

# Generated at 2022-06-22 23:04:09.754108
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    instance = FreeBSDHardwareCollector()
    assert isinstance(instance, HardwareCollector)
    assert isinstance(instance, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:04:21.619407
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import platform
    import sys

    # Skip this test if not on FreeBSD
    if platform.system() != 'FreeBSD':
        sys.exit()

    facter_bin = 'facter'
    try:
        facter_bin = get_bin_path('facter')
    except:
        facter_bin = False

    # Skip this test if facter not installed
    if facter_bin is False:
        sys.exit()

    (rc, out, err) = module.run_command('%s -p --json' % facter_bin)

    facts = json.loads(out)

    fbsd_hw = FreeBSDHardware()
    fbsd_hw_facts = fbsd_hw.populate()

    # Validate against facter facts
    assert fbsd_hw_facts['bios_date']

# Generated at 2022-06-22 23:04:29.535870
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hw = FreeBSDHardware(module=module)
    devices = hw.get_device_facts()['devices']
    assert(isinstance(devices, dict))
    assert('sda' in devices)
    for disk in devices:
        assert(isinstance(devices[disk], list))
        for d in devices[disk]:
            assert(isinstance(d, str))
            assert(re.search(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)', d))



# Generated at 2022-06-22 23:04:39.808463
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleStub:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
        def run_command(self, cmd, check_rc=False, encoding=None):
            self.run_command_rc = self.rc
            self.run_command_out = self.out
            self.run_command_err = self.err
            return (self.rc, self.out, self.err)
        def get_bin_path(self, cmd, required=False):
            if self.run_command_out:
                return 'dmidecode'
            else:
                return ''

# Generated at 2022-06-22 23:04:51.884939
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """Unit test for method get_memory_facts of class FreeBSDHardware."""
    import sys
    import unittest
    from ansible.module_utils.facts.freebsd.hardware import FreeBSDHardware
    from units.module_utils import facts_dumper

    class FakeModule(object):
        def __init__(self):
            self.run_command = sys.modules['units.module_utils.facts_dumper'].FakeModule.run_command

        def get_bin_path(self, path):
            return '/sbin/sysctl'

    test = FreeBSDHardware(FakeModule())
    memory_facts = test.get_memory_facts()
    print(memory_facts)


if __name__ == '__main__':
    test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-22 23:05:03.791298
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.facts import Facts

    if not os.path.exists(FreeBSDHardware.DMESG_BOOT):
        return

    dmesg_boot_content = get_file_content(FreeBSDHardware.DMESG_BOOT)
    assert dmesg_boot_content is not None

    dmesg_boot_uptime_strings = re.findall(r'^.+ up (\d+\sday(s)?\s)?(\d+:\d+),', dmesg_boot_content, re.MULTILINE)

    assert '1 day' in dmesg_boot_uptime_strings[-1][0]

    hardware = FreeBSDHardware(module=Facts())
    uptime_facts = hardware.get_uptime_facts()


# Generated at 2022-06-22 23:05:13.527852
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class module:
        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg, **kargs):
            out = 'hw.ncpu: 2\nvendor: GenuineIntel'
            return (0, out, '')

    m = module()
    h = FreeBSDHardware(m)
    output = h.get_cpu_facts()

    expected_output = {
        'processor': [],
        'processor_count': '2',
        'processor_cores': '1'
    }
    assert output == expected_output



# Generated at 2022-06-22 23:05:20.735701
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    m = FreeBSDHardware()
    sysdir = '/dev'
    m.module.run_command = lambda x: (0, 'ada0 da1 cd0', '')
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    assert_result = {
        'ada0': ['ada0s1', 'ada0s2', 'ada0s3'],
        'da1': ['da1s1'],
        'cd0': []
    }


# Generated at 2022-06-22 23:05:25.696809
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware('/tmp')


if __name__ == '__main__':
    # Unit test for constructor of class FreeBSDHardware
    test_FreeBSDHardware()

    fhw = FreeBSDHardware('/tmp')
    print(json.dumps(fhw.populate()))

# Generated at 2022-06-22 23:05:33.664503
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    '''
    TESTS FOR FreeBSDHardware.get_uptime_facts
    STAGES:
    * Set FreeBSDHardware._get_sysctl to return a well-known value
    * Run the test with a single thread
    * Run the test with a two threads
    * Check the returned value is correct
    '''
    import multiprocessing as mp
    import time

    def _get_sysctl(cmd, encoding=None):
        (retval, out, err) = (0, ' { "kern_boottime": 1188780171, "kern_boottime_usec": 158051 }', '')
        return (retval, out, err)

    # the single thread case
    FreeBSDHardware._get_sysctl = _get

# Generated at 2022-06-22 23:05:44.451081
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec={
        }
    )

    class MockModule(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return '/sbin/%s' % name

        def run_command(self, cmd, check_rc=True):
            return 0, '', ''

    m.get_bin_path = MockModule(m).get_bin_path
    m.run_command = MockModule(m).run_command

    fhw = FreeBSDHardware(m)

    fhw._device_facts_cache = {}
    device_facts = fhw.get_device_facts()
    assert device_facts == {'devices': {}}, device_facts


# Generated at 2022-06-22 23:05:56.108873
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Simulate module input parameters
    module_args = {}

    # Get a FreeBDSHardware instance to test method populate
    freebsdhardware_instance = FreeBSDHardware(module_args)

    # Run method populate of FreeBSDHardware class
    freebsdhardware_instance.populate()

    # Validate module output
    assert freebsdhardware_instance.facts['devices']['ada0'][0] == 'ada0s1'
    assert freebsdhardware_instance.facts['devices']['ada0'][1] == 'ada0s1a'
    assert freebsdhardware_instance.facts['devices']['ada0'][2] == 'ada0s1b'
    assert freebsdhardware_instance.facts['devices']['ada0'][3] == 'ada0s1d'


# Generated at 2022-06-22 23:06:06.532136
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    device_facts = {}
    device_facts['devices'] = {}
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')  # TODO: rc, disks, err = self.module.run_command("/sbin/sysctl kern.disks")
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')

    fh = FreeBSDHardware()
    sysdir = '/dev'
    if os.path.isdir(sysdir):
        dirlist = sorted(os.listdir(sysdir))
        for device in dirlist:
            d = drives.match(device)

# Generated at 2022-06-22 23:06:15.768377
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    assert hw.DMESG_BOOT == '/var/run/dmesg.boot'
    assert hw.get_cpu_facts()
    assert hw.get_memory_facts()
    assert hw.get_uptime_facts()
    assert hw.get_dmi_facts()
    assert hw.get_device_facts()
    assert hw.get_mount_facts()
    assert hw.populate()

# Generated at 2022-06-22 23:06:19.680479
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    har = FreeBSDHardware(module)
    har.populate()
    module.exit_json(changed=False, ansible_facts=dict(ansible_hardware=har.data))


# Unit test of main function

# Generated at 2022-06-22 23:06:30.472275
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Setup mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Setup mock module

# Generated at 2022-06-22 23:06:32.666780
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    harness = FreeBSDHardwareCollector(dict(module=None))
    facts = harness._collect()

    assert 'devices' in facts
    assert type(facts['devices']) == type({})
    assert 'vendor' in facts

# Generated at 2022-06-22 23:06:38.951288
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    hardware.module.run_command = run_command_mock

    cpu_facts = hardware.get_cpu_facts()

    assert len(cpu_facts['processor']) == 1
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-22 23:06:42.963903
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    x = FreeBSDHardwareCollector()
    assert isinstance(x,HardwareCollector)
    assert isinstance(x,FreeBSDHardwareCollector)
    assert x._platform == 'FreeBSD'
    assert x._fact_class == FreeBSDHardware
    assert isinstance(x._fact_class(),FreeBSDHardware)


# Generated at 2022-06-22 23:06:51.219543
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    def run_get_cpu_facts(mock_module, mock_file_exists):
        """
        For FreeBSDHardware.get_cpu_facts(),
        create a mock module object and mock file_exists function
        then call get_cpu_facts() to check the output
        """
        h = FreeBSDHardware(mock_module)

        # mock file exists function
        h.file_exists = mock_file_exists

        # call get_cpu_facts()
        fact = h.get_cpu_facts()

        # check the value of fact['processor']
        assert fact['processor'] == mock_cpu_fact

        # check the value of fact['processor_cores']
        assert fact['processor_cores'] == mock_cpu_cores_fact

        # check the value of fact['processor_count']

# Generated at 2022-06-22 23:06:57.811692
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Test case for method FreeBSDHardware.populate
    '''
    # Test procedure for FreeBSDHardware.populate for invalid option
    with pytest.raises(SystemExit):
        test_hardware = FreeBSDHardware()
        test_hardware.populate(collected_facts=None, module=None, options=["!invalid_option"])

    # Test procedure for FreeBSDHardware.populate for option 'all'
    module, test_module_args = get_mock_module_args()
    test_hardware = FreeBSDHardware()
    test_hardware.populate(collected_facts=None, module=module, options=["all"])
    assert test_hardware.cpu_facts['processor']
    assert test_hardware.cpu_facts['processor_cores']
    assert test_hardware.cpu_facts

# Generated at 2022-06-22 23:07:00.258066
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    c = FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:07:12.469613
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Unit test for method get_uptime_facts of class Hardware
    """

    # We need to mock both struct.calcsize and struct.unpack
    # in order to inject a known value in dmidecode output.
    # In order to do so, we create a subclass of Hardware (the class
    # implementation we want to test) and we mock those two functions
    # in the scope of the get_uptime_facts() method.

    import struct
    import time
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class FreeBSDHardwareSubclass(FreeBSDHardware):
        def get_uptime_facts(self):
            def mock_calcsize(struct_format):
                return 8

            def mock_unpack(struct_format, data):
                kern_boottime = 1000


# Generated at 2022-06-22 23:07:23.181974
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    mock_module = MockModule()
    mock_module.params = {}
    mock_module.run_command = Mock(return_value=(0, 'ada0p3', ''))
    mock_module.get_bin_path = Mock(return_value='/usr/bin/sysctl')
    from ansible.module_utils.facts import hardware
    hardware.sysctl = Mock(return_value=0)
    hardware.dmidecode = Mock(return_value=0)
    mock_module.get_bin_path = Mock(return_value='/usr/bin/dmidecode')
    facter = FreeBSDHardware(mock_module)
    facts = facter.get_device_facts()

    assert {'devices': {u'ada0p3': []}} == facts


# Generated at 2022-06-22 23:07:33.710826
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # TODO : remove this hack
    # You need to do a dummy import of the module (as the a real one will
    # import the actual module)
    module_path = os.path.realpath(__file__)
    module_dir = os.path.dirname(module_path)
    # You need to add a path so that python will be able to find them
    sys.path.append(module_dir)
    module = __import__('ansible.modules.system.freebsd_system')

    fixture_path = os.path.join(module_dir, 'fixtures', 'FreeBSDHardware_populate_dmesg.boot.out')
    test_module = module.AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'])})

# Generated at 2022-06-22 23:07:45.469769
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fh = FreeBSDHardware({})
    fh.module.run_command = lambda *args, **kwargs: (0, 'ada0p3', '')
    fh.module.get_bin_path = lambda *args, **kwargs: '/bin/true'
    d = fh.get_device_facts()
    assert set(['ada0', 'ada0p3']) == set(d['devices'].keys())
    assert d['devices']['ada0'] == ['ada0p3']

    # test for empty device list
    fh.module.run_command = lambda *args, **kwargs: (1, '', '')
    fh.module.get_bin_path = lambda *args, **kwargs: '/bin/true'
    d = fh.get_device_facts()
    assert d

# Generated at 2022-06-22 23:07:50.056800
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = DummyAnsibleModule()

    # Instantiate FreeBSDHardware
    obj = FreeBSDHardware(module)

    # Assert class attributes
    assert obj.platform == 'FreeBSD'
    assert obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-22 23:07:59.825464
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''Unit test for method get_dmi_facts of class FreeBSDHardware'''

    test_object = FreeBSDHardware()

    # dmidecode not installed.
    dmi_bin = test_object.module.get_bin_path('dmidecode')
    if dmi_bin is not None:
        os.system('mv %s %s_' % (dmi_bin, dmi_bin))

    # Test dmidecode executable not present.
    dmi_facts = test_object.get_dmi_facts()
    for (k, v) in dmi_facts.items():
        assert v == 'NA', '%s: %s' % (k, v)

    # Restore dmidecode executable.

# Generated at 2022-06-22 23:08:12.908770
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """Unit test for method `get_device_facts` of class FreeBSDHardware"""
    module = DummyAnsibleModule()
    freebsd_hw = FreeBSDHardware(module)
    freebsd_hw.get_device_facts()
    test_conditions = [
        {'message': 'The device facts should contain at least one drive', 'condition': len(freebsd_hw.facts['devices']) >= 1},
        {'message': 'The device facts must be a dictionary', 'condition': isinstance(freebsd_hw.facts['devices'], dict)}
    ]
    for condition in test_conditions:
        assert condition['condition'], condition['message']


# Generated at 2022-06-22 23:08:22.951439
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fake_module = type('Module', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/usr/bin/sysctl'})
    fake_module.sysctl = 'sysctl'
    fake_hardware_instance = FreeBSDHardware(module=fake_module)
    assert fake_hardware_instance.get_memory_facts() == {'memfree_mb': '0',
                                                         'memtotal_mb': '0',
                                                         'swapfree_mb': '0',
                                                         'swaptotal_mb': '0'}


# Generated at 2022-06-22 23:08:34.316268
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_facts = dict()
    hardware_facts['fqdn'] = 'hostname.domain.tld'
    hardware_facts['hostname'] = 'hostname'
    hardware_facts['domain'] = 'domain.tld'

    # Mock module and its params
    module = AnsibleModule(argument_spec=dict())

    # Mock facts
    collected_facts = dict()
    collected_facts['ansible_facts'] = {'hardware': hardware_facts}
    collected_facts['ansible_facts']['hardware']['fqdn'] = 'hostname.domain.tld'
    collected_facts['ansible_facts']['hardware']['hostname'] = 'hostname'
    collected_facts['ansible_facts']['hardware']['domain'] = 'domain.tld'

   

# Generated at 2022-06-22 23:08:37.464309
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    freebsd_hw = FreeBSDHardware(None)
    assert freebsd_hw is not None


# Generated at 2022-06-22 23:08:48.685636
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware_obj = FreeBSDHardware()
    hardware_obj.module = AnsibleModuleMock()
    hardware_obj.module.run_command = Mock(return_value=(0, "vm.stats.vm.v_page_size: 4096\n"
                                                            "vm.stats.vm.v_page_count: 1756201\n"
                                                            "vm.stats.vm.v_free_count: 303417", ""))
    result = hardware_obj.get_memory_facts()
    assert result['memfree_mb'] == 740
    assert result['memtotal_mb'] == 1701
    assert result['swapfree_mb'] == 0
    assert result['swaptotal_mb'] == 0


# Generated at 2022-06-22 23:09:02.207481
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class Module:
        def __init__(self, rc=0, out='', err=''):
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, executable):
            return None

        def run_command(self, cmd, encoding=None):
            return (self._rc, self._out, self._err)


# Generated at 2022-06-22 23:09:11.831866
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware({})
    hardware.module = type('Module', (), {'run_command': lambda self, command, check_rc=False, encoding='utf-8': (0, '1 6849112 5146448 164864 783004 60424 498260 59631045 15682838 574996932 1377682 16774144 1168732 8467968', '')})
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 6648
    assert memory_facts['memfree_mb'] == 1799
    assert memory_facts['swaptotal_mb'] == 5566
    assert memory_facts['swapfree_mb'] == 5302

# Generated at 2022-06-22 23:09:12.857381
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert FreeBSDHardware().get_dmi_facts()

# Generated at 2022-06-22 23:09:13.882868
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    # the test will be implemented in the future
    pass

# Generated at 2022-06-22 23:09:26.785865
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, command, check_rc=True, encoding=None, errors='strict'):
            return self.run_command_results.pop(0)

    hardware = FreeBSDHardware(MockModule())
    results = hardware.get_device_facts()

# Generated at 2022-06-22 23:09:30.263830
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hwc = FreeBSDHardwareCollector()
    assert isinstance(hwc, HardwareCollector)
    assert hwc._fact_class == FreeBSDHardware
    assert hwc._platform == 'FreeBSD'

# Generated at 2022-06-22 23:09:43.070766
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = FakeAnsibleModule()
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware_facts = hardware_collector.collect(module)
    assert hardware_facts['devices']['ada0'][0] == 'ada0s1a'
    assert hardware_facts['devices']['ada0'][1] == 'ada0s1b'
    assert hardware_facts['system_vendor'] == 'NA'
    assert hardware_facts['bios_vendor'] == 'NA'
    assert hardware_facts['bios_version'] == 'NA'
    assert hardware_facts['form_factor'] == 'NA'
    assert hardware_facts['product_name'] == 'NA'
    assert hardware_facts['product_serial'] == 'NA'

# Generated at 2022-06-22 23:09:51.037386
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fbh = FreeBSDHardware()
    fbh.module = MockModule()
    fbh.module.run_command = Mock(return_value=(0, '/dev/ada0p3        314368        0   314368     0%', ''))
    fbh.module.get_bin_path = Mock(return_value='/dev/ada0p3')
    assert fbh.get_device_facts()['devices'] == {'ada0': ['ada0p3']}



# Generated at 2022-06-22 23:09:56.600959
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': '!all'}
    module.exit_json = lambda x: x
    hardware = FreeBSDHardware(module=module)
    assert hardware.get_memory_facts()['swaptotal_mb'] == 0

# Generated at 2022-06-22 23:10:04.336856
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda x: '/usr/bin/%s' % x
    hardware = FreeBSDHardware(module=module)
    hardware.module.run_command = lambda x, **args: (0, 'hw.ncpu: 4', '')
    assert hardware.get_cpu_facts() == dict(
        processor=['Intel(R) Xeon(R) CPU E5-2640 v4 @ 2.40GHz'],
        processor_cores=2,
        processor_count='4'
    )

# Generated at 2022-06-22 23:10:07.466899
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector = FreeBSDHardwareCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDHardware
    assert collector.fact_class({}) is not None


# Generated at 2022-06-22 23:10:16.870333
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from module_utils.facts import Hardware
    from module_utils._text import to_text
    from io import StringIO
    import sys

    class TestModule(object):
        def __init__(self, stdout):
            self.exit_args = {}
            self.exit_args['failed'] = False
            self.exit_args['changed'] = False
            self.stdout = stdout
            self.stderr = StringIO()
            self.params = {}
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'

        def fail_json(self, **kwargs):
            self.exit_args.update(kwargs)
            self.exit_args['failed'] = True


# Generated at 2022-06-22 23:10:21.747627
# Unit test for constructor of class FreeBSDHardware

# Generated at 2022-06-22 23:10:24.881447
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module)
    memory_facts = fhw.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0


# Generated at 2022-06-22 23:10:27.584966
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():  # pylint: disable=redefined-outer-name
    my_obj = FreeBSDHardwareCollector()
    assert my_obj
    assert isinstance(my_obj, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:10:33.202083
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Run the constructor of class FreeBSDHardware
    hw = FreeBSDHardware({})

    # Check the result
    print("hw: {0}".format(hw))
    assert hw.platform == "FreeBSD"
    assert hw.cpu_facts["processor"] is None
    assert hw.cpu_facts["processor_count"] is None


# Generated at 2022-06-22 23:10:38.366927
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_class = FreeBSDHardware()
    result = test_class.get_dmi_facts()
    assert isinstance(result, dict)
    assert 'system_vendor' in result
    assert 'system_serial' in result
    assert 'system_product_name' in result
    assert 'system_product_version' in result

# Generated at 2022-06-22 23:10:43.036929
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    fake_module = FakeAnsibleModule()
    hardware.module = fake_module
    hardware.module.run_command = run_command_mock
    hardware.module.get_bin_path = get_bin_path_mock
    hardware.get_cpu_facts()
    assert fake_module.exit_args == {}


# Generated at 2022-06-22 23:10:56.031972
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class fake_module:
        def __init__(self):
            self.paths = ['/sbin/dmidecode']

        def get_bin_path(self, s, opt_dirs=[]):
            return self.paths[0]


# Generated at 2022-06-22 23:11:03.261142
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    def get_sysctl_mocked(command):
        # In fact, kern.boottime is a struct timeval.  Use a struct
        # encoded as a string here in order to test FreeBSDHardware.
        return (0, '@5c5cf5fc', '')

    # The mocking is applied only within the context block.  The object
    # FreeBSDHardware can be instantiated without mocking.
    with mock.patch.object(FreeBSDHardware, 'get_sysctl', get_sysctl_mocked):
        facts = FreeBSDHardware().get_uptime_facts()

    # The output from get_uptime_facts is seconds since Unix Epoch.
    assert facts['uptime_seconds'] == 1548962412

# Generated at 2022-06-22 23:11:15.529008
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create an instance of class FreeBSDHardware
    freebsd_hardware = FreeBSDHardware()

    # Test FreeBSD version 11.0-RELEASE-p10
    # Output of original method should have the form:
    # 1:51PM  up 6:40,  4 users,  load averages: 0.15, 0.18, 0.12
    # We will use a mock return_value to simulate this
    boottime_11_0_p10 = '''
kern.boottime: { sec = 1481953962, usec = 907844 } Mon Mar 13 13:52:42 2017
'''.strip().encode('utf-8')

    # Run the method with a mock

# Generated at 2022-06-22 23:11:25.227293
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    module = ModuleTestCase('setup.py')
    module.exit_json = lambda x: x

    class Hardware:
        def __init__(self, module):
            self.module = module

    class Base:
        def __init__(self, module):
            self.module = module

    class Memory:
        def __init__(self, module):
            self.module = module

    class CPU:
        def __init__(self, module):
            self.module = module

    class Processor:
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-22 23:11:32.194365
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    cpu_facts = FreeBSDHardware(module).get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor_vcpus'] == '1'
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz'


# Generated at 2022-06-22 23:11:33.914781
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    assert hardware.platform == 'FreeBSD'


# Generated at 2022-06-22 23:11:36.867315
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    args = {'module': None }
    fw = FreeBSDHardwareCollector(args)
    assert fw._fact_class == FreeBSDHardware
    assert fw._platform == 'FreeBSD'

# Generated at 2022-06-22 23:11:40.885304
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    devices = hardware.get_device_facts()['devices']

    assert len(devices.keys()) > 0
    for key in devices.keys():
        assert len(devices[key]) > 0
        for device in devices[key]:
            assert key in device


# Generated at 2022-06-22 23:11:51.815524
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Constructor of class FreeBSDHardware returns a new instance
    freebsd_hw = FreeBSDHardware(None)
    # method get_cpu_facts of class FreeBSDHardware returns a dictionary
    cpu_facts = freebsd_hw.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    # key processor in dictionary cpu_facts returns a list
    assert isinstance(cpu_facts['processor'], list)
    # key processor_cores in dictionary cpu_facts returns an integer
    assert isinstance(cpu_facts['processor_cores'], int)
    # key processor_count in dictionary cpu_facts returns an integer
    assert isinstance(cpu_facts['processor_count'], int)


# Generated at 2022-06-22 23:11:57.541753
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = AnsibleModuleMock({})
    m.get_bin_path = lambda _: '/bin/sysctl'
    h = FreeBSDHardware(m)

    cpu_facts = h.get_cpu_facts()

    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']

# Generated at 2022-06-22 23:12:01.868523
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Use try/except to set flag to False if the class throws an
    # exception while being instantiated
    try:
        hw_collector = FreeBSDHardwareCollector()
    except:
        hw_collector = False
    assert(hw_collector)


# Generated at 2022-06-22 23:12:13.749877
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_ans = []

        def get_bin_path(self, arg):
            return "/usr/bin/sysctl"

        def run_command(self, arg, check_rc=True, encoding=None):
            self.run_command_count += 1
            self.run_command_args.append(arg)
            rc = self.run_command_rcs.pop(0)
            ans = self.run_command_ans.pop(0)
            return (rc, ans, '')

    class MockHardware(FreeBSDHardware):
        def __init__(self):
            self.sysctl

# Generated at 2022-06-22 23:12:20.100078
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    mock_module = MockModule()
    mock_module.run_command.side_effect = [
        (0, '/dev:\n\taaa  bbb  ccc', ''),
        (0, '', ''),
        (0, '', ''),
    ]
    mock_module.get_bin_path.return_value = 'dmidecode'

    h = FreeBSDHardware(mock_module)
    device_facts = h.get_device_facts()
    assert device_facts['devices'] == {}


# Generated at 2022-06-22 23:12:29.423052
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = ''
    test_facts = FreeBSDHardware(test_module)
    test_list = ['ada0', 'ada0s1', 'ada0s2']
    test_device_facts = test_facts.get_device_facts()
    assert 'ada0' in test_device_facts['devices']
    assert 'ada0s1' in test_device_facts['devices']['ada0']
    assert 'ada0s2' in test_device_facts['devices']['ada0']
    assert set(test_device_facts['devices']['ada0']) == set(test_list)

# Generated at 2022-06-22 23:12:41.076046
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:12:47.619631
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Test get_dmi_facts of class FreeBSDHardware.
    This method opens a pipe on a subprocess running dmidecode.
    It is assumed that dmidecode is available and executable on path.
    Information returned by dmidecode is parsed and stored in a dict.
    This dict is checked for known content.
    '''
    # Create instance of class FreeBSDHardware
    test_hardware = FreeBSDHardware()
    # Call get_dmi_facts
    dmi_facts = test_hardware.get_dmi_facts()
    # Print dmi_facts
    print(dmi_facts)
    keys = dmi_facts.keys()
    print('dmi_facts contains %d items' % len(keys))
    # Check that dmi_facts contains the information we expect

# Generated at 2022-06-22 23:12:54.046425
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    hardware.module = module
    fp = open("/tmp/test_freebsd_hardware.txt","w")
    fp.write(json.dumps(hardware.get_device_facts()))
    fp.close()


# Generated at 2022-06-22 23:12:58.515791
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    from ansible.module_utils.facts.collection import FactsCollector
    from ansible.module_utils.facts import ansible_collector

    ansible_collector.add_collector('test_FreeBSDHardware', FreeBSDHardwareCollector)
    facts = FactsCollector()
    assert facts.__class__.__name__ == 'FactsCollector'

# Generated at 2022-06-22 23:13:06.196029
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = type('obj', (object,), {})
    module.run_command = lambda x: (1, '', '')
    module.get_bin_path = lambda x: '/usr/sbin/sysctl'
    bsd = FreeBSDHardware(module)
    swapinfo = type('obj', (object,), {})
    swapinfo.return_value = (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', '')
    bsd.module.run_command = swapinfo
    bsd.get_memory_facts()
    assert 'swapfree_mb' in bsd.facts
    assert 'swaptotal_mb' in bsd.facts
    assert 'memtotal_mb' in bsd.facts

# Generated at 2022-06-22 23:13:12.939365
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)

    result = hardware.get_cpu_facts()
    assert result['processor'][0] == 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz'
    assert result['processor_count'] == '2'
    assert result['processor_cores'] == '2'



# Generated at 2022-06-22 23:13:19.947092
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import sys
    sys.path.append('../../lib/python2.7/site-packages/ansible/module_utils')
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fhw = FreeBSDHardware()
    # returns a dictionary with keys 'processor' and 'processor_count'
    facts_dict = fhw.get_cpu_facts()
    # check the type of the return
    assert isinstance(facts_dict, dict)
    # check the size of the return
    assert len(facts_dict) == 2
    # check the keys
    assert sorted(facts_dict.keys()) == ['processor', 'processor_count']
    # check the types of the values
    assert isinstance(facts_dict['processor'], list)

# Generated at 2022-06-22 23:13:22.100999
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_facts = FreeBSDHardware()
    assert hardware_facts.platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:34.142751
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleMock():
        class RunCommand():
            return_code = 0
            stdout = "kern.boottime: { sec = \d+, usec = \d+ }\n"
            stderr = ""

        def run_command(self, cmd, check_rc=True, encoding=None):
            return self.RunCommand.return_code, self.RunCommand.stdout, self.RunCommand.stderr

        def get_bin_path(self, cmd):
            return "get_bin_path(%s)" % cmd

    uptime = {}
    now = int(time.time())
    start = now - (now % 512)
    return_data = "kern.boottime: {{ sec = %d, usec = 0 }}\n" % start
    module = ModuleMock()

# Generated at 2022-06-22 23:13:41.346635
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # arrange
    cpu_facts = {
        'processor': ['AMD Athlon(tm) II P360 Processor', 'AMD Athlon(tm) II P360 Processor'],
        'processor_cores': 2,
        'processor_count': 2
    }
    hardware = FreeBSDHardware()

    # act
    result = hardware.get_cpu_facts()

    # assert
    assert result == cpu_facts


# Generated at 2022-06-22 23:13:52.693649
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    import platform
    import subprocess
    import io

    mock_module = platform.system
    platform.system = lambda: 'FreeBSD'
    test_get_dmi_facts = FreeBSDHardware()

    # FreeBSD system without dmidecode
    subprocess.Popen.returncode = 1
    subprocess.Popen.communicate = lambda: ('', '')
    assert test_get_dmi_facts.get_dmi_facts() == {}

    # FreeBSD system with dmidecode
    subprocess.Popen.returncode = 0

# Generated at 2022-06-22 23:14:04.136463
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Unit test for method get_dmi_facts of class FreeBSDHardware"""
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:14:16.447138
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    Test dmi facts on FreeBSD system
    """
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class TestAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise AnsibleFailJson(kwargs['msg'])

        def exit_json(self, *args, **kwargs):
            raise AnsibleExitJson(kwargs['msg'])
