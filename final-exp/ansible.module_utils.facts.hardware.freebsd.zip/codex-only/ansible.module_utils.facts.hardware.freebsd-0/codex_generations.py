

# Generated at 2022-06-22 23:04:24.209159
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # We only care about the struct_format and struct_size variable values,
    # and not their use, so we can patch them in.
    original_format = '@L'
    original_size = struct.calcsize(original_format)
    original_struct = struct
    struct_format = '@L'
    struct_size = 8

    class MockedStruct(object):
        def calcsize(cls, fmt):
            return struct_size

    hardware = FreeBSDHardware(None)
    # We can define a function which will return a specific value for each call
    # to time.time().

# Generated at 2022-06-22 23:04:29.232743
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({})
    assert hardware.platform == 'FreeBSD'


# Generated at 2022-06-22 23:04:32.510303
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    d = FreeBSDHardware({})
    assert d.platform == "FreeBSD"
    assert d.DMESG_BOOT == "/var/run/dmesg.boot"



# Generated at 2022-06-22 23:04:36.252130
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fa = FreeBSDHardware()
    d = {}
    fa.populate(d)
    assert 'processor_count' in d.keys()
    assert 'processor' in d.keys()
    assert 'processor_cores'in d.keys()
    assert d['processor_count'] == '1'
    assert d['processor_cores'] == '1'
    assert d['processor'][0] == 'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz'


# Generated at 2022-06-22 23:04:49.210269
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware


# Generated at 2022-06-22 23:04:54.813375
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    test_object = FreeBSDHardware()
    current_facts = test_object.populate()
    assert 'ansible_facts' in current_facts
    assert current_facts['ansible_facts']['datacenter'] == 'NA'


# Generated at 2022-06-22 23:04:56.307826
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    x = FreeBSDHardwareCollector()
    assert x.get_platform() == 'FreeBSD'

# Generated at 2022-06-22 23:05:04.863605
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    freebsd_hardware = FreeBSDHardware()
    freebsd_hardware.module = MockModule()
    freebsd_hardware.module.run_command = MagicMock(return_value=(0, 'hw.ncpu: 4\n', ''))
    result = freebsd_hardware.get_memory_facts()
    assert result == {
        'memfree_mb': 0,
        'memtotal_mb': 0,
        'swapfree_mb': 0,
        'swaptotal_mb': 0
    }



# Generated at 2022-06-22 23:05:16.292319
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    import unittest

    # Test input data
    dmidecode_out = """# dmidecode 3.2
Getting SMBIOS data from sysctl(8).
SMBIOS 2.7 present.

Handle 0x0002, DMI type 2, 15 bytes
Base Board Information
Designed for: MS-7613
	Manufacturer: Micro-Star International
	Product Name: MS-7613
	Version: 1.0
	Serial Number: None
"""

    # Test result

# Generated at 2022-06-22 23:05:28.471091
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleStub():
        def __init__(self, *args, **kwargs):
            self.run_command_args = []
            self.run_command_kwargs = []
            self.run_command_exception = []
            self.run_command_exception_message = []

        def get_bin_path(self, command):
            return '/sbin/' + command

        def run_command(self, args, **kwargs):
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)
            if self.run_command_exception:
                e = self.run_command_exception.pop(0)
                msg = self.run_command_exception_message.pop(0)
                raise e(msg)

# Generated at 2022-06-22 23:05:40.808409
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockFreeBSDHardware(FreeBSDHardware):

        def __init__(self):
            self.sysctl_success = True
            self.swapinfo_success = True
            self.swapinfo_pagesize = 4096
            self.swapinfo_pagecount = 4096
            self.swapinfo_freecount = 4096
            self.swapinfo_total = 4096 * 4096
            self.swapinfo_free = 4096 * 4096
            self.swapinfo_swapused = 0
            self.swapinfo_swapusedpercent = 100
            self.swapinfo_swapcapacity = 100

        def run_command(self, command, **kwargs):
            self.command = command
            rc = 0
            err = ''

# Generated at 2022-06-22 23:05:53.158819
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    with open('tests/unit/module_utils/facts/hardware/FreeBSDHardware.txt') as f:
        test_data = f.read()
    module = FakeModule(cmd='./ansible-test hardware --targets foo', params={'gather_subset': 'all'})
    hw = FreeBSDHardware(module)
    hw.get_dmi_facts = lambda: test_data
    facts = hw.populate()
    # test the facts populated by dmidecode
    assert facts['form_factor'] == 'Other'
    assert facts['system_vendor'] == 'LENOVO'
    assert facts['bios_version'] == '3KCN25WW '
    assert facts['product_name'] == '4237F4U'

# Generated at 2022-06-22 23:06:03.967444
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class LocalModule:
        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'dmesg':
                mock_path = '/path/to/mock/dmesg'
            elif name == 'dmidecode':
                mock_path = '/path/to/mock/dmidecode'
            elif name == 'swapinfo':
                mock_path = '/path/to/mock/swapinfo'

            return mock_path

    class LocalOption:
        def __init__(self):
            self.connection = 'local'
            self.gather_subset = []
            self.gather_timeout = 10
            self.gather_network_resources = 'no'
            self.fetch_nested_containers = '0'

    set_module_args

# Generated at 2022-06-22 23:06:16.143807
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockModule()
    hardware_facts = FreeBSDHardware(module)
    hardware_facts.populate()
    assert 'memfree_mb' in hardware_facts.data
    assert 'memtotal_mb' in hardware_facts.data
    assert 'swapfree_mb' in hardware_facts.data
    assert 'swaptotal_mb' in hardware_facts.data
    assert 'processor' in hardware_facts.data
    assert 'processor_cores' in hardware_facts.data
    assert 'processor_count' in hardware_facts.data
    assert 'devices' in hardware_facts.data
    assert 'uptime_seconds' in hardware_facts.data



# Generated at 2022-06-22 23:06:18.197493
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hard_dic = FreeBSDHardwareCollector.collect()
    for k, v in hard_dic.items():
        print(k, v)



# Generated at 2022-06-22 23:06:21.719461
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    hardware.populate()

    assert len(hardware.facts) > 0

# Generated at 2022-06-22 23:06:27.693388
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    h = FreeBSDHardware()
    h.module = MockModule()
    h.populate()
    assert h.facts['processor_cores'] == '4'
    assert h.facts['processor'] == ['Intel(R) Core(TM) i5-3427U CPU @ 1.80GHz']
    assert h.facts['processor_count'] == '4'
    assert 'devices' in h.facts



# Generated at 2022-06-22 23:06:35.629570
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fake_module = FakeModule()
    hardware = FreeBSDHardware(fake_module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'][0] == "Intel(R) Core(TM) i7-3520M CPU @ 2.90GHz"
    assert cpu_facts['processor_cores'] == "2"
    assert cpu_facts['processor_count'] == "4"


# Generated at 2022-06-22 23:06:45.498305
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fhw = FreeBSDHardware()

    class mock_module(object):
        def run_command(self, cmd, check_rc=True):
            return (0, out, '')


# Generated at 2022-06-22 23:06:52.504894
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware()
    (rc, out, err) = m.module.run_command('sysctl -b kern.boottime', encoding=None)
    (kern_boottime, ) = struct.unpack('@L', out[:struct.calcsize('@L')])
    uptime_seconds = int(time.time() - kern_boottime)
    assert uptime_seconds == m.get_uptime_facts()['uptime_seconds']

# Generated at 2022-06-22 23:06:58.624473
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware, FreeBSDHardwareCollector
    from ansible.module_utils.facts import timeout

    fake_module = type("obj", (object,), {})()
    fake_module.get_bin_path = lambda self, arg: arg

    fake_module.run_command = lambda self, arg, check_rc=False, encoding=None: (0, '', '')
    hardware = FreeBSDHardware(fake_module)

    old_timeout = timeout._get_timeout()
    timeout._set_timeout(0)
    try:
        hardware.populate()
    finally:
        timeout._set_timeout(old_timeout)

# Generated at 2022-06-22 23:07:03.371690
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import doctest
    import tempfile
    import sys
    import os

    # Create a temporary file, with a kern.boottime value in
    # the SysV format.
    with tempfile.TemporaryFile() as t:
        t.write('kern.boottime: { sec = 1523959201, usec = 609054 }\n')
        t.seek(0)

        # Replace the module.run_command() function.

# Generated at 2022-06-22 23:07:16.280045
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    freebsd_hardware = FreeBSDHardware(module)

    # test a case with valid values
    page_size = 4096
    page_count = 1000000
    free_count = 400000
    sysctl_value = ("hw.pagesize", page_size), ("hw.physmem", page_count*page_size), ("vm.stats.vm.v_free_count", free_count)
    sysctl_output = "".join("{} = {}\n".format(*s) for s in sysctl_value)
    module.run_command = Mock(return_value=(0, sysctl_output, ""))
    memory_facts = freebsd_hardware.get_memory_facts()

# Generated at 2022-06-22 23:07:20.818769
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    device_facts = {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1e'],
                                'ada1': ['ada1s1f'], 'ada2': [], 'ada3': []}}
    hardware = FreeBSDHardware({'module_setup': True})
    assert hardware.get_device_facts() == device_facts


# Generated at 2022-06-22 23:07:31.929536
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    hardware = FreeBSDHardware()

    # Check default case
    hardware.module.run_command = lambda x, check_rc=False: (0, '/dev/ada0s1a / ufs ro,sync,noatime 1 1\n/dev/ada0s1b none swap sw 0 0\n/dev/ada0s1f /var ufs rw,userquota\n', None)
    assert hardware.get_device_facts() == {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1f']}}

    # Check failure case
    hardware.module.run_command = lambda x, check_rc=False: (1, None, None)
    assert hardware.get_device_

# Generated at 2022-06-22 23:07:39.092844
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    facts = hardware.populate()
    for fact in (
        'memfree_mb', 'memtotal_mb', 'processor', 'processor_cores', 'processor_count', 'uptime_seconds',
        'mounts', 'devices'
    ):
        assert fact in facts

    assert isinstance(facts['processor'], list)
    assert isinstance(facts['mounts'], list)
    assert isinstance(facts['devices'], dict)

    assert isinstance(facts['uptime_seconds'], int)
    assert isinstance(facts['processor_count'], int)

    for mount in facts['mounts']:
        assert 'size_total' in mount
        assert 'size_available' in mount

# Generated at 2022-06-22 23:07:46.834250
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    frbsd_hw = FreeBSDHardware(test_module)
    result = frbsd_hw.get_dmi_facts()

    assert result is not None
    assert('product_serial' in result.keys())
    for key in result.keys():
        assert(result[key] is not None)
        assert(isinstance(result[key], (str, bytes)))
        assert(len(result[key]) > 0)

# Generated at 2022-06-22 23:07:49.049947
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw_obj = FreeBSDHardware()
    assert hw_obj.platform == 'FreeBSD'

# Generated at 2022-06-22 23:07:51.298071
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert isinstance(fhc, HardwareCollector)


# Generated at 2022-06-22 23:07:54.237560
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    assert isinstance(hardware.get_uptime_facts(), dict)



# Generated at 2022-06-22 23:08:04.255518
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # The test fixture is a class, to allow the test class to inherit
    # the basic AnsibleModule object needed for these tests.
    class MockAnsibleModule:
        ''' Minimal mock version of AnsibleModule class for unit tests '''
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

        def run_command(self, cmd, encoding=None, check_rc=True):
            ''' Stub for AnsibleModule.run_command() '''
            self.run_command_args = cmd
            return (self.run_command_rc, self.run_command_stdout, self.run_command_stderr)

    class MockFreeBSDHardware(FreeBSDHardware):
        ''' Mock subclass of FreeBSDHardware '''

# Generated at 2022-06-22 23:08:10.738675
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsd_hw = FreeBSDHardware({'module_setup': True})
    memory_facts = freebsd_hw.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-22 23:08:18.465316
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    variable_manager = None
    loader = None
    module_name = 'unittest'

    module = FreeBSDHardwareCollector(module_name, 'localhost', variable_manager=variable_manager, loader=loader)

    now = time.time()
    boot_time = now - 50 * 60 * 60 * 24
    module._dmesg_boot = 'kern.boottime: { sec = %d, usec = 0 }\n' % boot_time
    assert module.get_uptime_facts() == {
        'uptime_seconds': 50 * 60 * 60 * 24,
    }

# Generated at 2022-06-22 23:08:29.894282
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Make parent class Hardware available for testing.
    from ansible.module_utils.facts.hardware.base import Hardware

    # Test cases without dmidecode binary
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommandNoDmidecode
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    # Check whether dmi_facts equals to expected result

# Generated at 2022-06-22 23:08:33.342341
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    facts = FreeBSDHardware(None).get_uptime_facts()
    assert isinstance(facts['uptime_seconds'], int)

# Generated at 2022-06-22 23:08:46.164920
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from .. import Hardware

    # Create a new object of class FreeBSDHardware
    hardware_object = FreeBSDHardware(module=None)

    # Create a dictionary of inputs
    inputs = {
            'module': None
    }

    # Set the above resource data as input data to the module
    hardware_object.module = inputs['module']

    # Create a dictionary of return values

# Generated at 2022-06-22 23:08:50.234340
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    hardware.populate()
    # calling FreeBSDHardware.populate() should populate
    # FreeBSDHardware.facts
    assert hardware.facts['processor'] == []
    assert hardware.facts['processor_cores'] == '1'
    assert hardware.facts['processor_count'] == '1'

# Generated at 2022-06-22 23:09:03.446643
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import ModuleFacts

    class BogusModule(object):
        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.exit_json = lambda **kwargs: sys.exit()

        def get_bin_path(self, executable, opt_dirs=[]):
            return executable

        def run_command(self, cmd, check_rc=False, encoding=None):

            return 0, '', ''

    module_facts = ModuleFacts()
    module_facts.populate()
    module_facts.gather_subset = ['all']
    module_facts.get_bin_path = lambda executable, opt_dirs=[] : executable

# Generated at 2022-06-22 23:09:11.396615
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    hardware = FreeBSDHardware(None)
    hardware.module = lambda: None
    hardware.module.run_command = lambda cmd, check_rc=True: (0, 'hw.ncpu:\t1\n', ''), None
    hardware.module.get_bin_path = lambda cmd, required=False: '/sbin/sysctl'
    hardware.module.get_file_content = lambda filename: ''
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == '1'

# Generated at 2022-06-22 23:09:23.453841
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import Hardware
    import time

    fbsd_hw = FreeBSDHardware()

    # Test no error, not timeout
    fbsd_hw.get_uptime_facts()

    # Test timeout
    fbsd_hw.get_uptime_facts.timeout = 1
    fbsd_hw.get_uptime_facts.start_time = time.time()
    try:
        fbsd_hw.get_uptime_facts()
    except TimeoutError:
        pass
    else:
        assert False, "Timeout not raised."

    # Test timeout expired
    fbsd_hw.get_uptime_facts.timeout = 1
    fbsd_hw.get_uptime_facts.start_time = 0

# Generated at 2022-06-22 23:09:26.410985
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware('module')
    uptime_facts = m.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-22 23:09:35.969308
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:09:40.855710
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Constructor for class FreeBSDHardwareCollector
    """
    freebsd_hw_collector = FreeBSDHardwareCollector()
    assert freebsd_hw_collector._platform == 'FreeBSD'
    assert freebsd_hw_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:09:43.445031
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware()
    assert hardware.platform == 'FreeBSD'



# Generated at 2022-06-22 23:09:47.698633
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()
    try:
        FreeBSDHardwareCollector(timeout=1)
        raise Exception('Second call to constructor of HardwareCollector should have failed with TypeError')
    except TypeError:
        pass



# Generated at 2022-06-22 23:10:00.563301
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import textwrap

# Generated at 2022-06-22 23:10:06.316139
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    mock_module = MockModule()
    mock_module.sysctl_rc = 0
    mock_module.sysctl_out = textwrap.dedent('''
        vm.stats.vm.v_page_size:        4096
        vm.stats.vm.v_page_count:   1015808
        vm.stats.vm.v_free_count:    768665
    ''')
    mock_module.swapinfo_rc = 0
    mock_module.swapinfo_out = textwrap.dedent('''
        Device          1M-blocks     Used    Avail Capacity
        /dev/ada0p3        314368        0   314368     0%
    ''')


# Generated at 2022-06-22 23:10:09.723962
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert isinstance(fhc, HardwareCollector)
    assert fhc._platform == FreeBSDHardwareCollector._platform
    assert fhc._fact_class == FreeBSDHardwareCollector._fact_class

# Generated at 2022-06-22 23:10:11.814778
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_collector = FreeBSDHardwareCollector()
    hardware_collector.collect()
    assert hardware_collector._platform == 'FreeBSD'

# Generated at 2022-06-22 23:10:24.606951
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class FakeModule(object):
        def run_command(self):
            return 0, 'ada0\nda1\nada0p3\nda1p3\nda1p7\ndisk0\ndisk1', ''

        def get_bin_path(self, executable):
            return '/sbin/sysctl'

    class FakeHardware(FreeBSDHardware):
        module = FakeModule()

    h = FakeHardware()
    devices = h.get_device_facts()
    assert devices == {
        'devices': {
            'ada0': [
                'ada0p3',
            ],
            'da1': [
                'da1p3',
                'da1p7',
            ],
            'disk0': [],
            'disk1': [],
        }
    }



# Generated at 2022-06-22 23:10:27.231693
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Unit test for method populate of class FreeBSDHardware"""

    # FreeBSDHardware.populate should return a dict()
    assert isinstance(FreeBSDHardware(None).populate(), dict)

# Generated at 2022-06-22 23:10:37.438098
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    sysctl_cmd = '/sbin/sysctl'
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    module = type('module', (object, ), {'run_command': run_command})

    def run_command(self, cmd, encoding=None):
        assert cmd == ['/sbin/sysctl', '-b', 'kern.boottime']
        return 0, b'boottime = { sec = 1357016415, usec = 345234 }\n', None

    fact = FreeBSDHardware()
    fact.module = module
    fact.populate()
    assert fact.uptime_seconds == 1357016415

# Generated at 2022-06-22 23:10:43.843068
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    from ansible.module_utils.facts.collector import GenericCollector
    from ansible.module_utils.facts import ansible_collector

    GenericCollector.collectors.pop(FreeBSDHardwareCollector._platform, None)
    facts_dict = ansible_collector.get_facts(FreeBSDHardwareCollector._platform)
    assert 'devices' in facts_dict
    assert 'memory' in facts_dict
    assert 'processor' in facts_dict
    assert 'uptime' in facts_dict

# Generated at 2022-06-22 23:10:48.483846
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    freebsd_hardware = FreeBSDHardware(module)
    rc, out, err = module.run_command("echo 2")
    assert(freebsd_hardware.get_cpu_facts()['processor_count'] == out)
    assert(len(freebsd_hardware.get_cpu_facts()['processor']) > 0)
    assert(freebsd_hardware.get_cpu_facts()['processor_cores'] == '1')


# Generated at 2022-06-22 23:10:56.987193
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ansible_module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True)
    fbsd_hardware = FreeBSDHardware(ansible_module)
    facts = fbsd_hardware.get_dmi_facts()
    assert isinstance(facts, dict)
    assert 'product_name' in facts.keys()
    assert 'bios_vendor' in facts.keys()
    assert 'system_vendor' in facts.keys()
    assert 'product_serial' in facts.keys()

# Generated at 2022-06-22 23:10:59.128372
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector = FreeBSDHardwareCollector()
    assert collector.platform == 'FreeBSD'
    assert collector.fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:11:12.738174
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_returns = []

        def get_bin_path(self, s):
            return s

        def run_command(self, args, check_rc=False, encoding=None):
            self.run_command_calls.append(args)
            return self.run_command_returns.pop(0)

    # Test with `sysctl` returning 0 and the expected output.
    module = TestModule()
    module.run_command_returns = [
        (0, "kern.boottime: { sec = 1551234567, usec = 123456 }", None),
    ]
    hw = FreeBSDHardware(module)
    uptime_facts = hw.get_upt

# Generated at 2022-06-22 23:11:22.211340
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class MockModule():
        """ mock module for FreeBSDHardware.get_dmi_facts() """
        def __init__(self, rc, out, err):
            """ mock return values for run_command() """
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command_args = []

        def get_bin_path(self, path):
            """ mock return values for get_bin_path() """
            if path == 'dmidecode':
                return '/usr/sbin/dmidecode'
            else:
                return None

        def run_command(self, args, check_rc=False, encoding=None):
            """ mock return values for run_command() """
            self.run_command_args.append(args)

# Generated at 2022-06-22 23:11:33.635681
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-22 23:11:37.409980
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = DummyAnsibleModule()

    # Get a FreeBSDHardware object
    obj = FreeBSDHardware(module)

    # Test the populate method of FreeBSDHardware
    obj.populate()
    assert obj.facts['devices']



# Generated at 2022-06-22 23:11:43.692888
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Mock class FreeBSDHardware
    class MockModule:
        def get_bin_path(self, arg):
            if arg == 'sysctl':
                return '/sbin/sysctl'
        def run_command(self, command, encoding=None, check_rc=False):
            if command == '/sbin/sysctl -n hw.ncpu':
                return (0, '4\n', '')
            if command == '/sbin/sysctl vm.stats':
                return (0, 'vm.stats.vm.v_page_size: 16384\nvm.stats.vm.v_page_count: 1048576\nvm.stats.vm.v_free_count: 1048576\n', '')
            return (1, '', '')

    fh = FreeBSDHardware()
    fh.module = MockModule

# Generated at 2022-06-22 23:11:54.272781
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:12:02.381305
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class FakeModule:
        ''' mock module to use in unit test'''
        class FakeResult:
            ''' mock result to use in unit test'''
            stdout = "";
            rc = 0;
        def run_command(self):
            return FakeModule.FakeResult()

        def get_bin_path(self):
            return '/usr/bin/'

    hardware = FreeBSDHardwareCollector().collect(FakeModule(), [])
    assert hardware.devices['ada0'][0] == 'ada0s1a'


# Generated at 2022-06-22 23:12:14.276724
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
        Unit test for method get_dmi_facts of class FreeBSDHardware
        The unit test need a system with dmidecode installed, and a test file named
        dmidecode.test in the same folder as this file. The content of the file are
        obtained from the about dmidecode command. It has two sections for the two possible
        outputs of dmidecode, one for a system with a SMBIOS implementation, the other for a
        system without SMBIOS implementation.
    """

    # Import needed class
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create utils instance
    Utils = FreeBSDHardware()

    import json
    import os
    import sys
    import pprint

    this_directory = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-22 23:12:24.191566
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """constructor of FreeBSDHardware class should return
    a valid instance of FreeBSDHardware class without raising
    any exceptions"""

    # no args
    obj = FreeBSDHardware()
    assert isinstance(obj, dict)

    # None argument raises ValueError
    try:
        obj = FreeBSDHardware(facts=None)
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError from FreeBSDHardware constructor"

    # invalid argument raises ValueError
    try:
        obj = FreeBSDHardware(facts=[])
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError from FreeBSDHardware constructor"

    # None argument raises ValueError
    try:
        obj = FreeBSDHardware(module=None)
    except ValueError:
        pass

# Generated at 2022-06-22 23:12:34.841590
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    global module
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError, timeout

    fs = FreeBSDHardware(module)

    @timeout()
    def get_memory_facts():
        return fs.get_memory_facts()

    try:
        info = get_memory_facts()
    except TimeoutError:
        info = None

    assert 'memtotal_mb' in info
    assert 'memfree_mb' in info
    assert 'swaptotal_mb' in info
    assert 'swapfree_mb' in info



# Generated at 2022-06-22 23:12:42.823281
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """ Test get_memory_facts method of class FreeBSDHardware """
    module = MagicMock(name='module')

    hardware = FreeBSDHardware(module=module)

    # Test the case when sysctl is not accessible
    hardware.module.get_bin_path.return_value = None
    res = hardware.get_memory_facts()
    assert 'memtotal_mb' not in res and \
           'memfree_mb' not in res and \
           'swaptotal_mb' not in res and \
           'swapfree_mb' not in res
    assert res == {}

    # Test the case when swapinfo is not accessible
    hardware.module.get_bin_path.return_value = '/sbin/swapinfo'
    hardware.module.run_command.return_value = (1, '', 'unknown error')
    res

# Generated at 2022-06-22 23:12:55.844497
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    set_module_args(dict(
        gather_subset='all',
        gather_timeout=10,
    ))
    from ansible_collections.ansible.community.plugins.module_utils import basic
    from ansible_collections.ansible.community.plugins.module_utils.facts import cache
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import pytest

    m_facts = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        bypass_checks=False,
    )

    HardwareFactCollector = cache.BaseFactCollector(m_facts)
    Hardware

# Generated at 2022-06-22 23:12:59.422835
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhw = FreeBSDHardwareCollector()
    assert fhw is not None
    assert fhw._fact_class is FreeBSDHardware
    assert fhw._platform is 'FreeBSD'
    assert fhw.platform is 'FreeBSD'
    assert fhw.collect() is not None

# Generated at 2022-06-22 23:13:00.832584
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({})
    assert isinstance(hardware, FreeBSDHardware)
    assert hardware.platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:13.718041
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    def create_module(params):
        class MyModule():
            def __init__(self, params):
                self.params = params
            def run_command(self, cmd, check_rc=True, encoding=None):
                if self.params.get('run_command', None):
                    return self.params['run_command'](cmd, check_rc, encoding)
                print("running command %s" % cmd)
                return self.params.get('run_command_rc', 0), self.params.get('run_command_out', ''), self.params.get('run_command_err', '')

# Generated at 2022-06-22 23:13:16.276012
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    inst = FreeBSDHardwareCollector()
    assert isinstance(inst, HardwareCollector)
    assert inst._fact_class == FreeBSDHardware
    assert inst._platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:28.283441
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for method populate of class FreeBSDHardware
    '''

    # Create an instance of FreeBSDHardware
    hardware = FreeBSDHardware()

    # Create a list of expected facts
    expected_facts = {}
    # Create a list of collected facts
    collected_facts = {}

    # Create mock functions of module
    def mock_run_command(cmd, check_rc=False):
        '''
        This is a mock function that simulates the function run_command in module AnsibleModule
        '''

        if cmd == '/sbin/sysctl -n hw.ncpu':
            rc = 0
            out = '1'
            err = ''
        elif cmd == '/sbin/sysctl vm.stats':
            rc = 0

# Generated at 2022-06-22 23:13:31.528511
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    assert hw.module.get_bin_path('sysctl')



# Generated at 2022-06-22 23:13:39.964096
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import pprint
    module = AnsibleModule(argument_spec=dict())
    hardware_instance = FreeBSDHardware()
    hardware_facts = hardware_instance.populate()

    # N.B. we do not check every fact but enough to have good coverage.
    # at least one expected device for every architecture.
    # we cannot use root directory as it's not existent on all FreeBSD flavors
    assert '/dev/ada0' in hardware_facts['devices'] or '/dev/sda' in hardware_facts['devices']

    assert 'amd' in hardware_facts['processor'][0].lower() or 'intel' in hardware_facts['processor'][0].lower()
    assert 1 <= int(hardware_facts['processor_cores'])
    assert 1 <= int(hardware_facts['processor_count'])

# Generated at 2022-06-22 23:13:51.368525
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware()

    # Test with kern.boottime sysctl (expected case)
    kern_boottime = "1554622138"
    kern_boottime_bytes = kern_boottime.encode("utf-8")
    assert hardware.get_uptime_facts()["uptime_seconds"] == int(time.time()) - int(kern_boottime)

    # Test if sysctl is missing (unexpected case)
    hardware.module.run_command = lambda cmd, check_rc=True, encoding=None: (1, "", "")
    assert hardware.get_uptime_facts() == {}

    # Test with random bytes from sysctl (unexpected case)
    hardware.module.run_command = lambda cmd, check_rc=True, encoding=None: (0, "abc", "")
   

# Generated at 2022-06-22 23:14:02.969683
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    import platform

    result = {}
    if sys.version_info < (2, 7):
        dmidecode_path = os.path.join(os.path.pardir, 'test', 'utils', 'dmidecode')
        test_platform_name = 'FreeBSD'
        test_platform_release = '9'
    else:
        test_platform_name = platform.system()
        test_platform_release = platform.release()
        dmidecode_path = '/usr/sbin/dmidecode'
    if test_platform_name == 'FreeBSD' and os.access(dmidecode_path, os.X_OK):
        test_module = type(sys)('ansible_test_module')
        test_module.run_command = lambda cmd: (0, '', '')
       

# Generated at 2022-06-22 23:14:14.905101
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.processor.freebsd import FreeBSDProcessor
    from ansible.module_utils.facts.storage.freebsd import FreeBSDStorage
    devices = {
        'devices': {
            'ada0': ['ada0s1a', 'ada0s1b', 'ada0s2'],
            'ada1': ['ada1s1a', 'ada1s1b', 'ada1s2'],
            'adb': []
        }
    }
    processor = FreeBSDProcessor(None)
    storage = FreeBSDStorage(devices.get('devices'), None)
    hardware = FreeBSDHardware(None, processor, storage)
    device_facts = hardware.get_device_facts()
    assert device_facts == devices
