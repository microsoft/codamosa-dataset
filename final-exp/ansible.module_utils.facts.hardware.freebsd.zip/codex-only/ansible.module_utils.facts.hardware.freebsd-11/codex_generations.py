

# Generated at 2022-06-22 23:04:18.053089
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] >= 1
    assert cpu_facts['processor_cores'] >= 1



# Generated at 2022-06-22 23:04:25.162646
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeModule({'swapinfo': True, 'sysctl': True})
    hardware = FreeBSDHardware(module)
    actual_memory_facts = hardware.get_memory_facts()

    expected_memory_facts = {'swaptotal_mb': 1024, 'swapfree_mb': 512, 'memtotal_mb': 2048, 'memfree_mb': 1024}
    assert actual_memory_facts == expected_memory_facts



# Generated at 2022-06-22 23:04:27.163849
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    h = FreeBSDHardware()
    device_facts = h.get_device_facts()
    assert type(device_facts['devices']) is dict

# Generated at 2022-06-22 23:04:34.608916
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self):
            self.params = {}

    class TestClass(object):
        def __init__(self):
            self.params = {}

    class TestOs(object):
        def __init__(self):
            self.params = {}

    class TmpBinDir(object):
        def __init__(self):
            self.params = {}

    tm = TestModule()
    tc = TestClass()
    to = TestOs()
    tmp_bin_dir = TmpBinDir()
    tmp_bin_dir.params['tmpdir'] = 'tmpdir'
    to.params['create'] = tmp_bin_dir
    tc.params['tmpdir'] = to
    tm.params['dl'] = tc
    fh = FreeBSDHardware(tm)



# Generated at 2022-06-22 23:04:41.772334
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not module.check_mode:
        hw = FreeBSDHardware()
        facts = hw.populate()
        keys = [
            'devices', 'memfree_mb', 'memtotal_mb', 'mounts', 'processor', 'processor_cores',
            'processor_count', 'swapfree_mb', 'swaptotal_mb', 'uptime_seconds'
        ]
        for key in keys:
            assert key in facts


# Generated at 2022-06-22 23:04:53.349825
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test FreeBSDHardware.get_cpu_facts()
    """

    # Test with dmesg.boot
    testobj = FreeBSDHardware()
    testobj.module.get_bin_path = lambda x: x
    testobj.module.run_command = lambda x, check_rc=False, encoding=None: (0, 'CPU: QEMU Virtual CPU version 1.5.3 (20141210)', '')
    cpu_facts = testobj.get_cpu_facts()
    assert cpu_facts['processor'] == ['QEMU Virtual CPU version 1.5.3 (20141210)']

    # Test without dmesg.boot
    testobj = FreeBSDHardware()
    testobj.module.get_bin_path = lambda x: x

# Generated at 2022-06-22 23:05:04.333167
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:05:16.042106
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Prepare a class to test
    class FreeBSDHardwareMock:
        def __init__(self):
            self.module = None

    # Return raw bytes
    def execute_command_mock(cmd, encoding):
        if cmd == ['/usr/sbin/sysctl', '-b', 'kern.boottime']:
            return (0, b'\x15\x53\x7b\x9b\x1f\x97', '')
        return (0, '', '')
    fh = FreeBSDHardwareMock()
    fh.module = type('', (), {})()
    fh.module.get_bin_path = lambda bin_name: bin_name
    fh.module.run_command = execute_command_mock
    res = fh.get_uptime_facts()
    expected

# Generated at 2022-06-22 23:05:22.676271
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)

    hardware.get_cpu_facts()
    assert hardware.facts['processor_count'] == '1'
    assert hardware.facts['processor_cores'] == '1'
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz']



# Generated at 2022-06-22 23:05:28.763669
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    run_command = lambda *args: (0, '{:d} {:d}'.format(int(time.time() - 150), 0).encode('utf-8'), '')

    module = lambda *args, **kwargs: None
    module.run_command = run_command

    hardware = FreeBSDHardware(module)
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == 150

# Generated at 2022-06-22 23:05:30.997800
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD', hardware_collector.platform



# Generated at 2022-06-22 23:05:43.121750
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fake_module = None
    fake_rc = 0
    fake_out = "TestInfo\n"
    fake_err = "TestInfo\n"
    hardware = FreeBSDHardware(fake_module)
    hardware.module.run_command = lambda x, encoding=None: (fake_rc, fake_out, fake_err)
    hardware.module.get_bin_path = lambda x: 'test_command'
    dmi_facts = hardware.get_dmi_facts()
    if dmi_facts['bios_date'] != 'TestInfo':
        raise AssertionError("bios_date should be TestInfo")
    if dmi_facts['bios_vendor'] != 'TestInfo':
        raise AssertionError("bios_vendor should be TestInfo")

# Generated at 2022-06-22 23:05:55.141307
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['architecture'] == 'x86_64'
    assert hardware_facts['devices']['ada0'] == ['ada0s1', 'ada0s2']
    assert hardware_facts['devices']['ada1'] == ['ada1s1', 'ada1s2']
    assert hardware_facts['devices']['cd0'] == []
    assert hardware_facts['devices']['da0'] == ['da0s1']
    assert hardware_facts['devices']['da1'] == ['da1s1', 'da1s2']
    assert hardware_facts['devices']['da2'] == ['da2s1']

# Generated at 2022-06-22 23:05:58.714238
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = None
    FreeBSDHardwareCollector._platform = 'FreeBSD'
    hw_collector = FreeBSDHardwareCollector(module)
    assert isinstance(hw_collector, HardwareCollector)

# Generated at 2022-06-22 23:06:04.270508
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_class = FreeBSDHardware()

    results = {
        'processor': ['AMD A6-5200 APU with Radeon(TM) HD Graphics (2097.0 MHz)'],
        'processor_cores': '2',
        'processor_count': '2',
    }

    test_results = test_class.get_cpu_facts()

    assert test_results == results


# Generated at 2022-06-22 23:06:10.669550
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    empty_facter = FreeBSDHardware({})
    empty_facter.get_memory_facts()

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class FakeModule:
        def __init__(self):
            self.exit_json = None
            self.run_command = None

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/swapinfo'

        def run_command(self, *args, **kwargs):
            return (0, 'Device\t  1M-blocks\tUsed\tAvail Capacity\n/dev/ada0p3\t  314368\t    0\t314368\t   0%', None)

    test

# Generated at 2022-06-22 23:06:13.366646
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw._platform == 'FreeBSD'


# Generated at 2022-06-22 23:06:17.419491
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test = FreeBSDHardware({})
    test_cpu_facts = {'processor': ['AMD Athlon(tm) II P360 Processor'],
                      'processor_cores': '2',
                      'processor_count': '2'}
    assert test.get_cpu_facts() == test_cpu_facts

# Generated at 2022-06-22 23:06:28.869776
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule:
        def __init__(self):
            self.bin_path = '/usr/bin'

        def get_bin_path(self, key):
            return os.path.join(self.bin_path, key)

    class TestFreeBSDHardware(object):
        def __init__(self):
            self.facts = {
                'devices': [],
                'memfree_mb': 0,
                'memtotal_mb': 0,
                'mounts': [],
                'processor': [],
                'processor_cores': '',
                'processor_count': 0,
                'swapfree_mb': 0,
                'swaptotal_mb': 0,
                'uptime_seconds': 0,
            }

        def populate(self):
            return self.facts


# Generated at 2022-06-22 23:06:40.956226
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module, timeout=5.0)
    facts = hardware_collector.collect(module.params, list(), module)
    assert 'hardware' in facts
    assert 'devices' in facts['hardware']
    assert 'mounts' in facts['hardware']
    assert 'processor' in facts['hardware']
    assert 'processor_cores' in facts['hardware']
    assert 'processor_count' in facts['hardware']
    assert 'memtotal_mb' in facts['hardware']
    assert 'memfree_mb' in facts['hardware']
    assert 'swaptotal_mb' in facts['hardware']
    assert 'swapfree_mb' in facts['hardware']
    assert 'uptime_seconds'

# Generated at 2022-06-22 23:06:43.622738
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert isinstance(hw, HardwareCollector)
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:06:54.285394
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import sys, os
    # avoid breaking our unittests
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LC_ALL'] = 'en_US.UTF-8'
    os.environ['LC_CTYPE'] = 'en_US.UTF-8'
    os.environ['LC_MESSAGES'] = 'en_US.UTF-8'
    os.environ['LC_NUMERIC'] = 'en_US.UTF-8'
    os.environ['LC_TIME'] = 'en_US.UTF-8'
    os.environ['LC_MONETARY'] = 'en_US.UTF-8'
    os.environ['LC_TRANSLIT'] = 'en_US.UTF-8'


# Generated at 2022-06-22 23:07:07.394871
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = FakeAnsibleModule()

    class FakeTime(object):
        def __init__(self):
            self._now = 1234
            self._mock_time = 0

        def time(self):
            return self._mock_time + self._now

    fake_time = FakeTime()

    class FakeStruct(object):
        def unpack(self, struct_format, out):
            struct_size = struct.calcsize(struct_format)
            if len(out) != struct_size:
                return ('NA', )

            (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])
            return (kern_boottime, )

    fake_struct = FakeStruct()

    class FakeSysctl(object):
        def __init__(self):
            self._

# Generated at 2022-06-22 23:07:19.553835
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fhw = FreeBSDHardware()
    fhw.module = MagicMock()
    fhw.module.get_bin_path.return_value = '/usr/local/sbin/dmidecode'

# Generated at 2022-06-22 23:07:30.907265
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default='all', type='list'),
    })

    hw_collector = FreeBSDHardwareCollector(module=module)
    hardware_facts = hw_collector.collect()
    for key in hardware_facts.keys():
        if key.startswith('ansible_') and hardware_facts[key] is None:
            hardware_facts[key] = 'NA'

    ansible_facts = dict()
    ansible_facts['ansible_local'] = dict()
    ansible_facts['ansible_local']['hardware'] = hardware_facts

    result = dict(
        ansible_facts=ansible_facts,
        changed=False,
    )
    module.exit_json(**result)



# Generated at 2022-06-22 23:07:33.441275
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Test with most important parameters
    obj = FreeBSDHardwareCollector(None)

    assert obj.platform == 'FreeBSD'
    assert obj.fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:07:45.120027
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Unit test for method populate of class FreeBSDHardware"""
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fact = FreeBSDHardware()

# Generated at 2022-06-22 23:07:53.410279
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = FreeBSDHardware(dict())
    assert module.platform == 'FreeBSD'
    expected_facts = set(['devices', 'processor', 'memfree_mb', 'processor_cores', 'processor_count', 'swapfree_mb',
                          'memtotal_mb', 'swaptotal_mb', 'uptime_seconds', 'mounts'])
    gathered_facts = set(module.get_facts().keys())
    assert expected_facts == gathered_facts

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-22 23:08:01.566283
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Forcibly load the class
    HardwareCollector.collectors.pop('FreeBSD', None)
    HardwareCollector.load_collector(FreeBSDHardwareCollector)

    m = FreeBSDHardware(None)
    mem = m._get_memory_facts()

    # Use assertIsInstance to provide better error messages on failure
    assert isinstance(mem['memtotal_mb'], int), "memtotal_mb is not an integer: {}".format(mem['memtotal_mb'])
    assert isinstance(mem['memfree_mb'], int), "memfree_mb is not an integer: {}".format(mem['memfree_mb'])
    assert isinstance(mem['swaptotal_mb'], int), "swaptotal_mb is not an integer: {}".format(mem['swaptotal_mb'])

# Generated at 2022-06-22 23:08:04.575572
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    data = FreeBSDHardware._test_get_uptime_facts()
    assert isinstance(data, dict)
    assert 'uptime_seconds' in data

# Generated at 2022-06-22 23:08:16.655028
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fixture = FreeBSDHardware({'module_setup': True})

    fixture.module.run_command = lambda x, check_rc=True: (0, 'hw.ncpu: 4', '')
    cpu_facts = fixture.get_cpu_facts()
    assert cpu_facts['processor_count'] == '4'
    assert cpu_facts['processor'] == [
        'Intel(R) Celeron(R) CPU G540 @ 2.50GHz',
        'Intel(R) Celeron(R) CPU G540 @ 2.50GHz',
        'Intel(R) Celeron(R) CPU G540 @ 2.50GHz',
        'Intel(R) Celeron(R) CPU G540 @ 2.50GHz'
    ]
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-22 23:08:29.007424
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def mock_run_command(*args, **kwargs):
        (rc, out, err) = (0, b'kern.boottime\t1463176930.856153 sec =\tThu Apr 28 18:45:30 2016', '')
        return (rc, out, err)

    class MockModule(object):
        def __init__(self, bin_path=None):
            self.bin_path = bin_path
        def get_bin_path(self, cmd, required=True):
            return self.bin_path

    module = MockModule()

    # Call the method
    hardware = FreeBSDHardware(module)
    hardware.module.run_command = mock_run_command
    hardware.get_uptime_facts()

    # Check the result
    assert hardware._collector_facts['uptime_seconds']

# Generated at 2022-06-22 23:08:41.558513
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_cases = [(1557049668.25, 1557049668), (1557049668.00, 1557049668), (1557049668, 1557049668)]
    for (test_time, exp_uptime_seconds) in test_cases:
        # Create a mock module.
        module = type('MockModule', (object,), {})
        module.command_warnings = []
        module.warnings = []

        # Mock out the sleep function.
        def mock_sleep(secs):
            pass
        module.sleep = mock_sleep

        # Mock out the run_command function.
        def mock_run_command(cmd, encoding=None):
            # We use the same test cases as above
            out = struct.pack('@L', int(test_time))
            return 0, out, ''
       

# Generated at 2022-06-22 23:08:54.064304
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # fmem is a fake executable
    fake_sysctl = '/usr/local/bin/fmem'

    # fmem output
    fake_sysctl_output = {
        'vm.stats.vm.v_page_size': "4096",
        'vm.stats.vm.v_page_count': "3924176",
        'vm.stats.vm.v_free_count': "2574099"
    }

    # emulate fmem output
    def fake_run_command(self, cmd, check_rc=False):
        data = cmd.split('-n ')[1]
        if data in fake_sysctl_output:
            return (0, fake_sysctl_output[data], None)
        else:
            return (1, "", None)

    # fake get_bin_path to return fmem

# Generated at 2022-06-22 23:09:07.123364
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.utils import get_file_content, get_mount_size
    from ansible.module_utils.facts.timeout import TimeoutError, timeout

    hardware = FreeBSDHardware()

    hardware.module.run_command = lambda *args, **kwargs: (0, '1', '')
    hardware.get_file_content = lambda x: ''
    hardware.get_mount_size = lambda x: {}


# Generated at 2022-06-22 23:09:08.619528
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhw = FreeBSDHardwareCollector()
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:09:13.198193
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    f = Facts()
    hw = FreeBSDHardware(module=f)

    assert hw.get_uptime_facts() == {'uptime_seconds': hw.uptime_seconds()}

# Generated at 2022-06-22 23:09:26.039524
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import time

    # Create an instance of FreeBSDHardware
    fhw = FreeBSDHardware()

    # mocker allows to mock objects and functions
    from ansible.utils.pytest_runner import mocker

    # Mocker requires a former import of mocker module
    import mocker

    # To check the results of get_uptime_facts, we mock the run_command
    # function.
    #
    # First we create a class with the same name as the function we want to
    # replace.
    class sysctl():
        pass

    # Now we create a function with the same name as the function we want to
    # replace.

# Generated at 2022-06-22 23:09:35.738427
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeModule({})
    facts = FreeBSDHardware(module)
    memory_facts = facts.get_memory_facts()

    if module.get_bin_path('sysctl'):
        assert memory_facts['memtotal_mb'] is not None
        assert memory_facts['memfree_mb'] is not None
        assert memory_facts['swaptotal_mb'] is not None
        assert memory_facts['swapfree_mb'] is not None
    else:
        assert memory_facts.get('memtotal_mb') is None
        assert memory_facts.get('memfree_mb') is None
        assert memory_facts.get('swaptotal_mb') is None
        assert memory_facts.get('swapfree_mb') is None


if __name__ == '__main__':
    # Unit test
    module = Fake

# Generated at 2022-06-22 23:09:39.137943
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = FakeModule()
    fhw = FreeBSDHardware(module)
    d = fhw.get_device_facts()
    assert d['devices'] is not None


# Generated at 2022-06-22 23:09:43.850315
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    device_facts = {
        'devices': {
            'ada0': ['ada0s1'],
            'ada1': ['ada1s1'],
            'ada2': ['ada2s1'],
        }
    }

    assert FreeBSDHardware(dict()).get_device_facts() == device_facts

# Generated at 2022-06-22 23:09:49.746697
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    results = hardware.populate()
    assert results.get('memtotal_mb')
    assert results.get('processor_count')
    assert results.get('devices')
    assert results.get('uptime_seconds')

# Generated at 2022-06-22 23:09:51.675463
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    HardwareCollector.test_HardwareCollector(FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:10:03.472882
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    freebsd_module = type('module', (object,), dict(run_command=lambda x: (0, '', ''),
                                                    get_bin_path=lambda x: None))
    freebsd_facts = FreeBSDHardware(freebsd_module)

# Generated at 2022-06-22 23:10:14.128196
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    _module = AnsibleModuleMock()
    output = """# dmidecode 3.0
Getting SMBIOS data from sysctl(3).
SMBIOS 2.7 present.

Handle 0x0001, DMI type 1, 27 bytes
System Information
    Manufacturer: VMware, Inc.
    Product Name: VMware Virtual Platform
    Version: None
    Serial Number: VMware-56 4d 3c 2c 03 75 2b de-d0 1d ee 68 a4 9d 24
    UUID: 424D3C2C-0375-2BDE-D01D-EE68A49D2433
    Wake-up Type: Power Switch
    SKU Number: Not Specified
    Family: Not Specified"""
    _module.run_command.return_value = (0, output, "")
    _FreeBSDHardware = FreeBSDHardware

# Generated at 2022-06-22 23:10:20.165374
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardwareCollector1 = FreeBSDHardwareCollector()
    hardwareCollector1.collect()
    hardwareCollector2 = FreeBSDHardwareCollector(load_on_init=False)

    assert hardwareCollector1.collector['FreeBSD'] is not None
    assert hardwareCollector1.collector['FreeBSD']._platform == 'FreeBSD'

    assert hardwareCollector2.collector['FreeBSD'] is None

# Generated at 2022-06-22 23:10:21.173370
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModuleMock()
    my_obj = FreeBSDHardware(module)
    assert my_obj


# Generated at 2022-06-22 23:10:31.168138
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule({'timeout': 10}, {'timeout': 10}, check_invalid_arguments=False)

    class TestClass:
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, executable):
            return executable

        def get_mount_size(self, path):
            return {
                'available_mb': 0,
                'capacity': 0,
                'device_mb': 0,
                'size_mb': 0,
            }

    class Test_module:
        def __init__(self, module):
            self.module = module

        def run_command(self, command, encoding=None):
            return (0, '', '')

    fact_class = FreeBSDHardware(TestClass(Test_module(module)))


# Generated at 2022-06-22 23:10:42.310831
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    class MockModule(object):

        def get_bin_path(self, name, True_or_False=None, opt_dirs=None):
            self.bin_path = '/sbin/sysctl'

    class FakeHardware(FreeBSDHardware):

        def __init__(self):
            self.module = MockModule()

    device_facts = FakeHardware()
    facts = device_facts.get_device_facts()
    assert 'devices' in facts
    assert 'ada0' in facts['devices']
    assert 'ada0' in facts['devices']['ada0']
    assert 'ada0s1' in facts['devices']['ada0']
    assert 'ada0s2' in facts['devices']['ada0']
    assert 'ada0s3' in facts['devices']['ada0']

# Generated at 2022-06-22 23:10:44.723011
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_instance = FreeBSDHardware()
    assert hardware_instance.get_cpu_facts() == {'processor': [], 'processor_count': '', 'processor_cores': ''}


# Generated at 2022-06-22 23:10:57.394254
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test module arguments
    module_args = {}
    module_args.update(dict(
        gather_subset="!all",
        filter="*memory*"
    ))

    # Setup AnsibleModule
    from ansible.module_utils.facts import module_provisioner
    module = module_provisioner(module_args, {'_ansible_version': '2.6.0'})

    # Setup ansible_module_freebsd_hardware
    module.run_command = run_command
    ansible_module_freebsd_hardware = FreeBSDHardware()
    ansible_module_freebsd_hardware.module = module
    memory_facts = ansible_module_freebsd_hardware.get_memory_facts()

    assert memory_facts['memfree_mb'] == 1249

# Generated at 2022-06-22 23:11:04.221149
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_obj = MockModule()
    module_obj.run_command = Mock(return_value=(0, b'\x00\x00\x00\x00\x00\x00\x03\x90', None))
    hardware = FreeBSDHardware(module_obj)
    facts = hardware.get_uptime_facts()
    assert facts['uptime_seconds'] == 2500


# Generated at 2022-06-22 23:11:13.522600
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    test_module = AnsibleModule(
        argument_spec = dict(
            timeout = dict(type='int', default=10),
        )
    )
    test_FreeBSDHardware = FreeBSDHardware(test_module)
    test_module_result = test_FreeBSDHardware.populate()

    assert test_module_result['memtotal_mb'] is not None
    assert test_module_result['memfree_mb'] is not None
    assert test_module_result['swaptotal_mb'] is not None
    assert test_module_result['swapfree_mb'] is not None

# Generated at 2022-06-22 23:11:15.717604
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """This will test the constructor of class FreeBSDHardwareCollector"""

    collector = FreeBSDHardwareCollector()
    assert isinstance(collector, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:11:27.427167
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    os.environ['LANG'] = 'C'

    current_dir = os.path.dirname(__file__)
    mock_dmesg_boot_file = os.path.join(current_dir, 'freebsd-dmesg.boot')
    os.symlink(mock_dmesg_boot_file, '/var/run/dmesg.boot')

    # Setup test data

# Generated at 2022-06-22 23:11:38.149659
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    current_dir = os.path.dirname(os.path.realpath(__file__))
    case_path = os.path.join(current_dir, "test_cases/")
    sysctl_output = open(case_path + "sysctl_vm.stats_expected_output", "r").read()
    swapinfo_output = open(case_path + "swapinfo_output", "r").read()

    test_module.run_command = MagicMock(return_value=(0, sysctl_output, ''))
    test_module.get_bin_path = MagicMock(return_value='/sbin/swapinfo')
    test_module.run_command = MagicMock(return_value=(0, swapinfo_output, ''))

   

# Generated at 2022-06-22 23:11:50.660885
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    #############################################################################################
    # Case 1: init class FreeBSDHardware with processing data from file dmesg_boot.txt
    #############################################################################################

    # Create FreeBSDHardware object
    fbsd_hardware = FreeBSDHardware({}, 'fake_rc', 'fake_out', 'fake_err')


# Generated at 2022-06-22 23:11:53.652494
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Setup argument for test
    module = None
    test_object = FreeBSDHardware(module)

    # Test get_cpu_facts()
    test_object.get_cpu_facts()



# Generated at 2022-06-22 23:11:55.508225
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fact_class = FreeBSDHardware()
    assert fact_class.populate()

# Generated at 2022-06-22 23:11:59.913327
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = DummyAnsibleModule()
    hardware = FreeBSDHardware(module=module)

    assert hardware.populate() is not None
    assert hardware.populate().get('uptime_seconds') == 1
    assert hardware.populate().get('devices') is not None


# Generated at 2022-06-22 23:12:11.862177
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    executable_not_found_msg = "cannot run dmidecode: [Errno 2] No such file or directory\n"
    m = {'run_command.return_value': ("", "", ""), 'get_bin_path.return_value': None}

    f = FreeBSDHardware(m)
    dmi_facts = f.get_dmi_facts()

    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['board_asset_tag'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_

# Generated at 2022-06-22 23:12:21.813293
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Set up test data
    fbsd_hw = FreeBSDHardware(module=module)
    sysctl = module.get_bin_path('sysctl')
    dmesg_boot = 'CPU: Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz (3601.69-MHz K8-class CPU)\n'

    # Test function get_cpu_facts
    fbsd_hw.module.run_command = lambda cmd, check_rc=False: (0, '2', '')
    cpu_facts = fbsd_hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'

# Generated at 2022-06-22 23:12:34.576119
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args


# Generated at 2022-06-22 23:12:38.349478
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    res = hardware.populate()
    for fact in ('processor_count', 'memtotal_mb', 'memfree_mb', 'swaptotal_mb', 'swapfree_mb'):
        assert fact in res

# Generated at 2022-06-22 23:12:45.061312
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    dummy_module = lambda *args: None
    dummy_module.run_command = lambda x, encoding=None, check_rc=True, warning=False: (0, '1 64\n2 64', 'error')
    f = FreeBSDHardware(dummy_module)
    f.get_memory_facts()
    assert f.facts['memtotal_mb'] == 64 * 1 * 2  # swapoff
    assert f.facts['memfree_mb'] == 64 * 1 * 2
    assert f.facts['swaptotal_mb'] == 64 * 1
    assert f.facts['swapfree_mb'] == 64 * 2


# Generated at 2022-06-22 23:12:49.486916
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardwarecollector = FreeBSDHardwareCollector()

    assert hardwarecollector.platform == 'FreeBSD'
    assert hardwarecollector._fact_class == FreeBSDHardware
    assert hardwarecollector._platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:00.304831
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.system.base import BaseFactCollector

    module = AnsibleModuleMock()

    # Populate dmesg.boot file
    sysdir = '/dev'
    dirlist = sorted(os.listdir(sysdir))
    device_facts = [l for l in dirlist if l.startswith('ada') or l.startswith('da') or l.startswith('acd')]

# Generated at 2022-06-22 23:13:13.299124
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''
    unit test for method get_cpu_facts of class FreeBSDHardware
    '''
    test_module = type('test_module', (object,), dict(run_command=lambda *args, **kwargs: dict(rc=0, err='', stdout='\n'.join(["hw.ncpu=8", "hw.machine=amd64", "hw.model=Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz"]))))

    test_module.get_bin_path = lambda *args, **kwargs: ''
    fact_module = FreeBSDHardware(test_module)
    result = fact_module.get_cpu_facts()
    assert result['processor_count'] == "8"
    assert result['processor_architecture'] == "amd64"

# Generated at 2022-06-22 23:13:17.555331
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    assert hardware.get_memory_facts()['memtotal_mb'] == 768
    assert hardware.get_cpu_facts()['processor_count'] == 2
    assert hardware.get_cpu_facts()['processor_cores'] == 1

if __name__ == '__main__':
    test_FreeBSDHardware()

# Generated at 2022-06-22 23:13:19.174539
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware()
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:25.315602
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    mod = 'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardwareCollector'
    my_obj = HardwareCollector()
    my_obj.collect()
    assert isinstance(my_obj, HardwareCollector)
    assert my_obj._fact_class.__name__ == 'FreeBSDHardware'
    assert my_obj._platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:36.623830
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # instantiate class
    obj = FreeBSDHardware(dict(), 'FreeBSD')
    # verify object key
    data = obj.populate()
    assert data['ansible_system'] == 'FreeBSD'
    # test get_cpu_facts
    cpu_facts = obj.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts
    # test get_memory_facts
    mem_facts = obj.get_memory_facts()
    assert 'memfree_mb' in mem_facts
    assert 'memtotal_mb' in mem_facts
    # test get_device_facts
    dev_facts = obj.get_device_facts()
    assert 'devices' in dev_facts
    # test get_dmi_facts


# Generated at 2022-06-22 23:13:41.156969
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.all_facts



# Generated at 2022-06-22 23:13:52.580653
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)

    # Define input arguments for method
    out = {
        'vm.stats.vm.v_page_size': '4096',
        'vm.stats.vm.v_page_count': '2098176',
        'vm.stats.vm.v_free_count': '132801',
    }

    # Create mock object
    sysctl = MagicMock(return_value=(0, out, ""))
    swapinfo = MagicMock(return_value=(0, "Device     1M-blocks   Used  Avail Capacity\n/dev/ada0p3      314368        0   314368     0%", ""))

    # Bind mock object to method get_bin_path of module
    hardware_obj.module.get

# Generated at 2022-06-22 23:13:58.709622
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    ''' Unit test for method populate of class FreeBSDHardware
    '''

    # Prepare a mock of module, this is a simple way to do it
    module = type('', (object,), dict(run_command=lambda *a, **k: (0, '', ''), get_bin_path=lambda *a, **k: None))

    facts = FreeBSDHardware(module)
    facts.populate()
    assert True

# Generated at 2022-06-22 23:14:10.698554
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = FreeBSDHardware(module)
    hardware_facts.populate()

    # Check dmi facts
    dmi_facts = hardware_facts.get_dmi_facts()
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['board_asset_tag'] != 'NA'
    assert dmi_facts['board_serial'] != 'NA'
    assert dmi_facts['board_name'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'
    assert dmi_facts['board_version'] != 'NA'
    assert dmi_

# Generated at 2022-06-22 23:14:19.362986
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # GIVEN: a mock instace of FreeBSDHardware
    module = FakeAnsibleModule()
    module.params = {}
    hardware = FreeBSDHardware(module)

    # WHEN: get_cpu_facts is called
    freebsd_cpu_facts = hardware.get_cpu_facts()

    # THEN: freebsd_cpu_facts must contain cpu data
    assert 'processor' in freebsd_cpu_facts
    assert 'processor_cores' in freebsd_cpu_facts
    assert 'processor_count' in freebsd_cpu_facts

