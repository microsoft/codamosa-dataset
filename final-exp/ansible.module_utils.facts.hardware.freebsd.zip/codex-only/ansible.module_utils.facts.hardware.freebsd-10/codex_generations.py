

# Generated at 2022-06-22 23:04:14.057568
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()

    assert hardware_collector
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:04:26.390963
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(return_value=(0, "4", None))
    test_module.get_bin_path = MagicMock(return_value="sysctl")

    test_hardware = FreeBSDHardware(test_module)
    test_hardware._dmesg_boot = "CPU: Intel(R) Xeon(R) CPU \nCPU: E5-2667 0 @ 3.00GHz (3002.04-MHz K8-class CPU)\nLogical CPUs per core: 1\n"
    facts = test_hardware.get_cpu_facts()

    assert facts['processor_count'] == "4"
    assert facts['processor_cores'] == "1"

# Generated at 2022-06-22 23:04:32.222937
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    collected_facts = {'ansible_lsb': {'distcodename': 'TIMTOWTDI', 'distdescription': 'TIMTOWTDI', 'distid': 'FreeBSD', 'distrelease': '11.0-RELEASE', 'distversion': '11.0-RELEASE'}}
    test_system = FreeBSDHardware(module=None, collected_facts=collected_facts)
    assert test_system.platform == "FreeBSD"

# Generated at 2022-06-22 23:04:41.226019
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import module_provisioner
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a FakeModule with a FakePopen object.
    module = basic.AnsibleModule(argument_spec={})
    module.Popen = module_provisioner.FakePopen
    module.run_command = module_provisioner.FakeRunCommand(module)
    setattr(module, 'params', {})
    setattr(module, 'check_mode', False)


# Generated at 2022-06-22 23:04:50.610784
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class FakeModule:
        def __init__(self):
            self.run_command = lambda cmd, encoding=None: (0, "4", None)

        def get_bin_path(self, name):
            return "/sbin/sysctl"

    module = FakeModule()
    fb_hw = FreeBSDHardware(module)
    cpu_facts = fb_hw.get_cpu_facts()
    assert cpu_facts['processor_count'] == "4"
    assert cpu_facts['processor'] == []


# Generated at 2022-06-22 23:04:54.920542
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    ''' Unit test for constructor of class FreeBSDHardwareCollector '''
    obj = FreeBSDHardwareCollector()
    assert obj.platform == 'FreeBSD'
    assert issubclass(obj.fact_class, FreeBSDHardware)


# Generated at 2022-06-22 23:05:01.419364
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = DummyAnsibleModule()
    module.run_command.return_value = [0, "4", 0]
    fhw = FreeBSDHardware(module)
    assert fhw.get_cpu_facts()['processor_count'] == 4
    assert 'processor_cores' not in fhw.get_cpu_facts().keys()
    assert isinstance(fhw.get_cpu_facts()['processor'], list)



# Generated at 2022-06-22 23:05:09.026155
# Unit test for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:05:18.779336
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:05:22.153335
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_facts_collector = FreeBSDHardwareCollector()
    assert hardware_facts_collector._platform == 'FreeBSD'
    assert hardware_facts_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:05:31.730118
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)
    dmi_facts = hardware_obj.get_dmi_facts()
    assert type(dmi_facts) is dict
    assert all(k in dmi_facts for k in ('bios_date', 'bios_vendor', 'bios_version',
        'board_asset_tag', 'board_name', 'board_serial', 'board_vendor',
        'board_version', 'chassis_asset_tag', 'chassis_serial',
        'chassis_vendor', 'chassis_version', 'form_factor', 'product_name',
        'product_serial', 'product_uuid', 'product_version', 'system_vendor'))

# Generated at 2022-06-22 23:05:43.288196
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class FakeModule(object):
        def run_command(self):
            return (0, '8', '')

        def get_bin_path(self):
            return 'sysctl'


# Generated at 2022-06-22 23:05:44.533735
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    assert isinstance(FreeBSDHardware(), FreeBSDHardware)

# Generated at 2022-06-22 23:05:52.248781
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware()
    # Create a device facts dict
    device_facts = {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1e', 'ada0s1f', 'ada0s1d', 'ada0s1g']}}
    # Call the method
    facts = fhw.get_device_facts()
    # Check the results
    assert facts == device_facts

# Generated at 2022-06-22 23:06:02.964523
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # mocking parameters
    class MockModule(object):
        def get_bin_path(self, path):
            return 'dmidecode'
        def run_command(self, cmd):
            return (0, '# dmidecode 2.12', None)

    # creating a mock module object
    mock_module = MockModule()

    # creating a FreeBSDHardware object with mock_module as parameter
    fbsd_hw = FreeBSDHardware(mock_module)

    # calling get_dmi_facts() method
    dmi_facts = fbsd_hw.get_dmi_facts()

    # testing the output
    assert dmi_facts['bios_date'] == 'NA'

    # mocking parameters
    class MockModule(object):
        def get_bin_path(self, path):
            return 'dmidecode'


# Generated at 2022-06-22 23:06:16.511267
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.module = AnsibleModule()
    collected_facts = {
        'ansible_architecture': 'x86_64',
        'ansible_cmdline': {'console': 'vga'},
        'ansible_distribution': 'FreeBSD',
        'ansible_distribution_major_version': '11',
        'ansible_distribution_version': '11.1-RELEASE',
        'ansible_kernel': 'FreeBSD',
        'ansible_machine': 'amd64',
        'ansible_pkg_mgr': 'pkg',
        'ansible_system': 'FreeBSD',
    }

    hardware_facts = hardware.populate(collected_facts)
    assert hardware_facts['devices']['ada0p3'] == ['ada0p3']
   

# Generated at 2022-06-22 23:06:18.957398
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    result = FreeBSDHardware().get_device_facts()

    assert result.get('devices') != {}
    assert 'devices' not in result.get('devices').keys()

# Generated at 2022-06-22 23:06:25.046959
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    facts = {'module': AnsibleModule(argument_spec={})}
    d = FreeBSDHardware(facts)
    result = d.get_device_facts()
    assert result == {'devices': {'ad0': ['ad0s1', 'ad0s2', 'ad0s3', 'ad0s4'], 'ada0': ['ada0s1', 'ada0s2']}}

# Generated at 2022-06-22 23:06:26.092348
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    my_object = FreeBSDHardwareCollector()
    my_object.collect()

# Generated at 2022-06-22 23:06:33.139221
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    freebsd = FreeBSDHardware('', module)
    result = freebsd.get_device_facts()
    assert 'devices' in result
    assert type(result['devices']) is dict

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:06:36.348713
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)

    assert hw.platform == 'FreeBSD'



# Generated at 2022-06-22 23:06:45.970080
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = FakeAnsibleModule()
    sysdir = '/dev'
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    hw = FreeBSDHardware(module)
    dirlist = sorted(os.listdir(sysdir))
    for device in dirlist:
        d = drives.match(device)
        if d:
            hw.device_facts['devices'][d.group(1)] = []
        s = slices.match(device)
        if s:
            hw.device_facts['devices'][d.group(1)].append(s.group(1))


# Generated at 2022-06-22 23:06:56.473838
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Arrange
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']
            self.exit_json = lambda v, **k: None
        def get_bin_path(self, name):
            return '/sbin/sysctl'

# Generated at 2022-06-22 23:07:00.196613
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """Test FreeBSDHardware class constructor and methods"""
    hardware = FreeBSDHardware(dict())
    hardware.populate()

# Generated at 2022-06-22 23:07:08.136978
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    d = FreeBSDHardware()

    my_memory_facts = d.get_memory_facts()
    assert type(my_memory_facts) is dict
    assert 'swaptotal_mb' in my_memory_facts
    assert 'memtotal_mb' in my_memory_facts
    assert 'swapfree_mb' in my_memory_facts
    assert 'memfree_mb' in my_memory_facts



# Generated at 2022-06-22 23:07:10.283203
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._platform == 'FreeBSD'



# Generated at 2022-06-22 23:07:17.198340
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    output = FreeBSDHardware(test_module).get_cpu_facts()
    assert output['processor_cores'] == '2'
    assert output['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']
    assert output['processor_count'] == '8'


# Generated at 2022-06-22 23:07:28.665194
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create a test FreeBSDHardware class
    module = AnsibleModule(argument_spec={})
    test_obj = FreeBSDHardware(module)

    # Initialize a test collection of facts
    facts = dict()

    # Call method populate to fill the test facts collection
    test_obj.populate(facts)

    # Assert that method populate worked properly
    assert 'freebsd' in facts['ansible_system']
    assert 'hardware' in facts
    assert 'memory_mb' in facts['hardware']
    assert 'cpu' in facts['hardware']
    if module.get_bin_path('dmidecode'):
        assert 'bios_date' in facts['hardware']
        assert 'bios_version' in facts['hardware']
        assert 'board_name' in facts['hardware']

# Generated at 2022-06-22 23:07:38.034269
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module,
                                                  section='hardware',
                                                  command='/tmp/doesnotexist',
                                                  fact_class=FreeBSDHardware)
    hardware_collector.populate()
    facts = module.params['ansible_facts']

    assert 'hardware' in facts
    assert 'devices' in facts['hardware']
    assert facts['hardware']['devices']
    assert 'processor' in facts['hardware']
    assert facts['hardware']['processor']
    assert 'processor_cores' in facts['hardware']
    assert facts['hardware']['processor_cores']
    assert 'processor_count' in facts['hardware']

# Generated at 2022-06-22 23:07:49.532442
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.module import AnsibleModule
    from ansible.module_utils.facts.system.freebsd.hardware import FreeBSDHardware
    from ansible.module_utils.facts.utils import MockModule

    # Initialization of FreeBSDHardware for tests
    module = AnsibleModule(argument_spec={})
    module.run_command = MockModule.run_command
    freebsd_hardware = FreeBSDHardware()
    freebsd_hardware.module = module

    # Set of tests
    uptime_facts = freebsd_hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert uptime_facts['uptime_seconds'] >= 0


# Generated at 2022-06-22 23:07:51.782826
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = FreeBSDHardware()
    assert type(m.get_cpu_facts()) is dict



# Generated at 2022-06-22 23:07:53.043784
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    FreeBSDHardwareCollector.collect(None)

# Generated at 2022-06-22 23:07:56.072464
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModule(argument_spec={})
    collector = FreeBSDHardwareCollector(module=module)
    assert collector.__class__.__name__ == 'FreeBSDHardwareCollector'


# Generated at 2022-06-22 23:08:08.039504
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class FreeBSDHardware
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    class AnsibleModuleMock(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, app):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            return (0, 'hw.ncpu: 1', '')

    class AnsibleModuleWrapper():
        def __init__(self):
            self.module = AnsibleModuleMock()
            return

        def __getattr__(self, item):
            if item == 'module':
                return self.module
            else:
                return None

    hw = FreeBSDHardware

# Generated at 2022-06-22 23:08:12.860138
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Note: not a real unit test, since this relies on the system uptime
    hardware = FreeBSDHardware()

    uptime_facts = hardware.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']

    assert uptime_seconds > 0

# Generated at 2022-06-22 23:08:21.915019
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    # Create a class object to test the method get_cpu_facts of class FreeBSDHardware
    hardware = FreeBSDHardware()

    # Test for case where sysctl is available for FreeBSD but dmesg.boot cannot be read
    # Expected the number of CPUs from sysctl but the information from dmesg.boot
    hardware.module.get_bin_path = lambda x: '/bin/sysctl'
    hardware.module.run_command = lambda x, check_rc=True, encoding=None: (0, '2', None)
    hardware.get_file_content = lambda *args, **kwargs: ''
    result = hardware.get_cpu_facts()

    assert result == {
        'processor': [],
        'processor_cores': None,
        'processor_count': '2',
    }

    # Test for case where sysctl is available

# Generated at 2022-06-22 23:08:28.883874
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    mock_module = type('MockModule', (object,), {
        'run_command': lambda cmd: [0, struct.pack('@L', 0x5a58b0f0), '']
    })()
    hardware = FreeBSDHardware(mock_module)

    assert hardware.get_uptime_facts() == {
        'uptime_seconds': int(time.time()) - 0x5a58b0f0
    }

# Generated at 2022-06-22 23:08:41.400996
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import os
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    import module_utils.facts.hardware.freebsd

    fh = module_utils.facts.hardware.freebsd.FreeBSDHardware(dict())

    dmi_facts = fh.get_dmi_facts()
    print("System product name : {}".format(dmi_facts['product_name']))
    print("System vendor : {}".format(dmi_facts['system_vendor']))
    print("System version : {}".format(dmi_facts['product_version']))
    print("System serial number : {}".format(dmi_facts['product_serial']))

# Generated at 2022-06-22 23:08:53.782121
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import configparser
    fake_module = configparser.RawConfigParser()
    fake_module.add_section("bins")
    fake_module.set("bins", "sysctl", str("/bin/true"))
    fake_module.set("bins", "swapinfo", str("/bin/true"))
    fake_module.add_section("commands")
    fake_module.set("commands", "sysctl_vm_stats", str("sysctl vm.stats"))
    fake_module.set("commands", "swapinfo", str("swapinfo"))
    fake_module.add_section("outputs")

# Generated at 2022-06-22 23:08:55.923085
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_instance = FreeBSDHardware()
    assert isinstance(hardware_instance, FreeBSDHardware)

# Generated at 2022-06-22 23:09:02.624379
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    # TODO: replace dummy with test case.
    dummy = {'dummy': 'dummy'}
    hw = FreeBSDHardware(module)
    hw.populate()
    # Verify that dmi_facts is populated
    assert hw.dmi_facts is not None


# Generated at 2022-06-22 23:09:04.374922
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert FreeBSDHardware.get_memory_facts(None) == {}



# Generated at 2022-06-22 23:09:15.085703
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import unittest

    class TestFreeBSDHardware(unittest.TestCase):
        def test_get_dmi_facts(self):
            bsdhw = FreeBSDHardwareCollector('/usr/bin')
            dmi_facts = bsdhw.get_dmi_facts()
            assert dmi_facts['bios_date'] == 'NA'
            assert dmi_facts['bios_vendor'] == 'NA'
            assert dmi_facts['bios_version'] == 'NA'
            assert dmi_facts['board_asset_tag'] == 'NA'
            assert dmi_facts['board_name'] == 'NA'
            assert dmi_facts['board_serial'] == 'NA'
            assert dmi_facts['board_vendor'] == 'NA'

# Generated at 2022-06-22 23:09:18.775509
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_sh = FreeBSDHardware()
    cpu_facts = test_sh.get_cpu_facts()
    assert len(cpu_facts['processor']) > 0
    assert cpu_facts['processor_cores'] > 0


# Generated at 2022-06-22 23:09:30.030458
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware
    processor_list = ['Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
                      'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
                      'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz',
                      'Intel(R) Core(TM) i7-4700MQ CPU @ 2.40GHz']
    cpu_facts = {'processor': processor_list,
                 'processor_cores': '4',
                 'processor_count': '4'}
    assert hardware.get_cpu_facts() == cpu_facts


# Generated at 2022-06-22 23:09:42.869701
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec = {})
    hw_obj = FreeBSDHardware(module=module)

    # Mock class method get_memory_facts to return pre-defined dict of facts
    def mock_get_memory_facts(self):
        return {
            'memtotal_mb': 16384,
            'memfree_mb': 10000,
            'swaptotal_mb': 1048576,
            'swapfree_mb': 99999,
        }
    hw_obj.get_memory_facts = mock_get_memory_facts.__get__(hw_obj, FreeBSDHardware)

    # Call method get_memory_facts and compare returned dict against pre-defined dict of facts
    memory_facts = hw_obj.get_memory_facts()

# Generated at 2022-06-22 23:09:50.363408
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Test FreeBSDHardware.get_cpu_facts()"""
    # init
    myFacts = FreeBSDHardware()
    sysctl = "/usr/bin/sysctl"
    # get cpu facts
    cpu_facts = myFacts.get_cpu_facts()
    # assert
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts



# Generated at 2022-06-22 23:09:55.613211
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    h = FreeBSDHardware(module=module)
    facts = h.populate()
    assert facts['devices']
    assert facts['devices']['ada1']
    assert facts['devices']['ada1'][0]

# Generated at 2022-06-22 23:10:05.990545
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # check that on FreeBSD, the dmi facts are retrieved via the dmidecode command
    module = FakeModule()
    mod_path = os.path.dirname(os.path.abspath(__file__))
    module.get_bin_path_mock = lambda x: os.path.join(mod_path, 'fake_bin', x)
    collector = FreeBSDHardwareCollector(module=module)
    fact_class = collector._fact_class
    facts = fact_class.get_dmi_facts()
    assert 'bios_date' in facts
    assert facts['bios_date'] == '09/12/2009'
    assert 'form_factor' in facts
    assert facts['form_factor'] == 'all-in-one'
    assert 'system_vendor' in facts

# Generated at 2022-06-22 23:10:15.764508
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    '''Unit test for class FreeBSDHardware in module ansible.module_utils.facts.hardware.freebsd'''
    facts = FreeBSDHardware(dict())
    rc = 0
    out = '''vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 123
vm.stats.vm.v_free_count: 23
vm.stats.vm.v_inactive_count:  11
vm.stats.vm.v_cache_count: 17
vm.stats.vm.v_free_reserved:  0
vm.stats.vm.v_wire_count: 17
vm.stats.vm.v_active_count:  17'''
    err = ''

# Generated at 2022-06-22 23:10:27.341174
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Load the module
    module = AnsibleModule(argument_spec=dict())

    # Create a dict with the expected result
    expected_result = { 'uptime_seconds': 1234 }

    # Load the mock for the get_bin_path function
    with nested(patch('ansible.module_utils.facts.hardware.freebsd.os.path.exists'),
                patch('ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware.module')) as (mock_exists, mock_module):
        mock_exists.return_value = True
        # We need to mock the run_command function as we are not able to get
        # the raw bytes directly from sysctl in a unittest.

# Generated at 2022-06-22 23:10:35.650556
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fhw = FreeBSDHardware()
    # Test for BIOS
    assert fhw.get_dmi_facts()['bios_vendor'] == 'NA'
    # Test for System
    assert fhw.get_dmi_facts()['system_vendor'] == 'NA'
    # Test for Board
    assert fhw.get_dmi_facts()['board_vendor'] == 'NA'
    # Test for Chassis
    assert fhw.get_dmi_facts()['chassis_vendor'] == 'NA'


# Generated at 2022-06-22 23:10:45.271005
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:10:51.764383
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware({})

    # Tell the mock module that the binary dmidecode exists and the dmidecode
    # binary returns the right output
    class MockModule:
        def get_bin_path(self, name):
            if name == "dmidecode":
                return "dmidecode"
            else:
                return None
        def run_command(self, command, check_rc=True, encoding=None):
            return (0, "mock output", None)

    freebsd_hardware.module = MockModule()

    # Check if the right output is returned
    dmi_facts = freebsd_hardware.get_dmi_facts()
    assert dmi_facts['bios_date'] == "mock output"
    assert dmi_facts

# Generated at 2022-06-22 23:10:57.657339
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_obj = FreeBSDHardware()
    expected_output = {
        'processor': ['Intel(R) Core(TM) i5-7360U CPU @ 2.30GHz'],
        'processor_cores': '2',
        'processor_count': '2',
    }
    assert test_obj.get_cpu_facts() == expected_output


# Generated at 2022-06-22 23:11:03.951554
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware(None)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:11:16.005588
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = Hardware()
    m.module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )
    dmi_facts = m.get_dmi_facts()
    assert isinstance(dmi_facts['bios_date'], str)
    assert isinstance(dmi_facts['bios_vendor'], str)
    assert isinstance(dmi_facts['bios_version'], str)
    assert isinstance(dmi_facts['board_asset_tag'], str)
    assert isinstance(dmi_facts['board_name'], str)
    assert isinstance(dmi_facts['board_serial'], str)
    assert isinstance(dmi_facts['board_vendor'], str)

# Generated at 2022-06-22 23:11:17.762083
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware(None)
    hw.populate()

# Generated at 2022-06-22 23:11:20.952522
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()

    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware
    assert hardware_collector._platform == 'FreeBSD'

# Generated at 2022-06-22 23:11:22.462245
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware({})
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:11:31.306793
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    test_cases = [
        {'input': {'devices': {}},
         'expected': {'devices': {'ada0': ["ada0s1a"]}}
         }
    ]

    for test_case in test_cases:
        test_obj = FreeBSDHardware()
        actual = test_obj.get_device_facts()
        assert actual == test_case['expected'], "Expected %s, got %s" % (
            test_case['expected'], actual)



# Generated at 2022-06-22 23:11:39.621507
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    If ansible runs on FreeBSD platform, try to get dmi facts for the system.
    If output from dmidecode can't be parsed as JSON, set it to "NA"
    """
    import sys
    if sys.platform.startswith('freebsd'):
        freebsd_hardware = FreeBSDHardware()
        dmi_facts = freebsd_hardware.get_dmi_facts()
        for flag, dmi_fact in dmi_facts.items():
            try:
                json.dumps(dmi_fact)
            except ValueError:
                return False
            except UnicodeDecodeError:
                return False
    return True

# Generated at 2022-06-22 23:11:51.984780
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    This unit test is designed to test the functionality of the method get_memory_facts of
    the class FreeBSDHardware of the module ansible.module_utils.facts.hardware.freebsd.

    It is assumed that the method is called with the arguments self and module where
    module is an instance of the module ansible.module_utils.facts.module_common.AnsibleModule
    and the return value is stored in the variable mem_facts.
    """

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    memory_facts = FreeBSDHardware().get_memory_facts()

    assert isinstance(memory_facts, dict)
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
   

# Generated at 2022-06-22 23:11:57.141149
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # https://github.com/ansible/ansible/pull/11469
    # Make sure the method "get_cpu_facts" of FreeBSDHardware class works
    # as expected.
    fhw = FreeBSDHardware({})
    cpu_facts = fhw.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-6300HQ CPU @ 2.30GHz']



# Generated at 2022-06-22 23:12:07.475815
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    # Mock subprocess.Popen and dmesg.boot
    from ansible.module_utils.facts.hardware.freebsd import MockPopen
    import ansible.module_utils.facts.hardware.freebsd as freebsd_mock
    freebsd_mock.subprocess.Popen = MockPopen
    freebsd_mock.FreeBSDHardware.DMESG_BOOT = './tests/unit/module_utils/facts/files/freebsd_dmesg.boot'

    # Import the module to be tested
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Instantiate a FreeBSDHardware object
    hardware = FreeBSDHardware()


    result = hardware.populate()
    assert type(result) is dict

# Generated at 2022-06-22 23:12:14.930771
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """
    Test for FreeBSDHardware class constructor
    """

    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware()

    # Create expected data from constructor
    expected_data = dict(uptime_seconds={},
                         device_facts={},
                         mount_facts={},
                         dmi_facts={},
                         cpu_facts={},
                         memory_facts={})

    # Compare expected data from constructor with data from object
    assert fhw.data == expected_data

# Generated at 2022-06-22 23:12:17.335226
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:12:28.334548
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-22 23:12:40.410274
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    h = FreeBSDHardware()
    h.module.run_command = lambda *args: (0, '1', '')
    h.module.get_bin_path = lambda *args: '/bin/sysctl'
    h.module.params['gather_timeout'] = 3
    h.module.params['gather_subset'] = ['!all']
    h.collect()
    facts = h.get_facts()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts

# Unit test

# Generated at 2022-06-22 23:12:42.102888
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    uut = FreeBSDHardwareCollector()
    assert uut is not None

# Generated at 2022-06-22 23:12:48.889064
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    facts_obj = FreeBSDHardwareCollector(module=module).collect()[0]
    facts = facts_obj.get_facts()

    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts



# Generated at 2022-06-22 23:12:56.700841
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule(object):
        def run_command(self, cmd, check_rc=True):
            return (0, '1', '')

        def get_bin_path(self, name):
            return 'sysctl'

    hardware = FreeBSDHardware(MockModule())
    hardware.populate()

    assert hardware.cpu_facts['processor_count'] == '1'
    assert hardware.cpu_facts['processor'] == []
    assert hardware.cpu_facts['processor_cores'] is None



# Generated at 2022-06-22 23:13:05.092698
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware_instance = FreeBSDHardware(module)
    harware_instance.populate()

    assert harware_instance.populate()["ansible_devices"]["root"][0] == "/dev/ada0p2"
    assert harware_instance.populate()["ansible_devices"]["root"][1] == "ada0p2"
    assert harware_instance.populate()["ansible_devices"]["root"][2] == "ada0"
    assert harware_instance.populate()["ansible_devices"]["root"][3] == "/dev"
    assert harware_instance.populate()["ansible_devices"]["root"][4] == "/dev/ada0"


# Generated at 2022-06-22 23:13:13.894111
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsd_hardware = FreeBSDHardware(dict())
    freebsd_hardware.module.run_command = lambda x: (0, 'vm.stats.vm.v_page_size: 65536 vm.stats.vm.v_page_count: 103787 vm.stats.vm.v_free_count: 123', '')
    memory_facts = freebsd_hardware.get_memory_facts()
    assert memory_facts == {
        'memtotal_mb': 669,
        'memfree_mb': 7
    }



# Generated at 2022-06-22 23:13:20.391719
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = FreeBSDHardware()

    # fake dmidecode output for bios-release-date, bios-vendor, bios-version,
    # baseboard-asset-tag, baseboard-product-name, baseboard-serial-number,
    # baseboard-manufacturer, baseboard-version, chassis-asset-tag,
    # chassis-serial-number, chassis-manufacturer, chassis-version,
    # chassis-type, system-product-name, system-serial-number, system-uuid,
    # system-version, system-manufacturer

# Generated at 2022-06-22 23:13:32.937174
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_exceptions = []
            self.run_command_executed = 0
            self.get_bin_path_args = []
            self.get_bin_path_exceptions = []
            self.get_bin_path_executed = 0

        def run_command(self, args, check_rc=None, encoding=None):
            self.run_command_args.append(args)
            self.run_command_executed += 1
            if self.run_command_executed > len(self.run_command_rcs):
                raise Exception('Increase the size of MockModule.run_command_rcs')

# Generated at 2022-06-22 23:13:40.459570
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = Mock(return_value="/sbin/sysctl")
    module.run_command = Mock(return_value=(0, "vm.stats.vm.v_page_size: 4194304\n"
                                               "vm.stats.vm.v_page_count: 1573796\n"
                                               "vm.stats.vm.v_free_count: 705370\n", None))

    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert "memtotal_mb" in memory_facts
    assert "memfree_mb" in memory_facts
    assert isinstance(memory_facts["memtotal_mb"], int)

# Generated at 2022-06-22 23:13:51.697132
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_facts = {'memfree_mb': 3023,
                 'memtotal_mb': 2097152,
                 'swapfree_mb': 0,
                 'swaptotal_mb': 0}
    test_module = type('module', (object,), {'run_command': lambda self, cmd, check_rc=False: (0, '', '')})
    test_module.get_bin_path = lambda self, name: '/sbin/sysctl'
    test_hardware_class = type('FreeBSDHardware', (FreeBSDHardware,), {'module': test_module})
    test_hardware = test_hardware_class()
    facts = test_hardware.get_memory_facts()
    assert facts[0] == mem_facts


# Unit tests for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:14:03.231991
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware


# Generated at 2022-06-22 23:14:08.239670
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    result = hardware.get_cpu_facts()

    # See if the number of processors is a digit
    assert result['processor_count'].isdigit()

    # See if we have at least one processor
    assert len(result['processor']) > 0

# Generated at 2022-06-22 23:14:15.665157
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import os

    # Create Hardware object
    testHardware = FreeBSDHardware()

    # Set sysctl binary path to custom path in order to execute test
    testHardware.module.run_command = os.path.join(os.path.dirname(__file__), 'bin', 'sysctl')

    # Test get_cpu_facts
    cpu_facts = testHardware.get_cpu_facts()
    assert(cpu_facts['processor'] == ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'])
    assert(cpu_facts['processor_cores'] == '2')
    assert(cpu_facts['processor_count'] == '8')
