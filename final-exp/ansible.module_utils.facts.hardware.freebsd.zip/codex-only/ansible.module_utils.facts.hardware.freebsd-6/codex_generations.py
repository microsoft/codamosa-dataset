

# Generated at 2022-06-22 23:04:22.427074
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModuleFixture(object):
        def __init__(self):
            self.run_command_results = [('', 'Test output', '')]
            self.fail_json_results = [{'msg': 'Test failure message'}]

        def get_bin_path(self, arg):
            return '/bin/' + arg

        def run_command(self, arg, encoding=None):
            return self.run_command_results.pop()

        def fail_json(self, **args):
            return self.fail_json_results.pop()

    class FakeFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            super(FakeFreeBSDHardware, self).__init__(module)
            self.module = module

    test_module = TestModuleFixture()
    bsd_hardware

# Generated at 2022-06-22 23:04:24.792885
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)
    assert hardware_obj.platform == 'FreeBSD'

# Generated at 2022-06-22 23:04:25.810474
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:04:31.460034
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_obj = FreeBSDHardware(None)
    test_obj.module.run_command = MagicMock()
    test_obj.module.run_command.return_value = "4", "", ""
    cpu_facts = test_obj.get_cpu_facts()
    assert cpu_facts['processor_count'] == "4"


# Generated at 2022-06-22 23:04:36.712812
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict(filter=dict(required=False, type='str')))
    bsd_hw = FreeBSDHardware(module=module)
    result = bsd_hw.get_cpu_facts()
    assert result['processor_cores'] != 'NA'
    assert result['processor_count'] != 'NA'



# Generated at 2022-06-22 23:04:39.733628
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fbsd_hw = FreeBSDHardware({})
    fbsd_hw_info = fbsd_hw.get_device_facts()
    assert 'devices' in fbsd_hw_info

# Generated at 2022-06-22 23:04:52.161227
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

    # Set up mocks
    swapinfo = MagicMock()
    swapinfo.return_value = '/usr/sbin/swapinfo'
    m = MagicMock(spec_set=FreeBSDHardware)
    m.module.get_bin_path.side_effect = swapinfo
    m.module.run_command.return_value = (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', None)

    memory_facts = m.get_memory_facts()
    assert memory_facts['swaptotal_mb'] == 312
    assert memory_facts['swapfree_mb'] == 312

    # negative test, where rc is not 0
    m.module.run_command

# Generated at 2022-06-22 23:05:03.791184
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:05:12.251036
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware_collector.collect()
    assert hardware_collector.hardware is not None
    assert hardware_collector.hardware.platform is not None
    assert hardware_collector.hardware.module is not None
    assert hardware_collector.hardware.module.params is not None
    assert hardware_collector.hardware.module._socket_path is not None



# Generated at 2022-06-22 23:05:17.118437
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bsdhardware = FreeBSDHardwareCollector()
    assert bsdhardware._platform == 'FreeBSD'
    assert bsdhardware._fact_class == FreeBSDHardware

if __name__ == '__main__':
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:05:25.141070
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    mock = AnsibleModuleMock()
    mock.params = {'module_name': 'freebsd_hardware'}
    mock.get_bin_path = lambda module_name: '/usr/bin/freebsd-hardware'
    mock.run_command = run_command

    # The mocked runs of sysctl return the following string.
    # root@freebsd:~ # /sbin/sysctl kern.disks
    # kern.disks: ada0 ada1 ada2

# Generated at 2022-06-22 23:05:29.679985
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hw = FreeBSDHardware({'module_setup': True, 'gather_subset': 'all', 'gather_timeout': 10}, ansible_facts={})
    hw.populate()
    assert hw.populate()['memtotal_mb'] > 0
    assert isinstance(hw.populate()['memtotal_mb'], int)

# Generated at 2022-06-22 23:05:41.912689
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    sys.path.append('../')
    from ansible.module_utils.facts import ModuleArgsParser
    import ansible.module_utils.facts.hardware.freebsd

    module_args = dict(
        gather_subset=['all'],
        filter='*',
    )

    module = ModuleArgsParser.from_json_dict(json.dumps(module_args))

    bsd_hardware = ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware(module)

    # test by providing dmidecode
    dmi_facts = bsd_hardware.get_dmi_facts()
    assert len(dmi_facts) > 0

    # test when dmidecode is not installed
    dmi_facts = bsd_hardware.get_dmi_

# Generated at 2022-06-22 23:05:44.953579
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.get_platform() == 'FreeBSD'
    assert fhc.get_fact_class() == FreeBSDHardware

# Generated at 2022-06-22 23:05:46.375033
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    obj = FreeBSDHardwareCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class is not None


# Generated at 2022-06-22 23:05:50.900169
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    obj = FreeBSDHardware(module)
    obj.get_dmi_facts()
    assert type(obj.get_dmi_facts()) is dict

# This class is a fake ansible module used in the unit test for the class FreeBSDHardware

# Generated at 2022-06-22 23:06:01.197956
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test get_cpu_facts of FreeBSDHardware class
    """
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.debug = False

        def get_bin_path(self, executable, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            return 0, 'hw.ncpu: 4', ''

    test_module = TestModule()
    hardware_instance = FreeBSDHardware()
    hardware_instance.module = test_module
    hardware_instance.populate()
    test_val = hardware_instance.get_cpu_facts()
    result = test_val['processor_count']
    assert result is not None


# Generated at 2022-06-22 23:06:10.725566
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0



# Generated at 2022-06-22 23:06:14.881763
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # mocking required modules and classes

    module = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    collect_subset_list = ['all']
    facts = {}
    mock_module = MagicMock(
        module=module,
        params={},
        check_mode=False,
        subset=collect_subset_list,
        collected_facts=facts)

    mock_module.facts = facts
    mock_module.check_mode = False

    hardware = FreeBSDHardware(mock_module)
    hardware.populate()

# Generated at 2022-06-22 23:06:16.203772
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    obj = FreeBSDHardwareCollector()
    assert obj._fact_class == FreeBSDHardware
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-22 23:06:27.642635
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    class_instance = FreeBSDHardware(module)

# Generated at 2022-06-22 23:06:29.630718
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    fhw = FreeBSDHardware(module)
    fhw.populate()

# Generated at 2022-06-22 23:06:34.697205
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    if not FreeBSDHardwareCollector.available():
        return

    # Test if FreeBSDHardware(module) can be created
    hardware_class_temp = FreeBSDHardware(None)
    assert hardware_class_temp

# Generated at 2022-06-22 23:06:44.175458
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import unittest

    class fake_module():
        def __init__(self):
            self.run_command = lambda cmd, encoding=None, check_rc=False: (0, 'seconds: 1234\n', '')
        def get_bin_path(self, cmd):
            if cmd == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

    class fake_args():
        pass

    class FreeBSDHardware_get_uptime_facts(unittest.TestCase):
        def setUp(self):
            self.facts = FreeBSDHardware(fake_module())

        def test_get_uptime_facts(self):
            result = self.facts.get_uptime_facts()

# Generated at 2022-06-22 23:06:45.891952
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware(dict())
    assert fhw.platform == 'FreeBSD'



# Generated at 2022-06-22 23:06:50.423747
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    facts = hardware.get_cpu_facts()
    assert type(facts['processor']) == list
    assert type(facts['processor_cores']) == int
    assert type(facts['processor_count']) == int



# Generated at 2022-06-22 23:06:53.724869
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Create a FreeBSDHardwareCollector without any arguments
    obj = FreeBSDHardwareCollector()

    # Make sure it is an instance of FreeBSDHardwareCollector
    assert isinstance(obj, FreeBSDHardwareCollector)

    # Assert the _fact_class and _platform properties
    assert obj._fact_class == FreeBSDHardware
    assert obj._platform == 'FreeBSD'

# Generated at 2022-06-22 23:07:06.746212
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:07:13.449913
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    ''' Set a fake module, then instantiate FreeBSDHardware() to get an object.'''
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    module = FakeModule({'freebsd_version': b'11.2-RELEASE-p5'})

    # This is the class object that we are testing.
    # It is instantiated with a module object
    freebsd_hw = FreeBSDHardware(module)
    # This should not be blank.
    assert freebsd_hw is not None

    # The platform should be FreeBSD
    assert freebsd_hw.platform == 'FreeBSD'


################################################################
#                                                              #
#   FakeModule class for FreeBSDHardware constructor testing   #
#                                                              #
################################################################
# A fake AnsibleModule class for FreeBSDHardware()
# needs the following

# Generated at 2022-06-22 23:07:15.709443
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware_obj = FreeBSDHardware(module)
    hardware_obj.module.get_bin_path = FakeGetBinPath()
    hardware_obj.module.run_command = FakeRunCommand()
    hardware_obj.get_dmi_facts()
    assert hardware_obj.facts['system_vendor'] == 'Fake System Vendor'

# Generated at 2022-06-22 23:07:16.830811
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    result = FreeBSDHardware(module)              # instantiate FreeBSDHardware
    assert 'FreeBSD' == result.platform

# Generated at 2022-06-22 23:07:24.288530
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.collector import get_collector_class

    # Collect all the facts
    facts = get_collector_class("hardware", "FreeBSDHardwareCollector")().collect()
    assert isinstance(facts, dict)

    # Test if the class `FreeBSDHardwareCollector` is the right class
    assert isinstance(facts, dict)
    assert 'ansible_facts' in facts
    assert 'hardware' in facts['ansible_facts']
    assert isinstance(facts['ansible_facts']['hardware'], dict)
    assert facts['ansible_facts']['hardware']['platform'] == 'FreeBSD'

# Generated at 2022-06-22 23:07:34.347787
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    class DummyModule(object):
        class DummyExecutable(object):
            def __init__(self, executable=None, timeout=None):
                self.executable = executable
                self.timeout = timeout
                self.DUMMY_BIN_PATH = '/tmp/dummy_bin_path'

            def get_bin_path(self, executable, required=False, opt_dirs=[]):
                if executable == "dmidecode":
                    return self.DUMMY_BIN_PATH

            def run_command(self, cmd, encoding=None, check_rc=False, data=None):
                pass


# Generated at 2022-06-22 23:07:36.980919
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware.module = DummyModule()
    return hardware.get_memory_facts()



# Generated at 2022-06-22 23:07:38.500545
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # instantiate collector
    FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:07:45.015121
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    #  Create the instance of FreeBSDHardware class
    freebsd_hardware = FreeBSDHardware()

    # Call get_dmi_facts method of FreeBSDHardware class
    dmi_facts = freebsd_hardware.get_dmi_facts()

    assert type(dmi_facts) == dict
    assert 'system_vendor' in dmi_facts.keys()
    assert type(dmi_facts['system_vendor']) == str

# Generated at 2022-06-22 23:07:56.422550
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import platform
    import subprocess

    if platform.machine() == 'x86_64':
        assert subprocess.call(['dmidecode', '--help']) == 0
        assert subprocess.call(['which', 'dmidecode']) == 0

        # give non-zero return code if requested dmi key is not present
        assert subprocess.call(['dmidecode', '-s', 'notpresent']) == 1

        # Run get_dmi_facts to populate facts
        fbsd_hw = FreeBSDHardware(dict())
        fbsd_hw_facts = fbsd_hw.populate()
        # These test values have been tested on the following machines
        #   1. VirtualBox VM
        #   2. vmware Fusion VM
        #   3. MacBook Pro
        #   4. A dedicated DELL server machine

# Generated at 2022-06-22 23:07:58.169211
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhwc = FreeBSDHardwareCollector()
    assert fhwc._fact_class is FreeBSDHardware



# Generated at 2022-06-22 23:08:08.559382
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Test FreeBSDHardware.get_memory_facts method.
    """
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.test_hardware.fixtures import get_freebsd_hardware_memory_facts
    class args:
        def __init__(self, module):
            self.module = module

    module = args(get_freebsd_hardware_memory_facts['args']['module'])

    freebsd_hardware = FreeBSDHardware(module)

    assert freebsd_hardware.get_memory_facts() == get_freebsd_hardware_memory_facts['result']


# Generated at 2022-06-22 23:08:19.758727
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:08:25.036753
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # unit test get_memory_facts
    m = FreeBSDHardware()
    memory_facts = m.get_memory_facts()
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']



# Generated at 2022-06-22 23:08:31.695808
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import pytest

    class TestFreeBSDHardware(FreeBSDHardware):

        def __init__(self, module):
            self.module = module
            self.dmi_facts = {}

    def TestFreeBSDHardware_get_bin_path(name):
        return 'path_to_dmidecode' if name == 'dmidecode' else None

    class TestAnsibleModule(object):

        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            raise AssertionError('unexpected call to fail_json')

        def get_bin_path(self, *args, **kwargs):
            return TestFreeBSDHardware_get_bin_path(*args, **kwargs)


# Generated at 2022-06-22 23:08:32.851249
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()


# Generated at 2022-06-22 23:08:45.603824
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:08:49.507869
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """Test whether the constructor of class FreeBSDHardwareCollector works."""
    module = FreeBSDHardwareCollector._create_mock_module()
    hardware_collector = FreeBSDHardwareCollector(module=module)
    assert hardware_collector._platform == 'FreeBSD'



# Generated at 2022-06-22 23:09:02.902329
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:09:08.133408
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """Test the constructor of class FreeBSDHardware"""
    from ansible.module_utils.facts import fact_collector

    # Invoke constructor
    output = HardwareCollector.collect(None, fact_collector.get_platform(None))

    # Verify that the object created is of the right type
    assert isinstance(output, dict)


# Generated at 2022-06-22 23:09:10.364952
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware({})
    hardware_devices = hardware.get_device_facts()
    assert hardware_devices['devices'] != []

# Generated at 2022-06-22 23:09:19.080611
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware()

    # mock method module.run_command
    def run_command_mock(self, args, *kwargs):
        assert args == ['/sbin/sysctl', '-b', 'kern.boottime']
        return 0, b'\x00\x00\x09\xbd\x00\x00\x01\x89', None
    hardware.module.run_command = run_command_mock

    # call get_uptime_facts
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts == {'uptime_seconds': 1065213}

# Generated at 2022-06-22 23:09:31.647535
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    # Run the facts module.
    test_m = FreeBSDHardwareCollector(None)
    test_m.populate()
    os_facts = test_m.get_facts()

    # Test the base class.
    assert 'uptime_seconds' in os_facts
    assert 'devices' in os_facts
    assert 'mounts' in os_facts
    assert 'processor_cores' in os_facts
    assert 'processor' in os_facts
    assert 'vendor' in os_facts
    assert 'os_family' in os_facts
    assert 'os_name' in os_facts
    assert 'processor_count' in os_facts

    # Test FreeBSDHardware specific facts.
    assert 'memfree_mb' in os_facts
    assert 'memtotal_mb' in os_facts

# Generated at 2022-06-22 23:09:43.980923
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    import unittest
    import warnings

    try:
        with warnings.catch_warnings(record=True) as w:
            import ansible.modules.system.freebsd
    except ImportError:
        # Skip this test if modules are not available
        return None

    module = ansible.modules.system.freebsd.FreeBSDHardware()
    module.get_bin_path = lambda x: '/sbin/sysctl'
    now = int(time.time())
    boottime = now - 314159
    module.run_command = lambda command: (0, 'kern.boottime: {}.{} sec = {}:{}:{}'.format(
        boottime, 896000, now - boottime, now, now + 1), None)
    module.os = 'FreeBSD'
    module.stdout

# Generated at 2022-06-22 23:09:55.373142
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = get_mocked_module()

    # Mock methods and attributes used by the function
    module.get_bin_path.side_effect = lambda program: '/sbin/{}'.format(program)
    module.run_command.return_value = (0, read_file_content('tests/unit/unittests_data/freebsd_swapinfo.out'), '')
    hardware = FreeBSDHardware(module)
    assert hardware.get_memory_facts() == {
        'memtotal_mb': 1023,
        'memfree_mb': 990,
        'swaptotal_mb': 2046,
        'swapfree_mb': 990,
    }

# Generated at 2022-06-22 23:10:01.226083
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    def my_time_sleep(seconds):
        pass

    def my_time_time():
        return 1544444444.444444

    def my_run_command(cmd, data=None, check_rc=False, encoding=None):
        rc = 0
        if cmd == ['/usr/bin/sysctl', '-b', 'kern.boottime']:
            out = b'\x00\x00\x00\x00\x00\x00\x00\x00'
        else:
            out = b''
        err = b''
        return (rc, out, err)


# Generated at 2022-06-22 23:10:05.132086
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware_object = hardware_collector.collect()
    hardware_object.populate()
    device_facts = hardware_object.get_device_facts()
    assert device_facts

# Generated at 2022-06-22 23:10:15.000887
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Setup test data
    time_data = 1452952338
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    time_data_bytes = struct.pack(struct_format, time_data)
    time_data_length = len(time_data_bytes)

    # Setup expected data
    test_time = time_data
    expected_uptime_facts = {
        'uptime_seconds': int(time.time() - test_time),
    }

    # Setup test harness
    obj = FreeBSDHardware()

    # Call test method
    rc = 0
    out = time_data_bytes
    err = ''
    actual_uptime_facts = obj.get_uptime_facts(rc, out, err, time_data_length)

    # Verify results
   

# Generated at 2022-06-22 23:10:26.661095
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, 'virtual machine', ''))
    module.get_bin_path = Mock(return_value='/usr/sbin/dmidecode')
    HH = FreeBSDHardware(module)
    HH.get_dmi_facts()

# Generated at 2022-06-22 23:10:38.932697
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Arrange
    # FreeBSDHardware Class object
    bsd_hw = FreeBSDHardware()

    # Mock.run_command
    def mock_run_command(command, check_rc=True, encoding=None):
        if command == bsd_hw.module.get_bin_path("sysctl") + " -n hw.ncpu":
            return (0, "4\n", "")

# Generated at 2022-06-22 23:10:45.232470
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    class TestModule(object):
        def __init__(self, params):
            self.params = params
        def run_command(self, command, check_rc=True):
            return (0, '', '')
        def get_bin_path(self, command):
            return ''


# Generated at 2022-06-22 23:10:57.860230
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestModule(object):
        def get_bin_path(self, binary_name):
            return binary_name

        def run_command(self, cmd, check_rc=True):
            return 0, 'hw.ncpu: 2', ''

    r = TestModule()
    hw = FreeBSDHardware(r)
    assert(r.run_command.called)
    assert(hw.get_cpu_facts() == {'processor': [], 'processor_cores': None, 'processor_count': '2'})

    # Test reading processor from dmesg.boot
    dmesg_boot = get_file_content(FreeBSDHardware.DMESG_BOOT)

# Generated at 2022-06-22 23:11:01.084758
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def set_time():
        return {'uptime_seconds': 1453000}

    fbd = FreeBSDHardware()
    fbd.get_uptime_facts = set_time
    facts = fbd.populate()

    assert facts['uptime_seconds'] == 1453000



# Generated at 2022-06-22 23:11:13.819346
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # mock object for module
    class AnsibleModule:
        class RunCommandResult:
            def __init__(self, out, err, rc):
                self.stdout = out
                self.stderr = err
                self.rc = rc
        def get_bin_path(self, path):
            return '/bin/' + path
        def run_command(self, cmd, encoding=None):
            out = b'kern.boottime: Sat Aug 26 13:09:28 2017'
            err = b''
            rc = 0
            if b'error' in cmd:
                err = b'error'
                rc = 1

# Generated at 2022-06-22 23:11:24.507583
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    assert hardware.platform == 'FreeBSD'
    assert hardware.cpu_facts == {}
    assert hardware.get_cpu_facts()
    assert hardware.memory_facts == {}
    assert hardware.get_memory_facts()
    assert hardware.uptime_facts == {}
    assert hardware.get_uptime_facts()
    assert hardware.dmi_facts == {}
    assert hardware.get_dmi_facts()
    assert hardware.device_facts == {}
    assert hardware.get_device_facts()
    assert hardware.mount_facts == {}
    assert hardware.get_mount_facts()
    assert hardware.populate()


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-22 23:11:34.017420
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """
    Unit test for method populate of class FreeBSDHardware.
    """
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    collected_facts = {}
    freebsd_hardware = FreeBSDHardware()

    def run_command_mockreturn(a):
        return (0, '1', '')

    freebsd_hardware.module.run_command = run_command_mockreturn

    freebsd_hardware.get_mount_facts = lambda: {'a': 'b'}
    populated_facts = freebsd_hardware.populate()
    assert isinstance(populated_facts, dict)

# Generated at 2022-06-22 23:11:36.963767
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware()
    hardware.module = get_fake_module()
    assert hardware.get_device_facts() == {'devices': {}}


# Generated at 2022-06-22 23:11:42.144300
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModuleMock({})
    hw = FreeBSDHardwareCollector(module=module,
                                  collector=module,
                                  platform='FreeBSD',
                                  strict_evaluation=False)

    devices = hw.get_device_facts()['devices']
    assert 'da0' in devices
    assert len(devices['da0']) == 1
    assert 'da0s1a' in devices['da0']


# Generated at 2022-06-22 23:11:45.141769
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    result = FreeBSDHardwareCollector()
    assert result.platform == 'FreeBSD'
    assert result.fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:11:55.057004
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_facts = {}
    dmi_bin = '/usr/sbin/dmidecode'

    # Test if dmidecode executable file exists
    if os.path.exists(dmi_bin):
        hardware = FreeBSDHardware()
        hardware.module.get_bin_path = lambda x: dmi_bin
        dmi_facts = hardware.get_dmi_facts()
    else:
        print("%s does not exist, please install dmidecode package to" % dmi_bin)
        print("enable DMI facts for platform FreeBSD")

    print("DMI facts for platform FreeBSD")
    for key in list(dmi_facts):
        print("%s : %s" % (key, dmi_facts[key]))

if __name__ == '__main__':
    test_FreeBSDHardware_

# Generated at 2022-06-22 23:11:58.222094
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector.fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:12:08.555694
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    # This method should return a dictionary of dictionaries
    freebsd_hw = FreeBSDHardware(None)
    result = freebsd_hw.get_device_facts()['devices']
    assert isinstance(result, dict)
    for key in result:
        assert key.startswith('ada')   # 'ada' or 'ada0' or 'ada1' or 'da0' or...
        assert isinstance(result[key], list)
        for x in result[key]:
            assert x.startswith(key)   # 'ada0s1' or 'ada0s2' or 'ada1s1' or...


# Generated at 2022-06-22 23:12:19.403421
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    # Use FreeBSDHardware object
    hw = FreeBSDHardware()

    # Set return values for method run_command
    hw.module.run_command = set_ansible_module_run_command(
        [
            ("/sbin/sysctl kern.disks", None, "", 0),
        ]
    )

    # Test FreeBSDHardware.get_device_facts
    device_facts = hw.get_device_facts()
    assert 'devices' in device_facts and device_facts['devices'] == {}

    # Set return values for method run_command
    hw.module.run_command = set_ansible_module_run_command(
        [
            ("/sbin/sysctl kern.disks", "kern.disks: ada0\n", "", 0),
        ]
    )

   

# Generated at 2022-06-22 23:12:21.093385
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """This will test the constructor of FreeBSDHardwareCollector
    """
    freebsd_hc = FreeBSDHardwareCollector()
    assert freebsd_hc

# Generated at 2022-06-22 23:12:33.408401
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class FreeBSDHardwareTestClass(object):
        def run_command(self, cmd, encoding=None, check_rc=False):
            '''This is a stub for method module.run_command'''

# Generated at 2022-06-22 23:12:38.616662
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    actual = hardware.get_device_facts()
    expected = {u'devices': {u'ad0': [u'ad0s1', u'ad0s2']}}
    assert actual == expected

# Generated at 2022-06-22 23:12:45.424756
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.collection import FactCollector
    # initialize the collector
    fact_collector = FactCollector()

    # Populate the instance of FreeBSDHardware
    fact_collector.populate({'_ansible_version': '2.4.2', 'vars': {}})
    # Get the instance of FreeBSDHardware
    hardware = fact_collector.get_real_hardware_instance()
    if not hardware:
        raise Exception('hardware is not of the class FreeBSDHardware')

    # Make the assertions
    assert hardware.get_cpu_facts()
    assert hardware.get_memory_facts()
    assert hardware.get_dmi_facts()
    assert hardware.get_mount_facts()
    assert hardware.get_device_facts()
    assert hardware.get_uptime_facts()



# Generated at 2022-06-22 23:12:48.312012
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f = FreeBSDHardwareCollector(None)
    assert isinstance(f, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:12:59.578015
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Unit test for method get_device_facts of class FreeBSDHardware'''
    # Test 1 - Test get_device_facts and verify device facts
    sysdir = '/dev'
    FreeBSDHardware = FreeBSDHardware()
    device_facts = FreeBSDHardware.get_device_facts()
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    dirlist = sorted(os.listdir(sysdir))
    for device in dirlist:
        d = drives.match(device)
        if d:
            assert d.group(1) in device_facts['devices'].keys()

# Generated at 2022-06-22 23:13:03.986778
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware({})
    assert hw.platform == 'FreeBSD'
    assert hw.DMESG_BOOT == '/var/run/dmesg.boot'


if __name__ == '__main__':
    hw = FreeBSDHardware({})
    facts = hw.populate()
    for k, v in facts.items():
        print(k, v)

# Generated at 2022-06-22 23:13:15.562433
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    cpu_facts = {
        'processor': ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'],
        'processor_cores': 4,
        'processor_count': 4
    }
    f = FreeBSDHardware(dict(), dict())
    assert f.get_cpu_facts() == cpu_facts

if __name__ == '__main__':
    # Unit testing for FreeBSD module
    import sys
    #sys.path.append('/usr/lib/python3.3/site-packages/ansible/module_utils')
    sys.path.append('/usr/share/ansible/plugins/modules/cloud/freebsd')
    import ansible.module_utils.facts.hardware.freebsd

# Generated at 2022-06-22 23:13:21.951300
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import sys
    if sys.version_info[0] == 2:
        import mock
        builtin_string = '__builtin__'
    else:
        import unittest.mock as mock
        builtin_string = 'builtins'

    # Use a class from the module we are testing to construct mocks.
    mock_module = mock.MagicMock()
    mock_module.params = {}

    # Mock run_command to return output we want
    def run_command_side_effect(*args, **kwargs):
        if args[0][0] == 'sysctl':
            if args[0][1] == 'hw.ncpu':
                return (0, '2', '')

# Generated at 2022-06-22 23:13:23.501929
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware({})
    assert facts.platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:29.763608
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = DummyModule()
    hw = FreeBSDHardware(module=module)
    devices = hw.get_device_facts()

    assert 'devices' in devices
    assert isinstance(devices['devices'], dict)

    # Check the dict contains devices
    for device, slices in devices['devices'].items():
        assert isinstance(slices, list)



# Generated at 2022-06-22 23:13:35.261255
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={})
    f = FreeBSDHardware(test_module)

    f.module.run_command = mock.Mock(return_value=(0, '', ''))
    test_module.get_bin_path = mock.Mock(return_value='')

    assert f.get_device_facts()


# Generated at 2022-06-22 23:13:43.034622
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hw = FreeBSDHardware(dict(module=dict(run_command=lambda *args, **kwargs: (0, 'my-faux-output', None))))
    hw.module.get_bin_path = lambda *args: '/usr/local/sbin/dmidecode'
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['chassis_asset_tag'] == 'NA'

# Generated at 2022-06-22 23:13:49.750359
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    h = FreeBSDHardware()

# Generated at 2022-06-22 23:14:02.396199
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Unit test for method get_uptime_facts of class FreeBSDHardware.
    """

    # We fake a module instance to provide a required method.
    # (This one is not used by the tested method.)
    class FakeModule:
        @staticmethod
        def run_command(cmd, encoding=None):
            return 1, '', ''

        @staticmethod
        def get_bin_path(name, opts=None):
            return None

    class FakeHardware(FreeBSDHardware):
        def __init__(self):
            self.module = FakeModule()

    fake_hardware = FakeHardware()

    # Normal case: kern.boottime returns something.
    # We fake the struct.unpack() method.

# Generated at 2022-06-22 23:14:08.228017
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['memtotal_mb'] == int(os.sysconf("SC_PHYS_PAGES")) * int(os.sysconf("SC_PAGESIZE")) // 1024 // 1024

# Generated at 2022-06-22 23:14:09.913131
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    assert hardware.platform == 'FreeBSD'

# Generated at 2022-06-22 23:14:21.852787
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """Unit test for method get_uptime_facts of class FreeBSDHardware"""
    import sys
    import unittest
    import datetime

    class MockedModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            """Mock run_command

            Returns:
                output of unpack command as string
            """
            assert('-b' in cmd)
            assert('kern.boottime' in cmd)
            assert(encoding is None)
            boottime = datetime.datetime.now() - datetime.timedelta(seconds=10)
            _, low, high = boottime.timestamp().as_integer_ratio()
            return 0, struct.pack('@LL', high, low), ''

