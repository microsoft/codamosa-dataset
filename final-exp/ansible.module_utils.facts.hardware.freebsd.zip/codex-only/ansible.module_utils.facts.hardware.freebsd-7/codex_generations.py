

# Generated at 2022-06-22 23:04:17.996053
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module=module)
    hw.module.params = hw.module.params
    hw.module.params['fact_path'] = os.path.dirname(__file__)
    facts = hw.get_memory_facts()
    assert facts["memtotal_mb"] == 449
    assert facts["memfree_mb"] == 422
    assert facts["swaptotal_mb"] == 6579
    assert facts["swapfree_mb"] == 6579


# Generated at 2022-06-22 23:04:29.002003
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()

    # Create and configure a mocked module.
    module.run_command = Mock()
    # The return value of run_command is b'b\x00\x00\x00\x00\x00\x00\x00',
    # which is equivalent to 1562906240.
    module.run_command.return_value = (0, b'b\x00\x00\x00\x00\x00\x00\x00', '')

    # Instantiate a FreeBSDHardware object with the mocked module.
    h = FreeBSDHardware(module)

    # Call get_uptime_facts.
    uptime_facts = h.get_uptime_facts()

    # Assert that the returned value is the expected one.

# Generated at 2022-06-22 23:04:39.336512
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    class Module:
        def __init__(self):
            self.run_command_environ_update = os.environ

        def get_bin_path(self, _):
            return 'sysctl'

        def run_command(self, cmd, encoding=u'utf-8', errors=u'strict', debug=False, check_rc=True):
            # Run the command and get the results back
            # We need to get raw bytes, not UTF-8.
            cmd = "sysctl vm.stats"

            try:
                (rc, out, err) = self.run_command_impl(cmd, encoding=encoding, errors=errors, debug=debug)
            except Exception:
                rc = 1
                out = b''
                err = b'command failed'


# Generated at 2022-06-22 23:04:41.959501
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    result = FreeBSDHardwareCollector()
    assert result.platform == 'FreeBSD'
    assert result._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:04:50.217268
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # TODO: Find a way to use real memory facts
    mem_facts = {
        'memfree_mb': '4588',
        'memtotal_mb': '16333',
        'swapfree_mb': '32542',
        'swaptotal_mb': '32542'
    }
    test_obj = FreeBSDHardware()
    assert test_obj.get_memory_facts() == mem_facts



# Generated at 2022-06-22 23:05:02.057477
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    class FreeBsdSysCtl(object):
        def __init__(self, out):
            pass

        def run_command(self, cmd, **kwargs):
            ncpu = 2
            byte_string = str.encode('hw.ncpu: %s\n' % ncpu)
            return (0, byte_string, '')

        @staticmethod
        def get_bin_path(name):
            return 'sysctl'

    class FreeBsdDmesg(object):
        def __init__(self, dmesg):
            pass

        def run_command(self, cmd, **kwargs):
            msg = 'CPU: Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz (2794.61-MHz K8-class CPU)\n'

# Generated at 2022-06-22 23:05:06.242349
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(
        0,
        'ada0  ada1    da0   da1',
        ''
        ))
    sysdir = '/dev'
    fact = FreeBSDHardware(module)
    fact.get_device_facts()

    assert fact.facts['devices']['ada0'] == []
    assert fact.facts['devices']['ada1'] == []
    assert fact.facts['devices']['da0'] == []
    assert fact.facts['devices']['da1'] == []


# Generated at 2022-06-22 23:05:17.137374
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Test FreeBSDHardware get_dmi_facts method"""

# Generated at 2022-06-22 23:05:26.724015
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.utils.fake_ansible_module import FakeAnsibleModule
    module = FakeAnsibleModule()

    freebsd_hardware = FreeBSDHardware(module=module, collected_facts={})
    memory_facts = freebsd_hardware.get_memory_facts()

    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']

    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']

# Generated at 2022-06-22 23:05:29.833342
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware_obj = FreeBSDHardware(module)
    hardware_obj.get_cpu_facts()

# Generated at 2022-06-22 23:05:42.040814
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for method populate of class FreeBSDHardware
    '''
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=False
    )

    freebsd_hardware = FreeBSDHardware(module)
    module_facts_dictionary = freebsd_hardware.populate()

    assert 'uptime_seconds' in module_facts_dictionary
    assert 'uptime_seconds' in module_facts_dictionary
    assert 'uptime_seconds' in module_facts_dictionary
    assert 'uptime_seconds' in module_facts_dictionary
    assert 'uptime_seconds' in module_facts_dictionary
    assert 'uptime_seconds' in module_facts_dictionary


# Generated at 2022-06-22 23:05:45.196996
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    facts = FreeBSDHardware(module).populate()
    assert (facts['swaptotal_mb'] >= 0)

# Generated at 2022-06-22 23:05:56.432844
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})

    # Prepare fake arguments to simulate the FreeBSD system_get_boot_time
    # underlying call.
    def fake_sys_get_boot_time():
        return 1539675200
    def fake_time():
        return 1539686977
    original_sys_get_boot_time = FreeBSDHardware.system_get_boot_time
    FreeBSDHardware.system_get_boot_time = fake_sys_get_boot_time
    original_time = time.time
    time.time = fake_time

    # Create a new FreeBSDHardware object and test the get_uptime_facts method
    obj = FreeBSDHardware(module)
    uptime_facts = obj.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 18177}

    # Restore the

# Generated at 2022-06-22 23:06:01.792674
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    os_obj = FreeBSDHardware(dict())
    hardware_facts = os_obj.populate()
    # Check few facts
    assert hardware_facts['devices']
    assert hardware_facts['memtotal_mb']


# For testing above class, run it directly
if __name__ == '__main__':
    test_FreeBSDHardware_populate()

# Generated at 2022-06-22 23:06:14.256779
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    kern_boottime = int(time.time()) - 400
    out = struct.pack('@L', kern_boottime)
    hardware = FreeBSDHardware(None, None, None)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 400}

    out = struct.pack('@L', kern_boottime) + struct.pack('@L', 0)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 400}

    out = struct.pack('@LQ', kern_boottime, 0)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 400}

    out

# Generated at 2022-06-22 23:06:24.734482
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class module_mock:
        def get_bin_path(self, command):
            return '/sbin/sysctl'


# Generated at 2022-06-22 23:06:37.486862
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware()
    hardware.module = AnsibleModule(argument_spec={})

    # test zero
    hardware.module.get_bin_path = Mock(return_value=None)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'

    # test one
    hardware.module.get_bin_path = Mock(return_value='/tmp/dmidecode')
    hardware.module.run_command = Mock(return_value=(0, 'foo', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'foo'

    # test two
    hardware.module.get_bin_path = Mock(return_value='/tmp/dmidecode')

# Generated at 2022-06-22 23:06:46.818346
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import pytest

    class ModuleMock(object):
        def __init__(self):
            self.run_command_calls = []

            def run_command(self, cmd, check_rc=False, encoding=None):
                self.run_command_calls.append(cmd)
                if cmd == ["sysctl", "-b", "kern.boottime"]:
                    return 0, struct.pack("@L", 12345), None
                else:
                    return 0, "fake command output", None

        def get_bin_path(self, cmd):
            if cmd == "sysctl":
                return "/sbin/sysctl"
            return None

    class FakeTime(object):
        @classmethod
        def time(cls):
            return 123456789

    module = ModuleMock()
    hardware = FreeBSDHardware

# Generated at 2022-06-22 23:06:56.964903
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware.module.run_command = lambda args, **kwargs: (0, "vm.stats.vm.v_inactive_count: 0", "")
    hardware.module.get_bin_path = lambda args: ""
    assert hardware.get_memory_facts()['memfree_mb'] == 0

    hardware = FreeBSDHardware()
    hardware.module.run_command = lambda args, **kwargs: (0, "vm.stats.vm.v_inactive_count: 0", "")
    class MockSysctl:
        def __init__(self):
            pass

        def get_bin_path(self, args):
            return args

    hardware.module = MockSysctl()
    assert hardware.get_memory_facts()['memfree_mb'] == 0

    hardware = FreeBSDHardware()
    hardware

# Generated at 2022-06-22 23:07:07.929539
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    sysctl = "/usr/bin/sysctl"
    module = FakeAnsibleModule({'sysctl': sysctl})
    fhw = FreeBSDHardware(module)

    cpu_facts = {
        'processor': [
            'Intel(R) Core(TM) i7-4578U CPU @ 3.00GHz (3594.14-MHz K8-class CPU)'
        ],
        'processor_cores': '4',
        'processor_count': '1'
    }

    hw_facts = fhw.get_cpu_facts()
    assert hw_facts == cpu_facts



# Generated at 2022-06-22 23:07:18.289875
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts_instance = FreeBSDHardware(module)
    hardware_facts = hardware_facts_instance.populate()
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'devices' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts



# Generated at 2022-06-22 23:07:29.850955
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

        def run_command(self, args, **kwargs):
            return (0, 'hw.ncpu: 1', '')

        def get_bin_path(self, arg):
            if arg == 'sysctl':
                return '/sbin/sysctl'

            return None

    m = MockModule()
    hardware_facts = FreeBSDHardware(m)
    cpu_facts = hardware_facts.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '1'



# Generated at 2022-06-22 23:07:40.583995
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes

    m = ModuleFacts()

    # test a normal run
    hardware = FreeBSDHardware(m)
    hardware.populate()
    assert m.facts['uptime_seconds'] == 286787
    assert m.facts['devices']['da0'] == ['da0s1a', 'da0s1b', 'da0s1d', 'da0s2', 'da0s1e', 'da0s1', 'da0s1f']
    assert m.facts['swapfree_mb'] == 0
    assert m.facts['memfree_mb'] == 10752

# Generated at 2022-06-22 23:07:45.857791
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    return_value = {'memtotal_mb': None,
                    'memfree_mb': None,
                    'swaptotal_mb': None,
                    'swapfree_mb': None}
    module_mock = MockModule()
    hardware_mock = FreeBSDHardware(module_mock)

    # test if sysctl command is not available
    assert hardware_mock.get_memory_facts() == return_value

    module_mock.get_bin_path.return_value = '/sbin/sysctl'
    module_mock.run_command.return_value = (1, '', '')
    # test if sysctl command fails
    assert hardware_mock.get_memory_facts() == return_value

    # test if sysctl command return valid output

# Generated at 2022-06-22 23:07:48.885231
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    hardware = FreeBSDHardware()
    hardware.get_memory_facts()


# Generated at 2022-06-22 23:07:50.178221
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    m = FreeBSDHardware()
    assert isinstance(m.get_memory_facts(), dict)


# Generated at 2022-06-22 23:07:59.925112
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command_calls = []

        def get_bin_path(self, _, **kwargs):
            return "/bin/sysctl"

        def run_command(self, _, **kwargs):
            self.run_command_calls.append(kwargs)
            return (self.rc, self.out, self.err)

    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self):
            self.module = MockModule()
            self.facts = {}

    # Test case:
    # Executable command returns 0, correct output and no error string

# Generated at 2022-06-22 23:08:01.695194
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f = FreeBSDHardwareCollector()
    assert f is not None



# Generated at 2022-06-22 23:08:05.217695
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    result = FreeBSDHardwareCollector(module).collect()
    assert result is not None

# Generated at 2022-06-22 23:08:17.268374
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import timeout

    # Call original get_uptime_facts
    class ModuleMock(object):
        def __init__(self):
            self.run_command = self.run_command_mock

        def get_bin_path(self, arg):
            return '/usr/bin/' + arg

        def run_command_mock(self, args, encoding=None):
            if args == ['/usr/bin/sysctl', '-b', 'kern.boottime']:
                return (0, '\x03\x00\x00\x00\t\x00\x00\x00\x9e\x8c\x13\xfb', None)
            else:
                return (0, '', None)

    hardware = FreeBSDHardware(ModuleMock())
   

# Generated at 2022-06-22 23:08:28.831594
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    facts_module = FreeBSDHardwareCollector(dict(), dict())
    facts = facts_module.collect()
    assert 'ansible_facts' in facts
    assert 'devices' in facts["ansible_facts"]
    assert 'memtotal_mb' in facts["ansible_facts"]
    assert 'memfree_mb' in facts["ansible_facts"]
    assert 'swaptotal_mb' in facts["ansible_facts"]
    assert 'swapfree_mb' in facts["ansible_facts"]
    assert 'processor_cores' in facts["ansible_facts"]
    assert 'processor_count' in facts["ansible_facts"]
    assert 'processor' in facts["ansible_facts"]
    assert 'uptime_seconds' in facts["ansible_facts"]



# Generated at 2022-06-22 23:08:36.791562
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hw = FreeBSDHardware()
    out = hw.get_cpu_facts()

    expected = {'processor_count': '2', 'processor': ['Intel(R) Xeon(R) CPU E5-2667 v3 @ 3.20GHz',
                                                     'Intel(R) Xeon(R) CPU E5-2667 v3 @ 3.20GHz']}
    actual = {'processor_count': out['processor_count'], 'processor': out['processor']}

    assert actual == expected



# Generated at 2022-06-22 23:08:49.276708
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:08:53.049067
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """ This is a unit test to test the constructor of class FreeBSDHardware """
    freebsd_hw = FreeBSDHardware({}, {}, {})
    assert freebsd_hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:08:58.906699
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible_collections.misc.not_a_real_collection.plugins.modules import freebsd_hardware
    fm = freebsd_hardware.FreeBSDHardware()
    dmi_facts = fm.get_dmi_facts()
    assert dmi_facts


# Generated at 2022-06-22 23:09:06.871101
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware(None)
    # FIXME
    # device_facts = hardware.get_device_facts()
    # expected_device_facts = {
    #    'devices': {
    #        'da0': ['da0s1'],
    #        'da1': ['da1s1'],
    #        'ada0': ['ada0s1a'],
    #    }
    # }

    # assert device_facts == expected_device_facts


# Generated at 2022-06-22 23:09:17.370289
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fbsdhw = FreeBSDHardware()
    fbsdhw.module = lambda: None
    fbsdhw.module.run_command = lambda command: (0, 'aacd0', '')
    fbsdhw.module.get_bin_path = lambda name: None
    os.path.isdir = lambda path: True
    os.path.isfile = lambda path: True
    os.listdir = lambda dir: ['aacd0', 'aacd0s1', 'aacd0s1a', 'aacd0s1b', 'aacd0s1c', 'aacd0s2', 'aacd0s3', 'aacd0s4']
    fbsdhw.get_device

# Generated at 2022-06-22 23:09:30.442142
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    'Test FreeBSDHardware.populate()'
    # Module input parameters
    module_args = dict(
    )

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)

    # dmesg.boot file content

# Generated at 2022-06-22 23:09:42.068719
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def mock_run_command(cmd, check_rc=True, run_command_environ_update=None):
        if cmd == [sysctl_cmd, '-b', 'kern.boottime']:
            return (0, struct.pack('@L', kern_boottime), None)
        raise Exception('Unexpected command %r' % cmd)
    kern_boottime = 12345
    sysctl_cmd = 'sysctl'
    module = type('FakeModule', (), {'run_command': mock_run_command})()
    facts = FreeBSDHardware(module).populate()
    assert facts['uptime_seconds'] == int(time.time() - kern_boottime)


# Generated at 2022-06-22 23:09:56.267311
# Unit test for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:10:06.385413
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeModule:
        def __init__(self):
            self.facts = {}
            self.params = None

        def run_command(self, cmd, check_rc=True, encoding=None):
            """Pretend that we're sysctl"""
            if isinstance(cmd, list):
                cmd = ' '.join(cmd)

            (sysctl_cmd, _, opt) = cmd.partition(' ')

            # Pretend that we're sysctl

# Generated at 2022-06-22 23:10:14.783836
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = {}
            self.fail_json = {}
            self.run_command = lambda *args, **kwargs: [0, ['test0', 'test1'], '']
            self.get_bin_path = lambda *args: '/sbin/'

    test_module = AnsibleModule()
    freebsd_h = FreeBSDHardware(module=test_module)
    assert freebsd_h.get_device_facts() == {'devices': {'test0': ['test0s0']}}



# Generated at 2022-06-22 23:10:26.475497
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_name = 'ansible.module_utils.facts.hardware.freebsd.test_FreeBSDHardware_populate'
    fixture_file = '%s.fact' % test_name
    # This fixture file is created by running the command on the local machine:
    #
    # ansible localhost -m setup --tree /tmp/test-FreeBSDHardware_populate
    #
    # and then manually stripping out the fact "facter_dot_d" since it can
    # only be generated by the facter command.
    fixture_data = get_file_content(fixture_file)

    # Set up a module so we can run commands like sysctl
    module = MockModule()
    module.run_command = MagicMock(
        return_value=(0, None, None))

    # Set up a dummy module_utils

# Generated at 2022-06-22 23:10:38.779340
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    testobj = FreeBSDHardware()
    testobj.module = MagicMock()
    testobj.module.run_command = MagicMock()
    testobj.module.run_command.return_value = 0, 'hw.ncpu: 1\n', ''
    testobj.module.get_bin_path = MagicMock(return_value='/sbin/sysctl')

# Generated at 2022-06-22 23:10:44.648536
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from mock import Mock

    mem_facts = FreeBSDHardware(Mock()).get_memory_facts()
    assert mem_facts['memtotal_mb'] == 1
    assert mem_facts['memfree_mb'] == 2
    assert mem_facts['swaptotal_mb'] == 3
    assert mem_facts['swapfree_mb'] == 4


# Generated at 2022-06-22 23:10:47.717353
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModuleMock()
    hardware_collector = FreeBSDHardwareCollector(module)
    assert hardware_collector is not None

# Generated at 2022-06-22 23:10:54.048175
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """Check the FreeBSDHardwareCollector class."""

    # Make sure FreeBSDHardwareCollector is not Windows or Darwin
    hardware_collector = FreeBSDHardwareCollector()
    # Check the fact class
    fact_class = hardware_collector._fact_class
    assert fact_class == FreeBSDHardware
    # Check the platform name
    platform = hardware_collector._platform
    assert platform == 'FreeBSD'

# Generated at 2022-06-22 23:11:00.373087
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    Test FreeBSDHardware.get_device_facts()
    """
    module = AnsibleModuleMock()
    freebsd_hw = FreeBSDHardware(module)

    sys_dir = '/dev'

    if os.path.isdir(sys_dir):
        expected = sorted(os.listdir(sys_dir))
    else:
        expected = []

    dirlist = sorted(freebsd_hw.get_device_facts()['devices'].keys())

    assert expected == dirlist

# Generated at 2022-06-22 23:11:13.575866
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class mock:
        def __init__(self):
            self.run_command_encoding = {}
            self.run_command_instances = {}

        def run_command(self, cmd, encoding=None):
            self.run_command_encoding[cmd] = encoding
            out = self.run_command_instances.get(cmd)
            if not out:
                # Return sensible defaults so that the test doesn't fail
                # when the platform doesn't have sysctl or dmidecode
                return 0, b"Unknown", ""
            return out

    class mock_struct:
        @staticmethod
        def unpack(format, bstring):
            return (0,)

    struct_save = struct.unpack
    struct.unpack = mock_struct.unpack

# Generated at 2022-06-22 23:11:23.360821
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    dmi_facts = {}

    # mocked version of dmidecode output

# Generated at 2022-06-22 23:11:34.785509
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.hardware.freebsd as m

    m.ANSIBLE_MODULE_ARGS = {}
    m.ANSIBLE_MODULE_ARGS.update({'paths': {'dmidecode': './tests/unit/module_utils/facts/hardware/freebsd/dmidecode'}})
    m.dmidecode = './tests/unit/module_utils/facts/hardware/freebsd/dmidecode'
    m.sysconfig = {}
    m.sysconfig['paths'] = {}
    m.sysconfig['paths']['dmidecode'] = './tests/unit/module_utils/facts/hardware/freebsd/dmidecode'
    m.basic = basic

    m.HAS_

# Generated at 2022-06-22 23:11:40.967338
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """
    Basic test to populate FreeBSDHardware.
    """
    import platform
    import tempfile
    import shutil
    import subprocess
    import json
    import os

    if not platform.system() == 'FreeBSD':
        print("Skipping.  Not on FreeBSD")
        return

    (fd, dmesg_boot_path) = tempfile.mkstemp()

# Generated at 2022-06-22 23:11:46.403093
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    dummy_module = type('', (), {})()
    dummy_module.run_command = lambda *args, **kwargs: ('', '', '')
    freebsd_hardware_instance = FreeBSDHardware(dummy_module)
    assert freebsd_hardware_instance != None


# Generated at 2022-06-22 23:11:54.813797
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    freebsd_hardware = FreeBSDHardware(module=module)
    collected_facts = freebsd_hardware.populate()
    assert collected_facts

    assert 'devices' in collected_facts
    assert collected_facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3']
    assert collected_facts['processor_cores'] == '2'
    assert collected_facts['processor_count'] == '8'
    assert collected_facts['memtotal_mb'] == 12288
    assert collected_facts['memfree_mb'] == 7251
    assert collected_facts['swaptotal_mb'] == 1024
    assert collected_facts['swapfree_mb'] == 9

# Generated at 2022-06-22 23:12:06.023704
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class Module(object):
        def __init__(self):
            self.params = {}
            self.run_command = self.mock_run_command

        def mock_run_command(self, command):
            class CmdResult(object):
                def __init__(self, command, rc=0, stdout='', stderr='', error='', **kwargs):
                    self.command = command
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = stderr
                    self.error = error
                    self.args = kwargs

            output = dict()

# Generated at 2022-06-22 23:12:17.646458
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """Unit test for get_memory_facts method of class FreeBSDHardware"""
    class MockModule(object):
        def __init__(self):
            self.run_command_arr = []

        def run_command(self, args, check_rc=False, encoding=None, errors='surrogate_then_replace'):
            # Mock run_command method
            rc, out, err = self.run_command_arr.pop(0)

            if encoding is None:
                out = out.encode()
                err = err.encode()
            else:
                out = out.encode(encoding=encoding, errors=errors)
                err = err.encode(encoding=encoding, errors=errors)

            return rc, out, err


# Generated at 2022-06-22 23:12:19.883182
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    Test constructor of class FreeBSDHardware
    '''
    my_obj = FreeBSDHardware({})
    assert my_obj


# Generated at 2022-06-22 23:12:32.106647
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(choices=['all', 'min'], default='all')})
    fh = FreeBSDHardware(module)
    fh.populate()
    # BIOS related facts are defined below
    assert fh.bios_date != 'NA'
    assert fh.bios_vendor != 'NA'
    assert fh.bios_version != 'NA'
    # Board related facts are defined below
    assert fh.board_name != 'NA'
    assert fh.board_serial != 'NA'
    assert fh.board_vendor != 'NA'
    assert fh.board_version != 'NA'
    # Chassis related facts are defined below
    assert fh.chassis_serial != 'NA'
    assert fh.chassis

# Generated at 2022-06-22 23:12:32.755439
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:12:38.971043
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class TestModule(object):
        def run_command(self, args, check_rc=False, encoding=None):
            return 0, '', ''

        def get_bin_path(self, name):
            return ''

    module = TestModule()
    freebsd_hw = FreeBSDHardware(module=module)
    freebsd_hw.get_device_facts()

# Generated at 2022-06-22 23:12:46.384234
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    tmpdir = tempfile.mkdtemp()
    filepath = os.path.join(tmpdir, 'devices')
    os.mkdir(filepath)
    for device in ('ada0', 'da0', 'cd0', 'ada0s1', 'da0s1', 'ada1', 'da1', 'cd1'):
        os.makedirs(os.path.join(filepath, device))

    fh = None
    try:
        fh = open('/dev', 'w')
        fh.write(filepath)
    except Exception as e:
        module.fail_json(msg="Cannot write to /dev: %s" % to_native(e))
    finally:
        if fh is not None:
            fh.close()

# Generated at 2022-06-22 23:12:49.191481
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware({})
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:00.108731
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:13:08.334492
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test = FreeBSDHardware()
    test.module = True
    test.module.run_command = True
    test.module.run_command.return_value = ('0', '', '')
    test.module.get_bin_path = True
    test.module.get_bin_path.return_value = '/sbin/sysctl'
    result = test.get_device_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-22 23:13:17.797860
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_facts = FreeBSDHardware().get_dmi_facts()
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'chassis_asset_tag' in dmi_facts
    assert 'chassis_serial' in dmi_facts
    assert 'chassis_vendor' in dmi_facts
    assert 'chassis_version' in dmi_facts
    assert 'form_factor' in dmi

# Generated at 2022-06-22 23:13:19.780942
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:13:24.423204
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert issubclass(FreeBSDHardwareCollector, HardwareCollector)
    assert FreeBSDHardwareCollector._platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware
    assert isinstance(FreeBSDHardwareCollector(None), FreeBSDHardwareCollector)



# Generated at 2022-06-22 23:13:36.141532
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class Module(object):
        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd):
            if re.match('swapinfo', cmd):
                # Return the output of swapinfo command
                # /dev/ada0p3        314368        0   314368     0%
                return 0, "/dev/ada0p3        314368        0   314368     0%", ""
            elif re.match('.* -n hw.ncpu$', cmd):
                # Return the output of sysctl -n hw.ncpu command
                # 2
                return 0, "2", ""

# Generated at 2022-06-22 23:13:38.488977
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    m = FreeBSDHardware({})
    assert m.platform == 'FreeBSD'



# Generated at 2022-06-22 23:13:50.334921
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.fake import FakeModule

    # fake module without dmi bin
    module = FakeModule(bin_path_search_paths=[])
    # fake module with dmidecode bin
    dmidecode_module = FakeModule(bin_path_search_paths=['/usr/local/sbin'])

    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    # bios_date
    if 'bios_date' in dmi_facts:
        assert dmi_facts['bios_date'] == 'NA'

    dmidecode_dmi_facts = FreeBSDHardware(dmidecode_module).get_dmi_facts()
    # bios_date

# Generated at 2022-06-22 23:13:59.509565
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule:
        def __init__(self):
            self.run_command = lambda x, encoding=None: (0, str(int(time.time()) - 100), '')

        def get_bin_path(self, name):
            return '/bin/' + name

    module = MockModule()

    h = FreeBSDHardware(module)
    actual_uptime_facts = h.get_uptime_facts()

    expected_uptime_facts = {
        'uptime_seconds': 100,
    }
    assert actual_uptime_facts == expected_uptime_facts

# Generated at 2022-06-22 23:14:03.704285
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_facts = FreeBSDHardware().get_memory_facts()
    assert isinstance(mem_facts['memfree_mb'], int)
    assert isinstance(mem_facts['swaptotal_mb'], int)

# Generated at 2022-06-22 23:14:16.063772
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware({})

    dmi_lib_path = os.path.join('/usr', 'local', 'lib', 'python3' + '.' + '6', 'site-packages', 'ansible', 'module_utils', 'facts', 'hardware', 'test_dmi', 'dmidecode')
    dmi_bin = os.path.join(dmi_lib_path, 'dmidecode')

    # Setup dmidecode output for testing