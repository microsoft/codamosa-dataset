

# Generated at 2022-06-22 23:04:14.822115
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware({})
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:04:18.450686
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Construct FreeBSDHardwareCollector Class
    This doesn't test loading data just instantiation of the class.
    """
    FreeBSDHardwareCollector()



# Generated at 2022-06-22 23:04:29.352376
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    HWCollector = FreeBSDHardwareCollector(module)
    HW = HWCollector.collect()[0]

    assert HW.uptime_seconds == int(time.time()) - int(os.stat(FreeBSDHardware.DMESG_BOOT).st_mtime)
    assert HW.processor_count > 0
    assert isinstance(HW.processor, list)
    assert len(HW.processor) == int(HW.processor_count)
    assert HW.memtotal_mb > 0
    assert HW.memfree_mb >= 0
    assert isinstance(HW.devices, dict)

    for (k, v) in HW.devices.items():
        if k.startswith('ada'):
            assert isinstance(v, list)

# Generated at 2022-06-22 23:04:34.167757
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Unit test for class FreeBSDHardwareCollector.
    It creates object of class FreeBSDHardwareCollector.
    It requires to have the directory /dev on system.
    """
    facts = {}
    hw = FreeBSDHardwareCollector(facts)
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:04:42.210555
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fake = FakeModule()
    fake.mock_command('sysctl -n hw.ncpu', b'0')
    facts = FreeBSDHardware(module=fake).get_cpu_facts()
    assert facts['processor_count'] == '0'
    assert facts['processor_cores'] is None
    assert facts['processor'] == []

    fake = FakeModule()
    fake.mock_command('sysctl -n hw.ncpu', b'4')
    with open('tests/unit/module_utils/facts/fixtures/dmesg_w_cores', 'r') as handle:
        fake.mock_command(['dmesg'], handle.read().encode())
    facts = FreeBSDHardware(module=fake).get_cpu_facts()
    assert facts['processor_count'] == '4'
    assert facts

# Generated at 2022-06-22 23:04:45.872878
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_obj = FreeBSDHardware({})
    assert(hardware_obj.get_cpu_facts() != {})

# Generated at 2022-06-22 23:04:51.468098
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Create a FreeBSDHardware instance and call the method get_memory_facts on this instance
    freebsd_memory_facts = FreeBSDHardware.get_memory_facts()

    # Check if the keys 'memtotal_mb' and 'swaptotal_mb' are in the dict freebsd_memory_facts
    assert ('memtotal_mb' and 'swaptotal_mb') in freebsd_memory_facts

# Generated at 2022-06-22 23:05:00.193480
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test that FreeBSDHardware.get_cpu_facts() returns
    a dictionary of expected cpu facts.
    """
    result = test_module_output('system_facts', 'get_cpu_facts', '', 'FreeBSD')
    assert 'processor_count' in result['ansible_facts']['ansible_processor_count']
    assert 'processor_cores' in result['ansible_facts']['ansible_processor_cores']
    assert 'processor' in result['ansible_facts']['ansible_processor']


# Generated at 2022-06-22 23:05:01.233857
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector = FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:05:03.487250
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f = FreeBSDHardwareCollector()
    assert isinstance(f, HardwareCollector)
    assert f._platform == 'FreeBSD'

# Generated at 2022-06-22 23:05:07.518051
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    sysctl = module.get_bin_path('sysctl')
    if sysctl:
        hardware = FreeBSDHardware(module)
        cpu_facts = hardware.get_cpu_facts()
        assert cpu_facts['processor_count'].isdigit()
        assert len(cpu_facts['processor']) == int(cpu_facts['processor_count'])



# Generated at 2022-06-22 23:05:16.495899
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = type('DummyModule', (object,), {'get_bin_path': lambda s, x: '/usr/sbin/dmidecode'})
    hardware = FreeBSDHardware(module)

    # Test for dmidecode not available
    FreeBSDHardware.get_dmi_facts = lambda x: {}
    facts = hardware.get_dmi_facts()
    assert len(facts) == 0

    # Test for dmidecode available
    FreeBSDHardware.get_dmi_facts = lambda x: x.get_dmi_facts()
    facts = hardware.get_dmi_facts()
    assert len(facts) == 19

# Generated at 2022-06-22 23:05:21.341454
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """Unit test for method get_device_facts of class FreeBSDHardware"""
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    facts = hardware.get_device_facts()

    assert facts['devices']


# Generated at 2022-06-22 23:05:31.424415
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import unittest

    class fake_module:
        ''' fake AnsibleModule to return valid absolute path for sysctl '''

        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            ''' return valid path for sysctl when it is requested '''
            if name:
                return '/sbin/sysctl'
            return None

        def run_command(self, cmd, check_rc=True):
            ''' fake AnsibleModule.run_command to return fake values '''

# Generated at 2022-06-22 23:05:36.465854
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fh = FreeBSDHardware()
    dmi_facts = fh.get_dmi_facts()
    assert type(dmi_facts) == dict
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-22 23:05:44.915513
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor'][0]
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0

if __name__ == '__main__':
    test_FreeBSDHardware_populate()

# Generated at 2022-06-22 23:05:56.368337
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import os
    import time

    # fauscide, you lied to me, that's why I'm forced to mock time.time()
    time_at_test_start = time.time()
    time_at_test_end = time.time()

    # Simulate a kern.boottime of 100 seconds, with a current time of 120 seconds
    kern_boottime = 100
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    struct_out = struct.pack(struct_format, kern_boottime)
    os.environ['ANSIBLE_KERN_BOOTTIME_BIN'] = '/sbin/sysctl'
    os.environ['ANSIBLE_KERN_BOOTTIME_KERN_BOOTTIME'] = struct_out

    fh = FreeBSD

# Generated at 2022-06-22 23:06:05.445373
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardware
    fhw = FreeBSDHardware()
    fhw.module = MockModule()
    hardware_facts = fhw.populate()
    assert 'uptime_seconds' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'memfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'devices' in hardware_facts



# Generated at 2022-06-22 23:06:15.853159
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import os
    fact = FreeBSDHardware()
    result = fact.get_dmi_facts()
    assert isinstance(result, dict)
    assert len(result) > 0
    assert result.get('bios_vendor') or result.get('bios_version') or result.get('bios_date') or result.get('system_vendor') or result.get('product_name') or result.get('product_version') or result.get('product_serial') or result.get('product_uuid')

# Generated at 2022-06-22 23:06:20.983705
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    h = FreeBSDHardware({'module_setup': None})
    assert h.get_platform() == 'FreeBSD'
    assert h.get_devices() is not None
    assert h.get_memory_facts() is not None
    assert h.get_cpu_facts() is not None
    assert h.get_uptime_facts() is not None

# Generated at 2022-06-22 23:06:23.825466
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    assert isinstance(hw, Hardware)
    assert isinstance(hw, FreeBSDHardware)

# Generated at 2022-06-22 23:06:25.367151
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({}, {})
    assert isinstance(hardware, FreeBSDHardware)

# Generated at 2022-06-22 23:06:28.596877
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bsd_hardware_collector = FreeBSDHardwareCollector()
    assert bsd_hardware_collector is not None
    assert bsd_hardware_collector.platform == 'FreeBSD'


# Generated at 2022-06-22 23:06:38.376447
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils._text import to_bytes

    # list of device names to test
    devices = [
        'ada1',
        'ada1s1',
        'ada1s2',
        'cd0',
    ]

    # set-up device list, sorted by device name
    dirlist = ' '.join(sorted(devices, key=lambda x: to_bytes(x)))

    # set-up an instance of the FreeBSDHardware class
    freebsd_hardware = FreeBSDHardware(dirlist)

    # test the method
    device_facts = freebsd_hardware.get_device_facts()

    # expected result

# Generated at 2022-06-22 23:06:48.483216
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    result = dict(changed=False, ansible_facts=dict(
        processors=['Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz', 'Intel(R) Xeon(R) CPU E5-2620 v4 @ 2.10GHz'],
        processor_cores=2,
        processor_count=2
    ))
    module = MagicMock(name='AnsibleModule')
    setattr(module, 'run_command',
            MagicMock(name='run_command', side_effect=[(0, '2', ''), (0, '1', '')]))
    setattr(module, 'get_bin_path', MagicMock(name='get_bin_path', return_value='/foo'))
    setattr

# Generated at 2022-06-22 23:06:56.428261
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={
        }
    )
    facts_obj = ModuleFacts(module=module, include_defaults=True)
    hw_obj = FreeBSDHardware()
    hw_obj.populate(facts_obj.get_facts())
    device_facts = hw_obj.get_device_facts()
    module.exit_json(changed=False, ansible_facts=device_facts)

# Generated at 2022-06-22 23:07:02.810407
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Test to ensure that the constructor of class FreeBSDHardwareCollector
    does not raise any exception.
    """
    try:
        FreeBSDHardwareCollector()
    except:
        raise AssertionError("Constructor of class FreeBSDHardwareCollector raised an exception.")


# Generated at 2022-06-22 23:07:15.703826
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class ModuleStub:

        def __init__(self):
            self.bin_path = 'dmidecode'
            self.params = []
            self.run_command_rc = 0

# Generated at 2022-06-22 23:07:19.428892
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    args = {'ANSIBLE_MODULE_ARGS': {}}

    hw = FreeBSDHardware(None, args, False)
    hw.module.get_bin_path = lambda x: '/usr/sbin/dmidecode'
    hw.get_dmi_facts()

# Generated at 2022-06-22 23:07:30.774850
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    setattr(module, 'run_command', run_command_mock)
    setattr(module, 'get_bin_path', get_bin_path_mock)
    hardware = FreeBSDHardware(module)

    # Set values for dmi_facts and mount_facts testing
    hardware.dmi_facts['system_vendor'] = 'VMWare, Inc.'
    hardware.mount_facts['mounts'] = [
        {   'device': '/dev/disk0s2',
            'mount': '/'},
        {   'device': '/dev/disk0s4',
            'mount': '/private/var'}]

    # Set the return value of 'sysctl -n hw.ncpu'

# Generated at 2022-06-22 23:07:38.355170
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """Test get_memory_facts of FreeBSDHardware."""
    from ansible.module_utils.facts import FactCollector

    # Create a stubbed AnsibleModule
    module = ANSIBLE_MODULE

    # Create a stubbed module_utils/facts/hardware/freebsd.py with dummy data to use in testing
    file_name = 'hardware/freebsd.py'
    import types
    module_stub = types.ModuleType('ansible.module_utils.facts.hardware.freebsd')
    setattr(module_stub, 'sysctl', lambda x: "0\nvm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 395873\nvm.stats.vm.v_free_count: 209096\n")
    setattr

# Generated at 2022-06-22 23:07:41.877420
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw.DMESG_BOOT == '/var/run/dmesg.boot'
    assert fhw.platform == 'FreeBSD'


# Generated at 2022-06-22 23:07:51.299132
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    freebsd_hw = FreeBSDHardware(module)
    freebsd_hw.get_cpu_facts()
    assert freebsd_hw.facts['processor_count'] == '2'
    assert freebsd_hw.facts['processor'] == ['Intel(R) Core(TM) i7-2640M CPU @ 2.80GHz', 'Intel(R) Core(TM) i7-2640M CPU @ 2.80GHz']
    assert freebsd_hw.facts['processor_cores'] == '4'


# Generated at 2022-06-22 23:07:58.169418
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:08:10.997887
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class FreeBSDHardwareTest:
        def __init__(self):
            self.facts = {}
            self.tmpdir = '/tmp'

        def get_bin_path(self, binary, opt_dirs=[]):
            if binary == 'dmidecode':
                return '/usr/local/sbin/dmidecode'

        def run_command(self, command, check_rc=True, encoding=None, errors='strict', binary_data=False):
            if command == '/usr/local/sbin/dmidecode -s bios-release-date':
                out = '1/1/70'
            elif command == '/usr/local/sbin/dmidecode -s bios-vendor':
                out = 'XX'

# Generated at 2022-06-22 23:08:11.800754
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    h = FreeBSDHardware(dict())
    assert h


# Generated at 2022-06-22 23:08:16.989958
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={'filter': {'required': False, 'type': 'list', 'elements': 'str'}})
    FreeBSDHardware.get_device_facts(module)
    facts = module.exit_json()['ansible_facts']
    assert 'devices' in facts.keys()
    assert 'mounts' in facts.keys()



# Generated at 2022-06-22 23:08:21.607723
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_mock = MockModule()
    module_mock.run_command = _run_command
    hardware = FreeBSDHardware(module_mock)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 90


# Generated at 2022-06-22 23:08:26.564440
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    FreeBSDHardware.module = AnsibleModule
    FreeBSDHardware.module.get_bin_path = lambda x: x
    fb = FreeBSDHardware()
    devs = fb.get_device_facts()
    for dev in devs['devices']:
        assert len(devs['devices'][dev]) >= 0


# Generated at 2022-06-22 23:08:30.201515
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware()

    # Good data
    raw_out = struct.pack('@L', 1)
    assert m.get_uptime_facts(raw_out)['uptime_seconds'] == int(time.time() - 1)

    # Bad data
    assert m.get_uptime_facts('') == {}
    assert m.get_uptime_facts('bad data') == {}

# Generated at 2022-06-22 23:08:31.601639
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()


# Generated at 2022-06-22 23:08:44.377130
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class TestModule(object):
        def __init__(self):
            self.run_command_environ_update = dict()
            self.params = dict()
            self.params['gather_timeout'] = 10

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = dict()

        def run_command(self, cmd, check_rc=False, encoding=None):
            if encoding is not None:
                cmd.append('--encoding=%s' % encoding)

            self.run_command_calls.append(cmd)


# Generated at 2022-06-22 23:08:52.517754
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    fact_collector = FreeBSDHardwareCollector(module)
    facts = fact_collector.collect(module, collected_facts={})
    assert 'processor' in facts['ansible_facts']
    assert 'processor_cores' in facts['ansible_facts']
    assert 'processor_count' in facts['ansible_facts']
    assert 'devices' in facts['ansible_facts']


# Test class for dmidecode on FreeBSD

# Generated at 2022-06-22 23:09:05.810313
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    try:
        import mock
    except ImportError:
        raise SkipTest("mock python module is required")

    # Create an instance of FreeBSDHardware
    m = FreeBSDHardware({})

    # Memory facts that we expect to get
    expected_memory_facts = {}
    expected_memory_facts['memtotal_mb'] = int(1024 * 1024 * 1024 * 2 / 1024)
    expected_memory_facts['memfree_mb'] = int(1024 * 1024 * 1024 * 1 / 1024)
    expected_memory_facts['swaptotal_mb'] = 1024
    expected_memory_facts['swapfree_mb'] = 512
    # Create a mock to run command and return value
    with mock.patch.object(FreeBSDHardware, 'run_command') as run_command_mock:
        # run_command will return some values
        run_command

# Generated at 2022-06-22 23:09:16.364435
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' Unit test for method get_dmi_facts of class FreeBSDHardware
    '''
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch

    class MockModule:
        def __init__(self):
            self.params = {}

        def exit_json(self, rc=0, ansible_facts=None):
            pass

        def fail_json(self, rc=0, msg=None):
            pass

        def run_command(self, args, check_rc=False, encoding='utf-8', errors='surrogate_then_replace'):
            return (0, '', '')


# Generated at 2022-06-22 23:09:19.661890
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fbx = FreeBSDHardwareCollector()
    assert fbx.platform == 'FreeBSD'
    assert fbx._fact_class == FreeBSDHardware

# vim: set et ts=4 ai :

# Generated at 2022-06-22 23:09:32.113877
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self, name, cmd, rc, out, err):
            self.name = name
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            if name == 'dmidecode':
                return self.cmd

        def run_command(self, cmd):
            return self.rc, self.out, self.err


# Generated at 2022-06-22 23:09:44.272751
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # test all return values to avoid case where a string is returned, but instead a dict is expected, or vice versa
    test = FreeBSDHardware()

# Generated at 2022-06-22 23:09:55.020445
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """ unit test for method populate of class FreeBSDHardware """
    hardware = FreeBSDHardware()
    hardware.module = type('', (), {})
    hardware.module.run_command = lambda x: [0, '', '']
    hardware.module.get_bin_path = lambda x: None
    hardware.module.fail_json = lambda **args: None
    hardware.populate()
    assert hardware.data['memfree_mb'] == 0
    assert hardware.data['memtotal_mb'] == 0
    assert hardware.data['uptime_seconds'] == 0
    assert hardware.data['devices']['devices'] == 0
    assert hardware.data['mounts'] == 0

# Generated at 2022-06-22 23:09:57.112793
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    tmp_freebsd_hw = FreeBSDHardware({})
    assert tmp_freebsd_hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:10:02.917051
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())

    # assign module to class
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    # test if dmi_facts is defined and has at least one entry
    assert dmi_facts is not None
    assert len(dmi_facts) > 0
    assert "system_vendor" in dmi_facts

# Generated at 2022-06-22 23:10:14.040235
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    ''' sanity checks get_cpu_facts() '''

    # a typical dmesg.boot

# Generated at 2022-06-22 23:10:25.724502
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    class MockModule(object):
        pass

    class MockLinuxHardware(FreeBSDHardware):

        def __init__(self):
            self.module = MockModule()
            self.module.get_bin_path = lambda x: '/usr/bin/os-hardware'

    fhw = MockLinuxHardware()

    class MockPopen(object):

        def __init__(self, return_code, out, err):
            self.return_code = return_code
            self.out = out
            self.err = err
            self.pid = 123

        def communicate(self):
            return (self.out, self.err)

        def wait(self):
            return self.return_code


# Generated at 2022-06-22 23:10:37.853370
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create a test module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a test command
    cmd = FreeBSDHardwareCollector(module)

    # Create some test output

# Generated at 2022-06-22 23:10:40.771731
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Test creation of object FreeBSDHardwareCollector
    hardware_collector_obj = FreeBSDHardwareCollector
    assert hardware_collector_obj._platform == 'FreeBSD'



# Generated at 2022-06-22 23:10:53.371186
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Test cases
    # Input: b"\x00\x00\x00\x00\x00\x00\x00\x00" as bytes
    # Expected output: {'uptime_seconds': 0}
    ret_1 = FreeBSDHardware.get_uptime_facts(None, None, b"\x00\x00\x00\x00\x00\x00\x00\x00")
    assert ({'uptime_seconds': 0} == ret_1)
    # Input: b"\x00\x00\x00\x00\x00\x00\x00\x01" as bytes
    # Expected output: {'uptime_seconds': 1}

# Generated at 2022-06-22 23:11:00.271003
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({})
    result = {'processor': ['AMD Ryzen 7 1800X Eight-Core Processor'],
              'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1d', 'ada0s1e', 'ada0s1f', 'ada0s1g', 'ada0s1h'],
                         'cd0': ['cd0']},
              'processor_count': '8',
              'processor_cores': '8'}
    assert hardware.populate() == result

# Generated at 2022-06-22 23:11:03.480689
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware
    assert hardware.get_cpu_facts() == {'processor_count': '4', 'processor': []}

# Generated at 2022-06-22 23:11:10.830697
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Unit test for method FreeBSDHardware.populate.
    Input, collected_facts: Dict of facts of target system.
    Return: Dict of facts of target system.
    '''
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': '!all,!min', 'gather_timeout': 5}
    fb = FreeBSDHardware(module)
    return fb.populate()



# Generated at 2022-06-22 23:11:20.067368
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = MockModule()
    module.run_command = Mock(side_effect=[(0, '', ''),
                                           (0, 'CPU: Intel(R) Xeon(R) CPU E3-1270 v2 @ 3.50GHz', '')])

    freebsd_hardware = FreeBSDHardware(module)
    cpu_facts = freebsd_hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == '', 'The processor count is not correct'
    assert cpu_facts['processor'] == ['Intel(R) Xeon(R) CPU E3-1270 v2 @ 3.50GHz'], 'The CPU facts are not correct'


# Generated at 2022-06-22 23:11:31.735938
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Creating a fake module
    import tempfile
    (f, module_path) = tempfile.mkstemp()
    m = AnsibleModule(argument_spec={'test_uptime_seconds': dict(type='int'), 'bin_dir': dict(type='list')})
    f = os.fdopen(f, 'w')
    f.write('#!/usr/bin/python2\n')
    f.write('import sys\n')
    f.write('from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware\n')
    f.write('from ansible.module_utils.facts.timeout import TimeoutError\n')
    f.write('from ansible.module_utils.facts.utils import get_file_content\n')

# Generated at 2022-06-22 23:11:36.053801
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware_facts = FreeBSDHardware()
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memfree_mb'] != memory_facts['memtotal_mb']
    assert memory_facts['swapfree_mb'] != memory_facts['swaptotal_mb']


# Generated at 2022-06-22 23:11:40.690241
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MockModule()
    module.get_bin_path.side_effect = ['', 'swapinfo']

    freebsd_hardware = FreeBSDHardware(module)
    freebsd_hardware.get_memory_facts()

    assert freebsd_hardware.facts['memtotal_mb'] == 0
    assert freebsd_hardware.facts['memfree_mb'] == 0


# Generated at 2022-06-22 23:11:52.738317
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Unit test for method populate of class FreeBSDHardware"""

    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware()
    hardware.module = module
    result = hardware.populate()
    assert result['uptime_seconds'] > 0
    assert result['memtotal_mb'] > 0
    assert result['memfree_mb'] > 0
    assert result['swaptotal_mb'] > 0
    assert result['swapfree_mb'] > 0
    assert result['processor_count'] >= 1
    assert len(result['processor']) == result['processor_count'] == result['processor_cores']
    assert result['devices']
    assert result.get('mounts')
    mounts = result['mounts']
    for mount in mounts:
        assert mount['mount']
        assert mount['device']

# Generated at 2022-06-22 23:11:54.695409
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:11:57.892860
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    freebsd_hw = FreeBSDHardware({})
    dmi_facts = freebsd_hw.get_dmi_facts()
    return dmi_facts


# Generated at 2022-06-22 23:12:02.685756
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """This function is used to test the constructor of the class FreeBSDHardwareCollector"""
    try:
        FreeBSDHardwareCollector()
        print("SUCC: Object initialization test of class FreeBSDHardwareCollector passed.")
    except Exception as e:
        print("FAIL: Object initialization test of class FreeBSDHardwareCollector failed.")


# Generated at 2022-06-22 23:12:14.590314
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    output = {
        'devices': {'ada0': ['ada0s1', 'ada0s2', 'ada0s3'],
                    'ada1': ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4'],
                    'ada2': ['ada2s5'],
                    'ada3': ['ada3s1', 'ada3s2', 'ada3s3']
                    }
        }
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    fh = FreeBSDHardware(module)
    result = fh.get_device_facts()
    module.exit_json(changed=False, ansible_facts=result)


# Generated at 2022-06-22 23:12:18.764351
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    assert(hw.platform == 'FreeBSD')
    assert(hw.get_cpu_facts()['processor_cores'] != '')
    hw.populate()
    assert(hw.get_cpu_facts()['processor_cores'] != '')

# Generated at 2022-06-22 23:12:24.991694
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Test case: BIOS
    _patched_run_command = None
    def _mocked_run_command(self, args, **kwargs):
        if isinstance(args, list) and args[0] == '/usr/sbin/dmidecode' and args[1] == '-s':
            if args[2] == 'bios-release-date':
                return (0, '08/25/2014\n', '')
            elif args[2] == 'bios-vendor':
                return (0, 'Acer\n', '')
            elif args[2] == 'bios-version':
                return (0, 'V2.10\n', '')
        return _patched_run_command(self, args, **kwargs)

    _patched_get_bin_path = None


# Generated at 2022-06-22 23:12:37.694057
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''Test method get_cpu_facts for FreeBSDHardware.'''
    fhw = FreeBSDHardware()
    fhw.module = AnsibleModuleMock()
    fhw.module.run_command.return_value = (0, '8', None)
    cpu_facts = fhw.get_cpu_facts()
    assert 8 == cpu_facts['processor_count']
    assert fhw.module.run_command.call_count == 1
    assert fhw.module.run_command.call_args == ((fhw.module.get_bin_path('sysctl') + ' -n hw.ncpu',),)
    assert fhw.module.run_command.call_args_list[0][0][0] == fhw.module.get_bin_path('sysctl') + ' -n hw.ncpu'


#

# Generated at 2022-06-22 23:12:39.981171
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector = FreeBSDHardwareCollector()
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:12:41.023255
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # TODO: unit tests...
    pass

# Generated at 2022-06-22 23:12:45.292190
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    with open('/tmp/FreeBSDHardware_get_device_facts.json', 'r') as o:
        results = o.read()

    h = FreeBSDHardware({'ansible_facts': {}})
    result = h.get_device_facts()

    assert result['devices'] == json.loads(results)

# Generated at 2022-06-22 23:12:57.913647
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_result = dict(rc=0,
                                           stdout=_get_sysctl_vm_stats_sample(),
                                           stderr='')

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

        def run_command(self, cmd, encoding=None, check_rc=True, data=None):
            return [self.run_command_result['rc'],
                    self.run_command_result['stdout'],
                    self.run_command_result['stderr']]

    class FreeBSDHardwareStub(FreeBSDHardware):
        module = ModuleStub()

    memory_facts = FreeBSDHardwareStub().get_memory_facts()
    assert memory_

# Generated at 2022-06-22 23:13:00.520033
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """This is to test the instantiation of the class FreeBSDHardwareCollector."""

    hardware_facts_collector = FreeBSDHardwareCollector()
    assert hardware_facts_collector._platform == 'FreeBSD'

# Generated at 2022-06-22 23:13:09.525368
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    mock_run_command = MagicMock(return_value=(0, b'\xc2\x10\x00\x00\x00\x00\x00\x00', ''))
    with patch.multiple(module, run_command=mock_run_command):
        hardware = FreeBSDHardware(module=module)
        uptime_facts = hardware.get_uptime_facts()
        assert uptime_facts['uptime_seconds'] == 0x10c2

# Generated at 2022-06-22 23:13:14.696262
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fhw = FreeBSDHardware()
    dmi_facts = fhw.get_dmi_facts()

    # dmidecode may not be installed on the system
    if 'system_vendor' in dmi_facts:
        assert dmi_facts['system_vendor'] in ('sysctl', 'NA')
    else:
        assert dmi_facts == {}

# Generated at 2022-06-22 23:13:21.687432
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = type('FakeModule', (object,), {
        'get_bin_path': lambda self, name: '/bin/' + name,
        'run_command': lambda self, cmd, encoding=None, errors='surrogate_then_replace', **kwargs: (0, '', ''),
        })()
    test_sysdir = '/tmp/test_sysdir'
    hardware_instance = FreeBSDHardware({}, module=module)

# Generated at 2022-06-22 23:13:24.524475
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bhc = FreeBSDHardwareCollector()
    assert bhc.get_platform() == 'FreeBSD'
    assert bhc.get_fact_class() == FreeBSDHardware

# Generated at 2022-06-22 23:13:27.059462
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule({})
    har = FreeBSDHardware(module)
    assert har.platform == 'FreeBSD'


# Generated at 2022-06-22 23:13:37.964072
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # pylint: disable=too-few-public-methods
    class AccessFunctions(object):
        ''' For testing only '''
        def __init__(self, module_name):
            self.module_name = module_name

        def get_bin_path(self, name, required=False):
            ''' For testing only '''
            return name

        def run_command(self, cmd, check_rc=True, encrypt=None, data=None, binary_data=True, **kwargs):
            ''' For testing only '''
            return None, None, None

    class TestModule(object):
        ''' For testing only '''
        def __init__(self):
            self.name = 'AnsibleModule'


# Generated at 2022-06-22 23:13:50.244197
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:14:00.802771
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = DummyModule()
    hardware = FreeBSDHardware(module)
    # Write device in /dev
    os.mknod('/dev/sda')
    os.mknod('/dev/sda1')
    devices = hardware.get_device_facts()['devices']
    # Remove device in /dev
    os.remove('/dev/sda')
    os.remove('/dev/sda1')
    assert 'sda' in devices.keys() and 'sda1' in devices['sda']

# Use module_utils.facts.utils.get_file_content function replacement to simulate
# the file descriptor pointing to the end of the file

# Generated at 2022-06-22 23:14:12.941328
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_list = []

        def get_bin_path(self, name):
            if name == 'sysctl':
                return None

        def run_command(self, args, **kw):
            self.run_command_list.append(dict(args=args, kw=kw))
            rc = 0
            out = None
            err = None
            if args[0] == '/bin/cat':
                out = '{"time":1489743950,"boottime":1489737181}'
            return (rc, out, err)

    import sys
    import os
    import json
    import time

    sys.path.insert(0, os.path.dirname(__file__))
    sys.path

# Generated at 2022-06-22 23:14:23.752805
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
   unit test to verify the get_dmi_facts method of class FreeBSDHardware
    dmidecode command is mocked to simulate the different scenarios while
    execution the dmidecode command
    """
    import sys
    if sys.version_info[0] == 2:
        get_file_content = __builtins__.__dict__['file']
    else:
        get_file_content = __builtins__.__dict__['open']