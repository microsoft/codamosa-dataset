

# Generated at 2022-06-22 23:04:20.751266
# Unit test for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:04:31.253018
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Replace function raw_fact_subset of module ansible.module_utils.facts.collector to avoid missing keys in MONITORED_SUBSETS
    def return_all_keys(collected_facts, subset):
        return collected_facts

    import ansible.module_utils.facts.collector
    ansible.module_utils.facts.collector.raw_fact_subset = return_all_keys

    # Replace function get_file_content of module ansible.module_utils.facts.utils to avoid missing keys in MONITORED_SUBSETS
    def return_none(file_name):
        return None

    import ansible.module_utils.facts.utils
    ansible.module_utils.facts.utils.get_file_content = return_none

    # Import module ansible.module_utils.facts.hardware.free

# Generated at 2022-06-22 23:04:40.777218
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    cpu_facts = {'processor_count': '2', 'processor': ['Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz', 'Intel(R) Core(TM) i5-4300U CPU @ 1.90GHz']}
    memory_facts = {'swaptotal_mb': 0, 'memtotal_mb': 16077, 'swapfree_mb': 0, 'memfree_mb': 1820}
    uptime_facts = {'uptime_seconds': 95891}

# Generated at 2022-06-22 23:04:44.990216
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={})
    freebsd_hw = FreeBSDHardware(module=test_module)
    freebsd_hw.get_device_facts()

# Generated at 2022-06-22 23:04:50.653354
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible_collections.ansible.community.plugins.module_utils.local import LocalAnsibleModule

    module = LocalAnsibleModule(
        argument_spec=dict()
    )

    hardware = FreeBSDHardware(module)
    facts = hardware.populate()

    assert isinstance(facts, dict)
    assert facts.get('devices')



# Generated at 2022-06-22 23:05:02.479682
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-22 23:05:08.311467
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(
        argument_spec = dict()
    )

    d = FreeBSDHardware(module)
    assert d.platform == 'FreeBSD'
    assert d.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-22 23:05:18.375104
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = type('AnsibleModule', (object,), {})
    module.get_bin_path = lambda *args, **kwargs: '/usr/bin/sysctl'

    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == ['AMD Phenom(tm) II X6 1055T Processor (2200.00-MHz K8-class CPU)']
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor_count'] == '6'

    # unit test for method get_mount_facts of class FreeBSDHardware
    def test_FreeBSDHardware_get_mount_facts():
        module = type('AnsibleModule', (object,), {})
        hardware = FreeBSDHardware(module)
        hardware.get_mount_facts

# Generated at 2022-06-22 23:05:29.791003
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict(filter=dict(required=False, type='str')))
    module.get_bin_path = lambda x: '/bin/%s' % x
    module.run_command = run_command

    """ Tests get_memory_facts() using a mocked version of the sysctl command """
    collector = FreeBSDHardwareCollector(module=module)

    """ First test: no vm.stats.vm.v_page_count """

# Generated at 2022-06-22 23:05:41.999938
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import tempfile
    import shutil

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()

    # Create a temp file under temp_dir
    fd, temp_file = tempfile.mkstemp(dir=temp_dir)

    # Test for method get_device_facts()

# Generated at 2022-06-22 23:05:49.444778
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    freebsd = FreeBSDHardware(module)
    result = freebsd.get_cpu_facts()
    assert result['processor_count'] == "8"
    assert result['processor_cores'] == "8"
    assert result['processor'][0] == "Intel(R) Xeon(R) CPU E5-2620 v2 @ 2.10GHz"


# Generated at 2022-06-22 23:05:51.613764
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()

    hardware.populate()

    # Assert if the result is none
    assert hardware.get_facts() is not None

# Generated at 2022-06-22 23:06:02.718105
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self):
            self._swapinfo = '/sbin/swapinfo'
            self._sysctl = '/sbin/sysctl'

        def get_bin_path(self, path):
            if path == 'sysctl':
                return self._sysctl
            elif path == 'swapinfo':
                return self._swapinfo

        def run_command(self, args, check_rc=True):
            if 'swapinfo' in args:
                return 0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', ''
            elif args[0] == self._sysctl:
                return 0, 'vm.stats.vm.v_page_count: 156180\n'

# Generated at 2022-06-22 23:06:09.793574
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    freebsd_hardware = FreeBSDHardware(module=module)

    assert freebsd_hardware.populate()['processor_count'] == '2'
    assert '2.8GHz' in freebsd_hardware.populate()['processor'][0]
    assert freebsd_hardware.populate()['processor_cores'] == '2'
    assert freebsd_hardware.populate()['uptime_seconds'] > 30
    assert freebsd_hardware.populate()['system_vendor'] == 'NA'
    assert freebsd_hardware.populate()['product_name'] == 'NA'
    assert freebsd_hardware.populate()['product_version'] == 'NA'

# Generated at 2022-06-22 23:06:15.977461
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'output', '')

    f = FreeBSDHardware()
    f.module = module

    f.get_dmi_facts()

    module.run_command.assert_called_with('/usr/sbin/dmidecode -s system-product-name')

# Generated at 2022-06-22 23:06:19.943948
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fb_collector = FreeBSDHardwareCollector()
    assert fb_collector.platform == 'FreeBSD'
    assert fb_collector.fact_class == FreeBSDHardware
    assert fb_collector.system_profiler == ['dmidecode']



# Generated at 2022-06-22 23:06:26.328470
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fhw = FreeBSDHardware()
    fhw.module = MockModule()
    cpu_facts = fhw.get_cpu_facts()
    assert cpu_facts['processor_count'] == '8'
    assert cpu_facts['processor'] == ['Intel(R) Atom(TM) CPU  D525   @ 1.80GHz']
    assert cpu_facts['processor_cores'] == '1'



# Generated at 2022-06-22 23:06:32.413888
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module=module)
    facts = fhw.get_memory_facts()
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-22 23:06:37.380882
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, 'TEST_DMI', ''))
    test_module.get_bin_path = MagicMock(return_value='/bin/dmidecode')
    hardware_collector = FreeBSDHardwareCollector(module=test_module)
    hardware_object = hardware_collector._fact_class(module=test_module)

    hardware_object.get_dmi_facts()

    assert test_module.run_command.call_count == 19

# Generated at 2022-06-22 23:06:40.308310
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    assert isinstance(dmi_facts, dict)


# Generated at 2022-06-22 23:06:48.976928
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    # When uptime is 1 hour (3600 seconds) and 14 minutes (14*60 seconds)
    # should return the second in the dictionary 'uptime_seconds':
    # - raw bytes: b'\xc0\x1c\x00\x00\x00\x00\x00\x00'
    # - seconds: 43160
    # - second_and_microsecond: (43160, 0)
    # - uptime_seconds: 37140
    raw_bytes = b'\xc0\x1c\x00\x00\x00\x00\x00\x00'
    second_and_microsecond = struct.unpack('@L', raw_bytes[:8])
    seconds = second_and_microsecond[0]
    uptime_seconds = int(time.time() - seconds)

# Generated at 2022-06-22 23:07:00.868816
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware({})
    hardware.module = Mock()
    hardware.module.run_command.return_value = [0, 'abc', '']

# Generated at 2022-06-22 23:07:13.055070
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # Non-existent binary
    module_data = dict(swapinfo='/path/to/swapinfo')
    module = type('FakeModule', (object,), module_data)
    freebsd_hw = FreeBSDHardware(module)
    memory_facts = freebsd_hw.get_memory_facts()
    assert sorted(memory_facts.keys()) == [
        'memfree_mb', 'memtotal_mb',
    ]

    # Empty output
    module_data = dict(swapinfo='/bin/cat')
    module = type('FakeModule', (object,), module_data)
    freebsd_hw = FreeBSDHardware(module)
    memory_facts = freebsd_hw.get_memory_facts()

# Generated at 2022-06-22 23:07:23.825425
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = type('', (object,), {
        'run_command': lambda self, args, check_rc=False, encoding=None: (0, args[2], ''),
        'get_bin_path': lambda self, executable, required=False, opt_dirs=[] : executable
    })()
    hardware = FreeBSDHardware(module=module)
    hardware.get_cpu_facts = lambda self: {'processor_count': 4}
    hardware.get_memory_facts = lambda self: {'memtotal_mb': 8192, 'swaptotal_mb': 8192}
    hardware.get_uptime_facts = lambda self: {'uptime_seconds': 180000}
    hardware.get_device_facts = lambda self: {'devices': ['dmesg', 'dmesg.boot', 'fstab']}

# Generated at 2022-06-22 23:07:31.081764
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    ansible_module = 'fake'
    ansible_version = '2017.05.99'
    ansible_module_args = {}
    os_platform = 'FreeBSD'
    os_version = '9.3-RELEASE'
    os_distribution = 'freebsd'

    hw = FreeBSDHardwareCollector(ansible_module, ansible_version, ansible_module_args, os_platform, os_version,
                                  os_distribution)
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:07:42.378849
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # pylint: disable=protected-access
    # This test is a bit fragile, since it relies on the exact output of sysctl and dmesg.boot
    # If those change, these tests also need to be changed.
    module = {}
    module['run_command'] = lambda cmd: (0, 'hw.ncpu: 4\n', '')
    module['get_bin_path'] = lambda name: '/usr/bin/' + name
    hw = FreeBSDHardware(module)
    facts = hw.get_cpu_facts()
    assert facts == {
        'processor': ['Intel(R) Core(TM) i3 CPU       M 370  @ 2.40GHz'],
        'processor_cores': '2',
        'processor_count': '4',
    }



# Generated at 2022-06-22 23:07:51.859428
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # populate_facts of class FreeBSDHardware
    module = type('AnsibleModule', (), {'exit_json': exit_json, 'run_command': run_command})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['system_vendor']
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0



# Generated at 2022-06-22 23:08:00.809619
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, command, encoding=None):
            assert command == ['/sbin/sysctl', '-b', 'kern.boottime']
            assert encoding is None

            return (0, b'\x8c\xce\x96\xb0\x00\x00\x00\x00', '')

    class MockedTime:
        def __init__(self):
            self.time = 0

        def time(self):
            return self.time

    module = MockModule()
    time = MockedTime()

    # Get uptime_seconds using kern.boottime=1451295666
    hardware = FreeBSDHardware(module)
    time.time = 1451295666

    # Try to set internal module member with mocked time class
    hardware._time = time

    # Try

# Generated at 2022-06-22 23:08:05.988839
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Test get_uptime_facts of FreeBSDHardware with 'Fri May 26 11:18:39 2017'
    """
    test_obj = FreeBSDHardware()
    assert test_obj.get_uptime_facts() == {'uptime_seconds': 18710180}



# Generated at 2022-06-22 23:08:15.958024
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''Unit test for method get_cpu_facts of class FreeBSDHardware'''
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module.params['gather_subset'] = ['all']
    module.run_command = mock.Mock(return_value=(0, '1', ''))
    fhs = FreeBSDHardware()
    fhs.module = module
    assert fhs.get_cpu_facts() == dict(
        processor_count='1',
        processor=[]
    )



# Generated at 2022-06-22 23:08:27.714411
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    data = {'ANSIBLE_MODULE_UTILS': '/usr/local/lib/freebsd/ansible'}
    module = AnsibleModule(argument_spec={}, supports_check_mode=False, bypass_checks=True,
                           check_invalid_arguments=False, no_log=True,
                           ansible_facts=data)

    fbsd = FreeBSDHardware(module=module)
    memory_facts = fbsd.get_memory_facts()

    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:08:40.156198
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    with open("../utils/dmidecode.txt", 'r') as myfile:
        dmidecode_data=myfile.read()
    class Module(object):
        def __init__(self):
            self.params = {
                'timeout': 1,
                'ansible_check_mode': False,
            }
        def check_mode(self):
            return self.params['ansible_check_mode']
        def get_bin_path(self, arg, required=False):
            return arg
        def run_command(self, arg, check_rc=True, encoding=None):
            return 0, dmidecode_data, ''

    class AnsibleModule(object):
        def __init__(self):
            self.params = {
                'timeout': 1,
            }

# Generated at 2022-06-22 23:08:43.224049
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    m = FreeBSDHardware()

    result = m.get_memory_facts()
    assert type(result['memtotal_mb']) == int
    assert type(result['memfree_mb']) == int
    assert type(result['swaptotal_mb']) == int
    assert type(result['swapfree_mb']) == int

# Generated at 2022-06-22 23:08:44.855664
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    x = FreeBSDHardware({})
    assert x.platform == 'FreeBSD'

# Generated at 2022-06-22 23:08:50.125718
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collectors = [x for x in HardwareCollector.__subclasses__() if x._platform == 'FreeBSD']
    assert(len(collectors) == 1)
    assert(collectors[0]._fact_class == FreeBSDHardware)
    assert(collectors[0]._platform == 'FreeBSD')


# Generated at 2022-06-22 23:08:51.939717
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector



# Generated at 2022-06-22 23:09:05.238945
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Method populate of class FreeBSDHardware is tested'''
    from ansible.module_utils.facts import ansible_freebsd_specific
    from ansible.module_utils.facts.collector import Cache
    freebsd_module_spec = {'user': 'root', 'get_bin_path': lambda *args, **kwargs: '/usr/bin/sysctl'}
    freebsd_mock_module = ansible_freebsd_specific.AnsibleModule(freebsd_module_spec)
    cache = Cache([FreeBSDHardwareCollector])
    freebsd_hw = FreeBSDHardware(freebsd_mock_module, cache)
    freebsd_hw_facts = freebsd_hw.populate()
    assert 'memtotal_mb' in freebsd_hw_facts

# Generated at 2022-06-22 23:09:15.823305
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import sys
    sys.path.insert(0, '..')
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.hardware.freebsd import test_FreeBSDHardware_get_mount_facts
    from ansible.module_utils.facts.timeout import SystemExit
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils._text import to_bytes
    hardware = FreeBSDHardware(default_collectors)

    sysctl_method = hardware.module.get_bin_path('sysctl')
    swapinfo_method = hardware.module.get_bin_path('swapinfo')

# Generated at 2022-06-22 23:09:28.856095
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    MOCK_RC = 0
    MOCK_ERR = ''

# Generated at 2022-06-22 23:09:42.112337
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.hardware.base import MockModule
    bsd_object = FreeBSDHardware()
    bsd_object.module = MockModule()
    import tempfile
    temp_dir = tempfile.mkdtemp()
    file1 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    file1.write(str.encode('/dev/ada0p3\n'))
    file2 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
    file2.write(str.encode('/dev/ada0s2\n'))
    file3 = tempfile.NamedTemporaryFile(dir=temp_dir, delete=False)
   

# Generated at 2022-06-22 23:09:45.689146
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.collect() == hardware_collector.hardware._facts


# Generated at 2022-06-22 23:09:52.812978
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    test = FreeBSDHardware()
    test.module.run_command = lambda *_, **kwargs: (0, '', '')
    test.module.get_bin_path = lambda *_, **kwargs: ''

    test.module.fail_json = lambda *_, **kwargs: None
    test.populate()

# Generated at 2022-06-22 23:09:58.819957
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mod = AnsibleModule(argument_spec={})
    fb = FreeBSDHardware(module=mod)

    sysctl = mod.get_bin_path('sysctl')
    if sysctl:
        rc, out, err = mod.run_command("%s vm.stats" % sysctl, check_rc=False)
        for line in out.splitlines():
            data = line.split()
            if 'vm.stats.vm.v_page_size' in line:
                pagesize = int(data[1])
            if 'vm.stats.vm.v_page_count' in line:
                pagecount = int(data[1])
            if 'vm.stats.vm.v_free_count' in line:
                freecount = int(data[1])


# Generated at 2022-06-22 23:10:07.985284
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    mock_module = type('MockModule', (object, ), {})()
    mock_module.get_bin_path = lambda x: '/bin/dmidecode'
    mock_module.run_command = lambda x: (0, "", "")

    hardware_facts = FreeBSDHardware(mock_module)
    devices = hardware_facts.get_device_facts()['devices']
    assert set(devices.keys()) == {'ad0', 'ad2', 'ad4', 'da0', 'da1', 'da2', 'cd0'}
    assert set(devices['ad0']) == {'ad0s1', 'ad0s2', 'ad0s3'}
    assert set(devices['ad2']) == {'ad2s1'}

# Generated at 2022-06-22 23:10:17.097256
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # 1. Run on a FreeBSD system
    # 2. Run on a non FreeBSD system

    module = DummyModule()

    # Hardware class takes two arguments
    # 1. module_name of type str
    # 2. module of type ansible.module_utils.basic.AnsibleModule
    h = FreeBSDHardware('setup', module)

    sysctl = '/sbin/sysctl'
    swapinfo = 'swapinfo'

    options = {'check_rc': True}

# Generated at 2022-06-22 23:10:20.165352
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:10:28.524893
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    output = {'swaptotal_mb': 5120, 'swapfree_mb': 5120}
    test_class_memory1 = FreeBSDHardware({'module_setup': True})
    test_class_memory1.module.get_bin_path = lambda x: "/usr/sbin/swapinfo"
    test_class_memory1.module.run_command = lambda x: (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', '')
    assert test_class_memory1.get_memory_facts() == output

# Generated at 2022-06-22 23:10:40.337391
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import sys
    import time

    # On Python 2, struct.pack returns a string
    if sys.version_info[0] < 3:
        pack_argument = 'c'
        pack_returns_string = True
    else:
        pack_argument = bytes('c', 'ascii')
        pack_returns_string = False

    # This is a test with a real kern.boottime value
    fake_time = time.time()
    boottime = fake_time - 1000000

# Generated at 2022-06-22 23:10:43.691908
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts

# Test for class FreeBSDHardwareCollector

# Generated at 2022-06-22 23:10:47.824228
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector.platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class.platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:10:59.405807
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MockAnsibleModule()
    module.run_command = MockRunCommand(module)

# Generated at 2022-06-22 23:11:02.467582
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware()

    assert facts is not None
    assert 'uptime_seconds' in facts

# Generated at 2022-06-22 23:11:14.854668
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Create FreeBSDHardware object
    hw = FreeBSDHardware()
    facts = hw.populate()
    # Check isinstance of object and object
    assert isinstance(hw, FreeBSDHardware)
    assert isinstance(facts, dict)
    # Check the platform
    assert facts['ansible_system'] == 'FreeBSD'
    # Check the CPU facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    # Check the memory facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    # Check the device facts
    assert 'devices' in facts
    assert 'mounts' in facts
    # Check the uptime facts
   

# Generated at 2022-06-22 23:11:16.582631
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    assert hardware.module == module

# Generated at 2022-06-22 23:11:26.019720
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    import ansible.module_utils.facts.hardware.freebsd
    assert ansible.module_utils.facts.hardware.freebsd.FreeBSDHardwareCollector.__module__ == 'ansible.module_utils.facts.hardware.freebsd'
    assert ansible.module_utils.facts.hardware.freebsd.FreeBSDHardwareCollector.__name__ == 'FreeBSDHardwareCollector'
    assert issubclass(ansible.module_utils.facts.hardware.freebsd.FreeBSDHardwareCollector, ansible.module_utils.facts.hardware.base.HardwareCollector)


# Generated at 2022-06-22 23:11:33.283896
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freebsd_hardware = FreeBSDHardware()
    freebsd_hardware.module = get_fake_module()
    cpu_facts = freebsd_hardware.get_cpu_facts()
    assert (cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz'])
    assert (cpu_facts['processor_cores'] == '1')
    assert (cpu_facts['processor_count'] == '2')


# Generated at 2022-06-22 23:11:41.805979
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """ Unit test for method populate of class FreeBSDHardware """

    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)

    # For now, we only test the presence of some facts
    assert 'memfree_mb' in hardware.populate()
    assert 'memtotal_mb' in hardware.populate()
    assert 'swapfree_mb' in hardware.populate()
    assert 'swaptotal_mb' in hardware.populate()
    assert 'processor' in hardware.populate()
    assert 'processor_count' in hardware.populate()
    assert 'processor_cores' in hardware.populate()
    assert 'devices' in hardware.populate()
    assert 'uptime_seconds' in hardware.populate()



# Generated at 2022-06-22 23:11:51.683872
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    module.params = {'gather_subset': ['all']}
    facts_collector = FreeBSDHardwareCollector(module=module)
    facts = facts_collector.collect()
    assert 'processor' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts



# Generated at 2022-06-22 23:12:03.785625
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.bsd import FreeBSDHardware
    from ansible.module_utils.facts.collector import BaseFileContentCollector
    from ansible.module_utils._text import to_bytes

    class MockBaseFileContentCollector(BaseFileContentCollector):
        # Provide a mock base class for Hardware and other collectors
        # which may use BaseFileContentCollector
        def __init__(self):
            self.files = {}

        def populate(self):
            pass

        def _get_file_content(self, file, default=''):
            return self.files.get(file, default)

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self._module = None
            self._file

# Generated at 2022-06-22 23:12:10.558680
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # create instance of class under test
    fhw = FreeBSDHardware()

    # test populates
    fhw.populate()

    # verify that the class under test did something
    facts_dict = fhw.get_facts()
    assert('processor' in facts_dict)
    assert('processor_cores' in facts_dict)
    assert('processor_count' in facts_dict)
    assert('devices' in facts_dict)
    assert('uptime_seconds' in facts_dict)

# Generated at 2022-06-22 23:12:21.053382
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_config = None
    test_module = None
    test_base = FreeBSDHardware(test_module, test_config)

    # Testing dmidecode if installed
    dmi_bin = test_base.module.get_bin_path('dmidecode')
    dmi_facts = {}

# Generated at 2022-06-22 23:12:23.825248
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    h = FreeBSDHardware({})
    assert h.platform == 'FreeBSD'
    assert h.get_cpu_facts()['processor_count'] == '1'


# Generated at 2022-06-22 23:12:36.556425
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleFailException(Exception):
        pass

    class TestModule:
        def __init__(self):
            self.exit_args = {}
            self.fail_args = {}

        def get_bin_path(self, path, required=False):
            return '/usr/sbin/%s' % path

        def run_command(self):
            if 'sysctl' in self.exit_args:
                rc = self.exit_args['sysctl']
            else:
                rc = 0

            if 'swapinfo' in self.exit_args:
                rc = self.exit_args['swapinfo']
            else:
                rc = 0

            if rc == 0:
                return (0, 'hw.ncpu: 4', '')
            else:
                return (1, '', '')


# Generated at 2022-06-22 23:12:46.350920
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class Module:
        def __init__(self, dmidecode_output):
            self.dmidecode_output = dmidecode_output

        def run_command(self, cmd, *_):
            # Check the command is correct
            if not cmd.startswith('"/dev/dmidecode" -s'):
                return (1, '', 'Command is incorrect')

            # Check the requested dmidecode property exists
            property_id = cmd.split()[-1]
            if property_id not in self.dmidecode_output['output']:
                return (1, '', '')

            return (0, self.dmidecode_output['output'][property_id], '')

        def get_bin_path(self, cmd):
            return os.path.join('/dev', cmd)



# Generated at 2022-06-22 23:12:53.351811
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})

    facts = FreeBSDHardware(module).populate()
    for key in ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb',
                'processor', 'processor_cores', 'processor_count',
                'devices', 'uptime_seconds']:
        assert key in facts

# Generated at 2022-06-22 23:13:01.915512
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import mock
    import tempfile
    import unittest

    try:
        # Create a named temporary file to emulate the output of sysctl.
        temp = tempfile.NamedTemporaryFile()

        # Create a mock AnsibleModule object.
        module = mock.MagicMock()
        # We need to get raw bytes, not UTF-8.
        module.run_command.return_value = (0, temp.read(), '')

        # Create an instance of the FreeBSDHardware class to test.
        hardware = FreeBSDHardware(module=module)
        hardware.populate()
    finally:
        # Delete the temporary file, so it is not left behind after the test.
        temp.close()

    # Check that the facts have been populated correctly.
    assert hardware.uptime_seconds is not None

# Generated at 2022-06-22 23:13:12.371768
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MockModule()
    module.run_command = Mock(return_value=(0, dedent('''\
        vm.stats.vm.v_page_size: 4096
        vm.stats.vm.v_page_count: 9437568
        vm.stats.vm.v_free_count: 5373543
        '''), ''))

    hw = FreeBSDHardware(module)
    info = hw.get_memory_facts()
    assert info['memtotal_mb'] == 9437568 * 4 / 1024 / 1024
    assert info['memfree_mb'] == 5373543 * 4 / 1024 / 1024



# Generated at 2022-06-22 23:13:19.718720
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fh = FreeBSDHardware(None)
    # Nothing returned when there is no cpu info
    assert fh.get_cpu_facts() == {}

    # Set a cpu number and check that this is the only value returned
    cpu_count = '4'
    setattr(fh, 'DMESG_BOOT', '/dev/null')
    fh.module.run_command = MagicMock(return_value=(0, cpu_count, ''))
    assert fh.get_cpu_facts() == {'processor_count': cpu_count}

    # Add some cpu info and test that the right info is returned
    cpu_count = '2'
    cpu_model = 'Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'
    cpu_cores = '4'
    dmesg_boot

# Generated at 2022-06-22 23:13:25.467661
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_collection = FreeBSDHardwareCollector(None)
    test_subject = FreeBSDHardware(module=None)
    result = test_subject.get_cpu_facts()
    assert type(result) == dict
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result


# Generated at 2022-06-22 23:13:36.705452
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test FreeBSDHardware.get_cpu_facts().
    """
    import os
    import json
    import shlex
    import random
    import sys

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../'))

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # make fake 'sysctl' command output
    current_cores = random.randint(1, 4)
    cpu_cores = []
    cpu_model = []
    for i in range(current_cores):
        cpu_cores.append('CPU: CPU%d' % i)
        cpu_model.append('Intel(R) Xeon(R) CPU E5-2680 0 @ 2.70GHz')

    output = []

# Generated at 2022-06-22 23:13:44.648056
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec=dict())
    fhw = FreeBSDHardware(module)
    assert fhw.platform == 'FreeBSD'
    assert not fhw.collector._cache
    assert not fhw.collector.responses
    assert not fhw.collector.results
    assert not fhw.collector.remove_extraneous_facts
    assert fhw.collector.platform == 'FreeBSD'



# Generated at 2022-06-22 23:13:52.926108
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import mock
    import ansible.module_utils.facts.hardware.freebsd as freebsd

    module = mock.MagicMock()
    module.run_command.return_value = (0, b'\x00\x00\x00\x00\x00\x00\x00\x45', '')
    module.get_bin_path.return_value = '/sbin/sysctl'

    facts = freebsd.FreeBSDHardware()
    facts.module = module

    uptime_facts = facts.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 45

# Generated at 2022-06-22 23:14:02.341883
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fake_module = type('', (), {})()
    class_member_name = "sysctl"
    setattr(fake_module, class_member_name, "/sbin/sysctl")

    freebsd_hardware = FreeBSDHardware()
    setattr(freebsd_hardware, "module", fake_module)

    memory_facts = freebsd_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1
    assert memory_facts['memfree_mb'] == 1
    assert memory_facts['swaptotal_mb'] == 1
    assert memory_facts['swapfree_mb'] == 1


# Generated at 2022-06-22 23:14:14.699326
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class FreeBSDHardwareMock(FreeBSDHardware):
        def __init__(self, module):
            self.module = module
            self.path = {}

    class ModuleMock():
        def __init__(self):
            self.run_command_inspect_rc = [0]