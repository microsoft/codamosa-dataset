

# Generated at 2022-06-22 23:04:25.526140
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import platform
    import unittest

    class MockModule(object):
        def __init__(self, kvm_available):
            self.kvm_available = kvm_available
            self.params = {}
            self.tmpdir = '/tmp'
            self.sysfs_path = '/sys'
            self.facts = {}

        def get_bin_path(self, executable, required=True):
            if executable.endswith('sysctl'):
                return '/sbin/sysctl'


# Generated at 2022-06-22 23:04:34.558493
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    def mock_run_command(self, args, check_rc=False, encoding=None, data=None):
        # fake the output of the devices command
        return 0, "ada0    AHCI_M0211A       446.950GB", ''

    import copy
    import sys
    module = type('', (), {'run_command': mock_run_command})()
    setattr(module, '__file__', sys.argv[0])

    hardware = FreeBSDHardware()
    hardware.module = module
    # Mock the output of the devices command
    hardware.get_device_facts = mock_run_command
    hardware.devices = {}
    # Mock the output of the slices command

# Generated at 2022-06-22 23:04:36.264925
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # TODO: add assertions
    FreeBSDHardware(module=None).get_dmi_facts()

# Generated at 2022-06-22 23:04:49.262560
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = MockModule()
    hardware = FreeBSDHardware(module)

    # Test if value is returned properly
    dmidecode_bin = hardware.module.get_bin_path('dmidecode')
    dmidecode_output = 'testvalue\n# comment'
    dmidecode_command = '%s -s testkey' % dmidecode_bin

    # Test if command fails properly
    module.run_command.return_value = (1, '', '')

# Generated at 2022-06-22 23:04:49.771302
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:04:56.040156
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Unit test for method get_device_facts of class FreeBSDHardware'''
    hardware = FreeBSDHardware()
    dict_device_facts = hardware.get_device_facts()

    # Test if method get_device_facts returns a dictionary
    assert type(dict_device_facts) is dict
    # Test if the dictionary is empty
    assert dict_device_facts == {}

# Generated at 2022-06-22 23:05:06.246606
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # create a dummy module
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda *args, **kwargs: True,
        'run_command': lambda *args, **kwargs: (0, '', ''),
    })()

    # create a dummy class with a run_command method
    class DummyClass:
        def __init__(self):
            self.module = module

    memory_facts = FreeBSDHardware(DummyClass()).get_memory_facts()
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb']

# Generated at 2022-06-22 23:05:07.884306
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    uut = FreeBSDHardwareCollector('FreeBSD')
    assert uut.fact_class == FreeBSDHardware
    assert uut.platform == 'FreeBSD'

# Generated at 2022-06-22 23:05:18.241402
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """
    Test if FreeBSDHardware.populate() works.
    """
    class MockModule(object):
        @staticmethod
        def get_bin_path(name, required=False):
            if name == 'sysctl':
                class MockCommand(object):
                    @staticmethod
                    def run_command(command, check_rc=False, encoding=None):
                        out = "hw.ncpu: 4\n"
                        return 0, out, ''
                return MockCommand
            if name == 'swapinfo':
                class MockCommand(object):
                    @staticmethod
                    def run_command(command):
                        out = "Device          1M-blocks     Used    Avail Capacity\n" \
                              "/dev/ada0p3        314368        0   314368     0%"
                        return 0, out, ''
                return Mock

# Generated at 2022-06-22 23:05:25.764989
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    import pytest

    mock_module = ModuleFacts(argument_spec={}, bypass_checks=False, no_log=False,
                              check_invalid_arguments=False, run_command_environ_update=None,
                              run_command_check_rc=False,
                              run_command_strings_whitelist=None,
                              run_command_debug=False)
    mock_module.get_bin_path = lambda x: '/nonexistentbin/' + x

    real_get_file_content = Hardware.get_file_content

# Generated at 2022-06-22 23:05:28.633060
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModuleMock()
    FreeBSDHardwareCollector(module)
    assert module.get_bin_path.call_count == 1
    assert module.run_command.call_count == 2

# Generated at 2022-06-22 23:05:30.556528
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fshc = FreeBSDHardwareCollector()
    assert fshc.platform == 'FreeBSD'

# Generated at 2022-06-22 23:05:37.081519
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Instantiate FreeBSDHardwareCollector class object.
    fhc = FreeBSDHardwareCollector()
    # Iterate over the facts and print them out
    for fact, value in fhc.collect().items():
        print("%s - %s" % (fact, value))

if __name__ == '__main__':
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-22 23:05:46.199632
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Simulate a FreeBSD device list
    f = open('/tmp/bsd_device_list', 'w')
    f.write('/dev/ada0s1a\n/dev/ada1s1b\n/dev/ada2s1c\n')
    f.write('/dev/ada0\n/dev/ada1\n/dev/ada2\n')
    f.write('/dev/da0s1a\n/dev/da1s1b\n/dev/da2s1c\n')
    f.write('/dev/da0\n/dev/da1\n/dev/da2\n')
    f.write('/dev/cd0\n')

# Generated at 2022-06-22 23:05:56.924008
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware(dict())

    # Returned empty hardware facts
    hardware_facts = hardware.populate()
    assert hardware_facts is not None

    # Check if the hardware facts is equal to the test data

# Generated at 2022-06-22 23:06:07.072185
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_facts={}
    dmi_facts['chassis_asset_tag']='Not Specified'
    dmi_facts['board_vendor']='ASRock'
    dmi_facts['system_vendor']='ASRock'
    dmi_facts['board_asset_tag']='Not Specified'
    dmi_facts['chassis_vendor']='Not Specified'
    dmi_facts['chassis_version']='Not Specified'
    dmi_facts['form_factor']='Rack Mount Chassis'
    dmi_facts['product_uuid']='00020003-0004-0005-0006-000700080009'
    dmi_facts['product_version']='P3.10'

# Generated at 2022-06-22 23:06:18.332807
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleStub:
        class RunCommand:
            def __init__(self, stdout='', returncode=0):
                self.cmd = None
                self.rc = returncode
                self.stdout = stdout

            def __call__(self, cmd, check_rc=True):
                self.cmd = cmd
                return self.rc, self.stdout, ''

        def __init__(self):
            self.rc = 0
            self.bin_path = {'sysctl': '/sbin/sysctl'}
            self.run_command = ModuleStub.RunCommand()

    # test 1
    m = ModuleStub()

# Generated at 2022-06-22 23:06:29.779333
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import Hardware
    from ansible.module_utils.facts.other.freebsd import FreeBSDHardwareCollector

    # initialize hardware metadata
    hardware_collector = FreeBSDHardwareCollector()
    hardware_metadata = hardware_collector.collect()[0]
    hardware_facts = hardware_metadata.populate()

    # Check keys of hardware facts
    hardware_keys = [
        'devices',
        'memfree_mb',
        'memtotal_mb',
        'mounts',
        'processor',
        'processor_cores',
        'processor_count',
        'swapfree_mb',
        'swaptotal_mb',
        'uptime_seconds',
    ]
    for key in hardware_keys:
        assert key in hardware_facts

# Generated at 2022-06-22 23:06:38.266435
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = FakeAnsibleModule()
    setattr(test_module,
            'run_command',
            lambda *args, **kwargs: (0, 'some ada0 some', ''))
    setattr(test_module,
            'get_bin_path',
            lambda *args, **kwargs: '/usr/local/bin/dmidecode')
    facts = FreeBSDHardware(test_module).populate()
    assert 'devices' in facts
    assert facts['devices']['ada0'] == []
    setattr(test_module,
            'run_command',
            lambda *args, **kwargs: (1, '', 'some'))
    facts = FreeBSDHardware(test_module).populate()
    assert 'devices' in facts

# Generated at 2022-06-22 23:06:43.533771
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = get_platform_subclass(FreeBSDHardware)
    assert module is not None

    hw = module()
    assert hw.get_file_content('/etc/fstab') is not None
    assert hw.mount_size('/tmp') is not None
    assert hw.mount_command('/tmp') is not None
    assert hw.mount_options('/tmp') is not None

# Generated at 2022-06-22 23:06:51.574048
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:06:58.242996
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = type('Module', (object,), {'run_command': run_command})()
    test_module.get_bin_path = lambda _: '/sbin/sysctl'
    test_hardware = FreeBSDHardware(test_module)
    answers = {
        'processor_cores': "2",
        'processor_count': "4",
        'processor': [
            'Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz',
            'Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz',
            'Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz',
            'Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz'
        ]
    }
    facts = test

# Generated at 2022-06-22 23:07:02.374873
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    hardware.get_cpu_facts()
    hardware.get_memory_facts()
    hardware.get_uptime_facts()

# Generated at 2022-06-22 23:07:07.285480
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardwareCollector
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    assert FreeBSDHardwareCollector._platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:07:11.787147
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Unit test for constructor of class FreeBSDHardwareCollector
    """
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.hardware.freebsd import FreeBSDHardwareCollector

    # built-in module, no need to specify args
    assert isinstance(collector.get_collector(FreeBSDHardwareCollector._platform, FreeBSDHardwareCollector._fact_class),
                      FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:07:13.376506
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict(), dict())


# Generated at 2022-06-22 23:07:23.947416
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FakeAnsibleModule(get_file_content=lambda x: FAKE_DMESG_BOOT_CONTENT)
    freebsd_hw = FreeBSDHardware(module)
    cpu_facts = freebsd_hw.get_cpu_facts()

# Generated at 2022-06-22 23:07:34.218951
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    result = {
        "processor": ['Intel(R) Core(TM) i7-2677M CPU @ 1.80GHz', 'AuthenticAMD'],
        "processor_cores": '1',
        "processor_count": '8'
    }

# Generated at 2022-06-22 23:07:46.141649
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # no output, return empty value
    assert hardware.get_uptime_facts() == {}

    # wrong output format, return empty value
    def mock_command(*args, **kwargs):
        return (0, "foo", "stderr")
    hardware.module.run_command = mock_command
    assert hardware.get_uptime_facts() == {}

    # correct struct output, return valid uptime
    def mock_command_success(*args, **kwargs):
        return (0, struct.pack('@L', int(time.time()) - 600), "stderr")
    hardware.module.run_command = mock_command_success
    assert hardware.get_uptime_facts() == {'uptime_seconds': 600}


# Generated at 2022-06-22 23:07:57.312096
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    class ModuleMock():
        def get_bin_path(self, arg):
            return arg

    def run_command(*args, **kwargs):
        if args[0] == ['sysctl', '-b', 'kern.boottime']:
            boottime = int(time.time()) - 100
            return (0, struct.pack('@L', boottime), '')
        else:
            raise Exception('Unexpected call of run_command: {}'.format(' '.join(args[0])))

    # We need to mock the module class to make get_bin_path work

# Generated at 2022-06-22 23:08:09.466117
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:08:20.308597
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    mocked_module = MockAnsibleModule()

    # Test the case where dmidecode is available and all fields are found.

# Generated at 2022-06-22 23:08:31.933194
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.utils import mock_module

    class TestArgs(object):
        def __init__(self, tmpdir):
            self.run_command_tmpdir = tmpdir
            self.debug = True
            self.timeout = 10

    test_args = TestArgs(tmpdir=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output'))
    test_module = mock_module(test_args)
    test_module.exit_json = lambda x: x

    # Set up a testable time point
    test_time = datetime.datetime(2017, 2, 14, 10, 0, 30, 0)

    # Prepare a fake kern.boottime timestamp
    boot_timestamp_file = test_module.get

# Generated at 2022-06-22 23:08:36.335848
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    This function is to test constructor of class FreeBSDHardwareCollector
    """
    hw = FreeBSDHardwareCollector()
    assert hw.hardware is not None
    assert hw.platform == 'FreeBSD'


# Generated at 2022-06-22 23:08:48.761577
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockModule({'kernel': 'FreeBSD'})
    facts = FreeBSDHardware(module=module).populate()

    assert facts['devices'] == {'ada0': ['ada0s1a', 'ada0s1b'], 'ada1': ['ada1s1']}
    assert facts['memfree_mb'] == 1055
    assert facts['memtotal_mb'] == 10173

# Generated at 2022-06-22 23:09:02.262905
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:09:13.055892
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    os_facts = {
        'distribution': 'FreeBSD',
        'distribution_version': '12.0-CURRENT',
        'distribution_release': 'amd64',
        'system': 'FreeBSD',
        'system_path': '/',
        'system_auto_swap_enabled': False,
        'system_auto_swap_path': '/var/swap',
        'system_auto_mount_enabled': False,
        'system_auto_mount_path': '/mnt'
    }

    hw = FreeBSDHardware(module=None, facts=os_facts)
    hwfacts = hw.populate()

    # Don't know how to check the values, but we can make sure the
    # key names are correct and that the dictionary has some content.

# Generated at 2022-06-22 23:09:14.468409
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict(), None)
    assert hardware.platform == 'FreeBSD'

# Generated at 2022-06-22 23:09:24.485499
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' Return a dmi_facts dict'''

    fhw = FreeBSDHardware()
    dmi_facts = fhw.get_dmi_facts()

    assert isinstance(dmi_facts, dict), 'get_dmi_facts must return a dict'
    # build a list of key that must be in the dict
    dmi_keys = []
    for (k, _) in fhw.DMI_DICT.items():
        dmi_keys.append(k)
    # test we have all keys in the dict
    assert dmi_keys == sorted(list(dmi_facts.keys()))

# Generated at 2022-06-22 23:09:33.728051
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # setup
    class Module:
        def get_bin_path(self, name):
            return name
        def run_command(self, args, encoding=None):
            class RC:
                def __init__(self, code, out, err):
                    self.rc = code
                    self.out = out
                    self.err = err
            return RC(0, 'kern.boottime: { sec = 1528617379, usec = 245322 }\n', '')
    module = Module()
    # test
    obj = FreeBSDHardware(module)
    uptime_facts = obj.get_uptime_facts()
    # assert
    assert uptime_facts['uptime_seconds'] == 1528617378

# Generated at 2022-06-22 23:09:45.013887
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    import tempfile
    import pytest

    from ansible.module_utils.facts.timeout import TimeoutError

    from ansible.module_utils.facts.collector.freebsd.freebsd_hardware import FreeBSDHardware

    def test_outputs(outputs):
        for cmd, value in outputs:
            rc, out, err = module.run_command(cmd, encoding=None)
            assert value == out

    # Faked commands to get different output
    # For the output formats: see https://www.freebsd.org/cgi/man.cgi?kern.boottime

# Generated at 2022-06-22 23:09:58.080502
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    iface = FreeBSDHardware(module)
    facts = iface.populate()
    assert 'ansible_freebsd_host_os_family' in facts
    assert 'ansible_freebsd_host_os_major_version' in facts
    assert 'ansible_freebsd_host_os_minor_version' in facts
    assert 'ansible_freebsd_os_family' in facts
    assert 'ansible_freebsd_os_major_version' in facts
    assert 'ansible_freebsd_os_minor_version' in facts
    assert 'ansible_distribution' in facts
    assert 'ansible_distribution_release' in facts
    assert 'ansible_distribution_version' in facts

# Generated at 2022-06-22 23:10:06.953550
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_name = 'ansible.module_utils.facts.hardware.freebsd'
    module_args = {}
    tmp_mock = __import__(module_name, globals(), locals(), ['AnsibleModule'], 0)
    tmp_mock.AnsibleModule.run_command = lambda *args, **kwargs: (0, struct.pack('@L', int(time.time()) - 1337), '')

    # Test the function called by the module
    hardware = FreeBSDHardware({})
    hardware.module = tmp_mock.AnsibleModule(module_name, module_args)
    result = hardware.get_uptime_facts()

    assert result['uptime_seconds'] == 1337


# Generated at 2022-06-22 23:10:17.800935
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.six import PY3

    class MockModule:
        def __init__(self, module_name='ansible.module_utils.facts.hardware.freebsd'):
            self.module_name = module_name

        def get_bin_path(self, name):
            return name

        if PY3:
            # Python 3 gives raw bytes so we decode them.
            def run_command(self, argv, encoding=None):
                self._argv = argv
                self._encoding = encoding
                return 0, b'\xaa\xbb\xcc\xdd', None
        else:
            # Python 2 gives text.
            def run_command(self, argv, encoding=None):
                self._argv = argv
                self._encoding = encoding
               

# Generated at 2022-06-22 23:10:21.728361
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # test if an instance has been created
    assert FreeBSDHardwareCollector.__doc__
    # test if _fact_class is of type Hardware
    assert isinstance(FreeBSDHardwareCollector._fact_class, Hardware)

# Generated at 2022-06-22 23:10:31.444350
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    facts_collector = FreeBSDHardwareCollector(module=module)
    facts = facts_collector.collect([]).populate()

    assert facts is not None
    assert 'ansible_devices' in facts
    assert 'ansible_mounts' in facts
    assert 'ansible_processor_cores' in facts
    assert 'ansible_processor_count' in facts
    assert 'ansible_processor' in facts
    assert 'ansible_memfree_mb' in facts
    assert 'ansible_memtotal_mb' in facts
    assert 'ansible_swapfree_mb' in facts
    assert 'ansible_swaptotal_mb' in facts
    assert 'ansible_system_vendor' in facts

# Generated at 2022-06-22 23:10:42.527601
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test without any argument.
    facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in facts
    assert isinstance(facts['uptime_seconds'], int)

    # Test with empty string.
    facts = hardware.get_uptime_facts('')
    assert 'uptime_seconds' in facts
    assert isinstance(facts['uptime_seconds'], int)

    # Test with non-empty string.
    with pytest.raises(AnsibleFailJson):
        facts = hardware.get_uptime_facts('non-empty-string')

    # Test with special character.
    with pytest.raises(AnsibleFailJson):
        facts = hardware.get_uptime_

# Generated at 2022-06-22 23:10:44.208832
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert isinstance(FreeBSDHardwareCollector()._fact_class, FreeBSDHardware)

# Generated at 2022-06-22 23:10:55.556360
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardwareCollector(module=module, facts={}).collect()[0]

    assert hardware.get_cpu_facts() == {
        'processor': [
            'Intel(R) Core(TM) i3-2120 CPU @ 3.30GHz',
            'Intel(R) Core(TM) i3-2120 CPU @ 3.30GHz',
            'Intel(R) Core(TM) i3-2120 CPU @ 3.30GHz',
            'Intel(R) Core(TM) i3-2120 CPU @ 3.30GHz'
        ],
        'processor_cores': '4',
        'processor_count': '4'
    }

# Generated at 2022-06-22 23:10:56.676233
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    FreeBSDHardware.get_uptime_facts(None)

# Generated at 2022-06-22 23:11:02.783269
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware_instance = FreeBSDHardware(module)
    hardware_instance.populate()

    fail_msg = "Expected fact not found from populate"

    assert hardware_instance.facts.get('processor_cores'), fail_msg
    assert hardware_instance.facts.get('processor_count'), fail_msg

# Generated at 2022-06-22 23:11:04.003441
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # TODO
    pass

# Generated at 2022-06-22 23:11:05.808204
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector.__name__ == 'FreeBSDHardwareCollector'

# Generated at 2022-06-22 23:11:07.460221
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert issubclass(FreeBSDHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:11:18.711435
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import sys
    import io
    import tempfile
    import shutil

    m = FreeBSDHardware({})
    assert m.get_device_facts() == {}

    t = tempfile.mkdtemp()
    sys.argv[1:] = ['-c', 'import sys; print(sys.argv[1:])', '/sys', '-o', 'devices']
    stdout = io.StringIO()
    stderr = io.StringIO()

# Generated at 2022-06-22 23:11:24.865992
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware_obj = FreeBSDHardware(dict())
    hardware_obj.module.get_bin_path = lambda x: '/usr/sbin/dmidecode'
    hardware_obj.module.run_command = lambda x: (0, 'system-manufacturer: VMware, Inc.', '')
    dmi_facts = hardware_obj.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'

# Generated at 2022-06-22 23:11:26.460066
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_facts = FreeBSDHardware()
    assert hardware_facts.platform == 'FreeBSD'



# Generated at 2022-06-22 23:11:31.454454
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = FreeBSDHardware()
    result = m.get_cpu_facts()
    assert result == {'processor': ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'],
                      'processor_cores': '4', 'processor_count': '4'}


# Generated at 2022-06-22 23:11:40.585753
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = FakeAnsibleModule()

    # Run a first test using the sysctl command
    FreeBSDHardware(module)
    module.run_command = fake_run_command
    facts = {'uptime_seconds': 121658}
    assert FreeBSDHardware(module).get_uptime_facts() == facts

    # Run another test using the sysctl command but with an invalid ouptut
    module.run_command.data['kern.boottime'] = {'stderr': 'Invalid output'}
    assert FreeBSDHardware(module).get_uptime_facts() == {}

    # Run another test when the sysctl command is not available
    module.get_bin_path.results = (None,)
    assert FreeBSDHardware(module).get_uptime_facts() == {}


# Generated at 2022-06-22 23:11:42.501303
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    o = FreeBSDHardware()
    assert o.platform == 'FreeBSD'



# Generated at 2022-06-22 23:11:44.559752
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    obj = FreeBSDHardware({})
    assert obj


# Generated at 2022-06-22 23:11:50.910948
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    def mock_run_command(module):
        return (0, 'value_match_string', '')

    test_module = type('test_module', (object,), {'run_command': mock_run_command})
    test_module.get_bin_path = mock_run_command
    test_facts = FreeBSDHardware(test_module)
    test_facts.get_dmi_facts()

# Generated at 2022-06-22 23:11:58.265557
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    mock_module = type('MockModule', (), dict(run_command=lambda self, args, check_rc=True: (0, '', '')))()
    mock_module.get_bin_path = lambda x: 'sysctl'
    hardware = FreeBSDHardware(mock_module)
    hardware.get_cpu_facts()
    assert hardware.cpu[0] == 'Intel(R) Xeon(R) CPU E5-2640 0 @ 2.50GHz'


# Generated at 2022-06-22 23:12:00.231435
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fh = FreeBSDHardwareCollector()
    assert(isinstance(fh, HardwareCollector))


# Generated at 2022-06-22 23:12:12.202499
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:12:22.114635
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    mock_module = MockModule()

# Generated at 2022-06-22 23:12:29.642181
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    check that get_uptime_facts returns a dict with 'uptime_seconds' key
    '''

    # get FreeBSDHardware object
    hardware = FreeBSDHardware()

    # get dict with uptime_seconds key
    uptime_facts = hardware.get_uptime_facts()

    # check that 'uptime_seconds' key is in dict
    assert 'uptime_seconds' in uptime_facts
    # should not be empty
    assert uptime_facts['uptime_seconds']

# Generated at 2022-06-22 23:12:32.373217
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    results = FreeBSDHardwareCollector()
    assert(results._fact_class is FreeBSDHardware)
    assert(results._platform is 'FreeBSD')

# Generated at 2022-06-22 23:12:42.814189
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:12:46.516083
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector_obj = FreeBSDHardwareCollector()
    assert hw_collector_obj.platform == 'FreeBSD'
    assert hw_collector_obj._fact_class == FreeBSDHardware


# Generated at 2022-06-22 23:12:58.603250
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import io
    import ansible.module_utils.facts.hardware.freebsd
    class DummyModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outputs = []
            self.run_command_exceptions = []
            self.get_bin_path_calls = []
            self.get_bin_path_paths = []
        def get_bin_path(self, cmd, required=False):
            self.get_bin_path_calls.append(cmd)
            if len(self.get_bin_path_paths) > 0:
                return self.get_bin_path_paths.pop(0)
            else:
                return cmd

# Generated at 2022-06-22 23:13:01.197450
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0

# Generated at 2022-06-22 23:13:03.619722
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw.platform == 'FreeBSD'


# Generated at 2022-06-22 23:13:10.594226
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {'AN': '1', 'IN': '2'}

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, "hw.ncpu: 2", ''

    class Mock:
        def __init__(self, **kwargs):
            self.params = {'ANSIBLE_MODULE_ARGS': {'AN': '1', 'IN': '2'}}
            for key, val in kwargs.items():
                setattr(self, key, val)

    # Creating instance of class FreeBSDHardware
    obj = FreeBSDHardware(Mock())


# Generated at 2022-06-22 23:13:18.930301
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError, timeout
    from ansible.module_utils._text import to_bytes
    import os
    import pytest
    import tempfile

    timeout_decorator = pytest.mark.timeout(5)
    fake_uuid = 'e0bb5a63-858d-401a-89df-c06d7de8e182'
    fake_product_name = 'KVM-based Virtual Machine'
    fake_system_vendor = 'innotek GmbH'
    fake_product_serial = '20374F81'
    fake_bios_vendor = 'innotek GmbH'
    fake_chassis_type = '4'
    fake

# Generated at 2022-06-22 23:13:31.263739
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for method FreeBSD.populate
    '''
    class MockModule(object):
        def __init__(self, module_name, bin_path, rc, out, err):
            self.module_name = module_name
            self.bin_path = bin_path
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, module_name):
            return self.bin_path

        def run_command(self, cmd, check_rc=True, encoding=None):
            return (self.rc, self.out, self.err)

    f = FreeBSDHardware()
    f.module = MockModule('freebsd_hardware', 'dmesg', 0, 'hw.ncpu: 4\nhw.machine: amd64', '')

# Generated at 2022-06-22 23:13:39.852910
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import subprocess
    import sys
    import unittest

    class mock_module:
        def __init__(self):
            pass

        def get_bin_path(module, executable, required=False):
            return executable

        def run_command(self, cmd, encoding=None):
            return subprocess.call(cmd, shell=False)

    class TestFreeBSDHardware(unittest.TestCase):
        def test_get_uptime_facts(self):
            fhw = FreeBSDHardware()
            fhw.module = mock_module()
            try:
                fhw.get_uptime_facts()
            except Exception:
                if sys.version_info[0] < 3:
                    self.assertEqual(1, True)
                else:
                    self.assertTrue(True)

# Generated at 2022-06-22 23:13:51.281377
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    expected = {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s2', 'ada0s3', 'ada0s3a', 'ada0s3b', 'ada0s3c', 'ada0s3d', 'ada0s3e', 'ada0s3f'], 'da0': ['da0s1a', 'da0s1b', 'da0s2', 'da0s3', 'da0s3a', 'da0s3b', 'da0s3c', 'da0s3d', 'da0s3e', 'da0s3f']}}
    freebsd_hardware = FreeBSDHardware(None)
    expected_devices = freebsd_hardware.get_device_facts()
    assert expected_devices == expected

# Generated at 2022-06-22 23:13:53.977041
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # the FreeBSDHardwareCollector class creates FreeBSDHardware objects
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector.fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:13:56.412272
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware()
    # This method does not accept any argument
    assert hardware.get_device_facts() == {'devices': {}}

# Generated at 2022-06-22 23:14:08.179191
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import tempfile
    import shutil

    fd, path = tempfile.mkstemp()
    test_facts = FreeBSDHardware({'module_name': 'test', 'module_args': {}})
    os.close(fd)

    os.mkdir(path + '/dev')
    open(path + '/dev/ada0', 'a').close()
    open(path + '/dev/ada0s1', 'a').close()
    open(path + '/dev/da0', 'a').close()
    open(path + '/dev/da0s1', 'a').close()

    os.environ['PATH'] = path
    devices = test_facts.get_device_facts()
    shutil.rmtree(path)

    assert devices['devices']['ada0'] == ['ada0s1']
    assert devices

# Generated at 2022-06-22 23:14:12.659207
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_class = FreeBSDHardware()

    result = test_class.get_cpu_facts()

    assert type(result) is dict
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result


# Generated at 2022-06-22 23:14:17.131308
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    fact_module_class = FreeBSDHardware(module)
    dmi_facts = fact_module_class.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'
