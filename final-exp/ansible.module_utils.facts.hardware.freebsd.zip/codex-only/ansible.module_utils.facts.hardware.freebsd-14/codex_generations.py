

# Generated at 2022-06-22 23:04:23.893087
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Tests are not part of the execution path:
    # we test them when invoked manually
    h = FreeBSDHardware({})
    # We can't call get_uptime_facts, as it needs module
    # But we can test the helper method
    assert h.calc_uptime_seconds(0, 0) == 0
    assert h.calc_uptime_seconds(0, 1) == (1e6)
    assert h.calc_uptime_seconds(10, 0) == 1e10
    assert h.calc_uptime_seconds(1, 1) == (1e6 + 1)
    assert h.calc_uptime_seconds(10, 10) == (1e10 + 1e6)

# Generated at 2022-06-22 23:04:34.715917
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleMock(object):
        def get_bin_path(mock, cmd):
            return '/usr/bin/dmidecode' if cmd == 'dmidecode' else None

        def run_command(mock, args, encoding=None):
            cmd = args[1][4:]
            if cmd == 'bios-release-date':
                return 0, '01/01/2011', None
            if cmd == 'chassis-version':
                return 1, None, None

        def fail_json(mock, rc):
            pass

    m = ModuleMock()
    f = FreeBSDHardware(m)
    dmi_facts = f.get_dmi_facts()
    assert dmi_facts['bios_date'] == '01/01/2011'

# Generated at 2022-06-22 23:04:37.423554
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    hardware.get_device_facts()
    assert isinstance(hardware.facts['devices'], dict)

# Generated at 2022-06-22 23:04:38.388210
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    obj_FreeBSDHardware = FreeBSDHardware()
    pass

# Generated at 2022-06-22 23:04:51.231622
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Mocked utmp struct
    utmp_time = struct.pack('@L', 1234567890)

    # Mocked sysctl command
    def mocked_run_command(cmd, encoding=None):
        if cmd[-1] == '-b':
            return 0, utmp_time, ''
        else:
            return -1, '', ''

    # Build mocked module
    module = type('AnsibleModule', (object,), {
        'run_command': mocked_run_command,
        'get_bin_path': lambda x: '/usr/bin/sysctl'
    })

    # Test
    hardware_class = FreeBSDHardware(module)
    expected = {'uptime_seconds': int(time.time() - 1234567890)}
    assert hardware_class.get_uptime_facts() == expected


# Generated at 2022-06-22 23:05:03.216772
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import tempfile
    import shutil
    import stat
    test_location = tempfile.mkdtemp()

    # Create temporary devices
    os.mkdir(os.path.join(test_location, 'dev'))
    os.mkdir(os.path.join(test_location, 'dev', 'ada0s1'))
    os.mkdir(os.path.join(test_location, 'dev', 'ada0s2'))
    os.mkdir(os.path.join(test_location, 'dev', 'ada0s3'))
    os.mkdir(os.path.join(test_location, 'dev', 'ada1s1'))
    os.mkdir(os.path.join(test_location, 'dev', 'ada1s2'))

# Generated at 2022-06-22 23:05:15.955971
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:05:23.737613
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = FakeAnsibleModule("FreeBSDHardwareCollector")
    test_module.swap = {'swapinfo': 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%'}

    hardware_collector = FreeBSDHardwareCollector(module=test_module)
    hardware_collector.get_memory_facts()

    assert hardware_collector.facts['memtotal_mb'] == 32279
    assert hardware_collector.facts['memfree_mb'] == 31164
    assert hardware_collector.facts['swaptotal_mb'] == 314368
    assert hardware_collector.facts['swapfree_mb'] == 314368


# Generated at 2022-06-22 23:05:27.465451
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = FreeBSDHardwareCollector(None, None).collect()
    assert facts['devices']['ada0'][0] == 'ada0s1', \
            "FreeBSDHardwareCollector failed to detect device"

# Generated at 2022-06-22 23:05:39.839267
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Case 1: rc != 0
    module = AnsibleModuleMock({})
    module.run_command.side_effect = [
        (-1, '', ''),
        None,
    ]
    hardware_fact = FreeBSDHardware(module)
    assert hardware_fact.get_uptime_facts() == {}

    # Case 2: rc == 0, but out is less than struct_size
    module = AnsibleModuleMock({})
    module.run_command.side_effect = [
        (0, '', ''),
        None,
    ]
    hardware_fact = FreeBSDHardware(module)
    assert hardware_fact.get_uptime_facts() == {}

    # Case 3: rc == 0, out contains the up time.
    module = AnsibleModuleMock({})

# Generated at 2022-06-22 23:05:40.812187
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    m = FreeBSDHardwareCollector()
    assert m != None

# Generated at 2022-06-22 23:05:47.907976
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts import get_module_path

    module = imp.load_source('module_name',
                             os.path.join(get_module_path('ansible.module_utils.facts.hardware.freebsd'),
                                          'freebsd.py'))
    fbsd = module.FreeBSDHardware()


# Generated at 2022-06-22 23:05:53.767119
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = type('test_module', (object,), {})
    module.run_command = lambda command: (0, 'hw.ncpu: 2', '')
    module.get_bin_path = lambda command: '/bin/sysctl'
    fhw = FreeBSDHardware(module)
    out = fhw.get_cpu_facts()
    assert out['processor_count'] == '2'


# Generated at 2022-06-22 23:05:58.927323
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fact_module = FreeBSDHardware()
    fact_module.module = module

    memory_facts = fact_module.get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert 'pagecount' in memory_facts
    assert 'pagefree' in memory_facts

# Generated at 2022-06-22 23:06:07.931756
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class ModuleStub:
        @staticmethod
        def get_bin_path(path):
            return path


# Generated at 2022-06-22 23:06:18.535411
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    bsdh = FreeBSDHardware()
    bsdh.module = module

    # Assume dmidecode is not available
    bsdh.module.get_bin_path = lambda x: None
    assert bsdh.get_dmi_facts() == {}

    # Test dmidecode behaviour
    bsdh.module.get_bin_path = lambda x: '/usr/sbin/dmidecode'
    bsdh.module.run_command = lambda x, encoding=None: (0, 'test\n#test2', '')
    assert bsdh.get_dmi_facts() == {'bios_date': 'test'}



# Generated at 2022-06-22 23:06:29.903524
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils._text import to_bytes
    # Create an instance of FreeBSDHardware class
    mh = FreeBSDHardware(dict())

    # Create a mocked module object for the FreeBSDHardware class
    mm = mh.module

# Generated at 2022-06-22 23:06:38.420253
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-22 23:06:39.786526
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware(dict(), dict())
    assert fhw is not None

# Generated at 2022-06-22 23:06:48.573816
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_facts = dict()
    dmi_facts['system_vendor'] = 'Test System Vendor'
    dmi_facts['product_name'] = 'Test Product Name'
    dmi_facts['product_version'] = 'Test Product Version'
    dmi_facts['product_serial'] = 'Test Product Serial'
    dmi_facts['product_uuid'] = 'Test Product UUID'
    dmi_facts['board_vendor'] = 'Test Board Vendor'
    dmi_facts['board_name'] = 'Test Board Name'
    dmi_facts['board_version'] = 'Test Board Version'
    dmi_facts['board_serial'] = 'Test Board Serial'
    dmi_facts['board_asset_tag'] = 'Test Board Asset Tag'
    dmi_facts['chassis_vendor']

# Generated at 2022-06-22 23:06:49.374131
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhw = FreeBSDHardwareCollector()


# Generated at 2022-06-22 23:06:56.435050
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={
        }
    )
    hardware_instance = FreeBSDHardware(module)
    hardware_facts = hardware_instance.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert type(hardware_facts['uptime_seconds']) == int or type(hardware_facts['uptime_seconds']) == float
    assert type(hardware_facts['devices']) == dict
    assert type(hardware_facts['mounts']) == list
    assert type(hardware_facts['mounts'][0]) == dict
    assert hardware_facts['memtotal_mb'] > 0
    assert type(hardware_facts['processor_cores']) == int
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['memtotal_mb']

# Generated at 2022-06-22 23:07:10.233092
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleStub():
        def __init__(self):
            self.bin_path = ''

        def run_command(self, cmd, check_rc=True, encoding='utf-8'):
            def guess_struct_format(length):
                return '@L'

            def decode_raw_bytes(value):
                return '%d.%d' % (value, 0)

            if 'kern.boottime' in cmd:
                output = guess_struct_format(length=8)
                output += decode_raw_bytes(value=1445526500)
                return (0, output, 'No error')
            else:
                return (0, '', 'No error')

    hardware_facts = FreeBSDHardware(ModuleStub())

    # Compare the output of method get_uptime_facts with the expected output

# Generated at 2022-06-22 23:07:22.083091
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.freebsd
    class TestModule():
        def __init__(self):
            import tempfile
            from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
            self.tmpdir = tempfile.mkdtemp()
            self.exit_args = {}
            self.exit_args['failed'] = False

# Generated at 2022-06-22 23:07:32.766099
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """FreeBSD - class FreeBSDHardware - method populate"""

    # Test #1 - Typical FreeBSD 12.0 install
    module = AnsibleModule(argument_spec={})
    facts_collector = FreeBSDHardwareCollector(module=module)
    facts = facts_collector.collect(module)
    assert facts['devices'] == {
        'ada0': [
            'ada0s1', 'ada0s2', 'ada0s3', 'ada0s4'
        ],
    }
    assert facts['bios_version'] == '1201-1'
    assert facts['board_name'] == 'B365M-D3H'
    assert facts['form_factor'] == 'Desktop'
    assert facts['memfree_mb'] == 13913
    assert facts['memtotal_mb'] == 16075
    assert facts['product_name']

# Generated at 2022-06-22 23:07:34.602307
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts_collector = HardwareCollector.factory('FreeBSDHardwareCollector')
    assert isinstance(facts_collector, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:07:46.590140
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = type('testModule', (object,), dict(params={}, run_command=lambda *a, **kw: (0, '', '')))()
    fh = FreeBSDHardware()
    fh.module = module

# Generated at 2022-06-22 23:07:49.262873
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = DummyAnsibleModule()
    hardware = FreeBSDHardware(module)
    assert hardware.platform == 'FreeBSD'


# Generated at 2022-06-22 23:07:59.453418
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.freebsd.hardware import FreeBSDHardware

    # Test valid output

# Generated at 2022-06-22 23:08:12.499578
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module(object):
        def __init__(self):
            self.check_mode = False

        @staticmethod
        def run_command(command, encoding=None, errors='strict'):
            # Doesn't matter which command we get as this is only a mock.
            # Expect the command to be passed to sysctl to get kern.boottime.
            class Result(object):
                def __init__(self, rc, stdout, stderr):
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = stderr

            # Return the time since epoch returned by time.time().
            # This is the raw value returned by sysctl.
            return Result(0, str(int(time.time())), '')

    # In the constructor of FreeBSDHardware, we call
    # the parent

# Generated at 2022-06-22 23:08:21.693290
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class FakeModule(object):

        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = []

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 0, '1024 1048576 1048576', ''

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

    memory_facts = FreeBSDHardware(FakeModule()).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1048576 / 1024
    assert memory_facts['memfree_mb'] == 1024 / 1024



# Generated at 2022-06-22 23:08:24.212955
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    assert isinstance(FreeBSDHardware(), dict)
    assert isinstance(FreeBSDHardware(set()), dict)


# Generated at 2022-06-22 23:08:31.074851
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return 'sysctl'

        @staticmethod
        def run_command(*args, **kwargs):
            return (0, struct.pack('@q', time.time() - 42), None)

    module = MockModule()
    result = FreeBSDHardware(module).get_uptime_facts()
    assert result['uptime_seconds'] == 42

# Generated at 2022-06-22 23:08:43.692525
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_platform = 'FreeBSD'
    test_os = 'FreeBSD'
    test_dist = None
    test_system = None

    # Construct an object of class FreeBSDHardwareCollector
    test_obj = FreeBSDHardwareCollector(test_platform, test_os, test_dist, test_system)

    # Confirm the attributes are set as expected
    assert test_obj._platform == test_platform
    assert test_obj.platform == test_platform
    assert test_obj._os == test_os
    assert test_obj.os == test_os
    assert test_obj._dist == test_dist
    assert test_obj.dist == test_dist
    assert test_obj._system == test_system
    assert test_obj.system == test_system
    assert test_obj._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:08:56.640881
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class Mod:
        def __init__(self, rc, out, err):

            class C:
                class M:
                    def __init__(self, rc, out, err):
                        self.rc = rc
                        self.out = out
                        self.err = err

                    def run_command(self, cmd, encoding):
                        return self.rc, self.out, self.err

                def __init__(self, rc=0, out="", err=""):
                    self.rc, self.err, self.out = rc, out, err
                    self.run_command = self.M(self.rc, self.out, self.err)

            self.run_command = self.C(rc, out, err)
            self.get_bin_path = lambda foo: "dmidecode"


# Generated at 2022-06-22 23:09:03.498772
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware._module.run_command = lambda x: (0, '5', '')
    hardware._module.get_bin_path = lambda x: '/usr/bin/sysctl'
    assert hardware.get_memory_facts() == {'swaptotal_mb': 0, 'swapfree_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 5}

# Generated at 2022-06-22 23:09:14.127309
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bsd_hardware = FreeBSDHardware(None)
    bsd_hardware.module = lambda: None

    # Mutate the method 'run_command' of the class 'ModuleUtils'
    # to return a defined output.
    def run_command(self, cmd, encoding=None):
        return (0, b'\x24\xaa\x6d\xe7\x07\x00\x00\x00\x74\xee\x0c\x00\x00\x00\x00\x00', None)
    bsd_hardware.module.run_command = run_command

    # Mutate the method 'get_bin_path' of the class 'ModuleUtils'
    # to return 'sysctl'

# Generated at 2022-06-22 23:09:27.063775
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class MyModule(object):
        def get_bin_path(self, arg):
            return '/usr/sbin/dmidecode'


# Generated at 2022-06-22 23:09:31.203614
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0

# Generated at 2022-06-22 23:09:43.895318
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    device_facts = {}
    device_facts['devices'] = {}
    device_facts['devices']['da1'] = []
    device_facts['devices']['ada0'] = []
    device_facts['devices']['ada0'].append('ada0s1a')
    devices = ["da1", "da0s1a"]
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    sysdir = '/dev'
    if os.path.isdir(sysdir):
        dirlist = sorted(os.listdir(sysdir))
        for device in dirlist:
            d

# Generated at 2022-06-22 23:09:48.288329
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec=dict())
    freebsd_hardware = FreeBSDHardware(module=module)
    assert freebsd_hardware is not None
    assert freebsd_hardware.module == module



# Generated at 2022-06-22 23:09:50.722775
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    bsdhw = FreeBSDHardware(dict())
    assert bsdhw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:10:02.825027
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Create class instance of FreeBSDHardware
    fhw = FreeBSDHardware()

    # Create mock sysctl and swapinfo results (this is what the code
    # expects to get)
    sysctl_out = (
        'vm.nkmempages: 782432\n'
        'vm.stats.vm.v_swappgsin: 1\n'
        'vm.stats.vm.v_swappgsout: 1\n'
        'vm.stats.vm.v_swappginuse: 1\n'
    )
    swapinfo_out = (
        'Device          1M-blocks     Used    Avail Capacity\n'
        '/dev/ada0p3        314368        0   314368     0%\n'
    )

    # Create mock run command results

# Generated at 2022-06-22 23:10:10.946053
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    sysdir = './tests/unittests/test_utils/hardware/freebsd/dev'
    device_facts = FreeBSDHardware(module).get_device_facts(sysdir)
    assert 'devices' in device_facts
    assert 'md99' in device_facts['devices']
    assert ['md99s1a', 'md99s1b', 'md99s1d', 'md99s1e'] == device_facts['devices']['md99']



# Generated at 2022-06-22 23:10:17.030599
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, _):
            return 'sysctl'

        def run_command(self, cmd, encoding=None):
            return 0, struct.pack('@L', int(time.time() - (15 * 60))), ''

    hw = FreeBSDHardware(MockModule())

    uptime_facts = hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 15 * 60

# Generated at 2022-06-22 23:10:24.971230
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create a fake module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'ada0s1\nada0s2\nda0s1\nda0s2\n', ''),
        'get_bin_path': lambda *args, **kwargs: '/dev'
    })

    # Create a fake AnsibleModule instance
    fbh = FreeBSDHardware(module)
    assert (fbh.get_device_facts() is not None)

# Generated at 2022-06-22 23:10:25.492444
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    return True

# Generated at 2022-06-22 23:10:31.511228
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fhw = FreeBSDHardware({})
    facts = fhw.get_memory_facts()
    assert type(facts) is dict
    assert{'memfree_mb', 'memtotal_mb'}.issubset(facts)
    assert type(facts['memtotal_mb']) is int
    assert type(facts['memfree_mb']) is int


# Generated at 2022-06-22 23:10:42.567448
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fhw = FreeBSDHardware()

    # Test handling of an empty output
    rc, out, err = (0, "", "")
    assert fhw.get_uptime_facts() == {}

    # Test handling of an incorrect output (less bytes than expected)
    rc, out, err = (0, "ab12", "")
    assert fhw.get_uptime_facts() == {}

    rc, out, err = (0, "ab12cd", "")
    assert fhw.get_uptime_facts() == {}

    # Test handling of an incorrect output (more bytes than expected)
    rc, out, err = (0, "ab12cd00ef1234567890", "")
    assert fhw.get_uptime_facts()

# Generated at 2022-06-22 23:10:47.548704
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)

    # The following calls to populate() will raise an
    # exception in the case of error.
    hw.populate()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-22 23:10:52.627455
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    sys.path.insert(0, '../')
    from ansible.module_utils.facts.hardware.freebsd import test_dmi
    test_dmi()


if __name__ == '__main__':
    test_FreeBSDHardware_get_dmi_facts()

# Generated at 2022-06-22 23:10:55.196505
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    Unit test for constructor of FreeBSDHardware class
    '''
    module = AnsibleModule(argument_spec={})
    current_freebsd_hardware = FreeBSDHardware(module)
    assert current_freebsd_hardware.module == module
    assert current_freebsd_hardware.platform == "FreeBSD"


# Generated at 2022-06-22 23:10:59.679697
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware({})
    assert isinstance(hardware.get_cpu_facts(), dict)
    assert 'processor' in hardware.get_cpu_facts()
    assert 'processor_cores' in hardware.get_cpu_facts()
    assert 'processor_count' in hardware.get_cpu_facts()


# Generated at 2022-06-22 23:11:02.068728
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc

# Generated at 2022-06-22 23:11:14.546639
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    import time
    # This test only check the seconds of the returned value.
    time_beg_total = time.time()
    time_beg_second = datetime.datetime.now().second

    time_beg_minute = datetime.datetime.now().minute

    fhw = FreeBSDHardware()
    uptime_facts = fhw.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']

    time_end = time.time()
    time_beg = time_end - uptime_seconds

    time_end_second = datetime.datetime.now().second

    time_end_minute = datetime.datetime.now().minute

    assert time_beg <= time_beg_total
    assert time_end >= time_beg_total

# Generated at 2022-06-22 23:11:16.992710
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    # Test FreeBSDHardware class constructor
    obj = FreeBSDHardware(dict())

    # Test platform attribute is set correctly
    assert obj.platform == 'FreeBSD'


# Generated at 2022-06-22 23:11:19.821003
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardwareCollector
    fhc = FreeBSDHardwareCollector()
    assert fhc is not None

# Generated at 2022-06-22 23:11:24.350217
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    facts = FreeBSDHardware.get_memory_facts()
    assert facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

# Generated at 2022-06-22 23:11:34.787506
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    freebsd_hw = FreeBSDHardware(module)

    collected_facts = {
        'ansible_system': 'FreeBSD',
        'ansible_distribution': 'FreeBSD'
    }

    result = freebsd_hw.populate(collected_facts)

    assert result['devices'][freebsd_hw.devices.keys()[0]][0] == freebsd_hw.devices[freebsd_hw.devices.keys()[0]][0]
    assert result['devices'][freebsd_hw.devices.keys()[0]][1] == freebsd_hw.devices[freebsd_hw.devices.keys()[0]][1]


# Generated at 2022-06-22 23:11:36.462337
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = {}
    hc = FreeBSDHardwareCollector(facts, None)

# Generated at 2022-06-22 23:11:36.912043
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    pass

# Generated at 2022-06-22 23:11:40.795383
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = type('Module', (object,), {
        'get_bin_path': lambda x: None,
        'run_command': lambda self, args, check_rc=True: ('', 'hw.ncpu: 2', '')
    })

    f = FreeBSDHardware(test_module)
    cpu_facts = f.get_cpu_facts()
    assert cpu_facts == {'processor': ['CPU: 0'], 'processor_count': '2', 'processor_cores': '4'}


# Generated at 2022-06-22 23:11:52.821423
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = FreeBSDHardware({})
    # test of private function _parse_dmi_data()
    # case 1

# Generated at 2022-06-22 23:12:04.754740
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockAnsibleModule()
    hardware = FreeBSDHardware(module)

    # mock the dmesg output
    module.run_command.return_value = [0, FREEBSD_DMESG_BOOT_OUTPUT, '']

    # mock the swapinfo output
    module.get_bin_path.return_value = '/sbin/swapinfo'
    module.run_command.return_value = [0, FREEBSD_SWAPINFO_OUTPUT, '']

    # mock the sysctl output
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.run_command.return_value = [0, FREEBSD_SYSCTL_OUTPUT, '']

    hardware.populate()
    assert hardware.facts['memtotal_mb'] == 16384

# Generated at 2022-06-22 23:12:08.453146
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''Unit test for FreeBSDHardwareCollector'''

    print('Unit test for FreeBSDHardwareCollector.__init__')
    collector = FreeBSDHardwareCollector()
    assert(collector._fact_class == 'FreeBSDHardware')
    assert(collector._platform == 'FreeBSD')

# Generated at 2022-06-22 23:12:19.320278
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Sample of the content of /dev
    dirlist = [u'ada1', u'ada0', u'ada0s1a', u'mvme1', u'mvme0', u'mvme0s1a', u'cd0', u'cd0s1a', u'da0', u'da0s1a']

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    hardware = FreeBSDHardware()
    hardware.module = type('', (object,), {})()
    hardware.module.get_bin_path = lambda s: None
    hardware.module.run_command = lambda cmd, encoding: (0, '', '')
    hardware.module.params = type('', (object,), {})()

# Generated at 2022-06-22 23:12:25.324801
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    This test case is here to ensure that get_uptime_facts method of
    FreeBSDHardware class returns a valid value.
    """

    class ModuleStub:

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, encoding=None, check_rc=False):
            return (0, b'kern.boottime: { sec = 1510543727, usec = 609154 }\n', '')

    class HardwareStub(FreeBSDHardware):

        def __init__(self, module):
            self.module = module

    module_stub = ModuleStub()
    hardware_stub = HardwareStub(module_stub)
    uptime_facts = hardware_stub.get_uptime_facts()

    # After 1 second of testing, the returned

# Generated at 2022-06-22 23:12:37.998712
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = DummyModule()
    hardware_collector = FreeBSDHardwareCollector(module=module)
    ansible_facts = hardware_collector.collect(module=module, collected_facts={})

    assert(ansible_facts['ansible_facts']['processor'][0] == 'Genuine Intel(R) CPU 0000 @ 2.20GHz')
    assert(ansible_facts['ansible_facts']['processor_cores'] == '2')
    assert(ansible_facts['ansible_facts']['devices']['ada0'][0] == 'ada0s1a')
    assert(ansible_facts['ansible_facts']['devices']['ada0'][1] == 'ada0s1b')

# Generated at 2022-06-22 23:12:45.220287
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fixture = [
        "Handle 0x0002, DMI type 2, 16 bytes",
        "Base Board Information",
        "	Manufacturer: ASRock",
        "	Product Name: Z87M Pro4",
        "	Version: 1.10",
        "	Serial Number: 123456789",
        "	Asset Tag: To be filled by O.E.M.",
        "	Features:",
        "		Board is a hosting board",
        "		Board is replaceable",
        "	Location In Chassis: To be filled by O.E.M.",
        "	Chassis Handle: 0x0003",
        "	Type: Motherboard",
        "	Contained Object Handles: 0",
    ]

    info = FreeBSDHardware.get_dmi_facts_from_lines(fixture)


# Generated at 2022-06-22 23:12:49.676332
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.populate()

    assert hardware.facts is not None
    assert hardware.facts['uptime_seconds'] is not None
    assert hardware.facts['devices'] is not None



# Generated at 2022-06-22 23:12:51.071085
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """Test if the FreeBSDHardwareCollector can be created"""
    fhcl = FreeBSDHardwareCollector(None)
    assert fhcl is not None

# Generated at 2022-06-22 23:12:59.210804
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    if not hasattr(module, 'set_module_args'):
        module.params = {}
    if not hasattr(module, 'get_bin_path'):
        from ansible.module_utils.facts.collector.freebsd import get_bin_path
        module.get_bin_path = get_bin_path
    if not hasattr(module, 'run_command'):
        from ansible.module_utils.facts.collector.freebsd import run_command
        module.run_command = run_command

    # Note: the following test is not complete, as it doesn't test cpu facts in case 'sysctl' is not available.
    # The complete test should also be updated when this class is changed.

# Generated at 2022-06-22 23:13:06.580064
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = FreeBSDHardware(module)

    hardware.populate()

    dmi_facts_rezult = hardware.get_dmi_facts()
    assert dmi_facts_rezult

    mount_facts_rezult = hardware.module.exit_json(hardware_facts=hardware.populate())
    assert mount_facts_rezult

    device_facts_rezult = hardware.get_device_facts()
    assert device_facts_rezult

    memory_facts_rezult = hardware.get_memory_facts()
    assert memory_facts_rezult

    cpu_facts_rezult = hardware.get_cpu_facts()
    assert cpu_facts_rezult

    uptime_facts_rezult = hardware.get_uptime_facts()
    assert uptime_facts_

# Generated at 2022-06-22 23:13:17.215768
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import Collector
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector

    # Copy the real module and run it in the background.
    # This way we can mock the imports inside it and still
    # use the real FreeBSDHardware class without duplicating any code.
    import shutil
    from tempfile import mkdtemp
    import os
    import sys
    import glob
    import imp

    test_dir = mkdtemp()
    src_dir = os.path.dirname(os.path.realpath(__file__))
    shutil.copytree(src_dir, test_dir)
    sys.path.append(test_dir)

# Generated at 2022-06-22 23:13:29.424915
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeModule()
    freebsdHardware = FreeBSDHardware(module)

    # Test with empty output from sysctl
    rc, out, err = module.run_command.return_value
    rc = 1
    out = ''
    err = ''

    memory_facts = freebsdHardware.get_memory_facts()
    assert memory_facts == {}

    # Test with output from sysctl:
    rc = 0
    out = '''
vm.stats.vm.v_page_size: 4194304
vm.stats.vm.v_page_count: 2058706
vm.stats.vm.v_free_count: 557372
'''
    err = ''

    memory_facts = freebsdHardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_

# Generated at 2022-06-22 23:13:37.657772
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Prepare the mock module
    module = MockModule()
    # Import the required python module
    try:
        from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    except ImportError:
        print('Could not import the required python module')
        return
    # Instantiate the tested class
    freebsd_hardware = FreeBSDHardware(module=module)
    # Run the tested method
    dmi_facts = freebsd_hardware.get_dmi_facts()
    # Check the result
    assert dmi_facts['chassis_vendor'] == 'Some Name'


# The mock module

# Generated at 2022-06-22 23:13:46.468442
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = DummyAnsibleModule(
        argument_spec=dict(),
    )
    hardware = FreeBSDHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert device_facts['devices'] is not None

    for device in device_facts['devices']:
        assert device_facts['devices'][device] is not None
        for slice_ in device_facts['devices'][device]:
            assert slice_.startswith(device)



# Generated at 2022-06-22 23:13:47.973033
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_freebsd = FreeBSDHardwareCollector()
    assert hw_freebsd._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:14:01.417684
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = FakeAnsibleModule()
    freebsd_hw = FreeBSDHardware(module=module)
    freebsd_hw.populate()
    assert freebsd_hw.facts['memtotal_mb'] >= 0
    assert freebsd_hw.facts['memfree_mb'] >= 0
    assert freebsd_hw.facts['processor'][0] == 'AMD Opteron(tm) Processor 6128'
    assert freebsd_hw.facts['processor_cores'] == '2'
    assert freebsd_hw.facts['processor'][1] == 'AMD Opteron(tm) Processor 6128'
    assert freebsd_hw.facts['processor_cores'] == '2'
    assert freebsd_hw.facts['processor_count'] == 2

# Generated at 2022-06-22 23:14:13.810069
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    class FakeModule(object):
        def __init__(self):
            self.run_command_counter = 0

        def get_bin_path(self, name, *args):
            return '/usr/bin/' + name

        def run_command(self, args, encoding=None):
            if self.run_command_counter == 0:
                self.run_command_counter += 1
                return (0, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', '')
            if self.run_command_counter == 1:
                self.run_command_counter += 1