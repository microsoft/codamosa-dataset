

# Generated at 2022-06-22 23:04:25.718171
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:04:36.218967
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import hardware
    module = hardware.Hardware()

    # Set defaults for testing
    module.run_command = lambda *args, **kwargs: ('', '', '')
    module.get_bin_path = lambda *args, **kwargs: '/bin/false'

    def set_module_run_command(rc, out, err):
        def run_command(self, *args, **kwargs):
            return (rc, out, err)

        module.run_command = run_command

    # Test the cpu facts
    set_module_run_command(0, '2', '')  # Set the processor_count
    h = FreeBSDHardware()
    facts = h.populate()
    assert facts['processor_count'] == 2
    assert facts['processor'] == []

# Generated at 2022-06-22 23:04:43.369938
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.utils import mock_uname_info


# Generated at 2022-06-22 23:04:53.052194
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestModule(object):
        def __init__(self):
            self.fail_json = lambda **kargs: None

        def get_bin_path(self, arg, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            return (0, 'hw.ncpu: 4', '')

    class TestClass(object):
        def __init__(self):
            self.module = TestModule()

    hardware = TestClass()

    res = hardware.get_cpu_facts()

    assert res is not None
    assert 'processor_count' in res
    assert res['processor_count'] == '4'



# Generated at 2022-06-22 23:04:54.655030
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhwc = FreeBSDHardwareCollector()
    assert fhwc is not None

# Generated at 2022-06-22 23:05:05.224464
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    hardware_instance = FreeBSDHardwareCollector.collect(test_module, list())

# Generated at 2022-06-22 23:05:16.572861
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.processor.freebsd import Processor  # noqa
    from ansible.module_utils.facts.processor.freebsd import ProcessorCollector  # noqa
    from ansible.module_utils import basic
    import collections
    import sys

    # We need to run this under something resembling Linux,
    # so we will just patch the platform module.
    sysinfo = {'distribution': 'FreeBSD', 'distribution_version': '10.1'}
    sys.modules['platform'] = collections.namedtuple('platform', sysinfo.keys())(*sysinfo.values())

    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-22 23:05:28.764952
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:05:35.816488
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.write("kern.boottime: { sec = %s, usec = %s }\n" % (
        int(time.time() - 42), 0))
    tmpfile.flush()

    hardware = FreeBSDHardware({}, tmpfile.name)
    return hardware.get_uptime_facts() == {'uptime_seconds': 42}


# Generated at 2022-06-22 23:05:45.663540
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    sysctl = '/usr/sbin/sysctl'
    memtotal_mb = 4096
    memfree_mb = 2047
    memtotal_kb = memtotal_mb * 1024
    memfree_kb = memfree_mb * 1024
    raw_output = '''vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: %d
vm.stats.vm.v_free_count: %d
''' % (memtotal_kb, memfree_kb)
    sysctl_command = '%s vm.stats' % sysctl
    mem_facts = {'memtotal_mb': memtotal_mb,
                 'memfree_mb': memfree_mb,
                 'swaptotal_mb': 0,
                 'swapfree_mb': 0,
                }

# Generated at 2022-06-22 23:05:51.265757
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    config_file = "ansible.cfg"
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    rh = FreeBSDHardware(config_file)
    rh.populate()
    cpu_facts = rh.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-22 23:06:02.243781
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class MockModule():
        def __init__(self):
            self.name = 'FreeBSDHardware'
            self.PATH = os.getenv('PATH') if os.getenv('PATH') is not None else '/usr/bin:/bin'

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/bin/dmidecode'


# Generated at 2022-06-22 23:06:15.144890
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' freebsd_module.py: FreeBSDHardware.get_dmi_facts()

    This is more of integration test as it mocks the run_command() method
    of AnsibleModule class.

    Initialize a FreeBSDHardware class with a mocked
    AnsibleModule class. Then test if the dmi facts
    returned by get_dmi_facts are as expected.
    '''

    from ansible.module_utils.facts import ModuleDummy
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Initialize a module object with a mocked AnsibleModule class
    module = ModuleDummy.ModuleDummy()
    module.run_command = lambda x: ("", DMI_OUT, "")

    # Initialize a FreeBSDHardware object
    fhw = FreeBSDHardware(module)

    # Test if dmi

# Generated at 2022-06-22 23:06:26.008171
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test a case with valid dmidecode
    # Dummy class to simulate a module
    class DummyModule:
        def get_bin_path(self, x):
            return 'dmidecode'

        def run_command(self, cmd):
            return (0, '# dmidecode 3.0\nHandle 0x0010, DMI type 16, 23 bytes\nPhysical Memory Array\n\tLocation: System Board Or Motherboard\n\tUse: System Memory\n\tError Correction Type: Multi-bit ECC\n\tMaximum Capacity: 32 GB\n\tError Information Handle: Not Provided\n\tNumber Of Devices: 4\n')

    fhw = FreeBSDHardware()
    fhw.module = DummyModule()
    dmi_facts = fhw.get_dmi_facts()

# Generated at 2022-06-22 23:06:29.105478
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware({'gather_subset': '!all'})
    hardware = FreeBSDHardware({'gather_subset': 'all'})

# Generated at 2022-06-22 23:06:34.606983
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    results = {'devices': {'da0': ['da0s1'], 'da1': ['da1s1']}}
    fh = FreeBSDHardware()
    assert fh.get_device_facts() == results


# Generated at 2022-06-22 23:06:44.742724
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_object = FreeBSDHardware()
    result = test_object.get_cpu_facts()
    assert len(result['processor']) == 1
    assert result['processor_cores'] == '2'
    result = test_object.get_device_facts()
    assert len(result['devices']['ada0']) == 8
    result = test_object.get_dmi_facts()
    assert result['bios_version'] == '1.16'
    result = test_object.get_mount_facts()
    result = test_object.get_memory_facts()
    assert result['memtotal_mb'] == 16384
    assert result['memfree_mb'] == 15352
    assert result['swaptotal_mb'] == 0
    assert result['swapfree_mb'] == 0

# Generated at 2022-06-22 23:06:50.423542
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    obj = FreeBSDHardwareCollector()
    assert repr(obj) == '<ansible.module_utils.facts.hardware.freebsd.FreeBSDHardwareCollector(ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware)>'
    assert obj._platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDHardware

# Generated at 2022-06-22 23:07:02.810423
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """ Unit test for method get_device_facts of class FreeBSDHardware """

    test_facts = {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1e', 'ada0s1f', 'ada0s1d', 'ada0s1g'],
                              'ada1': ['ada1s1h', 'ada1s1d'], 'ada2': ['ada2s1g', 'ada2s2a'], 'ada3': ['ada3s1a'],
                              'ada4': ['ada4s1b', 'ada4s1d'], 'ada5': ['ada5s1a', 'ada5s1b']}}

    sysctl = '/sbin/sysctl'
    sysctl_rc, sysctl_out, sysctl_err = 0,

# Generated at 2022-06-22 23:07:10.455398
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''Test FreeBSDHardware.get_dmi_facts()'''
    # Create a FreeBSDHardware instance to run tests against
    test_hardware = FreeBSDHardware()
    assert isinstance(test_hardware, FreeBSDHardware)
    # Create a dictionary containing output of dmidecode

# Generated at 2022-06-22 23:07:22.237743
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class DummyModule(object):
        def __init__(self, cmd):
            self.run_command_rc = 0
            self.run_command_out = struct.pack('<Q', int(time.time()) - 120)

        def run_command(self, cmd, encoding=None):
            return (self.run_command_rc, self.run_command_out, '')

    class DummyHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    mod = DummyModule(None)
    hw = DummyHardware(mod)

    assert hw.get_uptime_facts() == {
        'uptime_seconds': 120,
    }

    mod.run_command_rc = 1
    assert hw.get_uptime_facts() == {}

# Generated at 2022-06-22 23:07:23.287237
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware()

    assert hardware is not None

# Generated at 2022-06-22 23:07:32.767443
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # This test only works when run as root.
    # It is not meant to be part of the test suite.
    # Instead, it is meant to be run manually to test the
    # returned results.
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '{\n    "boottime": 1528507469\n}', ''))
    freebsdhw = FreeBSDHardware()
    now = int(time.time())
    uptime_expected = now - 1528507469
    uptime_facts = freebsdhw.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': uptime_expected}

# Generated at 2022-06-22 23:07:44.205042
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware()
    hardware.module.run_command = lambda *args, **kwargs: (0, '', '')
    hardware.module.get_bin_path = lambda *args, **kwargs: '/dev'
    hardware.module.params = {}
    hardware.module.params['gather_timeout'] = 10
    hardware.module.params['filter'] = '*'
    hardware.module.exit_json = lambda *args, **kwargs: None
    hardware.module.fail_json = lambda *args, **kwargs: None
    hardware.module.params['gather_subset'] = []
    hardware.module.params['filter'] = ''
    hardware.module.params['gather_timeout'] = 10

# Generated at 2022-06-22 23:07:55.809675
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import sys
    import os
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    module = sys.modules['ansible.module_utils.facts.hardware.freebsd']
    module.os = sys.modules['ansible.module_utils.facts.hardware.freebsd']
    module.os.path = sys.modules['ansible.module_utils.facts.hardware.freebsd.path']
    module.os.path.isdir = os.path.isdir

    module.open = os.open
    module.os.listdir = os.listdir

    def mock_run_command(command, check_rc=True, encoding=None):
        return 0, '', ''

    module.run_command = mock_run_command

    module.os.listdir = os

# Generated at 2022-06-22 23:08:00.180984
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    hardware = FreeBSDHardware(module)

    assert hardware.get_memory_facts() == {
        'memtotal_mb': 15261,
        'memfree_mb': 12374,
        'swaptotal_mb': 1527,
        'swapfree_mb': 1527
    }

# Generated at 2022-06-22 23:08:13.255141
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware


# Generated at 2022-06-22 23:08:18.422787
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/sbin/sysctl'
    fbsd_hw = FreeBSDHardware(module=module)
    result = fbsd_hw.get_memory_facts()
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result


# Generated at 2022-06-22 23:08:22.014149
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    freebsd_hardware = FreeBSDHardware(dict())
    assert freebsd_hardware.platform == 'FreeBSD'
    assert freebsd_hardware.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-22 23:08:29.289341
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, b'\x00\x00\x13@\x00\x00\x00\x00', ''))
    # test normal
    facts = FreeBSDHardware().get_uptime_facts()
    assert facts['uptime_seconds'] == 1

    # test rc != 0
    module.run_command.side_effect = [(1, '', '')]
    facts = FreeBSDHardware().get_uptime_facts()
    assert facts == {}

    # test out size < struct size
    module.run_command.side_effect = [(0, '', '')]
    facts = FreeBSDHardware().get_uptime_facts()
    assert facts == {}

    # test out size = struct size
    module.run_command.side_effect

# Generated at 2022-06-22 23:08:41.862551
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = run_command_mock
    test_module.get_bin_path = get_bin_path_mock
    test_module.params = {}

# Generated at 2022-06-22 23:08:45.497442
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Test that FreeBSDHardwareCollector class is valid
    """
    # Test class exists
    cls = HardwareCollector.get_platform_collector('FreeBSD')
    assert cls == FreeBSDHardwareCollector

# Generated at 2022-06-22 23:08:52.762255
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    hardware_facts = hardware.FreeBSDHardware(module)
    uptime_facts = hardware_facts.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts
    assert int(uptime_facts['uptime_seconds']) >= 0

# Generated at 2022-06-22 23:09:05.967346
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_data = dict(
        freecount="0",
        pagecount="0",
        pagesize="0",
    )
    sysctl = dict(
        stdout="vm.stats.vm.v_page_count: %(pagecount)s\n"
               "vm.stats.vm.v_free_count: %(freecount)s\n"
               "vm.stats.vm.v_page_size: %(pagesize)s\n"
               % mem_data,
        stderr="",
        rc=0,
    )

# Generated at 2022-06-22 23:09:11.504716
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

        def get_memory_facts(self):
            return super(MockFreeBSDHardware, self).get_memory_facts()

    ah = MockFreeBSDHardware(module)
    ah.get_memory_facts()


# Generated at 2022-06-22 23:09:23.567228
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import os
    import shutil
    import tempfile

# Generated at 2022-06-22 23:09:25.571327
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware(dict())
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-22 23:09:35.443296
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''
       Test method get_device_facts of class FreeBSDHardware
    '''
    module = FakeModule()
    # FreeBSDHardware instance to be tested
    freebsdhardware_test = FreeBSDHardware(module)

    # Test cases where sysdir is not valid
    sysdir = None
    if os.path.isdir(sysdir):
        dirlist = sorted(os.listdir(sysdir))
        for device in dirlist:
            d = drives.match(device)
            if d:
                device_facts['devices'][d.group(1)] = []
            s = slices.match(device)
            if s:
                device_facts['devices'][d.group(1)].append(s.group(1))
    # Test for inputs where sysdir is valid
    sysdir = '/dev'

# Generated at 2022-06-22 23:09:36.149186
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    pass

# Generated at 2022-06-22 23:09:45.133122
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModuleMock({})
    hardware = FreeBSDHardware(module)

# Generated at 2022-06-22 23:09:53.841534
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsd_hw_cls = FreeBSDHardware()
    freebsd_hw_cls.module = DummyAnsibleModule()
    freebsd_hw_cls.module.run_command = MagicMock(return_value=(0, '', ''))

    result = freebsd_hw_cls.get_memory_facts()

    assert result['memtotal_mb'] == 0
    assert result['memfree_mb'] == 0


# Class for mock up AnsibleModule

# Generated at 2022-06-22 23:09:58.959003
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    freebsd = FreeBSDHardware(module)

    assert freebsd.get_uptime_facts() == {
            'uptime_seconds': int(time.time() - os.stat(FreeBSDHardware.DMESG_BOOT).st_mtime)
    }

# Generated at 2022-06-22 23:10:04.019405
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.ARM

    assert fhc.ARM is not None
    assert fhc.ARM_V7
    assert fhc.ARM_V8
    assert fhc.X86
    assert fhc.X64
    assert fhc.PPC
    assert fhc.PPC64

# Generated at 2022-06-22 23:10:13.489370
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.params['gather_subset'] = ['min']

    freebsd_hardware = FreeBSDHardware(module)
    memory_facts = freebsd_hardware.get_memory_facts()

    memtotal_mb = memory_facts['memtotal_mb']
    assert memtotal_mb

    memfree_mb = memory_facts['memfree_mb']
    assert memfree_mb

    swaptotal_mb = memory_facts['swaptotal_mb']
    assert swaptotal_mb

    swapfree_mb = memory_facts['swapfree_mb']
    assert swapfree_mb

    return True

# Generated at 2022-06-22 23:10:19.950329
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import facts
    from collections import namedtuple
    module = namedtuple("AnsibleModule", "params")(params=facts.AnsibleFacts(facts_data={}))
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert 'memfree_mb' in hardware_facts
    assert hardware_facts['memfree_mb'] > 0
    assert 'processor_count' in hardware_facts
    assert int(hardware_facts['processor_count']) > 0
    assert 'uptime_seconds' in hardware_facts
    assert hardware_facts['uptime_seconds'] > 0
    assert 'mounts' in hardware_facts
    assert hardware_facts['mounts']

# Generated at 2022-06-22 23:10:29.630604
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import mock
    import sys

    # Initialisation of the class FreeBSDHardware
    test_module = mock.Mock()
    test_module.get_bin_path.return_value = '/bin'
    test_module.run_command.return_value = (0, '', '')
    test_module.params = {}
    test_class = FreeBSDHardware(module=test_module)
    # Call of the method get_device_facts of the class FreeBSDHardware
    device_facts = test_class.get_device_facts()
    assert device_facts['devices']['ada0'] == ['ada0s1', 'ada0s1a', 'ada0s1b', 'ada0s2', 'ada0s3']


# Generated at 2022-06-22 23:10:31.863500
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hwcollector = FreeBSDHardwareCollector()
    assert isinstance(hwcollector, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:10:36.821934
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Prepare test fixture with class instance
    fhw = FreeBSDHardware()
    # Test function
    output = fhw.get_uptime_facts()
    assert 'uptime_seconds' in output
    assert isinstance(output['uptime_seconds'], int)
    assert output['uptime_seconds'] > 0

# Generated at 2022-06-22 23:10:46.202582
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector.freebsd.utils import get_file_content

    # Part of the dmidecode output with reduced number of lines

# Generated at 2022-06-22 23:10:49.835685
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    fb = FreeBSDHardware(module)

    fb.get_device_facts = fb.get_device_facts()
    assert (fb.facts['devices'] == dict)



# Generated at 2022-06-22 23:10:55.309675
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # kern.boottime is encoded in binary.
    # Test values come from a local FreeBSD system.
    # They may need to be adjusted if platform defaults change.
    current_time = 1521336375
    boot_time = 1521172120
    class FakeModule:
        @staticmethod
        def get_bin_path(name):
            return name

    class FakeRC:
        def __init__(self, rc):
            self.rc = rc

        def communicate(self):
            out = struct.pack('@L', boot_time)
            return out, None

        def wait(self):
            return self.rc

    class FakePopen:
        def __init__(self, rc):
            self.rc = FakeRC(rc)


# Generated at 2022-06-22 23:10:59.118628
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Test for FreeBSDHardware class
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(type='list'), filter=dict(required=False)))
    result = FreeBSDHardware(module)
    assert result is not None

# Generated at 2022-06-22 23:11:06.685029
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec={},
                                supports_check_mode=False)
    test_freebsd_hardware = FreeBSDHardware(module=test_module)
    result = test_freebsd_hardware.get_dmi_facts()
    test_module.exit_json(ansible_facts=result)


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 23:11:18.221888
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError, timeout
    import shutil

    @timeout()
    def fake_get_mount_facts():
        return None


# Generated at 2022-06-22 23:11:28.128569
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleStub():
        def get_bin_path(self, name):
            if name == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        def run_command(self, command, encoding=None):
            return 0, bytes('kern.boottime = { sec = 1594174983, usec = 984228 }', 'UTF-8'), ''

    class HardwareStub(FreeBSDHardware):
        def __init__(self):
            self.module = ModuleStub()

    hardware = HardwareStub()
    assert hardware.get_uptime_facts() == {'uptime_seconds': 1594174983}

# Generated at 2022-06-22 23:11:38.487168
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = None

# Generated at 2022-06-22 23:11:42.325163
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    facts = FreeBSDHardware()

# Generated at 2022-06-22 23:11:53.671577
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Test FreeBSDHardware.populate()."""
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    hardware = FreeBSDHardware(mock_module)
    hardware.populate()
    assert set(hardware.facts.keys()) == set(['devices', 'mounts', 'processor', 'processor_count', 'memtotal_mb', 'uptime_seconds',
                                               'processor_cores', 'memfree_mb', 'swaptotal_mb', 'swapfree_mb', 'dmi', 'vendor_facts'])
    assert hardware.facts['processor_count'] == '4'
    assert hardware.facts['memtotal_mb'] == '3909'
    assert hardware.facts['memfree_mb'] == '980'

# Generated at 2022-06-22 23:11:57.590529
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    HardwareCollector.register_collector(FreeBSDHardwareCollector)
    hardware_collector = HardwareCollector.factory()
    assert isinstance(hardware_collector, FreeBSDHardwareCollector)

# Generated at 2022-06-22 23:12:07.067955
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    FreeBSDHardware unit test for method get_device_facts
    """
    # Mock the module class to avoid the exit_json call
    mock_module = type('AnsibleModule', (object,), {
        'exit_json': lambda self, **kwargs: None
    })()

    # Create an instance of FreeBSDHardware class
    freebsd_hw_collector = FreeBSDHardwareCollector(mock_module)

    # Test output of method get_device_facts
    assert freebsd_hw_collector.get_device_facts() == {
        'devices': {
            'ada0': ['ada0s1a'],
            'da0': ['da0s1a']
        }
    }

# Generated at 2022-06-22 23:12:15.765389
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    current_system = Hardware()
    memory_facts = FreeBSDHardware().get_memory_facts()

    assert 'memtotal_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts

    assert memory_facts['memtotal_mb'] == current_system.memtotal_mb
    assert memory_facts['swaptotal_mb'] == current_system.swaptotal_mb
    assert memory_facts['swapfree_mb'] == current_system.swapfree_mb

# Generated at 2022-06-22 23:12:26.122443
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Initialise class FreeBSDHardware
    freebsdhw = FreeBSDHardware(None)
    # Initialise data

# Generated at 2022-06-22 23:12:35.195220
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    mod = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hw_facts = FreeBSDHardware(module=mod)
    dmifacs = hw_facts.get_dmi_facts()
    if 'bios_date' in dmifacs.keys():
        assert len(dmifacs['bios_date']) == 4
    if 'board_version' in dmifacs.keys():
        assert len(dmifacs['board_version']) == 4


# Generated at 2022-06-22 23:12:43.985313
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create an object of class FreeBSDHardware
    freebsdhw = FreeBSDHardware(module=None)


# Generated at 2022-06-22 23:12:53.939670
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_mem_facts = {
        'processor': ['Intel(R) Xeon(R) CPU E5530  @ 2.40GHz'],
        'processor_cores': '2',
        'processor_count': '1',
        'devices': {},
        'memtotal_mb': 30434,
        'memfree_mb': 8258,
        'swaptotal_mb': 8191,
        'swapfree_mb': 8191}

    hardware = FreeBSDHardware({})
    hardware_facts = hardware.get_memory_facts()

    assert test_mem_facts == hardware_facts

# Generated at 2022-06-22 23:12:59.916460
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fake_module = object
    fake_module.run_command = lambda *args, **kwargs: (0, '/dev/ada0', '')
    freebsd_hardware = FreeBSDHardware(fake_module)
    device_facts = freebsd_hardware.get_device_facts()
    assert device_facts['devices'] == {'ada0': []}
    assert device_facts.get('devices', {}).get('sda0') is None

# Generated at 2022-06-22 23:13:11.409449
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    def mock_module_run_command(cmd, encoding=None):
        ''' Returns fixed output for sysctl -b kern.boottime '''
        return (0, b'1488808375', b'')

    test_args = {}

    testobj = FreeBSDHardware(module=None, **test_args)
    testobj.module.run_command = mock_module_run_command
    testobj.uptime_seconds = testobj.get_uptime_facts()

    assert(testobj.uptime_seconds == int(time.time() - 1488808375))

# Generated at 2022-06-22 23:13:19.542731
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_FreeBSDHardware = FreeBSDHardware()
    test_FreeBSDHardware.module = MockModule()

# Generated at 2022-06-22 23:13:30.581140
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import timeout

    m = basic.AnsibleModule(
        argument_spec = dict(
            gather_timeout = dict(type='int', default=10),
        )
    )

    test_object = FreeBSDHardware(m)

    assert test_object.get_uptime_facts() == {
        'uptime_seconds': int(time.time() - 1470109042),
    }

    m.params['gather_timeout'] = 0.1
    test_object = FreeBSDHardware(m)

    with pytest.raises(timeout.TimeoutError):
        test_object.get_mount_facts()

# Generated at 2022-06-22 23:13:39.541909
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-22 23:13:48.836173
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = FreeBSDHardware(module).populate()
    # The values below are platform specific. Only perform a sanity test.
    assert 'memtotal_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'uptime_seconds' in facts
    assert 'devices' in facts
    assert 'mounts' in facts

    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor' in facts

    for k in facts.keys():
        assert 'dmi' not in k

# Generated at 2022-06-22 23:13:55.698159
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec=dict())
    hw = FreeBSDHardware(module)
    facts = hw.populate()
    assert type(facts) == dict
    assert type(facts['processor']) == list
    assert type(facts['memfree_mb']) == int
    assert type(facts['memtotal_mb']) == int
    assert type(facts['swapfree_mb']) == int
    assert type(facts['swaptotal_mb']) == int
    assert type(facts['uptime_seconds']) == int
    assert type(facts['devices']) == dict
    assert type(facts['board_vendor']) == str


# Generated at 2022-06-22 23:13:58.978094
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    freebsd_hw = FreeBSDHardware(module=module)
    device_facts = freebsd_hw.get_device_facts()
    assert 'devices' in device_facts


# Generated at 2022-06-22 23:14:03.377254
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardwareCollector
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    assert FreeBSDHardwareCollector._platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware



# Generated at 2022-06-22 23:14:15.953568
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    bsd_hardware = FreeBSDHardware()
    # Define a DMI dictionary and values