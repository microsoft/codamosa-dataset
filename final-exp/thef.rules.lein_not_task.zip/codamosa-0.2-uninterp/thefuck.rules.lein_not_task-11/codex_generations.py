

# Generated at 2022-06-18 08:22:56.421452
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all\n  run-all-tests'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all\n  run-all-tests\n  run-all-tests-parallel'))

# Generated at 2022-06-18 08:23:00.558455
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev', error=1))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev', error=1))


# Generated at 2022-06-18 08:23:11.486411
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all\nrun-all-tests'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all\nrun-all-tests\nrun-all-tests-in-ns'))

# Generated at 2022-06-18 08:23:21.815512
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', 1))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', 0))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', 123))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', -1))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', -123))

# Generated at 2022-06-18 08:23:27.848728
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')) == 'lein run-tests'

    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')) == 'sudo lein run-tests'

# Generated at 2022-06-18 08:23:30.709454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
''')) == 'lein test'

# Generated at 2022-06-18 08:23:34.076784
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:23:37.797872
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('lein run',
                                   '"run" is not a task. See "lein help".\nDid you mean this?\n         run-',
                                   '')) == 'lein run- '

# Generated at 2022-06-18 08:23:41.045863
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   '"run" is not a task. See "lein help".\nDid you mean this?\n  run-dev\n  run-prod\n')) == 'lein run-dev'

# Generated at 2022-06-18 08:23:45.301041
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))


# Generated at 2022-06-18 08:23:53.850718
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:24:03.575770
# Unit test for function get_new_command

# Generated at 2022-06-18 08:24:10.238351
# Unit test for function get_new_command

# Generated at 2022-06-18 08:24:20.364250
# Unit test for function match

# Generated at 2022-06-18 08:24:28.297012
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))


# Generated at 2022-06-18 08:24:31.493595
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')
    assert get_new_command(command) == 'lein repl'

# Generated at 2022-06-18 08:24:41.043075
# Unit test for function match

# Generated at 2022-06-18 08:24:49.298115
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein foo', 'lein: foo is not a task. See \'lein help\'', 'Did you mean this?\n\n\tfoo\n'))
    assert not match(Command('lein', 'lein foo', 'lein: foo is not a task. See \'lein help\'', 'Did you mean this?\n\n\tfoo\n', 'Did you mean this?\n\n\tfoo\n'))
    assert not match(Command('lein', 'lein foo', 'lein: foo is not a task. See \'lein help\'', 'Did you mean this?\n\n\tfoo\n', 'Did you mean this?\n\n\tfoo\n'))


# Generated at 2022-06-18 08:24:52.697082
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', '', ''))
    assert not match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:25:03.813629
# Unit test for function get_new_command

# Generated at 2022-06-18 08:25:09.446352
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
lein run
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:25:12.752726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
         repl
''')) == 'lein run-\nlein repl'

# Generated at 2022-06-18 08:25:17.251398
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))


# Generated at 2022-06-18 08:25:28.054566
# Unit test for function get_new_command

# Generated at 2022-06-18 08:25:36.620679
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\n'))

# Generated at 2022-06-18 08:25:39.131083
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')) == 'lein run-tests'

# Generated at 2022-06-18 08:25:48.170855
# Unit test for function match
def test_match():
    assert match(Command('lein',
                         'lein test\n'
                         '"test" is not a task. See \'lein help\'.\n'
                         'Did you mean this?\n'
                         '         test-refresh\n'))
    assert not match(Command('lein',
                             'lein test\n'
                             '"test" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein',
                             'lein test\n'
                             '"test" is not a task. See \'lein help\'.\n'
                             'Did you mean this?\n'
                             '         test-refresh\n'
                             '         test-refresh\n'))

# Generated at 2022-06-18 08:25:56.822004
# Unit test for function match

# Generated at 2022-06-18 08:26:00.855870
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))


# Generated at 2022-06-18 08:26:03.209342
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:26:08.312207
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:26:16.763935
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-test'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-test\n\trun-test-all'))

# Generated at 2022-06-18 08:26:24.981767
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev\n\trun-prod'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev\n\trun-prod\n\trun-test'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev\n\trun-prod\n\trun-test\n\trun-test-all'))

# Generated at 2022-06-18 08:26:27.895945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   '"test" is not a task. See \'lein help\'.\nDid you mean this?\n         test-refresh')) == 'lein test-refresh'

# Generated at 2022-06-18 08:26:30.227918
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
Could not find task 'run'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:26:39.330865
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun\nrun'))
    assert not match

# Generated at 2022-06-18 08:26:43.254189
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein test',
                                   ''''test' is not a task. See 'lein help'.
Did you mean this?
         test
         test-refresh''')) == 'lein test'

# Generated at 2022-06-18 08:26:53.543368
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun\nrun'))
    assert not match

# Generated at 2022-06-18 08:27:02.548087
# Unit test for function get_new_command

# Generated at 2022-06-18 08:27:07.393065
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   '"run" is not a task. See "lein help".\nDid you mean this?\nrun')) == 'lein run'
    assert get_new_command(Command('lein run',
                                   '"run" is not a task. See "lein help".\nDid you mean this?\nrun\nrun-tests')) == 'lein run-tests'

# Generated at 2022-06-18 08:27:12.503044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   '"test" is not a task. See "lein help".\nDid you mean this?\n  test-refresh')) == 'lein test-refresh'

# Generated at 2022-06-18 08:27:19.864789
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun', 'lein run'))


# Generated at 2022-06-18 08:27:23.972026
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:27:31.828722
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:27:41.239512
# Unit test for function get_new_command

# Generated at 2022-06-18 08:27:45.237838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '  run-main\n'
                                   'Run `lein help` for detailed information.')) == 'lein run-main'

# Generated at 2022-06-18 08:27:48.055729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:27:57.396421
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tfoo'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tfoo\n\tbar'))

# Generated at 2022-06-18 08:28:06.429120
# Unit test for function match
def test_match():
    assert match(Command('lein test',
                         ''''test' is not a task. See 'lein help'.
Did you mean this?
         test-refresh'''))
    assert not match(Command('lein test',
                             ''''test' is not a task. See 'lein help'.
Did you mean this?
         test-refresh''',
                             stderr='error'))
    assert not match(Command('lein test',
                             ''''test' is not a task. See 'lein help'.
Did you mean this?
         test-refresh''',
                             stderr='error'))

# Generated at 2022-06-18 08:28:12.424668
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '\trun-dev\n'
                                   '\trun-prod\n'
                                   '\trun-test\n'
                                   'Run `lein help` for a list of available tasks.')) == 'lein run-dev'

# Generated at 2022-06-18 08:28:17.979154
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:28:20.795395
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:28:30.582729
# Unit test for function match
def test_match():
    assert match(Command('lein run',
                         'Could not find task or namespaced task run.\n'
                         'Did you mean this?\n'
                         '\trun-dev\n'
                         '\trun-prod\n'
                         'Run `lein help` for detailed information'))
    assert not match(Command('lein run',
                             'Could not find task or namespaced task run.\n'
                             'Run `lein help` for detailed information'))

# Generated at 2022-06-18 08:28:33.168676
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:28:42.168009
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru\n\tr'))

# Generated at 2022-06-18 08:28:45.414081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:28:55.283230
# Unit test for function get_new_command

# Generated at 2022-06-18 08:28:58.379631
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:29:02.645842
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'test is not a task. See \'lein help\'', ''))
    assert match(Command('lein test', 'test is not a task. See \'lein help\'', ''))
    assert not match(Command('lein test', 'test is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:29:09.806163
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'.'))
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'.',
                         'Did you mean this?'))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'.',
                             'Did you mean this?', 'bar'))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'.',
                             'Did you mean this?', 'bar', 'baz'))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'.',
                             'Did you mean this?', 'bar', 'baz', 'qux'))

# Generated at 2022-06-18 08:29:16.925691
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:29:26.852488
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:29:36.254741
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command

# Generated at 2022-06-18 08:29:39.516210
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   '''
                                   'test' is not a task. See 'lein help'.
                                   Did you mean this?
                                   test-refresh
                                   ''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:29:45.068910
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein:run is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:29:54.674447
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test\n  test2'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test\n  test2\n  test3'))

# Generated at 2022-06-18 08:29:57.821519
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:30:01.746984
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: not a task. See \'lein help\'.'))


# Generated at 2022-06-18 08:30:07.550863
# Unit test for function match
def test_match():
    assert match(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
'''))
    assert not match(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
'''))
    assert not match(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
         test
'''))


# Generated at 2022-06-18 08:30:13.594912
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See "lein help".\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See "lein help".'))
    assert not match(Command('lein run', 'lein run: is not a task. See "lein help".\nDid you mean this?\n\trun', 'lein run: is not a task. See "lein help".\nDid you mean this?\n\trun'))


# Generated at 2022-06-18 08:30:33.766643
# Unit test for function match

# Generated at 2022-06-18 08:30:40.005250
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n'))


# Generated at 2022-06-18 08:30:42.597130
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein foo', '''
'foo' is not a task. See 'lein help'.
Did you mean this?
         foo
''')) == 'lein foo'

# Generated at 2022-06-18 08:30:46.236754
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaced task '
                                   'run.\nDid you mean this?\n  run-dev',
                                   '')) == 'lein run-dev'

# Generated at 2022-06-18 08:30:48.874788
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.

Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:30:52.084761
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:30:55.228040
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')) == 'lein run-tests'

# Generated at 2022-06-18 08:31:01.313444
# Unit test for function match
def test_match():
    assert match(Command('lein help', 'lein help is not a task. See \'lein help\'.\nDid you mean this?\n  help\n'))
    assert not match(Command('lein help', 'lein help is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein help', 'lein help is not a task. See \'lein help\'.\nDid you mean this?\n  help\n', 'lein help is not a task. See \'lein help\'.\nDid you mean this?\n  help\n'))


# Generated at 2022-06-18 08:31:07.858851
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein: command not found'))
    assert match(Command('lein run', 'lein: \'run\' is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n  run'))
    assert not match(Command('lein run', 'lein: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n  run\n  run-all'))
    assert not match(Command('lein run', 'lein: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n  run\n  run-all\n  run-all-tests'))

# Generated at 2022-06-18 08:31:11.016538
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('lein deps',
                                   '''Could not find task 'deps' in project.clj.
Did you mean this?
         :deps''',
                                   '')) == 'lein :deps'

# Generated at 2022-06-18 08:31:39.414369
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun\n\trun'))

# Generated at 2022-06-18 08:31:47.699529
# Unit test for function get_new_command

# Generated at 2022-06-18 08:31:53.143514
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n', '', 1))


# Generated at 2022-06-18 08:31:55.301347
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:31:57.437999
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:32:05.764357
# Unit test for function match
def test_match():
    assert match(Command('lein repl',
                         'Could not find task \'repl\'.\nDid you mean this?\n  repl :repl\n',
                         ''))
    assert not match(Command('lein repl',
                             'Could not find task \'repl\'.\nDid you mean this?\n  repl :repl\n',
                             '',
                             'sudo'))
    assert not match(Command('lein repl',
                             'Could not find task \'repl\'.\nDid you mean this?\n  repl :repl\n'))
    assert not match(Command('lein repl',
                             'Could not find task \'repl\'.\nDid you mean this?\n  repl :repl\n',
                             '',
                             'sudo'))

# Generated at 2022-06-18 08:32:14.666649
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:32:17.679164
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:32:27.001004
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-tests'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-tests\n\trun-tests-travis'))

# Generated at 2022-06-18 08:32:37.827846
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))