

# Generated at 2022-06-18 08:22:55.515472
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))

# Generated at 2022-06-18 08:23:01.845523
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:23:13.145776
# Unit test for function match

# Generated at 2022-06-18 08:23:16.169533
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaced task run.\n'
                                   'Did you mean this?\n'
                                   '\trun-dev')) == 'lein run-dev'

# Generated at 2022-06-18 08:23:23.659906
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:23:28.887265
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: "run" is not a task. See "lein help".\nDid you mean this?\n         run-', 'lein run'))
    assert not match(Command('lein run', 'lein run: "run" is not a task. See "lein help".\nDid you mean this?\n         run-', 'lein run'))


# Generated at 2022-06-18 08:23:31.756810
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   ''''test' is not a task. See 'lein help'.
Did you mean this?
         test-refresh''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:23:37.627609
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'lein run'))


# Generated at 2022-06-18 08:23:47.119148
# Unit test for function match

# Generated at 2022-06-18 08:23:57.377055
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test', 'lein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test', 'lein test', 'lein test'))

# Generated at 2022-06-18 08:24:07.483435
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run', 'lein run', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run', 'lein run', 'lein run', 'lein run'))

# Generated at 2022-06-18 08:24:17.163570
# Unit test for function match

# Generated at 2022-06-18 08:24:23.204956
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '  run-dev\n'
                                   '  run-prod\n'
                                   '  run-test\n'
                                   '  run-test-all\n'
                                   '  run-test-refresh')) == 'lein run-dev'

# Generated at 2022-06-18 08:24:25.652565
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', ''''run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:24:31.364391
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run', 'lein:run is not a task. See \'lein help\'.\nDid you mean this?\n         run\n', '')) == 'lein run'
    assert get_new_command(Command('lein run', 'lein:run is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         run-main\n', '')) == 'lein run-main'

# Generated at 2022-06-18 08:24:34.722674
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
    test-refresh
    '''
    command = Command('lein test', output)
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:24:38.388804
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-
        run-dev
        run-prod
    ''')) == 'lein run-dev'

# Generated at 2022-06-18 08:24:47.833050
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run'))
    assert not match(Command('lein run', 'lein run: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         test'))
    assert not match(Command('lein run', 'lein run: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         test\n         test'))
    assert not match(Command('lein run', 'lein run: \'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         test\n         test\n         test'))

# Generated at 2022-06-18 08:24:50.876585
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein foo', '''
    lein foo
    'foo' is not a task. See 'lein help'.
    Did you mean this?
    run
    ''')) == 'lein run'

# Generated at 2022-06-18 08:25:01.738440
# Unit test for function match

# Generated at 2022-06-18 08:25:07.349191
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')
    assert get_new_command(command) == 'lein run-tests'

# Generated at 2022-06-18 08:25:10.362229
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.

Did you mean this?
         test
''')) == 'lein test'

# Generated at 2022-06-18 08:25:13.259479
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein foo', '''
    'foo' is not a task. See 'lein help'.
    Did you mean this?
    run
    ''')) == 'lein run'

# Generated at 2022-06-18 08:25:23.528264
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\nlein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\nlein test\nlein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\nlein test\nlein test\nlein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\nlein test\nlein test\nlein test\nlein test'))

# Generated at 2022-06-18 08:25:26.552669
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:25:35.842237
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\tteat'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\tteat\n\tteat'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\tteat\n\tteat\n\tteat'))

# Generated at 2022-06-18 08:25:44.590952
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    Did you mean one of these?
        jar
        uberjar
    ''')) == 'lein repl'

    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    Did you mean one of these?
        jar
        uberjar
    Did you mean one of these?
        install
        check
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:25:53.749456
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tru\n\tr'))

# Generated at 2022-06-18 08:26:00.253466
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest\n\t\ttest'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest\n\t\ttest\n\t\ttest'))

# Generated at 2022-06-18 08:26:08.595248
# Unit test for function get_new_command

# Generated at 2022-06-18 08:26:19.634020
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:26:27.782452
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun\nrun'))
    assert not match

# Generated at 2022-06-18 08:26:36.799738
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test', 'lein test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.', 'Did you mean this?', 'lein test', 'lein test', 'lein test'))

# Generated at 2022-06-18 08:26:45.187783
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun', 'lein run'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun', 'lein run'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun', 'lein run'))


# Generated at 2022-06-18 08:26:48.117013
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
Could not find task 'run'.
Did you mean this?
  repl
''')) == 'lein repl'

# Generated at 2022-06-18 08:26:51.445722
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein foo', '''
    'foo' is not a task. See 'lein help'.
    Did you mean this?
    run
    ''')
    assert get_new_command(command) == 'lein run'

# Generated at 2022-06-18 08:27:00.841560
# Unit test for function match
def test_match():
    assert match(Command('lein run',
                         '''Could not find task or namespaces 'run'.
Did you mean this?
         run-tests''',
                         ''))
    assert not match(Command('lein run',
                             '''Could not find task or namespaces 'run'.
Did you mean this?
         run-tests''',
                             '',
                             True))
    assert not match(Command('lein run',
                             '''Could not find task or namespaces 'run'.
Did you mean this?
         run-tests''',
                             '',
                             False))
    assert not match(Command('lein run',
                             '''Could not find task or namespaces 'run'.
Did you mean this?
         run-tests''',
                             '',
                             False))

# Generated at 2022-06-18 08:27:10.007004
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:27:19.357413
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tfoo'))
    assert not match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\tfoo\n\tbar'))

# Generated at 2022-06-18 08:27:28.605747
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'Did you mean this?'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'Did you mean this?', 'Did you mean this?'))

# Generated at 2022-06-18 08:27:34.328325
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:27:40.322373
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n'))


# Generated at 2022-06-18 08:27:43.113212
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:27:52.681221
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-dev'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-dev\nrun-prod'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-dev\nrun-prod\nrun-test'))

# Generated at 2022-06-18 08:27:55.898578
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:28:05.106612
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun\nrun'))

# Generated at 2022-06-18 08:28:07.463756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   '"test" is not a task. See \'lein help\'.\nDid you mean this?\n         test',
                                   '')) == 'lein test'

# Generated at 2022-06-18 08:28:11.245395
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert match(Command('lein', 'lein help', 'lein help'))
    assert not match(Command('lein', 'lein help', 'lein help'))
    assert not match(Command('lein', 'lein help', 'lein help'))


# Generated at 2022-06-18 08:28:15.212018
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help'))


# Generated at 2022-06-18 08:28:25.627341
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:28:31.398099
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    '''
    command = 'lein test'
    assert get_new_command(command, output) == 'lein test-refresh'

# Generated at 2022-06-18 08:28:37.830371
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all\n  run-all-tests'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run\n  run-all\n  run-all-tests\n  run-tests'))

# Generated at 2022-06-18 08:28:45.371587
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n', '', 1))


# Generated at 2022-06-18 08:28:49.176340
# Unit test for function get_new_command
def test_get_new_command():
    output = ''''lein' is not a task. See 'lein help'.

Did you mean this?
         lein-exec
'''
    command = Command('lein', output=output)
    assert get_new_command(command) == 'lein-exec'

# Generated at 2022-06-18 08:28:51.834866
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:28:57.948410
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '\trun-dev\n'
                                   '\trun-prod\n'
                                   'Run `lein help` for detailed information.')) == 'lein run-dev'

# Generated at 2022-06-18 08:29:00.816521
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:29:08.688729
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run\n\'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run'))
    assert not match(Command('lein run', 'lein run\n\'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         run'))
    assert not match(Command('lein run', 'lein run\n\'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         run\n         run'))
    assert not match(Command('lein run', 'lein run\n\'run\' is not a task. See \'lein help\'.\nDid you mean this?\n         run\n         run\n         run\n         run'))
    assert not match

# Generated at 2022-06-18 08:29:17.156597
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.')) is None
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'. Did you mean this?\n\n\t\ttest'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'. Did you mean this?\n\n\t\ttest')) is None
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'. Did you mean this?\n\n\t\ttest'))

# Generated at 2022-06-18 08:29:27.122630
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein run'))
    assert match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found'))

# Generated at 2022-06-18 08:29:41.183493
# Unit test for function match

# Generated at 2022-06-18 08:29:43.928007
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:29:53.442513
# Unit test for function get_new_command

# Generated at 2022-06-18 08:29:57.527424
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:30:06.394321
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', '', '', '', '', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', '', '', '', '', '', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:30:11.309122
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '  run-dev\n'
                                   '  run-prod\n'
                                   '  run-test\n'
                                   'See \'lein help\' for correct task names.')) == 'lein run-dev'

# Generated at 2022-06-18 08:30:13.688020
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
Could not find task 'run'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:30:21.609887
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'lein run'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'lein run', 'lein run'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.', 'Did you mean this?', 'lein run', 'lein run', 'lein run'))

# Generated at 2022-06-18 08:30:26.489181
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:30:30.383368
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.

Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:30:42.780865
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')) == 'lein run-tests'

# Generated at 2022-06-18 08:30:46.106642
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n  foo\n')) == 'lein foo'

# Generated at 2022-06-18 08:30:51.706405
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
''')) == 'lein test'

    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
         test-refresh
''')) == 'lein test'

# Generated at 2022-06-18 08:30:54.856556
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:30:57.640080
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   ''''test' is not a task. See 'lein help'.
Did you mean this?
         test-refresh''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:31:00.361292
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert not match(Command('lein', 'lein help', 'lein help'))
    assert not match(Command('lein', 'lein help', 'lein help'))


# Generated at 2022-06-18 08:31:02.727435
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:31:05.307997
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:31:08.580326
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein foo', '''
lein foo
'foo' is not a task. See 'lein help'.

Did you mean this?
         foo
    ''')) == 'lein foo'

# Generated at 2022-06-18 08:31:10.975350
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:31:33.065704
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test',
                                   ''''test' is not a task. See 'lein help'.
Did you mean this?
         test''')) == 'lein test'

# Generated at 2022-06-18 08:31:42.160056
# Unit test for function match

# Generated at 2022-06-18 08:31:50.469927
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest\n\t\ttest2'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t\ttest\n\t\ttest2'))


# Generated at 2022-06-18 08:31:53.348381
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task \'run\'.\nDid you mean this?\n  run-dev\n  run-prod\n  run-test\n',
                                   '', 1)) == 'lein run-dev'

# Generated at 2022-06-18 08:31:55.745614
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('lein',
                                   output="'foo' is not a task. See 'lein help'.\nDid you mean this?\n\trun\n")) == 'lein run'

# Generated at 2022-06-18 08:31:59.074213
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))


# Generated at 2022-06-18 08:32:00.625640
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
''')) == 'lein run'

# Generated at 2022-06-18 08:32:04.814967
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))
    assert not match(Command('lein run', 'lein run: No such task'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev', 'lein run'))

# Generated at 2022-06-18 08:32:11.370637
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n'))
    assert not match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n\'foo\' is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n', '', 1))


# Generated at 2022-06-18 08:32:18.359709
# Unit test for function match
def test_match():
    assert match(Command('lein',
                         'lein run is not a task. See \'lein help\'.\nDid you mean this?\n\tru'))
    assert not match(Command('lein', 'lein run'))
    assert not match(Command('lein', 'lein run is not a task. See \'lein help\''))
    assert not match(Command('lein', 'lein run is not a task. See \'lein help\'.\nDid you mean this?\n\tru',
                             'lein run is not a task. See \'lein help\'.\nDid you mean this?\n\tru'))
