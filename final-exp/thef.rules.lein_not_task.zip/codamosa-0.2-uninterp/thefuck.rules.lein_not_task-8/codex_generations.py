

# Generated at 2022-06-18 08:22:55.182027
# Unit test for function match
def test_match():
    assert match(Command('lein repl',
                         '"repl" is not a task. See "lein help".\nDid you mean this?\n         repl : Starts a repl session either with the current project or standalone.'))
    assert not match(Command('lein repl',
                             '"repl" is not a task. See "lein help".'))
    assert not match(Command('lein repl',
                             '"repl" is not a task. See "lein help".\nDid you mean this?\n         repl : Starts a repl session either with the current project or standalone.'))

# Generated at 2022-06-18 08:23:02.201453
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')
    assert get_new_command(command) == 'lein repl'

# Generated at 2022-06-18 08:23:06.831072
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    assert get_new_command(Command('lein run', '''
lein run
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
         repl
''')) == 'lein run-\n'

# Generated at 2022-06-18 08:23:11.984779
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))


# Generated at 2022-06-18 08:23:22.200610
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all'))
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all\nrun-all-tests'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\nrun\nrun-all\nrun-all-tests\nrun-tests'))

# Generated at 2022-06-18 08:23:31.982033
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein run'))
    assert match(Command('lein', 'lein run', 'lein: command not found'))
    assert not match(Command('lein', 'lein run', 'lein: command not found',
                             'Did you mean this?'))
    assert not match(Command('lein', 'lein run', 'lein: command not found',
                             'Did you mean this?', 'lein run'))
    assert not match(Command('lein', 'lein run', 'lein: command not found',
                             'Did you mean this?', 'lein run', 'lein run'))
    assert not match(Command('lein', 'lein run', 'lein: command not found',
                             'Did you mean this?', 'lein run', 'lein run',
                             'lein run'))

# Generated at 2022-06-18 08:23:38.222677
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun\n\trun-dev'))


# Generated at 2022-06-18 08:23:41.044808
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   ''''run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:23:43.856732
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
''')) == 'lein test'

# Generated at 2022-06-18 08:23:46.668742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:23:54.546552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '\trun-dev\n'
                                   '\trun-prod\n'
                                   '\trun-test\n'
                                   'Run `lein help` for detailed information.')) == 'lein run-dev'

# Generated at 2022-06-18 08:23:57.856376
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:24:04.366657
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun'))


# Generated at 2022-06-18 08:24:11.994292
# Unit test for function get_new_command

# Generated at 2022-06-18 08:24:14.886926
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
lein run
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:24:25.118315
# Unit test for function get_new_command

# Generated at 2022-06-18 08:24:33.007055
# Unit test for function match

# Generated at 2022-06-18 08:24:35.712602
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:24:42.485851
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run'))
    assert not match(Command('lein run', 'lein run: No such task'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run', 'sudo'))


# Generated at 2022-06-18 08:24:51.435118
# Unit test for function match

# Generated at 2022-06-18 08:24:56.628067
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')) == 'lein repl'

# Generated at 2022-06-18 08:25:07.795024
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein: \'foo\' is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'lein: \'foo\' is not a task. See \'lein help\'', 'Did you mean this?'))
    assert not match(Command('lein foo', 'lein: \'foo\' is not a task. See \'lein help\'', 'Did you mean this?', ''))
    assert not match(Command('lein foo', 'lein: \'foo\' is not a task. See \'lein help\'', 'Did you mean this?', 'Did you mean this?'))
    assert not match(Command('lein foo', 'lein: \'foo\' is not a task. See \'lein help\'', 'Did you mean this?', 'Did you mean this?', ''))

# Generated at 2022-06-18 08:25:17.679503
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein foo', 'lein: foo is not a task. See \'lein help\'', 'Did you mean this?\n\n\tfoo\n\tfoo-bar\n\tfoo-bar-baz\n'))
    assert not match(Command('lein', 'lein foo', 'lein: foo is not a task. See \'lein help\'', 'Did you mean this?\n\n\tfoo\n\tfoo-bar\n\tfoo-bar-baz\n', 'Did you mean this?\n\n\tfoo\n\tfoo-bar\n\tfoo-bar-baz\n'))

# Generated at 2022-06-18 08:25:21.228992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    lein run
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:25:32.098355
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein help'))
    assert match(Command('lein', 'lein help', 'lein: command not found'))
    assert match(Command('sudo lein', 'lein help', 'lein: command not found'))
    assert not match(Command('lein', 'lein help', 'lein: command not found',
                             'lein help'))
    assert not match(Command('lein', 'lein help', 'lein: command not found',
                             'lein help', 'lein help'))
    assert not match(Command('lein', 'lein help', 'lein: command not found',
                             'lein help', 'lein help', 'lein help'))

# Generated at 2022-06-18 08:25:34.711280
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        repl
    ''')
    assert get_new_command(command) == 'lein repl'

# Generated at 2022-06-18 08:25:38.471741
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run'))
    assert not match(Command('lein run', 'lein run: No such task'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n  run', 'lein run'))


# Generated at 2022-06-18 08:25:43.749899
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:25:52.993814
# Unit test for function match

# Generated at 2022-06-18 08:25:59.768887
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:26:06.219013
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:26:08.791195
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
Could not find task 'test' in project.clj.
Did you mean this?
  test-refresh
''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:26:17.237498
# Unit test for function match

# Generated at 2022-06-18 08:26:20.198568
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test', 'test is not a task. See \'lein help\'.\n\nDid you mean this?\n         test-refresh')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-18 08:26:25.369172
# Unit test for function match
def test_match():
    assert match(Command('lein run',
                         '"run" is not a task. See "lein help".\nDid you mean this?\n  run-dev'))
    assert not match(Command('lein run',
                             '"run" is not a task. See "lein help".'))
    assert not match(Command('lein run',
                             '"run" is not a task. See "lein help".\nDid you mean this?\n  run-dev',
                             'sudo'))


# Generated at 2022-06-18 08:26:27.930485
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.

Did you mean this?
         test
''')) == 'lein test'

# Generated at 2022-06-18 08:26:30.598621
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:26:36.138248
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:26:45.502456
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n    test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n    test\n    test2'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n    test\n    test2\n    test3'))

# Generated at 2022-06-18 08:26:55.697027
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\''))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test\n  test2'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n  test\n  test2\n  test3'))

# Generated at 2022-06-18 08:27:09.857765
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))
    assert match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t- test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t- test\n\t- test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n\t- test\n\t- test\n\t- test'))
    assert not match(Command('lein test', 'lein test is not a task. See \'lein help\'.'))

# Generated at 2022-06-18 08:27:12.125510
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''Could not find task 'run'.
    Did you mean this?
        repl
''')) == 'lein repl'

# Generated at 2022-06-18 08:27:21.915454
# Unit test for function match

# Generated at 2022-06-18 08:27:27.192297
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))


# Generated at 2022-06-18 08:27:34.931447
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-tests'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\n\trun\n\trun-tests\n\trun-tests-travis'))

# Generated at 2022-06-18 08:27:43.633825
# Unit test for function match
def test_match():
    assert match(Command('lein run',
                         'Could not find task or namespaces '
                         '"run".\nDid you mean this?\n  run-dev\n'))
    assert not match(Command('lein run',
                             'Could not find task or namespaces "run".'))
    assert not match(Command('lein run',
                             'Could not find task or namespaces "run".\n'
                             'Did you mean this?\n  run-dev\n'))
    assert not match(Command('lein run',
                             'Could not find task or namespaces "run".\n'
                             'Did you mean this?\n  run-dev\n',
                             'sudo'))


# Generated at 2022-06-18 08:27:52.122016
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun\n\trun-main'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'\nDid you mean this?\n\trun\n\trun-main\n\trun-main-1'))


# Generated at 2022-06-18 08:28:01.381896
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 08:28:10.164377
# Unit test for function match
def test_match():
    assert match(Command('lein',
                         stderr='Could not find task \'test\'\n'
                                'Did you mean this?\n'
                                '         test-refresh'))
    assert not match(Command('lein',
                             stderr='Could not find task \'test\'\n'
                                    'Did you mean this?\n'
                                    '         test-refresh\n'
                                    '         test-refresh'))
    assert not match(Command('lein',
                             stderr='Could not find task \'test\'\n'
                                    'Did you mean this?\n'
                                    '         test-refresh\n'
                                    '         test-refresh\n'
                                    '         test-refresh'))

# Generated at 2022-06-18 08:28:12.948392
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
lein run
'run' is not a task. See 'lein help'.

Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:28:32.377878
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'lein test\n'
                         '"test" is not a task. See \'lein help\'.\n'
                         'Did you mean this?\n'
                         '         test-refresh'))
    assert not match(Command('lein test', 'lein test\n'
                             '"test" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein test', 'lein test\n'
                             '"test" is not a task. See \'lein help\'.\n'
                             'Did you mean this?\n'
                             '         test-refresh\n'
                             '         test-refresh'))

# Generated at 2022-06-18 08:28:35.331038
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   'Could not find task or namespaces run.\n'
                                   'Did you mean this?\n'
                                   '  run-dev\n'
                                   '  run-prod\n')) == 'lein run-dev'

# Generated at 2022-06-18 08:28:37.965856
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.

Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:28:42.042628
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', '', ''))
    assert not match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))


# Generated at 2022-06-18 08:28:45.679217
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:28:48.569684
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:28:51.326130
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
Could not find task 'run'.
Did you mean this?
         run-
    ''')
    assert get_new_command(command) == 'lein run-'

# Generated at 2022-06-18 08:29:01.592124
# Unit test for function get_new_command

# Generated at 2022-06-18 08:29:06.618053
# Unit test for function match
def test_match():
    assert match(Command('lein help', 'lein help is not a task. See \'lein help\'.\nDid you mean this?\n\t-h, --help, -?, --?\tPrint this help information.'))
    assert not match(Command('lein help', 'lein help is not a task. See \'lein help\'.\nDid you mean this?\n\t-h, --help, -?, --?\tPrint this help information.'))


# Generated at 2022-06-18 08:29:15.546291
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev', error=1))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev', error=1))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))
    assert not match(Command('lein run', 'lein run: No such task\nDid you mean this?\n\trun-dev'))

# Generated at 2022-06-18 08:29:44.112566
# Unit test for function match
def test_match():
    assert match(Command('lein run',
                         '"run" is not a task. See \'lein help\'.'
                         '\nDid you mean this?\n         run'))
    assert not match(Command('lein run', '"run" is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', '"run" is not a task. See \'lein help\'.'
                                        '\nDid you mean this?\n         run\n         run'))
    assert not match(Command('lein run', '"run" is not a task. See \'lein help\'.'
                                        '\nDid you mean this?\n         run\n         run\n         run'))

# Generated at 2022-06-18 08:29:53.659056
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'', '', '', '', ''))

# Generated at 2022-06-18 08:29:57.914186
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = '''
    lein: command not found: test
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test
    '''
    assert get_new_command(Command('lein test', output)) == 'lein test'

# Generated at 2022-06-18 08:30:00.464648
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
'run' is not a task. See 'lein help'.
Did you mean this?
         run-
    ''')) == 'lein run- '

# Generated at 2022-06-18 08:30:06.160941
# Unit test for function match
def test_match():
    assert match(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-dev
    '''))
    assert not match(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    '''))
    assert not match(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-dev
    '''))


# Generated at 2022-06-18 08:30:12.319555
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\n'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n  foo\n', '', 1))


# Generated at 2022-06-18 08:30:20.423160
# Unit test for function get_new_command

# Generated at 2022-06-18 08:30:23.169847
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
        run-tests
    ''')
    assert get_new_command(command) == 'lein run-tests'

# Generated at 2022-06-18 08:30:26.098713
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
    'test' is not a task. See 'lein help'.
    Did you mean this?
        test-refresh
    ''')) == 'lein test-refresh'

# Generated at 2022-06-18 08:30:29.503544
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
    'run' is not a task. See 'lein help'.
    Did you mean this?
    run-
    ''')) == 'lein run-'

# Generated at 2022-06-18 08:31:10.818470
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test', '''
'lein test' is not a task. See 'lein help'.
Did you mean this?
         test
''')) == 'lein test'

# Generated at 2022-06-18 08:31:17.861599
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\''))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))


# Generated at 2022-06-18 08:31:22.602298
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.'))
    assert match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun'))
    assert not match(Command('lein run', 'lein run: is not a task. See \'lein help\'.\nDid you mean this?\nrun\nrun\nrun\nrun'))
    assert not match

# Generated at 2022-06-18 08:31:31.240755
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command

# Generated at 2022-06-18 08:31:40.365992
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command

# Generated at 2022-06-18 08:31:42.808355
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein foo', '''
'foo' is not a task. See 'lein help'.

Did you mean this?
         foo
    ''')) == 'lein foo'

# Generated at 2022-06-18 08:31:47.888769
# Unit test for function match
def test_match():
    assert match(Command('lein run', "Could not find task 'run'.\nDid you mean this?\n         run-dev"))
    assert not match(Command('lein run', "Could not find task 'run'."))
    assert not match(Command('lein run', "Could not find task 'run'.\nDid you mean this?\n         run-dev",
                             "Could not find task 'run'.\nDid you mean this?\n         run-dev"))


# Generated at 2022-06-18 08:31:50.322093
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''
Could not find task 'run' in project.clj.
Did you mean this?
  run-
''')) == 'lein run- '

# Generated at 2022-06-18 08:31:52.993637
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein run', '''
    lein run is not a task. See 'lein help'.
    Did you mean this?
        run
    ''')
    assert get_new_command(command) == 'lein run'

# Generated at 2022-06-18 08:32:00.414482
# Unit test for function get_new_command