

# Generated at 2022-06-24 06:46:08.936179
# Unit test for function match
def test_match():
    assert match(Command('lein help build', '', '', '', ''))
    assert not match(Command('lein help', '', '', '', ''))


# Generated at 2022-06-24 06:46:11.746842
# Unit test for function match
def test_match():
    assert match(Command('lein test', 'test is not a task. See \'lein help\'.\nDid you mean this?\n  run'))
    assert not match(Command('lein test', 'Error: No such namespace: test'))


# Generated at 2022-06-24 06:46:16.820435
# Unit test for function get_new_command
def test_get_new_command():
    output = """C:\lein\lein.bat test Error: Don't know how to test.
    'test' is not a task. See 'lein help'.
    Did you mean this?
      test-refresh
    Run `lein tasks` for a list of available tasks.
    """
    command = Command('lein test', output=output)
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-24 06:46:22.208372
# Unit test for function get_new_command
def test_get_new_command():

    # Expected new command (as string to be used in --help message)
    expected_new_command = "lein jar"
    
    # Output from lein
    command_output_example = """
'java' is not a task. See 'lein help'.
Did you mean this?
         jar
=> %s
""" % expected_new_command

    # Command (with script and output)
    command = type("", (), {})()
    command.script = "lein jar"
    command.output = command_output_example

    # Function call (get_new_command)
    new_command = get_new_command(command)

    # Assert new_command is equals to expected_new_command
    assert new_command == exp

# Generated at 2022-06-24 06:46:26.737517
# Unit test for function get_new_command
def test_get_new_command():
    output = '''invalid task: "javac" is not a task. See 'lein help'.
Did you mean this?
        jar'''
    assert get_new_command(Command('lein javac', '', output)) == \
        'lein jar'

    output = '''invalid task: "mvn" is not a task. See 'lein help'.
Did you mean this?
         help
         new
         run
         test
         with-profile
         uberjar
         upgrade
         version'''
    assert get_new_command(Command('lein mvn', '', output)) == \
        'lein help'


# Generated at 2022-06-24 06:46:36.538423
# Unit test for function match
def test_match():
    assert match(Command('lein', 'lein go to the mall', ''))
    assert not match(Command('lein', 'lein go to the mall',
                             "Did you mean this?\n'mall' is not a task"))
    assert not match(Command('lein', 'lein go to the mall',
                             'Did you mean this?'))
    assert not match(Command('lein', 'lein go to the mall',
                             "Did you mean this?\n'mall' is not a task",
                             '', 'lein2 go to the mall'))
    assert match(Command('lein', 'lein go to the mall',
                         "Did you mean this?\n'mall' is not a task",
                         '', 'lein2 go to the mall', True))


# Generated at 2022-06-24 06:46:40.158397
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command(script='lein clsi',
		output='Could not find task or namespaces clsi.\nDid you mean this?\n\tcljsbuild',
		stderr='')) == "lein cljsbuild"


# Generated at 2022-06-24 06:46:44.009686
# Unit test for function match
def test_match():
    command = Command('lein test-refresh')
    assert not match(command)
    command = Command('lein test-refresh',
                      stderr='test-refresh is not a task. See \'lein help\'.\nDid you mean this?\ntest-refresh')
    assert match(command)



# Generated at 2022-06-24 06:46:48.600665
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
    Command('lein dofibile', 
            'Leiningen is not a task. See \'lein help\'.\r\n\r\nDid you mean this?\r\n\r\ndocile\r\ndefile\r\ndeftest\r\ndoall\r\ndepot\r\n')) == 'lein docile'

# Generated at 2022-06-24 06:46:50.490411
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('lein uberjar') == 'lein jar'


enabled_by_default = True

# Generated at 2022-06-24 06:46:59.467468
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein test')) == 'lein run'
    assert get_new_command(Command('lein help')) == 'lein help'
    assert get_new_command(Command('lein')) == 'lein'
    assert get_new_command(Command('lein test plug')) == 'lein plug'
    assert get_new_command(Command('lein plug test ')) == 'lein plug'
    assert get_new_command(Command('sudo lein test')) == 'sudo lein run'
    assert get_new_command(Command('sudo lein help')) == 'sudo lein help'
    assert get_new_command(Command('sudo lein')) == 'sudo lein'
    assert get_new_command(Command('sudo lein test plug')) == 'sudo lein plug'
    assert get_

# Generated at 2022-06-24 06:47:03.392656
# Unit test for function match
def test_match():
    script = "lein uebug test"
    output = """
    'uebug' is not a task. See 'lein help'.
    
    Did you mean this?
        uberjar"""
    assert match(Command(script, output, ""))


# Generated at 2022-06-24 06:47:05.568201
# Unit test for function match
def test_match():
    assert match(Command('lein',
            stderr = '''Could not find task or namespaces with prefix: repl.
`repl' is not a task. See 'lein help'.

Did you mean this?
         run
''',script = 'lein'))


# Generated at 2022-06-24 06:47:09.143971
# Unit test for function match
def test_match():
    assert any((match(Command(script='lein run',
                              output='"run" is not a task. See "lein help".\nDid you mean this?\n\trun-all-tests\n\trun-all-specs\n\trun-task\n\trun-tests',))
                for app in ('lein',)))
    assert not any((match(Command(script='lein run',
                              output='"run" is not a task. See "lein help".',))
                for app in ('lein',)))


# Generated at 2022-06-24 06:47:19.014518
# Unit test for function match
def test_match():
    assert match(Command("lein do clean, run",
                         "lein do clean, run: 'clean' is not a task."
                         " See 'lein help'.\nDid you mean this?\n"
                         "lein do clean, help\nlein do clean, new\n"))

    assert not match(Command("lein do clean, run",
                             "lein do clean, run: 'clean' is not a task."
                             " See 'lein help'.\nDid you mean this?\n"
                             "lein do clean, hepp\nlein do clean, new\n"))


# Generated at 2022-06-24 06:47:23.314693
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein with-profile test javac',
                      ''''javac' is not a task. See 'lein help'.\nDid you mean this?\n         deps\n         jar\n         run\n         trampoline''')
    new_command = get_new_command(command)
    assert new_command == 'lein with-profile test deps'

# Generated at 2022-06-24 06:47:33.653016
# Unit test for function match
def test_match():
    assert match(Command('lein exec', "Unknown task 'exec'.  Did you mean this?\n\trun\n'exec' is not a task. See 'lein help'."))
    assert match(Command('lein testr', "Unknown task 'testr'.  Did you mean this?\n\ttest\n'testr' is not a task. See 'lein help'."))
    assert match(Command('lein te', "Unknown task 'te'.  Did you mean these?\n\ttest\n\ttechnomancy\n'te' is not a task. See 'lein help'."))
    assert match(Command('lein exec', "'exec' is not a task. See 'lein help'."))
    assert not match(Command('lein exec', 'Task \'exec\' not found.'))

# Generated at 2022-06-24 06:47:35.139241
# Unit test for function match
def test_match():
    assert match(Command('lein run', 'lein:run is not a task. See lein help'))


# Generated at 2022-06-24 06:47:40.835688
# Unit test for function match
def test_match():
    out_match = '''
[thefuck] Error: 'repl' is not a task. See 'lein help'.
Did you mean this?
         repl:start
    '''
    out_no_match = '''
[thefuck] Error: 'repl' is not a task. See 'lein help'.
'''


    assert match(Command('lein repl', '', out_match))
    assert not match(Command('lein repl', '', out_no_match))


# Generated at 2022-06-24 06:47:41.898012
# Unit test for function match
def test_match():
    assert match("lein help")
    assert not match("lein -h")



# Generated at 2022-06-24 06:47:49.571013
# Unit test for function match
def test_match():
    output = '''
    lein test :unit org.clojure/clojure.test :once is not a task. See 'lein help' for available tasks. Does not apply to dependencies, coming from org.clojure/clojure "1.8.0"
    Did you mean this?
    lein test :unit org.clojure/clojure.test :once

'''
    assert match(Command(script='lein test')), output
    assert not match(Command(script='lein run')), output


# Generated at 2022-06-24 06:47:52.436917
# Unit test for function match
def test_match():
    assert match(Command('lein help', "", "lein help: 'help' is not a task. See 'lein help'.\nDid you mean this?\n    hellop\n"))


# Generated at 2022-06-24 06:47:55.994819
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   ''''run' is not a task. See 'lein help'
    Did you mean this?
                 run-

    If so, you need to add a project.clj to the current directory.
                                    ''')) == 'lein run-what-you-mean'

# Generated at 2022-06-24 06:47:58.773980
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("lein with-profile +foo 'ancient' is not a task.\
                            See 'lein help'\
                            Did you mean this?\
                            with-profile +foo test ") ==\
                            "lein with-profile +foo test"

# Generated at 2022-06-24 06:48:05.321354
# Unit test for function get_new_command
def test_get_new_command():
    correct_cmd = 'lein doc'
    command = MagicMock(output='"docc" is not a task. See \'lein help\'.\n' + 
                    '\n' + 
                    'Did you mean this?\n' + 
                    '            doc\n' + 
                    'Project doc finished', script=correct_cmd, stdout='', stderr='')
    assert get_new_command(command) == correct_cmd

# Generated at 2022-06-24 06:48:08.391496
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("lein test", "lein tes is not a task. See 'lein help'.\
Did you mean this?\ntest")

    assert get_new_command(command) == "lein test"

# Generated at 2022-06-24 06:48:17.909076
# Unit test for function match
def test_match():
    assert match(Command("lein some", "command 'some' is not a task. See 'lein help'\nDid you mean this?\n- some\n", ""))
    assert match(Command("lein some", "command 'some' is not a task. See 'lein help'", ""))
    assert match(Command("lein some", "command 'some' is not a task. See 'lein help'", ""))
    assert match(Command("lein somee", "command 'some' is not a task. See 'lein help'\nDid you mean this?\n- somee\n", ""))
    assert match(Command("lein some", "command 'some' is not a task. See 'lein help'\nDid you mean this?\n- some\n", ""))

# Generated at 2022-06-24 06:48:23.134165
# Unit test for function match
def test_match():
    assert match(Command('lein goo', 'lein goo is not a task. See lein help'))
    assert match(Command('lein goo --bar',
                         'lein goo is not a task. See lein help'))
    assert match(Command('lein goo --bar',
                         'lein goo is not a task. See lein help'))
    assert not match(Command('sudo lein goo --bar',
                         'lein goo is not a task. See lein help'))
    assert not match(Command('lein goo --bar',
                         'lein goo is not a task. See sudo lein help'))
    assert not match(Command('lein goo --bar',
                         'lein goo is not a task. See lein help'))

# Generated at 2022-06-24 06:48:27.195316
# Unit test for function get_new_command
def test_get_new_command():
    output = ('Could not find task or command \'test\'.\n', 'Did you mean this?\n', "test\n", "list\n")
    newcmd = get_new_command(Command('test', output, '', ''))
    assert newcmd.script == 'lein list'

# Generated at 2022-06-24 06:48:30.946995
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run', '''Could not find task or
        command 'run'. Is 'lein' on your path? Do Leiningen tasks exist
        for this project? Run 'lein help' for available tasks.
        Did you mean this?
            run-task''')) == 'lein run-task'

# Generated at 2022-06-24 06:48:34.174484
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = '''arguments/repl-options/flg is not a task. See 'lein help'.

Did you mean this?
         repl
'''
    command = Command('lein fig', output)

    assert get_new_command(command).script == 'lein repl'

# Generated at 2022-06-24 06:48:38.631354
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein deploy clojars',
                      '''`deploy` is not a task. See 'lein help'.
Did you mean this?
         deploy-file''')
    assert get_new_command(command) == 'lein deploy-file clojars'

# Generated at 2022-06-24 06:48:45.141515
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein:foo is not a task. See \'lein help\'', ''))
    assert match(Command('lein bar', 'lein:bar is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'lein:foo is not a task. See \'lein help\'', ''))
    assert not match(Command('lein foo', 'is not a task. See \'lein help\'', ''))


# Generated at 2022-06-24 06:48:51.387294
# Unit test for function get_new_command
def test_get_new_command():
    # test output with single suggestion
    assert (get_new_command(Command('lein run', '''foo is not a task. See 'lein help'.
Did you mean this?
         run''')) == 'lein run')

    # test output with multiple suggestions
    assert (get_new_command(Command('lein run', '''foo is not a task. See 'lein help'.
Did you mean one of these?
         compile
         jar
         run''')) == 'lein run')

    # test output with no suggestions
    assert (get_new_command(Command('lein run', '''foo is not a task. See 'lein help'.
Did you mean one of these?''')) == None)

    # test that matching work for long output

# Generated at 2022-06-24 06:48:58.796525
# Unit test for function get_new_command
def test_get_new_command():
    Command = namedtuple('Command', ['script', 'output'])
    command = Command(
        "lein deploy release/walmart-newsletter-sf-0.1.0-20140328.071804-1.pom",
        "`deploy' is not a task. See 'lein help'.\nDid you mean this?\n  'uberjar'"
        )
    assert get_new_command(command) == "lein uberjar release/walmart-newsletter-sf-0.1.0-20140328.071804-1.pom"

# Generated at 2022-06-24 06:49:05.786223
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('lein repl\n'
                            "Could not find task or namespaces 'repl'.\n"
                            "Did you mean this?\n"
                            '         rep\n'
                            '         ref\n')
            == 'lein rep')
    assert (get_new_command('lein repl\n'
                            "Could not find task or namespaces 'repl'.\n"
                            "Did you mean this?\n"
                            '         ref\n')
            == 'lein ref')

# Generated at 2022-06-24 06:49:11.282695
# Unit test for function match
def test_match():
    assert match(Command('lein classpath', 'lein: '
                         'classpath is not a task. See \'lein help\'.'
                         ' Did you mean this?\n  repl\n'))
    assert match(Command('lein classpath', 'lein: '
                         'classpath is not a task. See \'lein help\'.'
                         ' Did you mean this?\n  repl\n')) is None
    assert match(Command('lein classpath', 'lein: '
                         'classpath is not a task. See \'lein help\''
                         )) is None



# Generated at 2022-06-24 06:49:15.085932
# Unit test for function match
def test_match():
    command = Command('lein test', 'test is not a task. See "lein help".\nDid you mean this?\n  test-refresh\n  test-simple\n  test-cljs\n  run-tests\n')
    assert match(command)


# Generated at 2022-06-24 06:49:17.973893
# Unit test for function match
def test_match():
    output = """Could not find task 'test' for 'test/test.clj'.
Did you mean this?
test/test
test-test"""
    assert match(Command('lein test', output=output))


# Generated at 2022-06-24 06:49:20.830754
# Unit test for function match
def test_match():
    assert match(Command('lein git', ''))
    assert match(Command('lein git', 'git is not a task. See \'lein help\'.'))
    assert not match(Command('lein git', 'git is not a task. See \'lein help\'.'))

# Unit test new_command

# Generated at 2022-06-24 06:49:26.135466
# Unit test for function match
def test_match():
    assert match(Command('lein my-awesome-tasd',
                         'Error: Could not find or load main class'))
    assert match(Command('lein my-awesome-tasd',
                         'MyClass is not a task. See `lein help`.'))
    #  'Did you mean this?' not included in error message
    assert not match(Command('lein my-awesome-tasd',
                             'Error: Could not find or load main class`.'))
    # 'Did you mean this?' included in error message, but
    # 'is not a task. See 'lein help'' not included
    assert not match(Command('lein my-awesome-tasd',
                             'Error: Could not find or load main class`.'
                             'Did you mean this?'))

# Generated at 2022-06-24 06:49:35.787891
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('lein repl\n\
"repl" is not a task. See "lein help".\n\
Did you mean this?\n\
         repl : Run a repl with the project classpath') ==
            'lein repl : Run a repl with the project classpath')
    assert (get_new_command('lein test\n\
"test" is not a task. See "lein help".\n\
Did you mean one of these?\n\
         test-refresh\n\
         test-selectors') ==
            'lein test-refresh\nlein test-selectors')

# Generated at 2022-06-24 06:49:41.761809
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein cljfmt fix',
                                   '"cljfmt fix" is not a task. See "lein help".\nDid you mean this?\n         cljfmt',
                                   ''))[0] == 'lein cljfmt'
    assert get_new_command(Command('lein cjlfmt fix',
                                   '"cjlfmt fix" is not a task. See "lein help".\nDid you mean this?\n         cljfmt',
                                   ''))[0] == 'lein cljfmt'

# Generated at 2022-06-24 06:49:47.798327
# Unit test for function match
def test_match():
    assert match(Command('lein deps',
                         '"deps" is not a task. See "lein help". Did you mean this?\n\n  help\n'))
    assert match(Command('lein kompile dumb',
                         'Could not find task or namespaces with prefix: kompile Did you mean one of these?\n\n  kompilest\n  kompile\n  compile\n  test\n'))
    assert match(Command('lein repl',
                         '"repl" is not a task. See "lein help". Did you mean one of these?\n\n  help\n  repl-listen\n  repl-server\n'))
    assert not match(Command('lein do clean, test',
                             'Unknown task'))

# Generated at 2022-06-24 06:49:52.841383
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = Command("lein crossof",
                        "Could not find task or namespaced task 'crossof' "
                        "in project.clj, did you mean this?\n"
                        "  * crossref\n"
                        "  * crossref-index",
                        "lein crossof")
    assert get_new_command(command_1) == "lein crossref"

# Generated at 2022-06-24 06:49:56.720435
# Unit test for function match
def test_match():
    assert not match(Command('lein build', ''))
    assert not match(Command('lein build', "Could not find artifact ..."))
    assert match(Command('lein serve',
                         "'serve' is not a task. See 'lein help'\nDid you mean this?\n\tserver\n",
                         ''))


# Generated at 2022-06-24 06:50:01.794639
# Unit test for function match
def test_match():
    """ Test function match """
    assert match(Command("lein refe", "lein refe is not a task. See 'lein help'", ""))
    assert not match(Command("lein ref", "lein ref is not a task. See 'lein help'", ""))
    assert not match(Command("lein ref", "", ""))


# Generated at 2022-06-24 06:50:08.429290
# Unit test for function match
def test_match():
    assert match(Command('lein', '', 'lein task is not a task. See help'))
    assert not match(Command('lein', '', 'lein is not a task. See help'))
    assert not match(Command('lein', '', 'lein foo is not a task. See help'))
    assert not match(Command('lein', '', 'lein foo bar is not a task. See help'))
    assert not match(Command('lein', '', 'foo bar lein is not a task. See help'))


# Generated at 2022-06-24 06:50:15.383714
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein dosomething', output="'dosomething' is not a task. See 'lein help'.\n\nDid you mean this?\n\n  instead\n  run")
    assert get_new_command(command) == "lein instead"

    command = Command('lein dosomething', output="'dosomething' is not a task. See 'lein help'.\n\nDid you mean one of these?\n\n  instead\n  run")
    assert get_new_command(command) == "lein instead"

# Generated at 2022-06-24 06:50:18.560743
# Unit test for function match
def test_match():
    assert match(Command('lein', stderr='lein jar is not a task. See '
                         '\'lein help\'.\nDid you mean this?\nlein install'))


# Generated at 2022-06-24 06:50:20.733107
# Unit test for function match
def test_match():
    command = 'lein dummy-task'
    assert match(command) is True



# Generated at 2022-06-24 06:50:22.673838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == 'lein deploy :db'

# Generated at 2022-06-24 06:50:31.159885
# Unit test for function match
def test_match():
	assert match(Command("lein run", output="'run' is not a task. See 'lein help'.\nDid you mean this?\n    run\n    test"))
	assert not match(Command("lein run", output="'run' is not a task. See 'lein help'.\nDid you mean this?\n    run\n    test", error="error"))
	assert not match(Command("lein run", output="'run' is not a task. See 'lein help'.\nDid you mean this?\n    run\n    test", exit_code=1))
	assert not match(Command("lein run", output="'run' is not a task. See 'lein help'"))
	assert not match(Command("lein run"))


# Generated at 2022-06-24 06:50:36.860848
# Unit test for function get_new_command
def test_get_new_command():
    from collections import namedtuple
    from thefuck.types import Command

    command = namedtuple('Command', ['output'])
    command_output = ''''scoop' is not a task. See 'lein help'.

Did you mean this?
         scoop-deps'''

    assert get_new_command(Command(script='lein scoop',
                                   output=command_output)) == \
        'lein scoop-deps'

# Generated at 2022-06-24 06:50:44.246199
# Unit test for function match
def test_match():
    assert match(Command(script='lein foo', output='foo is not a task. See \'lein help\'.\nDid you mean this?\nlein foo\n'))
    assert match(Command(script='lein foo bar', output='foo is not a task. See \'lein help\'.\nDid you mean this?\nlein foo\n'))
    assert not match(Command())
    assert not match(Command(script='lein foo', output='foo is not a task. See \'lein help\'.\nDid you mean this?\nlein foo\nlein bar\n'))


# Generated at 2022-06-24 06:50:49.980335
# Unit test for function match
def test_match():
    assert match(Command('lein cljsbuild auto app',
        "Command not found: lein.cljsbuild"
        "Did you mean one of these?"
        "lein.cljsbuild"
        "lein.less"))
    assert not match(Command('lein cljsbuild auto app', ''))
    assert not match(Command('lein cljsbuild auto app',
        "Command not found: lein.cljsbuild"
        "Did you mean one of these?"
        "lein.cljsbuild"
        "lein.less"))
    assert not match(Command("lein cljsbuild auto app",
        "Command not found: lein.cljsbuild"))


# Generated at 2022-06-24 06:50:54.087184
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein repl',
                                   output='"run" is not a task. See "lein help".\nDid you mean this?\nRuns lorem.\nrune\n')) == 'lein rune'


enabled_by_default = True

# Generated at 2022-06-24 06:50:57.629694
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein run',
                                   '"run" is not a task. See \'lein help\'.\n\nDid you mean this?\n         run',
                                   '', 0)) == ['lein run']

# Generated at 2022-06-24 06:51:01.214387
# Unit test for function match
def test_match():
    assert match(Command('lein repl', 'lein repl: is not a task. \
See \'lein help\'. Did you mean this?\n  repl\n'))
    assert not match(Command('lein repl', 'lein repl: is not a task. \
See \'lein help\'. \n'))

# Generated at 2022-06-24 06:51:09.262509
# Unit test for function get_new_command
def test_get_new_command():
    output = "lein repl : Could not find artifact ddf.repl:ddf.repl:jar:0.1.0-SNAPSHOT\n\
            \n\
            This could be due to a typo in :dependencies or network issues.\n\
            If you are behind a proxy, try setting the 'http_proxy' environment variable.\n\
            \n\
            \n\
            'repl' is not a task. See 'lein help'.\n\
            \n\
            Did you mean this?\n\
            \n\
            repl :headless\n\
            repl :start\n\
            repl :connect\n\
            \n\
            [ERROR] Could not start task :repl. \
            java.lang.ClassNotFoundException: ddf.repl.main"

# Generated at 2022-06-24 06:51:18.780101
# Unit test for function match
def test_match():
    assert match(Command('lein foo',
                         """
'foo' is not a task. See 'lein help'.
Did you mean this?
         foo-bar
"""))
    assert match(Command('lein foo',
                         """
'foo' is not a task. See 'lein help'.
Did you mean this?
         foo-bar
    a-b
"""))
    assert match(Command('lein foo',
                         '''
'foo' is not a task. See 'lein help'.
Did you mean this?
         foo-bar
    a-b
'''))
    assert match(Command('lein foo',
                         '''
'foo' is not a task. See 'lein help'.
Did you mean this?
         foo-bar
    a-b
    d
    c
'''))

# Generated at 2022-06-24 06:51:21.944746
# Unit test for function match
def test_match():
    assert match(Command('lein', stderr=open('./tests/resources/lein_error.out').read()))

# Unit test the function "get_new_command"

# Generated at 2022-06-24 06:51:25.705156
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein prj', ''''my-proj' is not a task. See 'lein help'.
Did you mean this?
         project''')) == 'lein project'

# Generated at 2022-06-24 06:51:36.129728
# Unit test for function get_new_command
def test_get_new_command():
    command_1= Command('lein run', '"run" is not a task. See "lein help".\nDid you mean this?\n         run-jetty')
    assert get_new_command(command_1) == "lein run-jetty"
    command_2= Command('lein run-help', '"run-help" is not a task. See "lein help".\nDid you mean this?\n         run'
                       '\nor this?\n         run-dev\nor this?\n         run-dev-help\nor this?\n         run-example\nor this?\n         run-plugin\nor this?\n         run-main')
    assert get_new_command(command_2) == "lein run"

# Generated at 2022-06-24 06:51:46.511950
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='lein deploy-library',
                      output='\'deploy-library\' is not a task. See \'lein help\'.\n\nDid you mean this?\n    deploy-local\n    deploy-m2\n')
    assert get_new_command(command) == 'lein deploy-local'

    command = Command(script='lein deploy-library',
                      output='\'deploy-library\' is not a task. See \'lein help\'.\n\nDid you mean one of these?\n    deploy-local\n    deploy-m2\n')
    assert get_new_command(command) == 'lein deploy-local'


# Generated at 2022-06-24 06:51:50.569067
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein swank', 'Leiningen is not a task. See \'lein help\'.\n\nDid you mean this?\n\tstart-swank')
    get_new_command(command)
    assert 'lein start-swank' == get_new_command(command)

# Generated at 2022-06-24 06:51:54.483367
# Unit test for function match
def test_match():
    assert match('lein run deploy')
    assert match('lein deploy')
    assert not match('lein depl')
    assert not match('lein run deploy --dry-run')
    assert not match('lein run deploy --help')
    assert not match('lein run help')
    assert not match('lein run help --version')


# Generated at 2022-06-24 06:52:03.827089
# Unit test for function match
def test_match():
    assert match(Command('lein deps',
                         '/usr/local/bin/lein: line 977: lein: command not found'))
    assert not match(Command('lein deps', ''))
    assert not match(Command('lein deps',
                         '/usr/local/bin/lein: line 977: lein: command not found',
                         stderr='/usr/local/bin/lein: line 977: lein: command not found'))
    assert match(Command('lein test',
                         """Could not find task 'test' in Leiningen.
Did you mean this?
         test-refresh"""))
    assert not match(Command('lein test',
                         'Could not find task \'test\' in Leiningen.'))

# Generated at 2022-06-24 06:52:09.818731
# Unit test for function match
def test_match():
    assert match(Command(script='lein repl',
                         stderr='Could not find task or namespaces. \
                                 Did you mean this? \
                                 \n\trepl',
                         output='Could not find task or namespaces. \
                                 Did you mean this? \
                                 \n\trepl'))

    assert not match(Command(script='lein repl',
                             stderr='Could not find task or namespaces.',
                             output='Could not find task or namespaces.'))



# Generated at 2022-06-24 06:52:11.584615
# Unit test for function match
def test_match():
    command = 'lein ring server-headless'
    assert(match(command))
    command = 'lein ring servr-headless'
    assert(not match(command))

# Generated at 2022-06-24 06:52:13.939702
# Unit test for function match
def test_match():
    assert match(Command('lein dorun'))
    assert not match(Command('lein run'))
    return


# Generated at 2022-06-24 06:52:16.891296
# Unit test for function get_new_command
def test_get_new_command():
    command = ''''lein classpath' is not a task. See 'lein help'.

Did you mean this?
         clean
'''
    assert get_new_command(command) == 'lein clean'

# Generated at 2022-06-24 06:52:27.241011
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_did_you_mean import get_new_command
    from thefuck.types import Command
    assert get_new_command(
        Command('lein foo', 
                'Could not find task \'foo\' in project root.\nDid you mean this?\n  foo',
                'lein foo')) == 'lein foo'
    assert get_new_command(
        Command('lein foo', 
                'Could not find task \'foo\' in project root.\nDid you mean this?\n  foo\n  foo-bar',
                'lein foo')) == 'lein foo-bar'

# Generated at 2022-06-24 06:52:30.181606
# Unit test for function match
def test_match():
    print(match(Command('lein trasnlator-core', 'lein trasnlator-core is not a task. See \'lein help\'.\n\nDid you mean this?\n        trasnlator-core\n\n    translator-core')))

# Generated at 2022-06-24 06:52:40.506559
# Unit test for function match
def test_match():
    assert match(Command('lein test', output=('test is not a task. '
                                              'See \'lein help\'.\n'
                                              'Did you mean this?  test\n')))
    assert not match(Command('lein version', output='Leiningen 2.6.1 on Java 1.8.0_72 OpenJDK 64-Bit Server VM'))
    assert not match(Command('lein version', output='lein: command not found'))
    assert match(Command('sudo lein test', output=('test is not a task. '
                                                   'See \'lein help\'.\n'
                                                   'Did you mean this?  test\n')))

# Generated at 2022-06-24 06:52:44.209103
# Unit test for function match
def test_match():
	s = 'lein test is not a task. See \'lein help\'.\nDid you mean this?\n         test-refresh'
	c = create_command(s)
	assert (match(c))


# Generated at 2022-06-24 06:52:51.226400
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command({
                'output': "lein2: 'repl' is not a task. See 'lein help'.\n"
                                   "Did you mean this?\n"
                                   "        repl\n"}) == 'lein repl'
    assert get_new_command({
                'output': "lein2: 'repl' is not a task. See 'lein help'.\n"
                                   "Did you mean this?\n"
                                   "        released\n"
                                   "        release\n"}) == 'lein released'

# Generated at 2022-06-24 06:52:57.116229
# Unit test for function match
def test_match():
    assert match(Command('lein deps', """'git' is not a task. See 'lein help'.

Did you mean this?
         :git
         :new
         :project""", ""))

    assert match(Command('lein deps', """'git' is not a task. See 'lein help'.""", ""))



# Generated at 2022-06-24 06:53:00.552923
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein foo',
                      "lein run version\n'foo' is not a task. See 'lein help'.\n\nDid you mean this?\n  run\n  version",)
    assert get_new_command(command) == 'lein run version'

# Generated at 2022-06-24 06:53:02.550372
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('''lein repl is not a task. See 'lein help'.
Did you mean this?
         repl
''').script == 'lein repl')

# Generated at 2022-06-24 06:53:05.440135
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein', '', 'lein testt\n`test` is not a task. See \'lein help\'.\nDid you mean this?\ntest\n')) == Command('lein', '', 'lein test\n')

# Generated at 2022-06-24 06:53:13.549642
# Unit test for function match
def test_match():
    assert match(Command('lein help', '''
    lein help is not a task. See 'lein help'.
    Did you mean this?
    plugin
    '''))
    assert not match(Command('lein help', '''
    lein help is not a task. See 'lein help'.
    '''))
    assert not match(Command('lein help', '''
    lein help is not a task. See 'lein help'.
    Did you mean this?
    plugin
    '''))
    assert not match(Command('lein help', '''
    lein help is not a task. See 'lein help'.
    Did you mean this?
    plugin
    plugin-deps
    '''))


# Generated at 2022-06-24 06:53:16.752672
# Unit test for function get_new_command
def test_get_new_command():
    command = None
    with open('data/output/lein_task_does_not_exist', 'r+') as output:
        command = type('', (), {})()
        command.script = 'lein run'
        command.output = output.read()
    assert(get_new_command(command) == 'lein runn')

# Generated at 2022-06-24 06:53:20.116896
# Unit test for function match
def test_match():
    assert match(Command('lein test', output='test is not a task. See `lein help`'))
    assert match(Command('lein unknown', output='unknown is not a task. See `lein help`'))


# Generated at 2022-06-24 06:53:25.595320
# Unit test for function get_new_command
def test_get_new_command():
    """ Unit test for function get_new_command"""
    from thefuck.rules.lein_typo import get_new_command
    command = type('Command', (object,),
                   {'script': 'lein',
                    'output': "Could not find task 'uberfie'.\nDid you mean this?\n  uberjar"})  # noqa
    assert get_new_command(command) == 'lein uberjar'

# Generated at 2022-06-24 06:53:32.940576
# Unit test for function match
def test_match():
    assert match(Command('lein build', '"build" is not a task. See \'lein help\'.'))
    assert match(Command('lein build', '"build" is not a task. See \'lein help\'.\nDid you mean this?\nrun'))
    assert not match(Command('lein build', '"build" is not a task. See \'lein help\'.'))
    assert not match(Command('lein build', '"build" is not a task. See \'lein help\'.\nDid you mean this?\nbuild'))

# Generated at 2022-06-24 06:53:37.295476
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('lein ishouldnotbeathing',
                                   '''
                                   `ishouldnotbeathing' is not a task. See 'lein help'.
                                   Did you mean this?
                                   	install
                                   ''',
                                   '')) == 'lein install'

# Generated at 2022-06-24 06:53:44.376963
# Unit test for function get_new_command
def test_get_new_command():
    command = type("command", (object,), {'script': "lein app", 'output': "Did you mean this?\nlein run"})
    assert get_new_command(command) == "lein run"
    command = type("command", (object,), {'script': "lein app", 'output': "Did you mean this?\nlein run\nlein uberjar"})
    assert get_new_command(command) in ["lein run", "lein uberjar"]

# Generated at 2022-06-24 06:53:49.456976
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_lookup import get_new_command
    command = Command('lein test',
                      'Could not find task or namespaces test.\n'
                      'Could not find task test.\n'
                      'Did you mean this?\n'
                      '  test-refresh')
    assert get_new_command(command) == 'lein test-refresh'

# Generated at 2022-06-24 06:53:56.111775
# Unit test for function get_new_command
def test_get_new_command():
    output = "lein repl\n'grunt' is not a task. See 'lein help'."
    output += "\nDid you mean this?\n  grunt"
    command = "lein grunt"
    assert get_new_command(command, output).script == 'lein grunt'
    output = "lein repl\n'grunt' is not a task. See 'lein help'."
    output += "\nDid you mean this?\n  grunt\n  grunge"
    assert get_new_command(command, output).script == 'lein grunt'

# Generated at 2022-06-24 06:54:01.600292
# Unit test for function get_new_command
def test_get_new_command():
    try:
        from thefuck.rules.lein_missing_task import _get_new_command
    except ImportError:
        """ The _get_new_command function MUST be the same as the function
        get_new_command
        """
        from thefuck.rules.lein_missing_task import get_new_command as _get_new_command

    assert _get_new_command('lein rundev --cljs') == 'lein rundev --compile'
    assert _get_new_command('lein rundev') == 'lein run'

# Generated at 2022-06-24 06:54:07.083404
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein test',
            '''** (LeiningenError) Could not find task
    'test' in project 'testing'.
    Do you have a :test profile?
    Perhaps you meant this:
        :e, :eval, :el, :elc, :eval-in-project, :run, :jar, :uberjar, :war, :install, :check, :outdated, :profiles, :deploy, :deploy-repositories, :upgrade, :version, :help''')
    assert get_new_command(command) == Command('lein jar', '')

# Generated at 2022-06-24 06:54:09.676251
# Unit test for function match
def test_match():
    assert match(Command('lein help', 'lein help: not a task', '', 0, None))
    assert not match(Command('jshint', '', '', 0, None))


# Generated at 2022-06-24 06:54:12.978941
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'foo is not a task. See \'lein help\'', ''))
    assert match(Command('lein', '\'c\' is not a task. See \'lein help\'', '')) is None
    assert match(Command('lein foo bar baz', 'foo is not a task. See \'lein help\'', '')) is None
    assert match(Command('lein foo bar baz', '', '')) is None


# Generated at 2022-06-24 06:54:17.308602
# Unit test for function match
def test_match():
	assert match(Command('lein help', '"foo" is not a task. See \'lein help\''))
	assert not match(Command('lein help', '"foo" is not a task. See \'lein help\''))


# Generated at 2022-06-24 06:54:22.417767
# Unit test for function match
def test_match():
    assert match(Command('lein',
                         'lein is not a task. See \'lein help\'.'))
    assert match(Command('lein foo',
                         'lein foo is not a task. See \'lein help\'.'))
    assert match(Command('lein bar',
                         'lein bar is not a task. See \'lein help\'.'
                         '\nDid you mean this?\n\tfoo\n\tbaz\n'))
    assert not match(Command('lein',
                             'Error: Could not find or load main class org.'
                             'codehaus.groovy.tools.GroovyStarter'))
    assert not match(Command('lein help',
                             'Usage: lein [task]\n\n'))



# Generated at 2022-06-24 06:54:25.334208
# Unit test for function match
def test_match():
    assert not match(Command('lein', stderr='lein: not found'))
    assert not match(Command('lein foo', stderr='lein: not found'))
    assert match(Command('lein foo bar', stderr='lein: foo is not a task. See \'lein help\'.'))



# Generated at 2022-06-24 06:54:33.126048
# Unit test for function match
def test_match():
    assert not match(Command('lein',
                             stderr='lein: do is not a task. See "lein help".\n',
                             script=''))

    new_command = Command('lein clean',
                          stderr="""Unknown task 'clena'. This task has a typo,
or lein-do, lein-exec or lein-psl plugin isn't installed, or "lein help"
doesn't know about it.
Did you mean this?
         clean
""",
                          script='')

    assert match(new_command)


# Generated at 2022-06-24 06:54:36.510993
# Unit test for function get_new_command
def test_get_new_command():
    script = 'lein help'
    output = r"""
'help' is not a task. See 'lein help'
Did you mean this?
         help

See 'lein help'
"""
    command = Command(script,output)
    assert(get_new_command(command) == 'lein help')

# Generated at 2022-06-24 06:54:40.752962
# Unit test for function match
def test_match():
    # When match() returns True
    assert match(Command('lein help', 'lein help \n\n'
             'Available tasks\nand some other line'))

    # When match() returns False
    assert not match(Command('lein help', 'lein help \n\n'
                 'Available tasks\nand some other line\n   [NO MATCH]'))

# Generated at 2022-06-24 06:54:46.437196
# Unit test for function match
def test_match():
    assert match(Command('lein', output=''))
    assert match(Command('lein', 
        output='"foo" is not a task. See \'lein help\'\nDid you mean this?\nbar'))
    assert not match(Command('lein', 
        output='"foo" is not a task. See \'lein help\''))
    assert not match(Command('lein', 
        output='"foo" is not a task. See \'lein help\'\nDid you mean this?\nbar\nbar'))


# Generated at 2022-06-24 06:54:50.394102
# Unit test for function match
def test_match():
    assert match(Command('lein', stderr='foo:bar is not a task. See \'lein help\'\nDid you mean this?\n  foobar'))
    assert not match(Command('lein', stderr='foo:bar is not a task. See \'lein help\'\nDid you mean this?\n  foobar', script='git'))


# Generated at 2022-06-24 06:54:55.909051
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.lein_task_not_found import get_new_command
    assert get_new_command(Command("lein test", "`test' is not a task. See `lein help'.", "Did you mean this?\n\trun-tests")) == "lein run-tests"

    assert get_new_command(Command("lein test 2>/dev/null", "`test' is not a task. See `lein help'.", "Did you mean this?\n\trun-tests")) == "lein run-tests 2>/dev/null"


# Generated at 2022-06-24 06:54:59.679085
# Unit test for function match
def test_match():
    assert match(Command('lein', output='''
'upgrade' is not a task. See 'lein help'.
Did you mean this?
     uberjar

'''))
    assert match(Command('lein', output='lein repl')) is False


# Generated at 2022-06-24 06:55:04.078028
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
lein run
'run' is not a task. See 'lein help'.
Did you mean this?
             run
             repl
    '''
    command = type('Command', (object,), {'output': output, 'script': ''})
    assert get_new_command(command) == ('lein run', 'lein repl')

# Generated at 2022-06-24 06:55:09.195830
# Unit test for function match

# Generated at 2022-06-24 06:55:14.292086
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein myproj1', 'myproj1 is not a task. See "lein help".\n\nDid you mean this?\n         myproj')).script == "lein myproj"
    assert get_new_command(Command('lein repl', 'repl is not a task. See "lein help".\n\nDid you mean this?\n   repl-options')).script == "lein repl-options"


# Generated at 2022-06-24 06:55:17.914553
# Unit test for function match
def test_match():
    assert match(Command('lein', output="'test' is not a task. See 'lein help'.\nDid you mean this?\n  test"))
    assert not match(Command('lein', output="'undefined-task' is not a task. See 'lein help'."))
    assert not match(Command('lein', output='lein:command: not found'))


# Generated at 2022-06-24 06:55:23.514326
# Unit test for function match
def test_match():
    command = Command('lein run', 'lein run: "run" is not a task. See "lein help".\nDid you mean this?\n         r2n\n')
    assert not match(command)

    command = Command('lein run', 'lein run: "run" is not a task. See "lein help".\nDid you mean this?\n         run\n')
    assert match(command)


# Generated at 2022-06-24 06:55:32.610844
# Unit test for function get_new_command
def test_get_new_command():
    # lein, recommend task 'uberjar'
    command = type('CommandObject', (), {'script': 'lein uberjar',
        'output': "''uberjar' is not a task. See 'lein help'." 
        "\nDid you mean this?" 
        "\n\t'uberjar'\tRuns the project\'s main method if -main namespaced."
        "\n\t'uberjar-uberwar'\tCreates a deployable uberwar package."
        "\n\t'uberwar'\tCreates a deployable war package."})
    new_command = get_new_command(command)
    assert new_command == 'lein uberjar'

    # lein, recommend task 'jar'

# Generated at 2022-06-24 06:55:38.890950
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command("lein doo", "lein doo is not a task. See 'lein help'\nDid you mean this?\n  do")
        ) == "lein do"

    assert get_new_command(
        Command("lein spec", "lein spec is not a task. See 'lein help'\nDid you mean this?\n  spec-all\n")
        ) == "lein spec-all"

# Generated at 2022-06-24 06:55:45.782350
# Unit test for function match
def test_match():
    assert match(Command('lein repl', stderr='[fuck] is not a task. See \'lein help\'.'))
    assert match(Command('lein run', stderr='[fuck] is not a task. See \'lein help\'.'))
    assert not match(Command('lein run', stderr='[fuck] is not a task. See \'lein help\'.'))
    assert not match(Command('lein [fuck]', stderr='Did you mean this?'))


# Generated at 2022-06-24 06:55:54.890185
# Unit test for function match
def test_match():
    command = type('Command', (), {
        'script': 'lein',
        'output': '\'run\' is not a task. See \'lein help\'.'
    })
    assert match(command)

    command = type('Command', (), {
        'script': 'lein',
        'output': 'Did you mean this? run'
    })
    assert match(command)

    command = type('Command', (), {
        'script': 'lein',
        'output': 'Did you mean this?'
    })
    assert not match(command)

    command = type('Command', (), {
        'script': 'lein',
        'output': 'Did you mean this? run'
    })
    assert not match(command)


# Generated at 2022-06-24 06:55:57.702978
# Unit test for function match
def test_match():
    match_test = match(Command('lein jar --help',
                     'Could not find task \'jar\'.\nDid you mean this?'
                     '\n    uberjar'))
    assert match_test == True


# Generated at 2022-06-24 06:56:00.511776
# Unit test for function match
def test_match():
    assert(match(Command('lein', 'lein help')) == False)
    assert(match(Command('lein test', 'lein help')) == False)
    assert(match(Command('lein test neko', 'lein help')) == False)
    #assert(match(Command('lein test neko', '')) == True)


# Generated at 2022-06-24 06:56:04.251224
# Unit test for function match
def test_match():
    assert match(Command('lein test'))
    assert match(Command('lein test', 'lein:x is not a task. See \'lein help\'.\n\nDid you mean this?\n         test'))
    assert not match(Command('lein', output='lein:x is not a task. See \'lein help\'.\n\nDid you mean this?\n         test'))


# Generated at 2022-06-24 06:56:08.940978
# Unit test for function get_new_command
def test_get_new_command():
    command = {'script': 'lein lien',
               'output': "Command not found: 'lein lien'.\nDid you mean this?\n\tline\n"}
    assert get_new_command(command) == "lein line"


enabled_by_default = True