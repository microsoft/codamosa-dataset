

# Generated at 2022-06-26 06:18:06.043804
# Unit test for function match
def test_match():
    assert match()


# Generated at 2022-06-26 06:18:15.577037
# Unit test for function get_new_command

# Generated at 2022-06-26 06:18:18.017132
# Unit test for function match
def test_match():
    tuple_0 = ()
    var_0 = match(tuple_0)
    assert var_0 == False

# Generated at 2022-06-26 06:18:26.353613
# Unit test for function get_new_command
def test_get_new_command():
    # https://github.com/nvbn/thefuck/issues/953
    tuple_0 = AttributeTuple(script='lein run',
                             output="'run' is not a task. "
                             "See 'lein help'.\nDid you mean this?\nrun-dev",
                             stderr='', stdout='', stdin='')
    var_0 = get_new_command(tuple_0)
    var_1 = Command(script='lein run-dev',
                    stderr='', stdout='', stdin='')

    assert (var_0 == var_1)



# Generated at 2022-06-26 06:18:35.005227
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = match(Command(script="lein aboot",
                          stderr="'aboot' is not a task. See 'lein help'.",
                          stdout="Did you mean this?\n=> about\n",
                          exit_code=1))
    tuple_0 = Command(script="lein aboot",
                      stderr="'aboot' is not a task. See 'lein help'.",
                      stdout="Did you mean this?\n=> about\n",
                      exit_code=1)
    var_1 = replace_command(tuple_0, 'aboot', 'about')
    var_2 = get_new_command(tuple_0)


# Generated at 2022-06-26 06:18:38.880865
# Unit test for function get_new_command
def test_get_new_command():
    exit_status, output = getstatusoutput(
        "lein nonTask; echo $$?")
    assert match(Command('lein nonTask', exit_status, output))
    assert get_new_command(Command('lein nonTask', exit_status, output)) == "lein new"

# Generated at 2022-06-26 06:18:44.635094
# Unit test for function match
def test_match():
    # Case 0: Match Lein version 1.7.1 output
    tuple_0 = ('lein check', 'bin/lein: line 37: lein: command not found')
    value_0 = match(tuple_0)
    assert value_0 == False

    # Case 1: Match Lein version 2.0.0 output
    tuple_1 = ('lein run', None, None, "leiningen.core/run is not a task. See 'lein help'\nDid you mean this?\n         leiningen.core/run-main")
    value_1 = match(tuple_1)
    assert value_1 == True


# Generated at 2022-06-26 06:18:47.570679
# Unit test for function match
def test_match():
    # print(match())  # todo should we use pytest's parametrize?
    pass


# Generated at 2022-06-26 06:18:53.483537
# Unit test for function get_new_command
def test_get_new_command():
    tuple_0 = ()
    tuple_1 = ()
    tuple_2 = ()
    tuple_3 = ()
    tuple_4 = ()
    assert get_new_command(tuple_0) == tuple_1
    assert get_new_command(tuple_2) == tuple_3
    assert get_new_command(tuple_4) == tuple_5


# Generated at 2022-06-26 06:19:04.689602
# Unit test for function match
def test_match():
    tuple_0 = (('lein', '', 'lein: command not found'),)
    var_0 = match(tuple_0)
    assert not var_0

    tuple_1 = ('lein javac', 'lein javac', 'lein javac: task not found\nDid you mean this?\n  rjavac\n  deps\n  jar\n  autotest\n  javac\n  do', 'lein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found\nlein: command not found')
    var_1 = match(tuple_1)
    assert var_1

    tuple_

# Generated at 2022-06-26 06:19:11.006518
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
    `lein javac` is not a task. See 'lein help'.
    Did you mean this?
    '''
    command = Command('lein javac', output=output)
    assert get_new_command(command) == "lein help"

# Generated at 2022-06-26 06:19:16.948447
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\nlein: foo is not a task. See \'lein help\'.'))
    assert match(Command('lein foo', 'lein foo\nlein: foo is not a task. See \'lein help\'.')) is False


# Generated at 2022-06-26 06:19:21.272903
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('lein hellorld', '''Could not find task 'hellorld' in project
Did you mean this?
    hello
    help
    hellorld''')

    new_command = get_new_command(command)

    assert new_command == 'lein hello'

# Generated at 2022-06-26 06:19:31.091364
# Unit test for function match
def test_match():
    assert match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n        foo\n        food'))
    assert not match(Command('lein foo', 'lein foo\n"foo" is not a task. See \'lein help\''))
    assert not match(Command('echo foo', 'echo foo\n"foo" is not a task. See \'lein help\'.\nDid you mean this?\n        foo\n        food'))


# Generated at 2022-06-26 06:19:38.856077
# Unit test for function match
def test_match():
    assert match(Command("lein build",'lein:task: jar is not a task. See "lein help".\nDid you mean this?\n         jar'))
    assert not match(Command("lein build", 'lein:task: build is not a task. See "lein help".\nDid you mean this?\n         jar'))


# Generated at 2022-06-26 06:19:42.980597
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    output = "Could not find task '"
    output += "C-c C-h"
    output += "' anywhere in project"
    output += "Did you mean this?"
    output += "C-c C-c"

    assert get_new_command(
        Command('lein hoge', output)) == 'lein hoge C-c C-c'

# Generated at 2022-06-26 06:19:53.837928
# Unit test for function get_new_command
def test_get_new_command():
    # Function replace_command only accept <str>, although command is an object
    # in reality. But this is OK since this test only focus on get_new_command
    old_command = 'lein help'
    new_command = 'lein'

    # Test1
    output = "Could not find task 'help'.\nDid you mean this?\nlein"
    command = type('', (), {'script': old_command, 'output': output})
    assert get_new_command(command) == new_command

    # Test2
    output = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    command = type('', (), {'script': old_command, 'output': output})
    assert get_new_command(command) == new_command

    # Test3

# Generated at 2022-06-26 06:19:58.446898
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('lein new hello-world',
                                 """This task is not available.
                                 Did you mean this?
                                     new (Create project skeleton)""")) == 'lein new hello-world'

# Generated at 2022-06-26 06:20:06.070495
# Unit test for function get_new_command
def test_get_new_command():
    # Test for simple case
    command = type('obj', (object,),
                   {'script': 'lein run',
                    'output': "'run' is not a task. See 'lein help'\nDid you mean this?\n  run-all"})
    assert get_new_command(command) == 'lein run-all'
    # Test for case with sudo
    command = type('obj', (object,),
                   {'script': 'lein run',
                    'output': "'run' is not a task. See 'lein help'\nDid you mean this?\n  run-all",
                    'sudo': True})
    assert get_new_command(command) == 'sudo lein run-all'

# Generated at 2022-06-26 06:20:11.810850
# Unit test for function match
def test_match():
    assert match(Command('lein foo',
                         '"foo" is not a task. See \'lein help\'.\n\nDid you mean this?\n         foo-bar'))

    assert not match(Command('lein foo', '"foo" is not a task'))

    assert not match(Command('not lein foo', '"foo" is not a task'))


# Generated at 2022-06-26 06:20:18.130912
# Unit test for function match
def test_match():
    assert True == match(type(str(), (), {'script': '', 'output': ''}))
    assert False == match(type(str(), (), {'script': '', 'output': ''}))
    assert False == match(type(str(), (), {'script': '', 'output': ''}))


# Generated at 2022-06-26 06:20:19.774258
# Unit test for function match
def test_match():
    assert match(Command('lein help', "Could not find task 'help'.\nDid you mean this?\nlein"))


# Generated at 2022-06-26 06:20:29.877043
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    str_2 = ''
    var_0 = ()
    str_3 = 'script'
    str_4 = 'output'
    str_5 = {str_3: str_0, str_4: str_1}
    var_1 = type(str_2, var_0, str_5)
    var_2 = match(var_1)
    var_3 = not var_2
    assert var_3


# Generated at 2022-06-26 06:20:39.360678
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nleinh"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = get_new_command(var_1)
    assert var_2 == 'lein leinh'

# Generated at 2022-06-26 06:20:51.371354
# Unit test for function match
def test_match():
    str_1 = 'lein'
    str_0 = 'lein help'
    var_0 = ()
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    var_3 = var_2 is True
    var_4 = var_3 is True
    var_5 = var_4 is True
    str_7 = "Could not find task 'help'.\n"

# Generated at 2022-06-26 06:20:54.638759
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('lein help') == 'lein'
    assert get_new_command('lein') == 'lein'


# Generated at 2022-06-26 06:21:03.515585
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = get_new_command(var_1)

    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    var_3 = ()
    str_8 = {str_4: str_0, str_5: str_7}

# Generated at 2022-06-26 06:21:13.374592
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    var_3 = ()
    str_8 = {str_4: str_0, str_5: str_7}

# Generated at 2022-06-26 06:21:17.747923
# Unit test for function match
def test_match():
    str_0 = "lein"
    str_1 = 'script'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = 'output'
    str_4 = {str_1: str_0, str_3: str_2}
    var_0 = type(str_0, (), str_4)
    var_1 = match(var_0)


# Generated at 2022-06-26 06:21:28.194414
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    assert var_2 == True
    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    var_3 = ()
    str_8 = {str_4: str_0, str_5: str_7}
    var_

# Generated at 2022-06-26 06:21:33.757222
# Unit test for function get_new_command
def test_get_new_command():
    test_case_0()
test_get_new_command()

# Generated at 2022-06-26 06:21:42.705555
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = get_new_command(var_1)
    str_7 = "lein"
    assert var_2 == str_7
    str_8 = 'lein help'
    str_9 = 'lein'
    str_10 = "Could not find task 'help'.\nDid you mean this?\nlein\n"

# Generated at 2022-06-26 06:21:49.512994
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    assert var_2 == True



# Generated at 2022-06-26 06:21:58.417503
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    int_0 = match(var_1)
    var_2 = not int_0
    assert_equals(var_2, False)


# Generated at 2022-06-26 06:22:09.357828
# Unit test for function match
def test_match():
    str_3 = 'lein'
    str_4 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_5 = 'script'
    str_6 = 'output'
    str_7 = {str_5: str_3, str_6: str_4}
    var_1 = type(str_1, var_0, str_7)
    var_2 = match(var_1, str_8)
    assert var_2 == False
    str_8 = 'script'
    str_9 = 'output'
    str_10 = {str_8: str_3, str_9: str_4}
    var_3 = type(str_1, var_0, str_10)
    var_4 = match(var_3, str_11)
    assert var

# Generated at 2022-06-26 06:22:19.919171
# Unit test for function match
def test_match():
    assert not match(type('', (),
                          {'script': 'lein help',
                           'output': 'lein\n'}))
    assert not match(type('', (),
                          {'script': 'lein help',
                           'output': "Could not find task 'help'.\nDid you mean this?\nlein\n"}))
    assert match(type('', (),
                      {'script': 'lein help',
                       'output': "Could not find task 'help'.\nDid you mean this?\nlein\n\n"}))
    assert match(type('', (),
                          {'script': 'lein help',
                           'output': "Could not find task 'help'.\nDid you mean this?\nlein\nlein\n"}))


# Generated at 2022-06-26 06:22:25.770735
# Unit test for function match
def test_match():
    assert match(Command()) == False 
    assert match(Command('', '', '')) == False 
    assert match(Command('', '', '', '')) == False 
    assert match(Command('', '', '', '', '')) == False 



# Generated at 2022-06-26 06:22:26.599274
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-26 06:22:27.891840
# Unit test for function get_new_command
def test_get_new_command():
    test_case_0()

# Generated at 2022-06-26 06:22:31.758916
# Unit test for function match
def test_match():
    input0 = "$ lein help\n$ lein"
    output = match(input0)
    assert output



# Generated at 2022-06-26 06:22:48.820092
# Unit test for function get_new_command
def test_get_new_command():
    try:
        str_0 = 'lein'
        str_1 = 'lein help'
        str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
#        str_3 = ''
        var_0 = ()
        str_4 = 'script'
        str_5 = 'output'
        str_6 = {str_4: str_1, str_5: str_2}
        var_1 = type(str_0, var_0, str_6)
        var_2 = get_new_command(var_1)
        var_3 = str_1 == var_2.script
        var_4 = 'lein'
        assert var_4 == var_2.script
    except AssertionError as e:
        var_5 = e


# Generated at 2022-06-26 06:22:59.312560
# Unit test for function get_new_command
def test_get_new_command():
    var_6 = 'help'
    var_7 = 'lein'
    str_9 = 'Did you mean this?'
    str_10 = "Could not find task '{}'.\n{}\n{}\n".format(var_6, str_9, var_7)
    str_11 = 'script'
    str_12 = 'output'
    str_13 = {str_11: var_7, str_12: str_10}
    var_8 = type('', (), str_13)
    var_9 = get_new_command(var_8)
    str_14 = 'runtest'
    str_15 = 'lein'
    str_16 = "Could not find task '{}'.\n{}\n{}\n".format(str_14, str_9, str_15)
    str

# Generated at 2022-06-26 06:23:06.033955
# Unit test for function match
def test_match():
    var_6 = 'help'
    var_7 = "Could not find task '{}'.\nDid you mean this?\nlein".format(var_6)
    var_8 = ()
    var_9 = 'script'
    var_10 = 'output'
    var_11 = {var_9: var_6, var_10: var_7}
    var_12 = type(var_6, var_8, var_11)
    var_13 = match(var_12)
    assert var_13

# Generated at 2022-06-26 06:23:12.835065
# Unit test for function match
def test_match():
    var_0 = ()
    str_0 = 'script'
    str_1 = 'output'
    str_2 = 'is not a task'
    str_3 = "Did you mean this?\nlein"
    str_4 = {str_0: 'lein\n' + str_2, str_1: str_3}
    var_1 = type('', var_0, str_4)
    var_2 = match(var_1)
    var_3 = ()
    str_5 = 'script'
    str_6 = 'output'
    str_7 = 'is not a task for lein.'
    str_8 = "Did you mean this?\nlein"
    str_9 = {str_5: 'lein\n' + str_7, str_6: str_8}
    var_

# Generated at 2022-06-26 06:23:14.778537
# Unit test for function match
def test_match():
    assert match(get_new_command())


# Generated at 2022-06-26 06:23:21.558998
# Unit test for function match
def test_match():
    var_0 = ('lein' ' ' 'help')
    str_0 = ''
    str_1 = 'script'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = 'output'
    str_4 = {str_1: var_0, str_3: str_2}
    var_1 = type(str_0, (), str_4)
    var_2 = match(var_1)
    var_3 = ()
    str_5 = "Could not find task 'helpp'.\nDid you mean this?\nlein\n"
    str_6 = {str_1: var_0, str_3: str_5}
    var_4 = type(str_0, var_3, str_6)

# Generated at 2022-06-26 06:23:29.333812
# Unit test for function match
def test_match():
    command_str = 'lein help'
    output_str = "Could not find task 'help'.\nDid you mean this?\nlein"
    result_bool = match(create_command(command_str, output_str))
    assert(result_bool == True)
    command_str = 'lein help'
    output_str = "Could not find task 'help'.\n"
    result_bool = match(create_command(command_str, output_str))
    assert(result_bool == False)


# Generated at 2022-06-26 06:23:40.996657
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "'help' is not a task. See 'lein help'"
    str_3 = "Did you mean this?\nlein"
    str_4 = ''
    var_0 = ()
    str_5 = 'script'
    str_6 = 'output'
    str_7 = {str_5: str_1, str_6: str_2 + '\n' + str_3}
    var_1 = type(str_4, var_0, str_7)
    var_2 = match(var_1)
    var_3 = type(str_4, var_0, str_7)
    var_4 = match(var_3)

# Generated at 2022-06-26 06:23:49.385603
# Unit test for function match
def test_match():
    var_6 = ()
    str_9 = 'foo'
    str_10 = 'help'
    str_11 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_12 = ''
    var_7 = ()
    str_13 = 'script'
    str_14 = 'output'
    str_15 = {str_13: str_9, str_14: str_11}
    var_8 = type(str_12, var_7, str_15)
    var_9 = match(var_8)
    assert var_9 == True


# Generated at 2022-06-26 06:23:50.444842
# Unit test for function match
def test_match():
    assert match(var_1) == True
    assert match(var_4) == False



# Generated at 2022-06-26 06:24:05.954776
# Unit test for function get_new_command
def test_get_new_command():
    test_case_0()

# Generated at 2022-06-26 06:24:17.901451
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    assert match(var_1) is True
    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    var_2 = ()
    str_8 = {str_4: str_0, str_5: str_7}

# Generated at 2022-06-26 06:24:27.893847
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    str_7 = 'lein help'
    str_8 = "Could not find task 'help'.\n"
    str_9 = ''
    var_3 = ()
    str_10 = 'script'
    str_11 = 'output'

# Generated at 2022-06-26 06:24:38.179230
# Unit test for function match
def test_match():
    # Invalid args
    if not match('lein help'):
        return False

    # Valid args
    if match(get_new_command(command='lein help')):
        return False

    if not match(get_new_command(command='lein help')):
        return False

    # Invalid args
    if not match('lein'):
        return False

    # Invalid args
    if match('lein'):
        return False

    # Valid args
    if match(get_new_command(command='lein')):
        return False

    if not match(get_new_command(command='lein')):
        return False

    # Invalid args
    if not match('lein help'):
        return False

    # Valid args
    if match(get_new_command(command='lein help')):
        return False


# Generated at 2022-06-26 06:24:39.239870
# Unit test for function match
def test_match():
    assert match(var_1)
    assert not match(var_4)


# Generated at 2022-06-26 06:24:46.896410
# Unit test for function match
def test_match():
    cmd_0 = {'script': 'lein help', 'output': "Could not find task 'help'.\nDid you mean this?\nlein"}
    var_0 = match(cmd_0)
    cmd_1 = {'script': 'lein help', 'output': 'lein is not a task. See "lein help".'}
    var_1 = match(cmd_1)
    cmd_2 = {'script': 'lein help', 'output': "Could not find task 'help'.\nDid you mean this?\nlein\nlein"}
    var_2 = match(cmd_2)
    cmd_3 = {'script': 'lein help', 'output': "Could not find task 'help'.\nDid you mean this?\nlein\nlein\n"}
    var_3 = match(cmd_3)
    cmd_4

# Generated at 2022-06-26 06:24:56.910250
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    var_3 = ()
    str_7 = {str_4: str_0, str_5: str_1}
    var_4 = type(str_3, var_3, str_7)
    var_5 = match(var_4)


# Generated at 2022-06-26 06:25:03.944360
# Unit test for function match
def test_match():
    str_0 = 'lein'
    str_1 = 'lein task'
    str_2 = 'task is not a task. See lein help.'
    str_3 = 'Did you mean this?\nbower'
    str_4 = '%s %s\n%s\n%s' % (str_0, str_1, str_2, str_3)
    var_0 = ()
    str_5 = 'script'
    str_6 = 'output'
    str_7 = {str_5: str_1, str_6: str_4}
    var_1 = type(str_0, var_0, str_7)
    var_2 = match(var_1)
    str_8 = 'lein'
    str_9 = 'lein task'

# Generated at 2022-06-26 06:25:11.819272
# Unit test for function match
def test_match():
    str_0 = 'lein jars'
    str_1 = "lein: 'jars' is not a task. See 'lein help'.\nDid you mean this?\nlein jar"
    str_2 = 'script'
    str_3 = 'output'
    str_4 = {str_2: str_0, str_3: str_1}
    var_0 = type(str_0, (), str_4)
    var_1 = match(var_0)
    assert var_1 == true


# Generated at 2022-06-26 06:25:20.609258
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = get_new_command(var_1)
    str_7 = 'lein'
    var_3 = var_2 == str_7
    var_4 = None
    if not var_3:
        var_4 = False
    else:
        str_8 = 'lein help'

# Generated at 2022-06-26 06:26:04.736049
# Unit test for function match
def test_match():
    var_0 = 'lein help'
    var_1 = 'lein'
    var_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    var_3 = ()
    var_4 = 'script'
    var_5 = 'output'
    var_6 = {var_4: var_0, var_5: var_2}
    var_7 = type(var_0, var_3, var_6)
    var_8 = ()
    var_9 = {}
    var_10 = type(var_0, var_8, var_9)
    var_11 = match(var_10)
    var_12 = match(var_7)
    assert (var_12 == var_11)

# Generated at 2022-06-26 06:26:12.325685
# Unit test for function get_new_command
def test_get_new_command():
    # Replace commands
    # (1) 'lein help' -> 'lein'
    # (2) 'lein' -> None
    test_case_0()



# Generated at 2022-06-26 06:26:21.802644
# Unit test for function match
def test_match():
    str_0 = 'lein'
    str_1 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_2 = ''
    var_0 = ()
    str_3 = 'script'
    str_4 = 'output'
    str_5 = {str_3: str_0, str_4: str_1}
    var_1 = type(str_2, var_0, str_5)
    var_2 = match(var_1)
    var_3 = False
    var_4 = match(var_1)
    var_5 = False
    str_6 = 'lein'
    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_8 = ''
    var_6 = ()
    str_9

# Generated at 2022-06-26 06:26:26.237592
# Unit test for function match
def test_match():
    """
    Unit test for function match
    """
    return match(None)



# Generated at 2022-06-26 06:26:35.050696
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)

    str_7 = 'lein help'
    str_8 = "Could not find task 'help'.\nDid you mean: \nlein\n"
    str_9 = ''
    var_3 = ()
    str_10 = 'script'
    str_11 = 'output'


# Generated at 2022-06-26 06:26:44.317610
# Unit test for function match
def test_match():
    str_0 = 'lein'
    str_1 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_2 = ''
    var_1 = ()
    str_3 = 'script'
    str_4 = 'output'
    str_5 = {str_3: str_0, str_4: str_1}
    var_2 = type(str_2, var_1, str_5)
    var_3 = [str_0, str_1]
    var_4 = match(var_2)
    var_5 = get_new_command(var_2)
    str_6 = 'lein'
    str_7 = "Could not find task 'help'.\nDid you mean this?\nlein\n"
    var_6 = ()
    str_8

# Generated at 2022-06-26 06:26:49.967490
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    var_3 = ()
    str_7 = {str_4: str_0, str_5: str_2}
    var_4 = type(str_3, var_3, str_7)
    var_5 = match(var_4)

# Generated at 2022-06-26 06:26:57.393409
# Unit test for function match
def test_match():
    # Unit: test_case_0
    str_1 = 'lein help'
    str_2 = 'lein'
    str_3 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_4 = ''
    var_0 = ()
    str_5 = 'script'
    str_6 = 'output'
    str_7 = {str_5: str_1, str_6: str_3}
    var_1 = type(str_4, var_0, str_7)
    var_2 = match(var_1)
    assert var_2 == True


# Generated at 2022-06-26 06:27:03.138223
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)



# Generated at 2022-06-26 06:27:11.115591
# Unit test for function match
def test_match():
    str_0 = 'lein help'
    str_1 = 'lein'
    str_2 = "Could not find task 'help'.\nDid you mean this?\nlein"
    str_3 = ''
    var_0 = ()
    str_4 = 'script'
    str_5 = 'output'
    str_6 = {str_4: str_0, str_5: str_2}
    var_1 = type(str_3, var_0, str_6)
    var_2 = match(var_1)
    var_3 = None
    var_4 = ()
    str_7 = {str_4: str_1, str_5: str_2}
    var_5 = type(str_3, var_4, str_7)
    var_6 = match(var_5)