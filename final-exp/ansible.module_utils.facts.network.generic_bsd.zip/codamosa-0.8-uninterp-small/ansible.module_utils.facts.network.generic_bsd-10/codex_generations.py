

# Generated at 2022-06-24 22:40:40.628000
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '  '
    str_1 = '    '
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_1)
    words_0 = None
    current_if_0 = None
    ips_0 = None

# Generated at 2022-06-24 22:40:52.188427
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    '''Test parse_inet_line of GenericBsdIfconfigNetwork'''
    dict_0 = dict()
    dict_0['ipv4'] = []
    dict_0['metric'] = '0'
    dict_0['device'] = 'eth0'
    dict_0['macaddress'] = 'fa:16:3e:97:2d:41'
    dict_0['mtu'] = '1500'
    dict_0['flags'] = ['BROADCAST', 'MULTICAST', 'UP', 'LOWER_UP']
    dict_1 = dict()
    dict_1['network'] = '192.168.1.0'
    dict_1['broadcast'] = '192.168.1.255'
    dict_1['netmask'] = '255.255.255.0'
    dict_

# Generated at 2022-06-24 22:40:59.768713
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '>5'
    generic_bsd_ifconfig_network_0.module = str_0
    str_1 = 'ifconfig -a'
    generic_bsd_ifconfig_network_2 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)
    assert generic_bsd_ifconfig_network_2 is None


# Generated at 2022-06-24 22:41:10.764494
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    dict_0 = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    tup_0 = ('autoselect (none)', )
    str_1 = 'autoselect (none)'
    str_2 = 'autoselect'
    str_3 = ' (none)'
    str_4 = 'none'
    generic_bsd_ifconfig_network_0.parse_media_line(tup_0, dict_0, dict_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(dict_0)
    tup_0 = (str_1, str_2, str_3, str_4)

# Generated at 2022-06-24 22:41:18.714371
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    collected_facts_0 = None
    generic_bsd_ifconfig_network_0.populate(collected_facts_0)
    str_0 = '>5'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    collected_facts_1 = None
    generic_bsd_ifconfig_network_1.populate(collected_facts_1)

if __name__ == "__main__":
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:41:25.932900
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    dict_1 = {'flags': []}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_1)
    list_0 = ['ether', '5', 'other', 'stuff']
    list_1 = ['ether', '01:23:45:67:89:ab', 'other', 'stuff']
    list_2 = ['ether', '01-23-45-67-89-ab', 'other', 'stuff']
    list_3 = ['ether', '0123456789ab', 'other', 'stuff']
    list_4 = ['ether', '01-23-45-67-89-ab', 'other', 'stuff']
    list_5 = ['ether', '01-23-45-67-89-ab', 'other', 'stuff']

# Generated at 2022-06-24 22:41:34.740698
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    interfaces = dict()
    interfaces['a'] = dict()
    interfaces['b'] = dict()
    interfaces['a']['media'] = 'ether'
    interfaces['b']['media'] = 'other'
    generic_bsd_ifconfig_network_0.detect_type_media(interfaces)
    assert_equals(interfaces['a']['type'], 'ether')
    assert_equals(interfaces['b']['type'], 'unknown')


# Generated at 2022-06-24 22:41:44.606443
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '<LOOPBACK,RUNNING,MULTICAST>'
    str_1 = 'inet6 fe80::%lo0 prefixlen 64 scopeid 0x2%lo0'
    list_0 = generic_bsd_ifconfig_network_0.get_options(str_0)
    list_1 = generic_bsd_ifconfig_network_0.get_options(str_1)
    assert list_0 == ['LOOPBACK', 'RUNNING', 'MULTICAST']


# Generated at 2022-06-24 22:41:57.310362
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'N-;!ug5_5'
    str_1 = 'f'
    str_2 = 'w*n\&GJ|d'
    str_3 = '&Fh['
    list_0 = []
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(list_0)

# Generated at 2022-06-24 22:42:03.959288
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # prepare
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    with patch.object(generic_bsd_ifconfig_network_0, 'get_bin_path', autospec=True) as mocked_get_bin:
        mocked_get_bin.return_value = 'a'
        with patch.object(generic_bsd_ifconfig_network_0, 'get_default_interfaces', autospec=True) as mocked_get_default_interfaces:
            mocked_get_default_interfaces.return_value = ('a', 'b')
            with patch.object(generic_bsd_ifconfig_network_0, 'get_interfaces_info', autospec=True) as mocked_get_interfaces_info:
                mocked_get_

# Generated at 2022-06-24 22:42:16.946641
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    dict_0 = {'macaddress': 'unknown'}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = ''
    str_1 = ''
    generic_bsd_ifconfig_network_0.parse_ether_line(str_0, str_1)


# Generated at 2022-06-24 22:42:28.730363
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '>5'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.parse_media_line(['media:', 'Ethernet', '10Gbase-T', '<full-duplex>,', 'rxpause,', 'txpause'], generic_bsd_ifconfig_network_0.current_if, generic_bsd_ifconfig_network_0.ips)

# Generated at 2022-06-24 22:42:33.817347
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    route_path = '/sbin/route'
    generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:42:44.574819
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:42:53.976955
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    dict_0 = None
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = generic_bsd_ifconfig_network_1.ifconfig_path
    print(str_0)
    str_1 = '-a'
    tuple_0 = generic_bsd_ifconfig_network_1.get_interfaces_info(str_0, str_1)
    print(tuple_0)


# Generated at 2022-06-24 22:42:59.140922
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = 'eCSJ4Wm'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    interfaces_0 = {}
    result = generic_bsd_ifconfig_network_1.detect_type_media(interfaces_0)


# Generated at 2022-06-24 22:43:04.602699
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_5['a'] = dict_2
    dict_5['b'] = dict_3
    dict_5['c'] = dict_4
    dict_1['i'] = dict_0
    dict_1['j'] = dict_0
    dict_1['k'] = dict_0
    dict_1['l'] = dict_0
    dict_1['m'] = dict_0
    dict_1['n'] = dict_0
    dict_1['o'] = dict_0
    dict_1['p'] = dict_0
    dict_1['q'] = dict_0
    dict_1['r'] = dict_0
   

# Generated at 2022-06-24 22:43:09.512928
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '>5'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    int_0 = 0
    int_1 = 0
    str_1 = '1'
    str_2 = '1'
    str_3 = '1'


# Generated at 2022-06-24 22:43:17.588928
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = ':'
    str_1 = 'b'
    str_2 = 't'
    # Create an instance of GenericBsdIfconfigNetwork
    # Assume no route details are available
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    # Call the method with a predefined argument
    # Verify the method returns a defined output
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(str_0) == {'interface': None, 'gateway': None}, 'Test failed because expected answer "((None, None))" does not match actual answer "{}".'
    # Call the method with a predefined argument
    # Verify the method returns a defined output
    assert generic_bsd_ifconfig_network_0.get

# Generated at 2022-06-24 22:43:21.439385
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    str_0 = '>5'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    # no actual way to test this without a bunch of mocks


# Generated at 2022-06-24 22:43:45.901578
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # Test case 0
    test_case_0()
    # Test case 1
    dict_0 = {}
    dict_0['platform'] = 'Linux'
    dict_0['path'] = 'path'
    dict_0['ipv4'] = 'ipv4'
    dict_0['ipv6'] = 'ipv6'
    dict_0['default_ipv4'] = 'default_ipv4'
    dict_0['default_ipv6'] = 'default_ipv6'
    dict_0['all_ipv4_addresses'] = 'all_ipv4_addresses'
    dict_0['all_ipv6_addresses'] = 'all_ipv6_addresses'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)

# Generated at 2022-06-24 22:43:52.755748
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    list_0 = [None, None]
    dict_1 = {'ipv6': None}
    dict_2 = {'all_ipv6_addresses': []}
    generic_bsd_ifconfig_network_0.parse_inet6_line(list_0, dict_1, dict_2)


# Generated at 2022-06-24 22:44:03.117504
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    dict_0 = dict()
    dict_0["default_ipv4"] = dict()
    dict_0["default_ipv4"]["interface"] = "unknown"
    dict_0["default_ipv6"] = dict()
    dict_0["default_ipv6"]["interface"] = "unknown"

    dict_1 = dict()
    dict_1["eth0"] = dict()
    dict_1["eth0"]["ipv4"] = list()

    ipv4_0 = dict()
    addr_0 = "192.168.1.1"
    netmask_0 = "255.255.255.0"
    broadcast_0 = "192.168.1.255"
    network_0 = "192.168.0.0"
    ipv4_0["address"] = addr_

# Generated at 2022-06-24 22:44:06.969291
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    generic_bsd_ifconfig_network_0.parse_media_line([], {}.copy(), {}.copy())


# Generated at 2022-06-24 22:44:08.718122
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    defaults_v4, defaults_v6 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    print(defaults_v4)
    print(defaults_v6)


# Generated at 2022-06-24 22:44:19.818511
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 517
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    dict_0 = {"a"}
    dict_1 = {"b"}
    dict_2 = {"c"}
    dict_3 = {"d"}
    dict_4 = {"e"}
    dict_5 = {"f"}
    dict_6 = {"g"}
    dict_7 = {"h"}
    dict_8 = {"i"}
    dict_9 = {"j"}
    dict_10 = {"k"}
    dict_11 = {"l"}
    dict_12 = {"m"}
    dict_13 = {"n"}
    dict_14 = {"o"}
    dict_15 = {"p"}
    dict_16 = {"q"}

# Generated at 2022-06-24 22:44:26.300563
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    r_0 = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = dict()
    ips = dict()
    expected_0 = None
    GenericBsdIfconfigNetwork.parse_media_line((r_0, current_if, ips))
    assert current_if == expected_0


# Generated at 2022-06-24 22:44:37.485378
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)

    # test with right param
    words_0 = ['inet6', 'fe80::a00:27ff:fe4d:78c9%vtnet0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if_0 = {'ipv6': []}
    ips_0 = dict(all_ipv6_addresses=[])
    generic_bsd_ifconfig_network_0.parse_inet6_line(
        words_0,
        current_if_0,
        ips_0)


# Generated at 2022-06-24 22:44:40.245084
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    args = {}
    args['defaults'] = None
    args['interfaces'] = None
    args['ip_type'] = None
    int_0 = 517
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(**args)


# Generated at 2022-06-24 22:44:45.207963
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    print("\n*** test_GenericBsdIfconfigNetwork_detect_type_media() ***")
    int_0 = 517
    dict_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    generic_bsd_ifconfig_network_0.platform = 'FreeBSD'
    interfaces = generic_bsd_ifconfig_network_0.get_interfaces_info("/sbin/ifconfig")[0]
    generic_bsd_ifconfig_network_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(None)

# Generated at 2022-06-24 22:45:08.327321
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:45:12.744909
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    var_0 = {}
    var_0 = {}
    #  Generic BSD ifconfig
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(var_0)
    var_1 = ['']
    var_2 = {}
    var_3 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(var_1, var_2, var_3)


# Generated at 2022-06-24 22:45:17.971104
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var_0 = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(var_0)
    cmd = 'route'
    route_path = generic_bsd_ifconfig_network_0.module.get_bin_path(cmd)
    rc, out, err = generic_bsd_ifconfig_network_0.module.run_command([route_path, '-n', 'get', 'default'])
    var_1 = {}
    var_2 = {}
    var_1, var_2 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:45:22.405117
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    var_1 = {}
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(var_1)
    var_2 = "ifconfig"
    var_3 = "-a"
    generic_bsd_ifconfig_network_1.get_interfaces_info(var_2, var_3)


# Generated at 2022-06-24 22:45:27.652947
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    # set up parameters
    words = ['media','Ethernet','autoselect','(1000baseT)','status:','active']
    current_if = {'device':'en0','ipv4':[],'ipv6':[],'type':'unknown','macaddress':'unknown'}
    ips = {'all_ipv4_addresses':[],'all_ipv6_addresses':[]}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(None)
    assert generic_bsd_ifconfig_network_0 is not None
    assert generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips) == None

    # check that current_if has the expected values
    assert current_if['device'] == 'en0'

# Generated at 2022-06-24 22:45:33.097528
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    var_0 = {}

# Generated at 2022-06-24 22:45:36.495318
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    var_1 = {}
    var_2 = {}
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(var_1)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(var_2)


# Generated at 2022-06-24 22:45:44.277122
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    with patch('platform.system', new=MagicMock(return_value='FreeBSD')):
        with patch.object(Path, 'which', return_value=True):
            with patch.object(BuiltinModule, 'run_command') as mock_run_command:
                mock_run_command.return_value = (0, '', '')
                # Test case with options
                data = {}
                network = GenericBsdIfconfigNetwork(data)
                network.populate()

                # Test case with default options
                data = {}
                network = GenericBsdIfconfigNetwork(data)
                network.populate()



# Generated at 2022-06-24 22:45:47.007513
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var_0 = {}
    obj_0 = GenericBsdIfconfigNetwork(var_0)
    var_1 = obj_0.get_default_interfaces("route_path")
    assertNotEquals(var_1, None)


# Generated at 2022-06-24 22:45:52.869599
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork

    # Method using one arguments(words)
    var_0 = []
    var_1 = "media:"
    var_2 = "Ethernet"
    var_0.append(var_1)
    var_0.append(var_2)

    var_3 = {}
    var_4 = {}
    var_5 = []

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(var_3)
    generic_bsd_ifconfig_network_0.parse_media_line(var_0, var_1, var_2)
    assert (var_1 == "media")
    assert (var_2 == "Ethernet")
    assert (var_3 == var_4)

# Generated at 2022-06-24 22:46:08.442123
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    #var_route_path = {}
    #var_return = GenericBsdIfconfigNetwork.get_default_interfaces(var_route_path)
    #assert var_return == var_expected, 'return is not equal to var_expected'
    pass


# Generated at 2022-06-24 22:46:11.316250
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    obj = GenericBsdIfconfigNetwork({})
    str_1 = 'awesome <fun,stuff>'
    var_0 = obj.get_options(str_1)
    print(var_0)

# Generated at 2022-06-24 22:46:19.342679
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    print("Testing method populate of class GenericBsdIfconfigNetwork")
    var_0 = {}

# Generated at 2022-06-24 22:46:20.025117
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    var_0 = {}


# Generated at 2022-06-24 22:46:23.382804
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    for i in range(0, 5):
        try:
            var_0 = GenericBsdIfconfigNetwork("ansible", "BSD")
            var_1 = "test_string"
            assert var_0.get_options(var_1) == "test_string"
            break
        except AssertionError:
            raise
        except Exception:
            pass


# Generated at 2022-06-24 22:46:27.568861
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    obj = GenericBsdIfconfigNetwork()
    obj.populate()
    var_0 = 'ether'
    obj.detect_type_media(var_0)


# Generated at 2022-06-24 22:46:31.067853
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    instance = GenericBsdIfconfigNetwork()
    ifconfig_path = instance.module.get_bin_path('ifconfig')
    result_var = instance.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 22:46:33.958156
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    fp_0 = GenericBsdIfconfigNetwork(var_0)
    var_1 = {} # Add test here.


# Generated at 2022-06-24 22:46:39.011374
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    var_0 = GenericBsdIfconfigNetwork.get_default_interfaces()
    test_case_0()


# Generated at 2022-06-24 22:46:42.525706
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    var_0 = module_GenericBsdIfconfig.GenericBsdIfconfigNetwork()
    data_1 = {'ansible_NET_OS_VERSION': '11.1'}
    var_0.populate(collected_facts=data_1)


# Generated at 2022-06-24 22:47:07.927583
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
  str_0 = '<:\x8c\x9d\x0c\x1e\x8d\xf7\xa49\x90\xa8\xcek\x14\xa9\xea\x11\x98\x7f\xdf\xd2\x91\r\x9d\xe9?P\xce>|\xd8\x06\xaf'
  bytes_0 = b'a\x9d\x0c\x1e\x8d\xf7\xa49\x90\xa8\xcek\x14\xa9\xea\x11\x98\x7f\xdf\xd2\x91\r\x9d\xe9?P\xce\x04\xf4\x9f\xaf'
  generic_bs

# Generated at 2022-06-24 22:47:18.078022
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = '0\x9f7\xb8\x96\xb6[\x0f\x10\xfa\xbf\xbe\xfc\xb6\x8c\x96\xe3\x11\xba]\x11\xbc\x05\x1a'
    bytes_0 = b'\x85\x14\x1b\xc2\x06\xcd\x02\t\x83\x93\x86\x1d\x04\x8e'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)

# Generated at 2022-06-24 22:47:24.140833
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '^}n7DJrK"r)'
    bytes_0 = b'\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    str_0 = '\xa1\x03\xf5\x83\xdc\x1a\xdd\xca\xa8\x1c\x0bU\xb3\xec\x87\x85\x05'

# Generated at 2022-06-24 22:47:33.461457
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '^}n7DJrK"r)'
    bytes_0 = b'\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    words_0 = ['inet6', '::1', 'prefixlen', '128', 'scopeid', '0x10']
    current_if_0 = {'device': 'wlan0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips_0 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    generic_bsd_ifconfig_

# Generated at 2022-06-24 22:47:39.876978
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    dict_0 = {}
    dict_1 = {}
    str_0 = '^}n7DJrK"r)'
    bytes_0 = b'\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    dict_0 = GenericBsdIfconfigNetwork(str_0, bytes_0).merge_default_interface(dict_0, dict_1, 'ipv4')
    assert (dict_0 == dict_1)


# Generated at 2022-06-24 22:47:46.787283
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
  try:
    test_case_0()
  except:
    print('Exception caught: ')
    import sys
    import traceback
    exc_type, exc_value, exc_traceback = sys.exc_info()
    traceback.print_tb(exc_traceback)
    print(exc_value)

# Boiler plate for call to main()
if __name__ == "__main__":
  test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:47:57.318603
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '^}n7DJrK"r)'
    bytes_0 = b'\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    dict_0 = dict(ipv6=[])
    dict_1 = dict(ipv6=[])
    dict_2 = dict(ipv6=[])
    dict_3 = dict(ipv6=[])
    dict_4 = dict(ipv6=[])
    dict_5 = dict(ipv6=[])
    list_0 = ['a']
    str_1 = '^}n7DJrK"r)'

# Generated at 2022-06-24 22:48:03.691722
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    return_0 = None
    str_0 = '^}n7DJrK"r)'
    bytes_0 = b'\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    return_0 = generic_bsd_ifconfig_network_0.populate()
    return return_0


# Generated at 2022-06-24 22:48:10.905056
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'EbI,M'
    bytes_0 = b'w\xab\xfc\x01\xfe'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:48:17.324548
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '^}n7DJrK"r)'
    str_1 = '\xce\xd7\xf4Y\xfa|\xdb\n\x91\t\xeb\x0b'
    interface_info_tuple = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_1)

# Generated at 2022-06-24 22:48:46.741335
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'E]{p^t'
    bytes_0 = b'\x12\xfe\xa4\xde\x80J'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    return None

# Generated at 2022-06-24 22:48:52.440451
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'r)Dnj`\x1c\x8a\xa5\xc2a\x86\xb0\x9e\xa7\x80\x82'
    bytes_0 = b'\xff\xb7\xd1\xdc\x06\xd9\xad~J\xff\xf6\xc8'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    str_1 = 'B!\xf5"\x89\xe9m\xa1\x92\x0c\x07\x8c\xae:O\x93\xb1'

# Generated at 2022-06-24 22:49:02.381614
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_1 = '*lT\x99\xe4\x96\xde\xca\x93t\x18\x1b\xd6='
    bytes_1 = b'\xa7\x96\xd5\x15\x1b\x7f\x1a\xf6\xff\x9c\xe3\xa3\xbb'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_1, bytes_1)
    defaults_0 = generic_bsd_ifconfig_network_0.defaults
    interfaces_0 = generic_bsd_ifconfig_network_0.interfaces
    ip_type_0 = generic_bsd_ifconfig_network_0.ip_type
    generic_bsd_ifconfig_network_0.merge_

# Generated at 2022-06-24 22:49:14.269102
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:49:22.916972
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    words_0 = ['media:', 'Ethernet', 'autoselect', '(1000baseT<full-duplex>)']
    current_if_0 = {'device': 'lo0', 'ipv4': [{}], 'ipv6': [], 'type': 'loopback', 'options': ['LLINFO', 'LOOPBACK', 'MULTICAST', 'NOARP'], 'metric': '0', 'mtu': '16384', 'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'macaddress': 'unknown'}
    ips_0 = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    GenericBsdIfconfigNetwork.parse_media_line(words_0, current_if_0, ips_0)
    media_0

# Generated at 2022-06-24 22:49:29.307440
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'T,:s\x9e\x83\xb0\xfe'
    bytes_0 = b'\xd4\x7f\x83\xe9\x04\xde\x7f\xed\x88\x0b\xa6J'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    generic_bsd_ifconfig_network_0.get_default_interfaces()
    generic_bsd_ifconfig_network_0.get_interfaces_info()

# Generated at 2022-06-24 22:49:39.594405
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = ';|P#3q>jr!r_'
    bytes_0 = b'\xc7\xe6\xdb\xef\x8a\xaa\xf6\xbe\xac\xbe\xca'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)

# Generated at 2022-06-24 22:49:50.375970
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Note: netbsd show aliases like this
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0.0.1 netmask 0xff000000
    #         inet alias 127.1.1.1 netmask 0xff000000
    str_0 = '127.0.0.1/24'
    words_0 = [str_0]
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes())
    var_0 = generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:49:51.376289
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 22:50:01.434722
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '(.k$%'
    bytes_0 = b'\xa3\xaa\x9d\xb8\xef\xfd'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, bytes_0)
    words_0 = ['Sd', '172.22.152.6', 'netmask', '0xffffc000', 'broadcast', '172.22.159.255']
    current_if = {}
    # ips = dict(
    #     all_ipv4_addresses=[],
    #     all_ipv6_addresses=[],
    # )
    ips = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if, ips)