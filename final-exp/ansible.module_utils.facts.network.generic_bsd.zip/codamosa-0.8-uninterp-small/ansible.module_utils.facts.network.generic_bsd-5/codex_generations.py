

# Generated at 2022-06-24 22:40:58.051960
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    print("Test: detect_type_media")
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(False)

# Generated at 2022-06-24 22:41:04.333857
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:41:10.713679
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    input_0 = ['', '', '']
    input_1 = ''
    input_2 = ''
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    generic_bsd_ifconfig_network_0.get_interfaces_info(input_0, input_1, input_2)


# Generated at 2022-06-24 22:41:17.983334
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    defaults = {}
    interfaces = {}
    ip_type = "ipv4"

    try:

        generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)
        if ip_type == "ipv4"  and 'interface' not in defaults:
            pass
        if ip_type == "ipv6"  and 'interface' not in defaults:
            pass

    except:
        raise


# Generated at 2022-06-24 22:41:25.437236
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:41:34.079321
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print("\n ##### Unit test for get_default_interfaces of class GenericBsdIfconfigNetwork\n")
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    route_path = "/sbin/route"
    ans_0, ans_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)
    print("\n ans_0 = ", ans_0)
    print("\n ans_1 = ", ans_1)
    print("\n\n")


# Generated at 2022-06-24 22:41:45.387041
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Superclass call
    # A set of module scope variables
    global rc
    ifconfig_path = None
    if config['platform'].startswith('FreeBSD'):
        ifconfig_path = module.get_bin_path('ifconfig')
        global rc, out, err
        rc, out, err = module.run_command([ifconfig_path, '-a'])
    else:
        ifconfig_path = module.get_bin_path('ip')
        global rc, out, err
        rc, out, err = module.run_command([ifconfig_path, '-a', '-4'])
    # A set of module scope variables
    global rc
    ifconfig_path = None
    if config['platform'].startswith('FreeBSD'):
        ifconfig_path = module.get_bin_

# Generated at 2022-06-24 22:41:58.022171
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    interface = {}
    ips = {}
    
    words = ['media:', 'Ethernet', '10baseT/UTP', '(auto)'];
    network = GenericBsdIfconfigNetwork(True)
    network.parse_media_line(words, interface, ips)
    assert(interface['media'] == 'Ethernet')
    assert(interface['media_select'] == '10baseT/UTP')
    assert(interface['media_type'] == '(auto)')

    interface = {}
    words = ['media:', 'Ethernet', '10baseT/UTP', '(auto)', 'options=none<RXCSUM>'];
    network.parse_media_line(words, interface, ips)
    assert(interface['media'] == 'Ethernet')

# Generated at 2022-06-24 22:42:04.499760
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []
    assert GenericBsdIfconfigNetwork.get_options("test-string") == []

# Generated at 2022-06-24 22:42:15.121988
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert GenericBsdIfconfigNetwork(False).get_options("<UP,RUNNING,MULTICAST>") == ["UP", "RUNNING", "MULTICAST"]
    assert GenericBsdIfconfigNetwork(False).get_options("UP,RUNNING,MULTICAST") == []
    assert GenericBsdIfconfigNetwork(False).get_options("<>") == []
    assert GenericBsdIfconfigNetwork(False).get_options("") == []
    assert GenericBsdIfconfigNetwork(False).get_options("<UP,RUNNING,MULTICAST") == []
    assert GenericBsdIfconfigNetwork(False).get_options("UP,RUNNING,MULTICAST>") == []

# Generated at 2022-06-24 22:42:35.280228
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Assertions
    # AssertionError: assert isinstance('test-string', str)
    # AssertionError: assert isinstance('test-string', str)
    pass


# Generated at 2022-06-24 22:42:45.181318
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # Test case setup
    str_0 = 'test-string'
    tuple_0 = (
        b'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184\n  options=3<RXCSUM,TXCSUM>\n  inet6 ::1 prefixlen 128\n  inet 127.0.0.1 netmask 0xff000000\n  groups: lo\n  nd6 options=3<PERFORMNUD,ACCEPT_RTADV>\n',
        '',
        0,
    )

# Generated at 2022-06-24 22:42:49.514103
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    obj.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:42:57.159749
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gb_0 = GenericBsdIfconfigNetwork()
    defaults_0 = {'test-key-0': 'test-value-0', 'test-key-1': 'test-value-1'}
    interfaces_0 = {'test-key-0': 'test-value-0'}
    ip_type_0 = str_0
    gb_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0)


# Generated at 2022-06-24 22:43:08.935385
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case where none of the branches runs
    test_object = GenericBsdIfconfigNetwork()
    test_object.module.run_command = MagicMock(return_value=[1,'a','b'])
    test_object.get_default_interfaces = MagicMock(return_value=('a','b'))


# Generated at 2022-06-24 22:43:15.767576
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    gbi_network = GenericBsdIfconfigNetwork()
    str_0 = 'inet alias 127.0.1.1/32 netmask 0xff000000'
    str_1 = 'inet 127.0.1.1'
    str_2 = 'inet 127.0.0.1/32'
    str_3 = 'inet 127.0.1.1 netmask 0xff000000'
    input_words = str_0.split()
    gbi_network.parse_inet_line(input_words, "interfaces", "ips")


# Generated at 2022-06-24 22:43:17.678178
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    args = []
    # No paramaters for this method
    unittest.main()
    # Return type:  bool
    return True


# Generated at 2022-06-24 22:43:21.170303
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = GenericBsdIfconfigNetwork.module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return
    interface_facts = GenericBsdIfconfigNetwork.get_interfaces_info(ifconfig_path)
    assert interface_facts

# Generated at 2022-06-24 22:43:24.555772
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    net_0 = GenericBsdIfconfigNetwork()
    cmd = Cmd()
    cmd.run()
    net_0.module = cmd
    str_0 = 'test-string'
    net_0.get_interfaces_info(str_0, str_0)


# Generated at 2022-06-24 22:43:28.064519
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    intfc = GenericBsdIfconfigNetwork()

    # Test case 0
    test_case_0()

if __name__ == "__main__":
    test_GenericBsdIfconfigNetwork_parse_inet_line()

# Generated at 2022-06-24 22:43:37.210900
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 22:43:47.903463
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = 'lo0'
    list_0 = []
    list_0.append(str_0)
    str_1 = 'UP'
    list_0.append(str_1)
    str_2 = 'LOOPBACK'
    list_0.append(str_2)
    str_3 = 'RUNNING'
    list_0.append(str_3)
    str_4 = 'MULTICAST'
    list_0.append(str_4)

    network_0 = GenericBsdIfconfigNetwork(str_0)
    result = network_0.parse_interface_line(list_0)



# Generated at 2022-06-24 22:43:52.909289
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:44:03.181517
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '\x1d\x1c\xf0\x04g\x97\xd9\x16\x15'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '\x1d\x1c\xf0\x04g\x97\xd9\x16\x15'
    str_2 = '\x1d\x1c\xf0\x04g\x97\xd9\x16\x15'
    dict_0 = dict()
    dict_0[str_0] = dict()
    dict_0[str_0]['ipv4'] = [dict()]
    dict_0[str_0]['ipv4'][0]['address'] = dict()
    dict_0

# Generated at 2022-06-24 22:44:07.749753
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:44:17.124034
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_1 = 'Om7(a)^m_;O$w\x0c'
    str_2 = 'V7]O5M5"b"_Z[g\x1b'
    str_3 = 'h\x0f}E\x1eD8i]{K\x1e'
    str_4 = '^19K'
    str_5 = 'L-}Y'
    str_6 = '[i@\x14'
    int_0 = len(str_5)
    str_7 = ':'
    str_8 = '*p}'
    str_9 = '\x1d'
    str_10 = 'nq(]!_T'
    int_1 = len(str_10)
    int_2 = int_0
    str_11

# Generated at 2022-06-24 22:44:29.655547
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '2I'

# Generated at 2022-06-24 22:44:39.947924
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    line_0 = 'qQ2y+hx@5l0\x7f$0#mZ'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.populate(str_0)
    generic_bsd_ifconfig_network_0.parse_interface_line(str_0)
    # Fixme: Type error: expected str, got list
    # generic_bsd_ifconfig_network_0.get_interfaces_info(str_0)

# Generated at 2022-06-24 22:44:47.751939
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'f+\tOdgfjGefmRJmt'
    str_1 = 'Wy*`Lrq3^Jn16JFx7h'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(str_1)
    var_1 = generic_bsd_ifconfig_network_0.populate(str_1)


# Generated at 2022-06-24 22:44:52.148364
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(str_0)
    if var_0 is None:
        assert False
    else:
        assert True


# Generated at 2022-06-24 22:45:06.688285
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:45:11.076852
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Qw/]gJ@RzE{*cQvM4W~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    print(var_0)

# Generated at 2022-06-24 22:45:14.672511
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'BqgEv[,FtP'
    str_1 = 'a,s;s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.parse_inet6_line([str_0, str_1], str_0, str_0)
    print(str_1)


# Generated at 2022-06-24 22:45:22.076714
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
  str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
  generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
  var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
  assert var_0 is None


# Generated at 2022-06-24 22:45:26.846472
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'I|X'
    str_1 = 'G`8&rk[\r'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)

test_case_0()
test_GenericBsdIfconfigNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:45:33.794574
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    var_0 = generic_bsd_ifconfig_network_0.merge_default_interface(var_0, str_0, str_0)


# Generated at 2022-06-24 22:45:42.889358
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    var_0 = GenericBsdIfconfigNetwork()
    var_1 = ['ASG']
    var_0.parse_interface_line(var_1)
    var_2 = ['A4w']
    var_0.parse_interface_line(var_2)
    var_0.parse_interface_line(var_1)
    var_0.parse_interface_line(var_2)
    var_3 = ['6Uq', '1', '5', 'R6H']
    var_0.parse_interface_line(var_3)

# Run test cases
if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_parse_interface_line()

# Generated at 2022-06-24 22:45:49.749569
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '<wBx1ZL(1R~T.Nr]tb9A'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_0 = 'e0n.kL'
    str_1 = 'neI>'
    str_2 = 'z{'
    str_3 = 'k'
    str_4 = '.'
    str_5 = 'R{'
    str_6 = 'z{'
    str_7 = 'z{'
    generic_bsd_ifconfig_network_0.parse_inet6_line([str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7], 'F', 'n')


# Generated at 2022-06-24 22:45:59.137201
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'R)wjQo-gniCeW_'
    str_1 = 'qj,mw2;I)0vd(#'
    str_2 = 'qp9Ib%&k<=l8HN'
    str_3 = 'cM68pW8"I=x/X9'
    str_4 = '8~V7c%EOdK{Y7b'
    str_5 = '].XKk}#+_|Cp1u'
    str_6 = 'z6,Z+H,,Zk6xJX'
    str_7 = '$UwmjqLg:l:*6H'
    str_8 = '%j6a0U|mHU$Om>'

# Generated at 2022-06-24 22:46:05.991389
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184', 'inet', '127.1.1.1', 'netmask', '0xff000000', 'inet6', '::1', 'prefixlen', '128', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']
    current_if = {'device': 'lo0', 'ipv4': []}
    ips = dict()
    ips['all_ipv4_addresses'] = []

# Generated at 2022-06-24 22:46:24.917574
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'QXz5G'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'RbXGj|m'
    int_0 = 3
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, int_0)


# Generated at 2022-06-24 22:46:29.091321
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(
        str_0)


# Generated at 2022-06-24 22:46:36.509432
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_1 = '0JhY0#+^Bk}[>T2T.@r'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:46:45.000210
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = ''
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_0 = '-a'
    str_1 = '/sbin/ifconfig'
    result = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, str_0)
    assert len(result) == 2
    assert result[0] == {}
    assert result[1] == {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}


# Generated at 2022-06-24 22:46:55.959546
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    print('Testing merge_default_interface')
    program_name = 'GenericBsdIfconfigNetwork'
    program_name = GenericBsdIfconfigNetwork(program_name)

# Generated at 2022-06-24 22:47:06.419204
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'oDnF#\U000ba9b6g'
    str_1 = '<GwV'
    str_2 = '0u3z>H0'
    str_3 = '<GwV'
    str_4 = '0u3z>H0'
    str_5 = '0u3z>H0'
    str_6 = '0u3z>H0'
    str_7 = '0u3z>H0'
    str_8 = '8Nv+GzR#'
    str_9 = '8Nv+GzR#'
    str_10 = '8Nv+GzR#'
    str_11 = 'cHf`'
    str_12 = 'cHf`'

# Generated at 2022-06-24 22:47:14.087987
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    list_0 = [str_0, str_0, str_0]
    dict_0 = {}
    dict_1 = {}
    dict_0.update(dict_1)
    generic_bsd_ifconfig_network_0.parse_inet_line(list_0, dict_0, dict_0)


# Generated at 2022-06-24 22:47:20.236536
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Z8r=0]1f"'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:47:31.674387
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    input0_0 = ['2600:3c03::f03c:91ff:fe96:6a4f', 'inet6', 'prefix', '64']
    input0_1 = []
    input0_2 = []
    expected_result_0 = {'address': '2600:3c03::f03c:91ff:fe96:6a4f', 'prefix': '64'}

    ipv6_list = []

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_0.parse_inet6_line(input0_0, input0_1, ipv6_list)
    assert expected_result_0 == ipv6_list[0]


# Generated at 2022-06-24 22:47:34.889114
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    try:
        assert True
    except:
        u.logger.info(traceback.format_exc())
        assert False


# Generated at 2022-06-24 22:47:53.712793
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'GDW`CXuV7x'

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    str_1 = 'GDW`CXuV7x'

    str_2 = 'F`U_'

    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_2['device'] = 'ljKi'
    dict_2['mtu'] = 'Y~t~G'
    dict_2['macaddress'] = 'i^B'
    dict_2['type'] = 'YF'
    dict_2['flags'] = ['g', 'p', '`9&']

# Generated at 2022-06-24 22:48:03.845815
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test case 0
    # Populate the needed arguments
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '3Us*pX8j'
    words_0 = [str_1]

    # Assigning argument 'words' to 'words_0'
    kwargs_0 = {}
    kwargs_0['words'] = words_0

    # Assigning argument 'current_if' to 'current_if_0'
    kwargs_0['current_if'] = None

    # Assigning argument 'ips' to 'ips_0'
    kwargs_0['ips'] = None


# Generated at 2022-06-24 22:48:09.064487
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'nqn<a.$Q1H!*h!UU%%0'
    str_1 = '"b#%cgY7fWGp8-vE9"s'
    dict_0 = {str_0: {str_1: str_1}}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.detect_type_media(dict_0)


# Generated at 2022-06-24 22:48:18.119141
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_2 = '+_IHJ&*n?g~7f{'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network_2.parse_inet6_line(words, current_if, ips)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_parse_inet6_line()

# Generated at 2022-06-24 22:48:22.170037
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Fo~%#NrtsYDUrmaM!b$.'
    str_1 = 'C=o/@tE7n.Y.1yb$mD.C'
    dict_0 = {str_0:str_1}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(str_0, dict_0, str_1)


# Generated at 2022-06-24 22:48:31.574545
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5hggv5JQ:}MD!H'
    str_1 = '0WE0QtLz$tH'
    str_2 = '<PC0aagl{p|'
    str_3 = '9V7Tkx'
    str_4 = '4IC:R7'
    str_5 = 'dHya'
    str_6 = '&jP'
    str_7 = ':FwGuD'
    str_8 = '$V7T'
    str_9 = 'dHya'
    str_10 = '&jP'
    str_11 = ':Fw?bD'
    str_12 = '$V7T'
    str_13 = 'dHya'
    str_14 = '&jP'


# Generated at 2022-06-24 22:48:41.171628
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    list_0 = ['HHCd8~7bmK7Tf3"2dgh.', '127.0.0.1', 'netmask', '0xff000000']
    list_1 = ['HHCd8~7bmK7Tf3"2dgh.', '127.0.0.1', 'netmask', '0xff000000']
    list_2 = ['HHCd8~7bmK7Tf3"2dgh.', '127.0.0.1', 'netmask', '0xff000000']
    str_1 = '0xff000000'
    str_2 = 'Mzc0LjI0Mi42Mi4y'

# Generated at 2022-06-24 22:48:49.591824
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'W*KfGNv+T}G7V,g_KG'
    str_1 = '-fQ1a>8Jq"b@}e&p'
    str_2 = 'qE#:>S#pS'
    str_3 = "R'eM4&4@w2f]O+"
    str_4 = '>Y'
    str_5 = 'HHCd8~7bmK7Tf3"2dgh.'
    str_6 = 'Gj|P8/E'
    module_0 = AnsibleModule(str_0, str_1)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_2)
    var_0 = module_0.get_bin_path(str_3)

# Generated at 2022-06-24 22:48:53.558786
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '"S7SdGVn8fv7Yy2c'
    generic_bsd__network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '"S7SdGVn8fv7Yy2c'
    str_2 = '"S7SdGVn8fv7Yy2c'
    var_0 = generic_bsd__network_0.get_interfaces_info(str_1, str_2)
    assert ((var_0 == [{}, {}]), 'Incorrect return value')


# Generated at 2022-06-24 22:48:59.981851
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_1 = 'v$Zq]w{zLUu@Q:4\x7fq'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.populate(str_1)
    assert var_1 == None


# Generated at 2022-06-24 22:49:18.531970
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    try:
        str_0 = ''
        generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
        str_1 = ''
        str_2 = ''
        var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, str_2)
    except RuntimeError as runtimeError_inst:
        print('Exception in test_GenericBsdIfconfigNetwork_get_interfaces_info ', runtimeError_inst.args)
        raise

# Generated at 2022-06-24 22:49:26.409079
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'wx/gIaJy'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '|@#tJ;A9Xbkd1R_'
    str_2 = 'l?hJf{G'
    dict_0 = {}
    dict_1 = {}
    dict_1['r5x6#J"wQP'] = dict_0
    dict_2 = {}
    dict_1['HHCd8~7bmK7Tf3"2dgh.'] = dict_2
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_1, dict_0, str_1)
    assert(dict_1 != {})
    assert(dict_0 != {})

# Generated at 2022-06-24 22:49:35.154060
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network_0 = GenericBsdIfconfigNetwork(None)
    str_0 = 'TnTETd6"~&b$a"~jdY!e8'
    var_0 = network_0.populate(str_0)
    assert var_0 == None
    var_1 = network_0.populate()
    assert set([str_0,str_0]) == set([str_0,var_1])
    var_2 = network_0.populate(str_0)
    assert None == var_1
    assert var_0 == var_2

# Generated at 2022-06-24 22:49:44.364546
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import os
    import json
    import subprocess
    import sys
    import tempfile
    import unittest
    import urllib
    import pytest
    import ansible.module_utils.basic
    import ansible.module_utils.facts.network.base
    import ansible.module_utils.facts.network.generic_bsd_ifconfig
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import get_default_interfaces
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import test_case_0

# Generated at 2022-06-24 22:49:54.179549
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    v_0 = ['1.2.3.4', 'netmask', '255.255.255.254']
    v_0.append('broadcast')
    v_0.append('1.2.3.5')
    v_0.append('8:0:27:a6:53:6e')
    v_0.append('media:')
    v_0.append('Ethernet')
    v_0.append('autoselect')
    v_0.append('status:')
    v_0.append('active')
    v_1 = []
    v_2 = {}
    gb = GenericBsdIfconfigNetwork('')
    v_0, v_1, v_2 = gb.parse_inet_line(v_0, v_1, v_2)

# Unit

# Generated at 2022-06-24 22:50:00.831601
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'HHCd8~7bmK7Tf3"2dgh.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # Call the method with a known argument
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
