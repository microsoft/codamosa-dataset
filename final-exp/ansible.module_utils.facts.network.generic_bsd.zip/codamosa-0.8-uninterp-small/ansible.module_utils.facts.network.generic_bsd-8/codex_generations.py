

# Generated at 2022-06-24 22:40:37.085406
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Initializing instance of class GenericBsdIfconfigNetwork
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    # Initializing list words
    words = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']

    # Initializing list words_1
    words_1 = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']

    # Initializing dictionary current_if

# Generated at 2022-06-24 22:40:38.079299
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    pass



# Generated at 2022-06-24 22:40:48.611564
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    words = ['lo0',
             'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>',
             'metric',
             '0',
             'mtu',
             '33184']

    result = generic_bsd_ifconfig_network_0.parse_interface_line(words)

    assert result['device'] == 'lo0'
    assert result['flags'] == ['UP',
                               'LOOPBACK',
                               'RUNNING',
                               'MULTICAST']
    assert result['metric'] == '0'
    assert result['mtu'] == '33184'
    assert result['macaddress'] == 'unknown'

# Generated at 2022-06-24 22:40:57.239374
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    media_words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {'device': 'test_iface', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    generic_bsd_ifconfig_network_0.parse_media_line(media_words, current_if, ips)
    if current_if['media'] == 'Ethernet':
        pass

# Generated at 2022-06-24 22:41:05.534708
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_0 = {'address': 'test_address_0'}
    test_1 = {'address': 'test_address_0'}
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    # Localhost6 is a list
    localhost6 = ['::1', '::1/128', 'fe80::1%lo0']
    # localhost6.append('test_address_0')
    # ips['all_ipv6_addresses'].append(address['address'])
    # current_if['ipv6'].append(address)
    words = ['test_word_0', 'test_address_0']

# Generated at 2022-06-24 22:41:14.410130
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    route_path_0 = '/sbin/route'
    latency_0 = None
    return_value_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    if isinstance(return_value_0, (tuple, list, set)):
        return_value_0 = list(return_value_0)
        return_value_0[0]
    else:
        return_value_0
    return_value_0[1]


# Generated at 2022-06-24 22:41:18.814395
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    with patch.object(module.AnsibleModule, 'run_command') as mock_run_command:
        with patch.object(module.AnsibleModule, 'get_bin_path') as mock_get_bin_path:
            mock_get_bin_path.return_value = '/sbin/route'
            mock_run_command.return_value = (0, "default via 192.168.122.1 dev enp0s3  proto dhcp  metric 100\n", "")
            GenericBsdIfconfigNetwork.populate()
            assert mock_get_bin_path.called == 1
            assert mock_run_command.called == 1

# Generated at 2022-06-24 22:41:23.429685
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    dict_0 = dict()
    dict_0['a'] = dict()
    dict_0['a']['media'] = 'Ethernet'
    dict_0['a']['type'] = 'unknown'
    dict_0['b'] = dict()
    dict_0['b']['media'] = 'Ethernet autoselect'
    dict_0['b']['type'] = 'unknown'
    dict_0['c'] = dict()
    dict_0['c']['type'] = 'unknown'

    ret_0 = generic_bsd_ifconfig_network_0.detect_type_media(dict_0)

    dict_1 = dict()
    dict

# Generated at 2022-06-24 22:41:25.252278
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # GenericBsdIfconfigNetwork.merge_default_interface()
    assert 'merge_default_interface' in dir(GenericBsdIfconfigNetwork)


# Generated at 2022-06-24 22:41:27.968967
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 3800
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    result = False
    try:
        generic_bsd_ifconfig_network_0.populate()
        result = True
    except NameError:
        pass

    assert result is True


# Generated at 2022-06-24 22:41:44.742082
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:41:57.450335
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

    # Test with command:
    #    route -n get default
    #    route -n get -inet6 default
    # to find out the default outgoing interface, address, and gateway

    # Setup command and expected result
    cmd_0 = ['/usr/bin/route', '-n', 'get', 'default']
    cmd_1 = ['/usr/bin/route', '-n', 'get', '-inet6', 'default']
    interface_0 = {'interface': 'lo0', 'gateway': '127.0.0.1'}
    interface_1 = {'interface': 'lo0', 'gateway': '::1'}

# Generated at 2022-06-24 22:42:04.047921
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:42:11.376472
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_1 = ()
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(tuple_1)
    var_1 = generic_bsd_ifconfig_network_1.populate()
    assert var_1 == 'None'


# Generated at 2022-06-24 22:42:15.749841
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    interfaces = {}
    assert generic_bsd_ifconfig_network_0.detect_type_media(interfaces) == {}, "'detect_type_media' did not return as expected"


# Generated at 2022-06-24 22:42:27.621906
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    if (True):
        tuple_0 = ()
        generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

# Generated at 2022-06-24 22:42:28.527277
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-24 22:42:37.133874
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    words_0 = ["inet6"]
    current_if_0 = dict()
    ips_0 = dict()
    var_0 = generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_parse_inet6_line()

# Generated at 2022-06-24 22:42:38.582594
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pass


# Generated at 2022-06-24 22:42:46.193438
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['interface'] = 'br0'
    dict_0['metric'] = '256'
    dict_0['gateway'] = '192.168.1.1'
    dict_0['mtu'] = '1500'
    dict_1[dict_0['interface']] = dict_0
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_1, 'ipv4')
    print(dict_1)


# Generated at 2022-06-24 22:43:17.106284
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

    # This function takes the following arguments:
    # defaults, interfaces, ip_type
    merge_default_interface_args = (deflocals(), deflocals(), "ip_type")
    merge_default_interface_args[0]["defaults"]["interface"] = "/dev/null"
    merge_default_interface_args[0]["defaults"]["address"] = "000.000.000.000"

# Generated at 2022-06-24 22:43:25.225101
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    # !TODO: Create a mock object of class CommandModule, type: AnsibleModule
    ansible_module_0 = None
    # !TODO: Create a mock object of class CommandModule, type: CommandModule
    command_module_0 = None
    str_0 = command_module_0.get_bin_path('route')
    command_0 = ['route', '-n', 'get', 'default']
    command_1 = ['route', '-n', 'get', '-inet6', 'default']
    tuple_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    # !TODO: Determine a way to

# Generated at 2022-06-24 22:43:30.278741
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    current_if = dict()
    ips = dict()
    words = ['inet','127.0.0.1','netmask','0xff000000']
    generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-24 22:43:35.723485
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:43:38.411004
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:43:44.265819
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    dict_0 = {}
    dict_1 = {}
    str_0 = ''
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_1, str_0)
    var_0 = generic_bsd_ifconfig_network_0.platform
    var_1 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:43:54.477197
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    words = ['ether', 'unknown']
    current_if = {'macaddress': 'unknown', 'type': 'unknown', 'device': 'em0'}
    ips = {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}
    generic_bsd_ifconfig_network_0.parse_ether_line(words, current_if, ips)
    var_0 = current_if['macaddress']
    var_1 = current_if['type']
    assert var_0 == 'unknown'
    assert var_1 == 'ether'


# Generated at 2022-06-24 22:44:02.373475
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    ifconfig_path = '/usr/bin/ifconfig'
    ifconfig_options = '-a'
    # Call the method with a known argument
    result_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert result_0 != None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:44:07.630040
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = get_binary_path_0()
    result_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(var_0)
    assert result_0[0] == {}
    assert result_0[1] == {}


# Generated at 2022-06-24 22:44:14.977041
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    route_path_0 = "p.O;CMF?;_D4oF(LIh3q"
    with mock.patch('anvil.util.test_helpers.run_command', return_value=(0, '', '')):
        result_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    assert result_0 == ({}, {})


# Generated at 2022-06-24 22:44:40.437399
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    words_0 = list()
    words_0.append('inet')
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)
    print(current_if_0)
    print(ips_0)

# Generated at 2022-06-24 22:44:43.609943
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    list_0 = []
    tuple_1 = (list_0, list_0)
    output = generic_bsd_ifconfig_network_0.get_default_interfaces(list_0)
    assert output == tuple_1


# Generated at 2022-06-24 22:44:49.414078
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info('ifconfig', '-a')


# Generated at 2022-06-24 22:44:54.699664
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    def_ip_type = 'ipv4'
    default_ip_info = {'interface':'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address':'127.0.0.1'}], 'type':'loopback', 'device':'lo0'}}
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_1.merge_default_interface(default_ip_info, interfaces, def_ip_type)


# Generated at 2022-06-24 22:45:05.230441
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    defaults = {'interface': 'lo0'}

# Generated at 2022-06-24 22:45:12.614681
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    words = 'inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2 inet6 ::1 prefixlen 128 inet6 ::ffff:0.0.0.0 prefixlen 96 inet6 2a01:e35:8b7f:c530:3d3:d9f9:dc57:52e0 prefixlen 64'
    words = words.split(' ')
    words = ['test_interface'] + words
    current_if = {'device': words[0][0:-1], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-24 22:45:18.928167
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

    #
    # Test with ifconfig_path = None
    #
    param_0 = None
    param_1 = None
    tuple_ret_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(param_0, param_1)
    assert len(tuple_ret_0) == 0

    #
    # Test with ifconfig_path = '/sbin/ifconfig' and ifconfig_options = None
    #
    param_0 = '/sbin/ifconfig'
    param_1 = None
    tuple_ret_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(param_0, param_1)
   

# Generated at 2022-06-24 22:45:27.372837
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    os.system("cp test/unit/data/platform/bsd/ifconfig_interfaces.txt test/unit/data/platform/bsd/ifconfig_interfaces.txt.orig")
    os.system("cp test/unit/data/platform/bsd/ifconfig_interfaces_sample.txt test/unit/data/platform/bsd/ifconfig_interfaces.txt")

    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

    ifconfig_path = "test/unit/data/platform/bsd/ifconfig_interfaces.txt"
    interfaces_info = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path)
    # The eth0 interface must have the following ip addresses
    #  192

# Generated at 2022-06-24 22:45:36.620484
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)

    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {}}

    # Test with ip_type == 'ipv4'
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)

    # Test with ip_type == 'ipv6'
    ip_type = 'ipv6'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:45:41.369433
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    str_0 = '/bin/route'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:46:11.013365
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    words_0 = ['lo0', 'inet', '10.0.2.15', 'netmask', '0xffffff00', 'broadcast', '10.0.2.255', 'nd6', 'options=1<PERFORMNUD>']

# Generated at 2022-06-24 22:46:15.419238
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')

    generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-24 22:46:24.556881
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    str_0 = 'ifconfig'
    str_1 = ''
    tuple_1 = ()
    tuple_1 = (str_0, str_1)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(tuple_1)


# Generated at 2022-06-24 22:46:34.318780
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    str_0 = "ifconfig"
    str_1 = "-a"
    tuple_1 = (str_0, str_1)
    tuple_2 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_1)
    assert type(tuple_2) == tuple
    assert len(tuple_2) == 2
    assert type(tuple_2[0]) == dict
    assert type(tuple_2[1]) == dict
    assert len(tuple_2[0]) == 0
    assert len(tuple_2[1]) == 2
    assert 'all_ipv4_addresses' in tuple_2[1]

# Generated at 2022-06-24 22:46:40.804407
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_1 = (None,)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(tuple_1)
    var_1 = generic_bsd_ifconfig_network_1.populate()
    assert isinstance(var_1, dict)
    assert var_1 == {}


# Generated at 2022-06-24 22:46:49.579836
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    _system_vars = ('ansible_architecture', 'ansible_bios_date', 'ansible_bios_version', 'ansible_machine', 'ansible_machine_id', 'ansible_product_name', 'ansible_system', 'ansible_system_vendor', 'ansible_system_uuid')


# Generated at 2022-06-24 22:46:54.664938
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # instantiate the object
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    tuple_1 = ()
    # call the method with a known good argument
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(tuple_1)


# Generated at 2022-06-24 22:47:03.702708
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    defaults_0 = "defaults_0"
    interfaces_0 = {'interfaces_0': "interfaces_0"}
    ip_type_0 = "ip_type_0"
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0)


# Generated at 2022-06-24 22:47:11.628406
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet']
    generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Ethernet'


# Generated at 2022-06-24 22:47:15.847863
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    route_path = '/usr/sbin/route'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)
    assert var_0[0] == {}
    assert var_0[1] == {}


# Generated at 2022-06-24 22:47:45.919444
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
	tuple_0 = ()
	generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
	current_if_1 = dict()
	current_if_1['ipv6'] = [dict()]
	ips_1 = dict()
	ips_1['all_ipv6_addresses'] = ['']
	generic_bsd_ifconfig_network_0.parse_inet6_line(['', '', '', ''], current_if_1, ips_1)


# Generated at 2022-06-24 22:47:51.833863
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    # Put arguments for method get_interfaces_info here
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info("ifconfig_path")
    assert var_0


# Generated at 2022-06-24 22:48:02.214089
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    my_path = get_path_from_file(__file__)
    tuple_0 = (None, 'route', ['/usr/sbin/route', '-n', 'get', 'default', '-inet6'], 'stdout')
    tuple_1 = (None, 'route', ['/usr/sbin/route', '-n', 'get', 'default'], 'stdout')
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0, var_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(tuple_1)


if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_get_default_interfaces()
    # test_case_0()

# Generated at 2022-06-24 22:48:11.216622
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    # get route path
    # route_path = generic_bsd_ifconfig_network_0.module.get_bin_path('route')

    # call get_default_interfaces with route path
    generic_bsd_ifconfig_network_0.get_default_interfaces('route')


# Generated at 2022-06-24 22:48:22.446235
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()

    var_1 = dict()
    var_2 = dict()
    var_2['type'] = 'unknown'
    var_2['device'] = 'lo0'
    var_2['macaddress'] = 'unknown'

# Generated at 2022-06-24 22:48:26.580951
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    assert var_0


# Generated at 2022-06-24 22:48:30.537574
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    a_class_0 = GenericBsdIfconfigNetwork((),)
    a_class_0.as_v4 = -1
    tuple_0 = ('route',)
    var_0 = a_class_0.get_default_interfaces(tuple_0)
    assert var_0 == ({}, {})


# Generated at 2022-06-24 22:48:35.936536
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    retval = GenericBsdIfconfigNetwork.get_interfaces_info('/sbin/ifconfig')
    print(retval)

if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:48:47.370322
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return
    route_path = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
    if route_path is None:
        return

    default_ipv4, default_ipv6 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)
    interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 22:48:57.151998
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    ifconfig_path_0 = '/sbin/ifconfig'
    ifconfig_options_0 = '-a'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)

# Generated at 2022-06-24 22:49:36.681614
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    with pytest.warns(DeprecationWarning):
        generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:49:42.652760
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    str_0 = generic_bsd_ifconfig_network_0.get_bin_path('ifconfig')
    tuple_1 = (str_0, '-a')
    dict_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(*tuple_1)
    print(dict_0)


# Generated at 2022-06-24 22:49:44.870419
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    pass # TODO: implement your test here if you want to test the code you've written


# Generated at 2022-06-24 22:49:48.247128
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    try:
        test_case_0()
    except Exception as error:
        print(error)
        raise AssertionError("An error has occured in the test_populate method")

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-24 22:49:59.763179
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from os.path import dirname
    from os.path import join
    from os.path import abspath
    from os import chdir
    from sys import path

    test_file_directory = dirname(abspath(__file__))
    test_data_directory = join(test_file_directory, 'data')

    test_modules_directory = join(test_file_directory, '..', '..', '..', '..', 'test', 'units', 'modules', 'network')
    chdir(test_modules_directory)

    path.insert(0, test_modules_directory)

    # Move back to original test file path
    chdir(test_file_directory)
    tuple_0 = ()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(tuple_0)
    ifconfig