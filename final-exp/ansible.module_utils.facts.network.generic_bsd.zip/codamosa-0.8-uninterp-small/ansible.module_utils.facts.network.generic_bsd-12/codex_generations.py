

# Generated at 2022-06-24 22:40:35.779893
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    list_0 = ['media:', 'Ethernet', 'autoselect', 'status:', 'active']
    dict_0 = {}
    dict_1 = {}
    # contents: variable 'current_if' of type 'dict', which is not a dictionary
    #assert_raises(TypeError, generic_bsd_ifconfig_network_0.parse_media_line, list_0, dict_0, ips=dict_1)

    pass


# Generated at 2022-06-24 22:40:38.903827
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    list_1 = []
    generic_bsd_ifconfig_network_0.populate(list_1)
    words_0 = []
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:40:49.388479
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    str_1 = 'types'
    list_1 = None
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, list_1)
    str_2 = 'types'
    list_2 = None
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2, list_2)
    str_3 = 'types'
    list_3 = None
    generic_bsd_ifconfig_network_3 = GenericBsdIfconfigNetwork(str_3, list_3)
    dict_0 = dict()
    dict_0['default_ipv4']

# Generated at 2022-06-24 22:40:54.364582
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    str_1 = 'route'
    result = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    print('result: ' + str(result))


# Generated at 2022-06-24 22:40:59.507098
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    arg_0 = 'option_string'
    option_string = 'option_string'
    arg_1 = 'option_string'
    option_string = 'option_string'
    arg_2 = 'option_string'
    option_string = 'option_string'

    # Call the method to test
    try:
        GenericBsdIfconfigNetwork.get_options(option_string)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 22:41:10.741229
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    

# Generated at 2022-06-24 22:41:16.499181
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # get the path to the ifconfig program
    ifconfig_path = module_finder.get_bin_path('ifconfig')
    if not ifconfig_path:
        # the ifconfig command is not installed
        return

    default_ifconfig_options = '-a'

    if 'FreeBSD' in platform.dist() or 'DragonFly' in platform.dist():
        # FreeBSD's ifconfig does not take options as arguments, but does
        # take ifconfig -e to show interface aliases
        freebsd_ifconfig_options = '-e'
    elif 'SunOS' in platform.system():
        # Solaris ifconfig -a does not show interface aliases.
        # Solaris ifconfig -e shows aliases
        freebsd_ifconfig_options = '-e'

# Generated at 2022-06-24 22:41:21.233831
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    str_1 = 'path'
    ret_val_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    assert ret_val_0 == {}


# Generated at 2022-06-24 22:41:25.744624
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    assert_equal(generic_bsd_ifconfig_network_0.populate(), {})


# Generated at 2022-06-24 22:41:34.357122
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'types'
    list_0 = None
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, list_0)
    str_1 = 'ifconfig_path'
    str_2 = 'ifconfig_options'
    tuple_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, str_2)
    str_3 = 'tuple_0'
    str_4 = str(tuple_0)
    print(str_3, str_4)


# Generated at 2022-06-24 22:42:12.464273
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    input_str_0 = 'types'
    # Call method get_default_interfaces and print it for debugging purposes

# Generated at 2022-06-24 22:42:24.467718
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    str_2 = '<UP,LOOPBACK> up'
    str_3 = ''
    # Run method without arguments
    # Run method with arguments
    str_4 = generic_bsd_ifconfig_network_0.get_options(str_1)
    str_5 = generic_bsd_ifconfig_network_0.get_options(str_2)
    str_6 = generic_bsd_ifconfig_network_0.get_options(str_3)

# Generated at 2022-06-24 22:42:34.561886
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    str_1 = 'media'
    str_2 = 'z4c'
    str_3 = 'zlm'
    str_4 = 'zwh'
    list_0 = [str_1, str_2, str_3, str_4]

# Generated at 2022-06-24 22:42:40.095241
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    dict_1 = dict()
    dict_1['dict_1'] = dict()
    dict_2 = dict()
    dict_2['dict_2'] = dict()
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_1, dict_2, str_0)


# Generated at 2022-06-24 22:42:47.797463
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'types'
    str_1 = 'args'
    str_2 = 'kwargs'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_3 = 'words'
    str_4 = 'str_4'
    str_5 = 'str_5'
    str_6 = 'str_6'
    str_7 = 'str_7'
    str_8 = 'str_8'
    str_9 = 'str_9'
    str_10 = 'str_10'
    str_11 = 'str_11'
    list_0 = [str_4, str_5, str_6, str_7, str_8, str_9, str_10, str_11]

# Generated at 2022-06-24 22:42:52.182943
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 'ifconfig_path'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 'ifconfig_options'
    generic_bsd_ifconfig_network_3 = generic_bsd_ifconfig_network_2.get_interfaces_info(str_0)
    print(generic_bsd_ifconfig_network_3)


# Generated at 2022-06-24 22:43:02.085481
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    int_0 = 0

# Generated at 2022-06-24 22:43:06.689801
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    str_1 = '127.0.0.1'
    str_2 = '127.0.0.1'
    str_3 = '127.0.0.1'
    str_4 = '127.0.0.1'
    str_5 = '127.0.0.1'
    str_6 = '127.0.0.1'
    str_7 = '127.0.0.1'
    str_8 = '127.0.0.1'
    str_9 = '127.0.0.1'
    str_10 = '127.0.0.1'

# Generated at 2022-06-24 22:43:17.251691
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'types'
    str_1 = 'types'
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    generic_bsd_ifconfig_network_0.platform = str_0
    dict_0 = {'dict_0': {'type': 'ether'}}
    dict_1 = dict()
    dict_2 = {'dict_2': {'media': 'ether'}}
    dict_1['dict_0'] = dict_2
    generic_bsd_ifconfig_network_0.interfaces = dict_1
    generic_bsd_ifconfig_network_0.detect_type_media(dict_0)


# Generated at 2022-06-24 22:43:19.217161
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    _str = GenericBsdIfconfigNetwork.merge_default_interface({'interface': 'a'}, 'b', 'c')


# Generated at 2022-06-24 22:43:33.420310
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    interface = 'types'
    collected_facts = 'types'
    network_facts = GenericBsdIfconfigNetwork(interface, collected_facts)
    network_facts.populate()


# Generated at 2022-06-24 22:43:44.447159
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    words_0 = ['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)\n']
    current_if_0 = {}
    ips_0 = {}

    generic_bsd_ifconfig_network_0.parse_media_line(words_0, current_if_0, ips_0)
    assert(current_if_0['media'] == 'Ethernet')
    assert(current_if_0['media_select'] == 'autoselect')
    assert(current_if_0['media_type'] == 'full-duplex')


# Generated at 2022-06-24 22:43:55.205038
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'mKl'
    str_1 = 'qoK'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_3 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_4 = GenericBsdIfconfigNetwork(str_0, str_0)

    ret_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    ret_

# Generated at 2022-06-24 22:44:00.903044
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'ifconfig'
    generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 22:44:03.333010
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(str_0) == (dict_0, dict_0)


# Generated at 2022-06-24 22:44:13.279616
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print("Starting test_GenericBsdIfconfigNetwork_parse_inet_line...")
    test_GenericBsdIfconfigNetwork_parse_inet_line_0()
    test_GenericBsdIfconfigNetwork_parse_inet_line_1()
    test_GenericBsdIfconfigNetwork_parse_inet_line_2()
    test_GenericBsdIfconfigNetwork_parse_inet_line_3()
    test_GenericBsdIfconfigNetwork_parse_inet_line_4()
    print("Finished test_GenericBsdIfconfigNetwork_parse_inet_line")

# Testcase 0

# Generated at 2022-06-24 22:44:18.915437
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'types'
    str_1 = 'types'
    
    # Test for operational error
    try:
        generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
        generic_bsd_ifconfig_network_0.parse_inet_line(str_0, str_0, str_1)
        assert False
    except Exception as err:
        print(err)
        assert True

# ~autogenerated

# Generated at 2022-06-24 22:44:31.296537
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    str_0 = 'test_str'
    str_1 = '!!test_str'
    str_2 = ':test_str'
    str_3 = 'test_str:'
    str_4 = 'test_str::test_str'
    str_5 = 'test_str:test_str:'
    str_6 = 'test_str:test_str:test_str'
    str_7 = 'test_str::test_str:test_str'
    int_0 = -1
    int_1 = 0
    int_2 = 1
    int_3 = 2
    int_4 = 3

    # Test if function returns localhost ip addresses
    ipv4_address_0 = '127.0.0.1'
    current_if_0 = {'ipv4': []}
    ips

# Generated at 2022-06-24 22:44:40.986296
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'types'
    str_1 = '0xI'
    str_2 = 'i'
    str_3 = 'U'
    str_4 = 'm'
    str_5 = 'F'
    str_6 = '`mLd'
    str_7 = '&8<Vd'
    str_8 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_8)
    dict_0 = {str_3:str_4, str_5:str_6, str_7:str_0}
    dict_1 = {str_1:dict_0}
    dict_2 = {str_2:dict_1}
    dict_2 = dict_2
    dict_0 = dict_0
    str

# Generated at 2022-06-24 22:44:52.042141
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case 0
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'default_ipv4'
    str_2 = 'default_ipv6'
    tuple_0 = (str_1, str_2)
    str_3 = 'interfaces'
    str_4 = 'interface'
    str_5 = 'ipv4'
    str_6 = 'ipv6'
    tuple_1 = (str_3, str_4, str_5, str_6)
    str_7 = 'Generic_BSD_Ifconfig'
    str_8 = 'types'
    tuple_2 = (str_7, str_8)
    generic_bsd_ifconfig_network_0

# Generated at 2022-06-24 22:45:16.010501
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'asdf'
    list_0 = ['asdf']
    dict_0 = {}
    dict_1 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(list_0,
                                                   dict_0,
                                                   dict_1)


# Generated at 2022-06-24 22:45:26.238683
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'flags'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['interface'] = 'lo1'
    dict_1['device'] = 'lo1'
    dict_3 = dict()
    dict_3['address'] = '127.0.0.1'
    dict_4 = dict()
    dict_4['address'] = '127.0.2.1'
    dict_5 = list()
    dict_5.append(dict_3)
    dict_5.append(dict_4)
    str_1 = 'ipv4'
    dict_1[str_1] = dict_5
    dict_0[dict_1['device']] = dict_1
    dict_6 = dict()

# Generated at 2022-06-24 22:45:31.798069
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # Variables initialization
    str_0 = 'hw'
    str_1 = 'hw\tHWaddr '
    str_2 = 'hw\tHWaddr '
    str_3 = 'ipv4'
    str_4 = 'ipv6'
    str_5 = 'lladdr '
    str_6 = 'lladdr '
    str_7 = 'media: '
    str_8 = 'media: '
    str_9 = 'media\tmedia: '
    str_10 = 'media\tmedia: '
    str_11 = 'media\tmedia  '
    str_12 = 'media\tmedia\t'
    str_13 = 'media\tmedia* '
    str_14 = 'media\tmedia* '
    str_15 = 'media\tmedia*\t'


# Generated at 2022-06-24 22:45:38.134196
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    defaults, interfaces, ip_type = (dict(), dict(), str_0)

    # Call the method
    try:
        generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)
    except Exception as err:
        print("Test case 0 failed")
        print(err)

test_GenericBsdIfconfigNetwork_merge_default_interface()

# Generated at 2022-06-24 22:45:46.087779
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    # Testing a netmask given as a hex number
    test_GenericBsdIfconfigNetwork_parse_inet_line__case_0()

    # Testing a netmask given as the special broadcast address
    test_GenericBsdIfconfigNetwork_parse_inet_line__case_1()

    # Testing a netmask given as a dotted-quad number
    test_GenericBsdIfconfigNetwork_parse_inet_line__case_2()

    # Testing a netmask given as a cidr mask
    test_GenericBsdIfconfigNetwork_parse_inet_line__case_3()

# Testing a netmask given as the special broadcast address

# Generated at 2022-06-24 22:45:48.335829
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network_facts_0 = dict()
    assert False  # TODO: implement your test here

if __name__ == "__main__":
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:45:58.964521
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    dict_0 = {}
    dict_1 = {}
    str_1 = 'interface'
    dict_1[str_1] = str_1
    dict_0[str_1] = dict_1
    dict_1 = {}
    str_1 = 'addresses'
    dict_1[str_1] = str_1
    dict_0[str_1] = dict_1
    dict_1 = {}
    str_1 = 'address'
    dict_1[str_1] = str_1
    dict_0[str_1] = dict_1
    dict_1 = {}
    str_1 = 'metric'
    dict_1

# Generated at 2022-06-24 22:46:08.704191
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'types'
    str_1 = str_0
    str_2 = 'media'
    str_3 = 'media_select'
    str_4 = str_3
    str_5 = 'media_type'
    str_6 = str_5
    str_7 = str_6
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = [str_0, str_7]
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict(ether=str_2, media_select=str_3, media_options=list_1, media_type=str_4, type=str_0, lo0=dict())
    dict_4 = dict()
    dict_5 = dict

# Generated at 2022-06-24 22:46:17.364996
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'host'
    generic_bsd_ifconfig_network_0.module = str_1
    str_2 = 'lo0_'
    str_3 = '_LOOPBACK'
    generic_bsd_ifconfig_network_0.get_options = MagicMock(name='get_options', side_effect=[str_2, str_3])
    dict_0 = generic_bsd_ifconfig_network_0.populate(str_2)
    assert type(dict_0) == dict
    str_4 = '/dev/null'
    str_5 = 'test_default_interface'
    assert dict_0[str_5]

# Generated at 2022-06-24 22:46:25.125959
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'types'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    list_0 = ['a', 'b', 'c', 'd', 'e', 'f']
    list_1 = ['a', 'b', 'c', 'd', 'e', 'f']
    dict_0 = {'a': 5, 'b': 1, 'c': 2, 'e': 0, 'd': 4}
    dict_1 = {'a': 5, 'b': 1, 'c': 2, 'e': 3, 'd': 4}
    generic_bsd_ifconfig_network_0.parse_inet_line(list_0, dict_0, list_1)

# Generated at 2022-06-24 22:46:38.252386
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    class_0 = GenericBsdIfconfigNetwork(var_0)
    var_1 = IF_CONFIG_RESULT_0
    var_2 = ''
    var_3 = class_0.get_interfaces_info(var_1, var_2)
    assert(True)


# Generated at 2022-06-24 22:46:42.744364
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork(module)
    words = ['lo0:']
    var_0 = dict(
        device = 'lo0',
        ipv4 = [],
        ipv6 = [],
        type = 'unknown'
    )
    assert generic_bsd_ifconfig.parse_interface_line(words) == var_0


# Generated at 2022-06-24 22:46:53.480876
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # var_0 : test_case_0
    # var_1 : current_if
    var_1 = dict()
    # var_2 : words
    var_2 = ['inet', '192.168.1.84', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    # var_3 : ips
    var_3 = dict()
    var_3['all_ipv4_addresses'] = []
    # var_2 : words
    var_2 = ['inet', '192.168.1.84', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    # var_3 : ips
    var_3 = dict()
    var_3['all_ipv4_addresses'] = []
   

# Generated at 2022-06-24 22:47:05.274041
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    global var_0
    var_0 = dict()
    var_0['address'] = None
    var_0['interface'] = 'lo0'
    var_0['ipv4'] = [
        {'broadcast': '127.255.255.255', 
        'address': '127.0.0.1', 
        'netmask': '255.0.0.0', 
        'network': '127.0.0.0'}, 
        {'address': '127.1.1.1', 
        'netmask': '255.0.0.0', 
        'network': '127.0.0.0'}
    ]

# Generated at 2022-06-24 22:47:12.039549
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.params['path'] = {'/': '/bin', '/usr/local/': '/bin'}
    obj = GenericBsdIfconfigNetwork(module)
    interfaces, ips = obj.get_interfaces_info(test_case_0)
    assert(isinstance(interfaces, dict))
    assert(isinstance(ips, dict))

# Generated at 2022-06-24 22:47:14.647853
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    obj = GenericBsdIfconfigNetwork()
    ifconfig_path = obj.module.get_bin_path('ifconfig')

    assert True == obj.get_interfaces_info(ifconfig_path)[0]



# Generated at 2022-06-24 22:47:21.720037
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    route_path = generic_bsd_ifconfig_network.module.get_bin_path('route')
    default_ipv4, default_ipv6 = generic_bsd_ifconfig_network.get_default_interfaces(route_path)

# Generated at 2022-06-24 22:47:27.901704
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    genericbsdifconfignetwork = GenericBsdIfconfigNetwork()

    words = [0, 1, 2, 3, 4, 5, 6]
    current_if = dict()
    ips = dict()
    genericbsdifconfignetwork.parse_inet_line(words, current_if, ips)
    return

# Generated at 2022-06-24 22:47:33.715156
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module=AnsibleModule(argument_spec=dict()))
    # maybe push module to a different class
    assert generic_bsd_ifconfig_network.module == AnsibleModule(argument_spec=dict())



# Generated at 2022-06-24 22:47:37.021565
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # You can test here if the method works as expected. Please, write at least one test case.
    var_0 = dict()
    for item in var_0:
        print(item)


# Generated at 2022-06-24 22:47:54.768976
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    var_0 = [
        'lo0',
        'inet',
        '127.0.0.1',
        'netmask',
        '0xff000000',
        'inet6',
        '::1',
        'prefixlen',
        '128',
        'inet6',
        'fe80::1%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x1',
        'nd6',
        'options=21<PERFORMNUD,AUTO_LINKLOCAL>'
    ]

# Generated at 2022-06-24 22:48:05.325542
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    var_0 = dict()

# Generated at 2022-06-24 22:48:08.541335
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    current_if = dict()
    words = ["lo0"]
    ips = dict()
    network_object = GenericBsdIfconfigNetwork(module=None)

    network_object.parse_inet_line(words, current_if, ips)


# Generated at 2022-06-24 22:48:10.481705
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = 'Generic_BSD_Ifconfig'
    var_0 = {}

    var_1 = get_default_interfaces(var_0)


# Generated at 2022-06-24 22:48:22.363552
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    var_0 = dict()
    var_0['item'] = dict()
    var_0['item']['device'] = '123'
    var_0['item']['type'] = '123'
    var_0['item']['ipv4'] = [{'broadcast': '123', 'address': '123', 'netmask': '123', 'network': '123'}]
    var_0['item']['ipv6'] = [{'scope': '123', 'prefix': '123', 'address': '123'}]
    var_0['item']['flags'] = ['123']
    var_0['item']['macaddress'] = '123'
    var_0['item']['macaddress'] = '123'
    var_0['item']['mtu'] = '123'

# Generated at 2022-06-24 22:48:29.903362
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    _test_GenericBsdIfconfigNetwork()
    words_0 = ["0x10001", "UP,LOOPBACK,RUNNING,", "PROMISC,NOARP,ALLMULTI,", "MTU:4470", "Metric:1", "RX", "bytes", "1089", "(1.0", "KiB)", "TX", "bytes", "1089", "(1.0", "KiB)"]
    GenericBsdIfconfigNetwork.parse_interface_line(words_0)

# Generated at 2022-06-24 22:48:37.268669
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Verify that the following calls to parse_interface_line return the correct result:
    #   words = []
    #   current_if = {}
    #   output = GenericBsdIfconfigNetwork.parse_interface_line(words, current_if)
    #   assert(output == None)
    
    var_0 = ['em0']
    var_1 = dict()
    output = GenericBsdIfconfigNetwork.parse_interface_line(var_0, var_1)
    
    
    
    


# Generated at 2022-06-24 22:48:39.145942
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    var_0 = dict()


# Generated at 2022-06-24 22:48:44.126119
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # test default
    args = []
    ret = GenericBsdIfconfigNetwork.get_default_interfaces(*args)

    assert ret is None


# Generated at 2022-06-24 22:48:55.624949
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    var_0 = '/sbin/ifconfig'
    var_1 = '/sbin/route'
    var_2 = {var_0:'/sbin/ifconfig', var_1:'/sbin/route'}
    var_3 = {'all_ipv4_addresses': ['10.0.0.1'], 'all_ipv6_addresses': ['fe80::b5a5:aff:fef5:5d49']}
    var_4 = {}

# Generated at 2022-06-24 22:49:15.449893
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    var_0 = test_case_0()
    current_if = {"device": "lo0", "ipv4": [], "ipv6": [], "type": "unknown", "macaddress": "00:00:00:00:00:00", "mtu": 33184, "flags": ["UP", "LOOPBACK", "RUNNING", "MULTICAST"]}
    words = ["lo0", "inet", "127.0.0.1", "netmask", "0xff000000"]
    ips = {"all_ipv4_addresses": "127.0.0.1", "all_ipv6_addresses": ""}

# Generated at 2022-06-24 22:49:23.906789
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.plugins.module_utils.network.common.facts import Facts
    from ansible.module_utils.network.common.plugins.module_utils.network.common.netlink.list_interfaces import ListInterfaces
    import ansible.module_utils.network.common.network_linux.interfaces
    module = ansible.module_utils.network.common.plugins.module_utils.network.common.network_linux.interfaces
    testobj = ansible.module_utils.network.common.plugins.module_utils.network.common.network_linux.interfaces.GenericBsdIfconfigNetwork(module)
    # First test
    # unit_test_case_0
    # /unit_test_case_

# Generated at 2022-06-24 22:49:25.756847
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    obj.merge_default_interface(var_0)


# Generated at 2022-06-24 22:49:28.558909
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    fixture = GenericBsdIfconfigNetwork()

    fixture.get_interfaces_info(
        ifconfig_path='/usr/sbin/ifconfig',
        ifconfig_options='-a'
    )


# Generated at 2022-06-24 22:49:30.015193
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    obj = GenericBsdIfconfigNetwork()
    return obj.get_interfaces_info()


# Generated at 2022-06-24 22:49:37.354553
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # var_0 is the object to test
    try:
        var_0 = GenericBsdIfconfigNetwork()
    except Exception as e:
        print("Could not create GenericBsdIfconfigNetwork")
        print(str(e))
        return
    try:
        print("Object created")
        test_case_0()
    except Exception as e:
        print('Exception raised: ' + str(type(e)) + ': "' + str(e) + '"\n')
    
test_GenericBsdIfconfigNetwork_merge_default_interface()


# Generated at 2022-06-24 22:49:45.151294
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:49:50.463983
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print("#### start method test_GenericBsdIfconfigNetwork_get_default_interfaces ####")
    var_0 = dict()
    var_0 = GenericBsdIfconfigNetwork_0()
    var_1 = dict()
    var_1 = var_0.get_default_interfaces('route_path')
    print(var_1)
    print("#### stop method test_GenericBsdIfconfigNetwork_get_default_interfaces ####")


# Generated at 2022-06-24 22:49:55.459370
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    config_0 = dict()
    var_0 = GenericBsdIfconfigNetwork()
    var_1 = var_0.merge_default_interface('', '', 'ipv6')
    var_1 = var_0.merge_default_interface('', '', 'ipv6')
    test_case_0()
