

# Generated at 2022-06-24 22:40:46.319799
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('V7-uCQw@l7')
    words_0 = ['media:', 'IEEE', '802.11', 'Wireless']
    current_if_0 = {'macaddress': 'unknown', 'ipv6': [], 'type': 'unknown', 'ipv4': [], 'flags': ['UP'], 'device': 'en0', 'options': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-24 22:40:55.753704
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # ValueError raised here if test fails
    interfaces = {"lo0": {"lladdr": "00:00:00:00:00:00", "metric": "0", "status": "active", "options": [], "device": "lo0", "mtu": "16384", "type": "unknown", "ipv4": [{"broadcast": "127.255.255.255", "netmask": "255.0.0.0", "address": "127.0.0.1", "network": "127.0.0.0"}], "ipv6": []}}
    generic_bsd_ifconfig_network_0

# Generated at 2022-06-24 22:41:01.235483
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '5"l9mdA-kX/F8Wp{['
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # param_0 is route_path
    param_0 = '>>;nPwFn$E6:'
    ifconfig_path = param_0
    # Call the method with correct parameters
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(ifconfig_path) == ('', '')


# Generated at 2022-06-24 22:41:04.154833
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    arg_0 = None
    temp_1 = None
    expect_0 = 'None'
    actual_0 = GenericBsdIfconfigNetwork().populate(temp_1)

    assert actual_0 == expect_0


# Generated at 2022-06-24 22:41:10.212511
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    assert var_0 is None



# Generated at 2022-06-24 22:41:19.638192
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '6mjU|8W_<-F(3dg^'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    ips_0 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-24 22:41:24.856707
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    list_0 = ['/usr/bin/ifconfig', '-a']
    generic_bsd_ifconfig_network_0.module.run_command = MagicMock(side_effect=[(0, '', '')])
    generic_bsd_ifconfig_network_0.get_interfaces_info(list_0[0], list_0[1])


# Generated at 2022-06-24 22:41:30.378531
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    expected = dict(
        address=str_0,
        macaddress='00:00:5e:00:53:00',
        nd6_options=['autoconf', 'router', 'autoproto'],
        type='ether',
        ipv6=[dict(address='fe80::2', scope='0x3')],
        mtu=str_0,
        flags=['BROADCAST', 'SIMPLEX', 'MULTICAST'])
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    get_interfaces_info_0 = generic_bsd_ifconfig_network_1.get_interfaces_info(str_0)

# Generated at 2022-06-24 22:41:36.387149
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_1 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.populate()
    assert var_1 == {}, 'Expected {}, but got {}'.format({}, var_1)


# Generated at 2022-06-24 22:41:46.100473
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    defaults_0 = {'interface': 'lo0'}
    interfaces_0 = {'lo0': {'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST']}}
    ip_type_0 = 'ipv4'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0)
    assert defaults_0['flags'] == ['LOOPBACK', 'RUNNING', 'MULTICAST']


# Generated at 2022-06-24 22:42:06.009681
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    str_0 = '5"l9mdA-kX/F8Wp{['
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['inet6', 'inet6', 'broadcast', 'prefixlen', 'scope', 'Lo']
    current_if_0 = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if_0['metric'] = '0'
    current_if_0['mtu'] = '32768'
    current_if_0['flags'] = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    current_if_0['lladdr'] = 'fe80::1%lo0'
    current_if

# Generated at 2022-06-24 22:42:13.046081
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'j:n:b_TeLn-Lpe=jC'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces('route')


# Generated at 2022-06-24 22:42:14.050402
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pass


# Generated at 2022-06-24 22:42:15.249480
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 22:42:21.253903
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_1 = 'M1{]GRtt-z}Pb^'
    str_2 = '+lRr<1rB,HNOu'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.populate(str_2)



# Generated at 2022-06-24 22:42:32.782255
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '_H1.Q&4i=Nf)TO'
    str_1 = 'Bbs8Yv'
    str_2 = '9z$lWm'
    dict_0 = {}
    dict_0['address'] = str_0
    dict_0['broadcast'] = str_0
    dict_0['netmask'] = str_0
    dict_0['network'] = str_0
    dict_1 = {}
    dict_1['all_ipv4_addresses'] = str_0
    dict_2 = {}
    dict_2['device'] = str_0
    dict_2['flags'] = str_0
    dict_2['ipv4'] = str_0
    dict_2['ipv6'] = str_0

# Generated at 2022-06-24 22:42:42.269269
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:42:49.008451
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    ifconfig_path_0 = ')F8WpWp{vG/'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0)
    str_1 = ' b[:h`'
    assert str_1 in var_0
    str_2 = "',w.N"
    assert str_2 in var_0[str_1]
    str_3 = "'.x%U"
    assert str_3 in var_0[str_1]
    str_4 = '<"l9mdA-kX'

# Generated at 2022-06-24 22:42:59.104546
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['cGZ!Nb17', '', '', '', '']
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)
    # Assert if the method_return_0 is equal to the expected_return_0.
    method_return_0 = generic_bsd_ifconfig_network_0.populate()
    expected_return_0 = str_0 + 'H'
    assert method_return_0 == expected_return_0
   

# Generated at 2022-06-24 22:43:06.074177
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '*5gB&5.=1d_I'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_0 = 'I8W+x}'
    str_1 = '>r+k_I=s$sF'
    bool_0 = generic_bsd_ifconfig_network_0.merge_default_interface(str_0, str_1, 'V2>)y1b]Y1')


# Generated at 2022-06-24 22:43:20.518582
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:43:27.443578
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:43:38.712575
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    args_1 = ['inet', '10.230.144.38', 'netmask', '0xffffff00', 'broadcast', '10.230.144.255']
    current_if_1 = {}
    ips_1 = {}
    expected_1 = {
                'network' : '10.230.144.0',
                'broadcast' : '10.230.144.255',
                'netmask' : '255.255.255.0',
                'address' : '10.230.144.38',
            }
    GenericBsdIfconfigNetwork.parse_inet_line(args_1, current_if_1, ips_1)

# Generated at 2022-06-24 22:43:43.829204
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = '3:4|]v.'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    var_0 = generic_bsd_ifconfig_network_0.parse_media_line(str_0, str_0, str_0)
    assert (var_0 == None)


# Generated at 2022-06-24 22:43:54.763573
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_0 = '{usv*3p'
    list_0 = [str_0, 'Q\x17]B', ' w', 'c>', 'tw3\tW8Y', 'u0']
    str_1 = '7F'
    str_2 = '\x7f'
    str_3 = 'ZF@\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    list_1 = [str_3, str_1, str_2]
    var_0 = generic_bsd_ifconfig_network_0.parse

# Generated at 2022-06-24 22:44:00.460819
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'e'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    arg_0 = 'u'
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(arg_0) == {}


# Generated at 2022-06-24 22:44:07.241796
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = ['name', '127.10.255.254', 'netmask', '0xffffff00', 'broadcast', '127.10.255.255', 'hahahahah']
    var_1 = generic_bsd_ifconfig_network_0.parse_inet_line(var_0)
    assert var_1 == None
    var_0 = ['/etc/name', '127.10.255.254', 'netmask', '0xffffff00', 'broadcast', '127.10.255.255', 'hahahahah']

# Generated at 2022-06-24 22:44:10.525609
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork("E;K(eQb4J-'~4!1-")
    var_0 = generic_bsd_ifconfig_network_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:44:20.310963
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # example input
    words = [
        'fe80::1%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x2',
    ]
    GenericBsdIfconfigNetwork.parse_inet6_line(
        None, words, current_if, ips)
    assert ips['all_ipv6_addresses'][0] == 'fe80::1%lo0'
    for ip in ips['all_ipv4_addresses']:
        assert ip == None

#

# Generated at 2022-06-24 22:44:27.389629
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '&=I-2d*'
    list_0 = list(str_1)
    var_0 = generic_bsd_ifconfig_network_0.parse_interface_line(list_0)
    

# Generated at 2022-06-24 22:44:52.158763
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    str_1 = '127.0.0.1'
    str_2 = '255.255.255.0'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['a', '123.123.123.123', 'netmask', '0xffffff00']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if, ips)
    assert words_0 == ['a', '123.123.123.123', 'netmask', '0xffffff00']

# Generated at 2022-06-24 22:44:55.309751
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'n9l"n86(P+g{h'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    option_string_0 = 'level  :  "hxM?u_7$,2'
    var_0 = generic_bsd_ifconfig_network_0.get_options(option_string_0)



# Generated at 2022-06-24 22:45:01.780287
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:45:10.647028
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'L<>'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '<>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_1)
    str_2 = 'L<>'
    var_1 = generic_bsd_ifconfig_network_0.get_options(str_2)
    return var_0, var_1


# Generated at 2022-06-24 22:45:17.555871
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'O8lT|)t|k+>7pv'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_0 = '/3]\xe8'
    float_0 = float(str_0)
    float_1 = float(str_0)
    float_2 = float(str_0)
    float_3 = float(str_0)
    float_4 = float(str_0)
    float_5 = float(str_0)
    float_6 = float(str_0)
    float_7 = float(str_0)
    float_8 = float(str_0)
    float_9 = float(str_0)
    float_10 = float(str_0)

# Generated at 2022-06-24 22:45:26.677506
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = "KxC`pw`Y-Jh/p<L?/"
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

# Generated at 2022-06-24 22:45:37.027720
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_1 = ' 5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.populate()
    str_2 = "5\"l9mdA-kX/F8Wp{[-"
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)
    var_2 = generic_bsd_ifconfig_network_2.populate()
    str_3 = '\x05"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_3 = GenericBsdIfconfigNetwork(str_3)
    var_3 = generic_bs

# Generated at 2022-06-24 22:45:46.618672
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    dict_0 = dict()
    list_0 = list()
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_0, str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_0, str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(list_0, dict_0, list_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_0, list_0)
    generic

# Generated at 2022-06-24 22:45:58.404182
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    str_2 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)
    var_0 = int(3)
    var_1 = int(3)
    str_3 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig

# Generated at 2022-06-24 22:46:00.603692
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'X+W8)GZ!Jt'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:46:15.136535
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = ['2001::1', '64', 'prefixlen', '-inet6', '-prefixlen', '64', '-scopeid', '0x1c', '0x1']
    var_1 = {}
    var_2 = {}
    generic_bsd_ifconfig_network_0.parse_inet6_line(var_0, var_1, var_2)


# Generated at 2022-06-24 22:46:18.743263
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Jc7@A+C'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface('Y`>a$p', 'CC', 'S:')


# Generated at 2022-06-24 22:46:26.206241
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    route_path_0 = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
    result_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)

# Generated at 2022-06-24 22:46:31.956514
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print("Testing get_default_interfaces")
    cmd = ['route', '-n', 'get', 'default']
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, _ = proc.communicate()
    result = stdout.decode("utf-8")
    assert("interface: en0" in result)


# Generated at 2022-06-24 22:46:33.442159
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_GenericBsdIfconfigNetwork_get_interfaces_info_0()


# Generated at 2022-06-24 22:46:41.041157
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # non-empty list of positional arguments
    route_path = '7oS_+6x<U6#Y2B'
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork('G~5imJ+I')
    var_ret_get_default_interfaces = generic_bsd_ifconfig_network.get_default_interfaces(route_path)
    return var_ret_get_default_interfaces


# Generated at 2022-06-24 22:46:49.734689
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    route_path_0 = '5"l9mdA-kX/F8Wp{[-'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    # Omitted test for default_ipv4
    mtu_0 = generic_bsd_ifconfig_network_0.populate()
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    # Omitted test for default

# Generated at 2022-06-24 22:46:54.214475
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '5"l9mdA-kX/F8Wp{['
    # no options specified as parameter
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:46:59.735631
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'lOIt\x7f|?/'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces()
    print(var_0)


# Generated at 2022-06-24 22:47:03.169259
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'test/test/test'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'test/test/test'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_1)
    print(var_0)


# Generated at 2022-06-24 22:47:36.796645
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # default_ipv4 (dict) of class GenericBsdIfconfigNetwork
    default_ipv4 = {
        'address': '192.168.0.101',
        'gateway': '192.168.0.1',
        'interface': 'en0'
    }

    # default_ipv6 (dict) of class GenericBsdIfconfigNetwork
    default_ipv6 = {
        'address': 'fe80::a00:27ff:fe7d:8d2',
        'gateway': 'fe80::1%lo0',
        'interface': 'en0'
    }

    # ifconfig_path (str) of class GenericBsdIfconfigNetwork
    ifconfig_path = '/sbin/ifconfig'

    # route_path (str) of class GenericBsdIfconfigNetwork
    route_

# Generated at 2022-06-24 22:47:46.143630
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'dQ\x1d\x7f\x0e\x10@\x8e\x18\x0c\x00\x05'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['', '', '', '', '', '', '', '']
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)
    assert len(current_if_0) == 0
    assert len(ips_0) == 0


# Generated at 2022-06-24 22:47:57.189407
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '~[ho0M'
    int_0 = 0
    str_2 = 'R$#I<\x7f'
    str_3 = 'zN~\x00'
    int_1 = 24
    str_4 = 'B\x7f\x00\x00'
    str_5 = 'n\x005'
    int_2 = 1
    str_6 = 'xjK{'

# Generated at 2022-06-24 22:48:05.444398
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    str_1 = 'em0'
    list_0 = ['inet', '10.0.0.1', 'netmask', '0xffffff00']
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1['all_ipv4_addresses'] = []
    dict_1['all_ipv6_addresses'] = []
    list_1 = []
    dict_0['device'] = str_1
    dict_0['macaddress'] = 'unknown'
    dict_

# Generated at 2022-06-24 22:48:12.361250
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'U6nB+6W8~&<J`_b+'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # Test for exceptions
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return
    route_path = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
    if route_path is None:
        return
    rc_0, out_0, err_0 = generic_bsd_ifconfig_network_0.module.run_command([route_path, '-n', 'get', 'default'])
    if not out_0:
        return
    var_

# Generated at 2022-06-24 22:48:17.685569
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:48:25.997141
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['']
    words_0[0] = ''
    current_if_0 = generic_bsd_ifconfig_network_0.parse_interface_line(words_0)
    assert current_if_0['device'] == ''


# Generated at 2022-06-24 22:48:32.381423
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    route_path_0 = '/usr/bin/route'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    assert type(var_0) == tuple
    assert len(var_0) == 2
    assert len(var_0[0]) == 0
    assert len(var_0[1]) == 0


# Generated at 2022-06-24 22:48:43.229961
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # route -n get default will return empty string
    str_0 = ''
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = {}
    var_0 = generic_bsd_ifconfig_network_0.populate()
    assert len(var_0) == 0, \
        'Size of {} is not zero'.format(var_0)
    # route -n get default will return string
    str_1 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_1 = generic_bsd_ifconfig_network_1.populate()

# Generated at 2022-06-24 22:48:49.047154
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '8gv>S"N?[:%N+('
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['8.j`\\o0', 'T\\}', 'B>8WdS']
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)
    assert(current_if_0['ipv4'][0]['netmask'] == '255.255.255.0')


# Generated at 2022-06-24 22:49:27.167091
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    try:
        var_0 = str.__mro__(str_0)
    except Exception as e:
        test_case_0()


# Generated at 2022-06-24 22:49:36.603732
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '2CYMJWRKdAG_X9,i|}I'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.module = "Pw[Nt{gYt"
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info("q.VT7)h8{J]ZAj+")
    assert var_0 == ("8n=Rx??}[wCZU~7Y", ["k-Tl%Vj+y.]2#J^", "+}<Gr[|V@>+j{_k1"]), "get_interfaces_info did not return expected value"


# Generated at 2022-06-24 22:49:39.626808
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:49:48.675804
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '5"l9mdA-kX/F8Wp{[-'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    list_0 = []
    str_1 = 'something'
    list_0.append(str_1)
    str_2 = 'todo'
    list_0.append(str_2)
    str_3 = 'something'
    list_0.append(str_3)
    str_4 = 'todo'
    list_0.append(str_4)
    str_5 = 'something'
    list_0.append(str_5)
    str_6 = 'todo'

# Generated at 2022-06-24 22:49:59.388610
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module_name = 'ansible_collections.jctanner.network_jctanner'
    module_path = 'ansible_collections/jctanner/network_jctanner'
    sys.modules['ansible_collections.jctanner.network_jctanner'] = imports.ImportSimulator(module_name, module_path)
    from ansible_collections.jctanner.network_jctanner.plugins.module_utils.network.generic.network import GenericBsdIfconfigNetwork

    module_name = 'ansible_collections.jctanner.network_jctanner.plugins.module_utils.network.common.utils'