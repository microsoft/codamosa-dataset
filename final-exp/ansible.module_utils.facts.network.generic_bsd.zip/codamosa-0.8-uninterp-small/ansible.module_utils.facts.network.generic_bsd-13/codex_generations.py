

# Generated at 2022-06-24 22:40:42.293003
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    b'/home/dic/bin:/home/dic/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    b'/home/dic/bin:/home/dic/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    b'/home/dic/bin:/home/dic/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'

# Generated at 2022-06-24 22:40:46.517226
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    str_0 = '-a'

    interface_1 = {}
    ip_1 = {}
    interface_2, ip_2 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_0)

    if interface_2 != interface_1:
        print('Expected:', interface_1)
        print('Actual:  ', interface_2)
        raise Exception('Unexpected return value!')

    if ip_2 != ip_1:
        print('Expected:', ip_1)
        print('Actual:  ', ip_2)
        raise Exception('Unexpected return value!')


# Generated at 2022-06-24 22:40:55.918944
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'by*RTtktLksaO$fn'
    len_0 = len(str_0)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'T^Tnk'
    str_2 = 'UvzjedqCgU'
    int_0 = len_0
    int_1 = len_0
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_0[str_1] = str_2
    dict_1[str_1] = str_2
    dict_2[str_1] = int_0

# Generated at 2022-06-24 22:40:59.802014
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Test for the default case
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # Add missing parameters so that we get a full function coverage
    generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:41:03.713670
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    result = generic_bsd_ifconfig_network_0.get_options(str_1)


# Generated at 2022-06-24 22:41:14.453281
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # Test without argument
    try:
        # Test with float argument
        float_0 = 3.8192954663136584
        generic_bsd_ifconfig_network_0.parse_inet_line(float_0)
    except TypeError:
        pass
    # Test with int argument
    # Declaration of local variable 'words'
    # Assigning value to variable 'words'
    words = [1]

# Generated at 2022-06-24 22:41:18.153240
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Test if call to method populate of class GenericBsdIfconfigNetwork
    # raises an exception when called with a non-None value for parameter collect
    str_0 = 'adby*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    try:
        generic_bsd_ifconfig_network_0.populate('str_1')
    except:
        pass
    else:
        assert False


# Generated at 2022-06-24 22:41:25.282637
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'J$2w'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '/usr/bin/ifconfig'
    str_2 = '-a'
    str_2 = '-a'
    str_2 = str_2
    str_1 = str_1
    str_1 = str_1
    str_0 = str_0
    str_0 = str_0
    str_1 = str_1
    str_0 = str_0
    str_1 = str_1
    str_2 = str_2
    int_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 22:41:26.704468
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # TODO: unit test for function get_interfaces_info of class GenericBsdIfconfigNetwork
    assert True == True

# Generated at 2022-06-24 22:41:37.116236
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'BHvcjx#Au$EAoIg'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    module_0 = Mock()
    generic_bsd_ifconfig_network_0.module = module_0
    str_1 = '_Yqh&~>$v+``|y'
    module_0.run_command = MagicMock(return_value=(1, str_1, 1))
    str_2 = '-a'
    str_3 = '^0Z`Ql<%9&q'
    module_0.get_bin_path = MagicMock(side_effect=[None, str_3])

    with pytest.raises(AnsibleFilterError) as exception:
        generic_bsd_

# Generated at 2022-06-24 22:41:52.137007
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = network_debugging.get_interface_mac(network_debugging.get_default_interfaces(network_debugging.INTERFACE_TYPE_ALL)[0])
    assert(str_0 == 'lo0')


# Generated at 2022-06-24 22:41:58.159009
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'soh$j*r'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'F&Cz'
    str_2 = 'x5>Q*jd.EdR'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1, str_2)


# Generated at 2022-06-24 22:42:01.336143
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'route'
    var_2 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:42:12.192807
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_2 = '/sbin/ifconfig'
    str_3 = '-a'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork('NA')
    list_0, list_1 = generic_bsd_ifconfig_network_1.get_interfaces_info(
        str_2, str_3)
    str_4 = 'P'
    str_5 = 'options'
    # assert len(list_0[str_4][str_5]) == 5
    # assert list_1['all_ipv4_addresses'][0] == '127.0.0.1'
    # assert list_1['all_ipv6_addresses'][0] == '::1'


# Generated at 2022-06-24 22:42:23.130672
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    if not generic_bsd_ifconfig_network_0.populate():
        raise Exception('Expected True but got False')
    str_0 = 'a*V7mw1f98uV7QlO'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    if not generic_bsd_ifconfig_network_1.populate():
        raise Exception('Expected True but got False')
    str_0 = 'u*_^Q(6aY9jzRVOM'
    generic_bsd_ifconfig_network_2 = GenericBsdIf

# Generated at 2022-06-24 22:42:34.511310
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    
    defaults = {'address': '192.168.67.129'}
    interfaces = {'eth0': {'device': 'eth0', 'ipv4': [{'address': '192.168.67.129', 'netmask': '255.255.255.0', 'network': '192.168.67.0', 'broadcast': '192.168.67.255'}], 'ipv6': [], 'type': 'unknown', 'metric': '0', 'mtu': '1500', 'macaddress': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']}}
    ip

# Generated at 2022-06-24 22:42:44.776641
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_2 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_2)
    str_3 = 'fe80::9c5b:8af1:ace5:521f%nfe0'
    list_0 = ['fe80::9c5b:8af1:ace5:521f%nfe0', 'prefixlen', '64']
    list_1 = ['scopeid', '0x8']
    list_0.extend(list_1)
    dict_0 = {}
    list_2 = []
    dict_1 = {}
    generic_bsd_ifconfig_network_1.parse_inet6_line(list_0, dict_0, list_2)

# Generated at 2022-06-24 22:42:57.343850
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    list_0 = ['lo0', 'gif0', 'stf0', 'en0', 'en1', 'fw0', 'en2', 'en3', 'en4', 'en5', 'en6', 'en7', 'en8', 'en9', 'en10', 'en11', 'en12', 'en13', 'en14', 'en15', 'en16', 'en17', 'en18', 'en19', 'en20', 'en21', 'en22', 'en23', 'en24', 'en25', 'en26', 'en27', 'en28']

# Generated at 2022-06-24 22:43:04.743692
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'oC<OK,'
    str_2 = 'a'
    str_3 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 22:43:16.520307
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    list_1 = ['my_str', '10.0.0.1', 'netmask', '0xff00', 'broadcast', '10.0.0.255']
    dict_0 = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    dict_1 = dict(ipv4=[dict(address='10.0.0.1', netmask='255.255.0.0', broadcast='10.0.0.255', network='10.0.0.0')], ipv6=[], device='my_str', macaddress='unknown', type='unknown')
    generic_bsd_ifconfig_

# Generated at 2022-06-24 22:43:37.307627
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_1)
    str_2 = 'media: Ethernet autoselect (1000baseT <full-duplex>)'
    str_3 = 'media'
    str_4 = 'Ethernet'
    str_5 = 'autoselect'
    str_6 = '(1000baseT'
    str_7 = '<full-duplex>)'

# Generated at 2022-06-24 22:43:49.454168
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Generic_BSD_Ifconfig'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    path_0 = '/sbin/ifconfig'
    generic_bsd_ifconfig_network_0.module.get_bin_path(path_0)
    path_1 = '/sbin/route'
    generic_bsd_ifconfig_network_0.module.get_bin_path(path_1)
    str_1 = 'ifconfig'
    var_0 = generic_bsd_ifconfig_network_0.module.run_command(str_1)
    str_2 = 'route'
    var_1 = generic_bsd_ifconfig_network_0.module.run_command(str_2)
    str_3 = 'route'

# Generated at 2022-06-24 22:44:01.388690
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    assert False == False
    # print('\n' + 'Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork')
    # str_0 = 'by*RTtktLksaO$fn'
    # generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # str_1 = 'ether'
    # str_2 = '0:30:de:3a:1e:58'
    # list_0 = [str_1, str_2]
    # dict_0 = {}
    # dict_1 = {}
    # dict_2 = {}
    # generic_bsd_ifconfig_network_0.parse_ether_line(list_0, dict_0, dict_1, dict_2)


# Generated at 2022-06-24 22:44:13.429047
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # populate is undefined

# Generated at 2022-06-24 22:44:19.297404
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_1)
    str_2 = 'oOy'
    var_1 = generic_bsd_ifconfig_network_0.populate(str_2)



# Generated at 2022-06-24 22:44:31.665249
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = {
        'interface': 'lo',
        'address': '127.0.0.1',
    }
    

# Generated at 2022-06-24 22:44:38.982499
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_1)
    generic_bsd_ifconfig_network_0.merge_default_interface(var_0, var_0, 'ipv4')


# Generated at 2022-06-24 22:44:43.739092
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    line = 'media: Ethernet autoselect (1000baseT <full-duplex>) '
    words = line.split()
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips)
    # Test to see if the call to parse_media_line changed the current_if dictionary
    assert 'media' in current_if
    assert 'autoselect' in current_if['media']
    assert '1000baseT' in current_if['media']
    assert 'full-duplex' in current_if['media_options']


# Generated at 2022-06-24 22:44:49.119291
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'tap0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1380\n'
    str_1 = '\tinet 192.168.153.1 --> 192.168.153.2 netmask 0xffffffff\n'
    str_2 = '\n'
    str_3 = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384\n'
    str_4 = '\tmedia: Ethernet autoselect (none)\n'
    str_5 = '\tstatus: active\n'
    str_6 = '\n'

# Generated at 2022-06-24 22:44:59.975158
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '/dev/null'
    str_1 = '-a'
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    module_0.run_command = MagicMock(return_value=(1, "", ""))
    module_0.get_bin_path = MagicMock(return_value="/sbin/ifconfig")
    str_2 = 'Generic_BSD_Ifconfig'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_2)
    generic_bsd_ifconfig_network_0.module = module_0

# Generated at 2022-06-24 22:45:16.896330
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    str_0 = ' by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'path'
    str_2 = '/sbin/ifconfig'
    module_0 = AnsibleModule(str_1, GenericBsdIfconfigNetwork=str_0, ifconfig_path=str_2)
    str_3 = '/sbin/route'
    module_0.run_command = MagicMock(return_value=(0, 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 33184', ''))
    module_0.get_bin_path = MagicMock(return_value=str_3)
    dict_0 = {}
    dict_

# Generated at 2022-06-24 22:45:19.364430
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    print('Test for method parse_interface_line of class GenericBsdIfconfigNetwork')


# Generated at 2022-06-24 22:45:27.612105
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'kQV7Fo:I%4G)LG[*'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['kQV7Fo:I%4G)LG[*'] = dict_1
    dict_2 = dict()
    str_1 = 'q@8=^I[ wC*&D5'
    dict_2['kQV7Fo:I%4G)LG[*'] = str_1
    dict_3 = dict()
    dict_3['kQV7Fo:I%4G)LG[*'] = dict_2
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

# Generated at 2022-06-24 22:45:37.825920
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_path = 'GenericBsdIfconfigNetwork.get_bin_path("ifconfig")'
    ifconfig_options = '-a'
    interfaces, ips = GenericBsdIfconfigNetwork.get_interfaces_info(ifconfig_path, ifconfig_options='-a')
    current_if = interfaces['lo0']
    words = 'media: Ethernet autoselect (1000baseT ) status: active'
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if, ips)
    assert (current_if['media']) == 'Ethernet'
    assert (current_if['media_select']) == 'autoselect'
    assert (current_if['media_type']) == '(1000baseT'
    assert (current_if['media_options']) == [' )']

# Generated at 2022-06-24 22:45:47.341784
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Create a new instance of class GenericBsdIfconfigNetwork
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)

    # Create a new instance of class GenericBsdIfconfigNetwork
    str_1 = '%6>;9WlQx'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_1)
    str_2 = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184'
    str_3 = ' inet 127.0.0.1 netmask 0xff000000'
    list_0 = [str_0, str_1, str_2, str_3]
    var_

# Generated at 2022-06-24 22:45:58.378909
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    import json
    import os

    ifnet_path = '/tmp/ifconfig-out.txt'
    route_path = '/tmp/route-out.txt'
    if not os.path.exists(ifnet_path):
        ifnet_path = os.path.join(os.path.dirname(__file__), 'data', 'ifconfig-out.txt')
    if not os.path.exists(route_path):
        route_path = os.path.join(os.path.dirname(__file__), 'data', 'route-out.txt')

    with open(ifnet_path) as f:
        ifconfig_out = f.read()
    with open(route_path) as f:
        route_out = f.read()


# Generated at 2022-06-24 22:46:08.211081
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'by'
    str_1 = 'RTtktLksaO$fn'
    str_2 = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    str_3 = '127.0.0.1'
    str_4 = '0xff000000'
    str_5 = '127.1.1.1'
    str_6 = '0xff000000'
    str_7 = 'Ethernet'
    str_8 = 'active'
    str_9 = '10:9a:dd:f4:cf:03'
    str_10 = 'unknown'
    str_11 = 'loopback'
    str_12 = 'ether'
    str_13 = 'Wi-Fi'
    str_14 = 'loopback0'

# Generated at 2022-06-24 22:46:13.579602
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'route -n get default'
    str_2 = 'route -n get -inet6 default'
    ret_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1, str_2)


# Generated at 2022-06-24 22:46:17.233504
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_2 = '/sbin/ifconfig'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_2)
    str_3 = '-a'
    tuple_0 = (generic_bsd_ifconfig_network_1.get_interfaces_info(str_2), str_3)
    assert len(tuple_0) == 2


# Generated at 2022-06-24 22:46:26.861429
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'ether'
    str_2 = '00:00:00:00:00:00'
    list_0 = ['ether', '00:00:00:00:00:00']
    dict_0 = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '00:00:00:00:00:00'}
    dict_1 = {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}

# Generated at 2022-06-24 22:46:46.098479
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {}
    str_0 = 'ge0'
    str_1 = {}
    interfaces[str_0] = str_1
    str_2 = 'ether'
    str_3 = 'Ethernet autoselect (100baseTX full-duplex)'
    str_1['media'] = str_3
    str_2 = 'unknown'
    str_1['type'] = str_2
    str_4 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_4)
    str_3 = 'ether'
    str_2 = 'type'
    str_1[str_2] = str_3

# Generated at 2022-06-24 22:46:57.683968
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'by*RTtktLksaO$fn'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    ansible_facts = dict()
    ansible_facts['ansible_network_resources']['interfaces'] = list()
    ansible_facts['ansible_network_resources']['interfaces'].append('ansible_interface_name')
    ansible_facts['ansible_network_resources']['interfaces'].append('macaddress')
    ansible_facts['ansible_network_resources']['interfaces'].append('ipv4')
    ansible_facts['ansible_network_resources']['interfaces'].append('ipv6')

# Generated at 2022-06-24 22:47:06.720939
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # ifconfig_path = None
    # ifconfig_options = None
    # cmd_result = dict(rc=1, stdout='ifconfig_path does not exist\n', stderr='ifconfig_path does not exist\n')
    # generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('GenericBsdIfconfigNetwork')
    # generic_bsd_ifconfig_network_0.module = ModuleStub(cmd_result)
    # interfaces = dict()
    # var_0 = generic_bsd_ifconfig_network_0.detect_type_media(interfaces)
    pass # TODO: Write test


# Generated at 2022-06-24 22:47:16.848721
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'KY+!r_x2P'
    str_1 = 'EB_HaB'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    str_2 = 'Ky'
    dict_0[str_1] = dict_1
    dict_0[str_2] = dict_2
    dict_1[str_1] = dict_0
    dict_3 = {}
    dict_4 = {}
    dict_3['ipv4'] = dict_4
    dict_3['ipv6'] = dict_4
    dict_1[str_2] = dict_3
    str_3 = 'interface'
    dict_5 = {}
    dict_5[str_3] = str_0
    str_4 = ''
    dict_6 = {}

# Generated at 2022-06-24 22:47:20.298382
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '9g7hFqekJ0V^e5w'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '#8W(^$q3n'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:47:26.728144
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '`^wEb@WWmFt'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    # Test with True argument
    str_1 = '.'
    result_1 = generic_bsd_ifconfig_network_0.populate(str_1)


# Generated at 2022-06-24 22:47:34.709495
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    str_0 = 'Y#$QQQQ$TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT$`}-log'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'ether'
    str_2 = '!<X!BV~uo%#:91]^'
    dict_3 = {}
    dict_4 = {}
    generic_bsd_ifconfig_network_0.parse_ether_line(str_1, str_2, dict_3, dict_4)


# Generated at 2022-06-24 22:47:43.219381
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = ''
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'route'
    str_2 = 'route6'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    var_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_2)


# Generated at 2022-06-24 22:47:47.606113
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    assert GenericBsdIfconfigNetwork.parse_inet_line(str, list, dict, dict) == None


# Generated at 2022-06-24 22:47:57.890261
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = 'GenericBsdIfconfigNetwork'
    func = 'parse_inet6_line'
    current_if = {'device': 'xl0',
                  'ipv4': [],
                  'ipv6': [],
                  'type': 'ether',
                  'macaddress': '00:03:47:20:15:d4',
                  'metric': '0',
                  'mtu': '1500',
                  'options': [],
                  'flags': ['BROADCAST',
                            'SIMPLEX',
                            'MULTICAST'],
                  'media': 'Ethernet autoselect (100baseTX <full-duplex>)',
                  'status': 'active'}

# Generated at 2022-06-24 22:48:13.716397
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    str_0 = 'CohGr0r'
    var_7 = [..., '84.7.154.205', '222.255.255.0']
    var_8 = {'address': '84.7.154.205', 'netmask': '222.255.255.0'}
    var_9 = {'broadcast': '84.7.154.255', 'network': '84.7.154.0'}

    generic_bsd_ifconfig_network_0.parse_inet_line(var_7, var_8, var_9)


# Generated at 2022-06-24 22:48:17.892460
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    words = ['words', 'words', 'words']
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Test pass
    try:
        GenericBsdIfconfigNetwork.parse_ether_line(words, current_if, ips)
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-24 22:48:28.350965
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:48:33.568278
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'CohGr0r'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['media:', 'Ethernet', '10Gbase-LR', '(1000baseT)']
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_1.parse_media_line(words_0, current_if_0, ips_0)
    assert current_if_0 == {'media': 'Ethernet', 'media_select': '10Gbase-LR', 'media_type': '(1000baseT)'}
    assert ips_0 == {}
    words_1 = ['media:', 'Ethernet', '10Gbase-LR', '(1000baseT)', 'none']


# Generated at 2022-06-24 22:48:44.074730
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'eth3'
    str_1 = 'Linux'
    str_2 = 'lo'
    str_3 = '127.0.0.1'
    str_4 = '127.0.0.1'
    str_5 = '127.0.0.1'
    str_6 = '255.0.0.0'
    str_7 = '127.0.0.1'
    str_8 = '127.0.0.1'
    str_9 = '255.0.0.0'

# Generated at 2022-06-24 22:48:51.189675
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network_0 = GenericBsdIfconfigNetwork('F')
    words_0 = ['f', 'j', 'k', 'l', 'm', 'n']
    current_if_0 = {'ipv4': []}
    ips_0 = {}
    network_0.parse_inet_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:49:02.249046
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Input parameters
    words = ['dummy', '2001:db8::1/64', 'prefixlen', '64']
    current_if = {}
    ips = {}

    # Module import
    module_name = 'ansible_collections.community.general.plugins.modules.network.generic_bsd_ifconfig'
    module = importlib.import_module(module_name)
    base_class_name = 'GenericBsdIfconfigNetwork'
    base_class = getattr(module, base_class_name)

    # Call method
    method = base_class.parse_inet6_line
    base_class.parse_inet6_line(words, current_if, ips)

    assert isinstance(current_if, dict) is True
    assert isinstance(ips, dict) is True


# Generated at 2022-06-24 22:49:08.476486
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'CohGr0r'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(str_0)


# Generated at 2022-06-24 22:49:12.740759
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    intf_0 = 'a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(intf_0)
    str_0 = 'nY'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_0)


# Generated at 2022-06-24 22:49:20.939153
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'CohGr0r'
    list_0 = ['CohGr0r']
    list_1 = ['CohGr0r']
    dict_0 = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    parse_inet6_line_0 = generic_bsd_ifconfig_network_0.parse_inet6_line(list_0, {}, list_1, dict_0)

# Generated at 2022-06-24 22:49:42.127406
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'CohGr0r'
    str_1 = 'OZHmq3f'
    str_2 = 'tC'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.merge_default_interface(str_1, str_2, str_0)

if __name__ == '__main__':
    str_0 = 'CohGr0r'
    str_1 = 'OZHmq3f'
    str_2 = 'tC'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

# Generated at 2022-06-24 22:49:47.383390
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'mDv2Qm'
    str_1 = 'kX9YrZ'
    str_2 = 'zsJ4'
    dict_0 = {'address': 'zsJ4', 'prefix': '0', 'scope': 'Q'}
    list_0 = [str_1, str_0, str_2]
    dict_1 = {'address': 'Q', 'prefix': str_0, 'scope': '1'}
    # \[('address': '[B', 'prefix': 'J3zq', 'scope': 'FpjR'), ('address': 'UJ7', 'prefix': '[P', 'scope': 'KjgD')\]
    # ipv6 = \[('address': 'G', 'prefix': 'p', 'scope': 'z'), ('address': '

# Generated at 2022-06-24 22:49:56.518885
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_2 = 'bFZoW'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)
    str_3 = 'u8eOV'
    str_4 = 'jq6Q8'
    var_9 = generic_bsd_ifconfig_network_2.get_interfaces_info(str_3, str_4)

if __name__ == '__main__':
    import sys
    if sys.argv[1] == 'gen_params': # generate test case parameters
        param_gen = ParameterGenerator()
        param_gen.gen_test_case()
    else: # run unit tests
        test_GenericBsdIfconfigNetwork_get_interfaces_info()
        test_case_0()