

# Generated at 2022-06-24 22:40:42.721594
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_1 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    words_1 = ['XyJ$n_jC|[;']
    current_if_1 = {}
    ips_1 = {}

    # Call the method
    result_1 = generic_bsd_ifconfig_network_1.parse_inet6_line(words_1, current_if_1, ips_1)

    # Check if the result is as expected
    if result_1 != None:
        print("TestCase0: parse_inet6_line() failed")
        sys.exit(1)


# Generated at 2022-06-24 22:40:52.880662
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'

# Generated at 2022-06-24 22:41:01.117958
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'P'
    str_1 = 'D\x1c\xe0\xed'
    str_2 = '{'
    str_3 = '\x0c\xe4\xfe\xb7v'
    str_4 = '\x1c\x97\x01lB'
    str_5 = '\x84\xd6dW8\x9b'

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    dict_0 = dict()
    dict_0['device'] = str_1
    dict_0['ipv4'] = list()
    dict_0['ipv6'] = list()
    dict_0['type'] = str_2
    dict_0['flags'] = list()

# Generated at 2022-06-24 22:41:05.513357
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = '*\n<\n.fpw-a\n*\n*\n4\n<\n'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    assert generic_bsd_ifconfig_network_0.get_options(str_0) == ['.fpw-a']


# Generated at 2022-06-24 22:41:07.863438
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    assert True == True


# Generated at 2022-06-24 22:41:10.982495
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'DkzE~r|_'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'F~\'Y;/b'


# Generated at 2022-06-24 22:41:20.254596
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '`#C"W2g8Bv\x086d\n'
    str_1 = 'v\x0eN\x12L\x01\x0b\x0e'
    str_2 = '+F"a\x11\x00\x0b\x0e'
    str_3 = '+F"a\x11\x00\x0b\x0e'
    str_4 = 'v\x0eN\x12L\x01\x0b\x0e'
    str_5 = '+F"a\x11\x00\x0b\x0e'
    str_6 = '+F"a\x11\x00\x0b\x0e'

# Generated at 2022-06-24 22:41:26.973945
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Test parsing of the default loopback line on a FreeBSD 8.0 box
    line = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384"
    words = line.split()
    current_if = GenericBsdIfconfigNetwork.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['metric'] == '0'
    assert current_if['mtu'] == '16384'
    assert current_if['type'] == 'loopback'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['macaddress'] == 'unknown'

# Generated at 2022-06-24 22:41:37.248511
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    str_1 = "p&"
    bool_1 = False
    int_1 = 32731
    double_1 = 0.0234
    str_2 = "2v_AE"
    str_3 = "gwy;z{05"
    str_4 = ">"
    bool_2 = True
    str_5 = "HX_a"
    list_0 = [str_1, bool_1, int_1, double_1, str_2, str_3, str_4, bool_2, str_5]
    str_6 = "TmvO_"

# Generated at 2022-06-24 22:41:47.082721
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    defaults_0 = dict()
    defaults_0['interface'] = '~w5d[/'
    interfaces_0 = dict()
    interfaces_0['~w5d[/'] = dict()
    interfaces_0['~w5d[/']['ipv4'] = []
    interfaces_0['~w5d[/']['ipv6'] = []
    ip_type_0 = 'ipv4'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0)


# Generated at 2022-06-24 22:42:11.914685
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print_debug()
    str_0 = '!(9F?I\x0cH\r'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '-1'
    var_0, var_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)
    assert var_0 == eval(str_0), 'Expected vars to be the same\'%s\' but got \'%s\'' % (str_0, var_0)
    assert var_1 == eval(str_1), 'Expected vars to be the same\'%s\' but got \'%s\'' % (str_1, var_1)


# Generated at 2022-06-24 22:42:17.916558
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'P=g2'
    str_1 = 'P=g2'
    str_2 = 'P=g2'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_1)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_2)


# Generated at 2022-06-24 22:42:29.576785
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_1 = 'wls1:'
    str_2 = '\tflags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500'
    str_3 = '\teether 00:11:22:33:44:55'
    str_4 = '\tinet 10.0.0.2 netmask 0xffffff00 broadcast 10.0.0.255'
    str_5 = '\tnd6 options=1<PERFORMNUD>'
    str_6 = '\tmedia: IEEE 802.11 Wireless Ethernet autoselect (autoselect)'
    str_7 = '\tstatus: associated'
    str_8 = '\tssid "SSID"'
    str_9 = '\tchannel 1 (2412 MHz 11g)'
    str_10

# Generated at 2022-06-24 22:42:39.449558
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'Z"j#n<Ok4Y\t\tHB'
    dict_0 = dict()
    dict_0['all_ipv4_addresses'] = []
    dict_0['all_ipv6_addresses'] = []
    generic_bsd_ifconfig_network_0.parse_inet_line(str_1, dict_0, dict_0)



# Generated at 2022-06-24 22:42:47.392416
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '\x0c'
    str_1 = '\x0c\x0c'
    str_1 = '\x0c\x0c\x0c'
    str_1 = '\x0c\x0c\x0c\x0c'
    str_1 = '\x0c\x0c\x0c\x0c\x0c'
    str_1 = '\x0c\x0c\x0c\x0c\x0c\x0c'

# Generated at 2022-06-24 22:42:48.859613
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    assert True

# Generated at 2022-06-24 22:42:55.768035
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.parse_interface_line(str_0)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.populate(str_0)


# Generated at 2022-06-24 22:43:03.316085
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '@p/} dH8>LM;rF'
    str_1 = 'M@8tB:C1)Y`'
    str_2 = 'x0o@l-a0VZ'
    str_3 = 'fzy$0o7~y'
    str_4 = 'v+;@Dn}=*'
    str_5 = 'n:9J-7=.e'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_3 = GenericBsdIf

# Generated at 2022-06-24 22:43:08.328039
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # need to create instance of GenericBsdIfconfigNetwork first
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    str_1 = 'lI NXYA]'
    generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 22:43:12.914190
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = '\tmedia: Ethernet autoselect (1000baseT <full-duplex>)'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.parse_media_line(str_0)


# Generated at 2022-06-24 22:43:26.754093
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    assert True


# Generated at 2022-06-24 22:43:37.969595
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    str_1 = 'Z"j#n<Ok4Y\t\tHB'
    str_2 = 'Z"j#n<Ok4Y\t\tHB'
    str_3 = 'Z"j#n<Ok4Y\t\tHB'
    str_4 = 'Z"j#n<Ok4Y\t\tHB'
    str_5 = 'Z"j#n<Ok4Y\t\tHB'
    str_6 = 'Z"j#n<Ok4Y\t\tHB'
    str_7 = 'Z"j#n<Ok4Y\t\tHB'
    str_8 = 'Z"j#n<Ok4Y\t\tHB'
   

# Generated at 2022-06-24 22:43:41.000285
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = ''
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.parse_inet_line(str_0, str_0, str_0)


# Generated at 2022-06-24 22:43:49.270134
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'a=b\tb=c\nc=d\n'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    assert var_0 == (None, None)


# Generated at 2022-06-24 22:44:01.275515
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    str_1 = 'Z"j#n<Ok4Y\t\tHB'
    str_2 = 'Z"j#n<Ok4Y\t\tHB'
    str_3 = 'Z"j#n<Ok4Y\t\tHB'
    str_4 = 'Z"j#n<Ok4Y\t\tHB'
    str_5 = 'Z"j#n<Ok4Y\t\tHB'
    str_6 = 'Z"j#n<Ok4Y\t\tHB'
    str_7 = 'Z"j#n<Ok4Y\t\tHB'
    str_8 = 'Z"j#n<Ok4Y\t\tHB'
   

# Generated at 2022-06-24 22:44:06.870917
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '-J<8X1q\x00g\x1ad'
    str_1 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(str_1) == (str_0, str_1)


# Generated at 2022-06-24 22:44:16.704928
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    str_1 = 'Z"j#n<Ok4Y\t\tHB'
    str_2 = 'Z"j#n<Ok4Y\t\tHB'
    str_3 = 'Z"j#n<Ok4Y\t\tHB'
    str_4 = 'Z"j#n<Ok4Y\t\tHB'
    str_5 = 'Z"j#n<Ok4Y\t\tHB'
    str_6 = 'Z"j#n<Ok4Y\t\tHB'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

# Generated at 2022-06-24 22:44:29.611095
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Z"j#n<Ok4Y\t\tHB'
    str_1 = 'L9<2U.>4F3\t\t0M'
    str_2 = 'S7Vg\t6ck%\t\tH6'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    var_0 = generic_bsd_ifconfig_network_0.parse_interface_line(str_1)
    var_1 = generic_bsd_ifconfig_network_0.parse_interface_line(str_2)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)

# Generated at 2022-06-24 22:44:39.874338
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:44:48.414041
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '\xa8\x90\x1b\x12\x83\xc5\x94\xa5\x0e\xfa\x93\x69\x89\x2f\xf8\x20\x00\x00\x00\x00\x00\x00\x00\x01'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    # Call the method of class GenericBsdIfconfigNetwork with the appropriate arguments
    generic_bsd_ifconfig_network_0.parse_inet6_line(str_0)


# Generated at 2022-06-24 22:45:07.139576
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    print("test_GenericBsdIfconfigNetwork_parse_inet6_line")

    # Initializing arguments
    words = []
    current_if = {}
    ips = {}

    # Calling parse_inet6_line method of GenericBsdIfconfigNetwork.
    GenericBsdIfconfigNetwork.parse_inet6_line(words, current_if, ips)


# Generated at 2022-06-24 22:45:14.445975
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '>\tauthencrypt0: flags=8011<UP,POINTOPOINT,MULTICAST> mtu 1280\t\n\tinet 10.1.1.1 --> 10.1.1.2 netmask 0xffffff00\n'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['authencrypt0:', 'flags=8011<UP,POINTOPOINT,MULTICAST>', 'mtu', '1280', 'inet', '10.1.1.1', '-->', '10.1.1.2', 'netmask', '0xffffff00']

# Generated at 2022-06-24 22:45:26.227044
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'hw\\P-#O\x0bS'

# Generated at 2022-06-24 22:45:28.698773
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(str_0)


# Generated at 2022-06-24 22:45:33.837580
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'x\xa0z'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)


# Generated at 2022-06-24 22:45:37.445625
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0)


# Generated at 2022-06-24 22:45:46.970418
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    default_ipv4, default_ipv6 = {}, {}

# Generated at 2022-06-24 22:45:49.783479
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '+-\x0b5\x00\x02\x00?\x0b\x00'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(str_0)


# Generated at 2022-06-24 22:45:55.360573
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    int_0 = random.randint(0, 100000)
    list_0 = [int_0]
    int_1 = random.randint(0, 100000)
    int_2 = random.randint(0, 100000)
    int_3 = random.randint(0, 100000)
    int_4 = random.randint(0, 100000)
    int_5 = random.randint(0, 100000)
    int_6 = random.randint(0, 100000)
    int_7 = random.randint(0, 100000)
    int_8 = random.randint(0, 100000)



# Generated at 2022-06-24 22:46:05.189369
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    print('Testing parse_inet6_line')
    str_0 = 'hw\\P-#O\x0bS'
    str_1 = ' \x1f\x1f'
    str_2 = 'hw\\P-#O\x0bS'
    str_4 = 'hw\\P-#O\x0bS'
    str_5 = 'hw\\P-#O\x0bS'
    str_6 = 'hw\\P-#O\x0bS'
    str_7 = 'hw\\P-#O\x0bS'
    words = ['hw\\P-#O\x0bS', '\x1f\x1f']
    current_if = {'ipv6': []}

# Generated at 2022-06-24 22:46:26.206921
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(generic_bsd_ifconfig_network_0, str_0)
    test_GenericBsdIfconfigNetwork_get_default_interfaces()
    test_GenericBsdIfconfigNetwork_get_interfaces_info(str_0)


# Generated at 2022-06-24 22:46:38.450342
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['S\x0c', 'P#O\x0bS', 'Q-U', 'ZU\x0c\x0c', 'Q-', '\x0c\x0c\x0c\x0c\x0c\x0c\x0c\x0c\x0c\x0c']
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_media_line(words_0, current_if_0, ips_0)
    # Test the method is correctly setting the dictionary values
    assert current_if

# Generated at 2022-06-24 22:46:47.179331
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '127.0.0.1'
    str_1 = '0xff000000'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    current_if = {'ipv4': []}
    ips = {'all_ipv4_addresses': []}
    words = [str_0, str_0, str_1, str_1, str_0, str_0]
    generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1', "generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips) failed."
   

# Generated at 2022-06-24 22:46:58.204738
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    global generic_bsd_ifconfig_network_0
    str_4 = '%t1\xe3\xed\xafb\x07C\xfe\xfb(\x11'
    str_0 = '\xf1\x1b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_4)
    str_3 = '\x00\xe7"L\xfd\x87\x9b\x9b\xa5\xaa\xe6>\xc6'
    generic_bsd_ifconfig_network_0.detect_type_media(str_3)
    str_1 = '\xcc\xbb\xe7\x9c\x18'

# Generated at 2022-06-24 22:47:07.689409
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'media: Ethernet 10baseT/UTP <full-duplex>'
    str_2 = 'hw\\P-#O\x0bS'
    dict_1 = generic_bsd_ifconfig_network_0.parse_media_line(str_1, str_2, str_0)
    assert len(dict_1) == 3
    assert dict_1['media'] == 'Ethernet 10baseT/UTP'
    assert dict_1['media_select'] == '<full-duplex>'


# Generated at 2022-06-24 22:47:12.800212
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('hw\\P-#O\x0bS')
    var_1 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:47:13.694506
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    assert True


# Generated at 2022-06-24 22:47:21.090577
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    module_0 = ansible_module_0()
    module_0.params = {'collected_facts': {'kernel': 'Linux'}}
    var_0 = generic_bsd_ifconfig_network_0.populate(module_0)


# Generated at 2022-06-24 22:47:31.918953
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '=R@\x0b4U\x0b\x0b\x14\x0b"\x0b\x0b\x0b\x0b\x0e\x0b\x0b2U\x0b\x0b-\n\x0b'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    rc_0, out_0, err_0 = generic_bsd_ifconfig_network_0.module.run_command(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_0)


# Generated at 2022-06-24 22:47:43.790504
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.populate(str_0)
    dict_0 = dict()
    dict_0['device'] = str_0
    dict_0[str_0] = dict_0
    dict_0['ipv4'] = [dict_0]
    dict_0['ipv6'] = [dict_0]
    dict_0['type'] = str_0
    dict_0[str_0] = dict_0
    dict_0['media'] = 'ether'
    var_0 = generic_bsd_ifconfig_network_0.detect_type_media(dict_0)
   

# Generated at 2022-06-24 22:48:04.629949
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'hw\\P-#O\x0bS'
    defaults = dict()
    interfaces = dict()
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:48:11.037631
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = '=\x15\x03\x11\x1a\x10p'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '\x0f<\x0e\x1d\x1c='
    str_2 = '\x03\rv\r@\x0b\x17'
    str_3 = '(\x0b\x16\x1d\x1a\x1c'
    generic_bsd_ifconfig_network_0.merge_default_interface(str_1, str_2, str_3)


# Generated at 2022-06-24 22:48:17.047313
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    a0 = ['\x94`\x0b\x14\x12', '\x00\x00\x008\x1d\x00\x00\x00\x00\x00\x00\x00', '\x00\x00\x00\x0b', '\x00\x00\x00\x00']
    a1 = dict({'broadcast': '127.0.0.1', 'network': '127.0.0.1', 'address': '127.0.0.1', 'netmask': '255.0.0.0'})
    a2 = dict()
    generic_bs

# Generated at 2022-06-24 22:48:25.632470
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults_0 = {}
    interfaces_0 = {}
    ip_type_0 = '/'
    # test method merge_default_interface of class GenericBsdIfconfigNetwork with parameters (defaults_0, interfaces_0, ip_type_0)
    test_GenericBsdIfconfigNetwork_merge_default_interface_0(defaults_0, interfaces_0, ip_type_0)


# Generated at 2022-06-24 22:48:33.699591
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '\x09\x07T\x07\x9a\xe8\x1a\x07\x1f\x06\xd0\x03\x17\x05\x0f\x04\x00\x03\xfd\x02\xe8\x01\x08\x00\x00'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

# Generated at 2022-06-24 22:48:41.662938
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = 's\x1a\x1dw\x1e\x1eZ)\x05\x7f\x17\r\x1a'

# Generated at 2022-06-24 22:48:49.860129
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1)
    str_2 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2)
    str_3 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_3 = GenericBsdIfconfigNetwork(str_3)
    str_4 = 'hw\\P-#O\x0bS'
    generic_bs

# Generated at 2022-06-24 22:49:01.281821
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = ''
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)

    # Call method
    # with param
    str_1 = '     eth0    Link encap:Ethernet  HWaddr 64:e5:99:1b:fd:c6  '
    str_2 = '     UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1 '
    str_3 = '     RX packets:0 errors:0 dropped:0 overruns:0 frame:0 '
    str_4 = '     TX packets:0 errors:0 dropped:0 overruns:0 carrier:0 '
    str_5 = '     collisions:0 txqueuelen:1000 '

# Generated at 2022-06-24 22:49:12.792976
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    assert callable(GenericBsdIfconfigNetwork.merge_default_interface)
    str_0 = 'dsC\tWe\x18'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    str_1 = '\x1a\x1f=\x18'
    list_0 = list()
    list_0.append(str_1)
    str_2 = 'r@\x12'
    str_3 = '\x1a\x1f=\x18'
    list_0.append(str_3)
    str_4 = '\x1a\x1f=\x18'
    list_0.append(str_4)
    str_5 = '\x1a\x1f=\x18'
   

# Generated at 2022-06-24 22:49:21.960253
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test for method get_interfaces_info(self, ifconfig_path)
    # This should fail gracefully when no ifconfig is found
    str_0 = 'hw\\P-#O\x0bS'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    try:
        var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0)
    except:
        var_0 = "An exception occurred"
    assert var_0 == "An exception occurred", "The value returned was not what was expected!"
