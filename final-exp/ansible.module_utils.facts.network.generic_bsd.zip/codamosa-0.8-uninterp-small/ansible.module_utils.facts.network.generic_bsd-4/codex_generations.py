

# Generated at 2022-06-24 22:40:42.221849
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'V'
    str_1 = '9p.hC'
    str_2 = '*O@|>-^'
    str_3 = 'OIti'
    str_4 = 'B2]g'
    str_5 = 'FnZ'
    str_6 = '^4>}a'
    str_7 = 'UeI;'
    str_8 = '/W!c%'
    str_9 = '=tN\\Y">'
    str_10 = 'IpF)'
    str_11 = 'R'
    str_12 = '8`'
    str_13 = 'x'
    str_14 = 'D"ka|/'
    str_15 = '1'
    str_16 = 'E'

# Generated at 2022-06-24 22:40:52.234164
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'X@;^u8SHVfrD`tbKql-'
    # Test with no 'address' in defaults
    defaults_0 = {}
    defaults_0['interface'] = 'eZ"/'
    interfaces_0 = {}
    interfaces_0[defaults_0['interface']] = {}

# Generated at 2022-06-24 22:41:01.027890
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print('')
    print('Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork')

    str_1 = '/*bvgC/g2Y=XNyd'
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    str_3 = ';l2Q<x'
    str_4 = 'e6U'
    str_5 = '%%qY9]r_E'
    str_6 = '?\\87B[:T"T16E_T"`)p0$MT'
    str_7 = 'x{g'
    str_8 = '7zv^'
    str_9 = '3Yp>'
    str_10 = 'Lw%?m'

# Generated at 2022-06-24 22:41:10.827149
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 't'
    str_1 = '<;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)

    #netbsd show aliases like this
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0.0.1 netmask 0xff000000
    #         inet alias 127.1.1.1 netmask 0xff000000
    # word_0 = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet',

# Generated at 2022-06-24 22:41:16.576252
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    str_1 = "/5`*?#3"
    str_2 = "S<o8|6'i;<h>Fv{:W"
    str_3 = "h&n"
    str_4 = "6Qh`>0)Uv0:4dW8H"
    str_5 = "k>Od"
    str_6 = 'RbPg"'.join([str_5, str_5, str_5, str_2])

# Generated at 2022-06-24 22:41:20.982165
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'h^L'
    str_1 = '-'
    str_2 = '0'
    str_3 = ' `:c'
    str_4 = '8x'
    str_5 = ''
    str_6 = 'A\t'
    str_7 = 'b[|'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    str_8 = 'oX?F95y$'
    str_9 = '/k'
    str_10 = ' '

# Generated at 2022-06-24 22:41:27.481952
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    str_3 = '=tN\\Y"><;[6xD"ka|/Q'
    str_4 = '=tN\\Y"><;[6xD"ka|/Q'
    str_5 = '=tN\\Y"><;[6xD"ka|/Q'
    str_6 = '=tN\\Y"><;[6xD"ka|/Q'
    str

# Generated at 2022-06-24 22:41:37.484498
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '>O!XUJ"K]p/Y[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '>C!2UJ"K]p/Y[6xD"ka|/Q'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, str_1)
    str_2 = '>O!2UJ"K]p/Y[6xD"ka|/Q'
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_2, str_2)

# Generated at 2022-06-24 22:41:43.922457
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, str_1)
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_1.get_interfaces_info(str_2, str_2)


# Generated at 2022-06-24 22:41:50.970380
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '!_=6'
    str_1 = '9Qy,ni'
    str_2 = 'g7TK*qZz]'
    str_3 = '$*K9'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    if (generic_bsd_ifconfig_network_0.module.get_bin_path(str_2) is None):
        pass
    else:
        if (generic_bsd_ifconfig_network_0.module.get_bin_path(str_3) is None):
            pass
        else:
            generic_bsd_ifconfig_network_0.get_default_interfaces(str_3)
            str_4 = '-a'
            generic_bsd_

# Generated at 2022-06-24 22:42:03.136286
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 22:42:14.209267
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    if_0 = 'N.{:C>P&?W'
    platform_0 = 'Generic_BSD_Ifconfig'
    ifconfig_path_0 = '['
    command_0 = {}
    interface_0 = {}
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.get_default_interfaces(ifconfig_path_0)
    generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_path_0)

# Generated at 2022-06-24 22:42:20.212462
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 's}sWd'
    str_1 = 't/gy{g&F8W'
    list_0 = [str_0, str_1]
    generic_bsd_ifconfig_network_0.parse_media_line(list_0, str_1, str_0)
    str_0 = 'k|>'
    str_1 = '/6*j\D<P7'
    list_0 = [str_0, str_1]

# Generated at 2022-06-24 22:42:31.064287
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    arg_0 = '3^E8Yb|>7v'
    arg_1 = '-a'
    arg_2 = '>+o\'$=('
    arg_3 = 'xiE`"0"y'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(arg_0, arg_1)
    generic_bsd_ifconfig_network_0.module = arg_2
    generic_bsd_ifconfig_network_0.module.get_bin_path = MagicMock(return_value='`~#.X6')

# Generated at 2022-06-24 22:42:41.581294
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    str_0 = '5+t$ae2:VEJX?|A'
    dict_0 = dict()
    list_0 = ['2]nVK', '2]nVK', "'", 'rK?B', '#=', '+t$ae2:VEJX?|A']
    dict_1 = dict()
    dict_2 = dict()
    dict_2['address'] = '2]nVK'
    dict_3 = dict()
    dict_3['broadcast'] = '+t$ae2:VEJX?|A'
    dict_3['address'] = '2]nVK'
    dict_3['netmask'] = "rK?B"
    dict_4 = dict()
    dict_4['address'] = '2]nVK'

# Generated at 2022-06-24 22:42:48.646808
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Test case data
    str_0 = 'ether 00:00:00:00:00:01'
    str_1 = '00:00:00:00:00:01'
    str_2 = 'ether '
    str_3 = 'ether 00:00:00:00:00:01 media: Ethernet 10Gbase-T media_type: Copper status: active'
    str_4 = 'ether 00:00:00:00:00:01 media: Ethernet 10Gbase-T media_type: Copper status: active options=1<RXCSUM,TXCSUM>'

# Generated at 2022-06-24 22:42:56.655863
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_1 = 'x@b|Mk]U'
    lega_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, str_1)
    str_2 = 'z$#]/B'
    str_3 = '/G~^'
    tuple_1 = lega_bsd_ifconfig_network_1.get_default_interfaces(str_2, str_3)
    assert type(tuple_1) == tuple
    assert len(tuple_1) == 2
    assert 'interface' in tuple_1[0]


# Generated at 2022-06-24 22:43:03.359187
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    network_facts_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:43:10.607439
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'V?#Fl{hEWDxHk6w$U6n}U'
    str_1 = '<n[n5V5)Zm+V$a(wc.=V2'
    str_2 = 'Xj;uEoV$Y&pMhuEjP@zw+'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    interfaces = {}
    str_3 = 'ether'
    str_4 = 'ether'
    str_5 = 'ether'
    str_6 = 'ether'
    str_7 = 'ether'
    str_8 = 'ether'
    str_9 = 'ether'
    str_10 = 'ether'
    str_11 = 'ether'


# Generated at 2022-06-24 22:43:19.806128
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path0 = '/sbin/ifconfig'
    ifconfig_options0 = '-a'
    # create dummy interfaces info

# Generated at 2022-06-24 22:43:40.332887
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    str_1 = 'Bd[1f#2l$+e0IacY3w6U|>'
    str_2 = '{2}m_8Jv"'
    str_3 = '{2}m_8Jv"'
    list_0 = [str_0, str_1, str_2, str_3]
    str_4 = 'xI2E?*n_Mjqz^'
    str_5 = 'R;<C@>g-s1t0x?2)NdybzMQ'
    str_6 = 'PX`i/}T/TtW.8b'
    list_1 = [str_4, str_5, str_6]


# Generated at 2022-06-24 22:43:52.525183
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'd#j/^&/}iI:=72_bM,m3i&\n'
    str_1 = '^G.f$uV7e.zd1n'
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    str_3 = '6fXU'
    str_4 = '})(M,6p~D54K1T6'
    str_5 = '>@aGG`"=+'
    # Uncomment next line and replace correct value for global 'test_interfaces'
    #test_interfaces = ""
    # Uncomment next line and replace correct value for global 'test_ips'
    #test_ips = ""
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:44:01.647540
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    try:
        print('Testing populate')
        str_0 = '%q61;{F6NO1X9Iy0_|:<>'
        generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
        args_0 = {}
        args_0['collected_facts'] = None
        ret_2 = generic_bsd_ifconfig_network_0.populate(**args_0)
        ret_3 = generic_bsd_ifconfig_network_0.populate()
        return ret_3
    except AttributeError as e_4:
        pass


# Generated at 2022-06-24 22:44:13.667197
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'c%(<,b+#1Ft_0m4'
    str_1 = ','
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    str_3 = 'u|#5)`w'
    str_4 = 'nh$<(8g|4k'
    str_5 = 'h,'
    str_6 = ' a<|?~'
    str_7 = '9'
    str_8 = '+Mk'
    str_9 = '+/'
    str_10 = 'U'
    str_11 = '+/'
    str_12 = 'n'
    str_13 = '='
    str_14 = '`U'
    str_15 = '>'
    str_16

# Generated at 2022-06-24 22:44:21.243672
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'z3t\x18-^\x00.\x10/\x08\x1b\x0b\x0b\x1b\x00\x08\x00\x00\x00\x1c\x07\x02'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '+G'
    str_2 = '+G'
    generic_bsd_ifconfig_network_0.module = UUTModule(str_1, str_2)

# Generated at 2022-06-24 22:44:33.455937
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    str_3 = '=tN\\Y"><;[6xD"ka|/Q'
    str_4 = '=tN\\Y"><;[6xD"ka|/Q'
    str_5 = '=tN\\Y"><;[6xD"ka|/Q'
    str_6 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    generic

# Generated at 2022-06-24 22:44:42.627464
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '=X\\K3b)^t\\k<:yE?`'
    str_2 = 'xrG,Hrv00K9F&8[,B'
    str_3 = 's&iW8;C!}xn?sRHG,\\'
    str_4 = '\\|_{FpwU,G'
    str_5 = 'Efz?%|7gRl>9:yG?C'

# Generated at 2022-06-24 22:44:48.265415
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:44:52.842891
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    # Setup
    test_interface = {
        'test0': {
            'type': 'unknown',
            'media': 'Ethernet 10Gbase-SR',
        }
    }
    test_type = 'ether'

    # Exercise
    actual = GenericBsdIfconfigNetwork(None, None).detect_type_media(test_interface)

    # Verify
    assert actual['test0']['type'] == test_type



# Generated at 2022-06-24 22:45:03.268740
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'interface'
    str_1 = 'address'
    str_2 = 'ipv4'
    str_3 = 'ipv6'
    str_4 = 'default_ipv4'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    # Generate random data for method invocation
    str_5 = generate_random_string(10)
    str_6 = generate_random_string(10)
    int_0 = random.randint(-55, -1)
    int_1 = random.randint(-55, -1)
    int_2 = random.randint(-55, -1)
    int_3 = random.randint(-55, -1)
    int_4 = random.randint(-55, -1)

# Generated at 2022-06-24 22:45:26.928719
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network_0 = GenericBsdIfconfigNetwork(None, None)

# Generated at 2022-06-24 22:45:35.583506
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_1 = '^j7.Q_EH'
    str_2 = 'X5dow^'
    str_3 = 'Mf`h'
    str_4 = 'W?g'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_1, str_2)
    try:
        generic_bsd_ifconfig_network_0.populate(str_3)
    except NameError:
        print("NameError")
    except ValueError:
        print("ValueError")
    except NotImplementedError:
        print("NotImplementedError")


# Generated at 2022-06-24 22:45:40.971450
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('rcvy', 'rcvy')
    generic_bsd_ifconfig_network_0.platform = 'dVyM9F'
    str_0 = 'RCvy'
    str_1 = '*66O<gC#'
    list_0 = [str_1, str_0]
    dict_0 = dict()
    dict_0['address'] = 'jd*(\'9F'
    dict_1 = dict()
    dict_1['broadcast'] = 'H'
    dict_1['address'] = 'Rt'
    dict_1['netmask'] = 'G)f'
    dict_1['network'] = '5-'
    dict_2 = dict()

# Generated at 2022-06-24 22:45:48.625282
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    # Test for successful call

# Generated at 2022-06-24 22:46:00.048144
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print('Testing for exception (TypeError) in get_default_interfaces')
    str_0 = 'sT#T{b~9X1|'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    try:
        generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    except TypeError:
        pass
    else:
        print('Expected TypeError!')
    print('Testing get_default_interfaces for return type')
    str_0 = 'aZ[&=0M1>'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

# Generated at 2022-06-24 22:46:09.986730
# Unit test for method get_options of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:46:19.738625
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test case 0
    str_0 = '/usr/sbin/route'
    str_1 = '-n get default'
    str_2 = '-n get -inet6 default'
    str_3 = '-n get default'
    str_4 = '-n get -inet6 default'
    rc_0, out_0, err_0 = module_0.run_command([str_0, str_1])
    rc_1, out_1, err_1 = module_0.run_command([str_2])
    str_5 = 'RTNETLINK answers: Invalid argument'
    if not out_1:
        if str_5 in err_1:
            str_6 = '/usr/sbin/route'
            str_7 = '-n get -inet6 default'

# Generated at 2022-06-24 22:46:26.044438
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '?lh1=0+w)-o|'
    # Call the method under test
    str_1 = '+JpG|>H!cq?T.f0'
    str_2 = '+JpG|>H!cq?T.f0'
    str_3 = 'A=}!U5c<U6I"QMFl'
    str_4 = 'A=}!U5c<U6I"QMFl'
    str_5 = 'A=}!U5c<U6I"QMFl'
    str_6 = 'A=}!U5c<U6I"QMFl'
    str_7 = 'A=}!U5c<U6I"QMFl'

# Generated at 2022-06-24 22:46:38.251683
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = ['=tN\\Y"><;[6xD"ka|/Q', '=tN\\Y"><;[6xD"ka|/Q', '=tN\\Y"><;[6xD"ka|/Q', '=tN\\Y"><;[6xD"ka|/Q', '=tN\\Y"><;[6xD"ka|/Q', '=tN\\Y"><;[6xD"ka|/Q']

# Generated at 2022-06-24 22:46:47.034116
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet', '10Gbase-SR', 'media', 'status:', 'active']
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips)
    res = current_if['media_select']
    assert res == words[1]
    assert generic_bsd_ifconfig_network_0 is not None
    res = current_if['media_type']
    assert res == words[2]
    res = current_if['media_options']
    assert res is None
    res = current_if['status']
    assert res == words[5]


# Generated at 2022-06-24 22:47:17.224695
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Example provided by @llelectronics
    interface_name = 'nfe1'
    inet_line = 'inet 192.168.99.254 netmask 0xffffffff '
    inet_line += 'broadcast 192.168.99.255'

    parse_inet_line(
        [interface_name, inet_line],
        {
            'device': 'nfe1',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown',
            'flags': [],
            'macaddress': 'unknown',
            'mtu': '',
        },
        {
            'all_ipv4_addresses': [],
            'all_ipv6_addresses': [],
        }
    )


# Generated at 2022-06-24 22:47:23.601182
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_name = 'GenericBsdIfconfigNetwork_parse_media_line'

    module = GenericBsdIfconfigNetwork(None, None)

    test_words = 'media: Ethernet autoselect (1000baseT <full-duplex>) '
    words = test_words.split()

    current_if = dict()
    ips = dict()

    module.parse_media_line(words, current_if, ips)

    if 'media' not in current_if or current_if['media'] != 'Ethernet':
        print_fail(test_name)
        return

    if 'media_select' not in current_if or current_if['media_select'] != 'autoselect':
        print_fail(test_name)
        return


# Generated at 2022-06-24 22:47:32.319486
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'g"b.f=<^H$T@T>gP'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'Rn`'
    str_2 = '-a'

# Generated at 2022-06-24 22:47:44.284811
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = '1 X^f7}*8/G'
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    s = 'vaI9=TIGTgAl'
    list_0 = ['vaI9=TIGTgAl', 'oYm+>,p1$=xdhT-?s', 'n1_+^x;J{a;]M"', '!Pc"=l9"4|B:JZ/', 'U&/6PxS6U85w6', '-', '-', '0xff000000']

# Generated at 2022-06-24 22:47:54.585082
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    ifconfig_path_0 = '=tN\\Y"><;[6xD"ka|/Q'
    route_path_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.module.run_command = MagicMock(return_value=(0, '0', '0'))
    assert generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0, ifconfig_path_0) is None


# Generated at 2022-06-24 22:48:04.522439
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    args_0 = {}
    ifconfig_path_0 = GenericBsdIfconfigNetwork.module.get_bin_path('ifconfig')

    if ifconfig_path_0 is None:
        return

    route_path_0 = GenericBsdIfconfigNetwork.module.get_bin_path('route')

    if route_path_0 is None:
        return

    rc_0, out_0, err_0 = GenericBsdIfconfigNetwork.module.run_command([route_path_0, '-n', 'get', 'default'])
    rc_0, out_1, err_1 = GenericBsdIfconfigNetwork.module.run_command([route_path_0, '-n', 'get', '-inet6', 'default'])

# Generated at 2022-06-24 22:48:13.327472
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'onXz}3'
    str_1 = 'Ho[V7'
    str_2 = 'n_G]O'
    dict_0 = {str_0:{str_1:str_2}, str_0:list([str_2])}
    str_3 = '{?9]y'
    str_4 = '_6U?k'
    dict_1 = {str_0:dict_0, str_3:str_4}
    str_5 = '<8Wx`'
    str_6 = '"B/X8'
    list_0 = [str_6, str_6, str_6, str_6, str_6, str_6, str_6, str_6, str_6, str_6]

# Generated at 2022-06-24 22:48:25.098797
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Initialization
    str_0 = 'R/YW1Od)r>V&~w<O{MVu!\x7f\x7f\x7f'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = ['', 'alias', '127.1.1.1', 'netmask', '0xff000000']
    current_if_0 = {}
    ips_0 = {}
    # Invocation
    parse_inet_line_Result = generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)

# Generated at 2022-06-24 22:48:31.178412
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    list_0 = []
    generic_bsd_ifconfig_network_0.parse_media_line(list_0, list_0, list_0)


# Generated at 2022-06-24 22:48:40.473115
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'fTtZb&L'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = '?B~6p"rb"+X0b=?R5c5'
    str_1 = 'H{_JLqgA(B"I+MQ~Xy'
    str_2 = ''
    assert_raises(ValueError, generic_bsd_ifconfig_network_0.get_interfaces_info, str_0, str_1, str_2)



# Generated at 2022-06-24 22:49:25.846751
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    list_0 = [str_0, str_1]
    str_0 = "media"
    list_1 = [str_0]
    str_0 = '=tN\\Y"><;[6xD"ka|/Q'
    str_1 = '=tN\\Y"><;[6xD"ka|/Q'
    list_2 = [str_0, str_1]


# Generated at 2022-06-24 22:49:32.272371
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'j~1g?h@'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'C'
    type(str_1)
    function_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    print(function_0)


# Generated at 2022-06-24 22:49:38.448576
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = "'(RU6wM]p:0mDq~>j+5]"
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    # Call populate in order to execute the code in the try block
    try:
        # Call populate
        generic_bsd_ifconfig_network_0.populate()
    except:
        # If an exception occurs, verify that it is an expected one
        str_1 = 'The "ifconfig" command is not available on this host'
        error_1 = generic_bsd_ifconfig_network_0.module._socket_path
        error_1 = generic_bsd_ifconfig_network_0.module.fail_json(msg=str_1)
        assert error_1['msg'] == str_

# Generated at 2022-06-24 22:49:48.035435
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'pADRckzwLF`C"'
    str_1 = 'Q^U|O8:s"X@$^'
    str_2 = '=tN\\Y"><;[6xD"ka|/Q'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    str_3 = 'mD3JhLR\\=$^7KwW.#vlx'
    str_4 = 'ZpN^WKjN}'
    # 	path = self.module.get_bin_path(str_4, False)
    # 	self.module.run_command([path, str_5], check_rc=True)
    str_5 = '_f{D(9g$Kz'


# Generated at 2022-06-24 22:49:56.027890
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '{1O:iLG9kYu^h'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 'DQnT^jr'
    collected_facts_0 = {str_0: {str_0: str_0}}
    bool_0 = True
    network_facts_0 = generic_bsd_ifconfig_network_0.populate(collected_facts_0)
    assert ((bool_0, network_facts_0) == (True, {}, {}, {}))
