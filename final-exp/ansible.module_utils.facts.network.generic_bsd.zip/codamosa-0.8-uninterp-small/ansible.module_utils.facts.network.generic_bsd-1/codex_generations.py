

# Generated at 2022-06-24 22:40:47.365831
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # TODO: make this unit test more robust
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 'inet6'
    str_1 = 'fe80::1%lo0'
    str_2 = 'prefixlen'
    int_0 = 64
    str_3 = 'scopeid'
    str_4 = '0x2'
    words_0 = [str_0, str_1, str_2, int_0, str_3, str_4]
    current_if_0 = dict()
    ips_0 = dict()

# Generated at 2022-06-24 22:40:54.308162
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'T4C6CnlN_Ca__3~'
    list_1 = [str_0, str_0, str_1]
    list_0 = [str_0, str_1]
    generic_bsd_ifconfig_network_0.parse_inet6_line(list_0, list_1, str_0)


# Generated at 2022-06-24 22:40:57.456674
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('str_0', 'str_1')
    var_0 = generic_bsd_ifconfig_network_0.detect_type_media(interfaces)
    pass


# Generated at 2022-06-24 22:40:59.046022
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    assert generic_bsd_ifconfig_network_0.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-24 22:41:10.498493
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    str_1 = 'lh1]<V,eoZf$-kQ'
    str_2 = 'zf~daM,X6E%b. 1'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    assert generic_bsd_ifconfig_network_0.module.get_bin_path(str_1)
    assert generic_bsd_ifconfig_network_0.module.get_bin_path(str_2)
    interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info(str_2)
    assert interfaces
    assert ips


# Generated at 2022-06-24 22:41:19.877447
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'QlRf:An}WnUvD47'
    str_3 = 'gf>57}da(A|Jp#F'

# Generated at 2022-06-24 22:41:27.211514
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = ['500BaseTX', '<FDX,100BaseTX,100BaseTX-FD,100BaseTX-HD>', 'ieee 802.3', 'autoselect (100baseTX <full-duplex>)']
    var_1 = generic_bsd_ifconfig_network_0.parse_media_line(var_0)


# Generated at 2022-06-24 22:41:36.370503
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'g"|mv!%c53W'
    str_1 = 'XYyvw@A.P`a'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0, str_1)
    str_2 = '#^x6M9`HLT_'
    str_3 = '$z~Q2:i]En;'
    var_0 = generic_bsd_ifconfig_network_1.get_default_interfaces(str_2, str_3)
    # AssertionError: None
    # assert var_0 is None


# Generated at 2022-06-24 22:41:42.057015
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    interfaces_0 = {}
    var_0 = generic_bsd_ifconfig_network_0.detect_type_media(interfaces_0)


# Generated at 2022-06-24 22:41:48.517092
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = '~98]3`JX<W5U6_G~'
    generic_bsd_ifconfig_network_0.ifconfig_path = str_0
    list_0 = ['~98]3`JX<W5U6_G~', '-a']
    generic_bsd_ifconfig_network_0.module.run_command(list_0)

# Generated at 2022-06-24 22:41:59.509523
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    assert 'GenericBsdIfconfigNetwork' in globals(), 'No global GenericBsdIfconfigNetwork class found.'
    assert 'populate' in dir(GenericBsdIfconfigNetwork), 'populate() method not found in GenericBsdIfconfigNetwork.'
    assert callable(GenericBsdIfconfigNetwork.populate), 'populate() method not callable in GenericBsdIfconfigNetwork.'
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-24 22:42:01.677273
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    string = '<LOOPBACK,RUNNING,MULTICAST>'
    result = GenericBsdIfconfigNetwork.get_options(string)
    assert result == ['LOOPBACK', 'RUNNING', 'MULTICAST']


# Generated at 2022-06-24 22:42:12.960720
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    #
    # Data to feed into unit test
    #
    words = ['media:', 'Ethernet', '10Gbase-T', '(10Gbase-T/100baseTX)', 'status:', 'active', 'options=']
    current_if = {'device': 'vnet0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    str_0 = 'T4C6CnlN_Ca__3~'
    #
    # Unit test body
    #
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network

# Generated at 2022-06-24 22:42:24.949941
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:42:33.223464
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    default_ipv6 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)[1]
    interface_0 = {str_0: {'ipv6': []}}
    ip_type = 'ipv6'
    generic_bsd_ifconfig_network_0.merge_default_interface(default_ipv6, interface_0, ip_type)


# Generated at 2022-06-24 22:42:40.531831
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = './ansible_modlib.zip/ansible/module_utils/network_lsr/'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)
    return var_0


# Generated at 2022-06-24 22:42:48.020673
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print('test_GenericBsdIfconfigNetwork_parse_inet_line()')
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    list_0 = ['r8kv', '192.0.2.1', '255.255.255.0', 'broadcast', '192.0.2.255', '', 'inherit']
    list_1 = ['r8kv', '192.0.2.1', '255.255.255.0', 'broadcast', '192.0.2.255', '', 'inherit']

# Generated at 2022-06-24 22:42:58.019397
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'T4C6CnlN_Ca__3~'

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.populate()

# Generated at 2022-06-24 22:43:02.262186
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # TODO: implement this test case
    # test_case_0()
    pass


# Generated at 2022-06-24 22:43:05.632185
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:43:17.975396
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(generic_bsd_ifconfig_network_1, [], [])


# Generated at 2022-06-24 22:43:22.746502
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # default parameters
    args_0 = 'kIx1vfq3Y6Kjf'
    expected_result_0 = ('DMjKZu_7Um_QW', 'V7kquDObtYbzt')
    result_0 = GenericBsdIfconfigNetwork.get_default_interfaces(args_0)
    assert expected_result_0 == result_0


# Generated at 2022-06-24 22:43:31.739514
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    # Test cases for class merge_default_interface

    # test case 0
    str_0 = 'T4C6CnlN_Ca__3~'
    str_1 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_1)
    defaults = { 'interface' : 'lo0', 'gateway' : '172.31.0.1', 'metric' : '0', 'mtu' : '16436' }

# Generated at 2022-06-24 22:43:37.678285
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_1 = 'abcd1234'
    str_2 = 'zyxw9876'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, str_2)
    var_1 = generic_bsd_ifconfig_network_1.get_default_interfaces()
    str_3 = 'S6JGFv6f1lWl_G6'
    assert var_1 == str_3


# Generated at 2022-06-24 22:43:45.369958
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)


# Generated at 2022-06-24 22:43:55.765572
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    # print (var_0)
    str_0 = 'T4C6CnlN_Ca__3~'
    list_0 = ['T4C6CnlN_Ca__3~', 'T4C6CnlN_Ca__3~', 'T4C6CnlN_Ca__3~', 'T4C6CnlN_Ca__3~', 'T4C6CnlN_Ca__3~']
    str_1 = 'T4C6CnlN_Ca__3~'
    str_2

# Generated at 2022-06-24 22:44:01.758018
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = '2hI$%cWtKjza$gMh'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    assert var_0 == None


# Generated at 2022-06-24 22:44:13.750796
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'T4C6CnlN_Ca__1~'

# Generated at 2022-06-24 22:44:17.753354
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:44:29.738684
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    str_1 = 'y^bNzbwTtFmW8Vu'
    str_2 = 'mf4CSWm9_'
    str_3 = 'wTtFmW8Vu'
    str_4 = 'K|>'
    str_5 = 's2tI_oFbx'
    str_6 = 'fkdv^Ac0'
    str_7 = 'f,Wa}Nk{'
    list_0 = ['loopback', 'plumb', 'up', 'running']
    list_1 = ['loopback', 'plumb', 'up', 'running']
    list_2 = ['loopback', 'plumb', 'up', 'running']

# Generated at 2022-06-24 22:44:54.681869
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = '4m>|'
    str_1 = '-R?S'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.module.get_bin_path(str_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:45:03.610216
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork('T4C6CnlN_Ca__3~', 'T4C6CnlN_Ca__3~')
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')
    if ifconfig_path:
        route_path = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
        if route_path:
            var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)
        

# Generated at 2022-06-24 22:45:14.142074
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    option_string = 'UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST'
    result = GenericBsdIfconfigNetwork.get_options(option_string)
    assert len(result) == 5, 'AssertionError: 1'
    assert result[0] == 'UP', 'AssertionError: 2'
    assert result[1] == 'BROADCAST', 'AssertionError: 3'
    assert result[2] == 'RUNNING', 'AssertionError: 4'
    assert result[3] == 'SIMPLEX', 'AssertionError: 5'
    assert result[4] == 'MULTICAST', 'AssertionError: 6'

    option_string = 'UP,BROADCAST,RUNNING,MULTICAST'

# Generated at 2022-06-24 22:45:21.990610
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    # Make assertions on the return value
    assert True == generic_bsd_ifconfig_network_0.populate()

if __name__ == '__main__':
    test_case_0()
    # test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:45:33.211820
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    list_0 = []
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')
    str_1 = '-a'
    ifconfig_options = str_1
    list_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)
    str_2 = '8#v*~6F'
    list_0.append(str_2)
    str_3 = 'c%eRff'
    list_0.append(str_3)

# Generated at 2022-06-24 22:45:34.185927
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 22:45:37.825584
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    return var_0

# Generated at 2022-06-24 22:45:47.298938
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
#    var_0 = 'T4C6CnlN_Ca__3~'
    var_0 = '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),LARGESEND,CHAIN>'
    print("Start testing for GenericBsdIfconfigNetwork.get_options")
#    print("Test case 0:")
#    test_case_0(var_0)
    print("End to test for GenericBsdIfconfigNetwork.get_options")
    print("Start testing for GenericBsdIfconfigNetwork.get_options")
#    print("Test case 0:")
#    test_case_0(var_0)

# Generated at 2022-06-24 22:45:55.220133
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    words = ['inet6', 'fe80::a00:27ff:fea3:3d0b%utun0', 'prefixlen', '64', 'scopeid', '0x8']
    interface_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    interface_0.parse_inet6_line(words, None, None)


# Generated at 2022-06-24 22:46:02.754531
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'c%9{'
    str_1 = '#wLN'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    defaults = dict()
    interfaces = dict()
    ip_type = str_1
    var_0 = generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:46:24.007400
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'G:t_4YfB~e'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    dict_0 = {}
    dict_1 = {}
    dict_1['QNj1'] = dict_0
    dict_2 = {}
    dict_2['address'] = 'J1m(h-vB$Z?3:m>J'
    dict_3 = {}
    dict_3['Uf0'] = dict_2
    dict_1['interface'] = '`Y.5'
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_1, dict_3, 'address')


# Generated at 2022-06-24 22:46:31.699865
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    network_facts_0 = generic_bsd_ifconfig_network_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:46:40.001702
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'T4D6GnlM_Cn__3~'

    assert_equal(map(is_list, generic_bsd_ifconfig_network_0.get_interfaces_info(str_1)), [True, True])


# Generated at 2022-06-24 22:46:48.978176
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    v1 = """nameif: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
        options=3<RXCSUM,TXCSUM>
        ether 04:0c:ce:10:00:14
        inet6 fe80::60c:ceff:fe10:14%nameif prefixlen 64 scopeid 0x4
        inet 192.168.1.1 netmask 0xffffff00 broadcast 192.168.1.255
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>"""
    ifconfig_path = '/sbin/ifconfig'
    network = GenericBsdIfconfigNetwork(v1, ifconfig_path)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-24 22:46:57.675940
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    str_1 = str_0
    str_2 = str_0
    str_3 = './ifconfig'
    str_4 = '-a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_1, str_2)
    generic_bsd_ifconfig_network_0.get_interfaces_info(str_3, str_4)


# Generated at 2022-06-24 22:47:03.666410
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:47:11.618230
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = ' '
    dict_1 = {'@': 'D'}
    assert generic_bsd_ifconfig_network_0.merge_default_interface(str_1, dict_1, ' ') == None
# Test for cases that are supposed to fail.

# Generated at 2022-06-24 22:47:14.876767
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:47:24.592012
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'T4C6CnlN_Ca__3~'
    str_1 = 'U4C6CnlN_Ca__3~'
    str_2 = 'V4C6CnlN_Ca__3~'
    str_3 = 'W4C6CnlN_Ca__3~'
    str_4 = 'X4C6CnlN_Ca__3~'

# Generated at 2022-06-24 22:47:33.733544
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'T4C6CnlN_Ca__3~'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = '#Z\'n#\x1a\x19\x1c\x06\x0e\x05\x05\x0f2\x1c\x1d#\x1a\x19\x1c\x06\x0e\x05\x05\x0f2\x1c\x1d'
    str_2 = '_2h\x1a\x06\x0e\x05\x05\x0f2\x1c\x1d'
    str_3 = 'T4C6CnlN_Ca__3~'
   