

# Generated at 2022-06-24 22:40:41.341278
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    str_0 = None
    str_1 = ''
    str_2 = ''
    str_3 = ''

    # This is to test the default value of argument route_path of method get_default_interfaces
    generic_bsd_ifconfig_network_0.get_default_interfaces()

    # This is to test the case of argument route_path being a valid string
    generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)

    # This is to test the case of argument route_path being an empty string
    generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)

    # This is

# Generated at 2022-06-24 22:40:52.215312
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test

# Generated at 2022-06-24 22:41:02.145739
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.platform = 'Generic_BSD_Ifconfig'
    generic_bsd_ifconfig_network_0.module = 'Generic_BSD_Ifconfig'
    generic_bsd_ifconfig_network_0.get_default_interfaces()
    generic_bsd_ifconfig_network_0.get_interfaces_info()
    generic_bsd_ifconfig_network_0.populate()
    generic_bsd_ifconfig_network_0.get_default_interfaces()
    generic_bsd_ifconfig_network_0.get_default_interfaces()


# Generated at 2022-06-24 22:41:12.547092
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    interface_line = numpy.array(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '16384'])
    interface_words = numpy.array(['lo0:'])
    current_if = {'device': 'lo0:'}
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    current_if['mtu'] = '16384'
    # address = {'address': '127.0.0.1'}

# Generated at 2022-06-24 22:41:15.776296
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.populate()



# Generated at 2022-06-24 22:41:23.855575
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = float()
    float_1 = float(2.08)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(float_1)
    list_0 = ['foo', 'bar', 'baz', '', 'something else']
    list_1 = ['foo', 'bar', 'xxx']
    list_2 = []
    list_3 = ['foo']
    list_4 = ['foo', 'bar', 'baz']
    list_5 = ['foo', 'bar', 'baz', '', 'something else']
    dictionary_0 = dict()
    dictionary_0['device'] = 'lo0'
    dictionary_0['flags'] = ['LOOPBACK', 'UP', 'RUNNING']
    dictionary_0['mtu'] = '16384'

# Generated at 2022-06-24 22:41:24.919264
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 22:41:33.427194
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(generic_bsd_ifconfig_network_0)
    list_0 = [generic_bsd_ifconfig_network_0]
    list_0.append('media:')
    generic_bsd_ifconfig_network_1.parse_media_line(list_0, list_0, list_0)


# Generated at 2022-06-24 22:41:44.827991
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)

    # test_case_0.yml is the fixture used to generate the output
    args = {'collected_facts': {}}
    result = generic_bsd_ifconfig_network_0.populate(**args)

# Generated at 2022-06-24 22:41:57.551711
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Make sure it works for two empty cases.
    defaults = dict()
    interfaces = dict()
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, '')
    assert defaults == dict()

    defaults = dict()
    interfaces = dict()
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'foo')
    assert defaults == dict()

    # Make sure we can merge some simple values.
    defaults = dict(interface="eth0")
    interfaces = dict(eth0=dict(baz="baz"))
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'foo')
    assert defaults == dict(interface="eth0", baz="baz")

    defaults = dict(interface="eth0", address="1.2.3.4")

# Generated at 2022-06-24 22:42:21.728907
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    str_0 = '<UP,BROADCAST,RUNNING,MULTICAST>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_0)


# Generated at 2022-06-24 22:42:29.213570
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(float_0)
    var_2 = ['::1', 'fe80::1%lo0']
    # unknown_type_0 = generic_bsd_ifconfig_network_0.parse_inet6_line(var_2, var_1, var_1)


# Generated at 2022-06-24 22:42:33.184272
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()

    if generic_bsd_ifconfig_network_0 is not None:
        # pass
        assert True


# Generated at 2022-06-24 22:42:39.004690
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    foo = GenericBsdIfconfigNetwork(1.0)

    # should raise exception about no ifconfig command
    with pytest.raises(os.error) as excinfo:
        foo.get_interfaces_info(None, ifconfig_options="-a")
    assert "ifconfig command not found" in str(excinfo.value)



# Generated at 2022-06-24 22:42:41.818585
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    result = GenericBsdIfconfigNetwork.get_interfaces_info(float_0)
    assert (result != None), "GenericBsdIfconfigNetwork_get_interfaces_info"


# Generated at 2022-06-24 22:42:45.654001
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network_facts_instance = GenericBsdIfconfigNetwork(float('inf'))
    assert network_facts_instance.get_options('lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-24 22:42:57.403594
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:43:05.010772
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    float_0 = -1535.8071
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)
    if (var_0 != None):
        raise Exception("Test #0 failed")



# Generated at 2022-06-24 22:43:07.756090
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 22:43:14.023116
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    # Testing for coverage of the entire method
    string_0 = "X<GR3>P"
    assert GenericBsdIfconfigNetwork(float_0).get_options(string_0) == ['X', 'GR3', 'P']


# Generated at 2022-06-24 22:43:35.747427
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case 0
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)

    # Test case 1
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)

    # Test case 2
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig

# Generated at 2022-06-24 22:43:41.956128
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Instanciate a class object
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    # Input parameters:
    words = ["lo0:","flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>","metric","0","mtu","16384"]
    # Expected result:
    current_if = {'device': "lo0", 'ipv4': [], 'ipv6': [], 'type': "unknown"}
    current_if['flags'] = ["UP", "LOOPBACK", "RUNNING", "MULTICAST"]
    current_if['mtu'] = "16384"
    current_if['macaddress'] = "unknown"
    # Call the method
    result = generic_bsd_ifconfig_network_0.parse_interface_

# Generated at 2022-06-24 22:43:52.526971
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    float_0 = -1438.5688516054834
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.get_options(float_0)
    generic_bsd_ifconfig_network_0.parse_tunnel_line(float_0, float_0, float_0)
    generic_bsd_ifconfig_network_0.get_interfaces_info(float_0, float_0)
    generic_bsd_ifconfig_network_0.parse_unknown_line(float_0, float_0, float_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(float_0, float_0, float_0)
    generic_bsd_ifconfig_

# Generated at 2022-06-24 22:43:57.041422
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 22:44:02.563417
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = -1443.8476
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)'], '', '')


# Generated at 2022-06-24 22:44:07.471050
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)
    print(var_0)

    ans = test_case_0()
    

# Generated at 2022-06-24 22:44:16.879476
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import sys
    import json
    import os.path

    path = sys.path.append(os.path.dirname(__file__))

    float_0 = -1535.8071

    # Generate input data to test the function
    test_file = open('/tmp/test_file_0.txt', 'r')
    test_ifconfig_path = test_file.readline()
    test_ifconfig_options = test_file.readline()

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    test_interface, test_all_ipv4_addresses = generic_bsd_ifconfig_network_0.get_interfaces_info(test_ifconfig_path, test_ifconfig_options)


# Generated at 2022-06-24 22:44:20.920738
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(float_0)


# Generated at 2022-06-24 22:44:25.988288
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 22:44:32.477761
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # this will fail for non-bsd systems
    if not platform.startswith('bsd'):
        return

    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)



# Generated at 2022-06-24 22:45:03.894967
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -963.843
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    dict_0 = generic_bsd_ifconfig_network_0.populate(None)
    if 'default_ipv6' not in dict_0:
        dict_0['default_ipv6'] = dict()
    dict_0['default_ipv6']['interface'] = "lo0"
    dict_0['default_ipv6']['address'] = "fe80::1%lo0"
    dict_0['default_ipv6']['gateway'] = "::1"
    dict_0['default_ipv6']['netmask'] = "ffff:ffff:ffff:ffff::"

# Generated at 2022-06-24 22:45:08.944364
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(float_0)



# Generated at 2022-06-24 22:45:12.314265
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    str_0 = "q&*J"
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(float_0, str_0)


# Generated at 2022-06-24 22:45:19.318379
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    # Testing
    generic_bsd_ifconfig_network_0.merge_default_interface(float_0, float_0, float_0)


# Generated at 2022-06-24 22:45:24.128839
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    float_0 = -1450.711
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    float_1 = -1535.8071
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(float_1)


# Generated at 2022-06-24 22:45:26.778176
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Tested method stub
    pass


# Generated at 2022-06-24 22:45:34.437728
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """
    Generated tests for method merge_default_interface of class GenericBsdIfconfigNetwork
    """
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(float_0, float_0, float_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(float_0, float_0, float_0)


# Generated at 2022-06-24 22:45:43.230390
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    float_0 = 1517.2159
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    list_0 = [float_0, float_0, float_0, float_0, float_0, float_0]
    dict_0 = {}
    list_1 = []
    generic_bsd_ifconfig_network_0.parse_inet6_line(list_0, dict_0, list_1)
    try:
        assert len(list_0) >= 0, "Unit test failed."
        assert len(list_1) >= 0, "Unit test failed."
    except AssertionError:
        report_error("Unit test failed.")


# Generated at 2022-06-24 22:45:45.550475
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    assert (generic_bsd_ifconfig_network_0.get_interfaces_info(float_0, float_0)) is None


# Generated at 2022-06-24 22:45:47.925070
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.merge_default_interface(0, 0, 0)


# Generated at 2022-06-24 22:46:12.053138
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    dict_0 = {}
    dict_1 = {}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(dict_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_1, 'ipv4')


# Generated at 2022-06-24 22:46:21.634957
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    print("processing unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork")
    # Create a new instance of class GenericBsdIfconfigNetwork
    float_0 = -443.48
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    # Declare variables for parameter 'words'
    str_0 = "rd_t0_24"
    str_1 = "sOBZd95"
    str_2 = "0Wqz8CJ"
    str_3 = "jJ2Q9eE"
    str_4 = "Km_qm8q"
    str_5 = "vAVkR2f"
    str_6 = "r99w77G"
    str_7 = "tY_YdKA"
   

# Generated at 2022-06-24 22:46:27.368571
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # this should be done using mock objects.
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    words = ['::1', 'prefixlen', '64']
    current_if = {'ipv6': []}
    ips = dict(all_ipv6_addresses=[])

    if isinstance(words, list):
        if len(words) >= 6 and words[4] == 'scopeid' and words[5] == '0x3':
            current_if['device'] = 'lo0'
            current_if['ipv6'] = [{    'address': '::1',    'scope': '0x3'}]
            ips['all_ipv6_addresses'] = ['::1']


# Generated at 2022-06-24 22:46:30.142299
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test empty argument
    assert(GenericBsdIfconfigNetwork.merge_default_interface(GenericBsdIfconfigNetwork, {}, {}) == "None")


# Generated at 2022-06-24 22:46:35.319007
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(float_0)
    assert var_0 is not None


# Generated at 2022-06-24 22:46:44.415616
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    float_0 = 0.01
    assert generic_bsd_ifconfig_network_0.get_interfaces_info(float_0) == [], "Return value for GenericBsdIfconfigNetwork.get_interfaces_info(float_0) == [], is: " + str(generic_bsd_ifconfig_network_0.get_interfaces_info(float_0))


# Generated at 2022-06-24 22:46:46.089047
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Return value of method parse_interface_line.
    # Assert against the value of the returned value from method
    # parse_interface_line.
    assert False


# Generated at 2022-06-24 22:46:54.028021
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    float_0 = 8.617991597639646e-05
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    current_if = {}
    ips = {}
    words = ['inet', '127.0.0.1', 'netmask', '255.0.0.0', 'broadcast', '127.255.255.255']
    generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)


# Generated at 2022-06-24 22:47:02.540616
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    params = {'run_command': [{'cmd': 'route -n get default', 'rc': 0, 'stdout': 'interface: en0\ngateway: 192.168.0.1\ndestination: default\nflags: <UP,GATEWAY,DONE,STATIC,PRCLONING>\nrecvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire\n0         0         0         0           0       0             1500    0\n', 'stderr': ''}], 'get_bin_path': {'route': '/sbin/route'}, 'get_bin_path': {'ifconfig': '/sbin/ifconfig'}}

# Generated at 2022-06-24 22:47:08.616788
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # set up some test facts
    test_facts = dict(
        ansible_distribution_version='6.2.2',
    )

    # set up test collection of module params and args
    test_opts = dict(
        config='',
        debug=False,
        _ansible_check_mode=False,
        _ansible_debug=False,
        _ansible_diff=False,
        _ansible_version='2.8.6',
        ansible_architecture='x86_64',
        ansible_env={},
        ansible_pkg_mgr='pkgng',
        ansible_user_dir='/root',
        ansible_version='2.8.6',
        ansible_machine='x86_64',
    )


# Generated at 2022-06-24 22:47:37.475530
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    float_0 = 16.73
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)
    assert var_0 == None


# Generated at 2022-06-24 22:47:47.349286
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    _out = {}
    _out['return_value'] = {'lo0': {'ipv6': [{'address': '::1', 'prefix': '128'}, {'address': 'fe80::1', 'prefix': '64', 'scope': '0x2'}], 'device': 'lo0', 'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0', 'broadcast': '127.255.255.255'}], 'macaddress': 'unknown', 'type': 'loopback', 'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST']}}
    _out['changed'] = True
    return_value = _out['return_value']

# Generated at 2022-06-24 22:47:57.717734
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifconfig_path = '/sbin/ifconfig'
    route_path = '/sbin/route'
    ifconfig_options = '-a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(ifconfig_path, route_path, ifconfig_options)
    current_if = {}
    ips = {}
    words = ['inet6', 'fe80::', 'prefixlen', '64', 'scopeid', '0x4', 'inet6', 'fe80::21f:5bff:fea6:1c29%lo0', 'prefixlen', '64', 'scopeid', '0x3']
    generic_bsd_ifconfig_network_0.parse_inet6_line(words, current_if, ips)
    assert current_if.items() == {}

# Generated at 2022-06-24 22:48:06.673715
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    int_0 = 1440
    float_0 = -666.938
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    mac_0 = onp.array([-9.73414, 28.0, -3.80382, -1.0, -3.34642, -8.0], dtype=np.float32)
    str_0 = onp.array(['dhcp', 'media:', 'Ethernet', '10baseT/UTP', '<1.0>', 'status:', 'active'], dtype=np.unicode_)
    dict_0 = {'address': '192.168.32.32', 'netmask': '255.255.255.0', 'broadcast': '192.168.32.255'}
    dict

# Generated at 2022-06-24 22:48:13.799936
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = -1420.163
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    words_0 = ['media:', 'Ethernet', '10GbasET', '(1000baseT)', 'status:', 'active']
    current_if = {'status': 'active'}
    ips_0 = {'all_ipv6_addresses': [], 'all_ipv4_addresses': [], }
    generic_bsd_ifconfig_network_0.parse_media_line(words_0, current_if, ips_0)
    assert current_if == {'status': 'active', 'media': 'Ethernet', 'media_select': '10GbasET', 'media_type': '1000baseT'}


# Generated at 2022-06-24 22:48:25.200399
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    cidr_style = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184" \
                 "    inet 127.0.0.1 netmask 0xff000000" \
                 "    inet alias 127.1.1.1 netmask 0xff000000"
    r = GenericBsdIfconfigNetwork(None)
    r.parse_interface_line(cidr_style.split())
    r.parse_inet_line(cidr_style.split()[3:])
    r.parse_interface_line(cidr_style.split())
    r.parse_inet_line(cidr_style.split()[6:])
    assert len(r.current_if['ipv4']) == 2

# Generated at 2022-06-24 22:48:29.080335
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(float_0, float_0, float_0)


# Generated at 2022-06-24 22:48:35.870662
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test case parameters
    words = ['123456789']
    current_if = {}
    ips = {}
    # Execute the tested method
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_0.parse_inet6_line(words, current_if, ips)


# Generated at 2022-06-24 22:48:41.698406
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)
    var_1 = generic_bsd_ifconfig_network_0.populate(var_0)


# Generated at 2022-06-24 22:48:43.629066
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(float_0)


# Generated at 2022-06-24 22:49:22.954181
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case data
    defaults = {'gateway': '192.168.178.1', 'interface': 'wlo1', 'address': '192.168.178.35'}

# Generated at 2022-06-24 22:49:26.307415
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = -1459.6844
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = float_0
    var_1 = float_0
    var_2 = float_0


# Generated at 2022-06-24 22:49:32.381110
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    float_0 = -1535.8071
    assert generic_bsd_ifconfig_network_0.get_interfaces_info(float_0, float_0) == (dict(), dict())


# Generated at 2022-06-24 22:49:39.058009
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    float_1 = 17.1553
    str_0 = 'I'
    str_1 = 'y'
    dict_0 = {}
    dict_0['Z'] = str_0
    dict_0['b'] = float_1
    dict_0['w'] = str_1
    dict_0['p'] = float_1
    dict_0['M'] = str_0
    dict_0['V'] = float_0
    dict_0['h'] = str_1
    dict_0['K'] = float_1
    dict_0[str_0] = float_0
    dict_0['t'] = float_1

# Generated at 2022-06-24 22:49:46.631406
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    float_0 = -30.0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = []
    var_1 = None
    var_2 = None
    var_3 = None
    var_3 = generic_bsd_ifconfig_network_0.parse_media_line(var_0, var_1, var_2)
    assert var_3 == None


# Generated at 2022-06-24 22:49:49.772629
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(float_0)


# Generated at 2022-06-24 22:50:00.321805
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    float_0 = -1535.8071
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(float_0)
    int_0 = 7477
    int_1 = 92
    int_2 = 5
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(float_0)
    var_1 = generic_bsd_ifconfig_network_0.detect_type_media({})
    var_2 = generic_bsd_ifconfig_network_0.get_interfaces_info(float_0)
    var_3 = generic_bsd_ifconfig_network_0.populate({})