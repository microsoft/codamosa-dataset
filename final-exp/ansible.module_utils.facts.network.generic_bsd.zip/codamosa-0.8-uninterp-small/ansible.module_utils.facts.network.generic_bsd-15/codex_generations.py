

# Generated at 2022-06-24 22:40:49.573856
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # input value(s) definition
    test_case_0_get_interfaces_info_input = \
        [   # test_case_0_get_interfaces_info_input value(s)
            "../valid_input/ifconfig.txt",
        ]
    # output value(s) definition

# Generated at 2022-06-24 22:41:00.160744
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print('Testing get_default_interfaces')
    int_0 = 802
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    route_path = '/gn/bin/route'
    default_ipv4_0, default_ipv6_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)
    print('default_ipv4_0 = ' + str(default_ipv4_0))
    print('default_ipv6_0 = ' + str(default_ipv6_0))


# Generated at 2022-06-24 22:41:10.787125
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    int_0 = -1080
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    str_0 = 'a<b>c'
    str_1 = 'a<b,c>d'
    str_2 = 'a<b>,c'
    str_3 = 'a<b,c>,d'
    str_4 = 'a,b<c>'
    str_5 = 'a,b<c,d>'
    str_6 = 'a,b<c>,d'
    str_7 = 'a,b<c,d>,e'
    str_8 = 'a,b<c,d>,e,f'
    
    assert generic_bsd_ifconfig_network_0.get_options(str_0) == []

# Generated at 2022-06-24 22:41:14.364798
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 37474
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    list_0 = []
    generic_bsd_ifconfig_network_0.populate(list_0)



# Generated at 2022-06-24 22:41:21.626648
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ifconfig_path = '/sbin/ifconfig'
    route_path = '/sbin/route'

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(ifconfig_path, route_path)
    network_facts = {}
    network_facts = generic_bsd_ifconfig_network_0.populate()
    print("\n")
    print("The output of method populate is:")
    print(network_facts)
    print("\n")

if __name__ == "__main__":
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:41:33.356708
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = -1080
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    list_0 = []
    str_0 = 'Generic BSD Ifconfig Network'
    str_1 = 'detect_type_media'
    str_2 = 'Generic BSD Ifconfig Network'
    str_3 = 'ether'
    str_4 = 'type'
    list_0.append(str_0)
    list_0.append(str_1)
    list_0.append(str_2)
    list_0.append(str_3)
    list_0.append(str_4)
    str_5 = str(list_0)
    str_6 = str_5.lower()

# Generated at 2022-06-24 22:41:36.252389
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = -1080
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)


# Generated at 2022-06-24 22:41:42.725829
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    retval = None

    # Populate test case variables from module
    # None

    # Invoke method under test
    retval = GenericBsdIfconfigNetwork(int)
    if retval:
        retval = GenericBsdIfconfigNetwork.populate()

    # Validate return code
    assert retval is not None  # null object reference

    # Validate return code
    assert retval is not None  # null object reference


# Generated at 2022-06-24 22:41:45.019874
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = {'interface': 'test'}
    interfaces = {}
    ip_type = 'test'
    interface = {'interface': 'test'}
    interfaces['test'] = interface
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(0)
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:41:57.744324
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = -1080
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ["inet6", "fe80::5c88:a9ff:fe4e:5ea8", "prefixlen", "64", "scopeid", "0x6", "inet6", "fe80::5c88:a9ff:fe4e:5ea8", "prefixlen", "64", "scopeid", "0x6", "inet6", "::1%lo0", "prefixlen", "128"]
    current_if_0 = {"ipv6": []}
    ips_0 = {}

# Generated at 2022-06-24 22:42:11.200695
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module_0 = GenericBsdIfconfigNetwork()
    route_path_0 = module_0.get_bin_path('route')
    var_0 = module_0.get_default_interfaces(route_path_0)


# Generated at 2022-06-24 22:42:22.105699
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces
    """
    # Negative test: Linux with no IPv6
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True,
    )
    if PATH_IS_LINUX:
        platform = 'Linux'
        def my_get_bin_path(self, arg, required=False):
            return '/bin/%s' % arg
        module.get_bin_path = my_get_bin_path.__get__(module, type(module))
        network_obj = GenericBsdIfconfigNetwork(module)
        assert network_obj is not None

# Generated at 2022-06-24 22:42:24.905360
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    var_0 = GenericBsdIfconfigNetwork()
    test_case_0()


# Generated at 2022-06-24 22:42:36.274299
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var__tmp_test_class = GenericBsdIfconfigNetwork()
    var_0 = None
    var_route_path = None
    var_1 = None
    var_1 = None
    var_1 = None
    var_1 = None
    var_2 = None
    var_1 = None
    var_2 = None
    var_command = dict()
    var_command['v4'] = [var_route_path, '-n', 'get', 'default']
    var_command['v6'] = [var_route_path, '-n', 'get', '-inet6', 'default']
    var_interface = dict()
    var_interface['v4'] = {}
    var_interface['v6'] = {}

# Generated at 2022-06-24 22:42:45.753118
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    iface = GenericBsdIfconfigNetwork()
    

# Generated at 2022-06-24 22:42:55.503970
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    #
    # Initialize a new GenericBsdIfconfigNetwork object
    #
    var_inst_0 = GenericBsdIfconfigNetwork()
    #
    # Initialize a variable to hold the value of ifconfig_path
    #
    var_0 = None
    #
    # Initialize a variable to hold the value of ifconfig_options
    #
    var_1 = '-a'
    #
    # Invoke method get_interfaces_info of var_inst_0
    #
    var_2 = var_inst_0.get_interfaces_info(var_0, var_1)


# Generated at 2022-06-24 22:43:01.645350
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    ifconfig_path = "/sbin/ifconfig"
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=["!all", "network"], type='list')
        ),
        supports_check_mode=True
    )

    obj = GenericBsdIfconfigNetwork(module)
    result = obj.detect_type_media(var_0)
    assert result['rc'] == 0
    assert result['failed'] == 0
    assert result['changed'] == 0
    assert result['warnings'] == 0
    

# Generated at 2022-06-24 22:43:09.657729
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    # Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
    # Test case 0
    #   Test case 0
    #   This test case will try to set up the environment the test needs and will test
    #   the method get_default_interfaces of class GenericBsdIfconfigNetwork with following equations
    #   Expected: ({'interface': 'iWl'}, {'interface': 'fie'})
    var_0 = sys.platform
    var_1 = 'freebsd'
    if var_0 == var_1:
        var_2 = b'interface: iWl\r\ngateway: 8.8.5.5\r\n'
        var_3 = b'interface: fie\r\ngateway: 8.8.6.6\r\n'
        var

# Generated at 2022-06-24 22:43:18.937118
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # from ansible.module_utils.basic import AnsibleModule
    # test_module = AnsibleModule(
    #     argument_spec=dict(
    #         interfaces=dict(type='dict'),
    #         options=dict(type='list'),
    #     ),
    #     supports_check_mode=True
    # )

    # test_module.exit_json(changed=False)
    # test_module.params = dict(
    #     interfaces=dict(type='dict'),
    #     options=dict(type='list'),
    # )
    # test_instance = GenericBsdIfconfigNetwork(test_module)
    # assert test_instance.detect_type_media(var_0) == expected
    test_module = GenericBsdIfconfigNetwork()

# Generated at 2022-06-24 22:43:25.795203
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    args = {}
    ifconfig_path = module.get_bin_path('ifconfig')
    if args:
        args = dict((k, v) for k, v in args.iteritems() if v is not None)
        args = json.dumps(args)

# Generated at 2022-06-24 22:43:37.710727
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:43:40.175614
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var_0 = GenericBsdIfconfigNetwork()
    var_1 = var_0.get_default_interfaces()
    test_stub_0()
    return var_1


# Generated at 2022-06-24 22:43:41.058501
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_case_0()


# Generated at 2022-06-24 22:43:42.220289
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var = None


# Generated at 2022-06-24 22:43:46.955891
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    var0 = GenericBsdIfconfigNetwork()
    var1 = None
    var2 = None
    var3 = var0.get_interfaces_info(var1, var2)
    assert var3 == None


# Generated at 2022-06-24 22:43:54.434560
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print('Testing get_interfaces_info of class GenericBsdIfconfigNetwork')
    # No argument
    var_0 = GenericBsdIfconfigNetwork(None).get_interfaces_info(None)
    # Argument - (1, None, None)
    var_1 = GenericBsdIfconfigNetwork(None).get_interfaces_info(None, None)
    # Argument - ('v0B0', None, None)
    var_2 = GenericBsdIfconfigNetwork(None).get_interfaces_info(None, None)


# Generated at 2022-06-24 22:43:55.720422
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    var_0 = GenericBsdIfconfigNetwork.get_default_interfaces()

# Generated at 2022-06-24 22:44:05.707155
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print('''
--------------------------------------------------------------------
Testing method parse_inet_line
--------------------------------------------------------------------
    ''')
    test_GenericBsdIfconfigNetwork_parse_inet_line_1()
    test_GenericBsdIfconfigNetwork_parse_inet_line_2()
    test_GenericBsdIfconfigNetwork_parse_inet_line_3()
    test_GenericBsdIfconfigNetwork_parse_inet_line_4()
    test_GenericBsdIfconfigNetwork_parse_inet_line_5()
    test_GenericBsdIfconfigNetwork_parse_inet_line_6()
    test_GenericBsdIfconfigNetwork_parse_inet_line_7()
    test_GenericBsdIfconfigNetwork_parse_inet_line_8()
    test_GenericBsdIfconfigNetwork_parse_inet_line_9()
    test_

# Generated at 2022-06-24 22:44:16.622722
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    global var_0
    a = GenericBsdIfconfigNetwork()
    var_0 = {'device': 'ge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'macaddress': '00:e0:81:bb:4a:63', 'metric': '0', 'mtu': '1500', 'media': 'Ethernet autoselect (1000baseT <half-duplex>)'}
    var_1 = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<half-duplex>)']
    var_2 = ({}, [])
    a.parse_media_line(var_1, var_0, var_2)


# Generated at 2022-06-24 22:44:29.240557
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    route_path = generic_bsd_ifconfig_network.module.get_bin_path('route')
    test_case_0_get_default_interfaces_route_path = route_path
    (default_ipv4, default_ipv6) = generic_bsd_ifconfig_network.get_default_interfaces(test_case_0_get_default_interfaces_route_path)
    var_0 = None
    var_1 = 'default'
    var_2 = var_1 not in default_ipv4
    var_3 = None
    var_4 = 'default'
    var_5 = var_4 not in default_ipv6

# Generated at 2022-06-24 22:45:16.267082
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    global var_0
    var_0 = None


# Generated at 2022-06-24 22:45:19.645030
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    words = ['']
    current_if = GenericBsdIfconfigNetwork.parse_interface_line(words)
    assert current_if['device'] == ''

# Generated at 2022-06-24 22:45:24.420257
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    class_to_test = GenericBsdIfconfigNetwork()
    method_to_test = class_to_test.populate
    # TODO: set up your class parameters here
    # options = {}
    # expected = {}
    # method_to_test(options)
    # assert(expected == result)
    assert False


# Generated at 2022-06-24 22:45:26.080955
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    false = None
    true = None
    var_0 = None
    var_0 = GenericBsdIfconfigNetwork()
    var_0.populate(false)

test_case_0()

# Generated at 2022-06-24 22:45:29.721194
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    iface = GenericBsdIfconfigNetwork()
    iface.get_default_interfaces(route_path)


# Generated at 2022-06-24 22:45:39.404604
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    var_0 = None
    var_0 = GenericBsdIfconfigNetwork()
    # Line 13
    var_1 = ["inet6", "fe80::2231:6eff:fe6c:fad2", "prefixlen", "64", "scopeid", 0x0]
    var_2 = {}
    # Line 14
    var_3 = {"all_ipv6_addresses": []}
    # Line 15
    var_4 = {}
    # Line 16

# Generated at 2022-06-24 22:45:45.471259
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    var_0 = GenericBsdIfconfigNetwork()
    var_1 = None
    var_2 = '-a'
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    try:
        var_0.get_interfaces_info()
    except Exception as e:
        var_6 = str(e)

    if var_6 is None:
        print('Success')


# Generated at 2022-06-24 22:45:46.630037
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    GenericBsdIfconfigNetwork().parse_inet6_line()


# Generated at 2022-06-24 22:45:51.995396
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    # Setup the test fixture
    fake_module = FakeModule()
    fake_module.params = {'a': 1 }
    fake_module.run_command = lambda x: ('', '', '')

    # Expected results

# Generated at 2022-06-24 22:45:54.476964
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Setup test case
    var_0 = None
    # Setup test case
    var_0 = None

    # Test the method
    res = GenericBsdIfconfigNetwork.detect_type_media(var_0)


# Generated at 2022-06-24 22:46:42.436941
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test for method merge_default_interface of class GenericBsdIfconfigNetwork
    var = None


# Generated at 2022-06-24 22:46:46.618125
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    var_0 = GenericBsdIfconfigNetwork()
    var_0.merge_default_interface()


# Generated at 2022-06-24 22:46:57.882207
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert GenericBsdIfconfigNetwork().get_options('<LOOPBACK,BROADCAST,MULTICAST,UP>') == ['LOOPBACK', 'BROADCAST', 'MULTICAST', 'UP']
    assert GenericBsdIfconfigNetwork().get_options('<LOOPBACK,BROADCAST,MULTICAST>') == ['LOOPBACK', 'BROADCAST', 'MULTICAST']
    assert GenericBsdIfconfigNetwork().get_options('<LOOPBACK,BROADCAST>') == ['LOOPBACK', 'BROADCAST']
    assert GenericBsdIfconfigNetwork().get_options('<LOOPBACK>') == ['LOOPBACK']
    assert GenericBsdIfconfigNetwork().get_options('<LOOPBACK,') == ['LOOPBACK']

# Generated at 2022-06-24 22:47:08.000653
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    logger.info("Testing get_interfaces_info")
    ifconfig_path = None
    ifconfig_options = '-a'
    bsd_ifconfig_network_instance = GenericBsdIfconfigNetwork()
    bsd_ifconfig_network_instance.module.run_command = mock_run_command
    interfaces, ips = bsd_ifconfig_network_instance.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert len(interfaces) == 1
    assert sorted(interfaces.keys())[0] == "en0"
    assert len(interfaces.get("en0")) == 7
    assert interfaces["en0"]["device"] == "en0"
    assert interfaces["en0"]["type"] == "ether"

# Generated at 2022-06-24 22:47:18.146069
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # ifconfig_path = self.module.get_bin_path('ifconfig')
    ifconfig_path = b'/sbin/ifconfig'
    # ifconfig_options='-a'
    ifconfig_options = b'-a'

    # ifconfig_path = self.module.get_bin_path('ifconfig')
    # ifconfig_options='-a'
    # rc, out, err = self.module.run_command([ifconfig_path, ifconfig_options])
    rc, out, err = run_command([ifconfig_path, ifconfig_options])
    # interfaces = {}
    interfaces = {}
    # current_if = {}
    current_if = {}
    # ips = dict(
    #     all_ipv4_addresses=[],
    #     all_ipv6_addresses=[

# Generated at 2022-06-24 22:47:24.184567
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    var_0 = GenericBsdIfconfigNetwork()
    defaults = {u'interface': u'lo0'}

# Generated at 2022-06-24 22:47:33.500006
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    var_0 = GenericBsdIfconfigNetwork('module_0')
    var_1 = Interface('interface_1')
    
    var_1.set_macaddress('macaddress_1')
    
    var_2 = Interface('interface_2')
    var_2.set_type('ether')
    var_3 = Interface('interface_3')
    var_3.set_media('media_3')
    var_1 = Interface('interface_3')
    var_1.set_media('Ether')
    
    
    var_4 = {
        'interface_1': var_1, 
        'interface_2': var_2, 
        'interface_3': var_3
    }

# Generated at 2022-06-24 22:47:44.819966
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    current_if = {}
    ips = {}
    words = ['inet6', 'fe80::fcee:8aff:fe01:5dc5%awdl0', 'prefixlen', '64', 'scopeid', '0x5']
    obj = GenericBsdIfconfigNetwork()
    obj.parse_inet6_line(words, current_if, ips)
    assert ips == {'all_ipv6_addresses': ['fe80::fcee:8aff:fe01:5dc5%awdl0']}

    current_if = {}
    ips = {}
    words = ['inet6', 'fe80::d714:df3a:d39:ccce%en0', 'prefixlen', '64', 'scopeid', '0x1']
    obj = GenericBsdIfconfigNetwork()
   

# Generated at 2022-06-24 22:47:51.108753
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    obj_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    names_0 = ['127.0.0.1', 'netmask', '0xff000000', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    var_0 = ' '.join(names_0)
    obj_GenericBsdIfconfigNetwork.parse_inet_line(var_0)


# Generated at 2022-06-24 22:47:55.673207
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    var_1 = GenericBsdIfconfigNetwork()
    var_2 = None
    var_2 = var_1.populate()
    if sys.version_info > (3,):
        assert isinstance(var_2, dict)
    else:
        assert isinstance(var_2, types.DictType)
