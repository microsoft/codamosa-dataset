

# Generated at 2022-06-24 22:40:30.270877
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = '::1'
    str_1 = '::1/128'
    str_2 = 'fe80::1%lo0'
    str_3 = '1'
    str_4 = '2'
    str_5 = '3'
    str_6 = '4'
    list_0 = [str_0, str_1, str_2]
    str_7 = 'scope'
    list_1 = [str_3, str_4, str_5]
    int_0 = -3762
    int_1 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    dict_0 = {}
    str_8 = 'abcd'
    dict_0['address'] = str_8
    dict_0['scope']

# Generated at 2022-06-24 22:40:42.169042
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    collected_facts_0 = {}
    returned_0 = generic_bsd_ifconfig_network_0.populate(collected_facts_0)
    print((''))
    print((returned_0))
    print((returned_0['default_ipv4']))
    print((returned_0['default_ipv6']))
    print((returned_0['all_ipv4_addresses']))
    print((returned_0['all_ipv6_addresses']))

# Comment out the test cases to speed up the unit test
if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_

# Generated at 2022-06-24 22:40:43.837467
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    print(GenericBsdIfconfigNetwork.detect_type_media.__doc__)


# Generated at 2022-06-24 22:40:54.167861
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:41:01.972019
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = generic_bsd_ifconfig_network_0.get_bin_path('route')
    defaults_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    dict_0 = dict(defaults_0[0])
    dict_1 = dict(defaults_0[1])
    value_0 = dict_0.get('interface', 'G')
    value_1 = dict_0.get('gateway', 'G')
    value_2 = dict_0.get('address', 'G')
    value_3 = dict_1.get('interface', 'G')

# Generated at 2022-06-24 22:41:03.711997
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    assert GenericBsdIfconfigNetwork(0).get_default_interfaces('route') == ('', '') # TODO: implement your test here


# Generated at 2022-06-24 22:41:14.497510
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # test harness for GenericBsdIfconfigNetwork.parse_inet6_line method
    # Replicates unit test located at
    # https://github.com/ansible/ansible/blob/v2.8.6/test/units/modules/network/basics/test_generic_bsd.py#L354
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ['inet6', 'fe80::5e5d:c8ff:fe9a:a04%carp0', 'prefixlen', '64', 'scopeid', '0x10']

# Generated at 2022-06-24 22:41:18.917295
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    instance = GenericBsdIfconfigNetwork(0)
    words = ['-', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {
            'device': '-', 
            'ipv4': [], 
            'ipv6': [], 
            'type': 'unknown', 
            'macaddress': 'unknown', 
            'mtu': '0xff000000'
        }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # cidr style ip address (eg, 127.0.0.1/24) in inet line
    # used in netbsd ifconfig -e output after 7.1
    # ip_address, cidr_mask = address['address

# Generated at 2022-06-24 22:41:25.395603
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from pydoc import locate
    module = 'ansible.module_utils.basic'
    clazz = 'GenericBsdIfconfigNetwork'
    method_name = 'merge_default_interface'
    foo = locate('{}.{}'.format(module, clazz))
    method_to_call = getattr(foo, method_name)
    #
    defaults = 'defaults'
    interfaces = 'interfaces'
    ip_type = 'ip_type'
    # execute
    method_to_call(defaults, interfaces, ip_type)

# Generated at 2022-06-24 22:41:32.011684
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # '<UP,BROADCAST,RUNNING,MULTICAST>'
    option_string = '<UP,BROADCAST,RUNNING,MULTICAST>'
    res = GenericBsdIfconfigNetwork.get_options(option_string)
    assert (res == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'])


# Generated at 2022-06-24 22:41:45.958246
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    Network = GenericBsdIfconfigNetwork()
    populate = Network.populate()
    assert populate == None


# Generated at 2022-06-24 22:41:50.207548
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    obj = GenericBsdIfconfigNetwork()
    obj.detect_type_media('interfaces')


# Generated at 2022-06-24 22:41:53.496729
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    
    obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-24 22:42:01.063201
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    cf = GenericBsdIfconfigNetwork()

    str_0 = 'inet6 fe80::2de:b7ff:fea3:155a%igb0 prefixlen 64 scopeid 0x20'
    str_1 = 'inet6 fe80::2de:b7ff:fea3:155a prefixlen 64 scopeid 0x20'
    str_2 = 'inet6 fe80::2de:b7ff:fea3:155a%igb0 prefixlen 64'
    str_3 = 'inet6 fe80::2de:b7ff:fea3:155a prefixlen 64'
    str_4 = 'inet6 fe80::2de:b7ff:fea3:155a%igb0 scopeid 0x20'

# Generated at 2022-06-24 22:42:03.286871
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    GenericBsdIfconfigNetwork_obj = GenericBsdIfconfigNetwork()
    GenericBsdIfconfigNetwork_obj.parse_inet6_line(test_data_0, test_data_1, test_data_2)

# Generated at 2022-06-24 22:42:10.537148
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    ipv4_result = obj.merge_default_interface('ifconfig_path', 'route_path')
    assert 'Generic BSD network facts' in ipv4_result['platform']
    print('passed test 0')

# Generated at 2022-06-24 22:42:18.345942
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    command_0 = ['/usr/sbin/ifconfig', '-a']

    ifconfig_path = command_0
    ifconfig_path = '/usr/sbin/ifconfig'

    command_1 = ['/usr/sbin/route', '-n', 'get', 'default']

    route_path = command_1
    route_path = '/usr/sbin/route'

    default_ipv4, default_ipv6 = GenericBsdIfconfigNetwork.get_default_interfaces(route_path)

    network_facts = {}

    network_facts = GenericBsdIfconfigNetwork.populate(network_facts)



# Generated at 2022-06-24 22:42:30.076593
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    obj_0 = GenericBsdIfconfigNetwork()
    obj_0.module = Mock()
    obj_0.module.run_command = Mock()
    obj_0.module.run_command.return_value = (
            0, '', ''
    )
    obj_0.module.get_bin_path = Mock()
    obj_0.module.get_bin_path.return_value = '/sbin/ifconfig'
    obj_0.get_default_interfaces = Mock()
    obj_0.get_default_interfaces.return_value = (dict(), dict())
    obj_0.get_interfaces_info = Mock()
    obj_0.get_interfaces_info.return_value = (dict(), dict())
    obj_0.merge_default_interface = Mock()

# Generated at 2022-06-24 22:42:42.001399
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    obj.get_default_interfaces = MagicMock(return_value = ({'interface': 'lo0', 'address': '127.0.0.1', 'gateway': '127.0.0.1'}, ))

# Generated at 2022-06-24 22:42:44.993879
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    populator_0 = GenericBsdIfconfigNetwork()
    populator_0.populate()
    return


if __name__ == '__main__':
    import sys
    sys.exit(test_GenericBsdIfconfigNetwork_populate())

# Generated at 2022-06-24 22:43:01.885329
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    num_args = 0
    path_0 = '/sbin/route'
    route_path = path_0
    obj_0 = GenericBsdIfconfigNetwork(route_path)
    intf_v4, intf_v6 = obj_0.get_default_interfaces(route_path)
    assert isinstance(intf_v4, dict)
    assert isinstance(intf_v6, dict)


# Generated at 2022-06-24 22:43:06.467921
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    gbin = GenericBsdIfconfigNetwork()
    
    #case0
    network_facts_0 = gbin.populate()
    print(network_facts_0)
    print(set(network_facts_0['interfaces']))
    print(network_facts_0['default_ipv4']['address'])
    print(network_facts_0['default_ipv6']['address'])
    
    

# Generated at 2022-06-24 22:43:17.106905
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # Setup test case inputs
    p1_0 = GenericBsdIfconfigNetwork()
    p1_1 = GenericBsdIfconfigNetwork()
    p1_2 = GenericBsdIfconfigNetwork()

    p1_2.module = mock.Mock()
    p1_2.module.run_command = mock.Mock(return_value=(1, 'Error', 'Error'))

    test_case_inputs = [
        (p1_0, 'Unknown', 'Unknown'),
        (p1_1, 'Unknown', 'Unknown'),
        (p1_2, 'Unknown', 'Unknown'),
    ]

    # Execute the test function
    for p1, p2, expected in test_case_inputs:
        with mock.patch('sys.platform', new=p1):
            actual = GenericBsdIfconfig

# Generated at 2022-06-24 22:43:27.524990
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible_collections.ansible.community.plugins.module_utils.network.common.utils import ComplexList
    from ansible_collections.ansible.community.plugins.module_utils.network.common.ifconfig.generic_bsd import GenericBsdIfconfigNetwork

    # Fixture 2: test with a successful execution
    # The fixture performs the following operations
    # - Define function get_bin_path from module ansible.module_utils.basic.AnsibleModule
    # - Define function run_command from module ansible.module_utils.basic.AnsibleModule
    # - Define 'route' as the command to be run on the Ansible module
    # - Define '-n get default' as the output of the command
    # - Define '-n get -inet6 default' as the output of the command
   

# Generated at 2022-06-24 22:43:38.593134
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    #
    # Set up mock
    #
    class GenericBsdIfconfigNetwork():
        def __init__(self, module):
            self.module = module
    class Module():
        def __init__(self):
            self.params = {}
            self.config = {}
        def get_bin_path(self, arg):
            return ''
        def run_command(self, arg):
            return 0, "", ""
    module = Module()
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    #
    # Invoke method
    #
    result = generic_bsd_ifconfig_network.populate()

    #
    # Assert conditions for expected results
    #
    assert result == {}


# Generated at 2022-06-24 22:43:45.878522
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # set up test input
    current_if = {}
    ips = {}

    # set up test case
    test_case_0_words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    test_case_0_current_if = {'ipv4': [], 'device': 'lo0', 'type': 'unknown', 'macaddress': 'unknown'}
    test_case_0_ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    test_case_0_ips_expected = {'all_ipv4_addresses': ['127.0.0.1'], 'all_ipv6_addresses': []}

# Generated at 2022-06-24 22:43:48.706025
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbin = GenericBSDIfconfigNetwork

    assert gbin.get_options(str_0) == ["UP", "BROADCAST", "RUNNING", "MULTICAST"], 'Expected different output'

# Generated at 2022-06-24 22:43:51.801337
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    gbini = GenericBsdIfconfigNetwork()
    assert gbini.get_default_interfaces('route') == ({}, {})


# Generated at 2022-06-24 22:44:03.137981
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    osbsd = GenericBsdIfconfigNetwork()
    param_0 = ["lo0:", "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>", "metric", "0", "mtu", "33184", "inet", "127.0.0.1", "netmask", "0xff000000", "inet6", "::1", "prefixlen", "128", "inet6", "fe80::1%lo0", "prefixlen", "64", "scopeid", "0x1", "nd6", "options=1<PERFORMNUD>"]
    param_1 = {}
    param_2 = {'all_ipv4_addresses': []}
    res_0 = osbsd.parse_inet_line(param_0, param_1, param_2)

# Generated at 2022-06-24 22:44:13.452556
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Create an instance of a generic bsd ifconfig network
    generic_bsd_ifconfig_network_obj = GenericBsdIfconfigNetwork()

    # Test for the line parsing for inet6
    arg_0 = ["inet6", "fe80::5e5f:caff:feab:251f%en1", "prefixlen", "64", "scopeid", "0x5"]
    if generic_bsd_ifconfig_network_obj.parse_inet6_line(arg_0) is not None:
        generic_bsd_ifconfig_network_obj.parse_inet6_line(arg_0)



# Generated at 2022-06-24 22:44:31.742243
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case #0
    int_0 = -5534
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = 'b)nU/\\5vL}!+Q\x0cM|\n'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_0)
    list_0 = ['nm7=OluKw'.strip()]
    dict_0 = {'': {}}
    generic_bsd_ifconfig_network_0.merge_default_interface(dict_0, dict_0, list_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:44:41.343816
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Setup
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    int_0 = 0
    str_0 = 'b)nU/\\5vL}!+Q\x0cM|\n'
    if (int_0 == 0):
        str_1 = str(int_0)
    elif (int_0 == 1):
        str_1 = str(int_0)
    str_2 = 'interfaces'
    str_3 = 'ipv4'
    str_4 = 'ipv6'
    str_5 = 'all_ipv4_addresses'
    str_6 = 'all_ipv6_addresses'
    # TypeError: 'NoneType' object is not iterable
   

# Generated at 2022-06-24 22:44:49.213072
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_b = '::1/128'
    int_c = 4
    str_d = 'scopeid'
    dict_d = dict({'scope': '0x9', 'address': '::1', 'prefix': '128'})
    list_a = ['inet6', '::1/128', 'prefixlen', '64', 'scopeid', '0x9']
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(4)
    dict_a = test_GenericBsdIfconfigNetwork.parse_inet6_line(list_a, dict_b, dict_c)
    assert dict_a == dict_d


# Generated at 2022-06-24 22:44:57.765194
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    int_1 = -3881
    str_0 = '@:6I5^5kv7KW\x0cKm;'
    dict_0 = dict()
    dict_0['@:6I5^5kv7KW\x0cKm;'] = int_1
    str_1 = 's*$<\x1aE\t<,se'
    generic_bsd_ifconfig_network_0.merge_default_interface(str_0, dict_0, str_1)



# Generated at 2022-06-24 22:45:04.659379
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 656
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = 'j6\x1c4'
    str_1 = 'Q'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_1)


# Generated at 2022-06-24 22:45:12.500797
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = -3762
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    dict_0 = {'M' : 'B>C.3\x7fQ*|\t\n-o\'\x1d', 'E' : 'n\x1f\x15\x7f\x0e\x15{`-\x13', 'S' : ':H\x7f$S>x\x7f<8\t\x7f('}
    var_0 = generic_bsd_ifconfig_network_0.populate(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:45:20.557673
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    str_0 = 'configure-and-watch,mfib-forwarding,path-mtu-discovery-input'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(0)
    var_0 = generic_bsd_ifconfig_network_0.get_options(str_0)
    print(var_0)


# Generated at 2022-06-24 22:45:28.094472
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 68958
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = (generic_bsd_ifconfig_network_0.default_ipv4, {})

# Generated at 2022-06-24 22:45:38.048123
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    print("Testing GenericBsdIfconfigNetwork.merge_default_interface()")

    # Setup, test the arguments provided

# Generated at 2022-06-24 22:45:47.450185
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = -2
    # merges defaults interface back into our interfaces
    # list, this allows us to use the interface specific
    # facts for the default device as well.
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = 'd1wJ`'
    str_1 = 'S=\x16fj'
    str_2 = 'hJ4A4'
    str_3 = 'n'
    const_str_0 = '\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b['
    const_str_1 = '\x05\x05\x05\x05\x05'
    generic

# Generated at 2022-06-24 22:46:05.611482
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # AssertionError
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(1115)
    int_0 = None
    with raises(AssertionError): generic_bsd_ifconfig_network_0.detect_type_media(int_0)


# Generated at 2022-06-24 22:46:15.300234
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(generic_bsd_ifconfig_network_0)

    assert generic_bsd_ifconfig_network_0.__class__.platform == 'Generic_BSD_Ifconfig', 'The returned value is incorrect'
    assert generic_bsd_ifconfig_network_0.__class__.platform == 'Generic_BSD_Ifconfig', 'The returned value is incorrect'
    assert generic_bsd_ifconfig_network_0.__class__.platform == 'Generic_BSD_Ifconfig', 'The returned value is incorrect'

# Generated at 2022-06-24 22:46:23.403909
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 4095
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0, var_0)
    assert var_0 is not None


# Generated at 2022-06-24 22:46:33.770590
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            as_dict=dict(default=False, type='bool')
        ),
        supports_check_mode=True
    )

    display_information = module.params['as_dict']

    #This is the return of the function get_interfaces_info
    interfaces, ips = GenericBsdIfconfigNetwork.get_interfaces_info()

    interface = list(interfaces.keys())
    if display_information:
        module.exit_json(changed=False, ansible_facts=dict(ansible_network_resources=dict(interfaces=interfaces, ips=ips)))
    else:
        module.exit_json(changed=False, ansible_facts=dict(ansible_interfaces=interface))


# Generated at 2022-06-24 22:46:39.913137
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)


# Generated at 2022-06-24 22:46:48.942067
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    int_0 = 1672
    int_1 = 1378
    str_0 = "qn%=,d_x&['sCY,"
    str_1 = 'G'
    str_2 = 'A'
    str_3 = 'U'
    str_4 = 'P'
    str_5 = ','
    str_6 = 'A'
    str_7 = 'W'
    str_8 = 'A'
    str_9 = 'K'
    str_10 = 'E'
    str_11 = ','
    str_12 = 'R'
    str_13 = 'U'
    str_14 = 'N'
    str_15 = 'N'
    str_16 = 'I'
    str_17 = 'N'
    str_18 = 'G'
    str

# Generated at 2022-06-24 22:46:53.563701
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    int_1 = 'hi!'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(int_1)


# Generated at 2022-06-24 22:47:01.514775
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = ""
    str_1 = ""
    var_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_1)
    int_1 = 0

    assert(var_1[int_0]["device"] == "lo0")


# Generated at 2022-06-24 22:47:08.150359
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info()
    assert var_0 is None, "Variable var_0 is set to 'None'."


# Generated at 2022-06-24 22:47:12.326759
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    int_0 = 876
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ['', '0.0.0.0', 'netmask', 'ff000000', 'alias']
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:47:30.384012
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(generic_bsd_ifconfig_network_0)


# Generated at 2022-06-24 22:47:34.453669
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    option_string_0 = '<UP,BROADCAST,LOOPBACK,MULTICAST>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(option_string_0)
    assert var_0 == ['UP', 'BROADCAST', 'LOOPBACK', 'MULTICAST']


# Generated at 2022-06-24 22:47:37.625025
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_1 = generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:47:46.787931
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test with just one argument
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)
    # Test with two arguments
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0, generic_bsd_ifconfig_network_0)


# Generated at 2022-06-24 22:47:52.781054
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    var_0 = generic_bsd_ifconfig_network_0.parse_interface_line(words_0)


# Generated at 2022-06-24 22:48:03.056887
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 711
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    # Test case with zero args passed in
    # Return value is not a boolean
    try:
        result = generic_bsd_ifconfig_network_0.get_interfaces_info()
    except TypeError as error:
        print("TypeError: ", error)

    # Test case with only one arg passed in
    # Return value is not a boolean
    try:
        result = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)
    except TypeError as error:
        print("TypeError: ", error)

    # Test with all args passed in
    # Return value is not a boolean

# Generated at 2022-06-24 22:48:11.055823
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    int_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)
    print(int_1)

test_GenericBsdIfconfigNetwork_get_interfaces_info()

# Generated at 2022-06-24 22:48:15.562132
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ['inet6', '2001:5c0:1400:a::1a', 'prefixlen', '64', 'scopeid', '0x0']
    current_if_0 = dict()
    current_if_0['ipv6'] = list()
    ips_0 = dict()
    ips_0['all_ipv6_addresses'] = list()
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)
    assert '2001:5c0:1400:a::1a' == ips_0['all_ipv6_addresses'][0]


# Generated at 2022-06-24 22:48:22.014440
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = 956
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)
    var_1 = generic_bsd_ifconfig_network_0.detect_type_media(var_0[0])


# Generated at 2022-06-24 22:48:26.960152
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Declare objects and variables
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = {}
    var_1 = {}
    var_2 = "interface"
    var_3 = 1115
    var_4 = 1115
    var_5 = 1115
    var_6 = "device"
    var_7 = 1115
    var_8 = 1115
    var_9 = 1115
    var_10 = "inet"
    var_11 = 1115
    var_12 = 1115
    var_13 = 1115
    var_14 = "flags"
    var_15 = 1115
    var_16 = 1115
    var_17 = 1115
    var_18 = "mtu"
    var

# Generated at 2022-06-24 22:48:47.151412
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 27
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    dict_0 = dict()
    dict_0['interface'] = 'tap2'
    dict_1 = dict()
    dict_1['ipv4'] = list_0 = list()
    dict_1['interface'] = 'tap2'
    dict_1['type'] = 'ether'
    dict_1['flags'] = list_0
    dict_1['mtu'] = '1500'
    dict_1['macaddress'] = 'unknown'
    str_0 = 'ipv4'
    dict_2 = dict()
    dict_2['address'] = '192.168.122.xx'
    dict_2['netmask'] = '255.255.255.0'
    dict

# Generated at 2022-06-24 22:48:48.724558
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-24 22:48:52.173981
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Pre-assign parameters
    collected_facts_0 = "!-#end!"

    # Call method directly
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(collected_facts_0)
    var_0 = generic_bsd_ifconfig_network_0.populate(collected_facts_0)

    # Make assertions
    assert var_0 == "!-#end!", "Incorrect value for var_0."


# Generated at 2022-06-24 22:48:57.345915
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = GenericBsdIfconfigNetwork(1)
    int_1 = int_0.get_interfaces_info()


# Generated at 2022-06-24 22:49:02.482644
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    defaults_0 = dict()
    interfaces_0 = dict()
    ip_type_0 = "D$\u001e"
    assert generic_bsd_ifconfig_network_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0) == None


# Generated at 2022-06-24 22:49:10.364203
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    (int_1, int_2) = 1115, 837
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(int_1)
    var_1 = generic_bsd_ifconfig_network_1.get_default_interfaces(generic_bsd_ifconfig_network_1.get_interfaces_info)
    assert var_1 == (int_1, int_2)


# Generated at 2022-06-24 22:49:14.531684
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    string_0 = '<>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(string_0)
    return var_0


# Generated at 2022-06-24 22:49:22.971761
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # happy path
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    interface_defaults = dict()
    interface_defaults['interface'] = 'eth0'
    interfaces = dict()
    interfaces['eth0'] = dict()
    interfaces['eth0']['flags'] = ['dummy_flag']
    interfaces['eth0']['ipv4'] = ['dummy_ipv4']
    generic_bsd_ifconfig_network_0.merge_default_interface(interface_defaults, interfaces, 'ipv4')
    assert interface_defaults['flags'] == ['dummy_flag']
    assert interface_defaults['ipv4'] == ['dummy_ipv4']
    assert 'interface' not in interface_defaults

# Generated at 2022-06-24 22:49:23.943259
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:49:28.162832
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    var_1 = generic_bsd_ifconfig_network.populate()
    var_1 = generic_bsd_ifconfig_network.populate()
    var_1 = generic_bsd_ifconfig_network.populate()


# Generated at 2022-06-24 22:49:49.398933
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 1115
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(generic_bsd_ifconfig_network_0)
    var_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(generic_bsd_ifconfig_network_0)
    var_2 = generic_bsd_ifconfig_network_0.merge_default_interface(var_0, var_1)

# Generated at 2022-06-24 22:49:54.043743
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 595
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    var_0 = generic_bsd_ifconfig_network_0.populate()
