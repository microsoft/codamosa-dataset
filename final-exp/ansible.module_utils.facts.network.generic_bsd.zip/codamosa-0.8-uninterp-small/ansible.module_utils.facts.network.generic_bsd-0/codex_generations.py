

# Generated at 2022-06-24 22:40:23.318263
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    words = ['media:', 'Ethernet', 'autoselect (1000baseT <full-duplex>)' ]
    current_if =  {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    GenericBsdIfconfigNetwork(str, str).parse_media_line(words, current_if, ips)


# Generated at 2022-06-24 22:40:30.457326
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = [
        'pass',
        'pass',
        'pass',
        'pass',
        'pass',
        'pass',
        'pass',
        'pass',
        'pass',
        'pass'
    ]
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_media_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:40:42.292373
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = ['']    
    current_if_0 = {'device': '','flags': ['','',''],'macaddress': '','mtu': '','ipv4': ['','','','','','','','','','','','','','',''], 'ipv6': ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',''], 'type': 'loopback'}    

# Generated at 2022-06-24 22:40:44.869614
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    assert generic_bsd_ifconfig_network_0.get_interfaces_info(arg_0, arg_1) == (arg_2, arg_3)


# Generated at 2022-06-24 22:40:52.635606
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_1 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_1, str_1)
    # Set arguments
    ifconfig_path = 'ifconfig_path'
    ifconfig_options = 'ifconfig_options'
    # Call method
    result = GenericBsdIfconfigNetwork.get_interfaces_info(generic_bsd_ifconfig_network_1, ifconfig_path, ifconfig_options)
    assert isinstance(result, tuple)


# Generated at 2022-06-24 22:40:57.425531
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_case_0()
    network_facts_0 = {'type': 'ether'}
    network_facts_1 = {'media': 'ether', 'type': 'unknown'}
    list_0 = [network_facts_0, network_facts_1]
    interfaces_0 = {'en0': list_0[1]}
    GenericBsdIfconfigNetwork.detect_type_media(interfaces_0)


# Generated at 2022-06-24 22:41:03.982349
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'Generic_BSD_Ifconfig'
    generic_bsd_ifconfig_network_0.platform = str_1
    str_2 = 'Command failed rc=%d, out=%s, err=%s'
    module_0 = AnsibleModule(str_2, str_2)
    generic_bsd_ifconfig_network_0.module = module_0
    str_3 = 'ifconfig'
    module_0.get_bin_path(str_3)
    str_4 = 'ifconfig'

# Generated at 2022-06-24 22:41:10.757747
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    defaults = {}
    interfaces = {}
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)



# Generated at 2022-06-24 22:41:16.524404
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    # SUT:
    words = ['ether', '6c:f0:49:05:f3:60']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': ['10.0.1.7'], 'all_ipv6_addresses': []}
    generic_bsd_ifconfig_network_0.parse_ether_line(words, current_if, ips)

# Generated at 2022-06-24 22:41:20.535385
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    #
    # Test for /usr/sbin/route -n get default
    #
    #
    # Test for /usr/sbin/route -n get -inet6 default
    #



# Generated at 2022-06-24 22:41:37.409564
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    ifconfig_path = 'ifconfig_path'
    str_1 = 'ifconfig_options'
    interfaces_0, ips_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, str_1)
    assert type(interfaces_0) is dict
    assert type(ips_0) is dict


# Generated at 2022-06-24 22:41:47.463538
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:41:59.212057
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    str_1 = '/etc/rc'
    str_2 = 'ip'
    str_3 = 'ipv6'
    str_4 = 'default'
    str_5 = '%i'
    dict_0 = dict()
    list_0 = [dict(), dict()]
    list_1 = [str(), str_4, str_1, str_4, str_4]
    list_2 = [str_4, str_4, str_2, str_4, str_1]
    dict_1 = dict(list_0=[], list_2=list_2)
    list_3 = [str_4, str_1, str_4, str_4, str_4]

# Generated at 2022-06-24 22:42:05.400083
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_path = 'GenericBsdIfconfigNetwork.ifconfig_path'
    ifconfig_options = 'GenericBsdIfconfigNetwork.ifconfig_options'
    network = GenericBsdIfconfigNetwork(ifconfig_path, ifconfig_options)
    words = ['media:', 'Ethernet autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']
    current_if = { 'media' : 'Ethernet autoselect', 'status' : 'active' }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    network.parse_media_line(words, current_if, ips)

# Generated at 2022-06-24 22:42:15.113912
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = ['vusahc', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184', 'inet 127.0.0.1 netmask 0xff000000']
    result_0 = generic_bsd_ifconfig_network_0.parse_interface_line(words_0)
    assert(result_0['device'] == 'vusahc')
    assert(result_0['mtu'] == '33184')


# Generated at 2022-06-24 22:42:22.145286
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'route'
    tuple_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    assert type(tuple_0) is tuple


# Generated at 2022-06-24 22:42:31.895528
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.module.run_command = MagicMock(
        side_effect=[(0, '', ''), (0, '', '')])
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_1.module.run_command = MagicMock(
        side_effect=[(0, '', ''), (1, '', '')])

# Generated at 2022-06-24 22:42:42.880023
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    # Variations of the 'words' parameter
    # words_0 = ['Command failed rc=%d, out=%s, err=%s']
    # words_1 = [[0, 1, 2]]
    words_2 = ['Command', 'failed', 'rc=%d,', 'out=%s,', 'err=%s']
    words_3 = ['Command', 'failed', 'rc=%d,', 'out=%s,', 'err=%s', 'Command failed rc=%d, out=%s, err=%s']

# Generated at 2022-06-24 22:42:48.829995
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 0
    dict_0 = dict()
    dict_0['interface'] = str()
    dict_0['address'] = str()
    dict_1 = dict()
    dict_1['ipv6'] = [dict_0, dict_0]
    dict_1['ipv4'] = [dict_0, dict_0]
    dict_1['macaddress'] = str()
    dict_2 = dict()
    dict_2['interface'] = str()
    dict_3 = dict()
    dict_3[str()] = dict_1
    dict_4 = dict()
    dict_4[str()] = dict_2
    dict_4[str()] = dict_2
    dict_4[str()] = dict_2
    dict_4[str()] = dict_2
    dict

# Generated at 2022-06-24 22:42:50.563181
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print(GenericBsdIfconfigNetwork.parse_inet_line())


# Generated at 2022-06-24 22:43:06.585443
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # No exception raised
    gen_bsd_net = GenericBsdIfconfigNetwork()
    result_bool_0 = gen_bsd_net.parse_media_line('', {}, {}, )

# Generated at 2022-06-24 22:43:17.416888
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # body
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    words_0 = ["bond1", "inet", "192.168.0.1", "netmask", "255.255.0.0", "broadcast", "192.168.255.255"]
    current_if_0 = {"device": "bond1", "ipv4": [], "ipv6": [], "type": "unknown"}
    ips_0 = {"all_ipv4_addresses": [], "all_ipv6_addresses": []}


# Generated at 2022-06-24 22:43:22.543815
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'route'
    generic_bsd_ifconfig_network_1 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)


# Generated at 2022-06-24 22:43:33.494667
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_1 = 'inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2'
    list_0 = str_1.split()
    dict_0 = {}
    ipv6_address_0 = {}
    ipv6_address_0['address'] = 'fe80::1%lo0'
    ipv6_address_0['prefix'] = '64'
    ipv6_address_0['scope'] = '0x2'

# Generated at 2022-06-24 22:43:40.287896
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    out = generic_bsd_ifconfig_network_0.populate()
    print(out)


# Generated at 2022-06-24 22:43:52.476672
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # test that we can handle all of the known variations
    # of output from ifconfig -a
    #
    # TODO: add more?
    #

    # test case 0
    str_0 = 'net0: flags=8008843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,NEEDSGIANT> metric 0 mtu 1500\n    options=8<VLAN_MTU>\n    ether 00:a0:cc:2e:d0:b0\n    inet 10.10.181.76 netmask 0xffffff00 broadcast 10.10.181.255\n    media: Ethernet autoselect (none)\n    status: no carrier\n'
    ifconfig_path = '/sbin/ifconfig'
    generic_bsd_ifconfig_network_0 = GenericB

# Generated at 2022-06-24 22:44:01.390904
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = [None]
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)



# Generated at 2022-06-24 22:44:13.417860
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print("unit testing get_default_interfaces")
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    print("Testcase 1: expected {'gateway': '10.0.0.1', 'interface': 'eth1'}, {'gateway': '2001:db8::1', 'interface': 'eth1'}")
    print("Testcase 1: real    {'gateway': '10.0.0.1', 'interface': 'eth1'}, {'gateway': '2001:db8::1', 'interface': 'eth1'}")

# Generated at 2022-06-24 22:44:21.092456
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_2 = 'route'
    str_1 = generic_bsd_ifconfig_network_0.module.get_bin_path(str_2)
    assert str_1 is not None, "Test if command 'route' exists"
    default_ipv4, default_ipv6 = generic_bsd_ifconfig_network_0.get_default_interfaces(str_1)
    print("default_ipv4: {}".format(default_ipv4))
    print("default_ipv6: {}".format(default_ipv6))


# Generated at 2022-06-24 22:44:33.345231
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork()
    interfaces_0 = {'lo0': {'ipv4': [], 'device': 'lo0', 'type': 'unknown', 'ipv6': [], 'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}, 'lo1': {'ipv4': [], 'device': 'lo1', 'type': 'unknown', 'ipv6': [], 'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}}
    generic_bsd_ifconfig_network_0.detect_type_media(interfaces_0)
    assert interfaces_0 == generic_bsd_ifconfig_network_

# Generated at 2022-06-24 22:44:52.097641
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    interfaces = {}
    interfaces_reuslt = generic_bsd_ifconfig_network_0.detect_type_media(interfaces)


# Generated at 2022-06-24 22:44:57.764518
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(test_case_0,test_case_0)

    # test for exceptions
    try:
        generic_bsd_ifconfig_network_0.detect_type_media('eth0')
    except Exception as e:
        print('can not detect type media of interface')
        print('triggered the exception: ', e)


# Generated at 2022-06-24 22:44:59.313257
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-24 22:45:10.105539
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    # list_0 is a list of bytes
    list_0 = [0x64,0x75,0x6d,0x70,0x20,0x73,0x20,0x61]
    # list_1 is a list of bytes
    list_1 = [0x6c,0x69,0x73,0x74,0x20,0x6f,0x66,0x20]
    # list_2 is a list of bytes
    list_2 = [0x74,0x65,0x73,0x74,0x73,0x21]
   

# Generated at 2022-06-24 22:45:14.243279
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    collected_facts = None
    network_facts = generic_bsd_ifconfig_network_0.populate(collected_facts)

    expect_network_facts_type_0 = str
    assert isinstance(network_facts, expect_network_facts_type_0)


# Generated at 2022-06-24 22:45:26.135606
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    global str_0
    route_path = str_0
    # Test case with args: /sbin/route
    test_0 = 'route: writing to routing socket: No buffer space available'
    out = test_0
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(str_0, test_0)
    rc, out, err = generic_bsd_ifconfig_network_1.module.run_command([route_path])
    if rc != 0:
        generic_bsd_ifconfig_network_1.module.fail_json(msg=out)
    generic_bsd_ifconfig_network_2 = GenericBsdIfconfigNetwork(str_0, out)
    out = generic_bsd_ifconfig_network_2.parse_route_output(out)
    default_ip

# Generated at 2022-06-24 22:45:33.064827
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """ test_GenericBsdIfconfigNetwork_merge_default_interface """
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    generic_bsd_ifconfig_network_0.merge_default_interface({}, {}, str_0)


# Generated at 2022-06-24 22:45:42.891073
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    str_0 = 'os.path.sep'
    str_1 = '.'
    len_0 = random.randrange(2, 6)
    list_0 = []
    for item_0 in range(0, len_0):
        int_0 = random.randrange(0, 100)
        list_0.append(int_0)
    var_0 = ''.join(map(chr, list_0))
    str_2 = '%s %s %s %s' % (str_0, str_1, var_0, str_1)
    str_3 = '/'

# Generated at 2022-06-24 22:45:48.047546
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)

    # Test with valid parameter values
    collected_facts = 'collected_facts'
    returned_value = generic_bsd_ifconfig_network_0.populate(collected_facts)
    assert returned_value == None

# Generated at 2022-06-24 22:45:58.450522
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'Command failed rc=%d, out=%s, err=%s'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0, str_0)
    words_0 = ['192.168.1.100/24', 'inet', '10.0.0.1/16', '192.168.1.100', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:46:16.217115
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    return_value_0 = dict({'broadcast': '', 'interface': '', 'network': '', 'address': '', 'netmask': '', 'gateway': ''})
    var_1 = dict({'broadcast': '', 'interface': '', 'network': '', 'address': '', 'netmask': '', 'gateway': ''})
    dict_1 = dict()
    dict_1['ipv4'] = var_1
    dict_1['ipv6'] = var_1
    dict_1['options'] = ''
    dict_1['device'] = ''
    dict_1['type'] = 'ether'
    dict_1['macaddress'] = ''
    dict_1

# Generated at 2022-06-24 22:46:26.816190
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    str_0 = '$ ifconfig -a'
    str_1 = '$ /usr/sbin/ifconfig -a'
    str_2 = '$ /sbin/ifconfig -a'
    int_0 = 3
    str_3 = ''
    str_4 = ''
    str_5 = ''
    bool_1 = bool_0
    bool_2 = bool_1
    bool_3 = bool_2
    bool_4 = bool_3
    bool_5 = bool_4
    bool_6 = bool_5
    bool_7 = bool_6
    bool_8 = bool_7
    bool_9 = bool_8
    bool_10 = bool_9


# Generated at 2022-06-24 22:46:37.582484
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Arrange - Assign
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)    
    ifconfig_path = generic_bsd_ifconfig_network_0.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    # Act
    interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)    
    # Assert
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)


# Generated at 2022-06-24 22:46:41.857278
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    result = generic_bsd_ifconfig_network_0.populate()
    assert True == result


# Generated at 2022-06-24 22:46:46.657559
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    str_0 = '/sbin/ifconfig'
    tuple_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(str_0)
    print(tuple_0)


# Generated at 2022-06-24 22:46:55.750419
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    words_0 = ['', 'fe80::8bcd:daff:fe44:6c85%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if_0 = dict()
    ips_0 = dict()
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:47:00.496738
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bool_1 = False
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(bool_1)
    str_0 = ''
    var_2 = generic_bsd_ifconfig_network_1.get_default_interfaces(str_0)


# Generated at 2022-06-24 22:47:05.555019
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()
    pass

if __name__ == "__main__":
    test_case_0()
    #test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:47:06.284693
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    assert True


# Generated at 2022-06-24 22:47:12.373024
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    defaults = {}
    interfaces = collections.defaultdict(dict)
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:47:32.287810
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test for a Hexidecimal Netmask
    words = ['inet', '160.8.0.1', 'netmask', '0xffffff00']
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'mtu': '1500'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    if not re.match('([0-9a-f]){8}', words[3]) and len(words[3]) == 8:
        words[3] = '0x' + words[3]

# Generated at 2022-06-24 22:47:44.279445
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # rc, out, err = self.module.run_command(...)
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    str_0 = 'le0'
    dict_0 = dict()
    dict_0['device'] = str_0
    dict_0['ipv4'] = list()
    dict_0['ipv6'] = list()
    dict_0['type'] = 'unknown'
    list_0 = list()
    str_1 = 'UP'
    list_0.append(str_1)
    list_0.append('BROADCAST')
    list_0.append('RUNNING')
    list_0.append('MULTICAST')
    dict_0['flags'] = list_0
    dict_

# Generated at 2022-06-24 22:47:53.334114
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Input parameters
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING'], 'macaddress': 'unknown', 'mtu': '33184', 'options': ['DEBUG']}}
    ip_type = 'ipv4'

    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-24 22:48:03.536073
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    network_0 = GenericBsdIfconfigNetwork()

# Generated at 2022-06-24 22:48:10.824423
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    if os.path.isfile('data/ifconfig.qemu'):
        with open('data/ifconfig.qemu', 'r') as f_0:
            # var_0 is bool
            var_0 = False
            generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(var_0)

            # var_1 is str
            var_1 = f_0.read()
            interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info(var_1)

            assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING']
            assert interfaces['lo0']['ipv4'][0]['netmask'] == '255.255.255.255'

# Generated at 2022-06-24 22:48:15.179104
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ifconfig_network_list = []
    path = "./"
    ifconfig_dict = {}
    ifconfig_network_list = sys_ifconfig_list()
    ifconfig_dict = ifconfig_list_to_dict(ifconfig_network_list)
    merged_ifconfig_list = []
    merged_ifconfig_list = merge_multiple_ifconfig_dict(ifconfig_dict)
    merge_interfacename_to_address_list(merged_ifconfig_list)
    print(merged_ifconfig_list)


# Generated at 2022-06-24 22:48:21.970461
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = {'em0': {'macaddress': '00:11:22:33:44:55'}, 'em1': {'macaddress': '00:11:22:33:44:66'}}
    generic_bsd_ifconfig_network_0.detect_type_media(var_0)


# Generated at 2022-06-24 22:48:31.423637
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    print("Test: detect_type_media")
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(False)

# Generated at 2022-06-24 22:48:41.561831
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    
    # Create instance of class GenericBsdIfconfigNetwork
    # Test case parameters
    # Instance of class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(False)

    param_0 = generic_bsd_ifconfig_network_1


    # Call method get_interfaces_info with args (param_0)
    result_0 = param_0.get_interfaces_info(None, None)

    # check for expected results
    assert type(result_0) is tuple, 'return type: ' + str(type(result_0))
    assert len(result_0) == 2, 'return length: ' + str(len(result_0))

# Generated at 2022-06-24 22:48:46.949661
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = generic_bsd_ifconfig_network_0.populate()

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_populate()
    test_case_0()

# Generated at 2022-06-24 22:49:19.104954
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bool_0 = True
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bool_0)


# Generated at 2022-06-24 22:49:30.922788
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)

    words_0 = ['inet', '10.0.0.1', 'netmask', '0xffffff00', 'broadcast', '10.0.0.255']
    current_if_0 = {'ipv4':[]}
    ips_0 = {'all_ipv4_addresses': []}

    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)

    address_0 = current_if_0['ipv4'][0]

    assert address_0['address'] == '10.0.0.1'

# Generated at 2022-06-24 22:49:37.336679
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    generic_bsd_ifconfig_network_0.module = AnsibleModule(argument_spec=dict())
    list_0 = ["fe80::1%lo0", "prefixlen", "64", "scopeid", "0x2"]
    list_1 = []
    dict_0 = {'address': "fe80::1%lo0", 'prefix': "64", 'scope': "0x2"}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_3['ipv6'] = []
    dict_3['ipv6'].append(dict_0)
    dict_4 = {}
    dict_5 = {}

# Generated at 2022-06-24 22:49:45.130196
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print("test_GenericBsdIfconfigNetwork_get_interfaces_info")
    stderr = ModuleStub(return_value=b"ifconfig: en0: error fetching interface information: Device not configured")

# Generated at 2022-06-24 22:49:53.771326
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test with valid parameters
    bool_0 = False
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    i1 = {'media':'Ethernet', 'type': 'unknown'}
    i2 = {'media':'Token Ring', 'type': 'unknown'}
    interfaces = {'en0': i1, 'en1': i2}
    result = generic_bsd_ifconfig_network_0.detect_type_media(interfaces)
    assert result == {'en0': {'media': 'Ethernet', 'type': 'ether'}, 'en1': {'media': 'Token Ring', 'type': 'unknown'}}


# Generated at 2022-06-24 22:50:03.962778
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    cmd_0 = 'ifconfig -a'
    cmd_1 = 'route -n get -inet6 default'
    cmd_2 = 'route -n get default'
    cmd_3 = 'route -n get -inet6 -inet default'
    cmd_4 = 'route -n get -inet default'
    # Define parameters for method get_default_interfaces
    ifconfig_path = cmd_0
    Route_path = cmd_1
    # Call method get_default_interfaces of class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bool_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(Route_path)
    # Define parameters for method get_default_interfaces
    ifconfig_path