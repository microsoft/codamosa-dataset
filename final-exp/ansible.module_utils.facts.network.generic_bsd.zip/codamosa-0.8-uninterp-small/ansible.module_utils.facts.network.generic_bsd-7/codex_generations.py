

# Generated at 2022-06-24 22:41:02.247114
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = [0, 'addr::1', 'prefixlen', 128, 'scopeid', 0x11]
    current_if_0 = {0: {0: 0}, 'ipv6': [0]}
    ips_0 = {0: [0]}
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:41:12.634973
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    route_path_0 = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
    str_0 = 'route -n get default'
    str_1 = 'route -n get -inet6 default'
    rc_0, out_0, err_0 = generic_bsd_ifconfig_network_0.module.run_command([route_path_0, '-n', 'get', 'default'])
    rc_1, out_1, err_1 = generic_bsd_ifconfig_network_0.module.run_command([route_path_0, '-n', 'get', '-inet6', 'default'])

# Generated at 2022-06-24 22:41:21.665794
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # Test argument passing
    class TestGenericBsdIfconfigNetwork:
        def __init__(self):
            pass

        def get_bin_path(self, name):
            return None

        def run_command(self, args):
            with open(args[1]) as f:
                out = f.read()
            return 0, out, None

    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(mode='w', delete=False)
    tmpfile.write('test')
    module = TestGenericBsdIfconfigNetwork()
    network_test = GenericBsdIfconfigNetwork(module)
    network_test.get_interfaces_info(tmpfile.name, tmpfile.name)
    tmpfile.close()
    import os
    os.remove(tmpfile.name)


# Generated at 2022-06-24 22:41:33.356522
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
        net_0 = {'interface': 'lo0', 'type': 'loopback'}
        int_0 = {'lo0': {'device': 'lo0', 'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255', 'network': '127.0.0.0'}], 'ipv6': [{'address': '::1', 'prefix': '128', 'scope': '0x10'}, {'address': 'fe80::1%lo0', 'prefix': '64', 'scope': '0x1'}], 'type': 'loopback', 'macaddress': 'unknown'}}
        generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
       

# Generated at 2022-06-24 22:41:44.738949
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    collected_facts_0 = dict()
    collected_facts_0['ansible_os_family'] = 'BSD'
    collected_facts_0['ansible_system'] = 'OpenBSD'
    collected_facts_0['ansible_lsb'] = dict()
    collected_facts_0['ansible_lsb']['version'] = dict()
    collected_facts_0['ansible_lsb']['version']['major'] = 7
    collected_facts_0['ansible_lsb']['version']['full'] = '7.1'
    collected_facts_0['ansible_lsb']['version']['minor'] = 1
    collected_facts_

# Generated at 2022-06-24 22:41:52.301031
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = "ifconfig"
    str_1 = ""
    assert generic_bsd_ifconfig_network_0.get_interfaces_info(str_0, str_1) == (None, None)


# Generated at 2022-06-24 22:42:00.163332
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    line0 = ['lo0', 'inet6', '::1', 'prefixlen', '128', '0x1', '0x2', '0x3', '0x4', '0x5', '0x6', '0x7']
    line1 = ['lo0', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    line2 = ['lo0', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', '0x1', '0x2', '0x3', '0x4', '0x5', '0x6', '0x7']

# Generated at 2022-06-24 22:42:03.485188
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    for fake_iface in generic_bsd_ifconfig_network_0.interfaces:
        generic_bsd_ifconfig_network_0.detect_type_media(fake_iface)


# Generated at 2022-06-24 22:42:14.472150
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    collected_facts_0 = {'ipv4': {'address': '0.0.0.0', 'broadcast': '255.255.255.255', 'netmask': '0.0.0.0'}, 'ipv6': {}}
    collected_facts_get_0 = collected_facts_0.get
    generic_bsd_ifconfig_network_0.collected_facts = collected_facts_0
    testValue_0 = generic_bsd_ifconfig_network_0.populate()
    int_1 = getattr(generic_bsd_ifconfig_network_0.module, 'run_command')

# Generated at 2022-06-24 22:42:19.530774
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_case_0()



# Generated at 2022-06-24 22:42:41.819901
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    line = "inet 192.168.1.1 netmask 0xffff0000 broadcast 192.168.255.255"
    words = line.split()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    expected_output = {
        'address': '192.168.1.1',
        'netmask': '255.255.0.0',
        'network': '192.168.0.0',
        'broadcast': '192.168.255.255'
    }

# Generated at 2022-06-24 22:42:46.877091
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000', 'group', 'default']
    current_if = dict()
    ips = dict()
    result = generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)
    assert(result == None)


# Generated at 2022-06-24 22:42:50.249077
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)


# Generated at 2022-06-24 22:42:55.378811
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(int_0)
    try:
        generic_bsd_ifconfig_network_1.populate()
    except Exception as e:
        msg = 'An exception has occurred in the populate method of class GenericBsdIfconfigNetwork'
        raise Exception(msg, e)


# Generated at 2022-06-24 22:42:59.780945
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    int_0 = 0
    words = {"127.0.0.1", "netmask", "0xff000000"}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    assert generic_bsd_ifconfig_network_0.parse_inet_line(words,"current_if", "ips") == None


# Generated at 2022-06-24 22:43:09.154005
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    words_0 = ['en0:', 'flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    current_if_0 = generic_bsd_ifconfig_network_0.parse_interface_line(words_0)

    assert current_if_0['device'] == 'en0'
    assert current_if_0['flags'] == ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if_0['metric'] == '0'
    assert current_if_0['mtu']

# Generated at 2022-06-24 22:43:13.899371
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(0)
    collected_facts = None

# Generated at 2022-06-24 22:43:19.614789
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    option_string = '<LOOPBACK>'
    expected = ['LOOPBACK']
    actual = GenericBsdIfconfigNetwork.get_options(option_string)
    assert expected == actual, 'Result  : %s\nExpected: %s' % (str(actual), str(expected))
    option_string = '<LOOPBACK,RUNNING,MULTICAST>'
    expected = ['LOOPBACK', 'RUNNING', 'MULTICAST']
    actual = GenericBsdIfconfigNetwork.get_options(option_string)
    assert expected == actual, 'Result  : %s\nExpected: %s' % (str(actual), str(expected))
    option_string = '<LOOPBACK,RUNNING>'
    expected = ['LOOPBACK', 'RUNNING']
    actual = Generic

# Generated at 2022-06-24 22:43:27.976122
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    route_path_0 = '/sbin/route'
    ifconfig_path_0 = '/sbin/ifconfig'
    # Unit test for the fact that this method is not implemented.
    with pytest.raises(NotImplementedError):
        x_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)


# Generated at 2022-06-24 22:43:39.167361
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ensure_dir('/etc/ansible')
    write_file('/etc/ansible/facts.d/test_GenericBsdIfconfigNetwork_get_interfaces_info.fact', '{}')

# Generated at 2022-06-24 22:43:55.762820
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_1 = None
    str_2 = None
    str_3 = None
    with open('/tmp/ansible_GenericBsdIfconfigNetwork_get_interfaces_info.txt', 'a') as f_0:
        f_0.write(generic_bsd_ifconfig_network_0.get_interfaces_info(str_1, str_2, str_3))


# Generated at 2022-06-24 22:44:05.757691
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print('Test method get_default_interfaces')
    prepare_mock_data()
    prepare_mock_data2()
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    route_path_0 = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
    generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    if (sys.platform == 'darwin'):
        command_0 = dict(v4=[route_path_0, '-n', 'get', 'default'], v6=[route_path_0, '-n', 'get', '-inet6', 'default'])

# Generated at 2022-06-24 22:44:10.686782
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_input_0 = ['inet', '127.0.0.1']
    test_input_1 = ['inet', '192.168.2.3', 'netmask', '0xffffff00']
    test_input_2 = ['inet', '172.28.0.1', 'netmask', '255.255.0.0']
    test_input_3 = ['inet', '172.28.0.1', 'netmask', '255.255.255.0', 'broadcast', '172.28.0.255']

    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    address = {}
    ips = {}

# Generated at 2022-06-24 22:44:20.932977
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    current_if = {'device': 'dummy_if'}
    ips = {}
    current_if['address'] = {'ipv4': []}
    generic_bsd_ifconfig_network_0.parse_inet_line(['inet', '10.3.3.3', 'netmask 0xffffff00', 'broadcast', '10.3.3.255'], current_if, ips)
    # print(ips)
    if ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}:
        print("Test case passed.")
    else:
        print("Test case failed.")


# Generated at 2022-06-24 22:44:33.227336
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    str_0 = '!io'
    list_0 = [str_0, 'lo2', '<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384']
    dict_0 = {'device': 'lo2', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'macaddress': 'unknown', 'metric': '0', 'mtu': '16384'}
    dict_1 = generic_bsd_ifconfig_network_0.parse_interface_line(list_0)
   

# Generated at 2022-06-24 22:44:35.265558
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)


# Generated at 2022-06-24 22:44:43.809711
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ae = get_assert_equal()
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_1 = []
    words_1.append('inet6')
    words_1.append('fe80::209:cbff:fe10:9c6b%em0')
    words_1.append('prefixlen')
    words_1.append('64')
    words_1.append('scopeid')
    words_1.append('0x1')
    current_if_2 = dict()
    current_if_2['device'] = 'em0'
    ips_3 = dict()
    ips_3['all_ipv4_addresses'] = []
    ips_3['all_ipv6_addresses']

# Generated at 2022-06-24 22:44:49.190099
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print('Executing test_GenericBsdIfconfigNetwork_get_default_interfaces...')
    # Test case data
    ifconfig_path = '/sbin/ifconfig'
    # Expected results
    expected_default_ipv4 = {'interface': 'en0', 'address': 'fe80:0:0:0:20c:29ff:fe5d:7d1c%en0', 'gateway': 'link#5'}
    expected_default_ipv6 = {}

    # Perform the test
    default_ipv4, default_ipv6 = GenericBsdIfconfigNetwork(ifconfig_path).get_default_interfaces()

    # Verify the results
    assert default_ipv4 == expected_default_ipv4

# Generated at 2022-06-24 22:44:59.524859
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Configure parameters and expected results
    option_string_0 = '<LOOPBACK,MULTICAST>'
    get_options_expected_0 = ['LOOPBACK', 'MULTICAST']

    # Perform the test
    get_options_actual_0 = GenericBsdIfconfigNetwork.get_options(option_string_0)

    #verify results

# Generated at 2022-06-24 22:45:10.331480
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    interface_1 = {"eth0": {"device": "eth0", "ipv4": [], "ipv6": [], "type": "loopback", "flags": ["UP", "BROADCAST", "RUNNING", "MULTICAST"], "metric": 0, "mtu": 1500, "media": "Ethernet 10Gbase-SR", "media_select": "Auto", "media_type": "10Gbase-SR", "media_options": ["FDX", "HDX", "AUTO"], "status": "active", "macaddress": "00:50:56:8d:cc:1b", "options": ["AUTOCONFIG"]}}
    interfaces = interface_1

# Generated at 2022-06-24 22:45:36.031337
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64']
    current_if = {'type': 'loopback',
                  'ipv4': [dict(address='127.0.0.1',
                                broadcast='255.0.0.0',
                                netmask='255.0.0.0')],
                  'device': 'lo0'}
    ips = dict(all_ipv4_addresses=[u'7.7.7.7'], all_ipv6_addresses=[])
    expected_ipv6 = [dict(address='fe80::1%lo0', prefix='64')]
    expected_ips_v6 = [u'fe80::1%lo0']

    int_0 = 0

# Generated at 2022-06-24 22:45:37.943243
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)


# Generated at 2022-06-24 22:45:47.607626
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:45:57.712061
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test case to run with -vvvv
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    ifconfig_path_0 = 'ifconfig'
    ifconfig_options_0 = '-a'
    interfaces_0, ips_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)
    assert(interfaces_0 == {})
    assert(ips_0 == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-24 22:46:02.784385
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    words = [u'fe80::1%lo0', u'prefixlen', u'64', u'', u'scopeid', u'0x2']
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)
    for iface in interfaces:
        for w in words:
            generic_bsd_ifconfig_network_0.parse_inet6_line(w, interfaces[iface], ips)



# Generated at 2022-06-24 22:46:10.389788
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    cur_if = {'ipv6': []} # ensure this is setup
    ips = {}

    w = ['fe80::1%lo0', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', '', '']
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(0)
    generic_bsd_ifconfig_network_0.parse_inet6_line(w, cur_if, ips)
    #print(cur_if['ipv6'])


# Generated at 2022-06-24 22:46:19.765169
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:46:26.067511
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    generic_bsd_ifconfig_network_0._module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    str_0 = 'route'
    with patch.object(generic_bsd_ifconfig_network_0.module, 'get_bin_path', return_value=str_0):
        route_path_0 = generic_bsd_ifconfig_network_0.module.get_bin_path('route')
        str_1 = '-n'
        str_2 = 'get'
        str_3 = 'default'

# Generated at 2022-06-24 22:46:38.251477
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    print(__name__, __file__)

    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    address_0 = {'address': '127.0.0.1'}
    words_0 = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if_0 = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    ips_0 = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:46:47.822737
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print("\n\n--- Test case ---")
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_0 = ['inet0', '10.160.9.156', 'netmask', '0xffff0000', 'broadcast', '10.160.255.255']
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0)
    print("\nCurrent interface: ")
    print(current_if_0)
    print("\nIPs: ")
    print(ips_0)


# Generated at 2022-06-24 22:47:02.420288
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    expected = generic_bsd_ifconfig_network_0.populate()
    # Testing the method populate of class GenericBsdIfconfigNetwork

    assert isinstance(expected, dict)


# Generated at 2022-06-24 22:47:13.262249
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    words_1 = ["inet6", "fe80::21b:77ff:fe23:b5c5%em0", "prefixlen", "64", "scopeid", "0x2"]
    current_if_2 = {"ipv4": [], "device": "em0", "ipv6": [], "type": "unknown", "flags": []}
    ips_3 = {"all_ipv4_addresses": [], "all_ipv6_addresses": []}
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_1, current_if_2, ips_3)

# Generated at 2022-06-24 22:47:24.512262
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:47:28.904903
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    assert isinstance(generic_bsd_ifconfig_network_0, GenericBsdIfconfigNetwork)


# Generated at 2022-06-24 22:47:39.658571
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    # Test with key 'gateway' doesn't exist in dict defaults_0.
    # Expected result: key 'gateway' doesn't exist in dict defaults_0.
    defaults_0 = {}

# Generated at 2022-06-24 22:47:48.811969
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    current_if = {'device': 'eth0'}
    ips = {}

    words = ['media:', 'Ethernet', '10Gbase-SR', '(10Gbps,', 'short', 'reach,', 'SFP+)', '<FULL-DUPLEX>', 'media',
             'type', 'is', '10Gbase-SR', 'status:', 'active']
    generic_bsd_ifconfig_network_0.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Ethernet'


# Generated at 2022-06-24 22:47:54.113538
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    # test default case
    # assert generic_bsd_ifconfig_network_0.populate() is ...
    # test case 1


# main function
if __name__ == '__main__':
    test_case_0()
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:48:04.921537
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    assert (generic_bsd_ifconfig_network_0.platform == 'Generic_BSD_Ifconfig')
    
    # Collected facts

    # Call method
    interfaces, ips = generic_bsd_ifconfig_network_0.get_interfaces_info()
    assert (interfaces[0]) == 'bridge_member'
    assert (interfaces[1]) == 'en0'
    assert (interfaces[2]) == 'en1'
    assert (interfaces[3]) == 'en2'
    assert (interfaces[4]) == 'en3'
    assert (interfaces[5]) == 'en4'
    assert (interfaces[6]) == 'en5'

# Generated at 2022-06-24 22:48:08.073436
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    collected_facts = 0

    var_0 = generic_bsd_ifconfig_network_0.populate(collected_facts)


# Generated at 2022-06-24 22:48:12.760576
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_1 = 1
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(int_1)
    argument_0 = None
    method_name = GenericBsdIfconfigNetwork.get_interfaces_info.__name__
    if method_name == "<lambda>":
        method = GenericBsdIfconfigNetwork.get_interfaces_info(generic_bsd_ifconfig_network_1, argument_0)
        assert isinstance(method, list)


# Generated at 2022-06-24 22:48:26.035762
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    generic_bsd_ifconfig_network_0.populate()

# ---------------------------------------------------------------------

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-24 22:48:33.977644
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)

    # Method: merge_default_interface(self, defaults, interfaces, ip_type)
    # Parameter: defaults (defaults)
    # Parameter: interfaces (interfaces)
    # Parameter: ip_type (ip_type)

    # Example 1:
    defaults_0 = {}
    interfaces_0 = {}
    ip_type_0 = "ip_type_0"
    generic_bsd_ifconfig_network_0.merge_default_interface(defaults_0, interfaces_0, ip_type_0)

    # Example 2:
    defaults_1 = {}
    interfaces_1 = {"interfaces_1_0": {}}

# Generated at 2022-06-24 22:48:44.228711
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    with pytest.raises(TypeError) as excinfo:
        GenericBsdIfconfigNetwork.parse_inet_line(None, None, None)
    assert "argument 'words' (pos 2): <class 'NoneType'> given" in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        GenericBsdIfconfigNetwork.parse_inet_line(None, None, None)
    assert "argument 'current_if' (pos 3): <class 'NoneType'> given" in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        GenericBsdIfconfigNetwork.parse_inet_line(None, None, None)
    assert "argument 'ips' (pos 4): <class 'NoneType'> given" in str(excinfo.value)
    test

# Generated at 2022-06-24 22:48:45.158590
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_method_0(GenericBsdIfconfigNetwork)


# Generated at 2022-06-24 22:48:50.749560
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    result_0 = generic_bsd_ifconfig_network_0.populate(  )
    assert result_0


# Generated at 2022-06-24 22:49:02.058069
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    interfaces = ({"en1": {"device": "en1", "ipv4": [], "ipv6": [], "type": "unknown", "flags": ["UP", "BROADCAST", "SMART", "RUNNING", "SIMPLEX", "MULTICAST"], "metric": "0", "mtu": "1500", "macaddress": "68:bc:0c:0e:3f:3d", "status": "active", "media": "none", "media_select": "autoselect", "media_type": "none", "media_options": ["none"]}})
    interfaces = generic_bsd_ifconfig_network_0.detect_type_media(interfaces)

# Generated at 2022-06-24 22:49:10.061891
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    int_0 = 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(int_0)
    ifconfig_path_0 = 'ifconfig_path'
    ifconfig_options_0 = 'ifconfig_options'
    interfaces_0, ips_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)


# Generated at 2022-06-24 22:49:19.125057
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    rc, out, err = module.run_command([ifconfig_path])
    assert rc == 0, "fail to run {0}".format(ifconfig_path)
    interfaces, ips = GenericBsdIfconfigNetwork(0).get_interfaces_info(ifconfig_path)
    assert isinstance(interfaces, dict), "interfaces should be a dictionary"
    assert isinstance(ips, dict), "ips should be a dictionary"
    assert len(interfaces) >= 1, "interfaces should not be empty"
    assert len(ips) >= 1, "ips should not be empty"
    # loopback interfaces are not included in 'interfaces' and 'ips'
    for iface in interfaces:
        assert iface not in [u'lo0'], "Interface '{0}' is not expected".format(iface)

# Generated at 2022-06-24 22:49:24.755785
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    print("\n*** Test_case_0: GenericBsdIfconfigNetwork::merge_default_interface() ***")
    test_case_0()


# Generated at 2022-06-24 22:49:29.099555
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    print('Testing get_options')
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(0)

    option_string = '<PRUNING,COMPRESSTX>'
    output = generic_bsd_ifconfig_network_0.get_options(option_string)
    print('output:', output)


# Generated at 2022-06-24 22:49:44.168018
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-24 22:49:44.928503
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 22:49:54.611351
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:50:02.343874
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    iface_0 = {}
    iface_1 = {}
    iface_2 = {}
    iface_3 = {}
    iface_4 = {}
    iface_5 = {}
    iface_6 = {}
    iface_7 = {}
    iface_8 = {}
    iface_9 = {}
    iface_10 = {}
    iface_11 = {}
    iface_12 = {}
    iface_13 = {}
    iface_14 = {}
    iface_15 = {}
    iface_16 = {}
    iface_17 = {}
    iface_18 = {}
    iface_19 = {}
    iface_20 = {}
    iface_21 = {}
    iface_22 = {}
    iface_23 = {}
    iface_24 = {}