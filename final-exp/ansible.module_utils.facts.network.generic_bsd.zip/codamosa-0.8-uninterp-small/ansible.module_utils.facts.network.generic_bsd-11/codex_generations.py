

# Generated at 2022-06-24 22:40:37.733090
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    str_0 = 'tIGo7VxIy8'
    GenericBsdIfconfigNetwork_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['tun', '0x5c9254d']
    current_if_0 = {}
    ips_0 = {}
    GenericBsdIfconfigNetwork_0.parse_inet6_line(words_0, current_if_0, ips_0)
    assert len(current_if_0['ipv6']) > 0


# Generated at 2022-06-24 22:40:46.603255
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'S07L*JJBJm'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    route_path_0 = 'uE#(X!7V;'
    return_value_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    assert return_value_0 == ({}, {})
    assert len(return_value_0) == 2
    assert len(return_value_0[0]) == 0
    assert len(return_value_0[1]) == 0


# Generated at 2022-06-24 22:40:55.971718
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    This test creates a suite of test cases for get_interfaces_info.
    """

    # Create a test case for each piece of data for the data-driven test

    # Create a data-driven test case for each parameter

    data_0 = ['ifconfig -a' ]
    data_1 = ['/sbin/ifconfig -a' ]
    data_2 = ['ifconfig -a' ]
    data_3 = ['ifconfig -a' ]

    # Create a data-driven test case for each platform

    def test_GenericBsdIfconfigNetwork_get_interfaces_info__Generic_BSD_Ifconfig(str_0):
        process = subprocess.Popen(str_0, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        process.wait()
        return

# Generated at 2022-06-24 22:41:02.328604
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    str_0 = 'S07L*JJBJm'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    route_path_0 = route_path_0 = '/Library/Application Support/zScreen/3rdParty/Wireshark.app/Contents/MacOS/route'
    tup_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    assert tup_0[0]['gateway'] == '192.168.1.1'
    assert tup_0[0]['interface'] == 'en0'
    


# Generated at 2022-06-24 22:41:11.246110
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    str_0 = 'a0cQ'
    words_0 = ['a0cQ', 'RJOP', 'p5mC', 'ROyh', 'mRnC', 'bJZm']
    current_if_0 = {'device': 'a0cQ'}
    ips_0 = dict(
        all_ipv4_addresses=[],
    )
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    assert generic_bsd_ifconfig_network_0.parse_inet_line(words_0, current_if_0, ips_0) == None



# Generated at 2022-06-24 22:41:12.995742
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # AssertionError: Expected False, but got True
    # assert 0 == 1
    pass


# Generated at 2022-06-24 22:41:17.024797
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    str_0 = 'S07L*JJBJm'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    words_0 = ['media:', 'Ethernet', '10baseT/UTP', '(<unknown type>)' ]
    current_if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_media_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:41:25.686813
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    str_0 = 'S07L*JJBJm'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    network_facts = {}
    ifconfig_path = generic_bsd_ifconfig_network_0.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return network_facts

    route_path = generic_bsd_ifconfig_network_0.get_bin_path('route')

    if route_path is None:
        return network_facts

    default_ipv4, default_ipv6 = generic_bsd_ifconfig_network_0.get_default_interfaces(route_path)

# Generated at 2022-06-24 22:41:32.377191
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    str_0 = 'S07L*JJBJm'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(str_0)
    interfaces = {}
    interfaces.setdefault(str_0, None)
    generic_bsd_ifconfig_network_0.detect_type_media(interfaces)


# Generated at 2022-06-24 22:41:43.263796
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # IPv6 with cidr prefixlen
    words = ['inet6', 'fe80::f816:3eff:fe59:a5ef%lo0', 'prefixlen', '64', 'scopeid', '0x2', 'inet6', 'fe80::f816:3eff:fe59:a5ef%lo0', 'prefixlen', '64', 'scopeid', '0x8']
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ifconfig = GenericBsdIfconfigNetwork('S07L*JJBJm')
    ifconfig.parse_inet6_line(words, current_if, ips)


# Generated at 2022-06-24 22:42:01.996404
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = b'/sbin/ifconfig'
    ifconfig_options = b'-a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc')
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path, ifconfig_options)


# Generated at 2022-06-24 22:42:13.238501
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    bytes_1 = b'\xad\xbc\x83\xf2\xc5\x85\xe6\xae\x0b\x17\xe2\x8f\xac\xc3\xae"'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(bytes_1)
    interfaces_0, ips_0 = generic_bsd_ifconfig_network_0.get_interfaces_

# Generated at 2022-06-24 22:42:18.589630
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_2 = generic_bsd_ifconfig_network_0.get_interfaces_info(bytes_0)


# Generated at 2022-06-24 22:42:27.663522
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    bytes_1 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(bytes_1)


# Generated at 2022-06-24 22:42:38.480958
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    # Test with argument passed
    var_0 = generic_bsd_ifconfig_network_0.parse_inet_line(bytes_0,
                                                           bytes_0,
                                                           [])
    # Test with argument not passed
    # TODO: Create a "this is not implemented" exception and throw it here
    # var_1 = generic_bsd_ifconfig_network_0.parse_inet_line()


# Generated at 2022-06-24 22:42:43.430789
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)



# Generated at 2022-06-24 22:42:44.695747
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    # Setup test case
    test_case_0()


# Generated at 2022-06-24 22:42:56.369340
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    bytes_1 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(bytes_1)
    var_0 = generic_bsd_ifconfig_network_1.get_interfaces_info(bytes_1, bytes_0)


# Generated at 2022-06-24 22:43:04.058211
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)



# Generated at 2022-06-24 22:43:09.067031
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():

    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_options(bytes_0)

    # This method is expected to raise a TypeError when the supplied 'option_string'
    # parameter is of type 'str'.
    # That is why we pass the following var to check for the exception.
    str_0 = str()
    with pytest.raises(TypeError):
        generic_bsd_ifconfig_network_0.get_options(str_0)


# Generated at 2022-06-24 22:43:53.411089
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    bytes_1 = b'\x10'
    bytes_2 = b'\x00'
    dict_0 = {'bytes': bytes_0, 'list': list_0, 'str': '', 'tuple': tuple_0}
    dict_1 = {'bytes': bytes_1, 'list': list_0, 'str': '', 'tuple': tuple_0}
    dict_2 = {'bytes': bytes_2, 'list': list_0, 'str': '', 'tuple': tuple_0}
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_

# Generated at 2022-06-24 22:44:02.074994
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    words_0 = ['lladdr', 'a']
    current_if_0 = {}
    current_if_0['ipv4'] = []
    words_1 = ['inet', '192.168.1.101']
    current_if_1 = {}
    ips_0 = {'all_ipv4_addresses': []}
    GenericBsdIfconfigNetwork.parse_inet_line(words_0, current_if_0, ips_0)
    GenericBsdIfconfigNetwork.parse_inet_line(words_1, current_if_1, ips_0)


# Generated at 2022-06-24 22:44:07.986703
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)
    assert var_0 == (None, None)



# Generated at 2022-06-24 22:44:14.308596
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)
    test_case_0()


# Generated at 2022-06-24 22:44:19.980381
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """
    Test for method detect_type_media.
    """
    media_0 = 'media: Ethernet autoselect (100baseTX <half-duplex>)'

# Generated at 2022-06-24 22:44:29.654615
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    bytes_1 = b'\xdf\x1c\xac\xc4\xbe\xab\xda\x83\xa1\x8fW\x17\x9f\xa7'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_1)
    assert True # tested as part of test_case_0


# Generated at 2022-06-24 22:44:39.606444
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'e\x00\x00\xf8\x00\x00\x80\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.merge_default_interface(bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-24 22:44:42.276413
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    generic_bsd_ifconfig_network_0.populate()


# Generated at 2022-06-24 22:44:46.411406
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    words_0 = []
    if_0 = {}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, if_0, ips_0)
    return None



# Generated at 2022-06-24 22:44:52.983230
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ifconfig_path_0 = b'bin/ifconfig'
    ifconfig_options_0 = b'-- -a'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(ifconfig_path_0)
    route_path_0 = b'bin/route'
    generic_bsd_ifconfig_network_0.get_default_interfaces(route_path_0)
    var_0 = generic_bsd_ifconfig_network_0.get_interfaces_info(ifconfig_path_0, ifconfig_options_0)


# Generated at 2022-06-24 22:45:15.303218
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bytes_0 = b"\x04\x00\x00\x00"
    bytes_1 = bytes_0
    int_0 = len(bytes_1)
    bytes_2 = b"\x00\x00\x00\x00"
    bytes_3 = bytes_2
    int_1 = len(bytes_3)
    bytes_4 = b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    bytes_5 = bytes_4
    int_2 = len(bytes_5)

# Generated at 2022-06-24 22:45:20.892836
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    dict_0 = dict()
    dict_0['default_ipv4'] = dict()
    dict_0['default_ipv6'] = dict()
    dict_0['default_ipv4']['interface'] = 'vlan1'
    dict_0['default_ipv6']['interface'] = 'vlan2'
    dict_0['vlan1'] = dict()
    dict_0['vlan1']['ipv4'] = list()
    dict_0['vlan1']['ipv4'].append(dict())

# Generated at 2022-06-24 22:45:30.443934
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test case 0
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)
    assert var_0 == ({}, {})
    # Test case 1
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork()
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces

# Generated at 2022-06-24 22:45:39.486930
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    words_0 = []
    current_if_0 = {}

# Generated at 2022-06-24 22:45:48.172530
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    words_0 = [b'\x1cF\x80\x97', b'\x0fe\x8e\xfe\xcd-uo^-\xbc']
    current_if_0=dict(device=b'\x1cF\x80\x97')
    ips_0=dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

# Generated at 2022-06-24 22:45:58.115466
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    option_string_0 = '<UP,LOOPBACK,RUNNING>'
    var_0 = generic_bsd_ifconfig_network_0.get_options(option_string_0)
    assert var_0 == ['UP', 'LOOPBACK', 'RUNNING'], 'var_0 is not equal to [UP, LOOPBACK, RUNNING].'


# Generated at 2022-06-24 22:46:07.192113
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    str_0 = 'unknown'
    str_1 = '\x06\x1a\x9c\x193\xab\x1f\t\x7f%\x8b\x1e\x9c'
    list_0 = [str_0, str_1, '\xc8\xde', 'dynamic']

# Generated at 2022-06-24 22:46:17.464130
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)

    # Test for function get_options
    # TODO: Write test for get_options
    #assert(False)

    bytes_0 = b' 9\xac\x8c\x00\x01'
    generic_bsd_ifconfig_network_0.get_interfaces_info(bytes_0)

    # Test for function merge_default_interface
    # TODO: Write test for merge_default_interface
    #assert(False)

    # Test for function populate
    # TODO: Write test for populate
    #assert(False)

   

# Generated at 2022-06-24 22:46:27.338897
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bytes_0 = b'\xcd\xbc\x1f\xcb\x80\x95\x0f\xe5\x98" \x83'
    bytes_1 = b'\x98\xbc\x15\x93\x8b\x9d\x0f`\xa7\x8f\x15\x80\x00c\x00\xb0\x0c\x00\x01\x10\x00\x01\x18\x00\x00\x01\x1c\x00\x00\x01\x01'
    bytes_2 = b'\x00\x8a\x00\x00'
    bytes_3 = b'\x00\x00'

# Generated at 2022-06-24 22:46:39.690663
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    list_of_bytes_0 = [b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc', b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc', b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc']

# Generated at 2022-06-24 22:47:19.256870
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:47:31.254254
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    bytes_1 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_1 = GenericBsdIfconfigNetwork(bytes_1)
    result_0 = generic_bsd_ifconfig_network_0.merge_default_interface(bytes_0, bytes_1, bytes_0)
    print(result_0)
    print(generic_bsd_ifconfig_network_1)


# Generated at 2022-06-24 22:47:40.782420
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\xa1\x99\x90\x1e(\x97\x95\x13\x00\xa1\x8e\x80\xe3\xe3\xcc{\xf8'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    var_0 = generic_bsd_ifconfig_network_0.get_default_interfaces(bytes_0)
    var_1 = generic_bsd_ifconfig_network_0.get_interfaces_info(bytes_0, '-a')
    generic_bsd_ifconfig_network_0.merge_default_interface(var_0, var_1, 'ipv6')


# Generated at 2022-06-24 22:47:48.549324
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    # bytes_1 = map(ord, "TESTING".encode("utf-8"))
    interfaces_0 = {"TESTING": {"media": "ether"}}
    var_0 = generic_bsd_ifconfig_network_0.detect_type_media(interfaces_0)
    assert var_0 == {"TESTING": {"media": "ether", "type": "ether"}}


# Generated at 2022-06-24 22:47:58.627628
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    bytes_1 = b'\xf0{\t\xbf\xaa\x8c\x1f$'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)

# Generated at 2022-06-24 22:48:07.172482
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    words_0 = [b'1', b'2', b'3', b'4', b'5', b'6', b'7']
    current_if_0 = {b'device': b'a', b'ipv4': [], b'ipv6': [], b'type': b'unknown'}
    ips_0 = {}
    generic_bsd_ifconfig_network_0.parse_inet6_line(words_0, current_if_0, ips_0)


# Generated at 2022-06-24 22:48:13.559971
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-24 22:48:21.273825
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b';<\xde\xf4\xab\x0f'
    bytes_1 = b'L\xd6\xaf\xb3&\x1d\xdc\xa2&\xf2\x92\x80'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    generic_bsd_ifconfig_network_0.merge_default_interface(bytes_0, bytes_1, bytes_0)


# Generated at 2022-06-24 22:48:30.229372
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    generic_bsd_ifconfig_network_0.get_interfaces_info(bytes_0)
    words, current_if, ips = bytes_0, bytes_0, bytes_0
    generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)
    var_0 = generic_bsd_ifconfig_network_0.parse_inet_line(words, current_if, ips)


# Generated at 2022-06-24 22:48:37.850396
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    bytes_0 = b'\x1cF\x80\x97\x0fe\x8e\xfe\xcd-uo^-\xbc'
    string_0 = 'yF'
    generic_bsd_ifconfig_network_0 = GenericBsdIfconfigNetwork(bytes_0)
    generic_bsd_ifconfig_network_0.parse_interface_line((string_0))
    var_0 = generic_bsd_ifconfig_network_0.parse_interface_line((string_0))



# Generated at 2022-06-24 22:49:44.808722
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    bytes_0 = b'\x12\x01\x00\xc0\xa8\x01\x00\t\x0e\xef\x00\x00\x08\x00\x45\x00'
    bytes_2 = b'\x11\x0b\x00\x00\xa1\x1b\x14\x00\x01\x11\x76\xe4\xc0\xa8\x01\xfe'
    bytes_3 = b'\x0b\x1b\x14\x00\x01\x11\x76\xe5\xc0\xa8\x01\xfe'

# Generated at 2022-06-24 22:49:49.772957
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(b'iftJ1^\xd4')
    var_1 = generic_bsd_ifconfig_network.get_default_interfaces(b'g\x95\x01\xcaQ')
    assert var_1 == (b'a\xa1\x06\x0c', b'\x8e/\x96\xba/')


# Generated at 2022-06-24 22:49:59.450967
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bytes_0 = b'\x9a\xfc,\xcbG\x8d\x1c\x1e\x01\xfc\xbb\x9d\xba\xc6\x00\xb8\x04\xd6\xbf6U'