

# Generated at 2022-06-17 00:43:49.868918
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a generic BSD ifconfig network object
    network = GenericBsdIfconfigNetwork(module)

    # Populate the network object
    network.populate()

    # Check the results
    assert network.facts['default_ipv4']['interface'] == 'lo0'
    assert network.facts['default_ipv4']['address'] == '127.0.0.1'
    assert network.facts['default_ipv4']['netmask'] == '255.0.0.0'
    assert network.facts['default_ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 00:44:02.046376
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test with a line containing a valid IPv6 address
    words = ['inet6', 'fe80::a00:27ff:fe5d:c0a5%bge0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )
    GenericBsdIfconfigNetwork.parse_inet6_line(GenericBsdIfconfigNetwork, words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::a00:27ff:fe5d:c0a5'
    assert current_if['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:44:12.234525
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a default interface
    route_path = 'route'
    route_command = [route_path, '-n', 'get', 'default']
    route_command_v6 = [route_path, '-n', 'get', '-inet6', 'default']
    route_command_output = '''
default: gateway: 192.168.1.1
        interface: en0
        local addr: 192.168.1.2
'''
    route_command_v6_output = '''
default: gateway: fe80::1%lo0
        interface: lo0
        if address: ::1
'''
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-17 00:44:24.159524
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a default route
    route_path = '/sbin/route'

# Generated at 2022-06-17 00:44:33.269722
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = GenericBsdIfconfigNetwork(module)

    # test with dotted quad netmask
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-17 00:44:44.217500
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a valid route command output
    route_path = '/sbin/route'

# Generated at 2022-06-17 00:44:54.041298
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test with empty defaults
    defaults = {}

# Generated at 2022-06-17 00:45:01.532868
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:45:14.463077
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns an IPv4 default route
    route_path = '/sbin/route'
    route_output = '''
default: gateway: 192.168.1.1
interface: en0
local addr: 192.168.1.2
'''
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    ipv4, ipv6 = network.get_default_interfaces(route_path)
    assert ipv4['interface'] == 'en0'
    assert ipv4['gateway'] == '192.168.1.1'
    assert ipv4['address'] == '192.168.1.2'
    assert ipv6 == {}

    # Test with a route command that returns an IPv6 default route

# Generated at 2022-06-17 00:45:22.025674
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with no default route
    route_path = '/sbin/route'
    route_output = '''
Routing tables

Internet:
Destination        Gateway            Flags      Netif Expire
default            link#1             UGS         en0
default            192.168.1.1        UGSc         en1
default            link#2             UGS         en2
default            link#3             UGS         en3
'''
    expected_v4 = {}
    expected_v6 = {}
    network = GenericBsdIfconfigNetwork()
    network.module = MagicMock()
    network.module.run_command.return_value = (0, route_output, '')
    v4, v6 = network.get_default_interfaces(route_path)
    assert v4 == expected_v4
    assert v6

# Generated at 2022-06-17 00:45:41.924930
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test with a valid output
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-17 00:45:51.454947
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # FreeBSD, DragonflyBSD, NetBSD, OpenBSD and macOS all implicitly add '-a'
    # when running the command 'ifconfig'.
    # Solaris must explicitly run the command 'ifconfig -a'.
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])

    for line in out.splitlines():

        if line:
            words = line.split()

            if words[0] == 'pass':
                continue

# Generated at 2022-06-17 00:46:01.042730
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a default interface
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default 192.168.1.1 UGS 0 8 en0', ''))
    network = GenericBsdIfconfigNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces('route')
    assert default_ipv4 == {'interface': 'en0', 'gateway': '192.168.1.1', 'address': '192.168.1.1'}
    assert default_ipv6 == {}

    # Test with a route command that returns no default interface
    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 00:46:09.427655
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test for method parse_inet6_line(self, words, current_if, ips)
    # of class GenericBsdIfconfigNetwork
    #
    # Test data
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    #
    # Test
    #
    network = GenericBsdIfconfigNetwork()
    network.parse_inet6_line(words, current_if, ips)
    #
    # Assert
    #

# Generated at 2022-06-17 00:46:18.920691
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Test with media line with media_select and media_type
    # media: Ethernet autoselect (1000baseT <full-duplex>)
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex>)' ]
    current_if = {}
    ips = {}
    network = GenericBsdIfconfigNetwork()
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']

    # Test with media line without media_select and media_type
    # media: Ethernet autoselect

# Generated at 2022-06-17 00:46:28.992236
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with route command output from FreeBSD
    route_path = 'route'

# Generated at 2022-06-17 00:46:40.475013
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-17 00:46:51.506621
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-17 00:47:02.404123
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test with a valid input
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-17 00:47:13.952782
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test with a valid output
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:47:29.759461
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)

    # test with netmask in hex
    words = ['lo0', 'inet', '127.0.0.1', '0xff000000', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-17 00:47:40.458617
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    # test with netmask in hex
    words = ['inet', '192.168.1.1', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '192.168.1.1'
    assert current_if['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:47:53.393082
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-17 00:48:05.137167
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test with no default interface
    defaults = {}
    interfaces = {'eth0': {'ipv4': [{'address': '192.168.1.1', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'}]}}
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == {}

    # Test with no matching interface
    defaults = {'interface': 'eth1'}
    interfaces = {'eth0': {'ipv4': [{'address': '192.168.1.1', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'}]}}

# Generated at 2022-06-17 00:48:11.471911
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)
    route_path = network.module.get_bin_path('route')
    if route_path is None:
        module.fail_json(msg='route command not found')
    default_ipv4, default_ipv6 = network.get_default_interfaces(route_path)
    module.exit_json(changed=False, default_ipv4=default_ipv4, default_ipv6=default_ipv6)


# Generated at 2022-06-17 00:48:23.612759
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test with a line containing a hex netmask
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    GenericBsdIfconfigNetwork.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'

# Generated at 2022-06-17 00:48:33.226283
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a default route
    route_path = 'route'

# Generated at 2022-06-17 00:48:45.004433
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Test with a string that has no options
    option_string = 'UP'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == []

    # Test with a string that has options
    option_string = 'UP,LOOPBACK,RUNNING,MULTICAST'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

    # Test with a string that has options but no brackets
    option_string = 'UP,LOOPBACK,RUNNING,MULTICAST'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

   

# Generated at 2022-06-17 00:48:51.748206
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test parse_inet6_line with a line containing a cidr style address
    # and a scopeid
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )
    network = GenericBsdIfconfigNetwork()
    network.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0x2'

# Generated at 2022-06-17 00:49:00.305334
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test with ethernet interface
    interfaces = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}}
    network = GenericBsdIfconfigNetwork()
    interfaces = network.detect_type_media(interfaces)
    assert interfaces['eth0']['type'] == 'ether'
    # Test with loopback interface
    interfaces = {'lo0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}}
    interfaces = network.detect_type_media(interfaces)
    assert interfaces['lo0']['type'] == 'loopback'
    # Test with unknown interface
    interfaces = {'eth1': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}}
    interfaces = network

# Generated at 2022-06-17 00:49:18.703288
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # Test 1: normal case
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-17 00:49:28.323550
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test with a line that has a prefix length
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )
    network = GenericBsdIfconfigNetwork()
    network.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0x2'

# Generated at 2022-06-17 00:49:40.570179
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test with no interface
    defaults = {'interface': 'lo0'}
    interfaces = {}
    ip_type = 'ipv4'
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == {'interface': 'lo0'}

    # Test with interface but no address
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address': '127.0.0.1'}]}}
    ip_type = 'ipv4'
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == {'interface': 'lo0', 'ipv4': [{'address': '127.0.0.1'}]}



# Generated at 2022-06-17 00:49:51.293715
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test with FreeBSD ifconfig output
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-17 00:49:59.538414
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()
    interfaces = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'}}
    result = network.detect_type_media(interfaces)
    assert result == {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)', 'type': 'ether'}}



# Generated at 2022-06-17 00:50:10.857673
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-17 00:50:17.513139
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == []
    assert current_if['status'] == 'active'
    assert ips == {}


# Generated at 2022-06-17 00:50:24.580329
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    ifconfig_path = module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        module.fail_json(msg='ifconfig not found')

    route_path = module.get_bin_path('route')
    if route_path is None:
        module.fail_json(msg='route not found')

    network_facts = GenericBsdIfconfigNetwork(module).populate()
    module.exit_json(ansible_facts=dict(network=network_facts))


# Generated at 2022-06-17 00:50:34.726281
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # get the basic mocks for the module
    mock_module = setup_mock_module(module)

    # get the basic mocks for the module running commands
    mock_run_commands = setup_mock_run_commands(module)

    # get the basic mocks for the module running commands
    mock_get_bin_path = setup_mock_get_bin_path(module)

    # get the mock_socket for the module
    mock_socket = setup_mock_socket(module)

    # get the mock_struct for the module
    mock_struct = setup_mock_struct(module)

    # get the mock_re for the module

# Generated at 2022-06-17 00:50:42.446891
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    network_module = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    network_module.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-17 00:51:08.476407
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:51:18.179684
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a valid IPv4 and IPv6 default route
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock(return_value=(0, 'default via 192.168.1.1 dev eth0\n', ''))
    test_module.run_command.side_effect = [(0, 'default via 192.168.1.1 dev eth0\n', ''), (0, 'default via fe80::1 dev eth0\n', '')]
    test_network = GenericBsdIfconfigNetwork(test_module)
    test_defaults = test_network.get_default_interfaces('/sbin/route')

# Generated at 2022-06-17 00:51:26.855669
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with a route command that returns a default interface
    route_path = '/sbin/route'
    route_command = [route_path, '-n', 'get', 'default']
    route_command_v6 = [route_path, '-n', 'get', '-inet6', 'default']
    rc, out, err = module.run_command(route_command)
    rc_v6, out_v6, err_v6 = module.run_command(route_command_v6)
    network = GenericBsdIfconfigNetwork()
    default_ipv4, default_ipv6 = network.get_default_interfaces(route_path)
    assert default_ipv4['interface'] == 'lo0'
    assert default_ipv6['interface'] == 'lo0'
    assert default_ipv

# Generated at 2022-06-17 00:51:36.666615
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST>') != ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'LOOPBACK']
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST>') != ['UP', 'BROADCAST', 'RUNNING']

# Generated at 2022-06-17 00:51:48.403973
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test with a valid interface
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.0.0.1', 'network': '127.0.0.0'}], 'ipv6': [{'address': '::1', 'prefix': '128', 'scope': '0x10'}]}}
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-17 00:51:59.768665
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:52:09.511373
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

# Generated at 2022-06-17 00:52:18.112755
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Test with a string with no options
    option_string = 'UP'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == []

    # Test with a string with one option
    option_string = '<UP>'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP']

    # Test with a string with multiple options
    option_string = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

    # Test with a string with multiple options and spaces

# Generated at 2022-06-17 00:52:28.666479
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    network = GenericBsdIfconfigNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['lo0']['device'] == 'lo0'
    assert interfaces['lo0']['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert interfaces['lo0']['mtu'] == '33184'
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-17 00:52:38.900990
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Test with a line that has no media options
    line = "media: Ethernet autoselect (none)"
    words = line.split()
    current_if = {}
    ips = {}
    GenericBsdIfconfigNetwork().parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert 'media_options' not in current_if

    # Test with a line that has media options
    line = "media: Ethernet autoselect (100baseTX full-duplex)"
    words = line.split()
    current_if = {}
    ips = {}