

# Generated at 2022-06-11 03:15:16.623261
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:15:28.515744
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # create a dummy module
    from ansible.module_utils.basic import AnsibleModule

    argv = ['ansible', 'test', '-m', 'Generic_BSD_Ifconfig']
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        bypass_checks=True,
    )
    module.run_command = MagicMock()

# Generated at 2022-06-11 03:15:37.832570
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # TODO: We should mock out run_command call in this test case
    # and make this test more robust.
    m = GenericBsdIfconfigNetwork()
    res = m.populate()
    assert 'interfaces' in res
    assert type(res['interfaces']) is list
    assert res['lo0']['macaddress'] in ['fe800000a0030a', 'fe800000a0030c']
    assert res['lo0']['mtu'] == '33184'
    assert res['lo0']['device'] == 'lo0'
    assert res['lo0']['flags']
    assert 'lladdr' not in res['lo0']
    assert 'media' not in res['lo0']
    assert res['lo0']['type'] == 'loopback'

# Generated at 2022-06-11 03:15:49.788669
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    m = GenericBsdIfconfigNetwork()
    defaults = dict()
    interfaces = dict()
    assert len(defaults.keys()) == 0
    assert len(interfaces.keys()) == 0
    m.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults.keys()) == 0
    assert len(interfaces.keys()) == 0
    defaults = dict(interface='lo0')
    interfaces = dict()
    m.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults.keys()) == 1
    assert len(interfaces.keys()) == 0
    interfaces = dict(lo0=dict())
    m.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults.keys()) == 1
   

# Generated at 2022-06-11 03:16:00.495029
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.exit_json = MagicMock()

    current = GenericBsdIfconfigNetwork(test_module)


# Generated at 2022-06-11 03:16:11.360343
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    ifconfig_path = module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        module.fail_json(msg="Cannot find ifconfig in bin paths")

    network = GenericBsdIfconfigNetwork(module)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    assert type(interfaces) == dict
    assert type(ips) == dict
    assert len(interfaces) >= 0
    assert type(ips['all_ipv4_addresses']) == list
    assert type(ips['all_ipv6_addresses']) == list

# Generated at 2022-06-11 03:16:23.747539
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork
    gen_ifconfig = GenericBsdIfconfigNetwork()

    option_string = 'biolinks<LOOPBACK,UP,LOWER_UP> mtu 8232'
    expected_output = ['LOOPBACK', 'UP', 'LOWER_UP']
    assert expected_output == gen_ifconfig.get_options(option_string)

    option_string = 'ether 00:00:00:00:00:00'
    expected_output = []
    assert expected_output == gen_ifconfig.get_options(option_string)

    option_string = '<OPTIONS>'
    expected_output = []
    assert expected_output == gen_ifconfig.get_options(option_string)



# Generated at 2022-06-11 03:16:30.063537
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Test if media line can be parsed correctly
    line = "media: Ethernet autoselect (none)"
    words = line.split()

    module = MagicMock()
    network_obj = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = {}

    network_obj.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(none)'
    assert current_if['media_options'] == []


# Generated at 2022-06-11 03:16:37.323382
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    word = "ether 10:20:30:40:50:60"
    current_if={}
    ips={}
    gen_ifconfig_netw = GenericBsdIfconfigNetwork()
    gen_ifconfig_netw.parse_ether_line(word.split(),current_if,ips)
    assert current_if['macaddress'] == '10:20:30:40:50:60'



# Generated at 2022-06-11 03:16:46.797189
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # create an instance of the class under test
    generic_bsd = GenericBsdIfconfigNetwork()
    media_line = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    interface_line = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    current_if = generic_bsd.parse_interface_line(interface_line)
    generic_bsd.parse_media_line(media_line, current_if, {})
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_select'] == 'autoselect'

# Unit test

# Generated at 2022-06-11 03:17:12.167702
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:14.704596
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    j = GenericBsdIfconfigNetwork()
    assert j.get_options('<foo,bar>') == ['foo', 'bar']
    assert j.get_options('<>') == []
    assert j.get_options('foo') == []



# Generated at 2022-06-11 03:17:21.735115
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    network = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:17:28.501227
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible.module_utils.network.generic.ifconfig.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    from collections import namedtuple
    from io import StringIO, BytesIO

    test_obj = GenericBsdIfconfigNetwork()
    test_obj.module = namedtuple("Module", "run_command get_bin_path")
    test_obj.module.run_command = lambda command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt=None, environ_update=None, umask=None, encoding=None: (0, '', '')
    test_obj.module.get_bin_path = lambda arg: arg

# Generated at 2022-06-11 03:17:40.655134
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # create a mock module
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    network = GenericBsdIfconfigNetwork(module)
    # create a network interface
    device = 'lo0'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = []
    if 'LOOPBACK' in current_if['flags']:
        current_if['type'] = 'loopback'
    current_if['macaddress'] = 'unknown'    # will be overwritten later
    current_if['metric'] = ''
    current_if['mtu'] = ''

# Generated at 2022-06-11 03:17:52.588343
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = 'ifconfig'
    fake_module = mock.MagicMock()

# Generated at 2022-06-11 03:18:04.665349
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Initialize the class
    network_obj = GenericBsdIfconfigNetwork()

    # The input argument

# Generated at 2022-06-11 03:18:13.268458
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    ifconfig = GenericBsdIfconfigNetwork(dict(module=dict()))
    assert ifconfig.get_options('') == []
    assert ifconfig.get_options('<>') == []
    assert ifconfig.get_options('<ONE>') == ['ONE']
    assert ifconfig.get_options('<ONE,TWO>') == ['ONE', 'TWO']
    assert ifconfig.get_options('<ONE,TWO,THREE>') == ['ONE', 'TWO', 'THREE']
    assert ifconfig.get_options('< ONE,TWO,THREE>') == []
    assert ifconfig.get_options('ONE,TWO,THREE>') == []
    assert ifconfig.get_options('ONE,TWO,THREE') == []

# Generated at 2022-06-11 03:18:24.718094
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
  network = GenericBsdIfconfigNetwork()
  ifconfig_path = "tests/unit/modules/network/data/ifconfig-openbsd-output.txt"
  with open(ifconfig_path, 'r', encoding='utf-8') as file_handle:
    out = file_handle.read()
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert len(interfaces) > 0
    assert 'lo0' in interfaces
    assert len(ips) > 0
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0

# Generated at 2022-06-11 03:18:36.286335
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    class ModuleStub:
        def get_bin_path(self, path):
            return True
        def run_command(self, path):
            return True
    module = ModuleStub()
    # test with an empty line
    line = []
    expected = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    network = GenericBsdIfconfigNetwork(module)
    result = network.parse_interface_line(line)
    assert expected == result
    # test with a single word
    line = ['wlan']
    expected = {'device': 'wlan', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    result = network.parse_interface_line(line)
    assert expected == result
    # test with a single

# Generated at 2022-06-11 03:19:00.681098
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    obj = GenericBsdIfconfigNetwork(module)
    ifconfig_path = obj.module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        raise SkipTest("ifconfig not found")

    iface = "lo0"

# Generated at 2022-06-11 03:19:11.700354
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    net_ifc_obj = GenericBsdIfconfigNetwork()
    words = ['ether', 'aa:bb:cc:dd:ee:ff']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    current_if['macaddress'] = 'unknown'
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    net_ifc_obj.parse_ether_line(
        words=words,
        current_if=current_if,
        ips=ips
    )
    assert current_if['macaddress'] == 'aa:bb:cc:dd:ee:ff'
    assert current_if['type'] == 'ether'


# Unit

# Generated at 2022-06-11 03:19:23.197326
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import sys, os
    import tempfile
    import subprocess
    import platform
    my_os = platform.system()
    my_platform = platform.system()+" "+platform.release()
    argv = ["GenericBsdIfconfigNetwork", "get_default_interfaces"]
    net = GenericBsdIfconfigNetwork()
    #
    # Check the IOSXE version is supported
    #
    if my_os != "Linux":
        print("SKIPPING TEST: The test requires a linux environment.")
        sys.exit()
    if my_platform != "Linux 3.2.0-4-amd64":
        print("SKIPPING TEST: The test requires a Debian 7.0 (wheezy) environment.")
        sys.exit()
    if net.module.get_bin_path('route') == None:
        print

# Generated at 2022-06-11 03:19:34.735415
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    generic_BSD_ifconfig_network = GenericBsdIfconfigNetwork(module)
    defaults = dict(interface='eth0', address='192.168.1.1')
    interfaces = dict(eth0=dict(ipv4=[dict(address='192.168.1.1'), dict(address='192.168.1.2')],
                                ipv6=[dict(address='2001:1::1'), dict(address='2001:2::2')]))
    generic_BSD_ifconfig_network.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['address'] == '192.168.1.1'
    assert defaults['ipv6'] == []



# Generated at 2022-06-11 03:19:40.265219
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible.module_utils.facts.networking.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    gn = GenericBsdIfconfigNetwork()
    a = gn.merge_default_interface({'interface': 'a'}, {'a': {}, 'b': {}}, 'ipv6')

    assert a == {'interface': 'a'}, "Actual result = %s" % a



# Generated at 2022-06-11 03:19:50.306915
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    An_interface = dict()

    # Test CIDR style addressing
    words = ['tcp_rep', 'inet', '192.168.1.1', 'netmask', '0xff000000', 'broadcast', '192.168.1.255']
    ifconfig = GenericBsdIfconfigNetwork()
    ifconfig.parse_inet_line(words, An_interface, dict())
    assert An_interface['ipv4'][0]['address'] == '192.168.1.1'
    assert An_interface['ipv4'][0]['netmask'] == '255.255.255.0'
    assert An_interface['ipv4'][0]['broadcast'] == '192.168.1.255'

# Generated at 2022-06-11 03:20:03.114370
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    c = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}
    # Test 1 with missing args
    line = 'media: Ethernet autoselect (1000baseT full-duplex)'
    c.parse_media_line(line.split(), iface, ips)
    assert iface['media'] == 'Ethernet'
    assert 'media_select' not in iface
    assert 'media_type' not in iface
    assert 'media_options' not in iface
    # Test 2 with full args
    line = 'media: Ethernet autoselect (1000baseT full-duplex) status: active'
    c.parse_media_line(line.split(), iface, ips)
    assert iface['media'] == 'Ethernet'

# Generated at 2022-06-11 03:20:06.924227
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    test_object = GenericBsdIfconfigNetwork(module)
    assert test_object.get_interfaces_info('ifconfig') is not None



# Generated at 2022-06-11 03:20:16.010045
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test with docker container running NetBSD image
    result = GenericBsdIfconfigNetwork.get_interfaces_info(None, \
        '/sbin/ifconfig -A')

# Generated at 2022-06-11 03:20:27.091577
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()

    line = "inet 127.0.0.1 netmask 0xff000000"
    words = line.split()
    current_if = {'device': 'lo0', 'ipv4': []}
    ips = dict( all_ipv4_addresses=[],
                all_ipv6_addresses=[])

    network.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    assert len(ips['all_ipv4_addresses']) == 1
    assert ips['all_ipv4_addresses'][0] == '127.0.0.1'

    line = "inet6 ::1 prefixlen 128"
    words = line.split()

# Generated at 2022-06-11 03:21:03.692688
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
  # We set these attributes because they can't be accessed in a normal running system
  # and we want to verify that the correct output is generated.
  GenericBsdIfconfigNetwork.platform = 'macOS'
  GenericBsdIfconfigNetwork.system = 'Darwin'
  GenericBsdIfconfigNetwork.distribution = 'macOS'
  GenericBsdIfconfigNetwork.os_version = '10.14.6'
  GenericBsdIfconfigNetwork.os_family = 'Darwin'
  GenericBsdIfconfigNetwork.host_name = 'host_name'
    
  test_obj = GenericBsdIfconfigNetwork()
  words = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '16384']
  current_if = test_obj.parse_interface

# Generated at 2022-06-11 03:21:12.595782
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class AnsibleModule(object):
        def run_command(self, command):
            out = """
default via 192.0.2.1 dev eth0
default dev eth0 scope link
"""
            if command == ['/sbin/route', '-n', 'get', 'default']:
                rc, out, err = 0, "RTNETLINK answers: Invalid argument\ndefault via 192.0.2.1 dev eth0", ""
            elif command == ['/sbin/route', '-n', 'get', '-inet6', 'default']:
                rc, out, err = 0, "default via 2001:db8::1 dev eth0", ""
            return rc, out, err

    module = AnsibleModule()
    gbi_net = GenericBsdIfconfigNetwork()
    gbi_net.module = module


# Generated at 2022-06-11 03:21:23.758333
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:31.149742
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    g = GenericBsdIfconfigNetwork(dict(module=None))

    words = [
        'em0',
        'inet',
        '10.20.30.40',
        'netmask',
        '0xffffffc0',
        'broadcast',
        '10.20.30.47',
    ]
    current_if = {
        'ipv4': [],
        'macaddress': 'unknown',
        'type': 'unknown',
        'device': 'em0',
        'flags': [],
    }

    expected_output = {
        'all_ipv4_addresses': [
            '10.20.30.40',
        ],
    }

    ips = dict(
        all_ipv4_addresses=[],
    )

    g.parse_inet_line

# Generated at 2022-06-11 03:21:43.165238
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ansible = AnsibleModule(argument_spec={})
    platform_fact_mock = get_platform_fact_mock()

    if 'Generic_BSD' in platform_fact_mock.keys():
        platform_fact_mock['Generic_BSD']['network'] = GenericBsdIfconfigNetwork(ansible)


# Generated at 2022-06-11 03:21:53.439065
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    l = GenericBsdIfconfigNetwork()

    defaults     = {}

# Generated at 2022-06-11 03:22:03.898738
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
  #
  # Add your test cases here.
  #
  # e.g.
  #
  #   Words = [ 'inet', '127.0.0.1', 'netmask', '0xffffff00' ]
  # 
  #   Result = generic_bsd_ifconfig.parse_inet_line(Words, MyIF, MyIPs)
  #
  #   assertEqual(Result, 'expected result')
  return ''

"""
A module to get network facts on a Solaris-like system
- Uses the ifconfig command
- Tested on: Solaris 11.3
"""
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import os
import re
import socket
import struct


# Generated at 2022-06-11 03:22:14.803381
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import shlex
    ifconfig_path = 'ifconfig'
    ifconfig_options = '-a'
    # test_interface is a string
    test_interface = '''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
        options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP,RXCSUM_IPV6>
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        nd6 options=201<PERFORMNUD,DAD>
        groups: lo
        status: active
        enc0: flags=0<>
        groups: enc
'''
   

# Generated at 2022-06-11 03:22:25.900605
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModuleMock({})
    network = GenericBsdIfconfigNetwork(module)

    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    rfc1918_networks = ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7']

    # netbsd show static addresses like this
    words = ['inet', '10.10.0.101', 'netmask',
             '0xffffffec', 'broadcast', '10.10.0.255']
    expected

# Generated at 2022-06-11 03:22:37.379429
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Without network_resources module, there is no way to instantiate
    # GenericBsdIfconfigNetwork class. To be able to unit test the class,
    # create a dummy class that inherits from it.
    class FakeGenericBsdIfconfigNetwork(network_resources.GenericBsdIfconfigNetwork):
        def __init__(self):
            return

    module = FakeGenericBsdIfconfigNetwork()

    # Create a fake interface
    current_if = dict()

    # Call parse_media_line using various fake lines
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    module.parse_media_line(words, current_if, dict())
    assert current_if['media'] == 'Ethernet'

# Generated at 2022-06-11 03:23:05.024732
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test is used for platform 'generic' and 'openbsd'
    module = AnsibleModule(argument_spec={})
    module.connect = MagicMock()

    # Test with valid parameters
    def test_with_valid_parameters():
        # Return data
        network = GenericBsdIfconfigNetwork(module)
        current_if = dict()
        ips = dict()
        words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
        # Execute method
        network.parse_inet_line(words, current_if, ips)
        # Verify if method returns the expected result

# Generated at 2022-06-11 03:23:15.555626
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Create object for testing
    module_obj = GenericBsdIfconfigNetwork()
    # get the module object
    module = AnsibleModule(
        argument_spec = dict(
            collected_facts = dict(required = False, type = 'dict')
        )
    );
    # Declare interfaces to test

# Generated at 2022-06-11 03:23:25.152657
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = dict(interface='lo0', address='9.9.9.9', metric='99', mtu='99')
    interfaces = dict(lo0=dict(ipv4=[], ipv6=[]))
    network.merge_default_interface(defaults, interfaces, 'ipv4')

    assert defaults == dict(interface='lo0', address='9.9.9.9', metric='99', mtu='99')

    defaults = dict(interface='lo0', address='9.9.9.9', metric='99', mtu='99')
    interfaces = dict(lo0=dict(ipv4=[dict(address='9.9.9.9', prefix='24', metric='99', mtu='99')], ipv6=[]))
    network.merge_default

# Generated at 2022-06-11 03:23:36.044503
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    def mock_run_command(module, cmd):
        def mock_communicate():
            raise CalledProcessError(1, 'fake', 'fake')

        proc = MagicMock()
        proc.communicate = mock_communicate
        return (0, '', '')

    # Create instance
    module = MagicMock()
    module.run_command = mock_run_command
    plugin = GenericBsdIfconfigNetwork(module=module)

    # Test function
    result = plugin.get_default_interfaces()
    assert result is not None

    # Test function
    result = plugin.get_default_interfaces(route_path=None)
    assert result is not None

    # Test function
    result = plugin.get_default_interfaces(route_path='')
    assert result is not None



# Generated at 2022-06-11 03:23:46.671833
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:23:53.881111
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    tmp = GenericBsdIfconfigNetwork()

    interface = {}
    ips = {}
    # Test 1
    words = ['inet6', 'fe80::1687:2bff:feff:31c1%lo0', 'prefixlen', '64', 'scopeid', '0x6', '%lo0']
    tmp.parse_inet6_line(words, interface, ips)
    assert interface['ipv6'] == [{'address': 'fe80::1687:2bff:feff:31c1', 'prefix': '64', 'scope': '0x6'}]

    # Test 2
    words = ['inet6', 'fe80::1687:2bff:feff:31c1%lo0', 'prefixlen', '64', 'scopeid', '0x6']
    interface = {}


# Generated at 2022-06-11 03:24:04.361823
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    net_obj = GenericBsdIfconfigNetwork()

    # test case - 1
    current_if = dict()
    ips = dict(all_ipv4_addresses=[])
    words = ['127.0.0.1', 'netmask', '0xff000000']

    net_obj.parse_inet_line(words, current_if, ips)

    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'
    assert current_if['ipv4'][0]['broadcast'] == '127.255.255.255'

    # test case - 2
    current_if = dict()

# Generated at 2022-06-11 03:24:13.871795
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())
    test_class = GenericBsdIfconfigNetwork(module)
    words = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'options=9<RXCSUM,TXCSUM,VLAN_MTU>', 'ether', 'xx:xx:xx:xx:xx:xx', 'inet6', 'fe80::xxxx:xxxx:xxxx:xxxx%em0', 'prefixlen', '64', 'scopeid', '0x2', 'inet', '10.xx.xx.xx', 'netmask', '0xffffff00', 'broadcast', '10.xx.xx.255']

# Generated at 2022-06-11 03:24:21.293423
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """
    Test for method merge_default_interface of class GenericBsdIfconfigNetwork
    """
    defaults = {'interface':'en0', 'address':'10.0.0.1'}
    interfaces = {'en0':{'ipv4':[{'address':'10.0.0.1'}]}}
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'ipv4')
    assert {'address':'10.0.0.1', 'interface':'en0', 'ipv4': [{'address':'10.0.0.1'}]} == defaults



# Generated at 2022-06-11 03:24:30.491409
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    task = AnsibleTask()
    network = GenericBsdIfconfigNetwork(task)

    def __run_mock__(cmd, *args, **kwargs):
        assert cmd[-1] in ['get', 'get -inet6']
        return 0, route_output[cmd[-1]], ''

    network.module.run_command = __run_mock__
