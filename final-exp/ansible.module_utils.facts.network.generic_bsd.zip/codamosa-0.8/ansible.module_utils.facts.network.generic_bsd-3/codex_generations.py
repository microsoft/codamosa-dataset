

# Generated at 2022-06-11 03:15:36.976704
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # empty defaults, 
    defaults = dict()
    interfaces = dict()
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == dict()

    # empty interfaces
    defaults = dict()
    defaults['interface'] = 'lo0'
    defaults['address'] = '127.0.0.1'
    interfaces = dict()
    ip_type = 'ipv4'
    generic_bsd_ifconfig_network.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == dict()

    # interface in interfaces, but no address
    defaults = dict()

# Generated at 2022-06-11 03:15:43.328898
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_network = GenericBsdIfconfigNetwork()
    option_string = '<UP,RUNNING,MULTICAST>'
    options = generic_bsd_network.get_options(option_string)
    assert options == ['UP', 'RUNNING', 'MULTICAST'], 'options: %s' % options


# Generated at 2022-06-11 03:15:50.220387
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_module = AnsibleModule(argument_spec=dict())
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(generic_bsd_ifconfig_module)
    assert generic_bsd_ifconfig_network.populate() == dict(
        default_ipv4=dict(),
        default_ipv6=dict(),
        interfaces=list(),
        all_ipv4_addresses=list(),
        all_ipv6_addresses=list()
    )

# Generated at 2022-06-11 03:16:00.866646
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    link_info = '''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
    inet6 ::1 prefixlen 128
    inet 127.0.0.1 netmask 0xff000000
    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    groups: lo
    '''


# Generated at 2022-06-11 03:16:13.044795
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import platform
    import os
    if not os.path.exists('/usr/local/bin/get_default_interfaces_test_file'):
        return
    if 'Darwin' in platform.system():
        return

    module = AnsibleModule(
        argument_spec=dict(
            test_lines=dict(required=True, type='list'),
            test_command=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    want = {}
    lines = module.params['test_lines']
    command = module.params['test_command']
    for line in lines:
        if line == '':
            continue
        words = line.strip().split(': ')

# Generated at 2022-06-11 03:16:24.120026
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_subject = GenericBsdIfconfigNetwork()

    current_if = {'ipv4': []}

    test_subject.parse_inet_line(['inet', '192.0.2.99', 'netmask', '0xffffff00', 'broadcast', '192.0.2.255'], current_if, {})

    assert len(current_if['ipv4']) == 1

    assert current_if['ipv4'][0] == {
        'address': '192.0.2.99',
        'netmask': '255.255.255.0',
        'broadcast': '192.0.2.255',
        'network': '192.0.2.0',
    }


# Generated at 2022-06-11 03:16:35.409449
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    def test_GenericBsdIfconfigNetwork_get_interfaces_info_actual(platform, stdout, interfaces, ips):
        module = FakeAnsibleModule({})
        network = GenericBsdIfconfigNetwork(module)
        network.platform = platform
        ifconfig_path = module.get_bin_path('ifconfig')
        if ifconfig_path is None:
            assert interfaces is None
            assert ips is None
        else:
            interfaces_actual, ips_actual = network.get_interfaces_info(ifconfig_path)
            assert interfaces_actual == interfaces
            assert ips_actual == ips

# Generated at 2022-06-11 03:16:45.405634
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
  class Helper(object):
    def __init__(self):
        self.bin_paths = {}
    def get_bin_path(self, name, opt_dirs=[]):
        return self.bin_paths.get(name, None)
    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, '', '')
    def supported(self):
        return True

  arg_module = Helper()
  arg_module.bin_paths['route'] = '/route/here'
  arg_module.bin_paths['ifconfig'] = '/ifconfig/here'
  result = GenericBsdIfconfigNetwork().populate(arg_module)

# Generated at 2022-06-11 03:16:50.206161
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    option1 = 'UP'
    option2 = 'MULTICAST'
    option3 = 'BROADCAST'
    result = network.get_options('{}<{},{},{}>'.format(option1, option1, option2, option3))
    assert option1 in result
    assert option2 in result
    assert option3 in result

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_get_options()

# Generated at 2022-06-11 03:16:54.007148
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module.network.common.facts.facts import NetworkFacts

    module = AnsibleModule(argument_spec={})
    network_module = NetworkFacts(module)
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork(network_module)
    result = generic_bsd_ifconfig.get_options('asdf <adf,adsf> asdf')
    assert result == ['adf', 'adsf']

# Generated at 2022-06-11 03:17:10.529090
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.network.common.utils import dict2list
    from ansible.module_utils.facts.network.bsd.ifconfig import GenericBsdIfconfigNetwork

    # output of ifconfig command

# Generated at 2022-06-11 03:17:19.078457
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    if not os.path.exists('test/generic_bsd_ifconfig_network/route-n-get-inet6.txt') or \
       not os.path.exists('test/generic_bsd_ifconfig_network/route-n-get.txt'):
        raise Exception('Test file not found')

    mock_module = type('AnsibleModule', (object,), {'run_command': lambda *args: (0, open('test/generic_bsd_ifconfig_network/route-n-get-inet6.txt').read(), '')})()
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    ipv6_default_interface = generic_bsd_ifconfig_network.get_default_interfaces(route_path = 'na')[1]

    assert ipv6

# Generated at 2022-06-11 03:17:28.321853
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    Test if parsing of lines of the form:

    inet6 fe80:0:0:0:202:b3ff:fe1e:8329%em0 prefixlen 64 scopeid 0x1
    inet6 2a01:e00::2d7:1 prefixlen 64
    inet6 fe80::250:56ff:fe8c:7b0c%lo0 prefixlen 64 scopeid 0x2
    inet6 fe80::%lo0/64
    inet6 2a00:1450:400b:812::2004/64
    inet6 fe80::250:56ff:fe8c:7b0c%lo0 prefixlen 64 scopeid 0x2
    inet6 ::1/128
    inet6 fe80::1%lo0/64
    """

# Generated at 2022-06-11 03:17:33.737711
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork({}, {})
    option_string = '<something=yes,another-thing=yes,last-thing=no>'
    assert generic_bsd_ifconfig_network.get_options(option_string) == ['something=yes', 'another-thing=yes', 'last-thing=no']


# Generated at 2022-06-11 03:17:46.543924
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # This line is necessary to force the AnsibleModule to convert the argument
    # from a string to a list as appropriate

# Generated at 2022-06-11 03:17:55.770327
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = './data/ifconfig.txt'

    gbn_test = GenericBsdIfconfigNetwork()

    interfaces_info_test, ips_test = gbn_test.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-11 03:18:07.415572
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModuleMock('GenericBsdIfconfigNetwork')
    module.run_command  = lambda x: ["127.0.0.1\tlocalhost.localdomain\tlocalhost", "::1\tlocalhost6.localdomain6\tlocalhost6"] if x[-1] == 'hosts' else [0, "", ""]

    module.get_bin_path = lambda x: None if x == 'route' else '/sbin/ifconfig'

    platform = get_platform()

# Generated at 2022-06-11 03:18:10.145733
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    result = GenericBsdIfconfigNetwork.get_options('UP,LOOPBACK,RUNNING')
    assert result == ['UP', 'LOOPBACK', 'RUNNING']


# Generated at 2022-06-11 03:18:22.389364
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    c = GenericBsdIfconfigNetwork()
    # Test for existing interface and address
    defaults = dict(
        interface='lo0',
        address='127.0.0.1'
    )
    interfaces = dict(
        lo0=dict(
            interface='lo0',
            name='lo0',
            ipv4=[dict(address='127.0.0.1')],
            ipv6=[dict(address='::1')]
        ),
        lo1=dict(
            interface='lo1',
            name='lo1',
            ipv4=[dict(address='128.0.0.1')]
        )
    )
    c.merge_default_interface(defaults, interfaces, 'ipv4')
    assert 'name' in defaults, "Expected interface name not found in defaults"

# Generated at 2022-06-11 03:18:29.192154
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """Method get_interfaces_info of class GenericBsdIfconfigNetwork"""
    gbin = GenericBsdIfconfigNetwork()

    ifconfig_test_data_1 = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>
    inet 127.0.0.1 netmask 0xff000000
    inet6 ::1 prefixlen 128
    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    nd6 options=201<PERFORMNUD,DAD>
    groups: lo
    """

    interfaces, ips = gbin.get_interfaces_info(None, ifconfig_test_data_1)
   

# Generated at 2022-06-11 03:18:41.719732
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    from ansible.module_utils.facts.network.ifconfig import GenericBsdIfconfigNetwork
    import socket
    import struct



# Generated at 2022-06-11 03:18:46.865847
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = MagicMock(name='module')
    module.run_command = MagicMock(
        name='run_command',
        return_value=(0,  # return code
                      '',  # stdout
                      ''), # stderr
        )
    module.get_bin_path = MagicMock(
        name='get_bin_path',
        return_value=None
        )
    net = GenericBsdIfconfigNetwork(module)
    assert net.populate() == {}


# Generated at 2022-06-11 03:18:53.149018
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if not HAS_SOCKET_IPV6:
        module.skip_json()

    (failed, changed,
     response) = GenericBsdIfconfigNetwork.populate(module)

    assert not failed
    assert not changed
    assert isinstance(response, dict)



# Generated at 2022-06-11 03:19:01.583072
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    test_cases = dict(
        basic_cidr='inet 10.1.1.1 netmask 0xffffff00',
        basic_cidr_alias='inet alias 10.2.2.2 netmask 0xffffff00',
        cidr_with_broadcast='inet 10.1.1.1 netmask 0xffffff00 broadcast 10.2.2.2',
        cidr_with_broadcast_alias='inet alias 10.1.1.1 netmask 0xffffff00 broadcast 10.2.2.2',
        hex_netmask='inet 10.1.1.1 netmask 0xffffff00',
        hex_netmask_alias='inet alias 10.1.1.1 netmask 0xffffff00',
    )


# Generated at 2022-06-11 03:19:13.498926
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Arrange
    import os

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    generic_bsd_ifconfig = GenericBsdIfconfigNetwork()
    route_path = '/sbin/route'
    fake_route_output = StringIO('   interface: lo0\n   gateway: 127.0.0.1\n')
    fake_route_cmd = [route_path, '-n', 'get', 'default']
    fake_route_cmd_v6 = [route_path, '-n', 'get', '-inet6', 'default']

    # os.path.exists = MagicMock(return_value = True)
    os.path.exists = Mock(return_value=True)
    generic_bsd_

# Generated at 2022-06-11 03:19:24.062956
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({})
    module.exit_json = basic.AnsibleModule.exit_json
    module.run_command = basic.AnsibleModule.run_command

    gbi = GenericBsdIfconfigNetwork(module)

    # ipv6 address no prefix
    words = ['inet6', 'fe80::11e7:9ff:fe96:19ce', 'prefixlen', '64', 'scopeid', '0x7']
    current_if = {'ipv6': []}
    ips = dict(all_ipv6_addresses=[])
    result = gbi.parse_inet6_line(words, current_if, ips)

# Generated at 2022-06-11 03:19:33.022839
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    def_if = {'interface': 'eth0'}
    ifs = {'eth0': {'ipv4': [{'address': '192.168.1.1'}]}}
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig.merge_default_interface(def_if, ifs, 'ipv4')
    assert def_if == {'interface': 'eth0', 'ipv4': [{'address': '192.168.1.1'}]}


# Generated at 2022-06-11 03:19:39.808160
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Testing a FreeBSD (and Mac) style line
    words = ['lo0:', 'flags=8d49', 'mtu', '16384', 'inet6',
             '::1', 'prefixlen', '128', 'inet6', 'fe80::1',
             '%lo0', 'prefixlen', '64', 'scopeid', '0x2',
             'inet', '127.0.0.1', 'netmask', '0xff000000',
             'nd6', 'options=21']
    current_if = dict(device='lo0')
    ips = dict(all_ipv4_addresses=[])

    GenericBsdIfconfigNetwork().parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:19:50.012575
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate(): 

    # Arrange
    module = None
    json_out = {'interface': 'lo0', 'ipv4': [{'address': '127.0.0.1', 'netmask': '255.255.255.0', 'broadcast': '127.0.255.255', 'network': '127.0.0.0'}], 'ipv6': [{'address': '::1', 'prefix': '128', 'scope': '0x10'}, {'address': 'fe80::1%lo0', 'prefix': '64', 'scope': '0x1'}], 'type': 'loopback', 'flags': ['LOOPBACK', 'RUNNING', 'UP', 'MULTICAST'], 'metric': '0', 'mtu': '32768', 'macaddress': 'unknown'}
    json_out

# Generated at 2022-06-11 03:20:02.786262
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """ Method merge_default_interface of class GenericBsdIfconfigNetwork """
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address': '127.0.0.1', 'netmask': '255.255.255.0'}],
                          'ipv6': [{'address': '::1', 'netmask': 'ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff'}],
                          'type': 'loopback',
                          'macaddress': 'unknown',
                          'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}}
    ip_type = 'ipv4'

# Generated at 2022-06-11 03:20:30.994650
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
    # Mock imports
    import sys
    import collections
    sys.modules['__main__'] = collections.namedtuple('FakeModule', 'params')

    # Create an instance of GenericBsdIfconfigNetwork
    module_args={}
    test_object = GenericBsdIfconfigNetwork(module_args=module_args)

    # Mock data
    defaults = {
        'interface': 'test_interface',
        'address': 'test_address'
    }
    interfaces = {
        'test_interface': {
            'ipv4': [
                {
                    'address': 'test_address',
                    'netmask': 'test_netmask'
                }
            ]
        }
    }

    # Call the function under test
    new_

# Generated at 2022-06-11 03:20:41.465526
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig = GenericBsdIfconfigNetwork()
    defaults = dict()
    interfaces = dict()
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert not defaults
    interfaces = dict(eth0=dict(ipv4=[dict(address='127.0.0.1')]))
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert not defaults
    defaults = dict(interface='eth0', address='127.0.0.1')
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert '127.0.0.1' in defaults
    # test adding all other non-address items from the interfaces into the defaults

# Generated at 2022-06-11 03:20:52.262645
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:03.245605
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test call with good binary returns 0 and empty output
    mock_module = Mock(**{
        'run_command.return_value': (0, '', None),
    })
    network = GenericBsdIfconfigNetwork()
    network.module = mock_module
    defaults = network.get_default_interfaces('route')
    assert defaults == ({}, {})

    # Test call with good binary returns 0 and empty output
    mock_module = Mock(**{
        'run_command.return_value': (0, '', None),
    })
    network = GenericBsdIfconfigNetwork()
    network.module = mock_module
    defaults = network.get_default_interfaces('route')
    assert defaults == ({}, {})

    # Test call with good binary returns 0 and empty output

# Generated at 2022-06-11 03:21:12.257345
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # all keywords in command output
    keywords = {
        'default': {
            'flags': ['UP', 'GATEWAY', 'DONE', 'LLINFO', 'STATIC', 'PROTO2'],
            'gateway': '192.168.122.1',
            'interface': 'vg0',
            'local addr': '192.168.122.77',
        },
        'default_inet6': {
            'flags': ['UP', 'GATEWAY', 'DONE', 'LLINFO', 'STATIC', 'PROTO2'],
            'gateway': 'fe80::a00:27ff:feed:aa8d',
            'interface': 'em0',
            'local addr': 'fe80::a00:27ff:feed:aa8d%em0',
        }
    }
    # Generate input

# Generated at 2022-06-11 03:21:23.465822
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module_mock = MagicMock()


# Generated at 2022-06-11 03:21:30.969837
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # AssertionError: 'lo0' != 'itm4'
    # E       +  where 'lo0' = <built-in method keys of dict object at 0x7ff8b21d33c0>.keyorder[0]
    # E       +  and   'itm4' = first(full_result['interfaces'])
    # E       +    where full_result = {'all_ipv4_addresses': ['10.0.2.15'],
    # E       +                          'all_ipv6_addresses': [],
    # E       +                          'default_ipv4': {'address': '10.0.2.15',
    # E       +                                

# Generated at 2022-06-11 03:21:43.073320
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    interfaces, ips = generic_bsd_ifconfig_network.get_interfaces_info(
            '/sbin/ifconfig')
    assert 'lo0' in interfaces
    assert interfaces['lo0']['macaddress'] == 'unknown'
    # Test MacOSX
    interfaces, ips = generic_bsd_ifconfig_network.get_interfaces_info(
            '/sbin/ifconfig', '-l -u')
    assert 'lo0' in interfaces
    assert interfaces['lo0']['macaddress'] == 'unknown'
    # Test Solaris
    interfaces, ips = generic_bsd_ifconfig_network.get_interfaces_

# Generated at 2022-06-11 03:21:48.661986
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    with open('tests/unit/modules/network/fixtures/bsd-ifconfig-route.txt') as ifconfig_route_fixture:
        ifconfig_route = ifconfig_route_fixture.read()
        test = GenericBsdIfconfigNetwork()

        ipv4, ipv6 = test.get_default_interfaces('/sbin/route')

        assert ipv4['gateway'] == '10.1.1.1'
        assert ipv4['interface'] == 'en0'
        assert ipv4['address'] == '10.1.1.1'
        assert ipv6['interface'] == 'en0'
        assert ipv6['address'] == 'fe80::d3a6:23ef:fec1:7695%awdl0'

# Generated at 2022-06-11 03:21:55.221440
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(argument_spec={})
    network_info = GenericBsdIfconfigNetwork()

    ifaces = {}
    ifaces['em0'] = {}
    ifaces['em0']['type'] = 'unknown'
    ifaces['em0']['flags'] = []
    ifaces['em0']['device'] = 'em0'
    ifaces['em0']['ipv4'] = []
    ifaces['em0']['ipv6'] = []

    words = ['em0', 'media:', 'Ethernet', 'autoselect', '[100baseTX', 'full-duplex]']

    network_info.parse_media_line(words, ifaces['em0'], {})

    assert ifaces['em0']['media'] == 'Ethernet'

# Generated at 2022-06-11 03:22:35.121411
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    p = GenericBsdIfconfigNetwork()
    assert p.get_default_interfaces('route')[0] == {}
    assert p.get_default_interfaces('route')[1] == {}


# Generated at 2022-06-11 03:22:43.216642
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    fake_module = FakeModule()
    fake_module.set_bin_path("route", "/sbin/route")
    route_output = """
add net default: gateway 192.168.1.1
add net default: gateway 192.168.0.1
add net default: gateway 192.168.1.2
add net default: gateway 192.168.1.3
add net default: gateway 192.168.1.4
add net default: gateway 192.168.1.5
add net default: gateway 192.168.1.6"""
    fake_module.set_module_results(0, stdout=route_output)
    fake_module.set_module_results(2, stderr="invalid argument")
    net = GenericBsdIfconfigNetwork(fake_module)

    v4, v6 = net.get_default_

# Generated at 2022-06-11 03:22:54.637172
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module_args = dict()
    fixture_obj = GenericBsdIfconfigNetwork()
    arguments_dict = dict()
    arguments_dict['module_args'] = module_args
    arguments_dict['module'] = fixture_obj.module
    results = dict()
    # TODO: Implement actual test
    # results['default_ipv4'], results['default_ipv6'] = fixture_obj.get_default_interfaces(fixture_obj.route_path)
    results['default_ipv4'] = {'interface': 'utun0', 'gateway': 'fe80::6cb1:54ff:fdfb:d6e9%utun0'}
    results['default_ipv6'] = {}
    assert results == fixture_obj.get_default_interfaces(fixture_obj.route_path)


# Generated at 2022-06-11 03:22:58.832602
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    retval = GenericBsdIfconfigNetwork(module).get_interfaces_info('/sbin/ifconfig', '-a')
    assert retval is not None
    assert len(retval) > 0
    assert retval[0] is not None


# Generated at 2022-06-11 03:23:09.959461
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:23:20.580853
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    x = GenericBsdIfconfigNetwork()
    x.module = Mock()

    mock_script = '''#!/bin/sh\necho -n ''\n'''

# Generated at 2022-06-11 03:23:28.167920
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if not HAS_SUBPROCESS:
        module.fail_json(msg=missing_required_lib('subprocess'), exception=SUBPROCESS_IMP_ERR)
    if not HAS_SOCKET:
        module.fail_json(msg=missing_required_lib('socket'), exception=SOCKET_IMP_ERR)

    from ansible.module_utils.network.generic.ifconfig import GenericBsdIfconfigNetwork

    mocker = Mock()
    mocker.get_bin_path.side_effect = [
        True,
        True
    ]
    

# Generated at 2022-06-11 03:23:36.305857
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # Arguments for testing
    ifconfig = '/sbin/ifconfig'
    ifconfig_options = '-a'
    out = open(os.devnull,'w')
    err = open(os.devnull,'w')
    (rc, interfaces, ips) = GenericBsdIfconfigNetwork.get_interfaces_info(ifconfig, ifconfig_options, None, out, err)

    if not rc:
        return (False, None)

    return (True, interfaces)


# Generated at 2022-06-11 03:23:46.925049
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_ifconfig_network = GenericBsdIfconfigNetwork()
    # testcase -> expected result

# Generated at 2022-06-11 03:23:53.996647
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    def gen_interface_output(interfaces, source_ip='10.0.0.1'):
        output = ''