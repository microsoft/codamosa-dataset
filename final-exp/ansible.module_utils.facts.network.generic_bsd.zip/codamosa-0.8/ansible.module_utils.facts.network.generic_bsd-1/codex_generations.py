

# Generated at 2022-06-11 03:15:30.405930
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test = dict()

    test['Media'] = dict()
    test['Media']['in'] = dict()
    test['Media']['in']['interfaces'] = dict()
    test['Media']['in']['interfaces']['lo0'] = dict()
    test['Media']['in']['interfaces']['lo0']['media'] = dict()
    test['Media']['in']['interfaces']['lo0']['media'] = 'LOOPBACK'

    test['Media']['in']['interfaces']['em0'] = dict()
    test['Media']['in']['interfaces']['em0']['media'] = dict()
    test['Media']['in']['interfaces']['em0']['media']

# Generated at 2022-06-11 03:15:39.023476
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Setup
    g = GenericBsdIfconfigNetwork()
    current_if = {'device': 'enp94s0f0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [],
           'all_ipv6_addresses': []}

    # Execute
    g.parse_inet_line(['inet', '147.11.0.1', 'netmask', '0xffff0000', 'broadcast', '147.11.255.255'],
                     current_if, ips)

    # Verify
    assert 'inet' in current_if
    assert current_if['ipv4'][0]['address'] == '147.11.0.1'

# Generated at 2022-06-11 03:15:50.331678
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Setup
    test_obj = GenericBsdIfconfigNetwork()
    test_current_if = {'ipv4': []}
    test_ips = {'all_ipv4_addresses': []}

    # Test cidr with broadcast

    test_words = ['inet', '172.16.2.2', 'netmask', '0xffffff00', 'broadcast', '172.16.2.255']
    test_obj.parse_inet_line(test_words, test_current_if, test_ips)

    assert test_ips['all_ipv4_addresses'] == ['172.16.2.2']

# Generated at 2022-06-11 03:16:00.947718
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    '''
    Unit test function for method get_default_interfaces of class
    GenericBsdIfconfigNetwork.
    '''
    print(colors.LIGHT_BLUE +
          "\nTesting method get_default_interfaces of class GenericBsdIfconfigNetwork:" +
          colors.ENDC)
    sys.stdout.write(colors.BOLD + "Testing on a FreeBSD 10.3 system... " + colors.ENDC)
    try:
        test_obj = GenericBsdIfconfigNetwork()
    except Exception as e:
        print(colors.FAIL + "Failed to create test object!" + colors.ENDC)
        print(colors.FAIL + str(e) + colors.ENDC)
        sys.exit(1)

# Generated at 2022-06-11 03:16:13.280662
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Set platform to 'generic_bsd_ifconfig'
    platform = 'generic_bsd_ifconfig'
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    network_facts = NetworkFacts(module)
    network_facts._populate()

    res = network_facts._get_interfaces_info(ifconfig_path='/sbin/ifconfig',
                                             ifconfig_options='-a')
    f = open('/tmp/' + platform + '_get_interfaces_info.txt', 'w')
    f.write('platform=' + platform + '\n')
    f.write('interfaces=' + str(res[0]) + '\n')
    f

# Generated at 2022-06-11 03:16:25.020863
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_NETIFACES:
        module.fail_json(msg='the python netifaces library is required')

    n = GenericBsdIfconfigNetwork(module)
    interfaces = n.populate()['interfaces']
    # just check that we have found at least one interface for each type
    for intf_type in ('ether', 'loopback'):
        if intf_type not in interfaces:
            module.fail_json(msg="No %s interface found" % intf_type)
    module.exit_json(ansible_facts=dict(ansible_network_resources=interfaces))

#

# Generated at 2022-06-11 03:16:28.278360
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    if not module.check_mode:
        module.fail_json(msg='test_GenericBsdIfconfigNetwork_get_default_interfaces not implemented')


# Generated at 2022-06-11 03:16:33.142068
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    targetObj = GenericBsdIfconfigNetwork()
    defaults = dict()
    interfaces = dict()
    ip_type = 'ipv4'
    result = targetObj.merge_default_interface(defaults, interfaces, ip_type)
    print(result)


# Generated at 2022-06-11 03:16:43.628318
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.network.common.config import NetworkConfig
    
    platform_class = load_platform_subclass(GenericBsdIfconfigNetwork) 
    network_obj = platform_class(module=None, config=NetworkConfig(),
                                       tempdir=None)
    
    iface = {'device': 'eth0', 'media': 'Ethernet 10Gbase-T'}
    interfaces = {'eth0': iface}
    
    assert network_obj.detect_type_media(interfaces) == {'eth0': {'device': 'eth0', 'media': 'Ethernet 10Gbase-T', 'type': 'ether'}}


# Generated at 2022-06-11 03:16:46.267625
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_inst = GenericBsdIfconfigNetwork()
    
    # Test with negative condition:
    if test_inst.populate() == {}:
        assert True
    else:
        assert False



# Generated at 2022-06-11 03:17:05.785263
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:11.568657
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifc = GenericBsdIfconfigNetwork()

    # test output from freebsd

# Generated at 2022-06-11 03:17:16.785849
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Use the command:
    #     route -n get default
    #     route -n get -inet6 default
    # to find out the default outgoing interface, address, and gateway

    path = "/usr/sbin/route"
    
    # ipv4
    command_v4 = [path, '-n', 'get', 'default']
    print(command_v4)
    time.sleep(10)
    rc, out, err = module.run_command(command_v4)
    print(out)


# Generated at 2022-06-11 03:17:26.647270
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    #Test with a 2-byte netmask
    m = GenericBsdIfconfigNetwork()
    words = ['inet', '192.168.1.1', 'netmask', '0xffff0000', 'broadcast', '192.168.255.255']
    current_if = {'ipv4': []}
    ips = dict(
        all_ipv4_addresses=[],
    )
    m.parse_inet_line(words, current_if, ips)

    #Test with a 1-byte netmask
    m = GenericBsdIfconfigNetwork()
    words = ['inet', '192.168.1.1', 'netmask', '0xff', 'broadcast', '192.168.255.255']
    current_if = {'ipv4': []}

# Generated at 2022-06-11 03:17:38.374243
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import os
    import tempfile

    def execute_command(command):
        return_code = 0

# Generated at 2022-06-11 03:17:39.685065
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    assert True

# Generated at 2022-06-11 03:17:51.843254
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # initializing the data for testing
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv6_addresses': []}

    # testing with a valid IPv6 address
    words = [None, 'fe80::1%lo0']
    GenericBsdIfconfigNetwork.parse_inet6_line(GenericBsdIfconfigNetwork, words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert ips['all_ipv6_addresses'][0] == 'fe80::1%lo0'

    # testing with cidr style IPv6 address

# Generated at 2022-06-11 03:18:04.246491
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()

    mock_route_path = Mock()
    mock_module = Mock()
    GenericBsdIfconfigNetwork.module = mock_module
    mock_module.get_bin_path.return_value = mock_route_path

# Generated at 2022-06-11 03:18:11.800488
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # gather_network_facts class is tested in test_module_setup.py
    # this test is specifically for the GenericBSDIfconfigNetwork
    # class that extends gather_network_facts

    # TODO: use the unittest mock module?

    class RunCommand:
        def __init__(self):
            self.command = {}

        def __call__(self, command, check_rc=None, data=None, binary_data=False,
                     path_prefix=None, cwd=None, use_unsafe_shell=None, environ_update=None,
                     umask=None, encoding=None, errors=None, log_errors=None,
                     binary_output=False, capture_error=True, capture_warnings=False):

            if command in self.command:
                return self.command[command]

# Generated at 2022-06-11 03:18:16.241914
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network_facts = GenericBsdIfconfigNetwork(module).get_interfaces_info("/sbin/ifconfig")
    assert network_facts != None



# Generated at 2022-06-11 03:18:42.534415
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    address = {'netmask': '255.255.255.0'}
    words = ['inet', '10.5.5.5', 'netmask', '0xffffff00']
    ips = dict(all_ipv4_addresses=[])
    current_if = dict(ipv4=[])
    GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork.parse_inet_line(None, words, current_if, ips)
    assert('10.5.5.5' in ips['all_ipv4_addresses'])
    assert('255.255.255.0' in current_if['ipv4'][0]['netmask'])

# Generated at 2022-06-11 03:18:49.557776
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network_facts = dict()
    network_facts['all_ipv6_addresses'] = list()
    network_facts['all_ipv4_addresses'] = list()
    network_facts['interfaces'] = list()
    interfaces = dict()
    ipv4 = list()
    ipv4.append(dict(address="1.2.3.4", netmask="255.255.255.0", broadcast="1.2.3.255", network="1.2.3.0"))
    ipv4.append(dict(address="5.6.7.8", netmask="255.255.255.0", broadcast="5.6.7.255", network="5.6.7.0"))
    interfaces["eth0"] = dict(ipv4=ipv4)

# Generated at 2022-06-11 03:18:59.742222
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:10.340618
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = GenericBsdIfconfigNetwork(module)

    # Test 1: IPv4 address with decimal-dotted-quad netmask + broadcast
    words = [
        'em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>',
        'metric', '0', 'mtu', '1500',
        'inet', '192.0.2.1', 'netmask', '0xffffff00', 'broadcast', '192.0.2.255',
        'nd6', 'options=1<PERFORMNUD>'
    ]
    interfaces = {}

# Generated at 2022-06-11 03:19:22.452948
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
#       Setup:
    class content(object):
        def __init__(self, module, bin_path=None, run_command=None):
            self.module = module
            self.bin_path = bin_path
            self.run_command = run_command
    class TestModule(object):
        def __init__(self, bin_path=None, run_command=None):
            self.bin_path = bin_path
            self.run_command = run_command
        def get_bin_path(self, arg):
            return self.bin_path
        def run_command(self, command, check_rc=True):
            return self.run_command(command)


# Generated at 2022-06-11 03:19:34.896560
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:37.200892
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_impl_GenericBsdIfconfigNetwork = ImplGenericBsdIfconfigNetwork()
    test_impl_GenericBsdIfconfigNetwork.populate()

# Generated at 2022-06-11 03:19:48.439427
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interface = dict(media='Ethernet autoselect (1000baseT full-duplex,master)')
    assertion_message = 'Expected ether type, got {0}'.format(interface['type'])
    assert 'ether' == GenericBsdIfconfigNetwork.detect_type_media(interface)['type'], assertion_message
    interface = dict(media='Fiber autoselect (none)')
    assertion_message = 'Expected none type, got {0}'.format(interface['type'])
    assert 'none' == GenericBsdIfconfigNetwork.detect_type_media(interface)['type'], assertion_message
    interface = dict(media='none')
    assertion_message = 'Expected none type, got {0}'.format(interface['type'])
    assert 'none' == GenericBsdIfconfigNetwork.det

# Generated at 2022-06-11 03:20:00.191111
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    get_default_interfaces_test_cases = [
        # line and output pairs
        (["""route -n get default""", "interface: ", "gateway: "],
            {'default_ipv4': {'gateway': 'gateway ip', 'interface': 'interface name'}}),
        (["""route -n get -inet6 default""", "interface: ", "gateway: "],
            {'default_ipv6': {'gateway': 'gateway ipv6', 'interface': 'interface name'}}),
        (["""route -n get -inet6 default""", "interface: ", "RTNETLINK answers: Invalid argument"],
            {'default_ipv6': {}})
    ]


# Generated at 2022-06-11 03:20:04.200764
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    network = GenericBsdIfconfigNetwork(module)
    print(network.populate())

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-11 03:21:03.336033
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Assert the ipv6 address format with prefix length
    inet6_test_string = "inet6 fe80::20c:29ff:fea8:d5b9%em0 prefixlen 64 " \
                        "scopeid 0x1"
    interfaces = GenericBsdIfconfigNetwork()
    words = inet6_test_string.split()
    current_if = {'ipv6' : []}
    ips = []
    interfaces.parse_inet6_line(words, current_if, ips)

    assert len(current_if['ipv6']) == 1
    assert current_if['ipv6'][0]['address'] == 'fe80::20c:29ff:fea8:d5b9'

# Generated at 2022-06-11 03:21:12.321081
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:21:23.508068
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    m = GenericBsdIfconfigNetwork({})
    current_if = {}

    # Full address
    words = ['inet6', 'dead:beef:cafe:babe:face:c0ff:ee0d:f00d',
             'prefixlen', '64', 'scopeid', '0x10', 'prefixlen', '64']
    m.parse_inet6_line(words, current_if, {})
    assert current_if['ipv6'][0]['address'] == 'dead:beef:cafe:babe:face:c0ff:ee0d:f00d'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0x10'

    # Address with no prefix
    current

# Generated at 2022-06-11 03:21:24.915327
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig_network = GenericBsdIfconfigNetwork()
    assert True

# Generated at 2022-06-11 03:21:31.685558
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network_module = NetworkModule()
    network_module.params = {
        'gather_subset': '!all',
        'gather_network_resources': 'all'
    }
    network_module.args = {}

    # result is a hash ref
    result = {
        'default_ipv4': {},
        'default_ipv6': {}
    }

    gbi = GenericBsdIfconfigNetwork(network_module)
    result['default_ipv4']['interface'] = 'eth0'
    result['default_ipv4']['gateway'] = '10.0.0.1'
    result['default_ipv4']['address'] = '10.0.0.2'
    # result['default_ipv4']['netmask'] = '255.255.255

# Generated at 2022-06-11 03:21:43.816003
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    assert GenericBsdIfconfigNetwork.parse_inet6_line(
        words=['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2'],
        current_if={'ipv6': []},
        ips={},
    ) == {
        'ipv6': [{'address': 'fe80::1%lo0', 'prefix': '64', 'scope': '0x2'}],
    }


# Generated at 2022-06-11 03:21:53.982187
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import create_autospec
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    mock_module = create_autospec(NetworkModule)
    mock_module.params = {}
    mock_module.run_command = mock_ansible_module.run_command
    mock_module.get_bin_path = mock_ansible_module.get_bin_path
    mock_module.check_args = mock_ansible_module.check_args


# Generated at 2022-06-11 03:22:04.185529
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:22:15.081902
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
            'v4': dict(type='dict'),
            'v6': dict(type='dict'),
        },
    )
    instance = GenericBsdIfconfigNetwork(module)
    command = dict(v4=['/bin/route', '-n', 'get', 'default'],
                   v6=['/bin/route', '-n', 'get', '-inet6', 'default'])
    module.run_command = MagicMock(side_effect=[(0, 'default:1:2:3', 'default:1:2:3'), (1, '', '')])
    out = instance.get_default_interfaces('/bin/route')
    assert out == ({'interface': 'default', 'gateway': '1'}, {})

# Generated at 2022-06-11 03:22:26.180854
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=True,
    )

# Generated at 2022-06-11 03:22:55.783976
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    def get_route_output(*args, **kwargs):
        if args[0][-1] == 'default':
            return 0, '192.168.1.1 192.168.1.2 UGS 0 10 en0'
        elif args[0][-1] == '-inet6':
            return 0, '2401:4f00:0:6a88::1 2401:4800:0:6a88::2 UGS 0 10 en0'
        elif args[0][-1] == '-inet6 default':
            return 0, '2401:4f00:0:6a88::1 2401:4800:0:6a88::2 UGS 0 10 en0'

    module = mock.MagicMock()
    module.run_command.side_effect = get_route_output
   

# Generated at 2022-06-11 03:23:06.510465
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    nm = GenericBsdIfconfigNetwork()
    ifconfig_path = nm.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return

    route_path = nm.module.get_bin_path('route')

    if route_path is None:
        return

    default_ipv4, default_ipv6 = nm.get_default_interfaces(route_path)
    interfaces, ips = nm.get_interfaces_info(ifconfig_path)
    interfaces = nm.detect_type_media(interfaces)

    nm.merge_default_interface(default_ipv4, interfaces, 'ipv4')
    nm.merge_default_interface(default_ipv6, interfaces, 'ipv6')
    # print(default_ipv4)
    #

# Generated at 2022-06-11 03:23:16.975735
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    m = GenericBsdIfconfigNetwork({})
    words = ["en0", "flags", "=", "8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500"]
    current_if = {'device': words[0], 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    m.parse_interface_line(words)
    words = ["inet", "10.95.45.220", "netmask", "0xffffc800", "broadcast", "10.95.63.255"]

# Generated at 2022-06-11 03:23:26.203129
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = dict(
        interface='lo0',
        address='127.0.0.1'
    )
    interfaces = dict(
        lo0=dict(
            flags=['UP', 'LOOPBACK', 'RUNNING']
        )
    )
    g = GenericBsdIfconfigNetwork(dict(
        module=dict(
            run_command=lambda *args, **kwargs: (0, '', ''),
            get_bin_path=lambda *args, **kwargs: '/sbin/route'
        )
    ))
    g.merge_default_interface(defaults, interfaces, 'ipv4')

    assert defaults == dict(
        interface='lo0',
        address='127.0.0.1',
        flags=['UP', 'LOOPBACK', 'RUNNING']
    )


# Generated at 2022-06-11 03:23:37.536736
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """GenericBsdIfconfigNetwork: get_default_interfaces()"""

    # Without 'out' the method will fail.
    # Add initial values to 'cmd' and 'result' to make the unit test work.
    cmd = "route -n get default"

    # Create instance of class with 'cmd' and 'out'.
    n = GenericBsdIfconfigNetwork()
    n.module.run_command = Mock(return_value=(0, '', ''))

    # Call method under test with 'cmd' and 'result'.
    result = n.get_default_interfaces(cmd)
    assert result == ({}, {})

    # Try with a real result.
    n.module.run_command = Mock(return_value=(0, 'default: gateway fe80::62e5:d%utun1', ''))
    result = n

# Generated at 2022-06-11 03:23:46.879831
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    g = GenericBsdIfconfigNetwork()

    # test case: ether
    interfaces = {
        'eth0': {
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)',
            'type': 'unknown'
        }
    }
    assert g.detect_type_media(interfaces)['eth0']['type'] == 'ether'

    # test case: not ether
    interfaces = {
        'eth0': {
            'media': 'Ethernet 1000baseT <full-duplex>',
            'type': 'unknown'
        }
    }
    assert g.detect_type_media(interfaces)['eth0']['type'] == 'unknown'

# Generated at 2022-06-11 03:23:53.974419
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # FIXME: see if we can run this off a file instead of a string
    ifconfout = """inet 127.0.0.1 netmask 0xff000000
inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2
inet6 ::1 prefixlen 128
nd6 options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>
"""

# Generated at 2022-06-11 03:24:04.165631
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network_getter = GenericBsdIfconfigNetwork()
    network_getter.module = module
    rc, out, err = module.run_command([network_getter.route_path, '-n', 'get', 'default'])
    if not out:
        module.fail_json(msg="Cannot get default interface's IP, please check if route command is available")

    rc, out, err = module.run_command([network_getter.route_path, '-n', 'get', '-inet6', 'default'])
    if not out:
        module.fail_json(msg="Cannot get default interface's IP (in IPv6), please check if route command is available")


# Generated at 2022-06-11 03:24:13.578204
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    _platform = "BSD"
    _module = Mock()
    _module.run_command = Mock(return_value=(0, '', ''))
    _module.get_bin_path = Mock(return_value="/sbin/ifconfig")
    _module.socket = Mock()
    _module.socket.has_ipv6 = Mock(return_value=True)

    inst = GenericBsdIfconfigNetwork(module=_module, platform=_platform)

    # test on DragonflyBSD (uses the BSD method)
    inst.populate()
    _module.run_command.assert_any_call(['/sbin/ifconfig', '-a'])

    # test on Mac (uses the BSD method)
    inst.populate()

# Generated at 2022-06-11 03:24:22.414363
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    _net = GenericBsdIfconfigNetwork()
    defaults = {
        'interface': 'tun0'
    }
    ifinfo = {
        'tun0': {
            'ipv4': [
                {'address': '10.0.0.1'},
                {'address': '10.0.0.2'}
            ],
            'ipv6': [
                {'address': '2001:db8::1'},
                {'address': '2001:db8::2'}
            ],
            'media': 'media',
            'options': ['option']
        }
    }
    _net.merge_default_interface(defaults, ifinfo, 'ipv4')