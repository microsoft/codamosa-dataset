

# Generated at 2022-06-11 03:15:34.617415
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    m_iface = GenericBsdIfconfigNetwork(module)
    words = ['inet6', 'fe80::212:6dff:fea1:36db', 'prefixlen', '64',
             'scopeid', '0x2']
    ifcfg = dict(device='lo0', ipv4=[], ipv6=[])
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:15:46.682824
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    network = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-11 03:15:50.829644
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    net = GenericBsdIfconfigNetwork()
    assert net.get_options('foo <bar,baz,aa>') == ['bar', 'baz', 'aa']
    assert net.get_options('foo <>') == []
    assert net.get_options('foo') == []
    assert net.get_options('foo <bar>') == ['bar']

# Generated at 2022-06-11 03:15:57.538473
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test that we can get the right interfaces info from a BSD-like system

    gbi = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:16:08.418307
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    obj = GenericBsdIfconfigNetwork()
    assert obj.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)'], {}, {}) is None
    assert obj.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'media:', 'Ethernet', 'autoselect', '(1000baseT)'], {}, {}) is None
    assert obj.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active'], {}, {}) is None
    assert obj.parse_media_line(['media:', 'Ethernet'], {}, {}) is None

# Generated at 2022-06-11 03:16:21.010508
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-11 03:16:29.723712
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
        bc = GenericBsdIfconfigNetwork()

        current_if = {}
        ips = dict(all_ipv4_addresses=[])
        line = ["inet", "127.0.0.1", "netmask", "0xff000000"]
        bc.parse_inet_line(line, current_if, ips)
        assert(len(current_if['ipv4']) == 1)
        assert(current_if['ipv4'][0]['address'] == "127.0.0.1")
        assert(current_if['ipv4'][0]['netmask'] == "255.255.255.0")
        assert(current_if['ipv4'][0]['network'] == "127.0.0.0")

# Generated at 2022-06-11 03:16:42.049322
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:16:50.052964
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    """
    GenericBsdIfconfigNetwork - Unit test for method parse_inet_line
    """
    #######################
    # Setup test environment
    #######################
    test_object = GenericBsdIfconfigNetwork(None)

    ######################
    # Test parse_inet_line
    ######################
    # parse_inet_line(): Test #1.1 - Test missing items
    words = ['1.1.1.1', 'netmask', '0xffffff00', 'broadcast', '1.1.1.255']
    current_if = dict(ipv4=[], ipv6=[])
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    test_object.parse_inet_line(words, current_if, ips)



# Generated at 2022-06-11 03:16:55.543368
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(
        argument_spec=dict()
    )

    c = GenericBsdIfconfigNetwork(module)

    current_if = {'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['device'] = 'lagg0'
    current_if['macaddress'] = 'unknown'    # will be overwritten later
    current_if['metric'] = 0
    current_if['mtu'] = 1500
    current_if['options'] = ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    current_if['flags'] = []

    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}


# Generated at 2022-06-11 03:17:37.073382
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    iface = {'media': 'EtHEr'}
    gbn = GenericBsdIfconfigNetwork()
    gbn.detect_type_media(iface)
    assert iface['type'] == 'ether'


# Generated at 2022-06-11 03:17:39.539866
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_ansible_module_defaults('GenericBsdIfconfigNetwork', 'get_default_interfaces')

# Generated at 2022-06-11 03:17:48.923441
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = MockModule(platform_subclass='GenericBsdIfconfigNetwork')
    module.run_command = Mock(return_value=(0,'gateway: 192.168.1.1\ninterface: en0\n') )

    gen_ifconfig_network = GenericBsdIfconfigNetwork(module)

    ipv4, ipv6 = gen_ifconfig_network.get_default_interfaces('')

    assert ipv4 == {'interface': 'en0', 'gateway': '192.168.1.1'}
    assert ipv6 == {}


# Generated at 2022-06-11 03:17:54.452846
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = dict()
    words = ["media:", "Ethernet", "autoselect", "(1000baseT)", "full-duplex"]
    ans = dict(media="Ethernet", media_select="autoselect", media_type="1000baseT", media_options=["full-duplex"])
    network = GenericBsdIfconfigNetwork(None)
    network.parse_media_line(words, iface, dict())
    assert iface == ans


# Generated at 2022-06-11 03:18:06.224270
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    bsd_ifconfig_net = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:18:15.978959
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    ``test_GenericBsdIfconfigNetwork_get_default_interfaces``

    Test function for method get_default_interfaces of class GenericBsdIfconfigNetwork.
    """

    # Test 1
    test_content = [
        'default via 192.168.0.1 dev tun0 proto static'
    ]

    gbn = GenericBsdIfconfigNetwork()
    gbn.run_commands = lambda *args, **kwargs: (None, '\n'.join(test_content), None)

    network_facts = dict()

    ipv4, ipv6 = gbn.get_default_interfaces(route_path='route')
    network_facts['default_ipv4'], network_facts['default_ipv6'] = ipv4, ipv6

    ipv4_expected = dict()


# Generated at 2022-06-11 03:18:25.195756
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    networks = get_network_data('netifaces', 'BSD')
    networks_facts = GenericBsdIfconfigNetwork(dict(module=AnsibleModule(argument_spec=dict()), params=dict())).populate(collected_facts=dict(network=networks))
    for iface in networks_facts.keys():
        if 'interfaces' in iface:
            assert sorted(networks_facts[iface]) == sorted(networks[iface])
        else:
            for key in networks_facts[iface].keys():
                net_key = iface + '.' + key
                assert sorted(networks_facts[iface][key]) == sorted(networks[net_key])


# Generated at 2022-06-11 03:18:36.373841
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = "/sbin/route"
    route_output = "     192.168.0.0        172.17.5.1        UGSc           202     38     en0\n"
    route_MOC = mock_open(read_data=route_output)
    route_MOC.return_value.readline.return_value = route_output
    cmn = GenericBsdIfconfigNetwork()
    cmn.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    with patch('__main__.open', route_MOC):
        ip_info = cmn.get_default_interfaces(route_path)

# Generated at 2022-06-11 03:18:41.386042
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = NetworkModule(argument_spec=dict(),
                           supports_check_mode=True)

    # TODO: finish me
    platform = 'Generic_BSD_Ifconfig'

    network_getter = GenericBsdIfconfigNetwork(module)

    # TODO: finish me
    network_getter.merge_default_interface()



# Generated at 2022-06-11 03:18:48.806548
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()

    defaults = {
        'interface' : 'em0',
        'foo' : 'bar',
    }
    interfaces = {
        'em0': {
            'interface': 'em0',
            'foo': 'baz',
            'ipv4': [
                {
                    'address': '1.2.3.4',
                    'netmask': '255.255.255.0',
                    'network': '1.2.3.0',
                }
            ],
            'ipv6': [
                {
                    'address': '1:2:3::4',
                    'prefix': '64',
                }
            ],
        },
    }

    # test with no interface
    defaults = {}
    interfaces = {}
    network.merge_default_interface

# Generated at 2022-06-11 03:19:20.473038
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    m_path = os.path.join(fixtures_path, 'module_utils_network_bsd_ifconfig')
    with open(os.path.join(m_path, 'ifconfig_output.txt'), 'r') as f:
        output = f.read()
    code, ifconfig_path, stderr, rc_mock = None, m_path, None, 0
    ins = GenericBsdIfconfigNetwork(module)

    interfaces, ips = ins.get_interfaces_info(ifconfig_path)


# Generated at 2022-06-11 03:19:27.867689
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_module = FakeModule()
    test_class = GenericBsdIfconfigNetwork(test_module)
    test_class.module.run_command = run_commands
    test_class.module.get_bin_path = get_bin_paths

    interfaces, ips = test_class.get_interfaces_info('ifconfig', '-a')
    assert interfaces['utun0']['ipv6'][0]['address'] == '::1%lo0'
    assert interfaces['gif0']['ipv6'][0]['prefix'] == '64'
    assert interfaces['gif0']['ipv6'][0]['scope'] == 'link'

    assert interfaces['lo0']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-11 03:19:37.497502
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from collections import namedtuple
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.network import NetworkModule
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import dict_merge

    module = Mock(NetworkModule)
    module.params = dict()
    option_string = '<UP,LOOPBACK,RUNNING>'
    expected = ['UP', 'LOOPBACK', 'RUNNING']
    actual = GenericBsdIfconfigNetwork.get_options(option_string)
    assert expected == actual


# Generated at 2022-06-11 03:19:48.479024
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    mod = AnsibleModule({})

    def get_bin_path_mock(*names, **kwargs):
        bin_paths = {
            'ifconfig': 'ifconfig path',
            'route': 'route path',
        }
        for name in names:
            if name in bin_paths:
                return bin_paths[name]
        raise Exception('bin not found')

    def run_command_mock(*args, **kwargs):
        if args[0] == 'route path -n get default':
            return 0, 'route_v4_output', ''
        elif args[0] == 'route path -n get -inet6 default':
            return 0, 'route_v6_output', ''

# Generated at 2022-06-11 03:20:00.243752
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:20:11.781275
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()

    current_if = {'ipv4': []}

    # Test ip address with netmask
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, {})
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['broadcast'] == '127.255.255.255'

    # Test ip

# Generated at 2022-06-11 03:20:15.307446
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    obj = GenericBsdIfconfigNetwork(module)
    obj.populate()

# Generated at 2022-06-11 03:20:20.635360
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    gbinet = GenericBsdIfconfigNetwork()
    ifconfig_path = gbinet.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = gbinet.get_interfaces_info(ifconfig_path, ifconfig_options)
    # FIXME: provide a mock ifconfig -a output
    pass

# Generated at 2022-06-11 03:20:25.521423
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    inet6_line = '  inet6 fe80::7a41:97ff:fe32:ce91%lo0 prefixlen 64'
    words = inet6_line.split()
    current_if = {}
    ips = dict(
        all_ipv4_addresses = [],
        all_ipv6_addresses = [],
    )
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    network_module = GenericBsdIfconfigNetwork(module)
    network_module.parse_inet6_line(words, current_if, ips)
    module.run_command.assert_called_once()
    assert type(current_if['ipv6']) == list

# Generated at 2022-06-11 03:20:32.599032
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    # Assume that the test is run on FreeBSD, OpenBSD, NetBSD or macOS
    # (all BSD platforms)
    network_def = GenericBsdIfconfigNetwork()

    ifconfig_lines = [
        'inet6 fe80::2c0:41ff:fe58:c18e%lo0 prefixlen 64 scopeid 0x1 ',
        'inet6 2001:470:262a:201::f prefixlen 64 ',
        'inet6 2001:470:262a:201::f prefixlen 64 scopeid 0x2 '
    ]

    # Test line with scopeid, and complete address
    words = ifconfig_lines[0].split()
    current_if = dict(
        ipv6=[],
        type="unknown"
    )
    ips = dict(
        all_ipv6_addresses=[]
    )

# Generated at 2022-06-11 03:20:54.069173
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'type': 'loopback', 'ipv4': [{'address': '127.0.0.1'}, {'address': '127.1.1.1'}], 'ipv6': [{'address': '::1'}, {'address': 'fe80::1%lo0'}]}}
    network.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['type'] == 'loopback'
    assert defaults['address'] == '127.0.0.1'
    assert len(defaults) == 4  # Expect just these 4 items in the output


# Generated at 2022-06-11 03:21:04.355804
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module_name = "ansible_collections.t_systems.os_facts.plugins.network.generic_bsd_ifconfig"
    test_module = importlib.import_module(module_name + '.GenericBsdIfconfigNetwork')

    # test case #1
    option_string = "0x0<UP,LOOPBACK,RUNNING>"
    expected_result = ["UP", "LOOPBACK", "RUNNING"]
    actual_result = test_module.GenericBsdIfconfigNetwork.get_options(option_string)
    assert expected_result == actual_result

    # test case #2
    option_string = "UP,LOOPBACK,RUNNING"
    expected_result = ["UP", "LOOPBACK", "RUNNING"]
    actual_result = test_module.GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:13.020832
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test where we have / in the address
    test_data = dict(
        words=['inet6', 'fe80::5cba:5aff:fee0:9bdb%ne0', 'prefixlen', '64', 'scopeid', '0x2'],
        current_if=dict(),
        ips=dict(
           all_ipv6_addresses=[],
        ),
    )

    test_obj = GenericBsdIfconfigNetwork()
    test_obj.parse_inet6_line(**test_data)
    assert test_data['ips']['all_ipv6_addresses'] == ['fe80::5cba:5aff:fee0:9bdb%ne0']

# Generated at 2022-06-11 03:21:24.100289
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    generic_bsd_network = GenericBsdIfconfigNetwork(module)

    # test with a well formed line of output from ifconfig
    facts = {}
    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )
    line = 'inet6 fe80::20c:29ff:fe66:f0da%igb1 prefixlen 64 scopeid 0x2'
    words = line.split(' ')
    generic_bsd_network.parse_inet6_line(words, current_if, ips)
    assert current_if == {}

# Generated at 2022-06-11 03:21:27.704966
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network = GenericBsdIfconfigNetwork()
    return_value = network.get_default_interfaces(route_path)
    print("default interface IPv4: %s" % return_value[0])
    print("default interface IPv6: %s" % return_value[1])


# Generated at 2022-06-11 03:21:38.594548
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:50.299946
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ansible = AnsibleModule(
        argument_spec = dict(),
    )

    defaults = {'interface': 'em0'}
    interfaces = {
        'em0': {
            'ipv4': [{'address': '192.168.0.1', 'netmask': '192.168.0.0', 'broadcast': '192.168.255.255'}],
            'ipv6': [],
            'macaddress': '00:11:22:33:44:55',
            'device': 'em0',
            'type': 'ether',
            'flags': ['BROADCAST', 'MULTICAST', 'UP', 'LOWER_UP'],
            'mtu': '1500'
        }
    }
    fn = GenericBsdIfconfigNetwork.merge_default_interface
    fn

# Generated at 2022-06-11 03:21:57.413903
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import sys
    import json

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    path_to_this_file = os.path.dirname(os.path.realpath(__file__))

    with open(path_to_this_file + '/' + 'test_data/test_ifconfig.txt', 'r') as f:
        ifconfig = f.read()
        if sys.version_info > (3,):
            ifconfig = ifconfig.encode('utf-8')

    with open(path_to_this_file + '/' + 'test_data/test_netstat.txt', 'r') as f:
        netstat = f.read()
        if sys.version_info > (3,):
            netstat = netstat.encode('utf-8')

# Generated at 2022-06-11 03:22:06.051380
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    facts = BaseNetwork()

    current_if = {'device': "lo0", 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    ips = {
        "all_ipv4_addresses": [],
        "all_ipv6_addresses": [],
    }

    # ipv4 address with netmask
    words = [
        "lo0",
        "inet",
        "127.0.0.1",
        "netmask",
        "0xff000000"
    ]
    facts.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['address'] == "127.0.0.1"
    assert current_if

# Generated at 2022-06-11 03:22:17.852132
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    # Test that passing no arguments returns a dict with
    # `interfaces` but no other keys
    platform = GenericBsdIfconfigNetwork()
    result = platform.populate()
    interfaces = result['interfaces']
    assert len(interfaces) > 0
    assert len(result) == 1

    # Test that passing an empty list returns a dict with
    # `interfaces` but no other keys
    platform = GenericBsdIfconfigNetwork()
    result = platform.populate(collected_facts=[])
    interfaces = result['interfaces']
    assert len(interfaces) > 0
    assert len(result) == 1

    # Test that passing an list containing only the
    # `default_ipv4` key returns a dict with `interfaces` but
    # no other keys
    collected_facts

# Generated at 2022-06-11 03:22:49.241979
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    result = {
        'device': 'eth0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown'
    }

    GenericBsdIfconfigNetwork.parse_media_line(['media:', 'Ethernet', '10Gbase-CR', '(none)'], result, {})
    assert result['type'] == 'ether'
    assert result['media'] == 'Ethernet'
    assert result['media_select'] == '10Gbase-CR'
    assert result['media_type'] == 'none'
    assert result['media_options'] == []

    result['type'] = 'unknown'
    GenericBsdIfconfigNetwork.parse_media_line(['media:', 'Ethernet', '10Gbase-SR'], result, {})
    assert result['type']

# Generated at 2022-06-11 03:22:54.637850
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    """Method populate of class GenericBsdIfconfigNetwork"""
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    networking = GenericBsdIfconfigNetwork(module)
    facts = networking.populate()
    assert facts

# Generated at 2022-06-11 03:23:02.300481
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    _defaults = dict(interface='bge0', gateway='192.168.1.1')
    _interfaces = dict(bge0=dict(interface='bge0', ipv4=list(), ipv6=list()))
    _interfaces['bge0']['ipv4'].append(dict(address='192.168.1.2', netmask='255.255.255.0'))
    c = GenericBsdIfconfigNetwork()
    c.merge_default_interface(_defaults, _interfaces, 'ipv4')


# Generated at 2022-06-11 03:23:08.094524
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Arrange
    network = GenericBsdIfconfigNetwork()
    ifconfig_path = ''
    ifconfig_options = '-a'

    # Act
    interfaces, ips = network.get_interfaces_info(ifconfig_path=ifconfig_path, ifconfig_options=ifconfig_options)

    # Assert
    assert type(interfaces) == dict
    assert type(ips) == dict

# Generated at 2022-06-11 03:23:18.457250
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = Mock()

    # ifconfig_path = self.module.get_bin_path('ifconfig')
    module.get_bin_path.return_value = 'ifconfig'

    # if ifconfig_path is None:
    #     return network_facts
    module.get_bin_path.return_value = None
    gbin = GenericBsdIfconfigNetwork(module)
    assert(gbin.populate() == {})

    # route_path = self.module.get_bin_path('route')
    module.get_bin_path.return_value = 'route'
    module.run_command.return_value = 3, '', 'err'

    gbin = GenericBsdIfconfigNetwork(module)
    assert(gbin.populate() == {})

    # default_ipv4, default_ip

# Generated at 2022-06-11 03:23:27.304863
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    """
    Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork.
    """
    sample_words = [
        'lo0:', 'flag=8049', 'metric=0', 'mtu=33184',
        'inet', '127.0.0.1', 'netmask', '0xff000000',
    ]
    network_module_instance = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network_module_instance.parse_inet_line(sample_words, current_if, ips)
    assert current_if

# Generated at 2022-06-11 03:23:39.575705
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    fact = GenericBsdIfconfigNetwork()
    ifconfig_path = fact.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return {}

    route_path = fact.module.get_bin_path('route')

    if route_path is None:
        return {}

    default_ipv4, default_ipv6 = fact.get_default_interfaces(route_path)
    interfaces, ips = fact.get_interfaces_info(ifconfig_path)
    interfaces = fact.detect_type_media(interfaces)

    fact.merge_default_interface(default_ipv4, interfaces, 'ipv4')
    fact.merge_default_interface(default_ipv6, interfaces, 'ipv6')
    assert('interfaces' in interfaces)
   

# Generated at 2022-06-11 03:23:49.273856
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    module = AnsibleModule(argument_spec={})
    interfaces = {
        'lo0': {'media': 'ether'},
        'lo2': {'media': 'unknown'},
        'lo1': {'media': 'ether', 'type': 'lo'},
        'lo3': {'media': 'Ether'}
    }
    network_module = GenericBsdIfconfigNetwork(module)
    interfaces_mod = network_module.detect_type_media(interfaces)

# Generated at 2022-06-11 03:24:01.529029
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())
    if_module = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'eth'}
    words = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184\ninet 192.168.0.0 netmask 0xff000000'.split()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    if_module.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1

# Generated at 2022-06-11 03:24:07.650140
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class MockModule(object):
        pass
    module = MockModule()
    n = GenericBsdIfconfigNetwork(module)
    assert n.get_options('<UP,LOOPBACK,RUNNING,MULTICAST>') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert n.get_options('options=<UP,LOOPBACK,RUNNING,MULTICAST>') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

