

# Generated at 2022-06-11 03:15:48.364421
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_if = dict(
        device="lo0",
        ipv4=[],
        ipv6=[],
        type="unknown"
    )
    expected_ipv6 = dict(
        address="fe80::1%lo0"
    )
    expected_test_if = dict(
        device="lo0",
        ipv4=[],
        ipv6=[expected_ipv6],
        type="unknown"
    )
    test = GenericBsdIfconfigNetwork()
    result_test_if = test.parse_inet6_line(["inet6", "fe80::1%lo0", "prefixlen", "64", "scopeid", "0x2"], test_if, dict(all_ipv4_addresses=[], all_ipv6_addresses=[]))
    assert result_test_if

# Generated at 2022-06-11 03:15:59.970877
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = mock.MagicMock()

# Generated at 2022-06-11 03:16:11.593014
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    # Setup object
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    words = ['inet', '127.0.1.1', 'netmask', '0x000000ff']
    address_expected = {'address': '127.0.1.1', 'netmask': '0.0.0.255'}
    generic_bsd_ifconfig_network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == address_expected['address']
    assert current_if['ipv4'][0]['netmask'] == address_expected['netmask']
    assert ips['all_ipv4_addresses'] == ['127.0.1.1']

   

# Generated at 2022-06-11 03:16:23.793894
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = FakeModule('Generic_BSD_Ifconfig', 'network')
    platform = GenericBsdIfconfigNetwork()

    # test with
    #   em0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
    #       options=b<RXCSUM,TXCSUM,VLAN_MTU>
    #       ether 00:1c:42:c2:3c:7f
    #       inet 192.168.1.27 netmask 0xffffff00 broadcast 192.168.1.255
    #       nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>

# Generated at 2022-06-11 03:16:34.292053
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    iface_fixture = '''
default: gateway: 192.168.1.1 interface: em0
default: gateway: ::1 interface: em0
'''

# Generated at 2022-06-11 03:16:42.445001
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    my_module = MyModule()
    my_module.run = MagicMock(return_value=(0, 'foobar', ''))
    platform = 'Generic_BSD_Ifconfig'
    module_path = 'ansible.modules.network.{}'.format(platform)
    network_module = my_module.load_platform_subclass(platform, module_path)
    network_module.populate(collected_facts=None)
    my_module.run.assert_called_with([network_module.get_bin_path('ifconfig'), '-a'])


# Generated at 2022-06-11 03:16:50.325766
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class module_mock:
        class run_command:
            @staticmethod
            def return_value():
                return 0, "", ""
    module_mock.get_bin_path = lambda x: "/sbin/{}".format(x)
    n = GenericBsdIfconfigNetwork(module_mock())

    # Prepare route stub
    def side_effect(args):
        if args == ['route', '-n', 'get', 'default']:
            return 0, "default: gateway: 192.0.2.254\n       interface: en0\n       local addr: 192.0.2.1\n", ""

# Generated at 2022-06-11 03:16:55.678376
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network_module = GenericBsdIfconfigNetwork(module=AnsibleModule(argument_spec=dict()))

# Generated at 2022-06-11 03:16:59.724934
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options = GenericBsdIfconfigNetwork.get_options("<UP,BROADCAST,RUNNING,MULTICAST>")
    assert options == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
        

# Generated at 2022-06-11 03:17:06.217294
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test = GenericBsdIfconfigNetwork()
    results = test.get_default_interfaces('/bin/true')
    assert results == ({}, {})
    results = test.get_default_interfaces('/bin/false')
    assert results == ({}, {})
    results = test.get_default_interfaces('/bin/ls')
    assert results == ({}, {})
    results = test.get_default_interfaces('/bin/cat')
    assert results == ({}, {})


# Generated at 2022-06-11 03:17:14.747101
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-11 03:17:18.852266
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    mock_module = Mock()
    mock_module.run_command.return_value = (0,'')
    network = GenericBsdIfconfigNetwork(mock_module)
    assert network.get_interfaces_info('ifconfig -a') == ({}, dict(all_ipv4_addresses=[], all_ipv6_addresses=[]))


# Generated at 2022-06-11 03:17:28.158712
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Test with FreeBSD
    words = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'.split()
    gbin = GenericBsdIfconfigNetwork()
    result = gbin.parse_interface_line(words)
    expected = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'loopback',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        'metric': '0',
        'mtu': '16384',
        'macaddress': 'unknown',
    }
    assert result == expected

# Generated at 2022-06-11 03:17:40.172562
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:52.218992
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.network.common.net_tools.ifconfig import Interface
    from ansible.module_utils.network.common.net_tools.ifconfig import IPv4Interface
    from ansible.module_utils.network.common.net_tools.ifconfig import IPv6Interface
    from ansible.module_utils.network.common.net_tools.ifconfig import InetInterface

    def create_interfaces(value):
        interfaces = {}
        for key in value:
            if key == 'get_interfaces_info':
                continue

            current_if = value[key]['interface']
            interfaces[current_if['device']] = current_if

# Generated at 2022-06-11 03:18:02.351233
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = type('module', (object,), {
        'get_bin_path': lambda self, cmd: '/sbin/%s' % cmd,
        'run_command': lambda self, args: (0, 'The cow says moo', '')
    })()
    m_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(module)
    facts = m_GenericBsdIfconfigNetwork.populate()

    assert facts['default_ipv4'] == {'address': 'The cow', 'broadcast': 'moo'}

# Unit test suite for GenericBSDIfconfigNetwork class
test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-11 03:18:11.901209
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network_module = generic_bsd_ifconfig.GenericBsdIfconfigNetwork()
    # Test that a broadcast address is known when not specified
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'mtu': '16384', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'type': 'unknown', 'metric': '0', 'macaddress': 'unknown'}

# Generated at 2022-06-11 03:18:23.618166
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def populate(self, detected_facts=None):
            pass
    testobj = TestGenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:18:34.318065
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    '''
    Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
    '''
    blank_if = {'device': 'interface', 'ipv4':[], 'ipv6':[]}
    interfaces = {'interface': blank_if}

    defaults = {}
    way_more_specific_if = {'device':'interface', 'ipv4':[], 'ipv6':[]}

    address_new = dict(address='1.2.3.4')
    address_old = dict(address='5.6.7.8')
    way_more_specific_if['ipv4'] = [address_new, address_old]

    interfaces['interface'] = way_more_specific_if

    _network = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:18:44.710423
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    with patch('os.path.exists', return_value=True):
        module = AnsibleModule(argument_spec={})
        network = GenericBsdIfconfigNetwork(module)
        ifconfig_data = open(
            'testdata/GenericBsdIfconfigNetwork_get_interfaces_info.data', 'rb'
        ).read()
        interfaces, ips = network.get_interfaces_info(None, ifconfig_options='-a')
        ifconfig_output_lines = ifconfig_data.split(b'\n')
        for line in ifconfig_output_lines:
            words = line.split()
            if len(words) == 0:
                continue
            if words[0] == b'Options:':
                continue

# Generated at 2022-06-11 03:19:03.809197
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json

    my_object = GenericBsdIfconfigNetwork(module)
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:19:15.529971
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    '''Support method, needs testing.'''
    interface_dict = {
        'lo0': {'type': 'ether'},
        'path0': {'type': 'ether'},
        'em0': {'type': 'ether'},
        'em1': {'type': 'ether'},
        'em2': {'type': 'ether'},
        'em3': {'type': 'ether'},
        'fw0': {'type': 'ether'},
    }

# Generated at 2022-06-11 03:19:25.625750
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
  module = AnsibleModule(argument_spec={})
  ifconfig_path = 'tests/ifconfig_stdout.txt'
  route_path = 'tests/route_stdout.txt'

# Generated at 2022-06-11 03:19:36.736694
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    mocker = Mocker()

    # Mock 'openbsd_ifconfig_network.GenericBsdIfconfigNetwork' class.
    mock_platform = mocker.mock()
    mock_platform.platform = 'OpenBSD'

# Generated at 2022-06-11 03:19:46.329660
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    client = GenericBsdIfconfigNetwork(module)

    assert client.populate() == {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
        'default_ipv4': {},
        'default_ipv6': {},
        'interfaces': []
    }


# Generated at 2022-06-11 03:19:51.110182
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_object = GenericBsdIfconfigNetwork()
    test_object.module = MagicMock()
    test_object.module.run_command.return_value = (0, 'default via 192.0.2.1 dev em1\n', '')
    test_object.get_default_interfaces(None)
    assert test_object.module.run_command.call_count == 1

# Generated at 2022-06-11 03:20:00.919813
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from nose import SkipTest
    module = AnsibleModule({}, supports_check_mode=True)

    if platform.system() == 'FreeBSD':
        raise SkipTest()

    # TODO: Test on other platforms (OpenBSD, NetBSD, MacOS, Solaris, etc.)

    option_string = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    network_facts = GenericBsdIfconfigNetwork(module)
    options = network_facts.get_options(option_string)

    assert options == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']



# Generated at 2022-06-11 03:20:12.283222
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Setup parameters for test
    ifconfig_path = 'NetIfConfig/ifconfig'
    ifconfig_options = '-a'
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ["lo0", "inet", 'alias', "127.1.1.1", "netmask", "0xff000000"]

    # Test first use case
    network_facts = GenericBsdIfconfigNetwork()
    network_facts.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:20:19.343464
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    if_config_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'FreeBSD_ifconfig')

    gb = GenericBsdIfconfigNetwork()
    gb.module = AnsibleModuleMock()
    gb.run_command = CommandMock(
        rc=0,
        stdout=read_file_content(if_config_path),
        err=None,
        stderr=None)

    expected_ifconfig_path = gb.module.get_bin_path('ifconfig')

    interfaces, ips = gb.get_interfaces_info(expected_ifconfig_path)


# Generated at 2022-06-11 03:20:22.818039
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Test if method network.GenericBsdIfconfigNetwork.populate() exists
    network_obj = GenericBsdIfconfigNetwork()
    assert callable(network_obj.populate)


# Generated at 2022-06-11 03:20:51.130186
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Given
    defaults = {
        'interface' : 'em0',
        'address' : '192.168.1.1',
    }


# Generated at 2022-06-11 03:20:57.312074
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = NetworkModule({})
    module.run_command = MagicMock(return_value=[0, '', ''])
    ifconfig_path = module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return None

    obj = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-11 03:21:07.645574
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:14.578689
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    iface1 = {
        'device': 'lo0',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        'ipv4': [],
        'ipv6': [],
        'macaddress': '00:00:00:00:00:00',
        'options': ['8D', 'ROUTETABLES=2', 'ROUTETABLE=220'],
        'status': 'active',
        'type': 'loopback'
    }

    # For FreeBSD

# Generated at 2022-06-11 03:21:19.526819
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from ansible_collections.gerg.network.plugins.modules.network_cli.generic_bsd import GenericBsdIfconfigNetwork

    module = GenericBsdIfconfigNetwork()

    options = module.get_options('<UP,BROADCAST,LOOPBACK>')

    assert options == ['UP', 'BROADCAST', 'LOOPBACK']

# Generated at 2022-06-11 03:21:29.216437
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    m = GenericBsdIfconfigNetwork()
    m.module.params = {}
    m.module.params['path'] = aix_path
    m.module.params['gather_subset'] = []
    result = m.populate()
    if result is not None:
        assert 'default_ipv4' in result
        assert 'default_ipv6' in result
        assert 'all_ipv4_addresses' in result
        assert 'all_ipv6_addresses' in result
        assert 'interfaces' in result
        assert 'en1' in result
        assert 'lo0' in result
        if 'en1' in result:
            assert 'ipv4' in result['en1']
            assert 'ipv6' in result['en1']
            assert 'type' in result['en1']


# Generated at 2022-06-11 03:21:41.582087
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    host_setup = HostSetupTest()
    host_setup.setup()
    module = FakeAnsibleModule(host_setup.connector)
    gbsdifconf = GenericBsdIfconfigNetwork(module)
    facts = gbsdifconf.populate()
    assert facts['default_ipv4']['interface'] == 'en1'
    assert facts['default_ipv4']['address'] == '10.0.0.175'
    assert facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert facts['default_ipv4']['network'] == '10.0.0.0'
    assert facts['default_ipv4']['broadcast'] == '10.0.0.255'

# Generated at 2022-06-11 03:21:46.802511
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    gbi = GenericBsdIfconfigNetwork()
    int_line = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if = gbi.parse_interface_line(int_line)
    assert current_if['device'], 'lo0'
    assert current_if['flags'], ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['metric'], '0'
    assert current_if['mtu'], '33184'

# Generated at 2022-06-11 03:21:55.942875
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from collections import OrderedDict
    from io import StringIO

    network = GenericBsdIfconfigNetwork()
    defaults = OrderedDict()
    defaults['interface'] = 'em1'
    defaults['gateway'] = '192.0.2.1'
    defaults['address'] = '192.0.2.2'

    interfaces = OrderedDict()

    em1 = OrderedDict()
    em1['device'] = 'em1'
    em1['mtu'] = '1500'
    em1['ipv4'] = [{'address': '192.0.2.1'}, {'address': '192.0.2.2'}]
    interfaces['em1'] = em1

    network.merge_default_interface(defaults, interfaces, 'ipv4')


# Generated at 2022-06-11 03:22:05.266418
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.network.common.utils import dict_merge
    bsd_ifconfig = GenericBsdIfconfigNetwork()

    # test setup
    test_ifconfig_path = 'ifconfig'
    test_ifconfig_options = '-a'

    # test input
    test_interfaces = {}
    test_current_if = {}
    test_ips = dict(all_ipv4_addresses=[],
                    all_ipv6_addresses=[],
                    )

    # test data
    test_line = ''

    # test output
    test_interfaces_out = {}
    test_current_if_out = {}
    test_ips_out = dict(all_ipv4_addresses=[],
                        all_ipv6_addresses=[],
                        )

# Generated at 2022-06-11 03:22:42.549167
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # case 1:
    # inet 10.0.0.1 netmask 0xfffff800 broadcast 10.0.31.255
    words = ['inet', '10.0.0.1', 'netmask', '0xfffff800', 'broadcast', '10.0.31.255']
    current_if = {'device': 'eth0'}
    ips = dict(all_ipv4_addresses=[])

    # result:
    # { 'address': '10.0.0.1',
    #   'broadcast': '10.0.31.255',
    #   'netmask': '255.255.248.0',
    #   'network': '10.0.0.0'
    # }

# Generated at 2022-06-11 03:22:54.099697
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gb = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'eth0', 'address': '1.1.1.1'}
    interfaces = {'eth0': {'ipv4': [{'address': '1.1.1.1', 'netmask': '255.255.255.0', 'network': '1.1.1.0', 'broadcast': '1.1.1.255'}, {'address': '2.2.2.2', 'netmask': '255.255.255.0', 'network': '2.2.2.0', 'broadcast': '2.2.2.255'}], 'ipv6': [], 'mtu': '1500', 'macaddress': '00:11:22:33:44:55', 'device': 'eth0'}}

    ip

# Generated at 2022-06-11 03:23:05.023804
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:23:15.566155
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    gb = GenericBsdIfconfigNetwork()
    # test for inet line
    line = "lo0: flags=8049 <UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 33184"
    words = line.split()
    current_if = gb.parse_interface_line(words)
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    line = "inet 127.0.0.1 netmask 0xff000000"
    words = line.split()
    gb.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1, "lo0 has 1 ipv4: 127.0.0.1"
    assert current_

# Generated at 2022-06-11 03:23:25.152177
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    # Unit tests for class GenericBsdIfconfigNetwork.merge_default_interface
    # Generated using python -m pytest -v tests/unit/module_utils/network/f5/test_bigip_facts.py::test_GenericBsdIfconfigNetwork_merge_default_interface

    ipv4_default = {
        "address": "192.168.1.11",
        "netmask": "255.255.255.0",
        "network": "192.168.1.0",
        "broadcast": "192.168.1.255",
        "interface": "en0"
    }
    ipv6_default = {
        "address": "::1",
        "prefix": "128",
        "scope": "0x10",
        "interface": "lo0"
    }
    interfaces

# Generated at 2022-06-11 03:23:31.710178
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    assert_equal(parse_inet6_line(["fe80::1%lo0"], {}), {})

    assert_equal(parse_inet6_line(["inet6", "fe80::1%lo0", "prefixlen", "64", "scopeid", "0x2"], {}), {'ipv6': [{'address': 'fe80::1',
                                                                                                              'prefix': '64',
                                                                                                              'scope': '0x2'}]})

# Generated at 2022-06-11 03:23:43.335364
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    g = GenericBsdIfconfigNetwork('/sbin/ifconfig')

# Generated at 2022-06-11 03:23:51.794436
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:24:03.467571
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = get_module()
    gen_bsd_ifconfig_net = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    # test that method parses inet6 line starting with a link-local address

# Generated at 2022-06-11 03:24:12.586402
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
        def get_bin_path(self, *args, **kwargs):
            return ""
        def run_command(self, *args, **kwargs):
            class MockRunCommand(object):
                def __init__(self, *args, **kwargs):
                    self.rc = 0
                    self.stderr = ""
                    self.args = args
                def __call__(self, *args, **kwargs):
                    return (self.rc, '', self.stderr)
            return MockRunCommand(*args, **kwargs)

    # Test case for route -n get default command
    def test_command_route_n_get_default():
        test_obj = MockModule()