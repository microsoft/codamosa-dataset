

# Generated at 2022-06-11 03:15:15.653718
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-11 03:15:28.165186
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    
    # Test 1
    words = ['dummy0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu 1500', 'inet 1.1.1.1', 'netmask 0xffffff00', 'broadcast 1.1.1.255']
    current_if = {'device': 'dummy0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:15:34.936173
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    module = AnsibleModule({})
    net_obj = GenericBsdIfconfigNetwork(module)

    defaults = {'interface': 'eth01'}
    interfaces = {
        'eth01': {
            'ipv4': [{'a': 1}],
            'ipv6': [{'b': 2}]
        }
    }

    net_obj.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['a'] == 1


# Generated at 2022-06-11 03:15:46.915544
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    ut = AnsibleModuleTestUnit(GenericBsdIfconfigNetwork)

    # set up the basic class


# Generated at 2022-06-11 03:15:53.372799
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # create an object
    obj = GenericBsdIfconfigNetwork()

    # put a standard interface into the interfaces dictionary
    default_ipv4 = {'interface':'em0'}
    interfaces = {'em0':{'ipv4':['ipv4'], 'ipv6':['ipv6']}}

    # call the method
    obj.merge_default_interface(default_ipv4, interfaces, 'ipv4')

    # check that the interface values were copied
    assert('ipv4' not in default_ipv4)
    assert('ipv6' not in default_ipv4)


# Generated at 2022-06-11 03:16:03.116256
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(module)
    ifconfig_path = test_GenericBsdIfconfigNetwork.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return

    route_path = test_GenericBsdIfconfigNetwork.module.get_bin_path('route')

    if route_path is None:
        return

    test_GenericBsdIfconfigNetwork.module.run_command = MagicMock()
    mock_xtuple = (0, '', '')

    test_GenericBsdIfconfigNetwork.module.run_command.return_value = mock_xtuple

# Generated at 2022-06-11 03:16:15.409207
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options = GenericBsdIfconfigNetwork.get_options("<UP,LOOPBACK>")
    assert options == ['UP', 'LOOPBACK']
    options = GenericBsdIfconfigNetwork.get_options("<UP>")
    assert options == ['UP']
    options = GenericBsdIfconfigNetwork.get_options("<LOOPBACK>")
    assert options == ['LOOPBACK']
    options = GenericBsdIfconfigNetwork.get_options("<UP,LOOPBACK,")
    assert options == ['UP', 'LOOPBACK', '', '']
    options = GenericBsdIfconfigNetwork.get_options("<LOOPBACK,UP>")
    assert options == ['LOOPBACK', 'UP']
    options = GenericBsdIfconfigNetwork.get_options("UP,LOOPBACK>")
    assert options == []
   

# Generated at 2022-06-11 03:16:26.547076
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork"""
    # - methods of class GenericBsdIfconfigNetwork
    def network_facts(self, collected_facts=None):
        """
        When using platform Unix and if in the module path is
        the application ifconfig, this function return the
        interfaces and ipv4, ipv6 and mac addresses.
        It also set the default_ipv4 and default_ipv6 facts with the
        default interfaces.
        """

        network_facts = {}
        ifconfig_path = self.module.get_bin_path('ifconfig')

        if ifconfig_path is None:
            return network_facts

        interfaces, ips = self.get_interfaces_info(ifconfig_path)
        interfaces = self.detect_type_media(interfaces)



# Generated at 2022-06-11 03:16:36.660997
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network = GenericBsdIfconfigNetwork()
    network.module = MagicMock()
    network.module.run_command = MagicMock()
    network.module.run_command.return_value = (0, "", "")
    network.module.get_bin_path = MagicMock()
    network.module.get_bin_path.return_value = ""

    expected = {'default_ipv6': {}, 'all_ipv6_addresses': [], 'all_ipv4_addresses': [], 'interfaces': [], 'default_ipv4': {}}
    result = network.populate()
    assert expected == result



# Generated at 2022-06-11 03:16:46.346027
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:08.687369
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = ansible_module_create()

    ifconfig_path = module.get_bin_path('ifconfig')

    text = open(ifconfig_path, 'r').readlines()

    gbi = GenericBsdIfconfigNetwork()

    interfaces, ips = gbi.get_interfaces_info(ifconfig_path)

    assert len(interfaces) > 1
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0


# Generated at 2022-06-11 03:17:14.978644
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interface = dict(media='Ethernet autoselect (1000baseT <full-duplex>)')
    expected = {'media': 'Ethernet autoselect (1000baseT <full-duplex>)', 'type': 'ether'}
    module = MagicMock(AnsibleModule)
    module.params = {}
    module.return_value = False
    module.run_command = MagicMock(side_effect=run_command)
    parser = GenericBsdIfconfigNetwork(module)
    assert parser.detect_type_media(interface) == expected

# Generated at 2022-06-11 03:17:21.947486
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({}, {}, True, TestAnsibleModuleNetwork())
    module.check_mode = False

    fixtures = {
        'route get': '''
default: gateway: 192.168.1.1 interface: en0
default: gateway: fe80::d9f9:974b:a77d:2562%en0 interface: en0
        '''
    }


# Generated at 2022-06-11 03:17:23.411631
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    GenericBsdIfconfigNetwork._get_default_interfaces()

# Generated at 2022-06-11 03:17:28.010176
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = Mock(return_value=(0, GENERIC_BSD_IFCONFIG_NETWORK_OUTPUT, ''))
    GenericBsdIfconfigNetwork(module).get_interfaces_info(ifconfig_path='/sbin/ifconfig')

    module.run_command.assert_called_with(['/sbin/ifconfig', '-a'])

# Generated at 2022-06-11 03:17:38.512591
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModuleMock()
    network = GenericBsdIfconfigNetwork(module)
    network.get_default_interfaces = MagicMock()
    network.get_interfaces_info = MagicMock()
    network.detect_type_media = MagicMock()
    network.merge_default_interface = MagicMock()
    expected = dict()

    actual = network.populate()

    assertEqual(actual, expected)
    assertTrue(network.get_default_interfaces.called)
    assertTrue(network.get_interfaces_info.called)
    assertTrue(network.detect_type_media.called)
    assertTrue(network.merge_default_interface.called)

# Generated at 2022-06-11 03:17:50.946511
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    # tests the function get_default_interfaces of class GenericBsdIfconfigNetwork
    :param self:
    :return:
    """
    ######################################################################
    # TODO: add IPv6 related test cases
    ######################################################################
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork()

    # Tests for BSD-like platforms only

# Generated at 2022-06-11 03:18:03.032913
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    print ("TestGenericBsdIfconfigNetwork.test_GenericBsdIfconfigNetwork_populate: begin")

    class TestGenericBsdIfconfigNetwork():

        platform = 'testplatform'

        def get_bin_path(self, name):
            return 'ifconfig'


# Generated at 2022-06-11 03:18:09.364528
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # pylint: disable=line-too-long
    # Tests for FreeBSD ifconfig -a output.
    ifconfig_results = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
        options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
        groups: lo"""


# Generated at 2022-06-11 03:18:14.571155
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    option_string = 'flags=<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>'
    assert network.get_options(option_string) == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']



# Generated at 2022-06-11 03:18:33.756120
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    exp_output = {'a-device': {'ipv4': [], 'ipv6': [], 'type': 'unknown', 'device': 'a-device', 'macaddress': 'aa:bb:cc:dd:ee:ff', 'media': 'ieee802.11', 'media_select': 'autoselect', 'media_type': 'IEEE802.11', 'media_options': ['wpa']}}
    input_words = ['ieee802.11', 'autoselect', 'IEEE802.11', '(wpa)']
    interface = {'device': 'a-device', 'macaddress': 'aa:bb:cc:dd:ee:ff'}
    network = GenericBsdIfconfigNetwork()
    network.parse_media_line(input_words, interface, {})

# Generated at 2022-06-11 03:18:44.240264
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gm = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:18:55.925711
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    g = GenericBsdIfconfigNetwork()
    # build a test object for the method to use
    interfaces = dict(
        interface1=dict(
            device='interface1',
            media='Ether',
        ),
        interface2=dict(
            device='interface2',
            media='Loopback',
        ),
        interface3=dict(
            device='interface3',
            media='NotEther',
        ),
    )

# Generated at 2022-06-11 03:19:05.583561
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    interfaces = {}
    interface = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    interfaces[interface['device']] = interface
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    current_if = interface
    words = 'media: autoselect (1000baseT <full-duplex>)'
    words = words.split()

    modobj = GenericBsdIfconfigNetwork()
    modobj.parse_media_line(words, current_if, ips)
    assert len(current_if) == 4
    assert current_if['media'] == 'autoselect', 'Expected %s but got %s' % ('autoselect', current_if['media'])

# Generated at 2022-06-11 03:19:11.143829
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    GenericBSDIfconfigNetwork().parse_inet_line([
        'inet',
        '10.0.0.4',
        'netmask',
        '0xffffff00',
        'broadcast',
        '10.0.0.255'],
        {},
        {'all_ipv4_addresses': []})



# Generated at 2022-06-11 03:19:20.754970
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    Test for method GenericBsdIfconfigNetwork.get_default_interfaces
    """

    from ansible.module_utils import basic
    import os

    if not os.path.exists('/sbin/route'):
        pytest.skip("skipping due to missing /sbin/route")
    # TODO: create mock

    # Initialize module
    module = basic.AnsibleModule(argument_spec={})

    # TODO: add test code
    # Create object instance
    obj = GenericBsdIfconfigNetwork(module)
    obj.get_default_interfaces()



# Generated at 2022-06-11 03:19:32.840479
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)


# Generated at 2022-06-11 03:19:39.769306
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:50.014187
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    fake_module = MagicMock()
    fake_module.run_command.return_value = [0, '', '']
    fake_module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')

    module = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork(fake_module)
    current_if = dict()
    ips = dict()
    words = 'inet 192.168.0.1 netmask 0xffffff00 broadcast 192.168.0.255'.split()
    module.parse_inet_line(words, current_if, ips)


# Generated at 2022-06-11 03:20:02.784462
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Example of how this method is called, and what it should return.
    defaults = {'interface': 'em0', 'gateway': '192.168.1.1', 'broadcast': '192.168.1.255', 'netmask': '255.255.255.0'}

# Generated at 2022-06-11 03:20:32.547171
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    generic_bsd = GenericBsdIfconfigNetwork(None)
    current_if = {'ipv4': [], 'ipv6': []}
    ips = {}
    generic_bsd.parse_inet_line(("inet", "10.20.30.40", "netmask", "0xffffff00"), current_if, ips)
    assert current_if['ipv4'][0]['netmask'] == (u"255.255.255.0")
    current_if = {'ipv4': [], 'ipv6': []}
    ips = {}

# Generated at 2022-06-11 03:20:43.716489
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    current_if = generic_bsd_ifconfig_network.parse_interface_line(["lo0:"])
    words = ["inet", "127.0.0.1", "netmask", "0xff000000"]
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    generic_bsd_ifconfig_network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:20:53.569714
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import sys
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass
    from collections import namedtuple

    module = AnsibleModule({},
                           supports_check_mode=True)

    if not sys.version_info[:2] == (2, 7):
        module.fail_json("This test requires Python 2.7")


# Generated at 2022-06-11 03:21:03.997853
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pl = GenericBsdIfconfigNetwork()
    interface = {'test_interface':{
                'ipv4': [{'address': '1.2.3.4'}],
                'macaddress': 'AA:AA:AA:AA:AA:AA',
                'mtu': '1500',
                'device': 'test_interface'
                }
            }
    defaults = {'interface': 'test_interface',
                'address': '1.2.3.4'
               }
    pl.merge_default_interface(defaults, interface, 'ipv4')
    assert defaults['macaddress'] == 'AA:AA:AA:AA:AA:AA'
    assert defaults['mtu'] == '1500'
    assert defaults['device'] == 'test_interface'

# Generated at 2022-06-11 03:21:12.801131
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()

    # Ensure we won't overwrite an existing 'ipv4' or 'ipv6' key
    defaults = {'interface': 'igb0', 'ipv4': [4], 'ipv6': [6]}
    interfaces = {'igb0': {'ipv4': [4], 'ipv6': [6]}}
    net.merge_default_interface(defaults, interfaces, 'ipv4')
    net.merge_default_interface(defaults, interfaces, 'ipv6')
    assert defaults['ipv4'] == [4]
    assert defaults['ipv6'] == [6]

    defaults = {}
    interfaces = {}
    net.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-11 03:21:23.881020
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:32.652729
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    # Test the ifconfig detect_type_media function
    # Input data

# Generated at 2022-06-11 03:21:41.886215
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    testobj = GenericBsdIfconfigNetwork()
    parsed_obj = testobj.parse_inet_line(['someif:', '127.0.0.1', 'netmask', '0xffffff00'])
    assert isinstance(parsed_obj, dict)
    assert parsed_obj.get('address') == '127.0.0.1'
    assert parsed_obj.get('netmask') == '255.255.255.0'
    assert parsed_obj.get('network') == '127.0.0.0'



# Generated at 2022-06-11 03:21:48.014682
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    gbin = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    gbin.parse_inet6_line(['inet6', '::1', 'prefixlen', '128', 'scopeid', '0x10'], current_if, ips)
    assert current_if == {'ipv6': [{'address': '::1', 'prefix': '128', 'scope': '0x10'}]}


# Generated at 2022-06-11 03:21:53.821168
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ipinfo = {'address': '192.168.1.1'}
    ifinfo = {'ipv4': [ipinfo, ipinfo]}
    iface = {'interface': 'test'}
    test_class = GenericBsdIfconfigNetwork()
    test_class.merge_default_interface(iface, ifinfo, 'ipv4')
    assert iface['address'] == '192.168.1.1'

# Generated at 2022-06-11 03:22:29.855638
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # Run the populate() method
    gefn_1 = GenericBsdIfconfigNetwork()
    test_out = gefn_1.populate()

    assert test_out['default_ipv4'] == {'broadcast': '169.254.255.255', 'address': '169.254.134.26', 'netmask': '255.255.0.0'}
    assert test_out['default_ipv6'] == {'address': 'fe80::1664:ff:fe36:99cd%lagg0'}
    assert test_out['eth0']['macaddress'] == 'a4:52:6e:8b:36:99'
    assert test_out['eth0']['type'] == 'ether'


# Generated at 2022-06-11 03:22:34.799387
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    correct = {
        'interface': 'lo0',
        'gateway': 'localhost',
        'address': '127.0.0.1',
    }
    result = GenericBsdIfconfigNetwork.get_default_interfaces('route')
    assert result[0] == correct


# Generated at 2022-06-11 03:22:43.072038
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    """Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork."""
    iface = GenericBsdIfconfigNetwork()

    assert iface.parse_interface_line(['lo0', 'Link', 'encap:Local', 'Loopback', 'mtu', '33184']) == {'type': 'loopback', 'metric': 'Loopback', 'mtu': '33184', 'macaddress': 'unknown', 'device': 'lo0', 'ipv4': [], 'ipv6': [], 'flags': ['LOOPBACK', 'RUNNING']}

# Generated at 2022-06-11 03:22:54.513717
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    from ansible.module_utils.network.common.utils import dict_merge
    import sys

    g = GenericBsdIfconfigNetwork()
    a = dict(a1='a1', a2='a2')
    b = dict(b1='b1', b2='b2')

    c = g.merge_default_interface(a, {'b': b}, 'ipv4')
    print(c)
    if c != a:
        sys.exit(1)

    a = dict(interface='b')
    c = g.merge_default_interface(a, {'b': b}, 'ipv4')
    print(c)
    if dict_merge(a, b) != c:
        sys.exit(1)


# Generated at 2022-06-11 03:23:05.527038
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # test using output from DragonflyBSD 5.4.0-DEVELOPMENT
    df = GenericBsdIfconfigNetwork(module)
    result = df.populate()
    assert result
    assert result['all_ipv4_addresses']
    assert result['all_ipv6_addresses']
    assert result['default_ipv4']
    assert result['default_ipv6']
    assert result['interfaces']
    assert result['lo0']
    assert result['lo0']['mtu']
    assert result['lo0']['type'] == 'loopback'

    # test using FreeBSD 10.0-RELEASE
    fr = GenericBsdIfconfigNetwork(module)
    result = fr.populate()
    assert result

# Generated at 2022-06-11 03:23:16.087225
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:23:25.557916
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module_mock = AnsibleModuleMock()
    ifconfig_network = GenericBsdIfconfigNetwork(module=module_mock)
    current_if = {'ipv4': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # IPv4, no broadcast
    words = ['lo0:', 'inet', '127.0.0.1', 'netmask', '0xffffff00']
    ifconfig_network.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:23:36.663517
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = MagicMock()
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    # Test case 1
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    generic_bsd_ifconfig_network.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:23:45.357911
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    def mock_route_v4(module):
        return (0, 'interface: bge0\ngateway: 192.168.122.1', '')
    m = module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    # monkey patch:
    m.run_command = mock_route_v4
    ifconfig = GenericBsdIfconfigNetwork(m)
    assert ifconfig.get_default_interfaces('route') == ({'interface': 'bge0', 'gateway': '192.168.122.1'}, {})


# Generated at 2022-06-11 03:23:53.107665
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig = GenericBsdIfconfigNetwork()
    interfaces, ips = ifconfig.get_interfaces_info('/sbin/ifconfig', ifconfig_options='lo0 vlan2')
    assert len(interfaces) == 2
    assert 'lo0' in interfaces
    assert 'vlan2' in interfaces

    for interface in interfaces:
        if interface == 'lo0':
            assert interfaces[interface]['device'] == 'lo0'
            assert interfaces[interface]['mtu'] == '33184'
            assert interfaces[interface]['metric'] == '16384'
            assert len(interfaces[interface]['ipv4']) == 3

# Generated at 2022-06-11 03:24:16.048360
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
    )

    cfact = GenericBsdIfconfigNetwork(module)
    res = cfact.populate()
    assert 'default_ipv4' in res
    assert 'default_ipv6' in res


# Generated at 2022-06-11 03:24:19.649816
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    ansible = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    gbi = GenericBsdIfconfigNetwork(ansible)

    assert gbi.get_default_interfaces(route_path='route') == ({}, {})


# Generated at 2022-06-11 03:24:25.824129
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    line = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    x = generic_bsd_ifconfig_network.parse_interface_line(line)
    assert 'device' in x and x['device'] == 'em0'
    assert 'flags' in x and x['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert 'metric' in x and x['metric'] == '0'
    assert 'mtu' in x and x['mtu'] == '1500'

# Generated at 2022-06-11 03:24:35.932403
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    interfaces = dict(
        em0=dict(flags=['UP'], type=None, ipv4=[], ipv6=[]),
        em1=dict(flags=['UP'], type=None, ipv4=[], ipv6=[]),
        em2=dict(flags=['UP'], type=None, ipv4=[], ipv6=[]),
    )
    defaults = dict()

    gbif = GenericBsdIfconfigNetwork()
    gbif.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == {}

    defaults['interface'] = 'em1'
    gbif.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == interfaces['em1']


# Generated at 2022-06-11 03:24:45.632334
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
