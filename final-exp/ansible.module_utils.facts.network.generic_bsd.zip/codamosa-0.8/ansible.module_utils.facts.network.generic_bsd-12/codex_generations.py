

# Generated at 2022-06-11 03:15:30.941260
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Build a fake class for GenericBsdIfconfigNetwork with common data for unit tests
    class FakeModule:
        def run_command(self, cmd):
            return (0, '', '')

        def get_bin_path(self, cmd):
            return cmd

    class FakeNetwork:
        default_ipv4 = '';
        default_ipv6 = '';
        ALL_IP_ADDRESSES = 'all_ip_addresses'
        ALL_IPV6_ADDRESSES = 'all_ipv6_addresses'

        def __init__(self):
            self.ips = {
                'all_ipv4_addresses': [],
                'all_ipv6_addresses': [],
            }


# Generated at 2022-06-11 03:15:40.411003
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    m = GenericBsdIfconfigNetwork()
    # Test with an address that has a cidr mask in inet line
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [],
                  'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING'],
                  'macaddress': 'unknown', 'mtu': '33184'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['lo0', 'inet', '127.0.0.1', '/8']
    m.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:15:50.829924
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from collections import namedtuple

    # create mock module with given list of interfaces
    def mock_ansibleModule_init(self, *args, **kwargs):
        self.params = namedtuple('Params', ['get_bin_path'])
        self.check_mode = False
        self.debug_msg = []
        self.run_command = mock_ansibleModule_run_command

    # run_command is mocked to avoid side effect on host

# Generated at 2022-06-11 03:15:57.538185
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    ifconfig_path = module.get_bin_path('ifconfig')
    if not ifconfig_path:
        module.fail_json(msg='ifconfig executable does not exist')
    # Fake output ifconfig command in FreeBSD with ipv4 and ipv6

# Generated at 2022-06-11 03:16:06.339915
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options = GenericBsdIfconfigNetwork.get_options
    assert options('<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>') == \
        ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']
    assert options('<UP,BROADCAST,RUNNING,MULTICAST> mtu 33184') == \
        ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    assert options('<LOOPBACK,UP,LOWER_UP>') == \
        ['LOOPBACK', 'UP', 'LOWER_UP']



# Generated at 2022-06-11 03:16:19.247757
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class FakeRoutes:
        pass
    routes = FakeRoutes()
    def run_command(command, in_data=None, sudoable=True):
        if command[-1] == 'default':
            return (0, 'default: gateway 192.168.1.1', '')
        elif command[-2:] == ['-inet6', 'default']:
            return (0, 'default: gateway fe80::a5e5:5cff:fe8e:ffb1%10', '')
        else:
            raise Exception('unexpected test_GenericBsdIfconfigNetwork_get_default_interfaces command ' + str(command))
    routes.run_command = run_command
    test_facts = GenericBsdIfconfigNetwork().populate()

# Generated at 2022-06-11 03:16:21.325435
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    # XXX see test_GenericNetBSDIfconfigNetwork_get_interfaces_info_alias
    pass


# Generated at 2022-06-11 03:16:29.911991
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import pytest

    # create a mock module
    mock_module = AnsibleModule(argument_spec={})

    # constructor test
    testobj = GenericBsdIfconfigNetwork(mock_module)
    assert testobj.module == mock_module

    # get_default_interfaces test
    try:
        testobj.get_default_interfaces(route_path='/usr/sbin/route')
    except:
        pytest.fail("If route_path is passed in, no exception should be thrown")

    with pytest.raises(Exception):
        testobj.get_default_interfaces(route_path=None)

    # because we don't set defaults in the route command, the
    # results will vary with the system.  But we can test to make
    # sure the route command was run

    # TODO: This

# Generated at 2022-06-11 03:16:35.588748
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    t_class = GenericBsdIfconfigNetwork()

    assert t_class.get_default_interfaces(route_path) == ({}, {'gateway': '::ffff:10.1.1.1', 'address': '::100', 'interface': 'em0'})


# Generated at 2022-06-11 03:16:45.586909
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    default_ipv4 = {'gateway': '10.24.1.1', 'interface': 'eth0'}
    default_ipv6 = {'gateway': 'fe80::1%lo0', 'interface': 'lo0'}
    defaults = {'default_ipv4': default_ipv4,
                'default_ipv6': default_ipv6}


# Generated at 2022-06-11 03:17:04.962947
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    f = open(os.devnull, 'w')
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(dict(module=dict(run_command=lambda *args, **kwargs: (0, "", ""))), f)
    options = generic_bsd_ifconfig_network.get_options("")
    assert options == []
    options = generic_bsd_ifconfig_network.get_options("word")
    assert options == []
    options = generic_bsd_ifconfig_network.get_options("word word")
    assert options == []
    options = generic_bsd_ifconfig_network.get_options("word <options>")
    assert options == ['options']
    options = generic_bsd_ifconfig_network.get_options("word <options,here>")

# Generated at 2022-06-11 03:17:14.318844
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:21.418893
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)
    # Default values for testing

# Generated at 2022-06-11 03:17:29.647214
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # arrange
    from ansible.module_utils.network.common.utils import (
        load_provider,
        get_module
    )
    module = get_module(argument_spec = dict(),
                        supports_check_mode = False)
    provider = load_provider(module, GenericBsdIfconfigNetwork)

# Generated at 2022-06-11 03:17:40.169087
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Test with interface media_type ether
    gbn = GenericBsdIfconfigNetwork()
    current_if = {'interface': 'lo0', 'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['media:', 'Ethernet', '1000baseT', '[full-duplex]', 'status:', 'active']
    gbn.parse_media_line(words, current_if, {})
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['type'] == 'ether'

# Generated at 2022-06-11 03:17:51.524089
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class TestModule():
        def get_bin_path(self, name, opt_dirs=None):
            if 'route' in name:
                return "route"

    test = GenericBsdIfconfigNetwork(TestModule())
    out = """
default via 172.16.1.1 dev eth0
172.16.1.0/24 dev eth0  proto kernel  scope link  src 172.16.1.2
169.254.0.0/16 dev eth0  scope link  metric 1002
"""
    assert test.get_default_interfaces(out) == ({'interface': 'eth0', 'gateway': '172.16.1.1', 'address': '172.16.1.2'}, {})


# Generated at 2022-06-11 03:18:03.830408
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = {}
    interfaces = {}
    ip_type = ""

    def assert_method_returns_nothing():
        assert None is GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, ip_type)

    # Tests with no 'interface' in defaults.
    defaults = {}
    interfaces = {}
    ip_type = "ipv4"

    assert_method_returns_nothing()

    # Tests with empty interfaces dictionary.
    defaults = {'interface': ''}
    interfaces = {}
    ip_type = "ipv4"

    assert_method_returns_nothing()

    # Tests with absent key in interfaces.
    defaults = {'interface': 'eth0'}
    interfaces = {'lo0': {}}
    ip_type = "ipv4"

    assert_method_returns

# Generated at 2022-06-11 03:18:07.689103
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    ifconfig_network = GenericBsdIfconfigNetwork(module)
    result = ifconfig_network.get_default_interfaces('route')
    assert result == ({}, {}), 'the expected result was not returned'

# Generated at 2022-06-11 03:18:14.864110
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # setup some dummy data
    test_hostname = 'testhostname'
    test_domain = 'testdomain'
    test_fqdn = '.'.join([test_hostname, test_domain])
    test_data = {'ansible_facts': {'ansible_hostname': test_hostname, 'ansible_domain': test_domain, 'ansible_fqdn': test_fqdn}}

    # make sure we have fresh instances of class Network and subclasses
    from collections import namedtuple
    module = namedtuple('module', ['get_bin_path', 'run_command'])('get_bin_path', 'run_command')
    module.get_bin_path.return_value = None
    module.run_command.return_value = (0, '', '')
    # test with no path

# Generated at 2022-06-11 03:18:25.677656
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:25.662123
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_platform = 'Generic_BSD_Ifconfig'
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    test_module.params['ansible_check_mode'] = True
    test_module.params['ansible_network_os'] = test_platform
    network_module = GenericBsdIfconfigNetwork(test_module)
    test_cmd = ['route', '-n', 'get', 'default']
    test_out = ['  route to: default\n', '      destination: default\n',
                '       interface: em0\n', '       gateway: 10.0.0.1\n']
    test_rc = 0
    test_err = []
    test_res = (test_rc, test_out, test_err)

# Generated at 2022-06-11 03:19:36.735697
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    m = AnsibleModule(
        argument_spec=dict(
            foo=dict(default='bar', type='str'),
        )
    )
    m.exit_json = exit_json
    network = GenericBsdIfconfigNetwork(m)
    network.populate()

# Generated at 2022-06-11 03:19:48.076117
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    fn = GenericBsdIfconfigNetwork.get_interfaces_info
    m = MagicMock(return_value=(0, TESTCASE_IF_OUTPUT, ''))
    with patch.object(GenericBsdIfconfigNetwork, 'module') as mock:
        mock.run_command = m
        # simple test
        interfaces, ips = fn('')
        assert 'lo0' in interfaces
        assert 'flags' in interfaces['lo0'] and '' not in interfaces['lo0']['flags']
        assert 'ipv4' in interfaces['lo0']
        assert 'address' in interfaces['lo0']['ipv4'][0]
        assert 'netmask' in interfaces['lo0']['ipv4'][0]

# Generated at 2022-06-11 03:19:59.550713
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    module = AnsibleModule({})
    generic_bsdifconfignet = GenericBsdIfconfigNetwork(module)
    defaults = None
    interfaces = {}
    interface_name = 'lo0'
    interface_data = {'ipv4':[{'address':'127.0.0.1', 'netmask':'255.0.0.0'}],
        'ipv6':[{'address':'fe80::1%lo0', 'prefix':'64'}],
        'macaddress':'unknown',
        'mtu':'33184',
        'metric':'0',
        'flags':['UP','LOOPBACK','RUNNING','MULTICAST']}

# Generated at 2022-06-11 03:20:09.075028
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    route_path = '/sbin/route'
    ipv4, ipv6 = network.get_default_interfaces(route_path)
    assert ipv4 == {'gateway': '192.168.1.1', 'interface': 'eth0', 'address': '192.168.1.6'}
    assert ipv6 == {'gateway': 'fe80::1%eth0', 'interface': 'eth0', 'address': '2000:6a:f6ff:4::4'}



# Generated at 2022-06-11 03:20:17.435761
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    import socket
    import ctypes

    class MockedModule:

        def __init__(self):
            self.bin_path = {}

        def get_bin_path(self, key):
            if key == 'ifconfig':
                return '/sbin/ifconfig'
            if key == 'route':
                return '/sbin/route'

    class MockedOS:
        family = 'FreeBSD'

        def __init__(self):
            self.socket = MockedSocket()

    class MockedSocket:

        def has_ipv6(self):
            return True


# Generated at 2022-06-11 03:20:28.546133
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Assert a single option
    s = '<UP,BROADCAST,RUNNING,PROMISC,ALLMULTI,SIMPLEX,MULTICAST>'
    assert GenericBsdIfconfigNetwork.get_options(s) == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'ALLMULTI', 'SIMPLEX', 'MULTICAST']

    # Assert a single option with extra whitespace
    s = '<UP, BROADCAST, RUNNING, PROMISC, ALLMULTI, SIMPLEX, MULTICAST>'
    assert GenericBsdIfconfigNetwork.get_options(s) == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'ALLMULTI', 'SIMPLEX', 'MULTICAST']

    # Assert empty string

# Generated at 2022-06-11 03:20:39.659464
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig = GenericBsdIfconfigNetwork()

    # Merge address into default interface (ipv4)
    default_interface = {'interface': 'net0'}
    interfaces = {'net0': {'mtu': '1500', 'ipv4': [{'netmask': '255.255.255.0', 'broadcast': '192.168.1.255', 'address': '192.168.1.128', 'network': '192.168.1.0'}]}}
    ifconfig.merge_default_interface(default_interface, interfaces, 'ipv4')

# Generated at 2022-06-11 03:20:44.890778
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """Function to test the method merge_default_interface of class GenericBsdIfconfigNetwork"""
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0':{}}
    ip_type = "ipv4"
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, ip_type)


# Generated at 2022-06-11 03:20:52.385205
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork(dict(module=dict()))
    # Should be the same as
    assert [] == network.get_options('')
    assert [] == network.get_options('no-options')
    assert [] == network.get_options('<>')
    assert [] == network.get_options('<not,comma,separated>')
    assert ['option'] == network.get_options('<option>')
    assert ['option1', 'option2'] == network.get_options('<option1,option2>')



# Generated at 2022-06-11 03:21:19.252799
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    platform = 'Generic_BSD_Ifconfig'
    module = FakeModule()
    network = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-11 03:21:29.057891
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    if not hasattr(socket, 'has_ipv6'):
        # Python 2.6, 2.7, 3.2 and 3.3 do not have socket.has_ipv6
        socket.has_ipv6 = False

    fake_module = FakeModule()
    fake_module.run_command = lambda *args, **kwargs: (0, "", "")

    # case 1: ifconfig -a output on Mac OS X
    fake_module.run_command = lambda *args, **kwargs: (
        0, MAC_OSX_OUTPUT, "")
    mac_ifconfig = GenericBsdIfconfigNetwork(fake_module)
    mac_facts = mac_ifconfig.populate()


# Generated at 2022-06-11 03:21:41.272698
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.utils.path import which
    import pytest
    import os
    ifconfig_path = which('ifconfig')
    ifconfig_options = '-a'
    if os.path.exists(ifconfig_path):
        interfaces, ips = GenericBsdIfconfigNetwork.get_interfaces_info(None, ifconfig_path, ifconfig_options)
        assert interfaces
        assert ips

        if 'lo0' in interfaces:
            assert interfaces['lo0']['type'] == 'loopback'
            assert 'ipv4' in interfaces['lo0']
            assert 'ipv6' in interfaces['lo0']
            assert 'macaddress' in interfaces['lo0']


# Generated at 2022-06-11 03:21:51.884710
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    ifconfig = GenericBsdIfconfigNetwork(module=module)
    ifconfig_options = '-a'
    rc, out, err = module.run_command(['/sbin/ifconfig', ifconfig_options])
    interfaces, ips = ifconfig.get_interfaces_info(ifconfig_options)
    assert(interfaces['vni0']['status'] == 'active')
    assert(interfaces['tun0']['status'] == 'active')
    assert(interfaces['lo0']['status'] == 'active')
    assert(interfaces['gre0']['status'] == 'active')
    assert(interfaces['gre0']['type'] == 'tunnel')
    assert(interfaces['vni0']['type'] == 'tunnel')
   

# Generated at 2022-06-11 03:22:02.590754
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    module = AnsibleModule(argument_spec=dict())
    network_module = GenericBsdIfconfigNetwork(module)
    interfaces, ips = network_module.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert type(interfaces) is dict
    assert type(ips) is dict
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert type(ips['all_ipv4_addresses']) is list
    assert type(ips['all_ipv6_addresses']) is list
    assert 'lo0' in interfaces
    assert 'lo0' in interfaces

# Generated at 2022-06-11 03:22:13.602640
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:22:19.585993
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    """
    GenericBsdIfconfigNetwork - method: populate
    """

    from ansible.module_utils import basic
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    # Setup a fake module
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    GenericBsdIfconfigNetwork.get_default_interfaces = MagicMock(return_value=({}, {}))

    # Setup a fake ifconfig output

# Generated at 2022-06-11 03:22:28.987204
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Test 'dragonflybsd' platform
    # This will set platform to be 'dragonflybsd'
    platform.system = MagicMock(return_value='dragonflybsd')
    module = AnsibleModule(argument_spec=dict())
    network_platform = GenericBsdIfconfigNetwork()
    network_platform.module = module
    # This will set the module.get_bin_path to return required ifconfig binary path
    module.get_bin_path = MagicMock(return_value='/sbin')
    network_facts = network_platform.populate()
    assert network_facts
    assert network_facts['default_ipv4']['interface'] == 'lo0'
    assert network_facts['lo0']['type'] == 'loopback'

# Generated at 2022-06-11 03:22:39.777629
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    net = GenericBsdIfconfigNetwork(module=None)

    # Test input for ifconfig_path /usr/sbin/ifconfig -a
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:22:51.870231
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    mock_module = Mock()
    mock_module.run_command = MagicMock()

# Generated at 2022-06-11 03:23:29.242183
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    #
    # netbsd show aliases like this
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0.0.1 netmask 0xff000000
    #         inet alias 127.1.1.1 netmask 0xff000000
    #
    words = ['em0', 'inet', '123.123.123.123', 'netmask', '0xffffff00']
    current_if = {'device': words[0], 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                  'flags': [], 'macaddress': 'unknown', 'mtu': ''}

# Generated at 2022-06-11 03:23:40.922568
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    vagrant_units_path = os.path.join(os.getcwd(), 'tests/units/modules/net_tools/vagrant_generic_bsd_ifconfig')
    units_paths = create_units_paths(vagrant_units_path, 'Generic_BSD_Ifconfig')
    # Test OpenBSD
    openbsd_network = GenericBsdIfconfigNetwork(units_paths['OpenBSD'])
    openbsd_ansible_module = AnsibleModule(argument_spec={'gather_subset': dict(type='list')})
    openbsd_ansible_module.params['gather_subset'] = ['all']
    openbsd_facts = openbsd_network.populate_facts(openbsd_ansible_module)

# Generated at 2022-06-11 03:23:50.342766
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    count = 0
    while count < len(TEST_DATA):
        count = count + 1
        network_plugin = GenericBsdIfconfigNetwork()
        current_if = {}
        current_if['ipv6'] = []
        ips = {}
        ips['all_ipv6_addresses'] = []
        input_words = TEST_DATA[count]['input_words']
        network_plugin.parse_inet6_line(input_words, current_if, ips)
        if 'output_words' in TEST_DATA[count]:
            output_words = TEST_DATA[count]['output_words']

# Generated at 2022-06-11 03:23:51.669470
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass



# Generated at 2022-06-11 03:24:03.427219
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    #Create the object of class GenericBsdIfconfigNetwork
    netobj = GenericBsdIfconfigNetwork()
    #Create the object of class BsdIfconfigNetwork
    bsdIfconfigNetwork = BsdIfconfigNetwork()
    #Create a list of interfaces
    interfaces = {}
    #Create a list of ips
    ips = {}

    #Assign the file path to the variable path
    path = "ifconfig.txt"
    #Open the file in read mode and store the data in a variable
    with open(path, 'r') as f:
        lines = f.read()
    #Assign the value of /sbin/ifconfig to path_ifconfig
    path_ifconfig = "/sbin/ifconfig"
    #Assign the value of -a to path_options
    path_options = "-a"

    #Call

# Generated at 2022-06-11 03:24:12.549746
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_module = GenericBsdIfconfigNetwork(module)
    # Test 1. Compare the output from the command ifconfig -a with the output from the method get_interfaces_info

# Generated at 2022-06-11 03:24:21.729393
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:24:31.659767
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd = GenericBsdIfconfigNetwork()

    words_no_prefix = ['fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2', '0x1']

    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )

    generic_bsd.parse_inet6_line(words_no_prefix, current_if, ips)

    assert ips == {'all_ipv6_addresses': ['fe80::1%lo0']}
    assert current_if == {
        'ipv6': [
            {
                'address': 'fe80::1%lo0',
                'prefix': '64',
                'scope': '0x2',
            },
        ],
    }

# Unit test

# Generated at 2022-06-11 03:24:42.138975
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)
