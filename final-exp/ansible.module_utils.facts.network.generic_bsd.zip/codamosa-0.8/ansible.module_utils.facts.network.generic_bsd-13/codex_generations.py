

# Generated at 2022-06-11 03:15:37.413795
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test for FreeBSD
    net = GenericBsdIfconfigNetwork()
    route_path = net.module.get_bin_path('route')
    default_ipv4, default_ipv6 = net.get_default_interfaces(route_path)

# Generated at 2022-06-11 03:15:49.594539
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    """
    test_GenericBsdIfconfigNetwork_get_options tests the get_options function
    with string of specified format for option flags
    """
    #  test data
    testdata = {
        "option_1": "UP,LOOPBACK",
        "option_2": "UP,BROADCAST,MULTICAST",
        "option_3": "",
        "option_4": "UP,LOOPBACK,RUNNING,MULTICAST",
        "option_5": "UP,BROADCAST,RUNNING,MULTICAST"
    }

    # expected results

# Generated at 2022-06-11 03:16:00.324555
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    mock_module = Mock()
    mock_module.params = {
        'fact_path': '/etc/ansible/facts.d'
    }
    ifconfig = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:16:12.336612
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ab = GenericBsdIfconfigNetwork(MockModule())
    defaults = dict()
    interfaces = dict()

    ab.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults) == 0

    defaults = dict(interface='none')
    interfaces = dict()

    ab.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults) == 1

    defaults = dict(interface='lo0')
    interfaces = dict(
        lo0=dict(
            device=defaults['interface'],
            ipv4=[dict(address='127.0.0.1')],
            flags=[]
        )
    )

    ab.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults) == 4

# Generated at 2022-06-11 03:16:24.398533
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    ifs = {
        'lo0': {
            'device': 'lo0',
            'type': 'loopback',
            'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
            'mtu': '16384',
            'macaddress': 'unknown',
            'ipv4': [
                {
                    'address': '127.0.0.1',
                    'netmask': '255.0.0.0',
                    'broadcast': '0.0.0.0'
                }
            ],
            'ipv6': [
                {
                    'address': '::1',
                    'prefix': '128'
                }
            ]
        }
    }

# Generated at 2022-06-11 03:16:35.692360
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module_mock = Mock(run_command=Mock(return_value=(0, 'a', '')))
    net_parser = GenericBsdIfconfigNetwork(module_mock)
    line_mock = 'media: Ethernet autoselect (1000baseT)'
    iface_mock = {}
    ips_mock = {}

    net_parser.parse_media_line(line_mock.split(), iface_mock, ips_mock)

    assert 'media' in iface_mock
    assert iface_mock['media'] == 'Ethernet'
    assert 'media_select' in iface_mock
    assert iface_mock['media_select'] == 'autoselect'
    assert 'media_type' in iface_mock

# Generated at 2022-06-11 03:16:45.615613
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network = GenericBsdIfconfigNetwork()

    # TODO: test a range of valid and invalid inputs
    _, route_out, _ = network.module.run_command(['route', '-n', 'get', 'default'])
    _, route_out6, _ = network.module.run_command(['route', '-n', 'get', '-inet6', 'default'])

    rc, ifconfig_out, err = network.module.run_command(['ifconfig', '-a'])
    if rc != 0:
        raise Exception("Cannot run ifconfig")

    interfaces, _ = network.get_interfaces_info(None)
    default_ipv4, default_ipv6 = network.get_default_interfaces(None)


# Generated at 2022-06-11 03:16:52.559003
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    obj = GenericBsdIfconfigNetwork()
    obj.module = AnsibleModuleStub()
    obj.module.get_bin_path = lambda x: '/sbin/route'
    obj.module.run_command = run_command_stub

    command = dict(v4=['/sbin/route', '-n', 'get', 'default'],
                   v6=['/sbin/route', '-n', 'get', '-inet6', 'default'])

# Generated at 2022-06-11 03:16:56.663570
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    wstr = "options=3<RXCSUM,TXCSUM>"
    options = GenericBsdIfconfigNetwork.get_options(wstr)
    assert set(['RXCSUM', 'TXCSUM']) == set(options)


# Generated at 2022-06-11 03:17:02.242901
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    assert BSD_IF_OBJ.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)'], {}, {}) \
        == {'media': 'Ethernet', 'media_select': 'autoselect', 'media_type': '1000baseT'}


# Generated at 2022-06-11 03:17:27.683223
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
  ifconfig_path = 'ifconfig'

  ifconfig_options = '-a'
  bsdNetwork = GenericBsdIfconfigNetwork()
  interfaces, ips = bsdNetwork.get_interfaces_info(ifconfig_path, ifconfig_options)
  assert(len(interfaces) > 0)


# Generated at 2022-06-11 03:17:39.541241
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    # Test with IPv4
    # Test 1: default interface in interfaces dictionary
    module = AnsibleModule({'groups': ['g1', 'g2']})
    del module.params['groups']
    defaults = {'interface': 'eth0'}

# Generated at 2022-06-11 03:17:51.798882
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:18:04.191740
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    g = GenericBsdIfconfigNetwork()
    words = ['inet6', 'fe80::9f65:e2ff:fe1e:db6b%vtnet0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    try:
        g.parse_inet6_line(words, current_if, ips)
        assert current_if != {}
        assert ips['all_ipv6_addresses'] == ['fe80::9f65:e2ff:fe1e:db6b%vtnet0']
    except Exception:
        assert False
# Unit

# Generated at 2022-06-11 03:18:12.992685
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})

    # Test with simple non-alias
    generic_bsd_object = GenericBsdIfconfigNetwork()
    current_if = dict()
    ips = dict()
    words = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384 inet 127.0.0.1 netmask 0xff000000'.split()
    generic_bsd_object.parse_inet_line(words, current_if, ips)
    assert current_if.get('ipv4')[0].get('netmask') == '255.255.255.0'
    assert current_if.get('type') == 'loopback'

    # Test with non-hex netmask
    generic_bsd_object = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:18:24.522958
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbn = GenericBsdIfconfigNetwork()
    # test typical options string
    option_string = ' flags=61<UP,RUNNING,POINTOPOINT> mtu 1500'
    options = gbn.get_options(option_string)
    assert options == ['UP', 'RUNNING', 'POINTOPOINT']
    # test empty option string
    option_string = ''
    options = gbn.get_options(option_string)
    assert options == []
    # test leading <
    option_string = '<UP,RUNNING,POINTOPOINT> mtu 1500'
    options = gbn.get_options(option_string)
    assert options == []
    # test trailing >
    option_string = 'flags=61<UP,RUNNING,POINTOPOINT'

# Generated at 2022-06-11 03:18:36.146350
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    iface = GenericBsdIfconfigNetwork(module)
    # test case 1 - empty defaults
    defaults = {}
    interfaces = {'lo0': {'loopback': True,
                          'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0',
                                    'broadcast': '127.255.255.255'}],
                          'ipv6': [{'address': '::1', 'prefix': '128'}],
                          'macaddress': 'none', 'type': 'loopback'}}
    ip_type = 'ipv4'
    iface.merge_default_interface(defaults,interfaces,ip_type)
   

# Generated at 2022-06-11 03:18:42.535988
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())

    # Watchtower
    from ansible.modules.network.bsd import bsd_ifconfig

    # Monkey patch the module
    bsd_ifconfig.AnsibleModule = AnsibleModule
    bsd_ifconfig.get_bin_path = lambda x: '/sbin/ifconfig'

    obj = bsd_ifconfig.GenericBsdIfconfigNetwork()
    obj.get_interfaces_info()



# Generated at 2022-06-11 03:18:49.500419
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:18:59.743107
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    gen_network = GenericBsdIfconfigNetwork()
    # TODO: currently this test only covers the BSD_Ifconfig class and not
    # specific sub-classes.
    platform = 'Generic_BSD_Ifconfig'
    pattern = os.path.join(os.path.dirname(__file__), 'network_platform_data', platform, '*')
    for filename in glob.glob(pattern):
        if filename.endswith('.out'):
            # Reading in the contents of the test file
            with open(filename, 'r') as test_file:
                test_data = test_file.read()

            # Doing the actual testing
            interfaces, ips = gen_network.get_interfaces_info(None, test_data)

            # Reading in the expected result
            expected_filename = os.path.splite

# Generated at 2022-06-11 03:19:25.326831
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class Argument(object):
        def __init__(self, value):
            self.value = value

    def test_get_options(arg):
        network = GenericBsdIfconfigNetwork()
        return network.get_options(arg)

    assert test_get_options(None) == []

    assert test_get_options('net0') == []

    assert test_get_options('<>') == []

    assert test_get_options('<<>') == []

    assert test_get_options('<a,b>') == ['a', 'b']


# Generated at 2022-06-11 03:19:36.539718
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from mock import Mock

    # get_options() is a static method, so mock module scope
    net = Mock()

    # TODO: Mock the module scope stuff, so we don't get these warnings:
    #    /usr/local/lib/python3.5/site-packages/ansible/module_utils/basic.py:1341: RuntimeWarning: AnsibleModule class AnsibleModule has a __getattr__ method with special behavior, which may cause certain operations, such as accessing members, to behave differently than when using a standard Python object.
    #      if not self.argument_spec:
    #    /usr/local/lib/python3.5/site-packages/ansible/module_utils/basic.py:1345: RuntimeWarning: AnsibleModule class AnsibleModule has a __getattr__ method with special behavior, which may cause certain operations, such as

# Generated at 2022-06-11 03:19:47.950319
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    g = GenericBsdIfconfigNetwork()
    ifconfig_path = g.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return network_facts

    route_path = g.module.get_bin_path('route')

    if route_path is None:
        return network_facts

    interfaces, ips = g.get_interfaces_info(ifconfig_path)
    interfaces = g.detect_type_media(interfaces)

# Generated at 2022-06-11 03:19:59.317827
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.facts import Network_GenericBsdIfconfig

    ip_path = '/opt/local/sbin/ip'
    ifconfig_path = '/sbin/ifconfig'

# Generated at 2022-06-11 03:20:11.136977
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    g = GenericBsdIfconfigNetwork()
    g.merge_default_interface({}, {}, 'ipv4')
    g.merge_default_interface({'interface': 'name', 'address': 'addr'}, {}, 'ipv4')
    g.merge_default_interface({'interface': 'name', 'address': 'addr'}, {'name': {}}, 'ipv4')
    g.merge_default_interface({'interface': 'name', 'address': 'addr'}, {'name': {}}, 'ipv6')
    g.merge_default_interface({'interface': 'name', 'address': 'addr'}, {'name': {'ipv4': [{'address': 'addr'}]}}, 'ipv4')

# Generated at 2022-06-11 03:20:13.450139
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_obj = GenericBsdIfconfigNetwork()
    expected = ({}, {})
    assert test_obj.get_default_interfaces('route') == expected


# Generated at 2022-06-11 03:20:20.003282
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    test_case = unittest.TestCase('__init__')
    network_facts = GenericBsdIfconfigNetwork(module)
    defaults = dict(interface='eth0')

    interfaces = dict(
        eth0={
            'device': 'eth0',
            'ipv4': [{'address': '1.1.1.1', 'netmask': '255.255.255.0', 'network': '1.1.1.0', 'broadcast': '1.1.1.255'}]
        }
    )

    network_facts.merge_default_interface(defaults, interfaces, 'ipv4')
    test_case.assertEqual(defaults['device'], 'eth0')

# Unit

# Generated at 2022-06-11 03:20:26.046808
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    if2 = network.GenericBsdIfconfigNetwork()
    assert if2.get_options('no options') == []
    assert if2.get_options('<UP>') == ['UP']
    assert if2.get_options('options=<foo>') == ['foo']
    assert if2.get_options('nd6 options=<foo>') == ['foo']


# Generated at 2022-06-11 03:20:31.493898
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    import pytest

    gbn = GenericBsdIfconfigNetwork()

    expected = ['one']
    result = gbn.get_options('<one>')
    assert result == expected

    expected = ['one', 'two']
    result = gbn.get_options('<one,two>')
    assert result == expected

    expected = []
    result = gbn.get_options('<one,two')
    assert result == expected

    expected = ['one', 'two']
    result = gbn.get_options('< one, two >')
    assert result == expected

# Generated at 2022-06-11 03:20:42.028907
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={'connection': {'default': '', 'choices': ['netconf'], 'type': 'str'}})
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-11 03:21:14.369385
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Create the object
    obj = GenericBsdIfconfigNetwork()

    # Mock the external method
    def mock_run_command(command, check_rc=True, close_fds=True, data=None, binary_data=False):
        output = """default: gateway 192.168.0.1"""
        return 0, output, ''

    # Apply the mock
    obj.module.run_command = mock_run_command

    # Test the method
    assert obj.get_default_interfaces('route') == ({'gateway': '192.168.0.1', 'interface': 'default'}, {})



# Generated at 2022-06-11 03:21:25.601455
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    m = GenericBsdIfconfigNetwork()

    # merge_default_interface is private, create a mock object to test it
    class GenericBsdIfconfigNetworkMock(GenericBsdIfconfigNetwork):
        def __init__(self):
            self.log = []
        def merge_default_interface(self, defaults, interfaces, ip_type):
            self.log.append(('merge_default_interface', locals()))

    m = GenericBsdIfconfigNetworkMock()

    # empty defaults and interfaces
    m.merge_default_interface({}, {}, 'ipv4')
    assert m.log.pop(0)['defaults'] == {}
    assert m.log.pop(0)['interfaces'] == {}
    assert m.log.pop(0)['ip_type'] == 'ipv4'

    #

# Generated at 2022-06-11 03:21:36.214515
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    platform = 'FreeBSD_9_4'
    hostname = 'myhostname'
    port = 22
    username = 'myusername'
    password = 'mypassword'
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
    )
    set_module_args(dict(gather_subset=['all']))
    if os.path.exists('/usr/bin/ifconfig'):
        potential_ifconfig = '/usr/bin/ifconfig'
    elif os.path.exists('/sbin/ifconfig'):
        potential_ifconfig = '/sbin/ifconfig'
    else:
        potential_ifconfig = 'ifconfig'
    module.run_command = MagicMock()


# Generated at 2022-06-11 03:21:47.613795
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

# Generated at 2022-06-11 03:21:56.352007
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    import os
    import sys
    import tempfile
    import shutil
    import json
    import unittest

    class TestGenericBsdIfconfigNetwork_get_options(unittest.TestCase):

        def setUp(self):
            self.__tmpdir = tempfile.mkdtemp(prefix='ansible_test_GenericBsdIfconfigNetwork_get_options_')

        def tearDown(self):
            shutil.rmtree(self.__tmpdir, True)

        def run_module(self, module_name, module_args):
            # since the API is constructed for CLI it expects a module
            # name, so we cut the leading directories from the __file__
            # filename and add them to the module name.
            module_path = module_name.split('.')
            module_name = '.'.join

# Generated at 2022-06-11 03:22:05.560918
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    testmodule = AnsibleModule(argument_spec={})
    d = GenericBsdIfconfigNetwork(testmodule)

    ifconfig_path = d.module.get_bin_path('ifconfig')


# Generated at 2022-06-11 03:22:16.690940
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:22:19.199875
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    client = get_client()
    module = AnsibleModule(argument_spec={},supports_check_mode=True)
    res = client.call_function('GenericBsdIfconfigNetwork.populate',module)
    assert res is None

# Generated at 2022-06-11 03:22:19.820280
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pass

# Generated at 2022-06-11 03:22:24.686529
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Setup
    module_args = {}

    module_class = GenericBsdIfconfigNetwork

    # Action
    module_instance = module_class(module_args)

    return_values = module_instance.populate()

    # Assert
    # Unknown test
    assert return_values is not None

# Generated at 2022-06-11 03:23:02.937130
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import platform
    import socket
    import struct

    class MockedModule(object):
        def run_command(self, cmd):
            return (0, '', '')

    class MockedNetwork(GenericBsdIfconfigNetwork):
        """
        Class to override methods to be tested
        """
        def get_options(self, option_string):
            return []

        def merge_default_interface(self, defaults, interfaces, ip_type):
            pass

    ip_address = '127.0.0.1'
    netmask = '0xff000000'
    address = {'address': ip_address}

    ip_address_cidr = '127.0.0.1/24'
    cidr_mask = '24'
    address_cidr = {'address': ip_address_cidr}



# Generated at 2022-06-11 03:23:12.207628
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network = GenericBsdIfconfigNetwork()
    mock_run_command = Mock()
    mock_run_command.return_value = (0, default_route_output, '')
    network.module.run_command = mock_run_command
    v4, v6 = network.get_default_interfaces('route')
    assert v4 == {'gateway': '192.168.2.2', 'interface': 'en0'}
    assert v6 == {'address': 'fe80::2e0:18ff:fe0b:4cbf%en0', 'gateway': 'fe80::1%en0', 'interface': 'en0'}

# Generated at 2022-06-11 03:23:16.715470
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    gbin = GenericBsdIfconfigNetwork()
    gbin.module = mock_module
    assert 'network' == gbin.populate()['platform']


# Generated at 2022-06-11 03:23:26.011682
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-11 03:23:37.251113
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    gbin = GenericBsdIfconfigNetwork()
    interfaces = {
        'eth0': {
            'device': 'eth0',
            'media': 'Ethernet autoselect',
            'type': 'unknown'
        }
    }
    interfaces = gbin.detect_type_media(interfaces)
    assert interfaces['eth0']['type'] == 'ether'
    interfaces = {
        'eth0': {
            'device': 'eth0',
            'media': 'Ethernet',
            'type': 'unknown'
        }
    }
    interfaces = gbin.detect_type_media(interfaces)
    assert interfaces['eth0']['type'] == 'ether'

# Generated at 2022-06-11 03:23:43.690222
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    bsd = GenericBsdIfconfigNetwork()
    intf = dict()

    words = ['interface', 'flags', 'metric', 'mtu']
    intf = bsd.parse_interface_line(words)

    assert intf['device'] == 'interface'
    assert intf['flags'] == ['flags']
    assert intf['metric'] == 'metric'
    assert intf['mtu'] == 'mtu'



# Generated at 2022-06-11 03:23:48.679888
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Check with a empty input string
    option_string = ""
    assert GenericBsdIfconfigNetwork.get_options(None, option_string) == []

    # Check with a option string
    option_string = "OPTION1,OPTION2,OPTION3"
    assert GenericBsdIfconfigNetwork.get_options(None, option_string) == ['OPTION1', 'OPTION2', 'OPTION3']

# Generated at 2022-06-11 03:24:00.470866
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # The contents of the ifconfig -a output usually contain the word 'flags'
    # or 'ether' in each line, and the first word will be the name of the
    # interface.
    ifname = 'lo0'
    ifconfig_out = """\
{}0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
        options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        nd6 options=201<PERFORMNUD,DAD>
        groups: lo
""".format(ifname)


# Generated at 2022-06-11 03:24:09.737207
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_instance = GenericBsdIfconfigNetwork()
    test_module = TestAnsibleModule()
    test_module.run_command = MagicMock(
        return_value=(0, test_fixtures.GenericBsdIfconfigNetwork_get_interfaces_info_ifconfig_output, None))

    actual_result = test_instance.get_interfaces_info(MagicMock())

# Generated at 2022-06-11 03:24:19.195865
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = MagicMock()
    from ansible.facts import network
    from ansible.constants import DEFAULT_LOCALE
    from ansible.module_utils.basic import AnsibleModule
    module.run_command = MagicMock(return_value=(0, ifconfig_output, None))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    module.ansible_facts = {}
    module.ansible_facts['ansible_env'] = {'LANG': DEFAULT_LOCALE}
    result = network.get_interfaces_info('/sbin/ifconfig')