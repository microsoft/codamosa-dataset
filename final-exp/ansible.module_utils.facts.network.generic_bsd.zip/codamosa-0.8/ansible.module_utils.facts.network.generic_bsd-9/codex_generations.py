

# Generated at 2022-06-11 03:15:35.948582
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule({})
    ifconfig = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # test invalid input
    ifconfig.parse_inet_line([], current_if, ips)
    assert current_if['device'] == 'eth0'
    assert len(current_if['ipv4']) == 0
    assert len(current_if['ipv6']) == 0

    # test invalid ipv4 address

# Generated at 2022-06-11 03:15:48.092773
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    m = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:15:59.491417
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    sys.stdout.write('Test method parse_ether_line of class GenericBsdIfconfigNetwork\n')
    obj = GenericBsdIfconfigNetwork()
    line = 'ether 00:11:22:33:44:55'
    words = line.split()
    current_if = {}
    ips = {}
    obj.parse_ether_line(words, current_if, ips)
    if 'macaddress' in current_if:
        print('macaddress: ' + current_if['macaddress'])
    else:
        print('macaddress: key not found')
    if 'type' in current_if:
        print('type: ' + current_if['type'])
    else:
        print('type: key not found')


# Generated at 2022-06-11 03:16:05.273813
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Setup
    involved_mock = {'media': 'Ethernet'}
    expected_result = {'media': 'Ethernet', 'type': 'ether'}
    interface = GenericBsdIfconfigNetwork()
    # Run
    actual_result = interface.detect_type_media(involved_mock)
    # Assert
    assert actual_result == expected_result


# Generated at 2022-06-11 03:16:18.008392
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_module = AnsibleModuleMock()
    test_module.run_command = run_command_mock
    test_module.get_bin_path = get_bin_path_mock
    test_class = GenericBsdIfconfigNetwork(test_module)
    test_class.parse_options_line = parse_options_line_mock
    test_class.parse_nd6_line = parse_nd6_line_mock
    test_class.parse_ether_line = parse_ether_line_mock
    test_class.parse_media_line = parse_media_line_mock
    test_class.parse_status_line = parse_status_line_mock
    test_class.parse_lladdr_line = parse_lladdr_line_mock
    test_class.parse_inet_line

# Generated at 2022-06-11 03:16:24.441979
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    # TODO: calls AnsibleModule.get_bin_path which is broken
    # bc = GenericBsdIfconfigNetwork(module)
    # bsd_ifconfig_output = open('/Users/michael/Development/ansible/test/unit/modules/network/interfaces/fixtures/freebsd-ifconfig_a.txt').read()
    # defaults = bc.get_default_interfaces('/bin/route')[0]
    # interfaces, ips = bc.get_interfaces_info('/sbin/ifconfig')
    # bc.merge_default_interface(defaults, interfaces, 'ipv4')
    # assert defaults['name'] == 'en0' 
    # assert defaults['inet'] == '10.0.0.137'
    #

# Generated at 2022-06-11 03:16:35.800521
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    """
    Test parse_inet_line method of class GenericBsdIfconfigNetwork
    :return:
    """
    # NetBSD
    words = ['netbsd1:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu 1500']
    current_if = {'device': 'netbsd1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = []
    current_if['metric'] = 0
    current_if['mtu'] = 1500
    # old date format pre 7.1
    words = words + ['inet', '192.168.122.2', 'netmask', '0xffffff00', 'broadcast', '192.168.122.255']
    ip_

# Generated at 2022-06-11 03:16:45.696943
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from distutils.version import StrictVersion
    from importlib import import_module

    "Setup basic args for AnsibleModule"
    if len(sys.argv) > 1:
        module = import_module(sys.argv[1])
        if hasattr(module, '__version__'):
            version = getattr(module, '__version__')
        else:
            version = 'unknown'
    else:
        module = AnsibleModule
        version = 'unknown'
    module_args = dict(
        config_file='/dev/null',
        renderer='json'
    )
    module_instance = AnsibleModule(argument_spec=module_args)

# Generated at 2022-06-11 03:16:52.616941
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic = GenericBsdIfconfigNetwork(None)

    # netbsd show aliases like this
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0.0.1 netmask 0xff000000
    #         inet alias 127.1.1.1 netmask 0xff000000
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = '''inet 127.0.0.1 netmask 0xff000000'''.split()

# Generated at 2022-06-11 03:17:04.001135
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:17:17.447016
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    mm = ModuleManager(module=module)
    mm.get_manager('network')

    results = mm.execute()
    module.exit_json(**results[0])



# Generated at 2022-06-11 03:17:27.224024
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    network = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_inet_line(['inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.255.255.255'], network, ips)
    assert ips['all_ipv4_addresses'] == ['127.0.0.1']
    assert network['ipv4'][0]['address'] == '127.0.0.1'
    assert network['ipv4'][0]['netmask'] == '255.0.0.0'
    assert network['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-11 03:17:39.340252
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Setup
    test_obj = GenericBsdIfconfigNetwork()
    words = ["fe80::21f:5bff:fe6e:d6dd%lo0",
            "prefixlen",
            "64",
            "scopeid",
            "0x1",
            "nd6",
            "options=21<PERFORMNUD,AUTO_LINKLOCAL>"]
    current_if = {"ipv6": [],
                "device": "lo0",
                "ipv4": [],
                "type": "loopback"}
    ips = {"all_ipv6_addresses": []}
    expected_ips = {"all_ipv6_addresses": ["fe80::21f:5bff:fe6e:d6dd%lo0"]}

    # Execute
    test_obj

# Generated at 2022-06-11 03:17:51.568774
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:18:03.884116
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Generate a check object to be used in unit tests
    obj = GenericBsdIfconfigNetwork()

    # Generate a simple defaults object with a matching interface
    defaults = {'address': '10.0.0.2'}
    interface = 'em1'
    ip_types = ['ipv4', 'ipv6']
    ip_type = 'ipv4'

    for ip_type in ip_types:
        # Generate a simple interface object with matching ip_type
        interfaces = {interface: {ip_type: [{'address': defaults['address'],
                                             'key': 'this_should_be_here'}]}}

        obj.merge_default_interface(defaults, interfaces, ip_type)

        assert defaults['key'] == 'this_should_be_here'

    # Generate an

# Generated at 2022-06-11 03:18:12.808636
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network_cls = network.GenericBsdIfconfigNetwork()
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # words = [inet, 172.22.0.83, netmask, 0xfffffc00, broadcast, 172.22.3.255]
    words = ['inet', '172.22.0.83', 'netmask', '0xfffffc00', 'broadcast', '172.22.3.255']
    network_cls.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-11 03:18:24.359431
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
        module = 'ansible.module_utils.basic.AnsibleModule'
        # TODO: fix this
        class args:
            pass
        module_args = args()
        module_args.hostname = 'hostname'
        module_args.username = 'username'
        module_args.password = 'password'

        network = GenericBsdIfconfigNetwork()
        network.module = importlib.import_module(module)

        # line from netbsd ifconfig -e output
        words = ['em1', 'flags=8802<BROADCAST,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500',
                 'inet', '10.10.10.11', 'netmask', '0xffffff00', 'broadcast', '10.10.10.255']
        current

# Generated at 2022-06-11 03:18:27.626088
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_obj = GenericBsdIfconfigNetwork(dict(module=''))
    test_obj.get_interfaces_info('ifconfig')


# Generated at 2022-06-11 03:18:38.567922
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    #
    # Module test
    #

    facts_file_name = 'GenericBsdIfconfigNetwork_facts.json'
    facts_file_path = '../../test/unit/module_utils/network_lsr_facts_files/'

    facts = {}

    module_mock = MagicMock(
        get_bin_path=lambda x, opt=True: x,
        params=dict(gather_subset=["!all", "+min"]),
        run_command=lambda x, check_rc=True, close_fds=False, executable=None: (0, "", ""),
    )

# Generated at 2022-06-11 03:18:47.277982
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:36.861435
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    routePath = 'route'
    test1 = TestGenericBsdIfconfigNetwork()
    test1.module.run_command = MagicMock(return_value=(0, "default: gateway 192.168.1.1", ""))
    test2 = TestGenericBsdIfconfigNetwork()
    test2.module.run_command = MagicMock(return_value=(0, "default: gateway 192.168.1.1  ", ""))
    test3 = TestGenericBsdIfconfigNetwork()
    test3.module.run_command = MagicMock(return_value=(0, "default: if address 192.168.1.1", ""))

    assert test1.get_default_interfaces(routePath) == ({'gateway': '192.168.1.1'}, {})
    assert test2.get_default_interfaces

# Generated at 2022-06-11 03:19:48.158758
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # Test first execution of method
    # The parsed network information is equal to dict_obj
    dict_obj = dict(
        address='2001:db9:1:1::1',
        prefix='64',
        scope='0x1',
    )
    words = ['inet6', '2001:db9:1:1::1', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = dict(ipv6=[])
    ips = dict(all_ipv6_addresses=[])
    generic_bsd_ifconfig_network.parse_inet6_line(words, current_if, ips)

    assert dict_obj == current_if['ipv6'][0]

# Generated at 2022-06-11 03:19:48.711077
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-11 03:20:00.606734
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(
        argument_spec = dict(
            config = dict(),
        ),
        supports_check_mode=True,
    )
    net = GenericBsdIfconfigNetwork(module)

    interface = dict()
    interfaces = dict()

    interfaces['eth0'] = interface
    interface['ipv4'] = []
    interface['ipv6'] = []
    interface['mtu'] = '1500'
    interface['interface'] = 'eth0'

    sample_ipv4_address = dict()
    sample_ipv4_address['address'] = '192.168.42.1'
    sample_ipv4_address['netmask'] = '255.255.255.255'
    sample_ipv4_address['broadcast'] = '192.168.42.255'
    sample_ipv

# Generated at 2022-06-11 03:20:12.074228
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    p = Platform()
    network = GenericBsdIfconfigNetwork(p, dict())
    result = network.populate(None)
    assert result['default_ipv4'] == {'interface': 'nfe0', 'address': '10.0.2.15', 'netmask': '255.255.255.0', 'network': '10.0.2.0', 'broadcast': '10.0.2.255', 'gateway': '10.0.2.2', 'metric': '0', 'mtu': '1500', 'macaddress': '52:54:00:12:35:02'}


if __name__ == '__main__':
    module = AnsibleModule(
        argument_spec=dict(),
        # not checking because of daisy chain to service module
        bypass_checks=True,
    )

# Generated at 2022-06-11 03:20:19.205504
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    ifconfig_path = ansible.utils.module_docs.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return None

    rc, out, err = ansible.utils.module_docs.run_command([ifconfig_path, '-a'])

    for line in out.splitlines():

        if line:
            words = line.split()

            if words[0] == 'pass':
                continue
            elif re.match(r'^\S', line) and len(words) > 3:
                current_if = network.parse_interface_line(words)
            elif words[0] == 'ether':
                network.parse_ether_line(words, current_if, None)

# Generated at 2022-06-11 03:20:29.825518
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network_module = GenericBsdIfconfigNetwork()

    defaults = dict(
        interface='foo',
    )
    interfaces = dict(
        foo=dict(
            ipv4=[],
            macaddress='00:11:22:33:44:55',
            type='ether',
        ),
    )
    network_module.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == dict(
        interface='foo',
        macaddress='00:11:22:33:44:55',
        type='ether',
    )

    defaults = dict(
        interface='foo',
    )

# Generated at 2022-06-11 03:20:40.182725
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import sys
    sys.path.append('/Users/user/Projects/python-ansible-collections/ansible/test/units/module_utils/network/f5/test_module_utils.egg')
    import module_utils
    import sys
    import argparse

    module_utils.basic.NO_LOG = True
    module_utils.basic.HAS_IPV6 = True
    module_utils.facts.FACTS = {}

    def mock_get_bin_path(name, opt_dirs=[]):
        if name == 'route':
            return 'route'

    module_utils.facts.get_bin_path = mock_get_bin_path
    default_ipv4, default_ipv6 = GenericBsdIfconfigNetwork().get_default_interfaces('route')
    assert default_ip

# Generated at 2022-06-11 03:20:51.333957
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    testobj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:20:57.442368
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network = GenericBsdIfconfigNetwork()
    network.module = AnsibleModuleMock()
    network.module.run_command.return_value = (0, MOCK_INF_ALLNET_MAC, None)
    ifaces = network.populate()
    #assert_equals(ifaces['default_ipv4'], {
    #    'interface': 'en0',
    #    'broadcast': '192.168.1.255',
    #    'address': '192.168.1.15',
    #    'netmask': '255.255.255.0',
    #    'network': '192.168.1.0'}
    #)

# Generated at 2022-06-11 03:21:39.087116
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.modules.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ifconfig_path = to_bytes('/usr/bin/env')
    test_network_facts = GenericBsdIfconfigNetwork(module)
    test_network_facts.get_interfaces_info(ifconfig_path, ifconfig_options='-e')



# Generated at 2022-06-11 03:21:50.824908
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    gbif = GenericBsdIfconfigNetwork()

    # Test 1
    words = ['inet6', 'fe80::a00:27ff:fe3e:d8f3', 'prefixlen', '64', 'scopeid', '0x4', 'inet6', 'fe80::a00:27ff:fe54:edad', 'prefixlen', '64', 'scopeid', '0x4', 'ether', 'a4:ba:db:43:e6:f3']
    current_if = {}
    ips = dict()
    gbif.parse_inet6_line(words, current_if, ips)

    assert len(current_if['ipv6']) == 2

# Generated at 2022-06-11 03:21:54.716882
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None)
        ),
        supports_check_mode=True
    )

    network = GenericBsdIfconfigNetwork(module)
    network.populate()

# Generated at 2022-06-11 03:22:04.554777
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.run_command = lambda *args, **kwargs: (0, '', '')
            self.module.get_bin_path = lambda *args, **kwargs: None

    network_class = TestGenericBsdIfconfigNetwork()

    def_interface = {'interface': 'eth0', 'gateway': '10.0.0.1', 'address': '10.0.0.2'}

# Generated at 2022-06-11 03:22:15.470536
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # test case where default interface is equal to one configured interface
    network = GenericBsdIfconfigNetwork(dict())
    defaults = dict()
    defaults['interface'] = 'lo0'
    defaults['address'] = '::1'
    interfaces = dict()
    interfaces['lo0'] = dict()
    interfaces['lo0']['ipv4'] = [{'address': '127.0.0.1'}, {'address': '10.0.0.1'}]
    interfaces['lo0']['ipv6'] = [{'address': '::1'}, {'address': '::2'}]
    interfaces['lo0']['macaddress'] = '00:00:00:00:00:00'
    interfaces['lo0']['type'] = 'loopback'

# Generated at 2022-06-11 03:22:26.488031
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    # Input parameters:
    defaults = {'gateway': '192.168.1.1', 'interface': 'lan0'}
    interfaces = {'lan0': {'ipv4': [{'address': '192.168.1.5', 'netmask': '255.255.255.0', 'network': '192.168.1.0', 'broadcast': '192.168.1.255'}, {'address': '192.168.2.5', 'netmask': '255.255.255.0', 'network': '192.168.2.0', 'broadcast': '192.168.2.255'}], 'ipv6': [], 'type': 'ether', 'mtu': '1500'}}
    ip_type = "ipv4"
    # Ex

# Generated at 2022-06-11 03:22:34.640019
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    network = GenericBsdIfconfigNetwork(module)
    ipv4, ipv6 = network.get_default_interfaces('./test/route')

    assert ipv4['interface'] == 'lo0'
    assert ipv4['address'] == '127.0.0.1'
    assert ipv4['gateway'] == '127.0.0.1'

    assert ipv6['interface'] == 'lo0'
    assert ipv6['address'] == '::1'
    assert ipv6['gateway'] == '::1'



# Generated at 2022-06-11 03:22:43.009468
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if_parser = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}

    # Test for a valid ipv6 line
    words = 'inet6 fe80::10c:28ff:fe2b:f546%fxp0 prefixlen 64 scopeid 0x2'.split()
    if_parser.parse_inet6_line(words, current_if, ips)
    assert not current_if
    assert not ips

    # Test for a valid ipv6 line
    words = 'inet6 fe80::10c:28ff:fe2b:f546 prefixlen 64 scopeid 0x2'.split()

# Generated at 2022-06-11 03:22:48.960755
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    module.params = {
        'path': {
            'ifconfig': 'ifconfig',
            'route': 'route'
        }
    }
    ifconfig_path = module.params['path']['ifconfig']
    route_path = module.params['path']['route']

    # Test intercept_methods()
    module = Ansi

# Generated at 2022-06-11 03:22:58.129786
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    assert GenericBsdIfconfigNetwork.parse_inet_line(["lo0", "inet", "127.0.0.1", "netmask", "0xff000000"], {}, {}) == {'ipv4': [{'netmask': '255.0.0.0', 'network': '127.0.0.0', 'broadcast': '127.255.255.255', 'address': '127.0.0.1'}]}

# Generated at 2022-06-11 03:23:46.167365
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """Test get_default_interfaces method of GenericBsdIfconfigNetwork class
    """
    network = GenericBsdIfconfigNetwork()
    # Test 1: empty output
    rc, out, err = network.module.run_command([])
    default_ipv4, default_ipv6 = network.get_default_interfaces([])
    if len(default_ipv4) > 0 or len(default_ipv6) > 0:
        assert 0 == 1
    # Test 2: test output
    rc, out, err = network.module.run_command(['route', '-n', 'get', 'default'])
    default_ipv4, default_ipv6 = network.get_default_interfaces(['route', '-n', 'get', 'default'])

# Generated at 2022-06-11 03:23:53.594844
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    #
    # Initialize the class
    #
    network_facts = GenericBsdIfconfigNetwork()
    default_ipv4 = dict()
    interface = dict()
    #
    # Test With default interface and Configured interfaces
    #
    default_ipv4['interface'] = 'en0'
    default_ipv4['gateway'] = '192.168.1.1'

# Generated at 2022-06-11 03:24:04.264769
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:24:13.698255
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    defaults = dict(interface='lo0', address='127.0.0.1')
    interfaces = dict(lo0=dict(ipv4=[dict(address='127.0.0.1'), dict(address='127.0.0.2')]),
                      lo1=dict(ipv4=[dict(address='127.1.1.1'), dict(address='127.1.1.2')]))
    # test with a valid interface
    net.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == dict(interface='lo0', address='127.0.0.1', ipv4=[dict(address='127.0.0.1')])
    # test with a valid interface but no 'address'

# Generated at 2022-06-11 03:24:22.476733
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # BSD ifconfig can sometimes output the netmask in hex (0xffffff00)

    # without broadcast
    iface = dict()
    ips = dict()
    words = ['inet', '127.0.0.1', 'netmask', '0xffffff00']

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(None, None)

    generic_bsd_ifconfig_network.parse_inet_line(words, iface, ips)
    assert iface['ipv4'][0]['address'] == '127.0.0.1'
    assert iface['ipv4'][0]['netmask'] == '255.255.255.0'
    assert iface['ipv4'][0]['network'] == '127.0.0.0'

# Generated at 2022-06-11 03:24:28.774771
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    f_module = FakeModule({'path': dict(key='path', value='')})
    f_module.run_command = MagicMock(return_value=(0, "", ""))
    m_platform = GenericBsdIfconfigNetwork(f_module).populate()

    # Assertions
    assert m_platform == {'all_ipv4_addresses': [], 'all_ipv6_addresses': [], 'default_ipv6': {}, 'default_ipv4': {}, 'interfaces': []}



# Generated at 2022-06-11 03:24:39.235228
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible_collections.alikins.network.tests.unit.compat.mock import MagicMock
    from ansible_collections.alikins.network.tests.unit.compat.mock import patch

    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(0, '', ''))

    with patch('ansible_collections.alikins.network.plugins.modules.network.common.facts.facts.NetworkResources.populate', new=MagicMock(return_value={})):
        network_facts = GenericBsdIfconfigNetwork(mock_module)
        network_facts.populate()

    assert network_facts.route_path is None
    assert network_facts.route6_path is None