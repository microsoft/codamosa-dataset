

# Generated at 2022-06-11 03:15:29.782586
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # create a mock module
    testModule = AnsibleModule({'file': '/etc/ansible/facts.d/network.fact'})

    # create the class
    genericBSD = GenericBsdIfconfigNetwork(testModule)
    interface = {}
    ips = {}

    # create test variables
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']

    # run test
    genericBSD.parse_media_line(words, interface, ips)

    # assert results
    assert interface['media'] == words[1]
    assert interface['media_select'] == words[2]
    assert interface['media_type'] == words[3][1:]

    # create test variables
    words = ['media:', 'Ethernet', 'autoselect', 'status:', 'active']

    #

# Generated at 2022-06-11 03:15:38.594394
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:15:50.105618
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Test case #1- missing interface
    defaults = dict(interface = 'eth0')
    interfaces = dict(lo0 = dict())
    ip_type = 'ipv4'
    GenericBsdIfconfigNetwork._merge_default_interface(defaults, interfaces, ip_type)
    assert 'interface' not in defaults
    # Test case #2 - existing interface but no address
    defaults = dict(interface = 'eth0')
    interfaces = dict(eth0 = dict())
    ip_type = 'ipv4'
    GenericBsdIfconfigNetwork._merge_default_interface(defaults, interfaces, ip_type)
    assert 'interface' not in defaults
    # Test case #3 - existing interface and address

# Generated at 2022-06-11 03:16:00.786079
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # See https://stackoverflow.com/a/6303310/4772020
    # We need to run this from the directory containing the module, so that it
    # can see the ansible modules.
    # We can't run this from the unit test directory, because it can't see the
    # ansible module directory from there.
    testdir = os.path.dirname(os.path.realpath(__file__))
    ansibledir = os.path.dirname(testdir)
    with tempfile.TemporaryDirectory() as tmpdirname:
        sys.path.insert(0, ansibledir)
        test_module = imp.load_source(
            "test_module",
            os.path.join(testdir, "test_GenericBsdIfconfigNetwork_module.py"))

        # Create an empty module

# Generated at 2022-06-11 03:16:12.950180
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule({})
    my_network = GenericBsdIfconfigNetwork(module)
    ifconfig_path = module.get_bin_path('ifconfig')
    if not ifconfig_path:
        module.fail_json(msg='ifconfig command not found')

    rc, out, err = module.run_command([ifconfig_path, '-a'])
    if rc != 0:
        module.fail_json(msg='ifconfig command failed')

    # find first interface with inet line
    for line in out.splitlines():
        my_words = line.split()
        if my_words[0] == 'inet':
            if len(my_words) < 3:
                continue
            inet_if = my_words[1]
            break

    # call parse_inet_line for that interface


# Generated at 2022-06-11 03:16:24.805567
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:16:27.666261
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbin = GenericBsdIfconfigNetwork()
    assert gbin.get_options('NO-CARRIER') == []
    assert  gbin.get_options('<LOOPBACK,UP>') == ['LOOPBACK', 'UP']



# Generated at 2022-06-11 03:16:29.419903
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # This needs a bit more work to avoid the side-effects in the original code
    pass



# Generated at 2022-06-11 03:16:41.734161
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    if platform.system() != 'Darwin':
        module = AnsibleModule(
            argument_spec={},
            supports_check_mode=False,
            check_invalid_arguments=False
        )
    else:
        module = AnsibleModule(
            argument_spec={},
            supports_check_mode=False
        )

    expected_rt_default_v4 = {'interface': 'lo0', 'gateway': 'localhost', 'address': '127.0.0.1'}
    expected_rt_default_v6 = {'interface': 'lo0', 'gateway': 'localhost', 'address': '::1'}

    exec_platform = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:16:49.834164
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # check null input
    defaults = None
    interfaces = None
    n = network()
    n.merge_default_interface(defaults, interfaces, 'ipv4')

    defaults = {}
    interfaces = None
    n.merge_default_interface(defaults, interfaces, 'ipv4')

    defaults = None
    interfaces = {}
    n.merge_default_interface(defaults, interfaces, 'ipv4')

    defaults = {}
    interfaces = {}
    n.merge_default_interface(defaults, interfaces, 'ipv4')

    # check null and empty variable
    defaults = {}

# Generated at 2022-06-11 03:17:27.150367
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    fqdn = 'hostname.example.org'
    collected_facts = dict(fqdn=fqdn)
    network_facts = GenericBsdIfconfigNetwork(module=None, collected_facts=collected_facts)
    interfaces = {'lo0': {'media': 'Ethernet'}, 'em0': {'media': 'OTHER'}}
    interfaces = network_facts.detect_type_media(interfaces)
    assert interfaces == {'lo0': {'media': 'Ethernet', 'type': 'ether'}, 'em0': {'media': 'OTHER', 'type': 'unknown'}}



# Generated at 2022-06-11 03:17:39.340213
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    result = GenericBsdIfconfigNetworkClass.merge_default_interface({'interface':'en0'}, {'en0':{'ipv4':[{'address':'192.168.1.1', 'netmask':'255.255.255.0', 'network':'192.168.1.0'},{'address':'192.168.1.1', 'netmask':'255.255.255.0', 'network':'192.168.1.0'}]}}, 'ipv4')

# Generated at 2022-06-11 03:17:49.075762
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network = GenericBsdIfconfigNetwork()
    facts = network.populate()
    assert 'interfaces' in facts
    assert 'all_ipv4_addresses' in facts
    assert 'all_ipv6_addresses' in facts
    assert 'eth0' in facts
    assert 'flags' in facts['eth0']
    assert facts['eth0']['flags'] == ['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert 'ether' in facts['eth0']['flags']
    assert 'inet' in facts['eth0']['flags']

# Generated at 2022-06-11 03:17:56.822821
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    network = GenericBsdIfconfigNetwork()

    interfaces = {
        'em0': {
            'mtu': '1500',
            'options': [],
            'device': 'em0',
            'ipv6': [],
            'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'],
            'ipv4': [],
            'metric': '0',
            'status': 'active',
            'type': 'unknown',
            'media_options': [],
            'media_select': 'autoselect',
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)',
            'media_type': '1000baseT',
            'macaddress': '00:04:23:c7:8a:00'
        }
    }

# Generated at 2022-06-11 03:18:00.918834
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    myIfconfigNetwork = GenericBsdIfconfigNetwork()
    myIfconfigNetwork.module = AnsibleModuleMock()
    myIfconfigNetwork.module.get_bin_path = lambda arg: arg
    myIfconfigNetwork.populate()



# Generated at 2022-06-11 03:18:11.236521
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:18:23.037651
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = MagicMock()
    ifcfg = GenericBsdIfconfigNetwork(module)

    line = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = ifcfg.parse_interface_line(line)
    ifcfg.parse_inet_line(line, current_if, dict())

    assert current_if['ipv4'][0] == {'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0', 'broadcast': '127.255.255.255'}

    line = ['lo0', 'inet', '127.0.0.1', 'netmask', '255.0.0.0','broadcast','127.255.255.255']
   

# Generated at 2022-06-11 03:18:33.840455
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    # ifconfig path is not None
    ifconfig_path = '/sbin/ifconfig'
    module.get_bin_path = MagicMock(return_value=ifconfig_path)

    # command_exists return True
    module.command_exists = MagicMock(return_value=True)

    # command_exists return True
    route_path = '/sbin/route'
    module.get_bin_path = MagicMock(return_value=route_path)

    # command_exists return True
    module.command_exists = MagicMock(return_value=True)

    # prepare mock objects

# Generated at 2022-06-11 03:18:44.319844
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:18:55.917561
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    a = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:19:27.046636
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    n = GenericBsdIfconfigNetwork()

    # in this test, the interface 'link0' has two addresses,
    # the default interface is (rightly) 'lo0'
    # the test is to merge_default_interface the iface lo0
    # with the lo0 info


# Generated at 2022-06-11 03:19:37.400038
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:48.478582
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModuleMock()
    ifconfig_path = module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return
    route_path = module.get_bin_path('route')
    if route_path is None:
        return
    platform = 'Generic_BSD_Ifconfig'
    network_facts = GenericBsdIfconfigNetwork(module).populate()
    if platform in network_facts['network']:
        network_facts = network_facts['network'][platform]

    assert network_facts['interfaces'] == ['lo0', 'lo1', 'lo2', 'gif0', 'stf0', 'en0', 'p2p0', 'awdl0', 'bridge0', 'utun0', 'vboxnet0']

# Generated at 2022-06-11 03:19:50.328780
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network = GenericBsdIfconfigNetwork()
    assert isinstance(network.get_default_interfaces(""), tuple)

# Generated at 2022-06-11 03:20:03.114463
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(path='/bin/ifconfig')
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=False)
        ),
        supports_check_mode=True
    )



# Generated at 2022-06-11 03:20:08.201095
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    interface = {}

    network_platform = GenericBsdIfconfigNetwork()

    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184',
             'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet6', '::1', 'prefixlen', '128', 'inet6',
             'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'nd6', 'options=1<PERFORMNUD>']

    network_platform.parse_interface_line(words)
    network_platform.parse_inet_line(words[5:], interface, {})


# Generated at 2022-06-11 03:20:16.886957
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_object = GenericBsdIfconfigNetwork()
    addr = dict()
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    test_object.parse_inet_line(words, addr, dict())
    assert addr['ipv4'][0]['address'] == '127.0.0.1'
    assert addr['ipv4'][0]['netmask'] == '255.0.0.0'

    addr = dict()
    words = ['inet', '192.0.2.1', 'netmask', '0xffffff00']
    test_object.parse_inet_line(words, addr, dict())
    assert addr['ipv4'][0]['address'] == '192.0.2.1'

# Generated at 2022-06-11 03:20:28.016523
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    class MockModule(object):
        def __init__(self, int_words):
            self.int_words = int_words
        def run_command(self, cmd):
            return (0, "", "")
        def get_bin_path(self, cmd):
            return "/sbin/ifconfig"

    words = ('em0:', 'inet6', '2001:db8::10', 'prefixlen', '64', 'scopeid', '0x3')

    module = MockModule(words)
    platform = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-11 03:20:34.238834
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    net = GenericBsdIfconfigNetwork()
    option_string = '<UP,UP,UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST,NOARP>'
    assert net.get_options(option_string) == ['UP', 'UP', 'UP', 'BROADCAST', 'SMART', 'RUNNING',
                                              'SIMPLEX', 'MULTICAST', 'NOARP']



# Generated at 2022-06-11 03:20:45.247240
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    class MockModule(object):
        @staticmethod
        def get_bin_path(*args, **kwargs):
            return 'mock_route'
        @staticmethod
        def run_command(command):
            out = ''
            err = ''

# Generated at 2022-06-11 03:21:37.789863
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    f = GenericBsdIfconfigNetwork()
    defaults = {
        'interface': 'lo0'
    }

# Generated at 2022-06-11 03:21:49.586547
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    iface = GenericBsdIfconfigNetwork()
    # 01 case
    iface_01 = dict(device='', ipv4=[], ipv6=[], type='')
    words_01 = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x3', 'inet6', '::1', 'prefixlen', '128', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    ips_01 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:21:57.061802
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        supports_check_mode=True)

    runner = Runner(
        module_name='test',
        module_args='',
        module=module,
        task_vars=dict(
            ansible_facts=dict(
                ansible_net_gather_subset=['all']
            ),
            ansible_check_mode=True
        ))


# Generated at 2022-06-11 03:22:05.876329
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsdifconfig_network = GenericBsdIfconfigNetwork()
    current_if = dict(ipv4=[], ipv6=[])
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test
    words = ['inet6', '2001:db8::100e:a0ff:fe00:e0', 'prefixlen', '64', 'scopeid', '0x1', '0x0']
    generic_bsdifconfig_network.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == '2001:db8::100e:a0ff:fe00:e0'

# Generated at 2022-06-11 03:22:17.345785
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig = GenericBsdIfconfigNetwork()

    defaults = {
        'interface': 'en0',
        'address': '192.168.1.1',
    }

    interfaces = {
        'en0': {
            'ipv4': [
                {'address': '192.168.1.1', 'netmask': '255.255.255.0'},
                {'address': '192.168.1.2', 'netmask': '255.255.255.0'},
            ],
            'ipv6': [
                {'address': '2001:db8::1', 'prefix': '64'},
                {'address': '2001:db8::2', 'prefix': '64'},
            ],
        },
    }

    _defaults = copy.deepcopy(defaults)
    _

# Generated at 2022-06-11 03:22:21.795587
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    Test method get_default_interfaces of class GenericBsdIfconfigNetwork
    """
    module = AnsibleModule(argument_spec={})
    bsd = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-11 03:22:30.323419
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test for case: words = ['fe80::b47a:79ff:fe68:c205', 'prefixlen', '64', 'scopeid', '0x2', 'ether', '0:b4:7a:68:c2:05', 'inet6', 'fe80::b47a:79ff:fe68:c205%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = dict()

# Generated at 2022-06-11 03:22:40.751183
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = MagicMock()

    module.get_bin_path.side_effect = ['/usr/sbin/ifconfig','route']


# Generated at 2022-06-11 03:22:47.334193
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = dict(interface="lo0")
    interfaces = dict(lo0=dict(device='lo0', ipv4=[], ipv6=[dict(address='::1')]))
    ip_type = 'ipv6'
    network = GenericBsdIfconfigNetwork()
    network.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults['address'] == '::1'

# Generated at 2022-06-11 03:22:57.134697
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    if_info = dict()
    if_info['ipv4'] = []

    words = ['net3', 'inet', '0.0.0.0', 'netmask', '0xffffff00']
    GenericBsdIfconfigNetwork.parse_inet_line(words, if_info, None)
    assert len(if_info['ipv4']) == 1
    assert if_info['ipv4'][0]['address'] == '0.0.0.0'
    assert if_info['ipv4'][0]['netmask'] == '255.255.255.0'
    assert if_info['ipv4'][0]['broadcast'] == '255.255.255.255'
    assert if_info['ipv4'][0]['network'] == '0.0.0.0'

# Generated at 2022-06-11 03:23:44.172285
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    network = GenericBsdIfconfigNetwork()


# Generated at 2022-06-11 03:23:52.386825
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_module = AnsibleModule(
        argument_spec=dict()
    )
    test_ifconfig = GenericBsdIfconfigNetwork(test_module)

    test_interface = {}

    test_words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', 'full-duplex)']
    test_ifconfig.parse_media_line(test_words, test_interface, None)
    assert test_interface['media'] == 'Ethernet'
    assert test_interface['media_select'] == 'autoselect'
    assert test_interface['media_type'] == '(100baseTX'
    assert test_interface['media_options'] == ['full-duplex']

    test_words = ['media:', 'Ethernet', 'autoselect', '(100baseTX']

# Generated at 2022-06-11 03:24:04.027720
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test using static output from ifconfig -a
    ifconfig_path = 'None'
    ifconfig_options = '-a'

# Generated at 2022-06-11 03:24:13.233295
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    mod = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    p = GenericBsdIfconfigNetwork(mod)
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words = [
        'inet6',
        'fe80::1%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x16',
    ]
    p.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-11 03:24:22.125820
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:24:32.080470
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    print("GENERICBSDIFCONFIGNETWORK - test_GenericBsdIfconfigNetwork_populate")
    module = FakeModule()
    platform = Platform()
    platform.set('system', 'FreeBSD')
    module.set_platform(platform)
    network = GenericBsdIfconfigNetwork()
    network.check_options()
    result = network.populate()
    print(result)
    assert 'default_ipv4' in result
    assert 'default_ipv6' in result
    assert 'all_ipv4_addresses' in result
    assert 'all_ipv6_addresses' in result
    assert 'interfaces' in result
    assert 'interface_lo0' in result
    assert 'lo0' in result['interface_lo0']

# Generated at 2022-06-11 03:24:33.991409
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # GenericBsdIfconfigNetwork.parse_media_line()
    pass


# Generated at 2022-06-11 03:24:43.962313
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork