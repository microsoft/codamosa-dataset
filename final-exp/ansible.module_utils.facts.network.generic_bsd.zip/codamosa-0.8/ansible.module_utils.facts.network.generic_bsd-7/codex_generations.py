

# Generated at 2022-06-11 03:15:39.736069
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    net = GenericBsdIfconfigNetwork(None)

    ifconfig_path = net.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        return

    route_path = net.module.get_bin_path('route')

    if route_path is None:
        return
    
    # macosx has ipv6 issues on the ramdisk, we can safely ignore testing it here
    if platform.mac_ver()[0]:
        return

    # Test route command
    dummy_route_v4 = 'GATEWAY0\tlink#9\tUHLWI\ti8254x0\t11\t0\t0\n'

# Generated at 2022-06-11 03:15:50.482804
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()

    class ModuleMock:
        def __init__(self, fails=None):
            self.failed = False
            self.fails = fails

    class IfconfigMock:
        def __init__(self, interfaces, options='-a'):
            self.interfaces = interfaces
            self.options = options

        def run_command(self, command):
            if self.fails is not None:
                return self.fails.pop(0)
            else:
                output = '\n'.join([x[1] for x in self.interfaces])
                return (0, output, '')


# Generated at 2022-06-11 03:15:52.162759
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    results = GenericBsdIfconfigNetwork.get_default_interfaces()
    assert results


# Generated at 2022-06-11 03:16:02.356251
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    """ Unit test for method GenericBsdIfconfigNetwork.parse_inet_line """
    # Test parameters

# Generated at 2022-06-11 03:16:15.016444
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ml = MockLinux()
    mod = AnsibleModule(argument_spec=ml.argument_spec)
    mod._debug = True
    mod.params = ml.params
    mod.exit_json = ml.exit_json

    f = open(os.path.join(os.path.dirname(__file__), '../fixtures/BSD-ifconfig-a.out'), 'r')
    bsd_ifconfig_a_out = f.read()

    mod.run_command = (lambda x: (0, bsd_ifconfig_a_out, ''))
    mod.get_bin_path = (lambda x: "/usr/local/bin/" + x)

    n = GenericBsdIfconfigNetwork(mod)
    n.populate()

    assert mod.exit_json.called

# Generated at 2022-06-11 03:16:26.298616
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import textwrap
    module = Mock()

# Generated at 2022-06-11 03:16:35.014413
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module_args = dict(
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Override methods in the specific type of manager
    mm = ModuleManager(module=module)
    mm.populate()
    assert len(mm.facts) == 2
    assert mm.facts['ansible_network_resources']['interfaces'] == ['eth0']
    assert mm.facts['ansible_network_resources']['default_ipv4']['address'] == '10.1.1.1'

# Generated at 2022-06-11 03:16:45.111337
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # FreeBSD test data
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384', 'options=680003<RXCSUM,TXCSUM,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6>']

# Generated at 2022-06-11 03:16:52.230039
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Test get_options
    #  - options with no brackets
    #  - options with brackets but no comma
    #  - options with brackets and commas

    gbi = GenericBsdIfconfigNetwork()

    options = gbi.get_options('options')
    assert len(options) == 0

    options = gbi.get_options('options<>')
    assert len(options) == 0

    options = gbi.get_options('options<one>')
    assert len(options) == 1
    assert options[0] == 'one'

    options = gbi.get_options('options<one,two,three>')
    assert len(options) == 3
    assert options[0] == 'one'
    assert options[1] == 'two'
    assert options[2] == 'three'



# Generated at 2022-06-11 03:16:59.211446
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    my_class = GenericBsdIfconfigNetwork()

    for test_in, test_out in [
      (dict(type='loopback', media='Ethernet autoselect (jumbo)'), dict(type='ether')),
      (dict(type='unknown', media='Ethernet autoselect (jumbo)'), dict(type='ether')),
    ]:
        assert my_class.detect_type_media(test_in) == test_out



# Generated at 2022-06-11 03:17:19.805936
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:28.871000
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule({})
    GIN = GenericBsdIfconfigNetwork(module=module)

    class TestIfconfigModule(object):
        def __init__(self, module_path=None, module_args=None, module_name=None, module_original_args=None,
                     module_supports_check_mode=False, module_check_mode=False, no_log=False,
                     module_deprecation_warnings=set()):
            self.bin_path = None
            self.run_command = self.run_command

        def run_command(self, args, check_rc=True):
            cmd = ' '.join(args)
            if cmd == route_v4:
                return 0, out_v4, None
            elif cmd == route_v6:
                return 0, out_v

# Generated at 2022-06-11 03:17:35.531627
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    def0 = GenericBsdIfconfigNetwork(None)

    test0 = def0.get_options('OPTIONS')
    assert test0 == []
    test1 = def0.get_options('<OPTIONS>')
    assert test1 == []
    test2 = def0.get_options('<OPTIONS1,OPTIONS2>')
    assert test2 == ['OPTIONS1', 'OPTIONS2']


# Generated at 2022-06-11 03:17:48.656643
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """ Test function 'merge_default_interface' of class GenericBsdIfconfigNetwork"""

    myconfig = GenericBsdIfconfigNetwork()

    defaults = dict(interface = "eth0",
                    address = "10.0.0.1")

    interfaces = dict()
    interfaces['eth0'] = dict(ipv4 = [dict(address = "10.0.0.1",
                                           netmask = "255.255.255.0")])

    myconfig.merge_default_interface(defaults, interfaces, 'ipv4')

    assert defaults == dict(interface = "eth0",
                            address = "10.0.0.1",
                            netmask = "255.255.255.0")

    defaults = dict(interface = "eth0")

    interfaces = dict()

# Generated at 2022-06-11 03:17:53.701434
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    option_string = '<UP,POINTOPOINT,RUNNING,MULTICAST,IPv6>'
    # option_string = '<UP,RUNNING,SIMPLEX,'
    result = GenericBsdIfconfigNetwork.get_options(option_string)
    assert result == ['UP', 'POINTOPOINT', 'RUNNING', 'MULTICAST', 'IPv6']



# Generated at 2022-06-11 03:17:57.004705
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    ifconfig_network = GenericBsdIfconfigNetwork()

    assert ifconfig_network.get_options('<UP,LOWER_UP>') == ['UP', 'LOWER_UP']


# Generated at 2022-06-11 03:18:08.448916
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Execute method parse_media_line from class GenericBsdIfconfigNetwork
    # and return result

    ifconfig_output = [
        "udp4       0   0  *.12345                 *.*                    udp4",
        "options:49152<RXCSUM,TXCSUM,UDP_CSUM_OUT,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>",
        "inet 127.0.0.1 netmask 0xff000000",
        "inet6 ::1 prefixlen 128",
        "nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>",
        "media: Ethernet autoselect (1000baseT full-duplex,flowcontrol,rxpause,txpause)",
        "status: active"
    ]

    n

# Generated at 2022-06-11 03:18:15.236999
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig = GenericBsdIfconfigNetwork()
    # case 1: no interface in defaults
    defaults = {}
    interfaces = {'eth0': {'ipv4': [], 'ipv6': []}}
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert 'interface' not in defaults
    # case 2: interface not in interfaces
    defaults = {'interface': 'eth1'}
    interfaces = {'eth0': {'ipv4': [], 'ipv6': []}}
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert 'interface' in defaults
    # case 3: interface in interfaces, address not in defaults
    defaults = {'interface': 'eth0'}

# Generated at 2022-06-11 03:18:25.709640
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    m = GenericBsdIfconfigNetwork()
    i = {
        'lo0': {
            'device': 'lo0',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown'
        },
        'bge0': {
            'device': 'bge0',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown'
        }
    }
    m.detect_type_media(i)

# Generated at 2022-06-11 03:18:33.521191
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    network_fact_module = GenericBsdIfconfigNetwork()
    network_fact_module.module = module
    assert network_fact_module.get_default_interfaces('/sbin/route') == ({'interface': 'lo0'}, {'interface': 'lo0'})


# Generated at 2022-06-11 03:18:48.946074
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import subprocess

    if sys.version_info[:2] == (2, 6):
        raise SkipTest("Python 2.6 does not support subprocess.DEVNULL")

    platform = 'Generic_BSD_Ifconfig'
    module = AnsibleModule(argument_spec=dict())
    network_module = platform_impls[platform](module)

    # Test for FreeBSD
    # $ route -n get default
    #   route to: default
    #destination: default
    #       mask: default
    #    gateway: 192.168.1.1
    #  interface: em0

    # Test for OpenBSD
    # OpenBSD
    # $ route -n get default
    #   route to: default
    #destination: default
    #       mask: default
    #    gateway: 192.168.1.1
    #

# Generated at 2022-06-11 03:18:59.636649
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    iface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test legacy format
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, iface, ips)
    assert iface['ipv4'][0]['address'] == '127.0.0.1'
    assert iface['ipv4'][0]['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:19:10.228554
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    class GenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self):
            self.module = Mock()
            self.module.run_command = self.run_command
            self.module.warn = self.warn
            self.module.get_bin_path = self.get_bin_path

        def run_command(self):
            from collections import namedtuple
            Response = namedtuple('Response', ['rc', 'stdout', 'stderr'])
            return Response(rc = 0,
                            stdout = '',
                            stderr = '')

        def warn(self, msg):
            pass

        def get_bin_path(self, binary):
            if binary == 'ifconfig':
                return '/sbin/ifconfig'
            else:
                return None

    #

# Generated at 2022-06-11 03:19:22.366227
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    n = GenericBsdIfconfigNetwork()
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    n.module = module

# Generated at 2022-06-11 03:19:34.865703
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    network = GenericBsdIfconfigNetwork()

    # IP address with CIDR netmask
    words = 'inet 10.1.1.10 netmask 0xffffff00 broadcast 10.1.1.255'.split()
    interface = {}
    ips = dict(all_ipv4_addresses=[])
    network.parse_inet_line(words, interface, ips)

    assert interface['ipv4'][0]['address'] == '10.1.1.10'
    assert interface['ipv4'][0]['netmask'] == '255.255.255.0'
    assert interface['ipv4'][0]['network'] == '10.1.1.0'
    assert interface['ipv4'][0]['broadcast'] == '10.1.1.255'

    # IP address with

# Generated at 2022-06-11 03:19:46.103575
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    iface_module = GenericBsdIfconfigNetwork(dict())
    iface_module.parse_interface_line
    iface_module.parse_nd6_line
    iface_module.parse_ether_line
    iface_module.parse_media_line
    iface_module.parse_status_line
    iface_module.parse_lladdr_line
    iface_module.parse_inet_line
    iface_module.parse_inet6_line
    iface_module.parse_tunnel_line
    iface_module.parse_unknown_line
    iface_module.get_options
    iface_module.merge_default_interface

# Generated at 2022-06-11 03:19:56.690468
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = Mock()
    module.run_command = Mock()

    module.get_bin_path = Mock(side_effect=[
        "/sbin/ifconfig",
        "/sbin/route",
        "/sbin/ifconfig",
        "/sbin/route",
        "/sbin/ifconfig",
        "/sbin/route",
    ])


# Generated at 2022-06-11 03:20:02.211545
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module._ansible_verbosity = 1
    bsdif_network = GenericBsdIfconfigNetwork(module)
    assert dict == type(bsdif_network.get_interfaces_info(None, None)[0])


# Generated at 2022-06-11 03:20:12.993680
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = GenericBsdIfconfigNetwork.module.get_bin_path('ifconfig')

# Generated at 2022-06-11 03:20:19.741896
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print("GenericBsdIfconfigNetwork_get_interfaces_info")
    ifconfig_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "fixtures", "bsd", "ifconfig.bsd")
    ifconfig_options='-a'
    network = GenericBsdIfconfigNetwork(module=None)

# Generated at 2022-06-11 03:20:40.400197
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:20:51.374424
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork

    network = GenericBsdIfconfigNetwork()

    def mock_get_bin_path(path):
        if path == 'ifconfig':
            return '/sbin/ifconfig'
        if path == 'route':
            return '/sbin/route'
        return ''

    network.module.get_bin_path = mock_get_bin_path


# Generated at 2022-06-11 03:21:01.797344
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    test_GenericBsdIfconfigNetwork_get_interfaces_info
    """
    # Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
    assert True
    my_object = GenericBsdIfconfigNetwork()
    with patch("os.path.exists", new=Mock(return_value=True)) as mocked_path,\
            patch("os.access", new=Mock(return_value=True)) as mocked_access,\
            patch("os.stat", new=Mock(return_value=True)) as mocked_stat,\
            patch("os.X_OK", new=Mock(return_value=True)) as mocked_xok:
        mocked_path.return_value = True
        mocked_access.return_value = True
        mocked_stat.return_value = True

# Generated at 2022-06-11 03:21:11.409117
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import pytest

# Generated at 2022-06-11 03:21:22.322431
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from io import StringIO
    from ansible.module_utils.network.common.utils import get_module

    # ifconfig output for OpenBSD 5.2-current amd64

# Generated at 2022-06-11 03:21:30.316161
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gbi = GenericBsdIfconfigNetwork(module=None)
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address':'10.0.0.1/32'}],
                          'ipv6': [{'address':'fe80::1/64'}],
                          'type': 'loopback',
                          'macaddress': '00:00:00:00:00:00'}}
    gbi.merge_default_interface(defaults, interfaces, 'ipv4')


# Generated at 2022-06-11 03:21:42.552341
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    plugin = GenericBsdIfconfigNetwork(dict(module=DummyModule()))

    # ifconfig isn't found - network facts are empty
    plugin.module.run_command = MagicMock(return_value=(1, '', ''))
    fact = plugin.populate()
    expected_fact = dict()
    assert fact == expected_fact

    # ifconfig is found but route isn't - network facts are empty
    plugin.module.run_command = MagicMock(side_effect=[(0, '', ''), (1, '', '')])
    fact = plugin.populate()
    assert fact == expected_fact

    # ifconfig and route are found - network facts include default interfaces

# Generated at 2022-06-11 03:21:52.916104
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # These should both be empty
    empty_object = {}
    empty_dict = dict(interface=None)
    empty_dict_from_func = dict(interface=True)

    no_info = dict(interface="eth0",
                   interface_eth0=None)

    # No interface information
    wrong_interface = dict(interface="en0",
                           interface_en0=None)

    # Interface information, but no IP address information
    no_interface_ip_info = dict(interface="eth0",
                                interface_eth0=dict(ipv4=None, ipv6=None))

    # Interface matches and IP address matches

# Generated at 2022-06-11 03:22:03.669320
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print("Test parse_inet_line of class GenericBsdIfconfigNetwork")

    #set up some variables to test the function
    current_if = {
        'ipv4': []
    }
    ips = {}

    ###########################################################################
    # Test 1:
    # - input: words = ["inet", "127.0.0.1", "netmask", "0xff000000"]
    # - expected: current_if['ipv4'] = [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}]
    ###########################################################################
    words = ["inet", "127.0.0.1", "netmask", "0xff000000"]
    result = GenericBsdIfconfigNetwork.parse_inet_line

# Generated at 2022-06-11 03:22:11.098670
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = FakeModule()
    network = GenericBsdIfconfigNetwork({'module': module})
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {}
    ips = {}
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'


# Generated at 2022-06-11 03:22:29.522822
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    """
    Method: merge_default_interface(defaults, interfaces, ip_type)

    These tests all pass if no exceptions, errors or assertion failures occur.
    """

    # initialize
    defaults = {'interface': 'lo0'}
    ip_type = 'ipv4'
    interfaces = {'lo0': {'device': 'lo0',
                          'ipv4': [{'address': '127.0.0.1',
                                    'netmask': '255.0.0.0',
                                    'broadcast': '127.255.255.255'},
                                   {'address': '127.0.0.2',
                                    'netmask': '255.0.0.0',
                                    'broadcast': '127.255.255.255'}]}}

    # test 1
    generic

# Generated at 2022-06-11 03:22:40.235878
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # read static fixture output
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json = MagicMock(return_value=None)
    mock_command_output = {}
    # mock ifconfig output

# Generated at 2022-06-11 03:22:52.425054
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Test with input that contains a default IPv4 gateway, default IPv6
    # gateway, Ethernet interface and the loopback interface.
    test_module = generic_module_mock()
    test_platform = GenericBsdIfconfigNetwork()
    test_platform.module = test_module
    test_platform.module.run_command = MagicMock(
        side_effect=[
            (0, test_output1, b''),
            (0, test_output2, b'')
        ]
    )

    # This is the test output from ifconfig on Mac OS X Yosemite (10.10.5).

# Generated at 2022-06-11 03:23:01.343781
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    options = []
    current_if = {}
    ips = {}

    ifconfig_facts = GenericBsdIfconfigNetwork()

    # Test 1
    options = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    current_if = {}
    ips = {}
    ifconfig_facts.parse_media_line(options, current_if, ips)

    assert 'media' in current_if
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert 'media_options' not in current_if
    assert current_if['status'] == 'active'

    # Test 2

# Generated at 2022-06-11 03:23:07.879771
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    module = AnsibleModuleMock()
    gbn = GenericBsdIfconfigNetwork(module)

    route_path = gbn.module.get_bin_path('route')
    default_ip4, default_ip6 = gbn.get_default_interfaces(route_path)
    assert isinstance(default_ip4, dict)
    assert 'gateway' in default_ip4
    assert 'interface' in default_ip4
    assert isinstance(default_ip6, dict)

# Generated at 2022-06-11 03:23:13.935239
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = find_ifconfig()
    network_module = GenericBsdIfconfigNetwork()

    interfaces, ips = network_module.get_interfaces_info(ifconfig_path)

    assert 1 == len(interfaces)
    assert 'lo0' in interfaces
    assert 'lo0' in ips['all_ipv4_addresses']
    assert 'lo0' in ips['all_ipv6_addresses']

# Generated at 2022-06-11 03:23:24.178553
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils import basic

    # Test input containing old style tun interface (FreeBSD)
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    obj = GenericBsdIfconfigNetwork(module)

    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')
    module._init_module_args()
    module.params = dict()

    # Set expected return based on supplied test data

# Generated at 2022-06-11 03:23:26.721385
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    assert bsd_ifconfig_network.get_default_interfaces('/bin/route') == ({}, {})

# Generated at 2022-06-11 03:23:38.262185
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test detect_type_media()
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-11 03:23:48.549076
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_class = GenericBsdIfconfigNetwork()
    test_case = 'inet 127.0.0.1 netmask 0xff000000'
    test_result = dict()
    test_current_if = dict()
    test_current_if['ipv4'] = list()
    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_words = test_case.split()

    test_class.parse_inet_line(test_words, test_current_if, test_ips)
    test_result = test_current_if['ipv4']
    assert test_result[0]['address'] == '127.0.0.1'