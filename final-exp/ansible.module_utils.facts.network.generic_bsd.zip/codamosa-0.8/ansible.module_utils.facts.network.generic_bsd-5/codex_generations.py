

# Generated at 2022-06-11 03:15:29.306710
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:15:38.311489
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet6_line(["inet6","fe80::21f:5bff:febe:6d48%em0","prefixlen","64","scopeid","0x1"], current_if, ips)
    assert ips['all_ipv6_addresses'][0] == 'fe80::21f:5bff:febe:6d48%em0'

# Generated at 2022-06-11 03:15:46.683616
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    options = network.get_options("""<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,CHECKSUM_OFFLOAD(ACTIVE),CHAIN>""")
    assert options == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'GROUPRT', '64BIT', 'CHECKSUM_OFFLOAD(ACTIVE)', 'CHAIN']



# Generated at 2022-06-11 03:15:50.106187
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {'interface': {'media': 'ether'}}
    result = GenericBsdIfconfigNetwork().detect_type_media(interfaces)
    expected = {'interface': {'media': 'ether', 'type': 'ether'}}
    assert result == expected


# Generated at 2022-06-11 03:16:00.786358
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    ifconfig_path = 'tests/unit/modules/network/ifconfig_output/bsd/ifconfig_media'

# Generated at 2022-06-11 03:16:12.947921
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Setup mocks
    module_mock = Mock()
    # Mock the methods

# Generated at 2022-06-11 03:16:24.803865
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    raw_data = """
    inet6 2001:db8:1918:142::1 prefixlen 64
    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2
    """.splitlines()
    raw_data = [x.strip() for x in raw_data]
    raw_data = [x for x in raw_data if x]
    interfaces = {}
    ips = {'all_ipv4_addresses':[], 'all_ipv6_addresses':[]}
    iface = {'ipv4':[], 'ipv6':[]}
    for words in raw_data:
        words = words.split()

# Generated at 2022-06-11 03:16:36.391303
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:16:46.145818
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """Method detect_type_media of class GenericBsdIfconfigNetwork"""

    #testing media ether

# Generated at 2022-06-11 03:16:52.920311
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = NetworkModule()
    platform = 'Generic_BSD_Ifconfig'


# Generated at 2022-06-11 03:17:11.055452
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    inputdata = """
default: gateway: 192.168.0.1

default: gateway: 192.168.0.1
if address: 192.168.0.10

default: gateway: 192.168.0.1
local addr: 192.168.0.10

default: gateway: 192.168.0.1
if address: 172.16.0.10
local addr: 192.168.0.10
"""
    expected_output = {
        'interface': 'en0',
        'gateway': '192.168.0.1',
        'address': '192.168.0.10'
    }

    for testdata in inputdata.splitlines():
        testdata = testdata.strip()
        if testdata == "":
            continue

        testdata = testdata.split("\n")
        net

# Generated at 2022-06-11 03:17:19.627513
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class Arguments:
        def get_bin_path(self, s):
            return s

    class ifconfig_module:
        arguments = Arguments()

    platform = GenericBsdIfconfigNetwork()
    platform.module = ifconfig_module()

    result = dict()
    data_1 = dict(ipv4=[dict(address='192.168.1.1'), dict(address='127.0.0.1')])
    data_2 = dict(ipv4=[dict(address='192.168.1.1'), dict(address='127.0.0.1')])
    network_facts = dict(ens37=data_1, ens38=data_2)

    platform.merge_default_interface(result, network_facts, 'ipv4')

    assert result == dict()

# Generated at 2022-06-11 03:17:28.732600
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:40.925107
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def detect_type_media(self, interfaces):
            return interfaces
    net = TestGenericBsdIfconfigNetwork(None)
    default_ipv4 = {
        'gateway': '192.0.2.1',
        'interface': 'eth0',
        'address': '192.0.2.4'
    }

# Generated at 2022-06-11 03:17:52.829930
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = fake_ansible_module()
    network_facts = GenericBsdIfconfigNetwork(module)
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=['10.0.0.1'],
        all_ipv6_addresses=[],
    )

    words = "inet6 fe80::a00:27ff:fe7a:6e8b%lo0 prefixlen 64 scopeid 0x2".split()
    network_facts.parse_inet6_line(words, current_if, ips)
    assert ips['all_ipv6_addresses'] == ['fe80::a00:27ff:fe7a:6e8b%lo0'], "Failed to add IPv6 address to ips"

# Generated at 2022-06-11 03:17:56.638375
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as m_obj
    netobj = m_obj({
        'run_command': run_command,
    })
    netobj.populate()



# Generated at 2022-06-11 03:18:08.138592
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = {'interface': 'lo0', 'address': '127.1.1.1'}
    interface_name = defaults['interface']
    interfaces = {
        interface_name: {
            'device': interface_name,
            'ipv4': [{
                'address': '127.1.1.1',
                'broadcast': '127.255.255.255',
                'netmask': '255.0.0.0',
                'network': '127.1.1.1'
            }],
            'macaddress': 'unknown',
            'mtu': 33184,
            'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST']
        }
    }

# Generated at 2022-06-11 03:18:19.373363
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Mock ifconfig output

# Generated at 2022-06-11 03:18:26.284268
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()

    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'group', '1']
    current_if = {'ipv4': []}
    ips = dict(
        all_ipv4_addresses=[],
    )
    network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-11 03:18:37.256852
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_object = GenericBsdIfconfigNetwork()
    test_if = {}
    test_ips = { 'all_ipv4_addresses': []}

    test_words = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384"
    test_words = test_words.split()
    test_object.parse_interface_line(test_words, test_if, test_ips)
    assert test_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    test_words = "options=3<RXCSUM,TXCSUM>"
    test_words = test_words.split()

# Generated at 2022-06-11 03:18:59.903175
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    
    # Default IPv4, Default IPv6
    assert GenericBsdIfconfigNetwork.get_default_interfaces(None) == ({}, {})

    # IPv4
    assert GenericBsdIfconfigNetwork.get_default_interfaces(None, route_path='fixtures/route_default_ipv4.txt') == \
            ({'interface': 'en0', 'gateway': '10.0.0.1', 'address': '10.0.0.2'}, {})

    # IPv6
    assert GenericBsdIfconfigNetwork.get_default_interfaces(None, route_path='fixtures/route_default_ipv6.txt') == \
            ({}, {'interface': 'lo0', 'gateway': '::1'})


# Generated at 2022-06-11 03:19:10.567329
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:19:22.575829
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    hostname = 'example.org'
    port = 22
    username = 'username'
    password = 'password'
    # connection = Connection(host=hostname, port=port)
    # connection.connect(username=username, password=password)

    module_options = dict(
        hostname=hostname,
        port=port,
        username=username,
        password=password,
        gather_timeout=60,
        gather_subset=None,
        filter=None,
    )

    check_args = dict(
        module_defaults=module_options,
        connection=None,
        file_name='/sbin/ifconfig',
        check=None,
        echo=None,
    )

    module = MappedAttributeFilesystemModule(client=None, **check_args)


# Generated at 2022-06-11 03:19:30.425579
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Initialize mock values
    defaults = dict(interface='eth0')
    interfaces = dict(eth0=dict(ipv6=[]))
    ip_type = 'ipv6'

    # Test function
    # Uncomment to skip this test
    # raise SkipTest('This test is not yet implemented')
    # Invoke method
    GenericBsdIfconfigNetwork().merge_default_interface(defaults, interfaces, ip_type)



# Generated at 2022-06-11 03:19:38.729803
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    fake_module = MagicMock(name='ansible.module_utils.facts.network.generic_bsd.AnsibleModule')
    fake_module.get_bin_path.side_effect = lambda name: '/bin/' + name

# Generated at 2022-06-11 03:19:46.282183
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Test parameters
    module_args = { }

    # Module to be tested
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # Create the module to be tested
    instance = GenericBsdIfconfigNetwork(module)

    # Test results
    assert instance.get_interfaces_info([]) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-11 03:19:49.460781
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_subject = Network()
    test_subject_class = GenericBsdIfconfigNetwork()
    assert test_subject.merge_default_interface(None, None, None) == test_subject_class.merge_default_interface(None, None, None)



# Generated at 2022-06-11 03:20:02.171674
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    fake_module = AnsibleModule(argument_spec={})
    fake_module.run_command = MagicMock(return_value=(0, 'foo', 'bar'))


# Generated at 2022-06-11 03:20:12.949143
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils._text import to_bytes

    mf = ModuleFacts(dict(ANSIBLE_MODULE_ARGS=dict(gather_subset='network')))

    # fake network facts
    mf.network_facts = dict(interfaces={'lo0': {'macaddress': '01:23:45:67:89:ab'}})

    # fake route command output

# Generated at 2022-06-11 03:20:19.717275
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    class TestGenericBsdIfconfigNetwork:
        def __init__(self):
            self.module = AnsibleModule(argument_spec=dict())
            super(TestGenericBsdIfconfigNetwork, self).__init__()

    if platform.system() == 'OpenBSD' and platform.release() < '5.9':
        fixture = 'OpenBSD_fixture.txt'
    elif platform.system() == 'FreeBSD' and platform.release() < '10.0':
        fixture = 'FreeBSD_fixture.txt'
    elif platform.system() == 'NetBSD' and platform.release() < '7.1':
        fixture = 'NetBSD7_fixture.txt'
    elif platform.system() == 'Darwin':
        fixture = 'Darwin_fixture.txt'

# Generated at 2022-06-11 03:20:49.965837
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    interface_to_test = 'vtnet0'
    default_ipv4 = {'gateway': '192.168.0.1', 'interface': interface_to_test, 'address': '192.168.0.100', 'broadcast': '192.168.0.255', 'macaddress': 'unknown', 'netmask': '255.255.255.0'}

# Generated at 2022-06-11 03:20:56.675268
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = dict()

    # normal case
    words = ['inet6', 'fe80::9a5a:d8ff:fe23:40a0%lo0', 'prefixlen', '64', 'scopeid', '0x2', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x4', 'inet6', '2407:7800:400:42::a', 'prefixlen', '64', 'inet6', '2407:7800:400:42::b', 'prefixlen', '64', 'inet6', '2407:7800:400:42::c', 'prefixlen', '64']

# Generated at 2022-06-11 03:21:00.021296
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert GenericBsdIfconfigNetwork.get_options('foo') == []
    assert GenericBsdIfconfigNetwork.get_options('foo <UP,LOOPBACK>') == ['UP', 'LOOPBACK']



# Generated at 2022-06-11 03:21:01.007327
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    assert True


# Generated at 2022-06-11 03:21:10.227705
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from units.compat import unittest
    from units.compat.mock import patch

    network = GenericBsdIfconfigNetwork()

    # Test an invalid option string
    assert not network.get_options("")
    assert not network.get_options("bla")

    # Test a valid option string
    assert network.get_options("<UP,BROADCAST>") == ['UP', 'BROADCAST']
    assert network.get_options("<up,broadcast>") == ['up', 'broadcast']
    assert network.get_options("<up,broadcast,>") == ['up', 'broadcast']
    assert network.get_options("<up,broadcast, >") == ['up', 'broadcast']



# Generated at 2022-06-11 03:21:21.347302
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:23.674158
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    assert GenericBsdIfconfigNetwork().parse_inet_line(['inet', '127.0.0.1']) == {}


# Generated at 2022-06-11 03:21:31.100499
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:21:43.121038
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    fail_list = []
    network = GenericBsdIfconfigNetwork()

    defaults = {}

# Generated at 2022-06-11 03:21:53.402164
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    assert network.get_options('<LOOPBACK,UP,LOWER_UP>') == ['LOOPBACK', 'UP', 'LOWER_UP']
    assert network.get_options('<MULTICAST,BROADCAST,DEBUG>') == ['BROADCAST', 'DEBUG', 'MULTICAST']
    assert network.get_options('<UP>') == ['UP']
    assert network.get_options('<>') == []
    assert network.get_options('<UP> mtu 1500') == ['UP']



# Generated at 2022-06-11 03:22:29.158841
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    # The data for this test is taken from an actual DragonFlyBSD system.
    # This test asserts that the method detect_type_media() of the class
    # GenericBsdIfconfigNetwork correctly detects 'ether' type for device
    # names that contain 'media: Ethernet' in their output.

    ifconfig_path = "ifconfig"
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value=ifconfig_path)

    p = platform.system()
    fake_platform = 'Darwin'

    with patch('platform.system', return_value=fake_platform) and \
         patch.object(GenericBsdIfconfigNetwork, 'get_interfaces_info',
                      return_value=(IFINFO, IPS)) as mock_method:
        network_facts = GenericBsdIfconfig

# Generated at 2022-06-11 03:22:39.895200
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # localhost6 = ['::1', '::1/128', 'fe80::1%lo0']
    # if address['address'] not in localhost6:
    #     ips['all_ipv6_addresses'].append(address['address'])
    # current_if['ipv6'].append(address)
    gbin = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    words = ['inet6', '::1', 'prefixlen', '128', 'link', 'anycast']
    gbin.parse_inet6_line(words, current_if, ips)
    assert {} == current_if
    assert {} == ips

    words = ['inet6', '::1', 'prefixlen', '128', 'link', 'anycast']
    current_if = {}

# Generated at 2022-06-11 03:22:46.425550
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    print ("Testing method get_options of class GenericBsdIfconfigNetwork")
    net = GenericBsdIfconfigNetwork()

    assert net.get_options('foo <bar,baz>') == ['bar', 'baz']
    assert net.get_options('foo <bar>') == ['bar']
    assert net.get_options('foo bar') == []

# Generated at 2022-06-11 03:22:56.488637
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    g = GenericBsdIfconfigNetwork()

    # an inet6 line with a cidr prefix - without a scope
    words = ['inet6', 'fc00:1::1/64', 'alias', 'foobar']
    iface = {'ipv6': []}
    ips = {}
    g.parse_inet6_line(words, iface, ips)
    result = iface['ipv6'][0]
    assert result['address'] == 'fc00:1::1'
    assert result['prefix'] == '64'

    # an inet6 line with a cidr prefix - with a scope
    words = ['inet6', 'fc00:1::1/64', 'alias', 'foobar', 'scopeid', '0x1']
    iface = {'ipv6': []}
   

# Generated at 2022-06-11 03:23:07.290271
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Prepare the parameters that would be returned by external_plugin

# Generated at 2022-06-11 03:23:17.789720
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = 'en0'
    media = 'autoselect'
    media_select = 'status: inactive'
    media_type = 'none'
    media_options = 'none'
    network = GenericBsdIfconfigNetwork()

    network.parse_media_line(['media:', media, media_select, media_type, media_options],
                             {'device': iface}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

    assert network.interfaces[iface]['media'] == media
    assert network.interfaces[iface]['media_select'] == media_select
    assert network.interfaces[iface]['media_type'] == media_type
    assert network.interfaces[iface]['media_options'] == media_options

#

# Generated at 2022-06-11 03:23:22.331424
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network.parse_inet_line(['inet', '127.0.0.1', 'netmask', '0xff000000'], {}, {'all_ipv4_addresses':[]})



# Generated at 2022-06-11 03:23:29.110350
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_output_path = 'ifconfig_output.txt'
    ifconfig_output_file = open(ifconfig_output_path, 'r')
    ifconfig_output = ''
    for line in ifconfig_output_file:
        ifconfig_output += line
    ifconfig_output_file.close()

    n = GenericBsdIfconfigNetwork()
    interfaces, ips = n.get_interfaces_info('/sbin/ifconfig', ifconfig_options="-a")

    # mock module
    module = Mock()
    module.run_command.return_value = (0, ifconfig_output, "")
    n.module = module

    interfaces, ips = n.get_interfaces_info('/sbin/ifconfig')
    assert 'eth0' in interfaces.keys()

# Generated at 2022-06-11 03:23:40.922411
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:23:50.306559
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # create an instance of the class being tested
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    # create a mock "route" command that we expect the module to call
    mock_route_path = create_mock_command('route', 'route_path')
    # set the "route" path to this mock command
    generic_bsd_ifconfig_network.module.run_command = mock_route_path
    # success case
    mock_route_path.append([0, 'default: gateway: 10.1.1.1', ''])
    mock_route_path.append([0, '    interface: vr0', ''])
    # failure case
    mock_route_path.append([1, '', 'RTNETLINK answers: Invalid argument'])
    # ipv6 route not configured
   

# Generated at 2022-06-11 03:24:37.958089
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import textwrap
    n = GenericBsdIfconfigNetwork()
    # output from ifconfig -a command on FreeBSD 8.2

# Generated at 2022-06-11 03:24:47.306160
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network_info = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Test case 1
    # Test words = ['inet', 'alias', '127.1.1.1', 'netmask', '0xff000000']
    words = ['inet', 'alias', '127.1.1.1', 'netmask', '0xff000000']

    network_info = GenericBsdIfconfigNetwork.parse_inet_line(
        words=words,
        current_if=current_if,
        ips=ips)
