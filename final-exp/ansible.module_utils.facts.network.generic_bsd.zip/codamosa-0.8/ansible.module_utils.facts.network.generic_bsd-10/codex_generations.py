

# Generated at 2022-06-11 03:15:32.701045
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    m_mod = MagicMock()
    ifconfig_path = m_mod.get_bin_path.return_value
    n_obj = GenericBsdIfconfigNetwork(m_mod)
    interface_info = {}
    ap_line = 'media: Ethernet autoselect (1000baseT <full-duplex>) status: active'
    # Case 1: media line with 4 words
    media_words = ap_line.split()
    n_obj.parse_media_line(media_words, interface_info, None)
    assert interface_info['media'] == 'Ethernet'
    assert interface_info['media_select'] == 'autoselect'
    assert interface_info['media_type'] == '1000baseT'
    assert interface_info['media_options'] == ['full-duplex']
    # Case 2: media

# Generated at 2022-06-11 03:15:44.393684
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    mac_example = ['en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500\n']
    expected_mac_example = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'ether', 'macaddress': 'unknown', 'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'mtu': '1500'}
    lo_example = ['lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384\n']

# Generated at 2022-06-11 03:15:53.120561
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    Test function for get_interfaces_info
    """
    ifconfig_path = "ifconfig"

    # Test for typical values
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.params = dict()
    test_obj = GenericBsdIfconfigNetwork(module)
    interfaces, ips = test_obj.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-11 03:16:02.943531
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    interface = {}
    ips = {}
    words = ['media:', 'Ethernet', '100baseTX', '<full-duplex,flow-control>']
    # expected = {'device': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'ether', 'macaddress': 'unknown', 'options': [], 'media': 'Ethernet', 'media_select': '100baseTX', 'media_type': 'full-duplex', 'media_options': ['flow-control']}

    network_modules_generic_bsd_ifconfig.GenericBsdIfconfigNetwork.parse_media_line(words, interface, ips)

    assert 'media' in interface
    assert interface['media'] == 'Ethernet'
    assert 'media_select' in interface

# Generated at 2022-06-11 03:16:15.357292
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    from ansible.module_utils._text import to_bytes

    facts = GenericBsdIfconfigNetwork()
    ifconfig_path = '/sbin/ifconfig'
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # FreeBSD, DragonflyBSD, NetBSD, OpenBSD and macOS all implicitly add '-a'
    # when running the command 'ifconfig'.
    # Solaris must explicitly run the command 'ifconfig -a'.
    rc, out, err = facts.module.run_command([ifconfig_path])

    for line in out.splitlines():

        if line:
            words = line.split()

            if words[0] == 'pass':
                continue

# Generated at 2022-06-11 03:16:26.545441
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(
        argument_spec={

        },
        supports_check_mode=True
    )

    # Set up a test GenericBsdIfconfigNetwork object
    GBIN = GenericBsdIfconfigNetwork()

    # Set up a test dictionaries
    defaults = {'interface':'lo0', 'address':'5.5.5.5', 'foo':99, 'bar':'fish', 'ipv4':[]}

# Generated at 2022-06-11 03:16:38.551727
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    # Arrange

    defaults = {'interface': 'en0'}

# Generated at 2022-06-11 03:16:46.345177
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    c = GenericBsdIfconfigNetwork()
    # Default arguments
    words = 'media: Ethernet autoselect (1000baseT <full-duplex>) status: active'.split()
    current_if = {}
    ips = {}
    c.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(1000baseT'
    assert current_if['media_options'] == ['full-duplex']
    assert current_if['status'] == 'active'



# Generated at 2022-06-11 03:16:53.079726
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384', 'options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>']
    network = GenericBsdIfconfigNetwork()
    current_if = network.parse_interface_line(words)

# Generated at 2022-06-11 03:16:53.805684
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass

# Generated at 2022-06-11 03:17:27.185316
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class FakeModule():
        def get_bin_path(self, arg):
            return 'fake_bin_path'

        def run_command(self, arg):
            return (0, 'fake_output_0', '')

    class FakeNetwork():
        def __init__(self, module):
            pass

    net = GenericBsdIfconfigNetwork(FakeModule())
    default_ipv4, default_ipv6 = net.get_default_interfaces('fake_route_path')
    assert default_ipv4['interface'] == 'fake_output_0'


# Generated at 2022-06-11 03:17:39.339712
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbi = GenericBsdIfconfigNetwork(module)

    # Blank option_string
    option_string = ''
    option_csv = gbi.get_options(option_string)
    assert option_csv == [], "option_csv='%s'" % option_csv

    # Empty option_string
    option_string = '<>'
    option_csv = gbi.get_options(option_string)
    assert option_csv == [], "option_csv='%s'" % option_csv

    # Single option
    option_string = '<BROADCAST>'
    option_csv = gbi.get_options(option_string)
    assert option_csv == ['BROADCAST'], "option_csv='%s'" % option_csv

    # Multiple options

# Generated at 2022-06-11 03:17:44.905961
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import struct
    import socket

    test_iface={'ipv4': [], 'device': 'lo0', 'mtu': '33184', 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}
    test_ips =  {'all_ipv4_addresses': []}

    # netbsd show aliases like this
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0.0.1 netmask 0xff000000
    #         inet alias 127.1.1.1 netmask 0xff000000
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    GenericBsdIfconfigNetwork.parse_

# Generated at 2022-06-11 03:17:55.004899
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network_facts = GenericBsdIfconfigNetwork()
    network_facts.module = AnsibleModuleMock()
    out = network_facts.populate()
    assert out['default_ipv4']['interface'] == 'lo0'
    assert out['default_ipv4']['address'] == '127.0.0.1'
    assert out['default_ipv4']['netmask'] == '255.0.0.0'
    assert out['default_ipv4']['network'] == '127.0.0.0'
    assert out['default_ipv4']['broadcast'] == '127.255.255.255'
    assert len(out['all_ipv4_addresses']) > 0
    assert len(out['all_ipv6_addresses']) > 0
   

# Generated at 2022-06-11 03:18:05.536170
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    obj = GenericBsdIfconfigNetwork()

    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'media': 'media: Ethernet autoselect (1000baseT <full-duplex>)',
    }

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # If contains media
    words = "media: Ethernet autoselect (1000baseT <full-duplex>)".split()
    result = obj.parse_media_line(words, current_if, ips)
    assert result == None


# Generated at 2022-06-11 03:18:13.765999
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    print("module_parse_inet_line")
    o = {}
    o['ipv4'] = []
    o['all_ipv4_addresses'] = []
    words = ['alias', '192.168.1.1', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    ans = {'broadcast':'192.168.1.255', 'netmask':'255.255.255.0',
           'address':'192.168.1.1', 'network':'192.168.1.0'}
    g = GenericBsdIfconfigNetwork()
    g.parse_inet_line(words, o, o)
    assert(len(o['ipv4']) == 1)
    assert(ans == o['ipv4'][0])
   

# Generated at 2022-06-11 03:18:25.113161
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    result = GenericBsdIfconfigNetwork.get_interfaces_info('ignored', [
        'en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500',
        'ether 2c:f0:ee:e7:67:13',
        'inet6 fe80::2ef0:eeff:fee7:6713%en0 prefixlen 64 scopeid 0x4',
        'inet 10.0.0.51 netmask 0xffffff00 broadcast 10.0.0.255',
        'nd6 options=1<PERFORMNUD>',
        'media: autoselect',
        'status: active',
    ])
    assert result['en0']['mtu'] == '1500'

# Generated at 2022-06-11 03:18:36.329415
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class Fake_ifconfig_network_plugin(GenericBsdIfconfigNetwork):
        def __init__(self, a, b, c):
            pass

    n = Fake_ifconfig_network_plugin(None, None, None)

    default_ipv6 = {'interface': 'lo0', 'address': '::1'}

# Generated at 2022-06-11 03:18:45.589051
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    module = AnsibleModule(argument_spec={})
    network_class = GenericBsdIfconfigNetwork()

    from ansible.module_utils.facts.network.test_get_interfaces_info_data import TEST_DATA
    for data in TEST_DATA:
        result = network_class.get_interfaces_info(data['test_path'], data['test_options'])
        print('[test] got:', result)
        print('[test] expected:', data['test_result'])

        assert data['test_result'] == result, 'test_interfaces_info failed'


# Generated at 2022-06-11 03:18:57.009179
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_words = [
        'inet6',
        'fe80::1%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x2',
        '0x1',
        'nd6',
        'options=21<PERFORMNUD,AUTO_LINKLOCAL>',
        'groups:',
        'lo'
    ]
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet6_line(test_words, current_if, ips)
   

# Generated at 2022-06-11 03:19:29.403374
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test cases for the method parse_inet6_line of class GenericBsdIfconfigNetwork
    # This method parses a line beginning with 'inet6' in ifconfig output
    # and returns a partial interface structure

    # Sample ifconfig output line: inet6 ::1 prefixlen 128
    # Sample ifconfig output line: inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2
    example_line_1 = ['inet6', '::1', 'prefixlen', '128']
    example_line_2 = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']

    # Define the expected output for each test case
    expected_output_1 = {'address': '::1', 'prefix': '128'}

# Generated at 2022-06-11 03:19:38.339828
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    # Test for dotted-quad ip address with dotted-quad netmask
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['inet', '192.0.2.0', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '192.0.2.0'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_

# Generated at 2022-06-11 03:19:48.974735
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    mgb = GenericBsdIfconfigNetwork(module)
    assert mgb.get_options('flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert mgb.get_options('options=409<VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM> mtu 1500') == ['VLAN_MTU', 'VLAN_HWTAGGING', 'VLAN_HWCSUM']
    assert mgb.get_options('foo=bar') == []
    assert mgb.get_options('') == []
    assert mgb.get_options('   ') == []
    assert mgb.get_options('<someting>') == []

# Generated at 2022-06-11 03:20:00.973978
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    collected_facts = {}
    module = MagicMock()
    module.get_bin_path.return_value = 'route'
    module.run_command.return_value = (0, 'default: gateway 192.168.1.1\ninterface: en1\n\
        local addr: 127.0.0.1\nstatus: active\n', '')
    ifc = GenericBsdIfconfigNetwork(module)
    default_ipv4, default_ipv6 = ifc.get_default_interfaces(route_path='route')

    assert default_ipv4['interface'] == 'en1'
    assert default_ipv4['gateway'] == '192.168.1.1'
    assert default_ipv4['address'] == '127.0.0.1'



# Generated at 2022-06-11 03:20:06.038261
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = FakeModule()
    obj = GenericBsdIfconfigNetwork(module)

    # TODO: consider other test cases, probably all variants of
    #       flags=<some,flags>...


# Generated at 2022-06-11 03:20:15.555959
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:20:26.712669
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'e1000g0'}

# Generated at 2022-06-11 03:20:33.217323
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    instance = GenericBsdIfconfigNetwork()

    interfaces = dict()
    interfaces['xn0'] = dict()
    interfaces['xn1'] = dict()
    interfaces['xn2'] = dict()

    interfaces['xn0']['media'] = 'Ethernet autoselect'
    interfaces['xn1']['media'] = 'Ethernet autoselect (100baseTX full-duplex)'
    interfaces['xn2']['media'] = 'Ethernet autoselect'

    instance.detect_type_media(interfaces)

    assert('xn0' not in instance.detect_type_media(interfaces))
    assert('xn1' not in instance.detect_type_media(interfaces))
    assert('xn2' in instance.detect_type_media(interfaces))

# Generated at 2022-06-11 03:20:44.526142
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    def_v4 = dict(interface='eth0')
    def_v6 = dict(interface='eth0')
    ifs = dict(eth0=dict(ipv4=[dict(address='192.168.0.1')],
                          ipv6=[],
                          type='ether'))

    GenericBsdIfconfigNetwork.merge_default_interface(def_v4, ifs, 'ipv4')
    assert def_v4['address'] == '192.168.0.1'
    assert def_v4['type'] == 'ether'
    assert 'ipv4' not in def_v4
    assert 'ipv6' not in def_v4

    def_v4 = dict(interface='eth0')
    def_v6 = dict(interface='eth0')

# Generated at 2022-06-11 03:20:54.038398
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(argument_spec={})
    GenericBsdIfconfigNetwork(module)
    iface = {}

    # Test with zero optional arguments
    words = ["media:", "Ethernet", "10GbaseSR", "(10.1)", "full"]
    GenericBsdIfconfigNetwork.parse_media_line(module, words, iface, {})
    assert iface["media"] == "Ethernet"
    assert iface["media_select"] == "10GbaseSR"
    assert iface["media_type"] == "(10.1)"
    assert iface["media_options"] == "full"

    # Test with one optional argument
    words = ["media:", "Ethernet", "(10.1)", "full"]

# Generated at 2022-06-11 03:21:42.039461
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    sub_class = GenericBsdIfconfigNetwork()
    sub_class.module = AnsibleModuleMock()
    sub_class.module.get_bin_path.side_effect = lambda arg: arg
    os_mock = mock.MagicMock()
    os_mock.path.exists.side_effect = lambda arg: arg == route_path
    with mock.patch('os', os_mock):
        route_path = '/sbin/route'
        expected_v4 = dict(interface='en0', gateway='10.0.1.1')
        expected_v6 = dict(interface='en0', gateway='fe80::a00:27ff:fe1b:8b33%en0')
        actual_v4, actual_v6 = sub_class.get_default_interfaces(route_path)



# Generated at 2022-06-11 03:21:46.181623
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    facts = GenericBsdIfconfigNetwork()
    assert facts.get_default_interfaces("route -n get default") == ({'interface': 'lo0', 'gateway': '127.0.0.1'}, {'interface': 'lo0', 'gateway': '::1'})


# Generated at 2022-06-11 03:21:55.565753
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    import platform
    sys_name = platform.system().lower()
    class MockerModule:
        def get_bin_path(self, cmd):
            if cmd in ['ifconfig', 'route']:
                return '/sbin/' + cmd
            else:
                return None
        def run_command(self, cmd):
            if cmd == ['/sbin/route', '-n', 'get', 'default']:
                return 0, 'default: localhost\ngateway: 127.0.0.1', ''
            elif cmd == ['/sbin/route', '-n', 'get', '-inet6', 'default']:
                return 0, 'default: localhost\ngateway: ::1', ''

# Generated at 2022-06-11 03:22:05.139398
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={'config': {'type': 'dict'}, 'gather_subset': {'type': 'list'}})
    network = GenericBsdIfconfigNetwork(module)
    defaults = {'interface': 'en0'}
    interfaces = {'en0': {'ipv4': [], 'ipv6': [], 'metric': '', 'device': 'en0', 'mtu': '1500', 'macaddress': '00:00:00:00:00:00'}}
    network.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['device'] == 'en0'
    assert defaults['mtu'] == '1500'
    assert defaults['macaddress'] == '00:00:00:00:00:00'

# Generated at 2022-06-11 03:22:16.207201
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Set up the class
    gi = GenericBsdIfconfigNetwork()
    class_method = gi.get_default_interfaces

    # Set up the test case
    test_input = ['route','-n','get', '-inet6', 'default']

    # Run the test
    test_result = class_method(test_input)

    # Check the results
    print('>>> Test Method: {0}'.format(class_method.__name__))
    print('>>> Input: {0}'.format(test_input))
    print('>>> Output: {0}'.format(test_result))

    # Assert that the test pass
    assert len(test_result) == 2
    assert len(test_result[0]) > 0
    assert len(test_result[1]) > 0

# Generated at 2022-06-11 03:22:27.006171
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    netinfo  = {
        'default_ipv4': {'gateway': '192.0.2.1'},
        'default_ipv6': {'gateway': '2001:db8::1'},
        'interfaces': [],
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    defaults = {
        'interface': 'en0',
        'gateway': '192.0.2.1',
    }

# Generated at 2022-06-11 03:22:37.955829
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Create a GenericBsdIfconfigNetwork class object
    GenericBsdIfconfigNetwork_obj = GenericBsdIfconfigNetwork()
    # Create a dictionary object
    interfaces = {}
    # Create a dictionary object
    ips = {}
    # Create a dictionary object
    current_if = {}
    # Create a list object
    words = []
    # Assign values to object
    words.append("lo0")
    words.append("inet")
    words.append("127.0.0.1")
    words.append("netmask")
    words.append("0xff000000")
    # Calling the method parse_inet_line of class GenericBsdIfconfigNetwork
    GenericBsdIfconfigNetwork_obj.parse_inet_line(words, current_if, ips)
    # Check the value of key 'address' in 'current_

# Generated at 2022-06-11 03:22:49.240983
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    my_module = FakeAnsibleModule()

# Generated at 2022-06-11 03:22:54.513139
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = Mock()
    module.run_command.return_value = (0, 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184\n', None)
    module.get_bin_path.return_value = '/usr/sbin/ifconfig'
    cls = GenericBsdIfconfigNetwork(module)
    interfaces, ips = cls.get_interfaces_info('/usr/sbin/ifconfig', ifconfig_options='')
    for item in interfaces:
        for link in interfaces[item]:
            assert(link == 'device' or link == 'ipv4' or link == 'ipv6')
    assert(len(interfaces) > 0)
    assert(len(ips) == 2)

# Generated at 2022-06-11 03:23:05.196607
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    ifconfig_path = '/sbin/ifconfig'

    route_path = '/sbin/route'

    interfaces_v4 = {'interface': 'gif0', 'gateway': '10.0.0.1'}

    interfaces_v6 = {'interface': 'gif0',
                     'gateway': '2001:db8:a0b:12f0::1',
                     'address': 'fe80::5efe:10.0.0.1%gif0'}

    network = GenericBsdIfconfigNetwork()

    def_interfaces_v4, def_interfaces_v6 = network.get_default_interfaces(route_path)

    assert def_interfaces_v4 == interfaces_v4

    assert def_interfaces_v6 == interfaces_v6

# Generated at 2022-06-11 03:24:23.296927
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    real_open_fds = __builtin__.open
    __builtin__.open = MagicMock()

# Generated at 2022-06-11 03:24:30.442038
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    assert GenericBsdIfconfigNetwork.parse_inet_line(['inet', 'addr:10.0.0.1' , 'P-t-P:10.10.10.10', 'Mask:255.255.255.0', 'UP', 'POINTOPOINT', 'BROADCAST'], {}, {}) == {'ipv4': [{'address': '10.0.0.1', 'netmask': '255.255.255.0', 'broadcast': '10.10.10.10', 'network': '10.0.0.0'}]}

# Generated at 2022-06-11 03:24:41.393426
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.legacy import OpenBSDIfconfigNetwork
    from ansible.module_utils import basic


    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        """Imitate the module's run_command method."""
        if cmd[0] == "ifconfig":
            return (0, IF_CONFIG_OUTPUT, None)
        elif cmd[0] == "route":
            return (0, ROUTE_OUTPUT, None)
        else:
            raise Exception("Unrecognized command: %s" % cmd)

    # inject our fake run_command method into the AnsibleModule
    basic._ANSIBLE