

# Generated at 2022-06-11 03:15:28.397795
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.check_mode = False
    module.exit_json = MagicMock()
    GenericBsdIfconfigNetwork.get_default_interfaces = MagicMock()
    GenericBsdIfconfigNetwork.get_default_interfaces.return_value = ''
    GenericBsdIfconfigNetwork.get_interfaces_info = MagicMock()
    GenericBsdIfconfigNetwork.get_interfaces_info.return_value = ''
    GenericBsdIfconfigNetwork.merge_default_interface = MagicMock()
    GenericBsdIfconfigNetwork.merge_default_interface.return_value = ''
    g = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-11 03:15:37.761376
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    default = {
        'interface': 'eth0',
        'gateway': '192.168.1.1',
        'address': '192.168.1.5'
    }
    interface = {
        'eth0': {
            'device': 'eth0',
            'ipv4': [
                {
                    'address': '192.168.1.5',
                    'netmask': '255.255.255.0',
                    'broadcast': '192.168.1.255',
                    'network': '192.168.1.0'
                }
            ]
        }
    }
    network = GenericBsdIfconfigNetwork()
    network.merge_default_interface(default, interface, 'ipv4')
    assert "interface" in default
    assert "gateway" in default

# Generated at 2022-06-11 03:15:49.787552
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    """
    Test for method parse_media_line of class GenericBsdIfconfigNetwork
    """
    test_object = GenericBsdIfconfigNetwork()

    # Test case with ifconfig -a line
    # wlan0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0
    #         mtu 1500
    #         ether 00:e0:4c:68:00:02
    #         nd6 options=1<PERFORMNUD>
    #         media: IEEE 802.11 Wireless Ethernet autoselect mode 11g
    #         status: associated
    #         ssid ssidname channel 11 (2462 MHz 11g) bssid 00:1d:2b:e8:3a:3c
    #         country US authmode WPA privacy ON deftxkey UN

# Generated at 2022-06-11 03:15:56.970928
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    globals()['__builtins__']['socket'] = FakeSockectModule()
    module = AnsibleModule(
        argument_spec=dict(
            test_option=dict(required=True, type='str')
        )
    )
    gen_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    assert sorted(gen_bsd_ifconfig_network.get_options(module.params['test_option'])) == sorted(module.params['test_option'].split(','))

# Generated at 2022-06-11 03:16:07.064122
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            if arg == 'ifconfig':
                return 'ifconfig'

    module = ModuleStub()
    network = GenericBsdIfconfigNetwork(module)

    v4_ip_route = {'interface': 'lo0', 'gateway': '127.0.0.1'}
    v6_ip_route = {'interface': 'lo0'}
    command = dict(v4='route -n get default', v6='route -n get -inet6 default')

    def ip_route_side_effect(*args, **kwargs):
        rc = 0
        out = ''
        err = ''


# Generated at 2022-06-11 03:16:20.039406
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # let's use our test data
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)

    test_route_path = get_test_route_path()

    # Test a known Darwin result
    darwin_defaults = {'interface': 'en0',
                       'gateway': 'fe80::22e:94ff:fe39:6412%en0',
                       'address': 'fe80::b1a:3bbc:f2b3:de6%en0'}
    this_defaults = network.get_default_interfaces(test_route_path + '/darwin')
    assert this_defaults == darwin_defaults

    # Test a known FreeBSD result

# Generated at 2022-06-11 03:16:23.794206
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    facts = dict()
    global_args = dict()
    facts['platform'] = 'FreeBSD'

    module = AnsibleModule(argument_spec=global_args)
    module.exit_json(**facts)


# Generated at 2022-06-11 03:16:30.773328
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule({})
    obj = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    obj.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'


# Generated at 2022-06-11 03:16:42.400279
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    command = dict(v4={'rc': 0, 'out': 'default via 192.168.123.1 dev eth0', 'err': ''},
                   v6={'rc': 0, 'out': 'default dev eth0 lladdr 00:00:00:00:00:00:00:01:00:00:00:00:00:00:00:01 REACHABLE', 'err': ''})

    magic_mock_module = MagicMock()
    magic_mock_module.run_command.side_effect = lambda command, check_rc=True: command[command[0]]

    network_module = GenericBsdIfconfigNetwork(magic_mock_module)

    ipv4, ipv6 = network_module.get_default_interfaces('some_route_path')


# Generated at 2022-06-11 03:16:50.297802
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # setup test data - check parse_inet_line method of class GenericBsdIfconfigNetwork
    input_words = ['lo0','inet','127.0.0.1','netmask','0xff000000']
    current_if = {}
    ips = {}
    # call the method
    GenericBsdIfconfigNetwork.parse_inet_line(GenericBsdIfconfigNetwork, input_words, current_if, ips)
    # check the results
    assert current_if['ipv4'] == [{'netmask': '255.0.0.0', 'address': '127.0.0.1', 'network': '127.0.0.0', 'broadcast': '127.255.255.255'}]
    assert ips == {'all_ipv4_addresses': ['127.0.0.1']}

# Generated at 2022-06-11 03:17:10.936728
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    x = GenericBsdIfconfigNetwork()
    defaults = dict(interface='eth0', address='2001:0db8:85a3:0000:0000:8a2e:0370:7334')

# Generated at 2022-06-11 03:17:19.542190
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule({})
    # Use the constructor to test method get_interfaces_info
    # class is instantiated in AnsibleModule.run_command
    network = GenericBsdIfconfigNetwork(module, 'test_GenericBsdIfconfigNetwork_get_interfaces_info')

    #
    # DragonflyBSD tests
    #
    # DragonflyBSD ifconfig (without -a)
    # ifconfig_dragonflybsd_v4 = """
    # lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    #         options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
    #         inet6 fe80::1%lo0 prefixlen 64 scopeid 0x3

# Generated at 2022-06-11 03:17:28.664829
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import dict_merge

    # TODO: this setup code should be moved to a separate method and not be repeated for every test method
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network_module = NetworkModule(module=module,
                                   add_argument_spec=Network.add_argument_spec)

    result = dict(changed=False,
                  failed=False,
                  warnings=[])

    wrap_ansible_module_defaults(module)

    # note: to test default collections of facts, we should use the ansible_facts field,
    #       not ansible_local

    facts = dict(ansible_facts=dict())

    # run populate to gather

# Generated at 2022-06-11 03:17:35.212036
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # If this is true, then we are running inside a test.
    # Add any additional test-only setups here.
    if 'ANSIBLE_TEST_LIB' in os.environ:
        pass    # do something
    # If this is true, then we are running inside a test.
    # Add any additional test-only setups here.
    if 'ANSIBLE_TEST_LIB' in os.environ:
        pass    # do something

# Generated at 2022-06-11 03:17:47.460779
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Arrange.
    iface = 'lo0'
    words = ['inet6', '::1', 'prefixlen', '128', 'alias']
    current_if = {}
    ips = dict(
        all_ipv6_addresses=[],
    )
    expected = dict(
        address = '::1',
        prefix = '128',
        scope = 'alias'
    )
    # Act.
    GenericBsdIfconfigNetwork().parse_inet6_line(words, current_if, ips)
    # Assert.
    assert(current_if['ipv6'][0] == expected)
    assert(ips['all_ipv6_addresses'][0] == '::1')


# Generated at 2022-06-11 03:17:55.152321
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    iface1 = {'media' : 'Ethernet autoselect'}
    iface2 = {'media' : 'Ethernet'}
    interfaces1 = {'iface1':iface1}
    interfaces2 = {'iface2':iface2}
    generic_bsd_ifconfig_network.detect_type_media(interfaces1)
    generic_bsd_ifconfig_network.detect_type_media(interfaces2)
    assert iface1['type'] == 'ether'
    assert iface2['type'] == 'ether'


# Generated at 2022-06-11 03:18:05.651960
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    fixture_path = os.path.join(fixture_dir, 'GenericBsdIfconfigNetwork_populate3.txt')
    with open(fixture_path, 'r') as f:
        data = f.read()
    # GenericBsdIfconfigNetwork.run_command = lambda self, *args: data, 0, ''
    GenericBsdIfconfigNetwork.run_command = run_command
    obj = GenericBsdIfconfigNetwork()
    obj.module = module
    assert obj.populate() == load_fixture('GenericBsdIfconfigNetwork_populate3.json')

# Generated at 2022-06-11 03:18:13.846144
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # We are testing 'parse_inet6_line' of class GenericBsdIfconfigNetwork

    # The first argument to the class constructor is the module
    # self.module = TheModule(argument_spec)

    # Create a class object
    obj = GenericBsdIfconfigNetwork(module=None)

    words = ['inet6', 'fe80::99e2:c9ff:fe38:b3e3', 'prefixlen', '64', 'scopeid', '0x6',
             'inet6', 'fe80::99e2:c9ff:fe38:b3e3%re0', 'prefixlen', '64', 'scopeid', '0x6']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:18:21.617912
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    network_info = GenericBsdIfconfigNetwork(module)
    ip_address = {'address':'127.0.0.1'}
    current_if = network_info.parse_inet_line(['inet 127.0.0.1 netmask 0xff000000'],{},{})
    assert ip_address == current_if['ipv4'][0], "Address 127.0.0.1 not found"


# Generated at 2022-06-11 03:18:27.528819
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # test using hex netmask
    gbn = GenericBsdIfconfigNetwork(None)
    current_if = {}
    ips = {}
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    gbn.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    v4addr = current_if['ipv4'][0]
    assert v4addr['address'] == '127.0.0.1'
    assert v4addr['netmask'] == '255.0.0.0'
    assert v4addr['network'] == '127.0.0.0'
    assert v4addr['broadcast'] == '127.255.255.255'
    # test using dotted quad netmask

# Generated at 2022-06-11 03:18:47.645366
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    if platform.system() != 'FreeBSD' and platform.system() != 'OpenBSD':
        pytest.skip('Platform not supported')

    # setup the test environment
    module = AnsibleModule(argument_spec=dict())
    # use an existing fact from module utils
    module.params['gather_subset'] = 'network'
    module.params['gather_network_resources'] = 'yes'
    module.params['gather_network_resources_status'] = 'yes'
    module.params['gather_network_resources_interfaces'] = 'yes'
    module.params['validate_certs'] = False
    module.params['ansible_python_interpreter'] = sys.executable
    module.params['ansible_connection'] = 'local'
    # initialize the Network instance
    network = GenericBsd

# Generated at 2022-06-11 03:18:58.829153
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    defaults = {
        'interface': 'lo0',
    }
    interfaces = {
        'lo0': {
            'ipv4': [{
                'address': '127.0.0.1',
                'netmask': '255.0.0.0',
                'broadcast': '127.0.0.1',
            }],
            'ipv6': [{
                'address': '::1',
                'prefix': '128',
            }],
        }
    }

    network = network_module.GenericBsdIfconfigNetwork()

    network.merge_default_interface(defaults, interfaces, 'ipv4')

    ipv4 = defaults['ipv4']

    assert ipv4 is not None
    assert 'address' in ipv4

# Generated at 2022-06-11 03:19:01.896272
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    print('GenericBsdIfconfigNetwork_parse_interface_line_called')
    GenericBsdIfconfigNetwork.parse_interface_line('test_GenericBsdIfconfigNetwork_parse_interface_line')


# Generated at 2022-06-11 03:19:13.838888
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = am.AnsibleModule({}, {}, [])
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    network = GenericBsdIfconfigNetwork(module)

    # FreeBSD
    module.run_command.return_value = (0, '''default:
        interface: fxp0
        gateway: 192.0.2.1
        local addr: 192.0.2.131
    ''', '')
    v4, v6 = network.get_default_interfaces('mock_route_path')
    assert v4 == {'interface': 'fxp0', 'gateway': '192.0.2.1', 'address': '192.0.2.131'}
    assert v6 == {}

    # OpenBSD

# Generated at 2022-06-11 03:19:23.752988
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    notest = None
    GenericBsdIfconfigNetwork.parse_interface_line(notest, ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184', 'options=3<RXCSUM,TXCSUM>', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet6', '::1', 'prefixlen', '128', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>'])
    assert True

# Generated at 2022-06-11 03:19:34.228415
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    class FakeModule():
        def run_command(self, cmd):
            return '', '', ''

    class FakeNetwork(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    network = FakeNetwork(module)

    network_facts = network.populate()
    assert network_facts['all_ipv4_addresses'] == list()
    assert len(network_facts['all_ipv6_addresses']) > 0


if __name__ == '__main__':
    # Unit test requires working network connection
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 03:19:45.112170
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bsdifconfig = GenericBsdIfconfigNetwork()

    assert bsdifconfig.merge_default_interface(None, None, None) == None
    assert bsdifconfig.merge_default_interface({}, {}, None) == None

    # Test for empty interface
    defaults = {'interface': 'eth0'}
    interfaces = {'eth0': {'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    assert bsdifconfig.merge_default_interface(defaults, interfaces, None) == None

    # Test for interface not in interfaces
    defaults = {'interface': 'eth0'}
    interfaces = {'eth1': {'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    assert bsdifconfig.merge_default_

# Generated at 2022-06-11 03:19:52.604620
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:20:04.680823
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = Mock()
    module.run_command = Mock()
    module.get_bin_path = Mock()

    module.run_command.return_value = 0, "/bin/bash", ""
    module.get_bin_path.return_value = "/bin/bash"

    # Test Case #1 - address with cidr
    words = ['lo0', 'inet', '127.0.0.1/24', 'netmask', '0xffffff00', 'broadcast', '127.0.0.1']

    network = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': []}

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network.parse_

# Generated at 2022-06-11 03:20:09.589406
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    n = GenericBsdIfconfigNetwork({})
    assert n.get_options('foo') == []
    assert n.get_options('foo bar') == []
    assert n.get_options('foo <bar>') == []
    assert n.get_options('foo <bar> baz') == []
    assert n.get_options('foo <bar,baz>') == ['bar', 'baz']
    assert n.get_options('foo <bar,baz> biz') == ['bar', 'baz']
    assert n.get_options('foo <bar, baz, qux>') == ['bar', 'baz', 'qux']
    assert n.get_options('foo < bar, baz, qux>') == []

# Generated at 2022-06-11 03:20:53.434875
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = 'Generic_BSD_Ifconfig'

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    fake_route_path = "/bin/route"
    fake_route_file = open(fake_route_path, 'w')
    fake_route_file.close()

    network = GenericBsdIfconfigNetwork(module)

    arguments = {}

    check_input_data = {}
    check_input_data['route_path'] = fake_route_path

    check_output_data = {}
    check_output_data['default_ipv4'] = {}
    check_output_data['default_ipv6'] = {}


# Generated at 2022-06-11 03:20:59.524829
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    ifconfig_parser = GenericBsdIfconfigNetwork()
    ifconfig_parser.module = MagicMock()
    interfaces, ips = ifconfig_parser.get_interfaces_info("ifconfig", ifconfig_options='lo0')
    assert len(interfaces) == 1
    assert interfaces['lo0']['type'] == 'loopback'
    assert interfaces['lo0']['macaddress'] == 'unknown'



# Generated at 2022-06-11 03:21:09.688691
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    net = GenericBsdIfconfigNetwork()
    net.module = FakeModule()
    net.module.run_command=( 0, "ifconfig -a\nlo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384\n    options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>\n    inet 127.0.0.1 netmask 0xff000000 \n    inet6 ::1 prefixlen 128 \n    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1 \n    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>\n    groups: lo \n\n", "" )
    net.populate()

# Unit test

# Generated at 2022-06-11 03:21:20.094003
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    class MyNetworkPlugin(GenericBsdIfconfigNetwork):
        def __init__(self, module, *args, **kwargs):
            self.module = module
    
    # create a mock module
    class MyModule(object):
        def __init__(self):
            self.files = {}
            self.params = dict()
            self.fail_json = dict(rc=1, msg="")
            
        def get_bin_path(self, executable):
            return None
            
        def run_command(self, cmd):
            if "%s %s" % (cmd[0], cmd[1]) in self.files:
                return 0, self.files["%s %s" % (cmd[0], cmd[1])], ""
            return 0, "", ""
            

# Generated at 2022-06-11 03:21:29.398538
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifc = GenericBsdIfconfigNetwork()
    # Test normal IPv6 address
    current_if = dict(device='test')
    words = ['inet6', '2001:db8:1:1:1:1:1:1', 'prefixlen', '64', 'scopeid', '0x17']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ifc.parse_inet6_line(words, current_if, ips)
    expected = {
        'ipv6': [
            {
                'address': '2001:db8:1:1:1:1:1:1',
                'prefix': '64',
                'scope': '0x17'
            }
        ]
    }

# Generated at 2022-06-11 03:21:41.941171
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    #This module can't be imported since it is a subclass of a module declared
    #inside a class
    #from test.unit.ansible_collections.ansible.community.plugins.module_utils.network.common.network import GenericBsdIfconfigNetwork
    from ansible.module_utils.network import GenericBsdIfconfigNetwork

    network_asserts = NetworkAsserts()
    platform_outputs = {}
    platform_outputs['route -n get default'] = 'interface: en1\ngateway: 192.168.1.1\ndestination: default\nflags: <UP,GATEWAY,DONE,STATIC,PRCLONING>'

# Generated at 2022-06-11 03:21:52.398132
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = GenericBsdIfconfigNetwork(module)
    network.get_default_interfaces = Mock(return_value=(
        {'interface': 'lo0', 'address': '127.0.0.1', 'gateway': '127.0.0.1'},
        {'interface': 'lo0', 'address': '::1', 'gateway': '::1'},
    ))

# Generated at 2022-06-11 03:21:58.503764
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Setup test data
    ifconfig_path = '/sbin/ifconfig'

    # Initialize object
    gn = GenericBsdIfconfigNetwork(module=None)

    # Test
    assert gn.get_interfaces_info(ifconfig_path) is not None

    # Unsupported data return None
    assert gp.get_interfaces_info(None) is None

# Generated at 2022-06-11 03:22:02.674396
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.facts.network import *
    from ansible.module_utils.facts.network.generic_bsd_ifconfig import Generic_BSD_Ifconfig
    gbin = Generic_BSD_Ifconfig(dict(module=AnsibleModule(
        argument_spec = dict()
    )))



# Generated at 2022-06-11 03:22:09.900139
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Stub
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None, type='str'),
        ),
        supports_check_mode=True,
    )

    # Save the original module/AnsibleModule objects
    orig_module = module

    # Invoke the method
    result = GenericBsdIfconfigNetwork.populate()

    # Fail the module for unittest
    assert module == orig_module



# Generated at 2022-06-11 03:22:56.020876
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 03:23:05.190643
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
  import pytest
  from ansible_collections.misc.not_a_real_collection.plugins.modules.network.generic import gen_ifconfig
  assert gen_ifconfig.GenericBsdIfconfigNetwork.detect_type_media({'eth0': {'media': 'EtHernet'}}) == {'eth0': {'media': 'EtHernet', 'type': 'ether'}}
  assert gen_ifconfig.GenericBsdIfconfigNetwork.detect_type_media({'eth0': {'media': 'AUX'}}) == {'eth0': {'media': 'AUX', 'type': 'unknown'}}



# Generated at 2022-06-11 03:23:15.746449
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network.module = AnsibleModule(argument_spec=dict())
    generic_bsd_ifconfig_network.module.run_command = MagicMock()
    route_path = '/bin/route'
    generic_bsd_ifconfig_network.module.get_bin_path = MagicMock(return_value=route_path)
    generic_bsd_ifconfig_network.module.run_command.return_value = (0, 'default: gateway: 192.0.2.1 interface: en0', '')
    ipv4_default, ipv6_default = generic_bsd_ifconfig_network.get_default_interfaces(route_path)

# Generated at 2022-06-11 03:23:25.295904
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    subject = GenericBsdIfconfigNetwork(None)


# Generated at 2022-06-11 03:23:36.307151
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Arrange
    import sys
    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, '', ''
    mock_module.get_bin_path.return_value = '/sbin/ifconfig'
    mock_network = GenericBsdIfconfigNetwork(mock_module)

# Generated at 2022-06-11 03:23:46.926007
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.modules.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    module = AnsibleModule(
    )
    module.run_command = MagicMock(return_value=(0, '', ''))  # noqa
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    route_path = "/sbin/route"
    output_v4 = "default: gateway 192.168.55.1 interface en0"
    output_v6 = "default: gateway nx00::ffff interface nxfe80::f00f:0:0:3 prefixlen 64"
    module.run_command.side_effect = [
        (0, output_v4, ''),
        (0, output_v6, '')]
    ret = generic_bsd_ifconfig_

# Generated at 2022-06-11 03:23:56.527329
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    command = "route -n get default"
    output = """
route to: default
destination: default
       mask: default
    gateway: 10.0.0.1
  interface: en0
      flags: <UP,GATEWAY,DONE,STATIC,PRCLONING>
 recvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire
       0         0         0         0         0         0      1500         0
"""
    linux_network = GenericBsdIfconfigNetwork(dict(bin_path=dict(route='/usr/bin/route')))
    interface = linux_network.get_default_interfaces("/usr/bin/route")
    assert interface[0]['interface'] == 'en0'


# Generated at 2022-06-11 03:24:06.224314
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Setup test values
    defaults = dict(
        interface='eth0',
        ipv4=[],
        ipv6=[],
        type='ether',
        macaddress='00:0c:29:65:91:a9',
        mtu='1500',
        options='',
        address='192.168.56.102',
        netmask='255.255.255.0',
        broadcast='192.168.56.255',
        network='192.168.56.0',
        metric='0',
        status='active',
    )


# Generated at 2022-06-11 03:24:07.223340
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # TODO
    pass


# Generated at 2022-06-11 03:24:16.652778
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdNetwork
    ifconfig_major_version = 1
    options = None
    module = None
    collected_facts = None
    mocker = Mocker()
    mock_module = mocker.mock()
    mock_module.run_command(ANY)
    mocker.count(0, None)
    mock_module.get_bin_path(ANY)
    mocker.count(0, "/bin/ifconfig")
    mocker.replay()
    generic_bsd_net = GenericBsdIfconfigNetwork(module=mock_module)
    defaults = {'interface': 'en0'}