

# Generated at 2022-06-11 03:15:46.683013
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:15:49.136599
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    gbifn_net = GenericBsdIfconfigNetwork(module)
    assert gbifn_net.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-11 03:16:00.147094
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    network = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}

    network.parse_inet6_line(['inet6', 'fe80::4001:aff:fe80:20', 'prefixlen', '64', 'scopeid', '0x2', 'prefixlen', '64'], iface, ips)
    assert iface['ipv6'][0]['address'] == 'fe80::4001:aff:fe80:20'
    assert iface['ipv6'][0]['prefix'] == '64'
    assert iface['ipv6'][0]['scope'] == '0x2'

    iface = {}

# Generated at 2022-06-11 03:16:12.159025
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command = lambda x, environ_update=None, check_rc=True, close_fds=True: (0, '', '')
            self.get_bin_path = lambda x: None


# Generated at 2022-06-11 03:16:24.216228
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    import textwrap

    # Generic BSD ifconfig -a output (FreeBSD)

# Generated at 2022-06-11 03:16:35.588505
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    words = "fe80::a00:27ff:fe5b:3e2e%lo0 prefixlen 64 scopeid 0x2".split()
    words1 = "fe80::a00:27ff:fe5b:3e2e%lo0 prefixlen 64".split()
    words2 = "fe80::a00:27ff:fe5b:3e2e%lo0".split()
    words3 = "::1 prefixlen 128".split()
    words4 = "::1/128".split()

    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-11 03:16:45.533188
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.facts import Network

    # setup the test data
    route_command = ['route', '-n', 'get', '-inet6', 'default']


# Generated at 2022-06-11 03:16:52.500457
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())

    # If a command is not available, bin_path will be None.
    bin_path = '/bin/something'
    if not os.path.exists(bin_path):
        bin_path = None

    mocker.patch("os.path.exists", return_value=True)
    mocker.patch("ansible.module_utils.basic.AnsibleModule.get_bin_path", return_value=bin_path)
    mocker.patch("ansible.module_utils.network.common.resource_filename", return_value=bin_path)
    network_facts = GenericBsdIfconfigNetwork(module)

    rc, actual_out, actual_err = network_facts.get_default_interfaces(bin_path)
    assert (rc == 0)


# Generated at 2022-06-11 03:16:55.069251
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # get_interfaces_info is tested by its callers:
    # populate, get_default_interfaces.
    pass



# Generated at 2022-06-11 03:17:05.827078
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # assert that we can simple merge a default value into an interface
    defaults = {'interface': 'en0',
                'address': '192.168.1.1'}
    interfaces = {'en0': {
        'device': 'en0',
        'mtu': '1500',
        'type': 'ether',
        'macaddress': '00:11:22:33:44:55',
        'ipv4': [{
            'address': '192.168.1.1',
            'netmask': '255.255.255.0',
            'broadcast': '192.168.1.255'}]}}

    gen = GenericBsdIfconfigNetwork()
    gen.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-11 03:17:21.711034
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    # Nothing is changed if no media is found
    interfaces = {'hmmm': {}}
    output = GenericBsdIfconfigNetwork().detect_type_media(interfaces)
    assert 'type' not in output['hmmm']

    # If the media contains ether, type of the interface is ether
    interfaces = {'hmmm': {'media': 'Ethernet something'}}
    output = GenericBsdIfconfigNetwork().detect_type_media(interfaces)
    assert output['hmmm']['type'] == 'ether'

    # If the media contains ether, type of the interface is ether
    interfaces = {'hmmm': {'media': 'Ether someone'}}
    output = GenericBsdIfconfigNetwork().detect_type_media(interfaces)
    assert output['hmmm']['type'] == 'ether'



# Generated at 2022-06-11 03:17:28.417216
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    parser = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
    parser.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(1000baseT)'
    assert 'media_options' not in current_if
    assert not ips


# Generated at 2022-06-11 03:17:40.529185
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:17:45.363800
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    base = GenericBsdIfconfigNetwork()
    input_string = '<UP,RUNNING,NOARP>'
    expected_output = ['UP', 'RUNNING', 'NOARP']
    output = base.get_options(input_string)
    assert expected_output == output

# Generated at 2022-06-11 03:17:55.238909
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Replace the module argument parsing code with a mock.
    module = AnsibleModule(argument_spec={})

    # Create the object under test.
    upt = GenericBsdIfconfigNetwork(module)

    # Expected interface output lines for different FreeBSD versions.

# Generated at 2022-06-11 03:18:06.934623
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import copy
    import re
    m = GenericBsdIfconfigNetwork()
    route_path = 'not/a/real/path'
    s = '''
default via 10.0.2.2 dev eth0 proto static
10.0.2.0/24 dev eth0  proto kernel  scope link  src 10.0.2.15
default via fe80::a00:27ff:fea4:dac6 dev tun0 proto ra  metric 1
    '''
    expected_result = dict(v4=dict(interface='eth0', gateway='10.0.2.2'),
                           v6=dict(interface='tun0', gateway='fe80::a00:27ff:fea4:dac6'))
    result = m.get_default_interfaces(route_path)
    assert result == expected_result

# Generated at 2022-06-11 03:18:14.501455
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network import NetworkError

    def set_module_args(args):
        module_args = dict(
            routing=dict(
                ipv4=dict(
                    address='192.168.0.2/24',
                    gateway='192.168.0.1'
                ),
                ipv6=dict(
                    address='2001:db8:a::2/64',
                    gateway='2001:db8:a::1'
                )
            )
        )
        module_args.update(args)
        module.params = module_args


# Generated at 2022-06-11 03:18:19.930279
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    (network_facts, expected_network_facts) = load_fixture('populate_gen_bsd_ifconfig')
    # If some platform specific classes not available, then skip the test
    if not network_facts:
        return
    check_network_facts(network_facts, expected_network_facts)



# Generated at 2022-06-11 03:18:21.626276
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # FIXME: we need to mock the module object
    GenericBsdIfconfigNetwork().populate()
# end class GenericBsdIfconfigNetwork


# Generated at 2022-06-11 03:18:27.873707
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    merged = dict(int1=dict(ipv4=[dict(address='1.1.1.1'), dict(address='2.2.2.2')]),
                  int2=dict(ipv4=[dict(address='3.3.3.3'), dict(address='4.4.4.4')]),
                  interface='int1',
                  address='4.4.4.4'
                  )
    net.merge_default_interface(merged, merged, 'ipv4')
    assert merged['ipv4'][0]['address'] == '4.4.4.4'

# ==== GenericBSD ====


# Generated at 2022-06-11 03:18:53.516684
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    Ins = GenericBsdIfconfigNetwork()

    # testing for IPv6 with prefix.
    words = ['inet6', '2601:8c:4040:f9ee::1', 'prefixlen', '128']
    current_if = None
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    Ins.parse_inet6_line(words, current_if, ips)
    address = {
        'address': '2601:8c:4040:f9ee::1',
        'prefix': '128'
    }
    assert ips['all_ipv6_addresses'] == [address['address']]
    assert ips['all_ipv4_addresses'] == []

    # testing for IPv6 with prefix and scope

# Generated at 2022-06-11 03:19:01.720986
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
   network = {}
   network['interfaces'] = ['lo0', 'em0']

# Generated at 2022-06-11 03:19:13.655973
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    '''Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork'''
    generic_bsd_network = GenericBsdIfconfigNetwork()

    # test route -n get default
    network_facts = {}
    defaults = {}
    defaults['interface'] = 'lo0'
    defaults['gateway'] = '::1'
    defaults['address'] = '::1'
    rc, out, err = generic_bsd_network.module.run_command(['route', '-n', 'get', 'default'])
    assert out == "route to: default\ninterface: lo0\ngateway: ::1\n"
    defaults = generic_bsd_network.get_default_interfaces('route')
    assert defaults[0]['interface'] == 'lo0'

# Generated at 2022-06-11 03:19:24.234691
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = {}
    network.merge_default_interface(defaults, {}, 'ipv4')
    assert defaults == {}
    defaults = {'interface': 'lo0'}
    network.merge_default_interface(defaults, {}, 'ipv4')
    assert defaults == {}
    defaults = {'interface': 'lo0'}
    network.merge_default_interface(defaults, {'lo0': {'device': 'lo0', 'ipv4': []}}, 'ipv4')
    assert defaults == {}
    defaults = {'interface': 'lo0', 'address': '127.0.0.1'}

# Generated at 2022-06-11 03:19:35.936302
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    bsd = GenericBsdIfconfigNetwork()

    interface_defaults = {
        'interface':'lo0',
        'gateway': '192.168.1.1'
    }


# Generated at 2022-06-11 03:19:42.276734
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    option_string = '<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>'
    options = network.get_options(option_string)
    assert options == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']


# Generated at 2022-06-11 03:19:51.131811
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:20:03.825548
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defconfigs = dict(
        v4=dict(
            interface='lo0',
            gateway='127.0.0.1'
        ),
        v6=dict(
            interface='lo0',
            gateway='::1'
        ),
    )

# Generated at 2022-06-11 03:20:14.345940
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = {'device': 'foo'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    ifconfig = GenericBsdIfconfigNetwork()

    with pytest.raises(TypeError):
        ifconfig.parse_media_line([], iface, ips)

    with pytest.raises(ValueError):
        ifconfig.parse_media_line(['media:', 'ethernet', 'full-duplex'], iface, ips)


# Generated at 2022-06-11 03:20:26.132632
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    route_path = module.get_bin_path('route')
    platform = 'freebsd'
    network = GenericBsdIfconfigNetwork(module)
    # netbsd specific
    if (platform == 'netbsd'):
        default_v4, default_v6 = network.get_default_interfaces(route_path)
        assert 'local addr' in default_v4
        assert 'local addr' in default_v6
    else:
        default_v4, default_v6 = network.get_default_interfaces(route_path)
        assert 'interface' in default_v4
        assert 'interface' in default_v6


# Generated at 2022-06-11 03:21:48.454836
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self):
            self.params = dict()
            self.check_mode = False

        def run_command(self, args):
            stdout = ""
            if args[2] == 'get':
                stdout = "interface: en0\n" \
                         "gateway: 10.0.2.2"
            if args[2] == 'get':
                stdout = "interface: gif0\n" \
                         "gateway: 0:c:42::0"
            stderr = ""
            rc = 0
            return (rc, stdout, stderr)

    module = FakeModule()
    _facts = GenericBsdIfconfigNetwork(module).populate()

# Generated at 2022-06-11 03:21:56.378653
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = MockAnsibleModule()
    network = GenericBsdIfconfigNetwork(module)
    # test case: route -n get default returns
    #     gateway: 192.168.1.1
    #     interface: re0
    #     local addr: 192.168.1.35
    network.module.run_command = Mock(return_value=(0, 'gateway: 192.168.1.1\ninterface: re0\nlocal addr: 192.168.1.35\n', ''))
    assert network.get_default_interfaces('route') == ({'gateway': '192.168.1.1', 'interface': 're0', 'address': '192.168.1.35'}, {})

# Generated at 2022-06-11 03:22:05.560962
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible.module_utils.facts import Network


# Generated at 2022-06-11 03:22:13.550695
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # We have to create a subclass that defines the module.platform
    from ansible.module_utils.facts import Facts # noqa

    class MyFacts(Facts):
        def __init__(self):
            self.facts = {'platform': 'Generic_BSD_Ifconfig'}

    # this is the standard module object that is created
    # by the ansible machinery when a module is invoked
    module = MyFacts()
    # this is the class object that implements the module
    x = GenericBsdIfconfigNetwork(module=module)


# Generated at 2022-06-11 03:22:24.800379
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-11 03:22:31.604057
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    platform = GenericBsdIfconfigNetwork()
    result = platform.merge_default_interface({}, {}, 'ipv4')
    assert result == None, "The method 'merge_default_interface' should return None when no interface is provided."

    result = platform.merge_default_interface({}, {'interface': 'test'}, 'ipv4')
    assert result == None, "The method 'merge_default_interface' should return None when interface is not in list."

    result = platform.merge_default_interface({}, {'interface': 'eth1', 'ipv4': 'test'}, 'ipv4')
    assert result == None, "The method 'merge_default_interface' should return None when parameter ip_type is unknown."


# Generated at 2022-06-11 03:22:34.954044
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    result = GenericBsdIfconfigNetwork(module).populate()
    assert 'default_ipv4' in result


# Generated at 2022-06-11 03:22:43.128809
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """Checking IPv6 addresses parse correctly"""
    mac = GenericBsdIfconfigNetwork()

    words = ['inet6', '2001:db8::1', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = {}
    ips = {}
    mac.parse_inet6_line(words, current_if, ips)

    assert current_if['ipv6'][0]['address'] == '2001:db8::1'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0x1'

    words = ['inet6', 'fe80::1%lo0']
    mac.parse_inet6_line(words, current_if, ips)
    assert current_if

# Generated at 2022-06-11 03:22:53.884396
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    # declaration of expected return from a call to parse_inet6_line
    expected = {'address': '::1', 'prefix': '128'}

    # create an instance of class GenericBsdIfconfigNetwork for calling parse_inet6_line
    network = GenericBsdIfconfigNetwork()
    # call parse_inet6_line in class GenericBsdIfconfigNetwork with test argument values:
    current_if = {}
    ips = {}
    words = ['inet6', '::1', 'prefixlen', '128', 'scopeid', '0x1']
    result = network.parse_inet6_line(words, current_if, ips)
    assert result is None
    assert current_if == {'ipv6': [expected]}



# Generated at 2022-06-11 03:23:04.803729
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    defaults = {'interface': 'bge0', 'address': '10.0.0.1/24' }

# Generated at 2022-06-11 03:24:21.512277
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    nm = GenericBsdIfconfigNetwork(module)

    with open(os.path.dirname(__file__) + "/route-get.txt", "r") as f:
        route_get_content = f.read()

    with patch.object(module, "run_command") as mock_run_command:
        mock_run_command.return_value = (0, route_get_content.split('\n'), None)
        default_ipv4, default_ipv6 = nm.get_default_interfaces('/fake/path')
        assert default_ipv4 == {'interface': 'bge0', 'gateway': '192.168.100.1', 'address': '192.168.100.101'}

# Generated at 2022-06-11 03:24:30.796763
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    a = GenericBsdIfconfigNetwork()
    assert a.merge_default_interface({}, {}, 'ipv4') == None
    assert a.merge_default_interface(
        {'interface': 'lo0'},
        {'lo0': {'device': 'lo0', 'ipv4': [{'address': '127.0.0.1'}], 'ipv6': []}},
        'ipv4') == None
    assert a.merge_default_interface(
        {'interface': 'lo0'},
        {'lo0': {'device': 'lo0', 'ipv4': [{'address': '127.0.0.1'}], 'ipv6': []}},
        'ipv4') == None

# Generated at 2022-06-11 03:24:41.578419
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # prepare data
    # Prepare test data for test_GenericBsdIfconfigNetwork_parse_inet_line
    test_module = AnsibleModule(
        argument_spec=dict()
    )

    test_module.params = {}
    test_module.check_mode = False

    network = GenericBsdIfconfigNetwork()

    network.module = test_module

    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {}
    ips = dict()

    # execute
    network.parse_inet_line(words, current_if, ips)

    # assert
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'