

# Generated at 2022-06-20 17:59:55.543415
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # test data
    ifc = GenericBsdIfconfigNetwork()
    word_list = ['inet6', 'fe80::250:56ff:fece:8f1a%en0', 'prefixlen', '64', 'scopeid', '0x3']
    # expected output
    ret = dict()
    ret['address'] = 'fe80::250:56ff:fece:8f1a'
    ret['prefix'] = '64'
    ret['scope'] = '0x3'
    # get actual output
    ret_in = dict()
    ifc.parse_inet6_line(word_list, {}, {'all_ipv6_addresses':[]})
    # compare result
    assert ret['address'] == ret_in['address']
    assert ret['prefix'] == ret_in['prefix']
   

# Generated at 2022-06-20 18:00:10.142212
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    ifconfig_output = "options=1b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,VLAN_HWTSO>\n"
    words = ifconfig_output.split()
    ifc = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    ifc.parse_options_line(words, current_if, ips)
    assert 'options' in current_if
    assert len(current_if['options']) == 8
    assert current_if['options'][0] == 'RXCSUM'
    assert current_if['options'][7] == 'VLAN_HWTSO'


# Generated at 2022-06-20 18:00:19.882173
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    words = ['status:', 'active']
    current_if = {
        'device': 'lo0',
        'metric': 0,
        'mtu': 65536,
        'flags': [
            'UP',
            'LOOPBACK',
            'RUNNING',
        ],
        'type': 'loopback',
        'ipv4': [
        ],
        'ipv6': [
            {
                'prefix': '64',
                'address': '::1',
                'scope': '0x1',
            },
            {
                'prefix': '64',
                'address': 'fe80::1%lo0',
            },
        ],
        'macaddress': 'unknown',
    }
    ips = None

    obj = GenericBsdIfconfigNetwork()
    obj.parse_status

# Generated at 2022-06-20 18:00:28.685808
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    platform_name = 'Generic_BSD_Ifconfig'
    module = FakeAnsibleModule(platform_name=platform_name)
    ifconfig_path = module.get_bin_path('ifconfig')
    options = '-a'
    get_interfaces_info_obj = GenericBsdIfconfigNetwork()
    get_interfaces_info_obj.module = module
    result = get_interfaces_info_obj.get_interfaces_info(ifconfig_path, options)

    assert result is not None

# Generated at 2022-06-20 18:00:41.708021
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:00:49.451600
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = Mock()
    # fmt: off

# Generated at 2022-06-20 18:01:03.238600
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    network = GenericBsdIfconfigNetwork()
    network.platform='generic_bsd'
    network.module = AnsibleModule(argument_spec=dict())
    current_if = {}
    ips = {}
    ''' Test 1 '''
    words = ['media', 'Ethernet', '10baseT/UTP', '(0x8)']
    network.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet', 'media_select': '10baseT/UTP', 'media_type': '0x8'}
    assert ips == {}
    ''' Test 2 '''
    words = ['media:', 'Ethernet', '10baseT/UTP', 'status:', 'active']

# Generated at 2022-06-20 18:01:12.189836
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-20 18:01:12.763967
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    assert True

# Generated at 2022-06-20 18:01:14.223315
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    network = GenericBsdIfconfigNetwork()
    assert network is not None

# Generated at 2022-06-20 18:01:38.925799
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    obj = GenericBsdIfconfigNetwork()
    obj.parse_options_line = MagicMock()
    obj.parse_options_line(['options=8010<LINK2,BROADCAST,SIMPLEX,MULTICAST>', 'mtu', '1500'], {}, {})
    # 
    obj = GenericBsdIfconfigNetwork()
    obj.parse_options_line = MagicMock()

# Generated at 2022-06-20 18:01:51.256719
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = MagicMock(spec=AnsibleModule)
    module.run_command.return_value = (0, '', '')
    network = GenericBsdIfconfigNetwork(module)

    # Arrange
    current_if = {}
    ips = {}
    expected_current_if = {
        'device': 'em0',
        'ipv4': [],
        'ipv6': [],
        'type': 'ether',
        'macaddress': '3c:07:54:b2:a3:e2'
    }

    # Act
    network.parse_ether_line(['ether', '3c:07:54:b2:a3:e2'], current_if, ips)

    # Assert
    assert current_if == expected_current_if

# Generated at 2022-06-20 18:01:57.793332
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """
    Test detect_type_media(interfaces)
    """

# Generated at 2022-06-20 18:02:11.739139
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:22.794079
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
        Test get_default_interfaces method of GenericBsdIfconfigNetwork class
    """
    test_obj = GenericBsdIfconfigNetwork()
    test_obj.module = MagicMock()
    test_obj.module.get_bin_path.return_value = '/sbin/route'
    test_obj.module.run_command.return_value = (0, 'interface: vlan1\ngateway: 10.0.0.1\nflags: <UP,GATEWAY,HOST,DONE,STATIC>\nrecvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire\n0         0         0         0           0       0             1500    0\n', '')

# Generated at 2022-06-20 18:02:24.867001
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # @TODO: implement this test
    pass


# Generated at 2022-06-20 18:02:34.808555
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:44.143037
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:50.975929
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import tempfile
    import os

    # Test ifconfig output with lo0
    with tempfile.NamedTemporaryFile() as tf:
        tf.write(b'''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
''')
        tf.flush()

        network = GenericBsdIfconfigNetwork()
        interfaces, ips = network.get_interfaces_info(os.path.basename(tf.name))

# Generated at 2022-06-20 18:03:03.291266
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    bsd_network = GenericBsdIfconfigNetwork()

    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'flags': ['LOOPBACK', 'UP', 'RUNNING'], 'ipv4': [{'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}], 'macaddress': 'unknown', 'metric': '0', 'mtu': '16384', 'device': 'lo0'}}
    bsd_network.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-20 18:03:34.659220
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    facts = GenericBsdIfconfigNetwork()
    # Test 1
    words = ['lladdr', '0c:c4:7a:e1:0b:8f']
    current_if = {'device': 'en0'}
    ips = {}
    facts.parse_lladdr_line(words, current_if, ips)
    assert 'lladdr' in current_if and current_if['lladdr'] == '0c:c4:7a:e1:0b:8f'

    # Test 2
    words = ['lladdr']
    current_if = {'device': 'en0'}
    ips = {}
    try:
        facts.parse_lladdr_line(words, current_if, ips)
    except:
        assert True
    else:
        assert False

#

# Generated at 2022-06-20 18:03:40.340082
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)

    # TODO: this has been lightly tested in real life, but needs unit tests
    # TODO: merge_default_interface may not be doing what I think it is
    module.fail_json(msg="No unit tests written")

# Generated at 2022-06-20 18:03:51.656273
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    device = 'lo0'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['macaddress'] = 'unknown'
    ipv4_address = {'address': '127.0.0.1'}
    ipv4_address['netmask'] = '255.0.0.0'
    ipv6_address = {'address': '::1', 'prefix': '128'}

    current_if['ipv4'].append(ipv4_address)
    current_if['ipv6'].append(ipv6_address)


# Generated at 2022-06-20 18:04:03.457461
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    interfaces = {}
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Testing parsing inet line, assuming all parameters are included
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.255.255.255']
    network.parse_inet_line(words, current_if, ips)
    assert ips == dict(
        all_ipv4_addresses=['127.0.0.1'],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-20 18:04:17.178395
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module_mock = MagicMock()
    module_mock.run_command = MagicMock(return_value=0)

    network = GenericBsdIfconfigNetwork(module_mock)

    # Case 1: v6 with / prefix
    words = ['inet6', 'fe80::1%lo2', 'prefixlen', '64', 'scopeid', '0x4']
    interface = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network.parse_inet6_line(words, interface, ips)

    assert interface.get('ipv6')[0].get('address') == 'fe80::1%lo2'
    assert interface.get('ipv6')[0].get('prefix') == '64'


# Generated at 2022-06-20 18:04:25.900474
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet6', 'fe80::10e:b3ff:fe26:d492%gif0', 'prefixlen', '64', 'scopeid', '0x11']
    current_if = {"device": "gif0"}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    obj.parse_tunnel_line(words, current_if, ips)
    assert current_if["device"] == "gif0"
    assert current_if["type"] == "tunnel"
    assert ips["all_ipv4_addresses"] == []

# Generated at 2022-06-20 18:04:36.927310
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    test_object = {
        'device': 'utun1',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown'
    }
    test_object['flags'] = ['UP', 'POINTOPOINT', 'MULTICAST']
    test_object['mtu'] = '1280'
    test_object['metric'] = '0'
    test_object['macaddress'] = '00:00:00:00:00:00'
    test_object['media'] = 'Unknown'
    test_object['status'] = 'active'
    test_object['lladdr'] = '00:00:00:00:00:00'
    test_object['options'] = ['nopersist']

# Generated at 2022-06-20 18:04:46.497970
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    mock_module = MagicMock()
    mock_module.run_command.return_value=(0, "ifconfig output", None)
    mock_module.get_bin_path.return_value="/usr/sbin/ifconfig"
    net = GenericBsdIfconfigNetwork(mock_module)
    net.get_interfaces_info("/usr/sbin/ifconfig")

    # Assert module.run_command was called to run 'ifconfig -a'
    mock_module.run_command.assert_called_once_with([mock_module.get_bin_path.return_value, '-a'])


# Generated at 2022-06-20 18:04:58.207204
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test setup
    module = AnsibleModule(argument_spec=dict())

    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            self.module = module

    test_GenericBsdIfconfigNetwork = TestGenericBsdIfconfigNetwork(module)

    # Generic output from ifconfig

# Generated at 2022-06-20 18:05:07.303945
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    _ifname = 'en1'
    _ifline = 'lladdr 48:5d:60:8a:2b:2b media: autoselect (none) status: inactive'
    _ifconfig_line = FakeIfconfigLine(_ifname, _ifline)

    network = GenericBsdIfconfigNetwork()
    network._parse_interface_line = FakeInterfaceLineParser()

    current_if = network.parse_interface_line([_ifname])
    network.parse_lladdr_line(_ifconfig_line.words, current_if, {})

    assert current_if['lladdr'] == '48:5d:60:8a:2b:2b'



# Generated at 2022-06-20 18:05:41.439722
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec=dict())
    class_to_test = GenericBsdIfconfigNetwork(module)

    current_if = {}

    words = ['options=2343<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>']
    class_to_test.parse_options_line(words, current_if, {})
    assert current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU', 'VLAN_HWTAGGING', 'VLAN_HWCSUM']

    words = ['options=3<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>']

# Generated at 2022-06-20 18:05:53.441104
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    assert ['UP', 'RUNNING', 'MULTICAST'] == network.get_options('UP,RUNNING,MULTICAST')
    assert ['UP', 'RUNNING', 'MULTICAST'] == network.get_options('<UP,RUNNING,MULTICAST>')
    assert ['UP', 'RUNNING', 'MULTICAST'] == network.get_options('   UP,RUNNING,MULTICAST   ')
    assert ['UP', 'RUNNING', 'MULTICAST'] == network.get_options('<   UP,RUNNING,MULTICAST   >')
    assert [] == network.get_options('UP, RUNNING, MULTICAST')
    assert ['UP', 'RUNNING', 'MULTICAST'] == network

# Generated at 2022-06-20 18:06:00.885816
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )
    test_object = GenericBsdIfconfigNetwork(module)
    test_if = {}
    test_ips = {}
    test_words = ['test', 'word']
    test_object.parse_unknown_line(test_words, test_if, test_ips)
    assert test_if == {}
    assert test_ips == {}


# Generated at 2022-06-20 18:06:12.882051
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    words = ['ether', '00:0c:29:b8:8a:59']
    interface = dict(device='enp0s3')
    cc = GenericBsdIfconfigNetwork()
    cc.parse_ether_line(words, interface, None)
    assert interface['type'] == 'ether'

    words = ['ether', '00:0c:29:b8:8a:59']
    interface = dict(device='lo0')
    cc = GenericBsdIfconfigNetwork()
    cc.parse_ether_line(words, interface, None)
    assert interface['type'] == 'loopback'


# Generated at 2022-06-20 18:06:26.568097
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from lib.systeminfo.network import GenericBsdIfconfigNetwork
    from lib.systeminfo.network import CidrStyleNetmask
    assert GenericBsdIfconfigNetwork.parse_inet_line(GenericBsdIfconfigNetwork(), []) == ()
    assert GenericBsdIfconfigNetwork.parse_inet_line(GenericBsdIfconfigNetwork(), '') == ()
    assert GenericBsdIfconfigNetwork.parse_inet_line(GenericBsdIfconfigNetwork(), ['.1.2.3.4', 'netmask']) == ()

# Generated at 2022-06-20 18:06:37.215609
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:06:45.168855
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    """
    Test of method parse_media_line of class GenericBsdIfconfigNetwork.
    """
    test = GenericBsdIfconfigNetwork()
    test.parse_media_line(['media:', 'Ethernet', 'autoselect', '(100baseTX)'], {}, {})
    assert test.current_if['type'] == 'ether'

# Generated at 2022-06-20 18:06:58.840125
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    _mock = {}
    # testing if media gets parsed properly by checking if the type 
    # of interface is set to ether
    _mock['device'] = 'em0'
    _mock['ipv4'] = []
    _mock['ipv6'] = []
    _mock['type'] = 'unknown'
    _mock['flags'] = 'up'
    _mock['mtu'] = '1500'
    _mock['macaddress'] = '00:00:00:00:00:00'
    _mock['media'] = 'Ethernet autoselect (10Gbase-SR)'


# Generated at 2022-06-20 18:07:01.211781
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:07:12.225601
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # DNS
    route_path = '/usr/bin/route'

    platform = 'Generic_BSD_ifconfig'

    module_mock = MagicMock()
    module_mock.check_mode = False
    module_mock.run_command.return_value = (0, 'route to: default\n'
                                                 'destination: default\n'
                                                 '   route:\n'
                                                 '      if address: 127.0.0.1\n'
                                                 '      gateway: some.gateway\n'
                                                 '      interface: some.interface\n'
                                                 '      flags: \n', '')
    module_mock.get_bin_path.return_value = route_path
    module_mock.params = {}

    default_interface_route_path

# Generated at 2022-06-20 18:07:34.734631
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    test_file = os.path.join(PLUGIN_TEST_DIRECTORY, 'test_GenericBsdIfconfigNetwork.txt')
    if not os.path.exists(test_file):
        raise Exception("Can't find test_GenericBsdIfconfigNetwork.txt test file")
    module = None
    with open(test_file) as f:
        for line in f:
            test_input, test_output = line.rstrip().split('|')
            test_data = test_input.split()
            network_facts = {'interfaces': [], 'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
            current_if = GenericBsdIfconfigNetwork.parse_interface_line(module, test_data)

# Generated at 2022-06-20 18:07:45.017391
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    gen_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    # Sample test data
    words = ["tun0:"]
    expected_output = {'device': "tun0"}
    # Perform the test
    actual_output = gen_bsd_ifconfig_network.parse_interface_line(words)
    assert expected_output == actual_output, \
        "expected output: {} does not match actual output: {}".format(expected_output, actual_output)

    # Sample test data
    words = ["en0:", "flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500"]

# Generated at 2022-06-20 18:07:54.054738
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Valid inet6 line
    words = ["inet6", "fe80::1", "prefixlen", "64"]
    network.parse_inet6_line(words, current_if, ips)
    assert current_if == {'ipv6': [{'prefix': '64', 'address': 'fe80::1'}],
                         'device': 'en0', 'ipv4': [], 'type': 'unknown'}

    # Valid inet6 line without prefixlen

# Generated at 2022-06-20 18:08:01.742670
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    def setUpModule():
        pass
    def tearDownModule():
        pass
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.get_bin_path = MagicMock(return_value='/usr/bin/ifconfig')
    module.run_command = MagicMock()
    module.run_command.side_effect = run_command_mock

    # Prepare test cases

# Generated at 2022-06-20 18:08:12.797259
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    network = GenericBsdIfconfigNetwork(module)
    ifaceinfo = network.populate()
    assert 'all_ipv4_addresses' in ifaceinfo
    assert 'all_ipv6_addresses' in ifaceinfo
    assert 'default_ipv4' in ifaceinfo
    assert 'lo0' in ifaceinfo['default_ipv4']
    assert 'address' in ifaceinfo['default_ipv4']
    assert 'netmask' in ifaceinfo['default_ipv4']
    assert 'broadcast' in ifaceinfo['default_ipv4']
    assert 'default_ipv6' in ifaceinfo
    assert 'lo0' in ifaceinfo['default_ipv6']

# Generated at 2022-06-20 18:08:23.542627
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})

    defaults = dict(
        interface='lo0',
        gateway='127.0.0.1',
        address='127.0.0.1'
    )


# Generated at 2022-06-20 18:08:31.645468
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = MagicMock()
    instance = GenericBsdIfconfigNetwork(module)
    iface = {}

    # test if status_list is empty
    instance.parse_options_line(words=['options=3<RXCSUM,TXCSUM,VLAN_MTU>', 'ether', '00:2e:67:11:eb:bf'], current_if=iface, ips=dict())

    assert iface == {'options': ['RXCSUM', 'TXCSUM', 'VLAN_MTU'], 'macaddress': '00:2e:67:11:eb:bf'}


# Generated at 2022-06-20 18:08:40.593573
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = 'Generic_BSD_Ifconfig'
    network = GenericBsdIfconfigNetwork(module=None)

    route_path_v4 = network.get_test_path("fixtures", "route_n_get_default")
    route_path_v6 = network.get_test_path("fixtures", "route_n_get_inet6_default")

    expected_v4 = dict(interface='en0', gateway='192.168.0.1')
    expected_v6 = dict(interface='en0', gateway='fe80::1')

    # Verify FreeBSD output
    actual_v4, actual_v6 = network.get_default_interfaces(route_path_v4)
    assert actual_v4 == expected_v4
    assert actual_v6 == expected_v6

    # Verify DragonflyBSD output


# Generated at 2022-06-20 18:08:52.243128
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    words=['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    result=generic_bsd_ifconfig_network.parse_interface_line(words)
    assert result['device']==words[0][0:-1]
    assert result['flags']==generic_bsd_ifconfig_network.get_options(words[1])
    assert result['mtu']==words[3]

# Generated at 2022-06-20 18:09:03.671348
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    iline = 'ether 00:50:56:06:7d:6c '
    current_if = {'device': 'em1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    GenericBsdIfconfigNetwork.parse_ether_line(iline.split(), current_if, ips)
    assert current_if['macaddress'] == '00:50:56:06:7d:6c'
    assert current_if['type'] == 'ether'
