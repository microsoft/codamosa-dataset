

# Generated at 2022-06-20 17:59:33.742837
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
  pass

# Generated at 2022-06-20 17:59:45.310315
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Fake command output
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']

    # Fake instance of class GenericBsdIfconfigNetwork
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    current_if, ips = {}, {}

    generic_bsd_ifconfig_network.parse_nd6_line(words, current_if, ips)

    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']



# Generated at 2022-06-20 17:59:51.672444
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    """Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
    """

    assert_equal(GenericBsdIfconfigNetwork.parse_status_line(None, ["status:", "active"], None, None)["status"], "active")



# Generated at 2022-06-20 17:59:55.737746
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    m = GenericBsdIfconfigNetwork()
    current_if = dict()
    ips = dict()
    m.parse_status_line(['status:', 'active'], current_if, ips)
    assert current_if == dict(status='active')



# Generated at 2022-06-20 18:00:10.225573
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    module = AnsibleModule(argument_spec={})
    module.params['path'] = ''
    ifconfig_path = module.get_bin_path('ifconfig')
    module.params['path'] = ifconfig_path
    net_info = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:00:14.424285
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():

    # check for lladdr line
    # lladdr 00:1e:52:7c:bd:0d

    words = ['lladdr', '00:1e:52:7c:bd:0d']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network_instance.parse_lladdr_line(words,current_if, ips)

    expected_current_if = {'lladdr': words[1]}
    assert current_if == expected_current_if


# Generated at 2022-06-20 18:00:16.923921
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    network = GenericBsdIfconfigNetwork()
    assert network.platform == "Generic_BSD_Ifconfig"


# Generated at 2022-06-20 18:00:29.984406
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
        module = AnsibleModule(argument_spec=dict())
        tmpdir = tempfile.mkdtemp()
        fake_route_path = os.path.join(tmpdir, "route")
        open(fake_route_path, 'a').close()
        os.chmod(fake_route_path, 0o755)

        ifaces = GenericBsdIfconfigNetwork(module)
        ifaces.module.get_bin_path = MagicMock(return_value=fake_route_path)
        ifaces.module.run_command = MagicMock(return_value=(0, "interface: en0\ngateway: 192.0.2.1", ""))

        ipv4, ipv6 = ifaces.get_default_interfaces(fake_route_path)


# Generated at 2022-06-20 18:00:41.815779
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Arrange
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'options': ['RUNNING']}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Act
    network = GenericBsdIfconfigNetwork()
    network.parse_lladdr_line(['lladdr', '00:00:00:00:00:00'], current_if, ips)

    # Assert
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == '00:00:00:00:00:00'


# Generated at 2022-06-20 18:00:48.211805
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    expected = [
        'UP', 'LOOPBACK', 'RUNNING', 'MULTICAST',
        'BROADCAST', 'SIMPLEX', 'LINK0', 'LINK1',
        'LINK2', 'NOARP', 'SLAVE', 'MASTER', 'ALTPHYS',
        'POINTOPOINT', 'DRIVERUP', 'RUNNING', 'NOFCS'
    ]
    assert GenericBsdIfconfigNetwork().get_options(
        'options=3<RXCSUM,TXCSUM,VLAN_MTU> mtu 9000'
    ) == expected

# Generated at 2022-06-20 18:01:14.177759
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    defaults = {'interface': 'lo0', 'address': '127.1.1.1'}

# Generated at 2022-06-20 18:01:23.862659
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    results = {}
    with open("tests/unit/net_generic_bsd_ifconfig/test_get_interfaces_info.out") as file_pointer:
        for line in file_pointer:
            if line.startswith("-"):
                current_section = line.strip("-\n")
                results[current_section] = {}
            elif line.strip() == "":
                pass
            elif line.startswith("  "):
                line = line.strip()
                key, value = line.split(": ")
                results[current_section][key] = value
    return results
    

# Generated at 2022-06-20 18:01:33.156910
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:01:40.731224
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {'ipv6': [], 'type': 'unknown'}
    ipv6_address = dict(address='dead:beef::2', prefix='64', scope='link')
    ipv6_address_expected = dict(
        address='dead:beef::2',
        prefix='64',
        scope='link',
    )
    network.parse_inet6_line(['inet6', ipv6_address['address'], 'prefixlen', ipv6_address['prefix'], 'scopeid', ipv6_address['scope']], current_if, dict())
    assert current_if['ipv6'] == [ipv6_address_expected]


# Generated at 2022-06-20 18:01:51.497443
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test with a dictionary of interfaces
    interfaces = dict()
    interfaces['lo0'] = dict(flags=['LOOPBACK', 'RUNNING', 'UP'])
    interfaces['em0'] = dict(media='Ethernet autoselect', flags=['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'UP'])
    interfaces['em1'] = dict(media='Ethernet media 10Gbase-T', flags=['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'UP'])
    interfaces['em2'] = dict(media='Ethernet media 1000baseT', flags=['BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'UP'])

# Generated at 2022-06-20 18:02:02.558938
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = 'tests/ifconfig_output.txt'
    with open(ifconfig_path, 'r') as f:
        ifconfig_output = f.read()

    nw_module = AnsibleModule(argument_spec={})
    nw_module.run_command = mock.MagicMock(return_value=(0, ifconfig_output, None))
    nw_module.get_bin_path = mock.MagicMock(return_value='ifconfig')

    gbn = GenericBsdIfconfigNetwork(module=nw_module)
    interfaces, ips = gbn.get_interfaces_info('ifconfig')

    # ipv4 addresses:
    # ifconfig_output.txt (line 34): inet 127.0.0.1 netmask 0xff000000
    # ifconfig_output.txt (line

# Generated at 2022-06-20 18:02:14.674110
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    testclass = GenericBsdIfconfigNetwork()

    # Test with command that has default IPv4 interface
    command = dict(v4=['route', '-n', 'get', 'default'],
                   v6=['route', '-n', 'get', '-inet6', 'default'])
    test_result = dict(v4={'interface': 'lo0', 'gateway': '127.0.0.1'},
                       v6={})
    assert test_result == testclass.get_default_interfaces(command)

    # Test with command that has no default IPv4 interface, but has a default IPv6 interface
    command = dict(v4=['route', '-n', 'get', 'default'],
                   v6=['route', '-n', 'get', '-inet6', 'default'])
    test_

# Generated at 2022-06-20 18:02:18.599336
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # Case 1
    module = fake_module(params=dict())
    platform = GenericBsdIfconfigNetwork(module)
    assert platform.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:02:29.699072
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule({})
    generic_network = GenericBsdIfconfigNetwork(module)
    assert generic_network.get_options("0x<UP,BROADCAST,LOOPBACK,MULTICAST,LLADDR>") == ['UP', 'BROADCAST', 'LOOPBACK', 'MULTICAST', 'LLADDR']
    assert generic_network.get_options("0x<UP,BROADCAST>") == ['UP', 'BROADCAST']
    assert generic_network.get_options("0x<>") == []


# Generated at 2022-06-20 18:02:42.138986
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    network_info = {
        'interfaces': [],
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': []
    }
    # init GenericBsdIfconfigNetwork object
    g = GenericBsdIfconfigNetwork(network_info)
    # init vars to test method parse_tunnel_line
    words = ['tunnel', 'inet', '46.101.63.64', '--->', '196.38.189.101', 'netmask', '0xffffff00',]

# Generated at 2022-06-20 18:03:07.646063
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    route_path = module.get_bin_path('route')
    network = GenericBsdIfconfigNetwork(module)
    test_default_interfaces = network.get_default_interfaces(route_path)
    assert test_default_interfaces is not None

# Generated at 2022-06-20 18:03:11.726463
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    net = GenericBsdIfconfigNetwork()
    assert net.get_options('options=1<RUNNING,MULTICAST> mtu 1500') == ['RUNNING', 'MULTICAST']
    assert net.get_options('ether 00:0c:29:87:76:e3') == []


# Generated at 2022-06-20 18:03:12.564810
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    pass


# Generated at 2022-06-20 18:03:24.869129
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    '''
    This unit test is for the merge_default_interface method of the GenericBsdIfconfigNetwork
    class
    '''
    # create an instance of the class
    GBI = GenericBsdIfconfigNetwork()
    # create an empty dictionary to use in the test
    interfaces = {}
    # create a dictionary of data to be used in the test
    ipv4 = {'interface': 'lo0'}
    # create a dictionary to use as the interface for ipv4
    interfaces['lo0'] = {}
    # create a list to use as a value for the ipv4 key in the interfaces dictionary
    interfaces['lo0']['ipv4'] = []
    # create a dictionary to use as the first item in the ipv4 list

# Generated at 2022-06-20 18:03:35.086044
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    if os.path.exists('/bin/freebsd-version') or os.path.exists('/usr/bin/freebsd-version'):
        platform = 'FreeBSD'
    elif os.path.exists('/usr/bin/sw_vers'):
        platform = 'Darwin'
    else:
        platform = 'Generic_BSD_ifconfig'
    network = GenericBsdIfconfigNetwork(dict(module=AnsibleModule, platform=platform))

    test_defaults = dict(current_if=dict(device='lo0'), ips=dict(), words=['lladdr', '1c:1b:0d:18:da:05'])

# Generated at 2022-06-20 18:03:45.858865
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    # Simple sample
    words = ['en0', 'inet', '10.0.0.15', 'netmask', '0xffffff00', 'broadcast', '10.0.0.255']
    generic_bsd_ifconfig.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'] == [{'address': '10.0.0.15', 'netmask': '255.255.255.0', 'broadcast': '10.0.0.255', 'network': '10.0.0.0'}]
    assert ips['all_ipv4_addresses'] == ['10.0.0.15']

    # Sample with

# Generated at 2022-06-20 18:03:54.640642
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    facts = GenericBsdIfconfigNetwork()
    ret = facts.merge_default_interface({'interface': 'if1'}, {'if1': {'ipv4': ['list'], 'foo': 'bar'}}, 'ipv4')
    assert ret == {'interface': 'if1', 'ipv4': ['list'], 'foo': 'bar'}
    ret = facts.merge_default_interface({'interface': 'if2'}, {'if1': {'ipv4': ['list'], 'foo': 'bar'}}, 'ipv4')
    assert ret == {'interface': 'if2'}


# Generated at 2022-06-20 18:04:06.307412
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    mock_module = MagicMock()
    mock_module.run_command.return_value = [0, 'looks like a mac line', '']
    network = GenericBsdIfconfigNetwork(mock_module)

    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = ['options=1e<PERFORMNUD,IFDISABLED,LINKSTATE,RXCSUM,TXCSUM,TXSTATUS,VLAN_MTU,VLAN_HWTAGGING>']
    network.parse_options_line(words, current_if, ips)

    assert network.get

# Generated at 2022-06-20 18:04:09.615208
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    generic_bsd_ifconfig_network_obj = GenericBsdIfconfigNetwork()
    words = ['a', 'b', 'c']
    current_if = ''
    ips = ''
    assert generic_bsd_ifconfig_network_obj.parse_unknown_line(words, current_if, ips) == None


# Generated at 2022-06-20 18:04:20.572443
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:05:16.170177
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=False)
    generic_bsd_network = GenericBsdIfconfigNetwork(mod)
    assert generic_bsd_network.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:05:26.158471
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = '/sbin/ifconfig'
    platform = GenericBsdIfconfigNetwork(module_mock)

    interfaces = {}
    current_if = {}
    ips = {}
    words = ['ether', '00:11:d8:11:11:11']
    platform.parse_ether_line(words, current_if, ips)

    assert 'macaddress' in current_if
    assert current_if['macaddress'] =='00:11:d8:11:11:11'


# Generated at 2022-06-20 18:05:29.980402
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    gbin = GenericBsdIfconfigNetwork(Mock())
    # TODO: expand this; any tests?
    assert gbin.get_interfaces_info('/sbin/ifconfig') == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-20 18:05:39.003851
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Place test here
    # 
    # input parameters
    defaults = "test"
    interfaces = "test"
    ip_type = "test"
    # expected return
    expected = "test"
    # create instance with parameters
    obj = GenericBsdIfconfigNetwork(defaults, interfaces, ip_type)
    # invoke method with arguments
    result = obj.merge_default_interface()
    # check if result returned
    assert result == expected
    # check if function returned
    assert True
    
    

# Generated at 2022-06-20 18:05:52.605870
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    # create an instance of the class we want to test
    network = GenericBsdIfconfigNetwork()

    # test with a line configured as 'this that'
    common_word = 'this'
    test_word = 'that'
    words = [common_word, test_word]
    before_line = words
    current_if = {}
    ips = {}
    network.parse_unknown_line(words, current_if, ips)
    after_line = words
    assert before_line == after_line

    # test with a line configured as 'this that whatever'
    words = [common_word, test_word, 'whatever']
    before_line = words
    current_if = {}
    ips = {}
    network.parse_unknown_line(words, current_if, ips)
    after_line = words

# Generated at 2022-06-20 18:06:02.835188
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule

    import json
    test_data_path = os.path.join(os.path.dirname(__file__), 'data')
    tmpdir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    def exit_json(*args, **kwargs):
        sys.stdout.write(json.dumps(dict(*args, **kwargs)))

    def run_command(command):
        command_path = command[0]
        command_args = command[1:]
        data_file = os.path.join

# Generated at 2022-06-20 18:06:12.959939
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    # create initial data
    words = ['le0:', 'mem', '0xf8000000-0xf800ffff']
    current_if = {'device': 'le0'}
    ips = dict()

    # create class
    gbi = GenericBsdIfconfigNetwork()

    # run function
    gbi.parse_unknown_line(words, current_if, ips)

    # tests
    assert current_if['device'] == 'le0'
    assert current_if['mem_info'] == '0xf8000000-0xf800ffff'


# Generated at 2022-06-20 18:06:26.598625
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = MockedNetworkModule()
    network = GenericBsdIfconfigNetwork(module)
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
        'mtu': '65536',
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

    network.parse_inet_line(['inet', '127.0.0.1', 'netmask', '0xff000000', '', ''], current_if, ips)

# Generated at 2022-06-20 18:06:37.216721
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    arguments.platform = 'Generic_BSD_Ifconfig'
    # in theory we should be able to run this on a BSD box...
    # but we are not going to enforce that
    #if not sys.platform.startswith('freebsd') and not sys.platform.startswith('netbsd') and not sys.platform.startswith('openbsd') and sys.platform != 'darwin':
    #    raise Exception('generic BSD test only works on BSD (and Darwin) platforms')
    # create a module and a class to test
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    network = GenericBsdIfconfigNetwork(module)

    current_if = {}

# Generated at 2022-06-20 18:06:47.474650
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetworkModule()
    interfaces = {'foo': {'type': 'ether', 'media': 'Ethernet autoselect (1000baseT <full-duplex>)'},
                  'bar': {'type': 'unknown'},
                  'baz': {'type': 'unknown', 'media': 'Ethernet autoselect'}}
    network.detect_type_media(interfaces)
    assert interfaces == {'foo': {'type': 'ether', 'media': 'Ethernet autoselect (1000baseT <full-duplex>)'},
                          'bar': {'type': 'unknown'},
                          'baz': {'type': 'unknown', 'media': 'Ethernet autoselect'}}



# Generated at 2022-06-20 18:08:00.379020
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    import string
    import random
    class Module(object):
        pass
    module = Module()

    # test the IPv4 parser method using IPv4 address inputs
    method = GenericBsdIfconfigNetwork.parse_inet6_line

    # IPv4 test cases used from parse_inet_line
    # as they are well tested and a good template

# Generated at 2022-06-20 18:08:05.833234
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    instance = GenericBsdIfconfigNetwork()
    assert isinstance(instance, GenericBsdIfconfigNetwork)


# Generated at 2022-06-20 18:08:13.900381
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:08:22.856945
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    obj = GenericBsdIfconfigNetwork()
    iface = obj.parse_interface_line('lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384')
    assert iface == {'device': 'lo0',
                     'ipv4': [],
                     'ipv6': [],
                     'type': 'loopback',
                     'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
                     'macaddress': 'unknown',
                     'metric': '0',
                     'mtu': '16384'
                     }

# Generated at 2022-06-20 18:08:30.065002
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    net_info = dict()
    net_func = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '192.168.1.1', '-->', '192.168.5.5', 'netmask', '0xffffff00']
    net_func.parse_tunnel_line(words, net_info, net_info)
    assert net_info['type'] == 'tunnel', "Failed to detect tunnel interface."

# Generated at 2022-06-20 18:08:39.590137
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # This sets up a instance of the class
    _tmp = GenericBsdIfconfigNetwork()
    # Test for a successful return
    assert _tmp.parse_interface_line(['lo0','flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>','mtu','33184']) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'macaddress': 'unknown', 'metric': 'mtu', 'mtu': '33184'}
    # Test for a successful return

# Generated at 2022-06-20 18:08:50.726985
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    line = 'nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>'
    words = line.split()
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    network.parse_nd6_line(words, current_if, ips)
    assert current_if['options'][0] == 'PERFORMNUD'
    assert current_if['options'][1] == 'AUTO_LINKLOCAL'


# Generated at 2022-06-20 18:08:57.701921
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    plugin = GenericBsdIfconfigNetwork()
    current_if = {'status': 'unknown'}
    words = ['status:', 'active']
    plugin.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'active'

# Generated at 2022-06-20 18:09:06.679791
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # Test 1
    interface_line = '''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'''

    words = interface_line.split()
    current_if = generic_bsd_ifconfig_network.parse_interface_line(words)

    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['metric'] == '0'
    assert current_if['mtu'] == '16384'

    # Test 2