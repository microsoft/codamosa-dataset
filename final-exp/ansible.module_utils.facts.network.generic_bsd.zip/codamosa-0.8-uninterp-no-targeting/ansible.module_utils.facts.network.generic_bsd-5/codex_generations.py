

# Generated at 2022-06-20 18:00:04.108859
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    g = GenericBsdIfconfigNetwork()
    g.parse_options_line([], {}, {})



# Generated at 2022-06-20 18:00:14.594301
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Testing a top-level function with a class argument
    # https://stackoverflow.com/questions/3589311/get-defining-class-of-unbound-method-object-in-python-3
    #
    # ns = BSDIfconfigNetwork()
    ns = GenericBsdIfconfigNetwork()
    # TODO: This test may fail if the order of elements in dict returned by ns.detect_type_media changes

# Generated at 2022-06-20 18:00:22.664102
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    '''Unit test for constructor of class GenericBsdIfconfigNetwork

    'test_GenericBsdIfconfigNetwork' will be executed only when this particular
    test_module is specified in command line. Otherwise all test_modules will
    get executed.
    '''
    obj = GenericBsdIfconfigNetwork()
    assert obj.interface_get_ipv4_address(
        {'ipv4': [{'address': '192.168.1.100', 'netmask': '255.255.255.0', 'broadcast': '192.168.1.255'},
                  {'address': '192.168.2.100', 'netmask': '255.255.255.0', 'broadcast': '192.168.2.255'}]}
    ) == '192.168.1.100'


# Generated at 2022-06-20 18:00:32.433214
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:00:34.125891
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gen_obj = GenericBsdIfconfigNetwork()
    result = gen_obj.get_options('UP <LOOPBACK, RUNNING, MULTICAST>')
    assert result == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']


# Generated at 2022-06-20 18:00:44.019465
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Given an GenericBsdIfconfigNetwork class instance
    net = GenericBsdIfconfigNetwork()
    # And a set of words, a current interface and an ip collection
    words = ['inet6', 'fe80::21e:8cff:feb7:2b30%en0', 'prefixlen', '64', 'scopeid', '0x6']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # When I parse the words
    net.parse_inet6_line(words, current_if, ips)
    # Then the ip info is in the expected format
    assert current_

# Generated at 2022-06-20 18:00:48.565116
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """Test constructor of class GenericBsdIfconfigNetwork"""
    module = AnsibleModule(argument_spec={})
    network_facts = GenericBsdIfconfigNetwork(module)
    assert network_facts != None

# Generated at 2022-06-20 18:01:02.601817
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    facts = GenericBsdIfconfigNetwork()
    current_if = {'ipv6': []}

    words = ['inet6', 'fe80::5054:ff:fe71:6d8b%lo0a', 'prefixlen', '64', 'scopeid', '0x3']
    expected_ipv6 = [{'address': 'fe80::5054:ff:fe71:6d8b%lo0a', 'prefix': '64', 'scope': '0x3'}]
    facts.parse_inet6_line(words, current_if, {'all_ipv6_addresses': []})
    assert current_if['ipv6'] == expected_ipv6


# Generated at 2022-06-20 18:01:14.143675
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    m = ansible_module_mock()
    o = GenericBsdIfconfigNetwork(m)

    m.get_bin_path.side_effect = lambda x: x

    o.get_default_interfaces = mock.MagicMock()
    o.get_default_interfaces.return_value = ('', '')

    o.detect_type_media = mock.MagicMock()

# Generated at 2022-06-20 18:01:17.203111
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule({})
    module.warn = lambda *args: None
    network = GenericBsdIfconfigNetwork(module)
    assert network is not None
    assert isinstance(network, GenericBsdIfconfigNetwork)


# Generated at 2022-06-20 18:01:39.047484
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = 'tests/unit/output/network_ifconfig_bsd_01_route'
    n = GenericBsdIfconfigNetwork()

    # Test freebsd 10.2
    ifconfig_path = 'tests/unit/output/network_ifconfig_bsd_02_ifconfig'
    expected = {
        'interface': 'epair0b',
        'gateway': 'fe80::1%epair0b',
        'address': 'fe80::6:53ff:fe7f:c2f'
    }
    (ipv4, ipv6) = n.get_default_interfaces(route_path)
    assert ipv4 == expected

    # Test netbsd
    ifconfig_path = 'tests/unit/output/network_ifconfig_bsd_03_ifconfig'
   

# Generated at 2022-06-20 18:01:45.993929
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    current_if = dict()
    words = ['lladdr', 'fe:ff:ff:ff:ff:ff']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    attrs = dict(
        get_options=MagicMock(return_value=[])
    )
    with patch.multiple(GenericBsdIfconfigNetwork, **attrs) as mocked_methods:
        inst = GenericBsdIfconfigNetwork()
        inst.parse_lladdr_line(words, current_if, ips)
        assert current_if['lladdr'] == 'fe:ff:ff:ff:ff:ff'

# Generated at 2022-06-20 18:01:50.910827
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    pltfrm = GenericBsdIfconfigNetwork()

    # DragonFly
        # xl0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
        #     options=8<VLAN_MTU>
        #     ether 00:30:48:01:80:2f
        #     media: Ethernet autoselect (none)
        #     status: no carrier
    assert pltfrm.parse_media_line(
        ['media:', 'Ethernet', 'autoselect', '(none)'],
        {'media': None}, {},
    ) == {'media': 'Ethernet autoselect (none)', 'media_select': 'autoselect', 'media_type': '(none)', 'media_options': []}

    # FreeBSD

# Generated at 2022-06-20 18:01:55.480147
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    interface_line_words = ['flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'options=3<RXCSUM,TXCSUM>']
    current_if = {}
    ips = {}
    gb = GenericBsdIfconfigNetwork(None)
    gb.parse_nd6_line(interface_line_words, current_if, ips)

    assert current_if['options'] == ['RXCSUM', 'TXCSUM']

# Generated at 2022-06-20 18:02:08.622237
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    import sys
    sys.path.append(os.path.dirname(__file__))
    from lib_network_generic_bsd_test import GenericBsdIfconfigNetworkTest

    n = GenericBsdIfconfigNetworkTest()

# Generated at 2022-06-20 18:02:20.039943
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    mod = module_skeleton.CommandBasedModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(mod)
    iface = {}
    words = ['media:', 'Ethernet', 'ie', '10Gbase-T', '(10Gbase-TX)', 'status:', 'active']
    network.parse_media_line(words, iface, {})
    assert iface['media'] == 'Ethernet'
    assert iface['media_select'] == 'ie'
    assert iface['media_type'] == '10Gbase-T'
    assert iface['media_options'] == ['10Gbase-TX']



# Generated at 2022-06-20 18:02:24.358239
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    ret = get_options('<UP,LOOPBACK,RUNNING,MULTICAST>')
    module.exit_json(changed=False, ansible_facts=dict(ansible_network_resources=ret))


# Generated at 2022-06-20 18:02:30.025485
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    GenericBsdIfconfigNetwork_instance = GenericBsdIfconfigNetwork()
    status_line = ['status:', 'active']
    current_if = {'status': 'inactive'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    GenericBsdIfconfigNetwork_instance.parse_status_line(status_line, current_if, ips)
    assert current_if['status'] == 'active'

# Generated at 2022-06-20 18:02:42.243526
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    net = GenericBsdIfconfigNetwork()
    current_if = {'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    #netbsd ifconfig output with dot separated netmask
    net.parse_inet_line(['inet', '1.1.1.1', 'netmask', '255.255.255.0'], current_if, ips)
    assert ips['all_ipv4_addresses'] == ['1.1.1.1']

# Generated at 2022-06-20 18:02:47.276447
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    option_string = "UP,BROADCAST,RUNNING,MULTICAST"
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']

    option_string = "UP,BROADCAST"
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'BROADCAST']

    option_string = "UP,BROADCAST"
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'BROADCAST']

    option_string = "UP BROADCAST"
    options = GenericBsdIfconfigNetwork.get_options(option_string)
    assert options == ['UP', 'BROADCAST']



# Generated at 2022-06-20 18:03:34.876333
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Create object
    network = GenericBsdIfconfigNetwork()
    # Create test data
    result = False
    errmsg = "Failed"
    expected_result_keys = ['device', 'flags', 'ipv4', 'ipv6', 'metric', 'macaddress', 'mtu', 'type']
    # The following works for FreeBSD, OpenBSD and NetBSD.
    words = ['lo1', ':', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    # Ensure method returns expected result
    result = network.parse_interface_line(words)

# Generated at 2022-06-20 18:03:45.752013
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    fact_under_test = GenericBsdIfconfigNetwork()

    # Target function callable
    function_under_test = fact_under_test.parse_tunnel_line

    # Test 1:
    # normal test. Single IPv6 address, no scope, no prefix
    current_if = dict()
    ips = dict()
    words = 'tunnel inet6 fe80::205:5eff:fe02:b16%en5 prefixlen 64  --> ::'
    words = words.split()

    function_under_test(words, current_if, ips)

    expected_current_if = dict()
    expected_current_if['type'] = 'tunnel'
    expected_current_if['ipv6'] = list()
    expected_current_if['ipv6'].append(dict())
    expected_current_

# Generated at 2022-06-20 18:03:55.872374
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    from ansible.module_utils.network.common.network import NetworkModule
    from ansible.module_utils.network.common.netinfo import NetworkInfo
    from ansible.module_utils.network.common.facts import NetworkFacts
    from ansible.module_utils.network.common.config import NetworkConfig, ConfigLine
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic.bsd.ifconfig import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic.bsd.netstat import GenericBsdNetstatNetwork
    from ansible.module_utils.facts.network.generic.bsd.route import GenericBsdRouteNetwork

# Generated at 2022-06-20 18:03:57.320435
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass

# Generated at 2022-06-20 18:04:07.375235
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    expected_current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
        'mtu': '33184',
        'flags': ['LOOPBACK', 'UP', 'RUNNING', 'MULTICAST']
    }

    expected_current_if_modified = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': 'unknown',
        'mtu': '33184',
        'flags': ['LOOPBACK', 'UP', 'RUNNING', 'MULTICAST'],
        'status': 'active'
    }


# Generated at 2022-06-20 18:04:19.539962
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = MockModule()


# Generated at 2022-06-20 18:04:24.519254
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # create an instance of the class GenericBsdIfconfigNetwork
    # to test method populate
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()

    assert test_GenericBsdIfconfigNetwork is not None


# Generated at 2022-06-20 18:04:35.861515
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    obj = GenericBsdIfconfigNetwork()
    assert obj.get_options("options=23<ACCEPT_RTADV,ACCEPT_RTADVD,AUTO_LINKLOCAL>") == ['ACCEPT_RTADV', 'ACCEPT_RTADVD', 'AUTO_LINKLOCAL']
    assert obj.get_options("options=3<RXCSUM,TXCSUM>") == ['RXCSUM', 'TXCSUM']
    assert obj.get_options("options=2<ACCEPT_RTADV,ACCEPT_RTADVD,AUTO_LINKLOCAL>") == ['ACCEPT_RTADV', 'ACCEPT_RTADVD', 'AUTO_LINKLOCAL']

# Generated at 2022-06-20 18:04:43.007153
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = dict()
    defaults['interface'] = 'lo0'
    defaults['address'] = '192.168.2.2/24'
    interfaces = dict()
    interfaces['lo0'] = dict()
    interfaces['lo0']['ipv4'] = [{'address': '127.0.0.1', 'netmask': '255.255.255.255'}, {'address': '192.168.2.2', 'netmask': '255.255.255.0', 'broadcast': '192.168.2.255', 'network': '192.168.2.0'}]
    interfaces['lo0']['ipv6'] = [{'address': '::1', 'prefix': '128'}]

# Generated at 2022-06-20 18:04:49.898962
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    klass = GenericBsdIfconfigNetwork()
    interfaces = dict()
    interfaces['eth0'] = dict()
    interfaces['eth0']['media'] = 'Ether'
    interfaces['eth0']['type'] = 'unknown'
    result = klass.detect_type_media(interfaces)
    assert result['eth0']['type'] == 'ether'

# Generated at 2022-06-20 18:05:22.841571
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Test parsing of ether type

    network = GenericBsdIfconfigNetwork()
    current_if = dict()

    # Test data
    words = ['ether', '00:00:f2:46:b7:73']
    ips = dict()

    # Expected output
    expected_current_if = dict(
        macaddress='00:00:f2:46:b7:73',
    )

    # Execute the parse_ether_line() method
    network.parse_ether_line(words, current_if, ips)

    # Verify the results
    assert current_if == expected_current_if

# Generated at 2022-06-20 18:05:31.385713
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    import pytest
    obj = GenericBsdIfconfigNetwork()
    # First test case:
    words = ["lladdr", "60:03:08:8b:61:1f"]
    current_if = {"device" : "en0"}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    expected = current_if
    obj.parse_lladdr_line(words, current_if, ips)
    assert current_if == expected
    # Second test case:
    words = ["lladdr", "60:03:08:8b:61:1f"]
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-20 18:05:44.077943
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    platform = 'Generic_BSD_Ifconfig'

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    input_words_1 = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    current_if = {}
    ips = {}

    generic_bsd_ifconfig_network.parse_nd6_line(input_words_1, current_if, ips)

    assert len(current_if) == 1
    assert len(ips) == 0
    assert 'options' in current_if
    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']

    input_words

# Generated at 2022-06-20 18:05:52.399779
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    # Needs to be initialized in order to use assertRaises
    exception = None
    obj = GenericBsdIfconfigNetwork(module)

    try:
        obj.get_interfaces_info()
    except Exception as inst:
        # Store exception for later comparison
        exception = inst

    assert exception is not None
    assert isinstance(exception, TypeError)

    # input parameters are incorrect
    try:
        obj.get_interfaces_info(ifconfig_path="", ifconfig_options="")
    except Exception as inst:
        # Store exception for later comparison
        exception = inst

    assert exception is not None
    assert isinstance(exception, ValueError)

    # input parameters are correct but ifconfig bin does not exist

# Generated at 2022-06-20 18:06:00.466242
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gbin = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}
    words = ['tunnel', 'inet6', '2001:470:1f0b:1c1::1', 'prefixlen', '64', 'tsec', 'nopmtu', 'autoconf', 'randomizeid']
    gbin.parse_tunnel_line(words, iface, ips)
    assert iface == {'type': 'tunnel'}


# Generated at 2022-06-20 18:06:14.122734
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Test case: Define a freebsd.conf file
    freebsd_conf = """
mtu 68976
options=80000<LINKSTATE>
nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
groups=epair0

nd6 options=201<PERFORMNUD,DAD,AUTO_LINKLOCAL>
media: Ethernet autoselect
status: active
"""

    network_facts = GenericBsdIfconfigNetwork()
    ifaces = network_facts.parse_network_data(freebsd_conf)
    assert ifaces['epair0']['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']
    assert ifaces['groups'] == ['epair0']

# Generated at 2022-06-20 18:06:21.637460
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    f_module = FakeModule()
    f_platform = FakePlatform()
    f_platform.machine = 'i386'
    f_module.platform = f_platform
    f_network = GenericBsdIfconfigNetwork(f_module)
    f_current_if = {}
    f_words = []
    f_ips = {}
    f_network.parse_options_line(f_words, f_current_if, f_ips)
    assert f_current_if['options'] == []
    f_words = ['options=<option1,option2>']
    f_network.parse_options_line(f_words, f_current_if, f_ips)
    assert f_current_if['options'] == ['option1', 'option2']

# Generated at 2022-06-20 18:06:29.242000
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork
    m = GenericBsdIfconfigNetwork()
    words=['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {}
    ips = {}
    m.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'

# Generated at 2022-06-20 18:06:38.009517
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    empty_option_string = ''
    assert GenericBsdIfconfigNetwork.get_options(empty_option_string) == []

    missing_delimiters_option_string = 'asdf'
    assert GenericBsdIfconfigNetwork.get_options(missing_delimiters_option_string) == []

    trailing_delimiter_option_string = '<>'
    assert GenericBsdIfconfigNetwork.get_options(trailing_delimiter_option_string) == []

    leading_delimiter_option_string = '<a>'
    assert GenericBsdIfconfigNetwork.get_options(leading_delimiter_option_string) == ['a']

    single_option_option_string = '<a>'
    assert GenericBsdIfconfigNetwork.get_options(single_option_option_string)

# Generated at 2022-06-20 18:06:49.097764
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # input parameters
    words = [ 'inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.0.255.255' ]
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # run method to be tested
    inet_line = GenericBsdIfconfigNetwork()
    inet_line.parse_inet_line(words, current_if, ips)

    # validation

# Generated at 2022-06-20 18:09:02.283881
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # This class is tested by test_parsers.py
    pass


# Generated at 2022-06-20 18:09:04.960920
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    result = []
    current_if = {}
    words = ['status:', 'active']
    GenericBsdIfconfigNetwork.parse_status_line(result, words, current_if)
    assert current_if['status'] == 'active'


# Generated at 2022-06-20 18:09:14.743942
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    hostname = "localhost"
    class_params = {"module":None}
