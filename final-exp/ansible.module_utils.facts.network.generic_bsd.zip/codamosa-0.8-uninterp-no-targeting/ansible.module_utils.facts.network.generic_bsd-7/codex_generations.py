

# Generated at 2022-06-20 17:59:42.677197
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    a = GenericBsdIfconfigNetwork()
    words = []
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    a.parse_unknown_line(words, current_if, ips)

# Generated at 2022-06-20 17:59:49.985151
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module_mock = MagicMock()
    module_mock.get_bin_path.side_effect = lambda x: 'route_bin_path'
    module_mock.run_command.return_value = 0, '', ''
    network = GenericBsdIfconfigNetwork(module_mock)

    network.get_default_interfaces('route_path')
    module_mock.run_command.assert_has_calls([
        call(['route_path', '-n', 'get', 'default']),
        call(['route_path', '-n', 'get', '-inet6', 'default'])
    ])

# Generated at 2022-06-20 17:59:58.147221
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    testobj = GenericBsdIfconfigNetwork(module)
    current_if = dict(device='lo0')
    words = ['ether', '00:00:00:00:00:00']
    testobj.parse_ether_line(words, current_if, dict())
    assert current_if == dict(device='lo0', macaddress='00:00:00:00:00:00', type='ether')



# Generated at 2022-06-20 18:00:11.843951
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork
    dut = GenericBsdIfconfigNetwork()

    # NetBSD ifconfig -a output

# Generated at 2022-06-20 18:00:21.754353
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Assume
    #   - There is ifconfig with -a option (in order to get all information)
    ifconfig_path = 'ifconfig'
    #   - There are 2 IPv4 addresses
    #     - 192.168.0.1/24 (with broadcast address)
    #     - 192.168.1.1/24
    #   - There is no IPv6 address
    # When
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-20 18:00:27.531027
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    interface = {}
    ips = {}
    words = ['inet6', 'fe80::250:56ff:fea8:f869', 'prefixlen', '64', 'scopeid', '0x2']
    network.parse_inet6_line(words, interface, ips)
    assert words[1] == interface['ipv6'][0]['address']
    assert words[3] == interface['ipv6'][0]['prefix']
    assert words[5] == interface['ipv6'][0]['scope']


# Generated at 2022-06-20 18:00:34.245993
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    GenericBsdIfconfigNetwork().parse_tunnel_line(['tunnel','inet','192.168.1.1','dest','192.168.1.2','netmask','255.255.0.0','0x0','0x0'], {'device': 'tun0'}, {})


# Generated at 2022-06-20 18:00:42.424737
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # Ensure we can parse a tunnel interface line
    # tun0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1440
    words = 'tun0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1440'.split()
    gen = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    gen.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

#############################################################################
# Network facts for Solaris
#############################################################################

# Generated at 2022-06-20 18:00:49.917266
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # FIXME: Note: To run the test, you need to comment the first line of the
    # class, i.e. #class GenericBsdIfconfigNetwork(GenericIfconfigNetwork):
    # Also, comment the line "from ansible.module_utils.common.network.common import get_interface_mac, load_platform_subclass"
    # in this file.
    test_class = GenericBsdIfconfigNetwork()

    device_name = 'lo0'
    flags = '8049<UP,LOOPBACK,RUNNING,MULTICAST>'
    mtu = '32768'
    words = [device_name, flags, 'metric', '1', 'mtu', mtu]
    current_if = test_class.parse_interface_line(words)
    assert current_if['device'] == device_name

# Generated at 2022-06-20 18:01:03.483555
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork({})

    class Interface():
        def __init__(self, word, word_list):
            self['ipv4'] = []
            self['ipv6'] = []
            self['device'] = word
            self['flags'] = self.get_options(word_list[3])

        def append(self, ip_list):
            self[ip_list].append(ip_list)

    def get_options(self, option_string):
        start = option_string.find('<') + 1
        end = option_string.rfind('>')
        if (start > 0) and (end > 0) and (end > start + 1):
            option_csv = option_string[start:end]
            return option_csv.split(',')
        else:
            return []



# Generated at 2022-06-20 18:01:37.082158
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    ctx = dict(
        module=Mock(),
        platform='darwin',
        host=Mock(),
    )
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='')
    ctx['module'].params = dict(gather_subset=['min'])
    ctx['module'].params = dict(gather_subset=['all'])
    network = GenericBsdIfconfigNetwork(module=module, **ctx)
    network.get_default_interfaces('route')


# Generated at 2022-06-20 18:01:46.951745
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModuleMock()
    platform = 'Generic_BSD_Ifconfig'
    ml = NetworkModuleLoader(platform)
    net = ml.load_module(module)

    current_if = {}
    words = ['status:', 'active']

    net.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:01:54.155373
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # This is not a real test, just a sanity check
    # that this function doesn't crash
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network.parse_interface_line(['em0', 'flags=', 'mtu'])


# Generated at 2022-06-20 18:02:03.417471
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule({})
    handler = GenericBsdIfconfigNetwork()

    words = ["mock0:", "flags=8802<BROADCAST,SIMPLEX,MULTICAST>", "metric 0", "mtu 1500"]
    current_if = handler.parse_interface_line(words)
    assert current_if == {'device': 'mock0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'], 'macaddress': 'unknown', 'mtu': '1500', 'metric': '0'}

    words = ["mock1:", "flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>", "mtu 1500"]
    current_if

# Generated at 2022-06-20 18:02:15.129207
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    abstract_network = GenericBsdIfconfigNetwork()
    # test_object is a new instance of class GenericBsdIfconfigNetwork
    if sys.version_info[:2] == (2, 6):
        test_object = abstract_network
    else:
        test_object = abstract_network()
    # words is an array containing tunnel
    words = list()
    words.append('tunnel')
    # current_if is a dictionary containing device
    current_if = dict()
    current_if['device'] = 'lo0'
    # ips is a dictionary containing all_ipv4_addresses, all_ipv6_addresses
    ips = dict()
    ips['all_ipv4_addresses'] = list()
    ips['all_ipv6_addresses'] = list()
    result = test

# Generated at 2022-06-20 18:02:23.994853
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    ifconfig_network = GenericBsdIfconfigNetwork()
    # test if parse_interface_line method return correct values
    test_interface_line = ['lo1:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384']
    test_interface = {'device': 'lo1',
                      'ipv4': [],
                      'ipv6': [],
                      'type': 'unknown',
                      'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
                      'macaddress': 'unknown',
                      'metric': '0',
                      'mtu': '16384'}
    parsed_interface = ifconfig_network.parse_interface_line(test_interface_line)


# Generated at 2022-06-20 18:02:34.374872
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())
    result = dict(changed=False, warnings=[])
    network_facts = GenericBsdIfconfigNetwork(module)
    current_if = dict(ipv4=[])
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.255.255.255', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']

# Generated at 2022-06-20 18:02:43.926558
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:50.802957
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    class TestGenericBsdIfconfigNetwork(unittest.TestCase):
        def setUp(self):
            self.generic_bsd_ifconfig = GenericBsdIfconfigNetwork()

        def tearDown(self):
            self.generic_bsd_ifconfig = None


# Generated at 2022-06-20 18:03:03.229786
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = distro.id()
    if platform != 'FreeBSD':
        pytest.skip("Skipping test, platform not supported")

    gbin = GenericBsdIfconfigNetwork()

    # Test FreeBSD
    route_path = gbin.module.get_bin_path('route')

    default_ipv4, default_ipv6 = gbin.get_default_interfaces(route_path)
    assert type(default_ipv4) is dict
    assert 'gateway' in default_ipv4
    assert 'interface' in default_ipv4
    assert default_ipv4['gateway'] == '192.168.0.1'
    assert default_ipv4['interface'] == 'igb0'

    assert 'gateway' in default_ipv6
    assert 'interface' in default_ipv6

# Generated at 2022-06-20 18:03:23.927016
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    mock_module = MagicMock()
    mock_module.run_command.return_value = 0, "", ""
    network = GenericBsdIfconfigNetwork(mock_module)
    interfaces = {}
    current_if = dict(
        device="utun",
        ipv4=[],
        ipv6=[],
        type="unknown"
    )
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    # Test the functions which are used in ifconfig
    network.parse_tunnel_line(['tunnel'], current_if, ips)
    assert interfaces['utun'] == dict(
        device="utun",
        ipv4=[],
        ipv6=[],
        type="tunnel"
    )

# Generated at 2022-06-20 18:03:34.515091
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    ifconfig_parser = GenericBsdIfconfigNetwork()

    # IPv6 tunnel
    input = 'tun6to4: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1280 tunnel inet6 2002:383a:8701:800::2 --> 2002:c058:6301::1'
    output = {}
    ifconfig_parser.parse_tunnel_line(input.split(), output, {})
    assert output == {'type': 'tunnel'}

    # IPv4 tunnel

# Generated at 2022-06-20 18:03:45.615433
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = dict(status='whatever')

# Generated at 2022-06-20 18:03:55.810779
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():

    # set up object
    mock_module = MagicMock() 
    mock_module.get_bin_path.return_value = True
    gen_bsd_ifconfig_net = GenericBsdIfconfigNetwork(mock_module)

    # test with valid input
    assert gen_bsd_ifconfig_net.get_options('<OPTIONS>') == []
    assert gen_bsd_ifconfig_net.get_options('<OPTION1,OPTION2>') == ['OPTION1', 'OPTION2']
    assert gen_bsd_ifconfig_net.get_options('<OPTION1, OPTION2>') == ['OPTION1', 'OPTION2']

# Generated at 2022-06-20 18:04:06.846118
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    media_line = "media: Ethernet 10Gbase-T <full-duplex> status: active"

    dev = GenericBsdIfconfigNetwork()
    media_dict = {}
    dev.parse_media_line(media_line.split(), media_dict, {})

    assert media_dict['media'] == 'Ethernet'
    assert media_dict['media_select'] == '10Gbase-T'
    assert media_dict['media_type'] == 'full-duplex'
    assert 'media_options' not in media_dict

    media_line = "media: Ethernet autoselect (1000baseT <full-duplex>) status: active"

    dev = GenericBsdIfconfigNetwork()
    media_dict = {}
    dev.parse_media_line(media_line.split(), media_dict, {})


# Generated at 2022-06-20 18:04:19.205373
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifc = GenericBsdIfconfigNetwork()

    defaults = {'interface': 'eth0'}
    interfaces = {'eth0':
        {
            'device': 'eth0',
            'ipv4': [{'address': '127.0.0.1'}],
            'ipv6': [{'address': '::1'}]
        }
    }
    ifc.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['ipv4[0].address'] == '127.0.0.1'

    defaults = {'interface': 'eth0', 'address': '127.0.0.2'}
    ifc.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-20 18:04:25.002516
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    current_if = {}
    ips = {}

    words = ['line', 'with', 'some', 'words']

    generic_bsd_ifconfig_network.parse_unknown_line(words, current_if, ips)

# Generated at 2022-06-20 18:04:36.208860
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:04:38.190925
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # This is a virtual method for a subclass which should be implemented to return
    # a list of default_ipv4, default_ipv6 interfaces.
    pass


# Generated at 2022-06-20 18:04:50.785282
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # Execute a pass run of the method to see if it does what we expected
    # Note: This unit test requires a working ifconfig in path, and root privileges on the system
    # This test has been specifically designed to pass on a FreeBSD system, but is also intended to
    # pass on most Linux distributions as well (although on Linux, a line with 'lladdr' is not expected)
    inst = GenericBsdIfconfigNetwork()

    words = [
        "lladdr", "xx:xx:xx:xx:xx:xx",
        "nws", "64",
        "maxmtu", "9000",
        "minmtu", "68",
        "media:", "Ethernet", "autoselect", "(none)"
    ]

# Generated at 2022-06-20 18:05:07.627311
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    gen = GenericBsdIfconfigNetwork()
    words = ['lladdr', '11:22:33:44:55:66']
    current_if = {}
    ips = {}
    gen.parse_lladdr_line(words, current_if, ips)
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == '11:22:33:44:55:66'

# Generated at 2022-06-20 18:05:19.782467
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    class TestModule(object):
        pass
    test_module = TestModule()
    test_module.run_command = MagicMock(return_value=[0, '', ''])

# Generated at 2022-06-20 18:05:29.579364
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    c = GenericBsdIfconfigNetwork()
    test_case_inputwords = [
        'ether',
        '00:0c:29:7d:3c:2b',
    ]
    test_case_output = {
        'device': '',
        'macaddress': '00:0c:29:7d:3c:2b',
        'ipv4': [],
        'type': 'ether',
        'ipv6': [],
    }
    current_if = {'device': '', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                  'macaddress': 'unknown'}
    ips = {}
    c.parse_ether_line(test_case_inputwords, current_if, ips)
    assert current_if == test_case_output

# Generated at 2022-06-20 18:05:34.090392
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    iface = dict(
        media='Ethernet',
    )
    f = GenericBsdIfconfigNetwork()
    f.detect_type_media(iface)
    assert iface['type'] == 'ether'

# Generated at 2022-06-20 18:05:45.132142
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():

    mac_test1 = {
        'lladdr': '00:11:22:33:44:55'
    }
    mac_test2 = {
        'lladdr': '00:11:22:33:44:55',
        'macaddress': 'unknown'
    }
    mac_test3 = {
        'lladdr': '00:11:22:33:44:55',
        'macaddress': '00:11:22:33:44:55'
    }

    generic = GenericBsdIfconfigNetwork()
    words = [
        'lladdr',
        '00:11:22:33:44:55'
    ]

    generic.parse_lladdr_line(words, mac_test1, {})

# Generated at 2022-06-20 18:05:55.383858
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '0.0.0.0'
    assert current_

# Generated at 2022-06-20 18:06:04.181601
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():

    class TestArgs(object):
        def __init__(self):
            self.bin_path = []
            self.run_command = []
    
    module = TestArgs()
    module.run_command = ['route', '-n', 'get', 'default']

    net_facts = GenericBsdIfconfigNetwork()
    net_facts._module = module
    net_facts._module.get_bin_path = lambda path: path

    iface = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    net_facts.parse_status_line(['status:', 'active'], iface, ips)

# Unit test

# Generated at 2022-06-20 18:06:12.958807
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = ansible_module_mock()
    network = GenericBsdIfconfigNetwork()
    network.module = module
    current_if = {}
    ips = {}
    network.parse_nd6_line(['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'], current_if, ips)
    assert current_if == {'options': ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']}



# Generated at 2022-06-20 18:06:16.371194
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    assert GenericBsdIfconfigNetwork.populate(None)
    assert GenericBsdIfconfigNetwork.populate(None)

# Generated at 2022-06-20 18:06:25.903122
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = dict()
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)' ]

    f = FailoverModule().get_network_module('Generic_BSD_Ifconfig')()
    f.parse_media_line(words, iface, 0)

    iface['media'] == 'Ethernet'
    iface['media_select'] == 'autoselect'
    iface['media_type'] == 'full-duplex'
    iface['options'] == ['100baseTX']


# Generated at 2022-06-20 18:06:56.538465
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    obj = GenericBsdIfconfigNetwork()
    obj.os = "Darwin"
    option_string = '<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>'
    option_list = ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']
    assert obj.get_options(option_string) == option_list

# Generated at 2022-06-20 18:07:09.654203
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """Test constructor of class GenericBsdIfconfigNetwork."""
    # Make sure we are on a supported system
    python_version = sys.version_info[0]
    if python_version not in (2, 3):
        raise Exception('Python version 2 or 3 is required for this unit test.')

    platform_module = __import__('platform')
    if not re.match(r'FreeBSD|OpenBSD', platform_module.system(), re.IGNORECASE):
        raise Exception('This unit test requires FreeBSD or OpenBSD')

    n = GenericBsdIfconfigNetwork()

    # _check_for_netstat will call down to the superclass and throw an exception if netstat is missing
    assert n is not None



# Generated at 2022-06-20 18:07:20.465077
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.network.facts.network import Network, NetworkCollector
    import ansible.module_utils.facts.network.generic_bsd_ifconfig as generic_bsd_ifconfig
    import ansible.module_utils.facts.network.generic_bsd as generic_bsd

    obj = Network()
    obj.params = dict(gather_subset=['!all', '!min'])
    facts = list()

    # instantiate the base class for BSD ifconfig
    # this is what would get done by the module loader
    NetworkCollector.subclasses['generic_bsd_ifconfig'] = generic_bsd_ifconfig.NetworkGenericB

# Generated at 2022-06-20 18:07:31.504482
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    network_info_provider = GenericBsdIfconfigNetwork()

    # test populate method
    interfaces, ips = network_info_provider.get_interfaces_info(ifconfig_path=GENERICBSD_IFCONFIG_EXAMPLE_PATH)
    assert len(interfaces) == 18
    # check a few of the interfaces
    assert 'lo0' in interfaces
    assert 'gif0' in interfaces
    assert 'stf0' in interfaces
    # check gif0
    gif0 = interfaces['gif0']
    assert gif0['device'] == 'gif0'
    assert gif0['mtu'] == '1280'
    assert len(gif0['ipv6']) == 1

# Generated at 2022-06-20 18:07:43.811797
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:07:44.327166
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    pass

# Generated at 2022-06-20 18:07:50.194855
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
      network_module = GenericBsdIfconfigNetwork()
      words = ['Passive','Passive','Autoconfiguration','enabled','passive','autoconfmulticast','dad']
      ifconfig_path = network_module.module.get_bin_path('ifconfig')
      current_if = {}
      ips = {'all_ipv4_addresses': []}
      network_module.parse_nd6_line(words, current_if, ips)
      assert network_module.get_options(words[1]) == ['Passive', 'Autoconfiguration', 'passive', 'autoconfmulticast', 'dad']


# Generated at 2022-06-20 18:07:58.527300
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # This is a placeholder for a unit test
    # Unit tests should ideally cover each function/class indepently
    # to aid in readability and understanding of the module/class and
    # aid in debugging as the code base evolves.  However,
    # unit tests can be difficult to construct for a number of reasons and
    # is left as an exercise for the user of this module
    pass


# Generated at 2022-06-20 18:08:09.579077
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    bin_path = {'route': "./bin/route"}

    module = Mock()
    module.run_command = Mock(side_effect=run_mock_route)
    module.get_bin_path = Mock(return_value="")

    network = GenericBsdIfconfigNetwork()
    network.module = module

    interface = network.get_default_interfaces(bin_path["route"])
    assert interface == ({'interface': 'en0', 'gateway': '192.168.237.2'}, {})



# Generated at 2022-06-20 18:08:20.991835
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_network = GenericBsdIfconfigNetwork()
    assert generic_bsd_network.get_options('<RUNNING,UP>') == ['RUNNING', 'UP']
    assert generic_bsd_network.get_options('<>') == []
    assert generic_bsd_network.get_options('<RUNNING,UP') == []
    assert generic_bsd_network.get_options('dummy') == []
    assert generic_bsd_network.get_options('<RUNNING,UP> this that stuff') == ['RUNNING', 'UP']


# Generated at 2022-06-20 18:09:14.919457
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    network = GenericBsdIfconfigNetwork()

    # test1: ensure we can handle different interface types and get the info
    line1 = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'
    words1 = line1.split()
    result1 = network.parse_interface_line(words1)
    expected1 = dict(device='lo0', ipv4=[], ipv6=[], type='loopback', flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
                     metric='0', mtu='16384', macaddress='unknown')
    assert result1 == expected1

    # test2: ensure we can handle different interface types and get the info