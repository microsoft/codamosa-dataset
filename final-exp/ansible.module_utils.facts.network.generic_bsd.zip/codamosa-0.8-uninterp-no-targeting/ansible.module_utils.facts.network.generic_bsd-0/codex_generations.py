

# Generated at 2022-06-20 18:00:03.134051
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = exit_json
    module.fail_json = fail_json

    # This is the expected output of `ifconfig` command when executed in a FreeBSD system
    test_input = 'mtu 1500 ether 00:9c:02:1b:12:34  media: Ethernet autoselect (100baseTX <full-duplex>) status: active'
    # This is the expected output of method `parse_ether_line`
    expected_output = {'macaddress': '00:9c:02:1b:12:34', 'type': 'ether'}

    network = GenericBsdIfconfigNetwork(module)
    result = {}
    current_if = {}
    ips = {}
    words = test_input.split()

   

# Generated at 2022-06-20 18:00:13.845834
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    import os
    from ansible.module_utils.network.common.utils import dict_diff

    test = GenericBsdIfconfigNetwork()

    interface = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    test_input = 'media: Ethernet autoselect (100baseTX <full-duplex,flowcontrol>)'.split()
    expected_result= dict(media='Ethernet', media_select='autoselect', media_type='100baseTX', media_options=['full-duplex', 'flowcontrol'])

    test.parse_media_line(test_input, interface, ips)

    assert dict_diff(interface, expected_result) == {}

# Generated at 2022-06-20 18:00:16.630505
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = GenericBsdIfconfigNetwork()

    assert module.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:00:29.944658
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """Test get_interfaces_info"""

    ifconfig_path = './ifconfig_example'
    platform = GenericBsdIfconfigNetwork()
    interfaces, ips = platform.get_interfaces_info(ifconfig_path)
    assert 6 == len(interfaces)
    assert 6 == len(ips['all_ipv4_addresses'])
    assert len(ips['all_ipv4_addresses']) == len(set(ips['all_ipv4_addresses']))
    assert 6 == len(ips['all_ipv6_addresses'])
    assert len(ips['all_ipv6_addresses']) == len(set(ips['all_ipv6_addresses']))

    # test ether
    assert 'ether' == interfaces['eth0']['type']

    # test loopback

# Generated at 2022-06-20 18:00:42.390674
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    '''GenericBsdIfconfigNetwork.parse_ether_line should return the expected dict'''
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.plugins.network.bsd import GenericBsdIfconfigNetwork

    eth_line = ['et0', 'ether', '00:14:78:41:34:05', 'media', 'Ethernet', 'status:', 'active']
    te_line = ['te0', 'ether', '00:00:5e:00:01:0a', 'media:', '10Gbase-LR', '(auto)']


# Generated at 2022-06-20 18:00:49.930146
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    class UnitUnderTest:
        platform = 'Generic_BSD_Ifconfig'
        module = FakeModule()

        def run_command(self, cmd):
            return 0, '', ''

        def get_bin_path(self, bin):
            return bin

    unit_obj = UnitUnderTest()

    # create a new empty object
    obj = GenericBsdIfconfigNetwork(unit_obj)

    # init vars
    words = []

    words = ['nd6',
             'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>',
             'flags=8<GATEWAY>']

    # test parse of special Generic_BSD_Ifconfig_parse_nd6_line
    obj.parse_nd6_line(words, {}, {})

    # TODO: add assertions


# Generated at 2022-06-20 18:00:59.692850
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_status_line(['status:', 'active'], current_if, ips)
    assert current_if['status'] == 'active'


# Generated at 2022-06-20 18:01:05.194585
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gbin = GenericBsdIfconfigNetwork()
    gbin.parse_tunnel_line('tunnel src 127.0.0.1 dst 127.0.0.1'.split())

# Generated at 2022-06-20 18:01:14.930214
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    print("Executing unit test for method parse_status_line of class GenericBsdIfconfigNetwork.")

    # Test case 01:
    # Test case when the status line is valid and is passed to the function.
    print("Executing unit test case 01: Test case when the status line is valid and is passed to the function.")
    words = ['status: ', 'active']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network.parse_status_line(words, current_if, ips)

    assert len(current_if) == 1
    assert 'status' in current_if
    assert current_if['status'] == 'active'
    assert len(ips) == 0

    # Test case 02:
    # Test case

# Generated at 2022-06-20 18:01:25.835034
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    ifconfig_path = '/sbin/ifconfig'
    #  lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384
    #          options=3<RXCSUM,TXCSUM>
    #          inet6 ::1 prefixlen 128
    #          inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    #          inet 127.0.0.1 netmask 0xff000000
    #          nd6 options=1<PERFORMNUD>
    # lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    #   options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
   

# Generated at 2022-06-20 18:01:38.893214
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    line = "media: Ethernet autoselect (1000baseT full-duplex)"
    current_if = {}
    ips = {}
    words = line.split()
    GenericBsdIfconfigNetwork.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet', 'media_select': 'autoselect',
                          'media_type': '1000baseT', 'media_options': ['full-duplex']}

# Generated at 2022-06-20 18:01:51.256565
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Check if method populate works as expected.
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import HAS_SOCKET_IPV6
    import socket
    import sys

    # Dummy data for test_GenericBsdIfconfigNetwork_populate

# Generated at 2022-06-20 18:02:02.475533
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    network = GenericBsdIfconfigNetwork()

    current_if = {}
    ips = {}
    ipv = 'ipv4'

    def check_ipv4(current_if, ips):
        assert current_if['ipv4']
        assert len(current_if['ipv4']) == 1
        address = current_if['ipv4'][0]
        assert address['address'] == "127.0.0.1"
        assert address['netmask'] == "255.0.0.0"
        assert address['broadcast'] == "127.255.255.255"
        assert address['network'] == "127.0.0.0"
        assert not ips['all_ipv4_addresses']

    def check_ipv6(current_if, ips):
        assert current_if

# Generated at 2022-06-20 18:02:09.710299
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    interface = dict(
        device = 'eth0',
    )
    network = GenericBsdIfconfigNetwork({})
    line = 'ahoj'.split()
    network.parse_unknown_line(line, interface, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert len(interface) == 1


# Generated at 2022-06-20 18:02:21.196188
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    platform = sys.modules['ansible.module_utils.facts.network.generic_bsd_ifconfig']

# Generated at 2022-06-20 18:02:32.739423
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    m_run_command = Mock(return_value=(0, "", ""))
    module.run_command = m_run_command

    m_get_bin_path = Mock(return_value='/bin/ifconfig')
    module.get_bin_path = m_get_bin_path

    test_obj = GenericBsdIfconfigNetwork(module)
    test_words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    test_current_if = dict()
    test_ips = dict()
    expected_result = dict(options=['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL'])


# Generated at 2022-06-20 18:02:39.483374
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    """
    GenericBsdIfconfigNetwork - test parse_ether_line method
    """
    if 0:
        # TODO: implement this test
        # This test needs to compare the parse_ether_line method output against a known good
        # YAML output.  Unfortunately, there is no good way to do this as the parse_ether_line method
        # is not stubbed.  It calls several other stubbed methods and these methods return data
        # that is not easily available in one location.
        # The test, therefore, is implemented but disabled.
        #
        # If you are interested in working on this issue, please do.
        # Once complete, please remove this "if 0" and enable the test.

        #
        # create a mock module on which we can call fail_json, exit_json, and set the params
        #
        mock_

# Generated at 2022-06-20 18:02:50.115243
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:58.170159
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    g = GenericBsdIfconfigNetwork()

    # Test 4: lladdr parsed in hex format
    w = ['lladdr', '0x4']
    c = {}
    i = {}
    g.parse_lladdr_line(w, c, i)
    assert c['lladdr'] == '4'


# Generated at 2022-06-20 18:03:04.973116
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network_facts = GenericBsdIfconfigNetwork()
    line = ['epair0b', 'vnet', 'bridge', '0', 'laggproto', 'failover', 'lagg', 'failover', 'laggport', 'em0', 'laggport', 'em1']
    interface = {}
    stub_ips = {}
    network_facts.parse_unknown_line(line, interface, stub_ips)
    assert interface == {'epair0b': {'lagg': {'failover': {'laggproto': 'failover', 'laggport': ['em0', 'em1'], 'vnet': ['bridge', '0']}}}}



# Generated at 2022-06-20 18:03:26.100912
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    option_string = '<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST>'
    result = generic_bsd_ifconfig_network.get_options(option_string)
    assert result == ['UP', 'BROADCAST', 'NOTRAILERS', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    option_string = '<UP,BROADCAST,RUNNING>'
    result = generic_bsd_ifconfig_network.get_options(option_string)
    assert result == ['UP', 'BROADCAST', 'RUNNING']
    option_string = '<LOOPBACK,UP,LOWER_UP>'
    result = generic_bsd_ifconfig_

# Generated at 2022-06-20 18:03:28.323447
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    net = GenericBsdIfconfigNetwork()
    assert net.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:03:36.787599
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """
    A limited set of unit tests for method detect_type_media of class GenericBsdIfconfigNetwork.
    """
    def create_dict(device, media):
        """
        Create a dictionary where the key is 'device' and the value is
        {'device': device, 'media': media}.
        """
        d = {}
        d[device] = {}
        d[device]['device'] = device
        d[device]['media'] = media
        return d
    # test 'ether'
    interfaces = create_dict('lo0', 'Ethernet autoselect (1000baseT full-duplex)')
    interfaces = GenericBsdIfconfigNetwork.detect_type_media(None, interfaces)
    assert interfaces['lo0']['type'] == 'ether'
    # test 'unknown'
    interfaces = create

# Generated at 2022-06-20 18:03:41.173106
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    global provider
    provider = GenericBsdIfconfigNetwork()
    res = provider.parse_options_line(['options=2<TSO4,TSO6>'], {}, {})
    assert res == None



# Generated at 2022-06-20 18:03:48.495036
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    import os
    import ctypes
    libc = ctypes.CDLL(os.environ['LIBC'])

    current_if = {}
    ips = {}
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    network = GenericBsdIfconfigNetwork()
    network.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']


# Generated at 2022-06-20 18:03:57.354432
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # Test with good data
    gbin = GenericBsdIfconfigNetwork()

    # Test with a single line
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '1', 'mtu', '16384']
    current_if = {}
    ips = {}
    gbin.parse_unknown_line(words, current_if, ips)
    assert current_if == {}, "Failed to parse a valid single line"

    # Test with non-zero current_if and ips input variables
    words = []
    current_if = {'test': 'test'}
    ips = {'ip_test': 'ip_test'}
    g

# Generated at 2022-06-20 18:04:00.365219
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    gbif = GenericBsdIfconfigNetwork()
    assert gbif.populate() != None
    assert gbif.populate() != []



# Generated at 2022-06-20 18:04:07.944766
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    class TestGenericBsdIfconfigNetwork():
        def parse_inet6_line(self, words, ifinfo, ips):
            return

    test_GenericBsdIfconfigNetwork_obj = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork()
    test_parse_inet6_line_obj = TestGenericBsdIfconfigNetwork.parse_inet6_line(test_GenericBsdIfconfigNetwork_obj, ["inet6", "fe80::21e:67ff:fe6e:a6b0%bridge0", "prefixlen", "64", "scopeid", "0x8"], [], [])
    return True



# Generated at 2022-06-20 18:04:10.272571
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """ Unit test to detect_type_media. """
    pass

# Generated at 2022-06-20 18:04:21.114173
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:04:47.459537
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0', 'address': '127.0.0.1'}

# Generated at 2022-06-20 18:04:55.402066
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)

    assert hasattr(network, 'populate')
    assert hasattr(network, 'detect_type_media')
    assert hasattr(network, 'get_default_interfaces')
    assert hasattr(network, 'get_interfaces_info')
    assert hasattr(network, 'merge_default_interface')

    assert network.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:05:03.034197
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.network.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork

    # If you are debugging a test, please set the following environmental
    # variables to the appropriate values and comment out the "pass" below.
    #
    # Example:
    #
    # export ANSIBLE_NET_IFCONFIG_PATH="/sbin/ifconfig"
    # export ANSIBLE_NET_ROUTE_PATH="/sbin/route"

    pass

# Generated at 2022-06-20 18:05:10.718503
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule({})
    network = GenericBsdIfconfigNetwork(module)
    current_if = {
        'device': 'tun0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'macaddress': '00:11:22:33:44:55',
        'flags': ['UP', 'POINTOPOINT', 'RUNNING']
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_tunnel_line(['tunnel', 'inet', '172.16.2.2'], current_if, ips)
    assert current_if['type'] == 'tunnel'
    assert current_if['ipv4']

# Generated at 2022-06-20 18:05:15.485675
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options_string = '<UP,BROADCAST,RUNNING>'
    ifconfig_network = GenericBsdIfconfigNetwork(None)
    assert ifconfig_network.get_options(options_string)==['UP', 'BROADCAST', 'RUNNING']


# Generated at 2022-06-20 18:05:26.689696
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Note: these are the FreeBSD output of 'ifconfig -a'
    # Ubuntu output differs in the netmask format

    # test with netmask as a hex
    words = 'inet 192.168.2.2 netmask 0xffffff00 broadcast 192.168.2.255'.split()
    network.parse_inet_line(words, current_if, ips)

    assert len(ips['all_ipv4_addresses']) == 1

# Generated at 2022-06-20 18:05:30.938363
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    words = ['lladdr', 'fe:80:97:4f:4b:de']
    network = GenericBsdIfconfigNetwork()
    network.parse_lladdr_line(words, current_if, {})
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == 'fe:80:97:4f:4b:de'


# Generated at 2022-06-20 18:05:43.722630
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = FakeModule()
    route_path = 'fake-route'
    command = dict(v4=[route_path, '-n', 'get', 'default'],
                   v6=[route_path, '-n', 'get', '-inet6', 'default'])
    # command should be called twice, once for IPv4 and once for IPv6
    module.run_command_calls_expected = 2


# Generated at 2022-06-20 18:05:54.724452
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:06:03.483344
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    class TestIfconfig(GenericBsdIfconfigNetwork):
        """Simple test class for unit testing."""
        def __init__(self):
            pass

    test_ifconfig = TestIfconfig()

    test_interfaces = dict()
    test_interfaces['eth0'] = dict(ipv4=[], ipv6=[], type='ether', macaddress='00:11:22:33:44:55',
                                   flags=['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'PROMISC'],
                                   mtu=1500, device='eth0')


# Generated at 2022-06-20 18:06:27.994003
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    ansible_module = fake_ansible_module()
    generic_network = GenericBsdIfconfigNetwork(ansible_module)
    current_if = generic_network.get_interfaces_info(ifconfig_path='/sbin/ifconfig', ifconfig_options='-a')[0]['fxp0']

    # Parse output of ifconfig on FreeBSD
    # The second parameter 'nd6' will be passed to method when parse_nd6_line is call from parse_options_line method
    generic_network.parse_nd6_line(['nd6', 'options=1<PERFORMNUD>'], current_if, {})
    assert 'PERFORMNUD' in current_if['options']



# Generated at 2022-06-20 18:06:37.544796
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    TestGenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    assert TestGenericBsdIfconfigNetwork.populate() == {'interfaces': ['lo0']}

    assert TestGenericBsdIfconfigNetwork.get_options('<LOOPBACK,RUNNING,MULTICAST>') == ['LOOPBACK', 'RUNNING', 'MULTICAST']
    assert TestGenericBsdIfconfigNetwork.get_options('<UP>') == ['UP']
    assert TestGenericBsdIfconfigNetwork.get_options('UP') == []
    assert TestGenericBsdIfconfigNetwork.get_options('<>') == []
    assert TestGenericBsdIfconfigNetwork.get_options('') == []


# Generated at 2022-06-20 18:06:47.621262
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    gbin = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    test_input = 'media: Ethernet autoselect (1000baseT <full-duplex>)'
    test_input = test_input.split(' ')
    gbin.parse_media_line(test_input, current_if, ips)
    assert current_if == {'media': 'Ethernet',
                          'media_select': 'autoselect',
                          'media_type': 'full-duplex'}
    current_if = {}
    test_input = 'media: Ethernet autoselect (none)'
    test_input = test_input.split(' ')
    gbin.parse_media_line(test_input, current_if, ips)

# Generated at 2022-06-20 18:06:58.992620
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Setup
    parser = GenericBsdIfconfigNetwork({})
    ifconfig_path = parser.module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        return
    command = [ifconfig_path, '-a']
    rc, out, err = parser.module.run_command(command)
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Exercise
    parser.get_interfaces_info(ifconfig_path, interfaces, ips)

    # Verify
    assert interfaces != {} and ips != {}



# Generated at 2022-06-20 18:07:11.542315
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    args = {}
    base_dir = os.path.dirname(__file__)
    # expected results for FreeBSD11_Ifconfig_output.json
    fd = open(base_dir + '/FreeBSD11_Ifconfig_output.json', 'r')
    expected_result = json.load(fd)
    fd.close()

    # test output data for FreeBSD11_Ifconfig_output.json
    fd = open(base_dir + '/FreeBSD11_Ifconfig_output.txt', 'r')
    test_data = fd.read()
    fd.close()

    # create the test object
    test_obj = GenericBsdIfconfigNetwork()
    test_obj.module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=False
    )

    # set test environment

# Generated at 2022-06-20 18:07:16.085434
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    test_obj = GenericBsdIfconfigNetwork()
    test_dict = {}
    setattr(test_obj.module, "run_command", test_fixture)
    test_obj.populate()



# Generated at 2022-06-20 18:07:20.952700
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    test_network = GenericBsdIfconfigNetwork(None)
    current_interface = {'device': 'lo0'}
    ips = {}
    test_network.parse_ether_line(['ether', 'fe:04:96:03:3a:c7'], current_interface, ips)
    assert current_interface['macaddress'] == 'fe:04:96:03:3a:c7'
    assert current_interface['type'] == 'ether'



# Generated at 2022-06-20 18:07:24.512949
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # setup
    gbin = GenericBsdIfconfigNetwork(None)
    gbin.parse_unknown_line(None, None, None)

# Generated at 2022-06-20 18:07:32.695827
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    gn = GenericBsdIfconfigNetwork()

    current_if = dict(ipv4=[], ipv6=[])
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['inet6', 'fe80::1', 'prefixlen', '64', 'scopeid', '0x6', '0x1']

    gn.parse_inet6_line(words, current_if, ips)

    assert len(current_if['ipv6']) == 1
    assert current_if['ipv6'][0]['address'] == 'fe80::1'
    assert current_if['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-20 18:07:35.464236
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    instance = GenericBsdIfconfigNetwork({})
    assert instance is not None


# Generated at 2022-06-20 18:08:27.545130
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    host = GenericBsdIfconfigNetwork()
    words = ['options=3<RXCSUM,TXCSUM>', 'inet', '10.0.0.1', 'netmask','0xffffff00', 'broadcast', '10.0.0.2']
    current_if = {}
    ips = {}
    host.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['RXCSUM', 'TXCSUM']


# Generated at 2022-06-20 18:08:33.682429
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:08:41.133356
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    gen_bsd = GenericBsdIfconfigNetwork()
    
    expected  = {'address': 'fe80::1%lo0', 'prefix': '0', 'scope': '0x2'}
    
    current_if = {}
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '0', 'scopeid', '0x2']
    ips = {}
    
    gen_bsd.parse_inet6_line(words, current_if, ips)
    
    assert current_if['ipv6'][0] == expected
    assert ips == {'all_ipv6_addresses': ['fe80::1%lo0']}
    

# Generated at 2022-06-20 18:08:51.448803
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Setup
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    words = "lladdr 11:22:33:44:55:66".split()
    current_if = {}
    ips = {}
    # Execute
    generic_bsd_ifconfig_network.parse_lladdr_line(words, current_if, ips)
    # Verify
    assert current_if['lladdr'] == '11:22:33:44:55:66'


# Generated at 2022-06-20 18:09:04.657657
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # cidr style ip address (eg, 127.0.0.1/24) in inet line
    # netbsd uses ifconfig -e output after 7.1
    test_input = 'inet 127.0.0.1/24 broadcast 127.255.255.255 netmask 0xffffff00'.split()
    net = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    net.parse_inet_line(test_input, current_if, ips)
    assert 'address' in current_if['ipv4'][0]
    assert 'netmask' in current_if['ipv4'][0]
    assert 'network' in current_if['ipv4'][0]
    assert 'broadcast' in current_if['ipv4'][0]
    assert current