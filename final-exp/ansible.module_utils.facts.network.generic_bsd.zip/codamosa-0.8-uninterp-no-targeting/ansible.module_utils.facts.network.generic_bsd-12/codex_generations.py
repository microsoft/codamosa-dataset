

# Generated at 2022-06-20 17:59:33.306308
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    pass

# Generated at 2022-06-20 17:59:47.124723
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    mock_ifaces = dict(ipv4=[],
                       ipv6=[],
                       type='unknown')
    mock_defaults = dict()
    test_ns = GenericBsdIfconfigNetwork()
    test_ns.merge_default_interface(mock_defaults, mock_ifaces, 'ipv4')
    assert mock_defaults == dict()

    mock_ifaces = dict(ipv4=[],
                       ipv6=[],
                       type='unknown')
    mock_defaults = dict(interface='awesome')
    test_ns.merge_default_interface(mock_defaults, mock_ifaces, 'ipv4')
    assert mock_defaults == dict(interface='awesome')


# Generated at 2022-06-20 17:59:55.653565
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    gb = GenericBsdIfconfigNetwork()
    words = ['status:','active','something','extra','ignore','me']
    current_if = {}
    ips = {}
    gb.parse_status_line(words,current_if,ips)
    assert current_if['status'] == 'active'
    words = ['status:','inactive','something','extra','ignore','me']
    current_if = {}
    ips = {}
    gb.parse_status_line(words,current_if,ips)
    assert current_if['status'] == 'inactive'



# Generated at 2022-06-20 18:00:10.225792
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():  
    module= AnsibleModule(argument_spec={})
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    assert generic_bsd_ifconfig_network != None

# Generated at 2022-06-20 18:00:15.940567
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    mod = imp.load_source('ansible_module', './hacking/test-module')
    mod.BasicModule.module_args = 'name=eth0 macaddress=00:01:02:03:04:05'
    mod.AnsibleModule = mod.BasicModule
    net = GenericBsdIfconfigNetwork(module=mod)
    net.module.run_command = lambda *args, **kargs: (0, '', '')
    net.module.get_bin_path = lambda *args, **kargs: '/sbin/ifconfig'
    interfaces, ips = net.get_interfaces_info(mod.get_bin_path('ifconfig'))
    assert 'ether' == interfaces['eth0']['type']

# Generated at 2022-06-20 18:00:24.528706
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ''' Test function for testing parse_media_line method of class GenericBsdIfconfigNetwork'''
    # Test case for parse interface line with media line
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    modified_words = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'media:', 'Ethernet', 'autoselect', '(1000baseT <full-duplex>)'
                      ]
    current_if = dict(device='lo0', ipv4=[], ipv6=[], type='unknown', macaddress='unknown', flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], mtu='33184'
                      )

# Generated at 2022-06-20 18:00:34.246335
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    media_line = 'media: Ethernet autoselect (1000baseT <full-duplex>) status: active'
    words = media_line.split()
    x = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    x.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == ['full-duplex']
    assert current_if['status'] == 'active'

# Generated at 2022-06-20 18:00:41.127722
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = FakeModule()
    net = GenericBsdIfconfigNetwork(module)
    words = ['eth0', 'ether', 'ab:cd:ef:ab:01:23']
    current_if = {}
    ips = {}

    net.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == 'ab:cd:ef:ab:01:23'
    assert current_if['type'] == 'ether'
    assert ips == {}


# Generated at 2022-06-20 18:00:53.108242
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:01:04.496155
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible.module_utils.network.common.network import GenericBsdIfconfigNetwork
    gen_bsd_net = GenericBsdIfconfigNetwork()

    words = ['lo0:', 'flags=8049', '<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    current_if = gen_bsd_net.parse_interface_line(words)

    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    gen_bsd_net.parse_inet_line(words, current_if, ips)

    assert 'ipv4' in current_if

# Generated at 2022-06-20 18:01:32.309583
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    ifconfig_path = '/usr/bin/ifconfig'
    interface = dict(v4={}, v6={})
    interface['device'] = 'lo0'
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-20 18:01:38.141200
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    ifconfig_gen = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = "nd6 -llinfo".split()
    ifconfig_gen.parse_nd6_line(words, current_if, ips)
    assert 'ipv6' not in current_if
    assert 'options' not in current_if
    assert 'options' in current_if
    assert 'llinfo' in current_if['options']
    assert 'llinfo' in ips

# Generated at 2022-06-20 18:01:50.912239
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:02.326066
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:11.037388
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    ifconfig_module = GenericBsdIfconfigNetwork(module=None)
    current_if = {}
    ips = {}
    ifconfig_module.parse_tunnel_line(words=['tunnel', 'inet', '10.1.1.1', '-->', '10.1.1.2', 'nopmtudisc'],
                                      current_if=current_if,
                                      ips=ips)
    assert current_if['type'] == 'tunnel'


# Generated at 2022-06-20 18:02:22.268316
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])

    interfaces = []

    for line in out.splitlines():
        if re.match(r'^\S', line) and len(line.split()) > 3:
            interfaces.append(line.split()[0][0:-1])

    network = GenericBsdIfconfigNetwork()

    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)

    for iface in interfaces:
        if iface in interfaces:
            assert iface in interfaces


# Generated at 2022-06-20 18:02:28.827709
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    p = GenericBsdIfconfigNetwork()
    words = 'inet6 ::1 prefixlen 128'.split()
    current_if = {'ipv6': []}
    ips = dict(
        all_ipv6_addresses=[],
    )
    p.parse_inet6_line(words, current_if, ips)
    assert len(current_if['ipv6']) == 1
    assert len(ips['all_ipv6_addresses']) == 1


# Generated at 2022-06-20 18:02:41.667416
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    from ansible.module_utils.network.common.utils import get_module

    module = get_module(argument_spec={})
    n = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = {}
    n.parse_nd6_line(['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>', 'lladdr', 'fe80::a00:27ff:fea3:3a3d'],
                    current_if, ips)
    assert 'options' in current_if
    assert current_if['options'] == ['PERFORMNUD', 'ACCEPT_RTADV', 'AUTO_LINKLOCAL']
    assert 'lladdr' in current_if

# Generated at 2022-06-20 18:02:46.796302
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # testcases in the format of:
    # ( ( [[words], current_if, ips], expected_results ), ... )
    testcases = [
        ( ( [['nd6', "options=21<PERFORMNUD,AUTO_LINKLOCAL>"], {}, {}], {'options': 'PERFORMNUD,AUTO_LINKLOCAL'} ), ),
    ]
    for testcase in testcases:
        for test_input, expected_result in testcase:
            module = FakeModule()
            module.params['path'] = '/sbin/'
            n = GenericBsdIfconfigNetwork(module)
            result = n.parse_nd6_line(
                test_input[0],
                test_input[1],
                test_input[2]
            )
            assert result == expected_result

# Generated at 2022-06-20 18:02:52.998346
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Override the class to allow reading the private members
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __getattribute__(self, item):
            return object.__getattribute__(self, item)

    network = TestGenericBsdIfconfigNetwork()
    test = {'device': 'lo0'}
    test_line = ['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)', 'status:', 'inactive']
    network.parse_media_line(test_line, test, test)
    assert test['media'] == 'Ethernet'
    assert test['media_select'] == 'autoselect'
    assert test['media_type'] == 'full-duplex'
    assert test['media_options'] == ['100baseTX']



# Generated at 2022-06-20 18:03:12.436455
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    m = GenericBsdIfconfigNetwork()

    route_output = [
        'route: writing to routing socket: not in table',
        'add net default: gateway 192.168.0.1',
    ]

    default_ipv4, default_ipv6 = m.get_default_interfaces(route_output)

    assert default_ipv4 == {}
    assert default_ipv6 == {}


# Generated at 2022-06-20 18:03:24.803849
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():

    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    network.parse_tunnel_line(['tunnel', 'inet', '10.10.10.1',
                               '-->', '10.10.10.2', 'netmask', '0xffffffff'],
                              current_if, ips)
    assert current_if['type'] == 'tunnel'

    current_if = {}
    network.parse_tunnel_line(['tunnel', 'inet6', '2002:c0a8:801::1',
                               '-->', '2002:c0a8:802::2', 'prefixlen', '64'],
                              current_if, ips)
    assert current_if['type'] == 'tunnel'

    current_if = {}

# Generated at 2022-06-20 18:03:33.438357
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Initialize class data
    ifc_obj = GenericBsdIfconfigNetwork()

    # Test ifc_obj.get_options()
    option_string = '<LOOPBACK,RUNNING,MULTICAST>'
    expected_value = ['LOOPBACK', 'RUNNING', 'MULTICAST']
    ifc_obj.get_options(option_string)

    # Test ifc_obj.get_options()
    option_string = '<LOOPBACK,RUNNING>'
    expected_value = ['LOOPBACK', 'RUNNING']
    ifc_obj.get_options(option_string)


# Generated at 2022-06-20 18:03:38.186955
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    platform_mock = mock.Mock()
    platform_mock.platform = 'FreeBSD'
    class_under_test = GenericBsdIfconfigNetwork(platform_mock)
    assert class_under_test != None


# Generated at 2022-06-20 18:03:40.143966
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # TODO: Implement method test
    return True

# Generated at 2022-06-20 18:03:47.215098
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})

    defaults = dict(interface='em0', address='192.168.1.1')
    interfaces = dict(em0=dict(ipv4=[dict(address='192.168.1.1', netmask='255.255.255.0')]))

    default_ipv4, default_ipv6 = GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'ipv4')

    module.exit_json(changed=True, ansible_facts=dict(default_ipv4=default_ipv4))

# Generated at 2022-06-20 18:03:53.655859
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    ifconfig = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    line = 'tunnel inet 172.16.0.1 --> 172.16.0.2 netmask 0xffffffff'
    ifconfig.parse_tunnel_line(line.split(), current_if, ips)
    assert current_if['type'] == 'tunnel'



# Generated at 2022-06-20 18:04:05.324143
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_ifconfig_network = GenericBsdIfconfigNetwork()
    words = ['em1:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    current_if = generic_ifconfig_network.parse_interface_line(words)
    assert current_if['device'] == 'em1'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'
    assert current_if['mtu'] == '1500'

# Generated at 2022-06-20 18:04:12.304246
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Setup and test data
    module = AnsibleModule(argument_spec={})
    # Setup for method parse_interface_line
    words0 = ["lo0:","<LOOPBACK,UP,LOWER_UP>","mtu","33184","inet","127.0.0.1","netmask","0xff000000","inet6","::1","prefixlen","128","inet6","fe80::1%lo0","prefixlen","64","scopeid","0x1","nd6","options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>"]

# Generated at 2022-06-20 18:04:22.399497
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    gb = GenericBsdIfconfigNetwork()

    # test 1
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet6', '::1', 'prefixlen', '128']
    current_if = gb.parse_interface_line(words)
    gb.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == 'unknown'
    assert current_if['type'] == 'unknown'

    # test 2

# Generated at 2022-06-20 18:05:16.223173
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_network_instance = GenericBsdIfconfigNetwork(module=None, collected_facts=None)
    input = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    want = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    got = generic_bsd_ifconfig_network_instance.get_options(input)
    assert_equals(got, want)


# Generated at 2022-06-20 18:05:27.287843
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    myclass = GenericBsdIfconfigNetwork(None)
    interfaces = dict()
    interfaces['eth0'] = dict()
    interfaces['eth0']['type'] = 'unknown'
    interfaces['eth0']['media'] = 'Ethernet autoselect'

    interfaces['lo0'] = dict()
    interfaces['lo0']['type'] = 'unknown'
    interfaces['lo0']['media'] = 'loopback'

    interfaces_new = myclass.detect_type_media(interfaces)
    assert 'type' in interfaces_new['eth0']
    assert 'type' in interfaces_new['lo0']
    assert interfaces_new['eth0']['type'] == 'ether'
    assert interfaces_new['lo0']['type'] == 'unknown'
    assert 'Ethernet autoselect'

# Generated at 2022-06-20 18:05:40.561159
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    network = GenericBsdIfconfigNetwork()
    network.parse_tunnel_line(['tunnel', 'inet', '127.0.0.1', '-->', '127.0.0.2', 'netmask', '0xffffffff'],
                              dict(device='tun0'), dict(all_ipv4_addresses=[], all_ipv6_addresses=[]))
    assert network.interfaces['tun0']['type'] == 'tunnel'
    assert network.ips['all_ipv4_addresses'] == ['127.0.0.1']
    assert network.ips['all_ipv6_addresses'] == []
    assert network.interfaces['tun0']['ipv4'][0]['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:05:53.115887
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # Tested with the following netstat output:
    #   netstat -rn | grep -E '^fuget0\b|^default\b'
    #
    # fuget0:
    #   Destination        Gateway            Flags     Netif Expire
    #   default            10.0.2.2           UGS         fuget0
    #
    #
    # fuget1:
    #   Destination        Gateway            Flags     Netif Expire
    #   default            10.0.3.2           UGS         fuget1
    #

    iface = GenericBsdIfconfigNetwork('fuget0')


# Generated at 2022-06-20 18:06:02.982593
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.modules.network.generic_bsd import GenericBsdIfconfigNetwork
    test_object = GenericBsdIfconfigNetwork(object(), {}, False)
    test_data = {
        'lo0': {'media': 'Ethernet autoselect'},
        'gif0': {'media': 'IEEE 802.3 Subtype Autoselect'},
        'en0': {'media': 'Ethernet autoselect'}
    }
    test_object.detect_type_media(test_data)
    assert test_data['lo0'] == {'media': 'Ethernet autoselect', 'type': 'loopback'}
    assert 'type' not in test_data['gif0']

# Generated at 2022-06-20 18:06:14.923182
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Test with a case where there is a status line
    # Test case where words = ['status:', 'active']
    # This test case should set the current_if['status'] to 'active'
    words = ['status:', 'active']

# Generated at 2022-06-20 18:06:23.519406
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gb = GenericBsdIfconfigNetwork()
    default_ipv4 = dict()
    default_ipv4['interface'] = 'lo0'
    default_ipv4['address'] = '127.0.0.1'

    default_ipv6 = dict()
    default_ipv6['interface'] = 'lo0'
    default_ipv6['address'] = '::1'

    interfaces = dict()
    interfaces['lo0'] = dict()
    interfaces['lo0']['ipv4'] = [{'address': '127.0.0.1', 'broadcast': '0.0.0.0', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}]

# Generated at 2022-06-20 18:06:32.050372
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Make a mock ifconfig output
    test_str = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    groups: lo
    """
    p = GenericBsdIfconfigNetwork()
    test_data = p.get_interfaces_info(None, test_str)[0]
    assert 'options' in test_data['lo0'], 'didn\'t parse options from nd6 line'


# Generated at 2022-06-20 18:06:39.045746
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    #mock the current interface and ip info
    current_if = {
        'device': 'lo0',
        'macaddress': '2e:0:0:0:0:0',
        'ipv4': [{
            'address': '127.0.0.1'
        }],
        'ipv6': [{
            'address': '::1'
        }],
        'type': 'ether',
        'status': 'active'
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': []
    }
    #the following test will assert if the lladdr line is parsed correctly
    line = ['lladdr', '2e:0:0:0:0:0']
    mock_obj = GenericBsdIfconfig

# Generated at 2022-06-20 18:06:42.354706
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    obj = GenericBsdIfconfigNetwork()
    words = 'three words'.split()
    current_if = dict()
    ips = dict()
    obj.parse_unknown_line(words, current_if, ips)



# Generated at 2022-06-20 18:07:40.734426
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule({
        'ANSIBLE_MODULE_ARGS': {},
    })
    parser = GenericBsdIfconfigNetwork(module)
    interface_info = {}
    ips = {}
    lladdr_line = ['lladdr', 'ab:ab']
    parser.parse_lladdr_line(lladdr_line, interface_info, ips)
    assert interface_info['lladdr'] == 'ab:ab'


# Generated at 2022-06-20 18:07:51.069982
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # check if parent class is GenericBsdIfconfigNetwork
    from ansible_collections.misc.not_a_real_collection.plugins.modules.network.base import NetworkCollector

    module = Mock(spec=NetworkCollector, name='NetworkCollector')
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.side_effect = lambda _: None

    facter_network = GenericBsdIfconfigNetwork(module)

    assert facter_network.populate() == dict(
        default_ipv4={},
        default_ipv6={},
        interfaces=[],
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    ifconfig_path = '/sbin/ifconfig'
    module.get_bin

# Generated at 2022-06-20 18:07:58.784979
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gbin = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['tunnel', 'inet']
    gbin.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-20 18:08:11.363124
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'TestDevice1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = ['options=2d,route']
    network.parse_options_line(words, current_if, ips)
    assert current_if == {'device': 'TestDevice1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'options': ['2d', 'route']}

# Generated at 2022-06-20 18:08:23.265719
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # create a subclass of GenericBsdIfconfigNetwork to run test on.
    class for_test_class(GenericBsdIfconfigNetwork):
        # since we are unit testing, we don't want to depend on the platform
        # we are running on.  So, hard the platform.
        platform = 'Darwin'
    # create a subclass of the module class so we can call it's run_command method
    class for_test_module(Module):
        def run_command(self, command):
            return [0, "lladdr e8:11:32:81:2a:8c", ""]
    # create a subclass of tmp to use its run_command

# Generated at 2022-06-20 18:08:33.641890
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Set up test object
    module = AnsibleModule(argument_spec={})
    ad = GenericBsdIfconfigNetwork(module)

    # Test cases

# Generated at 2022-06-20 18:08:41.865854
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    import platform
    result = GenericBsdIfconfigNetwork(module).get_interfaces_info(ifconfig_path, ifconfig_options=ifconfig_options)

# Generated at 2022-06-20 18:08:53.689654
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = GenericBsdIfconfigNetwork()

    interface_name = "en0"
    interface = {'device': interface_name, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    known_options = ("LLINFO", "AUTOCONF", "DAD", "NUD", "IFDISABLED")
    for options in (known_options, "LLINFO,AUTOCONF,DAD,NUD,IFDISABLED"):
        words = ["options=%s" % options]
        m.parse_options_line(words, interface, ips)
        assert interface['options'] == known_options


# Generated at 2022-06-20 18:08:59.036689
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    def GenericBsdIfconfigNetwork_get_default_interfaces(route_path):
        return route_path

    assert GenericBsdIfconfigNetwork_get_default_interfaces(route_path='route') == 'route'


# Generated at 2022-06-20 18:09:07.649209
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    #
    # This is a unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
    #
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

    module = AnsibleModule(argument_spec=dict())

    if ifconfig_path is None:
        return {}

    route_path = module.get_bin_path('route')

    if route_path is None:
        return {}

    default_ipv4, default_ipv6 = GenericBsdIfconfigNetwork().get_default_interfaces(route_path)
    interfaces, ips = GenericBsdIfconfigNetwork().get_interfaces_info(ifconfig_path)
    interfaces = GenericBsdIfconfigNetwork().detect_type_media(interfaces)
