

# Generated at 2022-06-20 17:59:34.178846
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    obj = GenericBsdIfconfigNetwork()
    assert obj.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 17:59:47.225354
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 17:59:56.438975
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    # Unit test for get_interfaces_info to have proper fields
    n = GenericBsdIfconfigNetwork()
    interfaces, ips = n.get_interfaces_info(None)
    for name in interfaces.keys():
        fields = interfaces[name]
        assert 'device' in fields
        assert 'ipv4' in fields and isinstance(fields['ipv4'], list)
        assert 'ipv6' in fields and isinstance(fields['ipv6'], list)
        assert 'type' in fields
        assert 'macaddress' in fields
        assert 'mtu' in fields
        assert 'metric' in fields



# Generated at 2022-06-20 17:59:57.853080
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    pass # TODO: implement your test here

# Generated at 2022-06-20 18:00:10.631697
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.params = {}
    Mn = GenericBsdIfconfigNetwork(module)
    words = ['status', 'LINK-UP']
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    Mn.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'LINK-UP'



# Generated at 2022-06-20 18:00:20.252334
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    lladdr_values = {
        '00:17:F2:15:5D:B9': '00:17:F2:15:5D:B9',
        '00:17:f2:15:5d:b9': '00:17:F2:15:5D:B9'
    }
    for test_line, expected in lladdr_values.items():
        current_if = {}
        ips = {
            'all_ipv4_addresses': [],
            'all_ipv6_addresses': [],
        }
        line = ['lladdr', test_line]
        module = NetworkModule(argument_spec={})
        module.ifconfig_path = ''
        network_module = GenericBsdIfconfigNetwork(module)
        network_module.parse_lladdr_line

# Generated at 2022-06-20 18:00:27.635731
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module_args = dict()
    module_args['path'] = dict()
    module_args['path']['route'] = 'route'
    module = get_module(module_args=module_args)

    network = GenericBsdIfconfigNetwork(module)

    interface = network.get_default_interfaces('route')
    assert interface == ({}, {})
    return


# Generated at 2022-06-20 18:00:40.761889
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # test expected output for this input
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    generic_bsd_ifconfig_network_class = GenericBsdIfconfigNetwork(module)

    line = "nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>"
    words = line.split()
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network_class.parse_nd6_line(words, current_if, ips)

    assert isinstance(current_if['options'], list), "should be a list"
    assert len(current_if['options']) == 3, "should have 3 items in list"


# Generated at 2022-06-20 18:00:49.158163
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():

    platform = 'Generic_BSD_Ifconfig'
    module = AnsibleModule({})

    action = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0'}
    ips = {}
    words = ['status:', 'active']

    action.parse_status_line(words, current_if, ips)

    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:01:00.236870
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    nf = GenericBsdIfconfigNetwork()

    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'mtu': '32768'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    nf.parse_status_line(['status:', 'active'], current_if, ips)
    assert current_if['status'] == 'active'

# Generated at 2022-06-20 18:01:40.425991
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    words = 'media: Ethernet autoselect (1000baseT <full-duplex>)'.split()

    interfaces = {}
    current_if = {'device': 'bge0', 'ipv4':[], 'ipv6':[]}
    interfaces[current_if['device']] = current_if
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # call method
    GenericBsdIfconfigNetwork.parse_media_line(None, words, current_if, ips)

    # test the result
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert 'media_options' in current_if


# Generated at 2022-06-20 18:01:47.269947
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    net_class  = GenericBsdIfconfigNetwork()
    tests = [
        ("<UP,BROADCAST,LOOPBACK,RUNNING>", ["UP", "BROADCAST", "LOOPBACK", "RUNNING"]),
        ("<UP,BROADCAST,LOOPBACK,RUNNING" , []),
        ("UP,BROADCAST,LOOPBACK,RUNNING>", []),
        ("<UP,BROADCAST,LOOPBACK,RUNNING", ["UP", "BROADCAST", "LOOPBACK", "RUNNING"]),
        ("UP,BROADCAST,LOOPBACK,RUNNING", []),
        ("UP,BROADCAST,LOOPBACK,RUNNING" , []),
    ]

# Generated at 2022-06-20 18:02:00.425411
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """Test detect_type_media of class GenericBsdIfconfigNetwork"""
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:02:13.697120
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    os_version_result = {'raw_version': 'FreeBSD 11.2-RELEASE-p10',
                         'raw_distro': 'freebsd',
                         'raw_major_version': '11',
                         'raw_minor_version': '2',
                         'raw_patch_version': '10',
                         'raw_build_version': 'RELEASE-p10',
                         'distro': 'FreeBSD',
                         'major_version': '11',
                         'minor_version': '2',
                         'patch_version': '10',
                         'build_version': 'RELEASE-p10'}


# Generated at 2022-06-20 18:02:17.074789
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    obj = GenericBsdIfconfigNetwork(None)

    words = ['', '', '']
    current_if = {}
    ips = {}
    obj.parse_unknown_line(words, current_if, ips)



# Generated at 2022-06-20 18:02:28.623827
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    test_obj = GenericBsdIfconfigNetwork()
    tests = [
        ('<UP,BROADCAST>', ['UP', 'BROADCAST']),
        ('<UP,LOOPBACK>', ['UP', 'LOOPBACK']),
        ('<>', []),
        ('<UP,LOOPBACK,RUNNING,MULTICAST>', ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']),
    ]
    for test in tests:
        option_string, expected = test
        actual = test_obj.get_options(option_string)
        if actual != expected:
            print(
                """
                option_string: {}
                expected: {}
                actual: {}
                """.format(option_string, expected, actual)
            )
            assert actual == expected

# Unit test

# Generated at 2022-06-20 18:02:37.982240
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    print('Test GenericBsdIfconfigNetwork.parse_unknown_line')
    test_module = module_factory()
    net = GenericBsdIfconfigNetwork(test_module)
    ifaces = {}
    words = []
    net.parse_unknown_line(words, ifaces, {})
    assert ifaces == {}
    words = ['word_one']
    net.parse_unknown_line(words, ifaces, {})
    assert ifaces == {}


# Generated at 2022-06-20 18:02:48.114585
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    set_module_args(dict(
        gather_subset=['!all', '!min']
    ))
    current_if = {}
    ips = {}
    words = ["status:", "active"]
    obj = GenericBsdIfconfigNetwork(module=AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    ))
    obj.parse_status_line(words, current_if, ips)
    assert current_if['status'] == "active"


# Generated at 2022-06-20 18:02:50.588689
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    net = GenericBsdIfconfigNetwork()
    current_if = {}
    words = ['word1', 'word2', 'word3']
    net.parse_unknown_line(words, current_if, ips={})


# Generated at 2022-06-20 18:02:59.267354
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    iface_info = {}
    ifconfig_path = "ifconfig_path"
    test_net = GenericBsdIfconfigNetwork(None, ifconfig_path, None, None)

    test_net.parse_status_line(["status:","active"], iface_info, {})
    assert iface_info == {'status': 'active'}


# Generated at 2022-06-20 18:03:26.992211
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:03:33.937737
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Example from NetBSD 8.1 ifconfig -a
    ifconfig_out = """\
lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 33184
        options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x3
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
ws:/home/root #
"""
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

# Generated at 2022-06-20 18:03:45.572703
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    # Expected results

# Generated at 2022-06-20 18:03:55.779401
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Create the object
    oModule = GenericBsdIfconfigNetwork()


# Generated at 2022-06-20 18:04:06.845980
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Setup
    from ansible.module_utils.network import network_info
    ifconfig_path = network_info.get_bin_path('ifconfig')
    rc, out, err = network_info.module.run_command([ifconfig_path, '-a'])
    if_line = out.splitlines()[0]
    words = if_line.split()
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Execute


# Generated at 2022-06-20 18:04:19.217625
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    bsd_ifconfig = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    ips = dict(all_ipv6_addresses=[])
    # case of inet6 line with parameter scope and cidr style address
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'mtu', '16384']
    expected = {'address': 'fe80::1%lo0', 'prefix': '64', 'scope': '0x1'}
    bsd_ifconfig.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0] == expected
    # case of inet6 line

# Generated at 2022-06-20 18:04:25.002407
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    m = GenericBsdIfconfigNetwork(dict(module=None))
    current_if = dict()
    ips = dict()
    words = ['status:','active']
    m.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active'


# Generated at 2022-06-20 18:04:30.883151
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    m = GenericBsdIfconfigNetwork()
    i = {'device': 'lo0', 'type': 'loopback'}
    m.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384'])



# Generated at 2022-06-20 18:04:39.122597
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    m = GenericBsdIfconfigNetwork()
    defaults = dict(address='172.20.2.11', interface='bridge0')
    interfaces = dict(bridge0=dict(ipv4=[dict(address='172.20.2.11', netmask='255.255.255.0',
                                              broadcast='172.20.2.255', network='172.20.2.0')],
                                   type='ether', macaddress='00:11:22:33:44:55',
                                   ipv6=[],
                                   flags=['BROADCAST', 'SIMPLEX', 'MULTICAST']))
    m.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-20 18:04:42.731620
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
  assert GenericBsdIfconfigNetwork.parse_nd6_line('', ['nd6', 'options=1<PERFORMNUD,DAD>,2<IGNORE_HOME_ADDRESS>'], None, None)


# Generated at 2022-06-20 18:06:04.088611
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:06:13.443054
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    words = ['inet6', 'fe80::cad3:e2ff:feab:646', 'prefixlen', '64', 'scopeid', '0x1', 'inet6', '2001:470:ff::12']
    current_if = {}
    ips = {}
    test = GenericBsdIfconfigNetwork()
    test.parse_inet6_line(words, current_if, ips)
    assert ips['all_ipv6_addresses'] == ['fe80::cad3:e2ff:feab:646', '2001:470:ff::12']

    words = ['inet6', 'fe80::cad3:e2ff:feab:646%re0', 'prefixlen', '64', 'scopeid', '0x2', 'inet6', '2001:470:ff::12']
    current

# Generated at 2022-06-20 18:06:23.856662
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Given
    words = ['lladdr', '6a:76:9f:82:eb:69']
    current_if = {}
    ips = {}
    # When
    GenericBsdIfconfigNetwork.parse_lladdr_line(GenericBsdIfconfigNetwork(), words, current_if, ips)
    # Then
    assert current_if == {'lladdr': '6a:76:9f:82:eb:69'}
    assert ips == {}


# Generated at 2022-06-20 18:06:28.585782
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    """Parse line we do not understand.
    """

    module = _common.AnsibleModuleMock({})
    bsd_network_cls = GenericBsdIfconfigNetwork(module)
    interfaces = {}
    cur_if = {}
    ips = {}
    bsd_network_cls.parse_unknown_line([], cur_if, ips)


# Generated at 2022-06-20 18:06:36.990703
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = DummyAnsibleModule()
    platform = GenericBsdIfconfigNetwork(module)

    # test case1:
    current_if = {}
    ips = {}
    words = ["media:", "Ethernet", "autoselect", "FOO"]
    platform.parse_media_line(words, current_if, ips)
    assert current_if['media'] == "Ethernet"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "FOO"

    # test case2:
    current_if = {}
    ips = {}
    words = ["media:", "Ethernet", "autoselect", "", "100baseTX"]
    platform.parse_media_line(words, current_if, ips)

# Generated at 2022-06-20 18:06:46.607782
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ipv6_line = 'lladdr fe80:0:0:0:c9e9:a067:7f84:8c0f%wlan0'
    words = ipv6_line.split()
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    ifconfig = GenericBsdIfconfigNetwork(module)
    ifconfig.parse_lladdr_line(words, current_if, ips)
    assert words[0] == 'lladdr'
    assert current_if['lladdr'] == words[1]



# Generated at 2022-06-20 18:06:59.592963
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    from ansible.module_utils.facts import Network
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as gn
    import sys

    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = ['media:', 'Ethernet autoselect', '(100baseTX full-duplex,100Mbps)']
    gn.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet autoselect'

# Generated at 2022-06-20 18:07:10.918004
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModuleMock()
    ifconfig = GenericBsdIfconfigNetwork()

    words = ['tunnel','inet','10.100.100.100','-->','10.100.100.1','prefixlen','16']
    current_if = {'ipv4': []}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    ifconfig.parse_tunnel_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '10.100.100.100'
    assert current_if['ipv4'][0]['prefix'] == '16'

# Generated at 2022-06-20 18:07:17.475120
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork({'module': MagicMock()})
    interfaces = {'ge0': {'media': 'Ethernet autoselect (100baseTX <full-duplex>)'}}
    interfaces = network.detect_type_media(interfaces)
    assert_equals(interfaces, {'ge0': {'media': 'Ethernet autoselect (100baseTX <full-duplex>)', 'type': 'ether'}})



# Generated at 2022-06-20 18:07:27.882654
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    cmd = GenericBsdIfconfigNetwork()
    words = ("lo0", "ether", "00:00:00:00:00:00")
    current_if = dict(device='lo0', ipv4=[], ipv6=[], type='unknown')
    cmd.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == words[2]
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:08:43.412851
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    obj = GenericBsdIfconfigNetwork()

    # Test with the interface <UP,BROADCAST,LOOPBACK,RUNNING>
    option_string = '<UP,BROADCAST,LOOPBACK,RUNNING>'
    expected_result = ['UP','BROADCAST','LOOPBACK','RUNNING']
    assert obj.get_options(option_string) == expected_result

    # Test with string with no options
    option_string = 'No options'
    expected_result = []
    assert obj.get_options(option_string) == expected_result

# Generated at 2022-06-20 18:08:54.083517
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    # Test -> address and netmask are both dotted quad
    # Params  -> "inet 10.10.10.5 netmask 0xffffff00 broadcast 10.10.10.255"
    # Expect -> {"address": "10.10.10.5, "netmask": "255.255.255.0", "network": "10.10.10.0", "broadcast": "10.10.10.255"}
    if_cfg_net = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:09:01.524158
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """Unit test method defined above in class GenericBsdIfconfigNetwork"""
    gbin = GenericBsdIfconfigNetwork()
    route_path = '/sbin/route'
    assert gbin.get_default_interfaces(route_path) == ({'interface': 'lo0'}, {'interface': 'lo0'})