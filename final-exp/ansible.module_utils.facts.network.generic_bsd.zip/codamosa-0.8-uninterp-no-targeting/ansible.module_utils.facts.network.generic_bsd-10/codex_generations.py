

# Generated at 2022-06-20 17:59:55.600733
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork"""
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()

    # invoke the function with the test arguments

# Generated at 2022-06-20 18:00:10.226251
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    def check_test_data(test_data, expected):
        result = GenericBsdIfconfigNetwork.get_options(test_data)
        assert result == expected


# Generated at 2022-06-20 18:00:15.902420
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Method tested
    platform = 'Generic_BSD_Ifconfig'
    module = GenericBsdIfconfigNetwork
    method = 'get_interfaces_info'

    # Test variables and data
    input_data = {'platform': platform, 'method': method}
    input_data['data'] = dict(
        ifconfig_path="echo",
        ifconfig_options='-a'
    )
    testcase1 = dict(
        input=None,
        expected=None
    )
    testcase2 = dict(
        input=None,
        expected=None
    )
    testcase3 = dict(
        input=None,
        expected=None
    )

    # Unit under test
    uut = module(module=module)

    # Run and test

# Generated at 2022-06-20 18:00:21.783492
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # arrange
    ifconfig_mock = GenericBsdIfconfigNetwork(None)
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['options=1', 'e01a205d', '0a01200']

    # act
    ifconfig_mock.parse_options_line(words, current_if, ips)

    # assert
    assert current_if['options'] == ['1', 'e01a205d', '0a01200']


# Generated at 2022-06-20 18:00:29.850557
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Setup test class
    network = GenericBsdIfconfigNetwork()
    network.module = module

    test_object = network

    # Setup mocks
    current_if = {}
    ips = {}

    # Test
    test_words = ['ether', '00:11:22:33:44:55']
    test_object.parse_ether_line(test_words, current_if, ips)

    # Verify results
    assert 'type' in current_if
    assert current_if['type'] == 'ether'
    assert 'macaddress' in current_if

# Generated at 2022-06-20 18:00:42.351294
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    net = GenericBsdIfconfigNetwork({}, {'run_command': run_command})
    net.platform = 'FreeBSD'
    net.populate()
    # test nd6 line
    current_if = {}
    ips = {}
    # test for FreeBSD
    words = ['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>',
             'media:', 'Ethernet', '10Gbase-T',
             '<full-duplex>', 'status:', 'active']
    net.parse_nd6_line(words, current_if, ips)
    assert 'PERFORMNUD' in current_if['options']
    assert 'ACCEPT_RTADV' in current_if['options']

# Generated at 2022-06-20 18:00:53.057497
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec={})

    # create a class like object
    class ClassLikeObject:
        def __init__(self):
            pass

    class_like_object = ClassLikeObject()
    class_like_object.module = module

    n = GenericBsdIfconfigNetwork()
    n.module = module

    option_strings = ['foo', 'foo<MULTICAST,POINTOPOINT,NOARP,UP,LOWER_UP>', 'bar<>', 'baz<UP>']
    for option_string in option_strings:
        result = n.get_options(option_string)
        if option_string == 'foo':
            assert result == []

# Generated at 2022-06-20 18:01:04.465083
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:01:14.650243
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Test for no words
    collected_facts = dict()
    iface = dict()
    ips = dict()
    words = list()
    instance = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork(collected_facts)
    instance.parse_lladdr_line(words, iface, ips)
    assert iface == dict()
    assert ips == dict()
    # Test for no lladdr word
    collected_facts = dict()
    iface = dict()
    ips = dict()
    words = list()
    words.append('word1')
    instance = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork(collected_facts)
    instance.parse_lladdr_line(words, iface, ips)
    assert iface == dict()
    assert ips == dict()
    #

# Generated at 2022-06-20 18:01:25.509458
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    """
    Test function for parse_ether_line function of class GenericBsdIfconfigNetwork
    :input parameters:
       words: A list of following format,
           [
            'ether',
            'b8:27:eb:73:3b:3e',
            'media:',
            'Ethernet',
            'autoselect'
           ]
    :return: None
    """
    # Test case for valid input parameter accepts valid input for argument words
    interface = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-20 18:01:47.387658
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():

    class ModuleStub:

        def __init__(self):
            pass

        def get_bin_path(self, path):
            return '/path/to/bin'

        def run_command(self, args):
            return (0, "", "")

    module = ModuleStub()

    network = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network.parse_nd6_line(['nd6', 'options=1<PERFORMNUD>'], current_if, ips)

    assert current_if == dict(options=['1', 'PERFORMNUD'])


# Generated at 2022-06-20 18:02:00.462792
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # set up test fixtures
    defaults = {'interface': 'vlan1',
                'address': '10.0.0.1'
                }
    interfaces = {
        'xl0': {'ipv4': [{'address': '10.0.0.2'}]},
        'vlan1': {'ipv4': [{'address': '10.0.0.1'}]}
    }
    ip_type = 'ipv4'
    # run the method under test
    network_facts_module = network_facts.GenericBsdIfconfigNetwork()
    network_facts_module.merge_default_interface(defaults, interfaces, ip_type)

    # assert the expected results
    assert defaults['address'] == '10.0.0.1'



# Generated at 2022-06-20 18:02:13.695461
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    print ("Unit test for method detect_type_media of class GenericBsdIfconfigNetwork")
    interfaces = {'vlan_bridge0': {'device': 'vlan_bridge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}, 'bridge0': {'device': 'bridge0', 'ipv4': [], 'ipv6': [], 'type': 'ether'}, 'tap': {'device': 'tap', 'ipv4': [{'address': '192.168.1.5', 'netmask': '255.255.255.0', 'network': '192.168.1.0', 'broadcast': '192.168.1.255'}], 'ipv6': [], 'type': 'unknown'}}
    network_facts = GenericBsdIfconfigNetwork()
    network_facts

# Generated at 2022-06-20 18:02:23.863099
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec=dict()
    )
    bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    current_if['device'] = 'bge0'
    ips = {}
    words = ['ether', '00:a0:98:8b:7e:f0']
    bsd_ifconfig_network.parse_ether_line(words, current_if, ips)
    assert current_if['type'] == 'ether'
    assert current_if['macaddress'] == '00:a0:98:8b:7e:f0'


# Generated at 2022-06-20 18:02:29.469119
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Setup
    options_string = '<LOOPBACK,RUNNING,MULTICAST>'
    # Exercise
    options = GenericBsdIfconfigNetwork.get_options(options_string)
    # Verify
    assert options == ['LOOPBACK', 'RUNNING', 'MULTICAST']


# Generated at 2022-06-20 18:02:37.982341
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['status:', 'active']
    obj = GenericBsdIfconfigNetwork()
    obj.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:02:45.566204
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    def_ipv4 = dict(interface='lo0', address='127.0.0.1', netmask='255.0.0.0')
    iflist = dict(lo0=dict(device='lo0', ipv4=[], ipv6=[]))
    GenericBsdIfconfigNetwork.merge_default_interface(def_ipv4, iflist, 'ipv4')
    assert def_ipv4['device'] == 'lo0'
    def_ipv4 = dict(interface='lo0', address='127.0.0.1', netmask='255.0.0.0')
    iflist = dict(lo0=dict(device='lo0', ipv4=[], ipv6=[]))

# Generated at 2022-06-20 18:02:53.305807
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec=
        dict(
        )
    )
    current_if = {'lladdr': 'test', 'foo': 'bar'}
    ips = {}
    expected_current_if = {'lladdr': 'test', 'foo': 'bar'}
    assert expected_current_if == current_if
    expected_ips = {}
    assert expected_ips == ips
    ansible_network_facts = AnsibleNetworkFacts(module=module)
    ansible_network_facts.populate()
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module=module)
    generic_bsd_ifconfig_network.parse_lladdr_line(['lladdr', 'test'], current_if, ips)
    assert expected_current_if == current_if

# Generated at 2022-06-20 18:02:57.710367
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifconfig_facts = GenericBsdIfconfigNetwork()
    defaults = {'interface':'lo0'}
    interfaces = {'lo0':{'ipv4':[{'address':'127.0.0.1'}], 'ipv6':[{'address':'2001:abc:abc:abc:abc:abc:abc:abc'}]}}
    ifconfig_facts.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['address'] == '127.0.0.1'
    ifconfig_facts.merge_default_interface(defaults, interfaces, 'ipv6')
    assert defaults['address'] == '2001:abc:abc:abc:abc:abc:abc:abc'

# Generated at 2022-06-20 18:03:03.349088
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {
        'pf': {'macaddress': 'unknown', 'type': 'unknown'},
        'lo0': {'macaddress': 'unknown', 'type': 'loopback'}
    }
    assert GenericBsdIfconfigNetwork.detect_type_media(interfaces) == {
        'pf': {'macaddress': 'unknown', 'type': 'ether'},
        'lo0': {'macaddress': 'unknown', 'type': 'loopback'}
    }



# Generated at 2022-06-20 18:03:43.745430
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    g = GenericBsdIfconfigNetwork()

    assert [] == g.get_options('OPTIONS')
    assert ['LOWPAN'] == g.get_options('OPTIONS=LOWPAN')
    assert ['UP'] == g.get_options('OPTIONS=<UP>')
    assert ['UP', 'BROADCAST'] == g.get_options('OPTIONS=<UP,BROADCAST>')
    assert [] == g.get_options('OPTIONS=<UP,BROADCAST')
    assert [] == g.get_options('OPTIONS=<UP,BROADCAST>OPTIONS')



# Generated at 2022-06-20 18:03:54.425101
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.common import NetworkFactsCommon
    import collections

    test_data = collections.namedtuple('test_data', ['line', 'expected_macaddress', 'expected_type'])
    test_data_list = [
        test_data(line=['ether', '00:00:00:00:00:00'], expected_macaddress='00:00:00:00:00:00', expected_type='ether'),
        test_data(line=['ether', '00-00-00-00-00-00'], expected_macaddress='00-00-00-00-00-00', expected_type='ether'),
    ]

    network_facts_common = NetworkFactsCommon

# Generated at 2022-06-20 18:04:06.108323
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    tmp = GenericBsdIfconfigNetwork()

    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = 'options=49bffff<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6>'
    words = words.split()
    tmp.parse_options_line(words, current_if, ips)

# Generated at 2022-06-20 18:04:14.709871
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = mock.MagicMock()
    plugin = GenericBsdIfconfigNetwork(module=module)

    current_if = {}
    ips = {}

    # testing basic mac address parsing
    line = ['lladdr', '11:22:33:44:55:66']
    plugin.parse_lladdr_line(line, current_if, ips)
    assert(current_if['lladdr'] == '11:22:33:44:55:66')



# Generated at 2022-06-20 18:04:21.884494
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    ifc = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    ifc.parse_options_line(['options=8c02<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>'], current_if, ips)
    assert True is True
    return True
test_GenericBsdIfconfigNetwork_parse_options_line()


# Generated at 2022-06-20 18:04:32.348129
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    module = MagicMock(run_command=lambda args: (0, '', ''), get_bin_path=lambda cmd: cmd)
    with patch('os.path.exists', return_value=True), patch('os.access', return_value=True), patch('builtins.open', mock_open(read_data='')):
        net = GenericBsdIfconfigNetwork(module)
        assert 'interface em0 flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n' in net.get_interfaces_info(ifconfig_path, ifconfig_options='-a')[1]


# Generated at 2022-06-20 18:04:39.091462
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    intermediate_result = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    platform_module = GenericBsdIfconfigNetwork()
    platform_module.module = intermediate_result

    test_interfaces = {
        'en0': {},
        'en1': {
            'media': 'Ethernet autoselect (none)',
            'type': 'unknown'
        },
    }

    result = platform_module.detect_type_media(test_interfaces)

    assert result['en0']['type'] == 'unknown'
    assert result['en1']['type'] == 'ether'


# Generated at 2022-06-20 18:04:51.127311
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec = dict()
    )
    words = ["bridge0:", "flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500", "ether", "88:15:44:ab:b9:9d", "nwid", "proxyclientname", "media:", "Ethernet", "preferred", "state", "up", "inet", "10.1.1.1", "netmask", "0xffffff00", "broadcast", "10.1.1.255", "nd6", "options=1<PERFORMNUD>"]
    current_if = {'device': 'bridge0'}

# Generated at 2022-06-20 18:05:03.467414
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # Mac has options like this...
    module = FakeAnsibleModule()
    test_object = GenericBsdIfconfigNetwork(module)
    words = ["options=16b4<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,VLAN_HWTSO,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6>",
             "inet6", "fe80::225:90ff:fef4:e4a3%en0", "prefixlen",
             "64", "scopeid", "0x5", "nd6", "options=1<PERFORMNUD>"]


# Generated at 2022-06-20 18:05:10.953620
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = MagicMock(name='module')
    module.run_command.return_value = (0, '', '')
    platform = GenericBsdIfconfigNetwork(module)
    current_if = {'ipv6': []}
    ips = dict(all_ipv6_addresses=[])
    words = ['inet6', '2001:0db8:85a3:0000:0000:8a2e:0370:7334', 'prefixlen', '64', 'scopeid', '0x8', '0x0', '0:0:1b:1']
    platform.parse_inet6_line(words, current_if, ips)


# Generated at 2022-06-20 18:06:13.222579
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    words = 'options=20000000<LOOPBACK,LINK1,MULTICAST>'.split()
    netmask = None
    ips = {}
    network.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['20000000', 'LOOPBACK', 'LINK1', 'MULTICAST']



# Generated at 2022-06-20 18:06:16.897678
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    gbn = GenericBsdIfconfigNetwork()

    current_if = {'device': 'test_tap0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = []

    gbn.parse_unknown_line(words, current_if, ips)

    assert('unknown' == current_if['type'])


# Generated at 2022-06-20 18:06:26.437126
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    gbin = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    gbin.parse_options_line(['options=2f00<BRIDGE,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM,VLAN_HWFILTER>', 'metric:1'],
                            current_if, ips)
    assert current_if['options'] == ['BRIDGE', 'VLAN_MTU', 'VLAN_HWTAGGING', 'VLAN_HWCSUM', 'VLAN_HWFILTER']

# Generated at 2022-06-20 18:06:29.749765
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    net = GenericBsdIfconfigNetwork(dict(module='test'))
    assert net.module == 'test'
    assert net.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:06:37.655304
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    net = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}
    net.parse_inet6_line(['inet6', 'fe80::250:56ff:fe88:c2a9%em0', 'prefixlen', '64', 'scopeid', '0x1'], iface, ips)
    assert iface['ipv6'][0]['address'] == 'fe80::250:56ff:fe88:c2a9'
    assert iface['ipv6'][0]['prefix'] == '64'
    assert iface['ipv6'][0]['scope'] == '0x1'
    assert ips['all_ipv6_addresses'][0] == 'fe80::250:56ff:fe88:c2a9'

# Generated at 2022-06-20 18:06:45.459092
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    assert network.get_options('foo') == []
    assert network.get_options('foo<>') == []
    assert network.get_options('foo<BAR,') == ['BAR']
    assert network.get_options('foo<BAR,BAZ>') == ['BAR', 'BAZ']
    assert network.get_options('foo<bar,BAR,BAZ>') == ['bar', 'BAR', 'BAZ']



# Generated at 2022-06-20 18:06:58.992353
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    platform_mock = mock.MagicMock()
    platform_mock.system.return_value = 'Generic_BSD_Ifconfig'
    module_mock = mock.MagicMock(platform=platform_mock)
    module_mock.get_bin_path.return_value = '/bin/ifconfig'

# Generated at 2022-06-20 18:07:11.542548
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    '''Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork'''
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    genericbsdifconfignetwork = GenericBsdIfconfigNetwork()
    # parameters for function parse_interface_line
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    # run func and test
    results = genericbsdifconfignetwork.parse_interface_line(words)
    assert results['device'] == 'lo0'
    assert results['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert results['macaddress'] == 'unknown'
   

# Generated at 2022-06-20 18:07:21.381204
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    network_facts = GenericBsdIfconfigNetwork(None)

    line = 'ether 10:bf:48:a3:38:68'

    iface = {}

    ips = {}

    network_facts.parse_ether_line(line.split(), iface, ips)

    assert iface['macaddress'] == '10:bf:48:a3:38:68'
    assert iface['type'] == 'ether'

    line = 'ether   10:bf:48:a3:38:68'

    iface = {}

    ips = {}

    network_facts.parse_ether_line(line.split(), iface, ips)

    assert iface['macaddress'] == '10:bf:48:a3:38:68'
    assert iface['type'] == 'ether'


# Generated at 2022-06-20 18:07:30.543305
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Set up
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network = GenericBsdIfconfigNetwork(module)
    # Test
    current_if = {}
    ips = {}
    words = ['lladdr', 'a0:b1:c2:d3:e4:f5', 'duplex', '1000', 'port']
    network.parse_lladdr_line(words, current_if, ips)
    # Verify
    assert current_if == {'lladdr': 'a0:b1:c2:d3:e4:f5'}

