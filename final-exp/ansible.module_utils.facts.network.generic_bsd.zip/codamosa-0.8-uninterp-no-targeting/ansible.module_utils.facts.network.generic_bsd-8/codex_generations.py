

# Generated at 2022-06-20 17:59:51.535465
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    gbin = GenericBsdIfconfigNetwork()
    rc, out, err = gbin.module.run_command('echo "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 33184\ninet 127.0.0.1 netmask 0xff000000\ninet alias 127.1.1.1 netmask 0xff000000\nnd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>"')
    interfaces, ips = gbin.get_interfaces_info('ifconfig')
    assert interfaces['lo0']['ipv4'][1]['netmask'] == '255.255.255.255'
    assert interfaces['lo0']['ipv4'][1]['broadcast'] == '127.255.255.255'

# Unit test

# Generated at 2022-06-20 18:00:00.770262
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # Init
    module = AnsibleModule(argument_spec={})

    # Mocks
    ifaces = {
        'lo0': {
            'device': 'lo0',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown',
            'flags': [],
            'macaddress': 'unknown'
        }
    }
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    GBIF = GenericBsdIfconfigNetwork(module)

    # Tests

# Generated at 2022-06-20 18:00:13.229064
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ansible_module = MockAnsibleModule()
    ifconfig_network = GenericBsdIfconfigNetwork(module=ansible_module)

    defaults = {'interface': 'lo0'}

# Generated at 2022-06-20 18:00:22.267499
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    net_obj = GenericBsdIfconfigNetwork()
    interfaces = {}
    current_if = {}

    net_obj.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384'], interfaces, current_if)
    net_obj.parse_options_line(['options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>'], interfaces, current_if)
    net_obj.parse_lladdr_line(['lladdr', '00:00:00:00:00:00'], interfaces, current_if)

# Generated at 2022-06-20 18:00:27.000592
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    m_run_command = MagicMock(return_value=(0, "", ""))
    m_get_bin_path = MagicMock(return_value="/sbin/ifconfig")
    module.run_command = m_run_command
    module.get_bin_path = m_get_bin_path

    n = GenericBsdIfconfigNetwork()
    n.module = module
    n.populate()

# Generated at 2022-06-20 18:00:28.129192
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    assert GenericBsdIfconfigNetwork()


# Generated at 2022-06-20 18:00:33.686648
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    obj = GenericBsdIfconfigNetwork()
    obj.parse_unknown_line([], {}, {'all_ipv4_addresses': [],
                                        'all_ipv6_addresses': []})

# Generated at 2022-06-20 18:00:42.456838
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    ifconfig_path = "/sbin/ifconfig"
    lladdr = '54:76:c0:fe:1b:8e'

    line = "lladdr %s" % lladdr

    current_if = {'device': 'test', 'ipv4': [], 'ipv6': []}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    gen = GenericBsdIfconfigNetwork()

    gen.parse_lladdr_line(line.split(), current_if, ips)

    assert current_if['lladdr'] == lladdr


# Generated at 2022-06-20 18:00:47.997394
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # Test with empty input
    try:
        # Create an object
        obj = GenericBsdIfconfigNetworkClass()
        # Set expected results
        words = []
        current_if = {}
        ips = {}
        # Call method with empty inputs
        returned_value = obj.parse_unknown_line(words, current_if, ips)
        assert returned_value is None
    except Exception as e:
        print('Test with empty input failed: {!r}'.format(e))

# Generated at 2022-06-20 18:00:55.213294
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    from ansible.module_utils.basic import AnsibleModule
    # setup mock module
    module = AnsibleModule()
    module.run_command = MagicMock(return_value=[0, "", ""])

    # instantiate test class
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork(module)
    # declare test variables

# Generated at 2022-06-20 18:01:07.771033
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    ifconfig_module = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    assert 'options' not in current_if
    words = ['options=80008<LINK2,VLAN_MTU,JUMBO_MTU,VLAN_HWTAGGING>']
    ifconfig_module.parse_options_line(words, current_if, ips)
    assert 'options' in current_if
    assert 'LINK2' in current_if['options']
    assert 'VLAN_MTU' in current_if['options']
    assert 'JUMBO_MTU' in current_if['options']
    assert 'VLAN_HWTAGGING' in current

# Generated at 2022-06-20 18:01:15.928136
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
  option_string = "abc<a,b,c>xyz"
  assert GenericBsdIfconfigNetwork.get_options(option_string) == ['a','b','c']
  option_string = "a<a,b,c>b<d,e,f>c"
  assert GenericBsdIfconfigNetwork.get_options(option_string) == ['a','b','c']
  option_string = "a<>b"
  assert GenericBsdIfconfigNetwork.get_options(option_string) == []
  option_string = "abc"
  assert GenericBsdIfconfigNetwork.get_options(option_string) == []
  option_string = "<a,b,c>xyz"
  assert GenericBsdIfconfigNetwork.get_options(option_string) == ['a','b','c']
 

# Generated at 2022-06-20 18:01:26.920301
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """
    Constructor test:
    """

    dummy_ifconfig_path = os.path.dirname(os.path.realpath(__file__)) + os.path.sep + 'dummy.ifconfig'

    # NOT_SET
    module_input = {}
    module_result = {}
    module_mock = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ifconfig = GenericBsdIfconfigNetwork(module_mock)
    assert ifconfig.platform == 'Generic_BSD_Ifconfig'

    # This platform doesn't support check mode
    assert not ifconfig.check_mode

    # ifconfig_path = NOT_SET
    module_input['ansible_ifconfig_path'] = ''

# Generated at 2022-06-20 18:01:38.990107
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class ModuleStub():
        def get_bin_path(self, _):
            return True

    class GenericBsdIfconfigNetworkStub(GenericBsdIfconfigNetwork):
        def __init__(self):
            super().__init__(ModuleStub())

    def test_get_default_interfaces(route_path, output, expected):
        genericbsdifconfig_network_stub = GenericBsdIfconfigNetworkStub()
        genericbsdifconfig_network_stub.module.run_command = lambda _, __: \
            (0, output, '')
        assert genericbsdifconfig_network_stub.get_default_interfaces(route_path) == expected

    test_get_default_interfaces('route', 'default: localhost\n', ({'interface': 'localhost'}, {}))

   

# Generated at 2022-06-20 18:01:45.896583
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    class TestModule(object):
        def run_command(self, *_, **__):
            return 0, '', ''

    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        pass

    module_obj = TestModule()
    gen_ifconfig_network_obj = TestGenericBsdIfconfigNetwork(module_obj)

    # Test 1
    iface = {}
    ips = {}
    words = ['fe80::21b:21ff:fe2f:fa31', 'prefixlen', '64']
    gen_ifconfig_network_obj.parse_inet6_line(words, iface, ips)
    assert len(iface.get('ipv6')) == 1
    ip = iface.get('ipv6')[0]

# Generated at 2022-06-20 18:01:53.920395
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # inet 127.0.0.1 netmask 0xff000000
    # inet alias 127.1.1.1 netmask 0xff000000
    # netbsd show aliases like this
    words = ['inet', '2.2.2.2', 'netmask', '255.255.0.0']
    current_if = dict(ipv4=[])
    ips = dict(all_ipv4_addresses=[])

    network = GenericBsdIfconfigNetwork()

    network._GenericBsdIfconfigNetwork__parse_inet_line(words, current_if, ips)

    assert current_if['ipv4'][0]['address'] == '2.2.2.2'
    assert current_if['ipv4'][0]['netmask'] == '255.255.0.0'
    assert current

# Generated at 2022-06-20 18:02:02.074086
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = 'Generic_BSD_Ifconfig'
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)

    route_path = network.module.get_bin_path('route')

    if route_path is None:
        module.fail_json(msg="Route binary not found")

    default_ipv4, default_ipv6 = network.get_default_interfaces(route_path)
    module.exit_json(changed=False, default_ipv4=default_ipv4, default_ipv6=default_ipv6)



# Generated at 2022-06-20 18:02:11.309163
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # setup parameters
    module_args = dict()
    # execute module code
    obj = GenericBsdIfconfigNetwork(module_args)
    # result is a dictionary
    result = obj.populate()
    assert isinstance(result, dict)
    # result is a dictionary with keys
    keys = [
        'all_ipv6_addresses',
        'all_ipv4_addresses',
        'interfaces',
    ]
    for key in keys:
        assert key in result

# Generated at 2022-06-20 18:02:22.295742
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()

    # line: 127.0.0.1 netmask 0xff000000
    ipv4_address_1 = str({'address': '127.0.0.1', 'netmask': '255.0.0.0'})

    # line: 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255
    ipv4_address_2 = str({'address': '127.0.0.1', 'netmask': '255.0.0.0', 'broadcast': '127.255.255.255'})

    # line: 127.0.0.1 0xffff0000 127.255.255.255

# Generated at 2022-06-20 18:02:33.399725
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    inp_route_command_a = ['route', '-n', 'get', 'default']
    inp_route_command_b = ['route', '-n', 'get', '-inet6', 'default']
    inp_route_output_a = '''
route to: default
destination: default
       mask: default
    gateway: 10.0.0.1
  interface: en0
      flags: <UP,GATEWAY,DONE,STATIC,PRCLONING>
 recvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire
       0         0         0         0         0         0      1500         0
'''

# Generated at 2022-06-20 18:02:51.233819
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = MagicMock(name='ansible.module_utils.basic.AnsibleModule')
    module.run_command.return_value = (0, '\n'.join([
        'default:',
        '	interface: vioif0',
        '	local addr: xxx.xxx.xxx.xxx',
        '	if address: xxx.xxx.xxx.xxx',
        '	gateway: xxx.xxx.xxx.xxx',
    ]), '')
    network = GenericBsdIfconfigNetwork(module)

    default_ipv4, default_ipv6 = network.get_default_interfaces('/some/route')

    module.run_command.assert_any_call(['/some/route', '-n', 'get', 'default'])

    assert(default_ipv4 == {})

# Generated at 2022-06-20 18:03:01.536375
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule(argument_spec={})
    module.params = {'ifconfig_options':'-a'}
    m = GenericBsdIfconfigNetwork(module)
    words = ['tunnel', 'inet', '5.5.5.5', '6.6.6.6', 'prefixlen', '16', 'mtu', '1480']
    current_if = {}
    ips = {}
    m.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'



# Generated at 2022-06-20 18:03:03.495611
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    n = GenericBsdIfconfigNetwork()


# Generated at 2022-06-20 18:03:12.754086
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    m = GenericBsdIfconfigNetwork({})
    # lo0 netbsd 7.1
    # lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33192 metric 0 groups: lo
    # strace -o /tmp/route.txt route -n get default
    # route: get: Invalid argument
    # l2: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500 lladdr f8:1a:67:2c:96:f3 priority: 0
    # media: Ethernet autoselect (none) status: no carrier
    # groups: egress
    # lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #         inet 127.0

# Generated at 2022-06-20 18:03:24.596042
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # input
    option_string = ''
    # '<UP,BROADCAST,RUNNING,MULTICAST>'
    # expected output
    expected_output = []
    obj = GenericBsdIfconfigNetwork()
    actual_output = obj.get_options(option_string)
    assert actual_output == expected_output, 'Mismatch actual output with expected output'
    # input
    option_string = '<UP,BROADCAST,RUNNING,MULTICAST>'
    # expected output
    expected_output = ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    actual_output = obj.get_options(option_string)
    assert actual_output == expected_output, 'Mismatch actual output with expected output'

# Generated at 2022-06-20 18:03:34.842807
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test happy path
    gbin = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0'}
    interfaces = {
        'lo0': {
            'device': 'lo0',
            'ipv4': [{'address': '1.2.3.4', 'netmask': '255.255.255.0', 'broadcast': '1.2.3.255', 'network': '1.2.3.0'}],
            'ipv6': [{'address': '1:2::3', 'prefix': '64', 'scope': 'link'}],
            'macaddress': '13:37:42:13:37:42',
            'mtu': 1500,
            'options': [],
            'type': 'ether'}
    }
    gbin.merge_

# Generated at 2022-06-20 18:03:40.443781
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    assert GenericBsdIfconfigNetwork._parse_inet_line(['127.0.0.1', 'netmask', '0xff000000'] \
        , {}, {}) == {'broadcast': None, 'address': '127.0.0.1', 'netmask': '255.255.255.0'}

# Generated at 2022-06-20 18:03:51.743951
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    my_obj = GenericBsdIfconfigNetwork()
    my_obj.module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
    )

# Generated at 2022-06-20 18:04:03.539451
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    m = Mock()
    n = GenericBsdIfconfigNetwork(m)
    m.run_command.return_value = (0, 'default: gateway 192.168.0.1', '')
    ipv4, ipv6 = n.get_default_interfaces('route')
    assert ipv4['gateway'] == '192.168.0.1'
    assert ipv6 == {}
    m.run_command.assert_called_once_with(['route', '-n', 'get', 'default'])
    m.reset_mock()
    m.run_command.return_value = (0, """
default: gateway 192.168.0.1
	interface: 192.168.0.30
""", '')
    ipv4, ipv6 = n.get_default_interfaces('route')

# Generated at 2022-06-20 18:04:17.316059
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    m = AnsibleModule(argument_spec={})
    m.exit_json = lambda **x: x
    module = m
    ################################################################
    class TestIface():
        def __init__(self, name):
            self.device = name
            self.ipv6 = []
    ################################################################

# Generated at 2022-06-20 18:04:32.012729
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    class DummyNetwork(GenericBsdIfconfigNetwork):
        def __init__(self):
            pass

        def parse_unknown_line(self, words, current_if, ips):
            pass

        def merge_default_interface(self, defaults, interfaces, ip_type):
            pass
    ip_address = "10.0.1.1"
    netmask = "255.255.255.0"
    broadcast = "10.0.1.255"

# Generated at 2022-06-20 18:04:40.229508
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec={})
    ifconfig_net = GenericBsdIfconfigNetwork(module)

    # test 1
    words = ['inet6', '2001:470:a:11:8b76:b2f1:5741:b5f5%re0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = {'ipv6': []}
    ips = dict(
        all_ipv6_addresses=[],
    )
    ifconfig_net.parse_inet6_line(words, current_if, ips)
    assert len(current_if['ipv6']) == 1
    assert len(ips['all_ipv6_addresses']) == 1

# Generated at 2022-06-20 18:04:52.035803
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    test_obj = GenericBsdIfconfigNetwork()
    out1 = test_obj.parse_unknown_line(['802', '11', 'media:', 'IEEE', '802.11', 'Wireless'])
    out2 = test_obj.parse_unknown_line(['802', '11', 'status:'])
    out3 = test_obj.parse_unknown_line(['802', '11', 'lladdr', 'b4:2e:99:b4:b0:9b'])
    out4 = test_obj.parse_unknown_line(['802', '11', 'inet', 'cntlmsg <unspec>'])

# Generated at 2022-06-20 18:04:54.768385
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    f = GenericBsdIfconfigNetwork()
    assert isinstance(f, GenericBsdIfconfigNetwork)
    # TODO


# Generated at 2022-06-20 18:05:06.100046
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """
    test_GenericBsdIfconfigNetwork_detect_type_media

    Validates results of detect_type_media method

    """
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-20 18:05:11.679627
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class MockModule(object):
        def run_command(self, command):
            return 0, "", ""

    module = MockModule()
    ifconfig = GenericBsdIfconfigNetwork(module)

    v4 = {'address': '192.168.0.1', 'interface': 'eno1', 'gateway': '192.168.0.254'}
    v6 = {'address': '2a01:e34:ed30:3a20::1', 'interface': 'eno1', 'gateway': 'fe80::6e40:8ff:fe04:5d6d'}
    assert ifconfig.get_default_interfaces("route") == (v4, v6)


# Generated at 2022-06-20 18:05:20.636273
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    network = GenericBsdIfconfigNetwork()

    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ["status:", "active"]
    network.parse_status_line(words, current_if, ips)

    assert 'status' in current_if
    assert current_if['status'] == "active"


# Generated at 2022-06-20 18:05:30.304299
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    import sys
    import os

    from ansible.module_utils import six
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork


# Generated at 2022-06-20 18:05:38.127918
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    test_network = GenericBsdIfconfigNetwork()
    test_line = b'vlan0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n'
    expected_result = 'vlan0'
    test_result = test_network.parse_interface_line(test_line.split())['device']
    assert test_result == expected_result


# Generated at 2022-06-20 18:05:43.311341
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbinc_n = GenericBsdIfconfigNetwork()

    assert gbinc_n.get_options('<no-options>') == []
    assert gbinc_n.get_options('<one-option>') == []
    assert gbinc_n.get_options('<more,options>') == ['more', 'options']

# Generated at 2022-06-20 18:05:53.769380
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    check_parse_ether_line_tests()

# Generated at 2022-06-20 18:06:00.346307
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Setup
    option_string = '<UP,LOOPBACK,RUNNING,MULTICAST>'

    # Expect result
    expect_result = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

    # Do the test
    if GenericBsdIfconfigNetwork.get_options(option_string) != expect_result:
        raise Exception("test_GenericBsdIfconfig_get_options() failed.")
    print("test_GenericBsdIfconfig_get_options() passed.")

test_GenericBsdIfconfigNetwork_get_options()



# Generated at 2022-06-20 18:06:14.059531
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    test = GenericBsdIfconfigNetwork()
    # Test 1: with more than three words
    words = ['fxp0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']

    output = test.parse_interface_line(words)

    # Check the expected results
    assert output == {'device': 'fxp0',
                      'ipv4': [],
                      'ipv6': [],
                      'type': 'unknown',
                      'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'],
                      'macaddress': 'unknown',
                      'metric': '0',
                      'mtu': '1500'}

    # Test 2: with exactly three

# Generated at 2022-06-20 18:06:26.865084
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test with no defaults.
    defaults = {}
    interfaces = {'eth0': {'ipv4': [{'address': '10.0.0.1'}]}}
    ifconfig = GenericBsdIfconfigNetwork()
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')
    assert 'interface' not in defaults
    assert 'address' not in defaults
    assert 'ipv4' not in defaults

    # Test with defaults for a non-existent interface.
    defaults = {'interface': 'eth1'}
    interfaces = {'eth0': {'ipv4': [{'address': '10.0.0.1'}]}}
    ifconfig = GenericBsdIfconfigNetwork()
    ifconfig.merge_default_interface(defaults, interfaces, 'ipv4')

# Generated at 2022-06-20 18:06:31.257834
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """
    Create an instance of the GenericBsdIfconfigNetwork class
    """
    module = AnsibleModule(argument_spec=dict())
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    assert generic_bsd_ifconfig_network


# Generated at 2022-06-20 18:06:38.663007
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    def test(args, out):
        in_dict = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': '02:42:ac:11:00:02'}
        out_dict = copy.deepcopy(in_dict)
        out_dict.update(out)
        m = GenericBsdIfconfigNetwork()
        m.parse_media_line(args, in_dict, out)
        assert in_dict == out_dict
    test(['media:', 'Ethernet', 'autoselect', '(1000baseT)'],
         dict(media='Ethernet', media_select='autoselect', media_type='1000baseT'))

# Generated at 2022-06-20 18:06:47.737862
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    temp_class = GenericBsdIfconfigNetwork()

    # A single option
    options = temp_class.get_options('<OPTION>')
    assert options[0] == 'OPTION'

    # No options
    options = temp_class.get_options('<>')
    assert len(options) == 0

    # Option with multiple commas
    options = temp_class.get_options('<OPTION1,OPTION2,OPTION3>')
    assert len(options) == 3
    assert options[0] == 'OPTION1'
    assert options[1] == 'OPTION2'
    assert options[2] == 'OPTION3'

    # Option with comma and brackets in name

# Generated at 2022-06-20 18:06:59.803902
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = GenericBsdIfconfigNetwork()
    iface = dict()

    iface['options'] = dict()
    iface['options']['HOME'] = 'YES'
    iface['options']['ND6_PROHIBIT_INFINITY'] = 'YES'

    words = ['', 'options=3<HOME,ND6_PROHIBIT_INFINITY,MTU>']

    network_facts.parse_nd6_line(words, iface, dict())
    assert iface['options'] == {'HOME': 'YES', 'ND6_PROHIBIT_INFINITY': 'YES', 'MTU': ''}

# Generated at 2022-06-20 18:07:05.859409
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule({})
    ifconfig = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ifconfig.parse_media_line(['media:', 'Ethernet', 'autoselect (1000baseT <full-duplex>)'], current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '(1000baseT'

# Generated at 2022-06-20 18:07:16.526257
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(
        argument_spec = dict(
            foo = dict(type='str'),
        ),
    )
    # ifconfig -a output from FreeBSD 9.2 system
    ifconfig_out = ''' lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
    inet6 ::1 prefixlen 128
    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    inet 127.0.0.1 netmask 0xff000000
    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    groups: lo
    '''

    # route -

# Generated at 2022-06-20 18:07:44.255271
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    device = 'lo0'
    words = [device + ':', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if = network.parse_interface_line(words)
    assert device == current_if['device']
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['metric'] == '0'
    assert current_if['mtu'] == '33184'
    assert 'macaddress' not in current_if

    device = 'lo0'
    words = [device + ':', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']

# Generated at 2022-06-20 18:07:53.605473
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    ifaces = {}
    interfaces = {}
    interfaces['lo0'] = {'macaddress': 'unknown', 'ipv6': [], 'device': 'lo0', 'options': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'status': 'active', 'ipv4': [{'netmask': '255.0.0.0', 'broadcast': '127.255.255.255', 'network': '127.0.0.0', 'address': '127.0.0.1'}], 'mtu': '32768'}
    interfaces['lo0']['media'] = 'Ethernet autoselect'

# Generated at 2022-06-20 18:08:03.161168
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = 'route'
    # Test with route command output with IPv4 and IPv6 interfaces

# Generated at 2022-06-20 18:08:10.544905
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    """
    Test: GenericBsdIfconfigNetwork.get_options
    """
    # instantiate object
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    option_string = '<UP,RUNNING,MULTICAST>'
    expected_list = ['UP', 'RUNNING', 'MULTICAST']
    actual_list = generic_bsd_ifconfig_network.get_options(option_string)
    assert expected_list == actual_list

# Generated at 2022-06-20 18:08:22.979863
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import network_facts

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):  # pylint: disable=unused-argument
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):  # pylint: disable=unused-argument
        kw

# Generated at 2022-06-20 18:08:31.337476
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(
        argument_spec = dict()
    )
    collected_facts = dict(network=dict())

    network = GenericBsdIfconfigNetwork()
    assert(network is not None)
    assert(network.run(module, collected_facts) is not None)

if __name__ == '__main__':
    # test_GenericBsdIfconfigNetwork()
    module = basic.AnsibleModule(
        argument_spec = dict()
    )

    network = GenericBsdIfconfigNetwork()
    result = network.run(module)
    module.exit_json(**result)

# Generated at 2022-06-20 18:08:40.347147
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import tempfile
    # Instantiate the GenericBsdIfconfigNetwork class
    network = GenericBsdIfconfigNetwork({})
    # Get the default interface ipv4 and ipv6 addresses
    with tempfile.NamedTemporaryFile() as route_v4:
        with tempfile.NamedTemporaryFile() as route_v6:
            route_v4.write('default: gateway 127.0.0.1')
            route_v4.flush()
            route_v6.write('default: gateway ::1')
            route_v6.flush()
            result = network.get_default_interfaces(route_v4.name)
            assert len(result) == 2
            assert result[0]['interface'] == 'default'
            assert result[0]['gateway'] == '127.0.0.1'
           

# Generated at 2022-06-20 18:08:53.369388
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(supports_check_mode=True)
    ifconfig_network = GenericBsdIfconfigNetwork(module)
    if os.path.isfile('/sbin/route'):
        # Mac OS X
        results = ifconfig_network.get_default_interfaces('/sbin/route')
        assert results[0]['interface'] == 'en0'
        assert results[0]['gateway'] == '192.168.1.1'
        assert results[0]['address'] == '192.168.1.7'
        assert results[1]['interface'] == 'en0'
        assert results[1]['gateway'] == 'fe80::224:36ff:fe9e:cd5c%en0'

# Generated at 2022-06-20 18:09:05.142920
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:09:13.412594
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_network_module = GenericBsdIfconfigNetwork()
    assert generic_bsd_network_module.get_options('LOOPBACK,UP,LOWER_UP') == ['LOOPBACK', 'UP', 'LOWER_UP']
    assert generic_bsd_network_module.get_options('LOOPBACK,UP') == ['LOOPBACK', 'UP']
    assert generic_bsd_network_module.get_options('UP,LOWER_UP') == ['UP', 'LOWER_UP']
    assert generic_bsd_network_module.get_options('LOWER_UP') == ['LOWER_UP']

