

# Generated at 2022-06-20 17:59:55.902971
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # create an instance of class GenericBsdIfconfigNetwork
    # needed to test protected methods
    class Object(GenericBsdIfconfigNetwork):
        pass
    obj = Object()

    # execute the method to test
    obj.parse_ether_line(['ether', '00:50:04:0d:78:00'], {}, {})

    # verify results of method execution
    assert obj.parse_ether_line(['ether', '00:50:04:0d:78:00'], {}, {}) == {'macaddress': '00:50:04:0d:78:00', 'type': 'ether'}


# Generated at 2022-06-20 18:00:03.989613
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [],
                  'type': 'unknown', 'macaddress': 'unknown',
                  'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST']}
    ips = dict(
        all_ipv4_addresses = [],
        all_ipv6_addresses = [],
    )
    network = GenericBsdIfconfigNetwork()
    network.parse_lladdr_line([u'lladdr', u'52:54:00:e6:d4:e8'], current_if, ips)
    assert current_if['lladdr'] == u'52:54:00:e6:d4:e8'


# Generated at 2022-06-20 18:00:17.091466
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    test_object = GenericBsdIfconfigNetwork({}, {})
    test_object.parse_nd6_line = {}
    current_if = {}
    ips = {}

    # 1. test with single option
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    test_object.parse_nd6_line(words, current_if, ips)
    assert words[1] in current_if['options']
    assert 'PERFORMNUD' in current_if['options']
    assert 'IFDISABLED' in current_if['options']
    assert 'AUTO_LINKLOCAL' in current_if['options']

    # 2. test with multiple options

# Generated at 2022-06-20 18:00:30.015604
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    configurator = network_info.Configurator()
    platform_info_obj = network_info.PlatformInfo('Linux')
    configurator.register_plugin(platform_info_obj)
    generic_bsd_platform_info_obj = network_info.GenericBsdIfconfigNetwork(None, None, None)
    configurator.register_plugin(generic_bsd_platform_info_obj)
    configurator.load()
    platform_info_obj.detect()
    generic_bsd_platform_info_obj.detect()
    obj = GenericBsdIfconfigNetwork(None, None, None)
    obj_defaults = obj.get_default_interfaces('route_path')
    assert(obj_defaults[0]['interface'] == 'lo0')

# Generated at 2022-06-20 18:00:32.051555
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    assert 1==1

# Generated at 2022-06-20 18:00:43.139860
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # setup
    GenericBsdIfconfigNetwork.__bases__ = (GenericBsdIfconfigNetwork,)
    GenericBsdIfconfigNetwork.parse_media_line
    test_data = [
        ['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)'],
        ['media:', 'Ethernet', '1000baseT', '<full-duplex>'],
        ['media:', 'Ethernet', '1000baseT', '<full-duplex>', 'status:', 'active'],
    ]

# Generated at 2022-06-20 18:00:54.415425
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    M = MagicMock()
    M.run_command.return_value = (0, '\n'.join(sample_ifconfig_execution), '')

    v = GenericBsdIfconfigNetwork(M)
    interfaces, ips = v.get_interfaces_info('/sbin/ifconfig')


# Generated at 2022-06-20 18:01:02.346699
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
  line = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active']
  result = {'media': 'Ethernet', 'media_select': 'autoselect', 'media_type': '1000baseT', 'status': 'active'} 
  n = GenericBsdIfconfigNetwork()
  result2 = n.parse_media_line(line, {'device': 'lo0'}, {})
  assert result == result2



# Generated at 2022-06-20 18:01:05.712131
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork(get_platform({}))

    words = ['foo', 'bar']
    current_if = {}
    ips = {}

    # calling the function to test
    network.parse_unknown_line(words, current_if, ips)

    assert not 'foo' in current_if
    assert not 'foo' in ips


# Generated at 2022-06-20 18:01:15.366791
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    '''Test method get_interfaces_info of class GenericBsdIfconfigNetwork.'''

    network = AnsibleGenericBsdIfconfigNetworkModule({}, {})

# Generated at 2022-06-20 18:01:29.205863
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    def obj_method_call(obj, method_name, arguments):
        method = getattr(obj, method_name)
        return method(**arguments)

    arguments = {'words': ['lladdr', '00:0c:29:51:e6:ef'], 'current_if': {}, 'ips': {}}
    obj = GenericBsdIfconfigNetwork({'run_command': None, 'get_bin_path': None})
    expected = None
    actual = obj_method_call(obj, 'parse_lladdr_line', arguments)
    assert actual == expected

# Generated at 2022-06-20 18:01:36.180661
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    macaddress = "3e:2f:9e:16:6a:1a"
    words = ["ether", macaddress]
    current_if = {'macaddress':None, 'type':None}
    ips = dict()
    
    gbi = GenericBsdIfconfigNetwork()
    gbi.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == macaddress
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:01:48.702557
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    rv = GenericBsdIfconfigNetwork.detect_type_media({'eth0': {'media': 'Ethernet autoselect (1000baseT)'}, 'em0': {'media': '10Gbase-T autoselect (10Gbase-T)'}, 'lo0': {'media': 'Loopback'}})
    assert rv == {'em0': {'media': '10Gbase-T autoselect (10Gbase-T)', 'type': 'unknown'}, 'eth0': {'media': 'Ethernet autoselect (1000baseT)', 'type': 'ether'}, 'lo0': {'media': 'Loopback'}}



# Generated at 2022-06-20 18:02:00.268473
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    assert network.get_options('options=3<RXCSUM,TXCSUM>') == ['RXCSUM', 'TXCSUM']
    assert network.get_options('flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert network.get_options('flags=0x843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']


# Generated at 2022-06-20 18:02:13.240430
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    """ GenericBsdIfconfigNetwork class parse_unknown_line method unit test """

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.network import Network
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import dict_merge
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import to_list
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import remove_default_spec
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import boolean
   

# Generated at 2022-06-20 18:02:23.315598
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # Set up test object
    o = GenericBsdIfconfigNetwork()

    # test empty input
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words = []
    assert current_if == o.parse_tunnel_line(words, current_if, ips)

    words = ['tunnel']
    assert current_if == o.parse_tunnel_line(words, current_if, ips)

    words = ['tunnel', 'inet', '6to4']
    assert current_if == o.parse_tunnel_line(words, current_if, ips)

    # Test with a known good input

# Generated at 2022-06-20 18:02:34.001009
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()

    # tests to make sure that default values are updated.
    default_ipv4 = {'default_ipv4': {'interface': 'wl0'}}
    interfaces = {'wl0': {'ipv4': [{'address': '10.1.1.10'}, {'address': '10.1.1.11'}]}}
    net.merge_default_interface(default_ipv4['default_ipv4'], interfaces, 'ipv4')
    assert default_ipv4['default_ipv4']['address'] == '10.1.1.10'

    # tests to make sure that if there is only one ipv4 address, the defaults will be set.

# Generated at 2022-06-20 18:02:39.068271
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    iface = dict(device='eth0', ipv4=[], ipv6=[], type='unknown')
    iface['flags'] = ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    iface['mtu'] = '1500'

    def check_parse_interface_line(generic_network, words, expected_interface):
        current_if = generic_network.parse_interface_line(words)
        assert current_if == expected_interface

    # Newer FreeBSD versions
    generic_network = GenericBsdIfconfigNetwork({}, {})

# Generated at 2022-06-20 18:02:50.905266
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():

    input = ['tunnel', 'inet', '10.10.10.1', '-->', '10.10.10.2']
    current_if = current_if = {'device': 'tun0', 'ipv4': [], 'ipv6': [],
                               'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=['::1'],
    )
    expected = {
        'device': 'tun0',
        'ipv4': [],
        'ipv6': [],
        'type': 'tunnel',
        'macaddress': 'unknown'
    }
    GenericBsdIfconfigNetwork().parse_tunnel_line(input, current_if, ips)


# Generated at 2022-06-20 18:02:59.093125
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    data = []
    module = Mock()
    module.run_command.side_effect = lambda *args, **kwargs: data.pop(0)
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    result = generic_bsd_ifconfig_network.populate()
    assert {} == result


# Generated at 2022-06-20 18:03:26.845163
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    # Create instance of class
    network = GenericBsdIfconfigNetwork()

    # Check parse_interface_line with a network that has flags, metric and mtu
    iface = network.parse_interface_line(['em0:', 'flags=8802<BROADCAST,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500'])
    assert iface['device'] == 'em0'
    assert iface['flags'] == ['BROADCAST', 'SIMPLEX', 'MULTICAST']
    assert iface['metric'] == '0'
    assert iface['mtu'] == '1500'
    assert iface['type'] == 'ether'

    # Check parse_interface_line with a network that has flags, metric and mtu

# Generated at 2022-06-20 18:03:30.361884
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=None, type='list')
        )
    )

    fact = GenericBsdIfconfigNetwork(module)
    assert fact.populate()


# Generated at 2022-06-20 18:03:38.100767
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(
        argument_spec=dict()
    )

    network = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = {}

    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex>,']
    network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert current_if['media'] == 'Ethernet'
    assert 'media_select' in current_if
    assert current_if['media_select'] == 'autoselect'
    assert 'media_type' in current_if
    assert current_if['media_type'] == '(1000baseT'
    assert 'media_options' in current_if

# Generated at 2022-06-20 18:03:47.986146
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # input
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '16384', 'metric', '1']
    # expected output
    expected = dict(device='lo0') #, 'ipv4': [], 'ipv6': [], 'type': 'unknown'})
    expected['flags'] = ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    expected['metric'] = '1'
    expected['mtu'] = '16384'
    # call method
    r = GenericBsdIfconfigNetwork.parse_interface_line(words)
    # assert statements
    assert(r == expected)


# Generated at 2022-06-20 18:03:57.183322
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    class Mock(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            self.module = module

    class MockModule(object):
        pass

    env = os.environ.copy()
    env['PATH'] = '/tmp'

    mock_module = MockModule()
    mock_module.run_command = MagicMock(return_value=(0, "", ""))
    mock_network = Mock(mock_module)

    words = ['lladdr', '00:de:ad:be:ef:be']
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    mock_network.parse_lladdr_line(words, current_if, ips)


# Generated at 2022-06-20 18:04:07.300349
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    if not HAS_SUBPROCESS:
        pytest.skip("Failed to import subprocess")

    class GenericBsdIfconfigNetworkMock(GenericBsdIfconfigNetwork):
        def __init__(self):
            self.facts = dict(interfaces=[])

        def populate(self, collected_facts=None):
            return self.facts

    # Create a mock class and test the detect_type_media method
    network = GenericBsdIfconfigNetworkMock()
    network.facts['interfaces'] = ['em0', 'lo0']


# Generated at 2022-06-20 18:04:19.500274
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module_name = 'ansible.module_utils.facts.network.generic_bsd_ifconfig'
    module_args = dict(
        gather_subset=['!all', '!min'],
        gather_network_resources=dict(interfaces=['tun0']),
    )

    config = dict(
        ansible_facts=dict(),
        ansible_cmdline=dict(),
        ansible_module_args=module_args
    )

    def get_bin_path_mock(arg):
        return '/sbin/' + arg


# Generated at 2022-06-20 18:04:20.963442
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    pass


# Generated at 2022-06-20 18:04:30.248720
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    test = AnsibleModule({})
    network = GenericBsdIfconfigNetwork()

    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    words = 'ether 00:11:22:33:44:55'.split()
    network.parse_ether_line(words, current_if, 'ips')
    assert current_if['macaddress'] == '00:11:22:33:44:55'
    assert current_if['type'] == 'ether'



# Generated at 2022-06-20 18:04:35.513369
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    generic_bsd_ifconfig_network_module = GenericBsdIfconfigNetwork()
    current_if = {'device': 'eno1'}

    words = ['lladdr', '18:03:73:7c:8d:2f']
    generic_bsd_ifconfig_network_module.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == words[1]

    return

# Generated at 2022-06-20 18:05:24.524316
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    macaddress = '00:1f:29:f4:00:fa'
    words = ['ether', macaddress]
    current_if = {'device': 'bge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    GenericBsdIfconfigNetwork.parse_ether_line(words, current_if, {})
    assert current_if['macaddress'] == macaddress
    assert current_if['type'] == 'ether'

# Generated at 2022-06-20 18:05:32.397067
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # Test with the following data structures
    module_params = [0, None]

    module_obj = TestAnsibleModule(argument_spec=dict())
    module_obj.params = module_params

    # Expected result from constructor
    expected_result = {
        'default_ipv4': {'interface': None, 'gateway': None, 'address': None},
        'default_ipv6': {'interface': None, 'gateway': None, 'address': None},
        'interfaces': None,
        'all_ipv4_addresses': None,
        'all_ipv6_addresses': None
    }

    # Need to mock run_command to return output from ifconfig & route

# Generated at 2022-06-20 18:05:44.532382
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    import platform

    platform_name = platform.system()

    if platform_name == 'FreeBSD':
        cmd = "ifconfig -a"
    else:
        cmd = "ifconfig -a"

    module = MockModule()
    module.run_command = Mock(return_value=(0, cmd, ""))
    platform = GenericBsdIfconfigNetwork(module)

    result = platform.populate()

    assert result != None
    assert result['all_ipv4_addresses'] != None
    assert result['all_ipv6_addresses'] != None
    assert result['interfaces'] != None
    assert result['default_ipv4'] != None
    assert result['default_ipv6'] != None

    print("Result: %s" % result)

# Unit test execution

# Generated at 2022-06-20 18:05:54.203572
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    platform_detect_mock = Mock(return_value='FreeBSD')
    module_patcher = patch.dict('sys.modules', {'platform': platform_detect_mock})
    module_patcher.start()
    import platform
    platform.system.return_value = 'FreeBSD'
    module_patcher.stop()
    objGenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    objGenericBsdIfconfigNetwork.get_options = Mock()
    objGenericBsdIfconfigNetwork.parse_options_line(['options=3<RXCSUM,TXCSUM>', 'metric', '0'], {}, {})
    assert objGenericBsdIfconfigNetwork.get_options.called


# Generated at 2022-06-20 18:06:03.218809
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    net = GenericBsdIfconfigNetwork()

    # test against FreeBSD
    current_if = {}
    line = "lladdr 00:e0:1c:e2:d8:a1"
    net.parse_unknown_line(line.split(), current_if, {})
    assert current_if['lladdr'] == '00:e0:1c:e2:d8:a1'

    # test against OpenBSD
    current_if = {}
    line = "priority: 0"
    net.parse_unknown_line(line.split(), current_if, {})
    assert current_if['priority'] == '0'
    line = "llprio: 0"
    net.parse_unknown_line(line.split(), current_if, {})
    assert current_if['llprio'] == '0'



# Generated at 2022-06-20 18:06:13.395156
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['lladdr', '00:00:00:00:00:00']
    network = GenericBsdIfconfigNetwork()
    network.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == '00:00:00:00:00:00'


# Generated at 2022-06-20 18:06:21.266172
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    words = ['lladdr', '11:22:33:44:55:66']
    network = GenericBsdIfconfigNetwork({})
    network.parse_lladdr_line(words, current_if, None)
    assert current_if['lladdr'] == '11:22:33:44:55:66'

# Generated at 2022-06-20 18:06:29.120877
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # create mock structures
    current_if = {}
    ips = {'all_ipv6_addresses': []}

    # test string
    inet6_line = "inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2"
    words = inet6_line.split()

    GenericBsdIfconfigNetwork.parse_inet6_line(None, words, current_if, ips)
    assert ips['all_ipv6_addresses'][0] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['scope'] == '0x2'
    assert current_if['ipv6'][0]['prefix'] == '64'

    # test string

# Generated at 2022-06-20 18:06:33.653954
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    obj = GenericBsdIfconfigNetwork()
    ifconfig_path='/sbin/ifconfig'
    ifconfig_options='-a'
    interfaces, ips = obj.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert interfaces['lo0']['device'] == 'lo0'


# Generated at 2022-06-20 18:06:47.811863
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    """ Verify returns parse_unknown_line of class GenericBsdIfconfigNetwork """
    network_facts = {}
    network_facts['interfaces'] = ['']
    network_facts['all_ipv4_addresses'] = ['']
    network_facts['all_ipv6_addresses'] = ['']
    ifconfig_path = None
    ifconfig_path = GenericBsdIfconfigNetwork().module.get_bin_path('ifconfig')
    if ifconfig_path is not None:
        command = [ifconfig_path, '-a']
        rc, out, err = GenericBsdIfconfigNetwork().module.run_command(command)
        for line in out.splitlines():
            words = line.split()
            if words[0] == 'pass':
                continue

# Generated at 2022-06-20 18:09:06.461650
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    nm = GenericBsdIfconfigNetwork()
    iface = dict(
        device='test',
        type='unknown',
        macaddress='00:00:00:00:00:00',
        ipv4=[], ipv6=[])
    ips = dict(all_ipv4_addresses=[])
    if 'metric' in iface:
        del iface['metric']
    if 'mtu' in iface:
        del iface['mtu']
    if 'netmask' in iface:
        del iface['netmask']
    if 'address' in iface:
        del iface['address']
    if 'network' in iface:
        del iface['network']
    if 'broadcast' in iface:
        del iface['broadcast']
    nm.parse_inet_