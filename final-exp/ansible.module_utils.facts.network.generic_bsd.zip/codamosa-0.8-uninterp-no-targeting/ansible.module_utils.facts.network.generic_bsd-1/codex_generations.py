

# Generated at 2022-06-20 17:59:35.380356
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # setup required test data
    GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    line_list = ['device:', 'lladdr', '01:23:45:67:89:ab']
    current_if = {'device': 'test_device', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'lladdr': None}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    # test call of method parse_lladdr_line
    GenericBsdIfconfigNetwork.parse_lladdr_line(line_list, current_if, ips)
    assert current_if['lladdr'] == '01:23:45:67:89:ab'

# Generated at 2022-06-20 17:59:47.456299
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    test_module = NetworkModule(argument_spec={}, supports_check_mode=True)
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(module=test_module)

    # Test tunnel line with correct words
    tunnel_words = ['tunnel', 'inet', '10.2.2.1', '-->', '10.1.1.1', 'netmask', '0xffffff00']

    test_current_if = {'device': 'tun0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    test_ips = {}

    assert test_GenericBsdIfconfigNetwork.parse_tunnel_line(tunnel_words, test_current_if, test_ips) == None

# Generated at 2022-06-20 17:59:57.254678
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = MockNetworkModule()
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words_case1 = ["status:", "active"]
    network.parse_status_line(words_case1, current_if, ips)
    assert current_if['status'] == "active"

    words_case2 = ["status:", "inactive"]
    network.parse_status_line(words_case2, current_if, ips)
    assert current_if['status'] == "inactive"


# Generated at 2022-06-20 18:00:10.938925
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = './test/test_GenericBsdIfconfigNetwork_get_interfaces_info.ifconfig'
    module = Mock()
    result = dict()
    result['rc'] = 0
    result['stdout'] = None
    result['stderr'] = None
    with open(ifconfig_path) as f:
        result['stdout'] = f.read()
    module.run_command = Mock(return_value=result)
    module.get_bin_path = Mock(return_value=ifconfig_path)
    test_object = GenericBsdIfconfigNetwork(module)
    result = test_object.get_interfaces_info(ifconfig_path)
    assert len(result[0]) == 6
    assert len(result[1]['all_ipv6_addresses']) == 0


# Generated at 2022-06-20 18:00:20.398971
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    interfaces = {
        'en0': {
            'ipv4': [
                {
                    'address': '192.0.2.2',
                    'broadcast': '192.0.2.255',
                    'netmask': '255.255.255.0',
                    'network': '192.0.2.0'
                }
            ],
            'ipv6': [
                {
                    'address': 'fe80::ba27:ebff:fe78:39f0',
                    'broadcast': 'fe80::1',
                    'prefix': '64',
                    'scope': 'link'
                }
            ],
            'type': 'ether',
        }
    }
    default_interface = 'en0'

# Generated at 2022-06-20 18:00:31.014883
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    # Create an instance of the module
    n = GenericBsdIfconfigNetwork(module)

    #
    # NetBSD ifconfig
    #
    netbsd_inet = ['inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.0.0.1']
    netbsd_inet = n.parse_inet_line(netbsd_inet, {}, {})
    assert netbsd_inet['address'] == '127.0.0.1'
    assert netbsd_inet['netmask'] == '0xff000000'
    assert netbsd_inet['broadcast'] == '127.0.0.1'
    assert netbsd_inet['network'] == '127.0.0.0'

   

# Generated at 2022-06-20 18:00:40.946593
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    net_cls = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['tunnel','inet','192.168.1.1','dest','192.168.1.2','netmask','0xffffffff']
    net_cls.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-20 18:00:53.108309
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """
    Test detect_type_media of class GenericBsdIfconfigNetwork
    """
    # Test 1:
    # Setup the test object
    interfaces = {}
    network_facts = GenericBsdIfconfigNetwork()

    # Test
    result = network_facts.detect_type_media(interfaces)
    # Check result
    assert result == {}, result

    # Test 2:
    interfaces = {'test_iface': {'media': 'none'}}
    # Test
    result = network_facts.detect_type_media(interfaces)
    # Check result
    assert result == {'test_iface': {'media': 'none', 'type': 'unknown'}}, result

    # Test 3:
    interfaces = {'test_iface': {'media': 'ether'}}
    # Test
    result

# Generated at 2022-06-20 18:01:00.108257
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    hostname = 'test_host'
    module = AnsibleModule(argument_spec={})
    module.CHECK_ARGUMENT_TYPES = False
    module.check_mode = False

    # BSD ifconfig command
    ifconfig_path = 'dummy'

    # Method to be tested
    def parse_inet_line(self, words, current_if, ips):
        address = {'address': words[1]}
        netmask_bin = struct.unpack('!L', socket.inet_aton(self.module.params['netmask']))[0]
        address['netmask'] = socket.inet_ntoa(struct.pack('!L', netmask_bin))
        address['network'] = socket.inet_ntoa(struct.pack('!L', netmask_bin & netmask_bin))
       

# Generated at 2022-06-20 18:01:13.405392
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    was_called = []

    def mock_parse_lladdr_line(words, current_if, ips):
        was_called.append((words, current_if, ips))

    network = GenericBsdIfconfigNetwork()
    network.parse_lladdr_line = mock_parse_lladdr_line
    current_if = dict(device='eth0', options=[])

    network.parse_lladdr_line(['lladdr', '01:02:03:04:05:06'], current_if, dict())

    assert len(was_called) == 1
    assert current_if['type'] == 'ether'
    assert current_if['macaddress'] == '01:02:03:04:05:06'
    assert current_if['lladdr'] == '01:02:03:04:05:06'
#

# Generated at 2022-06-20 18:01:30.757215
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from collections import namedtuple

    Interface = namedtuple('Interface', 'device flags macaddress type')
    interfaces = [
        Interface(device='lo0', flags=[], macaddress='00:00:00:00:00:00', type='unknown'),
        Interface(device='bge0', flags=[], macaddress='00:00:00:00:00:00', type='unknown'),
        Interface(device='ix0', flags=[], macaddress='00:00:00:00:00:00', type='unknown'),
        Interface(device='ix1', flags=[], macaddress='00:00:00:00:00:00', type='unknown'),
        Interface(device='ix2', flags=[], macaddress='00:00:00:00:00:00', type='unknown'),
    ]

    n = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:01:39.018076
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    test_obj = GenericBsdIfconfigNetwork()


    words = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': []}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    test_obj.parse_nd6_line(words, current_if, ips)
    assert current_if.get('options') == ['PERFORMNUD', 'AUTO_LINKLOCAL']


# Generated at 2022-06-20 18:01:40.971974
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # The function is successfully tested by the module tests.
    # This function is just a shadow for the same function in the
    # module, so it does not have to be tested separately.
    assert True


# Generated at 2022-06-20 18:01:48.324971
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    ips = {}
    network = GenericBsdIfconfigNetwork()

    words = ['lladdr', '00:2a:99:e6:f4:28']
    network.parse_lladdr_line(words, current_if, ips)
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == '00:2a:99:e6:f4:28'

# Generated at 2022-06-20 18:02:01.514156
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    def test(testname, line, expected_type):
        # testname is unused, but we are keeping it for readability
        network = GenericBsdIfconfigNetwork()
        iface = {}
        network.parse_tunnel_line(line.split(), iface, [])
        assert 'type' in iface
        assert iface['type'] == expected_type, "Expected type {0}, got {1}".format(expected_type, iface['type'])


# Generated at 2022-06-20 18:02:14.127508
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # test setup
    module = AnsibleModule(argument_spec={})
    # test
    # IPv6 with prefix
    words = ['inet6', '::1/128', 'prefixlen', '128', 'scopeid', '0x1']
    network = GenericBsdIfconfigNetwork()
    current_if = {'ipv6': list()}
    ips = dict(all_ipv6_addresses=list())
    network.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == '::1'
    assert current_if['ipv6'][0]['prefix'] == '128'
    assert current_if['ipv6'][0]['scope'] == '0x1'

# Generated at 2022-06-20 18:02:24.845828
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={
        "gather_subset": {"default": ["!all"], "type": "list"}
    })
    # for testing, we are just going to return dict with a populated interfaces list
    # we don't really want to actually call ifconfig etc.
    network_facts = dict(
        interfaces=['lo0', 'lo1', 'lo2', 'lo3', 'lo4', 'lo5', 'lo6', 'lo7', 'gif0', 'stf0'],
    )
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    result = generic_bsd_ifconfig_network.populate()
    assert result == network_facts


# Generated at 2022-06-20 18:02:31.973684
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    net = GenericBsdIfconfigNetwork()
    test_inputs = [
        '<UP,BROADCAST,RUNNING,PROMISC>',
        '<UP,BROADCAST,RUNNING,PROMISC,NOARP>',
    ]
    test_expecteds = [
        ['UP', 'BROADCAST', 'RUNNING', 'PROMISC'],
        ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'NOARP'],
    ]

    for index, test_input in enumerate(test_inputs):
        result = net.get_options(test_input)
        assert result == test_expecteds[index]



# Generated at 2022-06-20 18:02:42.870416
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Init
    module = AnsibleModule(argument_spec=dict())
    fake_interfaces = {}
    fake_ips = {}
    net_generic = GenericBsdIfconfigNetwork(module)

    # Normal case
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']

    net_generic.parse_inet_line(words, fake_interfaces, fake_ips)
    res = fake_interfaces['lo0']['ipv4']
    assert res == [{'address': '127.0.0.1', 'netmask': '255.255.255.0', 'network': '127.0.0.0', 'broadcast': '127.255.255.255'}]

    # Normal case with broadcast

# Generated at 2022-06-20 18:02:50.896725
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = Mock()
    module.run_command.return_value = (0, ROUTE_DEFAULT_OUTPUT, '')
    network = GenericBsdIfconfigNetwork(module)

    # Test 1: Happy path
    default_ipv4, default_ipv6 = network.get_default_interfaces('')
    assert_equals(default_ipv4, {'interface': 'en0'})
    assert_equals(default_ipv6, {'interface': 'en0'})

    # Test 2: Invalid argument in ipv6 routing
    module.run_command.return_value = (0, ROUTE_DEFAULT_INVALID_OUTPUT, '')
    default_ipv4, default_ipv6 = network.get_default_interfaces('')
    assert_equals

# Generated at 2022-06-20 18:03:12.504856
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    from ansible.module_utils.network.common.utils import dict_merge

    network_module_params={
        'async_timeout': 10,
        'connect_timeout': None,
        'ip': None,
        'match': 'all',
        'port': None,
        'provider': None,
        'retries': 3,
        'ssh_keyfile': None,
        'timeout': None,
        'username': None,
        'validate_certs': True
    }
    network_module = NetworkModule(argument_spec={}, supports_check_mode=True, **network_module_params)


# Generated at 2022-06-20 18:03:23.679629
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Build a test fixture.
    words = ['', 'flags=208843<UP,RUNNING,SIMPLEX,MULTICAST>']
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    module = FakeModule()
    gbi = GenericBsdIfconfigNetwork(module=module)

    # Run the test.
    gbi.parse_nd6_line(words, current_if, ips)

    # Verify the result.
    assert current_if['options'] == ['UP', 'RUNNING', 'SIMPLEX', 'MULTICAST']


# Generated at 2022-06-20 18:03:24.765995
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-20 18:03:34.982137
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # test with empty option
    assert [] == GenericBsdIfconfigNetwork.get_options('')
    # test with options alone
    assert ['LOOPBACK', 'MULTICAST', 'RUNNING', 'UP'] == GenericBsdIfconfigNetwork.get_options('LOOPBACK,MULTICAST,RUNNING,UP')
    # test with options starting with <
    assert ['LOOPBACK', 'MULTICAST', 'RUNNING', 'UP'] == GenericBsdIfconfigNetwork.get_options('<LOOPBACK,MULTICAST,RUNNING,UP>')
    # test with options starting with < and ending with >

# Generated at 2022-06-20 18:03:45.857820
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    parse_inet6_line tests.
    """
    # Example of ifconfig line
    # inet6 fe80::ba27:ebff:fe2f:7f71%em0 prefixlen 64 scopeid 0x1
    # address {'prefix': '64', 'scope': '0x1', 'address': 'fe80::ba27:ebff:fe2f:7f71%em0'}
    module = AnsibleModule(argument_spec={})
    n = GenericBsdIfconfigNetwork(module)

    # Pass words
    words = ['inet6', 'fe80::ba27:ebff:fe2f:7f71%em0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = dict()
    ips = dict()

    n.parse_inet6

# Generated at 2022-06-20 18:03:54.850955
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    from importlib import import_module
    from io import StringIO
    c = import_module('ansible.module_utils.basic')
    m = import_module('ansible.modules.network.bsd')
    n = m.GenericBsdIfconfigNetwork(c)
    current_if = {}
    current_if['status'] = 'up'
    words = ['status:','up']
    assert n.parse_status_line(words, current_if, {}) == None

# Generated at 2022-06-20 18:04:01.097497
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # parser = GenericBsdIfconfigNetwork()
    # words = ['word1', 'word2', 'word3']
    # current_if = {}
    # ips = {}
    # result = parser.parse_unknown_line(words, current_if, ips)
    # assert result == False, "Result is %s" % result
    pass

# Generated at 2022-06-20 18:04:09.205107
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():

    fixture = {
        'module': {'run_command': MagicMock(return_value=(0, "media 802-3 autoselect (1000baseT <full-duplex>) status: active", ''))}
    }

    network = GenericBsdIfconfigNetwork(fixture)
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    network.parse_status_line(network.module.run_command()[1].split(), current_if, None)
    assert current_if == {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'status': 'active'}

# Generated at 2022-06-20 18:04:12.536478
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    payload = ['lladdr', '00:00:00:00:00:00', 'alias', '10.0.0.1']
    network_facts = GenericBsdIfconfigNetwork()
    interface_info = {}
    ips = {}

    network_facts.parse_lladdr_line(payload, interface_info, ips)

    assert interface_info['type'] == 'ether'


# Generated at 2022-06-20 18:04:22.555215
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    p = GenericBsdIfconfigNetwork()
    interfaces, ips = p.get_interfaces_info(ifconfig_path)
    assert type(interfaces) is dict
    for v in interfaces.values():
        assert type(v) is dict
        assert type(v['device']) is str
        assert type(v['ipv4']) is list
        assert type(v['ipv6']) is list
        assert type(v['type']) is str
        assert type(v['flags']) is list
        assert type(v['macaddress']) is str
    assert type(ips) is dict
    assert type(ips['all_ipv4_addresses']) is list
    assert type(ips['all_ipv6_addresses']) is list
   

# Generated at 2022-06-20 18:04:41.087155
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    bsd_network = GenericBsdIfconfigNetwork()

    # Test OpenBSD interface
    words = "vioif0: flags=80c2<BROADCAST,SIMPLEX,MULTICAST,NEEDSGIANT> mtu 1500"
    words = words.split()

    interfaces = bsd_network.parse_interface_line(words)

    assert interfaces == dict(
        device='vioif0',
        type='ether',
        flags=['BROADCAST', 'SIMPLEX', 'MULTICAST', 'NEEDSGIANT'],
        metric='',
        mtu='1500',
        macaddress='unknown',
        ipv4=[],
        ipv6=[],
    )

    # Test FreeBSD interface

# Generated at 2022-06-20 18:04:52.960656
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    generic_bsd_ifconfig = network_info_module()
    interfaces = {
        'eth0': {
            'ipv4': {
                'address': '192.168.1.1',
                'broadcast': '255.255.255.255',
                'netmask': '255.255.255.0',
                'network': '192.168.1.0'
            }
        },
        'eth1': {
            'ipv4': {
                'address': '10.10.10.1',
                'broadcast': '255.255.255.255',
                'netmask': '255.255.255.0',
                'network': '10.10.10.0'
            }
        }
    }

# Generated at 2022-06-20 18:05:05.091621
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    network_module = GenericBsdIfconfigNetwork()
    assert network_module is not None

    # test when line is empty
    current_if = {}
    ips = {}
    words = []
    network_module.parse_ether_line(words, current_if, ips)
    assert current_if == {'macaddress': 'unknown'}

    # test when line has one token
    current_if = {}
    ips = {}
    words = ['ether']
    network_module.parse_ether_line(words, current_if, ips)
    assert current_if == {'macaddress': 'unknown'}

    # test when line has more than one token
    current_if = {}
    ips = {}
    words = ['ether', 'one', 'two', 'three']
    network_module.parse_ether

# Generated at 2022-06-20 18:05:13.855812
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    my_module = AnsibleModule({})
    my_network_facts = GenericBsdIfconfigNetwork(my_module)
    current_if = {}
    ips = {}
    words = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>', 'media:', 'Ethernet', '10Gbase-T', '(10Gbase-T<full-duplex>)' ]
    my_network_facts.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'AUTO_LINKLOCAL']


# Generated at 2022-06-20 18:05:25.127035
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    import sys
    sys.modules['__builtin__'].__dict__['openbsd_version'] = None
    sys.modules['__builtin__'].__dict__['os'] = 'FreeBSD'
    from ansible.module_utils.facts import network

    iface = network.GenericBsdIfconfigNetwork()
    _, ips = iface.get_interfaces_info('/sbin/ifconfig')
    assert ips == dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    cur_if = dict()
    words = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'.split()
    iface.parse_nd6_line(words, cur_if, ips)

# Generated at 2022-06-20 18:05:32.676050
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert GenericBSDIfconfigNetwork.get_options("BLAH") == []
    assert GenericBSDIfconfigNetwork.get_options("BLAH<>") == []
    assert GenericBSDIfconfigNetwork.get_options("BLAH<HELLO>") == []
    assert GenericBSDIfconfigNetwork.get_options("BLAH<ONE>") == ["ONE"]
    assert GenericBSDIfconfigNetwork.get_options("BLAH<ONE,TWO>") == ["ONE", "TWO"]
    assert GenericBSDIfconfigNetwork.get_options("BLAH<ONE,TWO,THREE>") == ["ONE", "TWO", "THREE"]
    assert GenericBSDIfconfigNetwork.get_options("BLAH<ONE,TWO,THREE,>") == ["ONE", "TWO", "THREE"]
    assert GenericBSDIfconfigNetwork.get_

# Generated at 2022-06-20 18:05:40.601309
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    """
    Test the method get_options
    :return: None
    """
    assert GenericBsdIfconfigNetwork.get_options('<LOOPBACK,RUNNING,MULTICAST>') == ['LOOPBACK', 'RUNNING', 'MULTICAST']
    assert GenericBsdIfconfigNetwork.get_options('<LOOPBACK>') == ['LOOPBACK']
    assert GenericBsdIfconfigNetwork.get_options('LOOPBACK') == []
    assert GenericBsdIfconfigNetwork.get_options('') == []



# Generated at 2022-06-20 18:05:50.787493
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()
    interfaces = {
        'en0': {
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)'
        },
        'lo0': {
            'media': 'loopback'
        }
    }
    expected_interfaces = {
        'en0': {
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)',
            'type': 'ether'
        },
        'lo0': {
            'type': 'unknown',
            'media': 'loopback'
        }
    }

    # Anything other than ether will be set to type: unknown
    network.detect_type_media(interfaces)
    assert interfaces == expected_interfaces
    # Method should not change any items other than type

# Generated at 2022-06-20 18:06:02.489457
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    mock_val = Mock(return_value=(0, '', ''))
    with patch.object(GenericBsdIfconfigNetwork, 'get_default_interfaces', mock_val):
        with patch.object(GenericBsdIfconfigNetwork, 'get_interfaces_info', mock_val):
            network = GenericBsdIfconfigNetwork(module)
            network.populate()
            assert "interfaces" in network.ansible_facts
            assert "ipv6" in network.ansible_facts['interfaces'][0]

# Generated at 2022-06-20 18:06:12.797485
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    n = GenericBsdIfconfigNetwork()
    cif = dict(
        ipv4=[],
        ipv6=[],
        type='unknown'
    )
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    words = ['tunnel', 'inet', '192.168.16.232', '-->', '192.168.16.1']
    n.parse_tunnel_line(words, cif, ips)
    assert cif['type'] == 'tunnel'

# Generated at 2022-06-20 18:06:47.262138
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  'en0': {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  'fw0': {'device': 'fw0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  'en1': {'device': 'en1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  'bridge0': {'device': 'bridge0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}

    result = GenericBsdIfconfigNetwork.detect_type_media(interfaces)



# Generated at 2022-06-20 18:06:59.832525
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork(None)

    defaults = {'interface': 'lo0'}

# Generated at 2022-06-20 18:07:05.878695
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork.
    """
    platform = 'Generic_BSD_Ifconfig'

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_module = GenericBsdIfconfigNetwork(module)
    ifconfig_path = network_module.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        module.fail_json(msg="ifconfig binary not found, aborting")

    interfaces, ips = network_module.get_interfaces_info(ifconfig_path)
    assert 'tun0' in interfaces
    assert 'lo0' in interfaces
    assert 'em0' in interfaces
    assert 'bridge0' in interfaces
    assert 'bridge1' in interfaces



# Generated at 2022-06-20 18:07:17.475497
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    ifconfig_path = '/sbin/ifconfig'

    # If ifconfig_path is none, this method should return False.
    if GenericBsdIfconfigNetwork.which(ifconfig_path) == None:
        return False

    network = GenericBsdIfconfigNetwork(dict())

    # Testing if method parse_inet_line works if the ip address is dotted quad
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'mtu': '33184'}
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    network.parse_inet_line(words, current_if, dict())

# Generated at 2022-06-20 18:07:18.924687
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    x = None


# Generated at 2022-06-20 18:07:31.221056
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = '/sbin/route'
    module = AnsibleModuleMock()

# Generated at 2022-06-20 18:07:43.737971
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:07:50.693744
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'] == GenericBsdIfconfigNetwork.get_options(
        'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184'
    )
    assert ['UP', 'BROADCAST', 'RUNNING'] == GenericBsdIfconfigNetwork.get_options(
        'bridge0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500'
    )
    assert ['BROADCAST', 'RUNNING'] == GenericBsdIfconfigNetwork.get_options(
        'stf0: flags=0<> mtu 1280'
    )
    assert ['UP', 'BROADCAST', 'RUNNING'] == GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:07:58.988665
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    c = GenericBsdIfconfigNetwork()
    # Test for words = ['/usr/local/bin/bash', '-c', './test']
    words = ['/usr/local/bin/bash', '-c', './test']
    c.parse_unknown_line(words, None, None)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_parse_unknown_line()



# Generated at 2022-06-20 18:08:11.604796
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Setup the module, mocks and values
    import ansible.module_utils.facts.network.bsd
    ansible.module_utils.facts.network.bsd.socket = my_socket
    m_module = Mock()
    m_module.params.copy.return_value = {}
    m_module.run_command.return_value = (0, '', '')
    m_module.get_bin_path.return_value = None
    my_bin = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bin', 'bsd-ifconfig-%s' % platform.system().lower())
    m_module.get_bin_path.return_value = my_bin