

# Generated at 2022-06-20 17:59:48.245051
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0,IFCONFIG_OUT,None))

    platform = MagicMock(return_value='Generic_BSD_Ifconfig')
    platform_spec = GenericBsdIfconfigNetwork()
    platform_spec.platform = platform
    platform_spec.module = module
    

# Generated at 2022-06-20 17:59:59.055177
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184"
    generic_ifconfig_network.parse_interface_line(words.split())

    words = "inet 127.0.0.1 netmask 0xfffffe00 broadcast 127.255.255.255"
    generic_ifconfig_network.parse_inet_line(words.split(), current_if, ips)

# Generated at 2022-06-20 18:00:05.232545
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork({})
    current_if = {}
    ips = {}
    words = ['foo', 'bar']
    network.parse_unknown_line(words, current_if, ips)
    assert current_if == {}

# Generated at 2022-06-20 18:00:15.159739
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ####
    # Set up mock values
    ####
    m_ifconfig_path = '/sbin/ifconfig'
    m_ifconfig_options = '-a'

# Generated at 2022-06-20 18:00:20.528428
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    m = GenericBsdIfconfigNetwork()

    eth_line = 'ether 08:00:27:86:b4:7b'
    words = eth_line.split()
    current_if = {}
    ips = {}

    m.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '08:00:27:86:b4:7b'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:00:31.076156
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    """
    Method parse_status_line() of class GenericBsdIfconfigNetwork does not parse the status line correctly.
    """
    ifconfig_path = module.get_bin_path('ifconfig')
    current_platform = 'Generic_BSD_Ifconfig'
    if ifconfig_path is None:
        # Skip the test
        return

    network = GenericBsdIfconfigNetwork(module)
    interface = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = ['status:', 'no', 'carrier']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_status_line(words, interface, ips)

# Generated at 2022-06-20 18:00:42.860588
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """Generic_BSD_Ifconfig_Network - parse_nd6_line """
    #
    # This is all that is required to invoke the module prolog
    # The only thing that is needed is to ensure that the AnsibleModule
    # is created and that its run_command function is available.
    # Running these on a generic class causes the class module imports
    # to run in the background and be available for testing.
    #
    module = get_platform_subclass(AnsibleModule)
    # Create the platform-specific subclass
    generic_ifconfig = GenericBsdIfconfigNetwork(module)
    #
    # Test the method parse_nd6_line
    #
    # Test #1
    #
    # Verify that parsing a line containing 'nd6 options=' and words containing
    # two valid tokens results in a dictionary containing the values of the

# Generated at 2022-06-20 18:00:53.288283
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # create a mock module since the module imports depend on the host
    module = MockModule()
    network = GenericBsdIfconfigNetwork(module)

    ifconfig_path = network.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    if platform.system() == 'OpenBSD' or platform.system() == 'NetBSD':
        ifconfig_options = ' '

    interfaces, ips = network.get_interfaces_info(ifconfig_path, ifconfig_options)

    assert 'lo0' in interfaces
    assert 'inet 127.0.0.1' in str(interfaces['lo0'])
    assert 'inet6 ::1' in str(interfaces['lo0'])

# This class is a subclass of the BSD ifconfig class.  It implements
# functionality for the Mac OS

# Generated at 2022-06-20 18:00:58.610989
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    iface = {'device': 'lo0'}
    ips = {}
    linfo = {'macaddress': '01:23:45:67:89:ab'}
    module_mock = MagicMock(params={})
    result = GenericBsdIfconfigNetwork(module_mock).parse_ether_line(linfo, iface, ips)
    assert ips == {}
    assert iface == {'device': 'lo0', 'macaddress': '01:23:45:67:89:ab', 'type': 'ether'}
    assert result is True


# Generated at 2022-06-20 18:01:01.473446
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    a = GenericBsdIfconfigNetwork()
    result = a.get_default_interfaces('/path/to/route')
    assert result[0] == {}
    assert result[1] == {}


# Generated at 2022-06-20 18:01:24.516735
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifconfig = """\
en2: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
	inet6 fe80::2e70:a9ff:fe9b:8c99%en2 prefixlen 64 secured scopeid 0x4
	inet6 2001:470:1f14:37d::2 prefixlen 64 autoconf secured
	inet6 2001:470:1f14:37d::1 prefixlen 64 autoconf temporary
	ether 2c:70:a9:9b:8c:99
	media: autoselect
	status: active
""".splitlines()


# Generated at 2022-06-20 18:01:26.768798
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    gbi = GenericBsdIfconfigNetwork()
    gbi.parse_unknown_line(['address', '10.0.0.1'],1,1)

# Generated at 2022-06-20 18:01:38.001831
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Stub
    networkClass = GenericBsdIfconfigNetwork()
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    current_if = {'device': 'lo0'}
    ips = {}
    result = networkClass.parse_nd6_line(words, current_if, ips)
    expected = {'device': 'lo0', 'options': ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']}
    assert result == expected


# Generated at 2022-06-20 18:01:50.828751
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = None
    path = '/sbin/ifconfig'
    module = MockAnsibleModule({'path': path})
    result = GenericBsdIfconfigNetwork(module).populate()
    assert result is not None
    assert type(result) is dict
    assert result['default_ipv4'] is not None
    assert result['default_ipv6'] is not None
    assert result['interfaces'] is not None
    assert type(result['interfaces']) is list
    assert len(result['interfaces']) >= 1
    assert result['all_ipv4_addresses'] is not None
    assert type(result['all_ipv4_addresses']) is list
    assert len(result['all_ipv4_addresses']) >= 1
    assert result['all_ipv6_addresses'] is not None

# Generated at 2022-06-20 18:02:02.295426
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    ifc = GenericBsdIfconfigNetwork({})

    # test case 1
    out = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'
    words = out.split()
    current_if = ifc.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['mtu'] == '16384'
    assert current_if['metric'] == '0'
    assert current_if['type'] == 'loopback'

    # test case 2
    out = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184'
    words = out.split()
    current_if = ifc.parse_interface_line(words)

# Generated at 2022-06-20 18:02:14.557395
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    iface = GenericBsdIfconfigNetwork()

    current_if = {'device': 'lo0', 'ipv6': [], 'macaddress': '00:00:00:00:00:00', 'mtu': '33184', 'ipv4': [], 'type': 'loopback', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}

    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    words = ['inet6', '::1', 'prefixlen', '128']
    iface.parse_inet6_line(words, current_if, ips)
    assert ips['all_ipv6_addresses'] == []
    assert current_if['ipv6'][0]

# Generated at 2022-06-20 18:02:26.414788
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # generic_bsd_ifconfig_network.parse_interface_line(words)
    test_words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    test_network = GenericBsdIfconfigNetwork()
    result_interface = test_network.parse_interface_line(test_words)
    assert type(result_interface) is dict
    assert 'device' in result_interface
    assert result_interface['device'] == 'lo0'
    assert 'flags' in result_interface
    assert result_interface['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert 'metric' in result_interface

# Generated at 2022-06-20 18:02:35.487157
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    hostname = socket.gethostname()

# Generated at 2022-06-20 18:02:37.501644
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    '''
    Test method get_options of class GenericBsdIfconfigNetwork
    '''
    network = GenericBsdIfconfigNetwork(module)
    result = network.get_options('test_<1, 2, 3>')

    assert result == ['1', '2', '3']

# Generated at 2022-06-20 18:02:50.680729
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    mac_ex1 = """nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
media: Ethernet autoselect (1000baseT <full-duplex>)
status: active
lladdr b4:75:0e:4d:a0:d4
"""
    mac_ex2 = """nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>
media: autoselect
status: active
lladdr b4:75:0e:4d:a0:d4
"""

# Generated at 2022-06-20 18:03:11.573407
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    line = ['foo', 'bar', 'fie', 'blech', 'blach']
    iface = {'device': 'lo0', 'type': 'loopback', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
             'ipv4': [], 'ipv6': [], 'mtu': '33184', 'macaddress': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    genifconfig = GenericBsdIfconfigNetwork()
    genifconfig.parse_unknown_line(line, iface, ips)
    # check that inbound params didn't change
    assert line == ['foo', 'bar', 'fie', 'blech', 'blach']

# Generated at 2022-06-20 18:03:22.926919
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    network = GenericBsdIfconfigNetwork()

    current_if = {'device': 'tun0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test 1
    words = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'.split()
    network.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']


# Generated at 2022-06-20 18:03:34.430365
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    subject = GenericBsdIfconfigNetwork()
    args = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    expected_output = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'loopback',
        'status': 'active',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        'mtu': '33184',
        'macaddress': 'unknown'
    }
    assert expected_output == subject.parse_interface_line(args)


# Generated at 2022-06-20 18:03:38.664127
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Verify method parse_nd6_line of class GenericBsdIfconfigNetwork
    #
    # Setup:
    #
    # Exercise:
    #
    # Verify:
    #
    # Cleanup:
    #
    # Return:
    pass


# Generated at 2022-06-20 18:03:45.858021
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})

    platform_mock = Mock()
    platform_mock.platform = 'FreeBSD'
    platform_mock.mac_ver = '10.3'
    platform_mock.version = '10.3'

    module.platform = platform_mock

    n = GenericBsdIfconfigNetwork(module)
    interfaces = n.populate(None)['interfaces']

    assert interfaces

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:03:49.630716
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """Test parse_nd6_line of class GenericBsdIfconfigNetwork"""
    ifaces = {'lo0': {'device': 'lo0'}}
    parser = GenericBsdIfconfigNetwork()
    # test FreeBSD output
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    parser.parse_nd6_line(words, ifaces['lo0'], {})
    assert ifaces['lo0']['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']


# Generated at 2022-06-20 18:04:00.090174
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = GenericBsdIfconfigNetwork()
    m.parse_options_line({
        "words": ['options', 'OSI', '0', 'TS', '0x8', 'IFACE', '0x1', 'ARP', '0x4', 'INET', '0x20', 'ISO', '0x100'],
        "current_if": {},
        "ips": {}})

    m.parse_options_line({
        "words": ['options', 'options=0x80000'],
        "current_if": {},
        "ips": {}})

    m.parse_options_line({
        "words": ['options=0x80000'],
        "current_if": {},
        "ips": {}})


# Generated at 2022-06-20 18:04:09.081262
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    g = GenericBsdIfconfigNetwork()
    g.debug = True
    # Test case 1: output from DragonflyBSD
    # interface_name: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
    g.parse_interface_line(["lo0:", "flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500"])
    # Test case 2: output from FreeBSD
    # interface_name: flags=8802<BROADCAST,SIMPLEX,MULTICAST> metric 0 mtu 1500

# Generated at 2022-06-20 18:04:20.500113
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():

    # setup the test harness
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Utility functions
    def get_bin_path(self, arg, required=False):
        # dummy function
        return None

    def get_distribution(self):
        # dummy function
        distribution = dict(
            family='FreeBSD',
            major_version='9',
        )
        return distribution

    def run_command(self, cmd, check_rc=True):
        # dummy function
        return None, None, None

    # Mock AnsibleModule.get_bin_path
    module.get_bin_path = types.MethodType(get_bin_path, module)

    # Mock AnsibleModule.get_distribution
    module.get_

# Generated at 2022-06-20 18:04:29.840445
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    network = GenericBsdIfconfigNetwork()
    words = ['media:', 'Ethernet autoselect (1000baseT <full-duplex>)']
    current_if = {'device': 'lo0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network.parse_media_line(words, current_if, ips)

    assert current_if.get('media') == words[1]


# Generated at 2022-06-20 18:04:50.202624
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    test = GenericBsdIfconfigNetwork()
    assert test.get_options('FOO') == []
    assert test.get_options('FOO:') == []
    assert test.get_options('FOO<BAR>') == []
    assert test.get_options('FOO<BAR>GT') == []
    assert test.get_options('FOO<BAR>GT<HH>') == []
    assert test.get_options('FOO<BAR,>GT<HH>') == []
    assert test.get_options('FOO<BAR,GT>') == ['BAR', 'GT']
    assert test.get_options('FOO<BAR,GT>VV') == ['BAR', 'GT']


# Generated at 2022-06-20 18:04:56.864282
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    network_facts = generic_bsd_ifconfig_network.populate()
    print("network_facts=%r" % network_facts)
    assert 'interfaces' in network_facts
    assert 'en0' in network_facts

# Unit test main
if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-20 18:05:03.424147
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    p = GenericBsdIfconfigNetwork()
    current_if = {}
    current_if = p.parse_ether_line(['ether', 'aa:bb:cc:dd:ee:ff'], current_if, {})
    assert current_if['type'] == 'ether'
    assert current_if['macaddress'] == 'aa:bb:cc:dd:ee:ff'



# Generated at 2022-06-20 18:05:10.929638
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    ifconfig_path = None
    ifconfig_options = None
    if platform.system() == 'FreeBSD':
        ifconfig_path = '/sbin/ifconfig'
        ifconfig_options = '-a'
    elif platform.system() == 'DragonFly':
        ifconfig_path = '/sbin/ifconfig'
        ifconfig_options = '-a'
    elif platform.system() == 'OpenBSD':
        ifconfig_path = '/sbin/ifconfig'
        ifconfig_options = '-a'
    elif platform.system() == 'NetBSD':
        ifconfig_path = '/sbin/ifconfig'
        ifconfig_options = '-a'
    elif platform.system() == 'Darwin':
        ifconfig_path = '/sbin/ifconfig'
        ifconfig_options

# Generated at 2022-06-20 18:05:21.502450
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Test with parser = GenericBsdIfconfigNetwork(module)
    parser = GenericBsdIfconfigNetwork(module)
    words = ['unknown', 'words']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # TODO: assert something
    parser.parse_unknown_line(words, current_if, ips)

# Generated at 2022-06-20 18:05:26.605401
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    #create the class object
    obj = GenericBsdIfconfigNetwork()
    #create the test data
    data = None
    words = None
    current_if = None
    ips = None
    result = obj.parse_unknown_line(words, current_if, ips)
    assert result == None
    assert result == data


# Generated at 2022-06-20 18:05:33.461751
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    mock_pipe = MagicMock(spec=Popen)
    mock_pipe.returncode = 0

# Generated at 2022-06-20 18:05:40.561374
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    """
    Make sure that the output of a ifconfig command is correctly parsed
    """

    input_dict = dict(
        words=["status:", "active"],
        current_if = dict(),
        ips = dict()
    )
    generic = GenericBsdIfconfigNetwork()
    generic.parse_status_line(input_dict["words"], input_dict["current_if"], input_dict["ips"])
    assert input_dict["current_if"] == dict(status="active")



# Generated at 2022-06-20 18:05:44.759770
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    f = GenericBsdIfconfigNetwork()
    interface = {}
    word = ['status:', 'active']
    f.parse_status_line(word, interface, {})
    assert interface['status'] == 'active'


# Generated at 2022-06-20 18:05:54.296823
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_network = GenericBsdIfconfigNetwork()
    iface = {'device': 'em1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['em1:', 'media:', 'Ethernet', '10Gbase-CR', 'media_type', '(X)']
    generic_network.parse_media_line(words, iface, ips)
    assert iface['media'] == 'Ethernet'
    assert iface['media_select'] == '10Gbase-CR'
    assert iface['media_type'] == '(X)'


# Generated at 2022-06-20 18:06:12.631096
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    assert (
        GenericBsdIfconfigNetwork.parse_status_line(None, ['status', 'UP'], {}, {})
        == {'status': 'UP'}
    )



# Generated at 2022-06-20 18:06:21.495898
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec=dict())
    n = GenericBsdIfconfigNetwork()
    current_if = {'item': "link"}
    words = ["status:", "active"]

    # test creation
    n.parse_status_line(words, current_if, {})
    # test match
    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:06:29.196351
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec=dict())
    result = dict(changed=False)
    command = dict(v4=[route_path, '-n', 'get', 'default'],
                   v6=[route_path, '-n', 'get', '-inet6', 'default'])
    import sys
    if sys.version_info[:2] == (2, 6):
        with patch('ansible.module_utils.basic.AnsibleModule') as mock_AnsibleModule:
            module = mock_AnsibleModule.return_value

# Generated at 2022-06-20 18:06:38.102242
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(argument_spec={})
    generic = GenericBsdIfconfigNetwork(module)
    defaults = {}
    interfaces = {}
    ip_type = 'ipv4'
    generic.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == {}
    defaults = {'interface':'em0'}
    generic.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == {'interface':'em0'}
    interfaces = {'em0': {'ipv4':[{'address':'192.168.1.55'}]}}
    generic.merge_default_interface(defaults, interfaces, ip_type)
    assert defaults == {'interface':'em0'}

# Generated at 2022-06-20 18:06:49.150354
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # TODO: create better test cases
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
      argument_spec = dict(
        ifconfig_path = dict(type='str', required=True),
      )
    )
    # Create instance
    network = GenericBsdIfconfigNetwork(module)
    #if module.get_bin_path('ifconfig') is None:
    #    module.exit_json(msg="get_bin_path('ifconfig'): did not find ifconfig")
    # Get test data
    with open("testdata.json", "r") as json_file:
        testdata = json.load(json_file)
    for test in testdata:
        # Get test variables
        ifconfig_path = test['ifconfig_path']
        # Expected result


# Generated at 2022-06-20 18:07:00.618477
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # needs to be instantiated for setUp() to work
    test_class = GenericBsdIfconfigNetwork(None)
    assert test_class

    # test_parse_unknown_line_no_words
    test_words = []
    test_current_if = {}
    test_ips = {}
    test_class.parse_unknown_line(test_words, test_current_if, test_ips)
    assert test_current_if == {}
    assert test_ips == {}

    # test_parse_unknown_line_no_action
    test_words = [
        "word1",
        "word2",
        "word3",
    ]
    test_current_if = {}
    test_ips = {}
    test_class.parse_unknown_line(test_words, test_current_if, test_ips)

# Generated at 2022-06-20 18:07:08.974448
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    line = ["ether", "08:00:27:7b:d8:d0"]
    current_if = dict()
    ips = dict()

    gb_nic = GenericBsdIfconfigNetwork()
    gb_nic.parse_ether_line(line, current_if, ips)

    assert current_if['macaddress'] == "08:00:27:7b:d8:d0"
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:07:20.150522
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.base import Network, Interface
    defaults = dict(address='192.168.1.1', interface='eth0')
    interfaces = dict(eth0=dict(ipv4=[dict(address='192.168.1.1', netmask='255.255.255.0', broadcast='192.168.1.255')]))
    GenericBsdIfconfigNetwork.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults['address'] == '192.168.1.1'
    assert defaults['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:07:31.466707
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    net_info = GenericBsdIfconfigNetwork(None)

    words = ["media:", "Ethernet", "autoselect", "(100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>,", "100baseTX", "<full-duplex>)", "status:", "active"]
    current_if = {}
    ips = {}

    try:
        net_info.parse_media_line(words, current_if, ips)
    except:
        # We shouldn't get an exception from this code.
        assert False

    assert "media" in current_if

    words = ["media:", "Ethernet", "10Gbase-SR", "autoselect", "(10Gbase-SR", "status:", "active"]



# Generated at 2022-06-20 18:07:43.801038
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    network = GenericBsdIfconfigNetwork(None)
    
    line = "media: Ethernet 10Gbase-T <full-duplex> status: active"
    words = line.split()
    current_if = dict()
    ips = dict()
    network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'full-duplex'
    assert current_if['media_type'] == '10Gbase-T'
    assert not 'media_options' in current_if
    
    line = "media: Ethernet autoselect (none) status: no carrier"
    words = line.split()
    current_if = dict()
    ips = dict()

# Generated at 2022-06-20 18:08:09.996231
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gb = GenericBsdIfconfigNetwork()
    assert gb.parse_tunnel_line(['tunnel','inet','192.168.1.15','-->','192.168.1.1','netmask','0xffffff00',],{},{}) == {'ipv4': [], 'ipv6': [], 'device': 'tunnel', 'type': 'tunnel'}



# Generated at 2022-06-20 18:08:22.712709
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test 1
    test_object = GenericBsdIfconfigNetwork()
    test_object.module = ModuleStub({})
    test_object.get_default_interfaces = Mock()(return_value=("1", "2"))
    assert test_object.get_default_interfaces("23") == ("1", "2")
    assert test_object.module.run_command.call_count == 0
    test_object.get_default_interfaces.assert_called_with("23")
    test_object.get_default_interfaces.reset_mock()

    # Test 2
    test_object.module = ModuleStub({})
    test_object.module.run_command = Mock()(return_value=(0, "", ""))

# Generated at 2022-06-20 18:08:32.065611
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():

    #
    # Tests parse_tunnel_line() of class GenericBsdIfconfigNetwork against
    # entries in 'DEFAULT_TUNNEL_LINES' for validity of expected results.
    #

    GENERIC_BSD_IFCONFIG_NETWORK = GenericBsdIfconfigNetwork()
    for line in DEFAULT_TUNNEL_LINES:
        words = line.split()
        ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
        current_if = dict(
            device=words[0],
            ipv4=[],
            ipv6=[],
            type='unknown',
        )

# Generated at 2022-06-20 18:08:40.937587
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    network = GenericBsdIfconfigNetwork(module)
    # parse_nd6_line(): does not set any ips
    network.parse_nd6_line([], {}, {})
    # parse_nd6_line(['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'], current_if, ips)
    current_if = {}
    ips = {}
    network.parse_nd6_line(['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'], current_if, ips)

# Generated at 2022-06-20 18:08:43.940672
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    mod = GenericBsdIfconfigNetwork()
    assert(mod is not None)



# Generated at 2022-06-20 18:08:54.486030
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network import NetworkModule
    # NetBSD ifconfig output

# Generated at 2022-06-20 18:09:04.176285
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    platform = GenericBsdIfconfigNetwork()
    interfaces = {'eth0': {'media': 'Ethernet autoselect (1000baseT)'}}
    assert platform.detect_type_media(interfaces) == {'eth0': {'media': 'Ethernet autoselect (1000baseT)', 'type': 'ether'}}


mock_module = MagicMock()
mock_module.run_command = MagicMock(return_value=(0, '', ''))
mock_module.get_bin_path = MagicMock(return_value='')
mock_module.params = {}
