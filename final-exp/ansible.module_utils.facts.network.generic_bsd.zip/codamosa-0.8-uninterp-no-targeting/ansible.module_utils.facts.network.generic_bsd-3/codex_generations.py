

# Generated at 2022-06-20 18:00:12.516123
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # test_iface: Test case object
    test_iface = {'device': 'lo0', 'type': 'unknown'}
    # test_ips: Test case object
    test_ips = {}
    # test_words: Test case object
    test_words = ['ether', '00:11:22:33:44:55']
    result = {}
    net = GenericBsdIfconfigNetwork()
    net.parse_ether_line(test_words, test_iface, test_ips)
    result['device'] = test_iface['device']
    result['type'] = test_iface['type']
    result['macaddress'] = test_iface['macaddress']

# Generated at 2022-06-20 18:00:20.809442
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    network_module = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    # Example line that we are parsing
    #     lladdr 36:7e:90:f9:7c:00
    words = ['lladdr', '36:7e:90:f9:7c:00']

    # Run the code we want to test
    network_module.parse_lladdr_line(words, current_if, ips)

    # Make sure it has the expected results
    assert current_if['lladdr'] == '36:7e:90:f9:7c:00'



# Generated at 2022-06-20 18:00:26.583472
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    obj = GenericBsdIfconfigNetwork(ModuleStub())
    words = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if = obj.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['mtu'] == '33184'
    assert 'metric' in current_if.keys()
    assert current_if['type'] == 'loopback'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']



# Generated at 2022-06-20 18:00:30.575064
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    from ansible.module_utils.basic import AnsibleModule
    mynet = GenericBsdIfconfigNetwork(AnsibleModule)
    print(mynet)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:00:40.443319
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():

    # Create an object of GenericBsdIfconfigNetwork
    gen = GenericBsdIfconfigNetwork()

    # Create arguments for method parse_lladdr_line
    words = ['lladdr','b8:27:eb:08:19:7e']
    current_if = {}
    ips = {}

    # Invoke method parse_lladdr_line of class GenericBsdIfconfigNetwork
    gen.parse_lladdr_line(words, current_if, ips)

    # Check the data
    assert 'b8:27:eb:08:19:7e' in current_if['lladdr']


# Generated at 2022-06-20 18:00:48.654123
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    iface = {}
    ips = {}
    GenericBsdIfconfigNetwork().parse_ether_line(['ether', '00:0c:29:34:05:0a'], iface, ips)

    assert iface['macaddress'] == '00:0c:29:34:05:0a'
    assert iface['type'] == 'ether'

# Generated at 2022-06-20 18:00:51.974506
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    p = GenericBsdIfconfigNetwork()
    assert p.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-20 18:01:04.029353
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:01:14.465890
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # Test with empty option string.
    gn = GenericBsdIfconfigNetwork('')
    assert gn
    assert gn.platform == 'Generic_BSD_Ifconfig'

# Unit tests for get_default_interfaces()

# Generated at 2022-06-20 18:01:25.351390
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interface_info = dict(
        en0 = dict(
            macaddress = '00:00:00:00:00:00',
            media = 'Ethernet autoselect'
        ),
        lo0 = dict(
            macaddress = '80:80:80:80:80:80',
            media = 'Loopback'
        )
    )


# Generated at 2022-06-20 18:01:49.750549
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_string = 'media: Ethernet autoselect (1000baseT <full-duplex>) ' \
                      '\tstatus: active'
    words = ifconfig_string.split()
    current_if = {}
    ips = {}

    bsd_network = GenericBsdIfconfigNetwork()
    bsd_network.parse_media_line(words, current_if, ips)

    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'full-duplex'
    assert current_if['media_options'] == ['1000baseT']

# Generated at 2022-06-20 18:02:02.009214
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    test_module = AnsibleModule({'device': 'xl0'})
    test_network = GenericBsdIfconfigNetwork(test_module)
    test_current_if = {'device': 'xl0'}
    test_ips = {}
    test_words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    test_network.parse_nd6_line(test_words, test_current_if, test_ips)
    assert 'PERFORMNUD' in test_current_if['options']
    assert 'IFDISABLED' in test_current_if['options']
    assert 'AUTO_LINKLOCAL' in test_current_if['options']
    assert len(test_current_if['options']) == 3

# Unit test

# Generated at 2022-06-20 18:02:12.236694
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    gbin = GenericBsdIfconfigNetwork()
    words = ['options=fe80::1%lo0']
    current_if = {'ipv4': [], 'ipv6': []}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    gbin.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['fe80::1%lo0']
    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []



# Generated at 2022-06-20 18:02:24.380824
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    ans = dict(
        device = 'em0',
        status = 'active',
    )
    ans_ipv6 = dict(
        device = 'lo0',
        status = 'active',
    )
    src = dict(
        words = ('status:', 'active'),
        ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    )
    src_ipv6 = dict(
        words = ('status:', 'active'),
        ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    )
    ifc = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:02:28.813696
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    test_object = GenericBsdIfconfigNetwork()

    #status: active
    assert(test_object.parse_status_line([b"status", b"active"]) == None)
    


# Generated at 2022-06-20 18:02:32.069050
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    assert 'Modules._Generic_BSD_Ifconfig.GenericBsdIfconfigNetwork'



# Generated at 2022-06-20 18:02:37.601910
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    """
    Test parse_tunnel_line method
    """
    network_obj = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['tunnel', 'inet6', 'fe80::216:6fff:fe1b:3726%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    network_obj.parse_tunnel_line(words, current_if, ips)
    assert current_if == {'type': 'tunnel'}
    assert ips == {}


# Generated at 2022-06-20 18:02:45.414741
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():

    # This is the class I am testing
    test_class = GenericBsdIfconfigNetwork()

    # I have to create a mock current_if dictionary to test against
    test_data = {'device': 'test',
                 'ipv4': [],
                 'ipv6': [],
                 'options': [],
                 'type': 'ether',
                 'macaddress': 'unknown',
                 'status': 'unknown',
                 'mtu': 98234,
                 'metric': 0,
                 'lladdr': 'unknown'}

    # I'm using a copy in case things get messed up
    test_current_if = test_data.copy()
    test_ips = dict()

    # I start with the lladdr set to unknown
    assert test_current_if['lladdr'] == 'unknown'


    # This is the

# Generated at 2022-06-20 18:02:52.053728
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
	module = AnsibleModule(
		argument_spec = dict()
	)
	#ifconfig_path = self.module.get_bin_path('ifconfig')
	ifconfig_path = "/sbin/ifconfig"

	if ifconfig_path is None:
		#return network_facts
		module.exit_json(changed=False, msg="get_bin_path failed with ifconfig")

	#route_path = self.module.get_bin_path('route')
	route_path = "/sbin/route"

	if route_path is None:
		#return network_facts
		module.exit_json(changed=False, msg="get_bin_path failed with route")

	#default_ipv4, default_ipv6 = self.get_default_interfaces(route_path)
	

# Generated at 2022-06-20 18:03:03.261477
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # This lets us test private method.
    GenericBsdIfconfigNetwork._GenericBsdIfconfigNetwork__populate = GenericBsdIfconfigNetwork.populate.__func__

    # Construct generic command
    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True,
    )

    m_run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = m_run_command

    # Instantiate the Network class to test
    sn = GenericBsdIfconfigNetwork(module)
    sn._GenericBsdIfconfigNetwork__populate(collected_facts=None)
    assert m_run_command.call_count == 2
    assert sn

# Generated at 2022-06-20 18:03:26.721115
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'en0', 'address': '192.168.1.1'}

# Generated at 2022-06-20 18:03:35.692542
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = AnsibleModule({})
    network = GenericBsdIfconfigNetwork(module)

    words = ['em0', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500']
    current_if = network.parse_interface_line(words)

    assert current_if == {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'macaddress': 'unknown', 'metric': '0', 'mtu': '1500'}


# Generated at 2022-06-20 18:03:46.380042
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Mock class options
    class Options:
        def __init__(self):
            self.connection = 'ssh'
            self.module_path = 'test/test_GenericBsdIfconfigNetwork.py'
            self.forks = 10
            self.remote_user = 'test_user'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = None
            self.become_method = None
            self.become_user = None
            self.verbosity = None
            self.check = None
            self.listhosts = None
            self.listtasks = None
            self.listtags = None


# Generated at 2022-06-20 18:03:47.183804
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # TODO: Implement unit test
    pass

# Generated at 2022-06-20 18:03:56.794371
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    """ Unit test for method detect_type_media of class GenericBsdIfconfigNetwork """

    a = GenericBsdIfconfigNetwork()

    interfaces = {
        'eth0': {
            'device': 'eth0',
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown',
            'flags': ['BROADCAST', 'MULTICAST', 'UP'],
            'macaddress': 'unknown',
            'options': [],
            'status': 'active',
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)',
            'lladdr': 'AA:BB:CC:DD:EE:FF'
        }
    }

    b = a.detect_type_media(interfaces)


# Generated at 2022-06-20 18:04:01.470661
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from __main__ import GenericBsdIfconfigNetwork
    obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:04:10.658937
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    words = ['ether', '00:00:11:22:33:44']
    network.parse_unknown_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:00:11:22:33:44'
    assert current_if['type'] == 'ether'
    assert 'all_ipv4_addresses' not in ips
    assert 'all_ipv6_addresses' not in ips


# Generated at 2022-06-20 18:04:16.951052
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
  module = AnsibleModule({})
  g = GenericBsdIfconfigNetwork(module)
  words = 'tunnel inet'.split()
  current_if = dict()
  ips = dict()
  g.parse_tunnel_line(words=words, current_if=current_if, ips=ips)
  assert current_if['type'] == 'tunnel'

# Generated at 2022-06-20 18:04:29.794552
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # Imports
    from units.compat import unittest
    from units.compat.mock import MagicMock, patch
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    # Arrange
    ifconfig_path = '/sbin/ifconfig'
    route_path = '/sbin/route'
    module = MagicMock()
    module.get_bin_path.return_value = '/sbin'
    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'test_out', 'test_err')
    ifconfig_options = '-a'

    # Act
    network = GenericBsdIfconfigNetwork()
    network.module = module
    network.get_interfaces_info = MagicMock()



# Generated at 2022-06-20 18:04:38.174283
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec={})
    words = ['options=eeee', 'ether', 'fe:3f:7c:d6:b8:fb', 'inet', '192.168.1.1', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255']
    current_if = {'device': 'lo0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network = GenericBsdIfconfigNetwork(module)
    network.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['eeee']
    assert len(ips['all_ipv4_addresses']) == 0

# Generated at 2022-06-20 18:05:31.596197
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Prepare test
    defaults = dict()
    interfaces = dict()
    ifconfig_network = GenericBsdIfconfigNetwork()

    # Verify with empty argument.
    ifconfig_network.merge_default_interface(defaults, interfaces, 'ipv4')
    assert len(defaults) == 0
    assert len(interfaces) == 0

    # Verify with ipv6.
    defaults = dict()
    interfaces = dict()
    defaults['interface'] = 'eth0'
    interfaces['eth0'] = {'device': 'eth0', 'ipv4': [], 'ipv6': []}
    ifconfig_network.merge_default_interface(defaults, interfaces, 'ipv6')
    assert len(defaults) == 1
    assert len(interfaces) == 1

    # Verify with interface not in interfaces.


# Generated at 2022-06-20 18:05:36.976537
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    testobj = GenericBsdIfconfigNetwork()
    result = testobj.get_options('<UP,LOOPBACK,RUNNING,MULTICAST>')
    assert ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'] == result


# Generated at 2022-06-20 18:05:47.867832
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    line = "bge0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500 options=9<RXCSUM,VLAN_MTU>"
    words = line.split()
    gbi = GenericBsdIfconfigNetwork()
    current_if = gbi.parse_interface_line(words)
    # test parse_interface_line of class GenericBsdIfconfigNetwork
    assert current_if['device'] == 'bge0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['metric'] == '0'
    assert current_if['mtu'] == '1500'

# Generated at 2022-06-20 18:05:53.290916
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils._text import to_bytes
    subject = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = to_bytes('ether 00:00:00:00:00:00').split()
    subject.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:00:00:00:00:00'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:06:02.172525
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    def test_status_line(status_line, status):
        words = status_line.split()
        current_if = {}
        current_if['macaddress'] = 'unknown'    # will be overwritten later
        network_module = GenericBsdIfconfigNetwork()
        network_module.parse_status_line(words, current_if, {})
        return current_if['status'] == status

    def test_status_line_ex(line, status):
        return test_status_line('status: ' + line, status)

    assert(test_status_line_ex('active', 'active'))
    assert(test_status_line_ex('inactive', 'inactive'))

# Generated at 2022-06-20 18:06:14.320737
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    net_facts = {}
    network = GenericBsdIfconfigNetwork()
    network.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)'],
                             net_facts, None)
    assert net_facts['media'] == 'Ethernet'
    assert net_facts['media_select'] == 'autoselect'
    assert net_facts['media_type'] == '(1000baseT)'
    assert 'media_options' not in net_facts

    network.parse_media_line(['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active'],
                             net_facts, None)
    assert net_facts['media_options'] == ['status:', 'active']


# Generated at 2022-06-20 18:06:24.232708
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {'all_ipv4_addresses':[],'all_ipv6_addresses':[]}
    words = ['status:', 'active']
    network.parse_status_line(words, current_if, ips)
    assert 'status' in current_if
    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:06:33.882721
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    def test_parse_inet6_line(obj, words, current_if, ips, address):
        obj.parse_inet6_line(words, current_if, ips)
        assert ips['all_ipv6_addresses'][0] == address

    # Test1
    obj = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(all_ipv6_addresses=[])
    words = ['inet6', 'fe80::a00:27ff:fe26:f313%em0', 'prefixlen', '64', 'scopeid', '0x1']
    address = 'fe80::a00:27ff:fe26:f313'
    test_parse_inet6_line(obj, words, current_if, ips, address)

    # Test2
    obj

# Generated at 2022-06-20 18:06:44.459368
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})
    bsd_ifconfig_plugin = GenericBsdIfconfigNetwork(module)
    assert('all_ipv4_addresses' in bsd_ifconfig_plugin.populate())
    assert('all_ipv6_addresses' in bsd_ifconfig_plugin.populate())
    assert('interfaces' in bsd_ifconfig_plugin.populate())


# Generated at 2022-06-20 18:06:49.888818
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:08:42.063285
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    ifc = GenericBsdIfconfigNetwork()

    # *BSD

# Generated at 2022-06-20 18:08:50.523437
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    '''
    unit test for class GenericBsdIfconfigNetwork
    '''
    print("test_GenericBsdIfconfigNetwork()")
    obj = GenericBsdIfconfigNetwork({})
    if obj:
        print("GenericBsdIfconfigNetwork() instantiated")
    else:
        print("GenericBsdIfconfigNetwork() not instantiated")

# Generated at 2022-06-20 18:09:04.474759
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # setup
    current_if = dict()
    ips = dict(all_ipv6_addresses=[])
    obj = GenericBsdIfconfigNetwork()

    # Test case 1
    words = ['inet6', '::1', 'prefixlen', '128', '0x1', 'lo0']
    obj.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == '::1'

    # Test case 2
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'lo0']
    obj.parse_inet6_line(words, current_if, ips)

# Generated at 2022-06-20 18:09:05.785347
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # TODO: need a real test for this method
    pass
