

# Generated at 2022-06-20 17:59:43.597068
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    n = GenericBsdIfconfigNetwork()

    current_if = {'device': 'device', 'type': 'unknown', "ipv4": []}

    words = ['tunnel', 'inet6', '2001:db8::1', 'prefixlen', '64']
    n.parse_tunnel_line(words, current_if, None)

    assert 'unknown' == current_if['type']



# Generated at 2022-06-20 17:59:53.457393
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    mac_words = ["options=289<RXCSUM,TXCSUM,VLAN_MTU,JUMBO_MTU,TSO4,TSO6,LRO>"]
    temp_current_if = dict(macaddress="00:00:00:00:00:00", type="unknown")
    queobj = Queue()
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(queobj)
    generic_bsd_ifconfig_network.parse_options_line(mac_words, temp_current_if, dict())
    assert temp_current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU', 'JUMBO_MTU', 'TSO4', 'TSO6', 'LRO']

# Generated at 2022-06-20 17:59:55.653162
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = sys.modules['ansible.module_utils.facts.network.generic_bsd_ifconfig']
    pass


# Generated at 2022-06-20 18:00:10.226007
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test the method detect_type_media of GenericBsdIfconfigNetwork
    # This test will only pass on platforms that support ethernet
    # devices.
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:00:19.305607
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ip = '2001:db8:0:f101::1'
    prefix = '64'
    scope = '0x4'
    result_1 = GenericBsdIfconfigNetwork.parse_inet6_line(['inet6', ip+'/'+prefix, 'prefixlen', prefix, 'scopeid', scope, '0x4'])
    result_2 = GenericBsdIfconfigNetwork.parse_inet6_line(['inet6', ip + '/' + prefix])

    expected_1 = dict(address={'address': ip, 'prefix': prefix, 'scope': scope})
    expected_2 = dict(address={'address': ip, 'prefix': prefix})

    assert result_1 == expected_1
    assert result_2 == expected_2


# Generated at 2022-06-20 18:00:30.616958
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {}
    current_if['ipv6'] = []
    ips = dict(
        all_ipv6_addresses=[],
    )

    ifconfig_network.parse_inet6_line(['inet6', '2620:9b::1c18:f493', 'prefixlen', '64', 'scopeid',
                                       '0xe'], current_if, ips)

    assert current_if['ipv6'][0]['address'] == '2620:9b::1c18:f493'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0xe'

# Generated at 2022-06-20 18:00:42.694265
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    Unit test function for method parse_inet6_line of class GenericBsdIfconfigNetwork.
    :return:
    """

    # Unit test for parse_inet6_line method of class GenericBsdIfconfigNetwork
    # Using the following input and expected output

    # Input

    #words = ['inet6', '2002::1/64', 'prefixlen', '64', 'scopeid', '0x5', 'inet6', '2002::3/64', 'prefixlen', '64', 'scopeid', '0x10']

    # Expected output

    #current_if['ipv6'] = [{'address': '2002::1/64'}, {'address': '2002::3/64'}]

    current_if = dict(ipv6=[])  # initialize the dictionary

# Generated at 2022-06-20 18:00:53.215198
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule({})
    bsd_network = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-20 18:01:04.557283
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test value of defaults dict is updated by merge_default_interface method
    fw = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0',
                'gateway'  : '192.168.0.1'}
    ifaces = {'lo0': {'ipv4': [{'address': '192.168.1.1'}],
                       'ipv6': [{'address': 'fd00::6db:c6ff:fe6c:b6d4'}],
                       'macaddress': '00:00:00:00:00:00'}}
    fw.merge_default_interface(defaults, ifaces, 'ipv4')
    assert defaults['gateway'] == '192.168.0.1'

# Generated at 2022-06-20 18:01:14.680673
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    netfacts = GenericBsdIfconfigNetwork({})
    netfacts.get_all_interfaces = MagicMock(return_value=['eth0', 'eth1', 'lo'])

# Generated at 2022-06-20 18:01:32.794936
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    '''
    Test cases for how the class GenericBsdIfconfigNetwork handles multiple IP
    addresses.  We want to ensure that the code can handle IPv6, as well as
    the more common IPv4 address types.
    '''
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.network.common.utils import dict_merge

    # Example output from the ifconfig command with multiple iNet addresses

# Generated at 2022-06-20 18:01:40.377584
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    genericBSDIfconfig = GenericBsdIfconfigNetwork()

    # ipV4 list
    ipv4List = [
        "127.0.0.1/24",
        "10.10.10.100/24",
        "10.10.10.128/25",
        "172.16.7.0/24"
    ]
    # ipV4 expected result

# Generated at 2022-06-20 18:01:47.214936
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_instance = GenericBsdIfconfigNetwork()

    test_data = [
        ('<LOOPBACK,MULTICAST>', ['LOOPBACK', 'MULTICAST']),
        ('<LOOPBACK, MULTICAST>', ['LOOPBACK', 'MULTICAST']),
        ('not in brackets', []),
        ('<noEndBracket', []),
        ('noStartBracket>', []),
        ('noBrackets', []),
        ('<>', []),
        ('<noData>', []),
        ('<noData,>', ['noData']),
        ('<,noData>', ['noData']),
        ('<noData, noData>', ['noData', 'noData']),
    ]


# Generated at 2022-06-20 18:02:00.426214
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    net = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:02:09.039928
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = 0, '', ''

    gbn = GenericBsdIfconfigNetwork(module)

    assert gbn.platform == 'Generic_BSD_Ifconfig'
    assert repr(gbn) == "<GenericBsdIfconfigNetwork(platform='Generic_BSD_Ifconfig')>"


# Generated at 2022-06-20 18:02:14.636119
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    network_facts = GenericBsdIfconfigNetwork()
    line = "lladdr 00:00:24:d9:a3:3b"
    current_if = {}
    ips = {}
    network_facts.parse_lladdr_line(line.split(), current_if, ips)
    assert current_if['lladdr'] == "00:00:24:d9:a3:3b"


# Generated at 2022-06-20 18:02:26.486668
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:02:32.106553
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    x = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '6.5.4.3', '-->', '7.8.9.10', 'netmask', '0xffffff00']
    current_if = {'device': 'tun0'}
    ips = {}
    x.parse_tunnel_line(words, current_if, ips)
    assert (current_if == {'device': 'tun0', 'ipv4': [], 'ipv6': [], 'type': 'tunnel'})
    assert (ips == {})


# Generated at 2022-06-20 18:02:35.391891
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    GenericBsdIfconfigNetwork().parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>',
                                                      'metric', '0', 'mtu', '33184'])


# Generated at 2022-06-20 18:02:36.893322
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test = GenericBsdIfconfigNetwork(module)
    result = test.populate(collected_facts=None)
    assert(result)

# Generated at 2022-06-20 18:03:04.016423
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    m = GenericBsdIfconfigNetwork()
    words =['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'ether', '00:04:23:81:19:28', 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'media:', 'Ethernet', 'autoselect', '(100baseTX', '<full-duplex>)', 'status:', 'active', '']
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-20 18:03:11.553596
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    # FreeBSD style
    m = GenericBsdIfconfigNetwork()
    iface = m.parse_interface_line(['lo0', ':', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384'])
    assert iface['device'] == 'lo0'
    assert iface['metric'] == '0'
    assert iface['mtu'] == '16384'
    assert iface['type'] == 'loopback'

    # NetBSD style
    iface = m.parse_interface_line(['lo0', 'at', 'lladdr', '00:00:00:00:00:00', 'media:', 'loop', 'status:', 'active'])
    assert iface['device'] == 'lo0'
   

# Generated at 2022-06-20 18:03:23.885835
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    values = dict(
        current_if={'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
        ips=dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[]
        )
    )
    # Test ipv4
    line = 'inet 127.0.0.1 netmask 0xff000000'
    words = line.split()
    GenericBsdIfconfigNetwork().parse_inet_line(words, values['current_if'], values['ips'])
    assert len(values['current_if']['ipv4']) != 0

    values['current_if']['ipv4'] = []

# Generated at 2022-06-20 18:03:34.514881
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """
    Test method `GenericBsdIfconfigNetwork.parse_nd6_line()`
    """
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.generic.net_tools.ifconfig import GenericBsdIfconfigNetwork
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import obj_without_key

    # DUT
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()

    # SUT
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    # given

# Generated at 2022-06-20 18:03:44.896042
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    "GenericBsdIfconfigNetwork - get_options()"
    test_pairs = {
        '': [],
        '<>': [],
        '<UP>': ['UP'],
        '<UP,BROADCAST>': ['UP', 'BROADCAST'],
        '<UP,BROADCAST,RUNNING>': ['UP', 'BROADCAST', 'RUNNING'],
        '<UP,BROADCAST,RUNNING>:': ['UP', 'BROADCAST', 'RUNNING'],
    }

    for option_string, result in test_pairs.items():
        obj = GenericBsdIfconfigNetwork()
        assert obj.get_options(option_string) == result



# Generated at 2022-06-20 18:03:55.288877
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:04:02.039018
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_dict = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    input_words = ['status:', 'active']
    assert generic_bsd_ifconfig_network.parse_status_line(input_words, current_dict, {})


# Generated at 2022-06-20 18:04:10.326772
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    fname = 'test_GenericBsdIfconfigNetwork_merge_default_interface'
    param_defs = {
        'run_command': {
            'default': fname + '.run_command'
        }
    }

# Generated at 2022-06-20 18:04:20.159402
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    net = GenericBsdIfconfigNetwork()
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', 'bc:30:5b:46:d5:0b']
    net._GenericBsdIfconfigNetwork__parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'bc:30:5b:46:d5:0b'
    assert current_if['type'] == 'ether'

# Generated at 2022-06-20 18:04:32.249738
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    genbsd = GenericBsdIfconfigNetwork(dict())

    words = ['fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    current_if = {
        'device': 'lo0',
        'flags': [],
        'ipv4': [],
        'ipv6': [],
        'macaddress': 'unknown',
        'mtu': 33184,
        'type': 'unknown'
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    genbsd.parse_unknown_line(words, current_if, ips)
    assert current_if

# Generated at 2022-06-20 18:05:02.013967
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
  netutils = GenericBsdIfconfigNetwork()
  defaults = {'interface': 'em0'}
  interfaces = {'em0': {'device': 'em0', 'ipv4': [{'address': '192.168.1.1'}], 'ipv6': [{'address': '2001:123:123:123::1'}]}}
  netutils.merge_default_interface(defaults, interfaces, 'ipv4')
  assert defaults == {'interface': 'em0', 'address': '192.168.1.1', 'device': 'em0', 'ipv4': [{'address': '192.168.1.1'}], 'ipv6': [{'address': '2001:123:123:123::1'}]}

# Generated at 2022-06-20 18:05:10.126500
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = type('', (), {})()
    module.check_mode = False

    gb = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = {}

    gb.parse_tunnel_line(['tunnel', 'inet', 'inet6', '10.10.10.1', 'prefixlen', '64', '10.10.10.2', 'prefixlen', '64', 'mtu', '1460'], current_if, ips)

    assert current_if['type'] == 'tunnel'

    # TODO: expand this...
    #assert current_if['tunnel'] == 'inet6'
    #assert current_if['inet'] == '10.10.10.1'
    #assert current_if['inet6'] == '10.10.10.2'
   

# Generated at 2022-06-20 18:05:21.653066
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:05:29.652869
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    ifcfg = GenericBsdIfconfigNetwork()
    current_if = {'device':'em0'}
    ips = {}
    ifcfg.parse_lladdr_line(['lladdr', '8c:70:5a:f2:4a:a8'],  current_if, ips)
    ifcfg.parse_lladdr_line(['lladdr', '8c:70:5a:f2:4a:a9'],  current_if, ips)
    assert '8c:70:5a:f2:4a:a9' == current_if['lladdr']



# Generated at 2022-06-20 18:05:39.136519
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    interface = {}
    ips = {}
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    generic_bsd_ifconfig_network.parse_media_line(words, interface, ips)
    assert interface == {
        'media': 'Ethernet',
        'media_select': 'autoselect',
        'media_type': '(1000baseT)',
        'media_options': [],
    }


# Generated at 2022-06-20 18:05:42.072844
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    assert True, 'TODO: write some tests'



# Generated at 2022-06-20 18:05:53.633307
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    platform_info.collect_platform_facts(module)

    if platform_info.system != 'GenericBSD':
        # Test only makes sense on non-Linux platform
        module.fail_json(msg="test_GenericBsdIfconfigNetwork_get_default_interfaces test on non-GenericBSD platform")

    # Monkey patch the route command output.
    def route_call(*args, **kwargs):
        if args[0] == ['/sbin/route', '-n', 'get', 'default']:
            return 0, "interface: en0\ngateway: fe80::a00:27ff:fe9a:49b2%en0\n", None

# Generated at 2022-06-20 18:06:02.768505
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()


# Generated at 2022-06-20 18:06:13.222639
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    network_facts = GenericBsdIfconfigNetwork(module).populate()
    assert network_facts['default_ipv4']['gateway'] == '192.168.1.1'
    assert network_facts['default_ipv4']['interface'] == 'en0'
    assert network_facts['default_ipv6']['interface'] == 'en0'
    assert 'fe80::dead:beef:dead:beef' in network_facts['all_ipv6_addresses']


# Generated at 2022-06-20 18:06:20.723767
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_mock_data = {}

# Generated at 2022-06-20 18:06:59.653199
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    class TestNetwork:
        def __init__(self):
            self.interfaces = dict()

        def parse_inet_line(self, words, current_if, ips):
            self.interfaces[current_if['device']] = current_if

    # Test 1 - generic input
    test_class = TestNetwork()
    iface = dict(
        device='lo0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        flags='UP,LOOPBACK,RUNNING,MULTICAST',
        macaddress='unknown',
        metric='0',
        mtu='33184',
    )

# Generated at 2022-06-20 18:07:11.777841
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    g = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:07:21.464505
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    # Test case with proper media line
    words = ['media:', 'Ethernet', 'auto', '(100baseTX)', 'status:', 'active']
    ifconfig_network.parse_media_line(words, current_if, ips)
    expected_output = {'media': 'Ethernet', 'media_select': 'auto', 'media_type': '100baseTX', 'media_options': []}
    assert current_if == expected_output

    # Test case with proper media line and extra words
    current_if = {}
    words = ['media:', 'Ethernet', 'auto', '(100baseTX)', 'status:', 'active', 'test', 'test']
    ifconfig_network.parse_

# Generated at 2022-06-20 18:07:30.197503
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = MockedModule()

    route_cmd = ['/sbin/route', '-n', 'get', 'default']
    route_6_cmd = ['/sbin/route', '-n', 'get', '-inet6', 'default']

    default_ipv4_output = '''destination: default
    interface:
    gateway:
    flags:<UP,GATEWAY,DONE,STATIC,PRCLONING>
    recvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire
    0         0         0         0           0       0             0       0
'''


# Generated at 2022-06-20 18:07:39.053121
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(argument_spec=dict(
        ansible_ifconfig=dict(type='path', required=False),
        ansible_route=dict(type='path', required=False),
    ))
    module.exit_json(ansible_facts={
        'ansible_network_resources': GenericBsdIfconfigNetwork().populate()
    })


# Generated at 2022-06-20 18:07:50.530248
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    def mock_ansible_module(**kwargs):
        m_ansible = MagicMock(AnsibleModule)
        m_ansible.params = kwargs
        return m_ansible

    def mock_send_message(message):
        print(message)

    # Initialize test variables
    current_if = dict()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['ether', '3f:da:49:5b:79:36']
    current_if['macaddress'] = 'unknown'
    expected_current_if = dict(current_if)
    expected_current_if['macaddress'] = '3f:da:49:5b:79:36'

# Generated at 2022-06-20 18:07:55.041546
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module_name = "ansible_collections.ansible.netcommon.tests.unit.modules.network.generic.test_ansible_module"
    test_overrides = {'module_utils.module_runner': None}

#   Run the test
    test_utils.run_unit_test(GenericBsdIfconfigNetwork, module_name, test_overrides)

# Generated at 2022-06-20 18:08:00.460786
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_test = GenericBsdIfconfigNetwork()
    words = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184"
    current_if = generic_bsd_test.parse_interface_line(words.split())
    assert current_if['device'] == 'lo0'
    assert len(current_if['ipv4']) == 0
    assert len(current_if['ipv6']) == 0


# Generated at 2022-06-20 18:08:11.802935
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(None)
    generic_bsd_ifconfig_network.parse_ether_line(['ether', '00:88:89:00:00:02'], {'device': 'igb0'}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    generic_bsd_ifconfig_network.parse_ether_line(['ether', '00:88:89:00:00:02'], {'device': 'igb0', 'macaddress': 'unknown'}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

# Generated at 2022-06-20 18:08:20.857073
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gbin = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '10.1.1.1', '-->', '10.1.1.2', 'netmask', '0xffffffff', 'groups:', 'tun']
    current_if = {}
    ips = {}
    gbin.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'


# Generated at 2022-06-20 18:09:03.064795
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    GenericBsdIfconfigNetwork._populate()
    # assert False # TODO: implement your test here
