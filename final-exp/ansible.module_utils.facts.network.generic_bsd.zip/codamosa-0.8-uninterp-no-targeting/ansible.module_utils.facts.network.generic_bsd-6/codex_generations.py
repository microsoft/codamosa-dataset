

# Generated at 2022-06-20 17:59:51.535098
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    data = {
        'current_if': {},
        'ips': {}
    }
    pattern = r'^(?!inet6|inet|lladdr|tunnel|status|media|options|ether|nd6|pass)^(\S+)\s'
    data = plugin._test_parse_lines(pattern, GenericBsdIfconfigNetwork, 'parse_unknown_line', data)

# Generated at 2022-06-20 18:00:00.770145
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    from ..module_utils.network.common.network import GenericBsdIfconfigNetwork

    test_module = GenericBsdIfconfigNetwork()

    interfaces = dict()
    interfaces['eth0'] = dict(device='eth0', ipv4=[], ipv6=[], macaddress='00:00:00:00:00:00', type='ether', mtu=1500)

    all_ipv4_addresses, all_ipv6_addresses = [], []

    def_interface = dict(interface='eth0', address='172.20.0.2', broadcast='172.20.255.255', gateway='172.20.0.1')

    test_module.merge_default_interface(def_interface, interfaces, 'ipv4')

    assert 'device' in def_interface
    assert 'ipv4' in def_interface

# Generated at 2022-06-20 18:00:03.234926
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # TODO
    pass

# Generated at 2022-06-20 18:00:15.935120
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Test creation of class
    gd = GenericBsdIfconfigNetwork()
    # Test netbsd
    # Test OpenBSD and Mac
    data = "le0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n"
    data += "        options=189b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,VLAN_HWFILTER>\n"
    data += "        ether 00:06:5b:5d:e5:7f\n"
    data += "        nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>\n"
    words

# Generated at 2022-06-20 18:00:23.146846
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    os.environ['PATH'] = '/sbin:/usr/sbin'
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    default_ipv4, default_ipv6 = generic_bsd_ifconfig_network.get_default_interfaces('/sbin/route')
    assert default_ipv4['interface'] == 'lo0', 'interface name is not "lo0"'
    assert default_ipv4['gateway'] == '127.0.0.1', 'gateway is not "127.0.0.1"'
    assert default_ipv4['address'] == '127.0.0.1', 'address is not "127.0.0.1"'


# Generated at 2022-06-20 18:00:33.693603
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Creating a mock module for testing
    with pytest.raises(SystemExit):
        set_module_args({})

    module = AnsibleModule(argument_spec={})

    # Creating a mock network class for testing
    network_obj = GenericBsdIfconfigNetwork(module)

    # Creating test args
    words = ["lo0:", "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>", "metric", "0",
             "mtu", "16384", "options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>"]


# Generated at 2022-06-20 18:00:40.024121
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    mock_module = MagicMock()
    mock_network = GenericBsdIfconfigNetwork(mock_module)


# Generated at 2022-06-20 18:00:44.960320
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec=dict())
    generic_network = GenericBsdIfconfigNetwork(module)
    assert (generic_network is not None)


# Generated at 2022-06-20 18:00:54.093593
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    ifcfg = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:01:04.823625
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network = GenericBsdIfconfigNetwork()
    collected_facts = {}
    network.module = AnsibleModuleMock()
    network.module.run_command = MagicMock(return_value=('0','','',0))
    network.module.get_bin_path = MagicMock(return_value="/usr/local/bin")
    result=network.populate()

# Generated at 2022-06-20 18:01:24.052855
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    class MockModule:
        pass

    mod = MockModule()


# Generated at 2022-06-20 18:01:28.378829
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = MockedModule()
    n = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}

    n.parse_options_line(['options=3<RXCSUM,TXCSUM>'], current_if, ips)

    assert current_if['options'] == ['RXCSUM', 'TXCSUM']


# Generated at 2022-06-20 18:01:38.696218
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    line = "  enc0: flags=0<>  "
    words = line.split()
    interface = {}
    ips = {}
    expected_interface = {"device": "enc0",
                          "ipv4": [],
                          "ipv6": [],
                          "type": "unknown",
                          "flags": [],
                          "macaddress": "unknown"}
    expected_ips = {"all_ipv4_addresses": [], "all_ipv6_addresses": []}
    net = GenericBsdIfconfigNetwork()
    net.parse_unknown_line(words, interface, ips)
    assert interface == expected_interface
    assert ips == expected_ips



# Generated at 2022-06-20 18:01:51.159413
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    current_if = {}
    ips = {}
    ifconfig_network = GenericBsdIfconfigNetwork()
    # Test if no option
    words = ["options="]
    ifconfig_network.parse_options_line(words, current_if, ips)
    assert current_if['options'] == []
    # Test if having single option
    words = ["options=1"]
    ifconfig_network.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['1']
    # Test if having multiple options
    words = ["options=1,2,3"]
    ifconfig_network.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['1', '2', '3']



# Generated at 2022-06-20 18:02:01.369152
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Create GenericBsdIfconfigNetwork object
    gen_obj = GenericBsdIfconfigNetwork()

    # Create iface object
    test_list = ['lo0:', 'flags', '=', '8049', '<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    interfaces = gen_obj.parse_interface_line(test_list)
    assert interfaces['device'] == 'lo0'
    assert interfaces['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert interfaces['mtu'] == '33184'
    assert interfaces['type'] == 'loopback'


# Generated at 2022-06-20 18:02:14.044013
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    passthrough_args = dict(
        module = mock.MagicMock(return_value=None),
        module_class = None
    )
    gn = GenericBsdIfconfigNetwork(**passthrough_args)

    words = ['tunnel', 'inet', '10.1.1.1', '-->', '10.2.2.2', 'netmask', '0xffffff00', 'tunid', '1']
    current_if = {'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )

    gn.parse_tunnel_line(words=words, current_if=current_if, ips=ips)


# Generated at 2022-06-20 18:02:23.634918
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule({
        "collected_facts": {
            "interfaces": {
                "en0": {
                    "device": "en0",
                    "media": "media: autoselect (100baseTX <full-duplex>)",
                    "media_select": "(100baseTX <full-duplex>)",
                    "media_type": "<full-duplex>",
                    "mtu": 1500,
                    "status": "active",
                    "type": "ether",
                },
                "lo0": {
                    "device": "lo0",
                    "flags": ["UP", "LOOPBACK", "RUNNING", "MULTICAST"],
                    "mtu": 16384,
                    "type": "loopback",
                },
            },
        },
    })
    network = GenericBsdIfconfig

# Generated at 2022-06-20 18:02:27.874049
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    facts = GenericBsdIfconfigNetwork({})
    words = facts.parse_lladdr_line(['lladdr', '2:8:20:49:66:d6'], {}, {})
    assert words['lladdr'] == '2:8:20:49:66:d6'



# Generated at 2022-06-20 18:02:33.947076
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    class GenericBsdIfconfigNetwork_test(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            pass
    gn = GenericBsdIfconfigNetwork_test(None)
    current_if = {}
    ips = {}
    # media
    line = "media: Ethernet autoselect (100baseTX <full-duplex>)"
    gn.parse_media_line(line.split(), current_if, ips)
    assert current_if['media'] == 'Ethernet', 'Media type should be Ethernet'
    assert current_if['media_select'] == 'autoselect', 'Media select should be autoselect'
    assert current_if['media_type'] == 'full-duplex', 'Media type should be full-duplex'

# Generated at 2022-06-20 18:02:39.022925
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    eut = GenericBsdIfconfigNetwork()
    # Test for ether option set in ifconfig output
    words = ['en7','ether','1c:ab:a7:37:4d:6b']
    current_if = {'device': 'en7', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    eut.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '1c:ab:a7:37:4d:6b'
    assert current_if['type'] == 'ether'
    # Test for ether option not set in ifconfig output

# Generated at 2022-06-20 18:03:24.966072
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:03:35.134207
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    Words = namedtuple('Words', ['words'])

    n = GenericBsdIfconfigNetwork(module)
    current_if = {'ipv4': []}
    ips = dict(all_ipv4_addresses=[])

    with open(os.devnull, "w") as fnull:
        saved_stderr = sys.stderr
        sys.stderr = fnull

        if os.name == 'posix':
            n.run_command = lambda cmd: dict(rc=0, stdout="", stderr="")

# Generated at 2022-06-20 18:03:38.652480
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    gbifnet = GenericBsdIfconfigNetwork({})
    words = ['tunnel', 'inet', '10.0.0.2', '-->', '10.0.0.1']
    current_if = {}
    ips = {}
    gbifnet.parse_tunnel_line(words, current_if, ips)
    assert 'type' in current_if
    assert current_if['type'] == 'tunnel'



# Generated at 2022-06-20 18:03:46.993081
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Test Parse nd6 line
    facts = GenericBsdIfconfigNetwork()
    words = ["nd6", "options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>", "media:", "Ethernet", "autoselect", "(100baseTX)", "status:", "active"]
    current_if = {}
    ips = {}
    facts.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ["PERFORMNUD", "IFDISABLED", "AUTO_LINKLOCAL"]


# Generated at 2022-06-20 18:03:56.674846
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    # This is the output of the command: ifconfig lo0
    line = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'
    ifc = GenericBsdIfconfigNetwork()
    interface_info = ifc.parse_interface_line(line.split())

    assert interface_info['device'] == 'lo0'
    assert interface_info['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert interface_info['mtu'] == '16384'

    # This is the output of the command: ifconfig lo0
    line = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>\tmetric 0 mtu 16384'
    ifc = GenericBsd

# Generated at 2022-06-20 18:04:07.152674
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_bsd_net = GenericBsdIfconfigNetwork()
    current_if = {}
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    if 'media' not in current_if:
        current_if['media'] = words[1]
    if len(words) > 2:
        current_if['media_select'] = words[2]
    if len(words) > 3:
        current_if['media_type'] = words[3][1:]
    if len(words) > 4:
        current_if['media_options'] = generic_bsd_net.get_options(words[4])

    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select']

# Generated at 2022-06-20 18:04:19.459789
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    class MockModule(object):
        def run_command(self, module_cmd):
            return 0, "", ""

        def get_bin_path(self, module_cmd):
            return "/bin/cmd"

    class MockNetwork(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            self.module = module

    platform = 'FreeBSD'
    module = MockModule()
    network_facts = MockNetwork(module)
    # Here we are just testing the method parse_media_line() for FreeBSD.
    # To support Solaris, NetBSD as well, we need to update this test case
    # for other platforms.
    interfaces, ips = network_facts.get_interfaces_info(
        "/bin/cmd", ifconfig_options="-a")


# Generated at 2022-06-20 18:04:31.441899
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = ansible_module_mock('GenericBsdIfconfigNetwork', 'options=')
    expected = {'options': ['options']}
    assert_equal(m.parse_options_line(['options='], {}, {}), expected)
    assert_equal(m.parse_options_line(['options=1'], {}, {}), expected)
    assert_equal(m.parse_options_line(['options=1,'], {}, {}), expected)
    expected = {'options': ['options', '1']}
    assert_equal(m.parse_options_line(['options=1,2'], {}, {}), expected)
    assert_equal(m.parse_options_line(['options=1,2,'], {}, {}), expected)


# Generated at 2022-06-20 18:04:39.122357
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    network_cls = Network(module)

    test_cases = [
        ('', ''),
        ('<>', ''),
        ('<FLAGS>', ''),
        ('<FLAGS,1,2,3>', ['FLAGS', '1', '2', '3']),
        ('< FLAGS , 1 , 2,3 , >', ['FLAGS', '1', '2', '3']),
    ]

    for option_string, expected_options in test_cases:
        options = network_cls.get_options(option_string)

        assert options == expected_options, \
            'Got %s, expecting %s' % (options, expected_options)


# Generated at 2022-06-20 18:04:50.414379
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Create an instance of GenericBsdIfconfigNetwork
    # method parse_interface_line
    G_B_I_N = GenericBsdIfconfigNetwork()
    current_if = G_B_I_N.parse_interface_line([
        'vswitch0:',
        'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>',
        'metric', '0',
        'mtu', '1500'
    ])
    current_if['status'] = ''
    # method parse_status_line
    G_B_I_N.parse_status_line(['status', 'active'], current_if, {})
    assert current_if['status'] == 'active'



# Generated at 2022-06-20 18:05:56.576464
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # mock a module with a run command
    module = Mock(run_command=Mock(return_value=(0, '', '')))
    mock_module = Mock(module_utils.basic.AnsibleModule(argument_spec={},
                                                        supports_check_mode=True))
    network = GenericBsdIfconfigNetwork(mock_module)

    # mock current_if and ips
    current_if = {}
    ips = {}

    # Mock words
    words = []

    # run parse_unknown_line
    network.parse_unknown_line(words, current_if, ips)

    # assert parse_unknown_line is working as expected
    assert current_if == {}
    assert ips == {}

# Generated at 2022-06-20 18:06:04.956910
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    import platform
    import glob
    import hashlib
    import shutil
    import sys
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    os_info = {'distribution': platform.system().lower(),
               'os_family': 'BSD'}

    # create temporary files and directories
    temp_dir = tempfile.mkdtemp()
    temp_stdout_path = tempfile.mkstemp(prefix='ansible_m_b_ut_stdout_', dir=temp_dir)

# Generated at 2022-06-20 18:06:14.201878
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-20 18:06:26.894935
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min']),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )

    network = GenericBsdIfconfigNetwork(module)

    # pull in the test data
    base_dir = os.path.dirname(__file__)

# Generated at 2022-06-20 18:06:34.755657
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = dict(
        interface1 = dict(
            media = 'Ether',
        ),
        interface2 = dict(
            media = 'SPI',
        ),
    )

    expected = dict(
        interface1 = dict(
            type = 'ether',
            media = 'Ether',
        ),
        interface2 = dict(
            type = 'unknown',
            media = 'SPI',
        ),
    )

    gen_bsd = GenericBsdIfconfigNetwork()
    result = gen_bsd.detect_type_media(interfaces)

    assert result == expected


# Generated at 2022-06-20 18:06:37.154526
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # TODO: implement this unit test.
    pass


# Generated at 2022-06-20 18:06:48.796097
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    class _module:
        def __init__(self):
            self.params = dict()

        def get_option(self, s):
            return self.params.get(s)

        def fail_json(self, *args, **kwargs):
            pass

    platform = 'Generic_BSD_Ifconfig'
    # create a clean object to test
    gb = GenericBsdIfconfigNetwork(platform)

    # create a test class to pass a params dictionary
    test_module = _module()
    gb.module = test_module
    # configure the object for a specific test
    test_module.params = {
        'path': '/sbin'
    }
    test_interface = dict()
    test_interface['device'] = 'lo0'
    test_interface['type'] = 'unknown'

# Generated at 2022-06-20 18:07:00.526951
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    test_object = GenericBsdIfconfigNetwork()

# Generated at 2022-06-20 18:07:07.579874
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    generic = GenericBsdIfconfigNetwork()
    words = [
        'description',
        '"test-description"'
    ]
    iface = dict()
    ips = dict()
    generic.parse_unknown_line(words, iface, ips)
    assert iface['description'] == words[1]



# Generated at 2022-06-20 18:07:19.504380
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Test with a line that do not have "alias" (no dibilties)
    words = [
        'lo0',
        'inet',
        '127.0.0.1',
        'netmask',
        '0xff000000',
        'group',
        'local'
    ]
    current_if = {
        'device': 'lo0',
        'type': 'loopback',
        'macaddress': 'unknown',
        'metric': None,
        'mtu': '33184',
        'options': [
            'LOOPBACK',
            'RUNNING',
            'MULTICAST'
        ],
        'ipv4': [],
        'ipv6': []
    }