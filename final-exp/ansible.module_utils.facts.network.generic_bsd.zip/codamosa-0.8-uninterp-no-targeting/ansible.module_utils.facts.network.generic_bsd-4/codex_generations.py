

# Generated at 2022-06-20 17:59:38.624423
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # test for multiple ipv4 address
    current_if = {}
    ips = {}
    address = {'address': "192.168.1"}
    words = ["lladdr", "00:11:22:33:44:55"]
    network_module = GenericBsdIfconfigNetwork()
    network_module.parse_lladdr_line(words, current_if, ips)
    assert current_if == {"macaddress": "00:11:22:33:44:55"}



# Generated at 2022-06-20 17:59:43.382317
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec=dict(options=dict(type='list')))
    check_input = ['status: active']
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    # Valid Status
    network.parse_status_line(check_input, current_if, ips)
    assert current_if['status'] == 'active'
    # Invalid Status
    check_input = ['status: deactive']
    network.parse_status_line(check_input, current_if, ips)
    assert current_if['status'] != 'deactive'
    assert current_if['status'] == 'active'


# Generated at 2022-06-20 17:59:56.291815
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible.module_utils.facts.system.network import GenericBsdIfconfigNetwork
    found_string=False
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words=['blah', 'blahblah']
    expected_current_if = {'blah': 'blahblah'}

    # run the code
    GenericBsdIfconfigNetwork.parse_unknown_line(words, current_if, ips)

    # check the current_if dictionary
    for word in words:
        if word in current_if:
            found_string = True
        else:
            found_string = False

    assert found_string == True
    assert current_if['blah'] == expected_current_

# Generated at 2022-06-20 18:00:09.560355
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec=dict())
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network = GenericBsdIfconfigNetwork(module)
    words = ['ether', '12:34:56:78:9a:bc']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '12:34:56:78:9a:bc'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-20 18:00:14.111250
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    mt = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '10.20.30.40', '-->', '42.42.42.42']
    current_if = {}
    mt.parse_tunnel_line(words, current_if, {})
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-20 18:00:23.146665
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    import platform


# Generated at 2022-06-20 18:00:33.612347
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()

    defaults_v4 = {
        "interface": "lo0",
        "gateway": "127.0.0.1",
    }


# Generated at 2022-06-20 18:00:36.242445
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    GenericBsdIfconfigNetwork.get_interfaces_info("ifconfig")



# Generated at 2022-06-20 18:00:41.707822
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    line = 'ether aa:bb:cc:dd:ee:ff'
    line_split = line.split(' ')
    network_facts = GenericBsdIfconfigNetwork()
    network_facts.parse_ether_line(line_split, {}, {})
    assert line_split[1] == 'aa:bb:cc:dd:ee:ff'
    assert line_split[1] == line_split[1]

# Generated at 2022-06-20 18:00:49.463428
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_class = GenericBsdIfconfigNetwork()

    # Test 1:
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    test_class.parse_media_line(words, current_if, ips)
    expected_result = {
        'type': 'unknown',
        'macaddress': 'unknown',
        'media': 'Ethernet',
        'media_select': 'autoselect',
        'media_type': '1000baseT',
    }
    assert expected_result == current_if

    # Test 2:
    current_if = {}

# Generated at 2022-06-20 18:01:23.190471
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    n = GenericBsdIfconfigNetwork()
    option_string = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    assert n.get_options(option_string) == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-20 18:01:32.721354
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_network_facts = GenericBsdIfconfigNetwork()
    current_if = {}

    # Test interface media line with media_type
    words = ['media:', 'Ethernet', '(configured)', 'media_type', '1000baseT']
    generic_network_facts.parse_media_line(words, current_if, None)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == '(configured)'
    assert current_if['media_type'] == '1000baseT'
    assert current_if['media_options'] == 'media_type'

    # Test interface media line with media_options
    words = ['media:', 'Ethernet', '(configured)', 'media_type', '1000baseT', 'media_options', 'media_options']
    generic

# Generated at 2022-06-20 18:01:40.308156
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    class TestModule(object):
        def run_command(self, words, check_rc=True):
            return (0, None, None)

        def get_bin_path(self, words):
            return None

    test_module = TestModule()

    network = GenericBsdIfconfigNetwork(test_module)

    # Here we are ensuring that if a scope id is given after
    # address/prefixlen it will be parsed properly.
    words = ['inet6',
             'fe80:1::1%lo1',
             'prefixlen',
             '64',
             'scopeid',
             '0x1']
    interfaces = dict()
    current_if = dict()
    ips = dict()

    result = network.parse_inet6_line(words, current_if, ips)
    assert result is None

   

# Generated at 2022-06-20 18:01:51.375940
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """
    Test if the function `parse_nd6_line` of the class `GenericBsdIfconfigNetwork`
      can handle FreeBSD and OpenBSD options
    """
    # Create an instance of the class
    bsd_network_facts = GenericBsdIfconfigNetworkCustom()

    # An array of line to test with expected result

# Generated at 2022-06-20 18:01:57.977933
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Use 'c' to skip the self argument
    mocker.patch('ansible.module_utils.facts.network.GenericBsdIfconfigNetwork.detect_type_media')
    GenericBsdIfconfigNetwork.detect_type_media('c')
    GenericBsdIfconfigNetwork.detect_type_media.assert_called_with('c')


# Generated at 2022-06-20 18:02:07.314655
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class GenericBsdIfconfigNetworkMock(GenericBsdIfconfigNetwork):
        module = None
        platform = None
        command = None

    gbinm = GenericBsdIfconfigNetworkMock()
    option_string = 'options=3<RXCSUM,TXCSUM>'
    assert ['RXCSUM', 'TXCSUM'] == gbinm.get_options(option_string)


# Generated at 2022-06-20 18:02:17.378499
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    class GenericBsdIfconfigNetwork_test():
        def __init__(self, *args, **kwargs):
            self.network_data = None
            self.interface_data = {}

        # The following method simulates the behaviour of run_command by storing the command argument.
        # This can be used to check, whether the methods are called with the correct arguments.
        def run_command(self, command):
            self.last_command = command
            return 0, '', ''

        # The following methods simulate the behaviour of module.fail_json and module.exit_json.
        # In unit tests, these methods simply store the arguments passed to them.
        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self.fail_json_kwargs = kwargs


# Generated at 2022-06-20 18:02:28.864771
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    #FIXME: Expected values for interfaces and ips are the same for BSD and Linux
    module = FakeAnsibleModule()
    #FIXME: class variables should be module scope
    module.platform = 'FreeBSD'
    module.bin_path = FakeBinPath()
    #FIXME: should be a list
    module.bin_path['ifconfig'] = 'ifconfig'
    #FIXME: This should be set in the setUp/tearDown methods
    network_provider = GenericBsdIfconfigNetwork(module)
    interfaces, ips = network_provider.get_interfaces_info(ifconfig_options='-a')

# Generated at 2022-06-20 18:02:41.703767
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    import GenericBsdIfconfigNetwork
    network_facts = GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork({})

    def test_get_options(line, expected):
        actual = network_facts.get_options(line)
        if actual != expected:
            print("FAIL: expected: %s\nactual:   %s" % (expected, actual))
        return actual == expected

    print("=== Test get_options() ===")
    if test_get_options('foo', []):
        print("PASS")
    if test_get_options('foo bar <>', []):
        print("PASS")
    if test_get_options('foo bar <baz>', ['baz']):
        print("PASS")

# Generated at 2022-06-20 18:02:48.967634
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    fact_module = GenericBsdIfconfigNetwork({})
    line = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = line.split()
    fact_module.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']

# Generated at 2022-06-20 18:03:09.332299
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = get_module_mock()
    ifconfig = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}

    ifconfig.parse_tunnel_line(['tunnel', 'inet6', 'fe80::34e0:43ff:fe9f:b303%gif0', 'prefixlen', '64', 'scopeid', '0x6'],
                               current_if, ips)
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-20 18:03:20.650628
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Create instance of class GenericBsdIfconfigNetwork
    network = GenericBsdIfconfigNetwork()

    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = {'ipv6': []}
    ips = {'all_ipv6_addresses': []}

    try:
        # Call the method with given arguments
        network.parse_inet6_line(words, current_if, ips)

    except Exception as error:
        # Raise an exception if the method call fails
        raise AssertionError(error)
    # Check if the output is as expected
    assert ips['all_ipv6_addresses'] == ['fe80::1%lo0'], 'Failed to parse inet6 line'

# Unit

# Generated at 2022-06-20 18:03:26.845765
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule({})
    cmd = {'bin_path': '/sbin/ifconfig', 'run_command': lambda *_, **__: [0, '', '']}
    module.params = {}
    module.run_command = cmd['run_command']
    network = GenericBsdIfconfigNetwork(module)

    network.parse_tunnel_line(['', '', '', ''], {}, {})
    assert 'type' not in {}

    network.parse_tunnel_line(['tunnel', '', '', ''], {}, {})
    assert {'type': 'tunnel'} == {}



# Generated at 2022-06-20 18:03:33.276780
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    fact_net_module = GenericBsdIfconfigNetwork()

    # empty test
    out = []
    current_if = {}
    ips = {}
    status_line = ['status:', 'active']
    fact_net_module.parse_status_line(status_line, current_if, ips)
    assert('status' in current_if)

    # test with unknown status
    out = []
    current_if = {}
    ips = {}
    status_line = ['status:', 'unknown_status']
    fact_net_module.parse_status_line(status_line, current_if, ips)
    assert('status' in current_if)


# Generated at 2022-06-20 18:03:42.491854
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    line = "status: active"
    words = line.split()
    x = GenericBsdIfconfigNetwork()
    current_if = {'device': None, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    x.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active'

# Generated at 2022-06-20 18:03:54.851165
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_module = GenericBSDIfconfigNetwork()
    current_if = {}
    ips = {}

    # 0: Addresses IPv6 with prefix
    line = 'inet6 fe80::21d:9ff:fe83:9c07%em0 prefixlen 64 scopeid 0x1',
    words = line[0].split()
    network_module.parse_inet6_line(words, current_if, ips)
    assert 'address' in current_if['ipv6'][0]
    assert current_if['ipv6'][0]['address'] == 'fe80::21d:9ff:fe83:9c07'

# Generated at 2022-06-20 18:04:06.429819
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # test_GenericBsdIfconfigNetwork_parse_options_line is the unit test function for
    # GenericBsdIfconfigNetwork_parse_options_line function defined in
    # module __init__.py in subdirectory network/plugins/__init__.py
    #
    #
    # Parameters
    # ----------
    #    None
    #
    # Returns
    # -------
    #    None
    #
    # Raises
    # ------
    #    None
    #

    def get_options(self, option_string):
        start = option_string.find('<') + 1
        end = option_string.rfind('>')
        if (start > 0) and (end > 0) and (end > start + 1):
            option_csv = option_string[start:end]
            return option_csv

# Generated at 2022-06-20 18:04:18.848719
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    import unittest2 as unittest
    import tempfile
    import shutil
    import os

    # setup mock ifconfig output
    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:04:31.481684
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network_facts = GenericBsdIfconfigNetwork()
    default_ipv4, default_ipv6 = network_facts.get_default_interfaces('')
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)

# List of platforms for which we need to load platform specific python class
# for the network module.

# Generated at 2022-06-20 18:04:37.852049
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    nc = GenericBsdIfconfigNetwork()

    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'ipv4': [{'address': '192.168.1.1'}]}}
    nc.merge_default_interface(defaults, interfaces, 'ipv4')
    assert(defaults['interface'] == 'lo0')
    assert(defaults['address'] == '192.168.1.1')

# TODO: lots of test coverage needed here

# Generated at 2022-06-20 18:05:23.065457
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    c = this_class()
    r = c.get_options('abc <op1,op2,op3>')
    assert r == ['op1', 'op2', 'op3']
    r = c.get_options('<op1,op2> def <op3,op4,op5>')
    assert r == ['op1', 'op2', 'op3', 'op4', 'op5']
    r = c.get_options('<op1, op2,>')
    assert r == ['op1', 'op2']
    r = c.get_options('<op1,op2,>')
    assert r == ['op1', 'op2']
    r = c.get_options('abc')
    assert r == []
    r = c.get_options('abc<>')

# Generated at 2022-06-20 18:05:31.568619
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = type('Module', (object,), {})()
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: 'ifconfig'
    module.debug = lambda x: None
    bsd = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-20 18:05:44.250622
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    GenericBsdIfconfigNetwork.parse_media_line(['media:', ETHERNET, AUTOSELECT, AUTO, '(autoselect)'], current_if, ips)
    assert current_if['media'] == ETHERNET
    assert current_if['media_select'] == AUTOSELECT
    assert current_if['media_type'] == AUTO
    assert current_if['media_options'] == ['autoselect']

    # TODO:
    # verify logging to store_exception()
    # GenericBsdIfconfigNetwork.parse_media_line(['media:', ETHERNET, AUTOSELECT, AUTO, '('], current

# Generated at 2022-06-20 18:05:55.013298
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():

    test_data = dict(
        test_data_1 = dict(
            words = ['status', 'active'],
            current_if = {},
            ips = {},
            expected_result = dict(
                current_if = dict(
                    status = 'active'
                ),
                ips = {}
            )
        )
    )

    for test_name, test_data_input in test_data.items():
        network_obj = GenericBsdIfconfigNetwork()
        network_obj.parse_status_line(test_data_input['words'], test_data_input['current_if'], test_data_input['ips'])
        assert test_data_input['current_if'] == test_data_input['expected_result']['current_if']

# Generated at 2022-06-20 18:05:55.517210
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    assert True

# Generated at 2022-06-20 18:06:01.613485
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork()
    network.parse_unknown_line = MagicMock(name='parse_unknown_line')
    network.parse_unknown_line.return_value = None

    words = ['test_value_1', 'test_value_2', 'test_value_3']
    current_if = {'key': 'value'}
    ips = {'key': 'value'}

    assert network.parse_unknown_line(words, current_if, ips) is None

# Generated at 2022-06-20 18:06:11.361226
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # The method parse_lladdr_line of class GenericBsdIfconfigNetwork

    # Note that this constructor does not call the super class constructor
    # so as to set platform to 'Generic_BSD_Ifconfig'.  It should probably 
    # call the super class constructor, but it doesn't.
    # 
    # If a subclass is provided, then the super class constructor (the
    # constructor for Network) will be called and the platform will be set
    # to the platform name.
    network = GenericBsdIfconfigNetwork(None)

    # This is the output of ifconfig when run with -e 
    #
    #    $ ifconfig -e
    #    nfe0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 2114
    #            options=80000<LINKSTATE

# Generated at 2022-06-20 18:06:26.305383
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    bsdifconfig = GenericBsdIfconfigNetwork()

    iface1 = bsdifconfig.parse_interface_line(["bridge0", "flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>", "metric", "0", "mtu", "1500", "ether", "02:a0:98:29:12:f1"])
    if iface1['device'] != 'bridge0':
        print('GenericBsdIfconfigNetwork_parse_interface_line unit test failed! (1)')

    if iface1['metric'] != '0':
        print('GenericBsdIfconfigNetwork_parse_interface_line unit test failed! (2)')


# Generated at 2022-06-20 18:06:37.186291
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
    )
    words = [
        'lo0:',
        'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>',
        'metric',
        '0',
        'mtu',
        '33184',
        'options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>',
        ]
    network.parse_interface_line(words)
    assert current_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

   

# Generated at 2022-06-20 18:06:47.447378
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    mod = FakeModule()
    gb = GenericBsdIfconfigNetwork(module=mod)
    current_if = dict(device='lo0', ipv4=[], ipv6=[], type='unknown')
    ips = {'all_ipv4_addresses': []}

    # test with dotted quad ip address
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    gb.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0] == dict(address='127.0.0.1', netmask='255.0.0.0', network='127.0.0.0')
    assert ips['all_ipv4_addresses'] == []

    # test with cidr ip