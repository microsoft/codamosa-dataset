

# Generated at 2022-06-22 23:45:46.643559
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = MockModule()
    generic_network = GenericBsdIfconfigNetwork(module)
    assert generic_network.platform == 'Generic_BSD_Ifconfig'

# Generated at 2022-06-22 23:45:59.578526
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print("Testing get_interfaces_info")

    from distutils.spawn import find_executable

    ifconfig_path = find_executable('ifconfig')
    ifconfig_options = '-a'
    n = GenericBsdIfconfigNetwork(dict(module=dict(run_command=run_command_local_with_outputs)))

    # Check that there are no interfaces when there is no ifconfig
    interfaces, ips = n.get_interfaces_info(None)
    assert interfaces == {}
    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []

    # Check that there are no interfaces when there is no output
    interfaces, ips = n.get_interfaces_info(ifconfig_path, ifconfig_options)

# Generated at 2022-06-22 23:46:06.775839
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    assert isinstance(network_fact_module, GenericBsdIfconfigNetwork)
    assert isinstance(network_fact_module.parse_inet6_line, types.FunctionType)
    assert hasattr(network_fact_module, 'parse_inet6_line')

    # TODO: write a unit test that verifies that parse_inet6_line handles
    #       the line passed in as the second argument.


# Unit tests for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:46:14.395928
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # Set up mock objects
    mock_module = Mock()
    mock_module.run_command = MagicMock()
    mock_module.run_command.return_value = (0, 'test inet6 fe80::cabc:b0ff:fef9:c75f%utun4 prefixlen 64 scopeid 0x11\n', None)

    # Perform the test
    gbi = GenericBsdIfconfigNetwork(mock_module)
    words = 'test inet6 fe80::cabc:b0ff:fef9:c75f%utun4 prefixlen 64 scopeid 0x11'.split()
    current_if = {}
    ips = {}
    gbi.parse_tunnel_line(words, current_if, ips)

    # Check the results

# Generated at 2022-06-22 23:46:24.964534
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    '''Test parse_interface_line method of class GenericBsdIfconfigNetwork'''
    module = MagicMock(name='module', fail_json=fail_json, check_mode=False)
    # Set the class up
    test_class = GenericBsdIfconfigNetwork(module)

    # Set the test arguments (basically copied from the params in
    # the gather_subset_facts function of the class)
    test_args = dict(interfaces='')

    # Set the test results

# Generated at 2022-06-22 23:46:33.024616
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_module = AnsibleModule(argument_spec={})
    c = GenericBsdIfconfigNetwork(test_module)

# Generated at 2022-06-22 23:46:44.756169
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Tested Method 
    test_meth = GenericBsdIfconfigNetwork.parse_inet6_line

    # Method Parsing Data
    test_datas = [
        {'words': ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1'],
         'expected_address': {'address': 'fe80::1%lo0', 'prefix': '64', 'scope': '0x1'}},
        {'words': ['inet6', '1111::1/64', 'prefixlen', '64', 'scopeid', '0x1'],
         'expected_address': {'address': '1111::1', 'prefix': '64', 'scope': '0x1'}},
    ]

    # Test Preparation
    module = AnsibleModule({})
   

# Generated at 2022-06-22 23:46:55.542908
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    sys.modules['_ansible_module_generated_by_test'] = MagicMock(AnsibleModule)

    network_facts = GenericBsdIfconfigNetwork()

    network_facts.module = MagicMock()
    network_facts.module.run_command = MagicMock(return_value=(0, 'test1', ''))
    network_facts.module.get_bin_path = MagicMock(side_effect=lambda x: x)

    # No interface
    defaults = {'interface': ''}
    interfaces = {}
    network_facts.merge_default_interface(defaults, interfaces, 'ipv4')
    network_facts.merge_default_interface(defaults, interfaces, 'ipv6')
    assert_equals({'interface': ''}, defaults)

    # Interface not found

# Generated at 2022-06-22 23:46:58.193826
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    gbn = GenericBsdIfconfigNetwork()
    gbn.get_default_interfaces('/sbin/route')


# Generated at 2022-06-22 23:47:01.287278
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    """
    Test populate
    """
    module = AnsibleModuleMock()
    a = GenericBsdIfconfigNetwork(module)
    a.run()


# Generated at 2022-06-22 23:47:13.316071
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Given
    options = []
    current_if = {}
    ips = {}
    # When
    module = GenericBsdIfconfigNetwork()
    module.parse_inet_line(['inet', '127.0.0.1', 'netmask', '0xff000000'], current_if, ips)
    # Then
    assert ips['all_ipv4_addresses'] == []
    assert current_if['ipv4'][0] == {'address': '127.0.0.1', 'netmask': '255.255.255.0', 'network': '127.0.0.0', 'broadcast': '127.0.0.255'}
    assert current_if['ipv6'] == []

# Generated at 2022-06-22 23:47:26.169689
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    from mock import call, patch, Mock

    class ModuleMock(Mock):
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/ifconfig'

    module_mock = ModuleMock()
    module_mock.run_command = lambda *args: (0, '', '')

    context_manager_mock = patch.object(GenericBsdIfconfigNetwork, 'get_interfaces_info', return_value=(dict(), dict()))
    open_mock = mock_open(read_data='device1: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n    options=1<ACCEPT_REDIRECTS>')


# Generated at 2022-06-22 23:47:39.224249
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')
    module.from_json = json.loads

    gbin = GenericBsdIfconfigNetwork(module)
    interfaces, ips = gbin.get_interfaces_info('/sbin/ifconfig')

    for intf in interfaces.values():
        for addr in intf['ipv6']:
            gbin.parse_inet6_line([intf['device'], addr['address'], 'prefixlen',
                                   addr['prefix'], 'scopeid', addr['scope']],
                                  intf, ips)
           

# Generated at 2022-06-22 23:47:52.444340
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    args = {'default_ipv4': 'default_ipv4', 'default_ipv6': 'default_ipv6', 'all_ipv4_addresses': 'all_ipv4_addresses', 'all_ipv6_addresses': 'all_ipv6_addresses', 'interfaces': 'interfaces', 'interface_lo0': 'interface_lo0', 'interface_en0': 'interface_en0', 'interface_en1': 'interface_en1'}
    facts = GenericBsdIfconfigNetwork(None).populate(args)

    assert facts['default_ipv4'] == 'default_ipv4'
    assert facts['default_ipv6'] == 'default_ipv6'
    assert facts['all_ipv4_addresses'] == 'all_ipv4_addresses'


# Generated at 2022-06-22 23:47:57.427784
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    try:
        from unittest.mock import MagicMock
        from unittest.mock import patch
        mock_module = MagicMock()
        with patch.object(GenericBsdIfconfigNetwork, 'module', mock_module):
            instance = GenericBsdIfconfigNetwork()
            instance.parse_unknown_line('', '', '')
            call_count = instance.module.fail_json.call_count
            assert call_count == 0
    except ImportError:
        from mock import MagicMock
        from mock import patch
        mock_module = MagicMock()
        with patch.object(GenericBsdIfconfigNetwork, 'module', mock_module):
            instance = GenericBsdIfconfigNetwork()
            instance.parse_unknown_line('', '', '')
            call_count = instance.module.fail_json

# Generated at 2022-06-22 23:48:10.170374
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    bsd = GenericBsdIfconfigNetwork()
    current_if = dict(
        media='Ethernet autoselect (1000baseT <full-duplex>)',
        media_select='1000baseT <full-duplex>',
        media_type='1000baseT',
        media_options='full-duplex',
    )

    bsd.parse_media_line(
        ['Ethernet', 'autoselect', '(1000baseT', '<full-duplex>)'],
        current_if, dict())

    assert dict(current_if) == dict(
        media='Ethernet autoselect (1000baseT <full-duplex>)',
        media_select='1000baseT <full-duplex>',
        media_type='1000baseT',
        media_options='full-duplex',
    )



# Generated at 2022-06-22 23:48:22.561733
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    import pytest

    default_ipv4 = {'interface': 'em0'}
    default_ipv6 = {'interface': 'em0'}

    # Case 1: merge defaults into interfaces successful

# Generated at 2022-06-22 23:48:23.666611
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# Generated at 2022-06-22 23:48:26.832589
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Just a simple test to show we call the method
    m = GenericBsdIfconfigNetwork()
    m.merge_default_interface({}, {}, '')


# Generated at 2022-06-22 23:48:38.050680
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    test_obj = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '192.0.2.2', '-->', '198.51.100.2']
    current_if = {'device': 'tun0'}
    ips = dict(all_ipv4_addresses=[])
    test_obj.parse_tunnel_line(words, current_if, ips)
    assert current_if['ipv4'][0] == dict(
        address='192.0.2.2',
        broadcast='198.51.100.2',
    )
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:48:51.204811
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
   # ipv6 tunnel interface
   words = ['tun6to4', 'tunnel', 'inet6', '2002:57f2:a6b5::57f2:a6b5', 'prefixlen', '16', '<compatibility,', 'autoconf>', 'mtu', '1480']
   current_if = {'device': 'tun6to4', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown', 'mtu': '1480'}
   ips = dict(
       all_ipv4_addresses=[],
       all_ipv6_addresses=[],
   )
   obj = GenericBsdIfconfigNetwork()
   obj.parse_tunnel_line(words, current_if, ips)
   assert current

# Generated at 2022-06-22 23:49:04.974606
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    generic_bsdifconfig_network = GenericBsdIfconfigNetwork()

    # Valid values
    words = ['tunnel', 'inet', '10.0.3.1', '-->', '10.0.2.2']
    current_if = {'device': 'eth0'}
    ips = {}
    generic_bsdifconfig_network.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'
    assert current_if['device'] == 'eth0'
    # Invalid values
    words = ['']
    current_if = {}
    ips = {}
    generic_bsdifconfig_network.parse_tunnel_line(words, current_if, ips)
    assert 'type' not in current_if


# Generated at 2022-06-22 23:49:09.151523
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
  mock_words = ['tunnel','inet6','fe80::1%lo0','prefixlen','64'
  ,'scopeid','0x4','inet6','fe80::dead:beef:fe01:2345%lo0','prefixlen','64'
  ,'tunnel','inet6','dead::1','prefixlen','64','tunnel','inet6','beef::1'
  ,'prefixlen','64','tunnel','inet6','dead:beef::1','prefixlen','64']
  test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
  dict_current_if = {'device': 'vlan8'}
  dict_ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
  call_parse_tunnel_line = test_Generic

# Generated at 2022-06-22 23:49:22.510272
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['inet6', '2001:db8:a::123', 'prefixlen', '64', '0x1', 'scopeid', '0x10']
    generic_bsd_network.parse_inet6_line(words, current_if, ips)

    assert 'ipv6' in current_if
    assert len(current_if['ipv6']) == 1
    assert 'address' in current_if['ipv6'][0]
    assert current_if['ipv6'][0]['address'] == '2001:db8:a::123'
    assert 'prefix' in current_if['ipv6'][0]

# Generated at 2022-06-22 23:49:31.233405
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # TODO: this test should be redone when we have unit tests for classes.
    #       currently the test methods are not even run
    #
    # https://docs.python.org/3.6/library/unittest.html
    #
    # https://www.patricksoftwareblog.com/unit-testing-a-flask-application/
    #
    # https://stackoverflow.com/questions/551671/how-do-you-run-python-unit-tests

    def test_parse_tunnel_line(self):
        words = ["tunnel", "inet", "10.0.0.1", "-->", "10.0.0.2", "netmask", "0xffff0000", "tos", "0x10"]

# Generated at 2022-06-22 23:49:36.327637
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = None
    mod_path = os.path.join(os.path.dirname(__file__), '../library')
    module = GenericBsdIfconfigNetwork()
    module.populate(None)
    facts = module.get_facts()
    print(facts)


# Generated at 2022-06-22 23:49:38.541000
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    p = GenericBsdIfconfigNetwork()
    assert p.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-22 23:49:50.446128
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    param_words = ['em0', 'ether', '08:00:27:4a:c2:a2']
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                  'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_obj = GenericBsdIfconfigNetwork()
    test_obj.parse_ether_line(param_words, current_if, ips)
    assert current_if['macaddress'] == '08:00:27:4a:c2:a2'
    assert current_if['type'] == 'ether'



# Generated at 2022-06-22 23:49:57.038527
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['ether', '00:0b:82:24:f7:dc']
    network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:0b:82:24:f7:dc'
    

# Generated at 2022-06-22 23:50:02.170601
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():

    network = GenericBsdIfconfigNetwork({})

    current_if = {}

    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', '(', 'null', ')']

    network.parse_nd6_line(words, current_if, None)

    assert('options' in current_if)
    assert(len(current_if['options']) == 3)
    assert('PERFORMNUD' in current_if['options'])
    assert('IFDISABLED' in current_if['options'])
    assert('AUTO_LINKLOCAL' in current_if['options'])


# Generated at 2022-06-22 23:50:09.026563
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
   module = AnsibleModule(
        dict(
            config=dict(type='str', default='/etc/ansible/facts.d/network.fact'),
            cache=dict(type='bool', default='True')
        )
    )
   network = GenericBsdIfconfigNetwork(module)
   network.populate()

test_GenericBsdIfconfigNetwork_populate()

# Generated at 2022-06-22 23:50:22.200335
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    platform_cls = GenericBsdIfconfigNetwork(module)
    test_input = []
    expected = {}
    module.run_command = MagicMock(return_value=[0, '', ''])
    setattr(module, '_ansible_version', LooseVersion('2.11.0'))
    module.get_bin_path = MagicMock(return_value=None)

    test_input = ['ether', '00:0c:29:9b:3e:d3']
    current_if = {'device': None, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

# Generated at 2022-06-22 23:50:30.410159
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
	words = ["inet6","fc00:0000:0000:0000:0000:0000:0000:0000","prefixlen","64"]
	current_if = {}
	ips = {}
	parser = GenericBsdIfconfigNetwork()
	parser.parse_inet6_line(words, current_if, ips)
	assert current_if["ipv6"][0] == {'address': 'fc00:0000:0000:0000:0000:0000:0000:0000', 'prefix': '64'}

# Generated at 2022-06-22 23:50:43.141086
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    # Mock class
    class MockPopen(object):
        pass
    # Instantiate mock
    mock = MockPopen()
    # Mock return value for method communicate of popen object
    mock.communicate = MagicMock(return_value=
        ('default via 10.0.2.2 dev eth0  proto static  metric 100  '
         '169.254.0.0/16 dev eth0  scope link  metric 1000\n',
        None))
    # Mock return value for method popen of subprocess module
    subprocess.Popen = MagicMock(return_value=mock)

    # Create instance of class GenericBsdIfconfigNetwork
    generic = GenericBsdIfconfigNetwork(None)

    # Call get_default_interfaces of GenericBsdIfconfigNetwork with route path

# Generated at 2022-06-22 23:50:44.470884
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pass


# Generated at 2022-06-22 23:50:52.811579
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.netinfo import InterfacesInfo

    netinfo = InterfacesInfo()

    words = ['lo0', 'flags', '0x8802<BROADCAST,SIMPLEX,MULTICAST,NEEDSGIANT>', 'metric', '0', 'mtu', '33184',
             'inet', '127.0.0.1', 'netmask', '0xff000000']

# Generated at 2022-06-22 23:50:57.368073
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # This function is called from test cases, never from code.
    module = AnsibleModule(argument_spec=dict())
    ip_type = 'ipv4'
    network = GenericBsdIfconfigNetwork(module)

    interfaces, ips = network.get_interfaces_info('/sbin/ifconfig')
    interfaces = network.detect_type_media(interfaces)

    default_ipv4, default_ipv6 = network.get_default_interfaces('/sbin/route')
    network.merge_default_interface(default_ipv4, interfaces, ip_type)

    network_facts = network.populate()

    assert isinstance(network_facts, dict)
    assert isinstance(network_facts['interfaces'], list)
    assert len(network_facts['interfaces']) > 0
   

# Generated at 2022-06-22 23:51:04.562834
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """
    This is a unit test for the constructor of class GenericBsdIfconfigNetwork.
    This class inherits from NetworkCommon. This test will construct
    an object for the class and
    1) test if the object is an instance of the class, and
    2) test the populate method of the class
    """
    module = AnsibleModuleMock()
    network = GenericBsdIfconfigNetwork(module)
    assert isinstance(network, GenericBsdIfconfigNetwork)
    assert isinstance(network, NetworkCommon)
    assert network.populate() == network.facts


# Generated at 2022-06-22 23:51:16.654122
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec=dict())
    gbn = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    gbn.parse_ether_line(['ether', '00:11:22:33:44:55'], current_if, ips)
    assert current_if['type'] == 'ether'
    assert current_if['macaddress'] == '00:11:22:33:44:55'

# Generated at 2022-06-22 23:51:28.692379
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    ## Dummy 'self' object, to pass to function
    class Dummy:
      def __init__(self, word_list):
        self.words = word_list

    # Test: words = ['ether', '00:11:22:33:44:55']

    # Expected output:
    result = {
      'device': '',
      'flags': [],
      'ipv4': [],
      'ipv6': [],
      'macaddress': '00:11:22:33:44:55',
      'type': 'ether'
    }

    # Test:
    current_if = {}

    d = Dummy(['ether', '00:11:22:33:44:55'])
    GenericBsdIfconfigNetwork.parse_ether_line(d, current_if, {})

   

# Generated at 2022-06-22 23:51:33.110955
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork(None)
    assert network.get_options('') == []
    assert network.get_options('<>') == []
    assert network.get_options('<a,b,c>') == ['a', 'b', 'c']

# Generated at 2022-06-22 23:51:35.073827
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec={})
    nm=GenericBsdIfconfigNetwork(module)
    return nm


# Generated at 2022-06-22 23:51:42.957807
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec=dict())

    ifc = GenericBsdIfconfigNetwork(module=module)
    line1 = ['ath0', 'ether', '00:2c:29:68:02:b9', 'media:', 'Ethernet', 'autoselect', 'status:', 'active']
    ifc.parse_ether_line(line1, {}, {})

    line2 = ['lo0', 'link', '0x8', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']
    ifc.parse_ether_line(line2, {}, {})


# Generated at 2022-06-22 23:51:47.623101
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # Instanciating GenericBsdIfconfigNetwork class object
    p = GenericBsdIfconfigNetwork()
    # Reading dummy output of ifconfig command
    srcfile = '../../../../../lib/ansible/module_utils/network/common/tests/dum_ifconfig_output'
    f = open(srcfile, 'r')
    dummy_ifconfig_output = f.read()
    # Instanciating module object
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Adding ifconfig output to module object
    module.run_command = MagicMock(return_value=(0, dummy_ifconfig_output, ''))
    # calling get_interfaces_info method
    interfaces, ips = p.get_interfaces_info(None)

# Generated at 2022-06-22 23:51:58.500135
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
  module = AnsibleModule(argument_spec={})

  iface = GenericBsdIfconfigNetwork(module)
  res = iface.populate()

  results = dict(
      interfaces=res['interfaces'],
      default_ipv4=res['default_ipv4'],
      default_ipv6=res['default_ipv6'],
      lo=res['lo'],
      all_ipv4_addresses=res['all_ipv4_addresses'],
      all_ipv6_addresses=res['all_ipv6_addresses'],
  )

  module.exit_json(**results)



# Generated at 2022-06-22 23:52:02.010484
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options = GenericBsdIfconfigNetwork.get_options('<LOOPBACK,RUNNING,MULTICAST>')
    assert options == ['LOOPBACK', 'RUNNING', 'MULTICAST']



# Generated at 2022-06-22 23:52:14.878576
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ip_data = GenericBsdIfconfigNetwork()
    # test data as returned by netbsd ifconfig -e in netbsd 7.1

# Generated at 2022-06-22 23:52:19.425455
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    c = GenericBsdIfconfigNetwork()
    # Test case #1
    words = ['lladdr', 'xx:xx:xx:xx:xx:xx']
    c.parse_lladdr_line(words, current_if, {})
    assert current_if['lladdr'] == 'xx:xx:xx:xx:xx:xx'
    current_if = {}
    # Test case #2
    words = ['lladdr']
    c.parse_lladdr_line(words, current_if, {})
    assert current_if == {}

# Generated at 2022-06-22 23:52:31.850121
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    gbi = GenericBsdIfconfigNetwork()
    ips = dict(all_ipv4_addresses=[])
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    # test 0
    words = ['--link1--']
    gbi.parse_unknown_line(words, current_if, ips)
    assert current_if['device'] == 'lo0'
    assert ips['all_ipv4_addresses'] == []
    # test 1
    words = ['--link2--']
    gbi.parse_unknown_line(words, current_if, ips)
    assert current_if['device'] == 'lo0'
    assert ips['all_ipv4_addresses'] == []
    # test 2

# Generated at 2022-06-22 23:52:43.613506
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    test_module = GenericBSDIfconfig()

    test_module.run_command = mock.Mock(return_value=(0, "", ""))

    test_facts = {}
    test_facts['ansible_facts'] = test_module.populate()

    assert test_facts['ansible_facts']['default_ipv4'] == {}
    assert test_facts['ansible_facts']['default_ipv6'] == {}
    assert test_facts['ansible_facts']['all_ipv4_addresses'] == []
    assert test_facts['ansible_facts']['all_ipv6_addresses'] == []
    assert test_facts['ansible_facts']['interfaces'] == []


# Generated at 2022-06-22 23:52:55.818190
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    import json

    # Construct an instance of the class with the module args
    module_args = dict(
        config_file='/etc/ansible/facts.d/network.fact',
        config_dir='/etc/ansible/facts.d',
        cache_dir=None,
    )

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module_args)

    # Create a dictionary that contains all the collected facts from the module
    collected_facts = dict()

    # Execute the populate command
    network_facts = generic_bsd_ifconfig_network.populate(collected_facts)

    # write the facts to a file so we can use them as input to the module.

# Generated at 2022-06-22 23:53:02.195071
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    check_class_exists("GenericBsdIfconfigNetwork")

    check_class_method_exists(GenericBsdIfconfigNetwork, "parse_ether_line")

    test_obj = GenericBsdIfconfigNetwork("dummy_module")
    current_if = {}
    ips = {}
    words = ['ether', 'aa:bb:cc:dd:ee:ff']
    test_obj.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] is 'aa:bb:cc:dd:ee:ff'
    assert current_if['type'] is 'ether'



# Generated at 2022-06-22 23:53:15.224606
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    fake_module = FakeModule()
    fake_module.add_output(['/usr/bin/route', '-n', 'get', 'default'], '''
route to: default
destination: default
flags:      <UP,GATEWAY,DONE,STATIC,PRCLONING>
recvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire
0         0         0         0           0       0             1500    0
localhost  link#8   UHS         0      0        lo0
''')


# Generated at 2022-06-22 23:53:21.270523
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    '''
    parse_lladdr_line() test cases
    '''
    test_object = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:53:24.825904
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    ifconfig = GenericBsdIfconfigNetwork()
    result = ifconfig.parse_unknown_line([], {}, {})

    assert result is None

# Generated at 2022-06-22 23:53:34.519138
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Create class object
    gbn = GenericBsdIfconfigNetwork({})
    # Create mock up
    current_if = {}
    ips = {}
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'media:', 'Ethernet', 'autoselect', '(100baseTX)', 'status:', 'active']
    # test
    gbn.parse_nd6_line(words, current_if, ips)
    # Assert
    assert current_if['options'] == ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']


# Generated at 2022-06-22 23:53:42.061337
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    from ansible.module_utils.facts.networking.generic_bsd import GenericBsdIfconfigNetwork
    input_array = ['em1: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500',
                   'ether 00:1c:42:00:00:08',
                   'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>',
                   'media: Ethernet autoselect (1000baseT <full-duplex>)',
                   'status: active']

# Generated at 2022-06-22 23:53:50.452554
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    ifc = GenericBsdIfconfigNetwork()

    # Test defaults
    defaults = {}

# Generated at 2022-06-22 23:54:02.774793
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:54:07.307634
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    if_config = GenericBsdIfconfigNetwork()
    assert if_config.__class__.__name__ == "GenericBsdIfconfigNetwork"
    assert if_config.platform == "Generic_BSD_Ifconfig"


# Generated at 2022-06-22 23:54:14.000299
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    if os.path.exists('/usr/sbin/ifconfig'):
        f_module = FakeModule(
            module_utils=NetworkModuleUtils,
            ifconfig_path='/usr/sbin/ifconfig'
        )
        network_facts = GenericBsdIfconfigNetwork(f_module)   # noqa

        assert network_facts.platform == 'Generic_BSD_Ifconfig'
    else:
        assert os.path.exists('/usr/sbin/ifconfig') == True



# Generated at 2022-06-22 23:54:26.851396
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:54:34.361567
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    class ModuleStub(object):
        pass

    class AnsibleModuleStub(object):
        def __init__(self):
            self.params = {}
            self.result = {}
            self.exit_args = {}
            self.exit_args['failed'] = False

    mod = ModuleStub()
    mod.params = dict()
    mod.check_mode = False
    mod.no_log = True
    mod.debug = False
    mod.run_command = MagicMock(return_value=(0, '', ''))

    amod = AnsibleModuleStub()
    amod.params = mod.params
    amod.check_mode = mod.check_mode
    amod.no_log = mod.no_log
    amod.debug = mod.debug

# Generated at 2022-06-22 23:54:47.194354
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    network = GenericBsdIfconfigNetwork()

    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if = network.parse_interface_line(words)
    assert current_if == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'metric': '0', 'mtu': '33184', 'macaddress': 'unknown'}

    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']

# Generated at 2022-06-22 23:54:54.482269
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = GenericBsdIfconfigNetwork()

    current_if = {'device': 'eth0'}
    ips = {}

    # Mac has options like this...
    words = ['options=3<RXCSUM,TXCSUM>']
    m.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['RXCSUM', 'TXCSUM']


# Generated at 2022-06-22 23:55:04.694088
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    def test(option_string, expected_options):
        options = GenericBsdIfconfigNetwork.get_options(option_string)
        if options != expected_options:
            raise AssertionError("option: %s, expected: %s, actual: %s" % (option_string, expected_options, options))

    test('1<2,3>4', ['2', '3'])
    test('<2,3>4', ['2', '3'])
    test('1<2,3>', ['2', '3'])
    test('<2,3>', ['2', '3'])
    test('1<>4', [])
    test('<>4', [])
    test('<>', [])

# Generated at 2022-06-22 23:55:15.981751
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = AnsibleModule(argument_spec={})
    module_class = GenericBsdIfconfigNetwork(module)

    # Test case 1
    words = ["lo0:", "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>", "metric", "0", "mtu", "33184"]
    output = {'device': "lo0",
              'ipv4': [],
              'ipv6': [],
              'type': 'loopback',
              'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
              'macaddress': "unknown",
              'metric': "0",
              'mtu': "33184"}

    assert module_class.parse_interface_line(words) == output

    # Test case 2

# Generated at 2022-06-22 23:55:25.862369
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    # init
    brdg = GenericBsdIfconfigNetwork()
    current_if = {}

    # for call
    words = ['media:', 'Ethernet', 'autoselect', '(none)']

    # call
    brdg.parse_media_line(words, current_if, {})

    # test result
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == 'none'
    assert 'media_options' not in current_if


# Generated at 2022-06-22 23:55:36.214658
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    obj = GenericBsdIfconfigNetwork()
    defaults = dict(interface='mem', gateway='127.0.0.1')
    interfaces = dict(mem=dict(ipv4=[dict(address='127.0.0.1', netmask='0xffff0000',
                                         broadcast='192.168.255.255')]))
    expected_defaults = dict(interface='mem', gateway='127.0.0.1',
                             address='127.0.0.1', netmask='0xffff0000',
                             broadcast='192.168.255.255')

    obj.merge_default_interface(defaults, interfaces, 'ipv4')

    assert defaults == expected_defaults


# Generated at 2022-06-22 23:55:47.823895
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = type('', (), {})()
    module.run_command = Mock(return_value=(0, '', ''))
    net_obj = GenericBsdIfconfigNetwork(module)
    current_if = {'device': "ge0", 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses':[], 'all_ipv6_addresses':[] }
    words = ['inet6', '2001:0db8:85a3:0000:0000:8a2e:0370:7334', 'prefixlen', '64', 'scopeid', '0x3']
    address = {'address': '2001:0db8:85a3:0000:0000:8a2e:0370:7334'}