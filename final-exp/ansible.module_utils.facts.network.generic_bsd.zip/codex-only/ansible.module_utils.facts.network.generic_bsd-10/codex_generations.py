

# Generated at 2022-06-22 23:45:54.982917
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # setup
    module_args = dict(
        name='test',
        type='GenericBsdIfconfigNetwork',
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    mm = GenericBsdIfconfigNetwork(module)

    current_if = {}
    ips = {}


# Generated at 2022-06-22 23:46:01.490051
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Test data
    raw_data = [
        ["status: active", {'status': 'active'}, {}],
        ["status: no carrier", {'status': 'no carrier'}, {}],
        ["status: active  (something else goes here)", {'status': 'active'}, {}]
    ]

    # Run Test
    for test_data in raw_data:
        _parse_status_test(test_data)



# Generated at 2022-06-22 23:46:08.957182
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    network = GenericBsdIfconfigNetwork()

    default_interfaces = network.get_default_interfaces('/sbin/route')
    
    assert default_interfaces == ({'gateway': '192.0.2.1', 'interface': 'en0', 'address': '192.0.2.15'},
                                  {'gateway': 'fe80::6800:7ff:fe00:1%en0', 'interface': 'en0', 'address': 'fe80::a800:eff:fe00:1'})
    

# Generated at 2022-06-22 23:46:16.160971
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    _module = Mock()
    _module.fail_json.side_effect = fail_json
    _module.run_command.return_value = 0, '', ''
    _module.check_mode = False


# Generated at 2022-06-22 23:46:18.745285
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    GenericBsdIfconfigNetwork.populate(
        GenericBsdIfconfigNetwork,
        collected_facts={'kernel': 'FreeBSD'}
    )

# Generated at 2022-06-22 23:46:24.482548
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    default_if = {
        'device': 'em0',
        'ipv4': [{'address': '10.0.0.10'}],
        'ipv6': [{'address': 'fd00:10:10::10'}],
        'mtu': '1500',
        'media': 'Ethernet autoselect (1000baseTX <full-duplex>)'
    }
    iflist = {'em0': default_if}
    gb = GenericBsdIfconfigNetwork()
    gb.detect_type_media(iflist)
    assert iflist['em0']['type'] == 'ether'
    default_if.pop('type')
    default_if['device'] = 'lo0'
    iflist['lo0'] = default_if
    gb.detect_type

# Generated at 2022-06-22 23:46:28.662108
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    assert obj.parse_tunnel_line(['tunnel', 'inet', '192.168.0.1', '-->', '192.168.0.2', 'netmask', '0xffffff00'], {}, {}) == {'type': 'tunnel'}

# Generated at 2022-06-22 23:46:37.392631
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    m = ModuleTestCase()
    network = GenericBsdIfconfigNetwork(m.module)
    iface = {}
    ips = {}
    words = ['tunnel', 'inet', '192.168.1.1', '-->', '172.16.1.1', 'netmask', '0xffffff00']
    network.parse_tunnel_line(words, iface, ips)
    assert iface['type'] == 'tunnel'

# Generated at 2022-06-22 23:46:40.882475
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    testobj = GenericBsdIfconfigNetwork()
    assert testobj.platform is not None
    assert testobj.platform == 'Generic_BSD_Ifconfig'
    assert testobj.use_ifconfig_path is not None


# Generated at 2022-06-22 23:46:46.710499
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    words = ["tunnel","inet","172.17.0.3","-->","172.17.0.1","netmask","0xffffffff","nd6","options=23<PERFORMNUD,ACCEPT_RTADV>"]
    current_if = dict()
    ips = dict()
    results = obj.parse_tunnel_line(words, current_if, ips)
    assert results is None


# Generated at 2022-06-22 23:46:54.641963
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    gbin = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:47:05.751922
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec={})
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    words = ['lladdr', 'fe80::1%lo0']
    GenericBsdIfconfigNetwork.parse_lladdr_line(module, words, current_if, ips)
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == 'fe80::1%lo0'


# Generated at 2022-06-22 23:47:14.985691
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # GIVEN
    net = GenericBsdIfconfigNetwork()

    # WHEN
    current_if = dict()
    net.parse_media_line(['media:', 'ieee80211', 'IEEE802.11-DS', '(autoselect)'], current_if, dict())

    # THEN
    expected_if = {
        'media': 'ieee80211',
        'media_select': 'IEEE802.11-DS',
        'media_type': '(autoselect)',
    }
    assert current_if == expected_if



# Generated at 2022-06-22 23:47:26.568569
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Create instance
    gn = GenericBsdIfconfigNetwork()

    # Create input variables and values
    words = list()

    words.append('nd6')
    words.append('options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>')
    words.append('metric 0')
    words.append('nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>')

    # Create expected output
    expected_result = dict(nd6=['PERFORMNUD', 'AUTO_LINKLOCAL'])

    # Call the method under test
    gn.parse_nd6_line(words, None, None)

    # Verify the result
    assert words == expected_result


# Generated at 2022-06-22 23:47:30.581673
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_instance = GenericBsdIfconfigNetwork()
    assert test_instance.parse_media_line(['media:', '10baseT', '/', 'full'], {}, {}) == {'media': '10baseT/full'}


# Generated at 2022-06-22 23:47:39.224655
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    parser = GenericBsdIfconfigNetwork(0)
    line = "eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500"
    iface = parser.parse_interface_line(line.split(" "))
    assert iface["device"] == "eth0"
    assert iface["flags"] == ["BROADCAST", "RUNNING", "MULTICAST"]
    assert iface["mtu"] == "1500"

# Generated at 2022-06-22 23:47:52.444236
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    words = ['bge0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'inet', '192.168.1.80', 'netmask', '0xffffff00', 'broadcast', '192.168.1.255', 'nwid', 'CandyYumYum', 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'media:', 'Ethernet', 'autoselect', 'status:', 'active', 'lladdr', '00:a0:cc:99:78:70', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']


# Generated at 2022-06-22 23:48:04.144911
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    template_object = GenericBsdIfconfigNetwork()

    # Test case #1 - IPv6 address
    ifcfg_line = 'inet6 fe80::1%lo0 prefixlen 64 scopeid 0x3'
    interface = {}
    ips = dict(all_ipv6_addresses=[])
    template_object.parse_inet6_line(ifcfg_line.split(), interface, ips)
    assert interface['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert interface['ipv6'][0]['prefix'] == '64'
    assert interface['ipv6'][0]['scope'] == '0x3'
    assert ips['all_ipv6_addresses'][0] == 'fe80::1%lo0'

    # Test case #2 - IPv6

# Generated at 2022-06-22 23:48:13.311014
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    iface = 'wm1'
    words = ['lladdr', '00:11:22:aa:bb:cc']
    current_if = {'device': iface, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    network = GenericBsdIfconfigNetwork()

    network.parse_lladdr_line(words, current_if, ips)

    assert 'wm1' in current_if
    assert current_if['wm1']['macaddress'] == "00:11:22:aa:bb:cc"

# Generated at 2022-06-22 23:48:26.019935
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self):
            pass

        def run_command(self, args):
            answers = dict()
            answers['BSD'] = dict()

# Generated at 2022-06-22 23:48:36.063422
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    net = GenericBsdIfconfigNetwork(None)    
    test_if = {"device": "bridge0", "metric": "0", "mtu": "1500", "flags": ["BROADCAST", "SIMPLEX", "MULTICAST"], "options": [], "macaddress": "unknown", "type": "unknown"}
    test_line = "options=8<VLAN_MTU>"
    net.parse_options_line(test_line.split(), test_if, None)
    assert set(["VLAN_MTU"]) == set(test_if['options'])

# Generated at 2022-06-22 23:48:43.786304
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Instansiate a GenericBsdIfconfigNetwork object with params
    x = GenericBsdIfconfigNetwork()

    # Define data for test
    test_words_1 = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet6', '::1', 'prefixlen', '128', 'inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1', 'noprefixroute', '--']

# Generated at 2022-06-22 23:48:45.077118
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    pass


# Generated at 2022-06-22 23:48:57.216898
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():

    # create mock object to test
    mock_module = MockModule(platform='SunOS', args=dict())
    mock_module.run_command = Mock(return_value=(0, '', ''))
    network_info = GenericBsdIfconfigNetwork(mock_module)

    # create test object
    words = ['tunnel','inet','127.0.0.1','-->','172.16.1.2','netmask','0xffffffff','destination','172.16.1.2','flags','0x2c3']

    # initialize test interface
    interface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown', 'mtu': 33184}

    # initialize test IP address collection

# Generated at 2022-06-22 23:49:10.751406
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # 1. IPv4 tests
    for ipv4 in ['127.0.0.1', '127.0.0.2', '192.168.2.1']:
        # 1.1. Test broadcast
        test_input = ['inet6', ipv4, 'prefixlen', '64', 'scopeid', '0x1', 'broadcast', '::']
        test_result = GenericBsdIfconfigNetwork.parse_inet6_line(test_input, {}, {})
        assert test_result == ['inet6', ipv4, 'prefixlen', '64', 'scopeid', '0x1', 'broadcast', '::']
        # 1.2. Test netmask and broadcast

# Generated at 2022-06-22 23:49:19.481320
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test with good input
    route_path = './tests/route'
    network = GenericBsdIfconfigNetwork()
    network.module.get_bin_path = MagicMock(return_value=route_path)
    default_ipv4, default_ipv6 = network.get_default_interfaces(route_path)
    assert(default_ipv4['interface'] == 'en0' and default_ipv6['interface'] == 'en0')


# Generated at 2022-06-22 23:49:30.346078
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = "/bin/route"


# Generated at 2022-06-22 23:49:42.738256
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0'}
    interfaces = {
        'lo0': {
            'device': 'lo0',
            'type': 'loopback',
            'macaddress': 'unknown',
            'ipv4': [{
                'address': '127.0.0.1',
                'netmask': '255.255.255.0',
                'network': '127.0.0.0',
                'broadcast': '127.0.255.255'}],
            'ipv6': [{
                'address': '::1',
                'prefix': '128',
                'scope': '0x10'}],
            'flags': {'UP', 'LOOPBACK', 'RUNNING'}}
    }
    network.merge_

# Generated at 2022-06-22 23:49:51.487780
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = FakeModule({'PATH': '/bin:/sbin:/usr/bin:/usr/sbin'})
    n = GenericBsdIfconfigNetwork(module)
    current_if = {}
    words = ['lladdr', '01:02:03:04:05:06']
    ips = {}

    n.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == '01:02:03:04:05:06'

# Tests for the class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:50:01.275565
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    '''
    Create a instance of GenericBsdIfconfigNetwork class, create a single
    line of dummy data, and check that the parse_options_line module works.
    '''
    generic_network = GenericBsdIfconfigNetwork()

    ifconfig_output = '  options=3<PERFORMNUD,ACCEPT_RTADV>'
    words = ifconfig_output.split()

    current_if = {}
    ips = {}

    generic_network.parse_options_line(words, current_if, ips)

    assert current_if['options'] == ['PERFORMNUD', 'ACCEPT_RTADV']


# Generated at 2022-06-22 23:50:08.929992
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    platform = 'Generic_BSD_Ifconfig'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.params = {}

    def run_command(params):
        return 0, 'a command output', ''

    module.run_command = run_command

    obj = GenericBsdIfconfigNetwork(module)

    obj.parse_unknown_line(['foo', 'bar'], {}, {})


# Generated at 2022-06-22 23:50:22.110679
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_instance = GenericBsdIfconfigNetwork(module)
    iface = 'lo0'

# Generated at 2022-06-22 23:50:34.951281
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_interface = {
        "eth0": {
            "device": "eth0",
            "ipv4": [],
            "ipv6": [],
            "type": "unknown",
            "flags": [
                "UP",
                "BROADCAST",
                "RUNNING",
                "SIMPLEX",
                "MULTICAST",
                "LINK0"
            ],
            "metric": "0",
            "mtu": "1500",
            "macaddress": "02:42:ac:11:00:02",
            "options": []
        }
    }

    test_instance = GenericBsdIfconfigNetwork()
    result = test_instance.detect_type_media(test_interface)
    assert "eth0" in result, 'Failed to detect interface type'
   

# Generated at 2022-06-22 23:50:46.834247
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Empty argument, no change.
    class Args:
        def __init__(self, words):
            self.words = words

    n = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    n.parse_media_line(Args([]).words, current_if, ips)
    assert(current_if == {})

    # Only word[1], no change.
    current_if = {}
    ips = {}
    n.parse_media_line(Args(['a']).words, current_if, ips)
    assert(current_if == {})

    # Argument passed, current_if changes.
    current_if = {}
    ips = {}

# Generated at 2022-06-22 23:50:53.357482
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork()

    words = ['network']
    current_if = {}
    ips = {}
    with pytest.raises(Exception) as excinfo:
        network.parse_unknown_line(words, current_if, ips)
    excinfo.match("Unexpected line in ifconfig output:" + " ".join(words))
    assert excinfo.type == Exception

# Generated at 2022-06-22 23:51:04.715472
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    m = module_args_builder("generic_bsd_ifconfig")

# Generated at 2022-06-22 23:51:16.773996
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    instr = "fe80::219:d7ff:fe3d:c826 lladdr 00:19:d7:3d:c8:26"
    words = instr.split()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    _GenericBsdIfconfigNetwork__GenericBsdIfconfigNetwork__parse_lladdr_line(words, current_if, ips)
    assert 'lladdr' in current_if
    assert current_if['lladdr'] == '00:19:d7:3d:c8:26'


# Generated at 2022-06-22 23:51:19.478110
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    print("Method test_GenericBsdIfconfigNetwork_merge_default_interface not implemented yet")


# Generated at 2022-06-22 23:51:22.788945
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = BasicModule()
    module.params = dict()
    network = GenericBsdIfconfigNetwork(module)
    assert network.platform == "Generic_BSD_Ifconfig"


# Generated at 2022-06-22 23:51:34.443797
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = {}
    ips = {}

    test1 = {'words': ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'status:', 'active'],
             'media': 'Ethernet',
             'media_select': 'autoselect',
             'media_type': '1000baseT',
             'expected': ['media', 'media_select', 'media_type']}

    test2 = {'words': ['media:', 'Ethernet', '10Gbase-T', 'status:', 'active'],
             'media': 'Ethernet',
             'media_type': '10Gbase-T',
             'expected': ['media', 'media_type']}


# Generated at 2022-06-22 23:51:38.219375
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    ifconfig_path = obj.module.get_bin_path('ifconfig')
    ifconfig_options = '-a'
    interfaces, ips = obj.get_interfaces_info(ifconfig_path, ifconfig_options)
    assert('gif0' in interfaces)


# Generated at 2022-06-22 23:51:49.327942
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    _ifconfig_path = '/usr/sbin/ifconfig'

    _platform_module_mock = _mock_module()

# Generated at 2022-06-22 23:52:01.776082
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_module = GenericBsdIfconfigNetwork(module)
    interface = 'predefined_interface'
    ipv4 = '1.1.1.1'
    netmask = '255.255.0.0'
    broadcast = '2.2.2.2'
    network = '172.16.0.0'
    ipv6 = '::1'
    prefix = '24'
    scope = 'unicast'
    flags = ['UP', 'BROADCAST', 'RUNNING']
    addr_type = 'inet'
    current_if = {'device': interface, 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

# Generated at 2022-06-22 23:52:14.499691
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    fixtures = [
        # Linux
        ["nd6 options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>", "23"],
        # FreeBSD
        ["nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>", "29"],
    ]
    for fixture in fixtures:
        current_if = {'options': None}
        ips = {}
        network = GenericBsdIfconfigNetwork()
        network.parse_nd6_line(fixture, current_if, ips)
        assert current_if['options'] == fixture[1], "Expected options to be {0} but got {1}".format(fixture[1], current_if['options'])


# Generated at 2022-06-22 23:52:20.749256
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    gbifn = network.GenericBsdIfconfigNetwork()
    line = ["options=1234<BLAH>"]
    current_if = {}
    ips = {}
    gbifn.parse_options_line(line, current_if, ips)
    assert current_if['options'] == ['1234', 'BLAH']


# Generated at 2022-06-22 23:52:32.908858
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gbif = GenericBsdIfconfigNetwork()
    interfaces = {
        'eth0': {
            'ipv4': [
                {'address': '172.16.1.1'},
                {'address': '172.16.1.2'}
            ]
        }
    }
    default_interface = 'eth0'
    ipv4_defaults = {
        'interface': 'eth0',
        'address': '172.16.1.1'
    }

    expected = {
        'interface': 'eth0',
        'address': '172.16.1.1',
        'ipv4': [
            {'address': '172.16.1.1'},
            {'address': '172.16.1.2'}
        ]
    }

# Generated at 2022-06-22 23:52:45.758157
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    """

    """
    # test different interface types
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'metric', '1']
    current_if = GenericBsdIfconfigNetwork.parse_interface_line(GenericBsdIfconfigNetwork(), words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['mtu'] == '33184'
    assert current_if['type'] == 'loopback'
    assert current_if['macaddress'] == 'unknown'
    assert current_if['metric'] == '1'


# Generated at 2022-06-22 23:52:57.513581
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    ifconfig = GenericBsdIfconfigNetwork()

    # input: words = [ 'en0:', 'flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500' ]
    # expected_value: current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'macaddress': 'unknown', 'metric': '0', 'mtu': '1500'}

# Generated at 2022-06-22 23:53:04.780560
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    net = GenericBsdIfconfigNetwork()
    line1 = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384\n'
    line2 = 'mtu 16384\n'
    line3 = 'en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500\n'
    line4 = 'en1: flags=963<UP,BROADCAS4T,SMART,RUNNING,PROMISC,SIMPLEX> mtu 1500\n'
    line5 = 'en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n'

# Generated at 2022-06-22 23:53:17.643225
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = os.path.join(os.path.dirname(__file__), 'ifconfig.out')
    module_mock.run_command.return_value = (0, '', '')
    module_mock.check_for_ipv6.return_value = True
    module_mock.run_command.return_value = (0, open(module_mock.get_bin_path.return_value, 'rb').read(), '')

    network_facts = GenericBsdIfconfigNetwork(module_mock).populate()

    assert network_facts['ge0']['type'] == 'ether'
    assert network_facts['ge0']['media'] == 'Ethernet autoselect'


# Generated at 2022-06-22 23:53:25.495088
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = MagicMock()
    platform = 'Generic_BSD_Ifconfig'

    class_to_test = GenericBsdIfconfigNetwork(module)
    iface_info = {'device': 'lo0', 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict()

    class_to_test.parse_options_line(['options=5b'], iface_info, ips)
    assert iface_info['options'] == ["5b"]


# Generated at 2022-06-22 23:53:33.664075
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_input = {'iface1': {'media': 'ether'}, 'iface2': {'media': 'unknown'}, 'iface3': {'media': 'ether'}}
    test_output = {'iface1': {'media': 'ether', 'type': 'ether'}, 'iface2': {'media': 'unknown'},
                   'iface3': {'media': 'ether', 'type': 'ether'}}
    assert GenericBsdIfconfigNetwork.detect_type_media(test_input) == test_output

# Generated at 2022-06-22 23:53:41.545553
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.network.bsd.facts import Facts

    defaults = load_platform_subclass(Facts, 'bsd')
    network = load_platform_subclass(GenericBsdIfconfigNetwork, 'Generic_BSD_Ifconfig', defaults)

    module = AnsibleModule({})
    module.params = {'dyndns_domain': 'tun.example.com'}
    network.module = module

    words = ['options=3','rest','of','string','is','ignored']
    current_if = {'device': 'tun0'}
    ips = []
    network.parse_options_line(words, current_if, ips)


# Generated at 2022-06-22 23:53:52.577687
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    print('Testing GenericBsdIfconfigNetwork.parse_interface_line')

    words = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384".split()
    expected_interface_line = dict(
        device='lo0',
        ipv4=[],
        ipv6=[],
        type='loopback',
        flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        metric='0',
        mtu='16384',
        macaddress='unknown'
    )
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    interface_line = generic_bsd_ifconfig_network.parse_interface_line(words)
    # Assert that all values in interface line are identical to the expected

# Generated at 2022-06-22 23:54:03.146849
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = Mock()
    ifconfig_path = '/bin/ifconfig'
    platform = 'Generic_BSD_Ifconfig'
    module.get_bin_path.return_value = ifconfig_path
    test_obj = GenericBsdIfconfigNetwork(module)
    test_iface = 'lo0'
    test_words = ['lladdr', '00:00:00:00:00:00']
    test_current_if = {}
    test_ips = {}
    test_obj.parse_lladdr_line(test_words, test_current_if, test_ips)
    assert test_current_if['lladdr'] == '00:00:00:00:00:00'


# Generated at 2022-06-22 23:54:14.360201
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()

    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-22 23:54:27.286262
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    default_ipv4 = {
        'interface': 'lo0'
    }

# Generated at 2022-06-22 23:54:39.329773
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    set_module_args({'gather_subset': '!all,!min'})

# Generated at 2022-06-22 23:54:40.445713
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # TODO
    pass

# Generated at 2022-06-22 23:54:45.267639
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # Create a fake module for testing
    module = AnsibleModule(argument_spec = dict())

    # Create a fake module for testing
    network_module = GenericBsdIfconfigNetwork(module)
    assert network_module.platform == "Generic_BSD_Ifconfig"


# Generated at 2022-06-22 23:54:58.268768
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Test the context for the merge_default_interface

    # create an object to test
    network_facts_object = GenericBsdIfconfigNetwork()

    # create the input parameters
    defaults = {'interface': 'en0'}

    # create the sample interfaces list
    interfaces = {'en0': {'ipv4': [{'address': '127.0.0.1'}],
                          'ipv6': [{'address': '0:0:0:0:0:0:0:0'}],
                          'macaddres': '01:23:45:67:89:ab',
                          'type': 'loopback'}}

    # call method to be tested
    network_facts_object.merge_default_interface(defaults, interfaces, 'ipv4')

    # we expect that the dictionary

# Generated at 2022-06-22 23:55:06.968415
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    '''
    Testing GenericBsdIfconfigNetwork::parse_interface_line
    '''

    # This is a test for GenericBsdIfconfigNetwork.parse_interface_line
    # It shows how you setup a test for a method of a class.
    # The test is for the first branch of the method.  
    # You instantiate the class, call the method with arguments.
    # Then you check for the results.

    gn = GenericBsdIfconfigNetwork()
    words = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if = gn.parse_interface_line(words)
    assert current_if['mtu'] == '33184'

# Generated at 2022-06-22 23:55:12.897007
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    m = GenericBsdIfconfigNetwork(None)
    current_if = {}
    ips = {}
    line = "some stuff unknown"
    words = line.split()
    m.parse_unknown_line(words, current_if, ips)
    assert not current_if
    assert not ips



# Generated at 2022-06-22 23:55:19.525122
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    network = GenericBsdIfconfigNetwork(module)
    results = network.populate()
    assert "interfaces" in results


# Generated at 2022-06-22 23:55:29.466020
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:55:40.995824
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    iface = GenericBsdIfconfigNetwork()
    current_if = {'ipv6': []}
    words = ['inet6', '3fff::1%lo0', 'prefixlen', '64', 'scopeid', '0x4', '0x4']
    iface.parse_inet6_line(words, current_if, {})
    assert '3fff::1' == current_if['ipv6'][0]['address']
    assert '64' == current_if['ipv6'][0]['prefix']
    assert '0x4' == current_if['ipv6'][0]['scope']
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x1']

# Generated at 2022-06-22 23:55:51.265619
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())

    platform_class = 'ansible.module_utils.facts.network.interfaces.GenericBsdIfconfig'
    platform = __import__(platform_class, fromlist=[platform_class])

    network = platform.GenericBsdIfconfigNetwork()
