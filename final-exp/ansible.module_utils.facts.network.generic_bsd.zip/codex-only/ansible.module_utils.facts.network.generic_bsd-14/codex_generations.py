

# Generated at 2022-06-22 23:45:57.683118
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = Mock()
    gn = GenericBsdIfconfigNetwork(module)
    words = ['eth0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'metric', '1']
    current_if = gn.parse_interface_line(words)
    assert current_if['device'] == 'eth0'
    assert current_if['type'] == 'unknown'
    assert current_if['macaddress'] == 'unknown'
    assert 'LOOPBACK' not in current_if['flags']
    assert 'UP' in current_if['flags']
    assert current_if['metric'] == '1'
    assert current_if['mtu'] == '1500'

# Generated at 2022-06-22 23:46:08.146679
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    '''
    Unit test for method populate of class GenericBsdIfconfigNetwork
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Mock module arguments
    args = dict(
        config_file='',
        exec_command=standard_exec_command
    )

    # Mock part of the ansible module
    mock_module = type('MockModule', (basic.AnsibleModule,), args)

    # We need to inject the AnsibleModule mock into the GenericBsdIfconfigNetwork class
    network = GenericBsdIfconfigNetwork(mock_module)

    # Execute method to be tested
    network_facts = network.populate()

    assert_network_facts(network_facts)


# Generated at 2022-06-22 23:46:20.575296
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    '''Test method merge_default_interface of class GenericBsdIfconfigNetwork'''

    # Create instance of class GenericBsdIfconfigNetwork.
    net = GenericBsdIfconfigNetwork()

    # With no default interface set, the default interface dictionary is not modified.
    defaults = {'interface': None}

# Generated at 2022-06-22 23:46:30.498664
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec={})
    mock_ifconfig_output = "ifnet0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> mtu 1500\noptions=1<RXCSUM,TXCSUM>\nnd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>"
    result = {}
    ipv4_addresses = []
    ipv6_addresses = []
    network_facts = Network(module=module)
    network_facts.get_interfaces_info(mock_ifconfig_output)
    result = network_facts.parse_options_line(mock_ifconfig_output[0].split(), result, ipv4_addresses, ipv6_addresses)

# Generated at 2022-06-22 23:46:42.459128
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Setup test fixture - create a mock object of class GenericBsdIfconfigNetwork
    gnicn = GenericBsdIfconfigNetwork()

    # Setup test data
    #   gnicn.root_dir = '/'
    #   gnicn.module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    #
    #   dummy_defaults = {'interface': 'eth0'}
    #   dummy_interfaces = {'eth0': {}}
    #   dummy_ip_type = ''

    # Test code
    gnicn.merge_default_interface(dummy_defaults, dummy_interfaces, dummy_ip_type)

    # Return assertion results
    return dummy_interfaces == dummy_interfaces

# Generated at 2022-06-22 23:46:54.979665
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:47:07.811016
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module=None)
    expected = {'eth0': {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'ether', 'media': 'Ethernet autoselect (1000baseT <full-duplex>)', 'status': 'active'}}
    interfaces = {'eth0': {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'media': 'Ethernet autoselect (1000baseT <full-duplex>)', 'status': 'active'}}
    result = generic_bsd_ifconfig_network.detect_type_media(interfaces)
    assert result == expected



# Generated at 2022-06-22 23:47:19.797179
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    def test_GenericBsdIfconfigNetwork_get_default_interfaces():
        platform = 'Generic_BSD_Ifconfig'

        def populate(self, collected_facts=None):
            network_facts = {}
            ifconfig_path = self.module.get_bin_path('ifconfig')

            if ifconfig_path is None:
                return network_facts

            route_path = self.module.get_bin_path('route')

            if route_path is None:
                return network_facts

            default_ipv4, default_ipv6 = self.get_default_interfaces(route_path)
            interfaces, ips = self.get_interfaces_info(ifconfig_path)
            interfaces = self.detect_type_media(interfaces)


# Generated at 2022-06-22 23:47:21.589324
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = GenericBsdIfconfigNetwork(module)

    assert network_facts.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-22 23:47:31.101343
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import platform
    import socket

    # (1) Test for Ipv4 address without broadcast
    interval = {}
    current_if = {}
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']

    if platform.system() == "FreeBSD":
        current_if['ipv4'] = []
    else:
        current_if['ipv4'] = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )

    GenericBsdIfconfigNetwork.parse_inet_line(interval, words, current_if, current_if['ipv4'])

# Generated at 2022-06-22 23:47:43.663203
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    mock_rc = MagicMock(return_value=(None, None, None))
    mock_run_command = MagicMock(side_effect=mock_rc)
    module.run_command = mock_run_command

    module.run_command = mock_run_command
    module.get_bin_path = MagicMock(return_value='/bin/route')

    ipv4_output = [
        'destination: default',
        'gateway: 192.168.1.1',
        'interface: en0'
    ]
    ipv4_error = [
        ''
    ]
    ipv4_rc = (0, ipv4_output, ipv4_error)


# Generated at 2022-06-22 23:47:48.721895
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    n = GenericBsdIfconfigNetwork()
    assert n.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-22 23:47:52.815127
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    options = GenericBsdIfconfigNetwork.get_options('LOOPBACK, RUNNING, IPRUNNING')
    assert options == ['LOOPBACK', 'RUNNING', 'IPRUNNING']

# Generated at 2022-06-22 23:47:57.299401
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    bsd_ifc_net_obj = GenericBsdIfconfigNetwork(module)
    ifc_info = bsd_ifc_net_obj.get_interfaces_info('/sbin/ifconfig')
    assert ifc_info


# Generated at 2022-06-22 23:48:10.030736
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {'ipv6': []}
    ips = dict(
        all_ipv6_addresses=[],
    )

    # Set up function arguments
    words = 'inet6 fe80::1%lo0 prefixlen 64 scopeid 0x6'.split()
    # Run function
    generic_bsd_ifconfig_network.parse_inet6_line(words, current_if, ips)
    # Check results
    ipv6_addresses = current_if['ipv6']
    assert len(ipv6_addresses)==1
    address = ipv6_addresses[0]
    assert address['address'] == 'fe80::1%lo0'
    assert address['prefix'] == '64'

# Generated at 2022-06-22 23:48:20.418663
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    network_data = GenericBsdIfconfigNetwork()
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    words = ['lladdr', '00:0c:29:32:ac:dc']
    network_data.parse_lladdr_line(words, current_if, ips)

    assert current_if.get('lladdr') == '00:0c:29:32:ac:dc'


# Generated at 2022-06-22 23:48:27.098656
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # TODO: embed a freebsd ifconfig output into the test and use that instead
    # of mocking
    g = GenericBsdIfconfigNetwork()
    # First test, with no broadcast line
    iface = {}
    ips = {}
    line_words = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>',
                  'metric', '0', 'mtu', '1500', 'ether', '00:a0:cc:f0:c0:01',
                  'inet', '10.153.0.1', 'netmask', '0xffffff00', 'inet', '10.153.0.2',
                  'netmask', '0xffffff00']

# Generated at 2022-06-22 23:48:39.810962
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    mod = MagicMock()
    mod.run_command.return_value = (0, MOCK_IFCONFIG_OUTPUT, '')
    gen = GenericBsdIfconfigNetwork(mod)

    facts = gen.populate()
    assert(facts['default_ipv4']['address'] == '192.168.1.1')
    assert(facts['default_ipv4']['hwaddr'] == '00:0f:1f:fe:0d:c2')
    assert(facts['default_ipv4']['interface'] == 'vlan0')
    assert(facts['default_ipv4']['netmask'] == '0xffffff00')
    assert(facts['default_ipv4']['network'] == '192.168.1.0')

# Generated at 2022-06-22 23:48:53.242502
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Arrange
    test_object = GenericBsdIfconfigNetwork()
    test_interfaces = {'eth0': {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                       'lo0': {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}}
    test_interfaces['eth0']['media'] = 'ether'
    test_interfaces['eth0']['status'] = 'active'
    test_interfaces['eth0']['macaddress'] = 'mac'
    test_interfaces['lo0']['media'] = 'loopback'
    test_interfaces['lo0']['status'] = 'active'

# Generated at 2022-06-22 23:48:56.918006
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible.module_utils.facts.networking.generic_bsd import GenericBsdIfconfigNetwork
    m = GenericBsdIfconfigNetwork(None)
    o = {}
    m.parse_unknown_line(['word', 'otherword'], o, {})
    assert 'words' not in o
    o = {'words': []}
    m.parse_unknown_line(['word', 'otherword'], o, {})
    assert o['words'] == ['word', 'otherword']
    m.parse_unknown_line(['word', 'otherword'], {}, {})
    assert 'words' not in o

# Generated at 2022-06-22 23:49:10.423581
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    # TODO: not enough coverage of parsing rules
    # TODO: also not enough variation in input
    m = GenericBsdIfconfigNetwork(dict(module=AnsibleModule(argument_spec=dict())))
    ifconfig_path = '/sbin/ifconfig'


# Generated at 2022-06-22 23:49:19.531799
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class TestClass():
        def __init__(self):
            pass
        def get_bin_path(self, arg):
            return "/sbin/route"

    test_obj = GenericBsdIfconfigNetwork()
    test_obj.module = TestClass()

    __tracebackhide__ = True
    val = test_obj.get_default_interfaces("/sbin/route")
    assert val == ({'interface': 'lo0'}, {'interface': 'lo0'})


# Generated at 2022-06-22 23:49:30.392089
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:49:35.417643
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    gb = GenericBsdIfconfigNetwork()
    def check(words, expect):
        result = gb.parse_interface_line(words)
        if result != expect:
            print("Failed: %s" % words)
            print("Expected: %s" % expect)
            print("Received: %s" % result)
        assert expect == result
    # FreeBSD testcase

# Generated at 2022-06-22 23:49:39.534979
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec=dict())
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    cbni = GenericBsdIfconfigNetwork()
    words = ['status:', 'active']
    cbni.parse_status_line(words,current_if,ips)
    module.exit_json(changed=False, ansible_facts=dict(
        network_facts=dict(current_if=current_if, ips=ips)
    ))


# Generated at 2022-06-22 23:49:47.212095
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    """
    Test method parse_tunnel_line of class GenericBsdIfconfigNetwork
    """
    obj = GenericBsdIfconfigNetwork()

    words = ['tunnel', 'inet', '192.168.121.184', '-->', '192.168.121.1', 'mtu', '1457', 'tunnel',
                'encap', 'GRE', 'tos', '0x0', 'ttl', '64', 'nopmtudisc']

    current_if = {'device': 'utun1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': ['192.168.121.184'], 'all_ipv6_addresses': []}


# Generated at 2022-06-22 23:49:55.818965
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_object = GenericBsdIfconfigNetwork()
    assert test_object.merge_default_interface(
        {'interface': 'eth0'},
        {'eth0': {'ipv4': [{'address': '192.168.0.1', 'netmask': '255.255.255.0'}]}},
        'ipv4') == {'interface': 'eth0',
                    'address': '192.168.0.1',
                    'netmask': '255.255.255.0'}


# Generated at 2022-06-22 23:50:08.553117
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import tempfile
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as class_to_test

    current_if = {}
    ips = dict()
    class_to_test.parse_inet_line(['inet', '127.0.0.1'], current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'
    assert current_if['ipv4'][0]['broadcast'] == '127.255.255.255'

# Generated at 2022-06-22 23:50:17.678440
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Test setup
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.get_bin_path = Mock(return_value='')
    test_module.run_command = Mock(return_value=(0, '', ''))

    generic_network = GenericBsdIfconfigNetwork(test_module)

    # Test execution
    ip4, ip6 = generic_network.get_default_interfaces('')

    # Test assertions
    assert ip4 == {}
    assert ip6 == {}


# Generated at 2022-06-22 23:50:27.913799
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # For some reason this test fails
    # when run as part of the suite
    # but not when executed in isolation
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

    words = ['ether', '00:11:22:33:44:55']

    network.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '00:11:22:33:44:55'
    assert current_if['type'] == 'ether'

# Generated at 2022-06-22 23:50:41.360144
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    output = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
    options=1203<RXCSUM,TXCSUM,TXSTATUS,SW_TIMESTAMP>
    inet 127.0.0.1 netmask 0xff000000
    inet6 ::1 prefixlen 128
    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    nd6 options=201<PERFORMNUD,DAD>
    groups: lo"""
    test = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:50:51.027289
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    test_line1 = ['options=80027<LINKSTATE,LLDEBUG,LINK1,AUTOCONF6,ACCEPT_RTADV>']
    test_line2 = ['options=80000<LINKSTATE>']
    module = type('obj', (object,), dict())()
    # module.run_command = MagicMock(return_value=(0, '', ''))
    g = GenericBsdIfconfigNetwork(module)
    g.parse_options_line(test_line1, current_if, ips)
    g.parse_options_line(test_line2, current_if, ips)

# Generated at 2022-06-22 23:51:03.587975
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    network = GenericBsdIfconfigNetwork()

    current_if = dict(device='em0', options=[])
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    network.parse_nd6_line(['nd6', 'options=1<PERFORMNUD>',
                           'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>',
                           'nd6', 'options=23<PERFORMNUD,AUTO_LINKLOCAL,ROUTER_ADVERT>'],
                           current_if, ips)

    assert_equals(current_if['options'], ['PERFORMNUD', 'AUTO_LINKLOCAL', 'ROUTER_ADVERT'])


# Generated at 2022-06-22 23:51:15.752562
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    n = Network()
    n.get_options("")
    assert n.get_options("") == []
    assert n.get_options("<>") == []
    assert n.get_options("<UP,LOOPBACK,RUNNING,MULTICAST>") == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert n.get_options("<LOOPBACK,RUNNING,MULTICAST>") == ['LOOPBACK', 'RUNNING', 'MULTICAST']
    assert n.get_options("UP,LOOPBACK,RUNNING,MULTICAST") == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-22 23:51:28.265044
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # arrange
    module = MockModule()
    mod = GenericBsdIfconfigNetwork()
    mod.module = module
    words = ["ip6.int_if", "ether", "xx:xx:xx:xx:xx:xx"]
    current_if = {'device': 'ip6.int_if', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    expected_macaddress = "xx:xx:xx:xx:xx:xx"

    # act
    mod.parse_ether_line(words, current_if, ips)
    
    # assert
    assert current_if['macaddress'] == expected_macaddress

# Generated at 2022-06-22 23:51:38.136856
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    # Test full and empty 'ifconfig -a' output
    platform_facts = dict(
        distrib_id='FreeBSD',
        distrib_release='11.0-RELEASE',
        distrib_codename='RELEASE',
    )
    module.platform_system = lambda: 'FreeBSD'
    # Test full and empty 'ifconfig -a' output

# Generated at 2022-06-22 23:51:43.113918
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    GenericBsdIfconfigNetwork = Generic_BSD_Ifconfig()
    my_current_if = {}
    words = ['options=80000<LINKSTATE>']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    GenericBsdIfconfigNetwork.parse_options_line(words, my_current_if, ips)
    assert my_current_if['options'] == ['LINKSTATE']


# Generated at 2022-06-22 23:51:55.942967
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    class FakeModule(object):
        def __init__(self, params=None):
            self.params = params


# Generated at 2022-06-22 23:52:04.530448
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # If the passed in object is None, or the passed in object has no attribute
    # 'module', then the call to GenericBsdIfconfigNetwork.parse_lladdr_line will
    # raise an exception.
    class Object(object):
        pass

    obj = Object()
    with pytest.raises(AttributeError):
        iface_module.GenericBsdIfconfigNetwork.parse_lladdr_line(obj, None, None, None)

    obj.module = iface_module.AnsibleModule(argument_spec=dict())
    with pytest.raises(AttributeError):
        iface_module.GenericBsdIfconfigNetwork.parse_lladdr_line(obj, None, None, None)

# Generated at 2022-06-22 23:52:13.700124
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    option_string = [
        ['ether aa:bb:cc:dd:ee:ff', {'macaddress': 'aa:bb:cc:dd:ee:ff'}],
        ['ether', {}],
        ['ether aa:bb:cc:dd:ee:g0', {}],
    ]

    for words, expected in option_string:
        current_if = {}
        ifc = GenericBsdIfconfigNetwork()
        ifc.parse_ether_line(words.split(), current_if, {})
        assert current_if == expected

# Generated at 2022-06-22 23:52:20.749041
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # arrange
    input = ['lladdr', '00:11:22:33:44:55']
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    # act
    network.parse_lladdr_line(input, current_if, ips)

    # assert
    assert current_if == {'lladdr': '00:11:22:33:44:55'}


# Generated at 2022-06-22 23:52:24.488256
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    '''
    Test get_interfaces_info method of class GenericBsdIfconfigNetwork
    '''
    module = AnsibleModule(
        argument_spec = dict()
    )

    # use from_json instead of from_yaml to avoid warnings from deepdiff
    if_info = json.loads(IF_INFO_JSON)
    ips = json.loads(IPS_JSON)

    gbin = GenericBsdIfconfigNetwork()
    interfaces, ips_out = gbin.get_interfaces_info('ifconfig_path', 'ifconfig_options')
    assert if_info == interfaces
    assert ips == ips_out

# Generated at 2022-06-22 23:52:36.737589
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Test cases
    test_cases = list()
    input_str = "vlan8: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500\n"
    expect_dict = {'device': 'vlan8',
                   'ipv4': [],
                   'ipv6': [],
                   'type': 'unknown',
                   'flags': ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST'],
                   'macaddress': 'unknown',
                   'metric': '0',
                   'mtu': '1500'}
    test_cases.append(dict(input=input_str, expect=expect_dict))

# Generated at 2022-06-22 23:52:49.470502
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    net = GenericBsdIfconfigNetwork()
    device = 'lo'
    current_if = {'device': device, 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}
    ifconfig = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384"
    words = ifconfig.split()
    words.append("ether")
    words.append("00:00:00:00:00:00")
    net.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == "00:00:00:00:00:00"
    assert current_if['type'] == 'loopback'


# Generated at 2022-06-22 23:52:59.419785
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    print("Starting test test_GenericBsdIfconfigNetwork_parse_ether_line.")


# Generated at 2022-06-22 23:53:05.153426
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    network = GenericBsdIfconfigNetwork()

    # FreeBSD has options like this...
    input = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>',
             'mtu', '1500']
    current_if = {}
    ips = {}
    network.parse_nd6_line(input, current_if, ips)
    assert(current_if['options'] == ['PERFORMNUD', 'AUTO_LINKLOCAL'])

# Generated at 2022-06-22 23:53:15.130447
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    os_platform = 'GenericBsdIfconfigNetwork'
    options = {}
    inst = GenericBsdIfconfigNetwork()

    check = { 'current_if' : {'device':'vnet0'}, 'ips':{}}
    words = ['status:','active']
    inst.parse_status_line(words, check['current_if'], check['ips'])
    assert check == { 'current_if' : {'device':'vnet0', 'status': 'active'}, 'ips': {}}



# Generated at 2022-06-22 23:53:16.802109
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    run_ansible_module_unit_test(GenericBsdIfconfigNetwork, 'test_GenericBsdIfconfigNetwork_get_interfaces_info.py')

# Generated at 2022-06-22 23:53:28.711610
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    test_interface = GenericBsdIfconfigNetwork()
    data_route_result = b'interface: em0\ngateway: 192.168.1.1\n'
    route_result = (0,data_route_result,None)
    default_ipv4_data_route_result = {'gateway': '192.168.1.1', 'interface': 'em0'}
    data_route_result_ipv6 = b'interface: em0\ngateway: fe80::xxxx:xxxx:xxxx:xxxx%em0\n'
    route_result_ipv6 = (0,data_route_result_ipv6,None)

# Generated at 2022-06-22 23:53:29.880154
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    pass



# Generated at 2022-06-22 23:53:39.351860
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    cmd = 'ifconfig -a'

# Generated at 2022-06-22 23:53:44.203300
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    generic_bsd = GenericBsdIfconfigNetwork()
    words=['status:','active']
    current_if={'status': 'unknown'}
    ips={}
    generic_bsd.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:53:51.279831
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import sys
    import subprocess
    import tempfile
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'route')
    test_files = os.listdir(fixture_path)
    orig_exists = os.path.exists

    temp_path = tempfile.mkdtemp()

    # Monkey Patch exists
    def my_exists(path):
        if path == '/usr/sbin/route':
            return True
        return orig_exists(path)


# Generated at 2022-06-22 23:53:58.251768
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    option_csv = 'UP,BROADCAST,RUNNING,MULTICAST'
    option_list = ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']
    result = generic_bsd_ifconfig_network.get_options(option_csv)
    assert result == option_list


# Generated at 2022-06-22 23:54:01.212974
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module_instance = GenericBsdIfconfigNetwork()
    # input
    output = module_instance.get_default_interfaces("/sbin/route")
    
    # assert that output matches 'expected'
    assert(output is not None)



# Generated at 2022-06-22 23:54:07.200176
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    _GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    words = ['inet6', 'fe80::a00:27ff:fef6:34c8%ath0', 'prefixlen', '64', 'scopeid', '0x3']
    current_if = {'ipv6': []}
    ips = dict(
        all_ipv6_addresses=[],
    )
    _GenericBsdIfconfigNetwork.parse_inet6_line(words, current_if, ips)
    assert current_if == {'ipv6': [{'address': 'fe80::a00:27ff:fef6:34c8', 'prefix': '64', 'scope': '0x3'}]}

# Generated at 2022-06-22 23:54:17.105459
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork.
    """
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)
    platform = network.platform
    platform = platform[0].upper() + platform[1:]
    if platform in ('Freebsd', 'Openbsd', 'Macos'):
        # FreeBSD and OpenBSD both return "RTNETLINK answers: Invalid argument" with IPv6 routing
        # MacOS 10.15.1 Catalina has the same behaviour
        assert network.get_default_interfaces()[1] == {}
        assert network.get_default_interfaces()[0]['interface'] == 'lo0'

# Generated at 2022-06-22 23:54:29.979715
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    import copy
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:54:41.702448
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    mac_address = '74:b5:0f:a1:4a:08'
    iface = 'en0'
    words = ['lladdr', mac_address]
    network_module = GenericBsdIfconfigNetwork()
    interfaces = {iface: {'device': iface, 'ipv4': [], 'ipv6': [], 'type': 'unknown',
                          'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'],
                          'mtu': 1500, 'metric': 0}}
    current_if = interfaces[iface]
    network_module.parse_lladdr_line(words, current_if, {})
    assert current_if['lladdr'] == mac_address


# Generated at 2022-06-22 23:54:54.575442
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    stream = Mock()

# Generated at 2022-06-22 23:55:05.273827
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    inst = GenericBsdIfconfigNetwork()

    # test merging default ipv4 interface
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0':{'ipv4':[{'address': '127.0.0.1', 'netmask': '255.0.0.0'}, {'address': '127.0.0.2'}]}}
    inst.merge_default_interface(defaults, interfaces, 'ipv4')
    assert '127.0.0.1' == defaults['address']
    assert '255.0.0.0' == defaults['netmask']

    # test merging default ipv6 interface
    defaults = {'interface': 'lo0'}

# Generated at 2022-06-22 23:55:09.489884
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    # Test for method get_options(option_string)
    # Test positive return value
    # Positive test: Test for method get_options(option_string)
    # of class GenericBsdIfconfigNetwork
    assert GenericBsdIfconfigNetwor

# Generated at 2022-06-22 23:55:19.406920
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    ifconfig = GenericBsdIfconfigNetwork()
    line = ['en5:', 'flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'ether', '00:1f:5b:82:d8:c4', 'nd6', 'options=1<PERFORMNUD>', 'media:', 'autoselect', '(1000baseT<full-duplex>', ')', 'status:', 'active']

# Generated at 2022-06-22 23:55:29.394764
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    net_facts = GenericBsdIfconfigNetwork()

    output = ['options=19b']

    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    net_facts.parse_options_line(output, current_if, ips)
    assert current_if['options'] == ['19b']

    output = ['options=19b,2a4']
    current_if = {}
    net_facts.parse_options_line(output, current_if, ips)
    assert current_if['options'] == ['19b', '2a4']

    output = ['options=39b']
    current_if = {}
    net_facts.parse_options_line(output, current_if, ips)
   

# Generated at 2022-06-22 23:55:40.943310
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    _temp_class = GenericBsdIfconfigNetwork()
    # Set up test parameters
    words = ['options=88904<LINKSTATE,VLAN_MTU,JUMBO_MTU,LOOPBACK,VLAN_HWTAGGING,VLAN_HWCSUM,POLLING,TSO3,TSO4,TSO6,LRO,NO_LINKSTATE,NO_CAPTIVE_PORTAL,NETMAP,RXCSUM_IPV6,TXCSUM_IPV6,VLAN_HWTSO,VLAN_HWCSUM_TX>']
    current_if = {'device': 'lo0'}

# Generated at 2022-06-22 23:55:51.230409
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module_mock = MagicMock(return_value=None)
    module_mock.params = {'gather_subset': '!all,!min'}
    module_mock.check_mode = False