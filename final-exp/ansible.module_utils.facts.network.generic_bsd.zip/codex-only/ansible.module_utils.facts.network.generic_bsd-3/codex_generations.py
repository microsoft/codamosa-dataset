

# Generated at 2022-06-22 23:45:55.116405
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # initialize
    net = GenericBsdIfconfigNetwork()
    defaults = dict(
        interface='em0',
        gateway='192.168.1.1'
    )

# Generated at 2022-06-22 23:46:06.589915
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    from ansible.modules.network.generic_bsd import GenericBsdIfconfigNetwork

    # TODO: Provide the actual test cases
    f = GenericBsdIfconfigNetwork()
    words = "option".split()
    current_if = f.parse_interface_line(words)
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    f.parse_options_line(words, current_if, ips)
    f.parse_nd6_line(words, current_if, ips)
    f.parse_ether_line(words, current_if, ips)
    f.parse_media_line(words, current_if, ips)
    f.parse_status_line(words, current_if, ips)
   

# Generated at 2022-06-22 23:46:07.944198
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = GenericBsdIfconfigNetwork(module)
    # check if class create successfully
    assert network_facts is not None

# Generated at 2022-06-22 23:46:20.291327
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    c = GenericBsdIfconfigNetwork()
    
    words = ['eth0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1500', 'metric', '0']
    current_if = c.parse_interface_line(words)
    assert current_if['device'] == 'eth0'
    assert 'UP' in current_if['flags']
    assert 'BROADCAST' in current_if['flags']
    assert 'RUNNING' in current_if['flags']
    assert 'SIMPLEX' in current_if['flags']
    assert 'MULTICAST' in current_if['flags']
    assert current_if['mtu'] == '1500'
    assert current_if['metric'] == '0'
    

# Generated at 2022-06-22 23:46:30.345735
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    import shutil
    if shutil.which('ifconfig') is None:
        return

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork

    MOCK_MODULE_ARGS = {}
    MOCK_MODULE_KWARGS = {}
    module = AnsibleModule(argument_spec=MOCK_MODULE_ARGS, **MOCK_MODULE_KWARGS)

    netobj = GenericBsdIfconfigNetwork(module)

    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-22 23:46:42.742912
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    generic_bsd_ifconfig_net_obj = GenericBsdIfconfigNetwork()

    # Test case-1
    # Input:
    #      defaults = {'interface': 'lo0', 'address' : '127.0.0.1'},
    #      interfaces = {
    #            'lo0': {
    #                'device': 'lo0',
    #                'ipv4': [{
    #                    'address': '127.0.0.1',
    #                    'broadcast': '1.1.1.1',
    #                    'netmask': '255.0.0.0',
    #                    'network': '1.0.0.0'
    #                }, {
    #                    'address': '2.2.2.2',
    #                    'broadcast': '2.2.

# Generated at 2022-06-22 23:46:55.038100
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Skip if we don't have ifconfig
    ifconfig_path = module.get_bin_path('ifconfig')
    if ifconfig_path is None:
        module.fail_json(msg="ifconfig command not found in PATH. If this is a MacOS system please install ifconfig using `brew install net-tools`")

    network = GenericBsdIfconfigNetwork(module)
    network_facts = network.populate()

    assert network_facts['localhost']['default_ipv4']['address'] == '127.0.0.1'
    assert network_facts['localhost']['default_ipv6']['address'] == '::1'
    assert network_facts['localhost']['interfaces']

# Generated at 2022-06-22 23:47:08.284843
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # First we create an instance of our class
    # set_module_args(dict(
    #    test=True
    # ))
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    facts = GenericBsdIfconfigNetwork(module)

    # parse_inet_line is a static method, so we need to call it through the class
    result = facts.parse_inet_line(['inet', '192.168.1.10', 'netmask', '0xffffff00'], {}, {})
    # This is an example of a dictionary in python, and how we access things in it
    assert result['address']['address'] == '192.168.1.10'
    assert result['address']['netmask'] == '255.255.255.0'

# Generated at 2022-06-22 23:47:20.264234
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig = GenericBsdIfconfigNetwork()
    ifconfig.module = MagicMock()
    ifconfig.module.run_command.return_value = (0, ifconfig_sample_output, '')
    ifconfig.module.get_bin_path.return_value = "/sbin/ifconfig"

# Generated at 2022-06-22 23:47:30.790728
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:47:43.415349
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # get object
    gen_bif_net = GenericBsdIfconfigNetwork()
    words = ['inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['macaddress'] = 'unknown'
    current_if['flags'] = ['LOOPBACK', 'UP', 'RUNNING']
    current_if['mtu'] = '33184'
    current_if['metric'] = '0'
    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )


# Generated at 2022-06-22 23:47:56.509317
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    module = AnsibleModule({})
    network_provider = GenericBsdIfconfigNetwork(module=module)
    interfaces = {'1': {'device': '1', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  '2': {'device': '2', 'ipv4': [], 'ipv6': [], 'type': 'unknown'},
                  '3': {'device': '3', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}}
    interfaces['1']['media'] = ''
    interfaces['2']['media'] = 'ether'
    interfaces['3']['media'] = 'ETHER'

# Generated at 2022-06-22 23:48:09.030869
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    # TODO: test that parse_interface_line calls populate_interface_line with the current_if
    #       and adds it to the interfaces dict

    # testing split words
    words = ['lo', '0', 'flags=8049', '<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '16384']
    current_if = dict(device='lo', ipv4=[], ipv6=[])
    iface = GenericBsdIfconfigNetwork()
    interface = iface.parse_interface_line(words)

    assert interface['device'] == 'lo'
    assert interface['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert interface['metric'] == '0'
    assert interface['mtu'] == '16384'

# Generated at 2022-06-22 23:48:14.213879
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    test = GenericBsdIfconfigNetwork()
    current_if = dict()
    ips = dict()
    words = ['lladdr', 'aa:bb:cc:dd:ee:ff']
    test.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == 'aa:bb:cc:dd:ee:ff'



# Generated at 2022-06-22 23:48:27.074405
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:48:39.810965
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = Mock()
    module.get_bin_path.return_value='/sbin/route'

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    with patch('os.path.exists') as mock_exists:
        mock_exists.return_value = True
        with patch.object(GenericBsdIfconfigNetwork, 'get_default_interfaces') as mock_get_default_interfaces:
            mock_get_default_interfaces.return_value = ({}, {})
            with patch.object(GenericBsdIfconfigNetwork, 'get_interfaces_info') as mock_get_interfaces_info:
                mock_get_interfaces_info.return_value = ({}, {})

# Generated at 2022-06-22 23:48:53.242614
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    
    interface1 = {}
    interface1['media'] = 'Ethernet autoselect mode 1000baseT status: active'
    interface2 = {}
    interface2['media'] = 'ETHER autoselect (1000baseT <full-duplex>) status: active'
    interface3 = {}
    interface3['media'] = 'IEEE 802.11 Wireless Ethernet MIB: autoselect status: active'
    interfaces = {}
    interfaces['interface1'] = interface1
    interfaces['interface2'] = interface2
    interfaces['interface3'] = interface3
    
    expected = {}
    expected['interface1'] = {'media': 'Ethernet autoselect mode 1000baseT status: active', 'type': 'ether'}

# Generated at 2022-06-22 23:49:06.856693
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    print("Testing method GenericBsdIfconfigNetwork.get_interfaces_info")
    
    # Test 1.1

# Generated at 2022-06-22 23:49:17.661379
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # ifconfig -a output.
    ifconfig_output = """lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384
        options=3<RXCSUM,TXCSUM>
        ether 00:00:00:00:00:00
        media: autoselect (none)
        status: active
        """
    # Generic_BSD_Ifconfig Network class object.
    network = GenericBsdIfconfigNetwork(None)
    # Calling the function parse_ether_line to validate device type.
    network.parse_ether_line(network.get_options("ether 00:00:00:00:00:00"),{},{})


# Generated at 2022-06-22 23:49:24.511468
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = FakeModule()
    network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    network.parse_nd6_line(words, current_if, ips)

# Generated at 2022-06-22 23:49:35.383396
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)
    ifconfig_path = module.get_bin_path('ifconfig')

    rc, out, err = module.run_command([ifconfig_path, '-a'])
    assert rc == 0
    assert len(out) > 10
    assert err == ''

    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    assert interfaces is not None
    assert len(interfaces) > 0
    assert ips is not None
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0


# Generated at 2022-06-22 23:49:47.389966
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_obj = GenericBsdIfconfigNetwork()

    def test_run(test_data_set):
        input_data, expected_output = test_data_set
        # Stub function with input data
        current_if = {}
        ips = {'all_ipv6_addresses': []}
        test_obj.parse_inet6_line(input_data, current_if, ips)
        assert current_if == expected_output['current_if']
        assert ips == expected_output['ips']

    # Test data

# Generated at 2022-06-22 23:49:58.893456
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    test_cases = (
        ('', []),  # expects an empty list
        ('foo', ['foo']),
        ('<>', []),  # expects an empty list
        ('<foo>', ['foo']),
        ('<foo,>', ['foo']),  # expects a single item list
        ('<foo,bar>', ['foo', 'bar']),
        ('<foo,bar,baz>', ['foo', 'bar', 'baz']),
        ('  <  foo ,   bar ,baz > ', ['foo', 'bar', 'baz']),
    )

    for option_string, expected in test_cases:
        given = GenericBsdIfconfigNetwork.get_options(option_string)
        assert given == expected



# Generated at 2022-06-22 23:50:04.454083
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = {
        'status': 'unknown',
    }
    result = GenericBsdIfconfigNetwork._parse_status_line(['status: ', 'active'], current_if, {})
    assert result == None
    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:50:06.279715
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass


# To be used with python -m unittest discover

# Generated at 2022-06-22 23:50:10.822914
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    p = GenericBsdIfconfigNetwork
    r = p.get_default_interfaces(p, route_path='unit_test_route')
    assert type(r) == tuple
    assert type(r[0]) == dict
    assert type(r[1]) == dict


# Generated at 2022-06-22 23:50:23.546630
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    def test_GenericBsdIfconfigNetwork_parse_inet_line_inner(words, current_if, ips):
        iface = GenericBsdIfconfigNetwork.parse_inet_line(words, current_if, ips)
        return iface
    words = ['vioif0:', 'flags=8008802<BROADCAST,SIMPLEX,MULTICAST,NEEDSGIANT>',
             'metric', '0', 'mtu', '1500', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'inet', '10.0.0.1',
             'netmask', '0xffffff00', 'broadcast', '10.0.0.255']
    current_if = []
    ips = []
    ret_val = test_GenericBsdIfconfig

# Generated at 2022-06-22 23:50:32.249900
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    interface_line = 'status: active'
    words = interface_line.split()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    GenericBsdIfconfigNetwork().parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:50:44.990561
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork(FakeModule(name='GenericBsdIfconfigNetwork_test_get_options'))
    assert network.get_options('UP,LOOPBACK,RUNNING,MULTICAST') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert network.get_options('UP,LOOPBACK,RUNNING,MULTICAST>') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert network.get_options('<UP,LOOPBACK,RUNNING,MULTICAST') == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-22 23:50:53.064960
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    """
    Test for method populate of class GenericBsdIfconfigNetwork
    """
    # Test with valid ifconfig and route commands
    ifconfig_path = "ifconfig"
    route_path = "route"
    ansible_facts = {}
    obj = GenericBsdIfconfigNetwork(ansible_facts)
    assert obj.populate(ifconfig_path, route_path)['default_ipv4'] == ""
    assert obj.populate(ifconfig_path, route_path)['default_ipv6'] == ""
    ifconfig_path = "ifconfig"
    route_path = "/bin/route"
    ansible_facts = {}
    obj = GenericBsdIfconfigNetwork(ansible_facts)
    assert obj.populate(ifconfig_path, route_path)['default_ipv4'] == ""


# Generated at 2022-06-22 23:51:04.599361
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    class FakeModule:
        class FakeConfig:
            default_ipv4 = {}
            default_ipv6 = {}
            def __init__(self, module):
                self.module = module

        def __init__(self):
            self.exit_args = {}
            self.fail_json_args = {}
            self.run_command_args = {}

        def run_command(self, args):
            self.run_command_args = args

# Generated at 2022-06-22 23:51:16.694592
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Fixture
    given = dict(interfaces={"en0": dict(type='loopback', media='Ethernet',
                                         ipv4=[dict(address='127.0.0.1',
                                                    netmask='255.0.0.0',
                                                    broadcast='127.255.255.255')]),
                             "lo0": dict(type='unknown', media='Loopback',
                                         ipv4=[dict(address='127.0.0.1',
                                                    netmask='255.0.0.0',
                                                    broadcast='127.255.255.255')])})

# Generated at 2022-06-22 23:51:28.739513
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    ifconfig = GenericBsdIfconfigNetwork(module)
    # TODO: all these tests should test for empty/missing strings, raise of ValueError, etc

    # Test a simple case, one option
    opt = '<UP,RUNNING>'
    assert sorted(ifconfig.get_options(opt)) == sorted(['UP', 'RUNNING'])

    # Test with some options not separated by commas
    opt = '<UP RUNNING>'
    assert sorted(ifconfig.get_options(opt)) == sorted(['UP', 'RUNNING'])

    # Test with some options quoted
    opt = '<"UP",RUNNING>'

# Generated at 2022-06-22 23:51:33.114136
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    g = GenericBsdIfconfigNetwork({})
    current_if = {'device': 'gif0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['tunnel', 'inet', '10.16.0.1', '-->', '10.16.0.2']
    g.parse_tunnel_line(words, current_if, ips)
    assert current_if['ipv4'] == [{'address': '10.16.0.1'}]
    assert current_if['type'] == 'tunnel'


# Generated at 2022-06-22 23:51:37.610936
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    from ansible.module_utils.basic import AnsibleModule

    ifname = '/sbin/ifconfig'

    gbin = GenericBsdIfconfigNetwork(AnsibleModule(argument_spec={}))

    current_if = dict(device='gif0')

    words = ['tunnel', 'inet', '192.0.2.2', '-->', '192.0.2.1', 'netmask', '0xffffffff', 'nd6', 'options=1<PERFORMNUD,ACCEPT_RTADV>']

    gbin.parse_tunnel_line(words, current_if, dict())

    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:51:43.208560
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    net = GenericBsdIfconfigNetwork({})
    interfaces = {
        'lo0': {
            'media': 'ether',
            'mtu': '33184',
            'device': 'lo0',
            'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
            'macaddress': 'unknown'
        }
    }
    assert 'ether' == net.detect_type_media(interfaces)['lo0']['type']
    assert 'ether' == interfaces['lo0']['type']

# Generated at 2022-06-22 23:51:56.036973
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    addresses = []
    words = ["lo0:", "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>", "mtu", "33184", "inet", "127.0.0.1", "netmask", "0xff000000", "inet", "alias", "127.1.1.1", "netmask", "0xff000000"]
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = generic_bsd_ifconfig_network.get_options(words[1])
    current_if['mtu'] = words[3]
    generic

# Generated at 2022-06-22 23:52:05.292366
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    gen_ifconfig_net_test = GenericBsdIfconfigNetwork()
    # test case 1
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '65536', 'metric', '1']
    current_if = gen_ifconfig_net_test.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['flags'] == ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']
    assert current_if['metric'] == '1'
    assert current_if['mtu'] == '65536'
    assert current_if['ipv4'] == []
    assert current_if['ipv6'] == []
    assert current_if['status']

# Generated at 2022-06-22 23:52:07.199757
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    GenericBsdIfconfigNetwork.populate() # test build arguments


# Generated at 2022-06-22 23:52:19.579942
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    _input = ['options=3<RXCSUM,TXCSUM>', 'media: Ethernet autoselect (1000baseT <full-duplex>)', 'status: active', 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    current_if = {}
    expected = {'macaddress': 'unknown', 'type': 'ether', 'ipv4': [], 'options': ['RXCSUM', 'TXCSUM'], 'device': 'en0', 'ipv6': [], 'media': 'Ethernet', 'status': 'active'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    _instance = GenericBsdIfconfigNetwork()
    _instance.parse_options_

# Generated at 2022-06-22 23:52:31.933752
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    gbi = GenericBsdIfconfigNetwork(None)
    # Test the method get_options of GenericBsdIfconfigNetwork
    assert (gbi.get_options('<UP,BROADCAST,RUNNING,MULTICAST>') ==
            ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'])
    assert (gbi.get_options('<BROADCAST,RUNNING,MULTICAST>') ==
            ['BROADCAST', 'RUNNING', 'MULTICAST'])
    assert (gbi.get_options('<UP,RUNNING,MULTICAST>') ==
            ['UP', 'RUNNING', 'MULTICAST'])

# Generated at 2022-06-22 23:52:44.709527
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = "/sbin/route"
    mock_module = unittest.mock.Mock()
    mock_module.run_command.side_effect = [
        (0, "default 10.0.2.2 UGS 0 8 sy0", ""),
        (0, "default fe80::a00:27ff:fe5c:f569%sy0 UGS 0 16 sy0", ""),
        ]
    expected_ipv4 = dict(interface='sy0', gateway='10.0.2.2', address='10.0.2.15')
    expected_ipv6 = dict(interface='sy0', gateway='fe80::a00:27ff:fe5c:f569', address='fe80::a00:27ff:fe5c:f569')
    network_facts = GenericB

# Generated at 2022-06-22 23:52:54.054849
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # method parse_unknown_line of class GenericBsdIfconfigNetwork
    # tests that the parse_unknown_line method does not change
    # anything for the known words, but does remove the unknown
    # words from the current_if dictionary
    words = ['word', 'another', 'known', 'unknown']
    current_if = {}
    network = GenericBsdIfconfigNetwork()
    network.parse_unknown_line(words, current_if, None)


# vim: se sw=4 ts=4 sts=4 ft=python et noro norl cin si ai

# Generated at 2022-06-22 23:53:02.989368
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModuleArgsMock({}, [])
    module.get_bin_path = mock.Mock(return_value='./bin/route')

    bsd = GenericBsdIfconfigNetwork(module)
    module.run_command = mock.Mock(return_value=(0, '''\
default: gateway 192.0.2.1
        local 192.0.2.222

default: gateway 2001:db8:1234::1
        local 2001:db8:1234::222
''', ''))
    ipv4, ipv6 = bsd.get_default_interfaces('route')

    expected = {'gateway': '192.0.2.1', 'address': '192.0.2.222', 'interface': 'default'}
    assert ipv4 == expected


# Generated at 2022-06-22 23:53:16.131076
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    network = GenericBsdIfconfigNetwork(module)
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST,SIMPLEX,MULTI_BCAST,NOINET6>') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'SIMPLEX', 'MULTI_BCAST', 'NOINET6']
    assert network.get_options('<UP,BROADCAST,RUNNING,MULTICAST,SIMPLEX>') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST', 'SIMPLEX']

# Generated at 2022-06-22 23:53:21.945465
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule({'module_setup': True})
    module.run_command = MagicMock()

    class DummyGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self, module):
            pass
    # nd6 options average out to one option per line
    for nd6 in ('nd6 options=23<PERFORMNUD,ACCEPT_RTADV>',):
        current_if = {}
        ips = []
        words = nd6.split()
        nd6_obj = DummyGenericBsdIfconfigNetwork(module)
        nd6_obj.parse_nd6_line(words, current_if, ips)
        assert current_if['options'] == ['PERFORMNUD', 'ACCEPT_RTADV']

# Generated at 2022-06-22 23:53:34.164697
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    '''
    Test the function GenericBsdIfconfigNetwork.detect_type_media
    '''

    # Create a dummy class to pass to the method
    test_class = GenericBsdIfconfigNetwork
    # Create a test interface dictionary

# Generated at 2022-06-22 23:53:42.781000
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():

    # Setup test data
    conf = "options=3<PERFORMNUD,ACCEPT_RTADV>"
    words = conf.split()
    current_if = {}
    ips = {}

    data = GenericBsdIfconfigNetwork()
    data.parse_nd6_line(words, current_if, ips)

    assert_equals(current_if['options'], ['PERFORMNUD', 'ACCEPT_RTADV'])


# Generated at 2022-06-22 23:53:48.275348
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():

    gbin = GenericBsdIfconfigNetwork()

    current_if = {'foo': 'bar'}
    ips = dict()
    words = ['lladdr', 'xx:xx:xx:xx:xx:xx']
    gbin.parse_lladdr_line(words, current_if, ips)
    assert current_if['foo'] == 'bar'
    assert current_if['lladdr'] == words[1]

# Generated at 2022-06-22 23:53:57.026530
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    mod = GenericBsdIfconfigNetwork()

    current_if = {'device': 'lo0'}
    ips = {}
    words = ['lladdr', '4a:49:43:4f:4e:4b:4a:43']
    mod.parse_lladdr_line(words, current_if, ips)

    assert current_if['lladdr'] == '4a:49:43:4f:4e:4b:4a:43'



# Generated at 2022-06-22 23:54:09.183142
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {'device': "lo0", 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Different address format of inet6 line as follows
    #inet6 ::1 prefixlen 128
    inet6_line1 = "inet6 ::1 prefixlen 128".split()
    generic_bsd_ifconfig_network.parse_inet6_line(inet6_line1, current_if, ips)
    assert current_if['ipv6'][0] == {'address': '::1', 'prefix': '128'}

# Generated at 2022-06-22 23:54:18.068362
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    networks = """
        inet6 fe80::5246:5dff:feb6:f721%lo0 prefixlen 64 scopeid 0x2 
        inet6 2607:f0d0:1002:0051:5246:5dff:feb6:f721 prefixlen 64 
        inet6 2607:f0d0:1002:0051:250:56ff:feb9:854c prefixlen 64 
        inet6 fe80::250:56ff:feb9:854c%em0 prefixlen 64 scopeid 0x1 
        """
    ipv6_addresses = []

    for line in networks.splitlines():
        words = line.strip().split()
        address = {'address': words[1]}

# Generated at 2022-06-22 23:54:26.414098
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class testargs:
        def __init__(self):
            self.run_command = fake_run_command
            self.has_ipv6 = True

    get_default_interfaces = GenericBsdIfconfigNetwork(testargs).get_default_interfaces
    interfaces = get_default_interfaces('route_path')
    assert interfaces[0]['interface'] == 'eth0'
    assert interfaces[1]['interface'] == 'eth0'



# Generated at 2022-06-22 23:54:37.909229
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # The test case.

    # The target object.
    obj = GenericBsdIfconfigNetwork()

    p = Mock()
    p.run_command.return_value = (0, "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384", "")

    obj.module = p

    # the method call
    gbi = GenericBsdIfconfigNetwork()
    words = ['options=3<RXCSUM,TXCSUM>']

    # The expected result.
    expected = {'options': ['RXCSUM', 'TXCSUM']}
    # compare the returned result with the expected.
    assert gbi.parse_options_line(words, expected, {}) is None
    assert expected == {'options': ['RXCSUM', 'TXCSUM']}

# Generated at 2022-06-22 23:54:50.844020
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule({})
    dut = GenericBsdIfconfigNetwork(module=module)

    interfaces = dut.get_interfaces_info('/sbin/ifconfig', ifconfig_options='-e')[0]
    assert 'en0' in interfaces
    assert 'ether' in interfaces['en0']
    assert 'media' in interfaces['en0']
    assert 'status' in interfaces['en0']
    assert 'mtu' in interfaces['en0']
    assert 'metric' in interfaces['en0']
    assert 'ipv4' in interfaces['en0']
    assert 'ipv6' in interfaces['en0']
    assert 'type' in interfaces['en0']
    assert interfaces['en0']['type'] == 'ether'

# Generated at 2022-06-22 23:54:58.205441
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network_platform = GenericBsdIfconfigNetwork()

    assert network_platform.get_options("UP") == []

    assert network_platform.get_options("UP,BROADCAST") == ['UP','BROADCAST']

    assert network_platform.get_options("UP<LOOPBACK>") == ['UP']

    assert network_platform.get_options("UP,BROADCAST<LOOPBACK>") == ['UP','BROADCAST']



# Generated at 2022-06-22 23:55:06.916075
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:55:12.843611
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Arrange
    current_if = {}
    ips = {}
    words = ['status', 'inactive']
    expected = dict(status='inactive')

    # Act
    GenericBsdIfconfigNetwork().parse_status_line(words, current_if, ips)

    # Assert
    assert current_if == expected


# Generated at 2022-06-22 23:55:26.583595
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    gif = Generic_BSD_Ifconfig()
    results = {}
    ips = {}
    current_if = {}
    tt = ['inet6', '::1', 'prefixlen', '0x80000000', 'scopeid', '0x10']
    gif.parse_inet6_line(tt, current_if, ips)
    tt = ['inet6', 'fe80::e6:8:6:75:6f2b', 'prefixlen', '64', 'scopeid', '0x7']
    gif.parse_inet6_line(tt, current_if, ips)
    tt = ['inet6', 'fe80::216:8ff:fe6d:6d8b', 'prefixlen', '64', 'scopeid', '0x9']

# Generated at 2022-06-22 23:55:38.039313
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
    """
    gbn = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # FreeBSD uses both styles
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    gbn.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-22 23:55:49.134246
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # mock class, with return values
    class nullobject(object):
        pass

    get_bin_path = nullobject()
    get_bin_path.return_value = True
