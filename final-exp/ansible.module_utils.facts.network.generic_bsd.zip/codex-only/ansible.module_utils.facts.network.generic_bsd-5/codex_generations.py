

# Generated at 2022-06-22 23:45:47.095944
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    t = GenericBsdIfconfigNetwork()
    t.parse_unknown_line(["", "", "", "", "", ""])

# Generated at 2022-06-22 23:45:52.551560
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = {}
    current_if['status'] = None
    words = ['status:', 'active']
    network = GenericBsdIfconfigNetwork(module)
    network.parse_status_line(words, current_if, None)
    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:46:00.052960
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    addon_obj = GenericBsdIfconfigNetwork(module)

    words = ['status:', 'active', 'in', 'blah']
    current_if = {'device': 'bge0'}
    ips = {}
    addon_obj.parse_status_line(words, current_if, ips)

    assert current_if['status'] == 'active in blah'

# Generated at 2022-06-22 23:46:06.109558
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['lladdr', '00:01:02:03:04:05']
    network.parse_lladdr_line(words, current_if, ips)
    assert ips == {}
    assert current_if == {'macaddress': '00:01:02:03:04:05'}


# Generated at 2022-06-22 23:46:16.365766
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = "dummy_route"
    module_mock = mock.MagicMock()
    module_mock.get_bin_path.return_value = route_path
    network = network_ifconfig.GenericBsdIfconfigNetwork()
    network.module = module_mock
    # Test for no output
    runner_mock = mock.MagicMock()
    runner_mock.run_command.return_value = [0, "", ""]
    network.module.run_command = runner_mock
    ipv4, ipv6 = network.get_default_interfaces(route_path)
    assert ipv4 == dict(interface="", gateway="")
    assert ipv6 == dict(interface="", gateway="")
    # Test for IPv4 only

# Generated at 2022-06-22 23:46:26.917541
# Unit test for method populate of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:46:33.830607
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    iface = {}
    gbifn = GenericBsdIfconfigNetwork(module)
    gbifn.parse_media_line(['media:', 'Ethernet', 'autoselect'], iface, {})
    assert iface == {'media': 'Ethernet', 'media_select': 'autoselect', 'media_type': 'Ethernet'}
    iface = {}
    gbifn.parse_media_line(['media:', 'Ethernet', '10baseT/UTP', '(10baseT,UTP)'], iface, {})

# Generated at 2022-06-22 23:46:45.152278
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = MagicMock()
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork(module)

    # Test OK
    words = ['options=8903<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWTSO>',
             'mtu 9000', 'id 00:00:00:00:00:00', 'priority 0', 'media: Ethernet autoselect (1000baseT ', '<full-duplex>)',
             'status: active']
    iface = {'device': 'eth0', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST']}
    generic_bsd_ifconfig.parse_interface_

# Generated at 2022-06-22 23:46:55.844236
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # e.g. lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184
    #     inet 127.0.0.1 netmask 0xff000000
    #     inet6 ::1 prefixlen 128
    #     inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
    #     nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    module = MagicMock()
    current_if = {}
    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    ifconfig_facts = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-22 23:47:09.009032
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    network = GenericBsdIfconfigNetwork()

    ifconfig_path = network.module.get_bin_path('ifconfig', False)
    ifconfig_path = ifconfig_path or '/sbin/ifconfig'

    cmd = [ifconfig_path, '-a']
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    interfaces_info_str, _  = p.communicate()
    interfaces_info_str = interfaces_info_str.decode('utf-8')

    interfaces, ips = network.get_interfaces_info(ifconfig_path)

    # replace the addresses

# Generated at 2022-06-22 23:47:21.583848
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    ifconfig_module = GenericBsdIfconfigNetwork(
        module=None,
    )
    current_if = {}
    current_if['options'] = []
    current_if['flags'] = []
    interface = {
        'device': 'lo0',
        'options': [],
        'flags': [],
    }
    ips = {
        'all_ipv6_addresses': [],
    }
    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'media:', 'Ethernet', '10Gbase-T', '<full-duplex>', 'status:', 'active', 'mtu', '1500']
    ifconfig_module.parse_nd6_line(words, interface, ips)

# Generated at 2022-06-22 23:47:31.101779
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)

    # Case 1:
    # (1) Test input with both prefix and scope
    # (2) Test correct ipv6 address, prefix, scope
    input_line = ['inet6', 'fe80::1102:bfff:fef7:28e9%lo0', 'prefixlen', '64', 'scopeid', '0x2']
    iface_info = {'ipv6': []}
    ips = {'all_ipv6_addresses': []}
    network.parse_inet6_line(input_line, iface_info, ips)

# Generated at 2022-06-22 23:47:40.897039
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['lladdr', 'fe80::1%lo0']
    ifc = GenericBsdIfconfigNetwork()
    ifc.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == 'fe80::1%lo0'


# Generated at 2022-06-22 23:47:54.186053
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    """
    Get default routes
    """
    def mock_run_command(module, command):
        if command[-2:] == ['get', 'default']:
            return 0, 'gateway: 192.168.1.1\ninterface: en0'
        if command[-2:] == ['get', '-inet6', 'default']:
            return 0, 'gateway: fe80::1:1\ninterface: en1'
        if command[-2:] == ['get', '-inet6', 'fe80::1:1']:
            return 1, 'RTNETLINK answers: Invalid argument'
        return 1, "ERROR"

    def mock_get_bin_path(module, path):
        if path == 'route':
            return '/sbin/route'
        return None

    original_run_command = Generic

# Generated at 2022-06-22 23:48:06.773476
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    network = GenericBsdIfconfigNetwork()
    assert network.parse_ether_line(['ether', 'ac:1f:6b:ff:ff:ff']) == \
        {'macaddress': 'ac:1f:6b:ff:ff:ff', 'type': 'ether'}

    assert network.parse_ether_line(['ether', 'ac:1f:6b:ff:ff:ff,', 'some', 'other', 'stuff']) == \
        {'macaddress': 'ac:1f:6b:ff:ff:ff', 'type': 'ether'}


# Generated at 2022-06-22 23:48:18.858965
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    test_name='test_GenericBsdIfconfigNetwork_parse_status_line'
    test_description='Testing method parse_status_line of class GenericBsdIfconfigNetwork'
    test_params=dict()
    test_steps='''
    '''
    try:
        print('{0} -- {1}'.format(test_name, test_description))
        steps=test_steps
        expected=True
        actual=False
        print('Expected: {0}'.format(expected))
        print('Actual: {0}'.format(actual))
        assert (expected==actual)
    except AssertionError as e:
        print('Expected: {0}'.format(expected))
        print('Actual: {0}'.format(actual))
        print('Test {0} failed'.format(test_name))

# Generated at 2022-06-22 23:48:30.561426
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    m_args = dict(
        check_invalid_arguments=mock.Mock(return_value=False),
        get_bin_path=mock.Mock(return_value='/sbin/ifconfig')
    )

# Generated at 2022-06-22 23:48:41.865853
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # create a mock for module
    module = Mock()
    # create a mock for ifconfig
    IFNET_file = 'ifnet_freebsd.txt' 
    ifconfig_path = 'ifconfig' 
    module.get_bin_path.return_value = ifconfig_path 
    module.run_command.return_value = 0, IFNET_file, ''
    # create object and call method
    net_info = GenericBsdIfconfigNetwork(module)
    network_facts = net_info.populate()
    # check results
    assert network_facts['default_ipv4'] == {'broadcast': '10.0.0.255', 'address': '10.0.0.1', 'netmask': '255.255.255.0', 'network': '10.0.0.0'}


# Generated at 2022-06-22 23:48:43.797257
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # TODO: make this a real test.
    assert True == True

# Generated at 2022-06-22 23:48:56.159531
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:49:09.456514
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-22 23:49:18.240313
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module=AnsibleModuleMock(dict(platform_version=(7,0),
                                  name='test_module'))
    fact=GenericBsdIfconfigNetwork(module)
    current_if={}
    words=['nd6']
    ips={'all_ipv4_addresses':[],'all_ipv6_addresses':[]}
    fact.parse_unknown_line(words,current_if,ips)
    assert current_if=={'options': ['ND6']}


# Generated at 2022-06-22 23:49:26.791889
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    d = dict()
    c = dict()
    i = dict()
    c['type'] = 'unknown'
    i['all_ipv4_addresses'] = []
    i['all_ipv6_addresses'] = []
    n = GenericBsdIfconfigNetwork()
    n.parse_ether_line(['ether', '90:9f:33:3a:1d:36'], c, i)
    assert c['type'] == 'ether'
    assert c['macaddress'] == '90:9f:33:3a:1d:36'
    return

# Generated at 2022-06-22 23:49:32.299459
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    my_obj = GenericBsdIfconfigNetwork()
    assert my_obj.platform == 'Generic_BSD_Ifconfig'
    assert my_obj.get_options('OPTIONS <UP,BROADCAST,RUNNING,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']



# Generated at 2022-06-22 23:49:44.316493
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec={})
    mocked_class = Mock(spec_set=Network)
    mocked_class.net_common = Common()
    mocked_class.get_interfaces_info = Mock(return_value=([], []))

    network = GenericBsdIfconfigNetwork()
    network.module = module
    network.platform = 'Generic_BSD_Ifconfig'
    network.net_common = mocked_class.net_common

    # Testing with typical line from FreeBSD output.
    words = ['lladdr', '00:11:22:33:44:55']
    current_if = {}
    ips = {}
    network.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == '00:11:22:33:44:55'
#

# Generated at 2022-06-22 23:49:56.979795
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # test instance
    mod = AnsibleModule({'bin_dir': ['.']})
    ifconfig_path = 'ifconfig'
    routing_path = 'route'
    net = GenericBsdIfconfigNetwork(mod)

    # test case with lladdr
    lladdr_test_case_1 = {
        'words': ['lladdr', '00:00:00:00:00:00'],
        'current_if': {'ipv6': [], 'device': 'em0', 'ipv4': [],
                       'macaddress': '00:00:00:00:00:00', 'type': 'ether'},
        'ips': {'all_ipv6_addresses': [], 'all_ipv4_addresses': []}
    }


# Generated at 2022-06-22 23:50:02.765659
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules.network.generic.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    network = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}
    words = ['media', 'media_select', 'media_type', 'media_options']
    network.parse_unknown_line(words, iface, ips)
    assert iface == {'media': 'media_select', 'media_type': 'media_type', 'media_options': 'media_options'}, 'Failed parsing media options'
    iface = {}

# Generated at 2022-06-22 23:50:14.823977
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class GenericBsdIfconfigNetwork
    """

    #
    # All tests assume that the first 2 arguements to the method are:
    # ifconfig_path = self.module.get_bin_path('ifconfig')
    # ifconfig_options='-a'
    #
    # This test, and all subsequent tests, assume the following test data:
    #

# Generated at 2022-06-22 23:50:27.191942
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    platform_module = GenericBsdIfconfigNetwork()
    test_words = ['wlan0', 'link/ether', '00:11:22:33:44:55', 'brd', 'ff:ff:ff:ff:ff:ff']
    test_current_if = {}
    test_ips = {}
    test_expected_current_if = {'device': 'wlan0', 'macaddress': '00:11:22:33:44:55', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}

    platform_module.parse_ether_line(test_words, test_current_if, test_ips)

    assert test_current_if == test_expected_current_if


# Generated at 2022-06-22 23:50:40.666740
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    '''
    Test method parse_unknown_line of class GenericBsdIfconfigNetwork
    '''

    # some functions are used only as static functions, not requiring self
    # pylint: disable=R0201
    # pylint: disable=W0212
    # mock.patch does not like functions in classes, so we use static functions
    @staticmethod
    def get_options(option_string):
        '''
        We cannot use self.get_options() directly in mock.patch below, so we
        have to create a static method as a workaround.

        This method is not tested as it is taken from BSDNetwork class.
        '''
        start = option_string.find('<') + 1
        end = option_string.rfind('>')

# Generated at 2022-06-22 23:50:41.324510
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    pass

# Generated at 2022-06-22 23:50:47.001456
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    unit = GenericBsdIfconfigNetwork()

    option_string = '<UP,LOOPBACK,RUNNING,MULTICAST>'
    expected_result = ['UP','LOOPBACK','RUNNING','MULTICAST']

    assert unit.get_options(option_string) == expected_result

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_get_options()

# Generated at 2022-06-22 23:50:52.759134
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    """
    Test this function of class GenericBsdIfconfigNetwork,
    invoke parse_lladdr_line
    """
    parser = GenericBsdIfconfigNetwork()
    words = ["kernel", "incomplete", "lladdr", "xx:xx:xx:xx:xx:xx"]
    current_if = {"device": "test"}
    ips = {"test": "test"}
    parser.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == "xx:xx:xx:xx:xx:xx"


# Generated at 2022-06-22 23:50:56.588663
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    myNet = GenericBsdIfconfigNetwork()
    current_if = {'device': 'mac_if'}
    ips = {}
    words = ['options=1','<quite, userconfig, up>','metric','0','mtu','1500','inet','192.168.1.1','netmask','0xffffff00','broadcast','192.168.1.255']
    myNet.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['quite', 'userconfig', 'up']

# Generated at 2022-06-22 23:51:05.964248
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    my_network = GenericBsdIfconfigNetwork()
    interfaces = {
        'lo0': {
            'device': 'lo0',
            'flags': ['UP', 'LOOPBACK', 'RUNNING'],
            'ipv4': [],
            'ipv6': [],
            'macaddress': '02:00:00:00:00:00',
            'media': 'Ethernet autoselect status: inactive',
            'type': 'unknown',
            'mtu': 33184
        }
    }


# Generated at 2022-06-22 23:51:17.449427
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
  module = AnsibleModule(argument_spec={})
  gbn = GenericBsdIfconfigNetwork(module)

  line1 = ["nd6", "options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>,", "flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>,", "mtu=1500"]
  line2 = ["nd6", "options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>,", "mtu=1500"]

  current_if = {'options': []}

  gbn.parse_nd6_line(line1, current_if, {})

# Generated at 2022-06-22 23:51:21.860571
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    temp_obj = GenericBsdIfconfigNetwork()
    # call the method
    temp_obj.parse_unknown_line(['foo', 'bar'], {}, {})

# Unit test to test the get_options method of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:51:31.892760
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
  test = GenericBsdIfconfigNetwork()
  a = [ 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'metric 0', 'mtu 0', 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>' ]
  b = {}
  c = {}
  test.parse_nd6_line(a, b, c)
  assert b == { 'options': [ '29<PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL>' ] }
  assert c == {}


# Generated at 2022-06-22 23:51:37.072646
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    words = ['tunnel', 'inet', '64.179.90.22', '-->', '64.179.81.98', 'netmask', '0xffffff00', 'tos', '0x0']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_tunnel_line(words, current_if, ips)
    expected = {'ipv4': [{'address': '64.179.90.22', 'netmask': '255.255.255.0', 'network': '64.179.90.0'}], 'type': 'tunnel', 'ipv6': []}

# Generated at 2022-06-22 23:51:44.382249
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test with a ether interface
    interfaces = {
        'eth0': {'mtu': '1500', 'macaddress': '01:23:45:67:89:ab', 'ipv4': [], 'device': 'eth0', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'], 'ipv6': [], 'media': 'Ethernet 10000baseT', 'type': 'unknown'}
    }

    # Test with a loopback interface

# Generated at 2022-06-22 23:51:50.913902
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '10.0.0.1', '-->', '10.0.0.2', 'netmask', '0xff000000']
    current_if = {'device': 'lo0'}
    ips = {}
    obj.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:52:02.909051
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_string_1 = '''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
        options=3<RXCSUM,TXCSUM>
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        inet 127.0.0.1 netmask 0xff000000
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        nd6 options=1<PERFORMNUD>
gif0: flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280
stf0: flags=0<> metric 0 mtu 1280'''


# Generated at 2022-06-22 23:52:15.123935
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:52:28.240983
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Create the test object with known values
    ifconfig_path = '/usr/sbin/ifconfig'
    ifconfig_options = '-a'
    test_object = GenericBsdIfconfigNetwork(ifconfig_path, ifconfig_options)
    
    # Create a line of the form 'inet6 2001:558:feed::1 prefixlen 64' 
    words = ['inet6', '2001:558:feed::1', 'prefixlen', '64']

    # Initialize the current_if variable
    current_if = {}

    # Initialize the ips variable
    ips = {}

    # Call the parse_inet6_line method
    test_object.parse_inet6_line(words, current_if, ips)

    # Initialize the expected_value variable with the expected result

# Generated at 2022-06-22 23:52:40.982599
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    """
    Test that GenericBsdIfconfigNetwork.parse_interface_line returns proper values
    """
    module = FakeModule(parallel=False)
    gen_obj = GenericBsdIfconfigNetwork(module)

    expected_result = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'flags': [
        'LOOPBACK', 'UP', 'RUNNING'], 'mtu': '33184'}
    test_words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>',
                  'metric', '0', 'mtu', '33184']
    assert gen_obj.parse_interface_line(test_words) == expected_result


# Generated at 2022-06-22 23:52:52.895311
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    import json
    # create instance of class to test
    network_facts = GenericBsdIfconfigNetwork()
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-22 23:52:58.011251
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    #Initialization
    gb = GenericBsdIfconfigNetwork()
    words = ['status:', 'active', 'tentatives']

    current_if = {}

    ips = {}
    #Expected result
    status_str = 'active tentatives'
    expected_result = {'status': status_str}
    #Actual result
    gb.parse_status_line(words, current_if, ips)
    actual_result = current_if
    assert actual_result == expected_result

# Generated at 2022-06-22 23:53:03.849341
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    bsd_net = GenericBsdIfconfigNetwork()
    dev = {'device': 'lo', 'type': 'loopback', 'ipv4': [], 'ipv6': []}

    bsd_net.parse_media_line(['media:', 'Ethernet', 'autoselect', 'status:', 'active'],
                             dev, {})

    assert dev['media'] == 'Ethernet'
    assert dev['media_select'] == 'autoselect'
    assert dev['media_type'] == 'status'
    assert dev['media_options'] == ['active']



# Generated at 2022-06-22 23:53:16.352347
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    test_interface = 'tun0'
    test_words = ['tun0:', 'flags=8851<UP,POINTOPOINT,RUNNING,SIMPLEX,MULTICAST>', 'mtu', '1482', 'inet', '10.0.0.2', '-->', '10.0.0.1', 'netmask', '0xffffff00']
    test_current_if = {'device': test_interface}
    test_ips = {}

    test_network = GenericBsdIfconfigNetwork()

    test_network.parse_tunnel_line(test_words, test_current_if, test_ips)

    assert test_current_if['type'] == 'tunnel'


# Generated at 2022-06-22 23:53:21.244743
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # This is a unit test for GenericBsdIfconfigNetwork
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network import NetworkModule
    module = NetworkModule()

    facts = dict()
    test = GenericBsdIfconfigNetwork(module=module)
    test.populate()
    test.parse_ether_line(facts, ['ether', '00:0e:c6:f4:31:55'], 'current_if', 'ips')
    assert facts['macaddress'] == '00:0e:c6:f4:31:55'
    assert facts['type'] == 'ether'

# Generated at 2022-06-22 23:53:33.468600
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    lines = ["status: active",
             "status: inactive",
             "status: in-active",
             "status: up",
             "status: down",
             "status: suspended",
             "status: unknown",
             "status: not-present",
             "status: dummy",
             "status: down-low-power",
             "status: powering",
             "status: testing",
             "status: ",
             "status: blah"
            ]
    
    expected = ["active",
                "inactive",
                "inactive",
                "up",
                "down",
                "suspended",
                "unknown",
                "not-present",
                "dummy",
                "down-low-power",
                "powering",
                "testing",
                "",
                "blah"
               ]
    

# Generated at 2022-06-22 23:53:39.989145
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    test_network = GenericBsdIfconfigNetwork()
    test_current_if = {}
    test_ips = {}

    test_words = ['lladdr', '08:00:27:5b:02:3e', 'media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)', 'status:',
                'active']
    test_network.parse_lladdr_line(test_words, test_current_if, test_ips)

    assert test_current_if['lladdr'] == '08:00:27:5b:02:3e'


# Generated at 2022-06-22 23:53:48.608937
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    _route_path = 'route'
    _ifconfig_path = 'ifconfig'

    gen_ifconfig_network = GenericBsdIfconfigNetwork()
    gen_ifconfig_network.module = FakeModule()
    gen_ifconfig_network.module.run_command.return_value = (0, route_output("v4"), "")
    gen_ifconfig_network.module.get_bin_path.return_value = 'route'
    gen_ifconfig_network.default_ipv4, gen_ifconfig_network.default_ipv6 = gen_ifconfig_network.get_default_interfaces('route')

    # Check default_ipv4 and default_ipv6 are dictionaries
    assert isinstance(gen_ifconfig_network.default_ipv4, dict)

# Generated at 2022-06-22 23:54:00.858456
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    module = Mock()

# Generated at 2022-06-22 23:54:12.892658
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():

    gbi = GenericBsdIfconfigNetwork()

    # Test 1: Valid MAC address
    current_if = {}
    words = "en6 ether 00:1b:63:7a:d8:dd".split()
    gbi.parse_ether_line(words, current_if, {})

    assert '00:1b:63:7a:d8:dd' == current_if['macaddress']
    assert current_if['type'] == 'ether'

    # Test 2: Invalid MAC address
    words = "en6 ether xx:1b:63:7a:d8:dd".split()
    gbi.parse_ether_line(words, current_if, {})

    assert 'unknown' == current_if['macaddress']
    assert current_if['type'] == 'ether'



# Generated at 2022-06-22 23:54:19.847044
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """GenericBsdIfconfigNetwork - Parse interface line"""

    # Setup mock object for test
    test_obj = GenericBsdIfconfigNetwork()

    # Setup mock function return value
    test_obj.get_options = Mock(return_value='option_return')

    # Test method
    words = ['nd6', 'options=1<PERFORMNUD,ACCEPT_RTADV>']
    result = test_obj.parse_nd6_line(words, {}, dict())
    assert result is None


# Generated at 2022-06-22 23:54:22.350201
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule({})
    network = GenericBsdIfconfigNetwork(module)
    assert network is not None


# Generated at 2022-06-22 23:54:23.685444
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    assert 1



# Generated at 2022-06-22 23:54:35.381371
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    
    ifconfig_network = GenericBsdIfconfigNetwork()

    # Test happy path
    test_words = ['lladdr', '00:11:22:33:44:55']
    test_current_if = {'lladdr': 'ff:ee:dd:cc:bb:aa'}
    test_ips = {}
    ifconfig_network.parse_lladdr_line(test_words, test_current_if, test_ips)
    assert test_current_if['lladdr'] == '00:11:22:33:44:55'
    assert test_ips == {}

    # Test unexpected word count
    test_words = ['lladdr', '00:11:22:33:44:55', 'extra']

# Generated at 2022-06-22 23:54:48.824734
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:54:58.558251
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Setup mocks
    module_mock = MagicMock()
    module_mock.run_command.side_effect = [
        [0, 'ether               00:00:00:00:00:00', ''],
        [0, 'media: Ethernet autoselect (1000baseT <full-duplex>)', ''],
    ]

    # Setup Plugin
    plugin = GenericBsdIfconfigNetwork(module_mock)

    # Run tested method
    plugin.parse_media_line('media: Ethernet autoselect (1000baseT <full-duplex>)'.split(), {}, '')



# Generated at 2022-06-22 23:55:01.778904
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    tmp = GenericBsdIfconfigNetwork()
    assert tmp.get_options('UP,LOOPBACK,RUNNING') == ['UP', 'LOOPBACK', 'RUNNING']



# Generated at 2022-06-22 23:55:07.997624
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    interfaces = {'lo0': {'media': 'ether', 'mtu': 33184}, 'bridge0': {'media': 'ether', 'mtu': 1500}}
    assert interfaces == generic_bsd_ifconfig_network.detect_type_media(interfaces)

# Generated at 2022-06-22 23:55:18.535207
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:55:28.890031
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = FakeModule()
    generic_network = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test happy path
    words = ['ether', '00:11:22:33:44:55']
    generic_network.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == '00:11:22:33:44:55'
    assert current_if['type'] == 'ether'

    # test short word (<6)
    words = ['ether', '00:11:22:33']

# Generated at 2022-06-22 23:55:38.360845
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # test 1
    input_words = [ 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>' ]
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    generic_bsd_ifconfig_network.parse_nd6_line(input_words, current_if, ips)

    assert 'PERFORMNUD' in current_if['options']
    assert 'IFDISABLED' in current_if['options']
    assert 'AUTO_LINKLOCAL' in current_if['options']


# Generated at 2022-06-22 23:55:44.071480
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    gifn = GenericBsdIfconfigNetwork()
    interfaces = {'lo0': {'media': 'Ethernet autoselect'}}
    result = gifn.detect_type_media(interfaces)
    assert result == {'lo0': {'type': 'ether', 'media': 'Ethernet autoselect'}}



# Generated at 2022-06-22 23:55:50.240845
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec=dict())
    network = GenericBsdIfconfigNetwork(module)

    options = network.get_options('<item1,item2,item3>')
    assert len(options) == 3, 'Options should have three items'
    assert options[0] == 'item1', 'options should return a list'
    assert options[1] == 'item2', 'options should return a list'
    assert options[2] == 'item3', 'options should return a list'
