

# Generated at 2022-06-22 23:45:57.100614
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    platform_obj = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:46:03.588518
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    ifconfig_path = module.get_bin_path('ifconfig')
    route_path = module.get_bin_path('route')
    network = GenericBsdIfconfigNetwork()
    default_ipv4, default_ipv6 = network.get_default_interfaces(route_path)
    interfaces, ips = network.get_interfaces_info(ifconfig_path)
    network.detect_type_media(interfaces)
    network.merge_default_interface(default_ipv4, interfaces, 'ipv4')
    network.merge_default_interface(default_ipv6, interfaces, 'ipv6')
    network.populate(None)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:46:10.124373
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    ifconfig_path = '/sbin/ifconfig'
    route_path = '/sbin/route'
    platform = 'Generic_BSD_Ifconfig'
    defaults_ipv4, defaults_ipv6 = GenericBsdIfconfigNetwork(ifconfig_path, route_path, platform).get_default_interfaces(route_path)
    print("defaults_ipv4:", defaults_ipv4)
    print("defaults_ipv6:", defaults_ipv6)


# Generated at 2022-06-22 23:46:21.735702
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network_info = GenericBsdIfconfigNetwork(module)
    ifconfig_path = network_info.module.get_bin_path('ifconfig')
    interfaces, ips = network_info.get_interfaces_info(ifconfig_path)

# Generated at 2022-06-22 23:46:31.253496
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    network_obj = GenericBsdIfconfigNetwork(module)
    
    current_if = dict(device = '', ipv4 = [], ipv6 = [], type = '', flags = [])
    ips = dict(all_ipv4_addresses = [], all_ipv6_addresses = [])

# Generated at 2022-06-22 23:46:39.396075
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    class ModuleTest(object):
        def get_bin_path(self, executable):
            if executable == 'ifconfig':
                return '/sbin/ifconfig'
            elif executable == 'route':
                return executable
        def run_command(self, cmd):
            return 0, '', ''

    module_test = ModuleTest()

    net = GenericBsdIfconfigNetwork()
    net.module = module_test
    print(net.populate())


# Generated at 2022-06-22 23:46:48.416171
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    facts = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}

    # test 1
    words = ['media:', 'Ethernet', 'autoselect (100baseTX <full-duplex>)', '(100baseTX <full-duplex>)', 'status:', 'active']
    facts.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_options'] == ['full-duplex']

    # test 2
    words = ['media:', 'Ethernet', '10baseT/UTP', '(10baseT/UTP)', 'status:', 'active']

# Generated at 2022-06-22 23:46:56.509464
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    mock_current_if = {}
    mock_ips = {}
    mock_words = ['tunnel','inet6','fe80::1','prefixlen','64','->','fe80::2','scopeid','0x6','tunnel','inet6','fe80::2','prefixlen','64','->','fe80::1','scopeid','0x6'] 
    network = GenericBsdIfconfigNetwork()
    network.parse_tunnel_line(mock_words, mock_current_if, mock_ips)    
    assert mock_current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:47:09.740983
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    macfreebsd_iface_01 = GenericBsdIfconfigNetwork()
    macfreebsd_iface_01_out = macfreebsd_iface_01.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '16384'])
    macfreebsd_iface_01_correct_out = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'macaddress': 'unknown', 'metric': '0', 'mtu': '16384'}
    assert macfreebsd_iface_01_out == macfree

# Generated at 2022-06-22 23:47:22.991510
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule(argument_spec=dict())
    genericbsdifconf = GenericBsdIfconfigNetwork(module)
    current_if = dict()
    ips = dict()
    current_if['ipv6'] = []
    ips['all_ipv6_addresses'] = []

    # fail without arguments
    assert genericbsdifconf.parse_inet6_line(words=[""], current_if=current_if, ips=ips) is None

    # test with valid arguments
    assert genericbsdifconf.parse_inet6_line(words=["inet6", "fe80::1%lo0"], current_if=current_if, ips=ips) == []
    assert len(current_if['ipv6']) == 1

# Generated at 2022-06-22 23:47:29.691063
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    interface = GenericBsdIfconfigNetwork()
    interfaces = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['tun0','addr','10.255.0.10','P2P','dest','10.255.0.10','netmask','0xffffffff','group','default']
    interface.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'


# Generated at 2022-06-22 23:47:42.218056
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = dict()
    ips = dict()
    words = ["media:", "Ethernet", "10Gbase-T", "(XFI)", "media-options:", "TXpause", "RXpause"]
    ifconfig_network.parse_media_line(words, current_if, ips)
    assert(current_if['media'] == "Ethernet")
    assert(current_if['media_select'] == "10Gbase-T")
    assert(current_if['media_type'] == "(XFI)")
    assert(current_if['media_options'] == ["TXpause", "RXpause"])
    del current_if['media_options']

# Generated at 2022-06-22 23:47:52.280900
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    test_class = GenericBsdIfconfigNetwork()
    test_interfaces = {}
    test_ips = {}
    test_words = ['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>', 'mtu', '0']
    test_class.parse_nd6_line(test_words, test_interfaces, test_ips)
    assert test_interfaces['options'] == ["PERFORMNUD", "ACCEPT_RTADV", "AUTO_LINKLOCAL"]


# Generated at 2022-06-22 23:48:04.006027
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    """Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork"""
    module, ifconfig_path, route_path = module_for_test()

    o = GenericBsdIfconfigNetwork(module)  # noqa: E501 # pylint: disable=not-callable

    # call_args list isn't in the order of the test, so I re-arrange it
    words = ['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>', 'media:', 'Ethernet', '10Gbase-T', '(10Gbase-T)']

    iface = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    o.parse_nd

# Generated at 2022-06-22 23:48:09.941935
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-22 23:48:20.330576
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    
    # Test setup
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    module.exit_json = MagicMock()

    # Test object setup
    test_instance = GenericBsdIfconfigNetwork(module)

    test_instance.parse_tunnel_line(
        words=['tunnel', 'inet', '127.0.0.1', '--', '>', '127.0.0.1'],
        current_if={},
        ips={}
    )

    assert test_instance.parse_tunnel_line.__name__ == 'parse_tunnel_line'



# Generated at 2022-06-22 23:48:31.851080
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    class FakeModule(object):
        def __init__(self):
            self.run_command = self.fake_run_command
        def fake_run_command(self):
            return 0, '', ''
    m = FakeModule()
    network = GenericBsdIfconfigNetwork(m)
    # test normal options
    words = 'options=8<VLAN_MTU>'.split()
    current_if = {'device':'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'options': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:48:41.499278
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    Network = GenericBsdIfconfigNetwork(module, 'GenericBsdIfconfigNetwork')
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    current_if = Network.parse_interface_line(words)
    assert current_if['device'] == 'lo0'
    assert current_if['type'] == 'loopback'
    assert 'LOOPBACK' in current_if['flags']
    assert current_if['mtu'] == '33184'


# Generated at 2022-06-22 23:48:50.270946
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    '''
    Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
    '''

    # FIXME: Create a mock class of GenericBsdIfconfigNetwork
    # and test the method parse_unknown_line() with that
    # once we have the mock module
    sys.stderr.write("test_GenericBsdIfconfigNetwork_parse_unknown_line(): "
                     "FIXME: No test implemented for this method\n")



# Generated at 2022-06-22 23:49:03.693563
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    # Test parse_inet_line of GenericBsdIfconfigNetwork with input "words" as "words"

    # no broadcast or netmask given
    words = ['em0:', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'options=9b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING>', 'ether', '00:15:17:ed:a7:eb', 'media:', 'Ethernet', 'autoselect', '(100baseTX)', 'status:', 'active', 'inet', '10.0.1.123', 'netmask', '0xffffff00']

# Generated at 2022-06-22 23:49:15.057854
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:49:27.611910
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    gbi = GenericBsdIfconfigNetwork()
    ifconfig_path = gbi.module.get_bin_path('ifconfig')

    if ifconfig_path is None:
        raise FileNotFoundError("ifconfig could not be found.")

    route_path = gbi.module.get_bin_path('route')

    if route_path is None:
        raise FileNotFoundError("route could not be found.")

    default_ipv4, default_ipv6 = gbi.get_default_interfaces(route_path)
    interfaces, ips = gbi.get_interfaces_info(ifconfig_path)
    interfaces = gbi.detect_type_media(interfaces)

    gbi.merge_default_interface(default_ipv4, interfaces, 'ipv4')
    gbi.merge_

# Generated at 2022-06-22 23:49:35.874725
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    net = GenericBsdIfconfigNetwork()
    words = 'inet6 ::1 prefixlen 128'.split()
    current_if = {}
    ips = {'all_ipv6_addresses': []}

    net.parse_inet6_line(words, current_if, ips)

    assert current_if == {'ipv6': [{'address': '::1', 'prefix': '128'}]}
    assert ips == {'all_ipv6_addresses': [':1']}


# Generated at 2022-06-22 23:49:48.237324
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Arrange
    # Create a FreeBSD-derived class with type and media parameters and
    #   assert that it properly detects that it has the ether type.
    obj = GenericBsdIfconfigNetwork({}, {})
    interface_dict = {
        "fxp0": {
            "flags": ["UP", "BROADCAST", "SIMPLEX", "MULTICAST"],
            "metric": "0",
            "mtu": "1500",
            "media": "Ethernet autoselect (100baseTX <full-duplex>)",
        }
    }
    assert interface_dict["fxp0"]["type"] == "unknown"

    # Act
    obj.detect_type_media(interface_dict)

    # Assert
    assert interface_dict["fxp0"]["type"] == "ether"
#

# Generated at 2022-06-22 23:50:00.370362
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def run_command(self, args):
            stdout = """
  interface: lo0
      route to: default
destination: default
       mask: default
    gateway: 127.0.0.1
"""
            return 0, stdout, ""

    class FakeParser(GenericBsdIfconfigNetwork):
        def __init__(self, *args, **kwargs):
            self.module = FakeModule()
            self.platform = 'foo'
            self.module.get_bin_path = lambda x: x

    parser = FakeParser()
    ipv4, ipv6 = parser.get_default_interfaces("")
    assert ipv4['interface'] == 'lo0', ipv

# Generated at 2022-06-22 23:50:13.060047
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    """
    test if the method parse_inet_line works as expected.
    """
    module = AnsibleModuleMock({
       "ANSIBLE_MODULE_ARGS": {
           "gather_subset": "default",
           "gather_network_resources": "yes"
       }
    })

    args = {}

    net = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-22 23:50:26.192041
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    test_sut = GenericBsdIfconfigNetwork()

    # Test 1: If words does not contain words[2]=='prefixlen', words[4]=='scopeid'
    test1_words = ['inet6', 'fe80::2%en0', 'prefixlen', '64', 'scopeid', '0x5']
    test1_current_if = {}
    test1_ips = {}
    test1_expected_address = {'address': 'fe80::2%en0', 'prefix': '64', 'scope': '0x5'}
    test_sut.parse_inet6_line(test1_words, test1_current_if, test1_ips)
    assert test1_current_if['ipv6'][0] == test1_expected_address

    # Test 2: If words[2]

# Generated at 2022-06-22 23:50:39.359532
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Create a mock module
    module = Mock()

    # Create an instance of GenericBsdIfconfigNetwork
    generic_bsd_ifconfig = GenericBsdIfconfigNetwork(module)

    # Create Mock parameters
    words = ['em0:',
             'inet',
             '10.0.0.1',
             'netmask',
             '0xff000000',
             'broadcast',
             '10.15.255.255']

    # Create Mock return values
    address = {'address': '10.0.0.1',
               'netmask': '0xff000000',
               'network': '10.0.0.0',
               'broadcast': '10.15.255.255'}

    # Create Mock current_if

# Generated at 2022-06-22 23:50:49.637259
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    # testing inet6 line without prefixlen example
    network = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0'}
    ips = {}
    # words = ['inet6', 'xxxx::xxxx:xxxx:xxxx:xxxx%lo0', 'prefixlen', '64',
    # 'scopeid', '0x5', 'inet6', 'xxxx::xxxx:xxxx:b7ff:fe92:xxxx%lo0',
    # 'prefixlen', '64', 'scopeid', '0x6']
    # words = ['inet6', 'xxxx::xxxx:xxxx:xxxx:xxxx%lo0', 'prefixlen', '64', 'scopeid', '0x5']
    words = ['inet6', 'xxxx::xxxx:xxxx:xxxx:xxxx%lo0', 'prefixlen', '64']

# Generated at 2022-06-22 23:50:56.192272
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module_args = dict()
    set_module_args(module_args)

    gm = GenericBsdIfconfigNetwork()

    words = ['bogus', 'unknown', 'line']
    current_if  = {}
    ips = {}

    gm.parse_unknown_line(words, current_if, ips)

# Generated at 2022-06-22 23:51:05.770047
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    # test case 1
    words = ['group', 'tun']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_unknown_line(words, current_if, ips)
    assert current_if == {}
    assert ips == {}
    # test case 2
    words = ['group', 'tun']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_unknown_line(words, current_if, ips)
    assert current_if == {}
    assert ips == {}
    # test case 3
    words = ['group', 'tun']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_

# Generated at 2022-06-22 23:51:10.475307
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic = GenericBsdIfconfigNetwork()
    option_csv = generic.get_options('<UP,BROADCAST,RUNNING,MULTICAST>')
    assert option_csv == ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-22 23:51:18.598497
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    ifc = GenericBsdIfconfigNetwork()
    current_if = ifc.parse_interface_line(['eno1:','flags=4163','mtu','1500','metric','33'])
    ifc.parse_ether_line(['ether','aa:bb:cc:dd:ee:ff'],current_if,{})
    assert current_if['device'] == 'eno1'
    assert current_if['flags'] == ['UP','BROADCAST','RUNNING','MULTICAST']
    assert current_if['macaddress'] == 'aa:bb:cc:dd:ee:ff'
    assert current_if['type'] == 'ether'

# Generated at 2022-06-22 23:51:30.906777
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    Test method get_interfaces_info of class GenericBsdIfconfigNetwork
    :return:
    """
    module = AnsibleModule(argument_spec=dict())

    network = GenericBsdIfconfigNetwork(module)


# Generated at 2022-06-22 23:51:34.787816
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    m_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork
    options_list = m_GenericBsdIfconfigNetwork.get_options("<flag1,flag2>")
    assert len(options_list) == 2
    assert ("flag1" in options_list) and ("flag2" in options_list)

# Generated at 2022-06-22 23:51:36.913920
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """Unit test for constructor of class GenericBsdIfconfigNetwork."""
    module = FakeAnsibleModule()
    gbif = GenericBsdIfconfigNetwork(module)
    assert gbif.module == module
    assert gbif.platform == 'Generic_BSD_Ifconfig'

# Generated at 2022-06-22 23:51:40.860009
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all'], type='list'),
        ),
    )

    # Test default value of constructor of class GenericBsdIfconfigNetwork
    network = GenericBsdIfconfigNetwork(module)
    assert 'Generic_BSD_Ifconfig' == network.platform


# Generated at 2022-06-22 23:51:46.698025
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    network = GenericBsdIfconfigNetwork()
    words = ['options=48<VLAN_MTU,JUMBO_MTU,VLAN_HWTAGGING>']
    current_if = {}
    ips = {}
    network.parse_options_line(words, current_if, ips)
    assert current_if == {'options': ['VLAN_MTU', 'JUMBO_MTU', 'VLAN_HWTAGGING']}

# Generated at 2022-06-22 23:51:54.986799
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=0)
    network = GenericBsdIfconfigNetwork(mock_module)
    result = network.parse_tunnel_line(['tunnel', 'inet', '10.55.55.55', '-->', '10.55.55.1', 'netmask', '0xffffffff'])
    assert result == 0

# Generated at 2022-06-22 23:52:00.739133
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # instantiate object
    network = GenericBsdIfconfigNetwork()
    # create test variable
    words = ['status:', 'active']
    # create interface variable
    current_if = {}
    #create statistics variable
    ips = {}

    network.parse_status_line(words, current_if, ips)
    assert current_if == {'status': 'active'}


# Generated at 2022-06-22 23:52:14.252361
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    def test_GenericBsdIfconfigNetwork_parse_inet6_line():
        class ModuleStub:
            def __init__(self):
                self.params = dict()
        module = ModuleStub()
        myclass = GenericBsdIfconfigNetwork(module)
        data = ['inet6', 'fe80::4f4:c84a:d03:8365%tap1', 'prefixlen', '64', 'scopeid', 0x6]
        return_value = myclass.parse_inet6_line(data, dict(), dict())
        expected_value = dict(address='fe80::4f4:c84a:d03:8365%tap1', prefix='64', scope='0x6')
        assert return_value == expected_value



# Generated at 2022-06-22 23:52:20.916741
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    """Unit test for method parse_status_line of class GenericBsdIfconfigNetwork"""
    result = {}
    # test case for status: active
    test_case_data = [["status:", "active"], result]
    network = GenericBsdIfconfigNetwork()
    network.parse_status_line(test_case_data[0], result, {})
    assert result['status'] == 'active'


# Generated at 2022-06-22 23:52:28.161741
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule({})
    ifconfig = GenericBsdIfconfigNetwork(module)
    words = ['tunnel', 'tun0']
    current_if = {}
    ips = {}
    ifconfig.parse_tunnel_line(words, current_if, ips)
    assert 'tunnel' == current_if['type']
    assert 'tun0' == current_if['device']



# Generated at 2022-06-22 23:52:29.003432
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    network = GenericBsdIfconfigNetwork()
    assert network.populate() == None

# Generated at 2022-06-22 23:52:37.280018
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    o = GenericBsdIfconfigNetwork()
    i = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    i = o.parse_ether_line(['ether', '52:54:00:8b:0a:05'], i, {})
    assert i['macaddress'] == '52:54:00:8b:0a:05', i['macaddress']
    assert i['type'] == 'ether', i['type']


# Generated at 2022-06-22 23:52:50.398578
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    c = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:52:59.155782
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Test for method parse_ether_line(self, words, current_if, ips)
    module = generic_bsd_ifconfig_network.GenericBsdIfconfigNetwork(AnsibleModule)
    words = ['ether', 'a1:b2:c3:d4:e5:f6']
    current_if = dict(device='test')
    ips = dict()

    module.parse_ether_line(words, current_if, ips)
    assert current_if['macaddress'] == 'a1:b2:c3:d4:e5:f6', "Parsed mac address is wrong"
    assert current_if['type'] == 'ether', "Type is wrong"



# Generated at 2022-06-22 23:53:11.065350
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    iface = {'device': 'eth0', 'macaddress': '00:11:22:33:44:55', 'ipv4':[], 'ipv6':[]}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    ifconfig_parser = GenericBsdIfconfigNetwork()
    # Make sure we don't explode
    ifconfig_parser.parse_media_line('', iface, ips)

    # inet 6 fe80::a00:27ff:fe98:feba%em0 prefixlen 64 tentative autoconf
    ifconfig_parser.parse_media_line('media: Ethernet autoselect (none)', iface, ips)
    assert iface['media'] == 'Ethernet'

# Generated at 2022-06-22 23:53:17.366562
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # test if the interface status is captured in the ifconfig output
    out = """
lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
        options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>
        status: active
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x2
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
gif0: flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280
        status: inactive
""".splitlines()
    g = GenericBsd

# Generated at 2022-06-22 23:53:29.114693
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    # Uses /etc/group file to test parse_group function
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ifconfig')

    mac_facts = GenericBsdIfconfigNetwork().populate()

    assert mac_facts['eth0']['media'] == 'ethernet'
    assert mac_facts['eth0']['media_options'] == ['none', 'autoselect']
    assert mac_facts['eth0']['media_type'] == '10Gbase-T'
    assert mac_facts['eth0']['media_select'] == 'autoselect'


# Generated at 2022-06-22 23:53:38.873891
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    """
    Test that a variety of OS/distro-specific `options` lines
    get parsed properly.
    Called by test_GenericBsdIfconfigNetwork_get_interfaces_info()
    """
    m = GenericBsdIfconfigNetwork()

    current_if = {}

    m.parse_options_line(['options=80000<LINKSTATE,VLAN_MTU>'], current_if, dict())
    assert current_if['options'] == ['LINKSTATE', 'VLAN_MTU']

    m.parse_options_line(['options=3<RXCSUM,TXCSUM,VLAN_MTU>'], current_if, dict())
    assert current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU']


# Generated at 2022-06-22 23:53:47.080408
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = MagicMock()
    defaults = {'interface': 'lo0'}
    interfaces = {'lo0': {'a': 1, 'b': 2, 'ipv4': [{'address': '1.2.3.4'}]}}
    gc = GenericBsdIfconfigNetwork(module)

    # Method call
    gc.merge_default_interface(defaults, interfaces, 'ipv4')

    # Check correctness
    assert defaults == {'interface': 'lo0', 'a': 1, 'b': 2, 'address': '1.2.3.4'} 
    


# Generated at 2022-06-22 23:53:59.757458
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = DummyModule()
    mod = GenericBsdIfconfigNetwork(module)
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    def test(words, expect):
        mod.parse_inet_line(words, current_if, ips)
        if current_if['ipv4'][0] != expect:
            print("Failed parsing %s" % words)
            print("Expected %s Got %s" % (expect, current_if['ipv4'][0]))
        current_if['ipv4'] = []

# Generated at 2022-06-22 23:54:11.468001
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    iface = "en0"
    parsed_line = "ether d0:67:e5:01:c2:a3"
    module = MockModule()
    ifconfig_obj = GenericBsdIfconfigNetwork(module)
    ifconfig_obj.parse_interface_line([iface])
    ifconfig_obj.parse_ether_line(parsed_line.split(), ifconfig_obj.current_if, ifconfig_obj.ips)
    assert ifconfig_obj.current_if == {
        'device': 'en0',
        'ipv4': [],
        'ipv6': [],
        'type': 'ether',
        'macaddress': 'd0:67:e5:01:c2:a3'
                       }



# Generated at 2022-06-22 23:54:21.511975
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = FakeModule(name='ifconfig')
    parser = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    #next line will test the if with no options is passed to the parse_media_line function.
    parser.parse_media_line([''], current_if, ips)
    assert ips == {}
    assert current_if['media'] == ''

    #next lines will test the if with options are passed to the parse_media_line function.
    parser.parse_media_line(['media', 'media_value1'], current_if, ips)
    assert ips == {}
    assert current_if['media'] == 'media_value1'
    assert 'media_select' not in current_if
    assert 'media_type' not in current_if

# Generated at 2022-06-22 23:54:27.490021
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network_facts = GenericBsdIfconfigNetwork()
    options = network_facts.get_options('options=3<RXCSUM,TXCSUM,VLAN_MTU>')
    assert options == ['RXCSUM', 'TXCSUM', 'VLAN_MTU']

# Generated at 2022-06-22 23:54:39.527522
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Unit test
    from ansible.module_utils.network.common.network.module_facts.network.GenericBsdIfconfigNetwork import GenericBsdIfconfigNetwork
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.utils import dict_diff

    CURR_DIR = os.path.dirname(os.path.realpath(__file__))

    def load_fixture(filename):
        path = os.path.join(CURR_DIR, 'fixtures', filename)
        with open(path) as f:
            return f.read()


# Generated at 2022-06-22 23:54:48.470411
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Arrange
    module = AnsibleModule(argument_spec={})
    current_if = {}
    ips = {}
    words = ['ether', '01:23:45:67:89:ab']

    # Act
    GenericBsdIfconfigNetwork.parse_ether_line(module, words, current_if, ips)

    # Assert
    assert current_if['macaddress'] == '01:23:45:67:89:ab'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-22 23:55:01.197100
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    net = GenericBsdIfconfigNetwork(None)
    #route output for freebsd
    route_out_freebsd = '''
default 192.2.2.2 UGS 0 12001 en0
default 192.2.2.2 UGS 0 12001 en0
default fe80::%utun0 UGPe 52 
default fe80::%utun0 UGPe 52 
'''
    #route output for openbsd

# Generated at 2022-06-22 23:55:13.562750
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    class MockModule(object):
        def __init__(self):
            self.exit_json = lambda x: None

    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self):
            self.module = MockModule()

    current_if = {'device': 'test'}
    ip = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    words = ['options=2342<VLAN_MTU,JUMBO_MTU,LINKSTATE>', 'inet', '10.0.0.1', 'netmask', '0xffffff00', 'broadcast', '10.0.0.255', 'blah']
    TestGenericBsdIfconfigNetwork().parse_options_line(words, current_if, ip)

# Generated at 2022-06-22 23:55:27.553911
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    import json
    import subprocess
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # Create a test subclass that uses a fake command
    class FakeCmd(object):
        def __init__(self, rc, out, err):
            self.fake_rc = rc
            self.fake_out = out
            self.fake_err = err

        def run_command(self, cmd, check_rc=True):
            return self.fake_rc, self.fake_out, self.fake_err

    class FakeAnsibleModule(object):
        def __init__(self, out, err, json):
            self.params = FakeCmd(0, out, err)
            self.dump_json = json


# Generated at 2022-06-22 23:55:39.112928
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Create an instance of ArgParse
    module = AnsibleModule(argument_spec=dict())
    # Create an instance of GenericBsdIfconfigNetwork
    gbin = GenericBsdIfconfigNetwork(module)

    # Test parse_media_line()
    current_if = {}
    ips = {}
    # Case #1: There are five words in the line
    words = ['media:', 'Ethernet', '1000baseT', 'mediaopt', 'media-options']
    gbin.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet', 'media_select': '1000baseT', 'media_type': 'mediaopt', 'media_options': ['media-options']}
    # Case #2: There are four words in the line
    current_if

# Generated at 2022-06-22 23:55:44.490885
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_os = dict(
        family='bsd',
        system='NetBSD',
        major='8',
        minor='99',
        release='0'
    )
    test_arch = dict(
        arch='amd64'
    )
    test_ansible_sys_facts = dict(
        ansible_system='NetBSD',
        ansible_distribution='NetBSD',
        ansible_distribution_version='8.99.0',
        ansible_architecture='x86_64'
    )