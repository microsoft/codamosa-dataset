

# Generated at 2022-06-22 23:45:55.169115
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:45:56.206635
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # All we can do is make sure a class of this name is constructed.
    fact = GenericBsdIfconfigNetwork()
    assert fact


# Generated at 2022-06-22 23:46:02.889203
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    network = GenericBsdIfconfigNetwork()

    words = ['lo0:', 'flags=849<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0',
        'mtu', '16384', 'options=3<RXCSUM,TXCSUM>', 'ether', '00:00:00:00:00:00']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'mtu': '16384', 'macaddress': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    network

# Generated at 2022-06-22 23:46:12.162993
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    global interfaces, ifconfig_path, defaults

    ifconfig_path = '/sbin/ifconfig'
    my_module = type('module', (object,), dict(check_mode=False, fail_json=fail_json, params=dict()))()
    network = GenericBsdIfconfigNetwork(my_module)

# Generated at 2022-06-22 23:46:22.560423
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    gni = GenericBsdIfconfigNetwork()

    # test lladdr line without lladdr value
    current_if = {}
    ips = {}
    line = "lladdr"
    words = line.split()
    gni.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == ''

    # test lladdr line with lladdr value
    current_if = {}
    ips = {}
    line = "lladdr 00:11:22:33:44"
    words = line.split()
    gni.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == '00:11:22:33:44'

# Generated at 2022-06-22 23:46:23.262080
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass

# Generated at 2022-06-22 23:46:32.111430
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    #GenericBsdIfconfigNetwork.parse_lladdr_line(words, current_if, ips)
    
    # setup
    words = ['lladdr','1A:3E:21:2A:85:54','media:','Ethernet','autoselect','(100baseTX)']
    current_if = {'device': 'vmx0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    current_if['flags'] = ['BROADCAST', 'SIMPLEX', 'MULTICAST', 'NOARP', 'NOALLMULTI', 'POINTTOPOINT']
    current_if['mtu'] = '1500'
    current_if['macaddress'] = 'unknown'

# Generated at 2022-06-22 23:46:43.445155
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # do not run test if python version is 2.6
    if sys.version_info[0] == 2 and sys.version_info[1] == 6:
        return

    assertEqual(GenericBsdIfconfigNetwork.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '32768', 'metric', '0']),
                {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'metric': '0', 'mtu': '32768', 'macaddress': 'unknown'})

# Generated at 2022-06-22 23:46:51.833830
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = GenericBsdIfconfigNetwork(module)

    # Create mocked objects for unit test.
    mocked_route_path = '/sbin/route'

    # Create mocked responses for unit test.
    mocked_route_v4_output = '''
default: gateway
    interface: utun0
        gateway: gateway
    if address: 127.0.1.1
'''
    mocked_route_v6_output = '''
default: gateway
    interface: utun0
        gateway: gateway
    if address: 127.0.1.1
'''

    # Replace mocked objects to the real objects
    nm.module.get_bin_path = Mock(return_value=mocked_route_path)

    # Replace mocked responses to the real

# Generated at 2022-06-22 23:46:58.345280
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.utils import get_module
    from ansible.module_utils.network.common.utils import load_provider
    import ansible.module_utils.network.bsd.ifconfig

    # Hack to setup the module loader
    # TODO: fix this hack
    ansible.module_utils.network.bsd.ifconfig.sys.modules['ansible.module_utils.basic'] = MagicMock()
    ansible.module_utils.network.bsd.ifconfig.sys.modules['ansible.module_utils.six'] = MagicMock()

    NetUtils = load_provider('netutils')
    net_utils = NetUtils()

    obj = GenericBsdIfconfigNetwork()


# Generated at 2022-06-22 23:47:05.379177
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    genbsdif = GenericBsdIfconfigNetwork(None)
    assert sorted(genbsdif.get_options('<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST>')) == sorted(['UP','BROADCAST','SMART','RUNNING','SIMPLEX','MULTICAST'])
    assert genbsdif.get_options('null') == []


# Generated at 2022-06-22 23:47:18.254129
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # case0
    # A tunnel is an interface added to the network stack for logical network
    # configurations.
    cls = GenericBsdIfconfigNetwork()
    regexp = re.compile(r'^tun\d:\s+\S+')
    lines = [
        'tun0: flags=80207<UP,DSTOPTS,RUNNING,MULTICAST> metric 0 mtu 1480\n',
        '\tinet 10.0.0.1 --> 10.0.0.2 netmask 0xffffffff\n'
    ]
    for line in lines:
        if regexp.match(line):
            words = line.split()
            assert words[0].startswith('tun')
            assert words[0].endswith(':')
            iface = words[0][0:-1]


# Generated at 2022-06-22 23:47:24.039223
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    match = GenericBsdIfconfigNetwork.parse_media_line

    assert match(['media:', 'Ethernet', 'autoselect', '(100baseTX)'], {}, {}) == \
           None, "If media option is Ethernet, result list should be [{}, {}, None, None, None]"

    assert match(['media:', 'Ethernet', 'autoselect', '(1000baseTX)'], {}, {}) == \
           None, "If media option is Ethernet, result list should be [{}, {}, None, None, None]"

    assert match(['media:', 'Ethernet', 'autoselect', '(10baseT)'], {}, {}) == \
           None, "If media option is Ethernet, result list should be [{}, {}, None, None, None]"


# Generated at 2022-06-22 23:47:32.106395
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    # check to make sure test is only being run on supported systems
    if platform.system() != 'FreeBSD':
        pytest.skip('The OS for this test is not FreeBSD. To run this test on FreeBSD.')

    # initialize the instance
    network = GenericBsdIfconfigNetwork()
    network.module = AnsibleModule(argument_spec=dict())

    # check to make sure test is only being run with ifconfig on path
    if network.module.get_bin_path('ifconfig') is None:
        pytest.skip('ifconfig is not on the path. To run this test install ifconfig and restart the tests.')

    # check to make sure test is only being run with route on path

# Generated at 2022-06-22 23:47:42.314491
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = MagicMock(name='module')
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    current_if = {}
    words = ['tunnel', 'inet', '10.100.100.100', '-->', '10.100.100.1', 'mtu', '1480']
    ips = dict(all_ipv6_addresses=[], all_ipv4_addresses=[])

    generic_bsd_ifconfig_network.parse_tunnel_line(words, current_if, ips)
    assert current_if == dict(ipv4=[], ipv6=[], type='tunnel')


# Generated at 2022-06-22 23:47:55.310160
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    Test parse_inet6_line()
    """
    ansible = AnsibleModule(dict(
        ansible_facts=dict(
            ansible_all_ipv6_addresses=[],
        ),
    ))
    args = dict(
        words=[
            'inet6',
            'fe80::1b0:dbff:feb9:3a7%em0',
            'prefixlen',
            '64',
            'scopeid',
            '0x1'
        ],
    )
    current_if = dict(
        ipv6=[],
    )
    ip_type = 'ipv6'
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:48:04.492276
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    words = ['status:', 'active']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(None)

    generic_bsd_ifconfig_network.parse_status_line(words, current_if, ips)
    assert 'status' in current_if
    assert current_if['status'] == 'active'

    words.append('foo')
    generic_bsd_ifconfig_network.parse_status_line(words, current_if, ips)
    assert current_if['status'] == 'active foo'

# Generated at 2022-06-22 23:48:13.598228
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Create an object of the class being tested.
    network = GenericBsdIfconfigNetwork(dict(module=AnsibleModule, platform='', collected_facts={}))
    # Run the method being tested.
    result = network.populate()
    # Check the result.
    assert('ipv4' in result)
    assert('ipv6' in result)
    assert(result['ipv4']['gateway'] == '192.168.1.1')
    assert(result['ipv6']['gateway'] == 'fe80::8a2e:370:7334')



# Generated at 2022-06-22 23:48:26.338191
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all']
    network = GenericBsdIfconfigNetwork(module)
    output = network.get_interfaces_info('ifconfig')
    assert output[0]['em1']['macaddress'] == '04:01:9c:87:4f:0a'
    assert output[0]['lo0']['ipv4'][0]['broadcast'] == '127.255.255.255'
    assert output[0]['em1']['ipv4'][0]['netmask'] == '255.255.255.0'
    assert output[0]['em1']['ipv4'][0]['network'] == '10.193.1.0'

# Generated at 2022-06-22 23:48:39.199946
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:48:52.255346
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    interface_line = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384"
    netbsd_inet_line = "    inet 127.0.0.1 netmask 0xff000000"
    netbsd_inet6_line = "    inet6 ::1 prefixlen 128"
    # inet6 line on linux can be "inet6 addr: ::1/128 Scope:Host"
    # but we skip that one because we are a different platform
    inet_line = "    inet 192.168.0.1 netmask 0xffffff00 broadcast 192.168.0.255"
    # netbsd inet line cidr style
    netbsd_inet_line_cidr = "    inet 127.0.0.1/24"


# Generated at 2022-06-22 23:49:06.000510
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(argument_spec={})
    ifconfig_network = GenericBsdIfconfigNetwork(module)

    # test ether word
    words = ['lagg0:', 'flags=8802<BROADCAST,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'ether', '00:00:5e:00:53:01']
    res = {}
    ifconfig_network.parse_ether_line(words, res, {})
    assert res['macaddress'] == '00:00:5e:00:53:01'
    assert res['type'] == 'ether'

    # test none ether word

# Generated at 2022-06-22 23:49:14.900954
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    n = GenericBsdIfconfigNetwork()

    words = ['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>', 'media:', 'Ethernet  autoselect']
    current_if = {'device': 'lo0'}
    ips = {}

    n.parse_nd6_line(words, current_if, ips)
    assert current_if == {'device': 'lo0', 'options': ['PERFORMNUD', 'ACCEPT_RTADV', 'AUTO_LINKLOCAL']}
    assert ips == {}


# Generated at 2022-06-22 23:49:27.332326
# Unit test for constructor of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:49:29.384139
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    print(GenericBsdIfconfigNetwork.get_default_interfaces(None, 'route'))


# Generated at 2022-06-22 23:49:41.756161
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    import platform
    import tempfile
    import textwrap
    from ansible.module_utils.basic import AnsibleModule

    # Generate test data to pass as input to the parser
    release = platform.release()

# Generated at 2022-06-22 23:49:54.247748
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = "/sbin/ifconfig"

    # Output for system with one interface with one IPv4 and one IPv6 address

# Generated at 2022-06-22 23:50:07.089137
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    current_if = {'ipv4':[], 'ipv6': []}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    generic_bsd_ifconfig_network.parse_inet6_line(['inet6', 'fe80::4bd4:6f5a:8fc8:2ed/64', 'prefixlen', '64', 'scopeid', '0x5'], 
        current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::4bd4:6f5a:8fc8:2ed'
    assert current_if['ipv6'][0]['prefix'] == '64'
   

# Generated at 2022-06-22 23:50:19.610049
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0', 'address': '127.0.0.1'}

# Generated at 2022-06-22 23:50:27.087791
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    m = GenericBsdIfconfigNetwork(dict(params=dict()), lambda *args: None)
    current_if = dict()
    ips = dict()
    words = [None, 'flags=20<POINTOPOINT,NOARP>']
    m.parse_nd6_line(words, current_if, ips)
    assert 'POINTOPOINT' in current_if['options']
    assert 'NOARP' in current_if['options']

# Generated at 2022-06-22 23:50:40.614110
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    network = GenericBsdIfconfigNetwork()
    # Test for various interface line formats

# Generated at 2022-06-22 23:50:50.424850
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # this shows weird media string on MacOS 10.13.3
    words = ['media:', 'autoselect (1000baseT <full-duplex>)', 'status:', 'active']
    current_if = {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    the_if = 'lo0'
    network = GenericBsdIfconfigNetwork()
    network.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert current_if['media'] == 'autoselect'

# Generated at 2022-06-22 23:51:03.173772
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    options = dict()
    options['module_name'] = 'ifconfig'
    options['module_args'] = ''
    options['module_supports_check_mode'] = False
    options['module_deprecation'] = None
    options['_ansible_check_mode'] = False
    options['_ansible_debug'] = False
    options['_ansible_diff'] = False
    options['_ansible_keep_remote_files'] = False
    options['_ansible_remote_tmp'] = '/tmp/ansible/tmp'
    options['_ansible_selinux_special_fs'] = ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']
    options['_ansible_shell_executable'] = '/bin/sh'
    options['_ansible_socket'] = None

# Generated at 2022-06-22 23:51:06.985127
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    assert generic_bsd_ifconfig_network is not None
    assert generic_bsd_ifconfig_network.platform == 'Generic_BSD_Ifconfig'



# Generated at 2022-06-22 23:51:07.873828
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    pass

# Generated at 2022-06-22 23:51:18.566161
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    for path in ['/sbin/ifconfig', '/usr/sbin/ifconfig']:
        if os.path.exists(path):
            break
    cmd_out = dict(
        mylo0=dict(options=['UP', 'LOOPBACK', 'RUNNING']),
        myem0=dict(options=['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']),
    )
    for dev, opt in cmd_out.items():
        test_dev = dict(device=dev)
        GenericBsdIfconfigNetwork.parse_options_line(
            None,
            ['options=%s' % ','.join(opt['options'])],
            test_dev,
            None)
        assert test_dev['options'] == opt['options']
# Unit test

# Generated at 2022-06-22 23:51:30.858398
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:51:39.543069
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    # Check if the class can be instantiated
    network_module = Generic_BSD_Ifconfig()
    assert network_module is not None

    # Unit test for method populate of class Generic_BSD_Ifconfig
    # First test error handling...
    network_module.module.run_command = Mock(return_value=(1, '', 'error'))

    facts = network_module.populate()
    assert facts == {}

    # Then test a normal return
    network_module.module.run_command = Mock(return_value=(0, IFCONFIG_V4_OUTPUT, ''))

    facts = network_module.populate()
    assert 'default_ipv4' in facts
    assert 'all_ipv4_addresses' in facts
    assert 'all_ipv6_addresses' in facts

# Generated at 2022-06-22 23:51:45.540359
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    instance = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet6', '::10', 'prefixlen', '64', 'clone', 'media', 'Ethernet', 'descr', 'some_interface']
    current_if = {}
    ips = {}
    instance.parse_tunnel_line(words, current_if, ips)
    assert 'type' in current_if and current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:51:58.383429
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform_subclass = GenericBsdIfconfigNetwork()
    # Test passing of empty array
    rc, out, err = platform_subclass.module.run_command([])
    assert rc != 0
    assert len(out) == 0
    assert len(err) > 0

    # Test passing of bogus command
    rc, out, err = platform_subclass.module.run_command(['bogus_command'])
    assert rc != 0
    assert len(out) == 0
    assert len(err) > 0

    # Test passing of known commands with different standard outputs
    for command in [['route', '-n', 'get', 'default'], ['route', '-n', 'get', '-inet6', 'default']]:
        rc, out, err = platform_subclass.module.run_command(command)

# Generated at 2022-06-22 23:52:05.129006
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options='-a'
    network = GenericBsdIfconfigNetwork(module)
    network.get_interfaces_info(ifconfig_path, ifconfig_options)
    print(network.interfaces)
    print(network.default_ipv4)
    print(network.all_ipv4_addresses)


if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:52:07.926569
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    obj = GenericBsdIfconfigNetwork()
    result = obj.get_options("option <ONE,TWO,THREE>")
    assert result == ['ONE', 'TWO', 'THREE']

    result = obj.get_options("nooptions")
    assert result == []

    result = obj.get_options("options <ONE,TWO,THREE>")
    assert result == ["ONE", "TWO", "THREE"]


# Generated at 2022-06-22 23:52:20.303354
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    g_b_n = GenericBsdIfconfigNetwork()

    option_string = '<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>'
    option_csv = g_b_n.get_options(option_string)
    assert len(option_csv) == 6
    assert 'UP' in option_csv
    assert 'BROADCAST' in option_csv
    assert 'RUNNING' in option_csv
    assert 'PROMISC' in option_csv
    assert 'SIMPLEX' in option_csv
    assert 'MULTICAST' in option_csv

    option_string = '<UP,BROADCAST,RUNNING,MULTICAST>'
    option_csv = g_b_n.get_options(option_string)

# Generated at 2022-06-22 23:52:32.158539
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../lib')
    from facts.facts.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    facts = GenericBsdIfconfigNetwork()
    words = ['tunnel', 'inet', '127.0.0.2', '-->', '127.0.0.1']
    current_if = {}
    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    facts.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'


# Generated at 2022-06-22 23:52:44.950735
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    subj = GenericBsdIfconfigNetwork()

    # wrong type of input
    with pytest.raises(TypeError):
        subj.parse_unknown_line('', '', '')

    # invalid length of input
    with pytest.raises(AssertionError):
        subj.parse_unknown_line(['a'])

    # unsupported attribute
    words = ['garbage']
    current_if = {}
    ips = {}
    subj.parse_unknown_line(words, current_if, ips)

    # unsupported attribute and unknown command
    words = ['garbage', 'moregarbage']
    current_if = {}
    ips = {}
    subj.parse_unknown_line(words, current_if, ips)

    # unknown command
    words = ['inet', 'moregarbage']

# Generated at 2022-06-22 23:52:56.855813
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    m = GenericBsdIfconfigNetwork(dict(module=None))
    defaults = {'interface': None, 'ipv4': [], 'ipv6': []}
    interfaces = {'lo0': {'device': 'lo0', 'ipv4': [dict(address='127.0.0.1',
                                                        netmask='255.0.0.0',
                                                        broadcast='127.255.255.255',
                                                        network='127.0.0.0')],
                          'ipv6': [dict(address='fe80::1',
                                        prefix='64',
                                        scope='1')],
                          'type': 'loopback'}}
    m.merge_default_interface(defaults, interfaces, 'ipv4')

    assert 'type' in defaults
    assert defaults['type']

# Generated at 2022-06-22 23:53:04.304219
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch
    from ansible.module_utils import basic

    # Declare a MockModule class, to be used by the unit test
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            pass

    # Declare a MockNetwork class, to be used by the unit test
    class MockNetwork(object):
        def __init__(self, *args, **kwargs):
            pass

    # Create a mock unit test module

# Generated at 2022-06-22 23:53:14.641089
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT']
    current_if = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_media_line(words, current_if, ips)
    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'



# Generated at 2022-06-22 23:53:25.688723
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.modules.network.generic_bsd_ifconfig import GenericBsdIfconfigNetwork
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass

    platform_cls = load_platform_subclass(GenericBsdIfconfigNetwork, 'Generic_BSD_Ifconfig')
    platform_obj = platform_cls(AnsibleModule)

    interfaces = {}
    interfaces["lan1"] = {'media':'Ethernet'}
    interfaces["lan2"] = {'media':'Ethernet autoselect'}
    interfaces["lan3"] = {'media':'Ethernet 100baseTX Full-duplex'}
    interfaces["lan4"] = {'media':'Ethernet 100baseTX Half-duplex'}

# Generated at 2022-06-22 23:53:36.774850
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    module = AnsibleModule(argument_spec={})
    network_detect_type_media = GenericBsdIfconfigNetwork()


# Generated at 2022-06-22 23:53:43.050326
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(module=None)
    assert test_GenericBsdIfconfigNetwork.populate() == {'interfaces': [],
                                                         'all_ipv4_addresses': [],
                                                         'all_ipv6_addresses': []}


# Generated at 2022-06-22 23:53:54.262768
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork()
    assert ['LOOPBACK', 'RUNNING', 'MULTICAST'] == network.get_options('3ffe:b00:c18:f00d::1%lo0<LOOPBACK,RUNNING,MULTICAST>')
    assert ['LOOPBACK', 'RUNNING', 'MULTICAST'] == network.get_options('fe80::21e:c9ff:fe63:bc8b%lo0 prefixlen 64 scopeid 0x3  <LOOPBACK,RUNNING,MULTICAST>')
    assert [] == network.get_options('fe80::21e:c9ff:fe63:bc8b%lo0 prefixlen 64 scopeid 0x3')

# Generated at 2022-06-22 23:54:07.098139
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    import json
    from ansible.module_utils.network.common.utils import dict_merge

    # example data
    defaults = dict(
        interface='eth0',
        address='192.168.0.2'
    )


# Generated at 2022-06-22 23:54:11.414114
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:54:16.133769
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    module = AnsibleModule(argument_spec=dict(option_string=dict(required=True, type='str')))
    option_string = module.params['option_string']
    network = GenericBsdIfconfigNetwork()
    result = network.get_options(option_string)
    assert result == ['BROADCAST', 'UP', 'MULTICAST', 'LOOPBACK']


# Generated at 2022-06-22 23:54:28.651756
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule({})
    ifconfig_network = GenericBsdIfconfigNetwork(module)

    current_if = {}
    test_data = []
    expected_result = {}
    ips = {}

    test_data.append(["ether", "00:50:56:9b:f3:00"])
    test_data.append(["ether", "00:50:56:9b:f3:00", "incomplete"])
    expected_result = {'macaddress': '00:50:56:9b:f3:00', 'type': 'ether'}

    for data in test_data:
        ifconfig_network.parse_ether_line(data, current_if, ips)
        assert current_if == expected_result
        current_if = {}


# Generated at 2022-06-22 23:54:40.762853
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    ifcfg = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    # NetBSD style
    words = ['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x4']
    ifcfg.parse_inet6_line(words, current_if, ips)
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'
    assert current_if['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-22 23:54:53.719071
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    result = dict(
        device='eth0',
        ipv4=[],
        ipv6=[],
        macaddress='unknown',
        type='unknown',
        flags=['BROADCAST', 'MULTICAST'],
        mtu=1500,
    )

    module = MagicMock()

    platform = GenericBsdIfconfigNetwork(module=module)


# Generated at 2022-06-22 23:55:04.694612
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'

# Generated at 2022-06-22 23:55:13.815368
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    network_facts = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ["", "flags=208843<UP,LOOPBACK,RUNNING,SIMPLEX,MULTICAST>", "mtu", "4096"]
    network_facts.parse_nd6_line(words, current_if, ips)
    assert 'options' in current_if


# Generated at 2022-06-22 23:55:27.555064
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:55:39.112770
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gen_net = GenericBsdIfconfigNetwork()

    # Need to provide a module for the call to 'run_command' inside
    # the method
    gen_net.module = DummyModule()

    default_ipv4 = { 'gateway': '10.0.2.2', 'interface': 'lo0' }
    default_ipv6 = { 'gateway': 'fe80::1', 'interface': 'lo0' }


# Generated at 2022-06-22 23:55:39.799207
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    pass

# Generated at 2022-06-22 23:55:50.515592
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Test case 1
    # Config given:
    # media: Ethernet autoselect (100baseTX <full-duplex>)
    iface = GenericBsdIfconfigNetwork()
    current_if = {}
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX', '<full-duplex>).']
    ips = {}
    iface.parse_media_line(words, current_if, ips)
    assert current_if == {'media': 'Ethernet', 'media_select': 'autoselect', 'media_options': ['full-duplex'], 'media_type': 'full-duplex'}
    assert ips == {}

    # Test case 2
    # Config given:
    # media: autoselect
    iface = GenericBsdIfconfigNetwork()
    current