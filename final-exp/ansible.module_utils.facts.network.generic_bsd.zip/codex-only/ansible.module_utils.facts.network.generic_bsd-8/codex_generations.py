

# Generated at 2022-06-22 23:45:56.182205
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    class TestGenericBsdIfconfigNetwork():
        def __init__(self):
            self.module = None

    gen_bsd = TestGenericBsdIfconfigNetwork()

    class TestCurrentIf():
        def __init__(self):
            self.media = None
            self.options = None

    curr_if = TestCurrentIf()

    class TestIps():
        def __init__(self):
            self.all_ipv4_addresses = []
            self.all_ipv6_addresses = []

    ips = TestIps()

    gen_bsd.parse_nd6_line(['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'], curr_if, ips)

# Generated at 2022-06-22 23:46:05.916838
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # Create class object
    network_class = GenericBsdIfconfigNetwork()

    # Define parameters for the test
    words=['options=799<LINKSTATE,RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING>', 'mtu', '1500']
    current_if = {'device': 'em0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Perform the test
    result = network_class.parse_options_line(words, current_if, ips)

    # Verify results
    assert result is None

# Generated at 2022-06-22 23:46:10.755758
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    m_module = MagicMock()
    m_class_args = {'module': m_module}
    m_class_kwargs = {}

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(**m_class_args, **m_class_kwargs)
    results = generic_bsd_ifconfig_network.parse_unknown_line(m_words, m_current_if, m_ips)

    assert results is None


# Generated at 2022-06-22 23:46:20.097294
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    platform = 'FreeBSD'
    module = AnsibleModule(argument_spec=dict())
    module.params = {}
    ifconfig_facts = GenericBsdIfconfigNetwork(module)

    ifconfig_facts.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184'])
    assert ifconfig_facts.current_if['device'] == 'lo0'
    assert ifconfig_facts.current_if['mtu'] == '33184'
    assert ifconfig_facts.current_if['type'] == 'loopback'


# Generated at 2022-06-22 23:46:27.436973
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class ModuleMock(object):
        def __init__(self):
            self.params = {'ansible_network_os': 'Generic_BSD_Ifconfig'}

    module = ModuleMock()
    test_input_string = '0x10<UP,LOOPBACK,RUNNING>'
    test_input_options = 'UP,LOOPBACK,RUNNING'

    n = GenericBsdIfconfigNetwork(module)

    assert n.get_options(test_input_string) == test_input_options.split(',')

# Generated at 2022-06-22 23:46:29.811787
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_object = GenericBsdIfconfigNetwork()
    assert [{}] == test_object.parse_media_line([], [{}], [])


# Generated at 2022-06-22 23:46:41.106555
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    class MockModule:
        def __init__(self, params):
            self.params = params

    module = MockModule(dict())
    network = GenericBsdIfconfigNetwork(module)
    words = ["nd6", "options=29"]
    current_if = {"device": "wlan0"}
    ips = {"all_ipv4_addresses": [], "all_ipv6_addresses": []}
    network.parse_nd6_line(words, current_if, ips)
    assert "nd6" in current_if["options"]
    assert 29 in current_if["options"]
# Unit tests for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:46:45.717798
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    network_plugin = GenericBsdIfconfigNetwork()
    current_if = {'foo':'bar'}
    ips = {}
    words = ['status', 'up']
    network_plugin.parse_status_line(words, current_if, ips)
    assert(current_if['status'] == 'up')


# Generated at 2022-06-22 23:46:49.174289
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    assert 'ether' == GenericBsdIfconfigNetwork().detect_type_media({'eth0': {'media': 'Ethernet autoselect (1000baseT)'}})['eth0']['type']


# Generated at 2022-06-22 23:46:50.519421
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    pass



# Generated at 2022-06-22 23:47:01.446865
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # set up input arguments
    defaults = {"interface": "eth0"}
    interfaces = {
        "eth0": {
            "device": "eth0",
            "ipv4": [
                {
                    "address": "192.168.1.101",
                    "netmask": "255.255.255.0",
                    "network": "192.168.1.0"
                }
            ]
        }
    }
    ip_type = "ipv4"

    # perform the test
    x = GenericBsdIfconfigNetwork()
    x.merge_default_interface(defaults, interfaces, ip_type)

    # verify the results

# Generated at 2022-06-22 23:47:10.664531
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    ifconfig_output_mock = 'options=3<RXCSUM,TXCSUM> metric 0 mtu 1500'
    words = ifconfig_output_mock.split()
    current_if = {}
    ips = []
    ifconfig_object = GenericBsdIfconfigNetwork()
    ifconfig_object.parse_options_line(words, current_if, ips)
    options = ifconfig_object.get_options(words[0])
    assert 'RXCSUM' in options
    assert 'TXCSUM' in options

# Generated at 2022-06-22 23:47:23.987788
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # this is expected to work on any BSD, but tested on FreeBSD
    module = AnsibleModule(argument_spec={})
    hostname = module.run_command('uname')[1].strip()

# Generated at 2022-06-22 23:47:32.054510
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    output = (
        'pfsync0: flags=41<UP,RUNNING> metric 0 mtu 1404\n'
        'options=80000<LINKSTATE>\n'
        'lladdr 00:e0:81:b8:93:b6\n'
        ''
    )
    module = get_module(dict(os_name='FreeBSD'))
    obj = GenericBsdIfconfigNetwork(module)

    # pylint: disable=protected-access
    obj.parse_interface_line = mock.MagicMock()
    obj.parse_interface_line.return_value = {'device': 'pfsync0'}

    obj.parse_ether_line = mock.MagicMock()
    obj.parse_ether_line.return_value = {'device': 'pfsync0'}

# Generated at 2022-06-22 23:47:43.856554
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    class ModuleMock(object):
        def __init__(self, platform_normalize):
            self.platform_normalize = platform_normalize
            self.run_command_return_value = (0, '', '')

        def get_platform(self):
            return ''

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            return self.run_command_return_value

    def parse_nd6_line(p_words, p_current_if, p_ips):

        if p_words[1] != "dr-temp=0,pltime=30s,vltime=1h":
            print("test_GenericBsdIfconfigNetwork_parse_nd6_line: parse_nd6_line failed: did not set options correctly")
            return False



# Generated at 2022-06-22 23:47:48.456150
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec=dict())
    fn = GenericBsdIfconfigNetwork.parse_lladdr_line
    line = "lladdr ac:22:0b:d4:d6:39"
    current_if = {"device": "en0"}
    ips = {"all_ipv4_addresses": []}
    fn(line.split(), current_if, ips)
    assert current_if["device"] == "en0"
    assert current_if["lladdr"] == "ac:22:0b:d4:d6:39"
    assert ips["all_ipv4_addresses"] == []


# Generated at 2022-06-22 23:48:00.880173
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    m_module = MockModule()
    m_module.run_command.return_value = (0, "", "")
    m_ifconfig_path = Mock()
    m_ifconfig_path.exists.return_value = True
    m_module.get_bin_path.return_value = m_ifconfig_path
    g = GenericBsdIfconfigNetwork(m_module)
    gi = g.get_interfaces_info('cmd')
    assert gi[0] == {}
    assert gi[1] == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}

    m_module.run_command.return_value = (0, "", "")
    m_module.get_bin_path.return_value = m_ifconfig_path
   

# Generated at 2022-06-22 23:48:07.501765
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    obj = GenericBsdIfconfigNetwork(None)
    ifaces = dict(interface1=dict(media='Ethernet'))
    result = obj.detect_type_media(ifaces)
    assert result == dict(interface1=dict(media='Ethernet', type='ether'))



# Generated at 2022-06-22 23:48:20.125997
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Test with valid data
    interfaces = {
        'Wired': {
            'device': 'Wired',
            'media': 'Ethernet autoselect (none)',
            'media_select': 'none',
            'flags': ['BROADCAST', 'MULTICAST'],
            'ipv4': [],
            'ipv6': [],
            'type': 'unknown'
        }
    }

    result = GenericBsdIfconfigNetwork.detect_type_media(interfaces)


# Generated at 2022-06-22 23:48:31.354493
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    #
    # Mock calls
    #
    def mock_get_bin_path(self, app, opt_flags=None, opt_paths=None):
        d = dict(
            ifconfig='/sbin/ifconfig',
            route='/sbin/route'
        )
        if app in d:
            return d[app]
        return None
    m_get_bin_path = MagicMock(side_effect=mock_get_bin_path)

    def mock_run_command(self, cmd, check_rc=True):
        d = dict(
            ifconfig=[0, 'foo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 33000', ''],
            route=[0, '', '']
        )

# Generated at 2022-06-22 23:48:42.231971
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_path = '/sbin/ifconfig'

    this_test = GenericBsdIfconfigNetworkTest(ifconfig_path, None)
    ifconfig_path = this_test.module.get_bin_path('ifconfig')

    if not ifconfig_path:
        assert False

    interfaces, ips = this_test.get_interfaces_info(ifconfig_path, ifconfig_options='-a')
    assert interfaces != None
    assert len(interfaces) > 0
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) > 0
    assert interfaces['lo0']['ipv4'][0]['address'] == '127.0.0.1'
    assert len(ips['all_ipv4_addresses']) > 0

# Generated at 2022-06-22 23:48:54.903347
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()

    # one item - ensure it gets merged
    defaults = {
        'interface': 'em0'
    }
    interfaces = {
        'em0': {
             'ipv4': [{'address': '10.0.0.1', 'netmask': '255.255.255.0', 'network': '10.0.0.1', 'broadcast': '10.0.0.1'}]
        }
    }
    network.merge_default_interface(defaults, interfaces, 'ipv4')

    assert defaults['interface'] == 'em0'
    assert defaults['ipv4'][0]['address'] == '10.0.0.1'

    # two items - ensure it gets merged

# Generated at 2022-06-22 23:49:08.368274
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    class Module:
        pass

    class Network:
        pass

    module = Module()
    module.run_command = lambda *args, **kwargs: (0, '', '')

    network = Network()
    network.module = module

    ifconfig = GenericBsdIfconfigNetwork()
    ifconfig.module = module

    # A line from ifconfig(8) output on FreeBSD 9.2-PRERELEASE:
    line_dict = {'line': 'gif0: flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280',
                 'words': 'gif0: flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280'.split()}

    result = ifconfig.parse_interface_line(line_dict['words'])
    assert result

# Generated at 2022-06-22 23:49:20.749115
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = AnsibleModule(
        argument_spec=dict()
    )

    words = ["interface0:", "ether", "00:80:48:12:f4:43"]

    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)

    current_if = dict(
        device="interface0",
        ipv4=[],
        ipv6=[],
        type="unknown",
        macaddress="unknown"
    )

    generic_bsd_ifconfig_network.parse_ether_line(words, current_if, dict())

    assert current_if['macaddress'] == '00:80:48:12:f4:43'
    assert current_if['type'] == 'ether'



# Generated at 2022-06-22 23:49:31.630138
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    
    interfaces = {'lo0': {'device': 'lo0', 'macaddress': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST']}, 
                  'bridge0': {'device': 'bridge0', 'macaddress': 'unknown', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'], 'media': 'Ethernet autoselect (1000baseT full-duplex)'}}
    

# Generated at 2022-06-22 23:49:33.517897
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    obj = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ["option=something"]
    obj.parse_unknown_line(words, current_if, ips)


# Generated at 2022-06-22 23:49:45.450783
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    np = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:49:53.431671
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():

    test_object = GenericBsdIfconfigNetwork()
    # Method call test
    test_words = 'options=3<RXCSUM,TXCSUM,LINKSTATE>'.split()
    test_current_if = {}
    test_ips = {}

    test_object.parse_options_line(test_words, test_current_if, test_ips)

    assert test_current_if['options'] == ['RXCSUM', 'TXCSUM', 'LINKSTATE']


# Generated at 2022-06-22 23:50:06.437767
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:50:14.254919
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # Test with ether AAAA.BBBB.CCCC
    # Expected output:
    #  current_if['macaddress'] = 'AAAA.BBBB.CCCC'
    #  current_if['type'] = 'ether'
    Test_GenericBsdIfconfigNetwork.parse_ether_line(['ether', 'AAAA.BBBB.CCCC'], current_if, ips)
    assert current_if['macaddress'] == 'AAAA.BBBB.CCCC'
    assert current_if['type'] == 'ether'

# Generated at 2022-06-22 23:50:27.465018
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    class CustomModule(Module):
        def get_bin_path(self, arg, *args, **kwargs):
            return '/sbin/ifconfig'

    custom_module = CustomModule()
    custom_module.run_command = Mock(return_value=(0, '', ''))

    network = GenericBsdIfconfigNetwork(custom_module)
    network.get_interfaces_info = Mock(return_value=([], {}))
    network.get_default_interfaces = Mock(return_value=('', ''))

    current_if = {}

# Generated at 2022-06-22 23:50:37.155536
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    ic = GenericBsdIfconfigNetwork({})

    current_if = {'device': 'en0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    ic.parse_status_line(['status:', 'active'], current_if, ips)

    assert current_if['status'] == 'active'

    ic.parse_status_line(['status:', 'foobar'], current_if, ips)

    assert current_if['status'] == 'foobar'

# Generated at 2022-06-22 23:50:45.463578
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Setup
    iface = dict(
        device='eth0',
        ipv4=list(),
        ipv6=list(),
        macaddress='unknown',
    )
    iface['status'] = 'UP'

    # Exercise and verify
    parse_status_line(list(['status', 'UP']), iface, dict())
    assert iface == dict(
        device='eth0',
        ipv4=list(),
        ipv6=list(),
        macaddress='unknown',
        status='UP',
    )

# Generated at 2022-06-22 23:50:57.623752
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
    )
    n = GenericBsdIfconfigNetwork()
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'group']
    n.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'

# Generated at 2022-06-22 23:51:07.139479
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    net = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:51:16.445077
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module_stub = NetworkModuleStub()
    module_stub.run_command = fake_run_command

    module_stub.params = dict(
        config_file=None,
        default=None,
        use_ipv6=None,
        route=None,
    )

    net_fact_module = GenericBsdIfconfigNetwork(module_stub)

    current_if = {}
    words = ['status:', 'active']
    net_fact_module.parse_status_line(words, current_if, None)

    assert current_if['status'] == 'active'

# Generated at 2022-06-22 23:51:28.538903
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # create a test class object
    test_obj = GenericBsdIfconfigNetwork()

    # negative test
    # not enough words in current_if, ips
    assert test_obj.parse_lladdr_line(['lladdr'], {}, {}) == None

    # positive test
    # address is not in current_if and in ips
    current_if = {'lladdr': 'test'}
    ipv4 = {'lladdr': 'test'}
    ips = {'ipv4': ipv4}
    assert test_obj.parse_lladdr_line(['lladdr'], current_if, ips) == None

    # positive test, address is in current_if and in ips
    current_if = {'lladdr': 'test'}

# Generated at 2022-06-22 23:51:30.808425
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    o = GenericBsdIfconfigNetwork()


# Generated at 2022-06-22 23:51:38.218683
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    genBsdNet = GenericBsdIfconfigNetwork()

    current_if = {
        'macaddress': 'unknown',
        'type': 'unknown'
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    genBsdNet.parse_ether_line(['ether', '10:1f:74:23:0a:8b'], current_if, ips)
    assert current_if['macaddress'] == '10:1f:74:23:0a:8b'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-22 23:51:40.334434
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    network = GenericBsdIfconfigNetwork()
    try:
        network.populate()
        assert True
    except Exception:
        assert False

    # TODO: add a test for the 'ifconfig -a' command, since this is a special case



# Generated at 2022-06-22 23:51:48.642748
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # This is needed for module import
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork as network_module

    network_facts = network_module()

    words = ['options=3a5b5a315d']

    current_if = {}
    ips = {}

    result = network_facts.parse_options_line(words, current_if, ips)

    assert result is None
    assert current_if['options'] == ['3a5b5a315d']
    assert result is None



# Generated at 2022-06-22 23:51:51.537800
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # GenericBsdIfconfigNetwork.parse_nd6_line(self, words, current_if, ips)
    pass


# Generated at 2022-06-22 23:52:03.357827
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:52:15.629378
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Initialise some mock input and output
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, '', '')
    option_string = 'status: active'
    words = ['status', 'active']
    current_if = dict(device='eth0', type='ether', ipv4=[], ipv6=[])
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    # Create instance of GenericBsdIfconfigNetwork class
    network = GenericBsdIfconfigNetwork(module_mock)

    # Call parse_status_line
    network.parse_status_line(words, current_if, ips)

    # Now test if the status value was correctly set in the
    # current_if dictionary

# Generated at 2022-06-22 23:52:28.594804
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    config = """
!
interface GigabitEthernet0/0
 ip address 1.1.1.1 255.255.255.0
 ipv6 address fe80::2 link-local
 ipv6 address 2001::2/64
 load-interval 30
 media-type rj45
 speed 100
 duplex full
!
interface GigabitEthernet0/1
 no ip address
 ipv6 address fe80::1 link-local
 ipv6 address 2001::1/64
 load-interval 30
 media-type rj45
 speed 1000
 duplex full
"""
    from ansible_collections.cisco.ios.tests.unit.compat.mock import patch
    from ansible.module_utils.network.ios.eos.facts.network.generic_bsd_ifconfig_network import GenericBsdIfconfigNetwork

   

# Generated at 2022-06-22 23:52:34.325611
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    n = GenericBsdIfconfigNetwork()
    words = []
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    n.parse_unknown_line(words, current_if, ips)
    assert current_if == {}
    assert ips == {}


# Generated at 2022-06-22 23:52:45.853926
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    lines = list()
    lines.append("tun0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST>")
    lines.append("        mtu 1280")
    lines.append("        tunnel inet 192.168.102.100 --> 192.168.102.101")
    lines.append("        inet 192.168.102.100 --> 192.168.102.101 netmask 0xffffffff")
    lines.append("")

    obj = GenericBsdIfconfigNetwork.parse_lines(lines, module)
    assert obj['tun0']['type'] == 'tunnel'


# Generated at 2022-06-22 23:52:57.552365
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    test_class = GenericBsdIfconfigNetwork(module=None)
    test_class.module.run_command = lambda x, check_rc=True: (0, '\n'.join(x), None)

    # simple ethernet with ipv4
    test_interfaces_info = test_class.get_interfaces_info('ifconfig -a')

    assert test_interfaces_info[0]['en0']['device'] == 'en0'
    assert test_interfaces_info[0]['en0']['type'] == 'ether'
    assert test_interfaces_info[0]['en0']['macaddress'] == '00:00:00:00:00:00'

# Generated at 2022-06-22 23:53:03.521012
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.ifconfig.generic_bsd import GenericBsdIfconfigNetwork
    import socket
    import struct

    m = GenericBsdIfconfigNetwork()
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    words = [
        'lladdr',
        'fe80::1%lo0',
    ]
    m.parse_lladdr_line(words, current_if, dict())



# Generated at 2022-06-22 23:53:16.698429
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = AnsibleModule(
        argument_spec=dict()
    )
    network_method = GenericBsdIfconfigNetwork(module)
    # set up defaults
    defaults = dict(default_ipv4=dict(interface='lo0', address='127.0.0.1'),
                    default_ipv6=dict(interface='lo0', address='::1'))
    # set up interfaces
    interfaces = dict()
    interfaces['lo0'] = dict(device='lo0', ipv4=[dict(address='127.0.0.1')],
                             ipv6=[dict(address='::1')], type='loopback', macaddress='unknown',
                             flags=['LOOPBACK', 'RUNNING', 'MULTICAST'], mtu='33184',
                             metric='0')

    # merge_default

# Generated at 2022-06-22 23:53:28.149616
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    gen_mock = MagicMock(spec_set=GenericBsdIfconfigNetwork)
    gen_mock.default_ipv4 = {'interface': 'eth0'}
    gen_mock.interfaces = {'eth0':
                          {'device': 'eth0',
                           'ipv4': [{'address' : '192.168.1.1'}]}}
    gen_mock.default_ipv6 = {'interface': 'eth0'}
    gen_mock.interfaces = {'eth0':
                          {'device': 'eth0',
                           'ipv6': [{'address' : 'fe80::1%eth0'}]}}
    gen_mock.default_ipv4 = {'interface': 'eth0'}
    gen_mock.inter

# Generated at 2022-06-22 23:53:38.455076
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Create a mock module
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['!all', '!min']),
        'filter': dict(type='list', default=None)
    })

    words1 = ['lo0', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184']
    current_if1 = dict()

    words2 = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    current_if2 = dict()

    words3 = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'nonsense']
    current_if3 = dict()

# Generated at 2022-06-22 23:53:49.595048
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    from collections import Iterable
    from ansible.module_utils.network.common.utils import dict_diff


    class Option:
        def __init__(self, value=None):
            self.value = value

    # Mock Option() for class GenericBsdIfconfigNetwork
    GenericBsdIfconfigNetwork.Option = Option

    # Mock get_bin_path() for class GenericBsdIfconfigNetwork
    GenericBsdIfconfigNetwork.get_bin_path = lambda self, command: "/usr/bin/%s" % command

    test_cases = []

    # Tests for method parse_inet_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:54:02.039766
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    platform = 'Generic_BSD_Ifconfig'

    # Initialize the object to test.
    # No need to initialize module.params
    obj = GenericBsdIfconfigNetwork()

    # On a system with IPv4 and IPv6 addresses

# Generated at 2022-06-22 23:54:13.498086
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_module = AnsibleModule({})
    test_obj = GenericBsdIfconfigNetwork(test_module)
    test_interfaces = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'},
                       'eth1': {'media': 'Ethernet autoselect (none)'}}  # should ignore
    expected_interfaces = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'},
                           'eth1': {'media': 'Ethernet autoselect (none)'}}
    assert test_obj.detect_type_media(test_interfaces) == expected_interfaces


# Generated at 2022-06-22 23:54:18.612647
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    network = GenericBsdIfconfigNetwork()
    network.parse_tunnel_line(['tunnel', 'inet6', 'enabled'], {}, {})
    assert 'type' in {'type': 'unknown'}

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_parse_tunnel_line()

# Generated at 2022-06-22 23:54:28.933603
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    
    network = GenericBsdIfconfigNetwork()
    network.detect_type_media = MagicMock(return_value = True)
    network.merge_default_interface(defaults = {'interface' : 'en0'}, interfaces = {'en0' : {'ipv4' : [{'address' : '172.17.0.2', 'netmask' : '255.255.0.0'}]}}, ip_type = 'ipv4')
    assert network.get_options('<UP,LOOPBACK,RUNNING,MULTICAST>') == ['UP','LOOPBACK','RUNNING','MULTICAST']

# Generated at 2022-06-22 23:54:41.073809
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    ifconfig_path = '/path/to/ifconfig'
    ifconfig_options = '-a'
    rc, out, err = module.run_command([ifconfig_path, ifconfig_options])
    given = out
    media_line_string = given.split('\n')[0]
    line_array = media_line_string.split(' ')

    # prepare an empty current_if object
    current_if = {}
    ips = {}

    # call the function to test
    network = GenericBsdIfconfigNetwork(module)
    network.parse_media_line(line_array, current_if, ips)

    # the function should add a new key value pair to the current_if object
    assert 'media' in current_if

    # check the value

# Generated at 2022-06-22 23:54:54.014736
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule({})
    network_facts = GenericBsdIfconfigNetwork(module)

# Generated at 2022-06-22 23:55:04.892416
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    class ModuleDouble(object):
        def get_bin_path(self, arg, default=None):
            return '/sbin/ifconfig'

        def run_command(self, arg):
            return 0, open(os.path.join(filedir, 'ifconfig_output'), 'r').read(), None

    class AnsibleModuleDouble(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    module = AnsibleModuleDouble()
    netinfo = GenericBsd

# Generated at 2022-06-22 23:55:16.156361
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    """
    Test for method - parse_tunnel_line
    """
    m = GenericBsdIfconfigNetwork()
    data = m.parse_tunnel_line({'device': 'eth0', 'ipv4': ['127.0.0.1'],
                         'ipv6': ['::1'], 'type': 'unknown',
                         'flags': ['UP', 'BROADCAST', 'RUNNING', 'MULTICAST'],
                         'metric': 1, 'mtu': 1500, 'lladdr': '00:21:86:3f:fa:f1'},
                         ['tunnel'], {})

# Generated at 2022-06-22 23:55:27.992846
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<UP,BROADCAST,RUNNING>') == ['UP', 'BROADCAST', 'RUNNING'])
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<UP>') == ['UP'])
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<UP,BROADCAST>') == ['UP', 'BROADCAST'])
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<BROADCAST>') == ['BROADCAST'])
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<RUNNING>') == ['RUNNING'])
    assert (ifconfig.GenericBsdIfconfigNetwork.get_options('&<>') == [])

# Generated at 2022-06-22 23:55:39.555739
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch

    route_command = [
        'route get default',
        'route get -inet6 default',
    ]


# Generated at 2022-06-22 23:55:46.883805
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    passed = True
    gbin = GenericBsdIfconfigNetwork()
    words = ['status:', 'active']
    current_if = {}
    ips = {}
    gbin.parse_status_line(words, current_if, ips)
    if current_if['status'] != 'active':
        passed = False
    if passed:
        print("test_GenericBsdIfconfigNetwork_parse_status_line passed")
    return passed
