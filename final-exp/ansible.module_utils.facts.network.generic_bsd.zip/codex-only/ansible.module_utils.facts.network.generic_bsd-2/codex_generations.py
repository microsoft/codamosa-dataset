

# Generated at 2022-06-22 23:45:51.842144
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    class AnsibleModuleMock():
        pass

    class ModuleMock():
        def __init__(self):
            self.run_command_results = ('', '', '')
            self.run_command_exceptions = ()
            self.run_command_calls = []

        def run_command(self, args):
            self.run_command_calls.append(args)
            if len(self.run_command_exceptions) > 0:
                raise self.run_command_exceptions.pop(0)
            return self.run_command_results.pop(0)

        def get_bin_path(self, executable, required=False):
            return executable

    module_obj = AnsibleModuleMock()
    module_obj.params = {}

    module_obj.check_mode = False
    module_obj

# Generated at 2022-06-22 23:46:03.647504
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from test.units.compat import unittest
    from test.units.modules.utils import set_module_args

    class TestGenericBsdIfconfigNetFactsModule(unittest.TestCase):

        def setUp(self):
            self.mock_module = MagicMock()
            self.mock_module.run_command.return_value = (0, "", "")
            self.mock_module.get_bin_path.return_value = "/sbin/ifconfig"
            self.test_GenericBsdIfconfigNetwork = GenericBsdIfconfigNetwork(self.mock_module)
            set_module_args(dict())


# Generated at 2022-06-22 23:46:12.584650
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    iface = GenericBsdIfconfigNetwork()
    words = ['em0:', 'flags', '=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric', '0', 'mtu', '1500', 'options', '=189<RXCSUM,VLAN_MTU,VLAN_HWTAGGING>', 'ether', '8c:dc:d4:23:da:d6', 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'media:', 'Ethernet', 'autoselect', '(1000baseT', '<full-duplex>)', 'status:', 'active']
    current_if = dict()
    ips = dict()

# Generated at 2022-06-22 23:46:23.816784
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list'),
    }, supports_check_mode=False)

    iface = dict(
        device='lo0',
        ipv4=[dict(address='127.0.0.1'), dict(address='127.0.1.1')],
        ipv6=[dict(address='::1')],
        lladdr='00:00:00:00:00:00',
        macaddress='00:00:00:00:00:00',
        metric='0',
        mtu='16384',
        flags=[
            'UP',
            'LOOPBACK',
            'RUNNING'
        ],
        type='loopback',
        status='active'
    )


# Generated at 2022-06-22 23:46:24.868190
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Nothing to test
    pass


# Generated at 2022-06-22 23:46:32.112044
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    """Tests a call to GenericBsdIfconfigNetwork.parse_unknown_line()."""

    network = GenericBsdIfconfigNetwork()

    # Test with a known bad call.
    current_if = dict()
    ips = dict()
    words = ['bad', 'call']
    with pytest.raises(TypeError):
        network.parse_unknown_line(words, current_if, ips)

    # Test with a known good call.
    current_if = dict()
    ips = dict()
    words = []
    network.parse_unknown_line(words, current_if, ips)
    # Should not crash



# Generated at 2022-06-22 23:46:43.445504
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # Input parameters for method
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    defaults = {'interface':'00:01:02:03:04:05'}
    interfaces = {'foo':{}, '00:01:02:03:04:05':{'ipv4':[],'ipv6':[]} }
    ip_type = 'ipv4'

    generic_bsd_ifconfig_network.merge_default_interface(defaults, interfaces, ip_type)

    # Return value
    assert defaults['interface'] == '00:01:02:03:04:05'

    # not in dictionary
    defaults = {'interface':'foo'}
    generic_bsd_ifconfig_network.merge_default_interface(defaults, interfaces, ip_type)

# Generated at 2022-06-22 23:46:51.828959
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class Options():
        def __init__(self, bin_path=None, gather_subset=None, filter=None):
            self.bin_path = bin_path
            self.gather_subset = gather_subset
            self.filter = filter

    class Module():
        def __init__(self):
            self.check_mode = False
            self.params = {}
            self.ifconfig_path = 'bin/ifconfig'
            self.run_command_environ_update = {}

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.ifconfig_path

        def run_command(self, args, check_rc=True):
            class Object(object):
                pass

            obj = Object()
            obj.stdout = ''

# Generated at 2022-06-22 23:47:03.613515
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:47:16.635620
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = MagicMock()
    interface = {}

    # binary netmask
    words = ['inet', '192.0.2.1', 'netmask', '0xffffff00']
    GenericBsdIfconfigNetwork(module).parse_inet_line(words, interface, {})
    assert len(interface['ipv4']) == 1
    assert interface['ipv4'][0]['netmask'] == '255.255.255.0'

    # dotted quad
    words = ['inet', '192.0.2.2', 'netmask', '255.255.255.0']
    GenericBsdIfconfigNetwork(module).parse_inet_line(words, interface, {})
    assert len(interface['ipv4']) == 2

# Generated at 2022-06-22 23:47:18.822107
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class TestGenericBsdIfconfigNetwork(GenericBsdIfconfigNetwork):
        def __init__(self):
            pass

    option_string = 'test<test,test>'
    options = TestGenericBsdIfconfigNetwork().get_options(option_string)
    assert len(options) == 2
    assert 'test' in options
    assert 'test,' in options

# Generated at 2022-06-22 23:47:24.654050
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network_info = {'em0': {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'mtu': '1500', 'macaddress': 'unknown', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST']}, 'em1': {'device': 'em1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'mtu': '1500', 'macaddress': 'unknown', 'media': 'Ethernet autoselect', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST']}}

# Generated at 2022-06-22 23:47:31.584874
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    w = ['tunnel', 'tun0', 'inet', '172.16.1.2', 'netmask', '0xfffff800', 'destination', '172.16.0.1', 'nd6', 'options=1']
    c = {'ipv4': [], 'ipv6': []}
    i = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    obj.parse_tunnel_line(w, c, i)
    if c['type'] != 'tunnel':
        print("tunnel: %s" % c['type'])


# Generated at 2022-06-22 23:47:43.715199
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Mock variables
    route_path = '/usr/bin/route'
    # Mock commands
    mock_commands = dict(
        v4=['/usr/bin/route', '-n', 'get', 'default'],
        v6=['/usr/bin/route', '-n', 'get', '-inet6', 'default'],
    )

    # Real command output

# Generated at 2022-06-22 23:47:49.097190
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    platform = GenericBsdIfconfigNetwork()
    platform.module = module
    platform.default_network = dict()
    platform.default_network['interfaces'] = []
    platform.ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = "nd6 options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL,NO_RADR>".split()
    current_if = {}
    platform.parse_nd6_line(words, current_if, platform.ips)


# Generated at 2022-06-22 23:48:01.829773
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    mod = MagicMock()
    mod.run_command.return_value = 0, "..\n..\n..\ninet 127.0.0.1 netmask 0xff000000 broadcast 127.255.255.255\n..\n..\n..", ""

    gbi = GenericBsdIfconfigNetwork(mod)

    ifconf = gbi.get_interfaces_info(mod.get_bin_path.return_value, ifconfig_options='-a')[0]

    assert ifconf['lo0']['ipv4'][0] == {
        'address': '127.0.0.1',
        'netmask': '255.255.255.0',
        'broadcast': '127.255.255.255',
        'network': '127.0.0.1'
    }

#

# Generated at 2022-06-22 23:48:09.802900
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    c = GenericBsdIfconfigNetwork()
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)', 'full-duplex']
    current_if = {}
    ips = {}
    c.parse_media_line(words, current_if, ips)
    assert 'media' in current_if
    assert 'media_select' in current_if
    assert 'media_type' in current_if
    assert 'media_options' in current_if



# Generated at 2022-06-22 23:48:16.145600
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    mock_module = MockModule(platform='MockCatalog')
    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    network = GenericBsdIfconfigNetwork(mock_module)

    current_if = {}

    words = ['status:', 'active']
    network.parse_status_line(words, current_if, None)
    assert current_if['status'] == 'active'

# Generated at 2022-06-22 23:48:28.673056
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule({'module_name': 'ifconfig', 'module_args': {'_ansible_check_mode': True}})
    network = GenericBsdIfconfigNetwork(module=module)

    class RouteOut(object):
        def __init__(self, out_str):
            self.out = out_str
            self.err = ""
            self.rc = 0


# Generated at 2022-06-22 23:48:40.862775
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = 'ifconfig'

    mock_connection = MagicMock()
    mock_connection.get_bin_path.return_value = 'ifconfig'

    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    mod.check_mode = False
    mod.connection =  mock_connection
    mod.params = {
        'gather_subset': '!all',
        'gather_network_resources': ['interfaces']
    }
    mod.run_command = lambda *args, **kwargs: (0, '', '')

    netinfo = GenericBsdIfconfigNetwork()

    netinfo.module = module_mock
    netinfo.get_default

# Generated at 2022-06-22 23:48:54.129575
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    m = GenericBsdIfconfigNetwork()
    interfaces = {'lo0': {'ipv4': [],
                          'ipv6': [],
                          'media': 'Ethernet autoselect (1000baseT full-duplex)'},
                  'xn0': {'ipv4': [],
                          'ipv6': [],
                          'media': 'Ethernet autoselect (1000baseT full-duplex)'}}
    for iface in interfaces:
        if 'ether' in interfaces[iface]['media'].lower():
            interfaces[iface]['type'] = 'ether'

# Generated at 2022-06-22 23:49:07.638214
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    from ansible.module_utils.basic import AnsibleModule
    test_data={
            "module": AnsibleModule,
            "module_args": "-a -b -c".split(" ")
            }
    ifconfig_module = GenericBsdIfconfigNetwork(test_data)

# Generated at 2022-06-22 23:49:20.749100
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # test options without '='
    words = ['options', 'RUNNING', 'BROADCAST', 'SIMPLEX', 'MULTICAST']
    ifcfg = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    ifcfg.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['RUNNING', 'BROADCAST', 'SIMPLEX', 'MULTICAST']

    # test options with '='
    words = ['options=RUNNING,BROADCAST,SIMPLEX,MULTICAST']
    ifcfg = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    ifcfg.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:49:25.035229
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    # Test if the method parse_interface_line of class GenericBsdIfconfigNetwork is working properly
    # Initialization of the class objects
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(None)
    # Converting positive test cases
    # Positive test case 1

# Generated at 2022-06-22 23:49:37.155368
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_ifconfig_output_single_1 = '''lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384
        inet 127.0.0.1 netmask 0xff000000
        inet6 ::1 prefixlen 128
        inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1
        nd6 options=201<PERFORMNUD,DAD>'''


# Generated at 2022-06-22 23:49:49.249614
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

  # given
  network = GenericBsdIfconfigNetwork()
  current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
  ips = dict(
      all_ipv4_addresses=[],
      all_ipv6_addresses=[],
  )

  # when
  test_case = 'inet 127.0.0.1 netmask 0xff000000'
  words = test_case.split()
  network.parse_inet_line(words, current_if, ips)

  # then
  assert '127.0.0.1' in current_if['ipv4']
  assert ips['all_ipv4_addresses'][0] == '127.0.0.1'



# Generated at 2022-06-22 23:49:52.113760
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network_facts = {}
    network_facts = GenericBsdIfconfigNetwork().detect_type_media(network_facts)

# Generated at 2022-06-22 23:50:04.845434
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    test_data = """nd6 options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>
    media: Ethernet autoselect (1000baseT <full-duplex>)
    status: active
lladdr 7c:c5:37:73:d3:07
    inet 192.168.3.9 netmask 0xffffff00 broadcast 192.168.3.255
    inet 10.1.1.1 netmask 0xffffff00 broadcast 10.1.1.255
    inet6 fe80::7ec5:37ff:fe73:d307%en0 prefixlen 64 scopeid 0x4
    inet6 2001:470:1f07:375::2 prefixlen 64
"""

# Generated at 2022-06-22 23:50:17.214032
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    """
    This function is not a unit test, it's just used as a scratch space to
    test the output of class GenericBsdIfconfigNetwork.
    """
    # This module was split from the main ifconfig_facts module.
    # So we need to setup a fake module object with a fake run_command.
    from ansible.module_utils.facts.network.base import NetworkModule
    # pylint: disable=unused-variable
    module = NetworkModule()

    # BSD ifconfig command is in the form of:
    #   ifconfig -e
    # This is similar to Linux command:
    #   ip -o link show
    #
    # But many keywords of these two command are different, 
    # so we need to construct a fake test data.
    #
    # Test data below is generated from a macOS.
   

# Generated at 2022-06-22 23:50:30.200621
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # create instance of class to test
    network_facts = GenericBsdIfconfigNetwork(module)

    # create test variables

# Generated at 2022-06-22 23:50:42.951621
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    """Unit test for method parse_media_line of class GenericBsdIfconfigNetwork"""
    # Specific values
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']

    # expected value
    expected_current_if = {'device': 'en1', 'metric': '0', 'flags': ['BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST', 'UP'], 'mtu': '1500', 'media': 'Ethernet', 'media_select': 'autoselect', 'media_type': '1000baseT', 'media_options': ['full-duplex']}

    # instanciating the class GenericBsdIfconfigNetwork
    network_obj = GenericBsdIfconfigNetwork()
    current_

# Generated at 2022-06-22 23:50:52.120083
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:50:58.743991
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    gbif = GenericBsdIfconfigNetwork()
    gbif.parse_unknown_line(['foo', 'bar', 'baz'], None, None)


# Generated at 2022-06-22 23:51:04.973566
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    network = GenericBsdIfconfigNetwork(None, ifconfig_path, ifconfig_options)
    words = ['unknown', 'words', '!!!']
    current_if = {}
    ips = {}
    # the method simply ignores the unknown line,
    # so let's verify nothing is changed
    network.parse_unknown_line(words, current_if, ips)
    assert len(current_if) == 0
    assert len(ips) == 0



# Generated at 2022-06-22 23:51:16.970912
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    '''
    To run this test, first use the following commands:

        $ sudo vagrant up
        $ sudo vagrant ssh
        $ cd /vagrant/lib/ansible/module_utils/network/bsd
        $ sudo valgrind --leak-check=full python3 -m nose -v tests/unit/module_utils/network/bsd/test_bsd_network.py

    '''
    ifconfig_path = '/sbin'
    gbi = GenericBsdIfconfigNetwork()

    interfaces, ips = gbi.get_interfaces_info(ifconfig_path)
    # Test if all interfaces are present
    assert len(interfaces) == 4

    # Test if ether interface configuration is there.
    assert 'media' in interfaces['en0']

# Generated at 2022-06-22 23:51:29.426108
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # BSDs use the route command
    m = GenericBsdIfconfigNetwork()
    assert isinstance(m, GenericBsdIfconfigNetwork)

    m.module = IfconfigNetworkModuleFake('BSD')
    route_path = m.module.get_bin_path('route')
    assert route_path is not None

    def_ipv4, def_ipv6 = m.get_default_interfaces(route_path)

    ifconfig_interface = 'wlan0'
    ifconfig_ipv4_address = '192.0.2.1'
    ifconfig_ipv6_address = '2001:db8::1'

    assert def_ipv4['interface'] == ifconfig_interface
    assert def_ipv4['address'] == ifconfig_ipv4_address


# Generated at 2022-06-22 23:51:38.573326
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    ifconfig_output = """\
en0: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500
    ether 12:34:56:78:9a:bc
    inet6 fe80::4567:89ab:cdef:1234%en0 prefixlen 64 secured scopeid 0x8
    inet 10.2.3.4 netmask 0xffffff00 broadcast 10.2.3.255
    nd6 options=201<PERFORMNUD,DAD>
    media: autoselect (100baseTX <full-duplex>)
    status: active
    lladdr 12:34:56:78:9a:bc"""
    # Parse the string using the class method
    defaults = dict()
    # Need to mock a fake network interface
   

# Generated at 2022-06-22 23:51:41.400092
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    class_instance = GenericBsdIfconfigNetwork(module)
    assert 'ether' == class_instance.detect_type_media({'lo0': {'type': 'unknown', 'media': 'Ethernet autoselect'}})['lo0']['type']



# Generated at 2022-06-22 23:51:43.869172
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    assert generic_bsd_ifconfig_network.get_default_interfaces('route') == ({}, {})



# Generated at 2022-06-22 23:51:50.865245
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = Mock()
    ifconfig_network_parser = GenericBsdIfconfigNetwork(module)
    current_if = {}
    words = ['status:', 'active']
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ifconfig_network_parser.parse_status_line(words, current_if, ips)
    assert 'status' in current_if


# Generated at 2022-06-22 23:52:02.866998
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    def mock_module_run_command_default_route_v4(self):
        module = self
        module.run_command.return_value = 0, "interface: en0\ngateway: 10.0.0.1", ""

    def mock_module_run_command_default_route_v6(self):
        module = self
        module.run_command.return_value = 0, "interface: en0\ngateway: fd00::1", ""

    # Test without IPv6
    module = self
    module.run_command = MagicMock()

# Generated at 2022-06-22 23:52:15.020851
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    words = [
        'inet6',
        'fe80::1%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x1',
        'inet6',
        'fe80::2%lo0',
        'prefixlen',
        '64',
        'scopeid',
        '0x2',
        'netmask',
        '0xffffffff'
    ]

    current_if = dict()
    ips = dict()
    network = GenericBsdIfconfigNetwork()
    network.parse_inet6_line(words, current_if, ips)

    # First address
    assert current_if['ipv6'][0]['address'] == 'fe80::1%lo0'

# Generated at 2022-06-22 23:52:28.153014
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    bsdIfconfigNetwork = GenericBsdIfconfigNetwork()
    current_if = {}
    words = ["options=29b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWTSO,RXCSUM_IPV6,TXCSUM_IPV6>"]
    ips = {}
    bsdIfconfigNetwork.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:52:30.362643
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    GenericBsdIfconfigNetworkInstance = GenericBsdIfconfigNetwork()
    assert True==True



# Generated at 2022-06-22 23:52:42.881031
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    m = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'lo0', 'gateway': '::'}
    interfaces = {'lo0': [{'ipv4': [], 'ipv6': [{'address': 'fe80::1%lo0', 'prefix': 64, 'scope': '0x2'}], 'device': 'lo0', 'metric': '0', 'mtu': '33333', 'type': 'tunnel', 'status': 'active', 'lladdr': 'fe80::1%lo0'}]}
    m.merge_default_interface(defaults, interfaces, 'ipv6')

# Generated at 2022-06-22 23:52:55.097801
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    module = FakeAnsibleModule()
    module.ansible_facts = {}
    gen_if = GenericBsdIfconfigNetwork(module)

    rv = vars(gen_if.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']))
    assert_equals(rv['device'], 'lo0')

    rv = vars(gen_if.parse_interface_line(['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184', 'metric', '1']))
    assert_equals(rv['metric'], '1')


# Generated at 2022-06-22 23:53:02.850037
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    class FakeModule(object):
        def run_command(self, stuff):
            return 0, 'tun0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1280', ''

    ifconfig = GenericBsdIfconfigNetwork(FakeModule())
    current_if = {}
    ips = {}
    words = 'tun0: flags=8051<UP,POINTOPOINT,RUNNING,MULTICAST> mtu 1280'.split()
    ifconfig.parse_interface_line(words)
    ipv4 = [{'address': '192.168.1.1'}, {'address': '192.168.1.2'}]

# Generated at 2022-06-22 23:53:16.003115
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    result = GenericBSDIfconfigNetwork.parse_unknown_line(
        ['en0', 'lladdr', '0a:00:02:6c:2d:a0', 'temp:', '0', '(expires', 'in', '23', 'sec)'],
        {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'ether', 'options': [], 'macaddress': '0a:00:02:6c:2d:a0', 'mtu': '1500', 'metric': '0', 'status': 'active', 'lladdr': '0a:00:02:6c:2d:a0'},
        {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    )

# Generated at 2022-06-22 23:53:20.533940
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    """Parse options line test"""
    network_facts = GenericBsdIfconfigNetwork()
    words = ['options=3<RXCSUM,TXCSUM,VLAN_MTU>', 'inet', '6.0.0.1', 'netmask', '0xffff0000']
    current_if = {}
    ips = {}
    network_facts.parse_options_line(words, current_if, ips)

    assert current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU']
    assert ips == {}

# Generated at 2022-06-22 23:53:25.547084
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    src = GenericBsdIfconfigNetwork(module)
    res = src.populate()
    module.exit_json(**res)


# Generated at 2022-06-22 23:53:36.643314
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # TODO: put in a command line argument parser
    test_platform = 'Generic_BSD_Ifconfig'

    # Mock up the module
    module = get_module_mock()
    fake_current_if = {}
    fake_ips = {}

    # Mock up the class we are testing.
    system = GenericBsdIfconfigNetwork()

    # Set up the method args.

# Generated at 2022-06-22 23:53:45.832307
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    new_network = GenericBsdIfconfigNetwork()
    parse_call_line = 'options=80000<LINKSTATE,LOOPBACK,MULTICAST>'
    words = parse_call_line.split()
    current_if = dict()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    new_network.parse_options_line(words, current_if, ips)

    assert current_if['options'] == ['LINKSTATE', 'LOOPBACK', 'MULTICAST']


# Generated at 2022-06-22 23:53:58.392852
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    # Setup data for unit test
    module = Mock()
    module.run_command.return_value = (0, '', '')
    gni = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {}
    words = ['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)',
             'status:', 'active', 'lladdr', 'a0:99:9b:d3:2a:ff', 'nd6',
             'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>']
    # Call parse_media_line()
    gni.parse_media_line(words, current_if, ips)
    # Validate data for unit test

# Generated at 2022-06-22 23:54:04.993459
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec={})
    network_module = GenericBsdIfconfigNetwork(module)
    interfaces = {}
    ips = {}
    current_if = {}

    words = ["options=69b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM,TSO4,TSO6,VLAN_HWTSO,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6>"]
    network_module.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:54:16.139992
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # System under test
    sut = GenericBsdIfconfigNetwork()
    # Mock route command to return overriden output and error
    mock_route_output = {
        "route -n get default": ("default: gateway 10.0.0.1\n"),
        "route -n get -inet6 default": ("default: gateway ::1%lo0\n")
    }
    sut.module.run_command = mock_command(sut.module.run_command, mock_route_output)
    #
    # Run the code to test
    default_ipv4, default_ipv6 = sut.get_default_interfaces('/sbin/route')
    #
    # Check results
    assert default_ipv4 == {'gateway': '10.0.0.1'}
    assert default_ip

# Generated at 2022-06-22 23:54:28.651127
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    gen_net_obj = GenericBsdIfconfigNetwork({})

    a_dict = {}
    a_dict['options'] = []
    gen_net_obj.parse_nd6_line(['nd6', 'options='], a_dict, {})
    assert a_dict['options'] == ['options=']

    a_dict['options'] = []
    gen_net_obj.parse_nd6_line(['nd6', 'options=PO'], a_dict, {})
    assert a_dict['options'] == ['PO']

    a_dict['options'] = []
    gen_net_obj.parse_nd6_line(['nd6', 'options=PO,PR'], a_dict, {})
    assert a_dict['options'] == ['PO', 'PR']

# Generated at 2022-06-22 23:54:40.762847
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    ifconfig_path = '/usr/sbin/ifconfig'

    if ifconfig_path is None:
        return

    bsd_network = GenericBsdIfconfigNetwork()
    route_path = '/usr/sbin/route'

    if route_path is None:
        return

    default_ipv4, default_ipv6 = bsd_network.get_default_interfaces(route_path)
    _, ips = bsd_network.get_interfaces_info(ifconfig_path)
    _ = ips

    # Test case 1

    # No words

    words = []
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-22 23:54:51.221177
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    def_intf = {'interface': 'eth0'}
    interface = {}
    interface['eth0'] = {'ipv4': ['192.168.0.1'], 'ipv6': ['10.0.0.1']}

    gen_bsd = GenericBsdIfconfigNetwork()
    gen_bsd.merge_default_interface(def_intf, interface, 'ipv4')

    assert def_intf['ipv4'] == interface['eth0']['ipv4']
    assert def_intf['ipv6'] == interface['eth0']['ipv6']



# Generated at 2022-06-22 23:55:00.452531
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    facts = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}

    values = ['ether', '95:04:18:a7:46:d8', 'lladdr', '95:04:18:a7:46:d8']
    facts.parse_ether_line(values, iface, ips)
    assert iface == dict(device='em0', ipv4=[], ipv6=[], type='unknown', macaddress='95:04:18:a7:46:d8')


# Generated at 2022-06-22 23:55:04.636425
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    instance = GenericBsdIfconfigNetwork()
    instance.parse_unknown_line(words=['word1', 'word2'], current_if=dict(), ips=dict())
    assert True, 'the code did not raise exception for having insufficient parameters'


# Generated at 2022-06-22 23:55:15.718179
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module)
    generic_bsd_ifconfig_network.devicename = 'lo0'
    words = 'inet 10.0.0.1 netmask 0xffffff00 broadcast 10.0.0.255'.split()
    res = generic_bsd_ifconfig_network.parse_inet_line(words, {}, {})
    assert res == {'address': '10.0.0.1', 'netmask': '255.255.255.0', 'network': '10.0.0.0', 'broadcast': '10.0.0.255'}



# Generated at 2022-06-22 23:55:23.470898
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    module = ansible_module_mock()
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown'}
    ips = dict(
      all_ipv4_addresses=[],
      all_ipv6_addresses=[],
    )
    words = 'ether 00:00:00:00:00:00'.split()
    expected_result = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'ether', 'macaddress': '00:00:00:00:00:00'}
    network_parser = GenericBsdIfconfigNetwork(module)
    network_parser.parse_ether_line(words, current_if, ips)
    assert current

# Generated at 2022-06-22 23:55:32.298018
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    iface = GenericBsdIfconfigNetwork()

    # The following lines are expected by the test.
    # If a line is commented out then it is not expected to be parsed by this test method

# Generated at 2022-06-22 23:55:39.164863
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    cmdobj = GenericBsdIfconfigNetwork(None)
    words = ['lladdr', '8a:7d:3a:3d:cf:b5']
    current_if = {}
    ips = {}
    cmdobj.parse_lladdr_line(words, current_if, ips)
    assert current_if['lladdr'] == '8a:7d:3a:3d:cf:b5'

# Generated at 2022-06-22 23:55:50.017117
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork