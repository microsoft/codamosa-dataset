

# Generated at 2022-06-22 23:45:51.881777
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    interfaces = {}
    ips = {}
    current_if = {}
    network = GenericBsdIfconfigNetwork()
    # Define words variable
    words = ['tunnel', 'inet', '6to4', 'tunnel', 'destination', 'any', 'tunnel', 'mode', 'sit']
    network.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

if __name__ == '__main__':
    # Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
    test_GenericBsdIfconfigNetwork_parse_tunnel_line()

# Generated at 2022-06-22 23:45:53.508428
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
  pass

if __name__ == '__main__':
  unittest.main()

# Generated at 2022-06-22 23:46:05.570129
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    result = GenericBsdIfconfigNetwork().parse_inet_line(
        ['inet', '10.0.0.1', 'netmask', '0xffffff00', 'broadcast', '10.0.0.255'],
        {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'mtu': '33184', 'flags': ['LOOPBACK', 'RUNNING', 'MULTICAST']})

    assert result
    assert result == {'device': 'lo0', 'ipv4': [{'address': '10.0.0.1', 'netmask': '255.255.255.0', 'network': '10.0.0.0', 'broadcast': '10.0.0.255'}], 'ipv6': []}



# Generated at 2022-06-22 23:46:13.481575
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network_module = GenericBsdIfconfigNetwork(module=dict())

    interfaces = {
        'eth0': {
            'ipv4': [],
            'ipv6': [],
            'type': 'ether',
            'device': 'eth0',
            'flags': ['BROADCAST', 'MULTICAST'],
            'macaddress': '08:00:27:76:32:8c',
            'metric': '0',
            'mtu': '1500',
        },
    }

    defaults = {
        'interface': 'eth0',
    }

    network_module.merge_default_interface(defaults, interfaces, 'ipv4')
    assert 'ipv4' not in defaults
    assert 'ipv6' not in defaults

# Generated at 2022-06-22 23:46:16.828238
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    # No setup is needed
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    assert(generic_bsd_ifconfig_network.platform == 'Generic_BSD_Ifconfig')


# Generated at 2022-06-22 23:46:27.392134
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    print("Executing test_GenericBsdIfconfigNetwork_parse_tunnel_line")
    gbifcnet = GenericBsdIfconfigNetwork({})
    words = ['tunnel', 'inet', '10.223.254.1', '-->', '10.223.254.2',
             'netmask', '0xffffffff', 'tos', '0x10']
    current_if = {'device': 'en0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    assert current_if == gbifcnet.parse_tunnel_line(words, current_if, ips)
    assert 'type' in current_if
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:46:33.231716
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule
    network_module = GenericBsdIfconfigNetwork(module)

    current_if = {}
    words = ['fe80::250:56ff:feaa:3c3e%bridge0',
             'prefixlen', '64',
             'scopeid', '0x8']
    network_module.parse_inet6_line(words, current_if, {})
    assert current_if == {"ipv6": [{'address': 'fe80::250:56ff:feaa:3c3e%bridge0',
                                   'prefix': '64', 'scope': '0x8'}]}



# Generated at 2022-06-22 23:46:44.840195
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:46:49.980942
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    sut = GenericBsdIfconfigNetwork()
    words = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'
    words = words.split()
    current_if = {'options':[]}
    expected = {'options': ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']}
    sut.parse_nd6_line(words, current_if, ips=None)
    assert current_if == expected

# Generated at 2022-06-22 23:46:57.254456
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    network = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {}
    words = ['options=23<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM>', 'metric', '0', 'mtu', '1500']
    network.parse_options_line(words, current_if, ips)
    assert current_if == {'options': ['RXCSUM', 'TXCSUM', 'VLAN_MTU', 'VLAN_HWTAGGING', 'VLAN_HWCSUM']}
    assert ips == {}

    #try empty word

# Generated at 2022-06-22 23:47:10.429187
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    ansible_module_mock, facts_module_mock, network_module_mock, facts_module_return, network_module_return, \
    ansible_module_mock_attrs, processor_architecture, ansible_module_exit_json, ansible_module_fail_json = setup_module_objects()

    # ###
    # Module parameters
    # ###

    ansible_module_mock_attrs['params'] = dict(
        gather_subset='!all',
        gather_network_resources='yes'
    )

    # ###
    # Facts gather helper methods
    # ###


# Generated at 2022-06-22 23:47:23.753547
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    data_in_1 = ["lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184",
                 "inet 127.0.0.1 netmask 0xff000000"]

    data_in_2 = ["lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184",
                 "inet 127.0.0.1 netmask ffffff00"]


# Generated at 2022-06-22 23:47:31.524794
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    ips = {}
    words = ['lladdr', '01:02:03:04:05:06', 'temp']
    GenericBsdIfconfigNetwork.parse_lladdr_line(0, words, current_if, ips)
    assert current_if['lladdr'] == '01:02:03:04:05:06'
    current_if = {}
    ips = {}
    words = ['lladdr', '01:02:03:04:05:06']
    GenericBsdIfconfigNetwork.parse_lladdr_line(0, words, current_if, ips)
    assert current_if['lladdr'] == '01:02:03:04:05:06'


# Generated at 2022-06-22 23:47:38.990559
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    network = GenericBsdIfconfigNetwork()
    line = 'ether 00:19:d2:e1:63:ad'
    current_if = {}
    ips = {}
    network.parse_ether_line(line.split(), current_if, ips)
    assert current_if['macaddress'] == '00:19:d2:e1:63:ad'
    assert current_if['type'] == 'ether'


# Generated at 2022-06-22 23:47:51.928303
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:47:56.933160
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    test_network = GenericBsdIfconfigNetwork()
    interfaces = {
        'lo0': {
            'ipv4': [{'address': '127.0.0.1'}, {'address': '127.1.1.1'}],
            'ipv6': [{'address': '::1'}]
        },
        'em0': {
            'ipv4': [{'address': '192.168.1.10'}, {'address': '192.168.1.100'}],
            'ipv6': [{'address': 'dead:beef::1'}]
        }
    }
    default_ipv4 = {'interface': 'em0', 'address': '192.168.1.10'}

# Generated at 2022-06-22 23:48:04.005631
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    module = AnsibleModule(
        argument_spec=dict()
    )

    gn = GenericBsdIfconfigNetwork(module)

    # Check that the object was instantiated properly
    assert hasattr(gn, 'module')
    assert hasattr(gn, 'platform')
    assert hasattr(gn, 'populate')
    assert hasattr(gn, 'get_default_interfaces')
    assert hasattr(gn, 'get_interfaces_info')

# Generated at 2022-06-22 23:48:16.006908
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:48:20.667616
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    # TODO: For now we don't have a good way to unit test this -
    #       the test module doesn't know how to mock socket.inet_aton()
    #       and similar
    pass


# Generated at 2022-06-22 23:48:32.176957
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    class TestModule(object):
        _shell = None

        @property
        def shell(self):
            return self._shell

        @shell.setter
        def shell(self, value):
            self._shell = value

    test_module = TestModule()
    network = GenericBsdIfconfigNetwork(test_module)
    iface = {'ipv4': []}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Test regular IP address

# Generated at 2022-06-22 23:48:42.555085
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    ifconfig = GenericBsdIfconfigNetwork()
    # Test case with mtu, metric and a leading , in flags
    words = [
        'wl0',
        ',UP,BROADCAST,RUNNING,',
        'SIMPLEX,MULTICAST',
        'metric',
        '1',
        'mtu',
        '1500',
        ]
    interface = ifconfig.parse_interface_line(words)
    assert 'wl0' == interface['device']
    assert interface['mtu'] == '1500'
    assert interface['metric'] == '1'

    # Test case with no metric
    words = ['vether0', 'flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'mtu 1500']
    interface = ifconfig.parse_interface_

# Generated at 2022-06-22 23:48:55.001480
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # TODO: make sure the other classes have the same members as GenericBsdIfconfigNetwork
    nf = GenericBsdIfconfigNetwork()

    words = ['fe80::1%lo0','','inet6','','prefixlen','64','','scopeid','0x2']
    current_if = {'ipv6' : [], 'device' : 'lo0'} # copied from any subclass
    ips = {'all_ipv6_addresses' : []} # copied from any subclass

    nf.parse_inet6_line(words, current_if, ips)

    assert len(current_if['ipv6']) == 1
    address = current_if['ipv6'][0]
    assert address['address'] == 'fe80::1%lo0'
    assert address['prefix'] == '64'
   

# Generated at 2022-06-22 23:49:08.444587
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    # create a new object, and call detect_type_media on it
    test_object = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:49:21.688526
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    a = GenericBsdIfconfigNetwork()
    print('>>> test_GenericBsdIfconfigNetwork_detect_type_media()')


# Generated at 2022-06-22 23:49:32.892990
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module_args = dict(
        config_file='/etc/ansible/roles/ansible-network_facts/tests/files/ifconfig_output_macos_nd6_1',
    )
    # create the FakeModule
    set_module_args(module_args)
    module = FakeModule(**module_args)
    # get the Network instance
    network = GenericBsdIfconfigNetwork(module)

    network._current_if = {}
    network._ips = {}
    words = ['options=8943<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>',
             'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>',
             'media:', 'autoselect', 'status:', 'active']



# Generated at 2022-06-22 23:49:40.350130
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT)']
    current_if = {}

    mgd = GenericBsdIfconfigNetwork()
    mgd.parse_media_line(words, current_if, {})

    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '1000baseT'


# Generated at 2022-06-22 23:49:52.440864
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    network = GenericBsdIfconfigNetwork(None)

    # Test with a tunnel interface
    words = ['tun0', 'tunnel', 'inet', '172.16.1.3', '10.1.1.1', 'netmask', '255.255.255.255', '0x0']
    current_if = {}
    ips = {}
    network.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

    words = ['tun0', 'flags=2d43<UP,POINTOPOINT,RUNNING,NOARP,MULTICAST>', 'mtu', '1492']
    current_if = {}
    ips = {}
    network.parse_tunnel_line(words, current_if, ips)
    assert current

# Generated at 2022-06-22 23:50:05.141143
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    #setup
    defaults = dict(v4={}, v6={})
    route_path = '/sbin/route'

    # run the command
    GenericBsdIfconfigNetwork.get_default_interfaces(route_path, defaults)

    # assert the expected results
    assert defaults['v4']['gateway'] == '192.168.0.1'
    assert defaults['v4']['interface'] == 'en0'
    assert defaults['v4']['address'] == '192.168.0.102'

    assert defaults['v6']['gateway'] == 'fe80::d03e:8f10:ff42:35ea'
    assert defaults['v6']['interface'] == 'en0'

# Generated at 2022-06-22 23:50:11.246778
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = {}
    ips = {}
    network_module = GenericBsdIfconfigNetwork()

    network_module.parse_lladdr_line(['lladdr', '00:11:22:33:44:55'], current_if, ips)

    assert current_if['lladdr'] == '00:11:22:33:44:55'

# Generated at 2022-06-22 23:50:23.965693
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    test_words = [
        'media:',
        'Ethernet',
        'autoselect',
        '(none)',
        'status:',
        'no',
        'carrier'
    ]

    test_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    test_current_if = dict(
        device='lo0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        macaddress='unknown',
        mtu=1234,
        flags=['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
    )

    gb = GenericBsdIfconfigNetwork()


# Generated at 2022-06-22 23:50:34.225827
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    mock_words = [
            "media:", "Ethernet", "autoselect", "(1000baseT)", "status:", "active"
    ]
    iface = {}
    ips = {}
    generic_bsd_ifconfig_network.parse_media_line(mock_words, iface, ips)
    assert iface['media'] == "Ethernet"
    assert iface['media_select'] == "autoselect"
    assert iface['media_type'] == "1000baseT"


# Generated at 2022-06-22 23:50:46.144952
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = AnsibleModule(argument_spec={})
    network_facts = GenericBsdIfconfigNetwork()

    current_if = {}
    ips = { 'all_ipv4_addresses' : [] }

    network_facts.parse_media_line(['media:', 'Ethernet', 'autoselect', '(100baseTX <full-duplex>)'], current_if, ips)

    assert current_if['media'] == 'Ethernet'
    assert current_if['media_select'] == 'autoselect'
    assert current_if['media_type'] == '100baseTX'
    assert current_if['media_options'] == ['full-duplex']


# Generated at 2022-06-22 23:50:47.685987
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    GenericBsdIfconfigNetwork.parse_options_line(['options=123456', '88'], {}, {})


# Generated at 2022-06-22 23:51:00.579295
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    current_if = dict()
    ips = dict()
    words = ['lladdr', 'fe:ed:be:ef:0:1']
    mocker = mocker_factory(mocker_raw_mock_fifo)
    mocker.patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.network.GenericBsdIfconfigNetwork.get_options')
    GenericBsdIfconfigNetwork.parse_lladdr_line(GenericBsdIfconfigNetwork.GenericBsdIfconfigNetwork(module), words, current_if, ips)
    assert current_if['lladdr'] == 'fe:ed:be:ef:0:1'



# Generated at 2022-06-22 23:51:11.735188
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():

    class Args(object):
        def __init__(self, state):
            self.state = state

    class Module(object):
        def __init__(self, args):
            self.args = args
        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])

    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, arg):
            if arg == 'ifconfig':
                return '/sbin/ifconfig'
            return None

        def run_command(self, cmd):
            if self.check_mode:
                raise Exception(cmd)
            if cmd[0] == '/sbin/ifconfig' and cmd[1] == '-a':
                return

# Generated at 2022-06-22 23:51:20.483506
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    class_instance = GenericBsdIfconfigNetwork()
    defaults = {
        "gateway": "fe80::1%lo0",
        "interface": "em0"
    }

# Generated at 2022-06-22 23:51:26.343451
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:51:36.630221
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    from ansible.module_utils.connection import Connection

    def run_command(module, command):
        out = ''
        if command[-1:] == 'default':
            intf = command[-1]

            if command[-1:] == '-inet6':
                out = '''\
interface: em0
gateway: fe80::20c:29ff:fe0b:8d15%em0
'''
            elif command[-2:] == 'get':
                out = '''\
interface: em0
gateway: 192.168.1.1
'''

        return 0, out, ''

    module = Mock()
    module.run_command = run_command
    platform = 'BSD'
    platform_subclass = 'Generic_BSD_Ifconfig'

# Generated at 2022-06-22 23:51:42.924974
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = {}
    current_if['status'] = 'active'
    words = ['status:','no','status','for','this','line']
    network = GenericBsdIfconfigNetwork()
    # check if this line will be ignored
    network.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'active'
    # check if status value is changed
    words = ['status:','up']
    current_if['status'] = 'inactive'
    network.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'up'

# Generated at 2022-06-22 23:51:55.724942
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModuleMock()
    network_info = GenericBsdIfconfigNetwork(module)

    words = ["options=49152<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,JUMBO_HWMOD,VLAN_HWCSUM,TSO4,TSO6,RSS>"]
    current_if = {}

    network_info.parse_options_line(words, current_if, {})

# Generated at 2022-06-22 23:52:05.128989
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:52:17.814153
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork()
    # test case: 1

# Generated at 2022-06-22 23:52:30.463067
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = _mock_module()

    # test word single word
    ifc = GenericBsdIfconfigNetwork(module)
    words = ['options=test']
    current_if = {}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    ifc.parse_options_line(words, current_if, ips)
    assert [current_if['options']] == [['test']]

    # test words list
    words = ['options=test,test2,test3']
    current_if = {}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    ifc.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:52:41.732217
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    # string ether 12:34:56:78:9a:bc in interface info
    # should result in a dictionary item
    # 'macaddress' : '12:34:56:78:9a:bc'
    test = GenericBsdIfconfigNetwork()
    line = 'ether 12:34:56:78:9a:bc'
    words = line.split()
    current_if = {}
    ips = {}
    test.parse_ether_line(words, current_if, ips)
    assert('macaddress' in current_if)
    assert(current_if['macaddress'] == '12:34:56:78:9a:bc')
    assert(ips == {})


# Generated at 2022-06-22 23:52:54.120041
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():

    # setup some mocks to make the tests easier
    class FakeModule:
        def run_command(self, command):
            return 0, '', ''

    # run the actual test
    mod = FakeModule()
    net = GenericBsdIfconfigNetwork(mod)

    net._parse_unknown_line = net.parse_unknown_line
    net.parse_unknown_line = lambda line, current_if, ips: net._parse_unknown_line(line, current_if, ips)
    net._test_known = True
    net.current_if = {}
    net.ips = {}

    # test our empty input case
    net.parse_unknown_line([], net.current_if, net.ips)
    assert not net.current_if
    assert not net.ips

    # it should ignore empty lines

# Generated at 2022-06-22 23:53:02.268469
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    mock_Class = Mock(spec=GenericBsdIfconfigNetwork)


# Generated at 2022-06-22 23:53:15.374305
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    Platform = namedtuple('Platform', 'system release')
    module = FakeModule(
        platform=Platform(system='FreeBSD'),
    )

    gbin = GenericBsdIfconfigNetwork(module)
    assert gbin.get_options('') == []
    assert gbin.get_options('<>') == []
    assert gbin.get_options('<UP>') == ['UP']
    assert gbin.get_options('<UP,RUNNING>') == ['UP', 'RUNNING']
    assert gbin.get_options('<LOOPBACK,RUNNING,MULTICAST>') == ['LOOPBACK', 'RUNNING', 'MULTICAST']

# Generated at 2022-06-22 23:53:20.827900
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    _network = GenericBsdIfconfigNetwork()
    interfaces = dict()
    interfaces['eth0'] = dict()
    interfaces['eth0']['media'] = 'ether'
    expected = dict()
    expected['eth0'] = dict()
    expected['eth0']['media'] = 'ether'
    expected['eth0']['type'] = 'ether'

    _network.detect_type_media(interfaces)
    assert interfaces == expected
    interfaces['eth0']['media'] = 'ETHER'
    expected['eth0']['media'] = 'ETHER'

    _network.detect_type_media(interfaces)
    assert interfaces == expected


# Generated at 2022-06-22 23:53:30.235441
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    gen_bsd_ifconfig_net = GenericBsdIfconfigNetwork()
    if_line_data = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 33184"
    words = if_line_data.split()
    interface_data = gen_bsd_ifconfig_net.parse_interface_line(words)
    assert interface_data['device'] == 'lo0'
    assert 'LOOPBACK' in interface_data['flags']
    assert interface_data['mtu'] == '33184'

# Generated at 2022-06-22 23:53:39.571536
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    with patch(
        'ansible_collections.ansible.community.plugins.modules.network.interfaces.GenericBsdIfconfigNetwork.get_default_interfaces',
        return_value=(dict(), dict()),
    ):
        with patch(
            'ansible_collections.ansible.community.plugins.modules.network.interfaces.GenericBsdIfconfigNetwork.get_interfaces_info',
            return_value=(dict(), dict(all_ipv4_addresses=[], all_ipv6_addresses=[])),
        ):
            module_name = 'ansible_collections.ansible.community.plugins.modules.network.interfaces.GenericBsdIfconfigNetwork'
            module_obj = importlib.import_module(module_name)

# Generated at 2022-06-22 23:53:44.595287
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = AnsibleModule(argument_spec={})

    current_if = {}
    ips = {}
    line = 'status: active'
    words = line.split()

    network = GenericBsdIfconfigNetwork()
    network.parse_status_line(words, current_if, ips)

    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:53:54.015556
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(dict())
    assert generic_bsd_ifconfig_network.parse_interface_line(["lo0:", "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>", "mtu", "33184"]) == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'metric': '33184', 'mtu': '33184', 'macaddress': 'unknown'}

# Generated at 2022-06-22 23:54:02.628166
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.sys_argv = ['setup.py']
    # 'a' added here to remove variable length argument warning
    interfaces, ips = GenericBsdIfconfigNetwork().get_interfaces_info('ifconfig', '-a')
    assert len(interfaces.keys()) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    if socket.has_ipv6:
        assert len(ips['all_ipv6_addresses']) > 0

# Generated at 2022-06-22 23:54:14.000234
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    ifconfig_output_ether = """
em0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
        options=4219b<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,VLAN_HWCSUM,WOL_MAGIC,VLAN_HWTSO,VLAN_HWCSUM_RX,VLAN_HWFILTER>
        ether 00:06:5b:4d:49:bb
        inet 192.168.30.10 netmask 0xffffff00 broadcast 192.168.30.255
        media: Ethernet autoselect (1000baseT <full-duplex>)
        status: active
"""

# Generated at 2022-06-22 23:54:26.851378
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    module = AnsibleModule(argument_spec={})
    generic_bsd_network = GenericBsdIfconfigNetwork(module)
    words = [ 'tunnel', 'inet6', '::1', 'prefixlen', '64', 'tentative', 'nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>', 'id', '0', 'ifscope', 'lo0' ]
    current_if = {'ipv4': [], 'ipv6': []}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    generic_bsd_network.parse_tunnel_line(words, current_if, ips)
    assert current_if['type'] == 'tunnel'

# Generated at 2022-06-22 23:54:31.909918
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    current_if = {}
    ips = {}
    test_input_words = ['status:','active']
    gbi = GenericBsdIfconfigNetwork()
    gbi.parse_status_line(test_input_words, current_if, ips)
    assert current_if['status'] == 'active'


# Generated at 2022-06-22 23:54:44.184592
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    mocker, module = mock_module_helper()
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_options='-a'
    interfaces, ips = GenericBsdIfconfigNetwork.parse_interfaces_info(ifconfig_path, ifconfig_options)
    current_if = interfaces['en0']
    assert current_if['device'] == 'en0'
    assert current_if['flags'] == ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if['metric'] == '0'
    assert current_if['mtu'] == '1500'
    assert current_if['media'] == '10baseT/UTP'

# Generated at 2022-06-22 23:54:57.193062
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    expected_out = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'loopback',
        'flags': [
            'UP',
            'LOOPBACK',
            'RUNNING'
        ],
        'metric': '0',
        'mtu': '32768',
        'options': [],
        'macaddress': 'unknown',
        'status': 'active'
    }
    cmd = ['lo0:',
           'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>',
           'metric 0',
           'mtu 32768',
           'nd6 options=1<PERFORMNUD>']
    out = GenericBsdIfconfigNetwork().parse_interface_line(cmd)


# Generated at 2022-06-22 23:55:01.934460
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = AnsibleModule()
    m.run_command = run_command

    g = GenericBsdIfconfigNetwork(m)

    current_if = {'device': 'lo0'}

    words = ["options=3<RXCSUM,TXCSUM>"]
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    g.parse_options_line(words, current_if, ips)
    assert current_if == {'device': 'lo0', 'options': ['RXCSUM', 'TXCSUM']}



# Generated at 2022-06-22 23:55:14.296268
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = dict(interface='eth0')
    interfaces = dict(eth0=dict(ipv4=[dict(address='192.168.1.1', netmask='255.255.255.0')]))
    network.merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == dict(address='192.168.1.1', netmask='255.255.255.0', interface='eth0'), 'test_GenericBsdIfconfigNetwork_merge_default_interface 2 failed'
    defaults = dict(interface='eth0', ipv4=[])
    interfaces = dict(eth0=dict(ipv4=[dict(address='192.168.1.1', netmask='255.255.255.0')]))
    network.merge_default_

# Generated at 2022-06-22 23:55:27.595817
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec=dict())
    # mocker.patch.object(custom_module.CustomModule, 'run_command')
    # mocker.patch.object(custom_module.CustomModule, 'run_command', return_value = (0, 'the result', 'error output'))
    # assert module.run_command == mocker.call('any arguments')

# Generated at 2022-06-22 23:55:39.166674
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():

    # TODO: if the test_GenericBSDIfconfigNetwork is ever promoted to
    # an actual test, this test should be moved there.

    # Test data derived from FreeBSD 10.x
    words_1 = [
        'inet6',
        'fe80::ac0f:2dff:fe51:99cb%em0',
        'prefixlen',
        '64',
        'scopeid',
        '0x9',
        '',
    ]
    current_if_1 = {'ipv6': []}
    ips_1 = {'all_ipv6_addresses': []}
    gb_1 = GenericBsdIfconfigNetwork({})

    # Test data derived from NetBSD 5.x

# Generated at 2022-06-22 23:55:44.532664
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    network = GenericBsdIfconfigNetwork()
    current_if1 = network.parse_interface_line(['ath0:', 'flags=', '8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST>', 'metric',
                                                '0', 'mtu', '1500'])
    assert current_if1['device'] == 'ath0'
    assert current_if1['flags'] == ['UP', 'BROADCAST', 'RUNNING', 'SIMPLEX', 'MULTICAST']
    assert current_if1['mtu'] == '1500'
    assert current_if1['metric'] == '0'
