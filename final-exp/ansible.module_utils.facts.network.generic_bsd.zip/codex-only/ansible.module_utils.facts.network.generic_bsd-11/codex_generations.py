

# Generated at 2022-06-22 23:45:52.030970
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    class MockModule(object):
        @staticmethod
        def run_command(args):

            if args == ['route', '-n', 'get', 'default']:
                return (0, 'interface: en0\ngateway: x.x.x.x\nflags: <UP,GATEWAY,DONE,STATIC,PRCLONING>\nrecvpipe  sendpipe  ssthresh  rtt,msec    rttvar  hopcount      mtu     expire\n0         0         0         0           0       0             0       0\n\n', '')

# Generated at 2022-06-22 23:46:03.787802
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    #ipv4 address with cidr style
    words0 = ['lo0', 'inactive', 'mtu', '33184', 'inet', '127.0.0.1/24' 'netmask', '0xffffff00', 'broadcast', '127.255.255.255']
    current_if0 = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips0 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    gbn = GenericBsdIfconfigNetwork()
    gbn.parse_inet_line(words0, current_if0, ips0)

# Generated at 2022-06-22 23:46:11.691046
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    ifc = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    ifc.parse_nd6_line(['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'], current_if, ips)
    assert current_if == {'options': ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']}
    assert ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}



# Generated at 2022-06-22 23:46:22.873927
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    text = "bge0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500  " + \
        "options=9<RXCSUM,VLAN_MTU>  ether 00:24:8c:e8:fd:ec  " + \
        "nd6 options=1<PERFORMNUD>  media: Ethernet autoselect (100baseTX <full-duplex>)"
    words = text.split()

    current_if = {}
    ips = {}

    iface = GenericBsdIfconfigNetwork()
    iface.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == "00:24:8c:e8:fd:ec"

# Generated at 2022-06-22 23:46:32.113213
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    module = MockModule()
    network = GenericBsdIfconfigNetwork(module)

    # Simple media input
    words = ["media:", "Ethernet", "autoselect", "(1000baseT)", "status:", "active"]
    current_if = {}

    network.parse_media_line(words, current_if, {})
    assert current_if['media'] == "Ethernet"
    assert current_if['media_select'] == "autoselect"
    assert current_if['media_type'] == "(1000baseT)"

    # More complex media input
    words = ["media:", "Ethernet", "autoselect", "(1000baseT)", "status:", "active", "mediaopt:"]
    current_if = {}

    network.parse_media_line(words, current_if, {})

# Generated at 2022-06-22 23:46:37.880410
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    gbif = GenericBsdIfconfigNetwork()
    words = ['mtu', '1500']
    current_if = {}
    ips = {}
    gbif.parse_unknown_line(words, current_if, ips)
    expected = {'mtu': '1500'}
    assert current_if == expected

# Generated at 2022-06-22 23:46:47.342225
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = Mock()
    class_inst = GenericBsdIfconfigNetwork(module)

    # FreeBSD, NetBSD and OpenBSD
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'group', 'default']
    current_if = {
        'device': 'lo0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'],
        'macaddress': 'unknown',
        'mtu': '33184',
    }
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    class_inst.parse_inet_line

# Generated at 2022-06-22 23:46:55.253872
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    instance = GenericBsdIfconfigNetwork(module)
    expected = []
    actual = instance.parse_options_line(['options=8943<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU,VLAN_HWCSUM,TSO4,TSO6,LRO,VLAN_HWTSO>', 'mtu', '1500', 'ether', '00:03:93:d5:b2:98', 'inet6', 'fe80::203:93ff:fed5:b298%lo0', 'prefixlen', '64', 'scopeid', '0x2'])
    assert expected == actual


# Generated at 2022-06-22 23:47:08.532895
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    import sys
    import pytest
    from collections import OrderedDict
    
    gb = GenericBsdIfconfigNetwork()
    interfaces = OrderedDict()
    
    interfaces['en0'] = {'flags': ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'], 'type': 'unknown', 'device': 'en0', 'macaddress': 'e8:03:9a:dd:d6:40', 'mtu': '1500', 'media': 'ieee80211', 'media_select': 'IEEE 802.11 (autoselect)', 'media_type': 'autoselect (autoselect)', 'media_options': ['mode', '11b', 'ieee80211', 'power']}

# Generated at 2022-06-22 23:47:20.443561
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # IPv4 address with its netmask and broadcast address
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000', 'broadcast', '127.0.0.1']
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    inet4_obj = GenericBsdIfconfigNetwork()
    inet4_obj.parse_inet_line(words, current_if, ips)
    assert current_if['type'] == 'loopback'
    assert current_if['device'] == 'lo0'

# Generated at 2022-06-22 23:47:30.854240
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:47:43.510410
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    import pprint
    from ansible.module_utils.network.freebsd import GenericBsdIfconfigNetwork

    ifconfig_output ="""wm0: flags=8843<UP,BROADCAST,RUNNING,SIMPLEX,MULTICAST> metric 0 mtu 1500
    options=18<VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU>
        ether 00:15:5d:e0:6b:e7
        nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>
    media: Ethernet autoselect (1000baseT <full-duplex>)
    status: active"""

    interfaces = GenericBsdIfconfigNetwork.get_interfaces_info(ifconfig_path=None, ifconfig_options='-a')[0]
    GenericBsd

# Generated at 2022-06-22 23:47:56.568453
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    mock_current_if = { 'ipv4': [], 'ipv6': [], 'type': 'unknown' }
    # Test 1 - Valid, success
    ips = dict( all_ipv4_addresses = [], all_ipv6_addresses = [] )
    testobj = GenericBsdIfconfigNetwork(module=None)
    testobj.parse_nd6_line(['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL'], mock_current_if, ips)
    assert mock_current_if['options'] == ['PERFORMNUD', 'ACCEPT_RTADV', 'AUTO_LINKLOCAL']
    assert ips == dict( all_ipv4_addresses = [], all_ipv6_addresses = [] )

# Generated at 2022-06-22 23:48:01.388448
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    mod = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = GenericBsdIfconfigNetwork(module=mod)

    iface = {'device': 'lo0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    
    ## In FreeBSD
    iface['device'] = 'lo0'
    words = ['options=', '3<RXCSUM,TXCSUM,VLAN_MTU,VLAN_HWTAGGING,JUMBO_MTU>', 'metric', '0', 'mtu', '16384']
    network.parse_options_line(words, iface, ips)

# Generated at 2022-06-22 23:48:05.706051
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    """
    This method test the parse_options_line method of GenericBsdIfconfigNetwork class
    """
    facts = GenericBsdIfconfigNetwork()

    # Mac has options like this...
    words = ['options=3<RXCSUM,TXCSUM,VLAN_MTU>']
    current_if = {'ipv4': [], 'ipv6': []}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    facts.parse_options_line(words, current_if, ips)
    assert current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU']


# Generated at 2022-06-22 23:48:15.812622
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Arrange
    current_if = dict(
        device='lo0',
        ipv4=[],
        ipv6=[],
        type='unknown',
        status='',
        macaddress='unknown',
        mtu=''
    )
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['status:', 'active']
    gen_ifconfig_net = GenericBsdIfconfigNetwork()
    # Act
    gen_ifconfig_net.parse_status_line(words, current_if, ips)
    # Assert
    assert current_if['status'] == 'active'

# Generated at 2022-06-22 23:48:28.376013
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    """
    Test function parse_inet6_line of class GenericBsdIfconfigNetwork
    """

# Generated at 2022-06-22 23:48:40.617130
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    data = {}

# Generated at 2022-06-22 23:48:54.032290
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    from collections import namedtuple
    MockNetworkModule = namedtuple('MockNetworkModule', ['run_command'])
    MockArgs = namedtuple('MockArgs', ['ifconfig_path'])

    module = MockNetworkModule(run_command=lambda x, y: (0, "", ""))
    args = MockArgs(ifconfig_path=None)
    gen = GenericBsdIfconfigNetwork(module, args)

    words = ["wlp0s20f3", "ether", "bc:54:36:1c:72:e2", "media:", "IEEE", "802.11", "Wireless", "Ethernet", "autoselect", "mode", "11n", "(HT", "mixed)", "status:", "associated"]
    current_if = gen.parse_interface_line(words)
    gen

# Generated at 2022-06-22 23:49:06.807046
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    ifconfig_net = GenericBsdIfconfigNetwork()
    current_if = {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
            all_ipv4_addresses=[],
            all_ipv6_addresses=[],
        )
    # Test with MAC Address which should be assigned to macaddress
    words = ['ether', '00:11:22:33:44:55']
    ifconfig_net.parse_ether_line(words, current_if, ips)
    assert '00:11:22:33:44:55' == current_if['macaddress']
    assert 'ether' == current_if['type']



# Generated at 2022-06-22 23:49:19.374320
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():

    platform_mock = MagicMock(spec=GenericBsdIfconfigNetwork)

    platform_mock.get_options.return_value = 'MULTICAST UP LOOPBACK'

    line = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384'
    words = line.split()
    current_if = platform_mock.parse_interface_line(words)
    platform_mock.parse_options_line(words, current_if, {})

    platform_mock.get_options.return_value = 'MULTICAST'

    line = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> mtu 16384'
    words = line.split()
    current_if = platform_mock.parse

# Generated at 2022-06-22 23:49:27.378190
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    args = dict()
    module = AnsibleModule(**args)
    mod = GenericBsdIfconfigNetwork(module)
    v4_out = 'default: gateway 127.0.0.1'
    v6_out = 'default: gateway ::1'
    args = dict()
    v4, v6 = mod.get_default_interfaces(None, v4_out, v6_out)
    assert v4['gateway'] == '127.0.0.1'
    assert v6['gateway'] == '::1'



# Generated at 2022-06-22 23:49:39.479509
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    # create a mock module
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = ''

    # create an instance of GenericBsdIfconfigNetwork
    interface_info = GenericBsdIfconfigNetwork(mock_module)

    # create a mock interface
    mock_interface = {}

    # This is the line we are testing
    interface_info.parse_lladdr_line(['lladdr', 'bb:bb:bb:bb:bb:bb'], mock_interface, {})
    mock_interface['lladdr'].should.equal('bb:bb:bb:bb:bb:bb')

if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-22 23:49:45.794574
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    GENERIC_BSD_IFCONFIG_NETWORK = GenericBsdIfconfigNetwork()

    assert GENERIC_BSD_IFCONFIG_NETWORK.get_options('<UP,BROADCAST,RUNNING,PROMISC,SIMPLEX,MULTICAST>') == ['UP', 'BROADCAST', 'RUNNING', 'PROMISC', 'SIMPLEX', 'MULTICAST']

# Generated at 2022-06-22 23:49:58.426061
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModule({})
    n = GenericBsdIfconfigNetwork(module)

    # test with cidr style addresses, ala NetBSD ifconfig post 7.1
    line = ['inet6', 'dead::beef:dead:beef:dead/64', 'prefixlen', '64', 'scopeid', '0x1']
    current_if = {'ipv6': []}
    expected = {'address': 'dead::beef:dead:beef:dead', 'prefix': '64', 'scope': '0x1'}
    n.parse_inet6_line(line, current_if, {})

    assert len(current_if['ipv6']) == 1
    assert current_if['ipv6'][0] == expected
    current_if = {'ipv6': []}

    #

# Generated at 2022-06-22 23:50:11.101046
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    net_default_if = dict(v4={'interface': 'lo0'}, v6={'interface': 'lo0'})

# Generated at 2022-06-22 23:50:17.265366
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    test_obj = GenericBsdIfconfigNetwork()

    # TODO: Test fails
    #words = ['tunnel', 'inet', '10.0.0.10', '-->', '10.0.0.1', 'netmask', '0xffffffff']
    #test_obj.parse_tunnel_line(words, current_if, ips)

    return


# Generated at 2022-06-22 23:50:30.296806
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    dummy_self = None
    assert ['LOOPBACK', 'RUNNING', 'MULTICAST'] == GenericBsdIfconfigNetwork.get_options(dummy_self, '<LOOPBACK,RUNNING,MULTICAST>')
    assert ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST'] == GenericBsdIfconfigNetwork.get_options(dummy_self, '<UP,BROADCAST,SIMPLEX,MULTICAST>')
    assert ['UP', 'BROADCAST', 'SIMPLEX', 'MULTICAST'] == GenericBsdIfconfigNetwork.get_options(dummy_self, '<UP,BROADCAST,SIMPLEX,MULTICAST,IPv4>')

# Generated at 2022-06-22 23:50:43.046755
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():

    # simple test
    test_parse_interface_line_1 = dict(
        words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'metric', '0', 'mtu', '33184'],
        result = dict(
            device='lo0',
            metric='0',
            mtu='33184',
            flags='UP,LOOPBACK,RUNNING,MULTICAST',
            type='loopback',
            macaddress='unknown')
        )

    # test with alias

# Generated at 2022-06-22 23:50:50.625249
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    my_module = AnsibleModule({})
    network = GenericBsdIfconfigNetwork()

    result = dict(device='lo0')

    my_module.run_command = MagicMock(return_value=(0, "", ""))
    words = ['test_device', 'options=3']

    network.parse_options_line(words, result, dict())
    assert result['options'] == ['3']

    words = ['test_device', 'options=3<RUNNING,NOARP,NOALIAS>']

    network.parse_options_line(words, result, dict())
    assert result['options'] == ['3', 'RUNNING', 'NOARP', 'NOALIAS']


# Generated at 2022-06-22 23:51:03.286731
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    interfaces = {
        'lo0': {
            'media': '<Loopback>',
            'type': 'unknown'
        },
        'em1': {
            'media': 'Ethernet autoselect (none)',
            'type': 'unknown'
        },
        'em2': {
            'media': 'Ethernet autoselect (1000baseT)',
            'type': 'unknown'
        }
    }

# Generated at 2022-06-22 23:51:09.842121
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():

    # Create a instance of GenericBsdIfconfigNetwork class
    net = GenericBsdIfconfigNetwork()
    # call the method parse_tunnel_line
    net.parse_tunnel_line(['tunnel', 'inet', '10.1.1.1', '-->', '10.2.2.2', 'netmask', '0xffffff00'], {}, {})


# Generated at 2022-06-22 23:51:19.506024
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    module = MockAnsibleModule()
    module.exit_json = MockAnsibleModule.exit_json
    module.fail_json = MockAnsibleModule.fail_json
    obj = GenericBsdIfconfigNetwork(module)
    current_if = {}
    ips = {"all_ipv6_addresses":[]}
    words = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>', 'media:', 'Ethernet',
             'autoselect', '(1000baseT)', 'status:','active']
    obj.parse_nd6_line(words, current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'AUTO_LINKLOCAL']
    assert current_if['media'] == 'Ethernet'
    assert current_

# Generated at 2022-06-22 23:51:31.757289
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(module=True)
    option = "<LOOPBACK,MULTICAST>"
    assert generic_bsd_ifconfig_network.get_options(option) == ['LOOPBACK', 'MULTICAST']
    option = "LOOPBACK,MULTICAST"
    assert generic_bsd_ifconfig_network.get_options(option) == ['LOOPBACK', 'MULTICAST']
    option = "LOOPBACK,MULTICAST,"
    assert generic_bsd_ifconfig_network.get_options(option) == ['LOOPBACK', 'MULTICAST']
    option = "LOOPBACKMULTICAST"
    assert generic_bsd_ifconfig_network.get_options(option) == []

# Generated at 2022-06-22 23:51:35.652845
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    n = GenericBsdIfconfigNetwork()
    current_if = {}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    n.parse_lladdr_line(['lladdr', '00:0c:29:b9:9b:69'], current_if, ips)
    assert current_if['lladdr'] == '00:0c:29:b9:9b:69'


# Generated at 2022-06-22 23:51:41.506422
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    """Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork"""

    output = ['lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384',
              '    options=3<RXCSUM,TXCSUM>',
              '    inet 127.0.0.1 netmask 0xff000000',
              '    inet6 ::1 prefixlen 128',
              '    inet6 fe80::1%lo0 prefixlen 64 scopeid 0x1',
              '    nd6 options=21<PERFORMNUD,AUTO_LINKLOCAL>',
              'gif0: flags=8010<POINTOPOINT,MULTICAST> metric 0 mtu 1280',
              'stf0: flags=0<> metric 0 mtu 1280']

# Generated at 2022-06-22 23:51:47.400312
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # Test normal operation
    test_if = {'device': 'lo0',
               'ipv4': [],
               'ipv6': [],
               'type': 'unknown'}

    words = ['accesspoint0', 'nd6:', 'flags=21<PERFORMNUD,AUTO_LINKLOCAL>']
    expected_if = {'device': 'lo0',
                   'ipv4': [],
                   'ipv6': [],
                   'type': 'unknown',
                   'options': ['PERFORMNUD', 'AUTO_LINKLOCAL']}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    gni = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:52:00.344879
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    """
    test_GenericBsdIfconfigNetwork_get_interfaces_info tests the get_interfaces_info method of the
    GenericBsdIfconfigNetwork class
    """
    module = AnsibleModule(argument_spec={})
    module.params = {'paths': {'ifconfig': 'ifconfig'}}
    ifconfig_network = GenericBsdIfconfigNetwork(module)
    ifconfig_data = test_data.get('ifconfig', dict())
    (interfaces, ips) = ifconfig_network.get_interfaces_info(
        ifconfig_data.get('path', 'ifconfig'), ifconfig_data.get('options', None))

    assert interfaces == ifconfig_data.get('interfaces', dict())
    assert ips == ifconfig_data.get('ips', dict())



# Generated at 2022-06-22 23:52:07.256027
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = GenericBsdIfconfigNetwork(module)
    out = (
        b'default\t192.0.2.1\tUGS\t0\t4501\t\te1000g0\n',
        b'default\tfe80::%e1000g0\tUGL\t0\t4501\t\te1000g0\n',
    )
    route_path = '/usr/sbin/route'
    command = dict(v4=[route_path, '-n', 'get', 'default'], v6=[route_path, '-n', 'get', '-inet6', 'default'])

# Generated at 2022-06-22 23:52:13.847564
# Unit test for method parse_ether_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_ether_line():
    testobj = GenericBsdIfconfigNetwork()
    current_if = dict()
    ips = dict()
    words = ['ether', '18:03:73:14:53:27']

    testobj.parse_ether_line(words, current_if, ips)

    assert current_if['macaddress'] == '18:03:73:14:53:27'


# Generated at 2022-06-22 23:52:19.967337
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    # Arrange
    words = ['status:', 'active']

    # Act
    current_if = dict()
    network_object = GenericBsdIfconfigNetwork()
    network_object.parse_status_line(words, current_if, 'ips')

    # Assert
    if current_if['status'] != 'active':
        assert False



# Generated at 2022-06-22 23:52:28.059922
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
  option_string = '<UP,BROADCAST,RUNNING,SMART,RUNNING,SIMPLEX,MULTICAST>'
  module = AnsibleModule(argument_spec=dict())
  network = GenericBsdIfconfigNetwork(module)
  returned = network.get_options(option_string)
  assert returned == ['UP', 'BROADCAST', 'RUNNING', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST']


# Generated at 2022-06-22 23:52:32.237205
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    iface = dict(device='lo0', ipv4=[], ipv6=[], type='unknown')
    ip_type = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    GenericBsdIfconfigNetwork.parse_options_line(['options=3<RXCSUM,TXCSUM>'], iface, ip_type)
    assert iface['options'] == ['RXCSUM', 'TXCSUM']


# Generated at 2022-06-22 23:52:42.463498
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict()
    )
    result = dict()
    result['interfaces'] = 'ifconfig -a'
    result['ipv4'] = 'route -n get default'
    result['ipv6'] = 'route -n get -inet6 default'
    ifaces = GenericBsdIfconfigNetwork(module)
    interfaces, ips = ifaces.get_interfaces_info(ifaces['interfaces'])
    print("Dumping interfaces ...")
    pprint(interfaces)

    print("Dumping ips ...")
    pprint(ips)


# Generated at 2022-06-22 23:52:54.728089
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
  network = GenericBsdIfconfigNetwork()
  words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
  current_if = {}
  ips = dict(
      all_ipv4_addresses=[],
      all_ipv6_addresses=[],
  )
  network.parse_inet_line(words, current_if, ips)
  assert current_if['ipv4'][0]['address'] == '127.0.0.1'
  assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
  assert current_if['ipv4'][0]['network'] == '127.0.0.0'
  assert current_if['ipv4'][0]['broadcast']

# Generated at 2022-06-22 23:52:57.339609
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    # Test parse_inet6_line of class GenericBsdIfconfigNetwork
    #
    # Setup fixture
    # module = None
    #
    # Exercise
    #
    # Verify
    #
    # Teardown
    pass


# Generated at 2022-06-22 23:53:04.664979
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = {
        'interface': 'lo0',
        'address': '127.0.0.1',
        'netmask': '255.0.0.0'
    }
    interfaces = {
        'lo0': {
            'ipv4': [{
                'address': '127.0.0.1',
                'netmask': '255.0.0.0'
            }, {
                'address': '127.0.0.2',
                'netmask': '255.0.0.0'
            }]
        }
    }
    assert network.merge_default_interface(defaults, interfaces, 'ipv4') == None

# Generated at 2022-06-22 23:53:15.408825
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule(argument_spec=dict())

    lines = ("", "foobar", "inet 127.0.0.1 netmask 0xff000000", "inet alias 127.1.1.1 netmask 0xff000000",
             "inet 10.0.0.1 netmask 0xffffff00 broadcast 10.0.0.255")
    for line in lines:
        words = line.split()
        interfaces = {}
        current_if = {}
        network_plugin = GenericBsdIfconfigNetwork()
        network_plugin.parse_inet_line(words, interfaces, current_if)


# Generated at 2022-06-22 23:53:26.594769
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Case 1: one ipv4 address
    words1 = ["lo0:",
              "flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>",
              "metric=0",
              "mtu=33184",
              "inet=127.0.0.1",
              "netmask=0xff000000",
              "inet6=::1%1/128",
              "inet6=fe80::1%lo0/64",
              "groups=lo"]
    network = GenericBsdIfconfigNetwork()
    current_if = network.parse_interface_line(words1)
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

# Generated at 2022-06-22 23:53:37.429557
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    module = AnsibleModule({})
    mock_object = GenericBsdIfconfigNetwork(module)
    ipv4_addr_list = ['127.0.0.1', '192.168.122.11']
    current_if = {
        'device': 'eth0',
        'ipv4': [],
        'ipv6': [],
        'type': 'unknown',
        'flags': [],
        'macaddress': 'unknown',
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

# Generated at 2022-06-22 23:53:48.966561
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    route_path = '/sbin/route'

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    g = GenericBsdIfconfigNetwork()

    # testing with a fake route command
    # csh interface has a different format than posix shells
    # test for csh
    fake_route_path = os.path.join(os.path.dirname(__file__), 'vars', 'fake_route_csh')
    rc, out, err = module.run_command([fake_route_path, '-n', 'get', '-inet6', 'default'])
    assert rc == 0
    default_ipv4, default_ipv6 = g.get_default_interfaces(route_path)
    assert default_ipv4 == {} and default_

# Generated at 2022-06-22 23:54:01.046847
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    # Setup
    class GenericBsdIfconfigNetworkMock(GenericBsdIfconfigNetwork):
        def __init__(self):
            pass

    network_obj = GenericBsdIfconfigNetworkMock()
    expected_v4_gateway = '10.3.3.3'
    expected_v4_interface = 'eth0'
    expected_v4_address = '10.3.3.200'
    expected_v6_gateway = 'fe80::1%eth0'
    expected_v6_interface = 'eth0'
    expected_v6_address = 'fe80::2'

    # set up responses for route

# Generated at 2022-06-22 23:54:03.000760
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    facts = GenericBsdIfconfigNetwork().populate()


# Generated at 2022-06-22 23:54:06.250196
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    i = GenericBsdIfconfigNetwork()
    words = ['group', 'name', '50']
    words_exp = ['group', 'name', '50']
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    i.parse_unknown_line(words, current_if, ips)
    assert words == words_exp


# Generated at 2022-06-22 23:54:12.440956
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()
    interfaces = {'lo0': {'media': 'Ethernet autoselect (1000baseT full-duplex,master)'}}
    actual = network.detect_type_media(interfaces)
    expect = {'lo0': {'media': 'Ethernet autoselect (1000baseT full-duplex,master)', 'type': 'ether'}}
    assert actual == expect


# Generated at 2022-06-22 23:54:23.622415
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    ifconfig_path = module.get_bin_path('ifconfig')
    ifconfig_output=_ifconfig_output()

    # PR #29477 - Use mock and friends to test this interface

# Generated at 2022-06-22 23:54:35.332840
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    network = GenericBsdIfconfigNetwork()
    # Parse a line from FreeBSD ifconfig -a output
    line = 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384'
    words = line.split()
    iface = network.parse_interface_line(words)
    assert iface == {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback',
                     'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'metric': '0',
                     'mtu': '16384', 'macaddress': 'unknown'}

    # Parse a line from FreeBSD ifconfig -a output with MAC Address

# Generated at 2022-06-22 23:54:48.772810
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # ARRANGE
    fake_ifconfig_network = GenericBsdIfconfigNetwork(None)
    current_if = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    words = ['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>', 'metric 0', 'mtu 65535', 'options=3<RXCSUM,TXCSUM>']

# Generated at 2022-06-22 23:55:01.513726
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    netinfo = GenericBsdIfconfigNetwork(None)
    defaults = {'interface': 'em0'}
    interfaces = {'em0': {'ipv4': [{'address': '192.168.1.1'}], 'ipv6': [], 'mtu': '1500', 'type': 'ether',
                          'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'], 'device': 'em0', 'macaddress': 'xx:xx:xx:xx:xx:xx'}}
    (netinfo.merge_default_interface(defaults, interfaces, 'ipv4'))

# Generated at 2022-06-22 23:55:12.369052
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    #  test for method parse_unknown_line of class GenericBsdIfconfigNetwork
    # if we cannot find a class to handle the platform,
    # we fallback to the Generic_BSD_Ifconfig network
    # so there must be a unit test for it.
    module = generic_ansible_module.AnsibleModule([])
    network_module = GenericBsdIfconfigNetwork()
    network_module.parse_unknown_line(["up", "mtu", "1500", "inet", "10.0.0.1", "netmask", "0xffffff00", "broadcast", "10.0.0.2"], {}, {})
    assert(True)



# Generated at 2022-06-22 23:55:22.333340
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    _module = AnsibleModule({})
    _network = GenericBsdIfconfigNetwork(_module)
    _current_if = {}
    _words = 'nd6 options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'.split(' ')
    _network.parse_nd6_line(_words, _current_if, {})

    assert _current_if == {
        'options': ['PERFORMNUD', 'IFDISABLED', 'AUTO_LINKLOCAL']
    }

# Generated at 2022-06-22 23:55:28.852832
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    net_module = GenericBsdIfconfigNetwork
    import platform
    net_module.platform = platform.system()
    test_module = net_module()
    test_module.module.run_command = lambda x,*args,**kwargs: (0,'','','','','','','')
    test_module.module.get_bin_path = lambda x,*args,**kwargs: '/usr/bin/' + x
    test_result = test_module.populate(collected_facts={})
    assert test_result

# Generated at 2022-06-22 23:55:40.352452
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils._text import to_bytes
    import sys

    klass = GenericBsdIfconfigNetwork
    print('1', '-' * 60, sep='\n')
    print('Running tests for class {}'.format(klass.__name__))

    # Try to use the argument parser ...
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--collect-only', action='store_true', dest='collect_only',
                        help='Only collect facts, do not apply any configuration')
    parser.add_argument('--module-path', action='store', dest='module_path',
                        help='Module search path(colon separated)')
    args, unknown_args = parser.parse_known_args()
    module_args = {}

# Generated at 2022-06-22 23:55:50.819972
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
    TODO: Currently, this unit test uses the following route command output
    as input to the function to be tested. The test can only be run on
    Ansible development system, as the given output is specific to such a
    system. Please check and revise the output to use the output of the
    route command on the system, where this test is intended to run.
    '''
    route_path = ''
    if platform.system() == 'Darwin':
        route_path = '/sbin/route'
    elif platform.system() == 'FreeBSD':
        route_path = '/sbin/route'
    elif platform.system() == 'OpenBSD':
        route_path = '/sbin/route'