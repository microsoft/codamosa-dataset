

# Generated at 2022-06-22 23:45:45.427468
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():

    GenericBsdIfconfigNetwork.get_default_interfaces(route_path)


# Generated at 2022-06-22 23:45:48.163166
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():
    gbifnet = GenericBsdIfconfigNetwork()
    assert gbifnet.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-22 23:46:00.618399
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    class FakeModule(object):
        def __init__(self):
            pass
        def get_bin_path(self, path, required=True, opt_dirs=[]):
            return 'ifconfig'
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            if args[0] == 'ifconfig':
                return 0, 'lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384' \
                          'media: Ethernet autoselect (1000baseT <full-duplex>)' \
                          'status: active', ''
            if args[0] == 'route':
                return 0, '', ''

    fake_module = FakeModule()

    fact

# Generated at 2022-06-22 23:46:10.785433
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():

    class MockedNetworkModule(object):
        def run_command(self, args):
            cmd = args[0]
            if cmd == route_path:
                if args[-1] == 'default':
                    return 0, route_v4, ''
                elif args[-2] == '-inet6' and args[-1] == 'default':
                    return 0, route_v6, ''
                else:
                    assert False
            elif cmd == ifconfig_path:
                return 0, ifconfig, ''
            else:
                assert False

        def get_bin_path(self, name):
            return name

    # Data
    ifconfig_path = 'ifconfig'
    route_path = 'route'

# Generated at 2022-06-22 23:46:19.329813
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    module = get_module_mock()
    m = GenericBsdIfconfigNetwork(module)
    current_if = {}
    words = ['status:', 'active']
    # test with status: active
    m.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'active'
    # test with status: not associated
    words[1] = 'not associated'
    m.parse_status_line(words, current_if, {})
    assert current_if['status'] == 'not associated'

# Generated at 2022-06-22 23:46:29.665248
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    net = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:46:42.007828
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    print('Testing method parse_nd6_line of class GenericBsdIfconfigNetwork')
    # Initialize the class
    generic_bsd_ifconfig_network = network.GenericBsdIfconfigNetwork()
    # Create the arguments to use
    current_if = {'device': 'lo0'}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    words = ['nd6', 'options=21<PERFORMNUD,AUTO_LINKLOCAL>']
    # Execute the test
    generic_bsd_ifconfig_network.parse_nd6_line(words, current_if, ips)
    # Verify the results
    assert current_if['options'] == ['PERFORMNUD', 'AUTO_LINKLOCAL']



# Generated at 2022-06-22 23:46:49.559530
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common import utils
    from ansible.module_utils.network.generic_bsd_ifconfig.network import GenericBsdIfconfigNetwork

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )

    # Return an empty fact dict
    module.exit_json(ansible_facts=dict(network=dict()))


# Generated at 2022-06-22 23:46:56.867221
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    fact = GenericBsdIfconfigNetwork()
    current_if = {'device': 'em0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    # Testing with IPv6 address
    words = ['lladdr', 'fe80:1:2:3:4:5:6:7']
    fact.parse_lladdr_line(words, current_if, ips={})
    assert current_if['lladdr'] == 'fe80:1:2:3:4:5:6:7'
    # Testing with IPv4 address
    words = ['lladdr', '1.2.3.4']
    fact.parse_lladdr_line(words, current_if, ips={})
    assert current_if['lladdr'] == '1.2.3.4'
    # Testing

# Generated at 2022-06-22 23:47:10.052419
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    facts = GenericBsdIfconfigNetwork()

    interfaces, ips = facts.get_interfaces_info('/sbin/ifconfig', '-a')

    assert len(interfaces) == 2
    assert 'lo0' in interfaces
    assert len(interfaces['lo0']['ipv4']) == 2

# Generated at 2022-06-22 23:47:23.316949
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    network = GenericBsdIfconfigNetwork()
    out = network.detect_type_media({'eth1': {'device': 'eth1', 'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'], 'mtu': '1500', 'macaddress': '08:00:27:1a:d8:f6', 'media': 'Ethernet autoselect', 'media_select': '(none)', 'media_type': '(none)', 'status': 'active', 'type': 'unknown'}})

# Generated at 2022-06-22 23:47:31.719403
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():
    net = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:47:36.678264
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    generic_bsd = GenericBsdIfconfigNetwork(None)

    # TODO: fix this test - it needs mock.patch to work now
    # with open('test_GenericBsdIfconfigNetwork.txt') as f:
    #     output = f.read()
    #
    # ix = output.index('route get -inet6 default')
    # route_cmd = output[ix:].split('\n')
    # rc, out, err = generic_bsd.module.run_command(route_cmd)
    # assert out == '''\
    #  default:
    #  interface: gif0
    #  gateway: ::
    # '''
    # if out == '''\
    #  default:
    #  interface: gif0
    #  gateway: ::
    # ''':
    #    

# Generated at 2022-06-22 23:47:43.451483
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    m = GenericBsdIfconfigNetwork()


# Generated at 2022-06-22 23:47:56.512937
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    module = FakeModule()
    instance = GenericBsdIfconfigNetwork(module)
    defaults = dict()
    defaults['interface'] = 'lo0' #interface that exists
    interfaces = dict()
    interfaces['lo0'] = dict()
    interfaces['lo0']['ipv4'] = [dict()]
    interfaces['lo0']['ipv6'] = [dict()]
    interfaces['lo0']['alldata'] = 'doesnotmatter'
    interfaces['lo0']['ipv4'][0]['address'] = '::1' #not a real address
    interfaces['lo0']['ipv6'][0]['address'] = 'fe80::1%lo0' #real address

# Generated at 2022-06-22 23:48:01.322696
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    test_subject = GenericBsdIfconfigNetwork()

    current_if = {}
    ips = {}
    # test hex netmask
    words = ['inet', '10.1.1.1', 'netmask', '0xffff0000', 'broadcast', '10.1.255.255']
    test_subject.parse_inet_line(words, current_if, ips)

    test_result = {'device': '', 'ipv4': [{'address': '10.1.1.1', 'netmask': '255.255.0.0', 'network': '10.1.0.0', 'broadcast': '10.1.255.255'}], 'ipv6': [], 'type': 'unknown', 'flags': [], 'macaddress': 'unknown', 'mtu': ''}

    assert current_

# Generated at 2022-06-22 23:48:06.143062
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    gni = GenericBsdIfconfigNetwork()

    interfaces = {}
    expected_interfaces = {}
    interfaces['interface0'] = {'media': 'Ethernet', 'type': 'unknown'}
    interfaces['interface1'] = {'media': 'Ethernet', 'type': 'ether'}
    interfaces['interface2'] = {'media': 'UNKNOWN', 'type': 'unknown'}

    expected_interfaces['interface0'] = {'media': 'Ethernet', 'type': 'ether'}
    expected_interfaces['interface1'] = {'media': 'Ethernet', 'type': 'ether'}
    expected_interfaces['interface2'] = {'media': 'UNKNOWN', 'type': 'unknown'}

    assert gni.detect_type_media(interfaces) == expected_interfaces

# Generated at 2022-06-22 23:48:09.985856
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    n = GenericBsdIfconfigNetwork()
    words = ['0;0;0', 'some', 'state', 'info']
    assert words == n.parse_unknown_line(words[:], {}, {})

# Generated at 2022-06-22 23:48:22.377021
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    nm = GenericBsdIfconfigNetwork()

    interfaces = {'eth0': {'device': 'eth0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [],
                           'macaddress': 'unknown', 'mtu': '1500', 'media': 'Ethernet 10Gbase-T (10GBASE-T)'},
                  'eth1': {'device': 'eth1', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'flags': [],
                           'macaddress': 'unknown', 'mtu': '1500', 'media': 'Ethernet copper'}}


# Generated at 2022-06-22 23:48:26.724729
# Unit test for method parse_unknown_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_unknown_line():
    network = GenericBsdIfconfigNetwork()
    iface = {}
    ips = {}
    words = []
    network.parse_unknown_line(words, iface, ips)
    assert iface == {}
    assert ips == {}



# Generated at 2022-06-22 23:48:30.613098
# Unit test for constructor of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork():

    # create instance and test we have the expected properties
    network_facts = GenericBsdIfconfigNetwork(dict(ANSIBLE_MODULE_ARGS={}))
    assert network_facts.platform == 'Generic_BSD_Ifconfig'


# Generated at 2022-06-22 23:48:41.893708
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    module = AnsibleModuleMock()
    current_if = {'ipv6': []}
    ips = dict(
        all_ipv6_addresses=[],
    )

    GenericBsdIfconfigNetwork._GenericBsdIfconfigNetwork__parse_inet6_line(
        GenericBsdIfconfigNetwork._GenericBsdIfconfigNetwork(),
        ['inet6', '2001:db8:1::1', 'prefixlen', '64', 'scopeid', '0x10'],
        current_if, ips)

    assert current_if['ipv6'][0]['address'] == '2001:db8:1::1'
    assert current_if['ipv6'][0]['prefix'] == '64'
    assert current_if['ipv6'][0]['scope'] == '0x10'


# Generated at 2022-06-22 23:48:54.806804
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_interfaces_info():

    mock_module = Mock(name='module')
    mock_module.get_bin_path.return_value='/sbin/ifconfig'

# Generated at 2022-06-22 23:49:03.547511
# Unit test for method parse_tunnel_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_tunnel_line():
    obj = GenericBsdIfconfigNetwork()
    def_if = {'device': 'tun0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    obj.parse_tunnel_line(['tunnel', 'inet', '10.20.30.40', '-->', '40.50.60.70'], def_if, {})
    assert def_if['type'] == 'tunnel'



# Generated at 2022-06-22 23:49:14.852463
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    from ansible.module_utils.network.common.utils import module_wrapper
    from ansible.module_utils.facts.network.base import NetworkCollector as NetBase

    # This class interface and behavior is not stable, these tests will break in the future.
    # This is the generic class that should always work, so may be a good place to fix breakages.
    # Note this test has been copied to network_tools/platform_specific_tools.py.
    generic = GenericBsdIfconfigNetwork()

    # Simple positive test.
    assert generic.get_options('1100<BROADCAST,MULTICAST>') == ['BROADCAST', 'MULTICAST']

    # Blank option string
    assert generic.get_options('') == []

    # No start of <

# Generated at 2022-06-22 23:49:27.618193
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    # ifconfig_path = 'ifconfig'
    ifconfig_path = '/sbin/ifconfig'
    ifconfig_options = '-a'
    crypto = 'open'
    classes = [GenericBsdIfconfigNetwork]

    for cls in classes:
        obj = cls(dict(module=dict(get_bin_path=lambda x: ifconfig_path,
                                   run_command=run_command,
                                   crypto=crypto)))
        interfaces, ips = obj.get_interfaces_info(ifconfig_path, ifconfig_options)
        for iface in interfaces:
            assert type(interfaces[iface]) == dict, 'parse_nd6_line: interface_%s is a dict' % iface
            iface = interfaces[iface]

# Generated at 2022-06-22 23:49:39.995357
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    class FakeModule(object):
        def __init__(self):
            self.params = dict()

    module = FakeModule()
    network = GenericBsdIfconfigNetwork(module)
    current_if = dict()

    test_data = dict(
        option=['nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'],
        option_no_nd6=[
            'nd6',
            'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>',
            'nd6',
            'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>',
        ],
    )


# Generated at 2022-06-22 23:49:52.068974
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    """ Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
    """
    print('Testing GenericBsdIfconfigNetwork.parse_interface_line()')
    network = GenericBsdIfconfigNetwork()

# Generated at 2022-06-22 23:50:04.794484
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    network = GenericBsdIfconfigNetwork()
    defaults = dict(interface='lo0')
    interfaces = dict()
    interfaces['lo0']= dict(device='lo0', type='loopback', ipv4=[], macaddress='unknown', options=[], ipv6=[], metric='0', mtu='33184', lladdr=None)
    interfaces['lo0']['ipv4'].append(dict(address='127.0.0.1', netmask='255.0.0.0', network='127.0.0.0', broadcast='127.255.255.255'))

# Generated at 2022-06-22 23:50:13.844193
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    module = AnsibleModule(argument_spec={})
    network = NetworkModule(module)
    generic_bsd_ifconfig_network = GenericBsdIfconfigNetwork(network)
    assert generic_bsd_ifconfig_network.parse_lladdr_line(["lladdr", "01:02:03:04:05:06"]) == {"device": "device", "macaddress": "01:02:03:04:05:06", "type": "unknown", "ipv4": [], "ipv6": [], "lladdr": "01:02:03:04:05:06"}


# Generated at 2022-06-22 23:50:26.982716
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    class GenericBsdIfconfigNetworkTester(GenericBsdIfconfigNetwork):
        def get_options(self, option_string):
            return GenericBsdIfconfigNetwork.get_options(self, option_string)
    generic = GenericBsdIfconfigNetworkTester()

    option_string = 'options=<loopback>'
    options = generic.get_options(option_string)
    assert options == ['loopback']

    option_string = 'options=<loopback,multicast>'
    options = generic.get_options(option_string)
    assert options == ['loopback', 'multicast']

    option_string = 'options=<loopback,multicast>'
    options = generic.get_options(option_string)
    assert options == ['loopback', 'multicast']


# Generated at 2022-06-22 23:50:40.455175
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    from ansible.module_utils.facts.network import GenericBsdIfconfigNetwork
    instance = GenericBsdIfconfigNetwork()
    lines = [
        ["nd6", "options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>", "media:", "Ethernet", "10Gbase-SR", "status:", "active"]
    ]

    result = instance.parse_nd6_line(lines[0], {}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert isinstance(result, dict), "Result is not a dictionary type"
    assert 'options' in result and result['options'] == ["PERFORMNUD", "IFDISABLED", "AUTO_LINKLOCAL"], "There is no such key as options in result."

# Generated at 2022-06-22 23:50:50.304598
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    m = AnsibleModule(argspec={})
    facts = dict(network=dict())
    ifcfg = GenericBsdIfconfigNetwork(m, facts)
    if not HAS_STRUCT:
        pytest.skip("platform is not supported")

    # normal addr
    words = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384"
    words += " options=600003<RXCSUM,TXCSUM,RXCSUM_IPV6,TXCSUM_IPV6>"
    words = words.split()
    current_if = ifcfg.parse_interface_line(words)
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

# Generated at 2022-06-22 23:51:01.461514
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Arrange
    test_interface = {
        'test0': {
            'media': 'Ethernet autoselect (1000baseT <full-duplex>)',
            'macaddress': '00:11:22:33:44:55',
            'device': 'test0',
            'flags': ['BROADCAST', 'SIMPLEX', 'MULTICAST'],
            'mtu': '1500'
        }
    }
    
    # Act
    result = GenericBsdIfconfigNetwork.detect_type_media(test_interface)
    
    # Assert
    assert result['test0']['type'] == 'ether'

# Generated at 2022-06-22 23:51:11.236256
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    import io

    ifconfig_net = GenericBsdIfconfigNetwork()

    def run_command_mock(*args, **kwargs):
        output = io.StringIO(u"""add net default: gateway 192.168.1.1
add net ::ffff:0.0.0.0/96: gateway ::1
""")
        return 0, output.read(), None
    ifconfig_net.module.run_command = run_command_mock

    result = ifconfig_net.get_default_interfaces(None)
    assert result[0]['interface'] == 'default'
    assert result[1]['interface'] == '::ffff:0.0.0.0/96'

# Generated at 2022-06-22 23:51:20.012495
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    facts = dict(
        default_ipv4 = dict(),
        default_ipv6 = dict(),
        all_ipv4_addresses = [],
        all_ipv6_addresses = [],
        interfaces = ['lo0']
    )
    mock_module = BsdIfconfigModuleMock()
    test_obj = GenericBsdIfconfigNetwork(mock_module)
    test_obj.populate(facts)
    assert mock_module.debug_messages == []

    test_obj.parse_inet6_line(['inet6', 'fe80::1%lo0', 'prefixlen', '64', 'scopeid', '0x2'], facts['lo0'], facts)
    assert mock_module.debug_messages == []



# Generated at 2022-06-22 23:51:32.165573
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # Create test object
    import pprint
    mynw = GenericBsdIfconfigNetwork()

    # This is the list of test cases
    #   Each tuple has the following items:
    #    0: An instance of GenericBsdIfconfigNetwork
    #    1: The input line to be parsed
    #    2: The correct output

# Generated at 2022-06-22 23:51:39.656325
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    m = GenericBsdIfconfigNetwork({'ansible_facts': {}}, None)
    m.parse_options_line(['options=3<RXCSUM,TXCSUM>', 'mtu', '65536', 'metric', '0', 'nd6', 'options=29<PERFORMNUD,IFDISABLED,AUTO_LINKLOCAL>'],
                        {'device': 'en0', 'ipv4': [], 'ipv6': [], 'type': 'unknown', 'macaddress': 'unknown', 'flags': ['BROADCAST', 'SMART', 'SIMPLEX', 'MULTICAST'], 'metric': '0', 'mtu': '1500'}, {})



# Generated at 2022-06-22 23:51:46.789638
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    input_line = "lo0: flags=8049<UP,LOOPBACK,RUNNING,MULTICAST> metric 0 mtu 16384"
    words = input_line.split()

    network = network_module.GenericBsdIfconfigNetwork()
    parsed_line = network.parse_interface_line(words)

    assert parsed_line['device'] == 'lo0'
    assert 'LOOPBACK' in parsed_line['flags']
    assert parsed_line['metric'] == '0'
    assert parsed_line['mtu'] == '16384'


# Generated at 2022-06-22 23:51:59.720636
# Unit test for method parse_lladdr_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_lladdr_line():
    platform = 'Generic_BSD_Ifconfig'
    check = GenericBsdIfconfigNetwork(platform, None)
    network_facts = {}
    network_facts['default_ipv4'] = {}
    network_facts['default_ipv6'] = {}
    interfaces = {}
    current_if = {}
    ips = collections.OrderedDict()
    ips['all_ipv4_addresses'] = []
    ips['all_ipv6_addresses'] = []
    words = ['lladdr', 'f4:0c:b8:f0:a0:75']
    current_if['device'] = 'en0'
    current_if['ipv4'] = []
    current_if['ipv6'] = []
    current_if['type'] = 'unknown'

# Generated at 2022-06-22 23:52:06.976587
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # old style netmask
    gbif = GenericBsdIfconfigNetwork()
    words = 'inet 10.10.10.1 netmask 0xffffff00 broadcast 10.10.10.255'.split()
    current_if = {'ipv4': []}
    ips = {}
    gbif.parse_inet_line(words, current_if, ips)
    assert len(current_if['ipv4']) == 1
    assert current_if['ipv4'][0]['address'] == '10.10.10.1'
    assert current_if['ipv4'][0]['netmask'] == '255.255.255.0'
    assert current_if['ipv4'][0]['network'] == '10.10.10.0'

# Generated at 2022-06-22 23:52:13.648428
# Unit test for method get_options of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_options():
    network = GenericBsdIfconfigNetwork('BSD')
    assert ['UP', 'BROADCAST', 'SMART', 'RUNNING', 'SIMPLEX', 'MULTICAST'] == network.get_options('sfo-hpr1a-vice-a.global.reno.gdg: flags=8802<BROADCAST,SIMPLEX,MULTICAST> mtu 1500')


# Generated at 2022-06-22 23:52:24.787390
# Unit test for method parse_nd6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_nd6_line():
    mock_module = Mock()
    mock_module.run_command.return_value = (0, '', '')
    iface = GenericBsdIfconfigNetwork(mock_module)

    current_if = {'device': 'ens3', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {}

    iface.parse_nd6_line(['nd6', 'options=23<PERFORMNUD,ACCEPT_RTADV,AUTO_LINKLOCAL>'], current_if, ips)
    assert current_if['options'] == ['PERFORMNUD', 'ACCEPT_RTADV', 'AUTO_LINKLOCAL']


# Generated at 2022-06-22 23:52:37.065407
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    generic_ifconfig_network = GenericBsdIfconfigNetwork()
    facts = {}
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    words = ['lo0', 'inet', '127.0.0.1', 'netmask', '0xff000000']
    generic_ifconfig_network.parse_inet_line(words, current_if, ips)
    assert current_if['ipv4'][0]['address'] == '127.0.0.1'
    assert current_if['ipv4'][0]['netmask'] == '255.0.0.0'
    assert current_if['ipv4'][0]['network'] == '127.0.0.0'

# Generated at 2022-06-22 23:52:50.188725
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    """ Parsing line with options should fill current_if with the options.
    """
    module = AnsibleModule()
    args = dict()
    args['ansible_facts'] = dict()
    ifconfig = GenericBsdIfconfigNetwork(module)
    words = ['options=3<RXCSUM,TXCSUM>', 'lladdr', 'xx:xx:xx:xx:xx:xx', 'media:', 'Ethernet', '10Gbase-T', '(none)',
             'status:', 'no', 'carrier']
    current_if = dict()
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])
    ifconfig.parse_options_line(words, current_if, ips)

# Generated at 2022-06-22 23:53:00.289646
# Unit test for method get_default_interfaces of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_get_default_interfaces():
    netinfo = []
    mock_module = MockModule(argv=[], connection=ConnectionMock('route -n get default\ninterface: en0\ngateway: 10.0.0.1\nroute -n get -inet6 default\ninterface: en0\ngateway: fe80::1\n'))
    g = GenericBsdIfconfigNetwork(mock_module)
    netinfo = g.get_default_interfaces('route')
    #assert netinfo == [{'interface': 'en0','gateway': '10.0.0.1'}, {'interface': 'en0','gateway': 'fe80::1'}]

# Generated at 2022-06-22 23:53:03.066618
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():

    # TODO: setup the MockedEnvironment object

    network = GenericBsdIfconfigNetwork(MockedEnvironment())
    # TODO: fix the params, so they are valid
    res = network.populate({})
    assert True == isinstance(res, dict)

# Generated at 2022-06-22 23:53:16.221052
# Unit test for method get_interfaces_info of class GenericBsdIfconfigNetwork

# Generated at 2022-06-22 23:53:22.005305
# Unit test for method parse_media_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_media_line():
    current_if = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # test_1
    words = ['media:', 'Ethernet', 'autoselect', '(1000baseT <full-duplex>)', 'status:', 'active']

# Generated at 2022-06-22 23:53:34.164473
# Unit test for method parse_inet6_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet6_line():
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.utils import validate_ipv4_address
    from ansible.module_utils.network.common.utils import validate_ipv6_address
    from ansible.module_utils.network.common.utils import validate_ipv6_interface_identifier

    # ipv6 addresses that should pass

# Generated at 2022-06-22 23:53:41.833422
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    # These values are from OpenBSD ifconfig output
    current_if = {'ipv4': []}
    ips = dict(all_ipv4_addresses=[])
    words = ['tun0:', 'inet6', 'fe80::8e0c:92ff:fedc:a87b%tun0', 'prefixlen', '64', 'scopeid', '0xa', 'inet', '10.3.0.1', 'netmask', '0xff000000', 'inet6', '2003:49:108:12f8:0:0:0:1', 'prefixlen', '64', 'inet6', 'fc48:7a60:6688:1::1', 'prefixlen', '64']
    test = GenericBsdIfconfigNetwork()

    test.parse_inet_line(words, current_if, ips)

# Generated at 2022-06-22 23:53:48.306989
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    # Setup
    options_line = 'options=3<RXCSUM,TXCSUM,VLAN_MTU>'
    words = options_line.split()
    current_if = {}
    ips = {}
    network = GenericBsdIfconfigNetwork()

    # Exercise
    network.parse_options_line(words, current_if, ips)

    # Verify
    assert current_if['options'] == ['RXCSUM', 'TXCSUM', 'VLAN_MTU']

# Generated at 2022-06-22 23:53:53.712799
# Unit test for method parse_inet_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_inet_line():
    line = 'inet 127.0.0.1 netmask 0xffffffff'
    words = line.split()
    iface = {'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'unknown'}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    facts = GenericBsdIfconfigNetwork()
    facts.parse_inet_line(words, iface, ips)
    assert len(iface['ipv4']) == 1
    assert iface['ipv4'][0]['address'] == '127.0.0.1'
    assert iface['ipv4'][0]['netmask'] == '255.255.255.255'

# Generated at 2022-06-22 23:54:06.470798
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    target = GenericBsdIfconfigNetwork()

    # Test 1: Test with a real output from ifconfig -a
    test_data = ['vmnet8: flags=8863<UP,BROADCAST,SMART,RUNNING,SIMPLEX,MULTICAST> mtu 1500',
                 'ether 00:50:56:c0:00:08',
                 'inet 192.168.144.1 netmask 0xffffff00 broadcast 192.168.144.255',
                 'nd6 options=1<PERFORMNUD>',
                 '']

    words = test_data[0].split()
    result = target.parse_interface_line(words)
    assert result['device'] == 'vmnet8'
    assert 'UP' in result['flags']
    assert 'BROADCAST' in result['flags']

# Generated at 2022-06-22 23:54:14.913674
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    # Hard to unit test in the process of init
    network = GenericBsdIfconfigNetwork()
    interfaces = {'em0': {'media': 'Ethernet autoselect (1000baseT)'},
                  'lo0': {'mtu': '33184', 'macaddress': 'unknown', 'flags': ['UP', 'LOOPBACK', 'RUNNING', 'MULTICAST'], 'device': 'lo0', 'ipv4': [], 'ipv6': [], 'type': 'loopback'}}

    interfaces_updated = network.detect_type_media(interfaces)
    assert interfaces_updated['em0']['type'] == 'ether'


# Generated at 2022-06-22 23:54:21.675455
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    ifconfig_path = '/sbin/ifconfig'
    rc, out, err = module.run_command([ifconfig_path, '-a'])
    interfaces, ips = GenericBsdIfconfigNetwork().get_interfaces_info(ifconfig_path)
    interfaces = GenericBsdIfconfigNetwork().detect_type_media(interfaces)

    assert interfaces['bridge0']['type'] == 'ether'


# Generated at 2022-06-22 23:54:28.838179
# Unit test for method parse_status_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_status_line():
    line = "status: active"
    current_if = {}
    ips = {}
    my_obj = GenericBsdIfconfigNetwork()
    my_obj.parse_status_line(line.split(), current_if, ips)
    print(current_if)

if __name__ == '__main__':
    test_GenericBsdIfconfigNetwork_parse_status_line()
    sys.exit()

# Generated at 2022-06-22 23:54:40.969893
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    assert GenericBsdIfconfigNetwork().merge_default_interface(
        {}, {}, 'ipv4'
    ) == None
    assert GenericBsdIfconfigNetwork().merge_default_interface(
        {'interface': 'eth0'}, {}, 'ipv4'
    ) == None
    assert GenericBsdIfconfigNetwork().merge_default_interface(
        {'interface': 'eth0'}, {'eth0': {'ipv4': {'address': '127.0.0.1'}}}, 'ipv4'
    ) == {'interface': 'eth0', 'address': '127.0.0.1'}

# Generated at 2022-06-22 23:54:53.915220
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
  # Test with defaults having interface and it exists in interfaces
  defaults = {'interface': 'eth1'}
  interfaces = {'eth0': {}, 'eth1': {'ipv4': [{'address': '10.0.0.1', 'netmask': '255.255.0.0'}]}}
  GenericBsdIfconfigNetwork(None, None).merge_default_interface(defaults, interfaces, 'ipv4')
  assert defaults == {'interface': 'eth1', 'ipv4': [{'address': '10.0.0.1', 'netmask': '255.255.0.0'}]}

  # Test with defaults having address and it exists in interfaces
  defaults = {'interface': 'eth1', 'address': '10.0.0.1'}

# Generated at 2022-06-22 23:55:01.734783
# Unit test for method merge_default_interface of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_merge_default_interface():
    # pylint: disable=protected-access
    net_facts = GenericBsdIfconfigNetwork()
    defaults = {'interface': 'em0', 'foo': 'bar'}
    interfaces = {'em0': {'ipv4': ['address']}}
    net_facts._merge_default_interface(defaults, interfaces, 'ipv4')
    assert defaults == {'interface': 'em0', 'foo': 'bar', 'ipv4': ['address']}


# Generated at 2022-06-22 23:55:14.104680
# Unit test for method parse_interface_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_interface_line():
    ansible = AnsibleModule(argument_spec={})
    obj = GenericBsdIfconfigNetwork(ansible)

    # Test normal case
    words = ['lo0:', 'flags=8049<UP,LOOPBACK,RUNNING,MULTICAST>', 'mtu', '33184']
    iface_info = obj.parse_interface_line(words)

    assert iface_info['device'] == 'lo0'
    assert 'LOOPBACK' in iface_info['flags']
    assert 'RUNNING' in iface_info['flags']
    assert 'UP' in iface_info['flags']
    assert 'MULTICAST' in iface_info['flags']
    assert iface_info['type'] == 'loopback'
    assert iface_info['mtu'] == '33184'


# Generated at 2022-06-22 23:55:27.595821
# Unit test for method populate of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_populate():
    module = get_module_mock()
    module.get_bin_path.side_effect = lambda x: x
    module.run_command.side_effect = lambda x: (0, get_ifconfig_output(),  "")

    facts = GenericBsdIfconfigNetwork(module).populate()

    assert_equals(facts['default_ipv4']['interface'], 'lo0')
    assert_equals(facts['default_ipv4']['address'], '127.0.0.1')
    assert_equals(facts['default_ipv4']['netmask'], '255.0.0.0')
    assert_equals(facts['default_ipv4']['network'], '127.0.0.0')

# Generated at 2022-06-22 23:55:39.165376
# Unit test for method parse_options_line of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_parse_options_line():
    resource_id  = 'lo0'
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'options=4819<RXCSUM,TXCSUM,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6> mtu 16384', None)
    network_obj = GenericBsdIfconfigNetwork(resource_id, module)
    current_if = {}
    network_obj.parse_options_line(['options=4819<RXCSUM,TXCSUM,LINKSTATE,RXCSUM_IPV6,TXCSUM_IPV6>',
                                    'mtu', '16384'], current_if, {})


# Generated at 2022-06-22 23:55:44.533752
# Unit test for method detect_type_media of class GenericBsdIfconfigNetwork
def test_GenericBsdIfconfigNetwork_detect_type_media():
    test_inst = GenericBsdIfconfigNetwork()
    test_dict = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)'},
                 'wlan0': {'media': 'IEEE 802.11 Wireless Ethernet autoselect mode 11g'},
                 'tun0': {'media': 'IEEE 802.11 Wireless Ethernet autoselect mode 11g'}}
    expected_dict = {'eth0': {'media': 'Ethernet autoselect (1000baseT <full-duplex>)', 'type': 'ether'},
                     'wlan0': {'media': 'IEEE 802.11 Wireless Ethernet autoselect mode 11g'},
                     'tun0': {'media': 'IEEE 802.11 Wireless Ethernet autoselect mode 11g'}}