

# Generated at 2022-06-20 22:15:38.078490
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from distutils.version import LooseVersion
    from pkg_resources import Requirement, VersionConflict

    def _test_satisfied_by_with_string_version(satisfied_version, version_to_test, expected_result):
        package = Package("foo", satisfied_version)
        assert package.is_satisfied_by(version_to_test) == expected_result

    def _test_satisfied_by_with_string_version_when_no_version_specifier(version_to_test, expected_result):
        package = Package("foo")
        assert package.is_satisfied_by(version_to_test) == expected_result

    def _test_satisfied_by_with_tuple_version(satisfied_version, version_to_test, expected_result):
        package

# Generated at 2022-06-20 22:15:50.355513
# Unit test for constructor of class Package
def test_Package():
    # Test normal requirement
    pkg = Package('distribute==0.7.3')
    assert pkg.package_name == 'distribute'
    assert pkg.has_version_specifier
    assert pkg.is_satisfied_by('0.7.3')
    assert not pkg.is_satisfied_by('0.7.4')
    assert str(pkg) == 'distribute==0.7.3'

    # Test plain package
    pkg = Package('ansible')
    assert pkg.package_name == 'ansible'
    assert not pkg.has_version_specifier
    assert not pkg.is_satisfied_by('0.0.0')
    assert str(pkg) == 'ansible'

    # Test package with version specifier

# Generated at 2022-06-20 22:15:53.083407
# Unit test for method __str__ of class Package
def test_Package___str__():
    test_package_name = 'New-Test_Package-1.1.2'
    p = Package(test_package_name)
    assert str(p) == test_package_name

# Generated at 2022-06-20 22:15:59.945203
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:16:11.397712
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():

    def verify_is_satisfied_by(package_string, version_string, expected):
        pkg = Package(package_string, version_string)
        assert pkg.is_satisfied_by(version_string) == expected

    verify_is_satisfied_by("ansible", "2.1.1", True)
    verify_is_satisfied_by("ansible", "2.1.2", False)
    verify_is_satisfied_by("ansible", "2.2.0", False)
    verify_is_satisfied_by("ansible", "2.1.1.dev0", False)
    verify_is_satisfied_by("ansible", "2.1.1-rc2", False)

# Generated at 2022-06-20 22:16:19.436921
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:16:24.877578
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import shutil
    import filecmp
    sys.path.append(os.path.dirname(__file__))
    from ansible_module_pip import main as pip_main

    test_dir = tempfile.mkdtemp()
    test_dir2 = tempfile.mkdtemp()

    #print test_dir, test_dir2
    module_args = dict(
        state='present',
        name='dulwich',
        editable='git+https://github.com/dulwich/dulwich.git#egg=dulwich',
        chdir=test_dir,
        executable='/usr/bin/python2',
    )

# Generated at 2022-06-20 22:16:34.072645
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('Foo-Bar') == 'foo-bar'
    assert Package.canonicalize_name('Foo_Bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar-baz') == 'foo-bar-baz'
    assert Package.canonicalize_name('FooBar') == 'foobar'


# Some package managers (yum,Homebrew) need to convert package name to match their naming standards

# Generated at 2022-06-20 22:16:41.794140
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def test_spec(spec, ver_to_test, result):
        req = Requirement.parse(spec)
        pkg = Package(spec.split()[0], spec.split()[1])
        assert pkg.is_satisfied_by(ver_to_test) == result, \
            "%s %s %s" % (spec, ver_to_test, result)
        assert req.specifier.contains(ver_to_test) == result, \
            "%s %s %s" % (spec, ver_to_test, result)

    for ver in ['1.0', '1.0.0', '1.0a1', '1.0-beta', '1.0.post1']:
        test_spec('foo>=0.9', ver, True)

# Generated at 2022-06-20 22:16:52.618175
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package_satisfied = Package("setuptools")
    assert package_satisfied.is_satisfied_by("1.1.6") == True
    assert package_satisfied.is_satisfied_by("1.1.6-1") == True
    assert package_satisfied.is_satisfied_by("1.1.7") == False
    assert package_satisfied.is_satisfied_by("0.9.6") == False
    assert package_satisfied.is_satisfied_by("2.6") == False

    package_satisfied = Package("setuptools < 2")
    assert package_satisfied.is_satisfied_by("1.1.6") == True

# Generated at 2022-06-20 22:17:26.049730
# Unit test for function main
def test_main():
    from ansible.modules.packaging.python import main
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import reload_module
    reload_module(basic)
    reload_module(main)

    sys.stdout = StringIO()
    sys.stderr = StringIO()
    try:
        main()
    except SystemExit as e:
        sys.stderr = sys.__stderr__
        sys.stdout = sys.__stdout__
        raise e


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:17:36.799081
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('FOO') == 'foo'
    assert Package.canonicalize_name('FOO-BAR') == 'foo-bar'
    assert Package.canonicalize_name('FOO_BAR') == 'foo-bar'
    assert Package.canonicalize_name('Foo') == 'foo'
    assert Package.canonicalize_name('Foo-Bar') == 'foo-bar'
    assert Package.canonicalize_name('Foo_Bar') == 'foo-bar'

# Generated at 2022-06-20 22:17:49.022293
# Unit test for method canonicalize_name of class Package

# Generated at 2022-06-20 22:18:01.241231
# Unit test for constructor of class Package
def test_Package():
    # Test no version info
    p = Package("testpkg")
    assert p.package_name == "testpkg"
    assert p.has_version_specifier == False

    # Test with version specifier
    p = Package("testpkg", "==1,<1.1")
    assert p.package_name == "testpkg"
    assert p.has_version_specifier == True
    assert p.is_satisfied_by("1.0.0") == True
    assert p.is_satisfied_by("1.0.1") == False

    # Test with plain package name
    p = Package("testpkg==2.0")
    assert p.package_name == "testpkg"
    assert p.has_version_specifier == True

# Generated at 2022-06-20 22:18:08.739510
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """
    Test the setup_virtualenv function.
    """
    import json
    import time
    import os
    import tempfile
    import shutil
    import subprocess

    import pytest

    class TempDirectory(object):
        """
        A stub class implementing the context manager protocol.
        This is used to test directory creation and deletion.
        """
        def __init__(self, tempdir):
            self.tempdir = tempdir

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback):
            if os.path.exists(self.tempdir):
                shutil.rmtree(self.tempdir)
            return False

    def run_ansible(cmdline, args):
        """
        Run the ansible module standalone.
        """

# Generated at 2022-06-20 22:18:15.975797
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    cases = {
        'soumi-dEVElopMENT': 'soumi-development',
        'PyyAmL': 'pyyaml',
        'SOUMI-deVElopment': 'soumi-development',
        'PyYAML': 'pyyaml',
        'foo_bar-1.0': 'foo-bar-1.0',
        'foo_bar_baz-2.0': 'foo-bar-baz-2.0',
        'foo-bar-baz-3.0': 'foo-bar-baz-3.0',
    }
    for k, v in cases.items():
        assert Package.canonicalize_name(k) == v



# Generated at 2022-06-20 22:18:23.622485
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test case: Un-satisfied requirement
    assert not Package('setuptools', '>=0.6c11').is_satisfied_by('0.6c10')
    # Test case: Satisfied requirement
    assert Package('setuptools', '>=0.6c11').is_satisfied_by('0.6c11')
    # Test case: Un-satisfied requirement
    assert not Package('setuptools', '<0.6c11').is_satisfied_by('0.6c11')
    # Test cases: Un-satisfied requirements
    assert not Package('setuptools', '==0.6c11').is_satisfied_by('0.6c10')

# Generated at 2022-06-20 22:18:24.224795
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-20 22:18:31.701368
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("strange.package_name") == "strange-package-name"

    assert Package.canonicalize_name("strange_package_name") == "strange-package-name"

    assert Package.canonicalize_name("strange-package-name") == "strange-package-name"

    assert Package.canonicalize_name("strange--package----name") == "strange-package-name"

    assert Package.canonicalize_name("StrangePackageName") == "strangepackagename"



# Generated at 2022-06-20 22:18:38.518021
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=''),
            virtualenv_site_packages=dict(type='bool', default=False),
        )
    )
    env = "/tmp/test_venv"
    chdir = None
    out = ''
    err = ''
    setup_virtualenv(module, env, chdir, out, err)



# Generated at 2022-06-20 22:19:49.140171
# Unit test for function main
def test_main():
    """Unit test for function main"""
    inputs = {
        "state": "present",
        "name": ["pip"],
        "version": "",
        "requirements": "",
        "virtualenv": "/tmp/test/testf3d6138d96ad45e7bbbde18f2af6aebb",
        "virtualenv_command": "virtualenv",
        "virtualenv_python": "/usr/bin/python2",
        "extra_args": "",
        "editable": False,
        "chdir": "/tmp/test",
        "executable": "",
        "virtualenv_site_packages": True,
        "umask": None,
        "check_mode": False
    }
    set_module_args(inputs)
    result = main()
    assert result['changed']

# Generated at 2022-06-20 22:19:58.168743
# Unit test for constructor of class Package
def test_Package():
    pkg1 = Package('foo')
    assert pkg1
    assert not pkg1._requirement
    assert pkg1.package_name == 'foo'

    pkg2 = Package('foo', '1.0')
    assert pkg2
    assert pkg2._requirement
    assert pkg2.package_name == 'foo'
    assert pkg2.has_version_specifier

    pkg3 = Package('setuptools', '==0.9.8')
    assert pkg3
    assert pkg3._requirement
    assert pkg3.package_name == 'setuptools'
    assert pkg3.has_version_specifier

    pkg4 = Package('distribute', '==0.9.8')
    assert pkg4
    assert pkg4._requirement
    assert pkg

# Generated at 2022-06-20 22:20:09.378990
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:20:14.017098
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("PasteDeploy") == "paste-deploy"
    assert Package.canonicalize_name("pycrypto-2.6") == "pycrypto-2-6"
    assert Package.canonicalize_name("IsNot-a_Package") == "isnot-a-package"



# Generated at 2022-06-20 22:20:23.671331
# Unit test for constructor of class Package
def test_Package():
    name = "TestPackAGe"
    version = "1.0"
    meta = "%s==%s" % (name, version)
    obj = Package(meta)
    # should be 1.0
    assert obj.is_satisfied_by("1.0")
    # should be 1.0.0
    assert obj.is_satisfied_by("1.0.0")
    # should be 1.0.1
    assert not obj.is_satisfied_by("1.0.1")
    # should be 1.0.0a2
    assert obj.is_satisfied_by("1.0.0a2")
    # should be 1.0.0b2
    assert not obj.is_satisfied_by("1.0.0b2")
    assert obj.package

# Generated at 2022-06-20 22:20:32.002809
# Unit test for function main
def test_main():
    # test module args
    module_args = dict(
        state='present',
        name='httplib2',
        virtualenv='/tmp/test_pip_install',
        virtualenv_site_packages=False,
        virtualenv_command='virtualenv',
        virtualenv_python='',
        extra_args='',
        editable=False,
        chdir='/tmp',
        executable='/usr/bin/python',
        umask=None,
    )
    # test module
    module = AnsibleModule(
        argument_spec=module_args,
        # not checking arguments
        check_invalid_arguments=False,
        # not checking mutualy exclusive arguments
        bypass_checks=True,
    )
    # Unit test init
    setup_virtualenv = Mock(return_value=('', ''))

# Generated at 2022-06-20 22:20:40.763202
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils._text import to_native

    if PY3:
        virtualenv_cmd = 'pyvenv'
    else:
        virtualenv_cmd = 'virtualenv'

    module = FakeAnsibleModule({
        'virtualenv_command': virtualenv_cmd,
        'virtualenv_site_packages': True,
    })
    env = '/tmp/venv'
    chdir = '/tmp/foo'
    out = 'creating a new virtualenv is always a good idea\n'
    err = ''

    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)
    assert module.run_command.call_count == 1
    assert module.fail_json.call_count == 0
    assert 'system-site-packages' in module.run_command

# Generated at 2022-06-20 22:20:45.653096
# Unit test for constructor of class Package
def test_Package():
    package = Package("pip", "8.0.0")
    assert package.package_name == "pip"
    assert package.has_version_specifier
    assert package.is_satisfied_by("8.0.0")
    assert str(package) == 'pip==8.0.0'

    package = Package("pip")
    assert package.package_name == "pip"
    assert not package.has_version_specifier
    assert not package.is_satisfied_by("8.0.0")
    assert str(package) == 'pip'



# Generated at 2022-06-20 22:20:48.604951
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:20:53.481694
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo-1') == 'foo-1'
    assert Package.canonicalize_name('foo_1') == 'foo-1'
    assert Package.canonicalize_name('foo.1') == 'foo-1'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo--bar') == 'foo-bar'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'


# Generated at 2022-06-20 22:23:30.906651
# Unit test for function main
def test_main():
    import mock
    
    # set up mocking for function used to fail the module
    def _fail(module, cmd, out, err):
        raise Exception("Unexpected failure. Unable to run pip command.")
    
    # set up mocking for module
    _exit_json = mock.Mock(return_value = None)
    _fail_json = mock.Mock(side_effect = _fail)
    setattr(mock.MagicMock(), 'exit_json', _exit_json)
    setattr(mock.MagicMock(), 'fail_json', _fail_json)

    _run_command = mock.Mock(return_value = (0, 'test stdout', ''))
    setattr(mock.MagicMock(), 'run_command', _run_command)


# Generated at 2022-06-20 22:23:41.267907
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """ Test for setup_virtualenv function
    """
    import ansible.module_utils.basic
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'virtualenv_command': {'default': 'python3', 'type': 'str'},
            'virtualenv_python': {'default': 'python3', 'type': 'str'},
            'virtualenv_site_packages': {'default': True, 'type': 'bool'}
        },
        supports_check_mode=True,
    )
    env = module.params['virtualenv_command']  # This should be python3
   

# Generated at 2022-06-20 22:23:51.534019
# Unit test for constructor of class Package
def test_Package():
    pkg = Package("pytz")
    assert(not pkg.has_version_specifier)
    assert(pkg.is_satisfied_by("2009d"))

    pkg = Package("pytz", "2009d")
    assert(pkg.has_version_specifier)
    assert(pkg.is_satisfied_by("2009d"))
    assert(not pkg.is_satisfied_by("2010d"))


# Generated at 2022-06-20 22:23:58.669085
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import tempfile
    import shutil
    import unittest
    class TestModule(unittest.TestCase):
        def setUp(self):
            self.module = FakeModule()
            self.tmpdir = tempfile.mkdtemp()
            self.module.params['virtualenv_command'] = 'virtualenv'
            self.module.params['virtualenv_python'] = ''
            self.module.params['virtualenv_site_packages'] = False
            self.module.params['chdir'] = self.tmpdir

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def _run_setup(self, env, chdir):
            return setup_virtualenv(self.module, env, chdir, '', '')


# Generated at 2022-06-20 22:24:08.504716
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # ref:
    # https://www.python.org/dev/peps/pep-0440/#version-specifiers
    # https://www.python.org/dev/peps/pep-0441/#version-specifiers
    p = Package("pkg")
    version_to_test = "0.0.0"
    assert not p.is_satisfied_by(version_to_test)
    p = Package("pkg==0.0.0")
    assert p.is_satisfied_by(version_to_test)
    p = Package("pkg==1.2.3")
    version_to_test = "1.2.3"
    assert p.is_satisfied_by(version_to_test)
    p = Package("pkg>=0.0.0")
    assert p

# Generated at 2022-06-20 22:24:14.810435
# Unit test for constructor of class Package
def test_Package():
    assert (Package("Ansible==1.9.4"))
    assert not (Package("Ansible==1.9.4").has_version_specifier)
    assert Package("Ansible>=1.9.4").has_version_specifier
    assert Package("Ansible<=1.9.4").has_version_specifier
    assert (Package("Ansible").is_satisfied_by("1.9.4"))
    assert (Package("Ansible>=1.9.4").is_satisfied_by("1.9.4"))
    assert (Package("Ansible>=1.9.4").is_satisfied_by("1.9.5"))

# Generated at 2022-06-20 22:24:25.891035
# Unit test for constructor of class Package
def test_Package():
    data = (
        ("django==1.8.5", "django"),
        ("django>=1.8.5", "django"),
        ("Django-1.8.5", "Django"),
        ("Django", "Django"),
        ("django_app", "django_app"),
    )

    for name, package_name in data:
        pkg = Package(name)
        assert pkg.package_name == package_name, "%s != %s" % (name, package_name)

    pkg = Package("django")
    assert not pkg.has_version_specifier
    assert pkg.is_satisfied_by("1.8.5")
    assert not pkg.is_satisfied_by("1.4.4")

    p