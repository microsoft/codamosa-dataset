

# Generated at 2022-06-20 22:14:41.478315
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-20 22:14:50.636258
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Test cases for Package.__str__()
    # With a plain package
    package = Package('setuptools', '18.4')
    assert(str(package) == 'setuptools==18.4')
    # With a plain package without version specifier
    package = Package('setuptools')
    assert(str(package) == 'setuptools')
    # With a non-standard package name
    package = Package('setuptools-git')
    assert(str(package) == 'setuptools-git')
    # With a non-standard package name with version specifier
    package = Package('setuptools-git', '18.4')
    assert(str(package) == 'setuptools-git==18.4')



# Generated at 2022-06-20 22:14:58.670281
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    tmpdir = tempfile.mkdtemp()
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command='/usr/bin/virtualenv',
            virtualenv_python=None,
            virtualenv_site_packages=False,
            virtualenv_extra_search_dirs=None,
            virtualenv=None,
            state='present',
            upgrade=False,
            chdir=tmpdir,
            executable=None,
            package=None,
            extra_args=None,
        ),
        supports_check_mode=True
    )
    env = os.path.join(tmpdir, 'venv')
    module.params['virtualenv_python'] = None

# Generated at 2022-06-20 22:15:08.230409
# Unit test for constructor of class Package
def test_Package():
    assert Package('setuptools').package_name == 'setuptools'
    assert Package('foo_bar', '2.3').package_name == 'foo-bar'
    assert Package('setuptools', '==0.6').package_name == 'setuptools'
    assert Package('setuptools==0.6').package_name == 'setuptools'
    # old pkg_resource will replace 'setuptools' with 'distribute' when it's already installed
    assert Package('distribute').package_name == 'setuptools'
    # does not contain a valid specifier
    assert Package('foo-').package_name == 'foo-'
    assert Package('foo-').has_version_specifier is False
    assert Package('setuptools', '==0.6').has_version_specifier is True

# Generated at 2022-06-20 22:15:15.783909
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    print('Running test_Package_is_satisfied_by...')
    version_tests = (
       ('pytest==1.0.0', '1.0.0', True),
       ('pytest==1.0.0', '2.0.0', False),
       ('pytest', '1.0.0', True),
       ('pytest', '2.0.0', True),
    )
    for string, version, expected in version_tests:
        package = Package(string)
        assert package.is_satisfied_by(version) == expected


# Generated at 2022-06-20 22:15:20.922558
# Unit test for constructor of class Package
def test_Package():
    name_strings = {
        "setuptools": "setuptools",
        "setuptools==1.1": "setuptools==1.1",
        "setuptools >= 1.1, <2": "setuptools>=1.1,<2",
        "pytest": "pytest",
    }

    for name_string in name_strings:
        pkg = Package(name_string)
        assert name_strings[name_string] == str(pkg)



# Generated at 2022-06-20 22:15:32.967455
# Unit test for constructor of class Package
def test_Package():
    def test_is_satisfied(name_string, version_string=None, version_to_test="1.2.3", expected=True):
        pkg = Package(name_string, version_string)
        assert pkg.is_satisfied_by(version_to_test) is expected
        return pkg

    # test data is from PEP 503
    # [name, version_string in requirements.txt, version_to_test, expected_result]

# Generated at 2022-06-20 22:15:43.980504
# Unit test for function main
def test_main():
    """test the main function"""
    # Initializing unit test variables
    params = {
        'state': 'present',
        'name': 'ansible-test-module',
        'version': None,
        'requirements': None,
        'virtualenv': None,
        'virtualenv_site_packages': False,
        'virtualenv_command': 'virtualenv',
        'virtualenv_python': None,
        'extra_args': None,
        'editable': False,
        'chdir': None,
        'executable': None,
        'umask': None,
    }


# Generated at 2022-06-20 22:15:54.958129
# Unit test for function main
def test_main():
    # Unit tests for code path if requirements are provided.
    mock_module = MagicMock()
    mock_module.params = {
        'requirements': 'test',
        'state': 'present',
        'name': None,
        'version': None,
        'virtualenv': None,
        'virtualenv_site_packages': False,
        'virtualenv_command': None,
        'virtualenv_python': None,
        'extra_args': None,
        'editable': False,
        'chdir': None,
        'executable': None,
        'umask': None
    }

    # when requirements is specified, no version or name.

# Generated at 2022-06-20 22:16:05.086905
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    cmd = '/usr/bin/virtualenv'
    module = ''
    env = ''
    chdir = ''
    out = ''
    err = ''
    _get_cmd_options()
    _get_packages()
    _is_present()
    _get_pip()
    _fail()
    _get_package_info()
    assert setup_virtualenv(module, env, chdir, out, err) == '%s %s %s %s %s' % (cmd, '--system-site-packages', '-p%s' % virtualenv_python, '-p%s' % sys.executable, env)


# Generated at 2022-06-20 22:16:37.963235
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    test_cases = (
        ('pkg_name', 'pkg-name'),
        ('Pkg_name', 'pkg-name'),
        ('pkg_name_01', 'pkg-name-01'),
        ('Pkg_name_01', 'pkg-name-01'),
        ('pkg_name.01', 'pkg-name.01'),
        ('Pkg_name.01', 'pkg-name.01'),
        ('pkg_name-01', 'pkg-name-01'),
        ('Pkg_name-01', 'pkg-name-01'),
    )
    for name_str, expected in test_cases:
        assert Package.canonicalize_name(name_str) == expected, \
            "Unexpected result: %s" % Package.canonicalize_name(name_str)



# Generated at 2022-06-20 22:16:48.537974
# Unit test for constructor of class Package
def test_Package():
    assert Package('some-package').package_name == 'some-package'
    assert not Package('some-package').has_version_specifier

    assert Package('some-package', '1.0').package_name == 'some-package'
    assert Package('some-package', '1.0').has_version_specifier
    assert Package('some-package', '>=1.0').has_version_specifier
    assert Package('some-package', '1.0,>=2.0').has_version_specifier

    assert Package('some-package', '>=1.0').is_satisfied_by('1.0')
    assert Package('some-package', '>=1.0').is_satisfied_by('1.1')

# Generated at 2022-06-20 22:16:50.628948
# Unit test for constructor of class Package
def test_Package():
    pkg = Package("foo")
    assert pkg.has_version_specifier == False


# Generated at 2022-06-20 22:16:59.282552
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("foo") == "foo"
    assert Package.canonicalize_name("Foo") == "foo"
    assert Package.canonicalize_name("foo-bar") == "foo-bar"
    assert Package.canonicalize_name("Foo-Bar") == "foo-bar"
    assert Package.canonicalize_name("foo_bar") == "foo-bar"
    assert Package.canonicalize_name("Foo_Bar") == "foo-bar"
    assert Package.canonicalize_name("Foo.Bar") == "foo-bar"



# Generated at 2022-06-20 22:17:11.957498
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():


    if PY2:
        return

    specifier = SpecifierSet("<0.9.1,>=0.9.0")
    assert specifier.contains("0.9.0")
    assert not specifier.contains("0.9.1")
    # This should not be valid, but currently is.
    # assert specifier.contains("0.8.1")

    specifier = SpecifierSet("<0.8.1,>=0.9.0")
    assert not specifier.contains("0.9.0")
    assert not specifier.contains("0.9.1")
    assert not specifier.contains("0.8.1")

    specifier = SpecifierSet(">=0.9.0,<0.9.1")

# Generated at 2022-06-20 22:17:24.333908
# Unit test for function main
def test_main():
    from ansible.compat.tests.mock import mock_open
    from ansible.module_utils import easy_value
    import ansible.module_utils.basic

    # Fake data
    pip_list = "package-1.0\npackage-2.0"

    # Create mocks
    class FakeModule(object):
        def __init__(self):
            self._ansible_module = self

# Generated at 2022-06-20 22:17:31.887412
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # 1. simple case
    assert Package.canonicalize_name('a_b') == 'a-b'

    # 2. leading, trailing, mixed and multiple separators
    assert Package.canonicalize_name('..a.._._.b') == '-a-.-b'

    # 3. empty string
    assert Package.canonicalize_name('') == ''

    # 4. None
    assert Package.canonicalize_name(None) is None

# Generated at 2022-06-20 22:17:40.251144
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("setuptools")) == "setuptools"
    assert str(Package("setuptools", "==1.7.1")) == "setuptools==1.7.1"
    assert str(Package("setuptools", ">=2.7.5")) == "setuptools>=2.7.5"
    assert str(Package("jinja2")) == "jinja2"
    assert str(Package("jinja2", "2.10")) == "jinja2==2.10"
    assert str(Package("jinja2", "2.10.3")) == "jinja2==2.10.3"
    assert str(Package("jinja2", ">=2.10")) == "jinja2>=2.10"

# Generated at 2022-06-20 22:17:50.416198
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    with tempfile.TemporaryDirectory() as tempdir_name:
        opts = {'virtualenv_python': '/usr/bin/python', 'virtualenv_command': 'python -m venv --system-site-packages', 'virtualenv_site_packages': True}
        orig_module = AnsibleModule(**opts)
        out, err = setup_virtualenv(orig_module, tempdir_name, '/', '', '')
        assert out == ''
        assert err == ''
        opts = {'virtualenv_python': '/usr/bin/python', 'virtualenv_command': 'python -m venv', 'virtualenv_site_packages': True}
        orig_module = AnsibleModule(**opts)

# Generated at 2022-06-20 22:18:02.216473
# Unit test for constructor of class Package
def test_Package():

    # Requirement.parse will not parse requirement string without space (' ')
    # or '=='
    assert Package('simplejson').package_name == "simplejson"
    assert not Package('simplejson').has_version_specifier

    assert Package('pip 1.3').package_name == "pip"
    assert Package('pip 1.3').has_version_specifier
    assert Package('pip', '1.3').has_version_specifier
    assert Package('pip==1.3').has_version_specifier


auto_version_specifier = ('==', LooseVersion('0.0.0'))

# Kinds of version specifiers

# Generated at 2022-06-20 22:18:39.019772
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("foo")) == "foo"
    assert str(Package("foo", "1.0")) == "foo==1.0"
    assert str(Package("foo", ">=3.0")) == "foo>=3.0"
    assert str(Package("foo", ">=1.0,<2.0")) == "foo>=1.0,<2.0"



# Generated at 2022-06-20 22:18:49.318431
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    import tempfile
    import shutil

    def run_command(module, cmd, check_rc=True, cwd=None, **kwargs):
        rc = 0
        stdout = "virtualenv %s" % env
        stderr = ""
        return rc, stdout, stderr

    tmp_dir = tempfile.mkdtemp()
    tmp_env = os.path.join(tmp_dir, 'venv')

# Generated at 2022-06-20 22:18:55.280600
# Unit test for function main
def test_main():
    out = StringIO()
    err = StringIO()
    with redirect_stdout(out):
        with redirect_stderr(err):
            main()
    print(out.getvalue())
    print(err.getvalue())

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:19:06.889927
# Unit test for function main
def test_main():
    # Skip unit tests if not package requirements are installed
    if not HAS_SETUPTOOLS:
        print("Skip unit tests if not package requirements are installed")
        return True
    # apply the unit testing on the main function

# Generated at 2022-06-20 22:19:19.253465
# Unit test for constructor of class Package
def test_Package():
    assert Package("Flask").package_name == "flask"
    assert Package("Flask==").package_name == "flask"
    assert Package("Flask", "==").package_name == "flask"
    assert Package("Flask", "").package_name == "flask"
    assert Package("Flask", "").has_version_specifier == False
    assert Package("Flask", "==").has_version_specifier == True
    assert Package("Flask", ">=1.2.3").has_version_specifier == True
    assert Package("Flask", ">=1.2.3").is_satisfied_by("1.5.5") == True
    assert Package("Flask", ">=1.2.3").is_satisfied_by("1.2.3") == True
   

# Generated at 2022-06-20 22:19:22.155260
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    package = Package('setuptools-Lite')
    assert package.package_name == 'setuptools-lite'
    package = Package('Pip-Lite')
    assert package.package_name == 'pip-lite'


# Generated at 2022-06-20 22:19:26.962373
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """Unit test for ``setup_virtualenv``."""
    # Can't use unittest since we are using AnsibleModule.
    module = ansible_module_mock()
    env = '/tmp/ansible-test-venv/'
    chdir = None
    out = ''
    err = ''
    out_new, err_new = setup_virtualenv(module, env, chdir, out, err)
    assert out_new == out
    assert err_new == err


# Generated at 2022-06-20 22:19:38.193947
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    class MockModule(object):
        params = {
            'virtualenv_command': 'my_venv'
        }
        check_mode = False
        name=None
        version=None
        warn=None
        fail_json=None
        def run_command(self, cmd, cwd=None):
            return (0, '', '')
        def get_bin_path(self, cmd, required, opt_dirs=None):
            return 'my_venv'
    env='my_venv'
    chdir=None
    out=''
    err=''
    module = MockModule()
    setup_virtualenv(module, env, chdir, out, err)
    assert True


# Generated at 2022-06-20 22:19:48.840295
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("aaa-bbb--ccc") == "aaa-bbb-ccc"
    assert Package.canonicalize_name("aaa_bbb__ccc") == "aaa-bbb-ccc"
    assert Package.canonicalize_name("aaa..bbb..ccc") == "aaa-bbb-ccc"
    assert Package.canonicalize_name("aaaBBBccc") == "aaabbbccc"
    assert Package.canonicalize_name("aaaBBBccc-DDD-eee") == "aaabbbccc-ddd-eee"
    assert Package.canonicalize_name("AaaBBBccc-DDD-eee") == "aaabbbccc-ddd-eee"



# Generated at 2022-06-20 22:19:57.981137
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import boolean
    module = basic.AnsibleModule({
        'virtualenv_command': '/usr/bin/pyvenv',
        'virtualenv_site_packages': False,
        'virtualenv_python': 'python2'
    }, check_invalid_arguments=False)
    cmd = shlex.split(module.params['virtualenv_command'])
    cmd.append('--system-site-packages')
    cmd.append('--no-site-packages')
    cmd.append('-p/usr/bin/python')
    # assert that the virtualenv command was created correctly
    result = setup_virtualenv(module, './test_env', './', '', '')

# Generated at 2022-06-20 22:21:16.445968
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # Effectively underscores are replaced by dashes
    assert Package.canonicalize_name('a_b_c') == 'a-b-c'
    # Case is converted to lower
    assert Package.canonicalize_name('aBc') == 'abc'
    # Other separators are also replaced by dashes
    assert Package.canonicalize_name('a.b.c') == 'a-b-c'
    # The conversion is done even if already "clean"
    assert Package.canonicalize_name('a-b-c') == 'a-b-c'
    # None is correctly handled
    assert Package.canonicalize_name(None) is None

    # Should pass through unchanged if it doesn't look like a package name

# Generated at 2022-06-20 22:21:20.459355
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # Requirement.parse("package_name") == Requirement.parse("package-name")
    assert Package("package_name") == Package("package-name")
    # Requirement.parse("SomePackageName") == Requirement.parse("some-package-name")
    assert Package("SomePackageName") == Package("some-package-name")



# Generated at 2022-06-20 22:21:27.591242
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.six.moves import cStringIO
    else:
        from io import StringIO, BytesIO  # pylint: disable=ungrouped-imports
        cStringIO = BytesIO

    try:
        old_stdin, sys.stdin = sys.stdin, StringIO()
        old_stdout, sys.stdout = sys.stdout, StringIO()
        old_stderr, sys.stderr = sys.stderr, cStringIO()
        unittest.main(module=__name__, buffer=True, exit=False)
    finally:
        sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout,

# Generated at 2022-06-20 22:21:39.414527
# Unit test for constructor of class Package
def test_Package():
    # Package should return a wrapper class for the Requirement object
    p = Package('ndg-httpsclient==0.3.3')
    assert p.has_version_specifier
    assert not p.is_satisfied_by('0.3.2-dev')
    assert p.is_satisfied_by('0.3.3')

    # If a package has a version specifier, then it should be treated as Requirement object
    p = Package('ndg-httpsclient==0.3')
    assert p.has_version_specifier
    assert p.package_name == 'ndg-httpsclient'
    assert p.is_satisfied_by('0.3.3')

    # If a package does not have a version specifier, then it should not be treated as Requirement object

# Generated at 2022-06-20 22:21:41.513341
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('setuptools', '12.0.5')) == 'setuptools==12.0.5'
    assert str(Package('setuptools')) == 'setuptools'


# Generated at 2022-06-20 22:21:45.233753
# Unit test for function main
def test_main():
    mock_module = MagicMock(name='mock_module')
    mock_module.check_mode = False
    # mock_module.params = {'virtualenv_command': 'pyvenv', 'requirements': 'requirements.txt'}
    main()

if __name__ == '__main__':
    main()
    # test_main()

# Generated at 2022-06-20 22:21:50.225082
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('foo____bar') == 'foo----bar'
    assert Package.canonicalize_name('foo-bar-baz') == 'foo-bar-baz'



# Generated at 2022-06-20 22:21:51.577533
# Unit test for constructor of class Package
def test_Package():
    assert Package('pkg-name')
    assert Package('pkg-name', '2.0.0').has_version_specifier
    assert not Package('pkg-name').has_version_specifier


# Generated at 2022-06-20 22:21:58.673408
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package("foo", "=3.2")
    assert pkg.is_satisfied_by("3.2.3")
    pkg = Package("foo", ">=3.2")
    assert pkg.is_satisfied_by("3.2.3")
    assert pkg.is_satisfied_by("3.3")
    assert not pkg.is_satisfied_by("3.1")
    pkg = Package("foo", "<=3.2")
    assert pkg.is_satisfied_by("3.2.3")
    assert pkg.is_satisfied_by("3.1")
    assert not pkg.is_satisfied_by("3.3")
    pkg = Package("foo", "!=3.2")
    assert p

# Generated at 2022-06-20 22:21:59.685711
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv is not None



# Generated at 2022-06-20 22:23:17.633140
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # normal case
    assert Package("package", "1.0").is_satisfied_by("1.0")

    # Version is "1.0a1" in requirement, "1.0" in package
    assert Package("package", "1.0a1").is_satisfied_by("1.0")

    # Version is "1.0" in requirement, "1.0a1" in package
    assert not Package("package", "1.0").is_satisfied_by("1.0a1")

    # requirement is "> 1.0", package is "1.0"
    assert not Package("package", "> 1.0").is_satisfied_by("1.0")

    # requirement is "> 1.0", package is "2.0"

# Generated at 2022-06-20 22:23:23.677789
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # Normalize package names
    assert Package.canonicalize_name("Foo-Package") == "foo-package"
    assert Package.canonicalize_name("foo-package.") == "foo-package"
    assert Package.canonicalize_name("foo_package") == "foo-package"
    assert Package.canonicalize_name("_foo_package") == "-foo-package"



# Generated at 2022-06-20 22:23:33.179360
# Unit test for constructor of class Package
def test_Package():
    pkg_meta = Package("setuptools", "5.8.0")
    assert pkg_meta.package_name == "setuptools"
    assert pkg_meta._plain_package is True
    assert str(pkg_meta) == "setuptools==5.8.0"

    pkg_meta = Package("setuptools==5.8.0")
    assert pkg_meta.package_name == "setuptools"
    assert pkg_meta._plain_package is True
    assert str(pkg_meta) == "setuptools==5.8.0"

    pkg_meta = Package("setuptools<=5.8.0")
    assert pkg_meta.package_name == "setuptools"
    assert pkg_meta._plain_package is True
    assert str(pkg_meta)

# Generated at 2022-06-20 22:23:41.543218
# Unit test for method __str__ of class Package
def test_Package___str__():
    """Test __str__ method of Package."""
    def test_run(output, expected):
        """Helper function to test __str__ method of Package.
        @param output: string output of __str__ method.
        @param expected: expected string.
        """
        assert output == expected
    # no version requirement
    test_run(str(Package('pip')), 'pip')
    # case-insensitive
    test_run(str(Package('SETUPTOOLS')), 'setuptools')
    # separator replacement
    test_run(str(Package('pip._vendor.requests')), 'pip-_vendor-requests')
    # multiple separator replacement
    test_run(str(Package('pip..._vendor..requests')), 'pip-_-vendor--requests')
   

# Generated at 2022-06-20 22:23:46.189060
# Unit test for function main
def test_main():
    pip_command = "pip-3.3"
    state = "present"
    name = "ipython"
    version = "1.7.1"
    requirements = None
    virtualenv = "/tmp/my_new_virtual_environment"
    virtualenv_site_packages = None
    virtualenv_command = "virtualenv"
    extra_args = None
    editable = None
    chdir = "/opt/tmp"
    executable = None
    umask = None

# Generated at 2022-06-20 22:23:55.075880
# Unit test for function main
def test_main():
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    os.environ['PATH'] = ':'.join([os.path.dirname(sys.executable)])
    pip = os.path.join(os.path.dirname(sys.executable), 'pip')
    if not os.path.exists(pip):
        pytest.skip('pip is not available')

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)

# Generated at 2022-06-20 22:24:01.265436
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from distutils.version import StrictVersion, LooseVersion
    package = Package('foo')
    is_satisfied_by = lambda v: package.is_satisfied_by(v)
    if LooseVersion(StrictVersion.__version__) >= LooseVersion('1.8'):
        assert is_satisfied_by('1.8.1') == False
        assert is_satisfied_by('2.5') == False
        assert is_satisfied_by('1.9.1') == False

        package = Package('foo', '~=1.8.1')
        assert is_satisfied_by('1.8.1') == True
        assert is_satisfied_by('2.5') == False
        assert is_satisfied_by('1.9.1') == False

# Generated at 2022-06-20 22:24:09.845210
# Unit test for constructor of class Package
def test_Package():
    pkg_1 = Package("pytz")
    pkg_2 = Package("Django", "1.9.2")
    pkg_3 = Package("tldextract", "1.7.2")

    assert pkg_1.package_name == "pytz"
    assert pkg_1.has_version_specifier is False
    assert pkg_1._plain_package is True
    assert pkg_1.is_satisfied_by("2016.6.1") is True
    assert pkg_1.is_satisfied_by("0.4") is False

    assert pkg_2.package_name == "django"
    assert pkg_2.has_version_specifier is True
    assert pkg_2._plain_package is True
    assert pkg_2.is_s

# Generated at 2022-06-20 22:24:15.965777
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('mock==1.3.0') == 'mock==1.3.0'
    assert Package.canonicalize_name('mock') == 'mock'
    assert Package.canonicalize_name('Mock-2.0.0') == 'mock-2.0.0'
    assert Package.canonicalize_name('Mock_2.0.0') == 'mock-2.0.0'
    assert Package.canonicalize_name('mock-mock-mock-MOCK-mock') == 'mock-mock-mock-mock-mock'
    assert Package.canonicalize_name('mock.with.dots') == 'mock.with.dots'