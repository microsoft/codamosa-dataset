

# Generated at 2022-06-20 22:15:03.144423
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    """Unit test of the canonicalize_name method of the Package class.
    """
    from nose.tools import assert_equal
    test_cases = (
        ('foo', 'foo'),
        ('Foo', 'foo'),
        ('foo_bar', 'foo-bar'),
        ('foo_bar_baz', 'foo-bar-baz'),
        ('foo-bar-Baz', 'foo-bar-baz'),
        ('foo.bar.Baz', 'foo-bar-baz'),
        ('foo_._.-__--_', 'foo'),
        ('fooBar-123', 'foobar-123')
    )

    for name, expected_canonical_name in test_cases:
        assert_equal(
            Package.canonicalize_name(name),
            expected_canonical_name
        )


# Unit

# Generated at 2022-06-20 22:15:08.228727
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("Foo-Bar") == "foo-bar"
    assert Package.canonicalize_name("foo_bar") == "foo-bar"
    assert Package.canonicalize_name("foo.bar") == "foo-bar"
    assert Package.canonicalize_name("foo-bar") == "foo-bar"



# Generated at 2022-06-20 22:15:18.154392
# Unit test for function main

# Generated at 2022-06-20 22:15:31.076020
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from distutils.version import LooseVersion
    a_package = Package("foo", "2.0")
    assert a_package.is_satisfied_by("1.0") == False
    assert a_package.is_satisfied_by("2.0") == True
    assert a_package.is_satisfied_by("2.1") == False
    a_package = Package("foo >= 2.0")
    assert a_package.is_satisfied_by("1.0") == False
    assert a_package.is_satisfied_by("2.0") == True
    assert a_package.is_satisfied_by("2.1") == True
    a_package = Package("foo == 2.0")

# Generated at 2022-06-20 22:15:42.792588
# Unit test for constructor of class Package

# Generated at 2022-06-20 22:15:44.124402
# Unit test for function main
def test_main():
    assert 'virtualenv' in main()

# Generated at 2022-06-20 22:15:50.124576
# Unit test for method __str__ of class Package
def test_Package___str__():
    name_version = 'pytest==2.3.5'
    package = Package(name_version)
    assert str(package) == name_version

    name_version = 'python-novaclient>=2.15.0'
    package = Package(name_version)
    assert str(package) == name_version

    name = 'python-openstackclient'
    package = Package(name)
    assert str(package) == name

    name = 'ansible'
    package = Package(name)
    assert str(package) == name

    name = 'pytest'
    package = Package(name, '2.3.5')
    assert str(package) == name_version

    name = 'python-novaclient'
    package = Package(name, '>=2.15.0')
    assert str(package)

# Generated at 2022-06-20 22:15:50.509323
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-20 22:15:52.148964
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv("test_virtualenv_path", "python") == "test_virtualenv_path"


# Generated at 2022-06-20 22:15:59.398612
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:16:37.963404
# Unit test for constructor of class Package
def test_Package():
    assert Package('foo', '1.2.3').package_name == 'foo'
    assert Package('foo', '1.2.3').has_version_specifier == True
    assert Package('foo', '1.2.3').is_satisfied_by('1.2.3') == True
    assert Package('foo', '1.2').is_satisfied_by('1.2.4') == True
    assert Package('foo', '>=1.2').is_satisfied_by('1.2.4') == True
    assert Package('foo', '<1.2').is_satisfied_by('1.2.4') == False
    assert Package('foo', '>=1.2,<=2').is_satisfied_by('2.0') == True

# Generated at 2022-06-20 22:16:43.854561
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    name_cases = [
        (('foo_bar_z-p',), 'foo-bar-z-p'),
        (('foo.bar.z.p',), 'foo-bar-z-p'),
        (('A_Foo-Bar',), 'a-foo-bar'),
    ]
    for params, expected in name_cases:
        assert Package.canonicalize_name(*params) == expected



# Generated at 2022-06-20 22:16:54.961200
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # First test case: No version
    pkg_info = 'pip'
    pkg = Package(pkg_info)
    version_to_test = '8.1.2'
    assert pkg.is_satisfied_by(version_to_test) == False
    # Second test case: >= constraint
    pkg_info = 'pip>=8.1.2'
    pkg = Package(pkg_info)
    assert pkg.is_satisfied_by(version_to_test) == True
    # Third test case: > constraint
    pkg_info = 'pip>8.1.2'
    pkg = Package(pkg_info)
    assert pkg.is_satisfied_by(version_to_test) == False
    # Fourth test case: <= constraint
    pkg

# Generated at 2022-06-20 22:17:04.373425
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    args = dict(
        env='/tmp/testvirtualenv',
        chdir='/',
        out='foo',
        err='bar',
        virtualenv_command='/usr/bin/virtualenv',
        virtualenv_site_packages=True,
        virtualenv_python='',
    )
    module = DummyModule(**args)
    out, err = setup_virtualenv(module, **args)
    assert out == 'foo /usr/bin/virtualenv --system-site-packages /tmp/testvirtualenv'
    assert err == 'bar'



# Generated at 2022-06-20 22:17:15.000867
# Unit test for constructor of class Package
def test_Package():
    # ensure that Package(name) works with trailing newline
    p = Package('package-name')
    assert p.package_name == 'package-name'
    assert not p.has_version_specifier

    # ensure that Package(name, version) works with trailing newline
    p = Package('package-name', '1.2.3')
    assert p.package_name == 'package-name'
    assert p.has_version_specifier
    assert p.is_satisfied_by('1.2.3')
    assert p.is_satisfied_by('1.2.4')
    assert not p.is_satisfied_by('1.1.3')

    # ensure that Package(name, version, extras) works with trailing newline

# Generated at 2022-06-20 22:17:16.508638
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("requests")) == "requests"

# Generated at 2022-06-20 22:17:29.224010
# Unit test for method __str__ of class Package
def test_Package___str__():
    from ansible.module_utils.parsing.convert_bool import boolean

    assert str(Package('foobar')) == 'foobar'
    assert str(Package('foobar', '1.0')) == 'foobar==1.0'
    assert str(Package('foobar', '[1.0')) == 'foobar>=1.0,<1.1'
    assert str(Package('foobar', '(1.0')) == 'foobar>1.0,<1.1'
    assert str(Package('foobar', '[1.0)')) == 'foobar>=1.0,<1.1'
    assert str(Package('foobar', '[1.0,)')) == 'foobar>=1.0'

# Generated at 2022-06-20 22:17:36.358151
# Unit test for constructor of class Package
def test_Package():
    for p in ('foo-bar', 'Foo_bar', 'Foo.Bar'):
        assert Package(p).package_name == 'foo-bar'

    for p in ('foo-bar', 'Foo_bar', 'Foo.Bar'):
        assert Package(p, '1.0').package_name == 'foo-bar'
        assert Package(p, '1.0').is_satisfied_by('1.0')
        assert not Package(p, '1.0').is_satisfied_by('1.1')



# Generated at 2022-06-20 22:17:45.344372
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('pip')) == 'pip'
    assert str(Package('Pip')) == 'pip'
    assert str(Package('Pip==8.0.0')) == 'pip==8.0.0'
    assert str(Package('pytest-mock')) == 'pytest-mock'
    assert str(Package('pytest-mock==0.9.0')) == 'pytest-mock==0.9.0'


# Generated at 2022-06-20 22:17:50.641306
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('Foo-Bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar_baz-qux') == 'foo-bar-baz-qux'
    assert Package.canonicalize_name('Foo.Bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar_baz.qux') == 'foo-bar-baz-qux'



# Generated at 2022-06-20 22:18:28.733972
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    foo_pkg = Package('foo')
    bar_pkg = Package('bar', '0.1.1')
    baz_pkg = Package('baz', '=0.2a4')

    for _ in (foo_pkg, bar_pkg):
        assert not _.is_satisfied_by('0.1.0')
        assert _.is_satisfied_by('0.1.0.post1')
        assert _.is_satisfied_by('0.1.1')
        assert _.is_satisfied_by('0.1.1.post1')

    assert not baz_p

# Generated at 2022-06-20 22:18:35.633304
# Unit test for constructor of class Package
def test_Package():
    test_cases = [
        Package('test_package'),
        Package('test_package', '1.1'),
        Package('test_package', '>=1.1'),
        Package('test_package', '>1.1,<2.0'),
        Package('test_package', '>=1.1,<=2.0'),
    ]
    # test print
    for tc in test_cases:
        print(tc)



# Generated at 2022-06-20 22:18:45.904432
# Unit test for constructor of class Package
def test_Package():
    assert Package("ansible").package_name == "ansible"
    assert Package("ansible", "2.1.0").package_name == "ansible"
    assert Package("ansible", "2.1.0").has_version_specifier
    assert Package("ansible==").has_version_specifier
    assert not Package("ansible").has_version_specifier
    assert str(Package("ansible", "2.1.0")) == "ansible==2.1.0"
    assert not Package("ansible", "2.1.0").is_satisfied_by("abc")
    assert Package("ansible", "2.1.0").is_satisfied_by("2.1.0")

# Generated at 2022-06-20 22:18:58.145347
# Unit test for constructor of class Package

# Generated at 2022-06-20 22:18:58.790241
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert True



# Generated at 2022-06-20 22:19:08.965951
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    test_package_name = "package_name"
    version_range = "==1.5.5,>=1.5.5,<=1.5.5,~=1.5.5,>1.5.5,<1.5.5"
    expected_result = [True] * 6

    try:
        # pkg_resources for python < 2.7.0 does not support parse_requirements
        from pkg_resources import parse_requirements
    except ImportError:
        from pip.req import parse_requirements
    # import pkg_resources.parse_requirements for python >= 2.7.0
    dummy_options = ['foo', 'bar']
    version_specs = list(parse_requirements(version_range, options=dummy_options))

# Generated at 2022-06-20 22:19:20.761046
# Unit test for function main

# Generated at 2022-06-20 22:19:27.969352
# Unit test for constructor of class Package
def test_Package():
    def _test(name, version, output):
        pkg = Package(name, version)
        assert pkg.package_name == output[0]
        assert pkg.has_version_specifier == output[1]
        assert str(pkg) == output[2]

    _test('setuptools', '3.4.4', ('setuptools', True, 'setuptools==3.4.4'))
    _test('pkg-resources==0.0.0', None, ('pkgresources', True, 'pkg-resources==0.0.0'))
    _test('setuptools', None, ('setuptools', False, 'setuptools'))
    _test('python-dateutil', None, ('pythondateutil', False, 'python-dateutil'))

# Generated at 2022-06-20 22:19:40.017268
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    simple_pkg = Package('simple')
    exact_pkg = Package('simple', '1.0')
    complex_pkg = Package('complex', '> 1.0, < 2.0')

    # Test satisfied package
    assert simple_pkg.is_satisfied_by('1.0.0')
    assert exact_pkg.is_satisfied_by('1.0')
    assert complex_pkg.is_satisfied_by('1.5')
    assert complex_pkg.is_satisfied_by('1.5.1')
    assert complex_pkg.is_satisfied_by('1.5.1.post0')

    # Test unsatisfied package
    assert not simple_pkg.is_satisfied_by('2.0.0')
    assert not complex_pkg.is_satisfied_by

# Generated at 2022-06-20 22:19:46.634594
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('Django', '1.8.5')) == 'Django==1.8.5'
    assert str(Package('Django', '1.9a1')) == 'Django==1.9a1'
    assert str(Package('Django', '>=1.8,<2.0')) == 'Django >=1.8,<2.0'



# Generated at 2022-06-20 22:20:25.482349
# Unit test for method __str__ of class Package
def test_Package___str__():
    package = Package("setuptools", "2.2")
    assert str(package) == "setuptools==2.2"
    package = Package("pip", "1.5")
    assert str(package) == "pip==1.5"


# Generated at 2022-06-20 22:20:33.312739
# Unit test for function main
def test_main():
    import sys
    import os
    module_path = os.path.dirname(sys.modules[__name__].__file__)
    code = '''
    from ansible.module_utils.six import PY3
    from ansible.module_utils.basic import *

    # Get the global main function
    main = sys.modules[__name__].main

    # Call the global main function
    main()
    '''
    module_args = dict(
        state = 'present',
        name = ['ansible'],
        executable = 'pip'
    )
    out = execute_redirected(code, module_path, module_args)
    print(out)

# Generated at 2022-06-20 22:20:41.788816
# Unit test for constructor of class Package
def test_Package():
    pkg = Package("pip")
    assert pkg.package_name == "pip"
    assert pkg._plain_package == False

    pkg = Package("pip", "1.1")
    assert pkg.package_name == "pip"
    assert pkg.has_version_specifier == True
    assert pkg.is_satisfied_by("1.1")

    pkg = Package("pip>=2.0,!=2.1")
    assert pkg.package_name == "pip"
    assert pkg.has_version_specifier == True
    assert pkg.is_satisfied_by("1.1") is False
    assert pkg.is_satisfied_by("2.2")

# Generated at 2022-06-20 22:20:45.989740
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("package.name") == "package-name"
    assert Package.canonicalize_name("package_name") == "package-name"
    assert Package.canonicalize_name("package-name") == "package-name"
    assert Package.canonicalize_name("Package-Name") == "package-name"
    assert Package.canonicalize_name("Package_name") == "package-name"
    assert Package.canonicalize_name("package_name-") == "package-name-"



# Generated at 2022-06-20 22:20:51.598240
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    import random
    import unittest

    class PackageTestCase(unittest.TestCase):
        def setUp(self):
            self.uppercase_versions = [chr(x) for x in range(ord('A'), ord('Z') + 1)]
            self.lowercase_versions = [chr(x) for x in range(ord('a'), ord('z') + 1)]
            self.num_versions = [chr(x) for x in range(ord('0'), ord('9') + 1)]
            self.symbols = list('_ - .')
            self.versions = self.uppercase_versions + self.num_versions + self.lowercase_versions
            self.versions_str = ''.join(random.sample(self.versions, len(self.versions)))
            self._test_data()



# Generated at 2022-06-20 22:20:58.496394
# Unit test for function main

# Generated at 2022-06-20 22:21:08.136715
# Unit test for method __str__ of class Package
def test_Package___str__():
    from ansible.module_utils.common.requirements import Package
    assert str(Package("foo", "1.0.0")) == "foo==1.0.0"
    assert str(Package("FooBar", "1.0.0")) == "foobar==1.0.0"
    assert str(Package("Foo-Bar", "1.0.0")) == "foo-bar==1.0.0"
    assert str(Package("Foo_Bar", "1.0.0")) == "foo-bar==1.0.0"
    assert str(Package("Foo.Bar", "1.0.0")) == "foo-bar==1.0.0"
    assert str(Package("FooBar", ">=1.0.0")) == "foobar>=1.0.0"
    assert str

# Generated at 2022-06-20 22:21:09.109340
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
   assert setup_virtualenv(module, env, chdir, out, err) == (0)



# Generated at 2022-06-20 22:21:11.881398
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('PACKAGe-4.1') == 'package-4.1'
    assert Package.canonicalize_name('_package-4.1') == 'package-4.1'
    assert Package.canonicalize_name('PACKAGE.4.1') == 'package-4.1'



# Generated at 2022-06-20 22:21:17.933437
# Unit test for function main

# Generated at 2022-06-20 22:22:28.252662
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('test_package')
    assert pkg.package_name == 'test_package'

    pkg = Package('test_package', 'dummy_version')
    assert pkg.package_name == 'test_package'
    assert pkg.has_version_specifier is False

    pkg = Package('test_package', '1.0')
    assert pkg.package_name == 'test_package'
    assert pkg.has_version_specifier is True



# Generated at 2022-06-20 22:22:36.320119
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    with pytest.raises(AttributeError):
        Package._CANONICALIZE_RE.sub = None
    assert Package.canonicalize_name("Apache-Beam-SDK-For-Python") == "apache-beam-sdk-for-python"
    assert Package.canonicalize_name("Apache2") == "apache2"
    assert Package.canonicalize_name("Apache2.4") == "apache2-4"
    assert Package.canonicalize_name("Apache_Beam") == "apache-beam"
    assert Package.canonicalize_name("Django_Beam") == "django-beam"
    assert Package.canonicalize_name("Django.Beam") == "django-beam"
    assert Package.canonicalize_name("Django.Beam.1")

# Generated at 2022-06-20 22:22:44.305624
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo_bar_baz') == 'foo-bar-baz'
    assert Package.canonicalize_name('foo.bar.baz') == 'foo-bar-baz'
    assert Package.canonicalize_name('fooBarBaz') == 'foo-bar-baz'
    assert Package.canonicalize_name('foo-bar-baz') == 'foo-bar-baz'
    assert Package.canonicalize_name('Foo-Bar-Baz') == 'foo-bar-baz'


# Generated at 2022-06-20 22:22:51.746832
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("foobar")) == "foobar"
    assert str(Package("foobar", "1.0")) == "foobar==1.0"
    assert str(Package("foobar", "1.0.0")) == "foobar==1.0.0"
    assert str(Package("foobar", ">1.0,<2.0")) == "foobar>1.0,<2.0"
    assert str(Package("foobar", ">1.0")) == "foobar>1.0"
    assert str(Package("foobar", "<2.0")) == "foobar<2.0"


# Generated at 2022-06-20 22:22:58.809481
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec=dict(
        virtualenv_command=dict(type='str', default='python'),
        virtualenv_python=dict(type='str', default=None),
        virtualenv_site_packages=dict(type='bool', default=False),
    ))
    assert isinstance(setup_virtualenv(module, 'env', 'dir', 'out', 'err'), tuple)



# Generated at 2022-06-20 22:23:05.739337
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def check(expected, req_str, pkg_str):
        req = Package(req_str)
        pkg = Package(pkg_str)
        if req.is_satisfied_by(pkg.package_name):
            req_version = pkg.package_name
        else:
            req_version = None
        if expected != req_version:
            print("%s should %s satisfy %s" % (req_str, "" if expected else "not", pkg_str))

    # Test with exact version number - we should get exact match.

# Generated at 2022-06-20 22:23:08.381979
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = Mock(params={'virtualenv_site_packages':True, 'virtualenv_command': '/usr/bin/virtualenv-3.6'})
    env = "/tmp/myvenv"
    chdir = "/tmp"
    out = ""
    err = ""
    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)

# -------------------------------------------------------------------
# MOCKS
# -------------------------------------------------------------------


# Generated at 2022-06-20 22:23:16.037308
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # test format n-m-o
    name = 'n-m-o'
    assert Package.canonicalize_name(name) == 'n-m-o'

    # test format n_m_o
    name = 'n_m_o'
    assert Package.canonicalize_name(name) == 'n-m-o'

    # test format n_m-o
    name = 'n_m-o'
    assert Package.canonicalize_name(name) == 'n-m-o'


# Generated at 2022-06-20 22:23:24.127419
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:23:33.210298
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package('pkg_name', '1.2.3')
    assert str(pkg) == 'pkg-name==1.2.3'

    pkg = Package('pkg_name')
    assert str(pkg) == 'pkg-name'

    pkg = Package('pkg_name!=2.0.0')
    assert str(pkg) == 'pkg-name!=2.0.0'

    pkg = Package('pkg_name>=3.0.0,<4.0.0')
    assert str(pkg) == 'pkg-name>=3.0.0,<4.0.0'

    pkg = Package('pkg_name~=4.0.0')
    assert str(pkg) == 'pkg-name~=4.0.0'

    pkg = Package('pkg_name')