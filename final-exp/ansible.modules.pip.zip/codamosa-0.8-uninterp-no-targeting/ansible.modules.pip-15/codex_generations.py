

# Generated at 2022-06-20 22:14:47.789703
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("aBc") == 'abc'
    assert Package.canonicalize_name("a-._Bc") == 'abc'
    assert Package.canonicalize_name("mypackage-test") == 'mypackage-test'
    assert Package.canonicalize_name("MYPACKAGE-TEST") == 'mypackage-test'



# Generated at 2022-06-20 22:14:54.824317
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    package = Package("pkg-name")
    assert package.canonicalize_name("PKG_Name") == "pkg-name"
    assert package.canonicalize_name("Pkg-Name.") == "pkg-name"
    assert package.canonicalize_name("Pkg_Name-") == "pkg-name"
    assert package.canonicalize_name("Pkg_Name-1.1.1") == "pkg-name-1.1.1"
    assert package.canonicalize_name("Pkg_Name-1.1.1-rc") == "pkg-name-1.1.1-rc"


# Generated at 2022-06-20 22:15:01.746974
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import StringIO
    import tempfile
    try:
        tf = tempfile.NamedTemporaryFile(delete=False)
        tf.write('')
        tf.close()
        out = StringIO.StringIO()
        err = StringIO.StringIO()
        if sys.version_info >= (2, 7):
            venv_cmd = 'virtualenv'
        else:
            venv_cmd = 'virtualenv'
        setup_virtualenv(tf.name, 'test_venv', venv_cmd, False, out, err)
        assert os.path.exists(tf.name)
    finally:
        os.unlink(tf.name)



# Generated at 2022-06-20 22:15:08.000285
# Unit test for method __str__ of class Package
def test_Package___str__():
    # test __str__ when package has version speciifier
    string_with_version = "pytest<2.10"
    package = Package(string_with_version)
    assert package.__str__() == string_with_version
    # test __str__ when package has no version speciifier
    string_without_version = "pytest"
    package = Package(string_without_version)
    assert package.__str__() == string_without_version


# Generated at 2022-06-20 22:15:15.871289
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('Pillow', '2.8.0')) == 'Pillow==2.8.0'
    assert str(Package('pillow', '2.8.0')) == 'pillow==2.8.0'

    # For this kind of package，
    # it can't be parsed into a requirement object
    # but we just want to get package name to do comparison
    assert str(Package('pillow', '<2.8.0')) == 'pillow'
    assert str(Package('pillow', '>2.8.0')) == 'pillow'



# Generated at 2022-06-20 22:15:22.780120
# Unit test for method __str__ of class Package
def test_Package___str__():
    def _test(name, version=None, out=None):
        p = Package(name, version)
        assert str(p) == out
    _test('foo', '1.0', 'foo==1.0')
    _test('foo', '>=1.0', 'foo>=1.0')
    _test('foo', '>=1.0,<2.0', 'foo>=1.0,<2.0')
    _test('foo', out='foo')
    _test('foo-bar-baz', out='foo-bar-baz')
    _test('foo_bar_baz', out='foo-bar-baz')
    _test('Foo Bar Baz', out='foo-bar-baz')
    _test('BAR', out='bar')

# Generated at 2022-06-20 22:15:34.483358
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p = Package('foo', '<=2.0')
    assert p.is_satisfied_by('2.0') is True
    assert p.is_satisfied_by('1.0') is True
    assert p.is_satisfied_by('2.1') is False
    p = Package('foo', '<2.0,>=1.0')
    assert p.is_satisfied_by('1.0') is True
    assert p.is_satisfied_by('1.5') is True
    assert p.is_satisfied_by('2.0') is False
    p = Package('foo', '==1.0,==2.0')
    assert p.is_satisfied_by('1.0') is True

# Generated at 2022-06-20 22:15:39.549123
# Unit test for method __str__ of class Package
def test_Package___str__():
    """Test method __str__ of class Package"""

    package_req = Package("setuptools", "==3.3")
    assert str(package_req) == "setuptools==3.3"
    package_req = Package("setuptools")
    assert str(package_req) == "setuptools"



# Generated at 2022-06-20 22:15:51.546002
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import shutil

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import pip_utils as pip

    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command='virtualenv',
            virtualenv_site_packages=False,
            virtualenv_python=None,
            chdir='/tmp',
            env=None,
        )
    )

    if not os.path.exists(module.params['chdir']):
        os.makedirs(module.params['chdir'])
    env = '%s/testenv' % module.params['chdir']
    out, err = pip.setup_virtualenv(module, env, module.params['chdir'], "", "")

    # s/b no virtualenvs, and

# Generated at 2022-06-20 22:15:54.059170
# Unit test for function main
def test_main():
    result = main()
    assert result == True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:16:52.288729
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    test_data = {
        'name': 'foo.bar_bar',
        'expected_output': 'foo-bar-bar'
    }
    assert Package.canonicalize_name(test_data['name']) == test_data['expected_output']



# Generated at 2022-06-20 22:16:53.343894
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv() == None



# Generated at 2022-06-20 22:16:58.492577
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("foo")) == "foo"
    assert str(Package("foo", "1.0")) == "foo==1.0"
    assert str(Package("foo", ">=1.0")) == "foo>=1.0"
    assert str(Package("foo", "<1.0")) == "foo<1.0"



# Generated at 2022-06-20 22:17:01.433853
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(None, None, None, None, None) == (None, None)


# Generated at 2022-06-20 22:17:07.525336
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    test_name = {
        "myPackage": "mypackage",
        "my-Package.with-more.parts": "my-package.with-more.parts",
        "MyPackage": "mypackage",
    }

    for real_name, canon_name in test_name.items():
        assert Package.canonicalize_name(real_name) == canon_name


# Generated at 2022-06-20 22:17:16.784359
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # This is a unit test for setup_virtualenv, only works in python3.6
    import ansible_collections.notstdlib.moveitallout.tests.unit.common.test_utils as test_utils
    from ansible_collections.notstdlib.moveitallout.plugins.modules import pip
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.process import get_bin_path
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.file import is_executable
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.pycompat24 as pycompat24
    import ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic as basic

# Generated at 2022-06-20 22:17:17.321586
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass


# Generated at 2022-06-20 22:17:28.683031
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('Foo_Bar.') == 'foo-bar'
    assert Package.canonicalize_name('Foo_Bar') == 'foo-bar'
    assert Package.canonicalize_name('Foo-Bar') == 'foo-bar'
    assert Package.canonicalize_name('foo-Bar') == 'foo-bar'
    assert Package.canonicalize_name('foo-Bar.is_here') == 'foo-bar-is-here'
    assert Package.canonicalize_name('foo-Bar_is._here') == 'foo-bar-is-here'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'



# Generated at 2022-06-20 22:17:33.295810
# Unit test for method __str__ of class Package

# Generated at 2022-06-20 22:17:39.199285
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    '''Test the Package class canonicalize_name method'''
    assert '-'.join(Package.canonicalize_name("Foo-bar").split()) == 'foo-bar'
    assert '-'.join(Package.canonicalize_name("foo_bar").split()) == 'foo-bar'
    assert '-'.join(Package.canonicalize_name("foo.bar").split()) == 'foo-bar'
    assert '-'.join(Package.canonicalize_name("FOOBAR").split()) == 'foobar'



# Generated at 2022-06-20 22:18:43.901819
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    cmd = 'pyvenv'
    cmd_list = shlex.split(cmd)
    assert cmd_list == ['pyvenv']

    cmd = 'virtualenv'
    cmd_list = shlex.split(cmd)
    assert cmd_list == ['virtualenv']

    cmd_list.append('--system-site-packages')
    assert cmd_list == ['virtualenv', '--system-site-packages']
    cmd_list.append('/tmp')
    assert cmd_list == ['virtualenv', '--system-site-packages', '/tmp']
# End of unit test



# Generated at 2022-06-20 22:18:52.378731
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    package = Package("foo")
    assert not package.is_satisfied_by("1.0")
    package = Package("foo", "> 1.0")
    assert package.is_satisfied_by("1.1")
    assert not package.is_satisfied_by("1.0")
    # test no version specifier
    package = Package("foo", "1.0")
    assert package.is_satisfied_by("1.0")
    assert not package.is_satisfied_by("1.1")
    # test equal version specifier
    package = Package("foo", "== 1.0")
    assert package.is_satisfied_by("1.0")

# Generated at 2022-06-20 22:19:01.385975
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    test_cases = (
        ('fooBarBaz', 'foobarbaz'),
        ('foo-Bar-Baz', 'foobarbaz'),
        ('foo_Bar_Baz', 'foobarbaz'),
        ('foo.Bar.Baz', 'foobarbaz'),
        ('fooBarBaz-BarBarBaz', 'foobarbaz-barbarbaz'),
        ('fooBarBaz-Bar_BarBaz', 'foobarbaz-barbarbaz'),
    )
    for arg, expected in test_cases:
        assert Package.canonicalize_name(arg) == expected



# Generated at 2022-06-20 22:19:04.831663
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Test to assert the function that calls setup_virtualenv
    assert setup_virtualenv(None, 'env', 'chdir', 'out', 'err') == ('outenv', 'errenv')


# Generated at 2022-06-20 22:19:17.363685
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert "foo" == str(Package("foo"))
    assert "foo==2.0" == str(Package("foo", "2.0"))
    assert "foo" == str(Package("Foo"))
    assert "foo-bar" == str(Package("Foo-Bar"))
    assert "foo-bar" == str(Package("Foo_Bar"))
    assert "foo-bar" == str(Package("Foo.Bar"))
    assert "foo-bar" == str(Package("foo-bar"))
    assert "foo-bar" == str(Package("foo.bar"))
    assert "foo-bar" == str(Package("foo_bar"))
    assert "foo-bar" == str(Package("foo--bar"))
    assert "foo-bar" == str(Package("foo__bar"))

# Generated at 2022-06-20 22:19:17.709878
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-20 22:19:18.863561
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-20 22:19:22.675144
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    name = 'PYthON-2_6-pytest-xdist'
    assert Package.canonicalize_name(name) == 'python-2-6-pytest-xdist'
    name = 'python_26'
    assert Package.canonicalize_name(name) == 'python-26'



# Generated at 2022-06-20 22:19:28.892573
# Unit test for constructor of class Package
def test_Package():

    def test_requirement(name_string, version_string=None, expected_plain_package=True):
        package = Package(name_string, version_string)
        assert package._plain_package == expected_plain_package
        if package._plain_package:
            assert package.package_name == package._requirement.project_name
            assert package.has_version_specifier == bool(version_string)

    # ## Test packages with version specifier
    test_requirement("requests>=2")
    test_requirement("requests", ">=2")

    # ## Test packages without version specifier
    test_requirement("requests")

    # ## Test packages with incompatible version specifier
    test_requirement("requests", "not-a-valid-version-specifier", expected_plain_package=False)

    #

# Generated at 2022-06-20 22:19:30.871966
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv() == "virtualenv_python should not be used when"



# Generated at 2022-06-20 22:21:44.780492
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert "setuptools" == str(Package("setuptools"))
    assert "setuptools==1.1" == str(Package("setuptools", "1.1"))
    assert "setuptools" == str(Package("setuptools", ">=1.1"))



# Generated at 2022-06-20 22:21:52.498677
# Unit test for function main
def test_main():
    import copy
    import filecmp
    import requests
    import shutil
    import tempfile
    import tarfile

    from ansible.module_utils import basic

    if not HAS_SETUPTOOLS:
        print('skipping due to missing setuptools')
        return

    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught in the test case"""
        pass

    class AnsibleFailJson(Exception):
        """Exception class to be raised by module.fail_json and caught in the test case"""
        pass

    def get_temp_dir(suffix=''):
        return tempfile.mkdtemp(suffix=suffix)


# Generated at 2022-06-20 22:21:59.577006
# Unit test for method __str__ of class Package
def test_Package___str__():
    p1 = Package(name_string='pip', version_string='==')
    assert str(p1) == 'pip=='
    p1 = Package(name_string='pip', version_string='>=')
    assert str(p1) == 'pip>='
    p1 = Package(name_string='pip', version_string='!=')
    assert str(p1) == 'pip!='
    p1 = Package(name_string='pip', version_string='<=')
    assert str(p1) == 'pip<='
    p1 = Package(name_string='pip', version_string='<')
    assert str(p1) == 'pip<'



# Generated at 2022-06-20 22:22:05.205078
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package("pkg", "==1.0.0")
    assert pkg.is_satisfied_by("1.0.0")

    pkg = Package("pkg", ">=1.0.0")
    assert pkg.is_satisfied_by("1.0.0")

    pkg = Package("pkg", ">=1.0.0,<=3.0.0")
    assert pkg.is_satisfied_by("1.0.0")
    assert pkg.is_satisfied_by("1.0.1")
    assert pkg.is_satisfied_by("2.0.0")
    assert pkg.is_satisfied_by("3.0.0")

    pkg = Package("pkg", ">3.0.0")
   

# Generated at 2022-06-20 22:22:17.045434
# Unit test for function main
def test_main():
    import random
    import StringIO
    import sys
    import tempfile
    import shutil
    import contextlib

    from ansible.module_utils import basic
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.pycompat24 import get_exception

    class AnsibleModuleMock(object):
        def __init__(self, **kwargs):
            self.params = kwargs

            self._debug = []
            self._log = []
            self._return = dict(
                changed=False,
                warnings=list(),
                rc=0,
            )

        def debug(self, msg):
            self._debug.append(msg)

        def log(self, msg):
            self._log.append(msg)


# Generated at 2022-06-20 22:22:28.861717
# Unit test for constructor of class Package
def test_Package():
    assert Package('foo')
    assert Package('foo', '1.2.3')
    assert Package('foo', '>=1.2.3')
    assert not Package('foo', '>=1.2.3').is_satisfied_by('1.2.2')
    assert Package('foo', '>=1.2.3').is_satisfied_by('1.2.3')
    assert Package('foo', '>=1.2.3').is_satisfied_by('1.2.4')
    assert not Package('foo', '>=1.2.3').is_satisfied_by('1.2.2')
    assert Package('foo', '~=1.2.3').is_satisfied_by('1.2.4')

# Generated at 2022-06-20 22:22:36.660444
# Unit test for constructor of class Package
def test_Package():
    # Test plain package without version specifier
    pkg = Package("foo")
    assert pkg.package_name == "foo"
    assert not pkg.has_version_specifier

    # Test plain package with version specifier
    pkg = Package("foo", ">=1.0, !=1.1")
    assert pkg.package_name == "foo"
    assert pkg.has_version_specifier

    # Test non-plain package without version specifier
    pkg = Package("foo[bar]")
    assert pkg.package_name == "foo[bar]"
    assert not pkg.has_version_specifier

    # Test non-plain package with version specifier
    pkg = Package("foo[bar]", ">=1.0, !=1.1")

# Generated at 2022-06-20 22:22:45.612383
# Unit test for constructor of class Package
def test_Package():
    assert(Package('test_package') is not None)
    assert(Package('test_package') == 'test_package')
    assert(Package('test_package==1.0.0') is not None)
    assert(Package('test_package==1.0.0').package_name == 'test_package')
    assert(Package('test_package==1.0.0').has_version_specifier)
    assert(str(Package('test_package==1.0.0')) == 'test_package==1.0.0')
    assert(Package('test_package').is_satisfied_by('1.0.0'))
    assert(not Package('test_package==1.0.0').is_satisfied_by('1.0.0'))

# Generated at 2022-06-20 22:22:50.179262
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    with pytest.raises(AssertionError) as exc_info:
        with pytest.raises(SystemExit):
            setup_virtualenv(None, None, None, None, None)
            sys.exit(test_setup_virtualenv())
    assert 'No active exception to reraise' in str(exc_info.value)



# Generated at 2022-06-20 22:23:01.584919
# Unit test for function setup_virtualenv
def test_setup_virtualenv():  # type: () -> None
    class ModuleMock(object):
        def __init__(self):
            self.params = {
                'virtualenv_command': 'virtualenv',
                'virtualenv_site_packages': False,
                'virtualenv_python': 'python2'
            }

        def fail_json(self, msg):
            raise Exception(msg)

        def check_mode(self):
            return False

        def get_bin_path(self, name, required, opt_dirs):
            return '/usr/bin/%s' % name

        def run_command(self, cmd, cwd=None, environ_update=None):
            return 0, '', ''

        def exit_json(self, changed=True):
            pass

    module = ModuleMock()