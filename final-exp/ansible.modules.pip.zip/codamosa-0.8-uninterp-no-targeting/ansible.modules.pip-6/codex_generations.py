

# Generated at 2022-06-20 22:14:41.421616
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 22:14:50.253561
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # some examples taken from http://legacy.python.org/dev/peps/pep-0503/
    assert Package.canonicalize_name('Foo Bar_Baz') == 'foo-bar-baz'
    assert Package.canonicalize_name('FooBar-Baz-1.2') == 'foobar-baz-1.2'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar-1.2') == 'foo-bar-1.2'
    assert Package.canonicalize_name('foo.bar_baz') == 'foo-bar-baz'



# Generated at 2022-06-20 22:14:52.063319
# Unit test for function main
def test_main():
    import unittest
    class TestMain(unittest.TestCase):
        pass
        #fixme
    unittest.main()



# Generated at 2022-06-20 22:15:04.348175
# Unit test for function main
def test_main():
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = False

    class FakeAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.check_mode = False
            self.fail_json = FakeModule.fail_json
            self.exit_json = FakeModule.exit_json


# Generated at 2022-06-20 22:15:14.727250
# Unit test for function main
def test_main():
    import imp

# Generated at 2022-06-20 22:15:27.183668
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-20 22:15:38.292542
# Unit test for constructor of class Package
def test_Package():
    assert str(Package('foo', '1.2.3')) == 'foo==1.2.3'
    assert str(Package('foo()=bar', '1.2.3')) == 'foo()=bar==1.2.3'
    assert str(Package('foo(baz)=bar', '1.2.3')) == 'foo(baz)=bar==1.2.3'
    assert str(Package('foo', '1.2.3')) == str(Package('foo(baz)=bar', '1.2.3'))
    assert str(Package('foo()=bar', '1.2.3')) == str(Package('foo(baz)=bar', '1.2.3'))

# Generated at 2022-06-20 22:15:46.949400
# Unit test for constructor of class Package
def test_Package():
    package = Package("pkgX[Y,Z]>=5.5,<6.0")
    assert package.package_name == "pkgx"
    assert package._requirement.project_name == "pkgx"
    assert package._requirement.specs == [('>=', '5.5'), ('<', '6.0')]
    assert package.has_version_specifier == True
    assert package.is_satisfied_by('5.5') == True
    assert package.is_satisfied_by('5.6') == True
    assert package.is_satisfied_by('5.5.1') == True
    assert package.is_satisfied_by('6') == False
    assert package.is_satisfied_by('6.0') == False
    assert package.is_satisf

# Generated at 2022-06-20 22:15:56.049634
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("foo") == "foo"
    assert Package.canonicalize_name("foo-bar") == "foo-bar"
    assert Package.canonicalize_name("foo-BAR-baz") == "foo-bar-baz"
    assert Package.canonicalize_name("foo-bar-baz") == "foo-bar-baz"
    assert Package.canonicalize_name("foo-2.10_bar.baz") == "foo-2-10-bar-baz"
    assert Package.canonicalize_name("foo_bar_baz") == "foo-bar-baz"


# ==============================================================
# Main control flow.
#

# Generated at 2022-06-20 22:16:07.357810
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('X', '1.0')) == 'X==1.0'
    assert str(Package('X', '==1.0')) == 'X==1.0'
    assert str(Package('X', '>=1.0')) == 'X>=1.0'
    assert str(Package('X', '>=1.0,<2.0')) == 'X>=1.0,<2.0'
    assert str(Package('X', '>=1.0,<2.0,!=1.1')) == 'X>=1.0,!=1.1,<2.0'

# Generated at 2022-06-20 22:16:36.771886
# Unit test for method __str__ of class Package
def test_Package___str__():
    obj = Package('a')
    assert "a" == str(obj)
    obj = Package('a', '1.0')
    assert "a==1.0" == str(obj)
    obj = Package('a', '1.0,<2.0')
    assert "a==1.0,<2.0" == str(obj)



# Generated at 2022-06-20 22:16:47.660837
# Unit test for constructor of class Package

# Generated at 2022-06-20 22:16:59.226878
# Unit test for constructor of class Package

# Generated at 2022-06-20 22:17:08.650954
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert Package("argparse", "1.2.1").__str__() == "argparse==1.2.1"
    assert Package("argparse", ">=1.2.1").__str__() == "argparse>=1.2.1"
    assert Package("argparse==1.2.1").__str__() == "argparse==1.2.1"
    assert Package("argparse>=1.2.1").__str__() == "argparse>=1.2.1"


# Generated at 2022-06-20 22:17:14.222260
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    p = Package("NaMe-v3r$i0n")
    assert p.package_name == "name-version"
    p = Package("NaMe-v3r$i0n", "3.1.4")
    assert p.package_name == "name-version"
    assert p.has_version_specifier
    assert p.is_satisfied_by("3.1.4")


# Generated at 2022-06-20 22:17:20.041575
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    p = Package("Test")
    assert p.canonicalize_name("Test-Package") == "test-package"
    assert p.canonicalize_name("Test_Package") == "test-package"
    assert p.canonicalize_name("Test.Package") == "test-package"
    assert p.canonicalize_name("Test---Package") == "test-package"



# Generated at 2022-06-20 22:17:32.578578
# Unit test for function main

# Generated at 2022-06-20 22:17:40.142889
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('foo')) == 'foo'
    assert str(Package('bar', '1.2')) == 'bar==1.2'
    assert str(Package('foo', '>1')) == 'foo>1'
    assert str(Package('foo', '>=1,<2')) == 'foo>=1,<2'
    assert str(Package('foo', '==1.*')) == 'foo==1.*'
    assert str(Package('foo', '~=1.2')) == 'foo~=1.2'
    assert str(Package('foo', '>=1,!=1.1,<2.0')) == 'foo>=1,!=1.1,<2.0'



# Generated at 2022-06-20 22:17:45.993184
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    fp = open(os.path.join(os.path.dirname(__file__), 'canonicalize_name_testcases.json'), 'rb')
    data = json.load(fp, 'utf-8')
    fp.close()
    for index in data:
        assert Package.canonicalize_name(index['in']) == index['out']



# Generated at 2022-06-20 22:17:57.929141
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module_args = {'virtualenv_command': '/usr/bin/virtualenv',
                   'virtualenv_site_packages': False,
                   'state': 'present',
                   'src_dir': '/home/redhat/ansible/modules/extras/cloud/redhat/openstack/rhos-release/'}
    # import module snippets
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=module_args)
    env = '/home/redhat/ansible/modules/extras/cloud/redhat/openstack/rhos-release/test_venv'
    chdir = '/home/redhat/ansible/modules/extras/cloud/redhat/openstack/rhos-release/'

# Generated at 2022-06-20 22:18:53.695453
# Unit test for function setup_virtualenv
def test_setup_virtualenv(): pass



# Generated at 2022-06-20 22:19:05.288514
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("ansible") == "ansible"
    assert Package.canonicalize_name("ansible-core") == "ansible-core"
    assert Package.canonicalize_name("ansible-core-extras") == "ansible-core-extras"
    assert Package.canonicalize_name("ansible_core_extras") == "ansible-core-extras"
    assert Package.canonicalize_name("ansible.core.extras") == "ansible-core-extras"
    assert Package.canonicalize_name("ansible-1.9.2") == "ansible-1-9-2"
    assert Package.canonicalize_name("ansible_1.9.2") == "ansible-1-9-2"
    assert Package.canonicalize_

# Generated at 2022-06-20 22:19:18.234695
# Unit test for constructor of class Package
def test_Package():
    p = Package("foo")
    assert p.package_name == "foo"
    assert p.has_version_specifier is False
    p = Package("foo", "==1.2.3")
    assert p.package_name == "foo"
    assert p.has_version_specifier is True
    assert p.is_satisfied_by("1.2.3") is True
    assert p.is_satisfied_by("1.2.4") is False
    p = Package("foo", "!=1.2.3")
    assert p.package_name == "foo"
    assert p.has_version_specifier is True
    assert p.is_satisfied_by("1.2.4") is True
    assert p.is_satisfied_by("1.2.3") is False

# Generated at 2022-06-20 22:19:26.911300
# Unit test for function main

# Generated at 2022-06-20 22:19:39.362305
# Unit test for method __str__ of class Package
def test_Package___str__():
    package = Package('pip')
    assert str(package) == 'pip'
    package = Package('pip', '10.0.2')
    assert str(package) == 'pip==10.0.2'
    package = Package('py-bcrypt', '==3.1.4')
    assert str(package) == 'py-bcrypt==3.1.4'
    package = Package('py-bcrypt', '>=3.1.4')
    assert str(package) == 'py-bcrypt>=3.1.4'
    package = Package('py-bcrypt', '>=3.1.4,==3.1.4')
    assert str(package) == 'py-bcrypt==3.1.4,>=3.1.4'



# Generated at 2022-06-20 22:19:50.553084
# Unit test for function main
def test_main():
    # pylint: disable=too-many-statements,too-many-locals,too-many-branches
    from ansible.compat.tests.mock import patch, MagicMock

    def _setuptools(name):
        if name == 'setuptools':
            return MagicMock()
        else:
            raise ImportError()

    def _virtualenv(name):
        if name == 'virtualenv':
            return MagicMock()
        else:
            raise ImportError()
    module = MagicMock()
    module.run_command = MagicMock()
    module.params = {}

    venv = MagicMock()
    venv.system_site_packages = False
    venv.created = False


# Generated at 2022-06-20 22:19:58.963815
# Unit test for method __str__ of class Package
def test_Package___str__():
    def _test(name_string, version_string, expected_output):
        pkg = Package(name_string, version_string)
        assert str(pkg) == expected_output
    # Test with a package name.
    _test('six', None, 'six')
    _test('six', '', 'six')
    _test('six', ' ', 'six')
    _test('six', '1', 'six==1')
    _test('six', '<=1.9', 'six<=1.9')
    _test('six', '<1.9', 'six<1.9')
    _test('six', '>=1.9', 'six>=1.9')
    _test('six', '>1.9', 'six>1.9')

# Generated at 2022-06-20 22:20:03.854605
# Unit test for function main
def test_main():
    # Test case 1
    # Test when requirements file is specified
    # and state is present
    # run module and get result
    result = run_module('pip', {'requirements': 'test_requirements.txt', 'state': 'present'})
    # assert we succeeded
    assert result['rc'] == 0
    assert result['changed']


# Generated at 2022-06-20 22:20:10.182030
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Test if str(Package(<package name>)) is <package name>
    assert str(Package('setuptools')) == 'setuptools'
    # Test if str(Package(<package name>, <version>)) is <package name>==<version>
    assert str(Package('setuptools', '24.0.2')) == 'setuptools==24.0.2'



# Generated at 2022-06-20 22:20:16.709159
# Unit test for constructor of class Package
def test_Package():
    plain_name = "abc"
    plain_version = "2.3"
    plain_string = "-e git://github.com/bcoe/path.py#egg=path.py-dev"
    plain_combined_string = "abc==2.3"

    with pytest.raises(ValueError):
        # test for non-plain
        Package(plain_name, plain_version)
    with pytest.raises(ValueError):
        # test for non-plain
        Package(plain_combined_string)
    with pytest.raises(ValueError):
        # test for non-plain
        Package(plain_string)


# Generated at 2022-06-20 22:22:26.879575
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("setuptools", "1.0")) == "setuptools==1.0"
    assert str(Package("setuptools")) == "setuptools"



# Generated at 2022-06-20 22:22:32.577740
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("ABC") == "abc"
    assert Package.canonicalize_name("ABC-DEF") == "abc-def"
    assert Package.canonicalize_name("abc.def") == "abc-def"
    assert Package.canonicalize_name("abc_def") == "abc-def"
    assert Package.canonicalize_name("__init__") == "__init__"


# Generated at 2022-06-20 22:22:37.882418
# Unit test for method __str__ of class Package
def test_Package___str__():
    package = Package('test-package', '<=0.1.0')
    assert str(package) == 'test-package<=0.1.0'



# Generated at 2022-06-20 22:22:44.374875
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('pip')) == 'pip'
    assert str(Package('pip', '1.4.1')) == 'pip==1.4.1'
    assert str(Package('flask', '==0.10.1')) == 'flask==0.10.1'
    # old pip will accept pkg name with ==.  But will not generate such
    # name in the output.
    assert str(Package('pip==', '1.4.1')) == 'pip==1.4.1'



# Generated at 2022-06-20 22:22:47.089713
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('My_PaCkAgE') == 'my-package'
    assert Package.canonicalize_name('My_PaCkAgE-1.0.12') == 'my-package-1.0.12'



# Generated at 2022-06-20 22:22:47.616820
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-20 22:22:49.423700
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv() == 0



# Generated at 2022-06-20 22:23:00.827983
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test method is_satisfied_by of class Package.

    # Test case 1: no version requirement specifier
    pkg = Package("pip")
    assert pkg.is_satisfied_by("1.5.6") == True

    # Test case 2: version requirement is ">=1.2"
    pkg = Package("wheel", ">=1.2")
    assert pkg.is_satisfied_by("1.2") == True
    assert pkg.is_satisfied_by("1.1") == False
    assert pkg.is_satisfied_by("1.3") == True
    assert pkg.is_satisfied_by("1.3.3") == True
    assert pkg.is_satisfied_by("2.0.0") == True

# Generated at 2022-06-20 22:23:04.628591
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Test for string with version
    pkg = Package("TestPackage", "1.0")
    assert str(pkg) == "TestPackage==1.0"
    pkg = Package("TestPackage", "1.0b2")
    assert str(pkg) == "TestPackage==1.0b2"
    # Test for plain string (no version)
    pkg = Package("TestPackage")
    assert str(pkg) == "TestPackage"



# Generated at 2022-06-20 22:23:08.685463
# Unit test for function main
def test_main():
    arguments = {
        'state': 'present',
        'name':[],
        'version':None,
        'requirements':None,
        'virtualenv':None,
        'virtualenv_site_packages':False,
        'virtualenv_command':'virtualenv',
        'virtualenv_python':None,
        'extra_args':None,
        'editable':False,
        'chdir':None,
        'executable':None,
        'umask':None
    }
    main(arguments)


main()