

# Generated at 2022-06-17 04:57:50.794423
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = 'test_env'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 04:58:00.608515
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv=dict(default=None),
            chdir=dict(default=None),
        ),
        supports_check_mode=True
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out
    assert not err


# Generated at 2022-06-17 04:58:09.283005
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import json
    import re
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six.moves import filter
    from ansible.module_utils.six.moves import input


# Generated at 2022-06-17 04:58:12.407152
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        )
    )
    env = 'test_env'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 04:58:23.160032
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-17 04:58:30.405236
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'default': '/usr/bin/virtualenv', 'type': 'str'},
        'virtualenv_python': {'default': None, 'type': 'str'},
        'virtualenv_site_packages': {'default': False, 'type': 'bool'},
    })
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    shutil.rmtree(env)



# Generated at 2022-06-17 04:58:38.640902
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Test with virtualenv_command = 'virtualenv'
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv', type='str'),
            virtualenv_python=dict(default=None, type='str'),
            virtualenv_site_packages=dict(default=False, type='bool'),
        )
    )
    env = 'test_env'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''

    # Test with virtualenv_command = 'pyvenv'

# Generated at 2022-06-17 04:58:42.665220
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(module, env, chdir, out, err) == (out_venv, err_venv)



# Generated at 2022-06-17 04:58:49.486764
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out
    assert not err



# Generated at 2022-06-17 04:58:55.815405
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 04:59:33.026371
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import get_exception
    import ansible.module_utils.pip_utils as pip_utils
    import tempfile
    import shutil
    import os
    import sys


# Generated at 2022-06-17 04:59:41.463892
# Unit test for function main

# Generated at 2022-06-17 04:59:51.479692
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = '/tmp/ansible-test-virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)


# Generated at 2022-06-17 05:00:00.261791
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'type': 'str', 'default': 'virtualenv'},
        'virtualenv_python': {'type': 'str', 'default': None},
        'virtualenv_site_packages': {'type': 'bool', 'default': False},
    })
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    shutil.rmtree(env)



# Generated at 2022-06-17 05:00:09.067614
# Unit test for constructor of class Package
def test_Package():
    # Test for plain package
    pkg = Package('pip')
    assert pkg.package_name == 'pip'
    assert pkg.has_version_specifier is False
    assert pkg.is_satisfied_by('1.0') is False
    assert str(pkg) == 'pip'

    # Test for package with version specifier
    pkg = Package('pip', '>=1.0')
    assert pkg.package_name == 'pip'
    assert pkg.has_version_specifier is True
    assert pkg.is_satisfied_by('1.0') is True
    assert pkg.is_satisfied_by('0.9') is False
    assert str(pkg) == 'pip>=1.0'

    # Test for package with version specifier


# Generated at 2022-06-17 05:00:14.677586
# Unit test for function main

# Generated at 2022-06-17 05:00:25.374536
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(argument_spec={})
    assert module.fail_json.called
    # Test with no valid parameters

# Generated at 2022-06-17 05:00:37.133044
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for package with version specifier
    pkg = Package('foo', '>=1.0,!=1.3.0,<2.0')
    assert pkg.is_satisfied_by('1.2.0')
    assert not pkg.is_satisfied_by('1.3.0')
    assert not pkg.is_satisfied_by('2.0.0')
    assert not pkg.is_satisfied_by('0.9.0')
    assert pkg.is_satisfied_by('1.0.0')
    assert pkg.is_satisfied_by('1.1.0')
    assert pkg.is_satisfied_by('1.1.1')

# Generated at 2022-06-17 05:00:47.085620
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package('foo', '>=1.0,<2.0')
    assert pkg.is_satisfied_by('1.1')
    assert not pkg.is_satisfied_by('2.0')
    assert not pkg.is_satisfied_by('0.9')

    pkg = Package('foo', '>=1.0,<2.0,!=1.5')
    assert pkg.is_satisfied_by('1.1')
    assert pkg.is_satisfied_by('1.4')
    assert not pkg.is_satisfied_by('1.5')
    assert not pkg.is_satisfied_by('2.0')
    assert not pkg.is_satisfied_by('0.9')

    p

# Generated at 2022-06-17 05:00:55.944005
# Unit test for function main

# Generated at 2022-06-17 05:01:47.637152
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for plain package
    pkg = Package('foo')
    assert not pkg.is_satisfied_by('1.0')
    pkg = Package('foo', '1.0')
    assert pkg.is_satisfied_by('1.0')
    pkg = Package('foo', '>1.0')
    assert pkg.is_satisfied_by('2.0')
    pkg = Package('foo', '>1.0,<2.0')
    assert pkg.is_satisfied_by('1.5')
    assert not pkg.is_satisfied_by('2.0')
    pkg = Package('foo', '>1.0,<2.0,!=1.5')

# Generated at 2022-06-17 05:01:56.239763
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = 'test_env'
    chdir = 'test_chdir'
    out = 'test_out'
    err = 'test_err'
    out_venv = 'test_out_venv'
    err_venv = 'test_err_venv'
    module.run_command = MagicMock(return_value=(0, out_venv, err_venv))
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == out_venv


# Generated at 2022-06-17 05:02:05.654013
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    import sys
    import os
    import tempfile
    import shutil

    def _get_pip(module, env, executable):
        if executable:
            pip = executable
        elif env:
            pip = os.path.join(env, 'bin', 'pip')
        else:
            pip = module.get_bin_path('pip', True)
        return pip

    def _get_packages(module, pip, chdir):
        pkg_cmd = pip + ['freeze']
        rc, out, err = module.run_command(pkg_cmd, cwd=chdir)

# Generated at 2022-06-17 05:02:15.375874
# Unit test for function main

# Generated at 2022-06-17 05:02:25.493527
# Unit test for function main

# Generated at 2022-06-17 05:02:31.664386
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True,
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:02:39.389901
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv=dict(default=None),
            chdir=dict(default=None),
        ),
        supports_check_mode=True,
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 05:02:51.992476
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map
    from ansible.module_utils.six.moves import filter

# Generated at 2022-06-17 05:03:01.221423
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pip import HAS_SETUPTOOLS, SETUPTOOLS_IMP_ERR, missing_required_lib, _get_pip, _get_packages, _is_present, _fail, _recover_package_name, _is_vcs_url, _get_package_info, setup_virtualenv, Package
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import shlex_quote

# Generated at 2022-06-17 05:03:10.706599
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE_STR
    from ansible.module_utils.parsing.convert_bool import B

# Generated at 2022-06-17 05:05:22.536010
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={'virtualenv_command': dict(type='str', default='virtualenv'),
                                          'virtualenv_python': dict(type='str', default=None),
                                          'virtualenv_site_packages': dict(type='bool', default=False)})
    env = 'test_env'
    chdir = 'test_chdir'
    out = 'test_out'
    err = 'test_err'
    assert setup_virtualenv(module, env, chdir, out, err) == ('test_out', 'test_err')


# Generated at 2022-06-17 05:05:32.576855
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'Missing required arguments: name or requirements'

    # Test with name and requirements
    module = AnsibleModule(argument_spec={'name': 'test', 'requirements': 'test'})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'name and requirements are mutually exclusive'

    # Test with name and requirements
    module = AnsibleModule(argument_spec={'name': 'test', 'requirements': 'test'})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'name and requirements are mutually exclusive'

    # Test with name and requirements

# Generated at 2022-06-17 05:05:47.971756
# Unit test for function main

# Generated at 2022-06-17 05:05:52.730169
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 05:06:06.693454
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import tempfile
    import shutil
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            if arg == 'python':
                return sys.executable
            if arg == 'virtualenv':
                return 'virtualenv'
            if arg == 'pyvenv':
                return

# Generated at 2022-06-17 05:06:10.135855
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        )
    )
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:06:16.005098
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes, to_native

# Generated at 2022-06-17 05:06:16.845021
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:06:18.874622
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)


# Generated at 2022-06-17 05:06:25.854299
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # test for old setuptools
    pkg = Package("setuptools", ">=0.6c11")
    assert pkg.is_satisfied_by("0.6c11")
    assert pkg.is_satisfied_by("0.6c12")
    assert not pkg.is_satisfied_by("0.6c10")

    # test for new setuptools
    pkg = Package("setuptools", ">=0.6c11,!=0.6c12,!=0.6c13,<1")
    assert pkg.is_satisfied_by("0.6c11")
    assert not pkg.is_satisfied_by("0.6c12")
    assert not pkg.is_satisfied_by("0.6c13")