

# Generated at 2022-06-17 04:57:41.633042
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-17 04:57:50.895737
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv=dict(default=None),
            chdir=dict(default=None),
        ),
        supports_check_mode=True
    )
    env = '/tmp/ansible_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    assert os.path.exists(env)


# Generated at 2022-06-17 04:57:54.313424
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # TODO: Implement unit test
    pass



# Generated at 2022-06-17 04:58:04.225371
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('foo')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier is False
    assert pkg.is_satisfied_by('1.0') is False
    assert str(pkg) == 'foo'

    pkg = Package('foo', '1.0')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier is True
    assert pkg.is_satisfied_by('1.0') is True
    assert str(pkg) == 'foo==1.0'

    pkg = Package('foo', '>1.0')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier is True

# Generated at 2022-06-17 04:58:09.662938
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = 'test_env'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 04:58:16.114911
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    import ansible.module_utils.six as six
    import sys

    if six.PY3:
        builtin_module_name = 'builtins'
    else:
        builtin_module_name = '__builtin__'

    # inject specific class into builtins for testing
    # pylint: disable=unused-variable
    class MockBuiltin(object):
        ''' mock builtin functions '''
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __call__(self, *args, **kwargs):
            if args:
                self.args = args

# Generated at 2022-06-17 04:58:19.306862
# Unit test for function main
def test_main():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:58:27.525470
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'One of the following is required: name, requirements'

    # Test with name and requirements
    module = AnsibleModule(argument_spec={'name': 'foo', 'requirements': 'bar'})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'name and requirements are mutually exclusive'

    # Test with name and executable
    module = AnsibleModule(argument_spec={'name': 'foo', 'executable': 'bar'})
    result = main()
    assert result['failed'] == True
    assert result['msg'] == 'executable and virtualenv are mutually exclusive'

    # Test with name and virtualenv

# Generated at 2022-06-17 04:58:29.134642
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)



# Generated at 2022-06-17 04:58:34.952795
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 04:59:09.554294
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-17 04:59:15.274082
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-17 04:59:24.320420
# Unit test for function main
def test_main():
    import json
    import os
    import shutil
    import sys
    import tempfile
    import time
    import traceback
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import urllib
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import urlopen

# Generated at 2022-06-17 04:59:30.925321
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    env = '/tmp/virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out != ''
    assert err == ''



# Generated at 2022-06-17 04:59:35.320538
# Unit test for function main

# Generated at 2022-06-17 04:59:42.736522
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import tempfile
    import shutil
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote

    class TestModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self.run_command_environ_update = dict()


# Generated at 2022-06-17 04:59:54.806313
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 05:00:05.407037
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import ContentTooShortError
    from ansible.module_utils.pip import HAS_SETUPTOOLS
    from ansible.module_utils.pip import SET

# Generated at 2022-06-17 05:00:15.387338
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec=dict(
        virtualenv_command=dict(default='virtualenv'),
        virtualenv_python=dict(default=None),
        virtualenv_site_packages=dict(default=False, type='bool'),
        virtualenv=dict(default=None),
        chdir=dict(default=None),
    ))
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:00:24.546352
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv=dict(default=None),
            chdir=dict(default=None),
        ),
        supports_check_mode=True,
    )
    env = module.params['virtualenv']
    chdir = module.params['chdir']
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:00:53.809895
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)


# Generated at 2022-06-17 05:01:03.542610
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package("foo", ">=1.0")
    assert pkg.is_satisfied_by("1.0")
    assert pkg.is_satisfied_by("1.1")
    assert not pkg.is_satisfied_by("0.9")

    pkg = Package("foo", ">=1.0,<2.0")
    assert pkg.is_satisfied_by("1.0")
    assert pkg.is_satisfied_by("1.1")
    assert not pkg.is_satisfied_by("2.0")
    assert not pkg.is_satisfied_by("0.9")

    pkg = Package("foo", ">=1.0,!=1.1")
    assert pkg.is_satisfied_

# Generated at 2022-06-17 05:01:12.576231
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(default='virtualenv'),
        'virtualenv_python': dict(default=None),
        'virtualenv_site_packages': dict(default=False, type='bool'),
    })
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)



# Generated at 2022-06-17 05:01:17.504406
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(default='virtualenv'),
        'virtualenv_python': dict(default=None),
        'virtualenv_site_packages': dict(default=False),
    })
    env = 'test_env'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:01:23.892862
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlunparse

# Generated at 2022-06-17 05:01:35.354751
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def test_case(name_string, version_string, version_to_test, expected_result):
        package = Package(name_string, version_string)
        assert package.is_satisfied_by(version_to_test) == expected_result

    test_case('foo', '>=1.2,!=1.3.0,<2.0', '1.2.0', True)
    test_case('foo', '>=1.2,!=1.3.0,<2.0', '1.3.0', False)
    test_case('foo', '>=1.2,!=1.3.0,<2.0', '1.4.0', True)

# Generated at 2022-06-17 05:01:45.846935
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    def _get_pip(module, env, executable):
        if env:
            pip = os.path.join(env, 'bin', 'pip')
        elif executable:
            pip = executable
        else:
            pip = module.get_bin_path('pip', True)
        return pip

    def _get_packages(module, pip, chdir):
        cmd = [pip, 'freeze']

# Generated at 2022-06-17 05:01:56.367563
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import shutil
    import os
    import sys
    import stat
    import subprocess
    import platform
    import json
    import pytest
    from ansible.module_utils.six.moves import StringIO

    def _create_virtualenv(module, env, chdir, out, err):
        cmd = [module.params['virtualenv_command'], env]
        if module.params['virtualenv_site_packages']:
            cmd.append('--system-site-packages')
        else:
            cmd_opts = _get_cmd_options(module, cmd[0])
            if '--no-site-packages' in cmd_opts:
                cmd.append('--no-site-packages')


# Generated at 2022-06-17 05:02:05.898839
# Unit test for function main
def test_main():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import install_opener

# Generated at 2022-06-17 05:02:10.892592
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:03:08.330519
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv_extra_search_dir=dict(default=None),
        ),
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)



# Generated at 2022-06-17 05:03:20.601353
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv=dict(default=None),
            chdir=dict(default=None),
        ),
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)



# Generated at 2022-06-17 05:03:30.811003
# Unit test for function main

# Generated at 2022-06-17 05:03:41.260631
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for version specifier
    pkg = Package('foo', '>=1.0,<2.0')
    assert pkg.is_satisfied_by('1.0')
    assert pkg.is_satisfied_by('1.1')
    assert not pkg.is_satisfied_by('2.0')
    assert not pkg.is_satisfied_by('0.9')

    # Test for version specifier with pre-release
    pkg = Package('foo', '>=1.0,<2.0')
    assert pkg.is_satisfied_by('1.0a1')
    assert pkg.is_satisfied_by('1.1a1')
    assert not pkg.is_satisfied_by('2.0a1')

# Generated at 2022-06-17 05:03:54.910430
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('foo')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier == False
    assert pkg.is_satisfied_by('1.0') == False
    assert str(pkg) == 'foo'

    pkg = Package('foo', '1.0')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier == True
    assert pkg.is_satisfied_by('1.0') == True
    assert str(pkg) == 'foo==1.0'

    pkg = Package('foo', '>=1.0')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier == True

# Generated at 2022-06-17 05:04:01.144670
# Unit test for function main

# Generated at 2022-06-17 05:04:13.658563
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for case with version specifier
    pkg = Package('foo', '>=1.0,!=1.3,<2.0')
    assert pkg.is_satisfied_by('1.1')
    assert pkg.is_satisfied_by('1.2')
    assert not pkg.is_satisfied_by('1.3')
    assert not pkg.is_satisfied_by('2.0')
    assert not pkg.is_satisfied_by('0.9')

    # Test for case without version specifier
    pkg = Package('foo')
    assert pkg.is_satisfied_by('1.1')
    assert pkg.is_satisfied_by('1.2')

# Generated at 2022-06-17 05:04:20.960455
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for package with version specifier
    package = Package('foo', '>=1.0,<2.0')
    assert package.is_satisfied_by('1.0')
    assert package.is_satisfied_by('1.5')
    assert not package.is_satisfied_by('2.0')
    assert not package.is_satisfied_by('0.5')

    # Test for package without version specifier
    package = Package('foo')
    assert package.is_satisfied_by('1.0')
    assert package.is_satisfied_by('1.5')
    assert package.is_satisfied_by('2.0')
    assert package.is_satisfied_by('0.5')

    # Test for package with version specifier and pre-release

# Generated at 2022-06-17 05:04:21.642404
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv() == "test"


# Generated at 2022-06-17 05:04:28.813885
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary virtualenv
    venv = os.path.join(tmpdir, 'venv')
    os.mkdir(venv)

    # Create a temporary requirements file
    reqs = os.path.join(tmpdir, 'reqs.txt')
    with open(reqs, 'w') as f:
        f.write('pytest')

    # Create a temporary ansible.cfg
    cfg = os.path.join(tmpdir, 'ansible.cfg')
    with open(cfg, 'w') as f:
        f.write('[defaults]\nroles_path=%s\n' % tmpdir)

    # Create a temporary role

# Generated at 2022-06-17 05:06:35.699787
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pip import HAS_SETUPTOOLS, SETUPTOOLS_IMP_ERR
    from ansible.module_utils.pip import _get_pip, _get_packages, _is_present, _get_package_info, _fail, _recover_package_name
    from ansible.module_utils.pip import _is_vcs_url, _get_cmd_options, setup_virtualenv, Package
    from ansible.module_utils.pip import main
    from ansible.module_utils.pip import state_map
    from ansible.module_utils.pip import _CANONICALIZE_RE
    from ansible.module_utils.pip import _CANONICALIZE_RE

# Generated at 2022-06-17 05:06:46.415086
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:06:59.361525
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:07:06.603287
# Unit test for function main