

# Generated at 2022-06-17 04:57:48.310754
# Unit test for function main

# Generated at 2022-06-17 04:57:58.457330
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # test for normal package name
    pkg = Package("ansible")
    assert not pkg.is_satisfied_by("2.0.0.0b1")
    assert not pkg.is_satisfied_by("2.0.0.0rc1")
    assert not pkg.is_satisfied_by("2.0.0.0")
    assert not pkg.is_satisfied_by("2.0.0.0.post1")
    assert not pkg.is_satisfied_by("2.0.0.0.dev1")
    assert not pkg.is_satisfied_by("2.0.0.0a1")
    assert not pkg.is_satisfied_by("2.0.0.0b2")

# Generated at 2022-06-17 04:58:05.744920
# Unit test for constructor of class Package
def test_Package():
    # test for normal package name
    pkg = Package('foo')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier is False
    assert pkg.is_satisfied_by('1.0') is False
    assert str(pkg) == 'foo'

    # test for package name with version specifier
    pkg = Package('foo', '>=1.0')
    assert pkg.package_name == 'foo'
    assert pkg.has_version_specifier is True
    assert pkg.is_satisfied_by('1.0') is True
    assert pkg.is_satisfied_by('0.9') is False
    assert str(pkg) == 'foo>=1.0'

    # test for package name with version specifier
    pkg

# Generated at 2022-06-17 04:58:19.680610
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pip import HAS_SETUPTOOLS, SETUPTOOLS_IMP_ERR
    from ansible.module_utils.pip import _get_pip, _get_packages, _is_present, _fail, _recover_package_name, _is_vcs_url, _get_package_info
    from ansible.module_utils.pip import setup_virtualenv, Package
    from ansible.module_utils.pip import main
    from ansible.module_utils.pip import state_map
    from ansible.module_utils.pip import HAS_SETUPTOOLS, SETUPTOOLS_IMP_ERR
    from ansible.module_utils.pip import _get_pip

# Generated at 2022-06-17 04:58:21.433479
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:58:27.524651
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'type': 'str', 'default': 'virtualenv'},
        'virtualenv_python': {'type': 'str'},
        'virtualenv_site_packages': {'type': 'bool', 'default': False},
    })
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 04:58:36.670311
# Unit test for function main

# Generated at 2022-06-17 04:58:39.917634
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-17 04:58:49.533954
# Unit test for function main
def test_main():
    import subprocess
    import os
    import sys
    import tempfile
    import shutil
    import stat
    import time
    import platform
    import re
    import json
    import types
    import copy
    import glob
    import textwrap
    import contextlib
    import io
    import shlex
    import pkg_resources
    import warnings
    import zipfile
    import tarfile
    import hashlib
    import base64
    import binascii
    import datetime
    import random
    import string
    import inspect
    import logging
    import collections
    import functools
    import itertools
    import threading
    import multiprocessing
    import socket
    import select
    import errno
    import fcntl
    import asyncore
    import asynchat
    import signal

# Generated at 2022-06-17 04:58:54.442128
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(),
            virtualenv_site_packages=dict(type='bool', default=False),
        ),
    )
    env = '/tmp/venv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 04:59:38.495493
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True,
    )
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 04:59:50.917440
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import subprocess
    import platform
    import time
    import re
    import pkg_resources
    import pkgutil
    import textwrap
    import pytest
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import string_types

# Generated at 2022-06-17 04:59:59.969289
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test cases for Package.is_satisfied_by
    # Test case 1:
    #   input:
    #       package_name = 'foo'
    #       version_to_test = '1.0'
    #   expected:
    #       False
    package_name = 'foo'
    version_to_test = '1.0'
    p = Package(package_name)
    assert not p.is_satisfied_by(version_to_test)

    # Test case 2:
    #   input:
    #       package_name = 'foo==1.0'
    #       version_to_test = '1.0'
    #   expected:
    #       True
    package_name = 'foo==1.0'
    version_to_test = '1.0'
    p

# Generated at 2022-06-17 05:00:10.471205
# Unit test for function main

# Generated at 2022-06-17 05:00:18.503159
# Unit test for function main
def test_main():
    # Test with no arguments
    module = AnsibleModule(argument_spec={})
    result = main()
    assert result['failed']
    assert result['msg'] == "No valid name or requirements file found."

    # Test with name and version

# Generated at 2022-06-17 05:00:28.389618
# Unit test for function main

# Generated at 2022-06-17 05:00:37.789134
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 05:00:47.144904
# Unit test for function main

# Generated at 2022-06-17 05:00:56.784839
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True,
    )
    env = 'test_env'
    chdir = 'test_dir'
    out = 'test_out'
    err = 'test_err'
    out_venv, err_venv = setup_virtualenv(module, env, chdir, out, err)
    assert out_venv == out
    assert err_venv == err


# Generated at 2022-06-17 05:01:02.499381
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:01:33.326719
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for a package with version specifier
    package = Package('pytest', '>=2.8.0')
    assert package.is_satisfied_by('2.8.0')
    assert package.is_satisfied_by('2.8.1')
    assert not package.is_satisfied_by('2.7.0')

    # Test for a package without version specifier
    package = Package('pytest')
    assert not package.is_satisfied_by('2.8.0')



# Generated at 2022-06-17 05:01:40.513597
# Unit test for constructor of class Package
def test_Package():
    # Test for normal package name
    pkg = Package("test")
    assert pkg.package_name == "test"
    assert not pkg.has_version_specifier

    # Test for package name with version specifier
    pkg = Package("test", ">=1.0")
    assert pkg.package_name == "test"
    assert pkg.has_version_specifier

    # Test for package name with version specifier
    pkg = Package("test", ">=1.0,<2.0")
    assert pkg.package_name == "test"
    assert pkg.has_version_specifier

    # Test for package name with version specifier
    pkg = Package("test", ">=1.0,<2.0,!=1.5")

# Generated at 2022-06-17 05:01:52.809179
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:01:54.476415
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-17 05:02:04.906075
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.request import Request
    from ansible.module_utils.six.moves.urllib.request import install_opener

# Generated at 2022-06-17 05:02:12.973838
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:02:24.230877
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import StringIO

    # we need to reload the module to make sure we don't have any
    # cached data from a previous run
    reload_module(sys.modules[__name__])

    # create a temporary directory to work in
    tmpdir = tempfile.mkdtemp()

    # create a temporary 'virtualenv'

# Generated at 2022-06-17 05:02:25.841267
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-17 05:02:33.728682
# Unit test for function main

# Generated at 2022-06-17 05:02:39.885932
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={'virtualenv_command': dict(type='str', default='virtualenv'),
                                          'virtualenv_python': dict(type='str', default=None),
                                          'virtualenv_site_packages': dict(type='bool', default=False)})
    env = '/tmp/test_venv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:03:11.359054
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:03:19.836914
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Test that setup_virtualenv fails when virtualenv_command is not found
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command='/usr/bin/virtualenv_command',
            virtualenv_site_packages=False,
            virtualenv_python=None,
        ),
    )
    env = '/tmp/virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    with pytest.raises(AnsibleFailJson) as excinfo:
        setup_virtualenv(module, env, chdir, out, err)
    assert 'Unable to find any of virtualenv_command to use.  pip needs to be installed.' in str(excinfo.value)

    # Test that setup_virtualenv fails when virtualenv_command is not found
    module = AnsibleModule

# Generated at 2022-06-17 05:03:25.349152
# Unit test for function main

# Generated at 2022-06-17 05:03:39.788532
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    # Test for function _fail
    def test_fail():
        module = AnsibleModule(argument_spec={})
        module.fail_json = Mock()
        cmd = ['cmd', 'arg1', 'arg2']
        out = 'out'
        err = 'err'
        _fail(module, cmd, out, err)
        module.fail_json.assert_called_once_with(
            cmd=cmd, msg=ANY, stdout=out, stderr=err
        )

# Generated at 2022-06-17 05:03:49.340763
# Unit test for function main
def test_main():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

# Generated at 2022-06-17 05:03:59.743874
# Unit test for constructor of class Package
def test_Package():
    assert Package('foo').package_name == 'foo'
    assert Package('foo', '1.0').package_name == 'foo'
    assert Package('foo', '1.0').has_version_specifier
    assert not Package('foo').has_version_specifier
    assert Package('foo', '1.0').is_satisfied_by('1.0')
    assert not Package('foo', '1.0').is_satisfied_by('1.1')
    assert Package('foo', '>=1.0').is_satisfied_by('1.1')
    assert Package('foo', '>=1.0').is_satisfied_by('1.0')
    assert not Package('foo', '>=1.0').is_satisfied_by('0.9')

# Generated at 2022-06-17 05:04:09.789669
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'type': 'str', 'default': 'virtualenv'},
        'virtualenv_python': {'type': 'str', 'default': None},
        'virtualenv_site_packages': {'type': 'bool', 'default': False},
    })
    env = 'test_env'
    chdir = 'test_dir'
    out = 'test_out'
    err = 'test_err'
    assert setup_virtualenv(module, env, chdir, out, err) == (out, err)


# Generated at 2022-06-17 05:04:20.382024
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'type': 'str', 'default': 'virtualenv'},
        'virtualenv_python': {'type': 'str', 'default': None},
        'virtualenv_site_packages': {'type': 'bool', 'default': False},
    })
    env = '/tmp/test_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''



# Generated at 2022-06-17 05:04:35.010179
# Unit test for function main
def test_main():
    # Test with no parameters
    module = AnsibleModule(argument_spec={})
    assert main() == module.fail_json(msg="No valid name or requirements file found.")

    # Test with name and version
    module = AnsibleModule(argument_spec={'name': 'test', 'version': '1.0'})
    assert main() == module.fail_json(msg="'version' argument is ambiguous when installing multiple package distributions. Please specify version restrictions next to each package in 'name' argument.")

    # Test with name and version
    module = AnsibleModule(argument_spec={'name': 'test', 'version': '1.0'})
    assert main() == module.fail_json(msg="'version' argument is ambiguous when installing multiple package distributions. Please specify version restrictions next to each package in 'name' argument.")

    # Test with name and version

# Generated at 2022-06-17 05:04:41.371484
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': {'type': 'str', 'default': 'virtualenv'},
        'virtualenv_python': {'type': 'str', 'default': None},
        'virtualenv_site_packages': {'type': 'bool', 'default': False},
    })
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out != ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)



# Generated at 2022-06-17 05:05:35.377658
# Unit test for function main

# Generated at 2022-06-17 05:05:48.458152
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
        supports_check_mode=True
    )
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out != ''
    assert err == ''
    assert os.path.exists(env)
    shutil.rmtree(env)



# Generated at 2022-06-17 05:05:59.738763
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
        ),
    )
    env = '/tmp/test_setup_virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:06:06.653587
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for plain package
    pkg = Package("pkg", "1.0")
    assert pkg.is_satisfied_by("1.0")
    assert not pkg.is_satisfied_by("1.1")
    pkg = Package("pkg", ">=1.0")
    assert pkg.is_satisfied_by("1.0")
    assert pkg.is_satisfied_by("1.1")
    assert not pkg.is_satisfied_by("0.9")
    pkg = Package("pkg", "<1.0")
    assert pkg.is_satisfied_by("0.9")
    assert not pkg.is_satisfied_by("1.0")
    assert not pkg.is_satisfied_by("1.1")


# Generated at 2022-06-17 05:06:12.684537
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec=dict(
        virtualenv_command=dict(default='virtualenv'),
        virtualenv_site_packages=dict(default=False, type='bool'),
        virtualenv_python=dict(default=None),
    ))
    env = '/tmp/virtualenv'
    chdir = '/tmp'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == ''
    assert err == ''


# Generated at 2022-06-17 05:06:20.658659
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Test for package with version specifier
    pkg = Package('foo', '>=1.0')
    assert pkg.is_satisfied_by('1.1')
    assert not pkg.is_satisfied_by('0.9')
    pkg = Package('foo', '==1.0')
    assert pkg.is_satisfied_by('1.0')
    assert not pkg.is_satisfied_by('1.1')
    pkg = Package('foo', '!=1.0')
    assert pkg.is_satisfied_by('1.1')
    assert not pkg.is_satisfied_by('1.0')
    pkg = Package('foo', '<1.0')

# Generated at 2022-06-17 05:06:30.999017
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pip import HAS_SETUPTOOLS, SETUPTOOLS_IMP_ERR
    from ansible.module_utils.pip import _get_pip, _get_packages, _is_present, _get_package_info
    from ansible.module_utils.pip import _recover_package_name, _is_vcs_url
    from ansible.module_utils.pip import _fail, setup_virtualenv
    from ansible.module_utils.pip import Package
    from ansible.module_utils.pip import main
    from ansible.module_utils.pip import state_map
    import os
    import sys
    import tempfile
    import shlex
    import re
    import os

# Generated at 2022-06-17 05:06:36.906516
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(type='str', default='virtualenv'),
        'virtualenv_python': dict(type='str', default=None),
        'virtualenv_site_packages': dict(type='bool', default=False),
    })
    env = 'test_env'
    chdir = 'test_dir'
    out = 'test_out'
    err = 'test_err'
    out_venv, err_venv = setup_virtualenv(module, env, chdir, out, err)
    assert out_venv == out
    assert err_venv == err



# Generated at 2022-06-17 05:06:47.914344
# Unit test for function setup_virtualenv

# Generated at 2022-06-17 05:07:01.822185
# Unit test for function main