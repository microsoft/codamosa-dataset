

# Generated at 2022-06-25 02:57:00.460505
# Unit test for function setup_virtualenv

# Generated at 2022-06-25 02:57:09.617455
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    set_module_args(dict(
        virtualenv_command = 'pyvenv',
        virtualenv_site_packages = False,
        virtualenv_python = '/usr/bin/python2.7',
    ))
    module = AnsibleModule(
        argument_spec = dict(
            virtualenv_command = dict(type='str', required=True),
            virtualenv_site_packages = dict(default=False, type='bool'),
            virtualenv_python = dict(default='', type='str'),
        ),
        supports_check_mode = True
    )
    setup_virtualenv(module, 'test', None,
                     '', '')

# Generated at 2022-06-25 02:57:10.998910
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    # test_case_0()
    test_main()

# Generated at 2022-06-25 02:57:15.264355
# Unit test for constructor of class Package
def test_Package():
    var_0 = Package("pytest-cov")
    var_1 = Package("pytest-cov", "2.2.1")
    var_2 = Package("pytest-cov", "")
    var_3 = Package("pytest-cov==2.2.1")

    # check if name is parsed out
    assert(var_0.package_name == "pytest-cov")
    assert(var_1.package_name == "pytest-cov")
    assert(var_2.package_name == "pytest-cov")
    assert(var_3.package_name == "pytest-cov")

    # check if version specifier is parsed out
    assert(var_0.has_version_specifier is False)

# Generated at 2022-06-25 02:57:25.826818
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # This is a named tuple
    ClassType = namedtuple('ClassType', ['__module__', '__doc__'])

    # This is a named tuple
    BuiltinFunctionType = namedtuple('BuiltinFunctionType', ['__module__', '__doc__'])

    # This is a named tuple
    BuiltinMethodType = namedtuple('BuiltinMethodType', ['__module__', '__doc__'])
    ModuleType = type(sys)

    # This is a named tuple
    ModuleSpecType = namedtuple('ModuleSpecType', ['__module__', '__doc__'])
    # This is a named tuple
    FunctionType = namedtuple('FunctionType', ['__module__', '__doc__'])

    # This is a named tuple

# Generated at 2022-06-25 02:57:26.766612
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:57:30.317866
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    print('Beginning Test #0 for function setup_virtualenv')
    test_case_0()
    print('Test #0 for function setup_virtualenv - succeeded')

test_setup_virtualenv()

# Generated at 2022-06-25 02:57:32.412220
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    param_0 = 'ansible-playbook'
    local_var = setup_virtualenv(param_0)
    print(local_var)



# Generated at 2022-06-25 02:57:34.337019
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p0 = Package('ansible', '2.9.10')
    p1 = Package('ansible', '>=2.9.9')
    assert p0.is_satisfied_by('2.9.10') == True
    assert p1.is_satisfied_by('2.9.10') == True


# Generated at 2022-06-25 02:57:43.898214
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Case 0
    var_0 = "package"
    var_1 = "package==0.1"
    obj0 = Package(var_0, var_1)
    ret0 = obj0.is_satisfied_by("0.1")
    test_assert(ret0 == True)

    # Case 1
    var_2 = "package"
    var_3 = "package < 0.1"
    obj1 = Package(var_2, var_3)
    ret1 = obj1.is_satisfied_by("0.1")
    test_assert(ret1 == False)

    # Case 2
    var_4 = "package"
    var_5 = "package > 0.1"
    obj2 = Package(var_4, var_5)
    ret2 = obj2.is_satisf

# Generated at 2022-06-25 02:58:34.399290
# Unit test for function setup_virtualenv
def test_setup_virtualenv():

    # Test case #0
    # [Description] - Make a virtual environment

    # Initialize Ansible module
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(type='str', required=True),
            virtualenv_python=dict(type='str', required=True),
            virtualenv_site_packages=dict(type='bool', required=True)
        )
    )

    # Check for idempotency
    if not os.path.exists('./test_dir'):
        vars_0 = main()
        module.exit_json(changed=True, meta=vars_0)
    module.exit_json(changed=False, meta=dict())



# Generated at 2022-06-25 02:58:40.337963
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    var0 = "foo"
    var1 = "1.0.0"
    var2 = Package(var0, var1)
    var3 = "1.0.0"
    var4 = var2.is_satisfied_by(var3)
    var5 = "foo==1.0.0"
    var6 = to_native(var2)
    var7 = bool(var6 == var5)
    var8 = bool(var4 == True) and var7
    var9 = bool(var8)
    return var9

# Generated at 2022-06-25 02:58:48.795667
# Unit test for function main
def test_main():
    mock_module = MagicMock()
    mock_module.params = {'chdir': 'fake_chdir', 'extra_args': 'fake_extra_args', 'executable': 'fake_executable', 'name': 'fake_name', 'requirements': 'fake_requirements', 'state': 'fake_state', 'umask': 'fake_umask', 'virtualenv': 'fake_virtualenv'}
    var_0 = main(mock_module)
    assert mock_module.fail_json.call_count == 0
    assert mock_module.exit_json.call_count == 0


# Generated at 2022-06-25 02:58:49.810953
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    var_0 = main()


# Generated at 2022-06-25 02:58:51.653454
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    try:
        test_main()
    except:
        raise

# Generated at 2022-06-25 02:58:52.412854
# Unit test for function main
def test_main():
    os.system("testify -i  test_main.py")

# Generated at 2022-06-25 02:58:54.461635
# Unit test for function main
def test_main():
    var_1 = setUp()
    def test_main_1():
        var_1.assertEqual(main(), None)


# Generated at 2022-06-25 02:59:02.247222
# Unit test for function main
def test_main():
    import random
    var_0 = random.choice(['absent', 'forcereinstall', 'latest', 'present'])
    var_1 = random.choice([random.choice(['absent', 'forcereinstall', 'latest', 'present']), [random.choice(['pyasn1', 'tweepy', 'yapsy'])]])
    var_2 = random.choice([{}, random.choice(['absent', 'forcereinstall', 'latest', 'present'])])

# Generated at 2022-06-25 02:59:04.169826
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Create fake arguments for testing
    var_0 = Package("test")
    var_1 = "var_1"
    var_0.is_satisfied_by(var_1)


# Generated at 2022-06-25 02:59:05.615144
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package = Package('ansible', '2.7.14')
    assert package.is_satisfied_by('2.7.14') == True


# Generated at 2022-06-25 02:59:46.222902
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:59:48.021081
# Unit test for function main
def test_main():
    assert re.match(r'ansible.module_utils.basic', repr(re))


# Generated at 2022-06-25 02:59:55.616879
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    params = dict(
        virtualenv_command='pyvenv-3.5',
        virtualenv_python='',
        virtualenv_site_packages='no'
    )
    defaults = dict(
        env='/opt/ansible/test_env',
        chdir='/var/tmp/test_dir',
        out='',
        err=''
    )

# Generated at 2022-06-25 02:59:56.786772
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    print("is_satisfied_by")
    var_0 = main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 03:00:01.667403
# Unit test for function setup_virtualenv
def test_setup_virtualenv():

    mod_0 = None
    env_0 = 'foo'
    chdir_0 = 'bar'
    out_0 = 'foobar'
    err_0 = 'foobar'
    out_1, err_1 = setup_virtualenv(mod_0, env_0, chdir_0, out_0, err_0)
    assert ((out_1, err_1) == ('foobar', 'foobar')), "Expected (out_1, err_1), got (" + str(out_1) + ", " + str(err_1) + ")"


# Generated at 2022-06-25 03:00:04.388538
# Unit test for function main
def test_main():
    # Create mock object for args
    class args:
        __init__ = Mock(return_value=None)

    # Create mock object for main
    class main:
        __init__ = Mock(return_value=None)

    # Call function
    main()

    # Check if mock was called
    main.assert_called()


# Generated at 2022-06-25 03:00:09.914103
# Unit test for function main
def test_main():
    # set up exception handling
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    builtins.__dict__['_'] = lambda s: s
    builtins.__dict__['gettext'] = lambda s: s

    class ModuleStub(object):
        def __init__(self, exit_json_value):
            self.exit_json_value = exit_json_value

        def fail_json(self, **args):
            raise Exception(args)

        def exit_json(self, **kwargs):
            return self.exit_json_value

    # function / class to be tested
    class AnsibleModuleStub(object):
        def __init__(self, argument_spec, mutually_exclusive, supports_check_mode):
            self.argument_spec = argument_spec

# Generated at 2022-06-25 03:00:16.324978
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    s = Package('salt-py3', '2014.1.0')
    assert s.is_satisfied_by('2014.1.0') == True
    assert s.is_satisfied_by('2014.1.1') == False
    assert s.is_satisfied_by('2016.3.2') == False
    assert s.is_satisfied_by('2014.1.0rc1') == False
    s = Package('salt-py3')
    assert s.package_name == 'salt-py3'
    assert s.has_version_specifier == False
    s = Package('salt-py3', '>=2014.1.0')
    assert s.is_satisfied_by('2014.1.0') == True
    assert s.is_satisfied_by

# Generated at 2022-06-25 03:00:18.293294
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    tup_0 = Package("", "")
    str_0 = tup_0.is_satisfied_by("")


# Generated at 2022-06-25 03:00:19.550008
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 03:01:57.891175
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # 验证输入参数
    requirement = "=="
    print_test_case(
        "Test case for is_satisfied_by",
        requirement=requirement
    )
    # 用例执行
    var_0 = Package(
        requirement
    ).is_satisfied_by(requirement)


# Generated at 2022-06-25 03:02:01.903585
# Unit test for constructor of class Package
def test_Package():
    var_0 = Package("pip")
    var_1 = Package("pip", "18.0")
    var_2 = Package("pip", ">=18.0,<19.0")
    var_3 = Package("PIP", "==18.0")
    var_4 = Package("pip", ">=18.0,<19.0")


# Generated at 2022-06-25 03:02:05.216400
# Unit test for function main
def test_main():
    # prepare environment
    f = StringIO()
    sys.stdout = f

    var_0 = main()

    # change stdout back
    sys.stdout = sys.__stdout__
    print("test case 0:", file=sys.stdout)
    print("expected:", file=sys.stdout)
    print("test case 0:", file=sys.stdout)
    print("actual:", file=sys.stdout)
    print(var_0, file=sys.stdout)
    assert True


# Generated at 2022-06-25 03:02:06.194435
# Unit test for function main
def test_main():
    case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:02:13.148165
# Unit test for function main
def test_main():
    name_0 = ""
    name_1 = ""
    # Fix the module name to use this script's name,
    # instead of 'test' -- this allows us to test
    # things like basic module args
    module = sys.modules[__name__]
    module.params = dict(
        state = 'present',
        name = 'pip',
        version = '1.0',
        requirements = '',
        virtualenv = '',
        virtualenv_site_packages = False,
        virtualenv_command = '',
        virtualenv_python = '',
        extra_args = '',
        editable = False,
        chdir = '',
        executable = '',
        umask = '',
        )
    module._ansible_version = LooseVersion(ansible_version)

    # Mock out builtin _

# Generated at 2022-06-25 03:02:20.978726
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    try:
        import contextlib
        import io
    except ImportError:
        pass

    class Module(object):

        def fail_json(self, **kwargs):
            self.something_failed = True
            self.kwargs = kwargs
            raise Exception("fail_json")

        def exit_json(self, **kwargs):
            self.something_succeeded = True
            self.kwargs = kwargs

        def get_bin_path(self, cmd, opt_dirs, environ=None):
            if cmd == 'python3.4':
                return 'ABSOLUTE_PATH_TO_PYTHON'
            return None


# Generated at 2022-06-25 03:02:24.258740
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    param_0 = None
    param_1 = None
    param_2 = None
    param_3 = None
    param_4 = None
    ret_0 = setup_virtualenv(param_0, param_1, param_2, param_3, param_4)
    ret_1 = setup_virtualenv(param_0, param_1, param_2, param_3, param_4)

    if ret_0 != ret_1:
        print('Test case 0 failed')



# Generated at 2022-06-25 03:02:30.019470
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule()
    # Input parameters

# Generated at 2022-06-25 03:02:34.112030
# Unit test for function main
def test_main():
    #with patch('ansible.modules.packaging.python.virtualenv') as mock_virtualenv:
    #    test_case_0()
    #    assert mock_virtualenv.call_count == 0

    #with patch('ansible.modules.packaging.python.virtualenv') as mock_virtualenv:
    #    test_case_0()
    #    assert mock_virtualenv.call_count == 0

    #with patch('ansible.modules.packaging.python.virtualenv') as mock_virtualenv:
    #    test_case_0()
    #    assert mock_virtualenv.call_count == 0
    pass


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 03:02:37.469979
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    test_environment_0()
    test_case_0()

