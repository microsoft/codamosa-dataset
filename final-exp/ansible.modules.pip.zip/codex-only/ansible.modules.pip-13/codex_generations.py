

# Generated at 2022-06-23 03:58:30.202941
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # arrange
    pkg_name = 'foo'
    no_specifier = Package(pkg_name)
    with_specifier = Package(pkg_name, '==1.0')
    # act
    with_specifier_satisfied = with_specifier.is_satisfied_by('1.0')
    no_specifier_satisfied = no_specifier.is_satisfied_by('1.0')
    with_specifier_unsatisfied = with_specifier.is_satisfied_by('2.0')
    no_specifier_unsatisfied = no_specifier.is_satisfied_by('2.0')
    # assert
    assert with_specifier_satisfied
    assert no_specifier_satisfied
    assert not with_specifier_unsatisfied

# Generated at 2022-06-23 03:58:34.277569
# Unit test for function main

# Generated at 2022-06-23 03:58:47.038506
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    assert not Package('any').is_satisfied_by('2.12')
    assert Package('any==2.12').is_satisfied_by('2.12')
    assert Package('any>=2.12').is_satisfied_by('2.12')
    assert Package('any>=2.12').is_satisfied_by('3')
    assert not Package('any>=2.12').is_satisfied_by('2.0')
    assert Package('any>2.12,<3.0').is_satisfied_by('2.12.1')
    assert Package('any>2.12,<3.0').is_satisfied_by('2.99')

# Generated at 2022-06-23 03:58:53.274183
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils import basic
    import os
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    test = "%s/test" % test_dir
    module = basic.AnsibleModule(argument_spec={
        'virtualenv_command' : {'type': 'str', 'default': '/bin/virtualenv'},
        'virtualenv_site_packages' : {'type': 'bool', 'default': False},
        'virtualenv_python': {'type': 'str', 'default': ''},
    })
    env = '%s/testenv' % test_dir
    out, err = setup_virtualenv(module, env, test_dir, '', '')
    assert os.path.isdir(env)

# Generated at 2022-06-23 03:58:58.137148
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as excinfo:
        main()
    the_exception = excinfo.value.args[0]
    assert the_exception['changed']
    assert the_exception['cmd'] == 'virtualenv test/test-packages --python=python2'
    assert the_exception['name'] is None
    assert the_exception['requirements'] is None

    with pytest.raises(AnsibleFailJson) as excinfo:
        main()
    assert excinfo.value.args[0]['msg'] == 'Requirement already satisfied (use --upgrade to upgrade): pip in test/test-packages/lib64/python2.6/site-packages'

    with pytest.raises(AnsibleFailJson) as excinfo:
        main()

# Generated at 2022-06-23 03:59:06.510798
# Unit test for method __str__ of class Package
def test_Package___str__():
    from pip._vendor.pkg_resources import Requirement
    from ansible.module_utils.six import PY3

    pkg = Package('foo', '2.3')
    assert str(pkg) == "foo==2.3"

    pkg = Package('bar')
    assert str(pkg) == "bar"

    pkg = Package('foo', '>=2.3')
    if PY3:
        assert str(pkg) == "foo>=2.3"
    else:
        assert str(pkg) == "foo (>=2.3)"

    pkg = Package('foo', '<=2.3')
    if PY3:
        assert str(pkg) == "foo<=2.3"
    else:
        assert str(pkg) == "foo (LTE=2.3)"

   

# Generated at 2022-06-23 03:59:08.431726
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:59:19.680145
# Unit test for function main
def test_main():
    from ansible_collections.community.general.tests.unit.compat import mock
    from ansible_collections.community.general.tests.unit.compat import unittest

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.start_dir = os.getcwd()

            self.test_dir = tempfile.mkdtemp()

            os.chdir(self.test_dir)

        def tearDown(self):
            os.chdir(self.start_dir)

            shutil.rmtree(self.test_dir)


# Generated at 2022-06-23 03:59:21.027366
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:59:32.682484
# Unit test for function main
def test_main():
    import pytest

    from ansible.module_utils.basic import AnsibleModule
    # Clone module to prevent accidental state leakage between tests
    module = ansible.module_utils.pip.__dict__.get('AnsibleModule').__class__(
        argument_spec={},
        supports_check_mode=True,
    )

    def _run_command(self, args, path_prefix=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, "Successfully installed", ""

    def _get_pip(self, virtualenv=None, executable=None):
        return Pip._get_pip(self, virtualenv=virtualenv, executable=executable)


# Generated at 2022-06-23 03:59:33.603862
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert True



# Generated at 2022-06-23 03:59:42.274550
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Package" can be used inside of an "if" statement
    # because Python uses the boolean value of the object.
    p = Package("test_package", "1.2.3")
    assert str(p) == "test_package==1.2.3"

    p = Package("test_package==1.2.3")
    assert str(p) == "test_package==1.2.3"

    p = Package("test_package", version_string="")
    assert str(p) == "test_package"

    p = Package("test_package", version_string=None)
    assert str(p) == "test_package"

    p = Package("test_package")
    assert str(p) == "test_package"



# Generated at 2022-06-23 03:59:53.790203
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p = Package('foo', '>=0.1.0')
    assert p.is_satisfied_by('0.1.1')
    assert not p.is_satisfied_by('0.0.1')

    p = Package('foo', '==0.1.0')
    assert p.is_satisfied_by('0.1.0')
    assert not p.is_satisfied_by('0.1.1')

    p = Package('foo', '0.1.x')
    assert p.is_satisfied_by('0.1.1')
    assert not p.is_satisfied_by('0.0.1')
    assert not p.is_satisfied_by('0.2.0')



# Generated at 2022-06-23 04:00:06.188756
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """
    Check if the function sets venv properly when run_command returns 0
    """
    module = Mock()
    module.params = {'virtualenv_python': '/usr/bin/python',
                     'virtualenv_command': 'virtualenv',
                     'virtualenv_site_packages': False}
    out_mock = "virtual environment"
    error_mock = ""
    rc_mock = 0
    module.run_command.return_value = rc_mock, out_mock, error_mock
    env_mock = "/tmp/fakeenv"
    chdir_mock = os.getcwd()
    out, err = setup_virtualenv(module, env_mock, chdir_mock, "", "")
    assert out == out_mock
    assert err == error_mock
   

# Generated at 2022-06-23 04:00:08.338077
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('foo')) == 'foo'
    assert str(Package('foo', '==42.0')) == 'foo==42.0'



# Generated at 2022-06-23 04:00:19.609174
# Unit test for constructor of class Package
def test_Package():
    p = Package("foo", "==1.2.3")
    assert (p.package_name == "foo")
    assert (p.has_version_specifier)
    assert (p.is_satisfied_by("1.2.3"))
    assert (not p.is_satisfied_by("1.2.4"))

    p = Package("foo==1.2.3")
    assert (p.package_name == "foo")
    assert (p.has_version_specifier)
    assert (p.is_satisfied_by("1.2.3"))
    assert (not p.is_satisfied_by("1.2.4"))

    p = Package("foo")
    assert (p.package_name == "foo")
    assert (not p.has_version_specifier)


# Generated at 2022-06-23 04:00:28.595887
# Unit test for function main
def test_main():
    class AnsibleModule(object):
        def __init__(self,argument_spec,required_one_of=None,supports_check_mode=False):
            self.params = {'state':'present','name':'pip'}

        def fail_json(self,**kwargs):
            print(kwargs)
        def exit_json(self,**kwargs):
            print(kwargs)

        def run_command(self,cmd,path_prefix=None,cwd=None):
            return 0,'stdout','stderr'
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:00:35.512908
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("CamelCase") == "camelcase"
    assert Package.canonicalize_name("ACRONYM2") == "acronym2"
    assert Package.canonicalize_name("consecutive_underscores") == "consecutive-underscores"
    assert Package.canonicalize_name("consecutive.dots") == "consecutive-dots"
    assert Package.canonicalize_name("consecutive-dashes") == "consecutive-dashes"


# Generated at 2022-06-23 04:00:42.544011
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    pkg = Package('OnlyOnePackageName')
    assert pkg.canonicalize_name('OnlyOnePackageName') == 'onlyonepackagename'
    assert pkg.canonicalize_name('only_one.packageName') == 'only-one-packagename'
    assert pkg.canonicalize_name('Only_One_Package-Name_') == 'only-one-package-name'



# Generated at 2022-06-23 04:00:54.375402
# Unit test for constructor of class Package

# Generated at 2022-06-23 04:00:55.781952
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert Package("setuptools").__str__() == "setuptools"
    assert Package("setuptools", "==20.0").__str__() == "setuptools==20.0"



# Generated at 2022-06-23 04:01:04.770037
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule({
        "virtualenv_command": "virtualenv",
        "virtualenv_site_packages": "True",
        "virtualenv_python": "python3.6",
        "virtualenv_args": "foo bar",
        "name": "requests",
        "state": "present",
    })
    chdir = "/home"
    env = "test_env"
    out = ""
    err = ""
    setup_virtualenv(module, env, chdir, out, err)
    # chdir = "/home"
    # env = "test_env"
    # out = ""
    # err = ""
    # setup_virtualenv(module, env, chdir, out, err)
    pass



# Generated at 2022-06-23 04:01:06.986720
# Unit test for function main
def test_main():
    assert 1 == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 04:01:15.423278
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    assert Package("pip").is_satisfied_by("2.0")
    assert Package("pip").is_satisfied_by("1.1.0")
    assert not Package("pip").is_satisfied_by("0.99.99")
    assert Package("pip", ">2.0").is_satisfied_by("2.0.1")
    assert Package("pip", ">2.0").is_satisfied_by("3.1")
    assert not Package("pip", ">2.0").is_satisfied_by("2.0")
    assert not Package("pip", ">2.0").is_satisfied_by("1.99")
    assert Package("pip", ">=2.0").is_satisfied_by("2.0")

# Generated at 2022-06-23 04:01:24.820762
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-23 04:01:35.223892
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def _test_satisfied(package, version_to_test, expected_satisfied):
        result = package.is_satisfied_by(version_to_test)
        assert result == expected_satisfied, "%s %s not satisfied by %s" % (
            package.package_name, package.version_string, version_to_test)

    # test plain name
    package = Package("mock")
    assert str(package) == "mock"
    assert package.package_name == "mock"

    # test non-plain name
    package = Package("mock>=1.3.0")
    assert str(package) == "mock>=1.3.0"
    assert package.package_name == "mock"

# Generated at 2022-06-23 04:01:45.960601
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-23 04:01:50.142371
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package("python-novaclient", "2.0")
    assert to_native(pkg) == "<Package python-novaclient 2.0>"
    assert str(pkg) == "python-novaclient"


# Generated at 2022-06-23 04:02:03.102168
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-23 04:02:08.774925
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("Some-Thing") == "some-thing"
    assert Package.canonicalize_name("Some_Thing") == "some-thing"
    assert Package.canonicalize_name("Some.Thing") == "some-thing"
    assert Package.canonicalize_name("sOmE.ThInG") == "some-thing"

# Generated at 2022-06-23 04:02:13.469251
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("aaBbcc") == "aabbcc"
    assert Package.canonicalize_name("aaBBcc") == "aabbcc"
    assert Package.canonicalize_name("aa_bb.cc") == "aa-bb-cc"



# Generated at 2022-06-23 04:02:23.338913
# Unit test for constructor of class Package
def test_Package():
    package = Package('requests')
    assert not package.has_version_specifier
    assert package.package_name == 'requests'
    assert package.is_satisfied_by('1.1.0')

    package = Package('pywinrm', '>=0.3.0')
    assert package.has_version_specifier
    assert package.package_name == 'pywinrm'
    assert package.is_satisfied_by('0.3.0')
    assert package.is_satisfied_by('0.4.0')
    assert not package.is_satisfied_by('0.2.0')

    package = Package('pywinrm', '>=0.3.0,<0.5.0')
    assert package.has_version_specifier
    assert package.package_name

# Generated at 2022-06-23 04:02:28.370221
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Given
    version_to_test = '1.12.4'
    # When
    pkg = Package('packaging==1.12')
    # Then
    assert pkg.is_satisfied_by(version_to_test)

    # When
    pkg = Package('packaging>=1.12')
    # Then
    assert pkg.is_satisfied_by(version_to_test)

    # When
    pkg = Package('packaging<1.12')
    # Then
    assert not pkg.is_satisfied_by(version_to_test)

    # When
    pkg = Package('packaging<=1.12')
    # Then
    assert not pkg.is_satisfied_by(version_to_test)

    # When

# Generated at 2022-06-23 04:02:41.115497
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    # test_1:
    assert Package.canonicalize_name("pip") == "pip"
    # test_2:
    assert Package.canonicalize_name("PIP") == "pip"
    # test_3:
    assert Package.canonicalize_name("PIP-extra") == "pip-extra"
    # test_4:
    assert Package.canonicalize_name("PIP-Extra") == "pip-extra"
    # test_5:
    assert Package.canonicalize_name("PIP_extra") == "pip-extra"
    # test_6:
    assert Package.canonicalize_name("PIP_Extra") == "pip-extra"
    # test_7:

# Generated at 2022-06-23 04:02:48.151946
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("Package-name") == "package-name"
    assert Package.canonicalize_name("another_package") == "another-package"
    assert Package.canonicalize_name("more.complicated.package") == "more-complicated-package"
    assert Package.canonicalize_name("yet-another-package") == "yet-another-package"



# Generated at 2022-06-23 04:02:56.331865
# Unit test for constructor of class Package
def test_Package():
    test_name_string = "pbr>=1.9"
    test_version_string = "2.0.0b2"
    test_package = Package(test_name_string, test_version_string)
    assert test_package.package_name == "pbr"
    assert test_package.has_version_specifier is True
    assert test_package.is_satisfied_by("2.0.0b2") is True
    assert test_package.is_satisfied_by("1.9") is False
    assert test_package.is_satisfied_by("1.8") is False
    assert test_package.is_satisfied_by("1.10") is False
    assert str(test_package) == test_name_string + ' ' + test_version_string



# Generated at 2022-06-23 04:03:03.873119
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.modules.packaging.os import pip
    class FakeModule(object):
        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args):
            return args
        def run_command(self, *args):
            return 0, '', ''
    fake_module = FakeModule()
    pip.setup_virtualenv(fake_module, 'env', 'chdir', 'out', 'err')



# Generated at 2022-06-23 04:03:08.889189
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import os
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.pip import (
        _get_cmd_options,
        _get_pip,
        setup_virtualenv,
    )

    # Set up an environment with a missing binary
    test_env_dir = tempfile.mkdtemp()
    test_env_bin = os.path.join(test_env_dir, 'bin')
    os.makedirs(test_env_bin)

    # Python 2.6 doesn't have shlex.quote

# Generated at 2022-06-23 04:03:11.652154
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("test")) == "test"
    assert str(Package("test", "1.0")) == "test==1.0"
    assert str(Package("test", ">=1.0")) == "test>=1.0"



# Generated at 2022-06-23 04:03:18.677229
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    mock_module = Mock()
    mock_module.check_mode = True
    mock_module.get_bin_path.return_value = "test_bin_path"
    mock_module.params = {'virtualenv_command': 'test_command',
                          'virtualenv_python': 'test_python',
                          'virtualenv_site_packages': None}
    mock_module.run_command.return_value = (0, '', '')
    out, err = setup_virtualenv(mock_module, '', '', '', '')
    assert out == ''
    assert err == ''
    mock_module.run_command.assert_called_with(['test_bin_path', '-ptest_python', 'test_command', ''], cwd='')



# Generated at 2022-06-23 04:03:28.006138
# Unit test for constructor of class Package
def test_Package():
    assert Package(name_string="pep8==1.4.3", version_string="1.4.3").package_name == "pep8"
    assert Package(name_string="pep8==1.4.3", version_string="1.4.3")._plain_package is True
    assert Package(name_string="pep8==1.4.3", version_string="1.4.3").has_version_specifier is True
    assert Package(name_string="pep8==1.4.3", version_string="1.4.3").is_satisfied_by("1.4.3") is True
    assert Package(name_string="pep8==1.4.3", version_string="1.4.3").is_satisfied_by("1.4.2") is False

# Generated at 2022-06-23 04:03:41.340634
# Unit test for method __str__ of class Package
def test_Package___str__():
    '''Unit tests for method __str__ of class Package'''

    # test package name with version
    pkg = Package("pkg-name", "0.2")
    assert str(pkg) == "pkg-name==0.2"

    # test package name without version
    pkg = Package("pkg-name")
    assert str(pkg) == "pkg-name"

    # test package name with version separated by a space
    pkg = Package("pkg-name", "==0.2")
    assert str(pkg) == "pkg-name==0.2"

    # test package name with version separated by a semicolon
    pkg = Package("pkg-name", "0.2; sys_platform!='win32'")
    assert str(pkg) == "pkg-name==0.2; sys_platform != 'win32'"


# Generated at 2022-06-23 04:03:54.372252
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    class Pair:
        def __init__(self, input, expected):
            self.input = input
            self.expected = expected

    pairs = (
        Pair('simple', 'simple'),
        Pair('with-dash', 'with-dash'),
        Pair('CAPITAL', 'capital'),
        Pair('UPPER', 'upper'),
        Pair('With_underscore', 'with-underscore'),
        Pair('with.dot', 'with-dot'),
        Pair('with-dash-and.dot', 'with-dash-and-dot'),
        Pair('with-many---dashes', 'with-many-dashes'),
        Pair('with-many___underscores', 'with-many-underscores'),
        Pair('with-mixed-_.dash-', 'with-mixed-dash')
    )


# Generated at 2022-06-23 04:04:03.992602
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    mock_module = AnsibleModuleMock()
    cmd = ['virtualenv', '-p', '/usr/local/bin/python3', '/path/to/venv']
    mock_module.params['virtualenv_site_packages'] = True
    mock_module.params['virtualenv_command'] = 'virtualenv'
    mock_module.params['virtualenv_python'] = '/usr/local/bin/python3'
    out, err = setup_virtualenv(mock_module, '/path/to/venv', '/tmp', '', '')
    assert cmd == mock_module.run_command.call_args[0][0]
    assert out == '/tmp'
    assert err == ''


# Generated at 2022-06-23 04:04:14.022434
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from nose.tools import assert_false, assert_true
    package = Package('foo', '1.0')
    assert_true(package.is_satisfied_by('1.0'))

    package = Package('foo', '>=1.0')
    assert_true(package.is_satisfied_by('1.0'))
    assert_false(package.is_satisfied_by('0.9'))

    package = Package('foo', '<1.0')
    assert_true(package.is_satisfied_by('0.9'))
    assert_false(package.is_satisfied_by('1.0'))

    package = Package('foo', '~=1.0')
    assert_true(package.is_satisfied_by('1.0'))

# Generated at 2022-06-23 04:04:23.639324
# Unit test for method __str__ of class Package
def test_Package___str__():
    p = Package('pip')
    assert str(p) == 'pip'
    p = Package('ansible', '2.2.0')
    assert str(p) == 'ansible==2.2.0'
    p = Package('package', '< 1.0')
    assert str(p) == 'package <1.0'
    p = Package('package', '<=2.0')
    assert str(p) == 'package <=2.0'
    p = Package('package', '>=5.0')
    assert str(p) == 'package >=5.0'
    p = Package('package', '> 2.0')
    assert str(p) == 'package >2.0'
    p = Package('package', '== 2.0')

# Generated at 2022-06-23 04:04:26.161115
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("foo_BAR-2") == "foo-bar-2"



# Generated at 2022-06-23 04:04:31.532940
# Unit test for function main
def test_main():
    name = 'syslinux'
    state = 'present'
    version = '4.06-2ubuntu2.2'
    requirements = None
    virtualenv = None
    stdout = None 
    stderr = None
    changed = True
    cmd = ['pip3', 'install', name, version]

# Generated at 2022-06-23 04:04:39.933795
# Unit test for method __str__ of class Package
def test_Package___str__():
    package_test_inputs = (
        ("a", "a"), "a==1.0", "setuptools==19.5",
        "setuptools>=19.5", "setuptools>=19.5,<20.0",
    )
    for test_input in package_test_inputs:
        package = Package(test_input)
        assert str(package) == test_input



# Generated at 2022-06-23 04:04:47.967204
# Unit test for method __str__ of class Package
def test_Package___str__():
    """
    Unit test for method __str__ of class Package
    """
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    def _satisfy_version(version_to_test):
        return True

    # install a package with a version specifier
    pkg = Package("foo", ">=1.0")
    assert str(pkg) == "foo>=1.0"

    # install a plain package
    pkg = Package("bar")
    assert str(pkg) == "bar"


# Generated at 2022-06-23 04:04:59.874521
# Unit test for constructor of class Package

# Generated at 2022-06-23 04:05:13.034893
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import tempfile
    import shutil

    sample_module = AnsibleModule({}, check_invalid_arguments=False)
    tmpdir = tempfile.mkdtemp()

    sample_module.params['virtualenv_command'] = 'virtualenv'
    sample_module.params['virtualenv_python'] = None
    sample_module.params['virtualenv_site_packages'] = False

    out_venv, err_venv = setup_virtualenv(sample_module, 'venv', tmpdir, '', '')

    assert out_venv
    assert err_venv

    assert os.path.exists(os.path.join(tmpdir, 'venv', 'bin', 'activate'))
    assert os.path.exists(os.path.join(tmpdir, 'venv', 'bin', 'python'))



# Generated at 2022-06-23 04:05:19.595726
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pip import setup_virtualenv

    env = '.'
    module = AnsibleModule(virtualenv_site_packages=True, virtualenv_command='/usr/bin/virtualenv')
    chdir = '.'
    out = ''
    err = ''
    setup_virtualenv(module, env, chdir, out, err)



# Generated at 2022-06-23 04:05:31.204834
# Unit test for constructor of class Package
def test_Package():
    assert Package("pytz").package_name == "pytz"
    assert Package("pytz", "2014b").package_name == "pytz"
    assert str(Package("pytz")) == "pytz"
    assert str(Package("pytz", "2014b")) == "pytz==2014b"
    assert str(Package("django-mptt", ">=0.6.0")) == "django-mptt>=0.6.0"
    assert Package("django-mptt", ">=0.6.0").is_satisfied_by("0.6.0")
    assert Package("django-mptt", ">=0.6.0").is_satisfied_by("0.6.11")

# Generated at 2022-06-23 04:05:42.184222
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package_dummy = Package('aaaa', 'aaaa')
    assert not package_dummy._plain_package
    package_setuptools = Package('setuptools', '20.3')
    assert not package_setuptools._plain_package
    package_pip = Package('pip', '8.1.2')
    assert not package_pip._plain_package
    pkg_distlib = Package('distlib', '0.2.0')
    assert pkg_distlib._plain_package
    assert pkg_distlib.has_version_specifier
    assert pkg_distlib.is_satisfied_by('0.2.0')
    pkg_dist = Package('dist', '1')
    assert pkg_dist._plain_package
    assert pkg_dist.has_version_specifier
   

# Generated at 2022-06-23 04:05:46.068451
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('foo')) == "foo"
    assert str(Package('foo==1.0.0')) == "foo==1.0.0"


# Generated at 2022-06-23 04:05:51.422651
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert 'foo==1.0' == str(Package('foo', '1.0'))
    assert 'foo' == str(Package('foo', 'latest'))
    assert 'foo' == str(Package('foo'))
    assert 'name[bar]' == str(Package('name[bar]'))



# Generated at 2022-06-23 04:06:01.907907
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import ansible.module_utils.basic as basic
    basic._ANSIBLE_ARGS = ' '.join(['ANSIBLE_MODULE_ARGS={"virtualenv_command": "pyvenv", "virtualenv_site_packages": "false"}'])
    m = AnsibleModule(
        argument_spec={
            'virtualenv_command': {'required': True, 'default': None},
            'virtualenv_site_packages': {'required': False, 'default': None},
        },
        supports_check_mode=True,
    )
    setup_virtualenv(m, "TESTENV", "", "", "")



# Generated at 2022-06-23 04:06:09.747494
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('Distribute') == 'distribute'
    assert Package.canonicalize_name('python_foo') == 'python-foo'
    assert Package.canonicalize_name('python-foo') == 'python-foo'
    assert Package.canonicalize_name('python--foo') == 'python--foo'
    assert Package.canonicalize_name('python_foo==1.0') == 'python-foo'
    assert Package.canonicalize_name('python-foo==1.0') == 'python-foo'
    assert Package.canonicalize_name('python--foo==1.0') == 'python--foo'



# Generated at 2022-06-23 04:06:24.880648
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Setup a mock module
    module = AnsibleModule({'virtualenv_command': '/usr/bin/virtualenv',
                            'virtualenv_python': '/usr/bin/python2.7',
                            'virtualenv_site_packages': False})

    # Setup a mock run_command
    def mock_run_command(command, cwd=None, check_rc=True, environ_update=None):
        if command == ['/usr/bin/virtualenv', '--no-site-packages', '-p/usr/bin/python2.7', '/some/path']:
            rc = 0
            out = 'Successfully created virtualenv in /some/path'
            err = ''
        else:
            raise AssertionError
        return rc, out, err

    # Run setup_virtualenv to test
    module.run

# Generated at 2022-06-23 04:06:31.996805
# Unit test for method __str__ of class Package
def test_Package___str__():
    p = Package("foo", "1.0")
    assert "foo==1.0" == p.__str__()
    p = Package("foo")
    assert "foo" == p.__str__()



# Generated at 2022-06-23 04:06:33.495372
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 04:06:42.703056
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('test')) == 'test'
    assert str(Package('test-2.0')) == 'test-2.0'
    assert str(Package('test==2.0')) == 'test==2.0'
    assert str(Package('test-2.0', '2.0')) == 'test-2.0==2.0'
    assert str(Package('test-2.0==2.0.1')) == 'test-2.0==2.0.1'
    assert str(Package('test-2.0', '2.0.1')) == 'test-2.0==2.0.1'

# Generated at 2022-06-23 04:06:47.627730
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p = Package("some_package==1.2.3")
    assert p.is_satisfied_by("1.2.3")
    assert not p.is_satisfied_by("1.2.4")


# Generated at 2022-06-23 04:06:58.767438
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # cases when Package.has_version_specifier is False
    assert not Package('foo').is_satisfied_by('1.0')
    # cases when Package.has_version_specifier is True
    assert Package('foo', '1.0').is_satisfied_by('1.0')
    assert Package('foo', '>=1.0,<2.0').is_satisfied_by('1.5')
    assert not Package('foo', '>=1.0,<2.0').is_satisfied_by('2.5')
    assert Package('foo', '~1.0').is_satisfied_by('1.0')
    assert Package('foo', '~1.0').is_satisfied_by('1.5')

# Generated at 2022-06-23 04:07:10.262007
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar.qux') == 'foo-bar-qux'
    assert Package.canonicalize_name('foo_bar_qux') == 'foo-bar-qux'
    assert Package.canonicalize_name('foo-bar-qux') == 'foo-bar-qux'
    assert Package.canonicalize_name('foo....bar.qux') == 'foo-bar-qux'



# Generated at 2022-06-23 04:07:22.896577
# Unit test for method __str__ of class Package
def test_Package___str__():
    from pkg_resources import Requirement
    # Old setuptools will be used to verify behaviour.

# Generated at 2022-06-23 04:07:31.791807
# Unit test for constructor of class Package
def test_Package():
    req_str = 'Distribute>=0.6.14,<=0.6.29 ; python_version=="2.7"'
    name_str = 'Distribute'
    pkg = Package(name_str, req_str)
    assert pkg.package_name == 'distribute'
    assert pkg.has_version_specifier
    assert pkg.is_satisfied_by('0.6.28')
    assert not pkg.is_satisfied_by('0.7.0')


# Generated at 2022-06-23 04:07:44.195898
# Unit test for constructor of class Package
def test_Package():
    package = Package("setuptools==1.0")
    assert package._plain_package is True
    assert package.package_name == "setuptools"
    assert package.has_version_specifier is True
    assert package.is_satisfied_by("1.0") is True
    assert package.is_satisfied_by("1.1") is False

    package = Package("setuptools")
    assert package._plain_package is True
    assert package.package_name == "setuptools"
    assert package.has_version_specifier is False
    assert package.is_satisfied_by("1.0") is True

    package = Package("setuptools>=1.0")
    assert package._plain_package is True
    assert package.package_name == "setuptools"
    assert package.has

# Generated at 2022-06-23 04:07:49.605108
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    package = Package('My.PyPI.Project')
    assert 'my-pypi-project' == package.package_name
    package = Package('my_PyPI_proJect')
    assert 'my-pypi-project' == package.package_name
    package = Package('My-PyPI-Project')
    assert 'my-pypi-project' == package.package_name
    package = Package('my-pypi-project')
    assert 'my-pypi-project' == package.package_name



# Generated at 2022-06-23 04:07:55.316790
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert 'python-markupsafe' == Package.canonicalize_name('python-markupsafe')
    assert 'python-markupsafe' == Package.canonicalize_name('Python_MarkupSafe')
    assert 'python-markupsafe' == Package.canonicalize_name('Python-markupSafe')



# Generated at 2022-06-23 04:08:06.412938
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p = Package('Django')
    assert (p.is_satisfied_by('1.4') and p.is_satisfied_by('1.5') and p.is_satisfied_by('1.5.1') and
            p.is_satisfied_by('1.6') and p.is_satisfied_by('1.6.1') and p.is_satisfied_by('1.6.2'))
    assert not (p.is_satisfied_by('1.3') or p.is_satisfied_by('1.2') or p.is_satisfied_by('1.7'))
    p = Package('Django==1.6')

# Generated at 2022-06-23 04:08:17.918057
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    test_module = AnsibleModule(
        argument_spec={
            'virtualenv_command': dict(type='str', default='virtualenv'),
            'virtualenv_python': dict(type='str', default=None),
            'virtualenv_site_packages': dict(type='bool', default=False),
        }
    )
    test_env = 'test_env'
    test_chdir = '/tmp'
    test_out = ''
    test_err = ''
    # We need to mock the module.run_command function so it doesn't
    # actually run anything.
    # The return values are: return_code, out, err
    test_module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-23 04:08:26.189041
# Unit test for method canonicalize_name of class Package