

# Generated at 2022-06-23 03:58:22.820162
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv("module","env","chdir","out","err") == ("outout", "errerr")


# Generated at 2022-06-23 03:58:25.491520
# Unit test for function main
def test_main():
    return_value = main()
    assert return_value is None

# Generated at 2022-06-23 03:58:35.442102
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package("ABC==1.0")) == "ABC==1.0"
    assert str(Package("ABC>=1.0")) == "ABC>=1.0"
    assert str(Package("ABC", ">=1.0")) == "ABC>=1.0"
    assert str(Package("ABC", ">=1.0")) == "ABC>=1.0"
    assert str(Package("ABC>=1.0", ">=1.0")) == "ABC>=1.0"
    assert str(Package("ABC>=1.0", ">=2.0")) == "ABC>=1.0,>=2.0"
    assert str(Package("ABC", ">=1.0", ">=2.0")) == "ABC>=1.0,>=2.0"
   

# Generated at 2022-06-23 03:58:43.127124
# Unit test for function main
def test_main():
    def _add_virtualenv(venv_dir, created_venv_dirs):
        if venv_dir and venv_dir not in created_venv_dirs:
            created_venv_dirs.add(venv_dir)
            os.makedirs(os.path.join(venv_dir, 'bin', 'activate'))

    def _add_requirements(requirements):
        if requirements:
            with open(requirements, 'w') as f:
                f.write('pbr\n')

    # get default arguments used by the ansible module

# Generated at 2022-06-23 03:58:43.653684
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-23 03:58:48.811560
# Unit test for method __str__ of class Package
def test_Package___str__():
    p = Package("name", "1.0")
    s = str(p)
    assert s == "name==1.0"
    p = Package("name", ">=1.0,<2.0")
    s = str(p)
    assert s == "name>=1.0,<2.0"
    p = Package("name", None)
    s = str(p)
    assert s == "name"
    p = Package("name", "")
    s = str(p)
    assert s == "name"



# Generated at 2022-06-23 03:58:54.660459
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec={
            'virtualenv_command': {'required': True, 'type': 'str'},
            'virtualenv_python': {'required': False, 'type': 'str'},
            'virtualenv_site_packages': {'required': False, 'type': 'bool'},
        },
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/python')

    out, err = setup_virtualenv(module, 'env', '', '', '')

    module.get_bin_path.assert_called_once_with('python', True)

# Generated at 2022-06-23 03:59:03.767779
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def assert_satisfied(package_name, version_string, ver_to_test, satisfied):
        package = Package(package_name, version_string)
        assert package.is_satisfied_by(ver_to_test) == satisfied
    assert_satisfied('test', '', '3.4.5', True)
    assert_satisfied('test', None, '3.4.5', True)
    assert_satisfied('test', '>=1.0.5', '1.0.4', False)
    assert_satisfied('test', '==1.0.5', '1.0.5', True)



# Generated at 2022-06-23 03:59:04.551540
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert True



# Generated at 2022-06-23 03:59:18.103513
# Unit test for constructor of class Package
def test_Package():
    assert Package("simple_package_name").package_name == "simple_package_name"
    assert Package("multi word package").package_name == "multi-word-package"
    assert Package("   Multiword    Package   ").package_name == "multiword-package"
    assert Package("setuptools", "30.3").package_name == "setuptools"
    assert Package("setuptools", "30.3").has_version_specifier is True
    assert Package("setuptools", "30.3").is_satisfied_by("30.3") is True
    assert Package("setuptools", "30.3.0").is_satisfied_by("30.3.0") is True
    assert Package("setuptools", "30.3.0").is_satisfied_by("30.3.1")

# Generated at 2022-06-23 03:59:28.059929
# Unit test for constructor of class Package
def test_Package():
    package1 = Package('setuptools')
    assert not package1.has_version_specifier
    assert package1.is_satisfied_by('1.6.0')

    package2 = Package('ansible', '>=2.0')
    assert package2.has_version_specifier
    assert package2.is_satisfied_by('2.0.0')
    assert package2.is_satisfied_by('2.1.0.dev0')
    assert not package2.is_satisfied_by('1.9.9')


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:59:32.690841
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        virtualenv_command='',
        virtualenv_python='',
        virtualenv_site_packages=''
    ))
    env = 'test/env'
    setup_virtualenv(module, env, '.', '', '')



# Generated at 2022-06-23 03:59:34.515806
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # TODO: Implement tests for pip in check mode
    pass



# Generated at 2022-06-23 03:59:37.251719
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package('foo==1.0')
    assert 'foo==1.0' == str(pkg)
    pkg = Package('foo')
    assert 'foo' == str(pkg)



# Generated at 2022-06-23 03:59:47.400858
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package = Package("foo")
    assert package.is_satisfied_by("1.0") is False
    package = Package("foo", "==1.0")
    assert package.is_satisfied_by("1.0") is True
    assert package.is_satisfied_by("1.1") is False
    package = Package("foo", ">=1.0,<2.0")
    assert package.is_satisfied_by("1.0") is True
    assert package.is_satisfied_by("1.1") is True
    assert package.is_satisfied_by("2.0") is False
    package = Package("foo", ">=0.9,<1.0")
    assert package.is_satisfied_by("0.9") is True
    package = Package

# Generated at 2022-06-23 03:59:58.509350
# Unit test for constructor of class Package
def test_Package():
    require_package = Package('setuptools', '>=20.2')
    assert require_package.package_name == 'setuptools'
    assert require_package.has_version_specifier
    assert require_package.is_satisfied_by('21.2')
    assert not require_package.is_satisfied_by('1.2')
    assert not require_package.is_satisfied_by('1.2.3')

    # a simple package without version specifier
    simple_package = Package('setuptools')
    assert simple_package.package_name == 'setuptools'
    assert not simple_package.has_version_specifier
    assert simple_package.is_satisfied_by('21.2')
    assert not simple_package.is_satisfied_by('1.2')

# Generated at 2022-06-23 04:00:04.783189
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pytest_plugins = [
        "ansible.plugins.modules.pip",
    ]
    from ansible.plugins.modules.pip import setup_virtualenv
    from ansible.module_utils.pip import Package
    setup_virtualenv(None, None, None, None, None)


# Generated at 2022-06-23 04:00:06.787343
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("foo-BAR1_._0") == "foo-bar1-0"



# Generated at 2022-06-23 04:00:18.456984
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert str(Package('foo')) == 'foo'
    assert str(Package('foo', '1.0')) == 'foo==1.0'
    assert str(Package('foo', '>1.0')) == 'foo>1.0'
    assert str(Package('foo', '>1.0,<2.0')) == 'foo>1.0,<2.0'
    # to fix https://github.com/ansible/ansible/pull/22338
    assert str(Package('foo', '>1.0,<2.0||3.0')) == 'foo>1.0,<2.0,!=3.0'
    # test with setuptools
    assert str(Package('setuptools')) == 'setuptools'

# Generated at 2022-06-23 04:00:32.262632
# Unit test for function main

# Generated at 2022-06-23 04:00:38.086636
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    testcases = (
        ("pkg==1", "1", True),
        ("pkg==1.0", "1.0", True),
        ("pkg==1", "1.0", False),
        ("pkg>=1", "1.0", True),
        ("pkg>1", "1.0", False),
        ("pkg<=1", "1.0", True),
        ("pkg<1", "1.0", True),
        ("pkg!=1", "1.0", True),
    )
    for test in testcases:
        p = Package(test[0])
        assert p.is_satisfied_by(test[1]) is test[2]



# Generated at 2022-06-23 04:00:51.362578
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def assert_is_satisfied_by(expected, name, version_string, version_to_test):
        pkg = Package(name, version_string)
        assert pkg.is_satisfied_by(version_to_test) == expected

    assert_is_satisfied_by(True, "foo", "==1.0.0", "1.0.0")
    assert_is_satisfied_by(False, "foo", "==1.0.0", "1.0.1")
    assert_is_satisfied_by(True, "foo", ">=1.0.0", "1.0.1")
    assert_is_satisfied_by(True, "foo", ">=1.0.0,<2.0.0", "1.0.1")


# Generated at 2022-06-23 04:01:03.186404
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package('MyPackage')
    assert str(pkg) == 'MyPackage'
    pkg = Package('MyPackage==1.0.0')
    assert str(pkg) == 'MyPackage==1.0.0'
    pkg = Package('MyPackage', '1.0.0')
    assert str(pkg) == 'MyPackage==1.0.0'
    pkg = Package('MyPackage', '>=1.0.0,<2.0.0,!=1.2.3,>=1.2.3')
    assert str(pkg) == 'MyPackage>=1.0.0,<2.0.0,!=1.2.3,>=1.2.3'

    # Old versions of setuptools (e.g. 0.6)
    # will not handle requirements

# Generated at 2022-06-23 04:01:05.192566
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    package = Package.canonicalize_name('python-Pillow')
    assert package == 'python-pillow'



# Generated at 2022-06-23 04:01:09.118859
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package('distribute', '0.6.34')
    assert str(pkg) == 'distribute==0.6.34'

    pkg = Package('distribute')
    assert str(pkg) == 'distribute'


# Generated at 2022-06-23 04:01:11.849220
# Unit test for method __str__ of class Package
def test_Package___str__():
    p1 = Package('foo')
    p2 = Package('foo', '2.0')
    assert str(p1) == 'foo'
    assert str(p2) == 'foo==2.0'



# Generated at 2022-06-23 04:01:22.719952
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """Tests a successful run of the setup_virtualenv function"""
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    test_dir = tempfile.mkdtemp()

    def run_command_test(cmd, cwd):
        """Function to simulate the AnsibleModule.run_command and returns the
        return code, out, and err as a tuple
        """
        return 0, '', ''

    class MockAnsibleModule(AnsibleModule):
        """A mock version of AnsibleModule"""

        def __init__(self, *args, **kwargs):
            super(MockAnsibleModule, self).__init__(*args, **kwargs)

            self.run_command = run_command_test


# Generated at 2022-06-23 04:01:33.859213
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    """Unit test for method is_satisfied_by of class Package.

    All test cases are from PEP 503
    """

# Generated at 2022-06-23 04:01:35.695270
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """Unit test for function setup_virtualenv.

    This hasn't been written yet.  The purpose of this test is to
    ensure the virtualenv is created properly when it is specified.
    """



# Generated at 2022-06-23 04:01:45.431309
# Unit test for method __str__ of class Package
def test_Package___str__():
    assert Package('test').__str__() == 'test'
    assert Package('test', '1.0').__str__() == 'test==1.0'
    assert Package('test', '<1.0').__str__() == 'test==1.0'
    assert Package('test', '>1.0').__str__() == 'test==1.0'
    assert Package('test', '>=1.0').__str__() == 'test==1.0'

    assert Package('test[extra,with-dash]', '1.0').__str__() == "test[extra,with-dash]==1.0"
    assert Package('test', '>=1.0').__str__() == "test==1.0"



# Generated at 2022-06-23 04:01:47.894536
# Unit test for method __str__ of class Package
def test_Package___str__():
    for name in ('Pip', 'pip', 'PIP', 'PiP'):
        package = Package(name)
        assert str(package) == 'pip'



# Generated at 2022-06-23 04:02:01.757518
# Unit test for function main
def test_main():
    fake_module = MagicMock()
    fake_module.params = dict(
        name=['p1', 'p2==1.0'],
        requirements='req_file.txt',
        executable=None,
        virtualenv='/some_path',
        state='present',
        virtualenv_site_packages=True,
        virtualenv_command='/usr/bin/virtualenv',
        virtualenv_python='python3',
        extra_args='--trusted-host',
        chdir='/fake_chdir',
        umask='022',
    )
    fake_module.check_mode = False

    # This is needed to use a side_effect on _fail() method
    fake_module.fail_json = MagicMock()

    args = dict(
        out='',
        err='',
    )



# Generated at 2022-06-23 04:02:08.176380
# Unit test for method __str__ of class Package
def test_Package___str__():
    p1 = Package("setuptools")
    p2 = Package("six", ">=1.9.0")
    assert "setuptools" == p1.__str__()
    assert "six>=1.9.0" == p2.__str__()



# Generated at 2022-06-23 04:02:14.640213
# Unit test for function main
def test_main():
    '''Test the main function'''
    # Test no args
    # Test no name or requirements
    # Test version is incompatible with state=latest
    # Test invalid combination of arguments
    # Test version conflicts with provided version specifier
    # Test using version
    # Test check mode
    # Test state=latest
    # Test extra_args
    # Test vcs
    # Test requirements
    # Test env
    # Test path_prefix
    # Test editable
    # Test chdir
    # Test executable
    # Test umask
    pass


# Generated at 2022-06-23 04:02:24.221592
# Unit test for function main

# Generated at 2022-06-23 04:02:35.260633
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # test for version specifier with '=='
    package = Package('package', '==1.2.3')
    assert package.is_satisfied_by('1.2.3') is True
    assert package.is_satisfied_by('1.2.4') is False
    assert package.is_satisfied_by('1.2.2') is False
    # test for version specifier with '<'
    package = Package('package', '<1.2.3')
    assert package.is_satisfied_by('1.2.2') is True
    assert package.is_satisfied_by('1.2.3') is False
    assert package.is_satisfied_by('1.2.4') is False
    # test for version specifier with '<='

# Generated at 2022-06-23 04:02:44.974177
# Unit test for function main
def test_main():
    # type: () -> None
    real_exit_json = AnsibleModule.exit_json
    real_fail_json = AnsibleModule.fail_json
    real_run_command = AnsibleModule.run_command
    real_open = open
    real_get_pip = _get_pip
    real_get_cmd_options = _get_cmd_options
    real_virtualenv_version = _virtualenv_version


# Generated at 2022-06-23 04:02:53.942356
# Unit test for constructor of class Package
def test_Package():
    # normal package name with version
    package = Package('mock', '1.3.0')
    assert package.package_name == 'mock'
    assert package.has_version_specifier
    assert package.is_satisfied_by('1.3.0')
    assert not package.is_satisfied_by('1.3.1')
    assert not package.is_satisfied_by('2.0.0')

    # normal package name without version
    package = Package('mock')
    assert package.package_name == 'mock'
    assert package.has_version_specifier == False
    assert package.is_satisfied_by('1.3.0')

    # package name with version specifier/s

# Generated at 2022-06-23 04:03:07.917208
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('test_pkg', '0.1.0')
    assert pkg.package_name == 'test-pkg'
    assert pkg.has_version_specifier == True
    assert str(pkg) == 'test-pkg==0.1.0'

    pkg = Package('test_pkg', '>0.1.0')
    assert pkg.package_name == 'test-pkg'
    assert pkg.has_version_specifier == True
    assert str(pkg) == 'test-pkg>0.1.0'

    pkg = Package('test_pkg')
    assert pkg.package_name == 'test-pkg'
    assert pkg.has_version_specifier == False
    assert str(pkg) == 'test-pkg'


# Used to validate whether or not packages should be removed.

# Generated at 2022-06-23 04:03:16.800971
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package = Package('python-pip')
    assert package.is_satisfied_by('9.0.1')
    package = Package('python-pip', '>=9.0.1')
    assert package.is_satisfied_by('9.0.1')
    assert package.is_satisfied_by('9.0.2')
    assert package.is_satisfied_by('10.0.0')
    assert not package.is_satisfied_by('9.0.0')
    assert not package.is_satisfied_by('8.0.0')
    assert not package.is_satisfied_by('8.0.0')
    package = Package('python-pip', '>=9.0.1,<9.0.3')

# Generated at 2022-06-23 04:03:24.802382
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("Foo-Bar1.baz") == "foo-bar1-baz"
    assert Package.canonicalize_name("Foo_Bar1.baz") == "foo-bar1-baz"
    assert Package.canonicalize_name("foo_bar1.baz") == "foo-bar1-baz"
    assert Package.canonicalize_name("foo-bar1.baz") == "foo-bar1-baz"
    assert Package.canonicalize_name("foo.bar1.baz") == "foo-bar1-baz"



# Generated at 2022-06-23 04:03:28.974867
# Unit test for method __str__ of class Package
def test_Package___str__():
    pkg = Package("package_name")
    assert str(pkg) == "package_name"

    pkg = Package("package_name", "1.1.1")
    assert str(pkg) == "package_name==1.1.1"

    pkg = Package("package_name", ">1.1.1")
    assert str(pkg) == "package_name>1.1.1"



# Generated at 2022-06-23 04:03:36.348028
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Arrange

    # Act
    p1 = Package("science", "==1.0.0.dev")
    p2 = Package("molecular_dynamics", "==0.99.0")

    # Assert
    assert str(p1) == "science==1.0.0.dev"
    assert str(p2) == "molecular_dynamics==0.99.0"



# Generated at 2022-06-23 04:03:39.165322
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():

    pkg = Package('testmod', '2.0')
    assert pkg.is_satisfied_by('2.0')


# Generated at 2022-06-23 04:03:45.174934
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    test_cases = [
        ('argh==0.26.2', '0.26.2', True),
        ('argh>=0.26', '0.26.2', True),
        ('argh>=0.27', '0.26.2', False),
        ('argh', '0.26.2', False)
    ]
    for pkg_string, version_to_test, expected_result in test_cases:
        pkg = Package(pkg_string, None)
        assert pkg.is_satisfied_by(version_to_test) == expected_result



# Generated at 2022-06-23 04:03:58.331235
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():

    def test_one(pkg_str, version_str, expected_result):
        pkg = Package(pkg_str, version_str)
        result = pkg.is_satisfied_by(pkg_str)
        assert result == expected_result, "is_satisfied_by test failed for: %s %s, got %s, expected %s"\
                                          % (pkg_str, version_str, result, expected_result)

    test_one("setuptools", None, False)
    test_one("setuptools", "==20.9.0", True)
    test_one("setuptools", ">=20.9.0", True)
    test_one("setuptools", ">=20.9.0,<20.10", True)

# Generated at 2022-06-23 04:04:08.065901
# Unit test for constructor of class Package
def test_Package():
    # Test the constructor with normal package name
    pkg0 = Package("bs4")
    assert not pkg0.has_version_specifier
    assert pkg0.is_satisfied_by("0.0.1")
    assert pkg0.package_name == "bs4"

    # Test the constructor with package name and version specifier
    pkg1 = Package("bs4", ">0.0.1")
    assert pkg1.has_version_specifier
    assert pkg1.is_satisfied_by("0.0.2")
    assert not pkg1.is_satisfied_by("0.0.0")
    assert pkg1.package_name == "bs4"

    # Test the constructor with package name and version specifier, with a complex specifier
    pkg2 = Package

# Generated at 2022-06-23 04:04:19.033491
# Unit test for constructor of class Package
def test_Package():
    name_strings = [
        'pip',
        'pip==1.0',
        'pip<=1.0',
    ]
    for name_string in name_strings:
        p = Package(name_string)
        assert p.package_name == 'pip'

    name_strings = [
        'django-haystack',
        'django-haystack==1.0',
        'django-haystack<=1.0',
    ]
    for name_string in name_strings:
        p = Package(name_string)
        assert p.package_name == 'django-haystack'


# Generated at 2022-06-23 04:04:30.625494
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    test_cases = [
        ("foo_name", "foo-name"),
        ("foo_name-bar_name", "foo-name-bar-name"),
        ("foo_name-bar_name", "foo-name-bar-name"),
        ("foo_name-2_1-bar_name", "foo-name-2-1-bar-name"),
        ("foo_name-2_1-bar_name", "foo-name-2-1-bar-name"),
        ("foo_name-2.1_1-bar_name", "foo-name-2.1-1-bar-name"),
        ("foo_name-2.1_1-bar_name", "foo-name-2.1-1-bar-name")
    ]

    for expected, name in test_cases:
        assert Package.canonical

# Generated at 2022-06-23 04:04:35.305737
# Unit test for constructor of class Package
def test_Package():
    package = Package('Foo')
    assert package.package_name == 'foo'
    assert package._plain_package == False
    assert package.has_version_specifier == False
    assert package.is_satisfied_by('1.0') == False

    package = Package('Foo', '1.0')
    assert package.package_name == 'foo'
    assert package._plain_package == True
    assert package.has_version_specifier == True
    assert package.is_satisfied_by('1.0') == True
    assert package.is_satisfied_by('1.1') == False
    assert package.is_satisfied_by('0.9') == False
    assert package.is_satisfied_by('2.0') == False


# Generated at 2022-06-23 04:04:36.357879
# Unit test for function main
def test_main():
    return main()


# Generated at 2022-06-23 04:04:41.624256
# Unit test for method __str__ of class Package
def test_Package___str__():
    package = Package("pytest")
    assert str(package) == "pytest"
    package = Package("pytest", "==3.0.0")
    assert str(package) == "pytest==3.0.0"



# Generated at 2022-06-23 04:04:52.567065
# Unit test for method __str__ of class Package
def test_Package___str__():
    for name_string, expected in [
        ('pip', 'pip'),
        ('pip==1.0', 'pip==1.0'),
        ('pip>=1.0', 'pip>=1.0'),
        ('pip>=1.1,<2.0', 'pip>=1.1,<2.0'),
        ('pip>=1.0,<1.1,!=1.2', 'pip>=1.0,<1.1,!=1.2'),
        ('distribute >=0.7.3', 'distribute>=0.7.3'),
        ('setuptools==1.0', 'setuptools==1.0'),
    ]:
        assert str(Package(name_string)) == expected

# Generated at 2022-06-23 04:05:01.840451
# Unit test for constructor of class Package

# Generated at 2022-06-23 04:05:14.548641
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pm = Package("test_package")
    # test equality operators
    assert pm.is_satisfied_by("1.0") == True
    assert pm.is_satisfied_by("2.0") == False
    # test not equal operators
    pm = Package("test_package", "!= 2.0")
    assert pm.is_satisfied_by("1.0") == True
    assert pm.is_satisfied_by("2.0") == False
    # test greater than operators
    pm = Package("test_package", "> 1.0")
    assert pm.is_satisfied_by("1.0") == False
    assert pm.is_satisfied_by("2.0") == True
    # test less than operators
    pm = Package("test_package", "< 2.0")


# Generated at 2022-06-23 04:05:20.052556
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import imp
    # TODO: test with ansible 2.3 env and py3
    imp.load_source('setup_virtualenv', os.path.realpath(os.path.join(os.path.dirname(__file__), '../../hacking/test-module-imports')))
    from ansible_collections.ansible.python.plugins.module_utils.basic import AnsibleModule
    params = {
        'name': 'foo',
        'virtualenv': '/tmp/foo',
        'virtualenv_command': 'virtualenv',
        'virtualenv_site_packages': True,
        'virtualenv_python': 'python2.7'
    }

# Generated at 2022-06-23 04:05:31.528130
# Unit test for constructor of class Package
def test_Package():
    pkg_test_data = [
        ["testpkg", "testpkg", True, False],
        ["testpkg == 1.1.1", "testpkg", True, True],
        ["testpkg>=1.0", "testpkg", True, True],
        ["testpkg-1.0", "testpkg", False, False],
        ["testpkg>=1.0,<2.0", "testpkg", True, True],
        ]

    for test in pkg_test_data:
        pkg = Package(test[0])
        if pkg.package_name != test[1]:
            raise Exception("fail to parse package name: got %s, expected %s" %(pkg.package_name, test[1]))

# Generated at 2022-06-23 04:05:42.413712
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Test module setup
    mock_module = type('MockModule', (object,), dict(
        check_mode=False,
        params=dict(
            virtualenv_command='virtualenv',
            virtualenv_python='python2',
            virtualenv_site_packages=True,
        ),
        run_command=mock.Mock(return_value=(0, '', '')),
        get_bin_path=mock.Mock(return_value='virtualenv'),
    ))
    mock_env = 'venv'
    mock_chdir = None
    mock_out = ''
    mock_err = ''

    # Run function
    out, err = setup_virtualenv(mock_module, mock_env, mock_chdir, mock_out, mock_err)

    # Assertions
    assert mock_module

# Generated at 2022-06-23 04:05:54.478981
# Unit test for constructor of class Package
def test_Package():
    from pkg_resources import Requirement

    name_string = 'Flask==0.6'
    version_string = '>= 0.6.1'

    flask_0_6 = Package(name_string)
    assert flask_0_6.package_name == 'flask'

    flask_0_6_1 = Package(name_string, version_string)
    assert flask_0_6_1._requirement == Requirement.parse(name_string + ',' + version_string)

    assert not flask_0_6.has_version_specifier
    assert flask_0_6_1.has_version_specifier

    assert flask_0_6.is_satisfied_by('0.6')
    assert flask_0_6.is_satisfied_by('0.6.0')

# Generated at 2022-06-23 04:06:05.926065
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name('foo') == 'foo'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('foo-bar') == 'foo-bar'
    assert Package.canonicalize_name('foo_bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('Foo.bar') == 'foo-bar'
    assert Package.canonicalize_name('foo.bar-baz') == 'foo-bar-baz'


# Generated at 2022-06-23 04:06:22.248457
# Unit test for function main

# Generated at 2022-06-23 04:06:29.268957
# Unit test for method __str__ of class Package
def test_Package___str__():
    # Tests for method __str__
    # of class Package
    # with str-obj as input
    pkg = Package("foo", "1.0")
    assert str(pkg) == "foo==1.0"

    pkg = Package("foo", ">=1.0")
    assert str(pkg) == "foo>=1.0"

    # with instance as input
    pkg = Package("foo", Package("bar", "1.0"))
    assert str(pkg) == "foo==bar==1.0"

    pkg = Package("foo", Package("bar", ">=1.0"))
    assert str(pkg) == "foo==bar>=1.0"


# Generated at 2022-06-23 04:06:40.002819
# Unit test for function main

# Generated at 2022-06-23 04:06:44.289647
# Unit test for method __str__ of class Package
def test_Package___str__():
    p1 = Package('foo')
    p2 = Package('foo', '>=3.4')
    assert_equal(str(p1), 'foo')
    assert_equal(str(p2), 'foo >=3.4')



# Generated at 2022-06-23 04:06:56.904765
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    """
    Unit test for method is_satisfied_by of class Package
    :return:
    """
    assert Package('foo').is_satisfied_by('0.0.0')
    assert Package('foo==1.0').is_satisfied_by('1.0')
    assert Package('foo==1.0').is_satisfied_by('1.0.0')
    assert Package('foo~=1.0').is_satisfied_by('1.0')
    assert Package('foo~=1.0').is_satisfied_by('1.0.0')
    assert Package('foo~=1.0').is_satisfied_by('1.1')
    assert Package('foo~=1.0').is_satisfied_by('1.1.0')
    assert Package

# Generated at 2022-06-23 04:07:09.333740
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    import unittest
    import pkg_resources

    class TestPackage(unittest.TestCase):
        def test_is_satisfied_by_case_1(self):
            package = Package('pip', '>=7.0.0')
            self.assertTrue(package.is_satisfied_by('7.1.2'))
            self.assertFalse(package.is_satisfied_by('7.0.0'))

        def test_is_satisfied_by_case_2(self):
            package = Package('ansible', '2.2.0.0')
            self.assertTrue(package.is_satisfied_by('2.2.0.0'))
            self.assertFalse(package.is_satisfied_by('2.2.1.0'))

# Generated at 2022-06-23 04:07:18.273036
# Unit test for method __str__ of class Package
def test_Package___str__():
    package_str = Package("Django").__str__()
    assert package_str == "Django"
    package_str = Package("Django", "1.8").__str__()
    assert package_str == "Django==1.8"
    package_str = Package("Django", ">=1.8.*").__str__()
    assert package_str == "Django>=1.8.*"


# Generated at 2022-06-23 04:07:29.816334
# Unit test for function main
def test_main():
    import ansible.module_utils
    import ansible.modules.extras.packaging.language.pip
    import ansible.modules.extras.packaging.language.pip.Package
    import ansible.modules.extras.packaging.language.pip.main
    import ansible.modules.extras.packaging.language.pip.setup_virtualenv
    import ansible.modules.extras.packaging.language.pip._fail
    import ansible.modules.extras.packaging.language.pip._get_package_info
    import ansible.modules.extras.packaging.language.pip._get_packages
    import ansible.modules.extras.packaging.language.pip._is_present
    import ansible.modules.extras.packaging.language.pip._recover_

# Generated at 2022-06-23 04:07:42.782924
# Unit test for constructor of class Package
def test_Package():
    # Negative test
    assert str(Package('pywin32')) == 'pywin32'
    # test '==' version specifier
    assert str(Package('pywin32', '==')) == 'pywin32=='
    assert str(Package('pywin32', '==2.64')) == 'pywin32==2.64'
    assert str(Package('pywin32', '== 2.64')) == 'pywin32==2.64'
    # test '>' version specifier
    assert str(Package('pywin32', '>')) == 'pywin32>'
    assert str(Package('pywin32', '>2.64')) == 'pywin32>2.64'
    assert str(Package('pywin32', '> 2.64')) == 'pywin32>2.64'


# Generated at 2022-06-23 04:07:50.598143
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import ansible.constants as C
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    module = AnsibleModule(
        argument_spec = dict(
            virtualenv_command = dict(type='str', default='virtualenv', aliases=['virtualenv']),
            virtualenv_site_packages = dict(type='bool', default=False),
            virtualenv_python = dict(type='str', default=None),
            virtualenv=dict(type='str'),
        ),
        supports_check_mode=True
    )
    result = {}
    chdir = ''
    cmd = shlex.split(module.params['virtualenv_command'])

# Generated at 2022-06-23 04:08:03.609668
# Unit test for constructor of class Package
def test_Package():
    # test constructor of class Package
    assert Package("pycparser").package_name == 'pycparser'
    assert Package("pycparser==2.19").package_name == 'pycparser'
    assert Package("pycparser>=2.19").package_name == 'pycparser'
    assert Package("pycparser<2.19").package_name == 'pycparser'
    assert Package("pycparser>=2.19,<2.20").package_name == 'pycparser'
    assert Package("pycparser>=2.19,<2.20").has_version_specifier
    assert not Package("pycparser").has_version_specifier
    assert Package("pycparser==2.19").is_satisfied_by("2.19")

# Generated at 2022-06-23 04:08:15.325225
# Unit test for constructor of class Package
def test_Package():
    p1 = Package('setuptools')
    assert p1.package_name == "setuptools"
    assert p1.has_version_specifier == False
    assert p1.is_satisfied_by('18.5') == True
    assert p1.is_satisfied_by('1.1') == False

    p2 = Package('requests', '2.2.0')
    assert p2.package_name == "requests"
    assert p2.has_version_specifier == True
    assert p2.is_satisfied_by('2.2.1') == True
    assert p2.is_satisfied_by('100.0.0') == False

    p3 = Package('requests', '!=2.2.0')

# Generated at 2022-06-23 04:08:22.983369
# Unit test for method canonicalize_name of class Package
def test_Package_canonicalize_name():
    assert Package.canonicalize_name("PACKAGE") == "package"
    assert Package.canonicalize_name("package") == "package"
    assert Package.canonicalize_name("package-name") == "package-name"
    assert Package.canonicalize_name("package_name") == "package-name"
    assert Package.canonicalize_name("package.name") == "package-name"
    assert Package.canonicalize_name("package---name") == "package-name"
    assert Package.canonicalize_name("package---name---") == "package-name-"
    assert Package.canonicalize_name("_package_name_") == "package-name"

