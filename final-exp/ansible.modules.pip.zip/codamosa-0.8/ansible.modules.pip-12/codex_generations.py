

# Generated at 2022-06-11 07:36:26.408195
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """ Test setup_virtualenv function """
    module = AnsibleModule({})
    env = 'test_env'
    chdir = ''
    out = ''
    err = ''
    assert(setup_virtualenv(module, env, chdir, out, err) == ('', ''))



# Generated at 2022-06-11 07:36:32.616343
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    import py
    import pytest
    from ansible.module_utils.six import StringIO

    stdin = pytest.builtins.open(os.path.join(os.path.dirname(__file__), 'fixtures/virtualenv.json'), 'rb')
    stdout = StringIO()
    stderr = StringIO()
    sys.stdin = stdin
    sys.stdout = stdout
    sys.stderr = stderr


# Generated at 2022-06-11 07:36:37.082667
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Examples from PEP 440
    assert Package("SomeProject").is_satisfied_by("1.3.0")
    assert Package("SomeProject").is_satisfied_by("1.4")
    assert Package("SomeProject").is_satisfied_by("1.4.1")
    assert Package("SomeProject").is_satisfied_by("2.0")
    assert not Package("SomeProject").is_satisfied_by("1.4.1.post1")
    assert Package("SomeProject", version_string=">1.3").is_satisfied_by("1.4.dev")
    assert Package("SomeProject", version_string=">1.3").is_satisfied_by("1.5")
    assert not Package("SomeProject", version_string=">1.3").is_satisf

# Generated at 2022-06-11 07:36:48.875355
# Unit test for constructor of class Package
def test_Package():
    assert Package('foo').package_name == 'foo'
    assert Package('foo', '1.0').package_name == 'foo'
    assert Package('foo', '1.0')._requirement.extras == ()
    assert str(Package('foo', '1.0')) == '[foo, 1.0]'
    assert str(Package('foo', '1.0, 2.0')) == '[foo, 1.0, 2.0]'
    assert str(Package('foo', 'bar')) == '[foo, bar]'
    assert str(Package('foo', '>=1.0,<2.0')) == '[foo, >=1.0,<2.0]'

# Generated at 2022-06-11 07:36:53.152175
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    #  when version specifier contains a equality relationship
    result = Package('pytz', '2014.7').is_satisfied_by('2014.7')
    assert result

    # when version specifier contains a equality relationship
    result = Package('pytz', '2014.7').is_satisfied_by('2014.7a0')
    assert not result

    # when version specifier contains a equality relationship
    # and requirement has a pre-release suffix
    result = Package('pytz', '2014.7a0').is_satisfied_by('2014.7')
    assert not result

    # when version specifier contains a equality relationship
    # and requirement has a pre-release suffix
    result = Package('pytz', '2014.7a0').is_satisfied_by('2014.7a0')
    assert result

    #

# Generated at 2022-06-11 07:37:03.749387
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # If a virtualenv_command is not provided
    # by the user, the command must fail.
    # This test is important to ensure the
    # function is not accidentally changed
    # to create a virtualenv using the default
    # module param values.
    if 'virtualenv_command' in os.environ:
        del os.environ['virtualenv_command']
    with pytest.raises(AnsibleFailJson) as excinfo:
        setup_virtualenv(FakeModule(), '', '', '', '')
    assert excinfo.value.args[0]['msg'] == 'virtualenv_command must be specified if virtualenv is specified.'
    os.environ['virtualenv_command'] = "test_virtualenv"



# Generated at 2022-06-11 07:37:13.124259
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pytest.skip("This test is currently broken and needs to be fixed. See: https://github.com/ansible/ansible/pull/46439")

    # Assume that version_requirements
    # string represents what the user of pip module
    # wants to install. version_installed
    # string represents what is already installed
    # and may be different from what is actually
    # installed on the system.
    # A test case passes if Package()
    # object set with version_requirements is satisfied
    # by the version_installed.

# Generated at 2022-06-11 07:37:20.210076
# Unit test for function main
def test_main():

    class TestAnsibleModule(object):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def fail_json(self, msg):
            assert None

        def check_mode(self):
            assert None

        def exit_json(self, changed):
            assert None

        def run_command(self, cmd):
            assert None

        def warn(self, msg):
            assert None

    class TestPipCommand(object):
        def __init__(self, pip):
            self.pip = pip

        def __str__(self):
            return self.pip

    class TestGetPackage(object):
        def __init__(self, pkg, version, parsed_pkg, package_spec):
            self.package = pkg
            self.version = version
            self

# Generated at 2022-06-11 07:37:27.143743
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = FakeModule()
    env = '/test_env'
    chdir = '/test_chdir'
    setup_virtualenv(module, env, chdir, 'test', 'err')
    assert module.run_command.call_count == 1
    assert module.run_command.call_args == [((['python', '-m', 'virtualenv', '--no-site-packages', env],), {'cwd': chdir})]


# Generated at 2022-06-11 07:37:33.588027
# Unit test for function main
def test_main():
    argv=['/bin/ansible-local',
        '-m', 'easy_install',
        '-a', 'name=openssh',
        '-e', 'virtualenv=/var/tmp/.ansible_venv',
        '-e', 'virtualenv_command=pyvenv',
        '-e', 'virtualenv_python=/usr/bin/python3.5']
    cmd=sys.argv=argv
    main()



# Generated at 2022-06-11 07:38:25.881813
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # FIXME: Move to an integration test suite
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['present', 'absent']),
            name=dict(type='list', elements='str', aliases=['pkg', 'package'], required=True),
            virtualenv=dict(default=None),
            virtualenv_site_packages=dict(default=False, type='bool'),
            virtualenv_command=dict(default='virtualenv'),
            requirements=dict(type='path'),
            executable=dict(type='path'),
            virtualenv_python=dict(default=None),
        ),
        supports_check_mode=True,
    )
    setup_virtualenv(module, 'test_env', os.getcwd(), '', '')
    assert os.path.ex

# Generated at 2022-06-11 07:38:26.519877
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    return



# Generated at 2022-06-11 07:38:37.439537
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    """ unit test for is_satisfied_by of class Package """

    # test for plain package
    _package = Package('pip')
    assert not _package.is_satisfied_by('1')

    _package = Package('pip==1.2.3')
    assert _package.is_satisfied_by('1.2.3')
    assert not _package.is_satisfied_by('1.2.4')

    _package = Package('pip>1')
    assert _package.is_satisfied_by('2')
    assert not _package.is_satisfied_by('1')

    _package = Package('pip>1,<2')
    assert _package.is_satisfied_by('1.9.9')
    assert not _package.is_satisfied

# Generated at 2022-06-11 07:38:38.043717
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-11 07:38:43.579980
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package("pkg", "==4.4.4")
    assert pkg.is_satisfied_by("4.4.4")
    assert not pkg.is_satisfied_by("4.4.5")
    pkg = Package("pkg", ">=4.4.4")
    assert pkg.is_satisfied_by("4.4.5")
    assert not pkg.is_satisfied_by("4.4.3")


# Generated at 2022-06-11 07:38:45.297202
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:46.775419
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv() == 'test_setup_virtualenv'


# Generated at 2022-06-11 07:38:58.141774
# Unit test for function main
def test_main():
    # argv is used as it's the only way to pass custom cmdline arguments
    # to AnsibleModule.
    sys.argv.extend(['fake-name', 'fake-version', 'fake-command'])

    # Make sure we don't break any other globals.
    old_argv = sys.argv
    old_modules = sys.modules
    old_path = sys.path
    old_ps1 = os.environ.get('PS1')

    # Stub out the items that will trigger a module fail
    if 'pip' in sys.modules:
        del sys.modules['pip']
    if 'setuptools' in sys.modules:
        del sys.modules['setuptools']
    sys.path = []
    os.environ['PS1'] = 'foo'

# Generated at 2022-06-11 07:39:07.997361
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from distutils.version import LooseVersion
    pkg = Package("foo", "1.0.0")
    assert pkg.is_satisfied_by("1.0.0")
    assert pkg.is_satisfied_by("1.0")
    assert not pkg.is_satisfied_by("0.99")
    pkg = Package("foo", ">1.0")
    assert pkg.is_satisfied_by("1.1")
    assert pkg.is_satisfied_by("1.1.0")
    assert pkg.is_satisfied_by("1.1.9")
    assert not pkg.is_satisfied_by("1.0")
    pkg = Package("foo", ">=1.0,<2.0")

# Generated at 2022-06-11 07:39:14.654121
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    test_module = AnsibleModule(argument_spec={
            'virtualenv_command': dict(type='str', default='/usr/bin/virtualenv'),
            'virtualenv_python': dict(type='str'),
            'virtualenv_site_packages': dict(type='bool', default=False),
    }, supports_check_mode=True)
    test_setup_virtualenv(test_module, env = 'venv', chdir = '', out = '', err = '')



# Generated at 2022-06-11 07:40:08.911962
# Unit test for function main
def test_main():
    def _good_name_with_version(self, name, version):
        return (
            name.startswith('bpython') and version == '0.13.dev0'
        )

    def _good_name(self, name):
        return (
            name == 'unittest2' or
            name == 'coverage==4.5.1'
        )

    def _good_name_with_license(self, name):
        return (
            name.startswith('bpython')
        )

    def run_function(function_name, **kwargs):
        if function_name == '_good_name_with_version':
            return _good_name_with_version(**kwargs)
        elif function_name == '_good_name':
            return _good_name(**kwargs)


# Generated at 2022-06-11 07:40:14.384417
# Unit test for function main

# Generated at 2022-06-11 07:40:16.177386
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-11 07:40:21.056172
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = None
    test_env = '/tmp/test_env'
    test_chdir = '/tmp'
    test_out = ''
    test_err = ''
    test_out, test_err = setup_virtualenv(module, test_env, test_chdir, test_out, test_err)
    assert test_err == ''
    assert "New python executable in /tmp/test_env/bin/python" in test_out
test_setup_virtualenv()



# Generated at 2022-06-11 07:40:29.331619
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(
        virtualenv_command="pyvenv",
        virtualenv_python=None,
    ))
    # No system-site-packages option is included because venv does not interpret --system-site-packages
    cmd = shlex.split("pyvenv")
    virtualenv_python = module.params['virtualenv_python']

    if virtualenv_python:
        cmd.append('-p%s' % virtualenv_python)
    elif PY3:
        cmd.append('-p%s' % sys.executable)

    cmd.append("/tmp/venv")
    assert cmd == setup_virtualenv(module, "/tmp/venv", "/tmp", "", "")[0]

    module = Ans

# Generated at 2022-06-11 07:40:38.390745
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    import pytest

    def is_satisfied_by(requirement_string, version_string, expected_result):
        package_instance = Package(requirement_string)
        result = package_instance.is_satisfied_by(version_string)
        assert result == expected_result, 'is_satisfied_by("%s", "%s") = %s, expected %s.' % (requirement_string, version_string, result, expected_result)

    # Test cases for is_satisfied_by

# Generated at 2022-06-11 07:40:46.128273
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import *
    from ansible.module_utils.local_ansible_utils_extension import *
    from ansible.module_utils.pip import *
    from ansible.modules.packaging.os import pip
    from ansible.module_utils.six import PY3
    if PY3:
        import pathlib
        env=pathlib.Path('env')
    else:
        env='env'
    chdir='.'
    out=''
    err=''
    out, err=setup_virtualenv(None, env, chdir, out, err)
    assert 1==1


# Generated at 2022-06-11 07:40:47.713169
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """Unit test for function setup_virtualenv."""
    # TODO: implement unit test
    pass



# Generated at 2022-06-11 07:40:56.258111
# Unit test for function main

# Generated at 2022-06-11 07:41:06.726717
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """
    Unit test for function setup_virtualenv
    """
    from ansible_collections.jctanner.pip_utils.plugins.modules.pip import setup_virtualenv

    # Test 1
    module = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/test/test-lib/test.py"
    env = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/test/test-lib/venv"
    chdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "/test/test-lib"
    out = ""
    err = ""
    setup

# Generated at 2022-06-11 07:43:16.182311
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = None
    assert setup_virtualenv(module, "env","chdir","out","err") == ('outout', 'errerr')


# Generated at 2022-06-11 07:43:27.438516
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """ Test if setup_virtualenv function return a venv path """
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        return {}

    class MockModule(AnsibleModule):
        def _execute_module(self, cmd, tmp=None, cwd=None):
            return 0, "", ""
    module = MockModule(argument_spec = {
        'virtualenv_command': dict(type='str', required=True),
        'virtualenv_site_packages': dict(type='bool', required=False),
        'virtualenv_python': dict(type='str', required=False)
    })
    env = 'mock_env'
    chdir = 'mock_dir'
    out = ''
    err = ''


# Generated at 2022-06-11 07:43:32.578585
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule({'virtualenv_command': '/bin/pyvenv', 'virtualenv_site_packages': False})
    env = 'test_venv'
    chdir = '/tmp'
    out = ''
    err = ''
    out_venv, err_venv = setup_virtualenv(module, env, chdir, out, err)
    cmd = ['/bin/pyvenv', 'test_venv']
    assert out_venv, cmd
    assert not err_venv



# Generated at 2022-06-11 07:43:41.503128
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:43:50.888678
# Unit test for constructor of class Package
def test_Package():
    package = Package('ansible')
    assert_equal(package.package_name, 'ansible')
    assert_equal(package.has_version_specifier, False)
    assert_equal(package.is_satisfied_by('2.0.1'), True)
    package = Package('ansible', '2.0.0')
    assert_equal(package.package_name, 'ansible')
    assert_equal(package.has_version_specifier, True)
    assert_equal(package.is_satisfied_by('2.0.0'), True)
    package = Package('ansible', '>=2.0.0')
    assert_equal(package.package_name, 'ansible')
    assert_equal(package.has_version_specifier, True)

# Generated at 2022-06-11 07:43:59.233799
# Unit test for function setup_virtualenv
def test_setup_virtualenv():

    class FakeModule:
        class FakeMD:
            params = {'virtualenv_command':'',
                        'virtualenv_python':'',
                        'virtualenv_site_packages':True,
                        'virtualenv_command':'',
                        'virtualenv_python':'',
                        'virtualenv_site_packages':True}
        module = FakeMD()
        params = {'path':str(pathlib.Path(__file__).parent),
                    'env':'',
                    'use_mirrors':True,
                    'pip_path':'',
                    'executable':'',
                    'virtualenv_command':'',
                    'virtualenv_python':'',
                    'virtualenv_site_packages':True}
        module.params = params
        path = params['path']
        env = params['env']
        use

# Generated at 2022-06-11 07:44:05.678026
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = Mock()
    module.params = {'virtualenv_command': 'virtualenv', 'virtualenv_site_packages': False, 'virtualenv_python': None}
    env = "venv"
    chdir = os.getcwd()
    out = 'mock out'
    err = 'mock err'
    out_venv, err_venv = setup_virtualenv(module, env, chdir, out, err)
    assert out == "mock out"
    assert err == "mock err"
    assert out_venv == "mock out"
    assert err_venv == "mock err"



# Generated at 2022-06-11 07:44:14.885817
# Unit test for function main

# Generated at 2022-06-11 07:44:21.843086
# Unit test for function main
def test_main():
    args = dict(
        name=['pkg1', 'pkg2'],
        requirements=['requirements.txt'],
        state='present',
        executable='/usr/bin/pip',
    )
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', default='present', choices=['present', 'latest', 'absent', 'forcereinstall']),
            name=dict(type='list', elements='str'),
            version=dict(type='str'),
            requirements=dict(type='str'),
            extra_args=dict(type='str'),
            chdir=dict(type='path'),
            executable=dict(type='path'),
        )
    )
    main(m, **args)

if __name__ == '__main__':
    main()