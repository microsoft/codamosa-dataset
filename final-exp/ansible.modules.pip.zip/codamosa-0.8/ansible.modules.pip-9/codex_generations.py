

# Generated at 2022-06-11 07:36:44.366418
# Unit test for function main
def test_main():
    with tempfile.NamedTemporaryFile() as requirements:
        requirements.write(to_bytes(DUMMY_REQUIREMENTS))
        requirements.flush()
        args = {
            'state': 'present',
            'requirements': requirements.name,
            'virtualenv': '/tmp/venv',
            'virtualenv_command': '/usr/local/bin/virtualenv',
            'virtualenv_python': 'python3',
            'virtualenv_site_packages': True,
        }

# Generated at 2022-06-11 07:36:48.928142
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = DummyAnsibleModule({'virtualenv_command': 'python3 -m venv', 'virtualenv_python': None, 'virtualenv_site_packages': False})
    env = '/tmp'
    out, err = '', ''
    assert setup_virtualenv(module, env, 'cwd', out, err) == ('', '')


# Generated at 2022-06-11 07:36:57.807347
# Unit test for function main

# Generated at 2022-06-11 07:37:08.236894
# Unit test for function main
def test_main():
    # Test module parameters of `main`
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves.builtins import zip
    from ansible.module_utils.six.moves import builtins
    import ansible
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

# Generated at 2022-06-11 07:37:08.913325
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-11 07:37:18.950582
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    # Since we patch the run_command function to return
    # fake results we cannot test the actual results,
    # so this test is only testing the function is called
    # with the correct arguments.
    fake_module = Mock()
    fake_env = '/tmp/env'
    fake_chdir = '/tmp'
    fake_out = ''
    fake_err = ''
    fake_run_command_res = 0, '', ''
    fake_python_bin = '/usr/bin/python'


# Generated at 2022-06-11 07:37:23.969646
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule()
    env = '/test/env'
    chdir = '/test'
    out = ''
    err = ''
    (out_result, err_result) = setup_virtualenv(module, env, chdir, out, err)
    assert out_result != out
    assert err_result != err


# Generated at 2022-06-11 07:37:34.891350
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import shutil
    import tempfile
    import json
    import subprocess

    env = tempfile.mkdtemp()

    # Build a fake AnsibleModule
    class FakeAnsibleModule(object):
        def __init__(self, params):
            self.params = params

        def check_mode(self):
            return self.params['check_mode']

        def fail_json(self, **kwargs):
            self._exit_json(failed=True, **kwargs)

        def exit_json(self, *args, **kwargs):
            self._exit_json(*args, **kwargs)

        def get_bin_path(self, arg, required, opt_dirs):
            return arg


# Generated at 2022-06-11 07:37:45.922102
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package('test_pkg', '<=0.0.3')
    # version 0.0.3 is expected to be satisfied by version 0.0.3
    assert pkg.is_satisfied_by('0.0.3')

    # version 0.1.0 is expected to be NOT satisfied by version 0.0.3
    assert pkg.is_satisfied_by('0.1.0') is False

    pkg = Package('test_pkg2', '>1.10.0')

    assert pkg.is_satisfied_by('1.10.0') is False

    assert pkg.is_satisfied_by('1.11.0')

    pkg = Package('test_pkg', '>2.0.1')
    # version 2.0.0 is expected to be NOT

# Generated at 2022-06-11 07:37:47.526696
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:25.933596
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():  # type: () -> None
    # unit test for method is_satisfied_by of class Package
    # test cases
    # not plain package, always return False
    assert Package("test").is_satisfied_by("test_version") is False
    # plain package, no version specifier, always return True
    assert Package("test==").is_satisfied_by("test_version") is True
    # plain package, with version specifier, need to test
    # case 1: no version constraints
    assert Package("test==1.0").is_satisfied_by("1.0") is True
    assert Package("test==1.1").is_satisfied_by("1.0") is False
    # case 2: <

# Generated at 2022-06-11 07:38:36.950243
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import tempfile
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os import pip

# Generated at 2022-06-11 07:38:44.921063
# Unit test for function main
def test_main():
    test_result = {}

# Generated at 2022-06-11 07:38:45.564381
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    return



# Generated at 2022-06-11 07:38:56.906242
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    class MockModule(object):
        def __init__(self, chdir, virtualenv_command, virtualenv_site_packages, virtualenv_python):
            self.params = {
                'chdir' : chdir,
                'virtualenv_command' : virtualenv_command,
                'virtualenv_site_packages' : virtualenv_site_packages,
                'virtualenv_python' : virtualenv_python
            }
        def run_command(self, cmd, cwd=None, environ_update=None):
            print('Called run command with', cmd)
            return 0, '', ''
        def get_bin_path(self, cmd, required=True, opt_dirs=[]):
            print('Called get bin path with', cmd)
            return '/bin/python3'

# Generated at 2022-06-11 07:38:58.413166
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert setup_virtualenv(None, None, None, None, None) is None



# Generated at 2022-06-11 07:39:06.956691
# Unit test for function main
def test_main():
    test_dict = {
        "name": None,
        "requirements": None,
        "editable": False,
        "extra_args": None,
        "executable": None,
        "state": "present",
        "umask": None,
        "virtualenv": None,
        "virtualenv_command": "virtualenv",
        "virtualenv_python": None,
        "virtualenv_site_packages": False,
        "version": None
    }

    try:
        main(self, lambda s: s, test_dict)
    except Exception as e:
        assert False, e


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:39:18.102825
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    cmd = ['virtualenv', '--no-site-packages', '-p%s' % sys.executable, 'python2', '--system-site-packages']
    module.params['virtualenv_command'] = ['virtualenv', '--no-site-packages', '-p%s' % sys.executable, 'python2', '--system-site-packages']
    module.params['virtualenv_site_packages'] = False
    virtualenv_python = module.params['virtualenv_python']
    msg = 'virtualenv_python should not be used when' \
                ' using the venv module or pyvenv as virtualenv_command'
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert out == 0
    assert err ==""

# Generated at 2022-06-11 07:39:28.436923
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    assert Package("").is_satisfied_by("") is False
    # plain packages
    assert Package("setuptools").is_satisfied_by("19.2") is False
    assert Package("setuptools==19.2").is_satisfied_by("") is False
    assert Package("setuptools==19.2").is_satisfied_by("19.2.0")
    assert Package("setuptools==19.2.0").is_satisfied_by("19.2")
    assert Package("setuptools>=19.2").is_satisfied_by("19.2.0")
    assert Package("setuptools==19.2.0").is_satisfied_by("19.2.1rc1")
    assert Package("setuptools==19.2.0").is_s

# Generated at 2022-06-11 07:39:38.751452
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import pytest
    from ansible.module_utils.basic import AnsibleModule, get_exception
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    environ = {
        'PATH': ':'.join([
            os.path.abspath('/bin'),
            os.path.abspath('/usr/bin'),
            os.path.abspath('/usr/local/bin'),
        ]),
    }

    failed_commands = []
    def run_command(cmd, cwd, environ_update=None, check_rc=True, encoding=None):
        if isinstance(cmd, str):
            cmd = shlex.split(cmd)

# Generated at 2022-06-11 07:40:47.671072
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    M = AnsibleModule
    m = M(virtualenv_command='python -m venv', virtualenv_site_packages=True)
    cmd = ['python', '-m', 'venv', '--system-site-packages']
    setup_virtualenv(m, 'test', '.', 'out', 'err')
    assert_equal(m.run_command.called, True)
    assert_equal(m.run_command.call_args[0][0], cmd)
    assert_equal(m.run_command.call_args[1]['cwd'], '.')


# Generated at 2022-06-11 07:40:54.332935
# Unit test for function main
def test_main():
    import os
    import tempfile
    def init(**kwargs):
        name = 'foo'
        version = None
        requirements = None
        extra_args = None
        state = 'present'
        virtualenv = None
        virtualenv_site_packages = False
        executable = None
        editable = False
        chdir = None
        umask = None
        params = {'requirements': requirements,
                  'extra_args': extra_args,
                  'virtualenv': virtualenv, 'virtualenv_site_packages': virtualenv_site_packages,
                  'virtualenv_command': 'virtualenv', 'virtualenv_python': None,
                  'name': name, 'version': version, 'state': state, 'executable': executable,
                  'editable': editable, 'chdir': chdir, 'umask': umask}

# Generated at 2022-06-11 07:41:05.064743
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('pytz')
    assert pkg.package_name == 'pytz'
    assert pkg.has_version_specifier is False

    pkg = Package('pytz', '2012g')
    assert pkg.package_name == 'pytz'
    assert pkg.has_version_specifier is True

    pkg = Package('setuptools', '<20.7.0')
    assert pkg.package_name == 'setuptools'
    assert pkg.has_version_specifier is True

    pkg = Package('cffi', '>= 1.4.1')
    assert pkg.package_name == 'cffi'
    assert pkg.has_version_specifier is True


# Generated at 2022-06-11 07:41:13.015081
# Unit test for constructor of class Package
def test_Package():
    for input, package_name, requirement in (
            ("abcd", "abcd", None),
            ("abcd<=2", "abcd", "abcd <=2"),
            ("abcd>=1.1", "abcd", "abcd >=1.1"),
            ("abcd", "abcd", None),
            ("abcd", "abcd", None),
            ("abcd<1.1", "abcd", "abcd <1.1"),
            ("abcd>1.1", "abcd", "abcd >1.1")):
        pkg = Package(input)
        assert pkg.package_name == package_name
        if requirement:
            assert str(pkg._requirement.specifier) == requirement


# Generated at 2022-06-11 07:41:13.658778
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-11 07:41:22.112582
# Unit test for function main
def test_main():
    test_args = dict(
        state='present',
        name=['requests'],
        version=None,
        requirements=None,
        virtualenv=None,
        virtualenv_site_packages=False,
        virtualenv_command='virtualenv',
        extra_args=None,
        editable=False,
        chdir=None,
        executable=None,
        umask=None,
    )

    set_module_args(test_args)

    global HAS_SETUPTOOLS
    HAS_SETUPTOOLS = True  # prevent exit_json
    global SETUPTOOLS_IMP_ERR
    SETUPTOOLS_IMP_ERR = None  # prevent exit_json

    from ansible.modules.packaging.language.pip import main as pip_main

    pip_

# Generated at 2022-06-11 07:41:27.259701
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule({})
    env = ""
    chdir = ""
    out = ""
    err = ""
    test_setup_virtualenv = setup_virtualenv(module, env, chdir, out, err)
    assert test_setup_virtualenv == "", "unittest failed"
    return True
test_setup_virtualenv()



# Generated at 2022-06-11 07:41:38.420088
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    assert not Package(
        "some_package==1.2.3").is_satisfied_by("0.9.9")
    assert Package(
        "some_package==1.2.3").is_satisfied_by("1.2.3")
    assert not Package(
        "some_package==1.2.3").is_satisfied_by("1.2.4")
    assert Package(
        "some_package>=1.2.3").is_satisfied_by("1.2.3")
    assert Package(
        "some_package>=1.2.3").is_satisfied_by("1.2.4")
    assert not Package(
        "some_package>=1.2.3").is_satisfied_by("1.2.2")
   

# Generated at 2022-06-11 07:41:45.530541
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    p_2 = Package('python-software-properties', '>=0.82.5')
    assert p_2.is_satisfied_by('0.82.5') == True
    assert p_2.is_satisfied_by('0.85') == True
    assert p_2.is_satisfied_by('0.81') == False

    p_3 = Package('python-software-properties')
    assert p_3.is_satisfied_by('0.82.5') == True
    assert p_3.is_satisfied_by('0.85') == True
    assert p_3.is_satisfied_by('0.81') == True

    p_4 = Package('python-software-properties', '2.1.1')
    assert p_4.is_satisfied

# Generated at 2022-06-11 07:41:50.891791
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from nose.tools import assert_equal, assert_true, assert_false
    package = Package('foo')
    assert_false(package.is_satisfied_by('1.0.0'))

    package = Package('foo==1.0.0')
    assert_true(package.is_satisfied_by('1.0.0'))
    assert_false(package.is_satisfied_by('1.1.0'))

    package = Package('foo>=1.0.0,<2.0.0')
    assert_true(package.is_satisfied_by('1.0.0'))
    assert_true(package.is_satisfied_by('1.1.0'))
    assert_false(package.is_satisfied_by('2.0.0'))

# Generated at 2022-06-11 07:44:34.602316
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.utils.path import makedirs_safe
    import tempfile
    from ansible.module_utils.common._text import to_bytes

    tmpdir = tempfile.mkdtemp()
    pipname = 'pip'
    venv_dir = os.path.join(tmpdir, 'venv_dir')
    python_dir = os.path.join(venv_dir, 'bin', 'python')

    if not os.path.exists(venv_dir):
        makedirs_safe(venv_dir)

    virtualenv_cmd = "echo foo"
    virtualenv_user_site_packages = True
    virtualenv_python = 'python3'
    env = {'PATH': os.environ.get('PATH', ''), 'HOME': os.environ.get('HOME', '')}


# Generated at 2022-06-11 07:44:41.979805
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def assert_satisfied(name, version_specifier, version_to_test):
        pkg = Package(name, version_specifier)
        assert pkg.is_satisfied_by(version_to_test)

    def assert_not_satisfied(name, version_specifier, version_to_test):
        pkg = Package(name, version_specifier)
        assert not pkg.is_satisfied_by(version_to_test)

    assert_satisfied("foo", "==0.1.1", "0.1.1")
    assert_satisfied("foo", "==0.1.1", "0.1.1post1")
    assert_not_satisfied("foo", "==0.1.1", "0.1.1+dev1")

# Generated at 2022-06-11 07:44:50.510614
# Unit test for function main
def test_main():
    args = {
        'name': ['foo'],
        'virtualenv': '/tmp/bar',
        'virtualenv_command': '/usr/bin/virtualenv',
        'virtualenv_python': '/usr/bin/python3',
        'virtualenv_site_packages': False,
        'extra_args': '--quiet'
    }
    from ansible.module_utils import basic
    from ansible.module_utils import common_koji
    global HAS_SETUPTOOLS
    HAS_SETUPTOOLS = True
    from ansible.module_utils import distro
    distro.DISTRO_NAME = 'Fedora'
    from ansible.module_utils import packaging
    old_run_command = basic.AnsibleModule.run_command

# Generated at 2022-06-11 07:44:51.356915
# Unit test for function main
def test_main():
    assert True


# Generated at 2022-06-11 07:44:51.997292
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass



# Generated at 2022-06-11 07:44:58.196236
# Unit test for constructor of class Package
def test_Package():
    assert Package('setuptools').package_name == 'setuptools'
    assert Package('setuptools', '20.0.0').package_name == 'setuptools'
    assert Package('setuptools', '20.0.0').has_version_specifier == True
    assert Package('setuptools', '20.0.0').is_satisfied_by('10.0') == False
    assert Package('setuptools', '>=20.0.0').is_satisfied_by('20.0') == True



# Generated at 2022-06-11 07:45:06.844082
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.common._collections_compat import Mapping
    class Mock(object):
        def __init__(self):
            self.params = {}
            self.params['virtualenv_python'] = None
            self.params['virtualenv_command'] = 'virtualenv'
            self.params['virtualenv_site_packages'] = False
        def check_mode(self):
            return False
        def get_bin_path(self,string, bool, list):
            return "virtualenv"
        def fail_json(self, msg):
            raise Exception(msg)
        def run_command(self,cmd, cwd=None):
            return (1, 'virtualenv', 'virtualenv')
    mock = Mock()
    out = ''
    err = ''
    env = ''
    chdir = ''


# Generated at 2022-06-11 07:45:07.988659
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    t = MyTest()
    assert t.setup_virtualenv()


# Generated at 2022-06-11 07:45:09.538313
# Unit test for function main
def test_main():
    assert os.path.exists(os.path.join(__file__, '..'))


# Generated at 2022-06-11 07:45:18.485586
# Unit test for function setup_virtualenv