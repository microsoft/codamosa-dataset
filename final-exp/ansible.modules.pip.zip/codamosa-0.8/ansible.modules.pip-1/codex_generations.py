

# Generated at 2022-06-11 07:36:26.953540
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    with pytest.raises(AttributeError) as e:
        pkg2 = Package("distribute==0.6c11")
        pkg2.is_satisfied_by('0.6c11')
    with pytest.raises(ValueError) as e:
        Package("distribute?==0.6c11")
    with pytest.raises(ValueError) as e:
        Package("distribute~==0.6c11")
    with pytest.raises(ValueError) as e:
        Package("distribute@==0.6c11")
    with pytest.raises(ValueError) as e:
        Package("distribute!==0.6c11")
    assert not Package("distribute").is_satisfied_by('0.6c11')

# Generated at 2022-06-11 07:36:29.635497
# Unit test for function main
def test_main():
    import ansible.module_utils.pip
    ansible.module_utils.pip.HAS_SETUPTOOLS = True
    res = main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:36:39.917826
# Unit test for function main

# Generated at 2022-06-11 07:36:50.267910
# Unit test for constructor of class Package
def test_Package():
    # test Package initializing without version specifier
    package = Package("foo")
    assert not package.has_version_specifier
    assert package.is_satisfied_by("1.0.0")
    assert package.package_name == "foo"
    # test Package initializing with version specifier
    package1 = Package("foo", "> 1.0, != 1.3.0")
    assert package1.has_version_specifier
    assert package1.package_name == "foo"
    assert not package1.is_satisfied_by("1.0.0")
    assert package1.is_satisfied_by("1.2.0")
    assert not package1.is_satisfied_by("1.3.0")
    package2 = Package("foo", "==1.0.0")


# Generated at 2022-06-11 07:37:00.284241
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import get_exception, AnsibleModule
    import sys
    import os

    if not HAS_SETUPTOOLS:
        raise Exception(missing_required_lib("setuptools"))

    args = dict(
        state='present',
        name=['ansible'],
    )

# Generated at 2022-06-11 07:37:10.292872
# Unit test for constructor of class Package
def test_Package():
    package = Package("foo")
    assert package.package_name == "foo"
    assert package._plain_package is False

    package = Package("foo", "abc")
    assert package.package_name == "foo"
    assert package._plain_package is True

    package = Package("foo", ">= 2.0")
    assert package.package_name == "foo"
    assert package._plain_package is True
    assert package.has_version_specifier is True

    assert package.is_satisfied_by("2.1") is True
    assert package.is_satisfied_by("1.0") is False
    package = Package("foo", "2.0")
    assert package.is_satisfied_by("2.0") is True
    assert package.is_satisfied_by("1.0")

# Generated at 2022-06-11 07:37:18.797071
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """Test to make sure we get the right error message if
    we try to use the virtualenv_python parameter with
    the pyvenv or venv modules.
    """
    out = ''
    err = ''
    cmd = shlex.split(module.params['virtualenv_command'])
    env = '/tmp/test'
    chdir = '/tmp'
    rc, out_venv, err_venv = setup_virtualenv(module, env, chdir, out, err)
    out += out_venv
    err += err_venv
    assert rc != 0
    assert 'is ignored when using venv or pyvenv as virtualenv_command' in err



# Generated at 2022-06-11 07:37:20.011737
# Unit test for function main
def test_main():
    assert False, "Test for function main, not implemented"


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:37:27.303227
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:37:28.361602
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert 1 == 1


# Generated at 2022-06-11 07:38:13.014048
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.test.test_mock.mock import MagicMock
    module = MagicMock(AnsibleModule)
    module.check_mode = False
    module.params = {'virtualenv_command': 'pyvenv', 'virtualenv_python': '/usr/bin/python3', 'virtualenv_site_packages': True}
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/python3'
    module.run_command = MagicMock()
    module.run_command.return_value = 0, 'stdout', 'stderr',
    setup_virtualenv(module, 'venv', 'chdir', 'out', 'err')
    assert module.run_command

# Generated at 2022-06-11 07:38:23.917722
# Unit test for function main

# Generated at 2022-06-11 07:38:24.540098
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass


# Generated at 2022-06-11 07:38:35.941109
# Unit test for function main
def test_main():
    if True:
        import doctest

# Generated at 2022-06-11 07:38:44.363618
# Unit test for function main
def test_main():
    import contextlib
    import tempfile
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 07:38:55.642552
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    import unittest
    class TestPackage(unittest.TestCase):
        def test_is_satisfied_by(self):
            def assert_is_satisfied_by(package_name, version_string, version_to_test, expected_result):
                expected_result = bool(expected_result)
                pkg = Package(package_name, version_string)
                self.assertEqual(pkg.is_satisfied_by(version_to_test), expected_result)
            assert_is_satisfied_by('foo', '==1.0', '1.0', True)
            assert_is_satisfied_by('foo', '>=1.0', '1.0', True)

# Generated at 2022-06-11 07:39:01.031269
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    mod = AnsibleModule(argument_spec={'virtualenv_command':{'type':'str'},
                                       'virtualenv_python':{'type':'str'},
                                       'virtualenv_site_packages':{'type':'bool'}
                                      })
    print(mod)
    assert setup_virtualenv(mod,'env','chdir','out','err')



# Generated at 2022-06-11 07:39:10.058268
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def test_one_spec(spec, version_to_test, expect):
        req = Package(name_string='foo', version_string=spec)
        assert req.is_satisfied_by(version.Version(version_to_test)) == expect

    test_one_spec('==1.0', '1.0', True)
    test_one_spec('==1.0', '1.1', False)

    test_one_spec('<1.0', '1.0', False)
    test_one_spec('<1.0', '0.9', True)

    test_one_spec('>1.0', '1.0', False)
    test_one_spec('>1.0', '1.1', True)


# Generated at 2022-06-11 07:39:12.304372
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert not setup_virtualenv(module, env, chdir, out, err) is False


# Generated at 2022-06-11 07:39:12.962019
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    assert True



# Generated at 2022-06-11 07:40:48.125732
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    option_stub = create_autospec(Option)
    option_stub.check_mode = False

    mock_run_command = MagicMock()

    module_stub = create_autospec(AnsibleModule)
    module_stub.get_bin_path.return_value = '/usr/bin/python'
    module_stub.params = {'virtualenv_command': 'virtualenv', 'virtualenv_python': '/usr/bin/python', 'virtualenv_site_packages': False}
    module_stub.run_command = mock_run_command
    setup_virtualenv(module_stub, '/foo/bar', '/foo/bar', '', '')

# Generated at 2022-06-11 07:40:50.503888
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    package = Package("pytest", "")
    assert package.is_satisfied_by("2.7.0") == True


# this is located here to avoid an import/use loop

# Generated at 2022-06-11 07:41:00.499950
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:41:03.174367
# Unit test for function main
def test_main():
    import __main__ as main
    main.main()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:41:05.066037
# Unit test for function main
def test_main():
    print("Testing main function")
    print("testing fail")
    print(main())


# Generated at 2022-06-11 07:41:13.910360
# Unit test for function main
def test_main():
    sys.modules['setuptools'].__version__ = '1.1.6'
    sys.modules['pkg_resources'].__version__ = '0.6c11'  # pylint: disable=undefined-variable
    sys.modules['pkg_resources'].parse_requirements.return_value = 'egg-info'

    def run_command(cmd, **kwargs):  # pylint: disable=unused-argument
        return 0, 'Successfully installed', ''

    mock = MagicMock(side_effect=run_command)


# Generated at 2022-06-11 07:41:22.247282
# Unit test for function main

# Generated at 2022-06-11 07:41:33.183726
# Unit test for function main
def test_main():
    '''Test function main'''
    # Try to load module in unit testing mode
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    basic._ANSIBLE_ARGS = to_bytes(os.environ['ANSIBLE_ARGS'])

    if not os.path.isfile('/tmp/test_pip.py'):
        raise Exception('Test file does not exist')
    module_args = dict(
        executable='/usr/bin/python',
        name='/tmp/test_pip.py',
    )
    with pytest.raises(Exception) as exec_info:
        main()
    assert 'Test file does not exist' in str(exec_info.value)



# Generated at 2022-06-11 07:41:35.438189
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    dummyResult = setup_virtualenv(None, None, None, None, None)
    assert dummyResult == (None, None)



# Generated at 2022-06-11 07:41:36.464854
# Unit test for function main
def test_main():
    import tempfile
    import os
    import re
    import shutil
    import stat
    main()




# Generated at 2022-06-11 07:45:25.801367
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package('pytz', '>=2014.7')
    assert pkg.is_satisfied_by('2014.7')

    pkg = Package('pytz', '>2014.7,<2015.4')
    assert pkg.is_satisfied_by('2014.7')
    assert not pkg.is_satisfied_by('2015.4')


# Generated at 2022-06-11 07:45:32.485034
# Unit test for constructor of class Package
def test_Package():
    # Use pip package names, that were never changed by pkg_resource
    simple_package = Package("pip")
    assert simple_package._plain_package == True
    assert simple_package.package_name == "pip"
    assert simple_package.__str__() == "pip"
    assert simple_package.has_version_specifier == False

    setuptools_package = Package("setuptools")
    assert setuptools_package._plain_package == True
    assert setuptools_package.package_name == "setuptools"
    assert setuptools_package.__str__() == "setuptools"
    assert setuptools_package.has_version_specifier == False

    # Complex names
    complex_package = Package("pip-tools")
    assert complex_package._plain_package == True
   

# Generated at 2022-06-11 07:45:41.563457
# Unit test for function main

# Generated at 2022-06-11 07:45:42.132874
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-11 07:45:50.667137
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    from importlib import util
    res = util.find_spec('ansible.module_utils.pip')
    if not res:
        sys.exit('unable to import ansible.module_utils.pip')
    else:
        sys.modules['ansible.module_utils.pip'] = res.loader.load_module()
    from ansible.module_utils.pip import Package

    package = Package('pywinrm')
    assert not package.is_satisfied_by('0.2.2')
    assert package.is_satisfied_by('0.3.0')
    assert package.is_satisfied_by('0.3.1')
    assert package.is_satisfied_by('0.3.2')

# Generated at 2022-06-11 07:45:59.600048
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    def fake_ansible_module(**kwargs):
        return type('AnsibleModuleFake', (AnsibleModule,), kwargs)
