

# Generated at 2022-06-11 07:36:35.159048
# Unit test for function main
def test_main():
    '''Unit test for function main'''
    # This is a unit test.

# Generated at 2022-06-11 07:36:36.617055
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:36:40.717801
# Unit test for constructor of class Package

# Generated at 2022-06-11 07:36:50.941287
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    pkg = Package('ansible', '2.2.0')
    # version equals to specifier
    assert pkg.is_satisfied_by('2.2.0')
    # version higher than specifier
    assert not pkg.is_satisfied_by('2.2.1')
    # version lower than specifier
    assert not pkg.is_satisfied_by('2.1.0')

    pkg = Package('pbr', '>=1.8')
    assert pkg.is_satisfied_by('1.8')
    assert pkg.is_satisfied_by('1.9')
    assert not pkg.is_satisfied_by('1.7.1')


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:36:57.442044
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    def _test(name_string, version_to_test, expected):
        package = Package(name_string)
        assert package.is_satisfied_by(version_to_test) is expected

    _test("beautifulsoup4==4.1.1", "4.1.1", True)
    _test("beautifulsoup4==4.1.1", "4.1.2", False)
    _test("cffi", "1.4.1", False)
    _test("Django", "1.6", False)
    _test("django>=1.8,<1.9", "1.8", True)
    _test("Django>=1.8,<1.9", "1.9", False)

# Generated at 2022-06-11 07:37:07.931260
# Unit test for constructor of class Package
def test_Package():
    pkg = Package('sample_package')
    assert pkg.package_name == 'sample_package'
    assert pkg._plain_package is False

    pkg = Package('sample_package', '1.1')
    assert pkg.package_name == 'sample_package'
    assert pkg._plain_package is True
    assert str(pkg) == 'sample_package==1.1'
    assert pkg.has_version_specifier is True
    assert pkg.is_satisfied_by('1.1') is True
    assert pkg.is_satisfied_by('1.2') is False

    pkg = Package('sample_package', '>=1.1,<2')
    assert pkg.package_name == 'sample_package'
    assert pkg._plain_package is True

# Generated at 2022-06-11 07:37:16.429777
# Unit test for function main
def test_main():
    def setup_module(module):
        def get_bin_path(ve_path, executable='python'):
            # given the path to a virtualenv return the path to the python inside
            return os.path.join(ve_path, "bin", executable)
        def get_pip_path(ve_path):
            return os.path.join(ve_path, "bin", "pip")
        # we don't want to actually install anything
        def run_command_mock(cmd, **kwargs):
            if cmd[0] == get_pip_path(virtualenv):
                if cmd == [get_pip_path(virtualenv), 'install', '-U', '--force-reinstall', 'pip']:
                    return (0, 'Successfully installed pip-6.0.8\n', None)
               

# Generated at 2022-06-11 07:37:22.455861
# Unit test for constructor of class Package
def test_Package():
    p1 = Package('ansible')
    if p1.package_name != 'ansible':
        print('failed to parse package name')
    if p1.has_version_specifier:
        print('failed to parse package specifier')
    if not p1.is_satisfied_by('0.0.1'):
        print('incorrect specifier returned')

    p2 = Package('ansible', '0.0.2')
    if p2.package_name != 'ansible':
        print('failed to parse package name')
    if not p2.has_version_specifier:
        print('failed to parse package specifier')
    if not p2.is_satisfied_by('0.0.2'):
        print('incorrect specifier returned')

# Generated at 2022-06-11 07:37:33.723230
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    import tempfile, shutil
    from ansible.module_utils.common.collections import ImmutableDict

    module = importlib_machinery.SourceFileLoader(
        'test_setup_virtualenv',
        os.path.join(os.path.dirname(__file__), 'test.py')
    ).load_module()
    module.run_command = lambda cmd, cwd=None: (0, cwd, cmd)
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 07:37:38.154192
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    """ dummy test for setup_virtualenv() """
    module = AnsibleModule(argument_spec={
        'virtualenv_command': dict(),
        })
    env, chdir, out, err = 'env', None, '', ''
    setup_virtualenv(module, env, chdir, out, err)
    assert 'dummy check'


# Generated at 2022-06-11 07:38:11.970516
# Unit test for function main
def test_main():
    main()

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:20.753536
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False)
        )
    )
    env = 'testenv'
    chdir = '.'
    out = ''
    err = ''
    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert os.path.exists(env)
    assert os.path.exists(os.path.join(env, 'bin'))
    shutil.rmtree(env)



# Generated at 2022-06-11 07:38:28.476113
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(type='str', default='/usr/bin/virtualenv'),
            virtualenv_python=dict(type='str', default=None),
            virtualenv_site_packages=dict(type='bool', default=True),
        ),
    )
    env = 'test_pip_virtualenv'
    chdir = None
    out = err = ''
    setup_virtualenv(module, env, chdir, out, err)



# Generated at 2022-06-11 07:38:29.522162
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as ex:
        main()
    assert ex.value.code == 0


# Generated at 2022-06-11 07:38:31.057535
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:38:41.290528
# Unit test for function main
def test_main():
    module_mock = MagicMock()
    module_mock.params = {}
    module_mock.check_mode = False
    module_mock.run_command.return_value = (0, '', '')
    module_main = Mock(return_value=module_mock)

# Generated at 2022-06-11 07:38:52.431737
# Unit test for function main
def test_main():
    test_pip = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'pip')
    out = b'Collecting pip\n  Using cached pip-7.1.2-py2.py3-none-any.whl\nInstalling collected packages: pip\n  Found existing installation: pip 1.5.4\n    Uninstalling pip-1.5.4:\n      Successfully uninstalled pip-1.5.4\nSuccessfully installed pip-7.1.2\n'
    err = ''

    assert _is_success(out, err) == True
    assert _is_success(err, out) == True

    out = 'Successfully installed pip-7.1.2\n'
    err = ''


# Generated at 2022-06-11 07:39:03.527321
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:39:10.532169
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    m = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    env = "/fast/pip-venv"
    chdir = "/fast/"
    out = ""
    err = ""
    exec_exception = None
    try:
        out, err = setup_virtualenv(m, env, chdir, out, err)
    except:
        exec_exception = get_exception()
    assert exec_exception is None
    assert out == ""
    assert err != ""



# Generated at 2022-06-11 07:39:16.863438
# Unit test for function main

# Generated at 2022-06-11 07:40:37.313130
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_text
    # import the module "pip" so we can mock the module
    from ansible.modules.packaging.os import pip

    from ansible.module_utils.six.moves import shlex_quote

    # Create a mock module object
    class FakeModule():
        def __init__(self, chdir=None):
            self.params = {}
            self.params['virtualenv_command'] = 'virtualenv {0}'.format(to_text(shlex_quote(chdir)))
            self.params['virtualenv_site_packages'] = True
            self.params['virtualenv_python'] = None
            self._tmpdir = None
            self.fail_json = lambda **args: 1

# Generated at 2022-06-11 07:40:46.826391
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:40:53.894083
# Unit test for function main
def test_main():
    print("Running tests")
    print("--------------")

# Generated at 2022-06-11 07:40:54.582832
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    pass

# Generated at 2022-06-11 07:41:05.332694
# Unit test for method is_satisfied_by of class Package

# Generated at 2022-06-11 07:41:14.261755
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec={
        'virtualenv_command':{'type': 'str', 'default': 'virtualenv'},
        'virtualenv_site_packages': {'type': 'bool', 'default': True}
        })
    env = 'venv'
    chdir = '/tmp'
    out = ''
    err = ''
    if not PY3:
        out, err = setup_virtualenv(module, env, chdir, out, err)
        print(out)
        print(err)
        assert(re.search(r'created virtual environment', out))
        # test for the global site package option for unsupported commands
        module.params['virtualenv_command'] = 'pyvenv'
        out, err = setup_virtualenv(module, env, chdir, out, err)

# Generated at 2022-06-11 07:41:20.827387
# Unit test for function main
def test_main():
    import ansible.modules.packaging.python.pip
    reload(ansible.modules.packaging.python.pip)
    from ansible.modules.packaging.python.pip import main
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import re
    try:
        reload(sys)
        sys.setdefaultencoding('utf8')
    except NameError:
        pass

    x = main()
    print("test_main test success")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 07:41:32.249040
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    tests = [
        {
            'virtualenv_command': 'virtualenv',
            'virtualenv_python': 'virtualenv_python',
            'check_mode': True
        },
        {
            'virtualenv_command': 'virtualenv',
            'virtualenv_python': 'virtualenv_python',
            'check_mode': False
        },
        {
            'virtualenv_command': 'pyvenv',
            'virtualenv_python': '',
            'check_mode': False
        },
        {
            'virtualenv_command': 'pyvenv',
            'virtualenv_python': 'virtualenv_python',
            'check_mode': True
        }
    ]
   

# Generated at 2022-06-11 07:41:41.674159
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # Batch create test cases
    test_cases = [
        ("1.0", [(">=", "0.0"), ("<", "2.0")]),
        ("2.0", [(">", "1.0"), ("<=", "3.0")]),
        ("0.9", [("==", "0.9")])
    ]

    for version_to_test, specs in test_cases:
        req = Requirement.parse("test-package%s" % "".join(map(lambda x: "%s%s" % x, specs)))
        pkg = Package("test-package", None)
        pkg._requirement = req
        pkg._plain_package = True

        assert pkg.is_satisfied_by(version_to_test), version_to_test



# Generated at 2022-06-11 07:41:47.520609
# Unit test for constructor of class Package
def test_Package():
    assert Package("foo").package_name == "foo"
    assert Package("foo").has_version_specifier == False
    assert Package("foo", None).has_version_specifier == False
    assert Package("foo", "bar").has_version_specifier == True
    assert Package("foo", ">=0.1").has_version_specifier == True
    assert Package("foo", ">=0.1").is_satisfied_by("0.1") == True
    assert Package("foo", ">=0.1").is_satisfied_by("0.2") == True
    assert Package("foo", ">=0.1").is_satisfied_by("0.0") == False
    assert Package("foo", ">=0.1").is_satisfied_by("0.1.1") == True

# Generated at 2022-06-11 07:45:01.542301
# Unit test for function main
def test_main():
    import __main__
    __main__.setup_virtualenv = setup_virtualenv
    __main__.Package = Package
    return main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:45:05.788920
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(
        argument_spec=dict(
            virtualenv_command=dict(default='virtualenv'),
            virtualenv_python=dict(default=None),
            virtualenv_site_packages=dict(default=False)
        )
    )
    setup_virtualenv(module, 'env', 'chdir', 'out', 'err')


# Generated at 2022-06-11 07:45:06.659025
# Unit test for function main
def test_main():
    """Tests for main()"""


# Generated at 2022-06-11 07:45:07.845582
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:45:13.640704
# Unit test for function main
def test_main():
    # Test 1:
    # pip3 install requests
    #   - pip3 executable: setuptools>=18.5
    #   - pip3 output:
    #       Collecting requests
    #       Downloading requests-2.13.0-py2.py3-none-any.whl (584kB)
    #       Installing collected packages: requests
    #       Successfully installed requests-2.13.0

    # mock input arguments
    state = 'present'
    name = 'requests'
    version = None
    requirements = ''
    extra_args = ''
    virtualenv = ''
    virtualenv_site_packages = ''
    virtualenv_command = ''
    virtualenv_python = ''
    chdir = ''
    executable = ''
    umask = ''

    # mock setup_virtualenv()
    # mock

# Generated at 2022-06-11 07:45:22.934629
# Unit test for method is_satisfied_by of class Package
def test_Package_is_satisfied_by():
    # test cases are copied from https://github.com/pypa/pip/blob/master/tests/test_req.py#L119
    def test(requirement, version):
        return Package(requirement).is_satisfied_by(version)

    # No specifier
    assert test("foo", "1.0")
    assert not test("foo", "2.0")

    # Equality specifier
    assert test("foo==1.0", "1.0")
    assert not test("foo==1.0", "2.0")

    # Compatible release specifier
    assert test("foo~=1.0", "1.0")
    assert test("foo~=1.0", "1.1")
    assert test("foo~=1.0", "1.3.5")

# Generated at 2022-06-11 07:45:30.918374
# Unit test for constructor of class Package
def test_Package():
    def _assert_package_name(name_string, version, expected_name, version_string=None):
        if version_string is None:
            name_string_with_version = '=='.join([name_string, version])
        else:
            name_string_with_version = '=='.join([name_string, version_string])

        pkg = Package(name_string_with_version)
        assert pkg.package_name == expected_name

    def _assert_package_version_specifier(name_string, version, expected_spec):
        pkg = Package(name_string, version)
        for ver, op in expected_spec:
            assert pkg.is_satisfied_by(ver) == op

    assert Package('foo').package_name == 'foo'


# Generated at 2022-06-11 07:45:32.279696
# Unit test for function main
def test_main():
    assert 1 == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:45:33.548722
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 07:45:42.637727
# Unit test for function setup_virtualenv
def test_setup_virtualenv():
    module = AnsibleModule(argument_spec=dict(
          virtualenv_command=dict(default='/usr/bin/virtualenv'),
          virtualenv_python=dict(),
          virtualenv_site_packages=dict(type='bool', default=False)
    ))

    env = '/testenv'
    chdir = '/'
    out = ''
    err = ''

    out, err = setup_virtualenv(module, env, chdir, out, err)
    assert module.params['virtualenv_command'] in ' '.join(out.splitlines())
    assert module.params['virtualenv_command'] in ' '.join(err.splitlines())
