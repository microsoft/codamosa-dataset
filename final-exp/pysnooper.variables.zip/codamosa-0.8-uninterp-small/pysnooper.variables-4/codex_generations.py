

# Generated at 2022-06-24 17:21:32.953764
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert False


# Generated at 2022-06-24 17:21:35.643138
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    exclusion_list_0 = ()


# Generated at 2022-06-24 17:21:39.350563
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__main__'
    str_1 = 'seconds'
    attrs_0 = Attrs(str_0)
    attrs_1 = Attrs(str_1)
    assert attrs_0 == attrs_1


# Generated at 2022-06-24 17:21:48.190780
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # Test for instance method items
    # 1. Test for source is an attribute name
    # Test for a key exists in the inspected object
    class A(object):
        pass

    a = A()
    a.x = 1
    attrs_1 = Attrs('a')
    assert attrs_1.items(sys._getframe()) == (
        ('a', '<instance of A at {:#x}>'.format(id(a))),
        ('a.x', '1 (int)'),
    )
    assert attrs_1.items(sys._getframe(), normalize=True) == (
        ('a', '<A>'),
        ('a.x', '1 (int)'),
    )

    a.x = [1, 2]

# Generated at 2022-06-24 17:21:55.249737
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    BaseVariable( source, exclude = () )
    """
    # Some additional test cases
    str_0 = 'microseconds'
    frame_0 = Frame(0)
    attrs_0 = Attrs(str_0)
    print("Result of test_BaseVariable_items")
    print(" .items( frame ) : ", attrs_0.items(frame_0))


# Generated at 2022-06-24 17:22:04.009306
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    bool_0 = True
    dict_0 = dict()
    dict_0['test_var'] = bool_0
    x_0 = attrs_0.items(dict_0)
    test_0 = x_0[0]

# Generated at 2022-06-24 17:22:13.802186
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from datetime import timedelta
    a = timedelta.hours
    b = timedelta.minutes
    c = timedelta.seconds
    d = timedelta.microseconds
    temp_0 = a
    temp_0 = b
    temp_0 = c
    temp_0 = d
    x = timedelta(hours=1, minutes=2, seconds=3, microseconds=4)
    t0 = Indices('x[:2]')
    t1 = Indices('x[2:]')
    t2 = Indices('x[:2]')
    t3 = Indices('x[2:]')

# Generated at 2022-06-24 17:22:20.731021
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    arg_0 = 'microseconds'
    arg_1 = None
    var_0 = Attrs(arg_0, arg_1)

    var_1 = Attrs(arg_0, arg_1)
    assert var_0 == var_1
    var_1 = Attrs(arg_0, arg_1)
    assert not var_0 == var_1
    var_1 = Attrs(arg_0, arg_1)
    assert not var_0 == var_1


# Generated at 2022-06-24 17:22:29.759192
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pytest
    import _pytest._code
    import _pytest.python
    import _pytest.assertion.rewrite
    import _pytest.assertion.util
    import _pytest.warning_types
    import warnings
    import _pytest.capture
    import py._io.terminalwriter
    import _pytest.recwarn

    class TestFrame(object):
        def __init__(self, f_globals, f_locals):
            self.f_globals = f_globals
            self.f_locals = f_locals
    if True: # Change to True to avoid pytest warnings
        from _pytest.assertion.util import _diff_text


# Generated at 2022-06-24 17:22:36.993692
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'days'
    list_0 = []
    tuple_0 = ()
    attrs_0 = Attrs(str_0)
    assert attrs_0 == attrs_0
    attrs_1 = Attrs(str_0, tuple_0)
    assert attrs_0 == attrs_1
    attrs_2 = Attrs(str_0, list_0)
    assert attrs_0 == attrs_2
    assert not (attrs_0 != attrs_2)
    attrs_3 = Attrs('days', tuple_0)
    assert attrs_0 == attrs_3
    assert not (attrs_0 != attrs_3)
    attrs_4 = Attrs('seconds', tuple_0)
    assert not (attrs_0 == attrs_4)
   

# Generated at 2022-06-24 17:22:57.263478
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = ''
    str_1 = ''
    str_2 = 'b'
    str_3 = 'g'
    str_4 = 't'
    attrs_0 = Attrs(str_0)
    attrs_1 = Attrs(str_1)
    attrs_2 = Attrs(str_2)
    attrs_3 = Attrs(str_3)
    attrs_4 = Attrs(str_4)
    attrs_5 = Attrs(str_4)
    attrs_6 = Attrs(str_2)
    assert attrs_0 == attrs_1
    assert attrs_0 == attrs_0
    assert attrs_3 == attrs_3
    assert attrs_2 == attrs_6
    assert attrs_4 == attrs_5


# Generated at 2022-06-24 17:23:09.212719
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Local variables used by test:
    str_0 = 'list_0'
    str_1 = 'tuple_1'
    # Create a new class of type object
    class object_0(object):
        # Create an instance method for class object_0 with name __init__
        def __init__(self, list_0, tuple_1):
            # Set the value of attribute 'list_0' of self to list_0
            self.list_0 = list_0
            # Set the value of attribute 'tuple_1' of self to tuple_1
            self.tuple_1 = tuple_1
    # Create a new Attrs object named attrs_0
    attrs_0 = Attrs(str_1)
    # Create a new object_0 object named object_1

# Generated at 2022-06-24 17:23:13.018392
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'microseconds'
    indices_0 = Indices(str_0)
    indices_0.__getitem__(1)
# unit test for method __getitem__ of class Indices

# Generated at 2022-06-24 17:23:22.248369
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'x'
    indices_0 = Indices(str_0)
    x = indices_0[1:-1]

if __name__ == '__main__':
    import sys
    import inspect
    import pytest
    from pathlib import Path

    try:
        from .utils import modify_traceback
    except (ImportError, ValueError):
        from remove_fast_traceback.utils import modify_traceback


    sys._called_from_test = True
    test_function = sys.argv[1]
    arg_names = inspect.getargspec(eval(test_function)).args
    assert arg_names == ['self'], arg_names
    test_case = sys.argv[2]

# Generated at 2022-06-24 17:23:28.497862
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = ')U;[6~'
    str_1 = 'k'
    seq_0 = (str_1, str_0)
    tuple_0 = (str_1, seq_0)
    Variable_0 = Keys(str_1, tuple_0)
    Variable_1 = Keys(str_0, tuple_0)
    bool_0 = Variable_0.__eq__(Variable_1)
    assert bool_0 == False


# Generated at 2022-06-24 17:23:30.789471
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  indices_0 = Indices('microseconds')
  indices_1 = indices_0[1:]
  

# Generated at 2022-06-24 17:23:33.054962
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'microseconds'
    indices_0 = Indices(str_0)


# Generated at 2022-06-24 17:23:34.354317
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pycompat.builtin_object.__eq__('microseconds', Attrs('microseconds'))



# Generated at 2022-06-24 17:23:37.224209
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    str_1 = 'datetime.datetime.today'
    attrs_1 = Attrs(str_1)

# Generated at 2022-06-24 17:23:43.270055
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    attrs_0 = Attrs('microseconds')
    assert (not (attrs_0 == 'foobar'))
    assert (not (attrs_0 == None))
    attrs_1 = Attrs('minutes')
    assert (not (attrs_0 == attrs_1))
    attrs_1.source = 'microseconds'
    assert (attrs_0 == attrs_1)
    attrs_2 = Attrs('milliseconds')
    attrs_2.exclude = ('milliseconds',)
    attrs_3 = Attrs('milliseconds', ('milliseconds',))
    assert (attrs_2 == attrs_3)
    attrs_4 = Attrs('milliseconds', ('microseconds',))
    assert (not (attrs_3 == attrs_4))
    att

# Generated at 2022-06-24 17:24:02.849679
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_10 = 'microseconds'
    attrs_10 = Attrs(str_10)
    tup_10 = (type(None), str_10, ())
    # AssertionError: Expected <variable>() == <variable>(), but result is False
    assert_equal((BaseVariable() == BaseVariable()), False)
    # AssertionError: Expected attrs_10.__hash__() == tup_10, but result is False
    assert_equal((attrs_10.__hash__() == tup_10), False)
    # AssertionError: Expected attrs_10 == BaseVariable(), but result is False
    assert_equal((attrs_10 == BaseVariable()), False)


# Generated at 2022-06-24 17:24:09.672824
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'hundreds'
    str_1 = '%8P'
    str_2 = '24'
    str_3 = 'hundreds'
    str_4 = '%8P'
    str_5 = '24'
    # Normal case - testing equality
    BaseVariable_0 = BaseVariable(str_1, str_0)
    BaseVariable_1 = BaseVariable(str_4, str_3)
    bool_1 = BaseVariable_0.__eq__(BaseVariable_1)
    # Unit test with non-BaseVariable object
    str_6 = 'Sincerely, the'
    int_0 = 0
    Mapping_0 = Mapping
    # Raises TypeError

# Generated at 2022-06-24 17:24:20.487886
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import datetime
    from . import utils
    from . import pycompat
    from .pycompat import abc
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding

    t0 = datetime.datetime(2014, 9, 10, 17, 0, 3, 519986)

# Generated at 2022-06-24 17:24:26.629146
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
   str_0 = 'microseconds'
   attrs_0 = Attrs(str_0)
   str_1 = 'microseconds'
   attrs_1 = Attrs(str_1)
   def func_0(frame):
      return (frame.f_globals['__file__'], frame.f_globals['__name__'])
   dict_0 = dict(func_0(getframeinfo(currentframe())))
   tuple_0 = ()
   assert tuple_0 == attrs_0.items(dict_0)
   assert tuple_0 == attrs_1.items(dict_0)


# Generated at 2022-06-24 17:24:31.576558
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    assert attrs_0.items(None) == [('microseconds',
                                    "'c22fc72d-3d3a-4ffa-97c3-75bb9fd9bf11'")]


# Generated at 2022-06-24 17:24:35.288745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = False

    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame, normalize)
    print()

# Generated at 2022-06-24 17:24:44.020411
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import time

    res_0 = time.sleep(0.5)
    attrs_0 = Attrs('time')
    frame_0 = None
    res_1 = attrs_0.items(frame_0)
    assert res_1 == [('time', 'module')]
    res_2 = time.time()
    str_0 = 'microseconds'
    attrs_1 = Attrs(str_0)
    frame_1 = None
    res_3 = attrs_1.items(frame_1)
    assert res_3 == [("microseconds", '<built-in function microseconds>')]


# Generated at 2022-06-24 17:24:55.701312
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from datetime import datetime
    import pdb
    now = datetime.now()
    now_items = now.isoformat()
    assert now_items == '2018-01-29T11:12:03.077367'
    now_items_locals = now_items.split('T')[1].split('.')[0]
    assert now_items_locals == '11:12:03'
    now_items_locals_split = now_items_locals.split(':')
    assert (now_items_locals_split[0], now_items_locals_split[1], now_items_locals_split[2]) == ('11', '12', '03')
    now_items_locals_split_1 = now_items_locals_split[0]
    assert now_items_

# Generated at 2022-06-24 17:25:02.994799
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import datetime as dt
    dt_0 = dt.datetime.now()
    #pass
    attrs = Attrs('dt')
    assert attrs.items(dt_0) == [
        ('microseconds', '0'),
        ('dt.hour', '22'),
        ('dt.second', '34'),
        ('dt.year', '2017'),
        ('dt.month', '9'),
        ('dt.day', '29'),
        ('dt.minute', '55'),
    ]


# Generated at 2022-06-24 17:25:14.396852
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = "microseconds"
    str_1 = "microseconds"
    attrs_0 = Attrs(str_0)
    str_2 = "microseconds"
    int_0 = 276
    exc_0 = Exception()
    exc_1 = Exception()
    frame_0 = ...
    str_3 = "microseconds"
    str_4 = "microseconds"
    assert attrs_0.items(frame_0) == (
        (str_1, str_2),
        ('{}.xxx'.format(str_3), "..."),
        ('{}.yyy'.format(str_4), str(int_0)),
    )

# Generated at 2022-06-24 17:25:34.794716
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dt_0 = datetime.datetime
    _exclude_0 = ('max', 'min', 'resolution')
    int_0 = 123456
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0, _exclude_0)
    str_1 = '{}.{}'.format(str_0, str_0)
    tuple_0 = (str_1, int_0)
    str_2 = '{}[None]'.format(str_1)
    tuple_1 = (str_2, None)
    dict_0 = {tuple_0: tuple_1}
    dict_1 = attrs_0.items(dt_0)
    assert dict_1 == dict_0

# Test of BaseVariable.__init__

# Generated at 2022-06-24 17:25:38.975508
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    seq_0 = itertools.count(0)
    key_0 = next(seq_0)
    for item in attrs_0.items(key_0):
        pass

Attributes = Attrs('<attr>')
ListIndices = Indices('<list>')
DictKeys = Keys('<dict>')
Explode = Exploding('<explode>')

# Generated at 2022-06-24 17:25:50.377972
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'tuple'
    str_1 = '_fn'
    str_2 = 'rc'
    str_3 = '_stderr'
    str_4 = '_exception'
    dict_0 = {str_1: 2, str_2: 4, str_3: 2, str_4: 1}
    dict_1 = {str_1: 1, str_2: 1, str_3: 1, str_4: 1}
    dict_2 = {str_1: 0, str_2: 0, str_3: 0, str_4: 0}
    dict_3 = {str_1: -1, str_2: -1, str_3: -1, str_4: -1}

# Generated at 2022-06-24 17:25:58.816917
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from datetime import timedelta
    from . import test
    frame = test.run_test(test_case_0)
    position_0 = frame.f_lasti
    frame.f_lasti = position_0
    main_0 = frame.f_locals[str_0]
    result_0 = attrs_0.items(frame)
    expected_0 = (('microseconds', '0'),)
    test.assert_equal(expected_0, result_0)


# Generated at 2022-06-24 17:26:06.419188
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'microseconds'
    str_1 = 'microseconds'
    obj_0 = 'microseconds'
    obj_1 = 'microseconds'
    obj_2 = 'microseconds'
    attrs_0 = BaseVariable(str_0)
    attrs_1 = BaseVariable(str_1)
    attrs_2 = BaseVariable(str_1)
    attrs_3 = BaseVariable(str_1)
    attrs_4 = BaseVariable(str_1)
    assert not (attrs_0 == attrs_1)
    assert not (attrs_1 == attrs_0)
    assert not (attrs_1 == attrs_2)
    assert (attrs_2 == attrs_3)
    assert not (attrs_3 == attrs_0)

# Generated at 2022-06-24 17:26:11.656683
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import logging
    import os

    with open(os.devnull, "w") as f:
        old_stdout = sys.stdout
        sys.stdout = f
        logger = logging.getLogger()
        def test_func(logger):
            pass
        assert not logger.hasHandlers()
        test_func(logger)
        assert logger.hasHandlers()
        sys.stdout = old_stdout

# Generated at 2022-06-24 17:26:17.557074
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    dict_0 = dict()
    dict_0[str_0] = None
    tuple_0 = (dict_0, )
    bool_0 = attrs_0.items((tuple_0, ), True)
    assert(bool_0)


# Generated at 2022-06-24 17:26:27.183591
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'microseconds'
    str_1 = 'path'
    str_2 = 'BtTQQy'
    attrs_0 = Attrs(str_0)
    attrs_0_copy = attrs_0
    attrs_1 = Attrs(str_1)
    attrs_2 = Attrs(str_2)
    keys_0 = Keys(str_0)
    keys_1 = Keys(str_1)
    keys_2 = Keys(str_2)
    indices_0 = Indices(str_0)
    indices_1 = Indices(str_1)
    indices_2 = Indices(str_2)
    exploding_0 = Exploding(str_0)
    exploding_1 = Exploding(str_1)

# Generated at 2022-06-24 17:26:28.798174
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'id'
    var_0 = BaseVariable(str_0)


# Generated at 2022-06-24 17:26:33.183743
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'microseconds'
    attrs_0 = Attrs(str_0)
    frame_obj_0 = Frame('stack', 'frame', 'locals', 'globals')
    attrs_0.items(frame_obj_0)
    print("added test case")
