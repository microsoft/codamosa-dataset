

# Generated at 2022-06-24 17:21:39.644749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    list_1 = [1, 2, 3]
    test_case_0()
    list_0.append(list_1)
    frame_0 = utils.Frame(('list', 'list_0'), {'list': list_0, 'list_0': list_0})
    assert Attrs('list').items(frame_0) == [('list', '[1, 2, 3]'), ('list.append', '<built-in function append>')]

# Generated at 2022-06-24 17:21:45.161386
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    data_1 = slice(0, None, None)
    data_2 = slice(None, None, None)
    data_3 = slice(0, 10, None)
    data_4 = slice(-10, None, None)
    data_5 = slice(-10, -5, None)
    data_6 = slice(None, None, 2)
    var_1 = Indices(data_1)
    var_2 = Indices(data_2)
    var_3 = Indices(data_3)
    var_4 = Indices(data_4)
    var_5 = Indices(data_5)
    var_6 = Indices(data_6)
    data_7 = var_1[data_1]
    data_8 = var_1[data_2]
    data_9 = var_1

# Generated at 2022-06-24 17:21:58.605969
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Does it work?
    var_0 = Indices('a').__getitem__(slice(None))
    assert(var_0._slice == slice(None))
    assert(var_0._keys('a') == range(0, 1))
    assert(var_0._format_key('a') == '[a]')
    assert(var_0._get_value('a', 'a') == 'a')
    assert(var_0._items('a') == [('a', "'a'")])
    assert(var_0._safe_keys('a') == range(0, 1))
    assert(var_0.source == 'a')
    assert(var_0.unambiguous_source == 'a')


# Generated at 2022-06-24 17:22:07.120547
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    _return_value = None
    _args = (None,)
    _exc = None
    result = None

    try:
        result = BaseVariable(*_args).items(*_args[1:])
    except Exception as e:
        _exc = e
    assert _return_value is None and _exc is not None

    try:
        result = BaseVariable(*_args).items(*_args[1:])
    except Exception as e:
        _exc = e
    assert _return_value is None and _exc is not None

    try:
        result = BaseVariable(*_args).items(*_args[1:])
    except Exception as e:
        _exc = e
    assert _return_value is None and _exc is not None


# Generated at 2022-06-24 17:22:10.070085
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = str()
    var_1 = True
    var_2 = BaseVariable(var_0)
    var_3 = var_2.items(var_1, var_1)


# Generated at 2022-06-24 17:22:14.414708
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = utils.Variable('source')
    exclude = utils.Variable('exclude')
    class_variable = BaseVariable(source, exclude)
    assert class_variable.__eq__(class_variable)


# Generated at 2022-06-24 17:22:16.775776
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = None
    var_1 = (type(var_0) is BaseVariable)


# Generated at 2022-06-24 17:22:22.063310
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # <Value of RHS> <Type of RHS> <Value of LHS> <Type of LHS> <Result of operation>
    # ------------------------------------------------------------------------------
    # False bool False bool True
    # True bool False bool False
    # -> Rest of test cases are from the XML test file.
    pass


# Generated at 2022-06-24 17:22:29.725766
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import test_case_0
    from . import test_case_1
    from . import test_case_2
    from . import test_case_3
    from . import test_case_4
    from . import test_case_5
    from . import test_case_6
    from . import test_case_7
    from . import test_case_8
    from . import test_case_9
    from . import test_case_10
    sai_0 = BaseVariable(test_case_0.bool_0)
    var_0 = sai_0.items()


# Generated at 2022-06-24 17:22:31.349938
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert(BaseVariable(bool_0).items(frame_0) == ())

# Generated at 2022-06-24 17:22:41.602858
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = None
    str_0 = str(bool_0)
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_0)
    assert (var_0 == var_1)


# Generated at 2022-06-24 17:22:45.711107
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    assert "frame" in True
    assert "self" in False
    assert "var_0" in True


# Generated at 2022-06-24 17:22:49.378716
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # case 0
    from inspect import currentframe
    frame_0 = currentframe()
    var_0 = BaseVariable('bool_0', exclude=())
    var_1 = var_0.items(frame_0)
    var_2 = ('(bool_0,)', 'None')
    var_1 = (var_1 == var_2)


# Generated at 2022-06-24 17:22:59.012878
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test 1
    from . import variable
    var_0 = variable.BaseVariable('test')
    var_1 = variable.BaseVariable('test')
    _temp_0 = var_0.__eq__(var_1)
    cor_res = True
    try:
        assert _temp_0 == cor_res
    except AssertionError:
        print("AssertionError")

    # Test 2
    var_0 = variable.BaseVariable('test0')
    var_1 = variable.BaseVariable('test1')
    _temp_0 = var_0.__eq__(var_1)
    cor_res = False
    try:
        assert _temp_0 == cor_res
    except AssertionError:
        print("AssertionError")


# Generated at 2022-06-24 17:23:04.391258
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = None
    expectation = ()
    arg_0 = frame
    arg_1 = normalize
    result = BaseVariable.items(arg_0, arg_1)
    assert result == expectation, "Expected {}, got {}".format(expectation, result)


# Generated at 2022-06-24 17:23:13.966926
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import abc
    from .basevariable import BaseVariable

    class Foo(BaseVariable, metaclass=abc.ABCMeta):
        pass

    assert not (Foo(None) == None)
    assert not (Foo(None) == "self._fingerprint")
    assert not (Foo(None) == "self.source")
    assert not (Foo(None) == "self.source")
    assert not (Foo(None) == "self._fingerprint")
    assert not (Foo(None) == "self.source")
    assert not (Foo(None) == "self.exclude")
    assert Foo(None) == Foo(None)
    assert not (Foo(None) == Foo(None, True))
    assert not (Foo(None, True) == Foo(None))

# Generated at 2022-06-24 17:23:17.745958
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('a', 'b')
    var_1 = BaseVariable('a', 'b')
    if var_0 != var_1:
        print('Failed')
#

# Generated at 2022-06-24 17:23:26.560696
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = None
    tuple_0 = (BaseVariable, tuple_0)
    list_0 = [BaseVariable, list_0]
    dict_0 = {BaseVariable: dict_0}
    # TypeError: must be str or a list (tuple, set or sequence), not BaseVariable
    # BaseVariable.items(__pdb_frame__, bool_0)
    BaseVariable.items(__pdb_frame__, tuple_0)
    BaseVariable.items(__pdb_frame__, list_0)
    BaseVariable.items(__pdb_frame__, dict_0)


# Generated at 2022-06-24 17:23:31.504261
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()
    test_case_1()



# Generated at 2022-06-24 17:23:34.477547
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable(None)
    var_1 = BaseVariable(None)
    assert var_0 == var_1


# Generated at 2022-06-24 17:23:52.388787
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    str_0 = '_t'
    str_1 = '_t1'
    str_2 = 'hasattr'
    str_3 = '_t'
    str_4 = 'hasattr'
    assert str_3 in str_1
    def _t():
        var_0 = BaseVariable(bool_0)
        return var_0
    _t()
    assert str_0 in str_1
    assert str_1 in str_0
    assert str_2 == str_4
    assert str_4 == str_2


# Generated at 2022-06-24 17:23:55.760596
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('', ())
    var_1 = BaseVariable('', ())
    assert var_0 == var_1


# Generated at 2022-06-24 17:24:05.942678
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # the following two variables are defined to test the inspect module
    def test_func_1(arg1, arg2):
        return 0

    class test_class_1(object):
        def __init__(self, arg1, arg2):
            self.func = 0
            self.attr = 0
            return

    class_1 = test_class_1(0, 0)
    func_1 = test_func_1
    # call of the method
    dict_0 = dict(func_1.__code__.co_varnames)
    result_1 = BaseVariable('class_1', exclude='func').items(func_1.__code__)
    result_2 = BaseVariable('class_1').items(func_1.__code__)


# Generated at 2022-06-24 17:24:09.955317
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1
    main_value_0 = {'a': 1}
    exclude_0 = ('a', )
    source_0 = 'main_value_0'
    
    BaseVariable(source=source_0, exclude=exclude_0).items(main_value_0)


# Generated at 2022-06-24 17:24:13.538671
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable("dummy_source",("dummy_exclude",))
    var_1 = BaseVariable("dummy_source",("dummy_exclude",))
    return var_0 == var_1


# Generated at 2022-06-24 17:24:16.142845
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (not (not BaseVariable.__eq__(BaseVariable(source=None), other=None)))





# Generated at 2022-06-24 17:24:25.483670
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    traceback = None
    normalize = False

    dump_list = []

    # test for Attrs
    keys = ['__dict__', '__slots__']
    values = [{}, ()]

    class test_class():
        pass

    class_inst = test_class()

    for key, value in zip(keys, values):
        setattr(class_inst, key, value)

    variable_inst = Attrs(class_inst)
    result_tuple = variable_inst.items(traceback, normalize)
    dump_list.extend([i[1] for i in result_tuple])
    result_tuple = variable_inst.items(traceback, normalize)
    dump_list.extend([i[1] for i in result_tuple])

    # test for Keys

# Generated at 2022-06-24 17:24:34.894021
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 1
    list_0 = []
    string_0 = '1'
    string_1 = 'a'
    dict_0 = {}
    dict_0[string_0] = int_0
    dict_0[string_1] = bool_0
    list_0.append(string_1)
    list_0.append(dict_0)
    dict_0 = {string_0: list_0}
    var_0 = Attrs(string_0).items(dict_0)
    var_1 = Attrs(string_1).items(dict_0)
    var_2 = Keys(string_0).items(dict_0)
    var_3 = Keys(string_1).items(dict_0)
    var_4 = Indices(string_0).items(dict_0)


# Generated at 2022-06-24 17:24:38.813468
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('0')
    var_1 = BaseVariable('1')
    var_2 = BaseVariable('0')
    assert_equal(var_0 == var_1, False)
    assert_equal(var_0 == var_2, True)


# Generated at 2022-06-24 17:24:46.894482
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    logger = logging.getLogger()
    logger.info('')
    logger.info('Test: method items of class BaseVariable')
    logger.info('')

    sub_test_1 = True
    if sub_test_1:
        # Test 1: check method items
        # Input arguments
        source = 'x'
        exclude = ''

        # Expected output
        exp_result = list()

        # Compute result
        instance = BaseVariable(source, exclude)
        result = instance.items(frame, normalize)
        # Test for expected output
        assert(result == exp_result)

    sub_test_2 = True
    if sub_test_2:
        # Test 2: check method items
        # Input arguments
        source = 'x'
        exclude = ''

        # Expected output
        exp_

# Generated at 2022-06-24 17:25:07.927374
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable()
    var_1 = BaseVariable()
    var_0.__eq__(var_1)


# Generated at 2022-06-24 17:25:12.014972
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = None
    bool_1 = None
    var_0 = BaseVariable(bool_0)
    var_1 = BaseVariable(bool_1)
    assert var_0 == var_1


# Generated at 2022-06-24 17:25:14.185115
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    result = BaseVariable('var_0.x').__eq__(BaseVariable('var_1.x'))
    assert result == False


# Generated at 2022-06-24 17:25:22.361067
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = None
    var_0 = BaseVariable(bool_0)
    bool_1 = None
    var_1 = BaseVariable(bool_1)
    bool_2 = type(var_0) is type(var_1)
    var_2 = var_0 == var_1
    bool_3 = bool_2 and var_2
    bool_4 = bool_3
    var_3 = needs_parentheses(bool_4)


# Generated at 2022-06-24 17:25:34.185879
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class_0 = BaseVariable
    var_0 = class_0('source')
    var_1 = class_0('source')
    var_2 = class_0('source', 'exclude')
    var_3 = class_0('source', 'exclude')
    var_4 = class_0('source', 'exclude', 'exclude')
    var_5 = class_0('source', 'exclude', 'exclude')
    assert (var_0 == var_0) == True
    assert (var_0 == var_1) == True
    assert (var_0 == var_2) == False
    assert (var_0 == var_3) == False
    assert (var_0 == var_4) == False
    assert (var_0 == var_5) == False


# Generated at 2022-06-24 17:25:35.822299
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable(None)
    var_2 = BaseVariable(None)
    assert var_1 == var_2


# Generated at 2022-06-24 17:25:48.334613
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 'var_0'
    bool_0 = None
    assert var_0 in needs_parentheses(var_0)
    var_1 = compile('var_1', '<variable>', 'eval').co_code
    bool_1 = None
    assert var_1 not in bool_1
    var_2 = 'var_2'
    bool_2 = None
    assert var_2 not in bool_2
    var_3 = compile('var_3', '<variable>', 'eval').co_code
    bool_3 = None
    assert var_3 not in bool_3
    var_4 = compile('var_4', '<variable>', 'eval').co_code
    bool_4 = None
    assert var_4 not in bool_4
    var_5 = 'var_5'
    bool

# Generated at 2022-06-24 17:26:00.844403
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from sys import getrefcount
    from numpy import array, dtype
    
    # Test case 0
    class var_0:
        
        def test___eq__():
            var_1 = BaseVariable('x.y')
            var_2 = BaseVariable('x.y')
            var_3 = BaseVariable('x.y', ())
            var_4 = BaseVariable('x.y', ())
            assert (var_1 == var_2)
            assert (var_3 == var_4)
    test___eq__()
    
    # Test case 1
    class var_0:
        
        def test___eq__():
            var_1 = BaseVariable('x.y')
            var_2 = BaseVariable('x.y', ('a',))
            var_3 = BaseVariable('x.y', ('b',))

# Generated at 2022-06-24 17:26:02.346347
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None).__eq__(BaseVariable(None))


# Generated at 2022-06-24 17:26:10.046906
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from debug_toolbar.panels.template.tests import pytest_funcarg__toolbar
    from debug_toolbar.panels.template.tests import pytest_funcarg__request
    from debug_toolbar.panels.template.tbtools import get_template_info
    info_0 = get_template_info(pytest_funcarg__toolbar, pytest_funcarg__request)
    assert info_0.template.endswith('debug_toolbar/panels/template/empty.html')


# Generated at 2022-06-24 17:27:11.809803
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    str_0 = 'source'
    tuple_0 = ()
    None_0 = None
    BaseVariable_0 = BaseVariable(str_0, tuple_0)
    BaseVariable_0.code = None_0
    BaseVariable_0.exclude = tuple_0
    BaseVariable_0.source = str_0
    BaseVariable_0._fingerprint = (None_0, str_0, tuple_0)
    BaseVariable_1 = BaseVariable(str_0, tuple_0)
    BaseVariable_1.code = None_0
    BaseVariable_1.exclude = tuple_0
    BaseVariable_1.source = 'not source'
    BaseVariable_1._fingerprint = (None_0, 'not source', tuple_0)
    BaseVariable_2

# Generated at 2022-06-24 17:27:15.306057
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = Attrs(None, None)
    bool_1 = bool_0.items(None, None)
    assert bool_1 == ()


# Generated at 2022-06-24 17:27:16.054639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Generated at 2022-06-24 17:27:17.348085
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None, None) == BaseVariable(None, None)



# Generated at 2022-06-24 17:27:22.761686
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    test_BaseVariable_items_var_0 = {'attr1': 'attr1-value', 'attr2': 'attr2-value'}
    test_BaseVariable_items_var_1 = Keys('{}', 'attr2').items(test_BaseVariable_items_var_0)

    test_BaseVariable_items_var_0.pop('attr1', None)


# Generated at 2022-06-24 17:27:33.010352
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 'arg'
    var_1 = compile(var_0, '<variable>', 'eval')
    var_2 = compile('{}[-1]', '<variable>', 'eval')
    var_3 = {
        'source': var_0,
        'exclude': (),
        'code': var_2,
        'unambiguous_source': var_0,
    }
    var_4 = var_3.copy()
    var_4['source'] = 'arg[-1]'
    var_5 = var_3.copy()
    var_5['source'] = 'arg[-11]'
    var_6 = var_3.copy()
    var_6['code'] = var_1
    var_7 = var_6.copy()
    # Actual output:
    #    

# Generated at 2022-06-24 17:27:37.509395
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    exclude = None
    normalize = None

    frame = None
    exclude = None
    normalize = False
    test_0 = BaseVariable('source', exclude)
    test_0.items(frame, normalize)


# Generated at 2022-06-24 17:27:40.912785
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = BaseVariable('a')
    bool_1 = (BaseVariable('a') == BaseVariable('a'))
    var_1 = (BaseVariable('a') == BaseVariable('b'))
    var_0 = bool_1
    assert var_0 is False



# Generated at 2022-06-24 17:27:42.783773
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    var_0 = BaseVariable(None, ())
    var_0.items(frame_0)


# Generated at 2022-06-24 17:27:45.442776
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = None
    BaseVariable_0 = BaseVariable(None, None)
    BaseVariable_0.items(None)



# Generated at 2022-06-24 17:29:00.040674
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = "source"
    exclude = tuple()
    _0 = BaseVariable(source, exclude)
    _1 = BaseVariable(source, exclude)
    _2 = BaseVariable(source, exclude)
    _3 = BaseVariable(source, exclude)
    _4 = BaseVariable(source, exclude)
    _5 = BaseVariable(source, exclude)
    _6 = BaseVariable(source, exclude)
    _7 = BaseVariable(source, exclude)
    _8 = BaseVariable(source, exclude)
    _9 = BaseVariable(source, exclude)
    _10 = BaseVariable(source, exclude)
    _11 = BaseVariable(source, exclude)
    _12 = BaseVariable(source, exclude)
    _13 = BaseVariable(source, exclude)
    _14 = BaseVariable(source, exclude)
    _15 = BaseVariable

# Generated at 2022-06-24 17:29:10.981588
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat

    int_0 = None
    str_0 = None
    list_0 = None
    int_1 = None
    int_2 = None
    int_3 = None
    Attrs_0 = None
    int_4 = None
    int_5 = None
    str_1 = None
    str_2 = None
    str_3 = None
    set_0 = None
    int_6 = None
    int_7 = None
    int_8 = None
    bool_0 = None
    int_9 = None
    int_10 = None
    str_4 = None
    str_5 = None
    str_6 = None
    Indices_0 = None
    int_11 = None
    int_12 = None
    int_13 = None


# Generated at 2022-06-24 17:29:17.196080
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source_0 = 'path'
    exclude_0 = None
    obj_0 = BaseVariable(source_0, exclude_0)
    source_1 = ''
    exclude_1 = ()
    obj_1 = BaseVariable(source_1, exclude_1)
    assert_equal(obj_0 == obj_1, False)

# generator for test case test_BaseVariable___hash___0

# Generated at 2022-06-24 17:29:26.487293
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = Attrs('foo')
    var_1 = var_0
    var_2 = var_0
    var_3 = var_0
    var_4 = var_0
    var_5 = var_0
    var_6 = var_0
    var_7 = var_0
    assert var_0 == var_1
    assert var_1 == var_2
    assert var_2 == var_3
    assert var_3 == var_4
    assert var_4 == var_5
    assert var_5 == var_6
    assert var_6 == var_7
    assert var_7 == var_0


# Generated at 2022-06-24 17:29:28.272372
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('<value>').__eq__(BaseVariable('<value>'))
    return "SUCCESS"


# Generated at 2022-06-24 17:29:29.611777
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    e = BaseVariable.__eq__(BaseVariable, BaseVariable)

# Generated at 2022-06-24 17:29:33.672426
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test cases for method items
    # param {BaseVariable} variable
    # param {frame} frame
    # param {bool} normalize
    # assert items(frame, normalize) == out_
    assert None


# Generated at 2022-06-24 17:29:35.765277
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    string_0 = 'abc'
    bool_0 = BaseVariable(string_0)
    bool_1 = bool_0.items('abc')
    assert bool_1 == None


# Generated at 2022-06-24 17:29:40.626366
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = None
    obj_0 = None
    var_0 = BaseVariable(bool_0,obj_0)


# Generated at 2022-06-24 17:29:44.396944
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a').__eq__(BaseVariable('a'))
    assert not BaseVariable('a').__eq__(BaseVariable('b'))
