

# Generated at 2022-06-24 17:21:34.113412
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = None
    base_variable_1 = BaseVariable(str_1)
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:21:36.063161
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)
    slice_0 = None
    indices_1 = indices_0[slice_0]


# Generated at 2022-06-24 17:21:37.500578
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 17:21:40.880085
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)
    assert isinstance(indices_0, BaseVariable)
    # Exception thrown from test.
    indices_0.__getitem__(slice(None))

# Generated at 2022-06-24 17:21:44.469817
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = ').'
    base_variable_0 = BaseVariable(str_0)
    frame_0 = None
    normalize_0 = False
    result = base_variable_0.items(frame_0, normalize_0)
    assert result is not None


# Generated at 2022-06-24 17:21:47.109849
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)
    slice_0 = slice(0, 10, 2)
    indices_0[slice_0]


# Generated at 2022-06-24 17:21:50.673073
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    obj_0 = Indices(str_0)
    obj_0.__getitem__(0)
    obj_0.__getitem__(0)

# Generated at 2022-06-24 17:21:54.162962
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    result = True
    utils.assert_equals(result, True)
    result = False
    utils.assert_equals(result, False)
#test_BaseVariable___eq__()
    

# Generated at 2022-06-24 17:21:56.084411
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)

# Generated at 2022-06-24 17:21:59.626450
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    # Test function body
    frame_0 = frame()
    base_variable_0.items(frame_0)

    return base_variable_0


# Generated at 2022-06-24 17:22:19.635902
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    frame_0 = None
    bool_0 = True
    result = base_variable_0.items(frame_0, bool_0)
    assert(result == ())


# Generated at 2022-06-24 17:22:22.395027
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices('hello')
    slice_1 = slice(0, 5, 1)
    base_variable_1 = indices_0[slice_1]

# Generated at 2022-06-24 17:22:24.015804
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)


# Generated at 2022-06-24 17:22:27.402715
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    frame_0 = None
    str_1 = None
    base_variable_0 = BaseVariable(str_0)
    base_variable_0._items(frame_0, str_1)


# Generated at 2022-06-24 17:22:35.346037
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('Unit test for method items of class BaseVariable')
    source = "This is the source string."
    exclude = "This is the exclude string."
    BaseVariable.__init__(BaseVariable, source, exclude)
    BaseVariable.items(BaseVariable, frame, normalize)


# Generated at 2022-06-24 17:22:39.800790
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)
    pycompat.implements_iterator(indices_0)
    object_0 = object()
    object_1 = object_0
    for object_2 in indices_0:
        object_1 = object_2


# Generated at 2022-06-24 17:22:42.822548
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    Indices_0 = Indices(str_0)
    slice_0 = slice(0, 1)
    Indices_0 = Indices_0[slice_0]
    assert Indices_0._slice == slice_0


# Generated at 2022-06-24 17:22:45.391396
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = None
    frame_0 = None
    base_variable_0.items(frame_0)


# Generated at 2022-06-24 17:22:47.547051
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = None
    indices_0 = Indices(str_0)
    indices_0[0]


# Generated at 2022-06-24 17:22:51.750233
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = None
    base_variable_1 = BaseVariable(str_1)
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:23:02.970792
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()
    base_variable_0 = BaseVariable('__file__')
    assert base_variable_0.items(frame) == (('__file__', '<string>'))


# Generated at 2022-06-24 17:23:11.896308
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    attrs_0 = Attrs(str_0)
    str_1 = None
    keys_0 = Keys(str_1)
    str_2 = None
    indices_0 = Indices(str_2)
    frame_0 = None
    bool_0 = False
    list_0 = attrs_0.items(frame_0, bool_0)
    list_1 = keys_0.items(frame_0, bool_0)
    list_2 = indices_0.items(frame_0, bool_0)


# Generated at 2022-06-24 17:23:16.058784
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    frame_0 = None
    bool_0 = BaseVariable(str_0).items(frame_0)
    str_0 = None
    frame_0 = None
    bool_1 = BaseVariable(str_0).items(frame_0)


# Generated at 2022-06-24 17:23:20.556355
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    common_variable_0 = None
    common_variable_1 = BaseVariable(str_0, common_variable_0)
    assert common_variable_0 == base_variable_0


# Generated at 2022-06-24 17:23:30.085409
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = 'aa'
    base_variable_1 = BaseVariable(str_1)
    assert base_variable_0.__eq__(base_variable_1)
    str_2 = 'aa'
    base_variable_2 = BaseVariable(str_2)
    assert base_variable_1.__eq__(base_variable_2)
    str_3 = 'aa'
    base_variable_3 = BaseVariable(str_3)
    assert base_variable_2.__eq__(base_variable_3)
    str_4 = 'aa'
    base_variable_4 = BaseVariable(str_4)
    assert base_variable_3.__eq__(base_variable_4)

# Generated at 2022-06-24 17:23:32.433502
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)



# Generated at 2022-06-24 17:23:40.719683
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    str_1 = None
    base_variable_0 = BaseVariable(str_0)
    base_variable_1 = BaseVariable(str_1)
    assert not base_variable_0 != base_variable_1
    int_0 = None
    base_variable_2 = BaseVariable(int_0)
    # assert not base_variable_2 != base_variable_1
    assert not base_variable_1 != base_variable_2
    assert not base_variable_0 != base_variable_2
    list_0 = None
    base_variable_3 = BaseVariable(list_0)
    assert not base_variable_2 != base_variable_3



# Generated at 2022-06-24 17:23:49.023619
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)

    assert(base_variable_0._fingerprint == (BaseVariable, None, tuple()))
    assert(base_variable_0 == BaseVariable(str_0))
    assert(base_variable_0 != BaseVariable(str_0, exclude='x'))
    assert(base_variable_0 != 'z')


# Generated at 2022-06-24 17:23:56.214449
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'p'
    exclude = ()
    base_variable_0 = BaseVariable(source, exclude)
    str_0 = None
    frame_0 = (str_0, str_0, str_0)
    list_0 = ()
    assert base_variable_0.items(frame_0) == list_0


# Generated at 2022-06-24 17:23:59.530590
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    assert not base_variable_0.__eq__(base_variable_0)


# Generated at 2022-06-24 17:24:07.079347
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_0 = None
    assert base_variable_0.items(str_0)



# Generated at 2022-06-24 17:24:08.109315
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    assert True


# Generated at 2022-06-24 17:24:19.261353
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    frame_0 = None
    bool_0 = base_variable_0.items(frame_0)
    float_0 = float(None)
    float_1 = float(None)
    float_2 = float(None)
    float_3 = float(None)
    float_4 = float(None)
    float_5 = float(None)
    float_6 = float(None)
    float_7 = float(None)
    float_8 = float(None)
    float_9 = float(None)
    float_10 = float(None)
    float_11 = float(None)
    float_12 = float(None)
    float_13 = float(None)
    float_14 = float(None)
    float

# Generated at 2022-06-24 17:24:24.472576
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    base_variable_1 = BaseVariable(str_0)
    base_variable_2 = BaseVariable(str_0)
    assert (base_variable_0 == base_variable_1), "Failed test_BaseVariable___eq__"
    assert not (base_variable_0 == base_variable_2), "Failed test_BaseVariable___eq__"


# Generated at 2022-06-24 17:24:29.704439
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = None
    base_variable_1 = BaseVariable(str_1)
    base_variable_0.__eq__(base_variable_1)


# Generated at 2022-06-24 17:24:31.907078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)


# Generated at 2022-06-24 17:24:37.228391
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    try:
        str_0 = None
        base_variable_0 = BaseVariable(str_0)
        str_1 = None
        base_variable_1 = BaseVariable(str_1)
        assert base_variable_0.__eq__(base_variable_1) == True
    except AssertionError:
        raise


# Generated at 2022-06-24 17:24:41.414759
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    bool_0 = bool()
    tuple_0 = utils.get_shortish_repr(None)
    tuple_1 = base_variable_0.items(frame_0, bool_0)
    assert tuple_0 == tuple_1

# Generated at 2022-06-24 17:24:49.581011
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = None
    frame_0 = None
    bool_0 = False
    # Test the correct return value.
    base_variable_0 = BaseVariable(str_0)
    assert base_variable_0.items(frame_0, bool_0) == ()
    # Test the correct return value.
    base_variable_1 = BaseVariable(str_0)
    assert base_variable_1.items(frame_0, bool_0) == ()
    # Test the correct return value.
    base_variable_2 = BaseVariable(str_0)
    assert base_variable_2.items(frame_0, bool_0) == ()
    # Test the correct return value.
    base_variable_3 = BaseVariable(str_0)

# Generated at 2022-06-24 17:24:53.559933
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = None
    base_variable_0 = BaseVariable(str_0)
    str_1 = None
    base_variable_1 = BaseVariable(str_1)
    base_variable_0 == base_variable_1



# Generated at 2022-06-24 17:25:02.468280
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    src_loc_0 = inspect.currentframe().f_back.f_lineno
    test_BaseVariable_items_1(src_loc_0)
    test_BaseVariable_items_2(src_loc_0)

# Test Attrs

# Generated at 2022-06-24 17:25:15.411680
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .utils import ensure_tuple
    bytes_0 = b'N'
    bytes_1 = b'T'
    cls_0 = Sequence
    exception_0 = Exception
    tuple_0 = (1,)
    tuple_1 = ensure_tuple(tuple_0)
    tuple_2 = tuple(tuple_1)
    tuple_3 = (1, 2)
    tuple_4 = tuple(tuple_3)
    tuple_5 = ensure_tuple(tuple_4)
    tuple_6 = tuple(tuple_5)
    bool_0 = BaseVariable.__eq__(Keys(bytes_0), Keys(bytes_1))
    bool_1 = BaseVariable.__eq__(Keys(bytes_0), Keys(bytes_0))

# Generated at 2022-06-24 17:25:25.227373
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_1 = b'S'
    dict_1 = dict()
    dict_1['key_1'] = 3
    dict_1['key_2'] = 'value_2'
    dict_1['key_0'] = 'value_0'
    keys_0 = Keys(bytes_1)
    tuple_0 = (dict_1,)
    dict_0 = dict()
    dict_0['key_2'] = 'value_2'
    dict_0[keys_0] = 'value_1'
    dict_0['key_0'] = 'value_0'
    dict_0['key_1'] = 'value_1'
    assert (tuple_0.__eq__(keys_0.items(dict_0)) == about_equal(tuple_0, dict_0))


# Generated at 2022-06-24 17:25:31.433578
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'A'
    keys_0 = Keys(bytes_0)
    test_BaseVariable_items_result = list(keys_0.items(None))
    assert (test_BaseVariable_items_result == [(bytes_0, "'A'"), (bytes_0+'[0]', "'A'"), (bytes_0+'[1]', "'A'")])



# Generated at 2022-06-24 17:25:36.939958
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    keys_0 = Keys(1)
    assert keys_0.items('c') == 1
    assert keys_0.items(1) == 1
    assert keys_0.items(1.0) == 1
    assert keys_0.items(False) == 1
    assert keys_0.items(True) == 1
    assert keys_0.items(None) == 1
    assert keys_0.items(()) == 1
    assert keys_0.items([]) == 1
    assert keys_0.items({}) == 1

# Generated at 2022-06-24 17:25:49.112244
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    global source_0
    source_0 = 'str'
    temp_0 = BaseVariable(source_0, exclude='str')
    temp_1 = BaseVariable(source_0, exclude='str')
    
    assert temp_0 == temp_1

    # Test for alternate path
    temp_1 = BaseVariable(source_0, exclude='')
    
    assert not temp_0 == temp_1
    
    # Test for alternate path
    temp_1 = BaseVariable(source_0, exclude='')
    
    assert not temp_0 == temp_1
    
    # Test for alternate path
    temp_1 = BaseVariable(source_0, exclude='')
    
    assert not temp_0 == temp_1
    
    # Test for alternate path
    temp_1 = source_0
    

# Generated at 2022-06-24 17:25:55.774157
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert self.source == self.source
    assert not self.source == self.exclude
    assert self.source == self.keys_0
    assert not self.source == self.unambiguous_source
    assert not self.source == self.code
    assert not self.source == self._fingerprint
    # TODO: handle this test correctly
    # assert self.source == self.__hash__()

# Generated at 2022-06-24 17:25:59.935214
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'N'
    base_variable_0 = Attrs(bytes_0)
    bytes_1 = b'N'
    bool_0 = Attrs(bytes_1) == base_variable_0
    assert bool_0


# Generated at 2022-06-24 17:26:03.041809
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test a ValueError raised in the function
    import sys
    try:
        BaseVariable.items(sys.stderr)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 17:26:07.588038
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_frame_0(name):
        locals_0 = {'name': 'B', 'age': 18}
        keys_0 = Keys(name)
        keys_0.items(locals(), normalize=True)
    test_frame_0('name')


# Generated at 2022-06-24 17:26:23.737686
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import platform, json
    import inspect
    import pytest

    stack = inspect.stack()
    if stack[1][3] == 'test_BaseVariable_items':
        from . import context
        from . import template
        from . import variables
        from . import markers
        from . import utils

    # Test for function utils.get_shortish_repr
    def test_utils_get_shortish_repr():
        assert utils.get_shortish_repr(
            'Hello-World!-This-is-a-very-long-string-for-unit-test.'
            '-The-exact-length-is-42-characters.', min_length=10, max_length=40) \
            == 'Hello-Wor...is-a-very-long-string...'

    # Test for

# Generated at 2022-06-24 17:26:29.643683
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # case 1
    assert (BaseVariable('a.b').items(None)[0] == ('a.b', 'None'))

    # case 2
    assert (BaseVariable('a.b', (1, 2)).items(None)[0] == ('a.b', 'None'))

    # case 3
    assert (BaseVariable('a.b', 1).items(None)[0] == ('a.b', 'None'))



# Generated at 2022-06-24 17:26:36.138892
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'N'
    keys_0 = Keys(bytes_0)
    bytes_1 = b'@'
    f_locals = {'N': bytes_0, '@': bytes_1}
    utils.assertEqualsHashed(
        keys_0.items(f_locals, normalize=True),
        (('N', 'b\'N\''), ('N[0]', '78'), ('N[1]', '64'))
    )



# Generated at 2022-06-24 17:26:42.972473
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Keys('a').items({'a': 'b'}) == [('a', "b'b'")]
    assert Attrs('d').items({'e': {'d': 'f'}}) == [("d", "b'f'")]
    assert Indices('h').items({'h': [1, 2, 3]}) == [("h[0]", "1")]
    assert Indices('k')[1:].items({'k': [1, 2, 3]}) == [("k[1]", "2"), ("k[2]", "3")]


# Generated at 2022-06-24 17:26:48.089428
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case 0
    obj = BaseVariable('bytes_0')
    frame = {'bytes_0': b'N'}
    result = obj.items(frame, normalize=False)
    assert result == [('bytes_0', 'b\'N\'')]


# Generated at 2022-06-24 17:26:57.860203
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def side_effect():
        raise RuntimeError('side_effect')

    def side_effect_2():
        raise KeyError('side_effect_2')

    variable = BaseVariable('sdasd')
    variable_2 = BaseVariable()
    variable_2.source = 'adsasd'
    variable_2.exclude = RuntimeError()
    variable_2.code = compile('adsasd', '<string>', 'eval')
    variable_2.unambiguous_source = '()'
    variable_3 = BaseVariable()
    variable_3.source = 'adsasd'
    variable_3.exclude = 'adsasd'
    variable_3.code = compile('adsasd', '<string>', 'eval')
    variable_3.unambiguous_source = '()'

    # Test with valid arguments

# Generated at 2022-06-24 17:27:05.134107
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'sys.version_info'
    v = BaseVariable(source)
    import sys
    f_locals = sys.version_info.__dict__
    f_locals['v'] = v
    r = eval('v.items(sys.version_info)', sys.version_info.__dict__, f_locals)
    assert r == (('sys.version_info', 'sys.version_info'),)


# Generated at 2022-06-24 17:27:07.490041
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    __tracebackhide__ = True
    test_source = "self"
    test_frame = sys._getframe()
    test_BaseVariable = BaseVariable(test_source)
    test_BaseVariable.items(test_frame)

# Generated at 2022-06-24 17:27:10.359872
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """Test items(frame, normalize) of BaseVariable."""
    frame = utils.Frame(None, globals(), locals())
    var = BaseVariable(source)
    var.items(frame, False)


# Generated at 2022-06-24 17:27:16.715893
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
  import inspect
  import pytest
  import re
  import types
  import uuid
  from inspect import getmodule
  from inspect import isclass
  from inspect import isfunction
  from inspect import ismodule
  from inspect import ismethod
  from inspect import istraceback
  from inspect import isframe
  from inspect import iscode
  from inspect import isbuiltin
  from inspect import isroutine
  from inspect import isgenerator
  from inspect import isgeneratorfunction
  from inspect import getmembers
  from inspect import getsourcefile
  from inspect import getfile
  from inspect import currentframe
  from inspect import getdoc
  from inspect import getcomments
  from inspect import getsource
  from inspect import getstatistics
  from inspect import getmoduleinfo
  from inspect import getclasstree
  from inspect import getargspec

# Generated at 2022-06-24 17:27:33.035895
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import test_helpers
    frame = sys._getframe()
    result_0 = Attrs('test_case_0').items(frame, normalize=False)
    expected_0 = [(
        'test_case_0',
        "Attrs('test_case_0', exclude=())",
    ), (
        'test_case_0.bytes_0',
        "'N'",
    ), (
        'test_case_0.keys_0',
        "Keys('N')",
    )]
    assert result_0 == expected_0

    test_helpers.reset_globals(frame.f_back)



# Generated at 2022-06-24 17:27:38.586471
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    code_0 = compile('x.b', '<variable>', 'eval')

    code_1 = compile('x[1]', '<variable>', 'eval')

    code_2 = compile('x.b', '<variable>', 'eval')

    assert code_0 == code_1 == code_2


# Generated at 2022-06-24 17:27:39.538235
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass



# Generated at 2022-06-24 17:27:49.282242
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import typing
    from . import typing as typing2
    from .typing import *
    from .typing import __all__, __name__
    from .typing import __all__ as __all___0, __name__ as __name___0
    from . import typing as typing3
    from .typing import __all__, __name__
    from .typing import __all__ as __all___0, __name__ as __name___0
    abc = (1, 2, 3, [6])
    typing2 = (1, 2, 3, [6])
    typing3 = (1, 2, 3, [6])
    typing.__all__ = ()
    typing.__name__ = 'test'
    typing2.__all__ = ()
    typing2.__name__ = 'test'

# Generated at 2022-06-24 17:27:51.557770
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    traceback_0 = Traceback({}, frames=[Frame({'b': 2, 'c': {'d': 3}})])


# Generated at 2022-06-24 17:28:02.220108
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert utils.test()
    bytes_0 = b'N'
    keys_0 = Keys(bytes_0)
    assert keys_0.items.__doc__
    frame_0 = {}
    assert keys_0.items(frame_0) == [('N', 'b\'' + str(bytes_0) + '\''), ("N['N']", '0')]
    buffer_0 = bytearray(4)
    dict_0 = {'bytes_0': bytes_0, 'keys_0': keys_0, 'buffer_0': buffer_0}
    keys_0 = Keys('bytes_0', exclude='buffer_0')

# Generated at 2022-06-24 17:28:05.523309
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    data = "some_data"
    source = "source"
    exclude = "exclude"
    v = BaseVariable(data,exclude)
    v.items(source)




# Generated at 2022-06-24 17:28:08.154383
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Tests for issue #51 ('key' is not defined in method _keys of class BaseVariable).
    # It's there!
    import inspect
    assert 'key' in inspect.getargspec(BaseVariable._keys)[0]

# Generated at 2022-06-24 17:28:13.256589
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    Tests whether the items of BaseVariable returns correct output.
    """
    test_string = "Testing"
    string_1 = BaseVariable(test_string)
    string_1_items = string_1.items(frame=None)
    assert string_1_items[0][0] == test_string
    assert string_1_items[0][1] == 'Testing'


# Generated at 2022-06-24 17:28:18.117173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'bar'
    exclude_0 = 'foo'
    obj = Attrs(source, exclude=exclude_0)
    frame = None
    normalize = False
    assert obj.items(frame, normalize) == (('bar', "<class 'str'>"),)

# Generated at 2022-06-24 17:28:40.772329
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:28:46.366449
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dct = {"a": 1}
    expr = "dct"
    keys = Keys(expr)
    vars = {}
    vars.update(dct)
    lcls = locals()
    lcls.update(dct)
    items = keys.items(lcls)
    assert items == [('dct', '{...}'), ('dct[\'a\']', '1')]


# Generated at 2022-06-24 17:28:49.749557
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'5'
    keys_0 = Keys(bytes_0)
    keys_0._items([])


# Generated at 2022-06-24 17:28:56.842646
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame = None  # TODO: construct a test frame
    test_BaseVariable = BaseVariable(test_frame)
    test_normalize = None  # TODO: set a test value for parameter normalize
    test_expected = "TODO: expected result"  # TODO: set a test expected value (float, int, str, etc.)
    test_result = test_BaseVariable.items(test_frame, test_normalize)
    assert test_result == test_expected


# Generated at 2022-06-24 17:29:00.545278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    BaseVariable.source = "a"
    BaseVariable.exclude = ("a")
    BaseVariable.items("b")
    BaseVariable.source = "c"
    BaseVariable.items("d")


# Generated at 2022-06-24 17:29:02.917769
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Keys('b').items(None) == [('b', '[1, 2, 3]')]

# Generated at 2022-06-24 17:29:04.933043
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert isinstance(BaseVariable('').items(None), tuple)

# Generated at 2022-06-24 17:29:10.335323
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys

    def frame():
        keys_0 = Keys(b'N')
        return sys._getframe(1)

    frame_0 = frame()
    source_0 = b'N'
    exclude_0 = ()
    base_variable_0 = BaseVariable(source_0, exclude_0)
    assert base_variable_0.items(frame_0) == keys_0.items(frame_0)



# Generated at 2022-06-24 17:29:13.621950
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    keys_0 = Keys('key')
    frame_0 = get_frame()
    result = keys_0.items(frame_0, False)
    assert result is not None


# Generated at 2022-06-24 17:29:25.726155
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = int('6')
    dict_0 = dict()
    dict_0['0'] = int_0
    dict_0[int_0] = int_0
    dict_0['1'] = int_0
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]
    dict_0[int_0] = dict_0[int_0]

# Generated at 2022-06-24 17:30:17.435563
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # TODO: Fix test
    if pycompat.PYTHON_VERSION >= (3, 0, 0):
        return

    # Test for function items of class BaseVariable
    def func():
        return 'x'
    var = BaseVariable('func')
    assert var.items(frame=None) == [('func', '<function func>')]

    # Test for object items of class BaseVariable
    class Cls:
        pass
    cls = Cls()
    cls.x = 10
    var = BaseVariable('cls')
    items = [('cls', '<Cls object>'), ('cls.x', '10')]
    assert var.items(frame=None) == items



# Generated at 2022-06-24 17:30:27.601539
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from sys._getframe import getframe
    from binascii import hexlify
    from types import FrameType
    from types import TracebackType
    from types import ModuleType
    from types import MethodType
    from types import BuiltinFunctionType
    from types import BuiltinMethodType
    from types import CodeType
    from types import GeneratorType
    from types import DynamicClassAttribute
    from types import MemberDescriptorType
    from types import GetSetDescriptorType
    from types import MappingProxyType
    from types import SimpleNamespace
    from types import StaticMethodType
    from types import ClassMethodType
    from types import WrapperDescriptorType
    from ast import arguments
    from ast import comprehension
    from ast import ExceptHandler
    from ast import keyword
    from ast import withitem
    from ast import cmpop

# Generated at 2022-06-24 17:30:33.793749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    local_var = 5
    test_scope = {'local_var': local_var, '__name__': '__main__'}
    code = """base_variable = BaseVariable("local_var")
    base_variable.items(test_scope)
    """
    result, result_type = utils.iframe_exec(code, test_scope)
    assert result == [('local_var', '5')] and result_type == list
    assert pycompat.is_py2 or not isinstance(result, utils.string_types) and result_type == list
    

# Generated at 2022-06-24 17:30:36.038315
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = object()
    normalize = False
    result = BaseVariable.items(frame, normalize)
    assert result is NotImplemented


# Generated at 2022-06-24 17:30:41.508345
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test number 0
    instance = BaseVariable(source = 'bytes_0', exclude = ())
    result = instance.items(frame = None, normalize = False)
    expected = ()
    assert result == expected, "Test 0 - Expected result: %s, Actual result: %s" % (expected, result)


# Generated at 2022-06-24 17:30:42.770833
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable("abc")
    assert v.items("abc") == ()


# Generated at 2022-06-24 17:30:49.240793
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    logger = logging.getLogger('lib.variables.test_BaseVariable_items')
    logger.info('Testing items of BaseVariable')
    scope = {'x': {'y': 'z'}}
    # Verify that calling item works
    item_0 = BaseVariable('x', exclude={'y'})
    item_0.items(frame=scope)


# Generated at 2022-06-24 17:30:51.818840
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import cgitb

    bytes_0 = b'N'
    utils.assert_equal(Keys(bytes_0).items(None), b'N')

# Generated at 2022-06-24 17:30:56.719660
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    local_vars = {'a': True, 'b': False}
    frame = type('Frame', (), {'f_locals': local_vars})
    assert BaseVariable('a').items(frame) == [
        ('a', 'True'),
    ]
    assert BaseVariable('b').items(frame) == [
        ('b', 'False'),
    ]


# Generated at 2022-06-24 17:31:07.635226
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test with variable that has multiple items, i.e. str 'abc' -> ('abc', 'abc.0', 'abc.1', 'abc.2')
    variable_0 = Keys('abc')
    assert variable_0.items(1) == (('abc', "'{}'".format('abc')), ('abc[0]', "'{}'".format('a')), ('abc[1]', "'{}'".format('b')), ('abc[2]', "'{}'".format('c')))

    # Test with variable that has only one item, i.e. str 'abc' -> ('abc', 'abc')
    variable_1 = Keys('abc')