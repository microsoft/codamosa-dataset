

# Generated at 2022-06-24 17:21:39.600641
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:21:47.387228
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -1
    str_0 = '-a0gdORF0JzKxOwI.77zC'
    str_1 = '3'
    Keys_0 = Keys(int_0, str_0)
    base_variable_0 = BaseVariable(str_1, str_0)
    # assert base_variable_0.items() == Keys_0.items()
    # assert not base_variable_0.items() == (BaseVariable,)
    # assert not base_variable_0.items() == (Keys_0.items(),)
    # assert not base_variable_0.items() == (base_variable_0,)


# Generated at 2022-06-24 17:21:59.584430
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = 'var_0'
    var_1 = 'var_1'
    var_2 = 'var_2'
    var_3 = 'var_3'
    var_4 = 'var_4'
    var_5 = 'var_5'
    var_6 = 'var_6'
    var_7 = 'var_7'
    var_8 = 'var_8'
    var_9 = 'var_9'
    var_10 = 'var_10'
    var_11 = 'var_11'
    var_12 = 'var_12'
    var_13 = 'var_13'
    var_14 = 'var_14'
    var_15 = 'var_15'
    var_16 = 'var_16'
    var_17 = 'var_17'
   

# Generated at 2022-06-24 17:22:04.344543
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices('test_source', 'test_exclude')
    indices_0__getitem__ = indices_0.__getitem__(slice(1, 3))
    assert isinstance(indices_0__getitem__, Indices)
    assert indices_0__getitem__._slice == slice(1, 3)

# Generated at 2022-06-24 17:22:07.088214
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    if True:
        bool_0 = True
        indices_0 = Indices(bool_0)
        assert not indices_0.__eq__('a')



# Generated at 2022-06-24 17:22:13.964458
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert pycompat.is_py2 is True
    assert BaseVariable(1).__eq__(None) is False
    assert BaseVariable(1).__eq__('str') is False
    assert BaseVariable(1).__eq__(False) is False
    assert BaseVariable(1).__eq__(1) is False
    assert BaseVariable(1).__eq__('1') is False
    assert BaseVariable(1).__eq__(BaseVariable(1)) is True
    assert BaseVariable(1).__eq__(BaseVariable(2)) is True
    assert BaseVariable(False).__eq__(BaseVariable(False)) is True
    assert BaseVariable(False).__eq__(BaseVariable(True)) is True
    assert BaseVariable('str').__eq__(BaseVariable('str')) is True
    assert BaseVariable('str').__eq__

# Generated at 2022-06-24 17:22:22.403334
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = frame_obj()
    frame_0.f_locals['bool_0'] = True
    frame_0.f_locals['keys_0'] = Keys('bool_0')
    frame_0.f_locals['entries_0'] = keys_0.items(frame_0)
    frame_0.f_locals['attrs_0'] = Attrs('keys_0')
    frame_0.f_locals['entries_1'] = attrs_0.items(frame_0)
    frame_0.f_locals['attrs_1'] = Attrs('attrs_0')
    frame_0.f_locals['entries_2'] = attrs_1.items(frame_0)
    frame_0.f_locals['exploding_0'] = Exploding

# Generated at 2022-06-24 17:22:24.353378
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = Attrs('foo')
    str_0 = str(bool_0)
    Attrs('bar') == bool_0
    assert str(bool_0) == str_0

# Generated at 2022-06-24 17:22:26.846350
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    item = slice
    ans = [False]
    try:
        assert indices_0[item] is ans
    except AssertionError as e:
        print ('Expected {}, but got {}'.format(ans, indices_0[item]))




# Generated at 2022-06-24 17:22:31.076906
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    attrs_0 = Attrs(bool_0)
    assert attrs_0.items('bool_0') == ()
    assert attrs_0.items('bool_0', 'normalize') == ()


# Generated at 2022-06-24 17:22:38.556388
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    func_0 = {"a": 1, "b": 2}
    common_variable_0 = Keys(func_0)
    print(common_variable_0.items(func_0))

# Generated at 2022-06-24 17:22:46.023176
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True


# Generated at 2022-06-24 17:22:46.668577
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert True

# Generated at 2022-06-24 17:22:51.454095
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class_0 = BaseVariable
    source_0 = "dummy_source"
    frame_0 = "dummy_frame"
    # Call method items
    BaseVariable.items(class_0, source_0, frame_0)


# Generated at 2022-06-24 17:22:58.404240
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pyvar_0 = True
    pyvar_1 = Keys(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Indices(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Keys(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Indices(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Attrs(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Indices(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Keys(pyvar_0)
    pyvar_0 = False

    pyvar_1 = Indices(pyvar_0)
    pyvar_0 = False


# Generated at 2022-06-24 17:23:10.184319
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Python file fixtures/test_case_0.py executed, output follows:
    #
    # +---------------------+-------------------------+
    # | Original            | Current                 |
    # +=====================+=========================+
    # | PyTestReport.groups | ('[a]', '[b]')          |
    # +---------------------+-------------------------+
    # | PyTestReport.trace  | ('[0]', '_execute_test')|
    # +---------------------+-------------------------+
    assert indices_0.items() == (('[4]', '"he"'),
                                 ('[3]', '"llo"'),
                                 ('[1]', '"ello"'),
                                 ('[2]', '"o"'),
                                 ('[0]', '"h"'))


# Generated at 2022-06-24 17:23:20.505961
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pprint import pprint
    test_objects = [
        BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__'), BaseVariable(
            'i', exclude='__init__')]

# Generated at 2022-06-24 17:23:21.990449
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('source')
    variable.items('frame')


# Generated at 2022-06-24 17:23:23.467337
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert True


# Generated at 2022-06-24 17:23:31.382219
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = float()
    float_1 = float()
    int_0 = int()
    str_0 = str()
    list_0 = list()
    str_1 = str()
    str_2 = str()
    float_2 = float()
    float_3 = float()
    str_3 = str()
    str_4 = str()
    float_4 = float()
    str_5 = str()
    float_5 = float()
    float_6 = float()
    str_6 = str()
    float_7 = float()
    str_7 = str()
    str_8 = str()
    float_8 = float()
    str_9 = str()
    float_9 = float()
    float_10 = float()
    str_10 = str()
    float_11 = float()

# Generated at 2022-06-24 17:23:42.612534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 42
    KeyError_0 = KeyError()
    dict_0 = dict()
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0
    dict_0[int_0] = int_0

# Generated at 2022-06-24 17:23:48.211464
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    str_1 = 'baz'
    str_2 = 'foo'
    float_0 = float()
    int_0 = int()
    list_0 = [str_0, str_0, str_1, str_1, str_1, str_1, str_1, str_0]
    list_1 = [int_0, int_0]
    list_2 = []
    dict_0 = {}
    dict_1 = {}
    dict_0[str_0] = list_0
    dict_0[str_1] = list_0
    dict_0[str_1] = list_2
    dict_0[str_0] = list_1
    dict_0[str_0] = list_1

# Generated at 2022-06-24 17:23:50.549784
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    attrs_0 = Attrs('bar')
    # Testing argument normalize of method items
    assert attrs_0.items(None) == [('bar', 'bar')]


# Generated at 2022-06-24 17:23:59.718668
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Attrs('foo').items({'foo': {'bar': 1}}) == [('foo', '{bar: 1}')]
    assert Attrs('foo').items({'foo': {'bar': 1}}, normalize=True) == [('foo', '{bar: 1}')]
    assert Attrs('foo').items({'foo': {'bar': 1, 'baz': 2}}, normalize=True) == [('foo', '{bar: 1, baz: 2}')]
    assert Attrs('foo').items({'foo': {'bar': 1, 'baz': 2}}, normalize=True) == [('foo', '{bar: 1, baz: 2}')]
    assert Attrs('foo').items({'foo': 'bar'}) == [('foo', 'bar')]
    assert Attrs

# Generated at 2022-06-24 17:24:05.409885
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    map_0 = Map()
    print(BaseVariable(str_0).items(map_0))


# Generated at 2022-06-24 17:24:07.439373
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    aVar = BaseVariable("aVar")
    assert isinstance(aVar, BaseVariable)
    assert isinstance(aVar, object)


# Generated at 2022-06-24 17:24:09.303895
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'pytest'
    assert str_0 == 'pytest'


# Generated at 2022-06-24 17:24:20.221261
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:24:23.185357
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    frame_0 = None
    attrs_0 = Attrs(str_0)
    result_0 = attrs_0.items(frame_0)
    assert result_0 == ()


# Generated at 2022-06-24 17:24:33.890901
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'foo'
    obj_0 = object()
    set_0 = {obj_0}
    dict_0 = {str_0: obj_0}
    attrs_0 = Attrs(str_0)
    source_0 = '0'
    str_1 = str_0
    arr_0 = [[0], [1], [2], [3], [4], [5], [6], [7], [8], [9]]
    indices_0 = Indices(str_1)
    tuple_0 = (obj_0, obj_0, obj_0, obj_0, obj_0, obj_0, obj_0, obj_0, obj_0)
    str_2 = str_0
    dict_1 = dict_0
    list_0 = [obj_0]
    attrs

# Generated at 2022-06-24 17:24:55.240305
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    _tuple_0 = ('foo', 'bar', 'baz')
    _tuple_1 = ('foo', 'bar', 'baz')
    _tuple_2 = ('foo', 'bar', 'baz')
    _tuple_3 = ('foo', 'bar', 'baz')
    _tuple_4 = ('foo', 'bar', 'baz')
    _list_0 = list(_tuple_4)
    _list_1 = list(_tuple_4)
    _list_2 = list(_tuple_4)
    _list_3 = list(_tuple_4)
    _list_4 = list(_tuple_4)
    _list_5 = list(_tuple_4)
    _list_6 = list(_tuple_4)

# Generated at 2022-06-24 17:25:06.619472
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'foo'
    in_values_0 = None
    in_values_1 = {}
    utils_get_shortish_repr_0 = utils.get_shortish_repr(str_0, True)
    utils_get_shortish_repr_1 = utils.get_shortish_repr(()), utils_get_shortish_repr_0
    out_values_0 = utils_get_shortish_repr_1
    out_values_1 = utils_get_shortish_repr_1
    
    in_values_2 = {}
    in_values_3 = {}
    utils_get_shortish_repr_2 = utils.get_shortish_repr(str_0, True)
    utils_get_shortish

# Generated at 2022-06-24 17:25:10.872848
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_10 = 'foo'
    attrs_10 = Attrs(var_10)
    # assert attrs_10.items() == ((var_10, 'foo'), )


# Generated at 2022-06-24 17:25:15.260713
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    str_1 = 'bar'
    attrs_0 = Attrs(str_0)
    pycompat_temp_0 = attrs_0.items(str_1)



if (__name__ == '__main__'):
    test_case_0()
    test_BaseVariable_items()

# Generated at 2022-06-24 17:25:25.177193
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    frame_obj = None
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame_obj)
    frame_obj = None
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame_obj)
    frame_obj = None
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame_obj)
    frame_obj = None
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame_obj)
    frame_obj = None
    attrs_0 = Attrs(str_0)
    attrs_0.items(frame_obj)
    frame_obj = None
    attrs_0 = Attrs(str_0)

# Generated at 2022-06-24 17:25:33.970739
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source_0 = 'bar'
    exclude_0 = ('bar', 'foo')
    exclude_1 = ('baz', 'baz')
    var_0 = Attrs(source_0, exclude_0)
    assert var_0.items() == ()
    var_1 = Attrs(source_0, exclude_1)
    assert var_1.items() == ()
    source_1 = 'foo'
    exclude_2 = ('bar', 'foo')
    var_2 = Attrs(source_1, exclude_2)
    assert var_2.items() == ()


# Generated at 2022-06-24 17:25:40.577944
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Try to find the value for which the expression evaluates to an exception.
    # The exception maches the given exception.
    str_0 = 'bar'
    m = re.search('\W', str_0)
    if m != None:
        str_0 = str_0[m.start() + 1:]
    if len(str_0) > 1:
        str_0 = str_0[1:]
    str_1 = 'baz'
    explode_0 = Exploding(str_0)
    try:
        explode_0.items(None, False)
    except Exception as e0:
        assert type(e0) == AttributeError
    explode_1 = Exploding(str_1)
    try:
        explode_1.items(None, False)
    except Exception as e1:
        assert type

# Generated at 2022-06-24 17:25:51.102222
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    str_1 = 'bar'
    attrs_1 = Attrs(str_1)
    # Tuple of objects
    tuple_0 = (attrs_0, attrs_1)
    str_2 = 'bar'
    attrs_2 = Attrs(str_2)
    str_3 = 'bar'
    attrs_3 = Attrs(str_3)
    tuple_1 = (attrs_2, attrs_3)
    dict_0 = dict()
    dict_0[tuple_0] = tuple_1
    str_4 = 'bar'
    attrs_4 = Attrs(str_4)
    str_5 = 'bar'

# Generated at 2022-06-24 17:25:59.075266
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    foo_instance_0 = foo()
    foo_instance_0.bar = {'baz': 'qux'}
    list_0.append(foo_instance_0)
    list_0.append({'baz': 'qux'})
    list_0.append([1, 2, 3, 4, 5, 6, 7, 8, 9])
    list_0.append((1, 2, 3, 4, 5, 6, 7, 8, 9))
    list_0.append(ImmutablePoint.create_IMMUTABLEPOINT(1,2))
    str_0 = 'bar'
    str_1 = 'bar'
    str_2 = 'bar'
    for obj in list_0:
        attrs_0 = Attrs(str_0)
        keys_0

# Generated at 2022-06-24 17:26:01.610173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    return attrs_0.items()


# Generated at 2022-06-24 17:26:26.138282
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test_case_0
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    str_1 = 'foo'
    int_0 = 3

    class_0 = type(str_0, (), {str_1: int_0})
    class_1 = type('baz', (class_0,), {})
    instance_0 = class_1()
    result = attrs_0.items(frame=instance_0)
    assert result == [('bar', "b'foo'")]


# Generated at 2022-06-24 17:26:29.445152
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dct = {"a":1,"b":2}
    obj = Keys(source='dct', exclude=['a'])
    result = obj.items(dct)
    assert result == [
        ('dct.b', '2')
    ]


# Generated at 2022-06-24 17:26:38.990828
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import pycompat

    str_0 = "bar"
    dict_1 = {"foo": "baz"}
    list_2 = []
    list_2.append(1)
    list_2.append(0)
    tuple_3 = (1, 0)
    dict_4 = {}
    dict_4["foo"] = "baz"
    dict_5 = {"bar": list_2}
    dict_6 = {"baz": list_2}
    dict_7 = {"bar": tuple_3}
    dict_8 = {"baz": tuple_3}
    dict_9 = {"foo": dict_5}
    dict_10 = {"bar": dict_6}
    dict_11 = {"baz": dict_7}
    dict_12 = {"bar": dict_8}
    dict_13

# Generated at 2022-06-24 17:26:43.613191
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    str_1 = attrs_0.items(0)



# Generated at 2022-06-24 17:26:50.126464
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for case 0
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    frame_0 = {}
    normalize_0 = False
    assert attrs_0.items(frame_0) == attrs_0.items(frame_0, normalize_0) == [('bar', 'bar')]



# Generated at 2022-06-24 17:26:55.420454
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0_0 = 'foo'
    attrs_0_0 = Attrs(str_0_0)
    dict_0_0 = {str_0_0: attrs_0_0}
    assert attrs_0_0.items(dict_0_0) == dict_0_0   # Final check


# Generated at 2022-06-24 17:26:56.863449
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)


# Generated at 2022-06-24 17:27:05.445083
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 'str_0' -- Attrs
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    assert attrs_0.source == str_0
    assert attrs_0.exclude == ()
    assert attrs_0.unambiguous_source == str_0
    attrs_0._items(attrs_0)
    assert attrs_0.items(attrs_0) == ('bar',)
    assert attrs_0._safe_keys(attrs_0) == ('bar',)

    # Test 'str_1' -- Attrs
    str_1 = 'baz'
    attrs_1 = Attrs(str_1)
    assert attrs_1.source == str_1
    assert attrs_1.exclude == ()
    assert attrs_

# Generated at 2022-06-24 17:27:13.669072
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    error_tracker_0 = Error()
    int_0 = 0
    int_1 = 0
    list_0 = []
    for int_0 in range(5,3,-1):
        list_0.append(int_0)
    list_0.__delitem__(2)
    keys_0 = Keys('foo')
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    bool_0 = bool(list_0)
    bool_1 = bool(int_0)
    bool_2 = bool(list_0)
    bool_3 = bool(int_0)
    bool_4 = bool(list_0)
    bool_5 = bool(int_0)
    bool_6 = bool(list_0)

# Generated at 2022-06-24 17:27:17.620365
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = utils.FrameWrapper.new_fake()
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    tuple_0 = attrs_0.items(frame_0)
    assert tuple_0 == (('bar', "'bar'"),)


# Generated at 2022-06-24 17:28:05.600076
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # The most complex case. The variable is not a simple identifier and has to
    # be wrapped by parentheses.
    source_0 = 'foo.bar[42].baz["too"]'
    exclude_0 = ()
    bv_0 = Attrs(source_0, exclude_0)
    frame_0 = None
    normalize_0 = True
    expected_0 = [('foo.bar[42].baz["too"]', 'Yes I\'m a...'),
     ('foo.bar[42].baz["too"].method', '<built-in method method of str object at 0x7...'),
     ('foo.bar[42].baz["too"].prop', 'I\'m a property'),
     ('foo.bar[42].baz["too"].x', 'Hello, world!')]

# Generated at 2022-06-24 17:28:10.572594
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    attrs_0 = Attrs(str_0)
    assert attrs_0.items(5, normalize=False) == ()
    from .utils import get_shortish_repr
    str_1 = 'bar'
    attrs_1 = Attrs(str_1)
    assert attrs_1.items(5, normalize=True) == ()


# Generated at 2022-06-24 17:28:18.474790
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    str_1 = '%s'
    str_2 = 'foo'
    str_3 = '%s'
    str_4 = 'baz'
    str_5 = '%s'
    str_6 = 'a'
    str_7 = '%s'
    str_8 = 'b'
    str_9 = '%s'
    str_10 = 'c'
    str_11 = '%s'
    dict_0 = {'bar': 'bar', 'baz': 'baz', 'foo': 'foo'}
    list_0 = ['bar', 'baz', 'foo']
    list_1 = list_0
    list_2 = list_0
    str_12 = '%s'
    str_13 = '%s'
    str

# Generated at 2022-06-24 17:28:25.270735
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    name = 'x'
    frame = mock.Mock()
    frame.f_globals = {name: 'foo'}
    frame.f_locals = {}
    source = 'x'
    exclude = set()
    obj = BaseVariable(source, exclude)
    ret_exclude = obj.items(frame)
    exclude = set(['x'])
    obj = BaseVariable(source, exclude)
    ret_not_exclude = obj.items(frame)
    assert ret_exclude == ()
    assert ret_not_exclude == (('x', 'foo'),)



# Generated at 2022-06-24 17:28:33.139551
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = 'bar'
    attrs_1 = Attrs(str_1)
    str_2 = 'bar'
    attrs_2 = Attrs(str_2)

    attrs_3 = Attrs(str_1, exclude='__dict__')
    str_4 = '__dict__'
    attrs_4 = Attrs(str_1, exclude=str_4)

# Generated at 2022-06-24 17:28:45.265540
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    class Variable(BaseVariable):
        def __init__(self, source, exclude=()):
            BaseVariable.__init__(self, source, exclude)

        def _items(self, key, normalize=False):
            return []

    def _test_items(source, exclude=(), normalize=False, frame=None, an_iterable=None):
        a_variable = Variable(source, exclude)
        return a_variable.items(frame, normalize)

    import inspect
    _, frame = inspect.stack()[0]
    a_dict = {}
    a_list = []
    a_e = Exception()
    a_str = 'bar'
    # assert (_test_items(a_str, frame=frame) == [])
    # assert (_test_items(a_str, exclude=a_dict, frame

# Generated at 2022-06-24 17:28:51.672285
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = {'a': 1, 'b': 2, 'c': 3}
    variable = Keys(d)

    nt.assert_equal(variable.items({'d': variable}), d.items())
    nt.assert_equal(variable.items({'d': variable}, normalize=True), d.items())



# Generated at 2022-06-24 17:29:00.799097
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = 'foo'
    attrs_1 = Attrs(str_1, exclude=['__dict__'])
    dict_0 = {}
    dict_1 = dict_0
    dict_1['key'] = 'value'
    dict_0 = dict_1
    str_2 = 'key'
    dict_0 = {}
    dict_1 = dict_0
    dict_1['key'] = 'value'
    dict_0 = dict_1
    str_3 = 'key'
    dict_1 = dict_0
    dict_1['key'] = 'value'
    dict_0 = dict_1
    str_4 = 'key'
    dict_0 = {}
    dict_1 = dict_0
    dict_1['key'] = {}
    dict_0 = dict_1
    str

# Generated at 2022-06-24 17:29:11.387068
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'baz'
    frame_0 = __import__('frame', globals(), locals(), [], 0)
    frame_0.f_globals = frame_0.f_locals = {'baz': None}
    frame_0.f_back = frame_0
    attributes_0 = ('baz',)
    indices_0 = ('baz',)
    keys_0 = ('baz',)
    expected_0 = ((str_0, None),)
    expected_1 = ((str_0, None), ('baz', None))
    expected_2 = ((str_0, None), ('baz[0]', None))
    expected_3 = ((str_0, None), ('baz.0', None))

# Generated at 2022-06-24 17:29:23.474087
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    normalize_0 = False

    # test case 1

# Generated at 2022-06-24 17:31:13.986217
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    from . import uutils
    from . import pycompat
    from . import utils
    from . import pycompat
    from . import uutils
    from . import utils
    from . import uutils
    from . import pycompat
    from . import utils
    from . import uutils
    from . import uutils
    attr_0 = 'foo'
    obj_0 = Keys(str_0)
    frame_0 = uutils.FakeFrame(globals={}, locals={attr_0: obj_0})
    cls_0 = Keys(str_0)
    lst_0 = [str_0, None]
    lst_1 = [str_0]



# Generated at 2022-06-24 17:31:17.940944
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    #BaseVariable.items(BaseVariable(), str_0, bool_0)
    assert True # TODO: implement your test here



# Generated at 2022-06-24 17:31:22.377733
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'bar'
    pycompat.set_exc_info(None)
    try:
        result = str_0.find('find', 80)
    except BaseException as e:
        pycompat.set_exc_info(sys.exc_info())
    expected = None
    assert result == expected
