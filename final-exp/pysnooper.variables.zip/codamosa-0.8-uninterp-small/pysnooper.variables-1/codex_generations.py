

# Generated at 2022-06-24 17:21:36.882075
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    locals_0 = {'tuple_0': ()}
    indices_0 = Indices('tuple_0')
    expected_0 = [('tuple_0', 'tuple()')]
    actual_0 = indices_0.items(locals_0)
    assert actual_0 == expected_0

    locals_1 = {'tuple_1': (1,)}
    indices_1 = Indices('tuple_1')
    expected_1 = [('tuple_1', '(1,)'), ('tuple_1[0]', '1')]
    actual_1 = indices_1.items(locals_1)
    assert actual_1 == expected_1

    locals_2 = {'tuple_2': (1, 2, 3)}
    indices_2 = Indices('tuple_2')
    expected

# Generated at 2022-06-24 17:21:40.216989
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    tuple_0 = (2, 3, 4)
    indices_0 = Indices(tuple_0)
    indices_1 = Indices(tuple_0)
    assert (indices_0 == indices_1)


# Generated at 2022-06-24 17:21:41.090955
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # TODO: Need more unit tests
    pass



# Generated at 2022-06-24 17:21:49.588843
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
  from pygments.console import terminal
  from pygments.token import Token
  from pygments.token import StandardToken
  from pygments.lexer import RegexLexer
  from pygments.formatter import Formatter
  from pygments.lexer import RegexLexer
  from pygments.lexer import bygroups
  from pygments.lexer import include
  import traceback
  import unittest
  import os
  import re
  import sys
  import locale
  import optparse
  import pygments
  import textwrap
  import tempfile
  from pygentest.util import is_main
  from pygentest.util import is_main_thread
  from pygentest.util import is_main_process
  from pygentest.util import is_generator_main
  from pygentest.util import is_gener

# Generated at 2022-06-24 17:21:59.888296
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = FrameType()
    main_value = Mapping()
    frame.f_locals = {'main_value': main_value}
    normalize = False
    source = main_value
    exclude = ()
    source = main_value
    assert not needs_parentheses(source)
    result = [source, utils.get_shortish_repr(main_value)]
    assert result == Attrs(source, exclude).items(frame, normalize)
    assert result == Keys(source, exclude).items(frame, normalize)
    assert result == Indices(source, exclude).items(frame, normalize)
    assert result == Exploding(source, exclude).items(frame, normalize)


# Generated at 2022-06-24 17:22:04.413502
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    obj_0 = object()
    obj_0 = object()
    BaseVariable(obj_0, obj_0)
    obj_0 = object()
    obj_0 = object()
    BaseVariable(obj_0, obj_0)

# Generated at 2022-06-24 17:22:07.853681
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    tuple_0 = ()
    class_0 = BaseVariable(tuple_0)
    assert not class_0.__eq__(None)
    assert not class_0.__eq__('')
    assert class_0.__eq__(class_0)



# Generated at 2022-06-24 17:22:10.926152
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    tuple_0 = ()
    indices_0 = Indices(tuple_0)
    indices_0.__getitem__(slice(0, 5, 1))
    indices_0.__getitem__(slice(10, 4, -2))

# Generated at 2022-06-24 17:22:13.487725
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bv = BaseVariable('abc')
    assert isinstance(bv, BaseVariable)


# Generated at 2022-06-24 17:22:16.859237
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    tuple_0 = ()
    indices_0 = Indices(tuple_0)
    result = indices_0[0:0:]
    assert result is not None


# Generated at 2022-06-24 17:22:30.714576
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = dict()
    dict_0['method'] = '__dict__'
    dict_0['__slots__'] = 'locals'
    dict_0['__dict__'] = '__slots__'
    dict_0['source'] = 'dict_0'
    dict_0['exclude'] = 'locals'
    dict_0['code'] = compile('dict_0', '<variable>', 'eval')
    dict_0['unambiguous_source'] = '(dict_0)'
    dict_1 = dict()
    dict_0['__dict__'] = dict_1
    dict_0['__weakref__'] = dict_1
    dict_1['x'] = 1
    dict_2 = dict()
    dict_2['__dict__'] = dict_0

# Generated at 2022-06-24 17:22:38.466517
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x_0 = '__slots__'
    x_1 = BaseVariable(x_0)
    x_2 = ('__slots__',)
    x_3 = x_1 == x_2
    x_4 = BaseVariable(x_0, x_2)
    x_5 = x_2 == x_4
    x_6 = (BaseVariable, '__slots__', ('__slots__',))
    x_7 = x_1._fingerprint == x_6


# Generated at 2022-06-24 17:22:41.869721
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_1 = '__slots__'
    indices_1 = Indices(str_1)
    result_slice = indices_1[1:2]
    
    assert isinstance(result_slice, Indices) == True


# Generated at 2022-06-24 17:22:48.879566
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'a'
    str_1 = 'b'

    # Test the first constructor of BaseVariable
    bv = BaseVariable(str_0, str_1)

    # Test the second constructor of BaseVariable
    bv = BaseVariable(str_0)

    int_0 = 0

    # Test the items method of BaseVariable
    bv.items(int_0)

    bv.items(int_0, True)

# Generated at 2022-06-24 17:22:50.556113
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable.__eq__()


# Generated at 2022-06-24 17:22:54.748350
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    indices_0[slice(1, 2)]
    indices_0[slice(0)]
    indices_0[slice(1, 8)]




# Generated at 2022-06-24 17:23:08.332001
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source_0 = '__slots__'
    source_1 = '__slots__'
    source_2 = '__slots__'
    source_3 = '__slots__'
    source_4 = '__slots__'
    source_5 = '__slots__'
    source_6 = '__slots__'
    source_7 = '__slots__'
    source_8 = '__slots__'
    source_9 = '__slots__'
    source_10 = '__slots__'
    source_11 = '__slots__'
    source_12 = '__slots__'
    source_13 = '__slots__'
    source_14 = '__slots__'
    source_15 = '__slots__'

# Generated at 2022-06-24 17:23:14.747978
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    str_1 = '__slots__'
    tuple_0 = (str_1,)
    attrs_0 = Attrs(str_1, tuple_0)
    attrs_1 = Attrs(str_1, tuple_0)
    assert attrs_0 == attrs_1
test_BaseVariable___eq__()


# Generated at 2022-06-24 17:23:26.612351
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 's'
    str_1 = 'str'
    str_2 = 'str'
    str_3 = 's'
    str_4 = 'str'
    str_5 = 'str'
    str_6 = 'str'
    str_7 = 'str'
    attrs_0 = Attrs(str_0)
    attrs_1 = Attrs(str_1, str_2)
    attrs_2 = Attrs(str_3, str_4)
    attrs_3 = Attrs(str_5, str_6)
    attrs_4 = Attrs(str_7)
    assert not attrs_0 == attrs_1
    assert attrs_2 == attrs_3
    assert not attrs_4 == str_7
    str_8 = 's'

# Generated at 2022-06-24 17:23:33.258680
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'Attrs.__init__'
    indices_0 = Indices(str_0)
    indices_0 = indices_0[slice(None, None, None)]
    

# Generated at 2022-06-24 17:23:42.416446
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = '__slots__'
    exclude = '__dict__'
    indices_0 = Indices(source)
    # ids = Indices(source)
    # assert ids == indices_0

# Generated at 2022-06-24 17:23:47.787766
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    str_1 = '__dict__'
    indices_1 = Indices(str_1)
    str_2 = '_shorten_repr_'
    str_3 = '__str__'
    str_4 = '__slots__'
    attrs_0 = Attrs(str_2, str_3, str_4)

    # MethodBaseVariable.__eq__ is not implemented
    try:
        indices_0.__eq__(indices_1)
        raise TypeError('MethodBaseVariable.__eq__ must not be implemented')
    except NotImplementedError:
        pass

    # MethodBaseVariable.__eq__ is implemented

# Generated at 2022-06-24 17:23:54.460744
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    str_1 = '__slots__'
    str_2 = '__slots__'
    str_3 = '__slots__'
    str_4 = '__slots__'
    str_5 = '__slots__'
    str_6 = '__slots__'

    attrs_0 = Attrs(str_0)
    attrs_1 = Attrs(str_1)
    attrs_2 = Attrs(str_2)

    keys_0 = Keys(str_3)
    keys_1 = Keys(str_4)
    keys_2 = Keys(str_5)

    exploding_0 = Exploding(str_6)
    exploding_1 = Exploding(str_6)

    assert attrs_0 == attrs_1

# Generated at 2022-06-24 17:23:55.803119
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    bool_0 = isinstance(BaseVariable, pycompat.ABCMeta)
    assert bool_0

# Generated at 2022-06-24 17:24:00.152939
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'z.x.y,z.x.w'
    indices_0 = Indices(str_0, str_0)
    assert indices_0.__eq__(indices_0)


# Generated at 2022-06-24 17:24:09.963456
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'spam'
    str_1 = 'func_name'
    str_2 = '__slots__'
    str_3 = 'spam'
    str_4 = '__slots__'
    # __test__ = {
    #     'test_BaseVariable_items' : r"""
    #     >>> class Spam:
    #     ...     __slots__ = ('eggs',)
    #     >>> spam = Spam()
    #     >>> spam.eggs = 11
    #     >>> spam.spam = 10
    #     >>> spam.spam
    #     10
    #     """,
    # }
    # case_0
    str_5 = "spam"
    str_6 = "spam"
    str_7 = "spam"
    # case_

# Generated at 2022-06-24 17:24:14.325906
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    basevariable_0 = Attrs(str_0)
    basevariable_1 = Attrs(str_0)
    bool_0 = basevariable_0 == basevariable_1
    assert bool_0


# Generated at 2022-06-24 17:24:19.586362
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '_rdeiwd'
    indices_0 = Indices(str_0)
    int_0 = 0
    while (int_0 < int(2)):
        class_0 = type(str())
        assert (BaseVariable.__eq__(indices_0, class_0) == False)
        int_0 += 1


# Generated at 2022-06-24 17:24:22.437300
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    indices_1 = Indices(str_0)
    assert indices_0 == indices_1



# Generated at 2022-06-24 17:24:27.275638
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a').__eq__(Attrs('a'))
    assert not Attrs('a').__eq__(Attrs('b'))
    assert not Attrs('a').__eq__(Keys('b'))


# Generated at 2022-06-24 17:24:35.609346
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    num_0 = 0
    frame_0 = frame
    attrs_0 = Attrs(num_0, frame_0)
    attrs_0.items(frame_0)

# Generated at 2022-06-24 17:24:41.724617
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
	str_0 = '__slots__'
	indices_0 = Indices(str_0)
	str_1 = '__dict__'
	attrs_0 = Attrs(str_1)
	str_2 = '(__dict__)'
	assert attrs_0.unambiguous_source == str_2, ('attrs_0.unambiguous_source should be equal to str_2')


# Generated at 2022-06-24 17:24:47.421728
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # e.g. test_case_0
    str_0 = '__slots__'
    indices_0 = Indices(str_0)



# Generated at 2022-06-24 17:24:57.227697
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # We want to do a test involving a SyntaxError, so we have to
    # execute this code dynamically.
    code = compile("def func(): x = 1; y = [1, 2]; z = {1, 2}",
                   "func", "exec")
    ns = {}
    exec(code, ns)
    locs = ns["func"].__code__.co_varnames
    frame = inspect.currentframe()

    # Test normal execution of items method
    int_0 = 0
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    indices_0.items(frame)

    # Test execution with a SyntaxError
    str_1 = '__slots__'
    indices_1 = Indices(str_1)
    indices_1.items(frame)

# Generated at 2022-06-24 17:25:06.779295
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    str_1 = '__dict__'
    attrs_0 = Attrs(str_0)
    attrs_1 = Attrs(str_1)
    for todo_0 in range(0, 2):
        for todo_1 in range(0, 2):
            keys_0 = Keys(str_0)
            keys_1 = Keys(str_1)
            indices_0 = Indices(str_0)
            indices_1 = Indices(str_1)
            str_2 = '__slots__'
            str_3 = '__dict__'
            exploding_0 = Exploding(str_2)
            exploding_1 = Exploding(str_3)
            raise Exception()

# Generated at 2022-06-24 17:25:17.117924
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # classes
    class Foo:
        bar = 5
    class Slotted:
        __slots__ = ('bar',)
        bar = 5
    # instances
    foo = Foo()
    slotted = Slotted()
    # values
    values = {
        '__dict__': {'bar': 5},
        '__slots__': ['bar'],
        '__annotations__': {'bar': int},
        '__qualname__': 'instance'
    }
    expected = list()
    # variables
    Bar = Attrs('bar')
    bar = Keys('bar')
    bar_slots = Keys('bar.__slots__')
    bar_dict = Keys('bar.__dict__')
    bar_annotation = Keys('bar.__annotations__')

# Generated at 2022-06-24 17:25:25.784286
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .tests import test_debugger
    import inspect
    import unittest
    import tempfile

    def load_tests(loader, tests, ignore):

        class BaseVariableTestCase(unittest.TestCase):
            def test_BaseVariable_items(self):
                # Issues 172 and 175
                test_cases = [
                    (
                        '__doc__',
                        '__doc__'
                    ),
                    (
                        '__slots__',
                        '__slots__'
                    )
                ]
                for test_case in test_cases:

                    # Call method items of class BaseVariable on test_case
                    BaseVariable(source=test_case[0]).items(inspect.currentframe())

        return tests


# Generated at 2022-06-24 17:25:36.095730
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:25:48.488599
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'c'
    str_1 = 'a'
    str_2 = 'd'
    str_3 = 'b'

    indices_0 = Indices(str_2)
    keys_0 = Keys(str_1)
    attrs_0 = Attrs(str_0)
    frame_0 = None
    py_0 = (
        (str_0, '3'),
        (str_0 + '.' + str_1, '2'),
        (str_0 + '.' + str_2, '4')
    )
    list_0 = [
        str_1,
        str_2,
        str_3
    ]
    list_1 = [
        str_1,
        str_2,
        str_3
    ]

# Generated at 2022-06-24 17:25:56.346084
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    str_1 = '__dict__'
    indices_1 = Indices(str_1)
    str_2 = '__dict__'
    str_3 = '__slots__'
    keys_0 = Keys(str_2, str_3)


# Generated at 2022-06-24 17:26:10.238833
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = '__slots__'
    exclude = ()
    BaseVariable_0 = BaseVariable(source, exclude)
    frame_0 = {'__slots__': '__slots__'}
    assert BaseVariable_0.items(frame_0) == ()


# Generated at 2022-06-24 17:26:12.376054
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    items_0 = BaseVariable('_')
    str_1 = 'BaseVariable'
    items_0.__class__ = str_1


# Generated at 2022-06-24 17:26:21.707028
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    list_0 = [1, 2, 3]
    assert indices_0.items(list_0) == (
        ('[0]', '1'),
        ('[1]', '2'),
        ('[2]', '3'),
    )
    assert indices_0.items(list_0, normalize=True) == (
        ('[0]', '1'),
        ('[1]', '2'),
        ('[2]', '3'),
    )



# Generated at 2022-06-24 17:26:29.151954
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    BaseVariable.items(self : BaseVariable, frame, normalize=False) -> (str, repr) tuple
    '''
    stack = utils.get_current_stack()
    frame = stack[3]

    # Expected output for parameters
    '''
    frame : frame
        The frame of the call stack
    '''

    # Unit test for method items of class Attrs
    attrs_list = ['__slots__']
    for var_name in attrs_list:
        attrs_0 = Attrs(var_name)
        attrs_1 = attrs_0.items(frame)
        assert(len(attrs_1) == 2)
        frame_locals = frame.f_locals
        assert (attrs_1[0][0] == '__slots__')
       

# Generated at 2022-06-24 17:26:32.738605
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    with pytest.raises(NotImplementedError):
        indices_0.items(None, None)


# Generated at 2022-06-24 17:26:34.446479
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert True


# Generated at 2022-06-24 17:26:44.780503
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    pycompat.import_(module_name=pycompat.string_types()[-1])('test_BaseVariable_items')
    pycompat.import_(module_name=pycompat.string_types()[-1])('test_BaseVariable_items')
    pycompat.import_(module_name=pycompat.string_types()[-1])('test_BaseVariable_items')
    pycompat.import_(module_name=pycompat.string_types()[-1])('test_BaseVariable_items')
    pycompat.import_(module_name=pycompat.string_types()[-1])('test_BaseVariable_items')

# Generated at 2022-06-24 17:26:48.824483
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    commonvariable_0 = CommonVariable('str_0')
    str_0 = 'd'
    assert commonvariable_0.items(frame_0, str_0) == ()


# Generated at 2022-06-24 17:26:58.731091
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    indices_1 = Indices(str_0)
    indices_2 = Indices(str_0)
    indices_3 = Indices(str_0)
    indices_4 = Indices(str_0)
    indices_5 = Indices(str_0)
    indices_6 = Indices(str_0)
    indices_7 = Indices(str_0)
    indices_8 = Indices(str_0)
    indices_9 = Indices(str_0)
    indices_10 = Indices(str_0)
    indices_11 = Indices(str_0)
    indices_12 = Indices(str_0)
    indices_13 = Indices(str_0)

# Generated at 2022-06-24 17:27:07.295775
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for method _items of class CommonVariable
    _var = Attrs('a')
    assert _var._items(None) == [('a', 'None')]
    assert _var._items('') == [('a', "''")]
    assert _var._items('a') == [('a', "'a'")]
    assert _var._items(123) == [('a', '123')]
    assert _var._items(123.45) == [('a', '123.45')]
    assert _var._items(123.45j) == [('a', '123.45j')]
    assert _var._items(True) == [('a', 'True')]
    assert _var._items(_var) == [('a', 'Attrs(_var)')]

    _var = Keys('a')
   

# Generated at 2022-06-24 17:27:19.898392
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = Frame(None, None, None, None)
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    list_0 = indices_0.items(frame_0, True)


# Generated at 2022-06-24 17:27:23.204234
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = '__slots__'
    assert BaseVariable(main_value).items is BaseVariable.items


# Generated at 2022-06-24 17:27:30.425340
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = '__slots__'
    indices_1 = Indices(str_1)
    frame = inspect.currentframe()
    ret_val_0 = indices_1.items(frame)
    str_2 = '__slots__'
    indices_2 = Indices(str_2)
    frame = inspect.currentframe()
    ret_val_1 = indices_2.items(frame)


# Generated at 2022-06-24 17:27:35.069598
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'attrs'
    str_1 = '_'
    #
    attrs_0 = Attrs(str_0)
    #
    assert attrs_0.items(str_0) == ''


# Generated at 2022-06-24 17:27:45.485083
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    baseVariable_0 = Attrs(str_0)
    dict_0 = dict()

    class Class_0:

        def test_0():
            pass

        def test_1():
            pass

    class_0 = Class_0()
    test_0 = class_0.test_0
    test_0.func_name = 'func_name'
    class_0.__slots__ = ['new_slot']
    dict_0['__slots__'] = '__slots__'
    dict_0['func_name'] = 'func_name'
    dict_0['new_slot'] = 'new_slot'
    frame_0 = test_0.func_code.co_firstlineno
    result = baseVariable_0.items(frame_0)


# Generated at 2022-06-24 17:27:53.167189
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '--parms'
    str_1 = '--rulers'
    int_0 = -86
    str_2 = '--kings'
    str_3 = '--partitioners'
    str_4 = '--y'
    str_5 = '--thresholds'
    str_6 = '--inits'
    str_7 = '--industries'
    str_8 = '--pops'
    str_9 = '--features'
    str_10 = '--borders'
    str_11 = '--trends'
    str_12 = '--lens'
    str_13 = '--cents'
    str_14 = '--scanpars'
    str_15 = '--roots'
    str_16 = '--mores'
    bool

# Generated at 2022-06-24 17:27:58.167745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert all(
        BaseVariable.items(BaseVariable()) ==
        BaseVariable.items(BaseVariable())
    )
    assert all(
        BaseVariable.items(BaseVariable()) ==
        BaseVariable.items(BaseVariable())
    )
    assert all(
        BaseVariable.items(BaseVariable()) ==
        BaseVariable.items(BaseVariable())
    )


# Generated at 2022-06-24 17:28:09.325195
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'lib'
    str_1 = 'send_access'
    str_2 = 'time'
    str_3 = 'script_path_list'
    keys_0 = Keys(str_3)
    # AssertionError('Argument of type str not valid for this method.')
    try:
        keys_0.items(str_0)
    except AssertionError:
        pass
    # AssertionError()
    try:
        keys_0.items()
    except AssertionError:
        pass
    str_4 = 'result'
    str_5 = 'stack'
    str_6 = 'the_stack'
    str_7 = 'result'
    str_8 = 'stack'
    str_9 = 'the_stack'
    str_10 = 'result'


# Generated at 2022-06-24 17:28:13.501022
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = "__slots__"
    indices_0 = Indices(str_0)
    tuple_0 = ()
    frame_0 = ()
    iterable_0 = indices_0.items(frame_0)
    pycompat.assert_equal(tuple(iterable_0), tuple_0)



# Generated at 2022-06-24 17:28:24.493197
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('Running test')
    # Argument types
    str_0 = '__slots__'
    py_0 = Attrs(str_0)
    utils.repr_test(py_0, normalize=True)
    str_1 = '__repr__'
    py_1 = Keys(str_1)
    utils.repr_test(py_1, normalize=True)
    str_2 = '__iter__'
    py_2 = Attrs(str_2)
    utils.repr_test(py_2, normalize=True)
    str_3 = '__getitem__'
    py_3 = Attrs(str_3)
    utils.repr_test(py_3, normalize=True)
    str_4 = '__bool__'
    py

# Generated at 2022-06-24 17:28:53.120547
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Variable 'result_1'
    str_0 = 'x_0'
    str_1 = 'x_1'
    str_2 = 'x_2'
    str_3 = 'x_3'
    str_4 = 'x_4'
    frame_0 = str_0
    
    # Call method items of class BaseVariable
    result_1 = Indices(a)[1:3]


# Generated at 2022-06-24 17:29:02.025830
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    str_1 = '__slots__'
    attrs_0 = Attrs(str_1)
    str_2 = '__slots__'
    keys_0 = Keys(str_2)
    str_3 = '__slots__'
    exploding_0 = Exploding(str_3)
    str_4 = '__slots__'
    base_variable_0 = BaseVariable(str_4)
    str_5 = '__slots__'
    base_variable_1 = BaseVariable(str_5)

    # Base variable items method invoked on Indices variable

# Generated at 2022-06-24 17:29:12.044455
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test each method of the class
    # Create instances and test that the correct number of values are returned
    str_0 = '__slots__'
    attrs_0 = Attrs(str_0)
    indices_0 = Indices(str_0)
    exploding_0 = Exploding(str_0)
    keys_0 = Keys(str_0)

    # Make sure the correct class is instantiated
    isinstance(attrs_0, BaseVariable)
    isinstance(indices_0, BaseVariable)
    isinstance(exploding_0, BaseVariable)
    isinstance(keys_0, BaseVariable)

    # This will raise an exception
    Attrs.items(attrs_0)
    Indices.items(indices_0)
    Exploding.items(exploding_0)

# Generated at 2022-06-24 17:29:24.342451
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    str_1 = '__slots__'
    indices_1 = Indices(str_1)
    str_2 = '__slots__'
    indices_2 = Indices(str_2)

    # test_items_0 of class BaseVariable
    indices_0.code = compile(str_0, '<variable>', 'eval')
    indices_0.exclude = ()
    indices_0.source = str_0

    # test_items_1 of class BaseVariable
    indices_1.code = compile(str_1, '<variable>', 'eval')
    indices_1.exclude = ()
    indices_1.source = str_1

    # test_items_2 of class BaseVariable
    indices

# Generated at 2022-06-24 17:29:31.170703
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    from .context import Context

    # Case 0
    frame = Context.caller_frame()
    assert frame.f_lasti == test_BaseVariable_items.__code__.co_firstlineno + 1
    assert frame.f_code.co_filename == __file__
    assert frame.f_lineno == test_case_0.__code__.co_firstlineno + 1

    result = Indices('__slots__').items(frame)
    # <No assertion>

# Generated at 2022-06-24 17:29:40.564714
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test function for code execution at the beginning of method items of class BaseVariable
    def _code_0():
        attrs_0 = Attrs('foo.bar')
        keys_0 = Keys('foo.bar')
        indices_0 = Indices('foo.bar')
        exploding_0 = Exploding('foo.bar')
        assert set(attrs_0.items({})) == set()
        assert set(keys_0.items({})) == set()
        assert set(indices_0.items({})) == set()
        assert set(exploding_0.items({})) == set()
    # Test function for code execution at the end of method items of class BaseVariable
    def _code_1():
        attrs_0 = Attrs('foo.bar')
        attrs_1 = Attrs('foo.bar')


# Generated at 2022-06-24 17:29:52.546252
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame0 = FrameType(
        code_object=None,
        traceback=None,
        lasti=-1,
        lineno=1,
        f_locals={'__slots__': [1, 2, 3]},
        f_globals={},
        f_code=None,
        f_back=None,
        f_trace=None,
        f_exc_type=None,
        f_exc_value=None,
        f_exc_traceback=None,
        f_restricted=False)

# Generated at 2022-06-24 17:29:57.429494
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__slots__'
    int_0 = 0
    dict_0 = dict()
    dict_1 = dict()
    dict_1['__str__'] = int_0
    str_1 = '__str__'
    dict_0[str_1] = dict_1
    dict_1 = dict()
    dict_1['__slots__'] = dict_0
    dict_0 = dict()
    dict_0['__slots__'] = dict_1
    frame_0 = dict_0
    str_2 = '__class__'
    dict_1 = dict()
    dict_1['__class__'] = frame_0
    dict_0 = dict()
    dict_0['__class__'] = dict_1
    dict_2 = dict()

# Generated at 2022-06-24 17:30:00.399429
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    lst_0 = []
    lst_0.append(('<string>', "''"))
    str_0 = ''
    var_0 = BaseVariable(str_0)
    assert var_0.items(var_0, True) == lst_0

# Generated at 2022-06-24 17:30:07.473574
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 0
    str_0 = '__slots__'
    indices_0 = Indices(str_0)
    assert len(indices_0.items(1)) == 0
    indices_0 = Indices(str_0)
    indices_0._slice = slice(1)
    assert indices_0[int_0: -1].items(1) == []
    str_1 = '_fingerprint'
    assert len(CommonVariable(str_1).items(1)) == 0
    assert len(CommonVariable(str_1).items(1, normalize=True)) == 0
    assert len(Attrs(str_1).items(1)) == 0
    assert len(Attrs(str_1).items(1, normalize=True)) == 0

# Generated at 2022-06-24 17:31:10.211505
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'client'
    str_1 = 'rpc_service'
    str_2 = 'localVariable'
    str_3 = 'pi'
    str_4 = 'methods'
    str_5 = 'path'
    str_6 = 'home'
    str_7 = 'i'
    str_8 = 'remoteVariable'
    str_9 = '__slots__'

    class MainClass(object):
        def __init__(self):
            self.localVariable = __main__.LocalClassA()
            self.remoteVariable = __main__.RemoteClassB()
            self.home = '/'
            self.i = 1

        def __dir__(self):
            return ['localVariable', 'remoteVariable', 'home', 'i']


# Generated at 2022-06-24 17:31:13.455382
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '```'
    indices_0 = Indices(str_0)
    int_0 = indices_0.items(globals(), True)
    test_BaseVariable_items_result = int_0
    return int_0


# Generated at 2022-06-24 17:31:24.501506
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Test(object):
        def __init__(self, attributes):
            self.attributes = attributes
        def __getattribute__(self, key):
            return self.attributes[key]
    var = Test({'hello': 1, 'world': Test({'hi': 2, 'there': 3, 'exclude': 4})})
    assert set(Attrs('').items(var)) == set(Attrs('var').items(var))
    assert set(Attrs('var').items(var)) == set(Keys('var').items(var)) == set(Indices('var').items(var)) == set(Exploding('var').items(var))