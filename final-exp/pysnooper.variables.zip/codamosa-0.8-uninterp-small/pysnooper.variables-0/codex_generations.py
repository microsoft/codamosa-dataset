

# Generated at 2022-06-24 17:21:34.565489
# Unit test for constructor of class Indices
def test_Indices():
    """Test that Indices works with the correct value of _slice"""
    Indices('x')
    Indices('x', exclude='y')
    Indices('x', [1, 2])
    Indices('x', tuple('y'))
    Indices('x')[:]
    Indices('x')[0:10]
    Indices('x')[0:10:2]

# Generated at 2022-06-24 17:21:42.277125
# Unit test for constructor of class Exploding
def test_Exploding():

    # Call Exploding(source)
    var_0 = Exploding('main_value')

    # Call Exploding(source, exclude)
    var_1 = Exploding('main_value', ())

    # Call Exploding(source)
    var_2 = Exploding('main_value')

    # Call Exploding(source, exclude)
    var_3 = Exploding('main_value', ())

    # Call Exploding(source)
    var_4 = Exploding('main_value')

    # Call Exploding(source, exclude)
    var_5 = Exploding('main_value', ())



# Generated at 2022-06-24 17:21:44.630053
# Unit test for constructor of class Indices
def test_Indices():
    t_0 = Indices('super_list')
    t_1 = Keys('super_list')
    t_2 = Attrs('super_list')


# Generated at 2022-06-24 17:21:49.536007
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    variable_0 = BaseVariable(frame_0)
    variable_0.items(frame_0)

# Generated at 2022-06-24 17:21:53.330765
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = "source"
    exclude = ("exclude",)
    obj = BaseVariable(source, exclude)
    obj1 = BaseVariable(source, exclude)
    assert obj == obj1


# Generated at 2022-06-24 17:21:58.617879
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices()
    indices__getitem__0 = indices.__getitem__(slice(None,None,None))
    indices__getitem__1 = indices.__getitem__(slice(0,None,None))
    indices__getitem__2 = indices.__getitem__(slice(None,None,2))


# Generated at 2022-06-24 17:22:07.544591
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    dict_0 = {}
    obj_0 = {}
    int_0 = 1
    str_0 = 's'
    bool_0 = True
    # Test for positive case and boundary case
    list_val_0 = Indices('list_0').items(list_0)
    dict_val_0 = Keys('dict_0').items(dict_0)
    obj_val_0 = Attrs('obj_0').items(obj_0)
    int_val_0 = BaseVariable('int_0').items(int_0)
    str_val_0 = BaseVariable('str_0').items(str_0)
    bool_val_0 = BaseVariable('bool_0').items(bool_0)
    # Test for negative case and boundary case

# Generated at 2022-06-24 17:22:08.470434
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    pass



# Generated at 2022-06-24 17:22:14.450318
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = CommonVariable()
    var_1 = CommonVariable()
    # assert var_0.items() == var_1.items()

    var_3 = Keys()
    # assert var_3.items(1) == var_1.items(0)

    var_4 = Keys()
    var_4_0 = var_4.items(1)
    for var_4_0_0 in var_4_0:
        # assert var_4_0_0 != var_1.items(1)
        pass

    # assert var_0.items() == var_1.items()

    # assert var_0.items() == (tuple(var_1.items()) + tuple(var_1.items()))

    var_8 = Keys()
    # assert var_8.items(1) == var_1

# Generated at 2022-06-24 17:22:18.852621
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    # given
    list_0 = []
    # when
    var_1 = BaseVariable(list_0, )
    # then
    assert var_1.source is list_0

# Generated at 2022-06-24 17:22:28.748601
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_1 = []
    var_1 = BaseVariable(list_1)
    list_2 = []
    var_2 = BaseVariable(list_2)
    assert var_1 == var_2


# Generated at 2022-06-24 17:22:39.390317
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1', 'key_2': 100,
            'key_3': 'value_3', 'key_4': 100, 'key_5': 'value_5', 'key_6':
            'value_6', 'key_7': 100, 'key_8': 'value_8', 'key_9': 100, 
            'key_10': 'value_10', 'key_11': 100, 'key_12': 'value_12',
            'key_13': 'value_13', 'key_14': 100, 'key_15': 'value_15',
            'key_16': 100, 'key_17': 'value_17', 'key_18': 100, 'key_19':
            'value_19'} # expected:

# Generated at 2022-06-24 17:22:42.740407
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    list_0 = [1, 2, 3]
    var_0 = Indices(list_0)
    var_1 = var_0[1:2]
    with pytest.raises(AssertionError):
        var_2 = var_0[1, 2]


# Generated at 2022-06-24 17:22:55.988412
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None, None) == BaseVariable(None, None)
    assert BaseVariable('a', None) == BaseVariable('a', None)
    assert BaseVariable(None, 'c') == BaseVariable(None, 'c')
    assert BaseVariable('e', 'g') == BaseVariable('e', 'g')
    assert BaseVariable(None, None) != BaseVariable(None, 'g')
    assert BaseVariable('e', None) != BaseVariable('f', None)
    assert BaseVariable(None, 'c') != BaseVariable('f', 'g')
    assert BaseVariable('e', 'g') != BaseVariable('e', 'g')


# Generated at 2022-06-24 17:22:57.163966
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices_0 = Indices('', ())
    Indices_0 = Indices_0[:]


# Generated at 2022-06-24 17:23:09.101004
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('Testing __eq__')
    list_0 = []
    var_0 = Attrs('list_0')
    var_1 = Attrs('list_0')
    assert_equal(var_0, var_1)
    list_1 = []
    var_2 = Attrs('list_1')
    assert_not_equal(var_0, var_2)
    var_3 = Attrs('list_0', 'list_1')
    assert_not_equal(var_0, var_3)
    class_0 = Attrs
    var_0 = class_0('list_0')
    assert_not_equal(var_0, var_1)
    var_4 = class_0('list_0', 'list_1')
    assert_not_equal(var_3, var_4)


# Generated at 2022-06-24 17:23:12.178960
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind_0 = Indices(None, None)
    temp_0 = ind_0[1:2]

    pass



# Generated at 2022-06-24 17:23:21.689894
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('a')
    var_1 = BaseVariable('b')
    var_2 = BaseVariable('a')
    var_3 = BaseVariable('a')
    var_4 = BaseVariable('b')
    var_5 = BaseVariable('a', exclude=('a',))
    var_6 = BaseVariable('a', exclude=('b',))
    var_7 = BaseVariable('a', exclude=('a',))
    var_8 = BaseVariable('a', exclude=('b',))
    var_9 = Attrs('a')
    var_10 = Attrs('b')
    var_11 = Attrs('a')
    var_12 = Attrs('a')
    var_13 = Attrs('b')
    var_14 = Keys('a')
    var_15 = Keys('b')
   

# Generated at 2022-06-24 17:23:23.141856
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert True


# Generated at 2022-06-24 17:23:30.740335
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_0 = [1, 2, 3]
    class_0 = Attrs(list_0)
    class_1 = Attrs(list_0)
    assert class_0 == class_1
    import random
    list_1 = random.sample(range(10**6), 10**6)
    class_2 = Attrs(list_1)
    class_3 = Attrs(list_1)
    assert class_2 == class_3
    list_3 = random.sample(range(10**6), 10**6)
    class_4 = Attrs(list_3)
    class_5 = Attrs(list_3)
    assert class_4 == class_5
    list_4 = random.sample(range(10**6), 10**6)
    class_6 = Attrs(list_4)
   

# Generated at 2022-06-24 17:23:43.988122
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    list_0 = []
    indices_0 = Indices(list_0)
    indices_0 = indices_0[slice(None)]


# Generated at 2022-06-24 17:23:48.941590
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable()
    var_1 = BaseVariable()
    assert (var_0 == var_1)


# Generated at 2022-06-24 17:23:52.248455
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'x'
    exclude = 'key'
    var = BaseVariable(source, exclude)
    other = BaseVariable(source, exclude)
    assert var == other


# Generated at 2022-06-24 17:23:55.699066
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var_1 = Indices("source", "exclude")
    var_2 = slice(None)
    var_1[var_2]

# Generated at 2022-06-24 17:24:02.415307
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from copy import deepcopy
    from .variables import BaseVariable

    var_0 = BaseVariable("")

    eq_1 = (var_0 == var_0)
    eq_2 = (var_0 == var_0)
    eq_3 = (var_0 == 1)

    assert eq_1 == eq_2, 'AssertionError'

    assert eq_1 != eq_3, 'AssertionError'


# Generated at 2022-06-24 17:24:09.376927
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    list_0 = [5, 1, 8, 6, 8, 5, 0, 4, 8, 4, 6, 1]
    list_1 = [5, 1, 8, 6, 8, 5, 0, 4, 8, 4, 6, 1]
    list_2 = [5, 1, 8, 6, 8, 5, 0, 4, 8, 4, 6, 1]
    list_3 = [5, 1, 8, 6, 8, 5, 0, 4, 8, 4, 6, 1]
    var_0 = test_case_0()
    var_1 = Indices(list_0)
    var_2 = slice(1, 4, 1)
    var_3 = var_1[var_2]
    var_4 = Indices(list_1)

# Generated at 2022-06-24 17:24:12.210749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Attributes with default values
    list_0 = [1, 2, 3]
    var_1 = Indices('x', exclude='').items(list_0)


# Generated at 2022-06-24 17:24:16.020425
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    cvar_0 = CommonVariable("cust_rsl", ())
    bvar_0 = BaseVariable("cust_rsl", ())
    var_0 = bvar_0 == cvar_0


# Generated at 2022-06-24 17:24:22.036127
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('\nTest #2, method BaseVariable.__eq__')
    var_0 = BaseVariable('list_0')
    var_1 = BaseVariable('list_0')
    var_2 = BaseVariable('list_1')
    print(var_0 == var_0)
    print(var_0 == var_1)
    print(var_0 == var_2)


# Generated at 2022-06-24 17:24:28.496922
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Case 0
    a = Indices('test_0')
    a.__getitem__(slice(None))

    # Case 1
    a = Indices('test_1')
    a.__getitem__(slice(0, None, 1))

    # Case 2
    a = Indices('test_1')
    a.__getitem__(slice(0))
    # Case 3
    a = Indices('test_1')
    a.__getitem__(slice(0, 1))
    # Case 4
    a = Indices('test_1')
    a.__getitem__(slice(0, 2, 1))
    # Case 5
    a = Indices('test_1')
    a.__getitem__(slice(1, 2, 1))

# Generated at 2022-06-24 17:24:47.028595
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    var_0 = sys.modules
    var_1 = var_0.keys()
    var_2 = var_1
    for var_3 in var_2:
        try:
            if var_3 in exclude:
                continue
            try:
                if var_3 in exclude:
                    continue
            except Exception as var_4:
                continue
        except Exception as var_5:
            break
    var_6 = var_0['__builtin__']
    var_7 = var_6.__import__
    var_8 = var_7('os')
    var_9 = var_8.path
    var_10 = var_9.dirname
    var_11 = var_10(__file__)
    var_12 = var_9.join

# Generated at 2022-06-24 17:24:52.132040
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v_1 = BaseVariable('x', exclude='x')
    assert v_1 == BaseVariable('x', exclude='x')

    assert v_1 != BaseVariable('y', exclude='y')
    assert v_1 != BaseVariable('x', exclude='y')
    assert v_1 != BaseVariable('x', exclude='x', excludes='x')


# Generated at 2022-06-24 17:24:59.731817
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    var_0 = Keys('a', exclude=())
    var_1 = var_0.items(frame)
    assert var_1 == (('a', '[]'),)
    var_1 = Keys('a', exclude=['b']).items(frame)
    assert var_1 == (('a', '[]'),)
    var_1 = Keys('a', exclude=['b']).items(frame)
    assert var_1 == (('a', '[]'),)
    var_1 = Keys('a', exclude=['b']).items(frame)
    assert var_1 == (('a', '[]'),)
    var_1 = Keys('a', exclude=['b']).items(frame)
    assert var_1 == (('a', '[]'),)

# Generated at 2022-06-24 17:25:01.092447
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert utils.test_items(BaseVariable('var_0'), 'var_0')


# Generated at 2022-06-24 17:25:13.875611
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame = {}
    test_normalize = True
    test_frame = {'var_0': [[[]]],'var_1': {'test': 'test'},'var_2': ['test']}
    test_normalize = True
    # Object type conversion test case for class BaseVariable
    var_0 = BaseVariable(test_frame, test_normalize)
    assert isinstance(var_0, BaseVariable)
    # Attribute type test case for class BaseVariable
    assert isinstance(var_0.source, list)
    assert isinstance(var_0.exclude, tuple)
    # Boundary value analysis test case for method items of class BaseVariable

# Generated at 2022-06-24 17:25:24.744408
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import mock
    list_0 = []
    tuple_0 = (1,)
    tuple_1 = (tuple_0, 2)
    set_0 = {1, 2, 3, 4}
    dict_0 = {}
    dict_1 = {1: 1, 2: 2}
    dict_2 = {1: 1, 2: 2, 3: 3, 4: 4}
    obj_0 = mock.AttrsMock(a=1)
    class_0 = mock.ClassMock()
    class_1 = mock.ClassMock(a=1)
    class_2 = mock.ClassMock(a=1, b=2)
    assert BaseVariable(list_0).items(list_0) == ()
    assert BaseVariable(tuple_0).items(tuple_0) == ()


# Generated at 2022-06-24 17:25:30.173533
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_0 = []
    var_0 = Attrs('list_0', list_0)
    assert var_0 == var_0
    # not equal
    list_1 = []
    var_1 = Attrs('list_1', list_1)
    assert var_0 != var_1


# Generated at 2022-06-24 17:25:38.018206
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('') == BaseVariable('')
    assert BaseVariable('', '') == BaseVariable('', '')
    assert BaseVariable('', []) == BaseVariable('', [])
    assert BaseVariable('') != BaseVariable('', '')
    assert BaseVariable('', '') != BaseVariable('')
    assert BaseVariable('', '') != BaseVariable('', [])
    assert BaseVariable('', '') != BaseVariable([], '')
    assert BaseVariable('', '') != BaseVariable('', '')
    assert BaseVariable('', '') != BaseVariable('', '')
    assert BaseVariable('', '') != BaseVariable('', '')
    assert BaseVariable('') != BaseVariable('', '')
    assert BaseVariable('', '') != BaseVariable('')

# Generated at 2022-06-24 17:25:49.683818
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_0 = [1, 2, 3]
    list_1 = [1, 2, 3]
    list_2 = [2, 3, 4]
    dict_0 = {1:1, 2:2, 3:3}
    dict_1 = {1:1, 2:2, 3:3}
    dict_2 = {2:2, 3:3, 4:4}
    dict_3 = {2:2, 3:3, 4:4}
    attrs_0 = Attrs(list_0)
    attrs_1 = Attrs(list_0)
    attrs_2 = Attrs(list_0)
    attrs_3 = Attrs(list_0)
    attrs_4 = Attrs(list_0)
    attrs_5 = Attrs(list_0)


# Generated at 2022-06-24 17:25:52.071063
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    t_1 = BaseVariable('1')
    t_2 = BaseVariable('2')
    t_3 = BaseVariable('1')
    assert (not t_1 == t_2)
    assert t_1 == t_3


# Generated at 2022-06-24 17:26:20.636966
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import types
    stack = inspect.stack()
    frame = stack[0].frame
    locals_ = frame.f_locals
    var_0 = Attrs('list_0')
    var_1 = Attrs('locals_')
    var_1 = Attrs('type')
    var_1 = Keys('locals_')
    var_2 = Indices('types.ListType')
    var_2 = Attrs('type')


# Generated at 2022-06-24 17:26:28.562929
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('', ())
    var_1 = BaseVariable('', ())
    var_2 = BaseVariable('', (1, ))
    var_3 = BaseVariable('', (1, ))
    var_4 = BaseVariable('', (1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
    var_5 = BaseVariable('', (1, 2, 3, 4, 5, 6, 7, 8, 9, 10))
    var_6 = BaseVariable('', (1, 2, 3, 4, 5, 6, 7, 8, 9, ))
    var_7 = BaseVariable('', (1, 2, 3, 4, 5, 6, 7, 8, 9, ))
    var_8 = BaseVariable('', (1, ))
    var_9 = BaseVariable('', (1, ))

# Generated at 2022-06-24 17:26:32.883890
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_0 = []
    dict_0 = {}
    dict_0['test'] = 'test'
    BaseVariable_0 = BaseVariable(dict_0, dict_0)
    BaseVariable_1 = BaseVariable(dict_0, dict_0)
    assert BaseVariable_0 == BaseVariable_1


# Generated at 2022-06-24 17:26:35.028135
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_1 = []
    var_1 = needs_parentheses(list_1)
    list_1.append(var_1)


# Generated at 2022-06-24 17:26:37.982460
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    list_0 = ['foo']
    assert not (Attrs('list_0') == Attrs('list_0'))
    assert Attrs('list_0') == Attrs('list_0')


# Generated at 2022-06-24 17:26:40.342618
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('', '')
    assert var_0.__eq__(var_0)


# Generated at 2022-06-24 17:26:43.550123
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    list_1 = list()
    assert BaseVariable(list_0, list_1).items() == ()



# Generated at 2022-06-24 17:26:46.913195
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = ''
    expected = True
    actual = BaseVariable(str_0).__eq__(BaseVariable(str_0))
    assert actual == expected


# Generated at 2022-06-24 17:26:51.646305
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = {'a': {'c': 5, 'b': 6}}
    variable = Attrs('dict_0', ['a'])
    assert variable.items(sys._getframe()) == [('dict_0', '{}'), ('dict_0.a', '{...}')]


# Generated at 2022-06-24 17:26:52.689604
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Attrs('a').items(None)

# Generated at 2022-06-24 17:27:17.956635
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():  # noqa
    # input arguments for the method BaseVariable.items
    frame_0 = None
    normalize_0 = True

    # No exception should be raised
    BaseVariable.items(frame_0, normalize_0)



# Generated at 2022-06-24 17:27:20.629054
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('{}', {})
    assert var_0.items(__frame__) == ()
#Unit test for method items of class Attrs


# Generated at 2022-06-24 17:27:32.260022
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .._patched_tests import patch
    from .._patched_tests.six import PY2

    with patch('inspect.currentframe') as currentframe:
        currentframe.return_value = None
        assert BaseVariable('foo', exclude=('x', 'y')).items() == ()

    if PY2:
        code_lines = ["def bar():",
                      "    a = 1",
                      "    b = 2",
                      "    c = 3",
                      "    z = 5",
                      "    return a + b + c"]
    else:
        code_lines = ["def bar():",
                      "    a = 1",
                      "    b = 2",
                      "    c = 3",
                      "    z = 5"]
    code = "\n".join(code_lines)

# Generated at 2022-06-24 17:27:42.916920
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    str_0 = '[]'
    tuple_0 = (list_0, )
    dict_0 = {'-': list_0, '+': str_0}
    tuple_1 = (dict_0, )
    dict_1 = {'[]': list_0, '{}': dict_0}
    dict_2 = {dict_1: list_0, '{}': str_0}
    tuple_2 = (dict_2, )
    dict_3 = {'[]': list_0, dict_1: dict_0}
    dict_4 = {'[]': list_0, dict_2: dict_1}
    tuple_3 = (dict_4, )

# Generated at 2022-06-24 17:27:50.163806
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = {'a': 2}
    frame_0 = inspect.currentframe()
    var_0 = BaseVariable('dict_0', ())
    var_1 = var_0.items(frame_0, )
    assert var_1 == (('dict_0', '{...}'), ('dict_0[\'a\']', '2'))


# Generated at 2022-06-24 17:27:52.556073
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    var_0 = BaseVariable(list_0)
    var_1 = list_0
    var_1 = var_0.items(var_1)


# Generated at 2022-06-24 17:27:56.939830
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = {'arg': [], 'f_locals': {'arg': []}, 'f_globals': {'arg': []}}
    var_0 = BaseVariable('arg')
    var_1 = var_0.items(frame_0)


# Generated at 2022-06-24 17:28:01.455476
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    stack = inspect.stack()
    with mock.patch.object(inspect, 'stack', return_value=stack):
        var_0 = Indices('variable_0_name')
        assert var_0.items(stack[0][0]) == [('variable_0_name[0]', '[]')]


# Generated at 2022-06-24 17:28:05.453968
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = '2+2'
    exclude = ()
    frame = {}
    normalize = False
    BaseVariable_0 = BaseVariable(source, exclude)
    BaseVariable_0.items(frame, normalize)


# Generated at 2022-06-24 17:28:14.541616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    _source = '_source'
    _exclude = '_exclude'
    _frame = '_frame'
    _normalize = '_normalize'
    _expected_result = '_expected_result'
    _returned_result = '_returned_result'

    # 1. Assign values to local variables
    var_0 = Variable(_source, _exclude)
    var_1 = _expected_result
    var_2 = var_0.items(_frame, _normalize)

    # 2. Assert
    # 2.1. Assert that the return value equals the expected result
    assert var_1 == var_2
    # 2.2. Assert that the return type of the function is correct
    assert isinstance(var_2, type(_expected_result))


# Generated at 2022-06-24 17:29:10.178613
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = [1]
    dict_0 = {1: 1, 2: 2}

    var_0 = Indices('var_0')
    var_0.items(list_0)
    assert len(var_0.items(list_0)) == 1

    var_1 = Keys('var_1')
    var_1.items(dict_0)
    assert dict_0 == dict_0

    var_2 = Attrs('var_2')
    var_2.items(dict_0)
    assert dict_0 == dict_0

    var_3 = Exploding('var_3')
    var_3.items(dict_0)
    assert dict_0 == dict_0


test_BaseVariable_items()

# Generated at 2022-06-24 17:29:20.785405
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''Test adding an item to a list'''
    # Create a list with 2 items
    BaseVariable1 = BaseVariable()
    BaseVariable1.source = 'var_x'
    BaseVariable1.exclude = '_x'
    frame_0 = {'var_x': {'x': 1, 'y': 2, '_x': 3}, 'var_y': 4}

    # Try to add an item
    result_items = BaseVariable1.items(frame_0)

    # Verify the result
    value = [('var_x', '{x: 1, y: 2, _x: 3}'), ('var_x.x', '1'), ('var_x.y', '2')]
    assert result_items == value


# Generated at 2022-06-24 17:29:27.483240
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
        frame_0 = utils.MagicMock()
        frame_0.f_locals = {}
        list_0 = []
        frame_0.f_locals['list_0'] = list_0
        str_0 = 'list_0'
        var_0 = BaseVariable(str_0, None)
        var_1 = var_0.items(frame_0, True)
        assert var_1 == (('list_0', '[]'),)


# Generated at 2022-06-24 17:29:36.875919
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    local_var_0 = 'str_0'
    local_var_1 = 'str_1'
    local_var_2 = 'str_2'
    local_list_0 = []
    local_list_1 = []
    local_list_2 = []
    local_list_3 = []
    var_0 = Keys(local_list_0)
    var_1 = Keys(local_list_1)
    var_2 = Keys(local_list_2)
    var_3 = Keys(local_list_3)
    var_0.items(local_list_0)
    var_1.items(local_list_1)
    var_2.items(local_list_2)
    var_3.items(local_list_3)


# Generated at 2022-06-24 17:29:43.106828
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    my_list = [1, 2, 3]
    obj = BaseVariable(my_list, exclude=('x'))
    assert obj.items('my_list') == ()


# Generated at 2022-06-24 17:29:48.268414
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Pick a frame where the variable can be used
    frame_1 = inspect.currentframe()
    frame_1 = frame_1.f_back
    variable_1 = Attrs('__init__')
    variable_1.items(frame_1)


# Generated at 2022-06-24 17:29:57.001936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .variables import BaseVariable
    from .pycompat import builtins
    import sys
    import _ast
    import io

    _globals = globals()
    _globals['var_0'] = list()
    _globals['var_1'] = list()
    _globals['var_2'] = list()
    _globals['var_3'] = list()
    _locals = locals()
    _builtins = builtins()
    _frame = sys._getframe()
    _code = _ast.parse(_ast.PyCF_ONLY_AST, '<string>', 'exec')

    # Call method items of class BaseVariable with argument frame set to _frame and argument normalize set to True and return call result

# Generated at 2022-06-24 17:29:59.076351
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = {}
    var_0 = BaseVariable(source=1, exclude=1).items(frame=frame_0)
    assert var_0 == ()


# Generated at 2022-06-24 17:30:04.845190
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame_0 = FrameRecord({'f_globals': {'x': 0}, 'f_locals': {'y': 1}})
    var_1 = BaseVariable('x', exclude=(2,))
    var_1.code = 'y'
    var_2 = var_1.items(test_frame_0, True)
    list_1 = []
    var_3 = list_1
    var_3 = tuple(var_3)


# Generated at 2022-06-24 17:30:14.947572
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Case 0: simple list
    list_0 = ['ab', 'cd']
    var_0 = Indices('list_0')
    list_0_items = var_0.items(sys._getframe(), normalize=False)
    assert list_0_items == [('list_0[0]', '\'ab\''), ('list_0[1]', '\'cd\'')], 'fail'

    # Case 1: simple dict
    dict_0 = {'a': 1, 'b': 3}
    var_0 = Keys('dict_0')
    dict_0_items = var_0.items(sys._getframe(), normalize=False)
    assert dict_0_items == [('dict_0[\'b\']', '3'), ('dict_0[\'a\']', '1')], 'fail'