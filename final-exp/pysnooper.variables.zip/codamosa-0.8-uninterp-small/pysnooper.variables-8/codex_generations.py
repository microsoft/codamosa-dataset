

# Generated at 2022-06-24 17:21:47.801052
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    str_0 = "this is a string"
    method_0_list_0 = [int_0, str_0]
    utils_0_list_0 = [method_0_list_0, int_0, str_0]
    utils_0_list_0.append(str_0)
    utils_0_list_0.append(int_0)
    utils_0_list_0.append(str_0)
    utils_0_list_0.append(method_0_list_0)
    utils_0_tuple = tuple(utils_0_list_0)
    common_variable_0 = CommonVariable(utils_0_tuple)

# Generated at 2022-06-24 17:21:59.794262
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = 0
    int_1 = 1
    # __eq__ will call isinstance, that is a built in function, so we do not need to stub it.
    # EXCEPTION: TypeError: isinstance() arg 2 must be a type or tuple of types
    # The __eq__ method of BaseVariable class will call self._fingerprint. So we need to fake the _fingerprint.
    BaseVariable.__dict__['_fingerprint'] = 'fake_fingerprint_0'
    # __eq__ will call BaseVariable.__eq__, so we fake it.
    BaseVariable.__eq__ = lambda self, other: True
    assert BaseVariable.__eq__(BaseVariable(int_0), BaseVariable(int_1)) == True
    assert isinstance(BaseVariable(int_0), BaseVariable) == True



# Generated at 2022-06-24 17:22:08.131348
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Expected behavior
    # Equals operator used to test if self == other
    # Returns true if self and other are instances of the same class and have the same fingerprint, false otherwise
    assert True == (Attrs(0) == Attrs(0))
    assert False == (Attrs(0) == Indices(0))
    assert False == (Attrs(0) == CommonVariable(0))
    assert False == (Attrs(0) == BaseVariable(0))
    assert False == (Attrs(0) == 0)
    assert False == (Attrs(1) == Attrs(0))
    assert False == (Attrs(Attrs(0)) == Attrs(Attrs(1)))
    assert False == (Attrs(Indices(0)) == Attrs(Indices(1)))

# Generated at 2022-06-24 17:22:09.794837
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable.__eq__(test_BaseVariable___eq__(),test_BaseVariable___eq__())

# Generated at 2022-06-24 17:22:11.286951
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None) == BaseVariable(None)


# Generated at 2022-06-24 17:22:18.622355
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    assert common_variable_0.items('<variable>') == ('<variable>', -908)
    common_variable_1 = CommonVariable('err')
    assert common_variable_1.items('<args>') == ('<args>', 'Unknown error')


# Generated at 2022-06-24 17:22:21.706661
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    indices_0 = Indices(int_0)
    indices_0[2:2]


# Generated at 2022-06-24 17:22:23.619005
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable(1)
    assert x == x
    assert x != BaseVariable(2)
    assert x != 1


# Generated at 2022-06-24 17:22:26.368356
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(1, 2) == BaseVariable(1, 2)
    assert not BaseVariable(1, 2) == BaseVariable(1, 3)


# Generated at 2022-06-24 17:22:29.473364
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    instance_BaseVariable = BaseVariable()
    assert isinstance(instance_BaseVariable.items(), collections.Iterable)


# Generated at 2022-06-24 17:22:38.693820
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Uncomment following line and change as needed
    frame_0 = {}
    base_variable_0 = BaseVariable(source=None, exclude='exclude')
    base_variable_0.items(frame_0)



# Generated at 2022-06-24 17:22:40.284732
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    base_variable_0 = BaseVariable()
    assert base_variable_0.items()


# Generated at 2022-06-24 17:22:47.829668
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test cases with one string as source
    base_variable_1 = BaseVariable("a")
    assert(base_variable_1.items("a") == "a")

    base_variable_2 = BaseVariable("a")
    assert(base_variable_2.items("a") == "a")
    base_variable_2.source = "b"
    assert(base_variable_2.items("a") == "b")

    base_variable_3 = BaseVariable("a")
    assert(base_variable_3.items("a") == "a")
    base_variable_3.source = ""
    assert(base_variable_3.items("a") == "")

    base_variable_4 = BaseVariable("a.b")
    assert(base_variable_4.items("a") == "a.b")
    base

# Generated at 2022-06-24 17:22:49.028900
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    base_variable = BaseVariable('main_variable')
    base_variable.items()

# Generated at 2022-06-24 17:22:51.222974
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices()
    indices_0[0:5:2]

# Generated at 2022-06-24 17:22:53.495604
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices()
    indices_0[slice(1, 1, 1)]


# Generated at 2022-06-24 17:23:02.073632
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global base_variable_0
    base_variable_0 = BaseVariable("frame.f_globals", exclude=("__builtins__",))
    try:
        assert base_variable_0.items("frame") == ()
        return True
    except Exception as e:
        print("unit test for method items of class BaseVariable fail")
        print(e)
        return False


# Generated at 2022-06-24 17:23:04.913530
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    base_variable_0 = Indices('this is source')
    base_variable_1 = base_variable_0[2:3]


# Generated at 2022-06-24 17:23:10.511954
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    base_variable_0 = BaseVariable('source')
    def dict_local_variable_0(**kw):
        return kw
    dict_local_variable_0(test_BaseVariable_items=True)
    assert (base_variable_0.items(sys._getframe(2), normalize=True) == [('source', 'True')])

# Generated at 2022-06-24 17:23:12.669034
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices()
    indices_0.__getitem__()


# Generated at 2022-06-24 17:23:20.134881
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print(BaseVariable.__eq__())


# Generated at 2022-06-24 17:23:29.795501
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable___eq___BaseVariable = BaseVariable()
    BaseVariable___eq___bool = True
    BaseVariable___eq___int = 10
    BaseVariable___eq___float = 1.1

    BaseVariable_bool_1 = BaseVariable() == BaseVariable___eq___BaseVariable
    BaseVariable_bool_2 = BaseVariable() == BaseVariable___eq___bool
    BaseVariable_bool_3 = BaseVariable() == BaseVariable___eq___int
    BaseVariable_bool_4 = BaseVariable() == BaseVariable___eq___float

    # Testing the method __eq__ of class BaseVariable
    # with parameters BaseVariable
    assert BaseVariable_bool_1
    # Testing the method __eq__ of class BaseVariable
    # with parameters bool
    assert not BaseVariable_bool_2
    # Testing the method __eq__ of class Base

# Generated at 2022-06-24 17:23:34.342324
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_variable_0 = BaseVariable()
    base_variable_1 = BaseVariable()

    assert base_variable_0 == base_variable_1
    assert base_variable_0 != 123
    assert not base_variable_0 == 123

# Generated at 2022-06-24 17:23:36.194966
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    _BaseVariable_0 = BaseVariable()
    assert _BaseVariable_0 == BaseVariable()


# Generated at 2022-06-24 17:23:42.724667
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:23:44.556026
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_variable_0 = BaseVariable()


# Generated at 2022-06-24 17:23:49.806335
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_variable_0 = BaseVariable()
    assert base_variable_0.__eq__(BaseVariable())
    assert base_variable_0.__eq__(BaseVariable())
    assert base_variable_0.__eq__(BaseVariable())

# Generated at 2022-06-24 17:23:55.505405
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        assert BaseVariable().items
    except TypeError:
        print("TypeError in BaseVariable.items")

    frame = frame(100,100,100)

    assert BaseVariable("main_value").items(frame)


# Generated at 2022-06-24 17:24:05.798468
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_variable_0 = BaseVariable()
    try:
        assert isinstance(base_variable_0.__eq__())
    except TypeError:
        assert True
    try:
        assert isinstance(base_variable_0.__eq__(True))
    except TypeError:
        assert True
    try:
        assert isinstance(base_variable_0.__eq__(1, True))
    except TypeError:
        assert True
    try:
        assert isinstance(base_variable_0.__eq__(1, 1, True))
    except TypeError:
        assert True
    try:
        assert isinstance(base_variable_0.__eq__(1, 1, 1, True))
    except TypeError:
        assert True

# Generated at 2022-06-24 17:24:06.651107
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:24:17.604727
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    any_variable_0 = common_variable_0
    common_variable_0.__eq__(any_variable_0)


# Generated at 2022-06-24 17:24:20.828279
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -908
    base_variable_0 = BaseVariable(int_0)
    bool_0 = base_variable_0.__eq__(base_variable_0)
    assert bool_0 == True


# Generated at 2022-06-24 17:24:23.039665
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 29
    string_0 = 'S'
    base_variable_0 = BaseVariable(int_0, string_0)


# Generated at 2022-06-24 17:24:33.835304
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable("obj0.attr0")
    frame0 = inspect.currentframe()
    frame0.f_locals["obj0"] = object()
    frame0.f_locals["obj0"].attr0 = object()
    frame0.f_locals["obj0"].attr0.attr1 = object()
    frame0.f_locals["obj0"].attr0.attr2 = object()
    frame0.f_locals["obj0"].attr0.attr3 = object()
    frame0.f_locals["obj0"].attr0.attr4 = object()
    frame0.f_locals["obj0"].attr0.attr5 = object()
    frame0.f_locals["obj0"].attr0.attr6 = object()

# Generated at 2022-06-24 17:24:37.621475
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -4
    common_variable_0 = CommonVariable(int_0)
    common_variable_1 = CommonVariable(int_0)
    result = common_variable_0 == common_variable_1
    assert result


# Generated at 2022-06-24 17:24:46.398122
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert_raises(Exception, BaseVariable(Keys(42, None, None)).items(Keys(20, None, None)))
    assert_raises(Exception, BaseVariable(Exploding(32)).items(Attrs(11, None, None)))
    assert_raises(Exception, BaseVariable(object()).items(Indices(None, None, None)))
    assert_raises(Exception, BaseVariable(Indices(50)).items(Attrs(0, None, None)))
    assert_raises(Exception, BaseVariable(Indices(None, None, None)).items(object()))
    assert_raises(Exception, BaseVariable(Exploding(None, None, None)).items(Indices(32)))
    assert_raises(Exception, BaseVariable(Keys(61, None, None)).items(Indices(None, None, None)))

# Generated at 2022-06-24 17:24:56.549931
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pdb import Pdb
    from itertools import chain
    from .common import noop_context_manager
    pdb = Pdb(stdout=noop_context_manager)
    int_0 = -908
    keys_0 = ['x', 'y']
    indices_0 = [1, 3]
    indices_1 = [3, 1]
    attrs_0 = {'b': 2, 'a': 1}
    attrs_1 = {'a': 1, 'b': 2}
    imports_0 = {'a': 1}
    imports_1 = {'a': 1, 'b': 2}

# Generated at 2022-06-24 17:25:01.211514
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # Test for BaseVariable instance common_variable_0
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    test_items(common_variable_0, {})
    # Test for BaseVariable instance common_variable_1
    int_0 = -908
    common_variable_1 = CommonVariable(int_0)
    test_items(common_variable_1, {})



# Generated at 2022-06-24 17:25:03.685107
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    bool_0 = common_variable_0 == common_variable_0


# Generated at 2022-06-24 17:25:05.541862
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()

# Generated at 2022-06-24 17:25:26.346715
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable_0 = CommonVariable(int_0)
    common_variable_1 = CommonVariable(int_0)
    assert common_variable_0 == common_variable_1
    assert not common_variable_0 == 'c'
    assert common_variable_1 == common_variable_0
    assert not common_variable_1 == 'i'
    assert not common_variable_0 == None
    assert not common_variable_0 == ''
    assert not common_variable_0 == 'afm'
    assert common_variable_1 == common_variable_0
    assert not common_variable_1 == 'c'
    assert not common_variable_1 == ''
    assert not common_variable_1 == None
    assert not common_variable_1 == 'vd'
    assert not common_variable_0 == 'k'
    assert not common

# Generated at 2022-06-24 17:25:30.542029
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    common_variable_1 = CommonVariable(int_0)

    assert common_variable_0 == common_variable_1


# Generated at 2022-06-24 17:25:38.239905
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # __eq__(self: BaseVariable, other: Any) -> bool
    # If a == b, (not necessarily a.__eq__()), then hash(a) == hash(b).
    int_0 = -405
    dict_0 = dict()
    str_0 = str()
    bool_0 = bool()
    int_1 = 75
    bytes_0 = bytes()
    int_2 = 21
    float_0 = float()
    int_3 = 707
    float_1 = float()
    int_4 = 771
    complex_0 = complex()
    int_5 = 40
    int_6 = 2
    int_7 = 168
    int_8 = -908
    int_9 = -811
    int_10 = -199
    int_11 = -958
    float_

# Generated at 2022-06-24 17:25:41.654478
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import prep_node
    from . import base_frame
    from . import eval_safety
    assert True # TODO: implement your test here


# Generated at 2022-06-24 17:25:51.611545
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Setup
    common_variable_0 = CommonVariable(1, 'some_exclude_value')

    # Testing 0: When 'other' is not an instance of BaseVariable and
    # 'other' is not None
    # Expected: common_variable_0.__eq__(None) returns False
    assert common_variable_0.__eq__(None) is False

    # Testing 1: When 'other' is an instance of BaseVariable and has
    # same attributes as 'common_variable_0'
    # Expected: common_variable_0.__eq__(common_variable_0) returns True
    assert common_variable_0.__eq__(common_variable_0) is True

    # Testing 2: When 'other' is an instance of BaseVariable and has
    # different types of 1st attribute from 'common_variable_0'

# Generated at 2022-06-24 17:25:59.567922
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    lst_0 = [3, 1, 0, 7, 5]
    str_0 = "f@rlC'ZVW1m)"
    tuple_0 = (123, -52, -17, 131)
    common_variable_0 = CommonVariable((-1, (100, -60, str_0, 0, tuple_0, (-9, '', -49, -98, str_0))))
    lst_1 = [3, 1, 0, 7, 5]
    str_1 = "f@rlC'ZVW1m)"
    tuple_1 = (123, -52, -17, 131)
    tuple_3 = (-1, (100, -60, str_0, 0, tuple_0, (-9, '', -49, -98, str_0)))
    tuple_2 = common_variable_0

# Generated at 2022-06-24 17:26:00.831931
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()



# Generated at 2022-06-24 17:26:04.763105
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source_0 = 865
    exclude_0 = tup_0 = (1, 2, )
    var_0 = BaseVariable(source_0, exclude_0)
    frame_0 = f_locals = dict()
    normalize_0 = True
    assert var_0.items(frame_0, normalize_0) == ((), )


# Generated at 2022-06-24 17:26:08.882646
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Attrs('foo.bar')
    v2 = Attrs('foo.bar')
    v3 = Attrs('foo.bar', 'baz')

    assert v1 == v2
    assert not v1 == v3


# Generated at 2022-06-24 17:26:11.187791
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable_0 = BaseVariable(True)

    if BaseVariable_0 == BaseVariable(True):
        pass
    else:
        print('BaseVariable___eq__ :: Failed')
        raise SystemExit


# Generated at 2022-06-24 17:26:40.638042
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    exp_result = True
    common_variable_0 = CommonVariable()
    result = common_variable_0.__eq__(common_variable_0)
    assert result == exp_result


# Generated at 2022-06-24 17:26:52.633707
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = float(0.0)
    float_1 = float(1.0)
    float_2 = float(2.0)
    float_3 = float(3.0)
    float_4 = float(4.0)
    float_5 = float(5.0)
    float_6 = float(6.0)
    float_7 = float(7.0)
    float_8 = float(8.0)
    float_9 = float(9.0)
    float_10 = float(10.0)
    float_11 = float(11.0)
    float_12 = float(12.0)
    float_13 = float(13.0)
    float_14 = float(14.0)
    float_15 = float(15.0)

# Generated at 2022-06-24 17:27:00.275814
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = {'dict_0': 23, 'dict_1': 99, 'dict_2': 5}
    varname = 'dict_0'
    # result = BaseVariable._items(dict_0, varname)
    # assert result == {'dict_0': '23', 'dict_0.keys()': 'dict_keys([\'dict_0\', \'dict_1\', \'dict_2\'])', 'dict_0.values()': 'dict_values([23, 99, 5])', 'dict_0.items()': 'dict_items([(\'dict_0\', 23), (\'dict_1\', 99), (\'dict_2\', 5)])'}, "Test Failed"


# Generated at 2022-06-24 17:27:04.932996
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = {'d': {'r': 'w'}}
    dict_1 = {'l': {'o': 'l'}}
    list_0 = [dict_0, dict_1, [1, 2, 3]]
    str_0 = 'abc'
    str_1 = 'abc'
    int_0 = 908
    int_1 = 908


# Generated at 2022-06-24 17:27:08.185010
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = -908
    int_1 = -908
    base_variable_0 = BaseVariable(int_0)
    base_variable_1 = BaseVariable(int_1)
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:27:20.205616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    @BaseVariable.items("test_BaseVariable_items", exclude=())
    def test_BaseVariable_items(self, frame, normalize):
        return self.items(frame, normalize)

    @BaseVariable.items("test_BaseVariable_items", exclude=())
    def test_BaseVariable_items(self, frame, normalize):
        return self.items(frame, normalize)

    str_0 = "test_BaseVariable_items"
    bool_0 = False
    BaseVariable.items(str_0, exclude=())
    assert_equal(test_BaseVariable_items(self, frame, normalize), BaseVariable.items(str_0, exclude=()))
    assert_equal(test_BaseVariable_items(self, frame, normalize), BaseVariable.items(str_0, exclude=()))

# Unit test

# Generated at 2022-06-24 17:27:32.027634
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import pycompat
    from .utils import ensure_tuple
    from .pycompat import ABC, abstractmethod
    from .commonvariable import CommonVariable
    from .basevariable import BaseVariable
    from .indices import Indices
    from .keys import Keys
    from .attrs import Attrs
    from .exploding import Exploding
    from .utils import get_shortish_repr
    import abc
    import itertools
    import re
    import random
    import pytest
    from .utils import get_shortish_repr
    from .test_utils import get_test_frame
    from .vars import normalize_var_repr
    import datetime
    from .utils import ensure_tuple
    from .pycompat import ABC, abstractmethod
    from .commonvariable import CommonVariable

# Generated at 2022-06-24 17:27:38.889143
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    arg0 = object()
    arg1 = object()
    arg2 = object()
    BaseVariable_0 = BaseVariable(arg0, arg1)
    BaseVariable_1 = BaseVariable(arg0, arg1)
    BaseVariable_2 = BaseVariable(arg0, arg2)
    assert BaseVariable_0.__eq__(BaseVariable_1)
    assert not BaseVariable_0.__eq__(BaseVariable_2)


# Generated at 2022-06-24 17:27:40.552009
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)

# Generated at 2022-06-24 17:27:44.546970
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = main_value()
    normalize = normalize()
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    result = common_variable_0.items(main_value, normalize)


# Generated at 2022-06-24 17:28:43.231262
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 17:28:44.034612
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Generated at 2022-06-24 17:28:48.020476
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable_0 = CommonVariable('common_variable_0')
    frame = ('frame')
    common_variable_0.items(frame)


# Generated at 2022-06-24 17:28:51.487590
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)

# Generated at 2022-06-24 17:28:56.024958
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable()
    variable.source = 'a'
    variable.exclude = set()
    variable.code = compile('a', '<variable>', 'eval')
    variable.unambiguous_source = variable.source
    variable.items('a',)
    return variable


# Generated at 2022-06-24 17:28:57.725039
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    common_variable_0.items()


# Generated at 2022-06-24 17:29:01.964661
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    frame_0 = frame or {}
    str_0 = str(int_0)
    common_variable_0 = CommonVariable(str_0)
    common_variable_0.items(frame)


# Generated at 2022-06-24 17:29:11.206469
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = ':cf\x1fDg\x17\x18\x15H\x1aA@\x1eV\x02'
    str_1 = '\x15\x16\x1e\n\x1e\x1a\x19A\n\x15\x16\x1e\x1aB'
    item_info_0 = ItemInfo(str_1, str_0)
    dict_0 = dict(item_info_0)
    frame_0 = Frame(dict_0)
    basevariable_0 = BaseVariable('z')
    list_0 = basevariable_0.items(frame_0)


# Generated at 2022-06-24 17:29:23.292441
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = [0]
    dict_0 = dict()
    dict_0[0] = 0
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[0] = 3
    dict_0[1] = 4
    dict_0[2] = 5
    dict_0[0] = 6
    dict_0[1] = 7
    dict_0[2] = 8
    dict_0[0] = 9
    dict_0[1] = 10
    dict_0[2] = 11
    dict_0[0] = 12
    dict_0[1] = 13
    dict_0[2] = 14
    dict_0[0] = 15
    dict_0[1] = 16
    dict_0[2] = 17
    dict

# Generated at 2022-06-24 17:29:29.371086
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '.?&9jt[d$8(LY@'
    assert BaseVariable(str_0).items(str_0) == ()


# Generated at 2022-06-24 17:30:13.559018
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable(1).items("") == ()
    assert BaseVariable("").items("") == ()


# Generated at 2022-06-24 17:30:17.376979
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 1098
    CommonVariable_0 = CommonVariable(int_0)
    frame_0 = None
    print(CommonVariable_0.items(frame_0))


# Generated at 2022-06-24 17:30:23.365422
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = dict()
    for i in range(1, 5, 1):
        dict_0[i] = i + 1
    assert list(BaseVariable(dict_0).items(frame = dict_0)) == list([('0', '1'), ('1', '2'), ('2', '3'), ('3', '4'), ('4', '5')])



# Generated at 2022-06-24 17:30:27.252459
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    base_variable_0 = BaseVariable(int_0)
    # ReSharper disable PyUnusedLocal
    frame_0 = None
    # ReSharper restore PyUnusedLocal
    result = base_variable_0.items(frame_0, False)
    assert True


# Generated at 2022-06-24 17:30:30.536034
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    string_0 = '9j7z5U5_5cCzsw'
    var_0 = BaseVariable(string_0)
    var_0.items(string_0)




# Generated at 2022-06-24 17:30:39.604818
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    slice_0 = slice(5, 5)
    list_0.__getitem__(slice_0)
    try:
        list_0[::-1]
    except IndexError:
        None
    else:
        None
    str_0 = ''
    list_0.append(str_0)
    tuple_1 = (None,)
    frame_0 = Frame(None, 0, 0)
    frame_0.f_globals.clear()
    frame_0.f_globals.update({(str): int_0})
    frame_0.f_locals.clear()
    tuple_2 = (None,)
    common_variable_0 = CommonVariable(*tuple_2)
    items = common_variable_0.items(frame_0)

# Generated at 2022-06-24 17:30:45.346623
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 4007
    str_0 = 'test_BaseVariable_items'
    dict_0 = dict()
    dict_0['int_0'] = int_0
    dict_0['str_0'] = str_0
    frame_0 = sys._getframe()
    frame_0.f_globals.update(dict_0)
    base_variable_0 = BaseVariable(int_0)
    result = base_variable_0.items(frame_0)
    print(result)
    expected = ('-908', '-908')
    assert result == expected


# Generated at 2022-06-24 17:30:47.992763
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable_0 = CommonVariable(('Z',), None)
    assert common_variable_0.items(None) == ()



# Generated at 2022-06-24 17:30:57.755161
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -908
    common_variable_0 = CommonVariable(int_0)
    str_0 = 'DUW'
    str_1 = 'DUW'
    str_2 = 'DUW'
    frame_0 = frame(str_0, str_1, str_2)
    str_3 = 'DUW'
    tuple_0 = (str_3,)
    bool_0 = False
    common_variable_1 = CommonVariable(str_3, tuple_0, bool_0)
    str_4 = 'DUW'
    tuple_1 = (str_4,)
    bool_1 = False
    common_variable_2 = CommonVariable(str_4, tuple_1, bool_1)
    str_5 = 'DUW'

# Generated at 2022-06-24 17:31:01.299739
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
	frame = inspect.currentframe()
	frame = frame.f_back
	int_0 = -908
	common_variable_0 = CommonVariable(int_0)
	return common_variable_0.items(frame, )
