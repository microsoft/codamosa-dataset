

# Generated at 2022-06-24 17:21:36.530153
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    common_variable_1 = 'logger'
    indices_0 = Indices(common_variable_1)

    frame_0 = None

    assert indices_0.items(frame_0) == []


# Generated at 2022-06-24 17:21:38.605556
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(None)
    assert indices_0[:] == Indices(None, slice(None, None, None))


# Generated at 2022-06-24 17:21:41.621484
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable_0 = None
    frame_0 = None
    normalize_0 = None
    items_0 = BaseVariable(common_variable_0).items(frame_0, normalize_0)


# Generated at 2022-06-24 17:21:43.276622
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_0 = None
    keys_0 = Keys(common_variable_0)
    assert keys_0 == keys_0


# Generated at 2022-06-24 17:21:52.092421
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    global common_variable_0
    common_variable_0_1 = CommonVariable(common_variable_0)
    common_variable_0_2 = CommonVariable(common_variable_0)
    assert ( common_variable_0_1 == common_variable_0_2 )


# Generated at 2022-06-24 17:21:54.767588
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    string = '../utils.py'
    result = Indices(string)[0]


# Generated at 2022-06-24 17:21:59.264930
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_0 = None
    attrs_0 = Attrs(common_variable_0)
    common_variable_1 = None
    keys_0 = Keys(common_variable_1)
    assert(attrs_0 == keys_0)


# Generated at 2022-06-24 17:22:09.177278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Variable 1 - There are no instances.
    common_variable_1 = None
    exclude_1 = ()
    normalize_1 = False
    base_variable_1 = BaseVariable(common_variable_1, exclude_1)
    def body_1():
        return base_variable_1.items(frame_0, normalize_1)
    # Unit test for method items of class Attrs
    # Verify that the method throws an exceptions.
    with pytest.raises(NotImplementedError):
        body_1()
    # Variable 2 - There are no instances.
    common_variable_2 = None
    exclude_2 = ()
    normalize_2 = False
    base_variable_2 = BaseVariable(common_variable_2, exclude_2)
    def body_2():
        # Variable 0
        frame_0

# Generated at 2022-06-24 17:22:13.999521
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    common_variable_1 = None
    indices_0 = Indices(common_variable_1)
    try:
        indices_slice = slice(None, None, None)
        indices_0[indices_slice]
    except:
        print('FAIL')


# Generated at 2022-06-24 17:22:18.478732
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable = None
    frame = None
    normalize = None
    base_variable = BaseVariable(common_variable)
    base_variable.items(frame, normalize)


# Generated at 2022-06-24 17:22:27.844990
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    keys_0 = Keys(None)
    keys_1 = Keys(None)
    assert keys_0 == keys_1


# Generated at 2022-06-24 17:22:40.401311
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_0 = None
    keys_0 = Keys(common_variable_0)
    def veri_eq(x, y):
        assert x == y
    def veri_neq(x, y):
        assert x != y
    varset = [Attrs, Attrs('a'), Attrs('a', exclude='b'), Attrs('a', exclude=('b',)), Exploding, Keys, Keys('a'), Indices, Indices('a')]
    for x in varset:
        for y in varset:
            if x == y:
                veri_eq(x, y)
            else:
                veri_neq(x, y)


# Generated at 2022-06-24 17:22:46.446505
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Constructor test for
    indices_0 = Indices('')
    # Member test for _slice
    # Call to __getitem__
    indices_0[:]


# Generated at 2022-06-24 17:22:51.746942
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_0 = None
    common_variable_1 = None
    common_variable_2 = None
    common_variable_3 = None

    assert BaseVariable(common_variable_0, common_variable_1) == BaseVariable(common_variable_2, common_variable_3)


# Generated at 2022-06-24 17:22:59.938140
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # init
    common_variable_0 = None
    keys_0 = Keys(common_variable_0)
    object_0 = object()
    object_1 = object()
    object_1.__dict__['a'] = object_0
    object_2 = object()
    object_2.__dict__['a'] = object_1
    object_2.__dict__['b'] = object()
    object_2.__dict__['c'] = object()
    list_0 = []
    dict_0 = {}
    dict_0['a'] = list_0
    dict_0['b'] = list_0
    dict_0['c'] = list_0
    dict_0['d'] = list_0
    # call
    actual = keys_0.items(object_2)
    # TODO understand why

# Generated at 2022-06-24 17:23:03.474040
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_variable_0 = Attrs(None)
    base_variable_1 = Attrs(None)
    assert(base_variable_0 == base_variable_1)


# Generated at 2022-06-24 17:23:07.379202
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Imports
    # Setup
    indices_0 = Indices(None)
    # Test
    try:
        indices_0.__getitem__(1)
    except TypeError:
        pass



# Generated at 2022-06-24 17:23:09.503958
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # A simple test which just makes sure the method exists
    BaseVariable('').items(None)


# Generated at 2022-06-24 17:23:15.378010
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from types import FrameType
    from types import TracebackType
    frame = frame_0 = FrameType(f_back=None, f_code=None, f_lasti=None, f_lineno=None, f_locals=None, f_trace=None)
    base_variable_0 = BaseVariable()
    base_variable_0.items(frame)


# Generated at 2022-06-24 17:23:17.569867
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable.__eq__(BaseVariable, BaseVariable) == NotImplementedError


# Generated at 2022-06-24 17:23:25.011541
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable('a')
    variable_2 = BaseVariable('a')
    assert variable == variable_2
    variable_3 = BaseVariable('b')
    assert variable != variable_3
    variable_4 = CommonVariable('a')
    assert variable != variable_4



# Generated at 2022-06-24 17:23:27.403845
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices("arg_0")
    indices_0.__getitem__(slice(1, 2, 3))


# Generated at 2022-06-24 17:23:29.300730
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices(test_case_0)


# Generated at 2022-06-24 17:23:32.139357
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = None
    indices_0 = Indices(indices_0)
    indices_0.__getitem__(1)


# Generated at 2022-06-24 17:23:37.820479
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_a = None
    common_variable_b = None
    base_variable_a = BaseVariable(common_variable_a)
    base_variable_b = BaseVariable(common_variable_b)
    base_variable_c = BaseVariable(common_variable_b)
    test_case_0(base_variable_a, base_variable_b, base_variable_c)


# Generated at 2022-06-24 17:23:41.269814
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    common_variable_0 = None
    base_variable_0 = BaseVariable(common_variable_0)
    assert(base_variable_0.__eq__(common_variable_0) == (isinstance(common_variable_0, BaseVariable) and base_variable_0._fingerprint == common_variable_0._fingerprint))


# Generated at 2022-06-24 17:23:42.720033
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert True


# Generated at 2022-06-24 17:23:44.233627
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    k = Keys("test.test2")
    j = Keys("test.test2")
    assert(k.__eq__(j) == True)


# Generated at 2022-06-24 17:23:49.246363
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_1 = Indices()
    indices_1.__getitem__()

# Verify that __getitem__ raises an exception if it's passed a None value.

# Generated at 2022-06-24 17:23:50.723422
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    return None


# Generated at 2022-06-24 17:24:06.881783
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for bool
    var_0 = BaseVariable(bool_0)
    var_1 = var_0.items()
    assert var_1[0][0] == 'bool_0'
    assert var_1[0][1] == 'True'
    # Test for int
    var_2 = BaseVariable(int_0)
    var_3 = var_2.items()
    assert var_3[0][0] == 'int_0'
    assert var_3[0][1] == '1'
    # Test for float
    var_4 = BaseVariable(float_0)
    var_5 = var_4.items()
    assert var_5[0][0] == 'float_0'
    assert var_5[0][1] == '1.0'
    # Test for str
    var

# Generated at 2022-06-24 17:24:14.682746
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import io
    import stackprinter
    from collections import defaultdict

    err_buff = io.StringIO()
    out_buff = io.StringIO()

    real_stdout, sys.stdout = sys.stdout, out_buff
    real_stderr, sys.stderr = sys.stderr, err_buff

    # Setup test data
    # Call the method to be tested
    
    # Assert method output
    
    # Teardown test data
    
    pass


# Generated at 2022-06-24 17:24:19.403126
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()

    def test_func():
        var_0 = sys._getframe()
        var_1 = Indices('var_0')
        var_2 = var_1.items(var_0, True)

    # Input parameters and expected outputs
    test_func()


# Generated at 2022-06-24 17:24:27.200497
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = pycompat.Mock()
    frame_0.f_globals = {}
    frame_0.f_locals = {}
    frame_0.f_globals['__builtins__'] = {}
    frame_0.f_globals['__builtins__']['__name__'] = "__builtin__"
    frame_0.f_globals['__builtins__']['__doc__'] = "Built-in functions, exceptions, and other objects."
    frame_0.f_globals['__builtins__']['__package__'] = None
    frame_0.f_globals['__builtins__']['__loader__'] = None

    frame_0.f_locals['__name__'] = "__main__"

# Generated at 2022-06-24 17:24:31.256185
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # bool_0 is the object for which we want to determine if it needs parentheses
    bool_0 = True
    # var_0 holds a boolean value, True or False, whether or not bool_0 needs parentheses
    var_0 = needs_parentheses(bool_0)


# Generated at 2022-06-24 17:24:37.101871
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()

    # Test the case where we're looking at no variables
    var_0 = BaseVariable()
    var_1 = var_0.items(frame)

    # Test the case where we're looking at a single variable
    var_0 = BaseVariable('bool_0')
    var_1 = var_0.items(frame)



# Generated at 2022-06-24 17:24:46.157317
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import _frame

    frame_0 = _frame.Frame(0)
    int_0 = 0
    str_0 = '0'
    bool_0 = True
    tuple_0 = (int_0, str_0, bool_0)
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'd'
    str_5 = 'e'
    str_6 = 'f'
    str_7 = 'g'
    str_8 = 'h'
    str_9 = 'i'
    str_10 = 'j'
    str_11 = 'k'
    str_12 = 'l'
    str_13 = 'm'
    str_14 = 'n'

# Generated at 2022-06-24 17:24:57.657586
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = str('')
    bool_0 = False
    frame_0 = frame()
    var_1 = frame_0.f_globals
    var_2 = frame_0.f_locals
    var_3 = compile(var_0, '<variable>', 'eval')
    var_4 = eval(var_3, var_1, var_2)
    var_5 = var_4[0]
    var_6 = Keys(var_0, var_4)
    var_7 = var_6._items(var_5)
    var_8 = var_4[1]
    var_9 = var_4[2]
    var_10 = var_4[3]
    var_5 = var_5[var_8]
    del var_4[var_8]


# Generated at 2022-06-24 17:25:08.169100
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Testing method items of class BaseVariable for an exception
    bool_0 = True
    int_0 = 1
    str_0 = '_'
    list_0 = []
    list_0.append(bool_0)
    list_1 = []
    list_1.append(int_0)
    list_2 = []
    list_2.append(str_0)
    list_2.append(str_1)
    list_3 = []
    list_3.append(list_0)
    list_3.append(list_1)
    list_3.append(list_2)
    list_3.append(list_3)
    list_3.append(tuple_0)

    frame_0 = {}
    frame_0["a"] = {}

# Generated at 2022-06-24 17:25:18.141116
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    bytes_0 = b'\x1d'
    complex_0 = 1 - 1j
    dict_0 = {}
    dict_1 = {}
    float_0 = 0.0
    int_0 = 0
    list_0 = [bool_0, bytes_0, complex_0, dict_0, float_0, int_0, list_0]
    list_1 = [complex_0, list_0, dict_0, list_0, int_0, float_0, bytes_0]
    list_2 = [int_0, list_0, dict_0, complex_0, bytes_0, list_0, float_0]
    list_3 = [bytes_0, list_0, float_0, list_0, int_0, dict_0, complex_0]

# Generated at 2022-06-24 17:25:31.926274
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    root = BaseVariable(bool_0)
    chain_0 = (root._items(fake_frame))
    print(chain_0)


# Generated at 2022-06-24 17:25:36.524938
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import frames
    from . import variable

    class Exploding(object):
        pass
    obj_0 = Exploding()
    items = variable.BaseVariable.items
    # Test for method items of class BaseVariable
    obj_0_items = items(obj_0)
    assert obj_0_items == ()
    assert isinstance(obj_0_items, tuple)

# Generated at 2022-06-24 17:25:48.821089
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = inspect.currentframe()
    inspect.getargvalues(frame_0)
    var_2 = Keys('a')
    var_3 = var_2.items(frame_0)
    var_4 = True
    var_5 = {'a': {}, 'b': {}}
    var_6 = var_5['a']
    var_7 = Attrs('d')
    var_8 = var_7.items(frame_0)
    var_9 = var_5['b']
    var_10 = var_9['c']
    var_11 = var_10.items(frame_0)
    var_12 = {'a': [], 'b': {'c': []}}
    var_13 = var_12['a']
    var_14 = Indices('d')
    var_

# Generated at 2022-06-24 17:26:01.026499
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 1
    str_0 = "b"
    list_0 = []
    dict_0 = {}
    list_0.append(dict_0)
    dict_0["a"] = list_0
    dict_0[str_0] = list_0

    # Test with a dictionary
    var_0 = Keys('dict_0').items(dict_0)
    assert var_0 == [('dict_0[a]', "[]"), ('dict_0[b]', "[]")]

    # Test with a list
    var_0 = Indices('list_0').items(list_0)
    assert var_0 == [('list_0[0]', repr(dict_0))]

    # Test with a boolean
    var_0 = Keys('bool_0').items(True)
    assert var

# Generated at 2022-06-24 17:26:05.077995
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    normalize_0 = False
    BaseVariable_0 = BaseVariable(frame_0,normalize_0)
    frame_1 = None
    normalize_1 = False
    BaseVariable_1 = BaseVariable(frame_1,normalize_1)

# Generated at 2022-06-24 17:26:13.449208
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 'a.b.c'
    var_1 = {'a.b.c': 0}
    var_2 = utils.ShortishRepr(0)
    var_3 = utils.ShortishRepr(0)
    var_4 = utils.ShortishRepr(0)
    frame = {'__file__': '/home/yli/yc/pyt/ph/tb_0.py', '__builtins__': {}, '__name__': 'ph.tb_0', 'a': {'b': {'c': 0}}}
    obj_0 = BaseVariable(var_0)
    var_5 = obj_0.items(frame)
    var_6 = utils.ensure_tuple(var_5)
    var_7 = obj_0._fingerprint

# Generated at 2022-06-24 17:26:16.647167
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = 3
    variable = BaseVariable('3')
    variable.items(main_value)



# Generated at 2022-06-24 17:26:26.549763
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f1(f_globals, f_locals):
        var_0 = f_globals
        var_1 = f_locals
        var_2 = {}
        var_2[0] = var_0
        var_2[1] = var_1
        var_1.update(var_2)
        return var_1

    var_2 = test_BaseVariable_items
    var_3 = f1
    var_0 = BaseVariable(var_2)
    var_1 = var_0.items(var_3)

# Generated at 2022-06-24 17:26:28.816547
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Indices('a')
    main_value = [1, 2, 3]
    var_1 = var_0.items(main_value)


# Generated at 2022-06-24 17:26:30.855342
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('test')
    var_1 = var_0.items(None)


# Generated at 2022-06-24 17:26:56.445132
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    str_1 = 'test {}'
    str_2 = 'test {}'
    assert str_1.format(bool_0) == str_2.format(bool_0)


# Generated at 2022-06-24 17:26:57.695173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:26:59.047553
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:27:01.087501
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test instance of BaseVariable
    var_0 = BaseVariable("test_str_0")
    var_0.items("test_str_1")


# Generated at 2022-06-24 17:27:02.692589
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    var_0 = True
    assert var_0 == True


# Generated at 2022-06-24 17:27:09.422278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import doctest
    test_case = inspect.getfile(test_case_0) # the file name
    test_case_name = inspect.getsource(test_case_0) # the code itself
    #print(test_case_name)
    tester = doctest.DocTestParser()
    test = tester.get_doctest(test_case_name,globals(),test_case,None,None)
    runner = doctest.DocTestRunner()
    runner.run(test)

if __name__ == "__main__":
    test_BaseVariable_items()

# Generated at 2022-06-24 17:27:20.860121
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_r_0 = random.uniform(0.0, 10.0)
    int_r_1 = random.randint(0, 10)
    str_r_2 = random.uniform(0.0, 10.0)
    str_r_3 = random.uniform(0.0, 10.0)
    bool_4 = bool(random.randint(0, 1))
    bool_5 = bool(random.randint(0, 1))
    bool_6 = bool(random.randint(0, 1))
    bool_7 = bool(random.randint(0, 1))
    str_r_8 = random.uniform(0.0, 10.0)
    str_9 = chr(random.randint(97, 122))

# Generated at 2022-06-24 17:27:29.838666
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Attrs('request')
    var_1 = var_0.items(None)
    var_2 = var_1[0][0]
    var_3 = var_1[0][1]
    var_4 = var_1[1][0]
    var_5 = var_1[1][1]
    var_6 = var_1[2][0]
    var_7 = var_1[2][1]

# unit test for method _items of class CommonVariable

# Generated at 2022-06-24 17:27:38.770053
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    assert frame
    method_1 = BaseVariable.items
    assert method_1
    method_1.test_frame_0 = frame
    BaseVariable.test_frame_0 = frame
    BaseVariable.items.test_frame_0 = frame
    def test_instance_1(self):
        frame = BaseVariable.items.test_frame_0
        assert frame
        del frame
        self.items(frame)
    test_instance_1(BaseVariable())
    del frame


# Generated at 2022-06-24 17:27:48.666113
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:28:35.977585
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable(bool_0)


# Generated at 2022-06-24 17:28:46.915314
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class _BaseVariable(BaseVariable):
        def __init__(self, *args, **kwargs):
            super(_BaseVariable, self).__init__(*args, **kwargs)
            self.exclude = 'exclude'

    _frame = None

    var_0 = 'a'
    bool_0 = needs_parentheses(var_0)

    var_1 = None
    var_2 = var_1
    bool_1 = isinstance(var_2, Mapping)

    var_3 = ''
    var_4 = var_3
    bool_2 = isinstance(var_4, Sequence)

    var_5 = _BaseVariable(var_0)
    var_6 = var_5
    var_7 = _BaseVariable.items(var_6, _frame)
    var_8 = var_7

# Generated at 2022-06-24 17:28:58.210170
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:29:08.250421
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('test_BaseVariable_items')
    # Test 1
    main_value_1 = 'xyz'
    main_value_2 = b'xyz'
    expected = [('x', "b'y'")]
    var_0 = Keys()._items(main_value_1)
    assert var_0 == expected

    # Test 2
    main_value_1 = b'xyz'
    main_value_2 = b'xyz'
    expected = [('x', "b'y'")]
    var_0 = Keys()._items(main_value_1)
    assert var_0 == expected


# Generated at 2022-06-24 17:29:13.515739
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Setup local variables used in the test
    string_0 = 'x'
    frame_0 = None
    # The following 'try' statement is used to catch the exception
    # raised when the test methdo raises an exception. It catches
    # the exception at this level and re-raises it with a different
    # exception message.
    try:
        var_0 = BaseVariable(string_0)
        var_0.items(frame_0)
    except Exception:
        e = sys.exc_info()[1]
        raise AssertionError(str(e))


# Generated at 2022-06-24 17:29:14.813008
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    return None


# Generated at 2022-06-24 17:29:26.330637
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import pycompat
    from . import utils
    from . import py_35
    from . import py_27
    from . import pycompat
    from . import pycompat
    from . import abc
    from . import OrderedDict
    from . import pycompat
    from . import py_3
    from . import typing
    from . import py_35
    from . import py_35
    from . import py_35
    from . import typing
    from . import BaseVariable
    from . import py_35
    from . import Attrs
    from . import typing
    from . import typing
    from . import typing
    from . import Attrs
    from . import typing
    from . import Attrs
    from . import typing
    from . import Keys
    from . import typing

# Generated at 2022-06-24 17:29:33.408996
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import get_shortish_repr
    def code(s):
        return compile(s, '<variable>', 'eval').co_code

    var_0 = BaseVariable(1)
    var_1 = BaseVariable((dict))
    var_0.code = code('True')
    var_1.source = (dict)
    var_0.exclude = ()
    var_1.exclude = ()
    var_0.unambiguous_source = 'True'
    var_1.unambiguous_source = '(dict)'
    var_0._items([], False)
    var_1._items(dict(), False)

# Generated at 2022-06-24 17:29:34.855818
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    instance = BaseVariable(source=0)
    assert instance.items(frame=0, normalize=0) == ()


# Generated at 2022-06-24 17:29:46.829078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Indices('a')
    var_1 = {}
    var_1[1] = 'abc'
    var_1[2] = 'def'
    var_1[3] = 'ghi'
    list_0 = []

    for var_2 in var_0.items(var_1):
        list_0.append(var_2)
    var_3 = (('a[0]', 'abc'), ('a[1]', 'def'), ('a[2]', 'ghi'))
    assert list_0 == var_3
