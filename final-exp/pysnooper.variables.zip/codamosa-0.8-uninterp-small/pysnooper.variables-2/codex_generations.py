

# Generated at 2022-06-24 17:21:39.915903
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    key = 'b'
    main_value = (1, 2, 3)
    indices_0 = Indices(key)
    result_0 = indices_0.items(main_value)
    assert len(result_0) == 2
    assert result_0[0][0] == 'b[0]'
    assert result_0[0][1] == '1'
    assert result_0[1][0] == 'b[1]'
    assert result_0[1][1] == '2'


# Generated at 2022-06-24 17:21:45.339043
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = 'main_value'
    frame_0 = utils.Frame(None, None, str_1)
    utils.set_value_to_frame(frame_0, str_1, '__main__')
    assert [(str_0, '__main__')] == common_variable_0.items(frame_0)

# Generated at 2022-06-24 17:21:46.884991
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)



# Generated at 2022-06-24 17:21:52.093835
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    assert (common_variable_0 == common_variable_1)



# Generated at 2022-06-24 17:21:56.951614
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    common_variable_0 = CommonVariable('__name__')
    assert common_variable_0.items({'__name__': '__name__'}) == [('__name__', "'__name__'")]



# Generated at 2022-06-24 17:22:06.759586
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    str_1 = '__init__'
    str_2 = str()
    str_3 = 'self'
    str_4 = '__file__'
    str_5 = '__repr__'
    str_6 = str()
    str_7 = str()
    str_8 = str()
    str_9 = str()
    str_10 = str()
    str_11 = str()
    str_12 = str()
    str_13 = str()
    str_14 = str()
    str_15 = str()
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_1)
    common_variable_2 = CommonVariable(str_2)

# Generated at 2022-06-24 17:22:09.899719
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    assert (common_variable_0 == common_variable_0), 'Not equal'


# Generated at 2022-06-24 17:22:19.237694
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    def check(actual, expected):
        for act, exp in zip(actual, expected):
            assert act[0] == exp[0]
        assert len(actual) == len(expected)
    #
    def test_case_0():
        common_variable_0.source = 'a'
        common_variable_0.exclude = ('a', 'b')
    #
    test_case_0()




# Generated at 2022-06-24 17:22:22.867969
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = Attrs(str_0)
    # assert str_0 == common_variable_0


# Generated at 2022-06-24 17:22:31.515901
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = None
    bool_0 = common_variable_0.exclude
    pycompat.unicode_0 = '__name__'
    str_1 = '__name__'
    bool_1 = bool_0
    common_variable_0.items(frame_0)
    common_variable_0.unambiguous_source
    common_variable_0.code
    common_variable_0.source
    common_variable_0.exclude
    tuple_0 = common_variable_0.items(frame_0)
    common_variable_0.items(frame_0)
    common_variable_0.items(frame_0)
    common_variable_0.items(frame_0)
   

# Generated at 2022-06-24 17:22:38.693671
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'a'
    indices_0 = Indices(str_0)
    indices_1 = indices_0.__getitem__(slice(-2, 3))


# Generated at 2022-06-24 17:22:46.056383
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'idx'
    str_1 = 'idx.__class__'
    str_2 = 'idx.__class__.im_self'
    str_3 = 'idx.__class__.im_self.__class__'
    str_4 = 'idx.__class__.im_self.__class__.__name__'
    base_variable_0 = BaseVariable(str_0)
    base_variable_1 = BaseVariable(str_1)
    base_variable_2 = BaseVariable(str_2)
    base_variable_3 = BaseVariable(str_3)
    base_variable_4 = BaseVariable(str_4)
    base_variable_5 = BaseVariable(str_0)
    assert not base_variable_0 == base_variable_1
    assert not base

# Generated at 2022-06-24 17:22:55.500376
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)

    module = importlib.import_module('test_method_items')
    frame = module.test_method_items.test_case_0.f_locals
    frame_1 = frame['frame_1']
    frame_1_items = common_variable_0.items(frame_1)
    assert frame_1_li == [('__name__', 'base_variable')]


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:22:58.649645
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_0)

# Generated at 2022-06-24 17:23:02.139391
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = '__name__'
    indices_0 = Indices(str_0)
    print(indices_0)
    indices_0[slice(0, 1, 1)]


# Generated at 2022-06-24 17:23:05.991103
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    assert(BaseVariable(str_0) == BaseVariable(str_0))
    assert(BaseVariable(str_0) != BaseVariable('__class__'))


# Generated at 2022-06-24 17:23:09.676710
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    keys_0 = Keys(str_0)
    assert common_variable_0 == keys_0


# Generated at 2022-06-24 17:23:16.225007
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = '__name__'
    indices_0 = Indices(str_0)
    slice_0 = slice(1, 1, 1)
    indices_0[slice_0]

    str_1 = '__name__'
    str_2 = '__name__'
    indices_1 = Indices(str_1)
    indices_2 = Indices(str_2)
    assert indices_1 == indices_2

# Generated at 2022-06-24 17:23:24.528195
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    str_0 = '__name__'
    str_1 = 'Hello, World!'
    list_0 = ['Hello, World!']
    list_1 = ['Hello, World!']
    list_2 = ['Hello, World!']
    list_1[int_0] = 'Hello, World!'
    list_1[int_1] = 'Hello, World!'
    list_1[int_2] = 'Hello, World!'
    list_2[int_0] = 'Hello, World!'
    list_2[int_1] = 'Hello, World!'
    list_2[int_2] = 'Hello, World!'
    indices_0 = Indices(str_0)

# Generated at 2022-06-24 17:23:30.124995
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    slice_0 = slice(None)
    indices_0 = Indices(str_0)
    indices_0[slice_0]

# Generated at 2022-06-24 17:23:35.321640
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        test_case_0()
    except Exception as e:
        raise e


# Generated at 2022-06-24 17:23:42.688064
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_1 = CommonVariable(str_0)
    common_variable_2 = CommonVariable(str_0)
    common_variable_3 = CommonVariable(str_0)
    common_variable_4 = CommonVariable(str_0)
    common_variable_5 = CommonVariable(str_0)
    common_variable_6 = CommonVariable(str_0)
    common_variable_7 = CommonVariable(str_0)
    common_variable_8 = CommonVariable(str_0)
    common_variable_9 = CommonVariable(str_0)
    common_variable_10 = CommonVariable(str_0)
    common_variable_11 = CommonVariable(str_0)
    common_variable_12 = CommonVariable(str_0)
    common_variable_13 = Common

# Generated at 2022-06-24 17:23:52.818868
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1
    str_0 = ''
    str_1 = ''
    dictionary_0 = {}
    dictionary_1 = {}
    base_variable_0 = BaseVariable(str_0)
    items_of_base_variable_0 = base_variable_0.items(dictionary_0, dictionary_1)
    # Check items_of_base_variable_0 (1)
    assert_equal(items_of_base_variable_0, ())
    # Test 2
    str_2 = '__name__'
    dictionary_2 = {}
    dictionary_3 = {}
    exception_0 = Exception()
    base_variable_1 = BaseVariable(str_2)
    # Check base_variable_1._items (1)

# Generated at 2022-06-24 17:23:59.144546
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_0_copy = deepcopy(common_variable_0)
    common_variable_0_copy.source = '__doc__'
    assert common_variable_0 != common_variable_0_copy
    common_variable_0_copy.source = str_0
    assert common_variable_0 == common_variable_0_copy


# Generated at 2022-06-24 17:24:03.278020
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    str_1 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_1)
    if (BaseVariable.__eq__(common_variable_0, common_variable_1)):
        pass

# Generated at 2022-06-24 17:24:07.776787
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_0)
    # assert BaseVariable.__eq__(common_variable_0, common_variable_1) == True
    dict_0 = {}
    # assert BaseVariable.__eq__(common_variable_0, dict_0) == False


# Generated at 2022-06-24 17:24:13.833689
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    base_variable_0 = CommonVariable(str_0)
    base_variable_1 = CommonVariable(str_0)
    assert base_variable_0 == base_variable_1
    str_1 = '__class__'
    base_variable_0 = CommonVariable(str_0)
    base_variable_1 = CommonVariable(str_1)
    assert not base_variable_0 == base_variable_1

# Generated at 2022-06-24 17:24:17.241566
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    class_0 = BaseVariable(str_0)
    class_1 = BaseVariable(str_0)
    assert class_0 == class_1


# Generated at 2022-06-24 17:24:20.584765
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_0)
    assert common_variable_0 == common_variable_1


# Generated at 2022-06-24 17:24:22.852918
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    base_variable_0 = BaseVariable(str_0)
    assert base_variable_0 == base_variable_0


# Generated at 2022-06-24 17:24:35.196322
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    Tests passing of key word argument 'normalize' to method _items
    """
    class CustomVariable(CommonVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, "should%sbe normalised" % ("" if normalize else " not"))]

    custom_variable_0 = CustomVariable(".x")
    frame_0 = test_case_0.__code__
    tuple_0 = custom_variable_0.items(frame_0, normalize=True)
    assert tuple_0[0][1] == "should be normalised"
    tuple_0 = custom_variable_0.items(frame_0, normalize=False)
    assert tuple_0[0][1] == "should not be normalised"


# Generated at 2022-06-24 17:24:40.459256
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initializing string variable str_0
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = inspect.currentframe()
    items = common_variable_0.items(frame_0)
    print (items)

if __name__ == "__main__":
    test_BaseVariable_items()

# Generated at 2022-06-24 17:24:47.098463
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_0)
    bool_0 = common_variable_0 == common_variable_1
    assert bool_0 is True


# Generated at 2022-06-24 17:24:50.257841
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    base_variable_0 = BaseVariable(str_0)
    common_variable_0 = CommonVariable(str_0)
    assert base_variable_0 != common_variable_0


# Generated at 2022-06-24 17:24:53.253274
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    assert BaseVariable(str_0).items(frame) == (('__name__', '__main__'),)


# Generated at 2022-06-24 17:24:56.433218
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    str_2 = 'LOCAL\t'
    common_variable_2 = CommonVariable(str_2)
    assert common_variable_1.items(common_variable_2) == str_1


# Generated at 2022-06-24 17:25:06.821047
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = ''
    common_variable_1 = CommonVariable(str_1)
    str_2 = '__name__'
    common_variable_2 = CommonVariable(str_2)
    str_3 = ''
    common_variable_3 = CommonVariable(str_3)
    class_0 = BaseVariable(str_3)
    str_4 = ''
    common_variable_4 = CommonVariable(str_4)
    str_5 = ''
    common_variable_5 = CommonVariable(str_5)
    str_6 = ''
    common_variable_6 = CommonVariable(str_6)
    in_1 = '__name__'
    main_value_0 = in_1
    str

# Generated at 2022-06-24 17:25:12.853548
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '__name__'
    base_variable_0 = CommonVariable(str_0)
    base_variable_1 = CommonVariable(str_0)
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:25:21.759511
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case where source is str_0 and frame is frame_0 and normalize is normalize_0
    str_1 = '__name__'
    frame_0 = [None, None, None]
    normalize_0 = True
    base_variable_0 = BaseVariable(str_1)
    items_0 = base_variable_0.items(frame_0, normalize_0)
    assert_equal(items_0, (), "BaseVariable.items():")


# Generated at 2022-06-24 17:25:29.259275
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    # Call __init__ method of class BaseVariable
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)

    # Call __init__ method of class BaseVariable
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    common_variable_1_result = common_variable_0.__eq__(common_variable_1)
    assert type(common_variable_1_result) == bool

    # Call __init__ method of class BaseVariable
    str_2 = '__name__'
    str_3 = 'im_class'
    common_variable_2 = CommonVariable(str_2, str_3)
    common_variable_2_result = common_variable_0.__eq__(common_variable_2)
    assert type

# Generated at 2022-06-24 17:25:40.549585
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    stack = inspect.currentframe()
    stack_items = common_variable_0.items(stack)

    assert stack_items[0][0] == "__name__", \
        "common_variable_0.items(stack) did not return __name__ for __name__"
    assert stack_items[0][1] == "'__main__'", \
        "common_variable_0.items(stack) did not return '__main__' for __name__"
    assert stack_items[1][0] == "__doc__", \
        "common_variable_0.items(stack) did not return __doc__ for __doc__"

# Generated at 2022-06-24 17:25:51.069585
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Declare variables
    str_0 = '__name__'
    int_0 = 0
    tuple_0 = ()
    tuple_1 = ()
    common_variable_0 = CommonVariable(str_0)
    base_variable_0 = common_variable_0
    common_variable_1 = CommonVariable(str_0, tuple_0)
    base_variable_1 = common_variable_1
    tuple_2 = (common_variable_0, base_variable_0, str_0, common_variable_1, base_variable_1)
    base_variable_2 = CommonVariable(str_0, tuple_1)
    common_variable_2 = base_variable_2
    # Set values
    common_variable_0.code = compile(str_0, '<variable>', 'eval')
    common_variable_

# Generated at 2022-06-24 17:26:01.380362
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import example
    from . import compat

    str_0 = '___'
    str_1 = '__main__'
    str_2 = 'a'
    str_3 = 'BaseVariable'
    str_4 = 'test_BaseVariable_items'
    str_5 = 'test_case_0'
    str_6 = 'example'
    str_7 = 'compat'
    str_8 = 'example_function'
    str_9 = 'foo'
    str_10 = '__doc__'
    str_11 = 'Example function to test with.'

    frame_0 = frame = compat.currentframe()
    source = '___ = {}'.format(str_8)
    example.eval(source, frame)
    tp_0 = type(common_variable_0)

# Generated at 2022-06-24 17:26:03.114928
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    attrs_0 = Attrs(str_0)


# Generated at 2022-06-24 17:26:12.582543
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # 1st test
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    # 2nd test
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    # 3rd test
    str_2 = '__name__'
    common_variable_2 = CommonVariable(str_2)
    # 4th test
    str_3 = '__name__'
    common_variable_3 = CommonVariable(str_3)
    # 5th test
    str_4 = '__name__'
    common_variable_4 = CommonVariable(str_4)
    # 6th test
    str_5 = '__name__'
    common_variable_5 = CommonVariable(str_5)
    # 7th test
   

# Generated at 2022-06-24 17:26:13.653635
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test with arguments: None, False
    return



# Generated at 2022-06-24 17:26:25.401985
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'test_case'
    dict_1 = {}
    dict_1['foo'] = 'bar'
    dict_1['baz'] = 'qux'
    dict_2 = {}
    dict_2['foo'] = 'bar'
    dict_2['baz'] = 'qux'
    dict_3 = {}
    dict_3['foo'] = 'bar'
    dict_3['baz'] = 'qux'
    str_1 = 'test_case'
    dict_4 = {}
    dict_4['foo'] = 'bar'
    dict_4['baz'] = 'qux'
    str_2 = 'test_case'
    dict_5 = {}
    dict_5['foo'] = 'bar'
    dict_5['baz'] = 'qux'
   

# Generated at 2022-06-24 17:26:27.505605
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)


# Generated at 2022-06-24 17:26:34.977193
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = ''
    dict_0 = dict()
    dict_1 = dict()
    dict_0['__name__'] = ''
    dict_1['__name__'] = ''
    frame_0 = utils.Frame(dict_0, dict_1)
    tuple_0 = common_variable_0.items(frame_0)
    assert all(tuple_0)
    # TODO: Add test for PY-34750
    return tuple_0

# Generated at 2022-06-24 17:26:38.505166
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = utils.Frame(None, globals(), locals())
    common_variable_0.items(frame_0) # TODO: should be called


# Generated at 2022-06-24 17:26:54.452452
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test cases for method items of class BaseVariable
    #
    #
    #         Variant 1.
    str_2 = '__name__'
    common_variable_2 = CommonVariable(str_2)
    #         Variant 2.
    str_4 = '__name__'
    str_5 = ()
    common_variable_4 = CommonVariable(str_4, str_5)
    #         Variant 3.
    str_13 = '__name__'
    str_14 = ()
    is_list_0 = [True, True, False]
    #         Variant 4.
    str_21 = '__name__'
    str_22 = ()
    is_list_1 = [True, True, True]
    #         Variant 5.
    str_29 = '__name__'
    str_30 = ()

# Generated at 2022-06-24 17:27:02.670646
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    keys_0 = ['__name__', '__doc__', '__package__', '__loader__', '__spec__', '__annotations__', '__builtins__', 'common_variable_0']
    # inputs: arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9 arg10 arg11 arg12
    # inputs: common_variable_0  keys_0
    assert 1 == 1


# Generated at 2022-06-24 17:27:06.292231
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    try:
        #fails with "Undefined variable '__name__'"
        common_variable_0.items()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:27:08.008478
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)



# Generated at 2022-06-24 17:27:20.065246
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = {
        '__name__' : 'a',
        '__doc__' : 'b',
        '__package__' : 'c',
        '__loader__' : 'd',
        '__spec__' : 'e',
        '__annotations__' : 'f',
        '__builtins__' : 'g',
        '__file__' : 'h',
        '__cached__' : 'i',
        '__docformat__' : 'j',
        '__initializing__' : 'k'
    }
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    str_2 = '__doc__'


# Generated at 2022-06-24 17:27:31.995379
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = '__name__'
    common_variable_0 = CommonVariable(str_1)
    def f(x):
        common_variable_0.items(x)
        return x
    str_2 = 'string'
    str_3 = 'string'
    int_0 = 0
    str_4 = 'string'
    int_1 = 0
    list_0 = ['b']
    dict_0 = {'b':'b'}
    class Class0:
        def __init__(self):
            self.str_1 = 'string'
        def method0(self, str_5):
            self.str_1 += str_5
    class Class1:
        def method0(self):
            return Class0()
    class Class2:
        def __init__(self):
            self

# Generated at 2022-06-24 17:27:39.976964
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print("Test for method items of class BaseVariable")
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = Frame(None)
    result = common_variable_0.items(frame_0);
    expected = [('__name__', '__main__')]
    if result != expected:
        print('Test for method items of class BaseVariable FAILED')
    else:
        print('Test for method items of class BaseVariable PASSED')


# Generated at 2022-06-24 17:27:40.955217
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()

# Generated at 2022-06-24 17:27:46.710532
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = '__name__'
    common_variable_1 = CommonVariable(str_1)
    str_2 = '__name__'
    common_variable_2 = CommonVariable(str_2)
    str_3 = '__name__'
    common_variable_3 = CommonVariable(str_3)
    tuple_0 = (common_variable_0, common_variable_1)
    str_4 = '__name__'
    common_variable_4 = CommonVariable(str_4)
    tuple_1 = (common_variable_2, common_variable_3, common_variable_4)
    tuple_2 = (tuple_0, tuple_1)

# Generated at 2022-06-24 17:27:50.931944
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    # test two similar frames
    frame_0 = frame_1 = 0
    # don't normalize the variables
    common_variable_0.items(frame_0, frame_1)
    # don't normalize the variables
    common_variable_0.items(frame_1, frame_0)


# Generated at 2022-06-24 17:28:10.962127
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 0
    int_1 = 1
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    str_3 = 'd'
    str_4 = '__name__'
    str_5 = 'str_4'
    str_6 = 'str_5'
    str_7 = 'str_6'
    str_8 = 'str_7'
    str_9 = 'str_8'
    str_10 = 'str_9'
    tuple_0 = (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)

# Generated at 2022-06-24 17:28:15.670580
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    dict_0 = {'__name__': '__main__'}
    base_variable_0 = common_variable_0.items(dict_0)
    test_0 = [common_variable_0, dict_0]
    assert test_0 == base_variable_0


# Generated at 2022-06-24 17:28:25.517431
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    str_1 = '__package__'
    str_2 = '__name__'
    str_3 = '__package__'
    str_4 = '__name__'
    str_5 = '__package__'
    str_6 = '__file__'
    str_7 = '__file__'
    str_8 = '__file__'
    str_9 = '__file__'
    str_10 = '__builtins__'
    str_11 = '__builtins__'
    str_12 = '__builtins__'
    str_13 = '__builtins__'
    str_14 = '__builtins__'
    str_15 = '__builtins__'
    str_16 = '__builtins__'

# Generated at 2022-06-24 17:28:33.786842
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    list_0 = []
    tuple_0 = (list_0,)
    list_0.append(tuple_0)
    return (common_variable_0.source, common_variable_0.code, common_variable_0._fingerprint, common_variable_0.unambiguous_source, common_variable_0.items(list_0))


# Generated at 2022-06-24 17:28:36.101642
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'a'
    common_variable_0 = BaseVariable(str_0)


# Generated at 2022-06-24 17:28:46.980734
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types

    # Declare a new class
    class TestClass:
        def test_fn(self):
            assert False
            return 42

        def __repr__(self):
            return "<pdbppTestClass>"

    NoneType = type(None)
    test_var_0 = TestClass()
    str_0 = 'test_var_0.test_fn'
    str_1 = '__name__'
    str_2 = 'sys.modules'
    common_variable_0 = CommonVariable(str_1)
    common_variable_1 = CommonVariable(str_0)
    str_3 = "local_var_0"
    common_variable_2 = CommonVariable(str_2)
    frame_0 = sys._getframe()
    # Test the items of frame_0
    result

# Generated at 2022-06-24 17:28:57.356759
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from unittest.mock import MagicMock
    str_0 = 'a'
    base_variable_0 = BaseVariable(str_0)
    sequence_0 = pycompat.imap(int, [])
    magic_mock_0 = MagicMock(return_value=sequence_0)
    magic_mock_1 = MagicMock(return_value=sequence_0)
    magic_mock_2 = MagicMock(return_value=False)
    frame_0 = Frame(magic_mock_0, magic_mock_1, magic_mock_2, '')
    assert base_variable_0.items(frame_0) == ()


# Generated at 2022-06-24 17:28:58.964741
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    assert True



# Generated at 2022-06-24 17:29:03.046879
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    base_variable_0 = BaseVariable(str_0)
    pycompat.assert_not_equal(base_variable_0.__hash__(), 0)

# Generated at 2022-06-24 17:29:12.467345
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    str_1 = '__name__'
    str_2 = '__name__'
    list_0 = []
    list_1 = []
    list_2 = []
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}

    attrs_0 = Attrs(str_0)
    assert attrs_0.items(list_0)[0][0] == str_1
    assert attrs_0.items(list_1)[0][0] == str_2
    attrs_1 = Attrs(str_0)
    assert attrs_1.items(dict_0)[0][0] == str_1
    assert attrs_1.items(dict_1)[0][0] == str_2

# Generated at 2022-06-24 17:29:37.509415
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    stray_0 = str()
    str_0 = '__name__'
    attrs_0 = Attrs(str_0)
    common_variable_0 = CommonVariable(str_0)
    test_0 = attrs_0.items(stray_0)
    common_variable_0.items(stray_0)
    assert(test_0 == [('__name__', '"__main__"')])


# Generated at 2022-06-24 17:29:44.017093
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # def __init__(self, source, exclude=()):
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    # def items(self, frame, normalize=False):
    # frame is a FrameType
    frame_0 = test_case_0.__code__.co_consts
    bool_0 = True
    list_0 = list()
    base_variable_0 = BaseVariable(str_0)
    base_variable_0.items(frame_0, bool_0)
    base_variable_0.items(frame_0, bool_0)
    base_variable_0.items(frame_0, bool_0)
    base_variable_0.items(frame_0, bool_0)

# Generated at 2022-06-24 17:29:53.823124
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    str_1 = '__init__'
    common_variable_1 = CommonVariable(str_1)
    str_2 = '__str__'
    common_variable_2 = CommonVariable(str_2)
    str_3 = '__module__'
    common_variable_3 = CommonVariable(str_3)
    str_4 = '__repr__'
    common_variable_4 = CommonVariable(str_4)
    str_5 = '__hash__'
    common_variable_5 = CommonVariable(str_5)
    str_6 = '__lt__'
    common_variable_6 = CommonVariable(str_6)
    str_7 = '__le__'
    common_variable_

# Generated at 2022-06-24 17:29:59.037858
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = None
    normalize_0 = False
    #
    try:
        common_variable_0.items(frame_0, normalize_0)
    except Exception as e:
        print('test_BaseVariable_items')
        print("Exception:", e)
        raise e


# Generated at 2022-06-24 17:30:05.863275
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['locals'] = dict_1
    dict_0['globals'] = dict_1
    dict_1['__name__'] = str_0
    dict_2 = dict()
    dict_2['f_locals'] = dict_1
    dict_2['f_globals'] = dict_1
    common_variable_0 = CommonVariable(str_0)
    common_variable_0.items(dict_2) # call BaseVariable.items(common_variable_0, dict_2)


# Generated at 2022-06-24 17:30:15.387530
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'var0'
    str_1 = 'var1'
    str_2 = 'var2'
    str_3 = 'var3'
    str_4 = 'var4'
    str_5 = 'var5'
    str_6 = 'var6'
    str_7 = 'var7'
    str_8 = 'var8'
    str_9 = 'var9'
    common_variable_0 = CommonVariable(str_0)
    common_variable_1 = CommonVariable(str_1)
    common_variable_2 = CommonVariable(str_2)
    common_variable_3 = CommonVariable(str_3)
    common_variable_4 = CommonVariable(str_4)
    common_variable_5 = CommonVariable(str_5)
    common_variable_6 = CommonVariable

# Generated at 2022-06-24 17:30:19.920076
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = test_case_0()
    common_variable_0.items(frame_0)


# Generated at 2022-06-24 17:30:29.430078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    i = 0
    # Test for case 0: str
    str_0 = '__name__'
    common_variable_0 = CommonVariable(str_0)
    # Test for case 1: str
    str_1 = '__name__'
    attrs_1 = Attrs(str_1)
    # Test for case 2: str
    str_2 = '__name__'
    keys_2 = Keys(str_2)
    # Test for case 3: str
    str_3 = '__name__'
    indices_3 = Indices(str_3)
    # Test for case 4: str
    str_4 = '__name__'
    exploding_4 = Exploding(str_4)
    # Test for case 5: str
    str_5 = '__name__'
    attrs_5 = Att

# Generated at 2022-06-24 17:30:35.672432
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    common_variable_0 = CommonVariable("__name__", "__spec__")
    expected_result_0 = None
    result_0 = common_variable_0.items(frame_0)
    assert result_0 == expected_result_0


# Generated at 2022-06-24 17:30:44.782626
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = '__name__'
    str_1 = '__doc__'
    common_variable_0 = CommonVariable(str_0)
    frame_0 = Frame(None, None, None)
    str_2 = common_variable_0.items(frame_0)
    str_3 = '__name__'
    str_4 = common_variable_0.items(frame_0)
    str_5 = '__name__'
    common_variable_1 = CommonVariable(str_5)
    frame_0 = Frame(None, None, None)
    str_6 = common_variable_1.items(frame_0)
    str_7 = '__name__'
    common_variable_2 = CommonVariable(str_7, str_1)
    frame_0 = Frame(None, None, None)