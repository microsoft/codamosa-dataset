

# Generated at 2022-06-24 17:21:31.651680
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert True
    int_0 = None
    base_variable_0 = BaseVariable(int_0, )
    assert not base_variable_0.items(None)


# Generated at 2022-06-24 17:21:33.162871
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print("Test method items of class BaseVariable\n")
    
    
    
    

# Generated at 2022-06-24 17:21:41.621417
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    file_0 = 'abc'
    data_0 = dict(b=2, c=3)
    frame_0 = utils.Frame(file_0, data_0)
    bool_0 = isinstance(data_0, Mapping)
    if bool_0:
        var_0 = Attrs(file_0)
    else:
        var_0 = Attrs(file_0)

    var_1 = var_0.items(frame_0)
    assert all((lambda var_1_i: var_1_i[0] == var_1_i[1]))(var_1)


# Generated at 2022-06-24 17:21:42.656478
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('d').__eq__(BaseVariable('d'))


# Generated at 2022-06-24 17:21:43.581944
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(0)


# Generated at 2022-06-24 17:21:52.092200
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test for method __getitem__ of class Indices(<type 'slice'>):
    int_0 = None
    base_variable_0 = Indices(int_0)
    base_variable_1 = base_variable_0[:]
    assert isinstance(base_variable_0, Indices)

# Generated at 2022-06-24 17:21:54.767427
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(None)
    indices_0.__getitem__(None)


# Generated at 2022-06-24 17:21:56.767039
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Can't find an example for this method
    assert False


# Generated at 2022-06-24 17:21:59.921039
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """ Does the method items of class BaseVariable work for the following scenarios:
    """
    # Set up test cases
    # Test case 1 - Checking that all attributes can be found in the current frame


# Generated at 2022-06-24 17:22:04.412570
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '<'
    BaseVariable.source = str_0
    str_1 = BaseVariable.source
    str_2 = '<'
    bool_0 = str_1 == str_2
    assert bool_0


# Generated at 2022-06-24 17:22:12.428729
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable("var_0",("var_1",))
    assert var_0.items("") == ()



# Generated at 2022-06-24 17:22:21.965686
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_x = 'x'
    var_X = 'X'
    var_0 = 0

    var_s = 's'
    var_t = 't'
    var_u = 'u'
    var_v = 'v'
    var_w = 'w'
    var_y = 'y'
    var_z = 'z'

    var_y0 = 'y0'
    var_z1 = 'z1'
    var_z2 = 'z2'
    var_z3 = 'z3'

    var_a = 'a'
    var_b = 'b'
    var_c = 'c'
    var_d = 'd'

    var_e0 = 'e0'
    var_e1 = 'e1'

# Generated at 2022-06-24 17:22:23.586996
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var_0 = Indices(float_0)
    var_0[0]



# Generated at 2022-06-24 17:22:28.326451
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable(source="var_2", exclude="var_1")
    float_0 = -912.08
    float_1 = var_0.__eq__(float_0)
    var_1 = BaseVariable(source="var_2", exclude="var_1")
    var_2 = var_1.__eq__(var_0)


# Generated at 2022-06-24 17:22:31.784649
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -718.308
    var_0 = needs_parentheses(float_0)
    var_1 = Indices.__getitem__(var_0, [0])


# Generated at 2022-06-24 17:22:34.370511
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = float // float
    indices_0 = Indices(float_0)
    float_1 = float // float
    indices_0[float_1]


# Generated at 2022-06-24 17:22:44.232792
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -718.308
    float_1 = float_0
    float_2 = float_1
    float_3 = float_2
    float_4 = float_3
    float_5 = float_4
    float_6 = float_5
    float_7 = float_6
    float_8 = float_7
    float_9 = float_8
    float_10 = float_9
    float_11 = float_10
    float_12 = float_11
    float_13 = float_12
    float_14 = 718.308
    float_15 = float_14
    float_16 = float_15
    float_17 = float_16
    float_18 = float_17
    float_19 = float_18
    float_20 = float_19
    float_21 = float_20

# Generated at 2022-06-24 17:22:47.384615
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    int_0 = 536633080
    indices_0 = Indices('a')
    indices_0[slice(None)]
    indices_0[slice(int_0)]


# Generated at 2022-06-24 17:22:48.511117
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass


# Generated at 2022-06-24 17:22:49.400890
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable.__eq__(Source1)


# Generated at 2022-06-24 17:23:01.836599
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def test_case_0():
        float_0 = -718.308
        float_1 = float(-0.964)
        dict_0 = dict()
        dict_0[float_1] = float_1
        dict_0[float_0] = float_0
        list_0 = list()
        list_0.append(float_1)
        list_0.append(float_0)
        list_0.append(dict_0)
        dict_0['__version__'] = '3.0.0-dev'
        dict_0['__name__'] = 'Black'
        dict_0['__doc__'] = 'Uncompromising code formatter for Python.'
        dict_0['__while'] = list_0
        dict_0['__if'] = list_0

# Generated at 2022-06-24 17:23:08.973646
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -718.308
    bool_0 = BaseVariable(float_0).__eq__(float_0)
    bool_1 = BaseVariable(float_0).__eq__(float_0)
    bool_2 = BaseVariable(float_0).__eq__(float_0)
    bool_3 = BaseVariable(float_0).__eq__(float_0)
    bool_4 = BaseVariable(float_0).__eq__(float_0)
    bool_5 = BaseVariable(float_0).__eq__(float_0)
    bool_6 = BaseVariable(float_0).__eq__(float_0)
    bool_7 = BaseVariable(float_0).__eq__(float_0)
    bool_8 = BaseVariable(float_0).__eq__(float_0)


# Generated at 2022-06-24 17:23:15.918895
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    arg_0 = 882.689
    arg_1 = -11
    arg_2 = (('code', 'compile("float_0", "", "eval")'), ('source', 'float_0'), ('exclude', '()'), ('unambiguous_source', '(float_0)'))
    ret_3 = BaseVariable.items(arg_0, arg_1)
    assert ret_3 == arg_2


# Generated at 2022-06-24 17:23:24.378630
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = pytest.test_case_0.caller
    variable = Indices()
    variable._slice = slice(0, 1)
    variable.source = 3
    variable.exclude = (1, 2, 3)
    value = variable.items(frame)

    #Test if the value is of type tuple
    assert isinstance(value, tuple)
    assert len(value) == 1

    key = value[0][0]
    assert key == '[0]'

    value = value[0][1]
    assert value == '-718.308'



# Generated at 2022-06-24 17:23:30.123194
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('sys', exclude=())
    var_1 = BaseVariable('sys', exclude=('argv',))

    with pytest.raises(NotImplementedError):
        var_0._items('sys')


# Generated at 2022-06-24 17:23:40.353628
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import reprlib
    from . import utils

    var_0 = utils.get_shortish_repr(reprlib)
    var_1 = BaseVariable(var_0)
    var_2 = BaseVariable(var_0, exclude=tuple())
    var_3 = BaseVariable(var_0, exclude=())

    var_4 = utils.get_shortish_repr(reprlib.__name__)
    var_5 = BaseVariable(var_4)
    var_6 = BaseVariable(var_4, exclude=tuple())
    var_7 = BaseVariable(var_4, exclude=())

    assert var_1 == var_1
    assert var_1 == var_2
    assert var_2 == var_3
    assert var_3 == var_1

# Generated at 2022-06-24 17:23:45.347826
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -718.308
    BaseVariable_0 = BaseVariable(float_0)
    assert BaseVariable_0.__eq__(BaseVariable_0) == True
    assert BaseVariable_0.__eq__(BaseVariable_0) == True


# Generated at 2022-06-24 17:23:53.989616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -718.308
    float_1 = 0.1
    dict_0 = dict()
    dict_0[float_1] = float_0
    str_0 = str()
    var_0 = CommonVariable(str_0, dict_0)
    var_1 = CommonVariable(float_0, dict_0)
    dict_1 = dict()
    dict_1[float_0] = float_1
    dict_2 = dict()
    dict_2 = dict(dict_2, **dict_1)
    dict_3 = dict()
    dict_3[float_0] = float_1
    dict_4 = dict()
    dict_4 = dict(dict_2, **dict_3)
    dict_5 = dict()

# Generated at 2022-06-24 17:23:57.404781
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert test_BaseVariable___eq__.__name__ == 'test_BaseVariable___eq__'
    var_0 = BaseVariable(0.0)
    var_1 = BaseVariable(0.0)
    var_2 = BaseVariable(0.0)
    assert var_0 == var_1
    assert var_1 == var_2
    var_3 = BaseVariable((0.0))
    assert not var_0 == var_3



# Generated at 2022-06-24 17:24:00.215327
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case for method items of class BaseVariable
    # TODO: Test case for method items of class BaseVariable
    # Code
    pass


# Generated at 2022-06-24 17:24:13.428431
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert not (BaseVariable(float_0) == None)
    assert not (BaseVariable(float_0, float_0) == None)
    assert not (BaseVariable(None) == float_0)
    assert not (BaseVariable(None, float_0) == float_0)


# Generated at 2022-06-24 17:24:16.648404
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('items begin')
    try:
        pass
    except AssertionError:
        pass
    finally:
        print('items end')


# Generated at 2022-06-24 17:24:20.646679
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable_0 = BaseVariable("var_0")
    BaseVariable_1 = BaseVariable("var_0")
    var_0 = BaseVariable_0._fingerprint
    var_1 = BaseVariable_1._fingerprint
    var_2 = BaseVariable_0 == BaseVariable_1


# Generated at 2022-06-24 17:24:26.211615
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -718.308
    bool_1 = bool
    BaseVariable_8, bool_2 = bool, bool
    BaseVariable_9, bool_3 = BaseVariable_8(float_0, bool_1), bool_2(False)
    BaseVariable_10, bool_4 = BaseVariable_8(float_0, bool_1), bool_2(False)
    BaseVariable_11, bool_5 = BaseVariable_9 == BaseVariable_10, bool_4
    bool_6 = bool_5
    assert_true(bool_6)


# Generated at 2022-06-24 17:24:28.824491
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Keys('x', ('a', 'b'))
    var_1 = {'a': 1, 'b': 2, 'c': 3}
    var_2 = var_0.items(var_1)
    assert var_2 == [('x[a]', '1'), ('x[c]', '3')]


# Generated at 2022-06-24 17:24:35.977087
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from pycallgraph.lib.pycompat27 import get_arg_values
    from pycallgraph.lib.pycompat27 import get_func_code
    from pycallgraph.lib.pycompat27 import make_cell
    from pycallgraph import __init__
    from pycallgraph import config
    from pycallgraph import globals
    from pycallgraph import lib
    from pycallgraph import plugin
    from pycallgraph import recorder
    from pycallgraph import utils
    from pycallgraph import viewer

    int_0 = 10
    str_0 = globals.BUILTIN_MODULES
    str_1 = globals.BUILTIN_MODULE_NAME
    str_2 = globals.REVISION
    str_3 = globals.VERSION
    str_4 = globals.VERSION_INFO


# Generated at 2022-06-24 17:24:38.074725
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Variables initialization
    BaseVariable_0 = BaseVariable(x, None)

    assert(BaseVariable_0 == BaseVariable_0)


# Generated at 2022-06-24 17:24:40.905317
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Indices('adf').__eq__(Indices('adf')) == True
    assert Indices('adf').__eq__(Indices('asdf')) == False


# Generated at 2022-06-24 17:24:48.540866
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -718.308
    # Test True branch
    variable_0 = bool
    variable_1 = bool
    variable_0 = variable_1
    assert variable_0 == variable_1
    # Test False branch
    variable_0 = float_0
    variable_1 = bool
    variable_0 = variable_1
    assert not(variable_0 == variable_1)
    # Test False branch
    variable_0 = float_0
    variable_1 = bool
    variable_0 = variable_1
    assert not(variable_0 == variable_1)


# Generated at 2022-06-24 17:24:55.022206
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -718.308
    result = BaseVariable(''.join(map(chr, [40, 60, 39, 71, 47, 39, 65, 75, 39, 58, 41, 46, 69])), ''.join(map(chr, [94, 58, 39, 75, 39, 60, 47, 39, 71, 47, 41, 94]))).items(float_0)
    assert isinstance(result, tuple)



# Generated at 2022-06-24 17:25:10.774277
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_1 = -718.308
    var_1 = needs_parentheses(float_1)
    frame_2 = {
        'float_0': -718.308
    }
    var_2 = BaseVariable(float_1)
    print(var_2.items(frame_2))


# Generated at 2022-06-24 17:25:18.951176
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import testcase
    from xml.etree.ElementTree import Element
    from io import StringIO
    from traceback import FrameSummary
    from bdb import Breakpoint
    from codeop import CommandCompiler
    from sys import getrecursionlimit
    from subprocess import PIPE
    from types import ModuleType
    from pstats import Stats
    from warnings import catch_warnings
    from timeit import Timer
    from os import access
    from pathlib import Path
    from csv import writer
    from json import loads
    from ast import parse
    from mmap import mmap
    from decimal import Decimal
    from datetime import datetime
    from tempfile import mkdtemp
    from random import random
    from pstats import Profile
    from functools import partial
    from collections import OrderedDict
    from calendar import time

# Generated at 2022-06-24 17:25:26.297448
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = sys._getframe(1)

    var_0 = Attrs("a")
    var_1 = var_0.items(frame)

    var_2 = Attrs("a.b")
    var_3 = var_2.items(frame)

    var_4 = Attrs("a.b.c")
    var_5 = var_4.items(frame)

    var_6 = Attrs("a.b.c.d")
    var_7 = var_6.items(frame)

    var_8 = Attrs("a.b[1]")
    var_9 = var_8.items(frame)

    var_10 = Attrs("a.b[1].c")
    var_11 = var_10.items(frame)

    var_12 = Keys("a.b[1]")


# Generated at 2022-06-24 17:25:30.215162
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'y'
    float_0 = -718.308
    instance_0 = BaseVariable(float_0)
    assert instance_0.items(['']) == []


# Generated at 2022-06-24 17:25:35.173948
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    stack = [{'f_locals': {'float_0': -718.308}}]
    var_0 = BaseVariable()
    var_0.source = 'float_0'
    var_0.exclude = ()
    var_1 = utils.StackVar()
    var_1.obj = stack
    var_1.idx = 0
    var_0.items(var_1)

# Generated at 2022-06-24 17:25:38.575445
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import pytest

    assert inspect.currentframe().f_lineno == pytest.get_linenumber()

    base_variable_0 = Attrs(float_0)
    var_1 = base_variable_0.items(sys._getframe(0))

    assert var_1 == ('<arg>', '(-718.308,)')


# Generated at 2022-06-24 17:25:41.013487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    b = BaseVariable("pyauto")
    assert b.items("pyauto") == tuple()



# Generated at 2022-06-24 17:25:47.835502
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_1 = 472.857
    tuple_0 = (float_1,)
    @utils.curry
    def items_0(exp, var):
        return var.items(exp.frame)
    generator_0 = (tuple_0[i_0] for i_0 in range(len(tuple_0)))
    int_1 = main(items_0, generator_0)


# Generated at 2022-06-24 17:26:00.583705
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = 523.74
    float_1 = -7.1514
    str_1 = 'eb*$dD=p)^(w8'
    dict_0 = dict()
    dict_1 = dict(zip([float_0, float_1], [float_0, float_1]))
    dict_2 = dict(zip(['f', '+s`h'], [float_1, float_0]))
    dict_2['0y '] = dict_1
    dict_2['aL*'] = dict_0
    dict_1['g{u'] = dict_0
    dict_1['X9,'] = dict_2
    dict_2['aL*'] = dict_0
    dict_1['X9,'] = dict_2

# Generated at 2022-06-24 17:26:03.405020
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Keys('x')
    assert var_0.items({'x': dict(a=3)}) == [('x', 'dict'), ('x[a]', '3')]


# Generated at 2022-06-24 17:26:27.423673
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame = pycompat.frame()
    var_0 = Attrs('var_0')
    var_0.items(test_frame)

# Generated at 2022-06-24 17:26:28.798443
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = -718.308
    var_1 = eval(var_0)

# Generated at 2022-06-24 17:26:38.705846
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -718.308
    float_1 = float_0 + float_0
    list_0 = [float_0, float_0, float_0, float_1, float_1]
    list_1 = list_0.copy()
    list_0.append(float_1)
    list_0.remove(float_1)
    class_0 = attrs(base_attr_0=float_0, base_attr_1=float_1, base_attr_2=float_1, cls_attr_0=float_1, cls_attr_1=float_0, cls_attr_2=float_1)
    class_0.base_attr_1 = float_0
    class_0.base_attr_2 = class_0.base_attr_1

# Generated at 2022-06-24 17:26:52.209637
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    arg_0 = set(['var_0', 'var_1', 'self', 'test_BaseVariable_items', 'test_case_0', 'var_2', 'var_3'])
    var_0 = set([])
    var_1 = set(['var_0', 'var_1', 'self', 'test_BaseVariable_items', 'test_case_0', 'var_2', 'var_3'])

# Generated at 2022-06-24 17:26:54.660808
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = sys._getframe()
    assert frame
    v = BaseVariable('float_0')
    v.items(frame)


# Generated at 2022-06-24 17:27:06.289536
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import dummy_with_vars
    from .utils import dummy_with_vars2

    assert Attrs('foo').items(dummy_with_vars) == [('foo.bar', 'None'),
                                                  ('foo.baz', '2')]

    assert Attrs('foo', exclude='bar').items(dummy_with_vars) == [('foo.baz', '2')]

    assert Keys('foo').items(dummy_with_vars) == [('foo["bar"]', 'None'),
                                                 ('foo["baz"]', '2')]

    assert Keys('foo', exclude='bar').items(dummy_with_vars) == [('foo["baz"]', '2')]


# Generated at 2022-06-24 17:27:09.322971
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert isinstance(BaseVariable(float_0), BaseVariable)
    assert len(BaseVariable(float_0, exclude=()).items(test_case_0())) == 2


# Generated at 2022-06-24 17:27:15.932700
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_var_0 = stack.Frame(frame_0)
    var_0 = Attrs('Attrs')
    var_1 = var_0.items(frame_var_0)
    var_2 = (Attrs, 'Attrs')
    assert (var_1 == var_2)


# Generated at 2022-06-24 17:27:19.998981
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Attrs('abc')
    var_1 = var_0.items({"abc": 123})
    assert var_1 == (('abc', '123'),)



# Generated at 2022-06-24 17:27:22.704520
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Keys('request.GET')
    var_0.items(None)


# Generated at 2022-06-24 17:28:10.921616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = needs_parentheses(1.707)
    var_1 = needs_parentheses(0.838)


# Generated at 2022-06-24 17:28:14.600721
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1 of 3
    attrs = Attrs('e')
    frame = None
    normalize = False
    result = attrs.items(frame, normalize)
    assert result == None

    # Test 2 of 3
    attrs = Attrs('e')
    frame = None
    normalize = True
    result = attrs.items(frame, normalize)
    assert result == None

    # Test 3 of 3
    attrs = Attrs('e')
    frame = None
    normalize = False
    result = attrs.items(frame, normalize)
    assert result == None



# Generated at 2022-06-24 17:28:17.453229
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('').items({'abc': abc}).__str__() == "[('', 'abc')]"
    assert BaseVariable('').items({'abc': abc}, normalize=True).__str__() == "[('', 'abc')]"


# Generated at 2022-06-24 17:28:27.932027
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = {}
    dict_0['a'] = 'b'
    dict_0['c'] = 'd'
    dict_0['e'] = 'f'

    float_0 = float(dict_0.pop())
    list_0 = [float_0, dict_0]

    var_0 = Keys(list_0)
    for var_1 in var_0.items(2):
        print(var_1)
    var_0 = Indices(list_0)
    for var_1 in var_0.items(2):
        print(var_1)
    var_0 = Attrs(list_0)
    for var_1 in var_0.items(2):
        print(var_1)
    var_0 = Exploding(list_0)

# Generated at 2022-06-24 17:28:31.464729
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Case 1
    float_0 = -718.308
    baseVariable_0 = BaseVariable("val")
    baseVariable_0.items("", float_0)



# Generated at 2022-06-24 17:28:34.001779
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = None
    exclude = None
    self = BaseVariable(source, exclude)
    frame = None
    normalize = None
    items = self.items(frame, normalize)
    assert items == ()


# Generated at 2022-06-24 17:28:37.348638
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Try to call method items of class BaseVariable with dummy data
    var_0 = BaseVariable('p')
    var_0.items('')

# Generated at 2022-06-24 17:28:48.139738
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -997.224
    float_1 = float(3.700000)
    float_2 = -9.063
    float_3 = float(-2.700000)
    float_4 = 2.029
    float_5 = -56.481
    float_6 = -0.981
    float_7 = 36.758
    float_8 = -3.847
    float_9 = float(2.700000)
    float_10 = float(-2.200000)
    float_11 = -68.292
    float_12 = 55.204
    float_13 = float(-6.800000)
    float_14 = -24.945
    float_15 = float(-6.500000)
    float_16 = float(4.000000)

# Generated at 2022-06-24 17:28:58.550447
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 5
    var_1 = 7.5
    var_2 = "__"
    var_3 = "xyz"
    var_4 = "abc"
    var_5 = -768.456
    var_6 = 9.79
    var_7 = "xyz"
    var_8 = '__'
    var_9 = "__"
    var_10 = '__'
    var_11 = 9.79
    var_12 = "__"
    var_13 = -768.456
    var_14 = "xyz"
    var_15 = "abc"
    var_16 = var_1
    var_17 = var_7
    var_18 = -738.432
    var_19 = var_9
    var_20 = var_10

# Generated at 2022-06-24 17:29:01.469105
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable(9.0).items(None) == (('9.0', '9.0'),)



# Generated at 2022-06-24 17:30:42.985456
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = False
    base_variable = BaseVariable(var_0)
    result = base_variable.items(frame, normalize)
    assert result == None


# Generated at 2022-06-24 17:30:48.230171
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()
    v = BaseVariable('hello')
    assert v.items({'hello': 'world'}) == [('hello', "'world'")]
    assert v.items({'hello': 'world'}, normalize=True) == [('hello', '"world"')]


# Generated at 2022-06-24 17:30:50.817845
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = 1.4959171816937388
    var_0 = BaseVariable(float_0)
    


# Generated at 2022-06-24 17:30:55.717679
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Case 0
    float_0 = -718.308
    str_0 = 'C#'
    float_1 = float_0
    int_0 = 718
    var_0 = Attrs(float_1, exclude=str_0)
    var_0.items(int_0)


# Generated at 2022-06-24 17:31:06.775093
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    globals_0 = {}
    locals_0 = {}
    var_0 = BaseVariable
    var_1 = var_0.__init__('test')
    var_2 = var_0.__init__(
        'test',
    )
    var_3 = var_0.__init__(
        'test',
        exclude='test',
    )
    var_4 = var_0.__init__(
        'test',
        exclude='test',
    )
    var_5 = var_0.items('test')
    var_6 = var_0.__init__(
        'test',
        exclude='test',
    )
    var_7 = var_0.items('test')

# Generated at 2022-06-24 17:31:08.390300
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pdb
    var_0 = BaseVariable(0, 0)
    var_0.items(0, 0)



# Generated at 2022-06-24 17:31:16.385521
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frame_utils
    from . import mock_module

    with mock_module.mock(frame_utils) as frame_utils_module:
        frame_utils_module.eval_in_frame.side_effect = [1, 2]
        frame = frame_utils_module.get_current_frame()

    source = 'x'
    float_0 = -718.308
    float_1 = -718.308
    float_2 = -718.308
    float_3 = -718.308
    float_4 = -718.308
    float_5 = -718.308
    float_6 = -718.308
    float_7 = -718.308
    float_8 = -718.308
    float_9 = -718.308
    float_10 = -718.308