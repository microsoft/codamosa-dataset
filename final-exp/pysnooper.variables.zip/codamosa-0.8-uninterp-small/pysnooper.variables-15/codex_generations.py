

# Generated at 2022-06-24 17:21:44.539934
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'z'
    bytes_1 = b'\xb2\x01\xcf\xea\x06\x97\x8e\xc0\x82\x98\xcc\xfc\xa2\x02\xef\x00\x97\x9e\xbe\xd5\x83\xac\x81\x8b\x00\xec\xce\xd9\x15\xba\x12`\xa7\x0e\x74\xf2\xbb\x17\x9f\x0f'
    base_variable_0 = BaseVariable(bytes_0)
    base_variable_1 = BaseVariable(bytes_1)
    # Assertion
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:21:46.805970
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(b'\x83', [])
    assert indices_0[slice(None)] == Indices(b'\x83', [])


# Generated at 2022-06-24 17:21:57.400959
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    bytes_1 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    bytes_2 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)
    base_variable_1 = BaseVariable(bytes_1)
    assert not base_variable_0.__eq__(base_variable_1)


# Generated at 2022-06-24 17:22:06.943014
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    byte_0 = b'\x88\xac\x0e\xf9\xdc\x1f\xd3\x03\xff\xb3\x8c3\xab\xe9\x9a\xdc\x84\xcd\x90\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    base_variable_0 = BaseVariable(byte_0)

# Generated at 2022-06-24 17:22:12.077006
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)
    frame_0 = None
    try:
        frame_0.f_globals
    except:
        try:
            result = base_variable_0.items(frame_0)
            assert type(result) == tuple
        except:
            assert False
    else:
        assert True



# Generated at 2022-06-24 17:22:18.365614
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """Test case for BaseVariable.items"""
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)
    assert base_variable_0(bytes_0)


# Generated at 2022-06-24 17:22:22.940322
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)
    base_variable_1 = BaseVariable(bytes_0)
    assert base_variable_0 == base_variable_1


# Generated at 2022-06-24 17:22:27.402056
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    source_0 = bytes_0
    result_0 = BaseVariable(source_0).items(utils.DummyFrame())
    expected_0 = ()


# Generated at 2022-06-24 17:22:41.758534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)

# Generated at 2022-06-24 17:22:47.629549
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    variable_0 = BaseVariable(bytes_0)
    s = set([])
    assert variable_0.items() == s


# Generated at 2022-06-24 17:22:55.848807
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bytes_0 = b'\x04\x96\xad\xc1\x14\x87\x19\xf0'
    base_variable_0 = BaseVariable(bytes_0)


# Generated at 2022-06-24 17:23:01.202049
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    bytes_1 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04\x83x\xe0k\x80{\xda\x08'
    t = BaseVariable.__eq__(None, None)
    t = BaseVariable.__eq__(bytes_0, None)
    t = BaseVariable.__eq__(None, bytes_0)
    t = BaseVariable.__eq__(bytes_0, bytes_0)
    t = BaseVariable.__eq__(bytes_0, bytes_1)


# Generated at 2022-06-24 17:23:06.327553
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    indices_0 = Indices(bytes_0)
    indices_1 = indices_0[0:4]


# Generated at 2022-06-24 17:23:11.676342
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class UnittestException(Exception):
        def __init__(self):
            pass
    # Test code
    class UnittestBaseVariable_items(BaseVariable):
        def __init__(self):
            self.source = 'test_source'
            self.code = compile(self.source, '<variable>', 'eval')
            self.exclude = ()
        def _items(self, key, normalize):
            if key == 'normalize':
                return normalize
            else:
                raise UnittestException()
    UnittestBaseVariable_items_0 = UnittestBaseVariable_items()
    assert UnittestBaseVariable_items_0.items('normalize')

# Generated at 2022-06-24 17:23:22.420405
# Unit test for method __getitem__ of class Indices

# Generated at 2022-06-24 17:23:25.303967
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable.__eq__()
    var_1 = test_case_0()
    assert var_0 == var_1


# Generated at 2022-06-24 17:23:30.233585
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    lst_0 = [bytes_0]
    dict_0 = dict(zip(lst_0, lst_0))
    int_0 = 0x7f
    base_variable_0 = BaseVariable(bytes_0, dict_0)
    base_variable_0.items(int_0)


# Generated at 2022-06-24 17:23:36.977148
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    bytes_1 = b'jF\x02\xc0\xab'
    base_variable_0 = BaseVariable(bytes_0)
    base_variable_1 = BaseVariable(bytes_1)
    assert base_variable_0.__eq__(base_variable_1) == False


# Generated at 2022-06-24 17:23:41.276119
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_0 = BaseVariable(bytes_0)
    bytes_0 = b'\x83x\xe0k\x80{\xda\x08\xa6\x04'
    base_variable_1 = BaseVariable(bytes_0)
    if base_variable_1.__eq__(base_variable_0):
        pass
    else:
        sys.exit(1)


# Generated at 2022-06-24 17:23:49.161098
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bytes_0 = b'\x83x\xe0\x00\x00\x00k\x00\x00\x00{\xda\x08 \x00\xa6\x04'
    indices_0 = Indices(bytes_0)
    slice_0 = slice(None)
    indices_0.__getitem__(slice_0)


# Generated at 2022-06-24 17:23:58.160458
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    case_0 = BaseVariable(source = 'frame')
    case_1 = BaseVariable(source = 'frame', exclude = ())
    case_2 = BaseVariable(source = 'frame', exclude = ())
    case_3 = BaseVariable(source = 'frame', exclude = ())
    case_4 = BaseVariable(source = 'frame', exclude = ())
    assert(case_0 == case_1)
    assert(case_2 == case_3)
    assert(case_3 == case_4)


# Generated at 2022-06-24 17:24:07.131818
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_1 = "a.b"
    str_2 = 'c.d'
    obj_0 = BaseVariable(str_1, str_2)
    if obj_0.items(test_case_0):
        raise Exception("Attrs.__init__() should raise an error with the following code if arg_1 is not an instance of code")
    obj_1 = Attrs(str_1, str_2)
    if obj_1.items(test_case_0):
        raise Exception("Attrs.__init__() should raise an error with the following code if arg_1 is not an instance of code")
    str_3 = 'frame'
    str_4 = 'normalize'
    obj_2 = Attrs(str_1, str_2)

# Generated at 2022-06-24 17:24:08.165735
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_1 = 'normalize'


# Generated at 2022-06-24 17:24:11.755656
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable(1)
    b = BaseVariable(1)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    assert(a == b)


# Generated at 2022-06-24 17:24:15.926672
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('normalize')
    # should not raise any exception
    var1.__eq__(var1)
    # should not raise any exception
    var1.__eq__(var1.source)


# Generated at 2022-06-24 17:24:17.138725
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    pass



# Generated at 2022-06-24 17:24:19.930897
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_0)
    assert var_0.__eq__(var_1) == True


# Generated at 2022-06-24 17:24:27.459749
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # def __init__(self, source, exclude=())
    #     self.source = source
    #     self.exclude = utils.ensure_tuple(exclude)
    #     self.code = compile(source, '<variable>', 'eval')
    #     if needs_parentheses(source):
    #         self.unambiguous_source = '({})'.format(source)
    #     else:
    #         self.unambiguous_source = source
    # def __eq__(self, other):
    #     return (isinstance(other, BaseVariable) and
    #                                    self._fingerprint == other._fingerprint)
    # @property
    # def _fingerprint(self):
    #     return (type(self), self.source, self.exclude)
    var_0 = BaseVariable

# Generated at 2022-06-24 17:24:29.231034
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    keys_0 = Indices(str_0)
    pass

# Generated at 2022-06-24 17:24:32.460741
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'normalize'
    str_1 = 'frame'
    str_2 = 'source'
    e = test_case_0()
    c = BaseVariable(str_0)
    assert c.items(str_1, str_2) == ()

# Generated at 2022-06-24 17:24:42.751490
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    #[1, 2, 3, 4, 5, 6, 7][None:1]
    indices = Indices("Indices")
    slice = slice(None, 1, 1)
    indices = indices.__getitem__(slice)
    assert indices.exclude is None
    assert indices.source == "Indices"

# Generated at 2022-06-24 17:24:44.541506
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None).__eq__(BaseVariable(None))


# Generated at 2022-06-24 17:24:48.984494
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Get a frame and an instance of the class
    frame = sys._getframe()
    instance = BaseVariable(pycompat.ensure_text(frame))

    # Display the default value of the exclude parameter in the result
    result = instance.items(frame)
    assert result == (), result



# Generated at 2022-06-24 17:24:58.290923
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_func():
        a = [1,2,3]
        b = {'key1':1, 'key2':2}
        c = [{'key1':1, 'key2':2}, {'key1':3, 'key2':4}]
        d = 'test'
        e = 10
        f = [1,2,3,4,5]
        g = [1,2,3,4,5]
        h = [1,2,3,4,5]
        i = [1,2,3,4,5]
        j = [1,2,3,4,5]
        k = 0.0001
        l = '1'
        m = [1,2,3,4,5]
        n = [1,2,3,4,5]
       

# Generated at 2022-06-24 17:25:03.604745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    text_0 = None
    data_0 = ()
    frame_0 = None

    temp_0 = BaseVariable(text_0, data_0).items(frame_0)
    assert isinstance(temp_0, tuple), \
        "Expected type 'tuple', got {0!r}.".format(type(temp_0))


# Generated at 2022-06-24 17:25:12.359448
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test that the method returns the empty tuple if
    # an exception occurs during the evaluation of the expression.
    none_source_value = None
    none_variable = BaseVariable(none_source_value)

    int_0 = 0
    int_0_tuple = (int_0, int_0)

    # Test that the method returns a tuple containing the expression as a key
    # and the corresponding value as a value.
    list_variable = BaseVariable(int_0_tuple)
    list_variable_items = list_variable.items(int_0, normalize=True)

    # Test that the key of the tuple is equal to the source of the variable.
    assert list_variable_items[0][0] == int_0_tuple
    # Test that the value of the tuple is equal to the evaluation of the
    # expression

# Generated at 2022-06-24 17:25:15.742878
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Create BaseVariable instances
    var_0 = BaseVariable(source='s', exclude=())
    var_1 = BaseVariable(source='s', exclude=())

    # Check if var_0 equals to var_1
    print(var_0 == var_1)


# Generated at 2022-06-24 17:25:23.538338
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Attrs(CommonVariable):
        def _keys(self, main_value):
            return itertools.chain(
                getattr(main_value, '__dict__', ()),
                getattr(main_value, '__slots__', ())
            )

        def _format_key(self, key):
            return '.' + key

        def _get_value(self, main_value, key):
            return getattr(main_value, key)

    assert Attrs('source') == Attrs('source')


# Generated at 2022-06-24 17:25:25.907499
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    int_0 = Indices(None, ())
    int_0[0:]

test_case_0()

# Generated at 2022-06-24 17:25:36.157229
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types

    var_0 = Var(0)
    var_1 = Var(1)
    var_2 = Var(2)
    var_3 = Var(3)

    func_0 = lambda: None
    frame_0 = sys._getframe()
    frame_1 = inspect.getouterframes(frame_0)[1][0]
    
    # Test case for other frame
    assert var_1.items(frame_1) == (('1', '1'),)
    assert var_2.items(frame_1) == (('2', '2'),)
    assert var_3.items(frame_1) == (('3', '3'),)

    # Test case for the same frame
    assert var_0.items(frame_0) == (('0', '0'),)


# Generated at 2022-06-24 17:25:49.318383
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import numpy as np
    a = np.array([1, 2, 3], dtype=np.uint8)
    var = Attrs('a')
    result = var.items(a)
    assert result == [('a', 'array([1, 2, 3])')]


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-24 17:25:53.012111
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Test methods
if __name__ == '__main__':
    test_case_0()  # execute only one test case

# Generated at 2022-06-24 17:26:03.003411
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    par_0 = None
    par_1 = None
    var_0 = BaseVariable(par_0, par_1)
    var_1 = BaseVariable(par_0, par_1)
    var_2 = BaseVariable(par_0, par_1)
    var_3 = BaseVariable(par_0, par_1)
    var_4 = BaseVariable(par_0, par_1)
    var_5 = BaseVariable(par_0, par_1)
    var_6 = BaseVariable(par_0, par_1)
    par_2 = None
    par_3 = None
    var_7 = BaseVariable(par_2, par_3)
    par_4 = None
    par_5 = ()
    var_8 = BaseVariable(par_4, par_5)
    var_9

# Generated at 2022-06-24 17:26:09.581350
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable(str).items(str) == ('',)
    assert BaseVariable('int').items(str) == ('int',)
    assert BaseVariable('str').items('str') == ('str',)
    assert BaseVariable('str').items(str) == ('str',)
    assert BaseVariable('int').items('int') == ('int',)
    assert BaseVariable('int').items(int) == ('int',)


# Generated at 2022-06-24 17:26:11.254654
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
        var_0 = BaseVariable('x')
        var_1 = BaseVariable('x')
        assert var_0 == var_1


# Generated at 2022-06-24 17:26:13.797195
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_4 = BaseVariable('var_0', ('var_1', ))
    var_5 = BaseVariable('var_0', ('var_1', ))

    assert(var_4 == var_5)


# Generated at 2022-06-24 17:26:25.561394
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_1 = {}
    str_1 = 'key'
    dict_1[str_1] = 'value'
    dict_1['other'] = 'other_value'
    dict_1['and_another'] = 'and_another_value'
    dict_1['and_another_value'] = 'and_another_value'
    dict_1['and_another_value_value'] = 'and_another_value_value'
    dict_1['and_another_value_value_value'] = 'and_another_value_value_value'
    dict_1['and_another_value_value_value_value'] = 'and_another_value_value_value_value'
    assert((dict_1['and_another'] == 'and_another_value') == True)

# Generated at 2022-06-24 17:26:33.522067
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = None
    var_0 = BaseVariable(int_0)

    # test that the special attribute __eq__ is a function
    assert callable(var_0.__eq__), "BaseVariable.__eq__ is not callable, where BaseVariable=%s" % (repr(var_0),)
    # test that the __defaults__ tuple of the __eq__'s function is empty
    assert var_0.__eq__.__defaults__ == (), "BaseVariable.__eq__ has __defaults__, where BaseVariable=%s" % (repr(var_0),)
    # test that the function __eq__ returns the expected result
    assert var_0.__eq__(int_0)
    assert not var_0.__eq__(int_0)


# Generated at 2022-06-24 17:26:42.064673
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 0
    str_1 = '0'
    var_0 = needs_parentheses(int_0)
    try :
        var_1 = compile(str_1, '<variable>', 'eval').co_code
        var_2 = eval(var_1, {}, dict(var_0))
    except Exception as e :
        raise utils.Unreachable()



# Generated at 2022-06-24 17:26:46.593879
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = NeedsParentheses(None)
    var_1 = needs_parentheses(None)
    var_2 = var_0.items(None)
    var_3 = var_0.items(None, None)


# Generated at 2022-06-24 17:27:10.585179
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import _utils
    from .pycompat import is_text, PY2
    from .utils import _get_frames
    from .variable import BaseVariable
    from .pycompat import is_text, PY2
    from .utils import _get_frames
    from .variable import BaseVariable
    from .utils import _get_frames
    from .pycompat import is_text, PY2
    from .variable import BaseVariable
    var_0 = BaseVariable(source = 0, exclude = ())
    var_1 = None
    var_2 = var_0 == var_1
    var_0 = BaseVariable(source = '', exclude = ())
    var_1 = None
    var_2 = var_0 == var_1
    var_3 = BaseVariable(source = '', exclude = ())

# Generated at 2022-06-24 17:27:12.082549
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('a', exclude='b')
    var_1 = BaseVariable('a', exclude='b')
    if not (var_0 == var_1):
        raise AssertionError


# Generated at 2022-06-24 17:27:16.533483
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dct_0 = {}
    ind_0 = 0
    var_0 = Attrs(dct_0, ind_0)
    var_1 = var_0.items(dct_0, ind_0)


# Generated at 2022-06-24 17:27:23.534111
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test variables currently only created in this scope, because 
    # scope of variables created in the scope of the function must be the function
    # scope, which is not what we want, i.e. test_0 variable would be
    # visible in the scope of function test_BaseVariable_items and could thus
    # influence other tests, which is not desired.
    test_0 = None
    assert list(Keys('test_0').items({'test_0':test_0})) == [('test_0', None)]

# Generated at 2022-06-24 17:27:30.607234
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('1')
    var_1 = BaseVariable('1')
    var_2 = BaseVariable('2')
    var_3 = BaseVariable('1', exclude=False)
    var_4 = BaseVariable('1', exclude=())
    assert var_0 == var_1
    assert not var_0 == var_2
    assert var_0 == var_3
    assert var_0 == var_4


# Generated at 2022-06-24 17:27:34.742817
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = BaseVariable(source = "i")
    int_1 = BaseVariable(source = "i", exclude = str())
    assert int_0.__eq__(int_1)


# Generated at 2022-06-24 17:27:42.831521
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Setup
    int_0 = None
    # AssertionError: assert 'x' == 'x'
    assert 'x' == 'x'


    # Setup
    int_1 = None
    # AssertionError: assert 'x' == 'x'
    assert 'x' == 'x'


    # Setup
    int_2 = None
    # AssertionError: assert 'x' == 'x'
    assert 'x' == 'x'


    # Setup
    int_3 = None
    # AssertionError: assert 'x' == 'x'
    assert 'x' == 'x'




# Generated at 2022-06-24 17:27:51.652799
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test values of variables
    int_0 = 10
    float_0 = 0.0
    str_0 = "test_string"

    # test values of eval()
    int_1 = eval('10')
    float_1 = eval('0.0')
    str_1 = eval("'test_string'")

    # test values of TypeError
    int_2 = eval('1e0')
    float_2 = eval('1.e0')
    str_2 = eval("'test_string'")

    # test values of eval()
    int_3 = eval('1e0 + 1')
    float_3 = eval('1.e0 + 1')
    str_3 = eval("'test_string' + '1'")

## EXPLODING VARIABLE TESTS
    # test values of

# Generated at 2022-06-24 17:27:59.149490
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for simple case
    var_0 = BaseVariable('f_lasti')
    var_0.items(explode=True, exclude=['f_back'])

    # Test for edge case
    var_0 = BaseVariable('f_locals')
    var_0.items(explode=True, exclude=['f_back'])

    # Test for edge case
    var_0 = BaseVariable('f_lineno')
    var_0.items(explode=True, exclude=['f_back'])


# Generated at 2022-06-24 17:28:06.608747
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = Attrs('test')
    assert var.items({'test':0}) == [('test', '0')]
    var = Attrs('test', exclude = ('__class__', '__name__'))
    assert var.items({'test':0}) == [('test', '0')]
    assert var.items({'test':{'abc':'def'}}) == [('test', "{'abc': 'def'}"), ('test.abc', 'def')]


# Generated at 2022-06-24 17:28:20.697382
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import pycompat
    if not isinstance(pycompat.abc, pycompat.string_types):
        assert BaseVariable(1) != BaseVariable(1)

# Generated at 2022-06-24 17:28:29.080926
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    Attrs_0 = Attrs('Attrs_0')
    assert list(Attrs_0.items(None)) == [('Attrs_0', 'None')]
    Attrs_1 = Attrs('Attrs_1')
    assert list(Attrs_1.items(None)) == [('Attrs_1', 'None')]
    Attrs_2 = Attrs('Attrs_2')
    assert list(Attrs_2.items(None)) == [('Attrs_2', 'None')]
    Attrs_3 = Attrs('Attrs_3')
    assert list(Attrs_3.items(None)) == [('Attrs_3', 'None')]
    Attrs_4 = Attrs('Attrs_4')

# Generated at 2022-06-24 17:28:33.620534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = None
    var_1 = int_0
    int_1 = 0
    var_2 = int_1
    int_2 = 0
    var_3 = int_2
    int_3 = 0
    var_4 = int_3
    var_5 = {}
    var_6 = var_5


# Generated at 2022-06-24 17:28:37.033578
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Keys("a")
    v2 = Keys("a")
    assert(v1 == v2)
    v2 = Keys("b")
    assert(v1 != v2)

# Generated at 2022-06-24 17:28:39.405628
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(None) == BaseVariable(None) and BaseVariable(None) != Attrs(None)


# Generated at 2022-06-24 17:28:45.022383
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable()
    var_1 = BaseVariable()
    var_2 = BaseVariable()
    var_3 = BaseVariable()
    var_4 = BaseVariable()
    var_5 = BaseVariable()
    assert var_0 == var_1
    assert var_2 == var_3
    assert var_0 != var_2


# Generated at 2022-06-24 17:28:49.037543
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    
    if True:
        # test BaseVariable.__eq__()
        BaseVariable_0 = BaseVariable('')
        assert BaseVariable_0.__eq__()



# Generated at 2022-06-24 17:28:52.574033
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = None
    int_1 = Attrs(int_0)
    int_2 = int_1.items(int_0)


# Generated at 2022-06-24 17:28:55.445717
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('0').__eq__(BaseVariable('0'))
    assert BaseVariable('0', []).__eq__(BaseVariable('0'))
    assert not BaseVariable('0').__eq__(BaseVariable('1'))
    assert not BaseVariable('0').__eq__(object)


# Generated at 2022-06-24 17:28:56.613634
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = needs_parentheses(None)



# Generated at 2022-06-24 17:29:26.548399
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 123
    var_0 = Attrs(int_0)
    var_1 = {'__dict__': {}, '__slots__': []}
    var_0.__dict__ = var_1
    str_1 = 'def '
    var_2 = str_1
    var_4 = '123'
    var_3 = {'__dict__': {}, '__slots__': [], 'source': int_0, 'exclude': (), 'code': var_2, 'unambiguous_source': var_4}
    var_0.__dict__ = var_3
    var_5 = {'__dict__': {}, '__slots__': [], 'source': int_0, 'exclude': (), 'code': var_2, 'unambiguous_source': var_4}


# Generated at 2022-06-24 17:29:32.418297
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable("a")
    var_1 = BaseVariable("a")
    var_1.source = "a"
    var_2 = BaseVariable("b")
    var_2.source = "b"
    var_3 = BaseVariable("a")
    var_3.source = "b"
    var_4 = BaseVariable("b")
    var_4.source = "a"
    assert var_0 == var_1
    assert not var_1 == var_2
    assert not var_2 == var_3
    assert not var_3 == var_4
    assert not var_4 == var_0

# Generated at 2022-06-24 17:29:41.311696
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (Attrs('') == Attrs('')) == True
    assert (Attrs('') == Attrs('a')) == False
    assert (Attrs('') == object) == False
    assert (Attrs('') == BaseVariable('')) == False
    assert (Keys('') == Keys('')) == True
    assert (Keys('') == Keys('a')) == False
    assert (Keys('') == object) == False
    assert (Keys('') == BaseVariable('')) == False
    assert (Exploding('') == Exploding('')) == True
    assert (Exploding('') == Exploding('a')) == False
    assert (Exploding('') == object) == False
    assert (Exploding('') == BaseVariable('')) == False

# Generated at 2022-06-24 17:29:52.845575
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frame
    __tracebackhide__ = True
    test_case_0()
    test_case_0()
    test_case_0()
    local_variables = {'int_0': int_0}
    frame_0 = frame.Frame(None, local_variables)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    var_source = int_0
    test_case_

# Generated at 2022-06-24 17:30:03.339012
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import pycompat
    import requests

    frame = pycompat.get_frame_by_func(test_BaseVariable_items)
    url = 'https://api.github.com/'
    response = requests.get(url)
    # String variable
    assert Keys('url').items(frame) == [('url', utils.get_shortish_repr(url))]
    # Sequence variable

# Generated at 2022-06-24 17:30:07.237575
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = None
    str_0 = None
    bool_0 = None
    BaseVariable_0 = BaseVariable(int_0)
    tuple_0 = BaseVariable_0.items(str_0, bool_0)


# Generated at 2022-06-24 17:30:08.851674
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("source").__eq__(list()) == False


# Generated at 2022-06-24 17:30:10.370393
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable.items(None, None) == ()


# Generated at 2022-06-24 17:30:12.778154
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    int_0 = None
    var_0_instance = BaseVariable(int_0)
    var_0_instance.__eq__(object)


# Generated at 2022-06-24 17:30:13.900534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:31:03.096821
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    assert BaseVariable(0, 0) == BaseVariable(0, 0) # __eq__
    assert BaseVariable(0, 0) != BaseVariable(0, 0) # __ne__


# Generated at 2022-06-24 17:31:13.682123
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import variables
    line0 = ''
    line1 = ''
    line2 = ''
    line3 = ''
    line4 = ''
    line5 = ''
    line6 = ''

    source0 = 'l'
    source1 = 'l['
    source2 = 'l['
    source3 = 'l['
    source4 = 'l['
    source5 = 'l['
    source6 = 'l['
    source7 = 'l['
    source8 = 'l.'
    source9 = 'l.'
    source10 = 'l.'
    source11 = 'l.'
    source12 = 'l.'
    source13 = 'l.'
    source14 = 'l.'
    source15 = 'l.'
    source16 = 'l.'
    source17 = 'l.'
    source18 = 'l.'

# Generated at 2022-06-24 17:31:20.993232
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable(int_0, (str_1, str_2))
    var_1 = BaseVariable(int_0, (str_1, str_2))
    bool_0 = (var_0 == var_1)
    bool_1 = (var_0 is var_1)
    bool_2 = (var_0 != var_1)
