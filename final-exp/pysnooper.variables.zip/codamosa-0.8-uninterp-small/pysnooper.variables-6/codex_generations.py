

# Generated at 2022-06-24 17:21:30.457826
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_1 = Indices(0)
    indices_1[0:1]
    assert indices_1._slice == slice(0, 1)


# Generated at 2022-06-24 17:21:32.831940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = ''
    assert BaseVariable(var_0).items(globals()) == (
        ('', 'False'),
    )



# Generated at 2022-06-24 17:21:35.901667
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys

    assert BaseVariable('sys.path').items(sys._getframe(0)) == (
        ('sys.path', '[]'),
    )



# Generated at 2022-06-24 17:21:42.381750
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = [1, 2, 3, 4, 5]
    indices_0 = Indices('test_variable')
    indices_1 = indices_0[2:4]
    assert len(indices_1.items(main_value)) == 2
    assert indices_1.items(main_value)[0] == ('test_variable[2]', '3')
    assert indices_1.items(main_value)[1] == ('test_variable[3]', '4')


# Generated at 2022-06-24 17:21:45.468841
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = '~%.?mVyvxT'
    indices_0 = Indices(str_0)
    slice_0 = slice(None, 0)
    indices_0.__getitem__(slice_0)


# Generated at 2022-06-24 17:21:47.290346
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    Key_0 = Keys('')
    assert Key_0 == Key_0
    assert Key_0 != 'asdf'


# Generated at 2022-06-24 17:21:50.294895
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(0)
    assert indices_0[0] == 0
    assert indices_0[1] == 1


# Generated at 2022-06-24 17:21:55.113610
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    code_object_0 = compile('None', '<string>', 'eval')
    int_0 = 4
    int_1 = 7
    slice_0 = slice(int_0, int_1, None)
    indices_0 = Indices(code_object_0)
    indices_0[slice_0]


# Generated at 2022-06-24 17:22:06.046551
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frames
    from .state import State
    import core.py
    import config.py
    import config.pyc
    import config.pyo
    import config.pyd

    config_file = open('./config.py')
    f_globals = {'__builtins__': __builtins__,
                 #'core.py': core.py,
                 #'config.py': config.py,
                 #'config.pyc': config.pyc,
                 #'config.pyo': config.pyo,
                 #'config.pyd': config.pyd,
                 'config_file': config_file,
                 '_': None,
                 '__': None,
                 '___': None,
                }

# Generated at 2022-06-24 17:22:09.830504
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    keys_0 = Keys(bool_0)
    keys_1 = Keys(bool_0)
    assert (keys_0 == keys_1)


# Generated at 2022-06-24 17:22:28.977603
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import base
    from . import variables
    from . import utils
    from importlib import reload

    reload(base)
    reload(variables)
    reload(utils)

    for key in dir(base):
        if key.startswith('_'):
            continue
        cls = getattr(base, key)
        if not issubclass(cls, BaseVariable):
            continue

        for i in range(100):
            x = None
            y = None
            try:
                x = cls(i)
                y = utils.get_shortish_repr(i)
            except Exception:
                continue
            assert isinstance(x, BaseVariable)
            assert x.items(globals()) == ((str(x), y),)



# Generated at 2022-06-24 17:22:39.569994
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # Unit test for method items of class CommonVariable
    def test_CommonVariable_items():

        # Unit test for method items of class Keys
        def test_Keys_items():
            main_value_0 = {}
            base_variable_0 = Keys(main_value_0)
            # Check for KeyError exception
            try:
                base_variable_0.items({}, normalize=0)
            except KeyError as e:
                print(e)
            else:
                print('No exception')

        test_Keys_items()
        # Unit test for method items of class Attrs
        def test_Attrs_items():
            main_value_0 = {}
            base_variable_0 = Attrs(main_value_0)
            list_0 = []
            list_1 = []
            list_2 = [False]


# Generated at 2022-06-24 17:22:47.274639
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = "2x"
    str_1 = "8O"
    str_2 = ":p"
    str_3 = "0)"
    assert BaseVariable.BaseVariable(str_0, str_1) == \
           BaseVariable.BaseVariable(str_0, str_1)
    assert BaseVariable.BaseVariable(str_2, str_3) == \
           BaseVariable.BaseVariable(str_2, str_3)
    assert BaseVariable.BaseVariable(str_1, str_0) == \
           BaseVariable.BaseVariable(str_1, str_0)
    assert BaseVariable.BaseVariable(str_3, str_2) == \
           BaseVariable.BaseVariable(str_3, str_2)


# Generated at 2022-06-24 17:22:55.849691
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1: Uninitialized variable
    keys_0 = Keys('1')
    result = keys_0.items(None)
    assert result == (), "Test 1 Failed!"

    # Test 2: Valid but empty variable
    keys_1 = Keys('')
    result = keys_1.items(None)
    assert result == (), "Test 2 Failed!"

    # Test 3: Invalid variable
    keys_2 = Keys('1')
    result = keys_2.items(None)
    assert result == (), "Test 3 Failed!"



# Generated at 2022-06-24 17:22:58.396187
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    keys_0 = Keys(bool_0)
    keys_1 = Keys(bool_0)

    any_0 = False
    any_1 = False
    any_0 = keys_0 == keys_1
    assert any_0 == True


# Generated at 2022-06-24 17:23:00.910896
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    keys_0 = Keys(bool_0)
    assert (keys_0.__eq__(keys_0))


# Generated at 2022-06-24 17:23:04.520896
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert len(BaseVariable.items(BaseVariable)) > 1

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 17:23:13.501279
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source_0 = 'input_0'
    var_0 = Keys(source_0)
    
    str_0 = 'input_0'
    str_1 = 'input_1'
    var_1 = Keys(str_0)
    var_2 = Keys(str_1)
    var_3 = Indices(str_0)
    var_4 = Exploding(str_0)
    
    assert var_0.__eq__(var_1)
    assert var_0.__eq__(var_2) is False
    assert var_0.__eq__(var_3) is False
    assert var_0.__eq__(var_4) is False


# Generated at 2022-06-24 17:23:16.596799
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = Keys(a = True, b = False)
    y = Keys(a = False, b = True)
    assert(x.__eq__(y) == False)


# Generated at 2022-06-24 17:23:19.151110
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    keys_0 = Keys("[0, 1, 2, 3, 4]")
    assert keys_0.items() == "[0, 1, 2, 3, 4]"



# Generated at 2022-06-24 17:23:31.508734
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # setup for test
    class test_BaseVariable_items:
        def __init__(self):
            self.var0 = 10
            self.var1 = 10
            self.var2 = BaseVariable('var1')
        def func0(self):
            return 'a'
        def func1(self):
            return 'b'
    self = test_BaseVariable_items()
    frame = FrameType(self.__init__, self.__dict__, '__init__', None, None)

    # call to method items
    result = self.var2.items(frame)

    assert(result == [('var1', '10')])



# Generated at 2022-06-24 17:23:34.101907
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = utils.Frame(test_case_0)
    assert BaseVariable('bool_0').items(frame_0) == (('bool_0', 'False'),)


# Generated at 2022-06-24 17:23:38.645041
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert utils.get_shortish_repr(42) == '42'
    assert utils.get_shortish_repr(42, normalize=True) == '42'
    assert utils.get_shortish_repr(True) == 'True'
    assert utils.get_shortish_repr(True, normalize=True) == 'True'


# Generated at 2022-06-24 17:23:51.335761
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    code = compile('a + b', '<string>', 'exec')
    f = lambda: None
    f.__code__ = code
    f.__globals__ = {}
    f.__globals__['a'] = 'test_str'
    f.__globals__['b'] = 'test_str_2'
    f.__globals__['c'] = True
    f.__globals__['d'] = {}
    f.__globals__['d']['test_key'] = 'test_val'
    f.__globals__['e'] = [1,2]
    f.__globals__['e'].append('test_val')
    f.__globals__['f'] = [3,4]

# Generated at 2022-06-24 17:23:56.253033
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    dict_0 = dict()
    keys_0 = Keys('bool_0', dict_0)
    frame_0 = None
    result = keys_0.items(frame_0, True)

# Generated at 2022-06-24 17:23:59.594733
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Setup
    bool_0 = False
    keys_0 = Keys(bool_0)
    # Teardown
    assert keys_0.items() == []


# Generated at 2022-06-24 17:24:07.830293
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'b'
    keys_0 = Keys(str_0)
    assert keys_0.items()[0] == ('b', 'b')

    bool_0 = False
    keys_0 = Keys(bool_0)
    assert keys_0.items()[0] == (False, 'False')

    keys_0 = Keys(str_0, exclude=str_0)
    assert keys_0.items()[0] == ('b', 'b')

    keys_0 = Keys(str_0, exclude=str_0)
    assert keys_0.items()[0] == ('b', 'b')

    keys_0 = Keys(str_0, exclude=str_0)
    assert keys_0.items()[0] == ('b', 'b')


# Generated at 2022-06-24 17:24:19.028639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0 = frame_0

# Generated at 2022-06-24 17:24:22.205743
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        dict_0 = {str: test_BaseVariable_items, str: test_BaseVariable_items, str: test_BaseVariable_items}
        indices_0 = Indices(dict_0)
        indices_0.items(1)
    except NotImplementedError:
        print("Expected error: NotImplementedError")


# Generated at 2022-06-24 17:24:26.013992
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = None
    base_variable = BaseVariable('one.two.three')
    assert list(base_variable.items(main_value)) == []


# Generated at 2022-06-24 17:24:33.498724
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('bool_0').items(locals()) == []


# Generated at 2022-06-24 17:24:36.216835
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_obj = BaseVariable('_0',tuple())
    assert test_obj.items(test_case_0) == None


# Generated at 2022-06-24 17:24:42.758011
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # If a variable is detected, returns a tuple of variable name and variable value
    debug_variables = [('a', 1)]
    var = BaseVariable('a', ['a'])
    test_case_0.var = var
    test_case_0.debug_variables = debug_variables
    var.items(sys._getframe())
    print(debug_variables)
    assert debug_variables == [('a', 1)]

# Generated at 2022-06-24 17:24:49.597504
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case items_0
    # Testing plain variable
    bool_0 = False
    bool_1 = bool_0
    frame = pycompat.mock_frame({'bool_0': bool_0}, test_case_0)
    variable_0 = BaseVariable('bool_0')
    result_0 = variable_0.items(frame, normalize=False)
    assert result_0 == (('bool_0', '<class \'bool\'>'),), \
        'wrong result for items_0'

    # Test case items_1
    # Testing self.source == 'frame'
    bool_0 = False
    bool_1 = bool_0
    frame = pycompat.mock_frame({'bool_0': bool_0}, test_case_0)
    variable_0 = BaseVariable('frame')
    result

# Generated at 2022-06-24 17:24:57.259573
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        from sys import _getframe
    except ImportError:
        from .pycompat import get_frame
        _getframe = get_frame
    from . import testutils

    # Variables
    var_frame = _getframe().f_back
    var_result = Keys('test_case_0["bool_0"]').items(var_frame)
    var_expected = [('test_case_0["bool_0"]', 'False')]
    # Unittest
    testutils.run_test(var_result, var_expected, 'test_BaseVariable_items')


# Generated at 2022-06-24 17:24:59.097935
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Attrs('bool_0').items(None) == [('bool_0', 'False')], 'Expected behavior did not occur'


# Generated at 2022-06-24 17:25:01.317787
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-24 17:25:08.245233
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import config
    from . import filter_
    import sys
    import traceback
    import inspect
    with config.set(include_extra_variables=True):
        try:
            test_case_0()
        except:
            ex = sys.exc_info()[1]
            lines = filter_.process_traceback(traceback.extract_tb(sys.exc_info()[2]))
            line = lines[-1]
            frame = inspect.currentframe()
            varname = 'bool_0'
            source = line.locals[varname]
            exclude = []
            var = BaseVariable(source, exclude)
            frame = inspect.currentframe()
            normalize = True
            items = var.items(frame, normalize)

# Generated at 2022-06-24 17:25:12.774952
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Creating instance
    base_0 = BaseVariable('')

    # Testing method items
    try:
        base_0.items(None, )
        assert False
    except NotImplementedError:
        assert True


# Generated at 2022-06-24 17:25:15.629160
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    _assert_eq(
        set(Attrs('bool_0').items(get_frame_by_name('test_case_0'))),
        {('bool_0', 'False')}
    )
    _assert_eq(
        set(Attrs('', ['__dict__']).items(get_frame_by_name('test_case_0'))),
        set()
    )


# Generated at 2022-06-24 17:25:25.106203
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('bool_0')
    var_1 = [False]
    method_0 = var_0.items(var_1)
    method_1 = len(method_0)
    assert method_1 == 1
    assert method_0[0][0] == 'bool_0'
    assert method_0[0][1] == 'False'


# Generated at 2022-06-24 17:25:28.128346
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    assert frame is not None
    BaseVariable.items(frame, normalize=False)



# Generated at 2022-06-24 17:25:32.718399
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert(BaseVariable('bool_0').items({'bool_0': bool_0}) == [('bool_0', 'False')])
    assert(BaseVariable('bool_0').items({'bool_1': bool_0}) == [('bool_0', 'undefined')])


# Generated at 2022-06-24 17:25:35.967654
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Indices('foo[1:2:3][]').items(test_case_0.__code__.co_varnames)[0] == ('foo[1:2:3][]', '[]')
    assert Attrs('').items(test_case_0.__code__.co_varnames)[0] == ('', '[]')


# Generated at 2022-06-24 17:25:40.636012
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('testing BaseVariable items')
    try:
        test_case_0()
        print('test case 0: pass')
    except:
        print('test case 0: fail')

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-24 17:25:49.421643
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import dis
    import types
    import enum
    code = inspect.currentframe().f_code
    frame = inspect.currentframe()
    frame = types.FrameType(code, frame.f_globals, frame.f_locals, frame.f_back)
    result = BaseVariable("bool_0", ("foo","bar")).items(frame)
    assert result[0] == ('bool_0', 'False')
    print("BaseVariable.items executed successfully!")
    return

if __name__ == "__main__":
    test_case_0()
    test_BaseVariable_items()

# Generated at 2022-06-24 17:25:51.038926
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    case_0_basevariable = BaseVariable('bool_0', ())
    case_0_basevariable.items(test_case_0())


# Generated at 2022-06-24 17:25:53.998445
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pytest

    from .context import context

    context.stack = [test_case_0]
    BaseVariable_instance_0 = BaseVariable('bool_0')

    with pytest.raises(NotImplementedError):
        BaseVariable_instance_0._items()

    BaseVariable_instance_0.items(context.stack[0].f_locals)


# Generated at 2022-06-24 17:25:57.799727
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = inspect.currentframe()
    var_1 = BaseVariable("", tuple())

    x_2 = None
    assert not var_1.items(frame_0), "items returned unexpected result"


# Generated at 2022-06-24 17:25:59.416060
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    BaseVariable.items(BaseVariable.BaseVariable, bool_0)


# Generated at 2022-06-24 17:26:18.733377
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = ''
    bool_0 = False
    str_1 = ''
    str_2 = ''
    str_3 = ''
    bool_1 = False
    bool_2 = False
    bool_3 = False
    test_BaseVariable_items_instance = BaseVariable(str_0,str_1)
    test_BaseVariable_items_instance.items(str_2,str_3)
    bool_1 = bool_2
    bool_3 = bool_0
    assert bool_3 == bool_1


# Generated at 2022-06-24 17:26:27.535936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create instance of class BaseVariable with default arguments
    # Create a new frame and store the lines from the current frame
    try:
        raise Exception()
    except Exception:
        _, _, tb = sys.exc_info()
        frame = tb.tb_frame
    # Variable __builtins__ from frame
    # Variable bool_0 from frame
    # Variable __package__ from frame
    # Variable __name__ from frame
    # Variable __doc__ from frame
    # Variable __loader__ from frame
    # Variable __spec__ from frame
    # Create instance of class CommonVariable with default arguments
    # Create empty list to store result of method items of class CommonVariable
    result_items = []
    # Store first result of method items of class CommonVariable to list result_items
    result_items.append(cl_0.items(frame))

# Generated at 2022-06-24 17:26:35.028674
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'bool_0'
    exclude = ()

    bool_0 = False
    frame = inspect.currentframe()
    frame.f_locals['bool_0'] = bool_0
    frame.f_locals['source'] = source
    frame.f_locals['exclude'] = exclude
    
    print('Test case 0 (method):')
    print('source: ', source, 'exclude: ', exclude)
    print(BaseVariable(source, exclude).items(frame, normalize=False))
    print('\n')
    


# Generated at 2022-06-24 17:26:36.416484
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()
    assert False


# Generated at 2022-06-24 17:26:39.209643
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    # Assign value to variable str_0
    var_0 = "str_0"
    str_0 = "str_0"
    bool_0 = test(var_0, str_0, bool_0)


# Generated at 2022-06-24 17:26:41.282169
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert [('__name__', "'test_BaseVariable_items'"), ('bool_0', 'False')] == list(Exploding('vars()').items(frame))

# Generated at 2022-06-24 17:26:43.870223
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    with pytest.raises(NotImplementedError):
        assert BaseVariable.items(None)


# Generated at 2022-06-24 17:26:47.972895
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    obj = test_BaseVariable_items.locals['bool_0']
    result = Keys('bool_0').items(frame=None)
    assert result == [('bool_0', 'False')]


# Generated at 2022-06-24 17:26:54.653300
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys

    def get_frame(f_back=1):
        frame = sys._getframe()
        while f_back > 0:
            frame = frame.f_back
            f_back -= 1
        return frame

    def get_vars():
        frame = get_frame(f_back=1)
        return inspect.getargvalues(frame).locals

    v_0 = test_case_0()
    vars_0 = get_vars()
    vars_0_iteritems = vars_0.iteritems()
    exp_0 = [("self", vars_0["self"]), ("f_back", vars_0["f_back"])]
    var_0 = BaseVariable("v_0", exclude=("frame", "f_back"))
    # Actual result
    result

# Generated at 2022-06-24 17:26:59.656150
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    #Testing situation where we have a dictionary
    #Initializing the dictionary
    frame_0 = sys._getframe()
    baseVariable_0 = BaseVariable('globals', exclude=['globals'])
    baseVariable_0.items(frame_0)
    assert True #Did not crash


# Generated at 2022-06-24 17:27:11.045191
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()


# Generated at 2022-06-24 17:27:14.274672
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pycompat.import_module('asyncio')
    import inspect
    # frame, frame_matcher, : target call
    frame, frame_matcher, _ = inspect.currentframe(), None, ()
    # frame, frame_matcher, : mocking
    _, frame_matcher = mock_currentframe(frame) # side-effect
    # frame, frame_matcher, : call inspected function
    result = BaseVariable.items(frame_matcher, normalize=False)
    # assert return value
    assert result == ()



# Generated at 2022-06-24 17:27:17.845511
# Unit test for method items of class BaseVariable
def test_BaseVariable_items(): 
    bool_0 = False
    func0 = BaseVariable('value', exclude={'*'})
    result = func0.items()
    bool_0 = bool(result)
    assert bool_0 == bool(result)


# Generated at 2022-06-24 17:27:19.703347
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert test_case_0() == 0, 'Method items of class BaseVariable returned an error!'

# Generated at 2022-06-24 17:27:25.378965
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "bool_0"
    exclude = False
    if __debug__:
        frame = inspect.currentframe()
        result_0 = BaseVariable.items(source, frame, exclude)
        print(result_0)

# =======


# Generated at 2022-06-24 17:27:29.698687
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    obj = BaseVariable()
    arg_0 = arg_0 = test_case_0()
    arg_1 = arg_1 = test_case_0()
    obj.items(arg_0, arg_1)


# Generated at 2022-06-24 17:27:31.635345
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = 15
    frame = frame_0
    var = BaseVariable('')
    result = var.items(frame)
    assert (result == ())


# Generated at 2022-06-24 17:27:42.607259
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Attrs(source='bool_0').items(test_case_0) == [('bool_0', 'False')]
    assert Attrs(source='bool_0').items(test_case_0, normalize=True) == [('bool_0', 'False')]
    assert Keys(source='dict_0').items(test_case_0) == [('dict_0', '{}')]
    assert Keys(source='dict_0').items(test_case_0, normalize=True) == [('dict_0', '{}')]
    assert Indices(source='list_0').items(test_case_0) == [(u'list_0', '[]')]

# Generated at 2022-06-24 17:27:48.337829
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # AssertionError: Value mismatch: 0 != 1
    global bool_0
    bool_0 = True
    obj = Exploding("test_case_0()")
    assert obj.items(test_case_0.__code__.co_firstlineno) == [("test_case_0()", "False")]

# Test: Launch test_BaseVariable_items
test_BaseVariable_items()

# Generated at 2022-06-24 17:27:51.411022
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    obj = BaseVariable(source, exclude)
    value = obj.items(frame, normalize = False)
    assert value == expectedValue
    assert True


# Generated at 2022-06-24 17:28:03.497227
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()



# Generated at 2022-06-24 17:28:12.966390
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global bool_0
    bool_0 = False

# Generated at 2022-06-24 17:28:19.517077
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    #   def items(self, frame, normalize=False):
    #       try:
    #           main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
    #       except Exception:
    #           return ()
    #       return self._items(main_value, normalize)
    assert False


# Generated at 2022-06-24 17:28:22.370652
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    Test method BaseVariable.items()
    '''
    foo_0 = BaseVariable('')
    assert foo_0.items({}) == ()


# Generated at 2022-06-24 17:28:25.715738
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    VAR_SOURCE = pycompat.unicode_('main_value')
    VAR_EXCLUDE = ()
    frame = inspect.stack()[1][0]
    main_value = test_case_0()
    var = BaseVariable(VAR_SOURCE, VAR_EXCLUDE)
    items = var.items(frame)
    assert isinstance(items, tuple)
test_BaseVariable_items()



# Generated at 2022-06-24 17:28:31.872545
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    with pytest.raises(NotImplementedError):
        stack = inspect.stack()

        obj_0 = BaseVariable(source = '', exclude = ())

        obj_0.items(frame = stack[0][0])


# Generated at 2022-06-24 17:28:38.748107
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print(Attrs('bool_0').items(test_case_0.__code__.co_varnames))
    print(Keys('bool_0').items(test_case_0.__code__.co_varnames))
    print(Indices('bool_0').items(test_case_0.__code__.co_varnames))
    print(Attrs('bool_0').items(test_case_0.__code__.co_varnames))

# Generated at 2022-06-24 17:28:43.951860
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe().f_back
    frame = frame.f_back
    bool_1 = True
    variable = Attrs("bool_1", exclude=())
    variable.items(frame, normalize=False)
    variable.items(frame, normalize=True)


# Generated at 2022-06-24 17:28:56.613046
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    _locals = {
        "bool_0": False
    }
    _globals = {
        "BaseVariable": BaseVariable,
        "explode": Exploding
    }
    bool_0 = _locals["bool_0"]
    source = '{}'
    source = source.format(bool_0)
    BaseVariable_inst = BaseVariable(source)
    BaseVariable_inst.source = source
    items_retval = BaseVariable_inst.items(frame)
    assert isinstance(items_retval, tuple)
    assert items_retval == ('bool_0', 'False')
    explode_inst = _globals["explode"]
    explode_inst.source = source
    items_retval = explode_inst.items(frame)

# Generated at 2022-06-24 17:29:08.721293
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    logger = logging.getLogger(testlib.my_name + '.test_BaseVariable_items')


# Generated at 2022-06-24 17:29:22.991053
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Attrs('a')
    # assert var_0.items() == (('a', '<Attrs>'),)

# Generated at 2022-06-24 17:29:33.912751
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import linecache
    import sys
    def get_line(filename, lineno, module_globals=None):
        linecache.checkcache(filename)
        return linecache.getline(filename, lineno, module_globals)
    def get_directory(filename):
        dirname = os.path.dirname(filename)
        if not os.path.exists(dirname):
            raise OSError("No such directory: '%s'" % dirname)
        return dirname
    def get_namespace(filename):
        directory = get_directory(filename)
        module_name = os.path.splitext(os.path.basename(filename))[0]

# Generated at 2022-06-24 17:29:37.009719
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = ''
    exclude = ()
    set_0 = set()
    dict_0 = dict()
    frame = dict()
    var_0 = BaseVariable(source, exclude)
    set_0.add(var_0)
    dict_0.update(var_0.items(frame))
    dict_0.get(var_0)


# Generated at 2022-06-24 17:29:38.652829
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a'
    exclude = ()
    variable = BaseVariable(source, exclude=exclude)
    variable.items(variable.code, variable.unambiguous_source)


# Generated at 2022-06-24 17:29:44.215394
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame_0 = sys._getframe(1)
    var_0 = frame_0.f_globals
    var_1 = frame_0.f_locals

    assert var_0 is not var_1

    # Unit test for class Attrs
    class Class_0:
        attr_0 = 42
        attr_1 = 'spam'

    obj_0 = Class_0()
    attrs_0 = Attrs('obj_0')
    result_0 = attrs_0.items(frame_0)

# Generated at 2022-06-24 17:29:45.992887
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    obj_0 = test_case_0
    obj_0(eval)

# Generated at 2022-06-24 17:29:54.460655
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {}

# Generated at 2022-06-24 17:29:56.232505
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    list_0 = []
    var_0 = BaseVariable(list_0)


# Generated at 2022-06-24 17:30:05.411876
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import struct
    import array
    import collections
    import types

    assert needs_parentheses('local_var')
    assert needs_parentheses('local_var[one]')
    assert needs_parentheses('local_var[two]')
    assert needs_parentheses('local_var[local_var[one][0]][local_var[two][1]]')
    assert needs_parentheses('local_var.attr')
    assert needs_parentheses('local_var[0].attr')
    assert needs_parentheses('local_var[local_var[one][0]][local_var[two][1]].attr')
    assert needs_parentheses('local_var.attr[0][5]')
    assert not needs_parentheses('(local_var[0])')
    assert not needs_

# Generated at 2022-06-24 17:30:15.275848
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    package_name = 'repo_name'
    bytes_0 = b'\x92\t\x00\xb5\xf0\xa8\x9f\xf67\xf0X\xa9V'
    str_0 = '\x92\t\x00\xb5\xf0\xa8\x9f\xf67\xf0X\xa9V'
    str_1 = 'variable'

    var_0 = NeedsParentheses(str_0)
    # variable = ExcludeDict({'exclude': {}})
    # assert var_0.items(frame, variable) == method_return_value

    assert var_0.source == str_0
    # assert var_0.exclude == variable
    # assert var_0.code == code_object


# Generated at 2022-06-24 17:30:48.113890
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .frame import Frame

    class TestClass(object):
        attr_1 = "This is a test"
        def __init__(self):
            self.attr_2 = 10
        def method_1(self):
            return "Method 1"

    test_inst = TestClass()


# Generated at 2022-06-24 17:30:51.699621
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable((int(None)))
    var_1 = var_0.items(frame=None, normalize=False)
    assert var_1 == (),"Failed 1"


# Generated at 2022-06-24 17:30:59.231772
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    lst_0 = list("0123456789abcdefghijklmnopqrstuvwxyz")
    exc_0 = tuple("0123456789abcdefghijklmnopqrstuvwxyz")
    tuple_0 = needs_parentheses(tuple(lst_0))
    str_0 = needs_parentheses(str("0123456789abcdefghijklmnopqrstuvwxyz"))
    type_0 = needs_parentheses(type(list(list("0123456789abcdefghijklmnopqrstuvwxyz"))))
    lst_1 = list("0123456789abcdefghijklmnopqrstuvwxyz")
    set_0 = needs_parentheses(set(lst_1))

# Generated at 2022-06-24 17:31:10.033006
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global bytes_0
    global var_0

    # Default arguments
    # AssertionError:
    # assert () == var_0.items((), )  # TODO

    # Normal case
    assert ((bytes_0, "<type 'str'> 9"),) == Attrs(bytes_0).items((), True)

    # Default arguments
    # AssertionError:
    # assert ((bytes_0, "<type 'str'> 9"), (bytes_0, "<type 'str'> 9")) == var_0.items((), True)  # TODO

    # Normal case
    assert ((bytes_0, "<type 'str'> 9"),) == Attrs(bytes_0).items((), )

    # Default arguments
    # AssertionError:
    # assert ((bytes_0, "<type 'str'> 9"), (bytes_0, "<

# Generated at 2022-06-24 17:31:23.928098
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    import ast
    from inspect import currentframe, getframeinfo

    def get_locals(frame_level=1):
        frameinfo = getframeinfo(currentframe())
        frame = frameinfo.frame
        for i in range(frame_level):
            frame = frame.f_back
        # return dict(params, **frame.f_locals)
        return frame.f_locals

    # Test 0: List
    class Test0(BaseVariable):
        def __init__(self, *args, **kwargs):
            BaseVariable.__init__(self, *args, **kwargs)
        def _items(self, key, normalize=False):
            return [self.source, '']

    list_0 = [0, 0, 0, 0, 0]
    t_var_0 = Test0