

# Generated at 2022-06-24 17:21:33.552572
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 't$Ia'
    str_1 = 't$Ia'
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_1)
    assert var_0.__eq__(var_1)


# Generated at 2022-06-24 17:21:35.416030
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable
    var_1 = BaseVariable
    assert var_0 == var_1


# Generated at 2022-06-24 17:21:39.183477
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'foo'
    str_1 = 'bar'
    list_0 = list()
    list_0.append(str_0)
    list_0.append(str_1)
    BaseVariable(str_0, list_0)


# Generated at 2022-06-24 17:21:45.775003
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    str_1 = '_8'
    var_0 = type('attrs', (object,), {'source': 'K8', 'exclude': ('_8',), 'code': '', 'unambiguous_source': 'K8'})
    var_1 = type('attrs', (object,), {'source': 'K8', 'exclude': ('_8',), 'code': '', 'unambiguous_source': 'K8'})
    assert var_0 == var_1


# Generated at 2022-06-24 17:21:52.474451
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    eq_0 = [1, 2]
    eq_1 = [2, 3]
    ne_0 = eq_0 != eq_1
    ok_0 = not ne_0
    assert ok_0

# Generated at 2022-06-24 17:21:57.894349
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    attrs_0 = Attrs('var_0')
    attrs_1 = Attrs('var_0')
    attrs_2 = Attrs('var_1')
    assert attrs_0 == attrs_1
    assert not attrs_0 == attrs_2


# Generated at 2022-06-24 17:22:01.231677
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'G1'
    var_0 = BaseVariable(str_0)
    str_1 = '"Y1Bz"'
    var_1 = BaseVariable(str_1)
    var_0 == var_1


# Generated at 2022-06-24 17:22:09.694004
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'd'
    str_1 = 'q1'
    str_2 = '9'
    int_0 = 0
    None
    str_3 = ''
    tuple_0 = (
        str_3, str_3, )
    int_1 = 1
    float_0 = float('0')
    float_1 = float('0')
    float_2 = float('0')
    float_3 = float('0')
    float_4 = float('0')
    float_5 = float('0')
    float_6 = float('0')
    float_7 = float('0')
    float_8 = float('0')
    int_2 = 2
    str_4 = '@'
    int_3 = 3
    str_5 = 'R'

# Generated at 2022-06-24 17:22:16.362775
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    expected_result = False
    str_0 = 'X9'
    var_0 = type(str_0)
    try:
        result = var_0.__eq__(str_0)
    except:
        result = False
    assert result == expected_result, 'Expected %s, got %s' % (str(expected_result), str(result))


# Generated at 2022-06-24 17:22:19.307352
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    cls = BaseVariable('key')
    assert cls.items('key') == ()


# Generated at 2022-06-24 17:22:31.959528
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case 0
    list_0 = ['B', '@', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T']
    str_0 = 'L8'
    var_0 = Indices(list_0, str_0)
    str_1 = 'M2'
    var_1 = Indices(var_0, str_1)
    str_2 = 'N1'
    var_2 = Indices(var_1, str_2)
    str_3 = 'O0'
    var_3 = Indices(var_2, str_3)
    str_4 = 'P6'

# Generated at 2022-06-24 17:22:42.684663
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'g(x/x)p'
    str_1 = 'y'
    str_2 = 'oU`+O=F'
    str_3 = 'Jk$+4'
    str_4 = 'K_J'
    str_5 = 'fGSJk'
    var_0 = BaseVariable(str_0, ())
    var_1 = BaseVariable(str_1, ())
    var_2 = BaseVariable(str_2, ())
    int_0 = var_1.__eq__(var_2)
    var_2 = BaseVariable(str_4, ())
    int_1 = var_1.__eq__(var_2)
    var_1 = BaseVariable(str_5, ())
    int_2 = var_1.__eq__(var_2)


# Generated at 2022-06-24 17:22:49.457913
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '50000'
    str_1 = 'Default'
    str_2 = 'tD'
    str_3 = 'iTR'
    str_4 = '@'
    str_5 = 'Y'
    str_6 = 'C'
    str_7 = 'T'
    str_8 = 'e'
    str_9 = 'qZ'
    str_10 = 'v'
    str_11 = 'H'
    str_12 = 'E'
    str_13 = '$'
    var_0 = BaseVariable()
    var_1 = BaseVariable()
    var_2 = var_0 == var_1
    var_1 = BaseVariable()
    var_1.source = str_0

# Generated at 2022-06-24 17:22:55.949784
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Init values for testing BaseVariable.items method
    d = BaseVariable(source='item', exclude=False)
    frame = False
    normalize = False
    # Use method Stat.items to test
    d.items(frame, normalize)


# Generated at 2022-06-24 17:22:56.635593
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    pass


# Generated at 2022-06-24 17:22:59.706507
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None # TODO: replace with real value
    normalize = None # TODO: replace with real value
    base_variable = BaseVariable()
    assert base_variable.items(frame, normalize) is not None


# Generated at 2022-06-24 17:23:12.365731
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    str_1 = "b'K8'"
    str_2 = "b'K8'"
    str_3 = "'K8'"
    str_4 = 'K8'
    str_5 = str_4
    str_6 = str_5
    str_7 = str_6
    bool_5 = str_7 == str_0
    bool_6 = str_6 == str_1
    bool_7 = str_5 == str_2
    bool_8 = str_4 == str_3
    bool_9 = str_3 == str_0
    bool_10 = bool_9 == bool_5
    bool_11 = bool_8 == bool_6
    bool_12 = bool_7 == bool_5
    bool_13 = bool_6 == bool_0
   

# Generated at 2022-06-24 17:23:15.724919
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str_0 = 'K8'
    var_0 = Indices(str_0)
    var_1 = slice(None)
    var_0 = var_0.__getitem__(var_1)


# Generated at 2022-06-24 17:23:18.407171
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    _slice = slice(None)
    indices = Indices('x')
    indices.__getitem__(_slice)


# Generated at 2022-06-24 17:23:20.851255
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var_0 = Indices('wf[1]')
    var_0.__getitem__(slice(0,11))


# Generated at 2022-06-24 17:23:30.842423
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:23:38.035875
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Unit: __eq__
    str_0 = 'a1'
    str_1 = 's3'
    str_2 = 'd7'
    base_variable_0 = BaseVariable(str_0)
    base_variable_1 = BaseVariable(str_1)
    base_variable_2 = BaseVariable(str_2)
    base_variable_0.__eq__(base_variable_1)
    base_variable_0.__eq__(base_variable_2)


# Generated at 2022-06-24 17:23:41.416581
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_0)
    assert var_0 == var_1
    str_1 = 'K9'
    var_2 = BaseVariable(str_1)
    assert var_0 != var_2


# Generated at 2022-06-24 17:23:52.478305
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'YF!c%>'
    str_1 = '$7'
    str_2 = 'f2^'
    str_3 = '.{'
    str_4 = '1U'
    obj_0 = BaseVariable(str_0)
    obj_1 = BaseVariable(str_1)
    obj_2 = BaseVariable(str_2)
    obj_3 = BaseVariable(str_3)
    obj_4 = BaseVariable(str_4)
    obj_5 = BaseVariable(str_0, (str_1, str_2, str_3, str_4))
    result = obj_0 == obj_1
    result = obj_0 != obj_1
    result = obj_0 == obj_2
    result = obj_0 != obj_2
    result = obj_0

# Generated at 2022-06-24 17:23:58.956596
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K1'
    str_1 = 'K0'
    str_2 = 'K2'
    str_3 = 'K0'

    var_0 = str_0 == str_1
    var_1 = str_0 != str_2
    var_2 = str_3 == str_1



# Generated at 2022-06-24 17:24:05.400165
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'model.calc.atoms'
    obj_0 = BaseVariable(str_0)
    func_0 = obj_0.items
    frame_0 = func_0()
    assert frame_0 == ()


# Generated at 2022-06-24 17:24:07.440749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'do'
    var_0 = BaseVariable(str_0)
    var_0.items(0)


# Generated at 2022-06-24 17:24:18.271931
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'rZ rb!+H0{'
    var_0 = Attrs(str_0)
    str_1 = 'l\x05Jz%c[o'
    var_1 = Attrs(str_1)
    var_2 = Attrs(str_0)
    str_2 = '`DY<7V4+{/'
    var_2 = Indices(str_2)
    var_2 = Attrs(str_2)
    var_2 = Keys(str_2)
    str_3 = '_h/^+ X]c,H'
    var_3 = Attrs(str_3)
    str_2 = 'J)@\tpvVS_L'
    var_2 = Keys(str_2)

# Generated at 2022-06-24 17:24:24.021498
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'T'
    str_1 = 'm'
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_1)
    var_2 = BaseVariable(str_1)
    var_3 = BaseVariable(str_0)
    var_4 = BaseVariable(str_1)
    var_5 = BaseVariable(str_0)
    var_6 = BaseVariable(str_1)
    var_7 = BaseVariable(str_0)
    var_8 = BaseVariable(str_1)
    var_9 = BaseVariable(str_0)
    var_10 = BaseVariable(str_1)
    var_11 = BaseVariable(str_0)



# Generated at 2022-06-24 17:24:27.881219
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    instance_0 = BaseVariable('sjK')
    instance_1 = BaseVariable(str_0)
    var_0 = instance_0 == instance_1


# Generated at 2022-06-24 17:24:47.070309
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'I3'
    var_0 = needs_parentheses(str_0)
    print("Equals")


# Generated at 2022-06-24 17:24:51.075091
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import builtins
    str_0 = 'a'
    builtins.builtins = {}
    attrs = Attrs(str_0)
    frame = builtins.builtins
    result = attrs.items(frame)
    assert(result == ())


# Generated at 2022-06-24 17:24:55.088754
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'B8'
    var_0 = needs_parentheses(str_0)
    str_1 = '\\v:2'
    BaseVariable(str_1)


# Generated at 2022-06-24 17:25:05.732973
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'dict_0'
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    var_0 = BaseVariable(str_0, 'a').items(dict_0)

dict_0 = {'a': 1, 'b': 2, 'c': 3}
dict_1 = {'a': 1, 'b': 2, 'c': 3}
dict_2 = {'a': 1, 'b': 2, 'c': 3}
dict_3 = {'a': 1, 'b': 2, 'c': 3}

dict_0['a'] = 1
dict_1['b'] = 2
dict_2['c'] = 3
dict_3['d'] = 4



# Generated at 2022-06-24 17:25:16.467763
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # 1
    source_1 = 'b'
    exclude_1 = ()
    frame_1 = {'b':dict([('a',2),('b',3)])}
    # 2
    source_2 = 'b.a'
    exclude_2 = ()
    frame_2 = {'b':dict([('a',2),('b',3)])}
    # 3
    source_3 = 'b'
    exclude_3 = ()
    frame_3 = {'b':[1,2,3]}


# Generated at 2022-06-24 17:25:20.139520
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable()
    var_1 = BaseVariable()
    assert var_0 == var_1
    assert not (var_0 != var_1)


# Generated at 2022-06-24 17:25:23.213749
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'G9'
    BaseVariable.source = str_0
    BaseVariable.exclude = ()
    pytest_assert_equal(BaseVariable.source == 'G9', True)
    BaseVariable.exclude = ()


# Generated at 2022-06-24 17:25:25.011540
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a').__eq__(BaseVariable('a'))


# Generated at 2022-06-24 17:25:28.557572
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('K8')
    var_1 = BaseVariable('K8')
    assert (var_0 == var_1)


# Generated at 2022-06-24 17:25:30.501130
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('a', 'b')
    assert variable.items(None)



# Generated at 2022-06-24 17:25:59.450621
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    str_1 = 'Y'
    var_1 = BaseVariable(str_1)
    str_2 = 'G'
    var_2 = BaseVariable(str_2)
    assert (var_0 == var_1)

    assert not (var_0 == var_2)

    str_0 = 'l'
    var_3 = BaseVariable(str_0)
    str_1 = 'V'
    var_4 = BaseVariable(str_1)
    assert not (var_3 == var_4)

    str_0 = 'y'
    var_5 = BaseVariable(str_0)
    str_1 = 'I'
    var_6 = BaseVariable(str_1)

# Generated at 2022-06-24 17:26:06.713131
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    str_1 = 'Q2'
    var_1 = BaseVariable(str_1)
    str_2 = 'K8'
    var_2 = BaseVariable(str_2)
    str_3 = '1h'
    var_3 = BaseVariable(str_3)
    str_4 = 'K8'
    var_4 = BaseVariable(str_4)
    str_5 = 'Q2'
    var_5 = BaseVariable(str_5)
    str_6 = 'K8'
    var_6 = BaseVariable(str_6)
    str_7 = '1h'
    var_7 = BaseVariable(str_7)
    str_8 = 'K8'

# Generated at 2022-06-24 17:26:14.044154
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_1 = 3
    str_0 = 'K8'
    var_0 = needs_parentheses(str_0)
    str_2 = '3'
    str_3 = '3'
    str_1 = '3'
    frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame = frame

# Generated at 2022-06-24 17:26:19.709385
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()  #str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    var_1 = var_0.items(frame)

    assert var_1 == ()


# Generated at 2022-06-24 17:26:28.039606
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_1 = BaseVariable('a')
    list_1 = [pycompat.PYTHON_VERSION_MAJOR, pycompat.PYTHON_VERSION_MINOR, pycompat.PYTHON_VERSION_MICRO, pycompat.PYTHON_VERSION_PATCHLEVEL]
    frame_1 = utils.make_fake_frame(globals={}, locals={'a': list_1})
    bool_1 = var_1.items(frame_1) == [('a', '[{{PLACEHOLDER}}, {{PLACEHOLDER}}, {{PLACEHOLDER}}, {{PLACEHOLDER}}]')]
    frame_2 = utils.make_fake_frame(globals={}, locals={'a': {'b': 1, 'c': 2}})


# Generated at 2022-06-24 17:26:36.061247
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import objects
    str_0 = 'a'
    str_1 = 'a'
    str_2 = 'b'
    var_0 = BaseVariable(str_0, (str_0, ))
    var_1 = BaseVariable(str_1, (str_1, ))
    var_2 = BaseVariable(str_1, (objects.int_type_1, ))
    var_3 = BaseVariable(str_2, (str_2, ))
    assert var_0 == var_1
    assert var_0 == var_2
    assert var_0 != var_3


# Generated at 2022-06-24 17:26:44.040091
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .console import ConsoleFrame
    from .console import Console
    from .console_render import _renormalize_path
    from .python_version import PY2
    import sys
    import pytest
    from .utils import text_repr
    # Testing frame: frame #4 in method test_BaseVariable___eq__ in class Exporter.
    # Line #3 in Exporter.py.

    def test_BaseVariable___eq__():
        class Test():
            pass

        str_0 = None
        var_0 = BaseVariable(str_0)
        str_1 = Test()
        var_1 = BaseVariable(str_1)
        str_0 = Test()
        var_2 = BaseVariable(str_0)
        str_2 = '__init__'
        var_3 = BaseVariable(str_2)


# Generated at 2022-06-24 17:26:46.849116
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    cast(BaseVariable, BaseVariable('source', 'exclude')).__eq__(BaseVariable('source', 'exclude'))



# Generated at 2022-06-24 17:26:52.173776
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'M'
    str_1 = 'U;c'
    var_0 = BaseVariable(str_0, str_1)
    str_2 = '4PJ'
    str_3 = 'W'
    var_1 = BaseVariable(str_2, str_3)
    assert (var_0 == var_0) == True



# Generated at 2022-06-24 17:26:59.879488
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Create instances of the standard class
    str_0 = 'K8'
    comp_0 = compile(str_0, '<variable>', 'eval')
    exc_0 = Exception
    int_0 = 0
    # Create instances of the user class
    var_0 = BaseVariable(str_0, exc_0)
    # A call to the method
    assert var_0._fingerprint == (type(var_0), str_0, exc_0)
    int_1 = hash(var_0._fingerprint)
    assert int_1 == 7258319793699309840
    comp_1 = var_0 == var_0
    assert comp_1 is True


# Generated at 2022-06-24 17:27:41.683098
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'jF'
    var_0 = BaseVariable(str_0)
    str_1 = 'iK'
    var_1 = BaseVariable(str_1)
    str_2 = 'U'
    var_2 = BaseVariable(str_2)
    assert var_0 != var_1
    assert var_1 != var_2
    assert var_2 != var_0


# Generated at 2022-06-24 17:27:47.046965
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'o'
    str_1 = 't'
    str_2 = 'u'
    str_3 = 's'
    str_4 = 'o'
    str_5 = 't'
    str_6 = 'u'
    str_7 = 's'
    str_8 = 'o'
    str_9 = 't'
    str_10 = 'u'
    str_11 = 's'
    str_12 = 'o'
    str_13 = 't'
    str_14 = 'u'
    str_15 = 's'
    str_16 = 'o'
    str_17 = 't'
    str_18 = 'u'
    str_19 = 'q'
    class_0 = BaseVariable

# Generated at 2022-06-24 17:27:51.928893
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v0 = Keys('a', exclude=('b',))
    assert v0 == v0
    assert not v0 == Keys('b')


# Generated at 2022-06-24 17:28:02.364979
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_case_1():
        py_0 = Attrs('local_var')
        py_1 = Attrs('local_var')
        py_2 = Attrs('local_var', 'x')
        py_3 = Attrs('local_var', 'x')
        py_4 = Keys('local_var')
        py_5 = Keys('local_var')
        py_6 = Indices('local_var')
        py_7 = Indices('local_var')
        py_8 = Exploding('local_var')
        py_9 = Exploding('local_var')
        py_10 = Exploding('local_var', 'x')
        py_11 = Exploding('local_var', 'x')

# Generated at 2022-06-24 17:28:07.681095
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print('\n::: TEST :::\n')
    f = globals()
    f['test_BaseVariable_items'] = BaseVariable
    var = BaseVariable()
    print('Variable: ' + str(var))
    var.items()
    print('Variable: ' + str(var))
    del f['BaseVariable']
    del f['test_BaseVariable_items']



# Generated at 2022-06-24 17:28:10.582650
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 's'
    var_0 = needs_parentheses(str_0)
    var_1 = BaseVariable(str_0)
    assert_true(var_0 == var_1)

# Generated at 2022-06-24 17:28:15.016277
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'QG'
    var_0 = Attrs(str_0)
    var_1 = Indices(str_0)
    var_2 = Attrs(str_0)
    var_3 = var_0 == var_1
    var_4 = var_0 == var_2
    var_5 = Keys(str_0) == var_1


# Generated at 2022-06-24 17:28:17.234166
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    var_1 = BaseVariable(str_0)
    var_2 = var_0 == var_1


# Generated at 2022-06-24 17:28:21.847818
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = 'P'
    str_1 = 'P'
    var_0 = needs_parentheses(str_0)
    var_1 = needs_parentheses(str_1)
    assert var_0 == var_1


# Generated at 2022-06-24 17:28:26.242950
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    str_0 = '1'
    str_1 = '1'
    str_2 = '1'
    str_3 = '1'
    exclude_0 = set()
    exclude_1 = set()
    exclude_1.add(str_0)
    var_0 = Keys(str_1,exclude_0)
    var_1 = Keys(str_2,exclude_0)
    var_2 = Keys(str_3,exclude_1)

    assert var_0 != var_1
    assert var_0 == var_0
    assert var_0 != var_2



# Generated at 2022-06-24 17:29:05.178913
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'K8'
    frame = inspect.currentframe()
    # TypeError: Normalizing [0] in [0, 1, 2] is not supported
    result = BaseVariable(str_0).items(frame)


# Generated at 2022-06-24 17:29:13.382815
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    def items(self, frame, normalize=False):
        try:
            main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
        except Exception:
            return ()
        return self._items(main_value, normalize)
    '''
    import re
    import inspect
    import sys
    import os
    import unittest
    curr_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, os.getcwd())
    sys.path.insert(0, curr_dir)
    sys.path.insert(0, os.getcwd() + os.sep + "..")

# Generated at 2022-06-24 17:29:25.575769
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'c'
    str_1 = 'foo'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3

    frame = frame_object_create(str_0, str_1)
    variable = Attrs(str_0, exclude=(str_1))
    source = variable.items(frame)
    assert int_2 == len(source)
    assert int_3 == len(source[int_0])
    assert str_0 == source[int_0][int_0]
    assert '"bar"' == source[int_0][int_1]
    assert str_1 == source[int_1][int_0]
    assert 'None' == source[int_1][int_1]

    variable = Keys(str_0)

# Generated at 2022-06-24 17:29:29.832692
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)
    test_calls = [
        ([], [(str_0, 'None')]),
        ({}, [(str_0, "{'a': 'b', 'c': 'd'}")])
    ]
    for params in test_calls:
        var_0.items(params)


# Generated at 2022-06-24 17:29:32.013578
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'K8'
    var_0 = BaseVariable(str_0)


# Generated at 2022-06-24 17:29:41.076410
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    locals_ = frame.f_locals
    globals_ = frame.f_globals
    # TODO test 1
    globals_['_toolz_DataFrame'] = pandas.DataFrame
    # TODO test 2
    globals_['numpy'] = numpy
    globals_['random'] = random
    # TODO test 3
    locals_['x'] = x
    x = numpy.ones(5)
    # TODO test 4
    locals_['y'] = y
    y = random.randint(1, 2, size=10)
    # TODO test 5
    locals_['df'] = df

# Generated at 2022-06-24 17:29:46.894510
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for case 0
    str_0 = 'K8'
    class_0 = BaseVariable(str_0)
    frame_0 = None
    normalize_0 = False
    result_0 = class_0.items(frame_0, normalize_0)
    assert result_0 == ()

# Generated at 2022-06-24 17:29:54.724216
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'K8'
    str_1 = '`'
    str_2 = 'p'
    list_0 = ['K8', '`', 'p']
    tuple_0 = ('I', 59.0, 'Z')
    tuple_1 = ('s', str_2, 'y')
    tuple_2 = ('k', str_1, 'h')
    tuple_3 = (tuple_1, tuple_2)
    tuple_4 = (tuple_0, tuple_3)
    tuple_5 = ('E', list_0, 'F')
    tuple_6 = ('F', tuple_4, 'B')
    tuple_7 = ('A', str_0, 'C')
    tuple_8 = ('G', tuple_5, 'D')

# Generated at 2022-06-24 17:29:56.123783
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:30:02.795302
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'V2'
    str_1 = 'V3'
    str_2 = 'V4'
    source = str_0 + str_1 + str_2
    exclude = {'V5'}
    obj = BaseVariable(source, exclude=exclude)
    frame = None
    normalize = False
    try:
        obj.items(frame, normalize=normalize)
    except Exception as e:
        raise Exception('Should not raise exception')
