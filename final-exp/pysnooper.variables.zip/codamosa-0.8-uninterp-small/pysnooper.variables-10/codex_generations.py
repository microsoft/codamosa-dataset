

# Generated at 2022-06-24 17:21:36.093871
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # an example source
    source = "float_0"
    # an example frame
    frame = test_case_0()
    if not isinstance(frame, dict):
        frame = frame.f_globals
    
    # an example exclude
    exclude = ()
    # an example normalize
    normalize = True
    # an example instance of BaseVariable:
    baseVariable_0 = BaseVariable(source, exclude)
    
    # the result of calling items should be a tuple
    items = baseVariable_0.items(frame, normalize)
    assert isinstance(items, tuple), 'Result is of type {}'.format(type(items))


# Generated at 2022-06-24 17:21:38.225340
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    indices_0[0:2]

# Generated at 2022-06-24 17:21:42.028521
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert_equal((Indices(-5.78)[:])[0:4], Indices(-5.78)[0:4])
    assert_equal((Indices(-5.78)[:])[7:], Indices(-5.78)[7:])


# Generated at 2022-06-24 17:21:44.643922
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('float_0')
    tuple_0 = var_0.items(float_0 = -2318.54562)
    assert tuple_0 == (('float_0', '-2318.54562'),), 'BaseVariable.items() #0 failed'


# Generated at 2022-06-24 17:21:50.223743
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    indices_0[1:-1]


# Generated at 2022-06-24 17:21:58.691517
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame_0_0 = utils.FrameInfo('test_BaseVariable_items', 'test_case_0', 0, 0)
    main_value_0_0 = float_0
    normalize_0_0 = True
    result = indices_0.items(test_frame_0_0, normalize_0_0)
    expected = [('-2318.54562', '-2.31854562e3')]
    utils.compare_output(expected, result, 'test_BaseVariable_items')

# Generated at 2022-06-24 17:22:07.595765
# Unit test for method items of class BaseVariable

# Generated at 2022-06-24 17:22:10.748832
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert eval(compile('-2318.54562', '<variable>', 'eval')) == float_0
    indices_0.items(None)
    assert float_0 == float_0



# Generated at 2022-06-24 17:22:14.811518
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    indices_1 = Indices(float_0)
    assert indices_0 == indices_1


# Generated at 2022-06-24 17:22:19.344858
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable_0 = BaseVariable(str())
    variable_1 = BaseVariable(str())
    variable_2 = Attrs(str())
    assert variable_0 == variable_1
    assert variable_0 != variable_2

# Generated at 2022-06-24 17:22:40.058157
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    int_0 = 0
    int_1 = 1
    slice_0 = slice(int_0, int_1)
    indices_1 = indices_0[slice_0]


# Generated at 2022-06-24 17:22:42.042055
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global float_0, indices_0
    for key in indices_0.keys():
        assert (float_0[key] == key, "keys() of indices_0 incorrect")


# Generated at 2022-06-24 17:22:47.171771
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)


# Generated at 2022-06-24 17:22:51.430868
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    indices_0_getitem = indices_0.__getitem__(slice(1, 2, 3))


# Generated at 2022-06-24 17:22:54.629844
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    BaseVariable.__eq__
    """
    assert (
        BaseVariable("<arg1>") == BaseVariable("<arg1>")
    )


# Generated at 2022-06-24 17:22:58.595144
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable_0 = Attrs(4.0)
    variable_0.__eq__(variable_0)


# Generated at 2022-06-24 17:23:01.769755
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    indices_1 = Indices(float_0)
    assert indices_1 == indices_0


# Generated at 2022-06-24 17:23:06.812895
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import math
    float_1 = math.fmod(float_0, math.hypot(float_0, float_0))
    assert math.hypot(float_1, float_1) == 0, "BaseVariable.items didn't return an empty list"


# Generated at 2022-06-24 17:23:14.061268
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Attrs('a').items(a=1) == [('a', '1')]
    assert Keys('a').items(a={1: 2}) == [('a', "{1: 2}"), ("a[1]", '2')]
    assert Indices('a').items(a=[1]) == [('a', '[1]'), ('a[0]', '1')]
    assert Exploding('a').items(a={1: 2}) == [('a', "{1: 2}"), ("a[1]", '2')]
    assert Exploding('a').items(a=[0]) == [('a', '[0]'), ('a[0]', '0')]

# Generated at 2022-06-24 17:23:18.103485
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -2318.54562
    indices_0 = Indices(float_0)
    float_1 = 2318.54562
    indices_1 = Indices(float_1)
    result = indices_0.__eq__(indices_1)
    assert result


# Generated at 2022-06-24 17:23:31.610824
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices['aa'][8] == False


# Generated at 2022-06-24 17:23:34.616018
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indexes = slice(None)
    object_0 = Indices('a')[indexes]
    assert object_0._slice == indexes


# Generated at 2022-06-24 17:23:42.392940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    thread_0 = Thread()
    str_0 = str
    set_0 = {'test_BaseVariable_items'}
    pycompat.implements_iterator(bool_0)
    pycompat.implements_iterator(thread_0)
    pycompat.implements_iterator(str_0)
    pycompat.implements_iterator(set_0)
    f_1 = Attrs(bool_0)
    f_2 = Attrs(thread_0)
    f_3 = Attrs(str_0)
    f_4 = Attrs(set_0)
    f_1.items(thread_0)
    f_2.items(thread_0)
    f_3.items(thread_0)

# Generated at 2022-06-24 17:23:48.064924
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    var_0 = needs_parentheses(bool_0)
    frame_0 = None
    var_1 = BaseVariable(var_0)
    var_2 = var_1.items(frame_0)



# Generated at 2022-06-24 17:23:51.963497
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    w_0 = Indices('', ())
    w_1 = w_0[1:2]
    assert isinstance(w_1, Indices)
    assert isinstance(w_1, Keys)
    # Test that all members of slice object have been properly copied.
    assert w_0._slice.start is None
    assert w_0._slice.stop is None
    assert w_0._slice.step is None


# Generated at 2022-06-24 17:23:59.719107
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0 = Indices(None)
    indices_1 = indices_0[:]

test_Indices___getitem__.func_annotations = {
    'test_Indices___getitem__':
        lambda: [{'type_inference': 'Indices'}]
}

if __name__ == '__main__':
    test_case_0()
    test_Indices___getitem__()

# Generated at 2022-06-24 17:24:07.888941
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    import types
    var_0 = BaseVariable('str(0)')
    var_1 = BaseVariable('str(0)')
    var_2 = BaseVariable('str(0)')
    var_3 = BaseVariable('str(0)')
    var_4 = BaseVariable('str(0)')
    var_5 = BaseVariable('str(0)')
    var_6 = BaseVariable('str(0)')
    var_7 = BaseVariable('str(0)')
    var_8 = BaseVariable('str(0)')
    var_9 = BaseVariable('str(0)')
    var_10 = BaseVariable('str(0)')
    var_11 = BaseVariable('str(0)')
    var_12 = BaseVariable('str(0)')
    var_13 = BaseVariable('str(0)')

# Generated at 2022-06-24 17:24:10.600848
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('source').__getitem__(slice(None)) == Indices('source')

# test_case_1 for method __getitem__ of class Indices


# Generated at 2022-06-24 17:24:11.818937
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    pass


# Generated at 2022-06-24 17:24:21.708624
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 0
    tuple_0 = ()
    str_0 = ""
    var_0 = Attrs(int_0)
    var_1 = Attrs(tuple_0)
    var_2 = Attrs(str_0)

    assert(var_0.items(int_0) != var_1.items(tuple_0))
    assert(var_0.items(int_0) == var_2.items(str_0))

    assert(var_0.items(int_0) is not var_1.items(tuple_0))
    assert(var_0.items(int_0) is not var_2.items(str_0))
    assert(var_1.items(tuple_0) is not var_2.items(str_0))


# Generated at 2022-06-24 17:24:34.740736
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = utils.frame_from_callable(test_case_0)
    var_0 = Attrs(bool_0)
    var_1 = var_0.items(frame)

# Generated at 2022-06-24 17:24:44.976936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_1 = False
    int_0 = 1
    int_1 = 2
    str_0 = 'string'
    main_value = [0, 1, 2]
    var_0 = Indices('test')
    expected_0 = [('test', '[0]'), ('test[1]', '1'), ('test[2]', '2')]
    var_1 = Indices('test')[1:]
    expected_1 = [('test[1]', '1'), ('test[2]', '2')]
    actual_result_0 = var_0.items(main_value=main_value, normalize=bool_1)
    actual_result_1 = var_1.items(main_value=main_value, normalize=bool_1)

# Generated at 2022-06-24 17:24:48.258524
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # TODO: add test code
    # test case 0
    bool_0 = True
    if bool_0:
        print("No error")
    else:
        raise Exception("Error")


# Generated at 2022-06-24 17:24:51.219920
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('a', 'b,c')
    with pytest.raises(NotImplementedError):
        assert var_0.items()


# Generated at 2022-06-24 17:24:59.230355
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a = "abc"
    b = 1
    c = (2, 3, 4)
    d = {'a': 1, 'b': 2}
    e = [5, 6, 7]
    f = {1, 2, 3}
    g = {'x': 'y'}
    h = [{'a': 'a'}, {'b': 'b'}]

    var_0 = BaseVariable(a)
    var_1 = BaseVariable(b)
    var_2 = BaseVariable(c)
    var_3 = BaseVariable(d)
    var_4 = BaseVariable(e)
    var_5 = BaseVariable(f)
    var_6 = BaseVariable(g)
    var_7 = BaseVariable(h)


# Generated at 2022-06-24 17:25:05.822132
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    name_0 = 'self'
    frame_0 = utils.Frame(f_globals={'+': '+'}, f_locals={})
    source_0 = '1+1'
    exclude_0 = ()
    class_0 = BaseVariable(source_0, exclude_0)
    result_0 = class_0.items(frame_0)
    expected_0 = ()
    assert result_0 == expected_0
    del name_0, frame_0, source_0, exclude_0, class_0, result_0, expected_0


# Generated at 2022-06-24 17:25:07.880866
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_case_0()

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-24 17:25:11.543163
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    str_0 = str(bool_0)
    print(utils.get_shortish_repr(str_0))


# Generated at 2022-06-24 17:25:14.143460
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = 'data'
    var_0 = BaseVariable(frame_0)
    var_1 = var_0.items('frame')


# Generated at 2022-06-24 17:25:21.795673
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import source
    from . import items
    from . import traceback
    v_1 = source.BaseVariable()
    v_2 = source.BaseVariable()

    v_3 = items.SourceVariable(v_1, 'co_filename')
    v_3.items(traceback.Frame(None, None, None, None, None, None))

# Generated at 2022-06-24 17:25:50.971748
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_0 = dict()
    dict_1 = dict()
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_1[1] = 1
    dict_1[4] = 4
    dict_0 = dict()
    dict_1 = dict()
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_1[1] = 1
    dict_1[4] = 4
    dict_1[5] = 4
    dict_0 = dict()
    dict_1 = dict()
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_1[1] = 1
   

# Generated at 2022-06-24 17:26:01.357738
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    CODE = compile('datetime.datetime.now()', '<variable>', 'eval')
    instance_0 = BaseVariable('datetime.datetime', ())
    instance_0.code = CODE
    instance_0.unambiguous_source = 'datetime.datetime'
    instance_0.source = 'datetime.datetime'
    instance_0.exclude = ()
    GLOBALS = {'datetime': datetime}
    with capture_stdout() as result_0:
        try:
            instance_0.items(frame={'f_globals': GLOBALS, 'f_locals': {}}, normalize=True)
        except Exception:
            pass
    assert result_0.getvalue() == "    datetime.datetime: <class 'datetime.datetime'>\n"

# Unit

# Generated at 2022-06-24 17:26:03.400913
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    index_0 = 0
    index_1 = 1
    index_2 = 2
    var_0 = BaseVariable()


# Generated at 2022-06-24 17:26:06.894573
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    result = BaseVariable('source').items('frame', 'normalize')
    assert result == ()
    result = BaseVariable('source', 'exclude').items('frame', 'normalize')
    assert result == ()


# Generated at 2022-06-24 17:26:14.104765
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    str_0 = str(bool_0)
    assert str_0 == 'True'
    dict_0 = {'a': 'b'}
    list_0 = ['a']
    assert 'a' in list_0
    # self._format_key of method items of class BaseVariable
    # TODO: implement test
    # self._get_value of method items of class BaseVariable
    # TODO: implement test
    # self._keys of method items of class BaseVariable
    # TODO: implement test
    # self._items of method items of class BaseVariable
    assert ['a'] == Keys(list_0)._items(list_0)
    frame_0 = inspect.currentframe()
    assert ('a', 'b') == Keys(dict_0).items(frame_0)

# Generated at 2022-06-24 17:26:25.830683
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TD:
        T = '<var>'
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source
        def items(self, frame, normalize=False):
            try:
                main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
            except Exception:
                return ()
            return self._items(main_value, normalize)

# Generated at 2022-06-24 17:26:26.592409
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Generated at 2022-06-24 17:26:30.675551
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a = {'b': {'c': {'d': 1, 'e': 2, 'f': 3}},'g': 'h'}
    
    x = BaseVariable(a, 'g')
    x_ = BaseVariable(a, ('g', 'b'))
    
    assert x.items(a), "incorrect"
    assert x_.items(a), "incorrect"


# Generated at 2022-06-24 17:26:39.734102
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import sysconfig
    import os

    frame = inspect.stack()[1]
    module = inspect.getmodule(frame[0])
    module_name = module.__name__
    frame = frame[0]
    frame_info = inspect.getframeinfo(frame)
    frame_source = frame_info.code_context[0]
    frame_locals = frame.f_locals

    # Assign vars and methods (for setup)
    enc = sys.getdefaultencoding()
    mod_path = sysconfig.get_path('platlib', '%s.dir/%s' % (enc, enc))
    mod_path = mod_path.replace(os.path.sep, '/')

# Generated at 2022-06-24 17:26:41.764674
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'bool_0'
    bool_0 = True
    var_0 = BaseVariable(source)
    assert var_0.items(locals()) == (('bool_0', 'True'),)



# Generated at 2022-06-24 17:27:27.604273
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_1 = BaseVariable("x")
    assert var_1.items("x") == ()

    var_2 = BaseVariable("x")
    assert isinstance(var_2.items("x"), tuple)


# Generated at 2022-06-24 17:27:31.145489
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable(bool_0, exclude=False)
    var_1 = var_0.items({'frame': False, 'normalize': False})
    assert_equal(var_1, var_1)


# Generated at 2022-06-24 17:27:42.363077
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = inspect.currentframe()
    var_0 = frame_0.f_globals
    test_0 = 'a'
    var_1 = (test_0, )
    obj_0 = Keys(test_0, var_1)
    test_1 = {'a': 1}
    var_2 = obj_0.items(frame_0, var_0)
    assert var_2 == [('a', 1)]

    test_0 = 'a'
    var_1 = (test_0, )
    obj_0 = Indices(test_0, var_1)
    test_1 = ['a']
    var_2 = obj_0.items(frame_0, var_0)
    assert var_2 == [('a[0]', 'a')]


# Generated at 2022-06-24 17:27:53.640564
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    str_0 = "test_BaseVariable_items.py"
    var_0 = 1.5<=1.5
    var_1 = needs_parentheses(bool_0)
    var_2 = BaseVariable(str_0).items(var_1)
    var_3 = 50
    var_4 = Attrs(var_3)
    var_5 = BaseVariable(var_3).items(var_4)
    var_6 = Indices(var_3)
    var_7 = BaseVariable(var_4)
    var_8 = var_7.items(var_6)
    var_9 = Keys(str_0)
    var_10 = BaseVariable(var_6).items(var_9)
    var_11 = Exploding(str_0)
    var_

# Generated at 2022-06-24 17:27:55.434614
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 'abc'
    var_1 = BaseVariable(var_0)

# Generated at 2022-06-24 17:27:58.513349
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('a')
    var_1 = BaseVariable('a', 'b')
    var_2 = BaseVariable(1, (1))
    var_3 = BaseVariable(1, [1])


# Generated at 2022-06-24 17:28:03.188035
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global var_0
    test_frame = inspect.currentframe()
    vars_0 = var_0.items(test_frame.f_back)
    assert vars_0 == (("bool_0", "True"),)


# Generated at 2022-06-24 17:28:06.825655
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize parameters
    key = True
    file_path = "test.py"
    method = ""
    line_no = 1
    frame = 1

    # Construct class
    obj = BaseVariable(key)

    # Check 1
    assert obj.items(frame) == tuple()

# Generated at 2022-06-24 17:28:13.008155
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    items(BaseVariable, frame, normalize=False)
    """
    # Note that we can't test anything else than stubbed-out methods here, as
    # this is an abstract method.
    # Make sure that we can at least call it (without getting a NotImplementedError!)
    # with something that looks vaguely like a frame
    frame = utils.DummyFrame()
    # Stub the abstract method
    BaseVariable.items(True, frame, normalize=False)


# Generated at 2022-06-24 17:28:24.164824
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = True
    normalize_expected = True
    var_0 = Attrs('a')
    var_1 = Attrs('b')
    var_2 = Attrs('c')
    var_3 = Attrs('d')
    var_4 = Attrs('e')
    var_5 = Attrs('f')
    var_6 = Attrs('g')
    var_7 = Attrs('h')
    var_8 = Attrs('i')
    var_9 = Attrs('j')
    var_10 = Attrs('k')
    var_11 = Attrs('l')
    var_12 = Attrs('m')
    var_13 = Attrs('n')
    var_14 = Attrs('o')
    var_15 = Attrs('p')
    var_16

# Generated at 2022-06-24 17:30:04.750522
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = 'type'
    var_1 = 'len'
    var_2 = 'range'
    var_3 = getattr(locals(), '{}'.format(var_0))(getattr(locals(), '{}'.format(var_2))(getattr(locals(), '{}'.format(var_1))([1,2,3])))
    var_4 = type(var_3)
    var_5 = getattr(locals(), '{}'.format(var_2))(getattr(locals(), '{}'.format(var_1))(var_3))
    var_6 = type(var_5)

# Generated at 2022-06-24 17:30:09.473659
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    str_0 = 'a'
    var_3 = str_0.isupper()
    var_4 = utils.get_shortish_repr(var_3)
    assert (var_4, 'True') == Attrs('a').items(frame=None)[0]

# Generated at 2022-06-24 17:30:12.739238
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_1 = Attrs('foo')
    var_2 = var_1.items({'foo': {'a': [1, 2, 3]}})
    var_3 = var_1.items({'foo': 0})


# Generated at 2022-06-24 17:30:19.648311
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    l_0 = globals().copy()
    l_0.update(locals())
    frame_0 = inspect.currentframe()
    frame_0.f_locals = l_0
    frame_0.f_globals = globals()
    bool_0 = True
    var_0 = keys = Keys(bool_0).items(frame_0)
    return var_0


# Generated at 2022-06-24 17:30:22.008745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_instance_0 = BaseVariable
    int_0 = 1
    test_instance_0.items(int_0)


# Generated at 2022-06-24 17:30:27.281742
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable("", "")
    variable.source = "bool_0"
    variable.exclude = ()
    variable.code = compile("bool_0", '<variable>', 'eval')
    variable.unambiguous_source = "bool_0"
    bool_0 = True
    frame = None
    normalize = False
    assert variable.items(frame, normalize) == ("bool_0", repr(True))


# Generated at 2022-06-24 17:30:30.165788
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = "test"
    checker = BaseVariable(x)
    x = 3
    assert checker.items(x) == x



# Generated at 2022-06-24 17:30:39.603958
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = 5
    str_0 = 'test'
    int_1 = 5
    str_1 = 'test'
    int_2 = 5
    str_2 = 'test'
    float_0 = 2.5
    float_1 = 2.5
    float_2 = 2.5
    CustomException_0 = CustomException()
    assert BaseVariable(
        int_0,
        str_0,
    ).items(
        int_1,
        str_1,
    ) == (
        (int_2, str_2),
    )

# Generated at 2022-06-24 17:30:46.536434
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import getframeinfo, stack
    frameinfo = getframeinfo(stack()[0][0])
    # Create test data for function `items`
    bool_0 = True
    str_0 = 'S'
    str_1 = 's'
    var_0 = needs_parentheses(bool_0)
    var_1 = needs_parentheses(str_0)
    # Template variable `var_2` is expected to be of type `Sequence`
    var_2 = [needs_parentheses(str_0)]
    # Template variable `var_3` is expected to be of type `BaseVariable`
    var_3 = test_BaseVariable_items.__globals__['BaseVariable']()
    var_4 = frameinfo
    var_5 = frameinfo.frame
    str_2 = 'var_0'

# Generated at 2022-06-24 17:30:57.233917
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame_0 = None
    bool_0 = True
    test_bool_0 = bool_0
    test_dict_0 = {
        'param_0': bool_0,
        'param_1': bool_0,
    }
    test_list_0 = [
        bool_0,
        bool_0,
    ]
    test_list_1 = test_list_0
    test_tuple_0 = (
        bool_0,
        bool_0,
    )
    test_tuple_1 = test_tuple_0
    test_None = None
    test_none_0 = test_None
    test_bool_1 = test_bool_0
    test_unicode_0 = pycompat.text_type()
    test_long_0 = int()
    test_