

# Generated at 2022-06-24 17:21:31.712458
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    assert BaseVariable(bool_0) == BaseVariable(bool_0)


# Generated at 2022-06-24 17:21:33.858014
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    base_variable_0 = BaseVariable(bool_0)
    other_0 = BaseVariable(bool_0)
    assert base_variable_0 == other_0


# Generated at 2022-06-24 17:21:37.023211
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bool_0 = False
    indices_0 = Indices(bool_0)
    item_0 = slice(None)
    indices_1 = indices_0[item_0]
    assert indices_1 is not None

# Generated at 2022-06-24 17:21:42.276495
# Unit test for constructor of class Attrs
def test_Attrs():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    assert not attrs_0.exclude
    assert attrs_0.source == bool_0
    assert attrs_0.unambiguous_source == bool_0
    assert attrs_0._fingerprint == (Attrs, bool_0, ())
    assert hash(attrs_0) != 2438482094400432465
    assert not attrs_0 == bool_0


# Generated at 2022-06-24 17:21:45.305844
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    key_0 = Keys(bool_0)
    key_1 = Keys(bool_0)
    key_2 = Keys(bool_0)
    key_3 = Keys(bool_1)
    
    assert not (key_1 == key_2)
    assert key_0 == key_1


# Generated at 2022-06-24 17:21:59.255609
# Unit test for constructor of class Attrs
def test_Attrs():
    bool_0 = False
    attrs_0 = Attrs(bool_0)

# Generated at 2022-06-24 17:22:01.895262
# Unit test for constructor of class Exploding
def test_Exploding():
   bool_0 = False
   attrs_0 = Attrs(bool_0)
   bool_1 = bool_0
   indices_0 = Indices(bool_1)


# Generated at 2022-06-24 17:22:06.241985
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = BaseVariable(bool_0)
    bool_1 = bool_0
    attrs_1 = BaseVariable(bool_1)
    assert attrs_0 == attrs_1


# Generated at 2022-06-24 17:22:08.480872
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    bool_1 = False
    attrs_1 = Attrs(bool_1)
    attrs_0 = attrs_1
    assert True

# Generated at 2022-06-24 17:22:11.881844
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Dummy frame variables
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    source_0 = 'hello'
    # Case 0: exception in eval(self.code, frame.f_globals or {}, frame.f_locals)
    with pytest.raises(Exception):
        eval(attrs_0.code, None)

# Generated at 2022-06-24 17:22:27.566031
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    bool_1 = False
    attrs_1 = Attrs(bool_1)
    assert attrs_0 == attrs_1


# Generated at 2022-06-24 17:22:41.796112
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    msg_0 = """Assertion error: Expected type is <class 'slice'> but actually it is <class 'int'>. 
The first argument must be slice"""
    msg_1 = """Assertion error: Expected type is <class 'slice'> but actually it is <class 'float'>. 
The first argument must be slice"""
    float_0 = 1.0
    int_0 = 0
    test_array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    test_array1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    test_array2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    indices = Indices(test_array)
    # Test 1

# Generated at 2022-06-24 17:22:48.222389
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a, b, c = False, False, True
    assert (Attrs(a) == Attrs(b)) == (a == b)
    assert Attrs(a) == Attrs(b)
    assert not (Attrs(a) == Attrs(c))
    assert Attrs(a) != Attrs(c)


# Generated at 2022-06-24 17:22:58.485304
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    globs = {'test_BaseVariable_items': utils.get_test_locals(locals())}
    exec('_res_0 = utils.set_repr_for(BaseVariable(None))', globs)
    exec('_res_1 = utils.set_repr_for(BaseVariable(None, _res_0[0]))', globs)
    exec('_res_2 = utils.set_repr_for(BaseVariable(None, _res_0[1]))', globs)
    # Checking with nothing excluded
    locals_0 = dict()
    exec('_res_3 = _res_0[0].items(locals_0)', globs, locals_0)
    # Checking with single excluded item
    locals_1 = dict()

# Generated at 2022-06-24 17:23:01.027808
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bool_0 = False
    indices_0 = Indices('a')
    slice_0 = slice(0)
    indices_1 = indices_0[slice_0]


# Generated at 2022-06-24 17:23:12.206248
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame = utils.Frame(None)
    test_frame.f_locals['foo'] = 'baz'
    test_frame.f_locals['bar'] = 'shaz'
    test_frame.f_locals['baz'] = 10
    test_frame.f_locals['shaz'] = 6
    test_vars = ('foo', 'bar', 'baz', 'shaz')
    for test_var in test_vars:
        test_var_obj = Keys(test_var)
        assert test_var_obj.items(test_frame) == ((test_var, test_frame.f_locals[test_var]),)


# Generated at 2022-06-24 17:23:13.267265
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_case_0()


# Generated at 2022-06-24 17:23:20.134870
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    assert frame is not None
    items = Attrs('bool_0').items(frame)
    assert items == [('bool_0', 'False'), ('bool_0.__class__', "<class 'bool'>"), ('bool_0.__doc__', "bool(x) -> bool\n\nReturns True when the argument x is true, False otherwise.\nThe builtins True and False are the only two instances of the class bool.\nThe class bool is a subclass of the class int, and cannot be subclassed.")]


# Generated at 2022-06-24 17:23:21.648399
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (attrs_0 == Attrs(bool_0))

# Generated at 2022-06-24 17:23:24.822563
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = False
    var_0 = Attrs(bool_0)
    var_1 = Attrs(bool_1)
    var_0 == var_1


# Generated at 2022-06-24 17:23:51.049088
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    pytest.raises(AssertionError, 'assert attrs_0.__eq__(True)')
    pytest.raises(AssertionError, 'assert attrs_0.__eq__(1)')
    pytest.raises(AssertionError, 'assert attrs_0.__eq__(str)')

# Generated at 2022-06-24 17:23:56.926278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        main_value = None
        attrs_0 = Attrs(main_value)
        frame = None
        normalize = None
        result = attrs_0.items(frame, normalize)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 17:24:00.928251
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    assert test_case_0() == test_case_0()
    assert test_case_0() != test_case_1()
    assert test_case_0() != test_case_2()
    assert test_case_0() != test_case_3()
    assert test_case_0() != test_case_4()
    assert test_case_0() != test_case_5()
    assert test_case_0() != test_case_6()
    assert test_case_0() != test_case_7()
    assert test_case_0() != test_case_8()
    assert test_case_0() != test_case_9()


# Generated at 2022-06-24 17:24:03.963173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    frame_0 = {bool_0:False, id:1}
    attrs_0.items(frame_0, normalize=False)


# Generated at 2022-06-24 17:24:06.496606
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'x': [10, 20, 30]}
    test = BaseVariable("x")
    res = test.items(frame)
    print("result:%s\t" % res)#debug



# Generated at 2022-06-24 17:24:11.174829
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source_0 = True
    exclude_0 = True
    base_variable_0 = BaseVariable(source_0, exclude_0)
    frame_0 = True
    normalize_0 = True
    result = base_variable_0.items(frame_0, normalize_0)
    print(result)


# Generated at 2022-06-24 17:24:15.833856
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    instance_0 = BaseVariable(bool_0, )
    instance_1 = BaseVariable(bool_0, )
    instance_2 = BaseVariable(instance_0, )
    assert instance_0 == instance_1
    assert instance_0 == instance_2


# Generated at 2022-06-24 17:24:19.599992
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    attrs_1 = Attrs(bool_0)
    assert attrs_0 == attrs_1


# Generated at 2022-06-24 17:24:27.278977
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    bool_2 = False
    attrs_0 = Attrs(bool_0)
    attrs_1 = Attrs(bool_0)
    attrs_2 = Attrs(bool_1)
    attrs_3 = Attrs(bool_2)
    x_0 = attrs_0 == attrs_0
    x_1 = attrs_0 == attrs_1
    x_2 = attrs_0 == attrs_2
    x_3 = attrs_0 == attrs_3
    x_4 = attrs_0 == bool_0
    x_5 = bool_0 == attrs_0
    x_6 = attrs_0 == bool_1
    x_7 = bool_1 == attrs_0
    assert x_0


# Generated at 2022-06-24 17:24:30.976328
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    # Method call to items with arguments (bool_0, )
    # Should be OK
    ans_0 = attrs_0.items(bool_0)


# Generated at 2022-06-24 17:25:15.705752
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    assert BaseVariable.__eq__(BaseVariable(bool_0, bool_0), BaseVariable(bool_0, bool_0))
    assert not BaseVariable.__eq__(BaseVariable(bool_0, bool_0), BaseVariable(bool_0))


# Generated at 2022-06-24 17:25:18.750472
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('test') == BaseVariable('test')
    assert not BaseVariable('test') == BaseVariable('test2')


# Generated at 2022-06-24 17:25:24.385902
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    # Test 1: bool_0 and bool_1 are boolean and they are different
    if isinstance(bool_0, bool) and isinstance(bool_1, bool) and bool_0 != bool_1 and bool_1 == bool_0:
        # State 0: Explicitly return as '__eq__' does not have a return statement
        return
    # State 1: No reachable state
    raise RuntimeError()


# Generated at 2022-06-24 17:25:34.093142
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from pytestqt.qt_compat import qt_api
    from PyQt5.QtWidgets import QWidget, QPushButton

    def test_attrs(my_var):
        my_var.items(inspect.currentframe())
        my_var.items(inspect.currentframe(), normalize = True)

    if qt_api.pytest_qt_api == 'pyqt5':
        widget = QWidget()
        button = QPushButton('OK')
        test_attrs(Attrs(widget))
        test_attrs(Attrs(button))
    else:
        raise NotImplementedError



# Generated at 2022-06-24 17:25:39.337551
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    bool_1 = True
    bool_2 = False
    attrs_0 = Attrs(bool_0)
    attrs_1 = Attrs(bool_1)
    attrs_2 = Attrs(bool_2)
    attrs_3 = Attrs(bool_2)
    assert attrs_0.__eq__(attrs_0)
    assert not attrs_1.__eq__(attrs_0)
    assert attrs_2.__eq__(attrs_2)
    assert attrs_2.__eq__(attrs_3)


# Generated at 2022-06-24 17:25:41.900812
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    assert not BaseVariable.__eq__(bool_0, bool_0)


# Generated at 2022-06-24 17:25:46.947252
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    #bool_1 = True
    #attrs_1 = Attrs(bool_1)
    attrs_0.__eq__(bool_0)


# Generated at 2022-06-24 17:25:49.716198
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.stack()[0]
    bool_0 = False
    attrs_0 = Attrs(bool_0)
    result = attrs_0.items(frame)
    assert result == ((bool_0, False),)


# Generated at 2022-06-24 17:25:55.801459
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (Attrs('bool_0') == Attrs('bool_0'))
    assert (not (Attrs('bool_0') == Attrs('bool_1')))
    assert (not (Attrs('bool_0') == 1))
    assert (Attrs('bool_0',exclude=()) == Attrs('bool_0'))
    assert (not (Attrs('bool_0',exclude=()) == Attrs('bool_0',exclude=('a',))))
    assert (Keys('bool_0') == Keys('bool_0'))
    assert (not (Keys('bool_0') == Keys('bool_1')))
    assert (not (Keys('bool_0') == 1))
    assert (Keys('bool_0',exclude=()) == Keys('bool_0'))

# Generated at 2022-06-24 17:26:03.456790
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Create an instance of the BaseVariable class with parameters bool_0 and bool_1
    attrs_0 = BaseVariable.__new__(BaseVariable)
    # Assign parameters to object attrs_0
    attrs_0.source = str()
    attrs_0.exclude = str()
    # Create an instance of the BaseVariable class with parameters bool_0 and bool_1
    attrs_1 = BaseVariable.__new__(BaseVariable)
    # Assign parameters to object attrs_1
    attrs_1.source = str()
    attrs_1.exclude = str()
    # Call method __eq__ of object attrs_0
    # Variable to store the return value of the method __eq__
    ret_0 = attrs_0.__eq__(attrs_1)
    # Assert the return

# Generated at 2022-06-24 17:26:31.481300
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Test_BaseVariable(BaseVariable):
        def __init__(self):
            self.source = test_case_0
            self.exclude = ()
        
        def _items(self, key, normalize=False):
            main_value = utils.get_shortish_repr(key, normalize=normalize)
            return main_value

    test_case_0 = False
    case_1 = Test_BaseVariable()
    result =  case_1.items(test_case_0, normalize=False)
    assert result == False



# Generated at 2022-06-24 17:26:34.834448
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # type: (bool_0) -> ([], {})
    if True:  # Change to True if you want to test something
        if test_case_0:
            pass
        else:
            pass
    return


# Generated at 2022-06-24 17:26:42.023160
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    inst_0 = BaseVariable(test_case_0,test_case_0)
    inst_1 = BaseVariable(inst_0,inst_0)
    inst_2 = BaseVariable(inst_1,inst_1)
    inst_3 = BaseVariable(inst_2,inst_2)
    inst_4 = BaseVariable(inst_3,inst_3)
    inst_5 = BaseVariable(inst_4,inst_4)
    inst_6 = BaseVariable(inst_5,inst_5)
    inst_7 = BaseVariable(inst_6,inst_6)
    inst_8 = BaseVariable(inst_7,inst_7)
    inst_9 = BaseVariable(inst_8,inst_8)
    inst_10 = BaseVariable(inst_9,inst_9)

# Generated at 2022-06-24 17:26:43.995616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    params_0 = {
        "frame": None,
        "normalize": False
    }
    print(BaseVariable(test_BaseVariable_items).items(**params_0))
    return None


# Generated at 2022-06-24 17:26:54.501072
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test: case 0
    bool_0 = False
    local_variable_0 = Attrs('x')
    try:
        local_variable_0.items(sys._getframe().f_back)
        assert False
    except Exception as e:
        assert type(e) is KeyError
        bool_0 = True
    assert bool_0
    local_variable_0 = False
    # Test: case 1
    bool_0 = False
    local_variable_0 = Attrs('x')
    bool_1 = bool()
    bool_1 = (local_variable_0.items(sys._getframe().f_back) == ('x', 'False'))
    bool_0 = bool_1
    assert bool_0
    local_variable_0 = False
    # Test: case 2
    bool_0 = False
   

# Generated at 2022-06-24 17:26:57.547425
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    s = Attrs('bool_0',())
    a = s.items(test_case_0.__globals__['test_case_0'].__code__.co_consts[1])
    assert a == (('bool_0', 'False'),)

# Generated at 2022-06-24 17:27:02.663421
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = inspect.currentframe()
    frame_0 = frame_0.f_back.f_back
    bool_0 = True
    # 
    # KeyError: 'frame_0.f_globals'
    # frame_0.f_globals
    bool_0 = False


# Generated at 2022-06-24 17:27:03.562496
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    t = BaseVariable()


    assert True


# Generated at 2022-06-24 17:27:05.158062
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    t = BaseVariable('t', ())
    assert t.items() == ()


# Generated at 2022-06-24 17:27:09.216659
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import currentframe
    from . import utils

    frame = currentframe().f_back.f_back
    assert frame
    v = BaseVariable(source='bool_0', exclude=())
    assert v
    assert v.items(frame, normalize=False) == (('bool_0', 'False'),)



# Generated at 2022-06-24 17:27:40.598451
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = None
    normalize_0 = None
    # Stub: Replace pycompat.execfile_fallback with some code that does nothing.
    pycompat.execfile_fallback = lambda filename, globals_arg, locals_arg: (lambda: None)
    
    # Stub: Replace utils.get_shortish_repr with some code that does nothing.
    utils.get_shortish_repr = lambda arg_0: None
    
    result_0 = keys_0.items(frame_0, normalize_0)
    assert result_0 == None


# Generated at 2022-06-24 17:27:42.857055
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Arrange
    bytes_0 = b'I'
    keys_0 = Keys(bytes_0)

    # Act
    # TODO: [AT] run a test here...

    # Assert


# Generated at 2022-06-24 17:27:53.662896
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = 1
    bytes_0 = b'x'
    instance_0 = BaseVariable(bytes_0)
    assert instance_0.items(x) == """<variable>""".items(x)
    assert instance_0.items(x) == """x""".items(x)
    x = (1, 1.1, b'1')
    bytes_0 = b'x'
    instance_0 = BaseVariable(bytes_0)
    assert instance_0.items(x) == """<variable>""".items(x)
    assert instance_0.items(x) == """(1, 1.1, b'1')""".items(x)
    assert instance_0.items(x) == """(1, 1.1, b'1')""".items(x)
    x = False
    bytes_0

# Generated at 2022-06-24 17:27:55.667064
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('').items(frame=frame).__class__ == tuple

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 17:28:01.896198
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create and return an instance of the class being tested
    bytes_0 = b'h\x10\xd7\x8c\xac\xca\xbc\xa3\x88\x9a\x93\x9b\xb8\xcb\x87\x93\xaa\xcb\x90\xa9'
    variable = Keys(bytes_0)
    result = variable.items(None)
    assert isinstance(result, collections.Sequence)


# Generated at 2022-06-24 17:28:04.938979
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = {'a': 10, 'b': 11}
    table_0 = BaseVariable('a', 'b').items(frame_0)


# Generated at 2022-06-24 17:28:07.896409
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    #Test the return value of method items for the class BaseVariable.
    #TODO: Do unit test for class BaseVariable.
    print("The return value of method items of class BaseVariable is ",
          BaseVariable("").items(""))


# Generated at 2022-06-24 17:28:10.436905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = False
    with pytest.raises(NotImplementedError):
        BaseVariable.items(frame, normalize)


# Generated at 2022-06-24 17:28:11.839888
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    lambda_0 = lambda: BaseVariable.items()


# Generated at 2022-06-24 17:28:14.346221
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('x')
    assert utils.is_equal(var.items(frame={'x': {'a': 1, 'b': 2}}), [('x', '{...}')])


# Generated at 2022-06-24 17:29:10.681398
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import random

    import torch
    from torch.utils.data import DataLoader
    from torchvision.datasets import MNIST
    from torchvision import transforms

    class Model(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.conv = torch.nn.Conv2d(1, 1, 1)

        def forward(self, x):
            return self.conv(x)

    model = Model()
    dataset = MNIST('./data', download=False)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

    random_input = next(iter(dataset))[0]
    model.eval()
    model(random_input.unsqueeze(0))

    # Create variables with source 'data' and

# Generated at 2022-06-24 17:29:16.454418
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import doctest
    doctest.testmod()


# Hide the testcase from the doctest.
__test__ = {n: v for n, v in locals().items() if n.startswith('test_')}

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 17:29:22.867464
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    keys_0 = Keys('base_variable')
    assert keys_0.items('hello') == ()
    assert (keys_0.items({ }) == [('base_variable', '{}')])
    assert (keys_0.items({ 'a': 'b' }) == [('base_variable', "{'a': 'b'}"), ('base_variable[a]', "'b'")])


# Generated at 2022-06-24 17:29:29.840165
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    bytes_0 = b'I'
    keys_0 = Keys(bytes_0)
    assert keys_0.items(frame) == [(b'I', b'b\'I\'')]



# Generated at 2022-06-24 17:29:35.870049
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    code = compile('[0, 1, 2]', '<variable>', 'eval')
    frame = {}
    main_value = eval(code, frame)
    assert Indices('index_0')._items(main_value) == [('index_0[0]', '0'), ('index_0[1]', '1'), ('index_0[2]', '2')]
    assert Keys('index_0')._items(main_value) == [('index_0[0]', '0'), ('index_0[1]', '1'), ('index_0[2]', '2')]
    assert Attrs('index_0')._items(main_value) == [('index_0', '<list>')]

# Generated at 2022-06-24 17:29:43.504199
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source_0 = 'bytes_1'
    exclude_0 = ()
    frame_0 = FrameType()
    normalize_0 = False
    ret_0 = BaseVariable(source_0, exclude_0).items(frame_0, normalize_0)
    passed = ret_0

    return passed


# Generated at 2022-06-24 17:29:46.002026
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    def ast(big_number):
        return big_number + 1
    ast_0 = ast(1)
    keys_0 = Keys('ast_0')
    attrs_0 = Attrs('ast_0')
    print(keys_0.items(frame))
    print(attrs_0.items(frame))

# Generated at 2022-06-24 17:29:54.461521
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import Attrs
    from . import Indices
    from . import Keys
    from . import Exploding
    import abc
    import itertools
    import collections
    import copy
    class TraceItem(object):
        def __init__(self, frame, *args, **kwargs):
            self.frame = frame
        def __getitem__(self, index):
            return frame
    args_0 = 1
    args_1 = 2
    def wrapped():
        return None
    frame_0 = TraceItem(args_0)
    main_value_0 = 1
    main_value_1 = 2
    source_0 = 1
    source_1 = 2
    source_2 = 3
    source_3 = 4


# Generated at 2022-06-24 17:29:58.593432
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialization
    source = b'I'
    exclude = ()
    base_variable_0 = BaseVariable(source, exclude)
    frame = ()
    normalize = False
    # items method of class BaseVariable
    base_variable_0.items(frame, normalize)


# Generated at 2022-06-24 17:30:06.545415
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print("test BaseVariable.items()")
    x = 1
    y = 2
    z = 10
    w = 11
    bytes_0 = b'I'
    bytes_1 = b'J'
    keys_0 = Keys(bytes_0)
    frame = inspect.currentframe()
    t1 = (bytes_0, 'b\'I\'')
    t2 = ('J[k]', '11')
    t3 = ('z[0]', '1')
    l1 = [t1, t2, t3]
    print("call func items() and return List l1")
    test_case_0()
    assert(l1 == keys_0.items(frame, normalize=True))
    print("return type is List")
    print("return value is right")
    return

# Unit test