

# Generated at 2022-06-24 17:21:24.646568
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    int_0 = 173
    int_1 = -4
    ind_0 = Indices('int_0')
    var_0 = ind_0[slice(int_1, int_0)]



# Generated at 2022-06-24 17:21:29.922798
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable('self.foo')
    assert var_0.items('self.foo') and var_0.items is BaseVariable.items
    assert var_0.items('self.foo') is not BaseVariable.items('self.foo')


# Generated at 2022-06-24 17:21:32.406009
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var_1 = Indices("")
    var_2 = var_1[0:2]



# Generated at 2022-06-24 17:21:36.155096
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    long_0 = long(-395.60161)
    var_0 = Attrs(float_0)
    var_1 = var_0.items(float_0, long_0)


# Generated at 2022-06-24 17:21:37.905655
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    raise Exception(str(BaseVariable('float_0').items(test_case_0)))


# Generated at 2022-06-24 17:21:47.290382
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Setup local variables
    var_0 = 'PYCHARM_HOSTED'
    var_1 = '__main__'
    var_2 = False
    # Setup mocks
    utils.get_shortish_repr = MagicMock(side_effect=[var_1, var_2])
    frame = MagicMock(return_value=(var_1, var_2))
    compile = MagicMock(side_effect=[var_0, var_1, var_2])
    eval = MagicMock(side_effect=[var_0, var_1, var_2, var_2, var_2, var_2])
    BaseVariable = MagicMock(side_effect=[var_0, var_1, var_2])
    # Setup arguments
    source = var_0
    # Call method
    var

# Generated at 2022-06-24 17:21:49.229288
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:21:53.215242
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    float_0 = 1.5
    var_0 = Indices(float_0)
    float_1 = float_0[:]
    var_1 = Indices(float_1)


# Generated at 2022-06-24 17:21:56.415797
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -395.60161
    float_1 = -395.60161
    BaseVariable_0 = BaseVariable(float_0, [])


# Generated at 2022-06-24 17:22:00.403327
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    exclude = ()
    normalize = False
    # Call method items of class BaseVariable
    if utils.PY2:
        raise utils.SkipTest()
    else:
        BaseVariable.items(frame, exclude, normalize)


# Generated at 2022-06-24 17:22:11.016749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    int_0 = -127
    dict_0 = {}
    str_0 = 'z'
    var_0 = BaseVariable(str_0, dict_0)
    var_0.items(int_0)


# Generated at 2022-06-24 17:22:16.776936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_1 = Indices('a')
    var_2 = var_1.items(frame)
    assert var_2 == (("a[0]", "0"), ("a[1]", "1"), ("a[2]", "2"), ("a[3]", "3"))


# Generated at 2022-06-24 17:22:21.024580
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    class BaseVariable:
        @abc.abstractmethod
        def items(self, frame, normalize=False):
            pass

    """
    # TODO: add test
    pass

# Generated at 2022-06-24 17:22:24.016226
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Attrs('a_0')
    str_0 = 'abc'
    dict_0 = {
        'abc': 1,
        'def': {'ghi': 'jkl'}
    }



# Generated at 2022-06-24 17:22:32.556303
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    unnormalized_value_0 = '-395.60161'
    normalized_value_0 = '"<value>"'
    value_0 = unnormalized_value_0
    simple_variable_0 = str(float_0)
    items_0 = simple_variable_0.items(frame_0)
    assert len(items_0) == 1
    item_0 = items_0[0]
    assert item_0[0] == simple_variable_0
    assert item_0[1] == value_0
    simple_variable_1 = 'len("abc")'
    items_1 = simple_variable_1.items(frame_0)
    assert len(items_1) == 1
    item_1 = items_1[0]
    assert item_1[0] == simple_variable_1

# Generated at 2022-06-24 17:22:38.884510
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = BaseVariable('var_0', None)
    float_0 = -395.60161
    dict_0 = dict()
    list_0 = list()
    assert isinstance(var_0, BaseVariable)
    assert isinstance(float_0, float)
    assert isinstance(dict_0, dict)
    assert isinstance(list_0, list)
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0
    assert var_0 == var_0


# Generated at 2022-06-24 17:22:42.658003
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    This test case is a stub.  There is no actual test here.
    The purpose of this test case is to show documentation
    and make sure that it can be compiled into a pystone benchmark
    """
    var_0 = BaseVariable(float_0)
    var_0.items(float_0)


# Generated at 2022-06-24 17:22:48.493437
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize variables
    float_0 = -395.60161
    var_0 = BaseVariable(float_0)
    float_1 = float_0
    # Call the method
    var_1 = var_0.items(frame=float_1)
    assert isinstance(var_1, tuple) == True
    # Return the result
    return var_1


# Generated at 2022-06-24 17:22:50.863799
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = Attrs('x.y')
    var_2 = Attrs('x.y')
    var_3 = Attrs('x.z')
    assert var_1 == var_2
    assert var_1 != var_3

# Testing method __hash__ of class BaseVariable

# Generated at 2022-06-24 17:22:54.629788
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    int_0 = frame.f_lineno
    class_0 = frame.f_locals
    return (int_0, class_0)


# Generated at 2022-06-24 17:23:06.682876
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_0 = CommonVariable('test', ('a', 'b'))
    var_1 = CommonVariable('test', ('a', 'b'))
    assert var_0 == var_1
    assert var_0 != 5


# Generated at 2022-06-24 17:23:09.515883
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    str_0 = str(float_0)
    print(needs_parentheses(float_0))
    print(needs_parentheses(str_0))
    print(float_0)
    print(type(float_0))



# Generated at 2022-06-24 17:23:11.629825
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('float_0').__eq__(BaseVariable('float_0')) == True


# Generated at 2022-06-24 17:23:21.310827
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # Exclude from test case #0
    assert Attrs("x").items(dict(x=5)) == [("x", "5")]

    # Exclude from test case #1
    assert Keys("x").items(dict(x=5)) == [("x", "5")]

    # Excluded from test case #2
    assert Attrs("x").items(dict(x=dict(y=6))) == [("x", "{'y': 6}"), ("x.y", "6")]

    # Excluded from test case #3
    assert Indices("x").items(["a", "b", "c"]) == [("x", "['a', 'b', 'c']"), ("x[0]", "'a'"), ("x[1]", "'b'"), ("x[2]", "'c'")]

# Generated at 2022-06-24 17:23:28.671989
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Basic test
    var_0 = BaseVariable()
    var_0.source = 'a.b.c'
    var_0.exclude = 'abc'
    var_1 = Frame()
    frame_0 = Frame()
    frame_0.init_globals = {}
    frame_0.f_globals = {}
    frame_0.init_locals = {}
    frame_0.f_locals = {}
    var_2 = var_0.items(frame_0)
    assert_equal(var_2, ())



# Generated at 2022-06-24 17:23:39.492674
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = 5.0
    variable_1 = Exploding(main_value)
    variable_1_items = variable_1.items(main_value)
    variable_items2 = variable_1.items(main_value)
    variable_2 = Attrs(main_value)
    variable_2_items = variable_2.items(main_value)
    variable_3 = Keys(main_value)
    variable_3_items = variable_3.items(main_value)
    variable_4 = Indices(main_value)
    variable_4_items = variable_4.items(main_value)
    variable_4.__getitem__(main_value)
    variable_4_items = variable_4.items(main_value)
    print('Success')


# Generated at 2022-06-24 17:23:48.750227
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    for _ in range(4):
        _random_string = utils.random_string(length=67)
        var_0 = BaseVariable(source=_random_string)
        _random_string = utils.random_string(length=91)
        var_1 = BaseVariable(source=_random_string)
        _random_string = utils.random_string(length=94)
        var_2 = BaseVariable(source=_random_string)



# Generated at 2022-06-24 17:23:55.401501
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    float_0 = -395.60161
    var_0 = BaseVariable(float_0)
    float_1 = 28.2165
    var_1 = BaseVariable(float_1)
    assert (var_0 == var_1)


# Generated at 2022-06-24 17:23:59.212198
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = keys.Keys(float_0)
    with pytest.raises(Exception):
        var_0.items()


# Generated at 2022-06-24 17:23:59.858988
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass



# Generated at 2022-06-24 17:24:16.800037
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test case 1
    pycompat.sys.stderr.write('Testing BaseVariable.items()...')
    main_value_0 = 1
    exclude_0 = (1,)
    var_0 = BaseVariable(main_value_0, exclude_0)
    frame_0 = False
    normalize_0 = True
    items_0 = var_0.items(frame_0, normalize_0)
    pycompat.sys.stderr.write('  OK\n')



# Generated at 2022-06-24 17:24:23.690877
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    float_1 = 0.01954
    float_2 = -0.0001
    float_3 = -0.0217
    float_4 = -6.67e-11
    float_5 = 0.16
    float_6 = -1.193e-05
    float_7 = -2.9e-06
    float_8 = 0.0066
    float_9 = -0.07231
    float_10 = 0.33
    float_11 = 8.99e+09
    float_12 = -2e+08
    float_13 = -4.9e+09
    float_14 = 5.97e+24
    float_15 = 2.25e+08
    float_16 = 2e+26
    float_17 = 4e+24

# Generated at 2022-06-24 17:24:34.215032
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # var_0 is of type BaseVariable
    var_0 = BaseVariable("test", ())
    # var_1 is of type BaseVariable
    var_1 = BaseVariable("test", ())
    # var_2 is of type BaseVariable
    var_2 = BaseVariable("test", ())
    # var_3 is of type BaseVariable
    var_3 = BaseVariable("test", ())
    # var_4 is of type BaseVariable
    var_4 = BaseVariable("test", ())
    # var_5 is of type BaseVariable
    var_5 = BaseVariable("test", ())
    # var_6 is of type BaseVariable
    var_6 = BaseVariable("test", ())
    # var_7 is of type BaseVariable
    var_7 = BaseVariable("test", ())
    # var_8 is of type BaseVariable
    var_8

# Generated at 2022-06-24 17:24:35.920089
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = BaseVariable(6)
    assert x.items is None


# Generated at 2022-06-24 17:24:44.617527
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import numpy as np
    array_0 = np.array([[-1, 1], [0, 0]])
    var_0 = Keys().items(array_0)
    var_1 = Keys().items(array_0[0])
    var_2 = Keys()['0'].items(array_0)
    assert var_0 == [('array_0', array_0)]
    # import code
    # code.interact(local=locals())
    assert var_1 == [('array_0.0', array_0[0])]
    assert var_2 == [('array_0[0]', array_0[0])]


# Generated at 2022-06-24 17:24:55.536570
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import exception_hierarchy
    from . import standard_exceptions
    from . import builtin_exceptions

    x = Attrs('x')
    assert x.items(sys._getframe()) == [('x', '<module \'drepr.variables\' (built-in)>')]

    x = Attrs('x', 'test_case_0')

# Generated at 2022-06-24 17:25:01.422338
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    string_0 = 'a_zqxjjjKZFwcV7dJ'
    var_0 = BaseVariable(string_0)
    int_0 = -1146
    var_1 = BaseVariable(int_0, string_0)
    bool_0 = var_1 != var_0
    assert bool_0
    var_1 = BaseVariable(int_0, string_0)
    bool_0 = var_0 != var_1
    assert not bool_0
    bool_0 = var_1 != var_0
    assert bool_0
    var_0 = BaseVariable(int_0, string_0)
    bool_0 = var_1 == var_0
    assert not bool_0
    var_0 = BaseVariable(string_0)

# Generated at 2022-06-24 17:25:04.463318
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class_0 = Attrs('func.args', exclude=('args',))
    class_1 = Attrs('func.args', exclude=('args',))
    var_1 = class_0.__eq__(class_1)



# Generated at 2022-06-24 17:25:07.974140
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = BaseVariable("-+2")
    var_0.source = "-+2"
    var_0.exclude = []
    print(var_0.items(""))


# Generated at 2022-06-24 17:25:09.004067
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-24 17:25:24.716435
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = BaseVariable(float_0)
    float_1 = float_0
    var_1 = BaseVariable(float_1)
    assert var_0 == var_1
    float_2 = float()
    var_2 = BaseVariable(float_2)
    assert var_0 != var_2
    var_0.items(float_0)


# Generated at 2022-06-24 17:25:35.507619
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create a new instance of Float with default value
    float_0 = -395.60161
    source = 'float_0'
    # Create a new instance of Attrs with source = 'float_0'
    attrs_0 = Attrs(source)
    # Create a new instance of Keys with source = 'float_0'
    keys_0 = Keys(source)
    # Create a new instance of Indices with source = 'float_0'
    indices_0 = Indices(source)
    # Create a new instance of Exploding with source = 'float_0'
    exploding_0 = Exploding(source)
    test_frame = sys._getframe()
    # Call method items of class Attrs with arguments test_frame and False
    result_0 = attrs_0.items(test_frame, False)
    assert result_0

# Generated at 2022-06-24 17:25:39.569900
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert not test_case_0()
    var_0 = float_0 + float(3)
    bool_0 = bool(False)
    while (var_0 < float(27)) and (bool_0 or (var_0 < float(25))):
        float_1 = float(36) / float(7)
        float_0 = float(var_0) + float_1
        var_0 = float_0 + float(3)
    print(float_0)

# Generated at 2022-06-24 17:25:42.023982
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Indices('sqlite3.Row.rows')
    var_0


# Generated at 2022-06-24 17:25:44.260407
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    obj_0 = BaseVariable('1')
    obj_0.items()


# Generated at 2022-06-24 17:25:48.930973
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_0 = frame()
    test_BaseVariable_items_0 = BaseVariable('var_0')
    test_BaseVariable_items_0_0 = test_BaseVariable_items_0.items(frame_0)
    assert test_BaseVariable_items_0_0 == ()



# Generated at 2022-06-24 17:25:54.719852
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    This is a stub. You should fill in the contents of this function with the
    appropriate tests to ensure that BaseVariable.items() works as expected.
    """
    assert False, "Unimplemented"


# Generated at 2022-06-24 17:25:59.732252
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_1 = Keys()
    var_1.exclude = 'test'
    var_1.source = 'Keys'
    var_1.unambiguous_source = '(Keys)'
    try:
        var_1.items(var_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:26:01.238111
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    r = BaseVariable('var')
    assert r.items(r) == r

# Generated at 2022-06-24 17:26:02.617380
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = 4
    var = Attrs('x')
    assert var.items(x) == [('x', '4')]

# Generated at 2022-06-24 17:26:31.698145
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = float('inf')
    var_1 = float_0
    var_2 = utils.get_shortish_repr(var_0, normalize=True)
    var_3 = utils.get_shortish_repr(var_1, normalize=True)
    var_4 = var_0 < var_1
    var_5 = [('inf', var_2), ('-395.60161', var_3)]
    var_6 = [('inf', var_2), ('float_0', var_3)]
    var_7 = var_4
    Methods = var_7
    var_8 = Methods.items()
    var_9 = var_5
    var_10 = var_9


# Generated at 2022-06-24 17:26:34.636650
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    Attrs("float_0").items(utils.ExecutionFrame("float_0 = -395.60161"), normalize=True)


# Generated at 2022-06-24 17:26:41.895494
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = BaseVariable(float_0)
    float_1 = -395.60161
    var_1 = BaseVariable(float_1)
    float_2 = -395.60161
    var_2 = BaseVariable(float_2)
    float_3 = -395.60161
    var_3 = BaseVariable(float_3)
    float_4 = -395.60161
    var_4 = BaseVariable(float_4)
    float_5 = -395.60161
    var_5 = BaseVariable(float_5)
    float_6 = -395.60161
    var_6 = BaseVariable(float_6)
    float_7 = -395.60161
    var_7 = BaseVariable(float_7)
    float_8 = -395

# Generated at 2022-06-24 17:26:43.874701
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable.items(float_0) == -395.60161


# Generated at 2022-06-24 17:26:47.964450
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    cell_0 = FrameCell(test_case_0, 2)
    var_0 = Variable(str(float_0))
    value_0 = var_0.items(cell_0.frame)


# Generated at 2022-06-24 17:26:57.749789
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_0 = Keys('var_0')
    var_1 = keys('var_1')
    var_2 = indices('var_2')
    var_3 = attrs('var_3')
    var_4 = exploding('var_4')
    d_0 = {1: 15, 2: 21, 3: 29, 4: 36}
    l_0 = [11, 21, 27, 29, 36, 41]
    class Class_0():
        def __init__(self, x_0, y_0, z_0):
            self.a_0 = x_0
            self.b_0 = y_0
            self.c_0 = z_0
            self.t_0 = x_0 + y_0 + z_0

# Generated at 2022-06-24 17:27:07.961499
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bool_0 = True
    bool_1 = False
    bool_6 = bool_0
    bool_2 = bool_1
    bool_4 = bool_0
    bool_5 = bool_1
    bool_7 = bool_0
    bool_3 = bool_1
    complex_0 = complex(float_0, float_1)
    float_0 = 5.2
    float_1 = -395.60161
    float_2 = int_0
    float_3 = int_1
    float_4 = float_0
    float_5 = float_1
    float_6 = float_0
    float_7 = float_1
    float_8 = float_0
    float_9 = float_1
    int_0 = -47
    int_1 = -101
    int_2 = int_

# Generated at 2022-06-24 17:27:14.747353
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = BaseVariable(float_0)
    with mock.patch(
        '.frame.frame.Frame.f_locals',
        new_callable=mock.PropertyMock(return_value={"float_0": -395.60161})
    ) as mock_f_locals, mock.patch(
        '.frame.frame.Frame.f_globals',
        new_callable=mock.PropertyMock(return_value={})
    ) as mock_f_globals:
        mock_frame = mock.MagicMock()
        assert var_0.items(mock_frame) == [("-395.60161", "-395.60161")]


# Generated at 2022-06-24 17:27:20.027270
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    normalize = False
    Attrs('x').items(frame, normalize)
    Attrs('x.y').items(frame, normalize)

    Keys('x').items(frame, normalize)
    Indices('x').items(frame, normalize)
    Keys('x[5]["a"]').items(frame, normalize)
    Indices('x[5]').items(frame, normalize)


# Generated at 2022-06-24 17:27:26.078134
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = Attrs(float_0)
    var_1 = var_0.items(utils.FakeFrame(None, None, None, None, None, None, None, None, {'a': var_0}))
    var_0.code


# Generated at 2022-06-24 17:28:12.319121
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert int_0 == 2
    pass


# Generated at 2022-06-24 17:28:16.132217
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    new_instance = BaseVariable()
    var_0 = new_instance.items(['', (), [], {}, None, 0, 0.0, True, False, complex(0), b'', var_0, new_instance, type, Ellipsis, NotImplemented], )
    assert var_0 == ()


# Generated at 2022-06-24 17:28:18.744244
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class_0 = BaseVariable()
    assert class_0.items() == ()


# Generated at 2022-06-24 17:28:28.604786
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    try:
        var_0, list_0 = [], [2, 3, -395.60161, 0, 1]
        for var_0 in list_0:
            pass
        var_1, var_2 = 1, 1
        var_1, var_2 = 1, 1
    except Exception:
        raise
    else:
        pass
    var_2 = 3
    for var_1 in range(1):
        var_2 = var_2 >> var_2 & 3
    var_3 = -395.60161 & 1
    var_4 = float(-395.60161)
    var_5 = -395.60161 >> 1
    var_6 = float(var_5)
    var_7 = -395.60161 >> 1

# Generated at 2022-06-24 17:28:33.912388
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # case 0

    print('Running test case 0...')

    # initialize variables
    source = float_0
    frame = None
    normalize = False

    # setup test objects
    obj = BaseVariable(source)
    # execute method
    result = obj.items(frame, normalize)

    # compare results
    assert result == (), 'Results do not match'

    print('Running test case 0...Done')



# Generated at 2022-06-24 17:28:38.869822
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_frame = None
    var_0 = BaseVariable(test_frame, var_0)
    test_frame = None
    var_0 = BaseVariable(test_frame, var_0)
    var_0 = BaseVariable(test_frame, var_0)


# Generated at 2022-06-24 17:28:45.345514
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    str_0 = 'globals'
    str_1 = 'locals'
    dict_0 = {float_0:float_0, str_0:str_0}
    var_0 = BaseVariable(float_0, dict_0).items(dict_0, True)
    var_1 = BaseVariable(str_1, dict_0).items(dict_0, True)

# Generated at 2022-06-24 17:28:47.016078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable(float_0).items(frame) == ()


# Generated at 2022-06-24 17:28:55.553512
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize parameters
    import sys
    frame = sys._getframe()
    var_0 = BaseVariable('float_0')
    var_1 = var_0.items(frame)
    assert var_1 == (('float_0', '-395.60161'),)
    var_0 = BaseVariable('float_0', ('x',))
    var_1 = var_0.items(frame)
    assert var_1 == (('float_0', '-395.60161'),)


# Generated at 2022-06-24 17:29:02.022406
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import currentframe
    frame = currentframe().f_back
    var_0 = BaseVariable()
    var_0.source = 'x.y.z'
    var_0.exclude = ('__dict__',)
    var_0.code = compile(var_0.source, '<variable>', 'eval')
    if needs_parentheses(var_0.source):
        var_0.unambiguous_source = '({})'.format(var_0.source)
    else:
        var_0.unambiguous_source = var_0.source
    var_0.float_0 = float('-395.60161')
    var_0.var_0 = needs_parentheses(var_0.float_0)
    var_0.list_0 = []
    var_0.dict_0

# Generated at 2022-06-24 17:30:45.990066
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    int_0 = -678
    dict_0 = {'element_0': 472, 'element_1': -235}
    dict_1 = {}
    str_0 = 'b9!@k-Ip'
    str_1 = ''
    float_1 = -146.5457
    dict_2 = {'element_0': -347, 'element_1': -566}
    dict_3 = {}

    t0_0 = BaseVariable(float_0)
    t0_0.items(None, True)
    t0_1 = BaseVariable(int_0)
    t0_1.items(None, True)
    t0_2 = BaseVariable(dict_0)
    t0_2.items(None, True)
    t0_

# Generated at 2022-06-24 17:30:55.981776
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # Test case 0
    var_0 = Attrs('h')
    test_0 = var_0.items('')

    # Test case 1
    var_1 = BaseVariable('')
    test_1 = var_1.items('')

    # Test case 2
    var_2 = Indices('p')
    test_2 = var_2.items('')

    # Test case 3
    var_3 = Keys('set.add')
    test_3 = var_3.items('')

    # Test case 4
    var_4 = Exploding('>')
    test_4 = var_4.items('')



# Generated at 2022-06-24 17:30:59.344628
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    expr_0 = float_0
    vars_0 = BaseVariable(expr_0)
    assert not vars_0.items(float_0)


# Generated at 2022-06-24 17:31:05.938373
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test_index = 0
    # str_0 = string
    # expected_result = set()
    # var_0 = list()
    # var_1 = list()
    # var_2 = list()
    frame_0 = utils.Frame(True, test_index)
    result = BaseVariable(float_0).items(frame_0)

    assert result == {test_case_0}


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 17:31:11.289009
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    float_0 = -395.60161
    var_0 = Attrs(float_0)
    line_0 = next(var_0.items(test_case_0))
    assert line_0 == '-395.60161', 'Expected: <"%s">, but was: <%s>' % ('-395.60161', line_0)

# Generated at 2022-06-24 17:31:17.031569
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = FrameSummary(
        frame={"f_code": {"co_code": [100, 0, 90, 10, 108, 0, 100, 1, 90, 9]},
               "f_locals": {'var_0': float_0,
                            'var_1': float_0,
                            },
               "f_globals": {"f_code": {"co_code": [100, 0, 90, 10, 108, 0, 100, 1, 90, 9]}}
               }
    )

    class BaseVariable_0(BaseVariable):
        code = compile(var_0, '<variable>', 'eval')

    BaseVariable_0.items(frame)
