

# Generated at 2022-06-20 12:38:15.326547
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('xyz', exclude='abc') == CommonVariable('xyz', exclude='abc')
    assert CommonVariable('xyz', exclude='abc') != CommonVariable('xyz', exclude='xxx')
    assert CommonVariable('xyz', exclude='abc') != CommonVariable('zzz', exclude='abc')

# Generated at 2022-06-20 12:38:17.007479
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('a')
    assert hash(v) == hash((v.source))



# Generated at 2022-06-20 12:38:18.660701
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    assert A('a') == A('a')
    assert A('b') != A('a')
    assert A('a', 'b') != A('a')

# Generated at 2022-06-20 12:38:23.364891
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('a.b[3]', exclude=('c',))._fingerprint == (Indices, 'a.b[3]', ('c',))
    assert Indices('a.b[3]', exclude='c')._fingerprint == (Indices, 'a.b[3]', ('c',))
    assert Indices('a.b[3]', exclude='d')._fingerprint == (Indices, 'a.b[3]', ('d',))


# Generated at 2022-06-20 12:38:28.816384
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices("")
    assert indices._slice == slice(None, None, None)
    assert indices._source == ""
    assert indices._exclude == ()
    assert indices._code == compile("", '<variable>', 'eval')
    assert indices._unambiguous_source == ""
    indices = Indices("", exclude=("",))
    assert indices._exclude == ("",)


# Generated at 2022-06-20 12:38:35.435293
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('a')
    assert Attrs('a', exclude=())
    assert Attrs('a', exclude='b')

    assert Attrs('a').source == 'a'
    assert Attrs('a').exclude == ()
    assert Attrs('a', exclude='b').exclude == ('b',)

    assert Attrs('a').unambiguous_source == 'a'
    assert Attrs('a.b').unambiguous_source == '(a.b)'



# Generated at 2022-06-20 12:38:45.616481
# Unit test for constructor of class Attrs
def test_Attrs():
    def test_gen():
        yield 1

    obj1 = Attrs('result')
    assert obj1.source == 'result'
    assert obj1.exclude == tuple()
    assert obj1.unambiguous_source == 'result'
    assert obj1.items(None) == list()
    assert obj1.items(None, normalize = True) == list()

    obj2 = Attrs('result', exclude=('a', 'b'))
    assert obj2.source == 'result'
    assert obj2.exclude == ('a', 'b')
    assert obj2.unambiguous_source == 'result'
    assert obj2.items(None) == list()
    assert obj2.items(None, normalize = True) == list()

    obj3 = Attrs('list(result)')
    assert obj3.source

# Generated at 2022-06-20 12:38:50.176031
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable('foo.bar')
    assert var.source == 'foo.bar'
    assert var.code == compile('foo.bar', '<variable>', 'eval')
    assert var.unambiguous_source == '(foo.bar)'
    assert 'foo.bar' in str(var)

# Generated at 2022-06-20 12:38:55.759570
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def test(source, value):
        assert needs_parentheses(source) is value
    test('f', False)
    test('f(a)', True)
    test('f(a, b)', True)
    test('f.x', False)
    test('f.x.y', False)
    test('f.x.y.z', False)
    test('f.x[y]', True)
    test('f[x].y', False)
    test('f[x][y]', True)

# Generated at 2022-06-20 12:38:58.806923
# Unit test for constructor of class Exploding
def test_Exploding():
    obj = []
    v = Exploding('')
    try:
        v.source = obj
        assert False
    except ValueError:
        pass
    assert v._items(obj) == []


# Generated at 2022-06-20 12:39:08.964904
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash((BaseVariable, 'x', ()))
    assert hash(BaseVariable('x', exclude=('y',))) == hash((BaseVariable, 'x', ('y',)))


# Generated at 2022-06-20 12:39:13.237314
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('a.x')
    assert needs_parentheses('(a).x')
    assert needs_parentheses('a[' + '5+5' * 1000 + ']')

# Unit tests for function get_key_source

# Generated at 2022-06-20 12:39:15.275085
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import pdb
    pdb.Pdb(skip=['django.*']).set_trace()

# Generated at 2022-06-20 12:39:17.608378
# Unit test for constructor of class Indices
def test_Indices():
    with pytest.raises(AssertionError):
        ind = Indices('abc', ('a',))[1:5]

# Generated at 2022-06-20 12:39:19.089493
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("value", "exclude")
    b = BaseVariable("value", "exclude")
    assert(a == b)



# Generated at 2022-06-20 12:39:21.987712
# Unit test for constructor of class Keys
def test_Keys():
    print('Keys(\'x\')._fingerprint')
    result = (type(Keys('x')), 'x', ())
    print(result)


# Generated at 2022-06-20 12:39:30.971441
# Unit test for constructor of class Exploding
def test_Exploding():
    mapping = {'a':'1','b':'2','c':'3'}
    mapping2 = {'x':'y','z':'w'}
    mapping['d'] = mapping2
    mapping2['h'] = mapping

    variable_to_test = Exploding('r', exclude=('r.d.h', 'r', 'r.d.x'))


# Generated at 2022-06-20 12:39:34.778879
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    def check(source, unambiguous_source):
        assert unambiguous_source == BaseVariable(source).unambiguous_source
        assert unambiguous_source == BaseVariable(unambiguous_source).unambiguous_source

    # see issue #178
    check('foo', 'foo')
    check('foo.bar', '(foo).bar')


# Generated at 2022-06-20 12:39:44.958103
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import math
    import sys
    frame = inspect.currentframe()
    source = 'math'
    variable = BaseVariable(source, exclude='')
    assert variable.source == source
    assert variable.exclude == ('')
    assert variable.code == compile(source, '<variable>', 'eval')
    assert variable.unambiguous_source == 'math'
    frame1 = sys._getframe() 
    main_value = eval(variable.code, frame1.f_globals or {}, frame1.f_locals)
    assert main_value == math
    assert variable.items(frame1) == [(source, 'module math')]
    assert variable.items(frame1, normalize=True) == [(source, 'module math')]


# Generated at 2022-06-20 12:39:50.599906
# Unit test for constructor of class Indices
def test_Indices():
    main_value = {1:'AMZN'}
    ind_obj = Indices('main_value')
    assert ind_obj._slice == slice(None)
    assert ind_obj._keys(main_value) == [0]
    assert ind_obj._format_key(0) == '[0]'
    assert ind_obj._get_value(main_value, 0) == 1


if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-20 12:39:56.302853
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable(source='a')
    v2 = BaseVariable(source='b')

    assert v1 == v1
    assert not v1 == v2
    assert not v1 == object()
    assert not v1 == 123

# Generated at 2022-06-20 12:40:04.192164
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var1 = CommonVariable('a')
    var2 = CommonVariable('a')
    var3 = CommonVariable('b')
    print(var1 == var2) # True
    print(var2 == var3) # False
    print(var3 == var1) # False
    print(hash(var1) == hash(var2)) # True
    print(hash(var2) == hash(var3)) # False
    print(hash(var3) == hash(var1)) # False


# Generated at 2022-06-20 12:40:11.158803
# Unit test for function needs_parentheses
def test_needs_parentheses():
    test_cases = [
        ('a', False),
        ('a.b', False),
        ('a()', True),
        ('a.b()', True),
        ('a.b.c', False),
        ('a().b', True),
        ('a().b.c', True),
        ('a.b()[c]', True),
        ('a[b][c]', False),
        ('a.b[c]()[d]', True),
    ]
    for test_case in test_cases:
        assert needs_parentheses(test_case[0]) == test_case[1]

# Generated at 2022-06-20 12:40:13.123239
# Unit test for constructor of class Exploding
def test_Exploding():
    var = pycompat.StringIO('test')
    ex = Exploding('var')
    print(ex.items(var))
    assert isinstance(ex, BaseVariable)
# End of unit test

# Generated at 2022-06-20 12:40:18.532607
# Unit test for constructor of class Indices
def test_Indices():
    """
    >>> indice = Indices('lst')
    >>> indice._slice
    slice(None, None, None)
    """

# Generated at 2022-06-20 12:40:23.043474
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    x = BaseVariable(1)
    y = BaseVariable(2)
    print("x.__hash__() = %s" % x.__hash__())
    assert x.__hash__() != y.__hash__()
test_BaseVariable___hash__()

# Generated at 2022-06-20 12:40:32.527633
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a')
    assert Keys('a', 'b')
    a = Keys('a')
    assert a
    assert a._fingerprint
    assert isinstance(a._fingerprint, tuple)
    assert isinstance(a._fingerprint[0], type)
    assert a._format_key
    assert a.__eq__(a)
    assert a.__hash__()
    assert a.__init__
    assert a.__init__('a', 'b')
    assert a._get_value
    assert a._items
    assert a._keys
    assert a._safe_keys
    assert Keys.__getitem__(a, slice(1,2))
    assert a.items
    assert a.source
    assert a.unambiguous_source
    assert a.exclude
    assert a.code

# Unit test

# Generated at 2022-06-20 12:40:34.181383
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('source', 'exclude'))
    assert hash(BaseVariable('source'))


# Generated at 2022-06-20 12:40:40.856106
# Unit test for constructor of class Keys
def test_Keys():
    k1 = Keys('a')
    k2 = Keys('b')
    k3 = Keys('a')
    k4 = Keys('a', 'b')
    k5 = Keys('a', 'c')
    k6 = Keys('a', ['b'])

    assert k1 == k3
    assert k1 == k1
    assert k1 != k2
    assert k1 != k4
    assert k4 == k5
    assert k5 == k6
    assert k4 != k6
    assert k4.__dict__ == Keys('a', 'b').__dict__
    assert k4.__dict__ == Keys('a', ['b']).__dict__

# Generated at 2022-06-20 12:40:47.839882
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # create an instance of dict
    d = dict()
    # create frames
    def f1():
        d['x'] = 1
        d['y'] = 2
        d['z'] = 3
        f2()

    def f2():
        d['x'] = 10
        d['y'] = 20
        f3()

    def f3():
        d['x'] = 100
        d['y'] = 200
        d['z'] = 300

    # call f1()
    f1()
    # get the frame stack
    frame = sys._getframe()
    # create an instance of class BaseVariable
    my_source = 'd'
    my_exclude = ()
    test_instance = BaseVariable(my_source, my_exclude)
    # call method items of test_instance
    result = test_

# Generated at 2022-06-20 12:40:54.314113
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x').source == 'x'
    # Test the use of exclude, when there is different behavior in Python 2 and 3.
    assert Keys('x', exclude='__dict__').source == 'x'

# Generated at 2022-06-20 12:40:54.825830
# Unit test for constructor of class Indices
def test_Indices():
    Indices("a[1]")

# Generated at 2022-06-20 12:40:56.041057
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable("bar")
    assert(var.source == "bar")
    assert(var.exclude == ())


# Generated at 2022-06-20 12:41:02.124154
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x+1')
    assert needs_parentheses('x*11')
    assert needs_parentheses('1*x')
    assert needs_parentheses('1+x')
    assert needs_parentheses('(x)')
    assert needs_parentheses('()')
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x[0]')
    assert not needs_parentheses('x["y"]')
    assert not needs_parentheses('x.y.z')

# Generated at 2022-06-20 12:41:07.555554
# Unit test for constructor of class Indices
def test_Indices():
    ind = Indices('i', exclude=('__class__', '__dict__'))
    keys = [k for k, _ in ind.items(sys._getframe())]
    assert keys == ['i[0]', 'i[1]', 'i[2]', 'i[3]']

# Generated at 2022-06-20 12:41:11.101782
# Unit test for function needs_parentheses
def test_needs_parentheses():
    from nose.tools import assert_false, assert_true
    assert_false(needs_parentheses('a_b'))
    assert_false(needs_parentheses('a_b.c'))
    assert_false(needs_parentheses('a_b.c_d'))
    assert_true(needs_parentheses('a.b'))
    assert_true(needs_parentheses('a.b_c'))
    assert_true(needs_parentheses('a.b_c.d.e'))

# Generated at 2022-06-20 12:41:15.079296
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {"k1":"v1", "k2":"v2"}
    cls = Exploding()
    cls.source ="main_value"
    cls.source_ = cls.source
    print (cls.source_)
    #cls._items(main_value)

if __name__ == "__main__":
    test_Exploding()

# Generated at 2022-06-20 12:41:19.814973
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('a')
    try:
        obj[1.5]
    except AssertionError:
        print('test_Indices___getitem__ Pass')
    else:
        print('test_Indices___getitem__ Fail')

test_Indices___getitem__()

# Generated at 2022-06-20 12:41:24.892886
# Unit test for constructor of class Keys
def test_Keys():
    foo = Keys('foo')
    bar = Keys('bar')
    assert hash(foo) != hash(bar)
    assert foo == Keys('foo')
    assert foo != Keys('bar')
    assert Keys('foo') != Keys('foo', 'baz')
    assert Keys('foo', 'baz') != Keys('foo', 'bar')

# Generated at 2022-06-20 12:41:27.929046
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable = CommonVariable('y', exclude='x')
    frame = {}
    assert variable.items(frame) == [('y', repr(None))]
    frame['y'] = 1
    assert variable.items(frame) == [('y', '1')]

# Generated at 2022-06-20 12:41:40.325798
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def fn(arg1, arg2):
        a = arg1
        b = arg2
        print(a + b)

    source = 'arg2'
    exclude = 'arg1'
    f = fn
    fn_globals = f.__globals__
    fn_locals = f.__code__.co_varnames
    fn_defaults = f.__defaults__
    code = compile(source, '<source>', 'eval')
    import dis
    dis.dis(code)
    print(code.co_code)
    print(code.co_varnames)
    print(code.co_names)
    print(code.co_const)
    print(code.co_argcount)
    print(code.co_cellvars)

# Generated at 2022-06-20 12:41:43.248290
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable(source='aaa', exclude='bbb').source == 'aaa'
    assert BaseVariable(source='aaa', exclude='bbb').exclude == ('bbb',)


# Generated at 2022-06-20 12:41:45.321767
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('x')
    b = BaseVariable('x')
    print(a == b)
    print(a == None)


# Generated at 2022-06-20 12:41:46.585967
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('a')[0:1]._slice == (0, 1)

# Generated at 2022-06-20 12:41:53.346536
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a', exclude=()).items({'a':{'b': 0,'d': 1}}, normalize=True)
    for i in k:
        print(i)
    assert(k[0][0] == 'a')
    assert((k[1][0] != 'a.d') and (k[1][0] != 'a[d]'))
    assert(k[1][0] == 'a.b' or k[1][0] == 'a[b]')

# Generated at 2022-06-20 12:41:54.880302
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable("x","y")
    assert(var.source == "x")

# Unit tests for items()

# Generated at 2022-06-20 12:42:00.660598
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Create a new instance of class Indices with source = 'x' and exclude = ()
    # Assign the result to the variable, indices
    indices = Indices('x')

    #Create a new instance of class Indices with source = 'x' and exclude = ()
    # and slice object which is expression indices[1:3] evaluate to.
    # Assign the result to the variable, slice_indices
    slice_indices = indices[1:3]

    # Test for instance attribute for class Indices, _slice
    assert slice_indices._slice == slice(1,3,None)

# Generated at 2022-06-20 12:42:07.175871
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a':1, 'b':2, 'c':3}
    try:
        k = Keys(d)
        if k.source == d:
            test = True
            print("Unit test for constructor of class Keys: passed")
            print("\n")
        else:
            test = False
    except Exception:
        test = False
    finally:
        return test


# Generated at 2022-06-20 12:42:08.760750
# Unit test for constructor of class Keys
def test_Keys():
    instance = Keys('variable')
    assert isinstance(instance, Keys)
    assert isinstance(instance, BaseVariable)


# Generated at 2022-06-20 12:42:10.442061
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    #BaseVariable()
    #BaseVariable(source, exclude=())
    assert BaseVariable



# Generated at 2022-06-20 12:42:25.681557
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        # Test when source is not a string
        import datetime
        source = datetime.datetime()
        variable = BaseVariable(source)
    except TypeError:
        pass
    else:
        raise Exception('Cannot detect TypeError thrown by type_checker.type_checker()')
    # Test when source is a string
    source = "12"
    variable = BaseVariable(source)
    assert variable.source == source
    assert variable.unambiguous_source == source

# Test the method items() in class BaseVariable

# Generated at 2022-06-20 12:42:26.687501
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('main_value')[1:3]

# Generated at 2022-06-20 12:42:28.963026
# Unit test for constructor of class Indices
def test_Indices():
    x = Indices('a')
    assert x._fingerprint == (~Indices, 'a', ())

if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-20 12:42:32.187406
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .vars import Indices
    result = Indices('asd')
    print (result.items())
    print ("\n")
    result = Indices('asd')[:3:2]
    print (result.items())


if __name__ == "__main__":
    test_Indices___getitem__()

# Generated at 2022-06-20 12:42:39.424281
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert i.source == 'a'
    assert i.exclude == ()
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.unambiguous_source == 'a'
    assert i._slice == slice(None)
    assert i.items(None, normalize=False) == _items_of_Indices(None, normalize=False)

#  Unit test for method items of class Indices

# Generated at 2022-06-20 12:42:48.447916
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices(0, ())
    # if method __getitem__ is called with a slice object
    assert isinstance(var.__getitem__(slice(None)), Indices)
    assert var.__getitem__(slice(None))._slice == slice(None)

    assert isinstance(var.__getitem__(slice(0)), Indices)
    assert var.__getitem__(slice(0))._slice == slice(0)

    assert isinstance(var.__getitem__(slice(0, 1)), Indices)
    assert var.__getitem__(slice(0,1))._slice == slice(0,1)

    assert isinstance(var.__getitem__(slice(0, 1, 2)), Indices)
    assert var.__getitem__(slice(0, 1, 2))._slice == slice

# Generated at 2022-06-20 12:42:53.686554
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('i')) == hash(BaseVariable('i'))
    assert hash(BaseVariable('i')) != hash(BaseVariable('j'))
    assert hash(BaseVariable('i', (1, 2))) == hash(BaseVariable('i', [1, 2]))
    assert hash(BaseVariable('i', (1, 2))) != hash(BaseVariable('i', [2, 3]))

# Generated at 2022-06-20 12:43:04.442902
# Unit test for constructor of class Indices
def test_Indices():
    import pytest
    from inspect import getsource
    from . import utils
    # Define simple sequence
    seq = [1,2,3]
    # Construct instance of Indices for all elements
    ai = Indices('seq')
    # We do not define excludes but lets test it anyway
    assert ai.exclude == ()
    # Get list of items
    items = ai.items(None)
    # Check whether items was returned as a list
    assert isinstance(items, list)
    # Check whether length of list is 3
    assert len(items) == 3
    # Check whether item[0] is a pair (source,value)
    assert isinstance(items[0], tuple) and len(items[0]) == 2
    # Check whether the sequence of items is correct

# Generated at 2022-06-20 12:43:05.339465
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    keys = Indices('foo')
    keys['bar']

# Generated at 2022-06-20 12:43:09.944830
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def check(source, expected):
        result = needs_parentheses(source)
        assert result == expected, (
            'needs_parentheses({!r}) should be {}; got {} instead'
            .format(source, expected, result)
        )
    check('foo', False)
    check('(1 + 1)', False)
    check('1 - 1', True)
    check('\nfoo\n', True)
    check('not foo', True)

# Generated at 2022-06-20 12:43:22.831798
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("__init__",("__init__","")) == BaseVariable("__init__",("__init__",""))
    assert BaseVariable("__init__",("__init__","")) == BaseVariable("__init__",("__init__",))
    assert BaseVariable("foo",("bar","")) == BaseVariable("foo",("bar",""))
    assert BaseVariable("foo",("bar","")) == BaseVariable("foo",("bar",))
    assert BaseVariable("foo",("bar","")) == BaseVariable("foo",("bar",))
    assert BaseVariable("foo",()) == BaseVariable("foo",())


# Generated at 2022-06-20 12:43:24.848188
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from pudb.settings import get_setting
    assert get_setting('x') == 'x'


# Generated at 2022-06-20 12:43:31.810081
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('ksdjf', exclude=['fdjsfdj'])
    assert c.source == 'ksdjf'
    assert c.exclude == ('fdjsfdj',)
    assert c.code == compile('ksdjf', '<variable>', 'eval')
    assert c.unambiguous_source == 'ksdjf'
    assert c._fingerprint == (CommonVariable, 'ksdjf', ('fdjsfdj',))



# Generated at 2022-06-20 12:43:39.264586
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("x", "a")
    var2 = BaseVariable("x", "a")
    var3 = BaseVariable("x", "b")
    var4 = BaseVariable("y", "a")
    var5 = Keys("x", "a")
    var6 = Keys("x", "a")
    var7 = Keys("x", "b")
    var8 = Keys("y", "a")
    assert (var1 == var2) and not (var1 == var3) and not (var1 == var4) and not (var1 == var5)
    assert (var5 == var6) and not (var5 == var7) and not (var5 == var8)

# Generated at 2022-06-20 12:43:40.970801
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('x')
    assert x.source == 'x'
    assert x.exclude == ()



# Generated at 2022-06-20 12:43:48.591146
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('this', exclude=['id'])
    assert x.source == 'this'
    assert x.exclude == ['id']
    assert x.code == compile('this', '<variable>', 'eval')
    assert x.unambiguous_source == '({})'.format('this')
    assert x._fingerprint == (Attrs, 'this', ('id',))

# Generated at 2022-06-20 12:43:58.644906
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class Foo():
        def __init__(self, name):
            self.name = name
    class Bar():
        def __init__(self):
            self.xx = Foo('xx')
            self.yy = Foo('yy')
        @classmethod
        def _keys(cls):
            yield 'xx'
            yield 'yy'
    bar = Bar()
    assert "bar={}.xx".format('bar.xx') == Keys('bar')._items(bar)[1][0]
    assert "bar={}.yy".format('bar.yy') == Keys('bar')._items(bar)[2][0]
    assert "bar={}.name".format('bar.xx.name') == Keys('bar')._items(bar)[1][1]

# Generated at 2022-06-20 12:44:04.260226
# Unit test for constructor of class Attrs
def test_Attrs():
    import sys
    print(Attrs('sys.path').source)
    print(Attrs('sys.path').exclude)
    print(Attrs('sys.path').code)
    print(Attrs('sys.path').unambiguous_source)
    assert Attrs('sys.path') == Attrs('sys.path')
    assert Attrs('sys.path') != Attrs('sys.modules')
    assert isinstance(Attrs('sys.path'), BaseVariable)
    

# Generated at 2022-06-20 12:44:06.348815
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('parentheses')
    assert needs_parentheses('1 + 2')
    assert not needs_parentheses('(a + b) * c')

# Generated at 2022-06-20 12:44:18.293458
# Unit test for constructor of class Exploding
def test_Exploding():
    class C(object):
        def __init__(self, a):
            self.a = a
        def __getitem__(self, key):
            return self.a[key]
        def keys(self):
            return self.a.keys()
    v = C({'a': 1, 'b': 2})
    assert ([k for k, v in Exploding('v').items(v)] == ['v', 'v[a]', 'v[b]'])
    v = C([1, 2])
    assert ([k for k, v in Exploding('v').items(v)] == ['v', 'v[0]', 'v[1]'])
    v = C({'a': 1, 'b': {'c': 11}})

# Generated at 2022-06-20 12:44:38.317145
# Unit test for constructor of class Attrs
def test_Attrs():
    foo = Attrs('foo')
    assert foo.source == 'foo'
    assert foo.code.co_name == '<module>'
    assert foo.unambiguous_source == 'foo'



# Generated at 2022-06-20 12:44:39.818783
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) != hash(BaseVariable('y'))


# Generated at 2022-06-20 12:44:41.630214
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("a")[1:3]
    assert a.source == "a"
    assert a._slice == slice(1, 3)

# Generated at 2022-06-20 12:44:43.526287
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("x")
    indices_slice = indices[1:3]
    print(indices_slice)

# Generated at 2022-06-20 12:44:51.807425
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    main_value = "Value"
    key = "value"
    source = "source"
    exclude = ("exclude",)
    code = compile(source, '<variable>', 'eval')
    variable = CommonVariable(source, exclude)
    variable.source == source
    variable.exclude == exclude
    variable.code == code
    variable.unambiguous_source == source
    variable._items(main_value, normalize=True)
    variable._safe_keys(source)
    variable._keys(key)
    variable._format_key(key)
    variable._get_value(main_value, key)
    variable._fingerprint[0] == CommonVariable
    variable._fingerprint[1] == source
    variable._fingerprint[2] == exclude
    hash(variable)
    variable.__hash__()
    id

# Generated at 2022-06-20 12:44:54.388153
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[4:7]
    assert b.source == 'a'
    assert b.unambiguous_source == 'a'


# Generated at 2022-06-20 12:45:01.935151
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('(x).y')
    assert needs_parentheses('x.y(z)')
    assert not needs_parentheses('(x.y)(z)')
    assert needs_parentheses('x().y')
    assert needs_parentheses('(x)().y')
    assert not needs_parentheses('(x()).y')

# Generated at 2022-06-20 12:45:05.575221
# Unit test for constructor of class Exploding
def test_Exploding():
    ex = Exploding('error')
    assert ex.source == 'error'
    assert ex.exclude == ()
    assert isinstance(ex.code, type(compile))
    assert ex.unambiguous_source == 'error'


# Generated at 2022-06-20 12:45:12.689741
# Unit test for constructor of class Exploding
def test_Exploding():
    d = {"1": 1, "2": 2, "3": 3}
    d1 = Exploding("d", exclude = "1")
    assert d1 is not None
    assert d1.__dict__ != None
    assert d1.source == "d"
    assert d1.exclude == "1"
    assert d1.code != None
    assert d1.unambiguous_source == "d"

    items = d1.items(d)
    assert (len(items) == 2)
    assert items[0] == ('d', '{2: 2, 3: 3}')
    assert items[1] == ('d[2]', '2')

# Generated at 2022-06-20 12:45:15.074865
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    if isinstance(BaseVariable()._fingerprint, tuple):
        assert isinstance(BaseVariable()._fingerprint, tuple)
        assert BaseVariable().__hash__() == hash(BaseVariable()._fingerprint)


# Generated at 2022-06-20 12:46:05.094450
# Unit test for constructor of class Keys
def test_Keys():
    my_keys = Keys("my_keys")
    assert my_keys.source == "my_keys"
    assert my_keys.exclude is ()
    assert my_keys.code == compile("my_keys", '<variable>', 'eval')
    assert my_keys.unambiguous_source == "my_keys"
    assert my_keys.items("frame") is ()

    my_keys_exclude_one = Keys("my_keys", ["one"])
    assert my_keys_exclude_one.exclude == ("one",)
    assert my_keys_exclude_one.exclude is not ("one",)
    assert my_keys_exclude_one.exclude is not ("one", "one")


# Generated at 2022-06-20 12:46:07.425213
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')
    assert var[:] == Indices('var', [])
    assert var[:1] == Indices('var', [])[:1]


# Generated at 2022-06-20 12:46:12.801758
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('req.headers').items(None) == [('req.headers', '<unknown>')]
    assert Attrs('req.headers.get').items(None) == [('req.headers.get', '<unknown>')]
    assert Attrs('[1,2,3]').items(None) == [('[1,2,3]', '<unknown>')]
    assert Attrs('{}').items(None) == [('{}', '<unknown>')]
    #assert Attrs('req').items(None) == [('req', '<unknown>')]


# Generated at 2022-06-20 12:46:19.338410
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("a")._slice == slice(None)
    assert Indices("a")[2:3]._slice == slice(2,3)
    assert Indices("a")[:3]._slice == slice(None, 3)
    assert Indices("a")[3:]._slice == slice(3, None)
    assert Indices("a")[4:5:2]._slice == slice(4, 5, 2)

# Generated at 2022-06-20 12:46:29.956214
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import pytest
    v1 = BaseVariable.__new__(BaseVariable)
    v1.source = 'a'
    v1._fingerprint = ()
    v2 = BaseVariable.__new__(BaseVariable)
    v2.source = 'a'
    v2._fingerprint = ()
    assert hash(v1) == hash(v2)

    # Unit test for method __eq__ of class BaseVariable
    v1 = BaseVariable.__new__(BaseVariable)
    v1.source = 'a'
    v1._fingerprint = ()
    v2 = BaseVariable.__new__(BaseVariable)
    v2.source = 'a'
    v2._fingerprint = ()
    assert v1 == v2

    # Unit test for method __init__ of class Attrs
    v = Attrs.__new

# Generated at 2022-06-20 12:46:33.267325
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert i.source == 'a'
    assert i.exclude == ()
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.unambiguous_source == 'a'


# Generated at 2022-06-20 12:46:40.082544
# Unit test for constructor of class Attrs
def test_Attrs():
    # Empty string
    assert Attrs('')
    # Space only
    assert Attrs('  ')
    # Invalid character in variable name
    assert Attrs('.')
    assert Attrs('1')
    assert Attrs('_')
    assert Attrs('Z_')
    assert Attrs('z_')
    assert Attrs('z_1')
    assert Attrs('z_A')
    assert Attrs('ä')
    assert Attrs('å')
    assert Attrs('ö')
    assert Attrs('Z1')
    assert Attrs('_1')
    assert Attrs('ä_1')
    assert Attrs('å_1')
    assert Attrs('ö_1')
    assert Attrs('eval_1')
    assert Attrs('print_1')
    assert Attrs('input_1')


# Generated at 2022-06-20 12:46:45.964299
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .utils import Any, Equal
    from .models import Variable, Frame
    from .matchers import Matcher, MatcherResult
    v = Indices("source")
    frame = Frame()
    frame.f_locals["source"] = [1, 2, 3, 4, 5]
    def f():
        return v[:2].items(frame)
    assert f() == [("source[0]", "1"), ("source[1]", "2")]

# Generated at 2022-06-20 12:46:47.494279
# Unit test for constructor of class Exploding
def test_Exploding():
    assert hasattr(Exploding(''), '_items')


# Generated at 2022-06-20 12:46:55.156144
# Unit test for constructor of class Attrs
def test_Attrs():
    # simple case
    a = Attrs(
        'req',
        exclude=('user', 'cookies')
    )
    # expected result
    a_exp = Attrs.__new__(Attrs)
    a_exp.exclude = ('user', 'cookies')
    a_exp.source = 'req'
    a_exp.unambiguous_source = 'req'
    a_exp.code = compile('req', '<variable>', 'eval')
    # compare actual with expected
    assert a_exp.__dict__ == a.__dict__
    # test parentheses case
    a_paren = Attrs(
        'request.user',
        exclude=('user', 'cookies')
    )
    # expected result
    a_paren_exp = Attrs.__new__(Attrs)
    a_