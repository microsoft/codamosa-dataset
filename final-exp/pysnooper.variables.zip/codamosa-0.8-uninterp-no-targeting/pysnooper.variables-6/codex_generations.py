

# Generated at 2022-06-20 12:38:20.281740
# Unit test for constructor of class Exploding
def test_Exploding():
    assert type(Exploding('abc')) == Exploding


# Generated at 2022-06-20 12:38:23.646686
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('({})'.format('x'))
    assert not needs_parentheses('({}).y'.format('x'))

# Unit tests for BaseVariable

# Generated at 2022-06-20 12:38:29.310384
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import pickletools
    import pickle
    # create a BaseVariable object for the testing
    TestBaseVariable = BaseVariable(source="Hello World", exclude=("World"))
    TestBaseVariable.code = 10
    TestBaseVariable.unambiguous_source = "Hello World"
    # dumps the object as a byte object which is easy to compare
    dumps_byte_object = pickle.dumps(TestBaseVariable)
    # dumps the object as a readable string which is easy to check
    dumps_readable_string = pickletools.dis(dumps_byte_object)
    # create an expected dumps_readable_string

# Generated at 2022-06-20 12:38:39.141482
# Unit test for constructor of class Exploding
def test_Exploding():
    def test(cls, source, exclude, isinstance_main_value):
        variable = Exploding(source, exclude)
        assert isinstance(variable, cls)
        if isinstance(exclude, tuple):
            assert variable.exclude == exclude
        else:
            assert variable.exclude == [exclude]
        assert variable.source == source
        assert variable._get_value(main_value, 0) == main_value[0]

    main_value = [1, 2, 3]
    test(Indices, 'data', (), type(main_value))
    test(Indices, 'data', ('attrib', 'attrib2'), type(main_value))
    test(Indices, 'data', 'attrib', type(main_value))
    test(Indices, 'data', 0, type(main_value))

# Generated at 2022-06-20 12:38:42.532374
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('x').code.co_code == b'x'
    assert Attrs('x').unambiguous_source == 'x'
    assert Attrs('(x)').unambiguous_source == '(x)'


# Generated at 2022-06-20 12:38:45.663795
# Unit test for constructor of class Keys
def test_Keys():
    foo = Keys("foo")

    assert foo.source == "foo"
    assert foo.exclude == ()
    assert "foo" in repr(foo.code)
    assert foo.unambiguous_source == "foo"

# Generated at 2022-06-20 12:38:55.386674
# Unit test for method items of class BaseVariable

# Generated at 2022-06-20 12:38:57.818250
# Unit test for constructor of class Keys
def test_Keys():
    with open('my_source_code.txt') as f:
        read_data = f.read()
    print(Keys(read_data))

# Generated at 2022-06-20 12:38:59.230612
# Unit test for constructor of class Indices
def test_Indices():
    variable = Indices('x')
    variable.source == 'x'


# Generated at 2022-06-20 12:39:03.429372
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
	assert BaseVariable.__hash__(BaseVariable)

	# Test for exceptions raised in the method
	try:
		BaseVariable.__hash__(BaseVariable.__init__)
	except Exception as ex:
		assert isinstance(ex, TypeError)


# Generated at 2022-06-20 12:39:13.752569
# Unit test for constructor of class Indices
def test_Indices():
    from . import utils
    from . import pylib_utils
    import sys

    utils.set_debug_flag(True)

    assert isinstance(Indices('a'), BaseVariable)

    pylib_utils.set_debug_flag(True)

    assert isinstance(Indices('a'), BaseVariable)
    print >>sys.stderr, '\nPassed unit test for class Indices\n'

# Generated at 2022-06-20 12:39:24.532128
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class BaseVariableChecker(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    bv = BaseVariableChecker('my_variable', ('a', 'b'))
    assert str(bv) == "<BaseVariableChecker my_variable>"
    assert bv.source == "my_variable"
    assert bv.exclude == ('a', 'b')
    assert bv.unambiguous_source == "my_variable"
    assert bv.code.co_name == "<module>"
    assert len(dir(bv.code)) == 4
    assert bv.code.co_consts == (None, 'my_variable')
    assert bv.code.co_names == ('my_variable',)
    assert bv.code.co_varnames == ()
    assert b

# Generated at 2022-06-20 12:39:32.476185
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'a + b'
    result = [
        (0, 0),
        (0, 1),
        (0, 2),
        (1, 0),
        (1, 1),
        (1, 2),
        (2, 0),
        (2, 1),
        (2, 2),
        (3, 0),
        (3, 1),
        (3, 2),
        (4, 0),
        (4, 1),
        (4, 2),
        (5, 0),
        (6, 0),
        (7, 0),
    ]
    for i in range(2):
        for j in range(3):
            for _ in range(i):
                exclude = exclude + ('c',)
            if i > 1:
                source = source + ' + c'

# Generated at 2022-06-20 12:39:39.685540
# Unit test for constructor of class Exploding
def test_Exploding():
    # isinstance(main_value, Mapping)
    x = Exploding('x')
    x_dict = {1:1, 2:2, 3:3}
    assert x.items(None, x_dict) ==\
            [('x', '{1: 1, 2: 2, 3: 3}'), ('x[1]', '1'),\
            ('x[2]', '2'), ('x[3]', '3')]

    # isinstance(main_value, Sequence)
    x_list = [1, 2, 3]
    assert x.items(None, x_list) ==\
            [('x', '[1, 2, 3]'), ('x[0]', '1'),\
            ('x[1]', '2'), ('x[2]', '3')]

    # else

# Generated at 2022-06-20 12:39:47.057453
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a', exclude=('exclude',))
    print('a =', a)  # a = Indices('a', exclude=('exclude',))
    b = a[1:10]
    print('b =', b)  # b = Indices('a', exclude=('exclude',))[1:10]
    print('b._slice =', b._slice)  # b._slice = slice(1, 10, None)
    print('a._slice =', a._slice)  # a._slice = slice(None)
    print(id(a))  # 165461268
    print(id(b))  # 165461296

# Generated at 2022-06-20 12:39:51.164203
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    array=[1,2,3,4]
    assert Indices('dummy')._keys(array) == range(len(array))[slice(None)]
    assert Indices('dummy')[1] == None
    assert Indices('dummy')[1:3] == slice(1, 3, None)

# Generated at 2022-06-20 12:39:53.541561
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "test_var"
    exclude = ("name")
    test_var = BaseVariable(source,exclude)
    assert test_var.source == "test_var"
    assert test_var.exclude == ("name")


# Generated at 2022-06-20 12:40:00.197536
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a[1]')
    assert needs_parentheses('a[1].b')
    assert needs_parentheses('a()')
    assert needs_parentheses('a().b')
    assert needs_parentheses('a().b[1]')
    assert needs_parentheses('a()[1]')
    assert needs_parentheses('a()[1].b')
    assert needs_parentheses('len(a)')
    assert needs_parentheses('len(a).b')
    assert needs_parentheses('len(a).b[1]')
    assert needs_parentheses('len(a[1])')
    assert needs_parentheses('len(a[1]).b')

# Generated at 2022-06-20 12:40:09.837876
# Unit test for constructor of class Indices
def test_Indices():
    class A(object):
        pass
    a = A()
    a.__len__ = lambda self: 10
    assert list(Indices('a').items(None)) == [('a[0]', '<unknown>'), ('a[1]', '<unknown>'), ('a[2]', '<unknown>'), ('a[3]', '<unknown>'), ('a[4]', '<unknown>'), ('a[5]', '<unknown>'), ('a[6]', '<unknown>'), ('a[7]', '<unknown>'), ('a[8]', '<unknown>'), ('a[9]', '<unknown>')]


if __name__ == '__main__':
    '''
    This function is used for unit test
    '''
    test_Indices()

# Generated at 2022-06-20 12:40:18.909106
# Unit test for constructor of class Keys
def test_Keys():
    vars = Keys('dict')
    dict = {'a': 1, 'b': 2}
    assert vars.source is 'dict'
    assert vars.code is compile('dict', '<variable>', 'eval')
    assert vars.unambiguous_source is 'dict'
    assert vars.exclude is ()
    assert vars._fingerprint is (Keys, 'dict', ())
    assert vars.items(dict) is dict.keys()
    assert vars._format_key(dict) is dict.keys()
    assert vars._get_value(dict, 'a') is dict['a']
    assert vars._get_value(dict, 'b') is dict['b']



# Generated at 2022-06-20 12:40:28.501798
# Unit test for constructor of class Exploding
def test_Exploding():
    def test_Exploding_TypeError():
        """
        TypeError: object.__init__() takes no parameters
        """
        try:
            e = Exploding(None)
        except Exception as e:
            print(e)
        else:
            print('test_Exploding_TypeError: failed!')

    test_Exploding_TypeError()



# Generated at 2022-06-20 12:40:31.009907
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Generated at 2022-06-20 12:40:40.136958
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    dict_indices_r0 = {
        Indices("a"): Attrs("a"),
        Indices("a")[:1]: Attrs("a[:1]"),
        Indices("a")[2:3]: Attrs("a[2:3]"),
        Indices("a")[::2]: Attrs("a[::2]"),
        Indices("a")[1::2]: Attrs("a[1::2]"),
        Indices("a")[::-1]: Attrs("a[::-1]"),
    }
    assert dict_indices_r0[Indices("a")] == dict_indices_r0[Indices("a")]
    assert dict_indices_r0[Indices("a")] != dict_indices_r0[Indices("a")[:1]]

# Generated at 2022-06-20 12:40:47.384378
# Unit test for constructor of class Exploding
def test_Exploding():
    # Tuples should automatically explode into indices
    assert Exploding('tup[1]').items(dict(tup=(1,2,3))) ==\
        [
            ('tup[1]', '2'),
            ('tup[2]', '3')
        ]

    assert Exploding('tup[1]')[1:].items(dict(tup=(1,2,3,4))) ==\
        [
            ('tup[2]', '3'),
            ('tup[3]', '4')
        ]

    # Dictionaries should automatically explode into keys

# Generated at 2022-06-20 12:40:52.838347
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BASE = BaseVariable('a')
    assert not BASE.exclude
    assert BASE.code == compile('a', '<variable>', 'eval')
    assert BASE.unambiguous_source == 'a'

    BASE = BaseVariable('a', exclude=('c',))
    assert BASE.exclude == ('c',)

    BASE = BaseVariable('(a)')
    assert BASE.unambiguous_source == '(a)'

# Generated at 2022-06-20 12:40:54.606342
# Unit test for constructor of class Attrs
def test_Attrs():
    class A():
        a = 0
    assert Attrs('a').items(A.__dict__)


# Generated at 2022-06-20 12:40:57.192571
# Unit test for constructor of class Exploding
def test_Exploding():
    tuple_variable = Exploding('42')
    assert (tuple_variable.source == '42')

    list_variable = Exploding('[42, 42]')
    assert (list_variable.source == '[42, 42]')

    dict_variable = Exploding('{42: 42}')
    assert (dict_variable.source == '{42: 42}')

# Generated at 2022-06-20 12:40:59.537447
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('keys', exclude=['z'])
    assert keys.source == 'keys'
    assert keys.exclude == ('z',)
    assert keys.code is not None
    assert keys.unambiguous_source == '(keys)'


# Generated at 2022-06-20 12:41:05.462117
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('foo')
    assert needs_parentheses('(foo)')
    assert needs_parentheses('foo.bar')
    assert needs_parentheses('foo().bar')
    assert needs_parentheses('foo.bar().baz')
    assert needs_parentheses('foo.bar().baz(a=42)')
    assert needs_parentheses('foo.bar().baz(a=42).__class__')

# Generated at 2022-06-20 12:41:10.790511
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class MyVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    assert hash(MyVariable('1')) == hash(MyVariable('1'))
    assert hash(MyVariable('1', exclude='x')) == hash(MyVariable('1', exclude=('x',)))



# Generated at 2022-06-20 12:41:26.758771
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source1 = "a"
    source2 = "(a)"
    source3 = "(a).b"
    source4 = "a.b"
    source5 = "a[b]"
    source6 = "a.get(b)"
    source7 = "a().b[c]"
    source8 = "a[0].b.c[d].e"
    source9 = "a.b()"
    source10 = "a().b()"

    bv1 = BaseVariable(source1)
    bv2 = BaseVariable(source2)
    bv3 = BaseVariable(source3)
    bv4 = BaseVariable(source4)
    bv5 = BaseVariable(source5)
    bv6 = BaseVariable(source6)
    bv7 = BaseVariable(source7)

# Generated at 2022-06-20 12:41:29.700058
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("a")
    print(a._slice)
    assert isinstance(a, Indices)
    b = a[0:6:2]
    print(b._slice)
    print(b.__dict__)
    assert isinstance(b, Indices)

# Generated at 2022-06-20 12:41:39.686562
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from types import FunctionType
    from copy import copy
    from .utils import get_shortish_repr

    # Mock frame for testing the output of the class
    frame = type('frame', (), {
        'f_globals': {},
        'f_locals': {}
    })

    # Our mock object, to be attached to frame.f_locals
    class MockObject:
        attr = 'mock_attr'
        slot = 'mock_slot'
        __slots__ = ['slot']

    # Mock function, to be attached to frame.f_locals
    func = FunctionType(
        name='mock_func',
        code=MockObject.__init__.__code__,
        globals={},
        defaultargs=(),
        closure=None
    )

    # Attach our mock

# Generated at 2022-06-20 12:41:41.209218
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    print(BaseVariable(1, 2).__hash__()) # 1, 2


# Generated at 2022-06-20 12:41:50.388292
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a[1]') is False
    assert needs_parentheses('a.b[1]') is False
    assert needs_parentheses('(a)') is False
    assert needs_parentheses('(a).b') is False
    assert needs_parentheses('(a[1])') is False
    assert needs_parentheses('(a.b[1])') is False

    assert needs_parentheses('(1 + 2) * a') is True
    assert needs_parentheses('a[1 + 2]') is True
    assert needs_parentheses('a.b[1 + 2]') is True
    assert needs_parentheses('(a.b)[1 + 2]') is True
    assert needs_

# Generated at 2022-06-20 12:41:55.807907
# Unit test for constructor of class Indices
def test_Indices():
    '''
    Class Indices: constructor
    '''
    # Create a Indices list
    indices = Indices('b')

    # Test that the constructor works properly
    assert indices.source == 'b'
    assert indices.exclude == ()
    assert indices._slice == slice(None)
    assert isinstance(indices.code, pycompat.code)
    assert indices.unambiguous_source == 'b'

# Generated at 2022-06-20 12:41:58.675850
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable("test", exclude=('a', 'b', 'c')) == BaseVariable("test", exclude=('a', 'b', 'c'))
    BaseVariable("test", exclude=('a', 'b', 'c')) != BaseVariable("test", exclude=('a', 'b'))

# Generated at 2022-06-20 12:42:03.472473
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    o = BaseVariable(
        source="test_source",
        exclude=["test_exclude1", "test_exclude2"],
    )
    f = hash(o)
    assert isinstance(f, pycompat.integer_types)



# Generated at 2022-06-20 12:42:11.652069
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'dict(a=0, b=1)'
    for i in range(4):
        for j in range(4):
            if j < i:
                continue
            a = Indices(source)
            b = Indices(source)
            aa = a[i:j]
            bb = b[i:j]
            assert aa is not bb
            assert aa != bb
        a = Indices(source)
        b = Indices(source)
        aa = a[i]
        bb = b[i]
        assert aa is not bb
        assert aa != bb


# Generated at 2022-06-20 12:42:22.170674
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import debug
    from . import frames
    from . import variables
    import types

    # trivial function which returns the argument unmodified
    def noop(var): return var

    # so let's make a frame and pretend this one is the current one
    f = frames.Frame(None, types.FunctionType(noop.__code__, noop.__globals__, 'str_test', noop.__defaults__, noop.__closure__), {'var' : 'this is my string'})
    debug.current_app.frame = f

    # we create the Attrs object, and pass the string to evaluate
    a = variables.Attrs('var')
    # now the core of the test
    assert a.items(f) == [('var', "'this is my string'")]


# Generated at 2022-06-20 12:42:34.323807
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var = BaseVariable('A.B.C', ('a', 'b'))
    assert var.__hash__() == hash((type(var), 'A.B.C', ('a', 'b')))

# Generated at 2022-06-20 12:42:36.628843
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert indices['b':'c'] == Indices('a')[slice('b','c')]

# Generated at 2022-06-20 12:42:46.313700
# Unit test for constructor of class Keys
def test_Keys():
    arr = [1, 2, 3, 4, 5]
    var = Keys("arr")
    assert var.source == 'arr'
    assert var.exclude == ()
    assert var.code == compile("arr", '<variable>', 'eval')
    assert var.unambiguous_source == 'arr'
    assert var._fingerprint == (Keys, 'arr', ())
    assert var.items(arr) == [('arr', ('[1, 2, 3, 4, 5]',)), ('arr[0]', ('1',)), ('arr[1]', ('2',)), ('arr[2]', ('3',)), ('arr[3]', ('4',)), ('arr[4]', ('5',))]


# Generated at 2022-06-20 12:42:48.224625
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('b')

    assert(a != b)
    assert(b == c)

# Generated at 2022-06-20 12:42:49.034590
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
  pass


# Generated at 2022-06-20 12:42:54.009901
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from unittest import TestCase, main

    class Test_Indices___getitem__(TestCase):
        def test__given_positive_slice__then_slice_is_set_on_the_variable(self):
            variable = Indices('')[1:3]

            self.assertEqual(variable._slice, slice(1, 3))

    main()

# Generated at 2022-06-20 12:43:00.666995
# Unit test for constructor of class Keys
def test_Keys():
    try:
        # Define a dictionary to test if Keys constructor works
        a = {'a':'A', 'c':'C', 'b':'B'}
        # Call Keys constructor on instance a
        b = Keys(a)
        # If the code completes succesfully, test passes
        print("test_Keys passes")
        return True
    except:
        # Exception is raised if constructor fails
        print("test_Keys fails")
        return False


# Generated at 2022-06-20 12:43:09.482601
# Unit test for constructor of class Exploding
def test_Exploding():
    # Mapping
    result = Exploding('a.b')._items(dict(b=dict(c=1)))
    expected = [('a.b', '{...}'), ('a.b.c', '1')]
    assert result == expected

    # Sequence
    result = Exploding('a.b')._items(list(range(3)))
    expected = [('a.b', '[...]'), ('a.b[0]', '0'), ('a.b[1]', '1'), ('a.b[2]', '2')]
    assert result == expected

    # Attrs
    class TestClass:
        pass
    test = TestClass()
    test.c = 1
    result = Exploding('a.b')._items(test)

# Generated at 2022-06-20 12:43:13.363314
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    example = BaseVariable("example")
    assert example.source == "example"
    assert example.exclude == ()
    assert example.code.co_code == 'example\x00\x83\x02\x00\x01'
    assert example.unambiguous_source == 'example'

# Generated at 2022-06-20 12:43:20.245397
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        pass

    class B(BaseVariable):
        pass

    assert A('a') == A('a')
    assert A('a') != B('a')
    assert A('a') != A('b')
    assert A('a', 'b') != A('a')
    assert A('a', 'b') != A('a', 'c')
    assert A('a', 'b') != A('a', 'b', 'c')
    assert A('a', 'b', 'c') != A('a', 'b')
    assert A('a', 'b', 'c') == A('a', 'c', 'b')

# Generated at 2022-06-20 12:43:44.648468
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') == BaseVariable('foo')
    assert BaseVariable('foo', exclude=['bar']) == BaseVariable('foo', exclude=['bar'])
    assert BaseVariable('foo') != BaseVariable('bar')
    assert BaseVariable('foo', exclude=['bar']) != BaseVariable('foo')
    assert BaseVariable('foo', exclude=['bar']) != BaseVariable('foo', exclude=['baz'])

# Generated at 2022-06-20 12:43:54.472871
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v1 = BaseVariable('abc')
    assert v1.source == 'abc'
    assert v1.exclude == ()
    assert v1.unambiguous_source == 'abc'

    v2 = BaseVariable('xyz', exclude='abc')
    assert v2.source == 'xyz'
    assert v2.exclude == ('abc',)
    assert v2.unambiguous_source == 'xyz'

    v3 = BaseVariable('xyz', exclude=['abc', 'def'])
    assert v3.source == 'xyz'
    assert v3.exclude == ('abc', 'def')
    assert v3.unambiguous_source == 'xyz'


# Generated at 2022-06-20 12:43:59.680621
# Unit test for constructor of class Exploding
def test_Exploding():
    ex = Exploding('s', exclude=['a', 'b'])
    assert ex.source == 's'
    assert ex.exclude == ('a', 'b')
    assert ex.code.co_code == b'o\x00\x00e\x06\x00\x00GH\x01\x00\x00S'
    assert ex.unambiguous_source == 's'

# Generated at 2022-06-20 12:44:06.592874
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def test():
        # Tests that BaseVariable.__eq__() works correctly
        x1 = Keys('x')
        x2 = Keys('x')
        x3 = Exploding('x')
        x4 = Keys('y')
        assert x1 == x1
        assert x1 == x2
        assert x1 != x3
        assert x1 != x4
        assert x2 == x1
        assert x2 == x2
        assert x2 != x3
        assert x2 != x4
        assert x3 == x3
        assert x3 != x1
        assert x3 != x2
        assert x4 == x4
        assert x4 != x1
        assert x4 != x2

    test()



# Generated at 2022-06-20 12:44:18.479874
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b()')
    assert needs_parentheses('a.b(1, 2)')
    assert needs_parentheses('(a.b)')
    assert needs_parentheses('(a.b)(1, 2)')
    assert needs_parentheses('(a + 1).b(1, 2)')
    assert not needs_parentheses('(a or 1).b(1, 2)')
    assert not needs_parentheses('a in b')
    assert needs_parentheses('a() in b')
    assert not needs_parentheses('a in (1, 2)')
    assert needs_parentheses('a or b')
    assert needs_parentheses('a or (b)')
    assert needs_parentheses('(a) or b')

# Generated at 2022-06-20 12:44:20.332256
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('foo')
    assert keys._fingerprint == (Keys, 'foo', ())


# Generated at 2022-06-20 12:44:25.475388
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('x').source == 'x'
    assert CommonVariable('x').code.co_names == ('x',)
    assert CommonVariable('x').exclude == ()
    assert CommonVariable('x', 'y').exclude == ('y',)
    assert CommonVariable('x', 'y').unambiguous_source == '(x)'
    assert CommonVariable('x.y').unambiguous_source == 'x.y'
    assert hash(CommonVariable('x')) == hash(('x', '()'))

# Generated at 2022-06-20 12:44:30.436441
# Unit test for constructor of class Keys
def test_Keys():
    # Given
    source = 'a'
    exclude = ('b',)
    main_value = 'xyz'

    # When
    k = Keys(source, exclude)

    # Then
    assert k.source == source
    assert k.exclude == exclude
    assert k.code == compile(source, '<variable>', 'eval')
    assert k.unambiguous_source == source



# Generated at 2022-06-20 12:44:31.569500
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("dcs.x")

# Generated at 2022-06-20 12:44:33.308208
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('', ())
    assert var.items({}) == ()


# Generated at 2022-06-20 12:45:13.242437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('foo')
    a2 = BaseVariable('foo')
    assert(a1 == a2)


# Generated at 2022-06-20 12:45:24.328284
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('y')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('x[y]')
    assert not needs_parentheses('(x)[y]')
    assert needs_parentheses('x.y[0]')
    assert needs_parentheses('(x.y)[0]')
    assert needs_parentheses('x[y][0]')
    assert not needs_parentheses('(x)[y][0]')

    # These are not supposed to work, but works just fine.
    assert not needs_parentheses('(x.y).0')
    assert not needs_parentheses('(x[y])[0]')

# Generated at 2022-06-20 12:45:27.955209
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = locals()
    new_variable = BaseVariable(source)

    assert new_variable.source == source
    assert new_variable.exclude == ()
    assert new_variable.code == compile(source, '<variable>', 'eval')
    assert new_variable.unambiguous_source == source


# Generated at 2022-06-20 12:45:29.997173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a.b.c').items(None)
    assert BaseVariable('{"a": 1}.get("a")', 'bar').items(None)


# Generated at 2022-06-20 12:45:34.384087
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bv = BaseVariable('self')
    try:
        bv.items(1)
    except Exception:
        pass
    else:
        raise AssertionError
    try:
        bv.items(None)
    except Exception:
        pass
    else:
        raise AssertionError
    try:
        bv.items('self')
    except Exception:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-20 12:45:36.798793
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a')
    print(attrs.source)
    print(attrs.unambiguous_source)

    # compile function
    print(attrs.code)
    print(attrs._fingerprint)


# Generated at 2022-06-20 12:45:41.170007
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a.b', exclude=['c'])
    assert attrs.source == 'a.b'
    assert attrs.unambiguous_source == '(a.b)'
    assert attrs.exclude == ('c', )
    assert attrs.code == compile('a.b', '<variable>', 'eval')
    return attrs


# Generated at 2022-06-20 12:45:51.183621
# Unit test for constructor of class Exploding
def test_Exploding():
    # Case 1 of map
    expected_result = [('{a:1,b:2}', '<anomaly_detection.variables.BaseVariable ...>')]
    result = [(x,y) for (x,y) in Exploding('test').items({'a':1,'b':2}) ]
    assert expected_result == result, expected_result 

    # Case 2 of list
    expected_result = [('test[0]', '1'), ('test[1]', '2')]
    result = [(x,y) for (x,y) in Exploding('test').items([1,2])]
    assert expected_result == result, expected_result

    # Case 3 of object
    class MyClass(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-20 12:45:54.584199
# Unit test for constructor of class Exploding
def test_Exploding():
    a_var = Exploding('a')
    assert a_var.source == 'a'
    b_var = Exploding('b', exclude=('b',))
    assert b_var.source == 'b'
    assert b_var.exclude == ('b',)



# Generated at 2022-06-20 12:46:00.456652
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a': 1, 'b': 2}
    k = Keys(d)
    assert k._keys(d) == d.keys()
    assert k._format_key('a') == '[a]'
    assert k._get_value(d, 'a') == 1
    # Test for excluding the 'b' key
    kk = Keys(d, exclude='b')
    assert kk._keys(d) == ('a',)

# Generated at 2022-06-20 12:47:40.136359
# Unit test for constructor of class Keys
def test_Keys():
    base_var = Keys("dict_var", ("key1",))
    assert base_var.__class__ == Keys
    assert base_var.source == "dict_var"
    assert base_var.exclude == ("key1",)
    assert base_var.code == compile("dict_var", '<variable>', 'eval')
    assert base_var.unambiguous_source == "dict_var"
    assert base_var.__hash__() == hash((Keys, "dict_var", ("key1",)))
    assert base_var == Keys("dict_var", ("key1",))
    assert base_var != Keys("dict_var", ())
    assert base_var != Keys("dict_var_2", ("key1",))
    assert base_var != Keys("dict_var_2", ())


# Generated at 2022-06-20 12:47:49.410243
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'len(x)'
    exclude = ('y', 'x')
    frame = dict(x=[2, 3, '1'], y=1)
    # Unit test for method items of class BaseVariable
    def test_BaseVariable_items():
        source = 'len(x)'
        exclude = ('y', 'x')
        frame = dict(x=[2, 3, '1'], y=1)
        obj = BaseVariable(source, exclude)
        assert obj.code == compile(source, '<variable>', 'eval')
        assert isinstance(obj.exclude, tuple)
        assert obj.items(frame) == \
            [('len(x)', '3'), ('(len(x)).x', '<list> [2, 3, 1]')]
        assert isinstance(obj, BaseVariable)
   

# Generated at 2022-06-20 12:47:50.227513
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    print('Passes test')


# Generated at 2022-06-20 12:47:59.807771
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .test_utils import DummyFrame
    import io

# Generated at 2022-06-20 12:48:01.595301
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    print(a.source)
    print(a.exclude)
    print(a.code)


# Generated at 2022-06-20 12:48:11.126066
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('(x)')
    assert not needs_parentheses('(x + 1)')
    assert not needs_parentheses('[x]')
    assert not needs_parentheses('[x][0]')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('x.y[0]')
    assert not needs_parentheses('x.y[0].z')
    assert not needs_parentheses('x + 1')
    assert needs_parentheses('-x')
    assert needs_parentheses('+x')
    assert not needs_parentheses('not x')
    assert not needs_parentheses('x and y')
    assert not needs_parentheses('x or y')
