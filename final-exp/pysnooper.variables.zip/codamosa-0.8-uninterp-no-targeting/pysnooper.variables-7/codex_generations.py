

# Generated at 2022-06-20 12:38:16.297571
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable('a')
    assert utils.ensure_tuple(v.items({'a':12})) == (('a', '12'),)
    

# Generated at 2022-06-20 12:38:20.520841
# Unit test for constructor of class Keys
def test_Keys():
    a_dict = {'a': 1, 'b': 2, 'c': 3}
    a_int = 5
    a_str = '111111111111111111111111111111111111' # a_str is longer than 100 characters
    b = 5.6
    c = 'hello'
    d = [2, 3, 4]
    e = ['a', 'b', 'c']
    tuple_of_list = [[1, 2], [2, 3], [3, 4]]
    Keys_instance = Keys('a_dict')
    print(Keys_instance.items(locals()))

# Generated at 2022-06-20 12:38:28.413328
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # variable with no dict
    x = 1
    y = CommonVariable('x', exclude=('y',))
    assert y.source == 'x'
    assert y.exclude == ('y',)
    assert y.code.co_filename == '<variable>'
    assert y.code.co_name == '<module>'
    assert not y.code.co_varnames
    assert y.code.co_code == b't\x00d\x00\x03\x00|\x00\x00S'
    assert not y.code.co_consts
    assert not y.code.co_names


# Generated at 2022-06-20 12:38:34.293532
# Unit test for constructor of class Keys
def test_Keys():
    # given
    source = "local_var"
    # when
    result = Keys(source)
    # then
    assert 'Keys' == result.__class__.__name__
    assert 'local_var' == result.source
    assert () == result.exclude
    assert 'eval' == result.code.co_name
    assert 'local_var' == result.unambiguous_source


# Generated at 2022-06-20 12:38:40.276610
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Dummy(BaseVariable):
        pass
    assert Dummy("a", ("b", "c")) == Dummy("a", ("b", "c"))
    assert Dummy("a", ("b", "c")) != Dummy("a")
    assert Dummy("a", ("b", "c")) != Dummy("a", ("c", "b"))

# Generated at 2022-06-20 12:38:47.543379
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable("main_value")
    assert bv.source == "main_value"
    assert bv.code
    assert not bv.exclude
    assert bv.unambiguous_source == "main_value"
    bv = BaseVariable("main_value", "exclude")
    assert bv.exclude == ("exclude",)
    bv = BaseVariable("main_value", ["exclude1", "exclude2"])
    assert bv.exclude == ("exclude1", "exclude2")


# Generated at 2022-06-20 12:38:50.130690
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('')) == hash((BaseVariable, '', ()))
    assert hash(BaseVariable('a')) == hash((BaseVariable, 'a', ()))



# Generated at 2022-06-20 12:38:51.651539
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('x')
    assert e.source == 'x'
    assert e.exclude == ()
    assert e.code is not None


# Generated at 2022-06-20 12:38:53.974218
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable('b')
    assert (bv == BaseVariable('b'))
    assert not (bv == BaseVariable('a'))



# Generated at 2022-06-20 12:39:04.595052
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    foo = BaseVariable('foo')
    assert foo.source == 'foo'
    foo_exclude_bar = BaseVariable('foo', exclude='bar')
    assert foo_exclude_bar.source == 'foo'
    assert foo_exclude_bar.exclude == ('bar',)
    foo_exclude = BaseVariable('foo', exclude=['bar', 'baz'])
    assert foo_exclude.source == 'foo'
    assert foo_exclude.exclude == ('bar', 'baz')

    def code_or_exception(s):
        return compile(s, '<variable>', 'eval').co_code

    assert code_or_exception('{}.x'.format(foo.unambiguous_source)) == code_or_exception('({}).x'.format(foo.source))
    assert code_

# Generated at 2022-06-20 12:39:15.990318
# Unit test for constructor of class Exploding
def test_Exploding():
    import unittest

    class TestExplodingMethods(unittest.TestCase):
        def test_type(self):
            self.assertEqual(Exploding('a')._items([1,2,3]).type, 'list')
            self.assertEqual(Exploding('a')._items({'a':1,'b':2}).type, 'dict')
            self.assertEqual(Exploding('a')._items(1).type, 'int')


    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-20 12:39:19.354415
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a')
    assert a.source == 'a'
    assert isinstance(a, Keys)
    assert a._slice == slice(None)
    
# test __getitem__() of class Indices

# Generated at 2022-06-20 12:39:20.349279
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable("a")



# Generated at 2022-06-20 12:39:23.350254
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('list')
    assert indices._slice is slice(None)
    assert indices.source == 'list'
    assert indices.exclude == ()


# Generated at 2022-06-20 12:39:25.306070
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    s = Indices("i")[2::2]
    assert (s._slice == slice(2, None, 2))

# Generated at 2022-06-20 12:39:28.889160
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_info = inspect.getframeinfo(inspect.currentframe())
    frame = inspect.getouterframes(inspect.currentframe())[1]
    frame_locals = frame[0].f_locals
    variable = BaseVariable("frame_info", "frame")
    variable.items(frame_locals)

# Generated at 2022-06-20 12:39:32.176542
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVar = BaseVariable(source = 'value', exclude='v')
    # expected values
    assert BaseVar.source == 'value'
    assert BaseVar.exclude == tuple('v')
    assert BaseVar.code == compile('value', '<variable>', 'eval')
    assert BaseVar.unambiguous_source == 'value'


# Generated at 2022-06-20 12:39:33.979837
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys("k")
    assert k.source == "k"
    assert k.exclude == ()
    assert k.code == compile("k", '<variable>', 'eval')


# Generated at 2022-06-20 12:39:39.049754
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    baseVariable = BaseVariable(source='1', exclude='')
    assert isinstance(baseVariable.source, str)
    assert isinstance(baseVariable.exclude, tuple)
    assert isinstance(baseVariable.code, type(lambda x:x))
    assert isinstance(baseVariable.unambiguous_source, str)


# Generated at 2022-06-20 12:39:47.980911
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # test for format_key
    cv = Attrs('main_value')
    assert cv._format_key('key') == '.' + 'key'

    # test for get_value
    assert cv._get_value(5, 3) == 5
    assert cv._get_value(5, '__add__') == 5 
    assert cv._get_value(5, '__class__') == 5

    # test for safe_keys
    # When it has __class__
    assert cv._safe_keys(5) == ('__add__', '__class__')

    # test for items
    # When it has __class__

# Generated at 2022-06-20 12:39:58.229842
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import sys
    import tracemalloc
    utils.set_test_mode(True)
    tracemalloc.start()
    #make a snapshot of the current tracemalloc stats to compare with later
    snapshot = tracemalloc.take_snapshot()
    #create a new CommonVariable
    ob = CommonVariable("sys.argv",("test","test2"))
    #get the current snapshot again
    snapshot2 = tracemalloc.take_snapshot()
    #grab the diff of the two snapshots
    stats = snapshot2.compare_to(snapshot, "lineno")
    assert len(stats) == 1, "Error: Only 1 error should be outputted"
    print(stats[0])

# Generated at 2022-06-20 12:40:00.314659
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Create a new instance of CommonVariable
    CommonVariable("self")


# Unit test the constructor of class Attrs

# Generated at 2022-06-20 12:40:10.219579
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    from . import Variable, VariableSet
    from .pycompat import StringIO
    import traceback

    def get_items(source):
        try:
            frame = traceback.extract_stack(limit=2)[0]
            return Variable(source).items(frame)
        except Exception:
            return []

    # Test for the 'source' attribute
    source_test = [
        ('.*', 'test.test_variable.test_BaseVariable_items:20: ', '20: '),
        ('.+', 'test.test_variable.test_BaseVariable_items:20: ', ': '),
        ('^.*', '', test_BaseVariable_items.__doc__),
        (' ^', None, None),
        ('^ $', None, None)
    ]

# Generated at 2022-06-20 12:40:20.977649
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    fn = sys._getframe().f_code.co_filename

    def check_items(f, items):
        i = BaseVariable(f).items(sys._getframe())
        assert i == tuple(items)

    check_items('1', (('1', '1'),))
    check_items('[]', (('[]', '[]'),))
    check_items('{}', (('{}', '{}'),))


# Generated at 2022-06-20 12:40:25.470692
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame = inspect.currentframe()
    var = BaseVariable(source='x')
    items = var.items(frame)
    assert items == []
    # test exclusion
    var = BaseVariable(source='x', exclude='y')
    items = var.items(frame)
    assert items == []


# Generated at 2022-06-20 12:40:29.964880
# Unit test for constructor of class Keys
def test_Keys():
    m={'a':1, 'b':2, 'c':3, 'd':4}
    k=Keys('m')
    assert k.items(m) == [('m','{}'), ('m[a]','1'), ('m[b]','2'), ('m[c]','3'), ('m[d]','4')]


# Generated at 2022-06-20 12:40:37.266969
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable("i", exclude=("x", "y"))
    assert v.source == "i" and v.exclude == ("x", "y") and v.code.co_code == b'e\x00\x00\x83\x01\x00\x00S', "test_BaseVariable_1 failed"
    v = BaseVariable("(1+3+4*6-9/3)")
    assert v.source == "(1+3+4*6-9/3)" and v.exclude == () and v.code.co_code == b'e\x00\x00\x83\x01\x00\x00S', "test_BaseVariable_2 failed"


# Generated at 2022-06-20 12:40:41.526916
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for source, expected in [
        ('x', False),
        ('(x)', False),
        ('x.y', True),
        ('x().y', False),
        ('(x()).y', False),
        ('x().y.z', True),
        ('x()[y]', False),
        ('((x.y))', False),
    ]:
        assert needs_parentheses(source) == expected, source

# Generated at 2022-06-20 12:40:46.388139
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variables = [
        BaseVariable('x'),
        BaseVariable('x', ('y',)),
        BaseVariable('x.y', ('y',)),
        BaseVariable('x.y'),
        BaseVariable('x.y', ('y',)),
        BaseVariable('x.y', ('y', 'z'))
    ]

    assert len(variables) == len(set(variables))
    assert len(variables) == 6


# Generated at 2022-06-20 12:40:46.947011
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass

# Generated at 2022-06-20 12:40:57.200857
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("")._slice == slice(None)
    assert Indices("")[1:3]._slice == slice(1, 3)
    assert Indices("")[3:]._slice == slice(3, None)
    assert Indices("")[:3]._slice == slice(None, 3)
    assert Indices("")[:-3]._slice == slice(None, -3)
    assert Indices("")[:]._slice == slice(None)

# Generated at 2022-06-20 12:41:05.890595
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('(1)')
    assert not needs_parentheses('1')
    assert not needs_parentheses('foo')
    assert needs_parentheses('[1]')
    assert needs_parentheses('{1}')
    assert needs_parentheses('f()')
    assert needs_parentheses('1+1')
    assert needs_parentheses('-1')
    assert needs_parentheses('-foo')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo()')
    assert not needs_parentheses('f()[0]')
    assert not needs_parentheses('f()[0].attr')
    assert not needs_parentheses('f()["key"]')
    assert not needs_parentheses('f()[0]()')

# Generated at 2022-06-20 12:41:08.978911
# Unit test for constructor of class Indices
def test_Indices():
    index = Indices("index",exclude = ('index1', 'index2'))
    index._slice= slice(None)
    assert index._slice == slice(None)

# Generated at 2022-06-20 12:41:17.172676
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    
    # STEP 1: Input values
    # For class BaseVariable:
    source = "request"
    exclude = ["x","y"]
    # For class Attrs:
    main_value_Attrs = "request"

    # STEP 2: Check if the inputs are right
    # For class BaseVariable:
    assert source == "request"
    assert exclude == ["x","y"]
    print("")
    # For class Attrs:
    assert main_value_Attrs == "request"

    # STEP 3: Get the actual outputs
    # For class BaseVariable:
    obj = BaseVariable(source, exclude)
    a0 = obj.items(source, exclude)
    a = 1

    # STEP 4: Check if the outputs are right (using the expected outputs)
    # For class BaseVariable:
    assert a == 1
    print

# Generated at 2022-06-20 12:41:27.892787
# Unit test for constructor of class Attrs
def test_Attrs():
    # Test 1:
    list_test = [1, 2, 3]
    a = Attrs(list_test)
    assert len(a.items(list_test, True)) == 4
    assert len(a.items(list_test, False)) == 4

    b = Attrs(list_test, exclude=[1])
    assert len(b.items(list_test, True)) == 3
    assert len(b.items(list_test, False)) == 3

    # Test 2:
    dic_test = {'name': 'me', 'age': 30}
    a = Attrs(dic_test)
    assert len(a.items(dic_test, True)) == 3
    assert len(a.items(dic_test, False)) == 3


# Generated at 2022-06-20 12:41:28.814057
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('dict.keys')._keys('a') == 'a'


# Generated at 2022-06-20 12:41:33.940680
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('(x)') == False
    assert needs_parentheses('(1 + x)') == False
    assert needs_parentheses('[x]') == False
    assert needs_parentheses('(1 + x).y') == False

    assert needs_parentheses('1 + x') == True
    assert needs_parentheses('{}') == True
    assert needs_parentheses('1 + x.foo') == True

    assert needs_parentheses('{}.x') == True

    # in python 2.7, if you have dictionary with uppercase key,
    # it is evaluated differently:
    assert needs_parentheses('{X: 1}') == True
    assert needs_parentheses('{X: 1}.x') == True

# Generated at 2022-06-20 12:41:41.331698
# Unit test for constructor of class Indices
def test_Indices():
    main_value = [1,2,3,4,5]
    indices = Indices('q', exclude=('q.3','q.4'))
    assert list(indices.items(main_value)) == [('q', '[1, 2, 3, 4, 5]'), ('q[0]', '1'), ('q[1]', '2'), ('q[2]', '3')]
    assert list(indices[None:4].items(main_value)) == [('q[:4]', '[1, 2, 3]')]
    assert list(indices[::-1].items(main_value)) == [('q[::-1]', '[5, 4, 3, 2, 1]')]

# Generated at 2022-06-20 12:41:43.397433
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # An BaseVariable object can be hashed.
    dut = BaseVariable(source='x.y.z')
    hash(dut)

# Generated at 2022-06-20 12:41:46.224953
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    with pytest.raises(TypeError):
        hash(BaseVariable)
    assert (BaseVariable("request").__hash__() ==
            BaseVariable("request").__hash__())


# Generated at 2022-06-20 12:41:55.645907
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class test(BaseVariable):
        def __init__(self, source):
            BaseVariable.__init__(self, source, exclude=())

        def _items(self, main_value):
            return self.source

    func = test('0')
    assert func.source == '0'
    assert func.exclude == ()

# Generated at 2022-06-20 12:42:00.955907
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    """
    Unit test for method __hash__ of BaseVariable class defined in variable.py.

    This test covers all the branches of method __hash__.
    """
    variables = [BaseVariable('aaa'), BaseVariable('aaa'), BaseVariable('aaa', exclude=('b')), BaseVariable('aaa', exclude=['b']),
                 BaseVariable('aab'), BaseVariable('aab', exclude=('b')), BaseVariable('aab', exclude=['b'])]
    hashes = [hash(x) for x in variables]
    assert len(hashes) == len(set(hashes))



# Generated at 2022-06-20 12:42:11.729774
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    with pytest.raises(TypeError):
        BaseVariable()  # TypeError: Can't instantiate abstract class BaseVariable with abstract methods _items
    assert BaseVariable('x')
    assert BaseVariable('x.y').items(frame=None) == [
        ('x.y', 'None'),
        ('x.y.__class__', "<type 'NoneType'>")
    ]
    assert BaseVariable('x.y').items(frame=None, normalize=True) == [
        ('x.y', 'None'),
        ('x.y.__class__', 'NoneType')
    ]
    assert BaseVariable('[1, 2, 3]')

# Generated at 2022-06-20 12:42:16.452558
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # __hash__() should return a value of the same type as that of hash "1",
    # and must be in the range of [-2**31, 2**31-1].
    assert isinstance(BaseVariable('').__hash__(), int)
    # __hash__() must return the same value for objects that compare as equal.
    assert BaseVariable('') == BaseVariable('')
    assert hash(BaseVariable('')) == hash(BaseVariable(''))

# Generated at 2022-06-20 12:42:18.231200
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x').__getitem__(slice(None, None, 2))
    assert ind._slice == slice(None, None, 2)


# Generated at 2022-06-20 12:42:20.987957
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "a + b + c"
    exclude = ("a", "b")
    BaseVariable(source, exclude)

# Test function items() in class BaseVariable

# Generated at 2022-06-20 12:42:26.687554
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert needs_parentheses('a[b]')
    assert needs_parentheses('a.b[c]')
    assert needs_parentheses('(a[b])')
    assert needs_parentheses('a[b].c')
    assert not needs_parentheses('(a[b]).c')
    assert not needs_parentheses('a().b')

# Generated at 2022-06-20 12:42:31.357488
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    test_class = CommonVariable("a")
    assert test_class.source == "a"
    assert test_class.exclude == ()
    assert test_class.unambiguous_source == "a"

# Unit tests for the constructor of class Attrs
# Test Case 1:
# Case when getattr on main_value returns a list
# with one element, that element must be returned in a tuple

# Generated at 2022-06-20 12:42:42.734096
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():    
    var1 = BaseVariable('var1')
    var2 = BaseVariable('var2')
    var3 = BaseVariable('var2')           
    assert var1 != var2
    assert var1 != var3
    assert var2 != var3    
    assert var1.__hash__() != var2.__hash__()
    assert var1.__hash__() != var3.__hash__()
    assert var2.__hash__() == var3.__hash__()  
    
    dict = {var1 : 'var1', var2 : 'var2', var3 : 'var3'}

    assert dict[var1] == 'var1'
    assert dict[var2] == 'var2'
    assert dict[var3] == 'var3'
    
    assert len(dict) == 2


# Generated at 2022-06-20 12:42:45.709043
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class BaseVariableTest(BaseVariable):
        def __init__(self):
            BaseVariable.__init__(self, 'main')
        def items(self, frame, normalize=False):
            return ()
    BaseVariableTest().__hash__()

# Generated at 2022-06-20 12:43:10.199639
# Unit test for constructor of class Indices
def test_Indices():
    main_value = ["7", "8", "9", "10"]
    idx = Indices("x")
    assert list(idx._keys(main_value)) == [0,1,2,3]
    # Test the item slicing that's possible with the `[]` notation
    idx = Indices("x")[1:3]
    #assert list(idx._keys(main_value)) == [1,2] # doesnt work


# Generated at 2022-06-20 12:43:18.449984
# Unit test for constructor of class Keys
def test_Keys():
    from collections import OrderedDict

    from .utils import DummyObject

    d = DummyObject()
    key = Keys('d')
    assert key.items(d) == [('d', '<dummy_object>'), ('d.attr1', '1'), ('d.attr2', '2'), ('d.attr3', '3')]
    d1 = OrderedDict((('a', 1), ('b', 2)))
    key1 = Keys('d1')
    assert key1.items(d1) == [('d1', '{...}'), ('d1[\'a\']', '1'), ('d1[\'b\']', '2')]

test_Keys()

# Generated at 2022-06-20 12:43:28.942476
# Unit test for constructor of class Attrs
def test_Attrs():
    d = Attrs('x')
    assert d.source == 'x'
    assert d.exclude == ()
    assert d.code == compile('x', '<variable>', 'eval')
    assert d.unambiguous_source == 'x'

    d = Attrs('x', exclude=())
    assert d.source == 'x'
    assert d.exclude == ()
    assert d.code == compile('x', '<variable>', 'eval')
    assert d.unambiguous_source == 'x'

    d = Attrs('x', exclude=('y', ))
    assert d.source == 'x'
    assert d.exclude == ('y', )
    assert d.code == compile('x', '<variable>', 'eval')
    assert d.unambiguous_source == 'x'


# Unit test

# Generated at 2022-06-20 12:43:38.152543
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import utils
    import inspect
    import sys
    import os
    import io
    import re

    ##### Environment Setting #####
    # for coverage
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../..') # utils.py directory
    sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../..') # source directory

    # for debug
    # sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../debug')

    # for edit
    # sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/../../../py-spy')

    # sys.path.

# Generated at 2022-06-20 12:43:40.238699
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable("a")
    var_2 = BaseVariable("a")
    if not (var_1 == var_2):
        raise AssertionError


# Generated at 2022-06-20 12:43:41.827425
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices("a")._fingerprint == (Indices, "a", tuple())


# Generated at 2022-06-20 12:43:47.032516
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('b')) != hash(BaseVariable('a'))
    assert hash(BaseVariable('b', ('a',))) != hash(BaseVariable('b'))



# Generated at 2022-06-20 12:43:50.188407
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('x')
    v2 = BaseVariable('x')
    v3 = BaseVariable('y')
    assert v1 == v2
    assert v1 != v3


# Generated at 2022-06-20 12:43:51.472262
# Unit test for constructor of class Exploding
def test_Exploding():
    assert issubclass(Exploding('a'), BaseVariable)


# Generated at 2022-06-20 12:43:53.632272
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('abc')
    assert Exploding('abc', exclude='x')
    assert Exploding('abc', exclude=['x'])


# Generated at 2022-06-20 12:44:18.700265
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo.bar', 'x y')._safe_keys({'x': 1, 'y': 2}) == ()
    assert list(Keys('foo.bar', 'x y')._safe_keys({'x': 1, 'y': 2})) == []


# Generated at 2022-06-20 12:44:25.470869
# Unit test for constructor of class Exploding
def test_Exploding():
    # make sure that the class constructor doesn't raise an error
    e = Exploding('some_variable')
    assert e.source == 'some_variable'
    assert e.exclude == tuple()

    e = Exploding('some_variable', 'variableToExclude')
    assert e.source == 'some_variable'
    assert e.exclude == tuple('variableToExclude')

    e = Exploding('some_variable', ('variableToExclude', 'anotherVariableToExclude'))
    assert e.source == 'some_variable'
    assert e.exclude == tuple('variableToExclude', 'anotherVariableToExclude')


# Generated at 2022-06-20 12:44:27.907465
# Unit test for constructor of class Attrs
def test_Attrs():
    class Foo:
        def __init__(self):
            self.x = 1
    f = Foo()
    vars = Attrs('f')
    assert len(vars._items(f))==2

# Generated at 2022-06-20 12:44:34.156611
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    # Get the class
    commonvariable = CommonVariable

    # Create an instance
    obj = commonvariable('test', exclude=('a', 'b'))

    # Check for __init__
    assert isinstance(obj, commonvariable)

    # Check for __hash__
    assert isinstance(obj.__hash__(), int)
    assert hash(obj)

    # Check for __eq__
    other = commonvariable('test')
    assert obj == other


# Generated at 2022-06-20 12:44:39.743964
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable("a").source == "a"
    assert BaseVariable("a").exclude == ()
    assert BaseVariable("a", "b").source == "a"
    assert BaseVariable("a", "b").exclude == ("b", )
    assert BaseVariable("a", ("b", "c")).source == "a"
    assert BaseVariable("a", ("b", "c")).exclude == ("b", "c") 


# Generated at 2022-06-20 12:44:44.799608
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a()') is True
    assert needs_parentheses('a()().b') is True
    assert needs_parentheses('a.b().c') is True


# Helpers for unit tests

# Generated at 2022-06-20 12:44:45.713333
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs("Test",())

# Generated at 2022-06-20 12:44:47.226795
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    x = BaseVariable("foo")
    assert x.__hash__() == x.__hash__()
    

# Generated at 2022-06-20 12:44:55.478474
# Unit test for constructor of class Exploding
def test_Exploding():
    # testing Mapping
    dic = {'c': 3, 'b': 2, 'a': 1}
    assert ((('c', '3'), ('b', '2'), ('a', '1')), (), ()) == Exploding(source='dic', exclude=())._items(dic)

    # testing Sequence
    seq = [3, 2, 1]
    assert ((('[0]', '3'), ('[1]', '2'), ('[2]', '1')), (), ()) == Exploding(source='seq', exclude=())._items(seq)

    # testing not Mapping or Sequence
    class Test:
        x = 1
        y = 2
        z = 3

# Generated at 2022-06-20 12:45:06.947750
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = 1
    y = 2
    z = 3
    test_var = CommonVariable('x')
    assert test_var.source == 'x'
    assert test_var.code == compile('x', '<variable>', 'eval')
    if hasattr(test_var.code, 'co_filename'):
        assert test_var.code.co_filename == '<variable>'
    assert test_var.unambiguous_source == 'x'
    assert test_var.items(sys.__dict__['_getframe']()) == [('x', '1')]
    assert test_var._fingerprint == (CommonVariable, 'x', ())
    assert isinstance(test_var, BaseVariable)
    assert test_var.__hash__() == hash(test_var._fingerprint)
    assert test_var.__

# Generated at 2022-06-20 12:45:53.168985
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('a.b').source == 'a.b'
    assert Attrs('a.b').exclude == ()
    assert Attrs('a.b').unambiguous_source == 'a.b'
    assert Attrs('a.b', 'c').exclude == ('c',)


# Generated at 2022-06-20 12:45:57.714852
# Unit test for constructor of class Attrs
def test_Attrs():
    obj=Attrs('i',10)
    print(obj.source)
    print(obj.exclude)
    print(obj.code)
    print(obj.unambiguous_source)
    obj.items('a', 10)
    print(obj.__hash__())
    print(obj.__eq__(obj))

test_Attrs()

# Generated at 2022-06-20 12:46:07.425223
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var2 = var[:]
    var3 = var[0:1]
    var4 = var[::-1]
    assert var.__dict__ == var2.__dict__
    assert var['slice(0, 1, None)'].__dict__ == var3.__dict__
    assert var['slice(None, None, -1)'].__dict__ == var4.__dict__
    var5 = var[1:2]
    assert var5.__dict__['_slice'] == slice(1, 2)
    var5._slice = slice(1, 2, None)
    assert var5.__dict__['_slice'] == slice(1, 2)
    var5._slice = slice(1)
    assert var5.__dict__['_slice'] == slice(1)
test

# Generated at 2022-06-20 12:46:09.967941
# Unit test for constructor of class Exploding
def test_Exploding():
    assert len(Exploding('config', exclude=('password',)).items(frame={
        'config': {
            'a': 1,
            'b': 2,
            'password': '123456'}
    })) == 3

# Generated at 2022-06-20 12:46:20.244216
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    class FrameProxy:
        def __init__(self, f_locals):
            self.f_locals = f_locals
        def __repr__(self):
            return "<FrameProxy>"

    arg = (1, 2, 3)
    frame = FrameProxy({"arg":arg})
    #items = Indices("arg").items(frame)
    #print(items)
    #assert items == (("arg[0]", "1"), ("arg[1]", "2"), ("arg[2]", "3")), items
    #print(list(Indices("arg")[:2].items(frame)))
    #print(list(Indices("arg")[::-1].items(frame)))
    #print(list(Attrs("arg").items(frame)))

# Generated at 2022-06-20 12:46:22.674486
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    c1 = BaseVariable('x')
    assert c1.source == 'x'
    assert c1.code == compile('x', '<variable>', 'eval')


# Generated at 2022-06-20 12:46:27.368644
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs(source = "test_source", exclude = 100).exclude == (100,)
    assert Attrs(source = "test_source", exclude = (100,)).exclude == (100,)
    assert Attrs(source = "test_source", exclude = [100]).exclude == (100,)


# Generated at 2022-06-20 12:46:35.217711
# Unit test for constructor of class Keys
def test_Keys():
    from .test_utils import pprint
    main_value = {'key1':[1,2,3]}
    obj = Keys('key1')
    pprint(obj.items(main_value))
    main_value = [1,2,3]
    obj = Indices('key1')
    pprint(obj.items(main_value))
    main_value = [1,2,3]
    obj = Indices('key1', exclude=('0'))
    pprint(obj.items(main_value))
    main_value = {'key1':[1,2,3]}
    obj = Keys(main_value)
    pprint(obj.items(main_value))

# Generated at 2022-06-20 12:46:38.827001
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys("key1", "exclude1")
    assert var.source == "key1"
    assert var.exclude == ("exclude1",)
    assert var.code == compile("key1", '<variable>', 'eval')
    assert var.unambiguous_source == "key1"


# Generated at 2022-06-20 12:46:40.137046
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('v', exclusion='x')
# ========================= EOF ================================================================