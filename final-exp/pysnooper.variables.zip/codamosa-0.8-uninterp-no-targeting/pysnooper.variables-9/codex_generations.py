

# Generated at 2022-06-20 12:38:17.857963
# Unit test for constructor of class Indices
def test_Indices():

    from . import print_recursive
    
    print_recursive(foo=[1,2,3,4,5,6,7,8,9], limit=1)
    print_recursive(foo=[1,2,3,4,5,6,7,8,9], limit=2, variables=[Indices[1:7]])

# Generated at 2022-06-20 12:38:25.409240
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from inspect import currentframe
    from collections import Counter

    frame = currentframe()
    t = BaseVariable('a')
    a, b = t, BaseVariable('b')
    bo = BaseVariable('b', ('objjj',))
    c = BaseVariable('b', ('obj',))
    assert set([a, b, c]) == set([a, bo, c])
    assert len(Counter(a, b, c).keys()) == 2
    assert len(Counter(a, b, bo, c).keys()) == 2
    assert len(Counter(a, b, bo, c, t).keys()) == 3
    assert set(t.items(frame, normalize=True)) != set(a.items(frame, normalize=True))

# Generated at 2022-06-20 12:38:27.155385
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cm = CommonVariable("Value", exclude=("Exclude"))


# Generated at 2022-06-20 12:38:29.258540
# Unit test for constructor of class Exploding
def test_Exploding():
    expldng = Exploding('main_value',())
    assert isinstance(expldng, BaseVariable)
    return

# Generated at 2022-06-20 12:38:35.478566
# Unit test for constructor of class Keys
def test_Keys():
    test_data = {'key1': 'data1', 'key2': 'data2'}
    test_data_key = Keys('test_data')
    test_data_keys = [key for key, value in test_data_key.items(sys._getframe(1))]

    assert test_data_keys == list(test_data.keys())

if __name__ == '__main__':
    test_Keys()

# Generated at 2022-06-20 12:38:39.410282
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import pytest
    common_var = CommonVariable("test", exclude=("exclude1","exclude2"))
    assert isinstance(common_var, BaseVariable)
    with pytest.raises(NotImplementedError):
        assert common_var._items("value")

# Generated at 2022-06-20 12:38:42.879831
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import test_code

    frame=sys._getframe().f_back
    a=Attrs('sys')
    b=a.items(frame)
    print(a._items(test_code.d,True))

# Generated at 2022-06-20 12:38:45.978884
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class TestIndices(Indices):
        source=None
        exclude=None
    a=TestIndices
    a1=a['a':'b']
    assert a1._slice==slice('a','b')


# Generated at 2022-06-20 12:38:48.198473
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('X')
    assert a[2:6] != a[5:8]

# Generated at 2022-06-20 12:38:53.689885
# Unit test for constructor of class Indices
def test_Indices():
    '''
    >>> v = Indices('x', exclude=(1, 'two'))
    >>> v.items(None)
    [('x[0]', '1'), ('x[2]', '3'), ('x', 'dict(one=1, two=2, three=3)')]
    '''
    indices_var = Indices('x', exclude=(1, 'two'))
    indices_var.items(None)


# Generated at 2022-06-20 12:39:07.978848
# Unit test for constructor of class Exploding
def test_Exploding():
    # Prepare objects for testing
    iterable_object = [1, 2, 3]
    mapping_object = {"a": 1, "b": 2, "c": 3}
    class_object = ClassWithSlots()
    class_object.a = 1
    class_object.b = 2
    class_object.c = 3

    # Testing object is iterable
    exploded_object = Exploding("iterable_object")._items(iterable_object)
    exploded_object = {item[0]: item[1] for item in exploded_object}

# Generated at 2022-06-20 12:39:11.670918
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class DummyVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    
    v1 = DummyVariable('x')
    v2 = DummyVariable('y')
    assert(v1 == v1)
    assert(v1 != v2)


# Generated at 2022-06-20 12:39:15.772471
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    def get_BaseVariable_instance():
        return BaseVariable(source='x', exclude=('b', 'c'))

    v1 = get_BaseVariable_instance()
    v2 = get_BaseVariable_instance()

    assert v1 == v2


# Generated at 2022-06-20 12:39:19.503360
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('x')
    assert var.source == 'x'
    assert var.exclude == ()
    assert hasattr(var, 'code')     # not sure what to test here
    assert var.unambiguous_source == 'x'


# Generated at 2022-06-20 12:39:22.831196
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('vars', exclude=())
    indices_slice = indices[2:5]
    assert indices._slice == slice(None)
    assert indices_slice._slice == slice(2, 5)

# Generated at 2022-06-20 12:39:31.279856
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from . import variables
    from . import plugins
    assert hash(variables.Attrs('web_app.request.url.query')) \
        == hash(variables.Attrs('web_app.request.url.query'))
    assert hash(variables.Attrs('web_app.request.url.query')) \
        != hash(variables.Attrs('web_app.request.url.query', ['hello']))
    assert hash(variables.Attrs('web_app.request.url.query')) \
        != hash(variables.Keys('web_app.request.url.query'))
    assert hash(variables.Attrs('request.url.query', ['hello'])) \
        != hash(plugins.FlaskPlugin())


# Generated at 2022-06-20 12:39:34.478475
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('item')
    BaseVariable('item', exclude='a')
    BaseVariable('item', exclude=['a'])
    BaseVariable(source='item', exclude='a')
    BaseVariable(source='item', exclude=['a'])


# Generated at 2022-06-20 12:39:36.273061
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("abc")
    assert a.source == "abc"
    assert a.exclude is None
    assert type(a) == Indices


# Generated at 2022-06-20 12:39:40.150618
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('x')
    print(indices)
    assert isinstance(indices, Indices)
    assert indices.source == 'x'
    assert isinstance(indices.code, type(compile))
    assert indices.exclude == ()
    assert indices.unambiguous_source == 'x'


# Generated at 2022-06-20 12:39:41.531170
# Unit test for constructor of class Attrs
def test_Attrs():
    begin_vars = Attrs("my_dict['key1']", "my_dict['key2']")
    assert begin_vars is not None


# Generated at 2022-06-20 12:39:55.392094
# Unit test for constructor of class Attrs
def test_Attrs():
    import unittest
    import math
    import sys
    class Test(unittest.TestCase):
        def setUp(self):
            self.x = 2
            self.l = [1,2,3,4]
            self.o = object()
            self.m = math
            self.a = Attrs('m', '__doc__')
        def test_list(self):
            self.assertEqual(list(self.a.items(sys._getframe())), [('m', '<module \'math\' (built-in)>'), ('m.pi', '3.141592653589793')])

# Generated at 2022-06-20 12:40:02.570380
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable("x")
    assert eval(cv.code, {}, {'x': 1}) == 1
    assert cv.items(frame=None) == [("x", "1")]
    assert cv.items(frame=None, normalize=True) == [("x", "1")]
    assert cv.items(frame=None, normalize=False) == [("x", "1")]


# Generated at 2022-06-20 12:40:11.689527
# Unit test for constructor of class Exploding
def test_Exploding():
    # tests that exploding object of mapping type doesn't explode,
    # but simply return all key-value pairs
    mapping = {
        1: 'hello',
        2: 'world',
    }
    exploding_mapping = Exploding('mapping', exclude=[])
    mapping_items = exploding_mapping.items(dict())
    assert mapping_items == [(str(key), str(value)) for (key, value) in mapping.items()]

    # tests that exploding object of sequence type doesn't explode,
    # but simply return all indices and values
    sequence = ['hello', 'world']
    exploding_sequence = Exploding('sequence', exclude=[])
    sequence_items = exploding_sequence.items(dict())
    assert sequence_items == [(str(i), str(value)) for (i, value) in enumerate(sequence)]

    # tests

# Generated at 2022-06-20 12:40:14.056269
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) != 0


# Generated at 2022-06-20 12:40:20.625840
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'x'
    exclude = set(['__doc__'])
    BaseVariable_a = BaseVariable(source, exclude)
    BaseVariable_b = BaseVariable(source, exclude)
    result = BaseVariable_a == BaseVariable_b
    assert result == True


# Generated at 2022-06-20 12:40:23.862596
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('x', exclude='x')
    var2 = BaseVariable('x', exclude='x')
    assert var1.__eq__(var2) == True

# Generated at 2022-06-20 12:40:27.357104
# Unit test for constructor of class Exploding
def test_Exploding():
    test_string = 'this is a test string'
    ev = Exploding('test_string')
    assert ev._items(test_string) == [('test_string',
                                       "('this is a test string',)")]
    return

# Generated at 2022-06-20 12:40:30.334183
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('obj')
    assert keys.source == 'obj'
    assert keys.exclude == tuple()
    assert keys._fingerprint == (Keys, 'obj', tuple())


# Generated at 2022-06-20 12:40:33.045301
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('var', exclude='exclude')
    assert var.code == compile('var', '<variable>', 'eval')
    assert var.exclude == ('exclude',)
    assert var.source == 'var'



# Generated at 2022-06-20 12:40:38.391033
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    for x in [1, 'x', [1, 2], {'a': 3}]:
        assert BaseVariable(str(x)) == BaseVariable(str(x))
        assert BaseVariable(str(x)) == BaseVariable(str(x), exclude=())
        assert BaseVariable(str(x), exclude=()) == BaseVariable(str(x))
        assert BaseVariable(str(x), exclude=(1, 2, 3)) == BaseVariable(str(x), exclude=(1, 2, 3))


# Generated at 2022-06-20 12:40:50.054188
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('x')
    j = deepcopy(i)
    j._slice = slice(1,2)

    assert i.__getitem__(slice(1,2)) is j

# Generated at 2022-06-20 12:40:54.506182
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable("a", exclude=("b", "c"))
    assert a.source is "a"
    assert isinstance(a.exclude, tuple)
    assert len(a.exclude) == 2
    assert a.exclude is ("b", "c")
    assert a.code.co_code is compile("a", '<variable>', 'eval').co_code
    assert a.unambiguous_source is "a"



# Generated at 2022-06-20 12:41:03.053926
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var1 = BaseVariable('foo.bar')
    var2 = BaseVariable('foo.bar')
    var3 = BaseVariable('foo')
    var4 = BaseVariable('foo.bar', exclude=['a', 'b'])
    var5 = BaseVariable('foo.bar', exclude=['a', 'b'])
    var6 = BaseVariable('foo.bar', exclude=['a', 'c'])

    assert var1 == var2
    assert var4 == var5
    assert var1 != var3
    assert var4 != var6

    set_var = {var1, var2, var3, var4, var5, var6}
    assert len(set_var) == 4
    assert var1 in set_var
    assert var3 in set_var
    assert var4 in set_var
    assert var6 in set_

# Generated at 2022-06-20 12:41:06.576931
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("x")[2] == Indices("x")[:3]
    assert Indices("x")[-3] == Indices("x")[-3:]

# Generated at 2022-06-20 12:41:10.299508
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('1')._slice == slice(None)
    assert Indices('1')[:3]._slice == slice(None, 3)
    assert Indices('1')[1:3]._slice == slice(1, 3)

# Generated at 2022-06-20 12:41:13.191783
# Unit test for constructor of class Attrs
def test_Attrs():
    a1 = Attrs('a')
    a2 = Attrs('a')
    assert a1 == a2

    a1 = Attrs('a', 'b')
    a2 = Attrs('a', 'b')
    assert a1 == a2


# Generated at 2022-06-20 12:41:18.936530
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import sys
    s = sys.version
    frame = sys._getframe()
    exc = IdentifierError
    print(frame.f_code.co_code)
    print(exc.__name__)
    var = CommonVariable(frame, exc)
    print(var)

if __name__ == "__main__":
    test_CommonVariable()

# Generated at 2022-06-20 12:41:29.141209
# Unit test for constructor of class Indices
def test_Indices():
    l = [1,2,3,4,5]
    assert l[Indices('l', exclude=['x'])] == l[:]
    assert l[Indices('l', exclude=['x'])[1:4]] == l[1:4]
    assert l[Indices('l', exclude=['x'])[2::2]] == l[2::2]
    assert l[Indices('l', exclude=['x'])[::-1]] == l[::-1]

    # Test that constructor doesn't change the passed in list
    l = [1,2,3,4,5]
    assert l[2::2] == l[2::2]
    assert l == [1,2,3,4,5]

    # Make sure that we properly slice the list and not just return a reference to it


# Generated at 2022-06-20 12:41:32.000802
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('a', ['b']), BaseVariable)


# Generated at 2022-06-20 12:41:34.421051
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')['0:2'] == Indices('a')[slice(0, 2)]

var = Exploding

# Generated at 2022-06-20 12:41:59.399476
# Unit test for constructor of class Keys
def test_Keys():
    d = {'x': 'y'}
    x = Keys('d', ('x',))
    assert x.source == 'd'
    assert x.exclude == ('x',)
    assert x.code != None
    assert x.unambiguous_source == 'd'
    assert x.items({'d': d}) == [('d', "{'x': 'y'}"), ('d[x]', "'y'")]
    assert x.items({'d': d}, normalize=True) == [('d', '{...}'), ('d[x]', "'y'")]
    assert x.items({'d': d}) != [('d', "{'x': 'y'}"), ('d[y]', "'y'")]

# Generated at 2022-06-20 12:42:04.268319
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    b1 = BaseVariable("args[0]")
    b2 = BaseVariable("args[0]")
    assert b1.source == "args[0]"
    assert b1.exclude == ()
    assert hash(b1) == hash(b2)
    assert b1 == b2

# Generated at 2022-06-20 12:42:07.899686
# Unit test for constructor of class Keys
def test_Keys():
    source = 'something'
    exclude = 'nothing'
    var = Keys(source, exclude)

    assert var.source == source
    assert var.exclude == exclude
    assert var.unambiguous_source == source



# Generated at 2022-06-20 12:42:10.655473
# Unit test for constructor of class Keys
def test_Keys():
    # instantiate Keys class
    k = Keys("key", "exclude")
    assert k.source == "key"
    assert k.exclude == "exclude"
    assert k.unambiguous_source == "key"

# Generated at 2022-06-20 12:42:13.475536
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('d')
    print (a[1:3]._slice)
    print (a[None]._slice)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-20 12:42:20.296102
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # source: str
    c = CommonVariable('str')
    assert c.source == 'str'
    # exclude: str
    c = CommonVariable('str', exclude='exclude')
    assert c.exclude == ('exclude',)
    # exclude: list
    c = CommonVariable('str', exclude=['exclude'])
    assert c.exclude == ('exclude',)
    # exclude: tuple
    c = CommonVariable('str', exclude=('exclude',))
    assert c.exclude == ('exclude',)
    # source: str; exclude: str
    c = CommonVariable('str', exclude='exclude')
    assert c.exclude == ('exclude',)
    # source: str; exclude: tuple
    c = CommonVariable('str', exclude=('exclude',))

# Generated at 2022-06-20 12:42:22.858484
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    item = slice(1, 2)
    var = Indices('main_value').__getitem__(item)
    assert(var._slice == item)



# Generated at 2022-06-20 12:42:32.177602
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('i') == False
    assert needs_parentheses('i*j') == False
    assert needs_parentheses('(i,j)') == True
    assert needs_parentheses('[i,j]') == True
    assert needs_parentheses('{i,j}') == True
    assert needs_parentheses('i.j') == False
    assert needs_parentheses('i.__getitem__') == False
    assert needs_parentheses('i.__getitem__(j)') == False
    assert needs_parentheses('i.__class__') == False
    assert needs_parentheses('i.__class__.__name__') == False
    assert needs_parentheses('i.__getitem__()') == True
    assert needs_parentheses('i()') == True

# Generated at 2022-06-20 12:42:34.742565
# Unit test for constructor of class Attrs
def test_Attrs():
    a=Attrs('frame.f_globals')
    print(a)

if __name__ == '__main__':
    test_Attrs()

# Generated at 2022-06-20 12:42:43.143421
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('foo')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo.bar()')
    assert not needs_parentheses('foo().bar')
    assert needs_parentheses('foo.bar().baz')
    assert needs_parentheses('foo().bar().baz()')
    assert needs_parentheses('foo.bar().baz.qux()')
    assert needs_parentheses('foo().bar.baz().qux()')


# Unit tests for Variable subclasses


# Generated at 2022-06-20 12:43:26.590093
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'a.b'
    base = BaseVariable(source)
    assert hash(base) == hash(type(base)) + hash(source) + hash(tuple())


# Generated at 2022-06-20 12:43:36.245073
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert (BaseVariable('x')).source == 'x'
    assert (BaseVariable('x', exclude='z').exclude) == ('z',)
    assert (BaseVariable('x', exclude='z').exclude) == ('z',)
    assert (BaseVariable('x', exclude='z') == BaseVariable('x')) == False
    assert (BaseVariable('x', exclude='z') == BaseVariable('x', exclude='z')) == True
    assert (BaseVariable('x', exclude='z') == 5) == False
    assert (BaseVariable('x', exclude='z')._fingerprint) == (BaseVariable, 'x', ('z',))
    assert BaseVariable('x', exclude='z').__hash__() == hash((BaseVariable, 'x', ('z',)))


# Generated at 2022-06-20 12:43:40.345060
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('X')) == hash(BaseVariable('X'))

    assert hash(BaseVariable('X')) != hash(BaseVariable('y'))

    assert hash(BaseVariable('X')) != hash(BaseVariable('X', exclude='y'))
    assert hash(BaseVariable('X', exclude='y')) == hash(BaseVariable('X', exclude='y'))


# Generated at 2022-06-20 12:43:43.428375
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = {'y': {'z': 3}}
    method = BaseVariable(x)
    method.items(frame=utils.Frame(frame='test'), normalize=False)

# Generated at 2022-06-20 12:43:45.560100
# Unit test for constructor of class Indices
def test_Indices():
    assert [i for i in Indices('a')] == [i for i in Indices('a')[:]]

# Generated at 2022-06-20 12:43:48.843548
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('_')
    indices__ = indices[0:]
    assert indices__._slice == slice(0, None, None)
    indices__1 = indices[1:]
    assert indices__1._slice == slice(1, None, None)
    indices__1_2 = indices[1:2]
    assert indices__1_2._slice == slice(1, 2, None)
    indices__S = indices[:]
    assert indices__S._slice == slice(None, None, None)

# Generated at 2022-06-20 12:43:58.836640
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
  from .patcher import patch
  from .patcher import patch_object
  from .patcher import patch_dict
  from .patcher import patch_item
  from .patcher import patch_multiple
  from .patcher import patch_multiple_dict
  from .patcher import patch_multiple_item
  from .patcher import patch_multiple_object
  from .patcher import patch_multiple_dict
  from .patcher import patch_instance_attribute

  # Tests for method __hash__ of class BaseVariable
  from .patcher import patch
  from .patcher import patch_object
  from .patcher import patch_dict
  from .patcher import patch_item
  from .patcher import patch_multiple
  from .patcher import patch_multiple_dict
  from .patcher import patch_multiple_item

# Generated at 2022-06-20 12:44:06.818259
# Unit test for constructor of class Exploding
def test_Exploding():
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    a = A()
    a.__slots__ = ("__dict__", "a", "b", "c")
    assert ([('.a', '1'), ('.b', '2'), ('.c', '3')] == list(Exploding('a', exclude=["b"]).items(None)) or
    [('.a', '1'), ('.c', '3')] == list(Exploding('a', exclude=["b"]).items(None)))

# Generated at 2022-06-20 12:44:10.071295
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    _items = BaseVariable('A', exclude='C').items({'A': 'C', 'C': 'A'})
    assert (_items == [('A', "'C'"), ('(A).C', "'A'")])


# Generated at 2022-06-20 12:44:22.831960
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('a.b') == Attrs('a.b')
    assert Attrs('a.b', exclude=('b', 'c')) == Attrs('a.b', exclude=('b', 'c'))
    assert Attrs('a.b', exclude=('b', 'c')) != Attrs('a.b', exclude=('b', 'c', 'd'))
    assert Attrs('a.b') != Attrs('c.b')
    assert Attrs('a.b') != Attrs('a.b', exclude=('b', ))

    assert Keys('a') == Keys('a')
    assert Keys('a.b') == Keys('a.b')

# Generated at 2022-06-20 12:45:13.913233
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('x')
    x1 = BaseVariable('x')
    x2 = BaseVariable('x', exclude=('a', 'b'))
    y = BaseVariable('y')
    assert x == x1
    assert x != x2
    assert x != y
    assert x != object()


# Generated at 2022-06-20 12:45:15.960857
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable("a",exclude=("x","y","z"))
    assert variable.items(frame=None) == ()



# Generated at 2022-06-20 12:45:18.036199
# Unit test for constructor of class Exploding
def test_Exploding():
    exp = Exploding('a')
    assert exp.source == 'a'

#Test for function _items

# Generated at 2022-06-20 12:45:19.310015
# Unit test for constructor of class Keys
def test_Keys():
    source = 'a'
    Keys(source)

# Generated at 2022-06-20 12:45:25.541673
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') == BaseVariable('foo')
    assert not (BaseVariable('foo') == BaseVariable('bar'))
    assert not (BaseVariable('foo') == BaseVariable('foo', exclude='bar'))
    assert not (BaseVariable('foo', exclude='bar') == BaseVariable('foo'))
    assert not (
    BaseVariable('foo', exclude='bar') == BaseVariable('foo', exclude='baz'))


# Generated at 2022-06-20 12:45:33.760436
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v = CommonVariable(source='test', exclude=())
    assert v.source=='test'
    assert v.unambiguous_source=='test'
    assert v.code

# Generated at 2022-06-20 12:45:35.638424
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('__x__')._slice == slice(None)
    assert Indices('__x__')[1:2]._slice == slice(1, 2)

# Generated at 2022-06-20 12:45:37.417749
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')[:3]
    assert isinstance(a, Indices)
    assert a._slice == slice(None, 3, None)


# Generated at 2022-06-20 12:45:39.299119
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('bar').__getitem__(slice(1,3))
    assert var._slice == slice(1,3)

# Generated at 2022-06-20 12:45:43.936100
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('1')) == hash(BaseVariable('1'))
    assert hash(BaseVariable('2')) != hash(BaseVariable('1'))
    assert hash(BaseVariable('1')) != hash(BaseVariable('1', exclude=('exclude')))


# Generated at 2022-06-20 12:47:26.378280
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('getattr(x, "y")')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('getattr(x, "y")')



# Generated at 2022-06-20 12:47:33.933545
# Unit test for constructor of class Exploding
def test_Exploding():
    # A global variable 'x' is defined
    global x
    x = {'y': {'z': 123, 'w': 456}}
    # Create an instance of class Exploding
    e = Exploding('x')
    # Unpack the .items() method
    # into cls, source, and exclude
    cls, source, exclude = e._items(x)
    # The class of the first item of the output
    # should be Keys
    assert cls is Keys, 'Wrong class.'



# Generated at 2022-06-20 12:47:41.202136
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import local
    from . import global_vars
    import inspect
    import re

    def method_source_code(self, method_name):
        """Return method source code from methods
        of class BaseVariable
        """

        method = getattr(self, method_name)
        raw_code = inspect.getsource(method).split('\n')[1:-1]
        return ' '.join(
            re.split(' +', line.strip())
            for line in raw_code
        )

    source = 'some_variable'
    variable = Attrs(source)
    variable.source
    source_code = method_source_code(variable, '_items')
    frame_locals = local.get_locals(depth=2)
    frame_globals = global_vars.get_globals()

# Generated at 2022-06-20 12:47:50.302158
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('x')
    assert var.source == 'x'
    assert var.exclude == tuple()
    code = compile('x', '<variable>', 'eval')
    assert var.code == code
    assert needs_parentheses('x') == False
    assert var.unambiguous_source == 'x'

    var = Indices('x', exclude='y')
    assert var.source == 'x'
    assert var.exclude == tuple('y')
    code = compile('x', '<variable>', 'eval')
    assert var.code == code
    assert needs_parentheses('x') == False
    assert var.unambiguous_source == 'x'

    var = Indices('x', exclude=('y1', 'y2'))
    assert var.source == 'x'
    assert var.ex

# Generated at 2022-06-20 12:47:59.890219
# Unit test for constructor of class Keys
def test_Keys():
    import inspect
    import types
    import copy

    def test_init_commonvariable(self):
        try:
            Keys()
        except TypeError as e:
            assert e.args[0] == '__init__() missing 2 required positional arguments: \'source\' and \'exclude\''
        else:
            assert False

    def test_init_keys(self):
        try:
            Keys('test','test')
        except TypeError as e:
            assert e.args[0] == '__init__() missing 1 required positional argument: \'exclude\''
        else:
            assert False


# Generated at 2022-06-20 12:48:03.477663
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('a.b')
    assert BaseVariable('a.b') == BaseVariable('a.b')
    assert BaseVariable('a.b') != BaseVariable('a.c')
    assert BaseVariable('a.b').items(None) == ()


# Generated at 2022-06-20 12:48:12.324468
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import debugger
    from . import testutils
    import pytest

    class NormalizationTest(testutils.FakeFrame):
        def __init__(self, testcase, *args, **kwargs):
            super(NormalizationTest, self).__init__(*args, **kwargs)
            self.testcase = testcase
            self.f_locals = {'x': 0, 'y': 1, 'z': 2}

        def fake_normalize_subframe(self, frame):
            return self.testcase.normalize_subframe(*frame)

        def fake_normalize_subframe_with_subframes(self, frame):
            return self.testcase.normalize_subframe_with_subframes(*frame)
