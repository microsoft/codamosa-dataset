

# Generated at 2022-06-20 12:38:19.844571
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ()
    variable1 = TestVariable('user.first_name')
    variable2 = TestVariable('user.first_name')
    assert variable1 == variable2
    assert hash(variable1) == hash(variable2)

# Generated at 2022-06-20 12:38:22.720703
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys("__class__", exclude=["__module__", "__dict__"])
    # The exclude parameter takes either a string, or a tuple of strings.
    assert k.source == "__class__"
    assert k.exclude == ("__module__", "__dict__")

# Generated at 2022-06-20 12:38:25.488914
# Unit test for constructor of class Exploding
def test_Exploding():
    # Define a constatnt
    exp = Exploding("False")
    assert isinstance(exp, Exploding)
    # Define a Python variable with a value
    exp = Exploding("myvar")
    assert isinstance(exp, Exploding)

# Generated at 2022-06-20 12:38:34.391080
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import inspect
    import textwrap

    def check(v):
        argspec = inspect.getargspec(v.__init__)
        assert argspec.args == ['self', 'source', 'exclude'], argspec.args
        assert argspec.varargs is None, argspec.varargs
        assert argspec.keywords is None, argspec.keywords
        assert argspec.defaults == ([],), argspec.defaults

    check(CommonVariable)
    check(Attrs)
    check(Keys)
    check(Indices)
    check(Exploding)


# Generated at 2022-06-20 12:38:40.646863
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert needs_parentheses('(a)')
    assert needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c.d')
    assert not needs_parentheses('a.b[0]')
    assert not needs_parentheses('a.b[0][1]')
    assert needs_parentheses('1.0')
    assert not needs_parentheses('a.b[10:20]')
    assert not needs_parentheses('a.b[0].c.d')
    assert needs_parentheses('(a.b)')

# Generated at 2022-06-20 12:38:47.999510
# Unit test for constructor of class Exploding
def test_Exploding():
    r1 = Exploding('r1')
    assert r1.source == 'r1'
    assert r1.exclude == ()

    r2 = Exploding('r2', ['exclude'])
    assert r2.source == 'r2'
    assert r2.exclude == ('exclude', )

    r3 = Exploding(source='r3', exclude=['exclude'])
    assert r3.source == 'r3'
    assert r3.exclude == ('exclude', )
# End of test functions


# Generated at 2022-06-20 12:38:56.657050
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x["y"]')
    assert not needs_parentheses('x[1]')
    assert not needs_parentheses('x()')
    assert not needs_parentheses('x.y()')
    assert not needs_parentheses('x["y"]()')
    assert not needs_parentheses('x[1]()')

    assert needs_parentheses('(x)')
    assert needs_parentheses('(x).y')
    assert needs_parentheses('(x)["y"]')
    assert needs_parentheses('(x)[1]')
    assert needs_parentheses('(x)()')
    assert needs_parentheses('(x).y()')

# Generated at 2022-06-20 12:39:01.912282
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    OBJ = {}
    instr = "OBJ"
    var = BaseVariable(instr)
    assert var.source == instr
    assert var.exclude == ()
    assert type(var.code) == type(compile(instr, '<variable>', 'eval').co_code)
    assert var.unambiguous_source == instr


# Generated at 2022-06-20 12:39:06.001294
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('a', 'b')
    assert x.source == 'a'
    assert x.exclude == ('b',)
    assert x.code
    assert x.unambiguous_source == 'a'
    assert not x._items('a')
    assert not x._items(1)
    

# Generated at 2022-06-20 12:39:08.709332
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import inspect
    assert len(inspect.getargspec(CommonVariable).args) == 2  # only source and exclude
    assert inspect.getargspec(CommonVariable).defaults == (())   # only source and exclude


# Generated at 2022-06-20 12:39:19.152830
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('b.c', ('time',))
    var2 = BaseVariable('b.c', ('time',))
    assert var1 == var2
    var3 = BaseVariable('a.c', ('time',))
    assert var1 != var3
    var4 = BaseVariable('b.c', ('time2',))
    assert var1 != var4


# Generated at 2022-06-20 12:39:22.441212
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('t')
    assert k.source == "t"
    assert k.code == compile('t', '<variable>', 'eval')
    assert k.exclude == ()


# Generated at 2022-06-20 12:39:28.352222
# Unit test for function needs_parentheses
def test_needs_parentheses():
    cases = [
        ('a', False),
        ('a.b', True),
        ('a[1]', True),
        ('a.b[1]', True),
        ('(a).b', False),
        ('(a)[1]', False),
        ('(a.b)[1]', False),
    ]

    for expr, expected_result in cases:
        result = needs_parentheses(expr)
        assert result == expected_result, 'case %r' % expr

# Generated at 2022-06-20 12:39:31.055966
# Unit test for constructor of class Exploding
def test_Exploding():
    m = Exploding('a', exclude=('b',))
    assert m.source == 'a'
    assert m.exclude == ('b',)
    assert m.code is not None


# Generated at 2022-06-20 12:39:33.205854
# Unit test for constructor of class Attrs
def test_Attrs():
    v = Attrs('a')
    assert isinstance(v, BaseVariable)
    assert v.source == 'a'
    assert v.exclude == tuple()
    assert isinstance(v.code, compile)


# Generated at 2022-06-20 12:39:35.029716
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable(BaseVariable):
        def _items(self, key, normalize=False):
            raise NotImplementedError
    a = BaseVariable("a")
    b = Attrs("a")
    assert (a == b) == False

# Generated at 2022-06-20 12:39:41.221392
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    slice_1 = slice(2,None)
    slice_2 = slice(2,4)
    slice_3 = slice(None, 4)
    var = Indices("val")
    assert var[slice_1] == slice_1
    assert var[slice_2] == slice_2
    assert var[slice_3] == slice_3

# Generated at 2022-06-20 12:39:49.544054
# Unit test for constructor of class Exploding
def test_Exploding():
    d = {'a':1}
    f = {'a':2}
    assert type(Exploding('d')).__name__ == 'Exploding'
    assert Exploding('d').source == 'd'
    assert Exploding('d').exclude == ()
    assert type(Exploding('d', exclude='a')).__name__ == 'Exploding'
    assert Exploding('d', exclude='a').source == 'd'
    assert Exploding('d', exclude='a').exclude == ('a',)
    e = Exploding('d')
    assert type(e._items(d)).__name__ == 'tuple'
    assert e._items(d) == (('d', '{...}'), ('d.a', '1'))
    e = Exploding('d', exclude='a')

# Generated at 2022-06-20 12:39:57.600876
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for source in (
        'a',
        'a.b',
        'a.b.c',
        'a[0]',
        'a[0].b',
        'a[0][1]',
        'a[0][1].b',
        # '(a)',
        # '(a).b',
        # '(a.b)',
        # '(a.b).c',
        # '(a[0])',
        # '(a[0]).b',
        # '(a[0]).b.c',
        # '(a[0][1])',
        # '(a[0][1]).b',
        # '(a[0][1].b)',
    ):
        assert not needs_parentheses(source)


# Generated at 2022-06-20 12:40:00.160430
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('a', 'b')
    assert x.source == 'a'
    assert x.exclude == ('b',)



# Generated at 2022-06-20 12:40:15.184285
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    '''
    >>> source = "main_value._get_value(main_value, key)"
    >>> bv = BaseVariable(source)
    >>> print(bv.source)
    main_value._get_value(main_value, key)
    >>> print(bv.exclude)
    ()
    >>> print(bv.code)
    <code object <module> at 0x10701fdc0, file "<variable>", line 1>
    >>> print(bv.unambiguous_source)
    (main_value._get_value(main_value, key))
    '''


# Generated at 2022-06-20 12:40:27.810654
# Unit test for constructor of class Indices
def test_Indices():
    # test values
    values = [0, 1, 2, 3]
    # get max value
    max_val = len(values) - 1

    # test cases
    test_cases = [
        { "range": 0 },
        { "range": len(values) },
        { "range": [0, max_val] },
        { "range": [0, max_val, 2] },
        { "range": [max_val, 0, -1] },
        { "range": [0, max_val, -1] },
    ]

    for test_case in test_cases:
        # Create a Indices instance
        indices_instance = Indices(test_case["range"])
        # Pull the range slice out of the indices_instance
        range_slice = indices_instance._slice
        # Create a list of

# Generated at 2022-06-20 12:40:36.982019
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    s = 'x'
    source = 'stackprinter.utils.utils.get_shortish_repr(x)'
    exclude = ['__weakref__', '__dict__']
    x = compile(source, '<string>', 'eval')
    bv1 = BaseVariable(source, exclude)
    bv2 = BaseVariable(source, exclude)
    assert hash(bv1) == hash(bv2)
    assert bv1.__hash__() == bv2.__hash__()
    bv2.source = s
    assert hash(bv1) != hash(bv2)
    assert bv1.__hash__() != bv2.__hash__()
    bv2 = BaseVariable(source, exclude)
    bv2.exclude = s
    assert hash(bv1)

# Generated at 2022-06-20 12:40:39.997613
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('source', exclude=())
    # v.__hash__() should be hash(type(v), v.source, v.exclude)
    check_hash = hash(v._fingerprint)
    assert v.__hash__() == check_hash


# Generated at 2022-06-20 12:40:45.792576
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class Test(BaseVariable):
        def __init__(self, source, exclude=()):
            super(Test, self).__init__(source, exclude=exclude)

        def _items(self, key, normalize=False):
            pass

    v1 = Test('a', exclude=('a', 'b'))
    v2 = Test('a', exclude=('b', 'a'))
    v3 = Test('a', exclude='a')

    assert hash(v1) == hash(v2)
    assert hash(v1) != hash(v3)
    assert hash(v2) != hash(v3)

# Generated at 2022-06-20 12:40:53.339582
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .utils import _C
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('x', exclude=('z',))
    assert BaseVariable('x') == BaseVariable('x', exclude=('z',))

    # Not the same class
    assert BaseVariable('x') != _C(BaseVariable, 'x', exclude=())
    # Different attributes
    assert BaseVariable('x') != _C(BaseVariable, 'x', exclude=('x',))
    # Different class but all attributes are the same
    assert BaseVariable('x') == _C(BaseVariable, 'x', exclude=())


# Generated at 2022-06-20 12:40:58.363740
# Unit test for constructor of class Attrs
def test_Attrs():
    source = "test_source"
    exclude = "test_exclude"
    attrs = Attrs(source, exclude)
    assert attrs.source == source
    assert attrs.exclude == exclude
    code = compile('test_source.x', '<variable>', 'eval')
    assert attrs.code == code
    assert attrs.unambiguous_source == "test_source"



# Generated at 2022-06-20 12:41:00.228758
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x')
    ind_slice = ind[1:5]
    ind_slice.source == 'x[1:5]'



# Generated at 2022-06-20 12:41:06.626863
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('x', 'a')._fingerprint == (Attrs, 'x', ('a',))
    var = Attrs('x', 'a')
    assert not var._safe_keys('q')
    assert var._keys(Attrs) == Attrs.__dict__.keys()
    assert var._format_key('q') == '.q'
    assert var._get_value(Attrs, '__dict__') == Attrs.__dict__

# Generated at 2022-06-20 12:41:14.581166
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x(1)') == True
    assert needs_parentheses('x.__call__') == False
    assert needs_parentheses('x().__class__.__call__') == True
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('x(1).y.z') == True
    assert needs_parentheses('x().y.z') == True
    assert needs_parentheses('x.y()') == True
    assert needs_parentheses('x().y()') == True
    assert needs_parentheses('x.y().z') == True


# Generated at 2022-06-20 12:41:39.651304
# Unit test for constructor of class Keys
def test_Keys():
    a = {'a': 1, 'b': 'asdf', 'c': ('asdf', 123)}
    assert Keys('a').items(a) == [('a', '{...}')]
    assert Keys('a', exclude='a').items(a) == [('a', '{...}')]
    assert Keys('a', exclude=('a', )).items(a) == [('a', '{...}')]
    assert Keys('a', exclude=('a', 'c')).items(a) == [('a', '{...}'), ('a[b]', 'asdf')]


# Generated at 2022-06-20 12:41:47.903045
# Unit test for constructor of class Exploding
def test_Exploding():
    # A mapping
    e = Exploding("x")
    assert e._items({"a": 1}) == [("x", "{'a': 1}"), ("x[a]", "1")]

    # A sequence
    assert e._items([1, 2]) == [("x", "[1, 2]"), ("x[0]", "1"), ("x[1]", "2")]

    # A non-sequence, non-mapping
    class C:
        def __init__(self):
            self.a = 1
            self.b = 2
    c = C()
    assert e._items(c) == [("x", "<__main__.C object>"), ("x.a", "1"), ("x.b", "2")]

# Generated at 2022-06-20 12:41:53.200841
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x', 'y')) == hash(BaseVariable('x', 'y'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('x', 'z'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('y'))

# Generated at 2022-06-20 12:42:00.730043
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a', 'b').items(None) == ()
    assert BaseVariable('a', 'b').items(utils.make_frame(a=1)) == \
        (('a', '1'),)
    assert BaseVariable('a', 'b').items(utils.make_frame(a=[])) == \
        (('a', '[]'),)
    assert BaseVariable('a', 'b').items(utils.make_frame(a=[1])) == \
        (('a', '[1]'),)
    assert BaseVariable('a', 'b').items(utils.make_frame(a=[1, 2])) == \
        (('a', '[1, 2]'),)

# Generated at 2022-06-20 12:42:09.873901
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    #Arrange
    variable = CommonVariable('__dict__')
    #Assert
    assert variable.source == '__dict__'
    assert variable.exclude == ()
    assert variable.code == compile('__dict__', '<variable>', 'eval')
    assert str(variable.code) == "b'd\\x00\\x00\\x00S\\x00\\x00\\x00d\\x01\\x00\\x00S\\x01\\x00\\x00'\n"
    assert needs_parentheses('__dict__') == False
    assert variable.unambiguous_source == '__dict__'


# Generated at 2022-06-20 12:42:13.079754
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a or b')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a or b.c')
    assert not needs_parentheses('(a or b).c')



# Generated at 2022-06-20 12:42:20.027138
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Test Items
    items = CommonVariable('x').items({'x': 1})
    assert len(items) == 1
    assert items[0][0] == 'x'
    assert items[0][1] == '1'

    # Test _get_value
    x = {'foo': 'bar'}
    assert CommonVariable('x')._get_value(x, 'foo') == 'bar'

    # Test _format_key
    assert CommonVariable('x')._format_key('foo') == ''
    assert CommonVariable('x')._format_key('foo') == ''

    # Test _safe_keys
    x = {'foo': 'bar'}
    assert CommonVariable('x')._safe_keys(x) == ['foo']

    # Test _keys
    x = {'foo': 'bar'}

# Generated at 2022-06-20 12:42:29.708821
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frames
    from . import variables
    from . import utils
    frame = utils.FakeFrame()
    frame.f_locals = {'a': {'b': {'c': 3}}}
    # testing code in method items of BaseVariable
    # testing method items of class Keys
    assert Keys('a').items(frame) == [('a', '{}')]
    assert Keys('a[b]').items(frame) == [('a[b]', "{'c': 3}")]
    assert Keys('a[b][c]').items(frame) == [('a[b][c]', '3')]
    assert Keys('a[b][c]').items(frame) == [('a[b][c]', '3')]

# Generated at 2022-06-20 12:42:31.509181
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    result = BaseVariable('x').items({'x':1})
    assert result[0][0] == 'x'
    assert result[0][1] == '1'


# Generated at 2022-06-20 12:42:33.872726
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x').source == 'x'
    assert Keys('x').unambiguous_source == 'x'
    assert Keys('x').code is not None
    assert Keys('x', 'y').exclude == ('y',)


# Generated at 2022-06-20 12:42:48.611264
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class PretendVariable(BaseVariable):
        def __init__(self, s):
            BaseVariable.__init__(self, s)

        def _items(self, key, normalize=False):
            pass

    v = PretendVariable("x")
    assert v.source == "x"
    assert v.code == compile("x", '<variable>', 'eval')
    assert v.unambiguous_source == "x"

# Generated at 2022-06-20 12:42:58.738535
# Unit test for function needs_parentheses
def test_needs_parentheses():
    class X:
        pass

    x = X()

    def a():
        pass
    def b(a):
        pass
    def c(a, b):
        pass
    def d():
        pass

    class A:
        pass

    class B:
        pass

    class C:
        pass

    assert not needs_parentheses('a')
    assert not needs_parentheses('x.a')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(x.a)')
    assert needs_parentheses('a()')
    assert not needs_parentheses('x.a()')
    assert needs_parentheses('(a)()')
    assert needs_parentheses('(x.a)()')
    assert needs_parentheses('(a)()()')
    assert needs_

# Generated at 2022-06-20 12:43:03.474001
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x').__eq__(BaseVariable('x')) == BaseVariable('y').__eq__(BaseVariable('y')) == True
    assert BaseVariable('x').__eq__(BaseVariable('y')) == False
    assert BaseVariable('x').__eq__(object()) == False

# Generated at 2022-06-20 12:43:07.716457
# Unit test for constructor of class Attrs
def test_Attrs():
    main = Attrs('this_is_a_test', exclude=['f'])
    assert main.source == 'this_is_a_test'
    assert main.exclude == ('f',)
    assert main.code == 'this_is_a_test'
    assert main.unambiguous_source == 'this_is_a_test'


# Generated at 2022-06-20 12:43:12.250096
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # test __init__ function of BaseVariable
    a = BaseVariable('x')
    assert a.source == 'x'
    assert a.exclude == ()

    b = Attrs('y')
    assert b.source == 'y'
    assert b.exclude == ()



# Generated at 2022-06-20 12:43:20.003414
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class test_object:
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2
    test_object_instance = test_object('', '')
    r = BaseVariable(test_object_instance.arg1)
    s = BaseVariable(test_object_instance.arg1)
    print(r==s)
    print(s.__hash__())
    print(r.__hash__())
    print(s.__hash__())

if __name__ == '__main__':
    test_BaseVariable___hash__()


__all__ = ['BaseVariable', 'Attrs', 'Keys', 'Indices', 'Exploding']

# Generated at 2022-06-20 12:43:21.631757
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))



# Generated at 2022-06-20 12:43:26.031574
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys('MyDict')
    assert var.source == 'MyDict'
    assert type(var) == Keys
    assert var.unambiguous_source == 'MyDict'
    assert type(var.code) == type(compile('1','','eval'))

# Generated at 2022-06-20 12:43:36.129423
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('a.b.()')
    assert not needs_parentheses('a.b.c.d')
    assert not needs_parentheses('a.b.c.d.e')
    assert not needs_parentheses('a.b.c.d.e.f')
    assert not needs_parentheses('a.b.c.d.e.f.g')
    assert not needs_parentheses('a().b')
    assert not needs_parentheses('a().b.c')
    assert not needs_parentheses('a.b.c()')
    assert not needs_parentheses('a[b]')
    assert not needs_parentheses

# Generated at 2022-06-20 12:43:46.134119
# Unit test for constructor of class Keys
def test_Keys():
    import exceptions
    import sys
    sys.modules['test_Keys'] = exceptions
    from collections import OrderedDict

# Generated at 2022-06-20 12:44:02.284459
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x'), 'literal'
    assert needs_parentheses('a.b'), 'dotted'
    assert needs_parentheses('a.b'), 'function call'
    assert not needs_parentheses('(x)'), 'parentheses'
    assert not needs_parentheses('a'), 'variable'
    assert needs_parentheses('lambda x: x + 1'), 'lambda'
    assert not needs_parentheses('(lambda x: x + 1)'), 'lambda parenthesized'

# Generated at 2022-06-20 12:44:06.315156
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('f')
    assert needs_parentheses('(x)')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.y.z')
    assert not needs_parentheses('x[1]')
    assert needs_parentheses('(x)[1]')
    assert needs_parentheses('(x.y)[1]')

# Generated at 2022-06-20 12:44:09.696862
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def _(source, expected_result):
        result = needs_parentheses(source)
        assert result is expected_result

    _('object', True)
    _('object.x', False)
    _('object.x.y', False)

# Generated at 2022-06-20 12:44:11.114259
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('x').items(0, 0) == ()

# Generated at 2022-06-20 12:44:22.319865
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('x.y')
    assert needs_parentheses('-x')
    assert needs_parentheses('x.y if z else a')
    assert needs_parentheses('x.y if z')
    assert needs_parentheses('(x).y if z')
    assert not needs_parentheses('((x)).y if z')
    assert needs_parentheses('((x.y).z).a')
    assert not needs_parentheses('((x.y)z).a')
    assert not needs_parentheses('x if y')
    assert not needs_parentheses('(x if y)')
    assert not needs_parentheses('(x if y).z')

# Generated at 2022-06-20 12:44:26.133099
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('f')
    assert needs_parentheses('(a) + f')
    assert needs_parentheses('1 + f')
    assert not needs_parentheses('f.x')
    assert not needs_parentheses('f.x.y')
    assert not needs_parentheses('(a).x')
    assert not needs_parentheses('((a)).x')



# Generated at 2022-06-20 12:44:31.786926
# Unit test for constructor of class Exploding
def test_Exploding():
    dict_source = "__builtins__['dict']"
    list_source = "__builtins__['list']"
    str_source = "__builtins__['str']"

    for source in [dict_source, list_source]:
        exp_var = Exploding(source)
        assert isinstance(exp_var, Keys)
    exp_var = Exploding(str_source)
    assert isinstance(exp_var, Indices)



# Generated at 2022-06-20 12:44:41.131613
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert i.source == 'a'
    assert i.exclude == tuple()
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.unambiguous_source == 'a'

    i = Indices('a', exclude='test')
    assert i.source == 'a'
    assert i.exclude == tuple(['test'])
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.unambiguous_source == 'a'

    def code(s):
        return compile(s, '<variable>', 'eval').co_code

    assert code('{}.x'.format(i.source)) != code('({}).x'.format(i.source))


# Generated at 2022-06-20 12:44:49.963820
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert (CommonVariable(source="foo").source == "foo")
    assert (CommonVariable(source="foo", exclude=('bar',)).source == "foo")
    assert (CommonVariable(source="foo", exclude=('bar',)).exclude == ('bar',))
    assert (CommonVariable(source="foo", exclude=('bar',)).code ==
            compile('foo', '<variable>', 'eval'))
    assert (CommonVariable(source="(foo).bar").source == "(foo).bar")
    assert (CommonVariable(source="(foo).bar").code ==
            compile('(foo).bar', '<variable>', 'eval'))
    assert (CommonVariable(source="foo.bar").source == "foo.bar")

# Generated at 2022-06-20 12:44:56.099033
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a_dict = {"a":1, "b":2}
    a_str = "ab"
    frame = {"a_dict": a_dict, "a_str": a_str}
    variable = Attrs("a_dict", exclude=["a"])
    variable2 = Attrs("a_str")
    # test for Attrs with exclude
    assert variable.items(frame) == tuple([("a_dict", '{\'b\': 2}'), ("a_dict.b", '2')])
    # test for Attrs without exclude
    assert variable2.items(frame) == tuple([("a_str", "'ab'"), ("a_str[0]", "'a'"), ("a_str[1]", "'b'")])
    # test for Keys

# Generated at 2022-06-20 12:45:25.761568
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Test __init__()
    assert BaseVariable('x').source == 'x'
    assert BaseVariable('x.y.z').source == 'x.y.z'
    assert BaseVariable('x', ('y',)).exclude == ('y',)
    assert BaseVariable('x', ['y']).exclude == ('y',)
    assert BaseVariable('x', 'y').exclude == ('y',)
    assert BaseVariable('x', 'y').unambiguous_source == '(x)'
    assert BaseVariable('(x)').unambiguous_source == '(x)'
    assert BaseVariable('x + 1').unambiguous_source == '(x + 1)'
    assert BaseVariable('(x + 1)').unambiguous_source == '(x + 1)'



# Generated at 2022-06-20 12:45:28.225464
# Unit test for constructor of class Attrs
def test_Attrs():
    from inspect import currentframe
    frame = currentframe()

    a = Attrs('a')
    b = a.items(frame)
    print(b)



# Generated at 2022-06-20 12:45:35.322960
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class Foo(BaseVariable):
        def __init__(self, s):
            self.s = s

        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(self.source, normalize=False))]

    assert Foo("a")._fingerprint == (Foo, "a", ())
    assert Foo("a", exclude="b")._fingerprint == (Foo, "a", ("b",))
    assert Foo("a")._fingerprint == Foo("a", exclude="b")._fingerprint
    assert Foo("a") == Foo("a", exclude="b")
    assert Foo("a") != Foo("b", exclude="b")



# Generated at 2022-06-20 12:45:41.094123
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c')
    assert needs_parentheses('(a)')
    assert needs_parentheses('(a).b')
    assert needs_parentheses('a.b.c.d')
    assert needs_parentheses('(a).b.c.d')
    assert not needs_parentheses('(a.b.c).d')
    assert needs_parentheses('(a.b).c.d')



# Generated at 2022-06-20 12:45:51.103118
# Unit test for constructor of class Exploding
def test_Exploding():
    # test with a list
    var1 = pycompat.to_str(Exploding('[1,2,3]'))
    assert var1 == '{}.0'.format(Exploding('[1,2,3]').source)
    # test with a dictionary
    var2 = pycompat.to_str(Exploding('{"a":1}'))
    assert var2 == '{}["a"]'.format(Exploding('{"a":1}').source)
    # test with an object
    var3 = pycompat.to_str(Exploding('(1+1)'))
    assert var3 == '{}.n'.format(Exploding('(1+1)').source)
    var4 = pycompat.to_str(Exploding('[1,2,3][1]'))

# Generated at 2022-06-20 12:45:57.548474
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test source codes
    source1 = 'a'
    source2 = 'a.b'
    source3 = '(a).b'
    source4 = 'a.b.c'
    source5 = 'a.b().c'
    source6 = 'a.b.c.d'
    source7 = 'a.b.c[0]'
    source8 = 'a[0]'
    source9 = 'a.b[0]'
    source10 = 'a.b.c[0]'
    source11 = 'a.b.c[0].d'
    source12 = 'a.b[0].c'
    source13 = 'a[0].b'

    # test dicts
    dict1 = {'b': 'value of b'}

# Generated at 2022-06-20 12:46:01.735848
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('a.b')
    assert repr(a) == '<BaseVariable source: a.b>'
    assert a.source == 'a.b'
    assert a.exclude == ()
    assert a.unambiguous_source == 'a.b'


# Generated at 2022-06-20 12:46:09.505284
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        pass
    class B(BaseVariable):
        pass
    a = A('123')
    b = B('123')
    assert(a!=b)
    a = A('123', 'a')
    b = A('123', 'b')
    assert(a!=b)
    a = A('123')
    b = A('123', 'a')
    assert(a!=b)
    a = A('123', 'a')
    b = A('123')
    assert(a!=b)
    a = A('123', 'a')
    b = A('123', 'a')
    assert(a==b)


# Generated at 2022-06-20 12:46:12.782083
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs("source",("exclude",))
    assert a._keys("source") == ()
    assert a._format_key("key") == '.' + "key"
    assert a._get_value("source", "key") == "source"


# Generated at 2022-06-20 12:46:18.104281
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    print(BaseVariable('x').__hash__())
    print(Attrs('x').__hash__())
    print(Keys('x').__hash__())
    print(Indices('x').__hash__())
    print(Exploding('x').__hash__())
    print(BaseVariable('x', exclude='y').__hash__())


# Generated at 2022-06-20 12:47:06.927474
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('x') == Attrs('x')
    assert not (Attrs('x') == Attrs('y'))
    assert not (Attrs('x') == Keys('x'))

    assert Keys('x') == Keys('x')
    assert not (Keys('x') == Keys('y'))
    assert not (Keys('x') == Attrs('x'))

    assert Indices('x') == Indices('x')[:]
    assert not (Indices('x') == Indices('y')[:])
    assert not (Indices('x') == Keys('x'))


# Generated at 2022-06-20 12:47:16.843415
# Unit test for constructor of class CommonVariable

# Generated at 2022-06-20 12:47:19.720604
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert indices.source == 'a'
    assert indices.exclude == ()
    assert indices.code is not None
    assert indices.unambiguous_source == 'a'
    assert indices._slice == slice(None)


# Generated at 2022-06-20 12:47:23.035583
# Unit test for constructor of class Keys
def test_Keys():
    obj = Keys('obj')
    assert obj.source == 'obj'
    assert obj.exclude == ()
    assert isinstance(obj, BaseVariable)
    assert obj._fingerprint == (Keys, 'obj', ())


# Generated at 2022-06-20 12:47:27.456791
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('foo')
    a2 = BaseVariable('foo', ('bar',))
    a3 = BaseVariable('bar')

    assert a1 == a1
    assert a2 == a2
    assert a3 == a3

    assert a1 != a2
    assert a1 != a3
    assert a2 != a3

# Generated at 2022-06-20 12:47:37.906475
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a+b').source=='a+b'
    assert Keys('a+b').exclude==()
    assert Keys('a+b').unambiguous_source =='(a+b)'
    assert Keys('a+b').code==compile('a+b','<variable>','eval')
    assert Keys('a+b.c').source=='a+b.c'
    assert Keys('a+b.c').exclude==()
    assert Keys('a+b.c').unambiguous_source=='(a+b).c'
    assert Keys('a+b.c').code==compile('a+b.c','<variable>','eval')
    assert Keys('@a').source=='@a'
    assert Keys('@a').exclude==()
    assert Keys('@a').unambiguous_

# Generated at 2022-06-20 12:47:39.650661
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding("x")
    assert isinstance(e, BaseVariable)


# Generated at 2022-06-20 12:47:43.883465
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a=BaseVariable("1+1")
    assert isinstance(a, BaseVariable)

    try:
        BaseVariable("a+1")
        assert False
    except Exception:
        assert True

    try:
        a.items("frame", "test")
        assert False
    except TypeError:
        assert True

    assert a.items("frame") == ()



# Generated at 2022-06-20 12:47:45.372712
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    common = CommonVariable('1')
    assert(set(common._safe_keys(1)) == set())


# Generated at 2022-06-20 12:47:49.913656
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'frame.f_locals'
    exclude = ('args', 'a', 'b')
    cv = CommonVariable(source, exclude)
    assert cv.source == source
    assert cv.exclude == exclude
    assert cv.code
    assert cv.unambiguous_source == source
    return cv
