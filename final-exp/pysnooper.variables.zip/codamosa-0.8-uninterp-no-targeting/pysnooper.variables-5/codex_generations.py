

# Generated at 2022-06-20 12:38:24.619817
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_a = {'a': 1, 'b': 2, 'c': 3}
    dict_b = {'dt': datetime.datetime(2017,7,27,15,36,34,872383)}
    dict_c = {'a': 1, 'b': 2, 'c': dict_a['c']}

    list_a = [0, 1, 2, 3, 4, 5]
    list_b = [1, 'a', 'hello world!', dict_a['c'], list_a[4], dict_b['dt']]

    tuple_a = (10, 20, 30, 40)
    tuple_b = ('a', 'b', (1,2,3), tuple_a[3], ('this is a tuple', ('another tuple', None, 'end of tuple')))


# Generated at 2022-06-20 12:38:27.743352
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('f()')
    assert not needs_parentheses('f(x, y)')
    assert needs_parentheses('(x)')
    assert needs_parentheses('(x.y)')
    assert needs_parentheses('(x.y) + 1')
    assert not needs_parentheses('(x.y).z')

# Generated at 2022-06-20 12:38:30.843460
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x')._slice == slice(None)
    assert Indices('x')[0:3]._slice == slice(0,3)


# Generated at 2022-06-20 12:38:35.142140
# Unit test for function needs_parentheses

# Generated at 2022-06-20 12:38:45.615373
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('a') != Indices('b')
    assert Indices('a') == Indices('a')
    assert Indices('a') != Indices('a', exclude=['b'])
    assert Indices('a', exclude=['b']) == Indices('a', exclude=['b'])
    assert Indices('a', exclude=['b']) != Indices('a', exclude=['c'])
    assert Indices('a', exclude=['b', 'c']) == Indices('a', exclude=['b', 'c'])
    assert Indices('a', exclude=['b']) != Indices('a', exclude=['b', 'c'])
    assert Indices('a', exclude=['b', 'c']) != Indices('a', exclude=['b'])


# Generated at 2022-06-20 12:38:55.349613
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from _pydevd_frame_eval.vendored import frame_eval
    from _pydevd_frame_eval.vendored.object_info import format_variable
    from _pydevd_frame_eval.vendored import object_info
    from _pydevd_frame_eval.vendored.object_info_cache import ObjectInfoCache

    class A: pass
    a = A()
    b = A()
    c = A()

    globals = {'a': a, 'b': b, 'c': c}
    locals = {'a': a, 'b': b, 'c': c}
    cache = ObjectInfoCache()
    cache.update(a)
    cache.update(b)
    cache.update(c)

    var_ = 'a'


# Generated at 2022-06-20 12:39:03.795234
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x')._fingerprint == (Keys, 'x', ())
    assert Keys('x', exclude='y')._fingerprint == (Keys, 'x', ('y',))
    assert Keys('x', exclude=('y',))._fingerprint == (Keys, 'x', ('y',))
    assert Keys('x', exclude=['y', 'z'])._fingerprint == (Keys, 'x', ('y', 'z'))
    assert Keys('x', exclude=set(['y', 'z']))._fingerprint == (Keys, 'x', ('y', 'z'))


# Generated at 2022-06-20 12:39:05.010985
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x')
    ind[1:2]

# Generated at 2022-06-20 12:39:12.366207
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import base
    from traceback import extract_stack
    from inspect import currentframe, getargvalues, getframeinfo
    
    def _get_frame_top_of_method(caller_frame):
        for (file, line, method, text) in extract_stack(caller_frame):
            if method == 'test_BaseVariable_items':
                return caller_frame
            else:
                caller_frame = caller_frame.f_back
        raise AssertionError('Method test_BaseVariable_items not found')
    def dot_path(path):
        return '.'.join(path)
    def check(variable, path, expected_value, caller_frame=None):
        if caller_frame is None:
            caller_frame = currentframe()

# Generated at 2022-06-20 12:39:23.168671
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import frames
    from . import utils
    from . import pycompat
    from . import varnames
    from . import config

    globals().update({
        'Keys': Keys,
        'Attrs': Attrs,
        'Indices': Indices,
        'Exploding': Exploding,
        'frames':frames,
        'utils': utils,
        'pycompat': pycompat,
        'varnames': varnames,
        'config': config,
    })
    e = eval('''Exploding(source='a', exclude='_exclude')''')
    assert isinstance(e._keys, method)
    assert isinstance(e.source, str)
    assert isinstance(e.exclude, tuple)

if __name__ == '__main__':
    test_Exploding()

# Generated at 2022-06-20 12:39:30.474975
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('val', exclude='a').exclude == 'a'

# Generated at 2022-06-20 12:39:35.161966
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('a')
    assert isinstance(e, BaseVariable)
    assert e.source == 'a'
    assert e.code == compile('a', '<variable>', 'eval')
    assert e.unambiguous_source == 'a'
    assert e.exclude == ()
    e = Exploding('b', exclude=['c'])
    assert isinstance(e, BaseVariable)
    assert e.source == 'b'
    assert e.code == compile('b', '<variable>', 'eval')
    assert e.unambiguous_source == 'b'
    assert e.exclude == ('c',)

# Generated at 2022-06-20 12:39:46.241530
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    Test
    """
    import sys
    import os
    import pdb
    import unittest

    def print_test(test, result):
        if test in result:
            print(test + " : " + result[test])
        else:
            print(test + " : " + "None")

    class TestBaseVariable(unittest.TestCase):
        def test_BaseVariable_items(self):
            # testing method __init__ of class BaseVariable
            # testing code: self.source = source
            self.assertEqual(x1.source, "[0]")
            # testing code: self.exclude = utils.ensure_tuple(exclude)
            self.assertEqual(x1.exclude, ())
            # testing code: if needs_parentheses(source):

# Generated at 2022-06-20 12:39:55.365856
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame = [0]
    def func():
        frame[0] += 1
        return frame[0]

    # test when argument source has parenthesiss
    var = BaseVariable('(a+b)', exclude=())
    assert var.source == '(a+b)'
    assert var.exclude == ()
    assert var.code == compile('(a+b)', '<variable>', 'eval')
    assert var._fingerprint == (BaseVariable, '(a+b)', ())
    assert var.items(frame, normalize=False) == ()

    # test when argument source has no parenthesiss
    var = BaseVariable('a+b', exclude=())
    assert var.source == 'a+b'
    assert var.exclude == ()

# Generated at 2022-06-20 12:40:05.361187
# Unit test for constructor of class Indices
def test_Indices():
    # Test construction of object of class Indices and its attributes
    indices = Indices('x.y.z')
    assert indices.source == 'x.y.z'
    assert indices.code == compile('x.y.z', '<variable>', 'eval')
    assert indices.unambiguous_source == '(x.y.z)'
    assert indices.exclude == ()
    assert indices._slice == slice(None)
    assert indices._fingerprint == (Indices, 'x.y.z', ())
    # test getitem of class Indices
    indices = indices[:]
    assert indices._slice == slice(None)


# Generated at 2022-06-20 12:40:08.742011
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')
    var_slice = var[3:6]
    assert var_slice._fingerprint == (Indices, 'var', ())
    assert var_slice._slice == slice(3, 6)

test_Indices___getitem__()

# Generated at 2022-06-20 12:40:14.824845
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x.y.z') == False

    assert needs_parentheses('(x)') == True
    assert needs_parentheses('(x.y)') == True
    assert needs_parentheses('(x.y).z') == True
    assert needs_parentheses('x.y.z()') == True

    assert needs_parentheses('1 + 2') == False
    assert needs_parentheses('x + y') == False
    assert needs_parentheses('(1 + 2)') == True
    assert needs_parentheses('(x + y)') == True
    assert needs_parentheses('(x + y).z') == True

# Generated at 2022-06-20 12:40:25.720192
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('foo').items(object()) == []
    assert Attrs('foo').items(object(), normalize=True) == []
    assert Attrs('foo', exclude=tuple()).items(object()) == []
    assert Attrs('foo', exclude=tuple()).items(object(), normalize=True) == []
    assert Attrs('foo', exclude=()).items(object()) == []
    assert Attrs('foo', exclude=()).items(object(), normalize=True) == []
    assert Attrs('foo', exclude='').items(object()) == []
    assert Attrs('foo', exclude='').items(object(), normalize=True) == []


# Generated at 2022-06-20 12:40:32.717536
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('test')
    assert i[:]._slice == slice(None)
    assert i[1:]._slice == slice(1, None)
    assert i[:3]._slice == slice(3)
    assert i[3:5]._slice == slice(3, 5)
    assert i[:4:2]._slice == slice(4, None, 2)
    assert i[4:2]._slice == slice(4, 2)
    assert i[3:]._slice == slice(3, None)
    assert i[::-1]._slice == slice(None, None, -1)

# Generated at 2022-06-20 12:40:39.854427
# Unit test for constructor of class Indices
def test_Indices():
	# Function test_Indices creates an object of class Indices,
	# and test its properties
	v = Indices('a_seq')
	assert v.source == 'a_seq'
	assert v.exclude == ()
	assert v.code == compile('a_seq', '<variable>', 'eval')
	assert v.unambiguous_source == 'a_seq'
	assert v._fingerprint == (Indices, 'a_seq', ())
	assert hash(v) == hash(v._fingerprint)
	
	# Create another object under the same class 
	v_new = Indices('a_seq')

	# Compare two objects created
	assert v == v_new

# Generated at 2022-06-20 12:40:54.538711
# Unit test for function needs_parentheses
def test_needs_parentheses():
    # Simple names should not receive parenthesis.
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')

    # Calls should receive parenthesis.
    assert needs_parentheses('f()')
    assert needs_parentheses('x.f()')
    assert needs_parentheses('x.f()[0]')

    # Binary operators should not receive parenthesis.
    assert not needs_parentheses('x + 1')
    assert not needs_parentheses('x + y')
    assert not needs_parentheses('x + y.z')

    # Multiplication should not receive parenthesis.
    assert not needs_parentheses('3 * x')
    assert not needs_parentheses('x * y')

# Generated at 2022-06-20 12:40:55.625889
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass


# Generated at 2022-06-20 12:41:02.382997
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for source in (
            'x',
            'x[0]',
            'x()',
            'x.y',
            'x[0]()',
            'x().y',
            'x[0].y',
            'x.y()',
            'x()[0]',
            '(x+1)',
            '(x)[0]',
    ):
        assert needs_parentheses(source)

    for source in (
            'x+1',
            'x*1',
            '(x+1)*2',
            'x+1*2'
    ):
        assert not needs_parentheses(source)

# Generated at 2022-06-20 12:41:07.021269
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert type(a.code) == code
    assert a.unambiguous_source == 'a'


# Generated at 2022-06-20 12:41:11.073208
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('name', exclude='exclude')
    zz = ind[1:3]
    assert zz._slice == slice(1,3)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-20 12:41:12.619050
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'test'
    exclude = ()
    code = 'test'


# Generated at 2022-06-20 12:41:14.357393
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("dict").__getitem__(slice(1, 2)) == Indices("dict")[1:2]

# Generated at 2022-06-20 12:41:25.743091
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    old = [1, 2, 3]
    new = [4, 5, 6]
    global a
    a = old
    def f(var):
        assert var.source == 'a'
        assert var.exclude == ()
        assert var.code is not None
        assert var.unambiguous_source == 'a'
        assert var.items(frame) == (('a', '[1, 2, 3]'),)
    def g(var):
        assert var.source == 'a[1:]'
        assert var.exclude == []
        assert var.code is not None
        assert var.unambiguous_source == 'a[1:]'
        assert var.items(frame) == (('a[1:]', '[2, 3]'),)
    def h(var):
        assert var.source == 'a'


# Generated at 2022-06-20 12:41:26.353013
# Unit test for constructor of class Indices
def test_Indices():
    Indices("a", ())

# Generated at 2022-06-20 12:41:28.977337
# Unit test for constructor of class Indices
def test_Indices():
    source = 'i' # source
    exclude = '' # exclude
    i = Indices(source, exclude)
    assert i.source == source
    assert i.exclude == exclude
    assert i.code == compile(source, '<variable>', 'eval')
    assert i.unambiguous_source == source


# Generated at 2022-06-20 12:41:47.829833
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import datetime
    cv = CommonVariable(source = '2+3',exclude = (1,2,'a'))
    print(cv.code)
    print(cv.source)
    print(cv.exclude)
    print(cv.unambiguous_source)
    try:
        print(cv.test)
    except:
        print('this is the except')
    print(cv.items(datetime.datetime(2018, 1, 1, 0, 0)))

# Generated at 2022-06-20 12:41:57.475802
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('foo') == Attrs('foo')
    assert not (Attrs('foo') == Attrs('bar'))
    assert not (Attrs('foo') == Attrs('foo', exclude=('abc',)))
    assert Attrs('foo.bar') == Attrs('foo.bar')
    assert not (Attrs('foo.bar') == Attrs('foo.baz'))
    assert not (Attrs('foo.bar') == Attrs('bar.bar'))
    assert Keys('foo') == Keys('foo')
    assert not (Keys('foo') == Keys('bar'))
    assert not (Keys('foo') == Keys('foo', exclude=('abc',)))
    assert Indices('foo') == Indices('foo')
    assert not (Indices('foo') == Indices('bar'))

# Generated at 2022-06-20 12:42:09.296179
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Check parameters values
    assert BaseVariable('1').source == '1'
    assert BaseVariable('1', '2').source == '1'
    assert BaseVariable('1', '2').code == compile('1', '<variable>', 'eval')
    assert BaseVariable('1', '2', '3').source == '1'
    assert BaseVariable('1', '2', '3').code == compile('1', '<variable>', 'eval')
    assert BaseVariable('1', '2', '3', '4').source == '1'
    assert BaseVariable('1', '2', '3', '4').code == compile('1', '<variable>', 'eval')
    # Check exception throws on wrong argument
    with pytest.raises(TypeError):
        BaseVariable(source = 1, exclude = '2')

# Generated at 2022-06-20 12:42:13.240213
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'source'
    exclude = ('exclude0', 'exclude1')
    common_variable = CommonVariable(source, exclude)
    assert common_variable.source == source
    assert common_variable.exclude == exclude
    assert isinstance(common_variable.code, compile)
    assert common_variable.unambiguous_source == source

# Generated at 2022-06-20 12:42:20.137165
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a[0]') is False
    assert needs_parentheses('a.x') is False
    assert needs_parentheses('a[0].x') is False
    assert needs_parentheses('(a)') is False
    assert needs_parentheses('(a).x') is False
    assert needs_parentheses('(a[0]).x') is False
    assert needs_parentheses('a.0') is True
    assert needs_parentheses('a.0.x') is True
    assert needs_parentheses('(a.0).x') is False
    assert needs_parentheses('a.0[0]') is True
    assert needs_parentheses('a.0[0].x') is True

# Generated at 2022-06-20 12:42:23.582078
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys("hello").items({'__builtins__': __builtins__}) == [("hello", "''")]
    assert Keys("hello[3]").items({'__builtins__': __builtins__}) == [("hello[3]", "'hi'")]

# Generated at 2022-06-20 12:42:32.741242
# Unit test for constructor of class Attrs
def test_Attrs():
    def test():
        class Foo(object):
            def __init__(self):
                self.a = 1
                self.b = 2
            def __getattribute__(self, name):
                return object.__getattribute__(self, name)
        foo = Foo()
        foo.c = foo.b
        foo.d = foo.a
        return foo

    f = test()
    assert Attrs('f').items(inspect.currentframe()) == [('f', 'test.<locals>.Foo object at 0x03E926F0')]
    assert Attrs('f').items(inspect.currentframe()) == [('f', 'test.<locals>.Foo object at 0x03E926F0')]

# Generated at 2022-06-20 12:42:34.503411
# Unit test for constructor of class Indices
def test_Indices():
    test_var = Indices("foo")
    print(test_var)


# Generated at 2022-06-20 12:42:35.999318
# Unit test for constructor of class Keys
def test_Keys():
    pass
    # TODO: implement your unit test here


# Generated at 2022-06-20 12:42:39.959702
# Unit test for constructor of class Indices
def test_Indices():
    x=Indices('x')
    y=Indices('y')
    assert (x[0] == y[0])
    assert (x[0:2] == y[0:2])

# Generated at 2022-06-20 12:43:05.179069
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable("x.y")
    assert var.source == "x.y"
    assert var.code == compile("x.y", '<string>', 'eval')
    assert var.unambiguous_source == "(x.y)"


# Generated at 2022-06-20 12:43:09.085293
# Unit test for constructor of class Keys
def test_Keys():
    source = 'foo'
    exclude = 'bar'
    key = Keys(source, exclude)
    assert key.source == source
    assert key.exclude == exclude
    assert key.unambiguous_source == source
    assert key.code == compile(source, '<variable>', 'eval')

# Generated at 2022-06-20 12:43:11.527904
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert (hash(BaseVariable('')) == hash(BaseVariable('')) 
            == hash(BaseVariable('', exclude=())))


# Generated at 2022-06-20 12:43:15.035781
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('data')
    assert needs_parentheses('data[0]')
    assert not needs_parentheses('data.std()')
    assert needs_parentheses('(data + 1) / 2')
    assert needs_parentheses('(data).std()')

# Generated at 2022-06-20 12:43:19.590987
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
	# Test case 1: constructor with parameters source and exclude
	v1 = CommonVariable('source', 'exclude')
	 #expect value should be 1
	assert v1._fingerprint == (CommonVariable, 'source', ('e', 'x', 'c', 'l', 'u', 'd', 'e'))

	# Test case 2: constructor with parameter source
	v2 = CommonVariable('source')
	#expect value should be 2
	assert v2._fingerprint == (CommonVariable, 'source', ())

# test for class Attrs

# Generated at 2022-06-20 12:43:30.213570
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # add a global variable in env
    env = {
        'x': {
            'y': {
                'z': 'foo'
            }
        }
    }

    # build a local list in env
    frame = inspect.currentframe()
    for key, value in env.items():
        frame.f_globals[key] = value

    # test the keys and source of variables
    result = list(BaseVariable('x').items(frame))
    assert result[0][0] == 'x'

    # test the items of class Exploding
    result = list(Exploding('x').items(frame))
    assert result[0][0] == 'x'
    assert result[1][0] == 'x.y'
    assert result[2][0] == 'x.y.z'

    # test the items

# Generated at 2022-06-20 12:43:36.558036
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    frame = frame = inspect.currentframe()
    item = CommonVariable('x', exclude='x')
    assert item.source == 'x'
    assert item.exclude == ('x',)
    assert isinstance(item.code, types.CodeType)
    assert item.unambiguous_source == '(x)'
    assert item.items(frame) == [('x', '1')]
    assert item.items(frame) != [('x', '2')]
    assert item.items(frame) != [('y', '1')]


# Generated at 2022-06-20 12:43:39.311408
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("a")
    b = BaseVariable("b")
    c = BaseVariable("a")
    d = Indices("d")
    assert(a == c)
    assert(a != b)
    assert(a != d)


# Generated at 2022-06-20 12:43:45.560159
# Unit test for constructor of class Indices
def test_Indices():
    seq = range(100)
    i = Indices("name")
    assert i.source == "name"
    i = i[10:20]
    assert i.source == "name"
    for index, value in zip(range(10, 20), seq[10:20]):
        assert (i._format_key(index), i._get_value(seq, index)) == (str(index), value)
    return 0


# Generated at 2022-06-20 12:43:56.237671
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from .frames import Frame
    from .objects import Status
    import copy
    import inspect

    def get_variable_list(f):
        """ Get a list of variables according to the decoratored function"""
        frame = Frame(f)
        variables = frame.locals + frame.globals
        return variables.items()

    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ()

    def test_function(f, g):
        """ Check if the decorated function produces
        the same output as the original function, decoratored
        with the BaseVariable object
        """
        a = get_variable_list(f)
        b = get_variable_list(g)
        return a == b


# Generated at 2022-06-20 12:44:41.950803
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x')[1:] == Indices('x')[1:]
    assert Indices('y')[1:] == Indices('x')[1:]
    assert Indices('y')[:1] != Indices('x')[1:]

# Generated at 2022-06-20 12:44:50.682553
# Unit test for constructor of class Exploding
def test_Exploding():
    variable = Exploding
    variable_attrs = variable('test_variable')
    variable_keys = variable('test_variable')
    variable_indices = variable('test_variable')
    class_A = 'class_A'
    class_B = 'class_B'
    class_C = 'class_C'
    obj_1 = 'obj_1'
    obj_2 = 'obj_2'
    obj_3 = 'obj_3'
    obj_4 = 'obj_4'
    obj_5 = 'obj_5'
    obj_6 = 'obj_6'
    obj_7 = 'obj_7'
    obj_8 = 'obj_8'
    obj_9 = 'obj_9'
    obj_10 = 'obj_10'
    obj_11 = 'obj_11'
   

# Generated at 2022-06-20 12:44:52.824994
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source='a'
    cls = BaseVariable(source)
    frame={'a':(1,2)}
    result=cls.items(frame)
    assert result == []


# Generated at 2022-06-20 12:44:56.101858
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'something'
    exclude = ()
    index = slice(1,3)
    new_instance = Indices(source, exclude)
    result = new_instance.__getitem__(index)
    assert (result._slice == index)



# Generated at 2022-06-20 12:45:02.969726
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert isinstance(BaseVariable('x'), BaseVariable)
    assert isinstance(BaseVariable('(x)'), BaseVariable)
    assert isinstance(BaseVariable('x.y'), BaseVariable)
    assert isinstance(BaseVariable('x[0]'), BaseVariable)
    assert isinstance(BaseVariable('x[0].y'), BaseVariable)
    assert isinstance(BaseVariable('x[0]', exclude='y'), BaseVariable)


# Generated at 2022-06-20 12:45:05.016222
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('item')
    var2 = BaseVariable('item')
    assert var1 == var2


# Generated at 2022-06-20 12:45:08.394647
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var_slice = var[1:3]
    assert var != var_slice
    assert isinstance(var_slice, Indices)
    assert var_slice._slice == slice(1, 3)


# Generated at 2022-06-20 12:45:12.021720
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=('b'))
    assert BaseVariable('a') != BaseVariable('b')

    assert BaseVariable('a') != object()
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != 1



# Generated at 2022-06-20 12:45:22.587337
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable(source="valx", exclude=("a",))
    print("print var: " + str(var))
    print("print var.source: " + var.source)
    print("print var.exclude: " + str(var.exclude))
    print("print var.code: " + str(var.code))
    print("print var.unambiguous_source: " + var.unambiguous_source)
    print("print var.items({'valx': 1, 'valy': 2}): " + str(var.items({'valx': 1, 'valy': 2})))
    print("print hash(var): " + str(hash(var)))

if __name__ == "__main__":
    test_BaseVariable()

# Generated at 2022-06-20 12:45:27.034405
# Unit test for constructor of class Attrs
def test_Attrs():
    with pytest.raises(NotImplementedError):
        Attrs(1)._keys(1)
    with pytest.raises(NotImplementedError):
        Attrs(1)._format_key(1)
    with pytest.raises(NotImplementedError):
        Attrs(1)._get_value(1)


# Generated at 2022-06-20 12:46:55.077546
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import test_utils
    test_utils.run_doctest(Attrs, globals())



# Generated at 2022-06-20 12:46:56.995629
# Unit test for constructor of class Keys
def test_Keys():
    from . import utils
    assert utils.replace_method_argument_regex.match(Keys.__init__.__doc__)

# Generated at 2022-06-20 12:47:03.921983
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('obj').source == 'obj'
    assert Attrs('obj.a').source == 'obj.a'
    exc = Attrs('obj.a', exclude=['b', 'c'])
    assert exc.source == 'obj.a'
    assert exc.exclude == ('b', 'c')
    assert Attrs('obj.a', exclude='b').source == 'obj.a'
    assert Attrs('obj.a', exclude='b').exclude == ('b',)


# Generated at 2022-06-20 12:47:09.297801
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    item = slice(1,3)
    var_srcs = [Indices('main_value')[item].source, 'main_value[1:3]']
    var_srcs = utils.ensure_tuple(var_srcs)
    assert var_srcs[0] == var_srcs[1], '__getitem__ is not implemented yet.'

# Generated at 2022-06-20 12:47:12.201265
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()
    b = Attrs('a', ['b'])
    assert b.exclude == ('b',)

# Generated at 2022-06-20 12:47:20.390886
# Unit test for constructor of class Attrs
def test_Attrs():
    import numpy as np
    n = np.array([1, 2, 3])
    a = Attrs('n')
    assert a._keys(n) == ['size', 'shape', 'strides', 'data', 'dtype', 'real', 'imag', 'flat', 'ctypes', '__array_interface__', '__array_struct__', '__array_priority__', '__array_finalize__']
    assert a._format_key('size') == '.size'
    value = a._get_value(n, 'size')
    assert value == 3
    value = a._get_value(n, 'T')
    assert value == 'not a key'
    value = a._get_value(n, 'size')
    assert value == 3
    value = a._get_value(n, 'T')
    assert value

# Generated at 2022-06-20 12:47:22.365451
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('x')
    print (i.source)
    print (i._slice)

# Generated at 2022-06-20 12:47:26.205566
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert CommonVariable('a') == CommonVariable('a')
    assert CommonVariable('a') != CommonVariable('b')
    assert CommonVariable('a') != Attrs('a')
    assert CommonVariable('a', exclude=('b')) != CommonVariable('a', exclude=('c'))

# Generated at 2022-06-20 12:47:32.728272
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert needs_parentheses('a')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('a.b')
    assert needs_parentheses('a[1]')
    assert not needs_parentheses('a[(1)]')
    assert needs_parentheses('a.b[1]')
    assert BaseVariable(None).source == None
    assert BaseVariable(None).exclude == ()


# Generated at 2022-06-20 12:47:39.517902
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    filename = 'pdbpp_tests_BaseVariable.py'
    line_number = 9
    source = 'var1'

    bv = BaseVariable(source)
    assert isinstance(bv, BaseVariable)
    assert bv.code is not None
    assert bv.source == source
    assert bv.exclude == ()
    assert bv.code.co_filename == filename
    assert bv.code.co_firstlineno == line_number
    assert str(bv.code) == "0 LOAD_NAME 'var1' (3)\n" \
                           "3 RETURN_VALUE\n"
