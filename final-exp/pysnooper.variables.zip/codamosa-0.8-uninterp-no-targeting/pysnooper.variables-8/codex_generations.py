

# Generated at 2022-06-20 12:38:20.704675
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert Attrs('a.x', exclude=['d']).items({'a': {'x': 1, 'd': 2}}) ==\
           [('a.x', '1'), ('a.x.x', '1'), ('a.x.d', '2')]

# Unit tests for constructor of class Attrs

# Generated at 2022-06-20 12:38:22.235925
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable("1")
    assert(v.items("")==())


# Generated at 2022-06-20 12:38:32.828965
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v1 = CommonVariable('a')
    assert v1.source == 'a'
    assert v1.code == compile('a', '<variable>', 'eval')
    assert v1.unambiguous_source == 'a'
    assert v1.exclude == ()

    ## it's a tuple, not list
    v2 = CommonVariable('a', exclude=[1, 2, 3])
    assert v2.source == 'a'
    assert v2.code == compile('a', '<variable>', 'eval')
    assert v2.unambiguous_source == 'a'
    assert v2.exclude == (1, 2, 3)

    v3 = CommonVariable('a', exclude=[1, 2, 3])
    assert v3.source == 'a'

# Generated at 2022-06-20 12:38:34.617926
# Unit test for constructor of class Indices
def test_Indices():
	a=Indices('a','b')
	assert a.source == 'a'
	assert a.exclude == ('b', )

# Generated at 2022-06-20 12:38:37.974820
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable("6")
    assert cv.source == "6"
    assert cv.exclude == ()
    assert cv.code == compile("6", '<variable>', 'eval')
    assert cv.unambiguous_source == "6"


# Generated at 2022-06-20 12:38:44.742881
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs("a")
    assert a.code == compile("a", '<variable>', 'eval')
    assert a.source == "a"
    assert a.exclude is None
    assert a.unambiguous_source == "a"

    b = Attrs("b", exclude="exclude")
    assert b.code == compile("b", '<variable>', 'eval')
    assert b.source == "b"
    assert b.exclude == "exclude"
    assert b.unambiguous_source == "b"


# Generated at 2022-06-20 12:38:49.596830
# Unit test for constructor of class Attrs
def test_Attrs():
    atr = Attrs('a', exclude=('a',))
    assert atr.source == 'a'
    assert atr.exclude == ('a',)
    assert atr.code == compile('a', '<variable>', 'eval')
    assert atr.unambiguous_source == 'a'



# Generated at 2022-06-20 12:38:54.537318
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    from frame import frame
    assert BaseVariable(source="frame.f_locals['a']", exclude=frame)
    assert BaseVariable(source="frame.f_locals['a']", exclude=('a','b'))
    assert BaseVariable(source="frame.f_locals['a']", exclude=())


# Generated at 2022-06-20 12:38:57.486910
# Unit test for constructor of class Attrs
def test_Attrs():
	a = Attrs("a",("source","source2"))
	assert(a.source == "a")
	assert(a.exclude == ("source","source2"))


# Generated at 2022-06-20 12:39:06.787536
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from devlib.core.utils.pythonic import is_true
    # One BaseVariable object is equal to another BaseVariable object
    # having the same source, exclude, and type as the first BaseVariable
    # object
    assert is_true(Attrs('foo.bar', 'spam') == Attrs('foo.bar', 'spam'))
    assert is_true(Attrs('foo.bar', 'spam') != Attrs('foo.baz', 'spam'))
    assert is_true(Exploding('foo.bar', 'spam') == Exploding('foo.bar', 'spam'))
    assert is_true(Exploding('foo.bar', 'spam') != Exploding('foo.bar', 'eggs'))


# Generated at 2022-06-20 12:39:22.038892
# Unit test for constructor of class Attrs
def test_Attrs():
    assert(set(Attrs('a').items((), {'a': 1})) == {('a', '1')})
    assert (set(Attrs('a').items((), {'a': 1}, True)) == {('a', 'int')})
    a = object()
    a.x = 1
    assert(set(Attrs('a').items((), {'a': a})) == {('a.x', '1')})
    assert(set(Attrs('a', exclude='x').items((), {'a': a})) == {('a', '<object object at ' + hex(id(a)) + '>')})
    a.x = object()
    a.x.y = 1

# Generated at 2022-06-20 12:39:23.900469
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    result = Indices('main_value')[3:10]
    assert result._slice == slice(3,10)

# Generated at 2022-06-20 12:39:32.175489
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    attrs = Attrs('x', exclude=('__dict__',))

# Generated at 2022-06-20 12:39:33.899695
# Unit test for constructor of class Keys
def test_Keys():
    a = dict()
    b = 'abc'
    a['k1'] = b
    a['k2'] = '123'
    test = Keys('a')
    test.items(sys._getframe())

# Generated at 2022-06-20 12:39:45.371063
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test method items in class BaseVariable
    import sys
    import os
    import inspect
    import unittest
    import inspect
    import sys

    def get_filename_and_lineno():
        try:
            raise Exception
        except:
            f = sys.exc_info()[2].tb_frame.f_back
        return f.f_code.co_filename, f.f_lineno

    class TestBaseVariable(unittest.TestCase):
        def test_BaseVariable_items(self):
            class BaseVariable_tester(BaseVariable):
                def _items(self, main_value, normalize=False):
                    return [(0,0)]
            instance = BaseVariable_tester('1')
            self.assertTrue(type(instance.source) == str)

# Generated at 2022-06-20 12:39:54.509375
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # assert __eq__
    v1 = Attrs('a', ('b',))
    v2 = Attrs('a', ('b',))
    assert v1 == v2
    v3 = Attrs('a', ('b', 'c'))
    assert v3 != v2
    v4 = Keys('a')
    assert v1 != v4
    # assert __hash__
    v5 = Attrs('a', ('b',))
    v6 = Attrs('a', ('b',))
    v7 = Attrs('a', ('b', 'c'))

    assert hash(v1) == hash(v5)
    assert hash(v2) == hash(v6)
    assert hash(v3) != hash(v7)
    assert hash(v1) != hash(v4)



# Generated at 2022-06-20 12:39:55.139227
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    raise NotImplementedError()


# Generated at 2022-06-20 12:40:00.993173
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = {'a': 1, 'b': 2, 'c': 3}
    tmp = Indices('main_value')
    print(tmp.items(None))
    tmp = tmp[::-1]
    print(tmp.items(None))


if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-20 12:40:05.602566
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices.__getitem__(slice(0,3)) == Indices('x')
    assert indices.__getitem__(slice(1,4)) == Indices('x')
    assert indices.__getitem__(slice(2,4)) == Indices('x')



# Generated at 2022-06-20 12:40:08.984694
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a', exclude='b')
    assert k.source == 'a'
    assert k.exclude == ('b',)
    assert k.unambiguous_source == 'a'
    assert k._fingerprint == (Keys, 'a', ('b',))


# Generated at 2022-06-20 12:40:21.496083
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices("main_value")
    assert_equal(var._slice, slice(None))
    assert_equal(var.source, "main_value")

    var = var[2:3]
    assert_equal(var._slice, slice(2, 3, None))
    assert_equal(var.source, "main_value")

# Generated at 2022-06-20 12:40:22.732247
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('var')


# Generated at 2022-06-20 12:40:32.302069
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from .utils import register_class_for_testing
    import unittest

    @register_class_for_testing
    class Test(BaseVariable):
        def __init__(self, a, b):
            super(Test, self).__init__('self.source', 'self.exclude')
            self.a = a
            self.b = b

    class Test_BaseVariable_hash(unittest.TestCase):
        def setUp(self):
            super(Test_BaseVariable_hash, self).setUp()
            self.a = Test('a', 'b')
            self.b = Test('a', 'b')
            self.c = Test('d', 'e')


# Generated at 2022-06-20 12:40:37.290443
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x')._slice == slice(None)
    assert Indices('x')[0:10]._slice == slice(0, 10)
    assert Indices('x')[:10]._slice == slice(0, 10)
    assert Indices('x')[10:]._slice == slice(10, None)
    assert Indices('x')[10:20]._slice == slice(10, 20)

# Generated at 2022-06-20 12:40:44.985092
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from sys._getframe import _getframe
    bv=BaseVariable('d[' '"c"' ']',exclude='12345')
    a={'b':('v',['w','x','y','z'])}
    d={'a':a,'c':3,'d':{'c':a}}
    frame=_getframe(1)
    frame.f_locals['d']=d
    result=list(bv.items(frame))

# Generated at 2022-06-20 12:40:52.838537
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # The attribute 'source' in the third one is different from the others.
    result = set()
    var = [BaseVariable('a'), BaseVariable('b'), BaseVariable('c')]
    result.add(var[0])
    result.add(var[0])
    result.add(var[1])
    result.add(var[0])
    result.add(var[1])
    result.add(var[2])
    # The order of var might be not the same as the order of the set result.
    assert var[0] not in result
    assert var[1] not in result
    assert var[2] in result


# Generated at 2022-06-20 12:40:59.310557
# Unit test for constructor of class Keys
def test_Keys():
    import yaml
    y = yaml.load(open('/home/mustakim/dev/map_tools/test/data/test_yaml.yaml'))
    # Use the Keys class to get the data in the yaml file
    klass = Keys('y', exclude=())
    keys_list = klass._keys(y)
    # print(list(keys_list))
    keys_list_with_values = klass.items(y, normalize=False)
    # print(keys_list_with_values)


# Generated at 2022-06-20 12:41:01.746832
# Unit test for constructor of class Indices
def test_Indices():
    s = Indices('x')
    if (s.source == 'x') & (s.exclude == ()):
        print('Passed')
    else:
        print('Failed')


# Generated at 2022-06-20 12:41:04.928769
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable = CommonVariable(source='arr', exclude='exclude')
    assert variable.source == 'arr'
    assert variable.exclude == ('exclude', )


# Generated at 2022-06-20 12:41:11.074716
# Unit test for constructor of class Indices
def test_Indices():
    a=Indices("a")
    assert a.source == "a"
    assert a.exclude == ()
    assert a._slice == slice(None)
    assert a._fingerprint == (Indices, "a", ())
    assert a._safe_keys(1) == ()
    # a[::-1]
    assert a[::-1]._slice == slice(None, None, -1)


# Generated at 2022-06-20 12:41:22.499458
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():

    i = Indices('my_variable')
    i1 = i[:]
    i2 = i[1:5]
    assert i1 is not i
    assert i2 is not i
    assert i1 is not i2
    assert i._slice == slice(0, len(i))
    assert i1._slice == slice(0, len(i))
    assert i2._slice == slice(1, 5)

# Generated at 2022-06-20 12:41:25.558257
# Unit test for constructor of class Keys
def test_Keys():
    """
    my_dict = {'a':1}
    test_Keys = Keys('my_dict')
    test_Keys.keys('my_dict')
    """
    pass


# Generated at 2022-06-20 12:41:30.117058
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('*args', exclude=['d'])
    assert indices._keys((1,2,3,4,5)) == range(5)
    assert indices._get_value((1,2,3,4,5), 3) == 4
    assert indices._format_key(2) == '[2]'
    assert indices[1:3]._keys((1,2,3,4,5)) == range(1,3)


# Generated at 2022-06-20 12:41:34.709159
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable("x", "y")
    assert variable.source == "x"
    assert variable.exclude == ("y",)
    assert variable.code == compile("x",'<variable>','eval')
    assert variable.unambiguous_source == "(x)"


# Generated at 2022-06-20 12:41:37.905966
# Unit test for constructor of class Indices
def test_Indices():
    result = Indices("source", exclude="exclude")
    assert result.source == "source"
    assert result.exclude == ("exclude",)
    assert result.code == compile("source", '<variable>', 'eval')
    assert result.unambiguous_source == "source"

# Generated at 2022-06-20 12:41:41.485318
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'source'
    exclude = 'a'
    bv = BaseVariable(source, exclude)
    assert bv.source == source
    assert bv.exclude == (exclude,)
    assert bv.unambiguous_source == source
    assert bv.code
    

# Generated at 2022-06-20 12:41:45.603184
# Unit test for constructor of class Exploding
def test_Exploding():
    E = Exploding('some_var')
    assert E.source == 'some_var'
    assert E.exclude == tuple()
    assert E.code == compile('some_var', '<variable>', 'eval')
    assert needs_parentheses('some_var') == True
    assert E.unambiguous_source == '(some_var)'


# Generated at 2022-06-20 12:41:47.488676
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('test[')
    assert i[::2]._slice == slice(0, None, 2)


# Generated at 2022-06-20 12:41:54.239784
# Unit test for constructor of class Attrs
def test_Attrs():
    frame = frame = call_stack()[0]

    a = Attrs('a', exclude=['argv'])
    assert a.source == 'a'
    assert a.exclude == ('argv',)

    a_items = a.items(frame, normalize=False)
    assert a_items[0] == ("a", 'sys')

    a_items1 = a.items(frame, normalize=True)
    assert a_items1[0] == ("a", 'module sys')

# Generated at 2022-06-20 12:41:57.354175
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    common_variable = CommonVariable('sdsds')
    assert common_variable.source == 'sdsds'
    assert common_variable.exclude == ()
    assert common_variable.code == compile('sdsds', '<variable>', 'eval')


# Generated at 2022-06-20 12:42:14.270248
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x'), 'x'
    assert not needs_parentheses('(x)'), '(x)'
    assert not needs_parentheses('y'), 'y'
    assert needs_parentheses('x + y'), 'x + y'
    assert needs_parentheses('x()'), 'x()'
    assert not needs_parentheses('(x())'), '(x())'
    assert needs_parentheses('x.y'), 'x.y'
    assert not needs_parentheses('(x).y'), '(x).y'
    assert needs_parentheses('x[y]'), 'x[y]'
    assert not needs_parentheses('(x)[y]'), '(x)[y]'

# Generated at 2022-06-20 12:42:16.415193
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    #Base case
    assert BaseVariable('x')


# Generated at 2022-06-20 12:42:19.389874
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    indices_slice = indices[:2]
    assert(isinstance(indices_slice, Indices))
    assert(indices_slice._slice == slice(0, 2, 1))
    indices_slice = indices[::2]
    assert(indices_slice._slice == slice(0, 10, 2))

# Generated at 2022-06-20 12:42:24.423467
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('x', exclude=('x', 'y'))
    assert x.source == 'x'
    assert x.exclude == ('x', 'y')
    assert x.code == compile('x', '<variable>', 'eval')


# Generated at 2022-06-20 12:42:25.927078
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    obj = CommonVariable('test')
    assert bool(obj)


# Generated at 2022-06-20 12:42:33.568246
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global_var = {'foo': 'bar'}
    def test_func():
        foo = 'bar'
    def test_func_with_global_var():
        foo = 'bar'
        foo = global_var
    frame = test_func.__code__.co_varnames
    test = BaseVariable('_')
    assert test.items(frame) == [('_', '"bar"')]
    # test to get items from global variable
    frame = test_func_with_global_var.__code__.co_varnames
    test = BaseVariable('_')
    assert test.items(frame) == [('_', '"bar"'), ('(_).foo', '"bar"')]


# Generated at 2022-06-20 12:42:37.758413
# Unit test for constructor of class Indices
def test_Indices():
    indices_obj = Indices("var", exclude=["abc", "def"])
    assert indices_obj.source == "var"
    assert indices_obj.exclude == ("abc", "def")
    assert indices_obj._slice == slice(None)


# Generated at 2022-06-20 12:42:42.045831
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    D = {'a': 1, 'b': 2}
    cv = CommonVariable('D', 'a')
    assert cv.items(None) == [('D', '{...}'), ('D.b', '2')]


# Generated at 2022-06-20 12:42:49.727921
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame = utils.get_frame(BaseVariable)
    v = BaseVariable('1.0', 'float')
    assert v.items(frame) == [
        ('1.0', repr(1.0)),
        ('1.0.real', repr(1.0)),
        ('1.0.imag', repr(0.0)),
        ('1.0.numerator', repr(1.0)),
        ('1.0.denominator', repr(1.0)),
    ]

# Generated at 2022-06-20 12:42:54.539771
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable('a', exclude=['b', 'c'])
    assert var.source == 'a'
    assert var.exclude == ('b', 'c')
    assert var.code == compile('a', '<variable>', 'eval')
    assert var.unambiguous_source == 'a'
    assert var.items(None) == ()

# Generated at 2022-06-20 12:43:20.393555
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Foo(BaseVariable):
        pass

    foo1 = Foo('x')
    foo2 = Foo('x', exclude=0)
    foo3 = Foo('y')
    foo4 = Foo('x')
    foo5 = Foo('x', exclude=0)
    foo6 = Foo('y')
    foo7 = Foo('x')
    foo8 = Foo('x', exclude=0)
    foo9 = Foo('y')
    assert (foo1 != foo2 != foo3 != foo4 == foo5 != foo6 != foo7 == foo8 == foo9)



# Generated at 2022-06-20 12:43:24.432788
# Unit test for constructor of class Exploding
def test_Exploding():
    assert len(Exploding('foo').items(None)[0]) == 2
    assert len(Exploding('foo').items(None)[1]) == 2
    assert len(Exploding('foo').items(None)[2]) == 2
    assert len(Exploding('foo').items(None)[3]) == 2

test_Exploding()

# Generated at 2022-06-20 12:43:34.921072
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c[d]')
    assert needs_parentheses('a.b.c(d)')
    assert needs_parentheses('a.b(c).d(e).f[g](h)')

    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a(b))')
    assert not needs_parentheses('(a.b).c')
    assert not needs_parentheses('(a.b).c[d]')
    assert not needs_parentheses('(a(b)).c[d]')
    assert not needs_parentheses('(a(b)).c[d.e]')
   

# Generated at 2022-06-20 12:43:42.139760
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def check(code, expected_result):
        result = needs_parentheses(code)
        if result != expected_result:
            raise AssertionError('needs_parentheses({!r}) gave wrong result: '
                                 '{!r} != {!r}'.format(code, result, expected_result))

    check('a', True)
    check('a.b', False)
    check('a.b.c', False)
    check('(a.b)', False)
    check('((a.b))', False)
    check('a.b.c.d', False)
    check('(a.b).c.d', False)
    check('a.b.c.d.e', False)
    check('(a.b).c.d.e', False)

# Generated at 2022-06-20 12:43:47.890002
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs('a', exclude=['__class__'])
    assert attr.source == 'a'
    assert attr.exclude == ('__class__',)
    assert attr.code == compile('a', '<variable>', 'eval')
    assert attr.unambiguous_source == '(a)'


# Generated at 2022-06-20 12:43:57.990852
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    def check(variable, main_value, expected):
        assert list(variable._items(main_value)) == expected

    # test object with attributes
    class A:
        attr1 = 1
        attr2 = 2

    a = A()
    check(Attrs('a'), a, [('a', 'A()'), ('a.attr1', '1'), ('a.attr2', '2')])
    check(Attrs('a', exclude=['attr1']), a, [('a', 'A()'), ('a.attr2', '2')])

    # test dictionary-like object
    class B:
        def keys(self):
            return ['attr1', 'attr2']

        def __getitem__(self, item):
            return item

    b = B()

# Generated at 2022-06-20 12:44:02.952968
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    from types import ModuleType
    import mock
    import numpy as np
    with mock.patch(__name__ + '.utils.get_shortish_repr', autospec=True) as m:
        m.side_effect = lambda x, normalize: x
        bv = BaseVariable('int')
        assert bv.source == 'int'
        assert bv.exclude == ()
        bv = BaseVariable('list', 'append')
        assert bv.source == 'list'
        assert bv.exclude == ('append',)
        bv = BaseVariable('foo.bar.baz')
        assert bv.source == 'foo.bar.baz'
        assert bv.exclude == ()
        bv = BaseVariable('foo.bar.baz', 'boo')

# Generated at 2022-06-20 12:44:05.713545
# Unit test for constructor of class Attrs
def test_Attrs():
    start = 100
    class TestAttrs:
        x = 1
        y = 2
        
        def __init__(self, start):
            self.z = start
            
    ob = TestAttrs(start)
    attrs = Attrs('ob')

# Generated at 2022-06-20 12:44:17.628980
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {'a': 1,'b':2, 'c':3} # main_value is a dictionary
    main_value2 = [1,2,3,4,5] # main_value is a list

    ev = Exploding('ev')
    #print(isinstance(ev,BaseVariable)) # True
    class_result0 = ev.__class__.__name__ # "Exploding"
    #print(class_result0)

    #main_value is a dictionary
    #assert ev._items(main_value) == [
    #    ('ev', '{}'),
    #    ('ev.a', '1'),
    #    ('ev.b', '2'),
    #    ('ev.c', '3'),
    #]

    #main_value is a list

# Generated at 2022-06-20 12:44:22.832183
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    test_instance = BaseVariable("sys.argv[1]")
    assert test_instance.source == "sys.argv[1]"
    assert test_instance.exclude == ()
    assert test_instance.code == compile("sys.argv[1]", "<variable>", "eval")
    assert test_instance.unambiguous_source == "sys.argv[1]"


# Generated at 2022-06-20 12:45:07.986186
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding(source = 'main_value')
    assert isinstance(e, BaseVariable)

# Unit tests for class Keys

# Generated at 2022-06-20 12:45:10.780046
# Unit test for constructor of class Keys
def test_Keys():
    # Data
    source = 'a'
    exclude = 'b'
    test_keys = Keys(source, exclude)
    assert test_keys.source == source
    assert test_keys.exclude == exclude


# Generated at 2022-06-20 12:45:17.213386
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert not needs_parentheses('a.x')
    assert needs_parentheses('a.x()')
    assert needs_parentheses('(a)')
    assert not needs_parentheses('(a).x')
    assert needs_parentheses('(a)(b)')
    assert not needs_parentheses('a[0]')
    assert needs_parentheses('a[0].x')
    assert not needs_parentheses('a[(0)]')
    assert not needs_parentheses('(a)[0]')
    assert needs_parentheses('(a[0])')

# Generated at 2022-06-20 12:45:28.143719
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Inspection of hash codes of equal objects shows that they MUST be equal
    assert hash(BaseVariable("0")) == hash(BaseVariable("0"))
    assert hash(BaseVariable("0", exclude=1)) == hash(BaseVariable("0", exclude=1))
    assert hash(BaseVariable("0", exclude=())) == hash(BaseVariable("0"))
    # Inspection of hash codes of non-equal objects shows that they MUST be different
    assert hash(BaseVariable("0")) != hash(BaseVariable("1"))
    assert hash(BaseVariable("0")) != hash(BaseVariable("0", exclude=1))
    assert hash(BaseVariable("0", exclude=1)) != hash(BaseVariable("1", exclude=1))
    assert hash(BaseVariable("0")) != hash(BaseVariable("0", exclude=()))


# Generated at 2022-06-20 12:45:29.920892
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('self')
    assert hash(v) == hash((type(v), 'self',()))


# Generated at 2022-06-20 12:45:37.307000
# Unit test for constructor of class Keys
def test_Keys():
    #1. set up
    test_Keys_source = 'a'
    test_Keys_exclude = 'a'
    test_Keys_property_source = 'a'
    test_Keys_property_unambiguous_source = 'a'
    test_Keys_property_code = compile('a', '<variable>', 'eval')
    #2. run the code to be tested
    test_Keys_instance = Keys(test_Keys_source, test_Keys_exclude)
    #3. assert the result
    assert 'source' in test_Keys_instance.__dict__
    assert 'exclude' in test_Keys_instance.__dict__
    assert 'code' in test_Keys_instance.__dict__
    assert 'unambiguous_source' in test_Keys_instance.__dict__
    assert test_Keys_

# Generated at 2022-06-20 12:45:46.937680
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("") is False
    assert needs_parentheses("0") is False
    assert needs_parentheses("()") is False
    assert needs_parentheses("0.x") is False
    assert needs_parentheses("0.x()") is False
    assert needs_parentheses("a") is False
    assert needs_parentheses("a.x") is False
    assert needs_parentheses("a.x()") is False
    assert needs_parentheses("(a)") is False
    assert needs_parentheses("(a).x") is False
    assert needs_parentheses("(a).x()") is False
    assert needs_parentheses("0[0]") is False
    assert needs_parentheses("0[0]()") is False
    assert needs_parentheses("a[0]") is False
    assert needs

# Generated at 2022-06-20 12:45:49.164696
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = "a.b"
    v1 = BaseVariable(source, exclude=("a",))
    assert hash(v1) > 0

# Generated at 2022-06-20 12:45:51.723987
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo')[1:2]._slice == slice(1,2)
    assert Indices('foo')[1:2]._slice == slice(1,2)

# Generated at 2022-06-20 12:45:52.406050
# Unit test for constructor of class Attrs
def test_Attrs():
    obj = Attrs('obj')
    print(obj)



# Generated at 2022-06-20 12:47:35.885124
# Unit test for constructor of class Attrs
def test_Attrs():
    assert (Attrs('a', exclude=['b']) ==
            Attrs('a', exclude=['b']))
    assert (Attrs('a', exclude=['b']) !=
            Attrs('a', exclude=['b', 'c']))
    assert (Attrs('a', exclude=['b']) !=
            Attrs('a', exclude=()))
    assert (Attrs('a', exclude=['b']) !=
            Attrs('b', exclude=['b']))
    assert (Attrs('a', exclude=['b']) !=
            Attrs('a', exclude=()))
    assert (Attrs('a', exclude=['b']) !=
            object())


# Generated at 2022-06-20 12:47:39.544923
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices(source="x", exclude="x.__class__")
    assert ind[0:1].source == "x", "Variable source"
    assert ind[0:1].exclude == ('x.__class__',), "Variable exclude"



# Generated at 2022-06-20 12:47:43.804062
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert BaseVariable.__hash__() == None
    assert hash(BaseVariable) == None
    assert hash(BaseVariable('')) == None
    assert hash(BaseVariable('')) == None
    assert hash(BaseVariable('', '')) == None
    assert hash(BaseVariable('', ('',))) == None
    assert hash(BaseVariable('', ('', ''))) == None

# Generated at 2022-06-20 12:47:52.715081
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # create a frame
    def very_deep(i):
        if i:
            return very_deep(i - 1)
        else:
            return i

    frame = sys._getframe(1)
    # test a very simple variable
    variable = BaseVariable('i')
    assert variable.items(frame) == (
        ("i", '0'),
    )
    # test a variable with a deep value
    variable = BaseVariable('a')

# Generated at 2022-06-20 12:47:58.008471
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def func_test_BaseVariable_items(x):
        z = y
        return x, z

    y = 1
    frame = sys._getframe()
    baseVariable = BaseVariable('z.x', exclude=('x',))
    items = baseVariable.items(frame)

    assert items == (
        ('z.x', '1'),
        ('z.y', '1'),
    )



# Generated at 2022-06-20 12:48:01.589981
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('b')) == hash(BaseVariable('b'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))


# Generated at 2022-06-20 12:48:06.811396
# Unit test for constructor of class Exploding
def test_Exploding():
    class MyClass(object):
        pass
    obj = MyClass()
    obj.a = 'a'
    obj.b = 'b'
    obj.c = 'c'
    print(Exploding('obj').items(obj))
    print(Exploding('obj', ['a', 'c']).items(obj))
    print(Exploding('obj')[1:].items(obj))
    print(Exploding('obj')[1:].items(obj, normalize=True))