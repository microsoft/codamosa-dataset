

# Generated at 2022-06-20 12:38:15.030327
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")
    assert BaseVariable("a") != BaseVariable("b")
    assert BaseVariable("a", exclude="b") != BaseVariable("a")

# test class Attrs

# Generated at 2022-06-20 12:38:23.259031
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Variable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    v = Variable('a')
    assert v == v
    assert v == Variable('a')
    assert v != Variable('b')
    assert v != Variable('a', exclude=('x', ))
    assert v != Variable('a', exclude=('y', ))



# Generated at 2022-06-20 12:38:26.522883
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('name')
    indices_slice = indices[1:5]
    assert indices_slice._fingerprint == (Indices, 'name', ())
    assert indices_slice._slice == slice(1, 5)
    assert indices_slice._slice != slice(None)

# Generated at 2022-06-20 12:38:37.781760
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def monkey_patch_eval(f):
        def fn(*args, **kwargs):
            # Add 'main_value' to frame
            main_value = 2
            frame = args[0]
            frame.f_locals['main_value'] = main_value
            return f(*args, **kwargs)
        return fn

    def test_monkey_patch_eval():
        class MonkeyPatchBaseVariable(BaseVariable):
            def items(self, frame):
                # Monkey-patch eval method to inject 'main_value' variable
                return super(MonkeyPatchBaseVariable, self).items(frame, monkey_patch_eval)

        variable = MonkeyPatchBaseVariable('main_value')
        frame = inspect.currentframe()

        # Check that the main_value variable is resolved

# Generated at 2022-06-20 12:38:40.659421
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    result = Indices('a').__getitem__(slice(1, None, 2))
    assert isinstance(result, Indices)
    assert result._slice == slice(1, None, 2)


# Generated at 2022-06-20 12:38:45.301876
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = range(5)
    attrs = Indices('x')[1:3]
    assert attrs.items({'x': a}) == [('x[1]', '1'), ('x[2]', '2')]

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-20 12:38:49.449534
# Unit test for constructor of class Indices
def test_Indices():
   ivar = Indices('c[3]')
   assert ivar.source == 'c[3]'
   assert ivar.unambiguous_source == 'c[3]'
   assert ivar.exclude == ()
   assert ivar._slice == slice(None)


# Generated at 2022-06-20 12:38:53.775357
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable('source', exclude='exclude')
    assert cv.source == 'source'
    assert cv.exclude == ('exclude',)
    assert cv.code == compile('source', '<variable>', 'eval')
    assert cv.unambiguous_source == '(source)'



# Generated at 2022-06-20 12:39:04.427578
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
	
	import sys
	print("Before")
	print("sys.modules['inspect'] = ",sys.modules['inspect'])
	print("sys.modules['inspect'].getfile(inspect) = ",sys.modules['inspect'].getfile(inspect))
	#
	# 1. Remove the module 'inspect'
	# 2. Insert a fake module 'inspect' and make it to have a fake function getfile
	#
	del sys.modules['inspect']
	from imp import new_module
	fakeinspect = new_module('inspect')
	fakeinspect.getfile = lambda *args, **kwargs: None
	sys.modules['inspect'] = fakeinspect
	print("After")
	#print("sys.modules['inspect'] = ",sys.modules['inspect'])
	

# Generated at 2022-06-20 12:39:11.988243
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .test_utils import test_traceback
    fake_frame = test_traceback().tb_frame
    fake_frame.f_globals = dict(
        spam=1,
        eggs=2,
        abc=dict(
            item1=1,
            item2=2,
            item3=3,
        ),
        defg=(
            10,
            20,
            30,
        ),
        hijk=True,
        lmnop=False,
        qrstuv=('foo', 'bar', 'baz'),
        wxyz='eggs-and-spam',
    )

# Generated at 2022-06-20 12:39:26.477298
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var = BaseVariable("x")
    assert hash(var) == hash((type(var), "x", ()))
    unittest.expectedFailure
    assert hash(var) != hash((type(var), "x", ("a")))
    assert hash(var) != hash((type(var), "y", ()))



# Generated at 2022-06-20 12:39:35.705444
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable1 = Attrs('self')
    variable2 = Attrs('self')
    variable3 = Attrs('self', exclude=['test'])
    variable4 = Attrs('self', exclude=['test1','test2'])
    variable5 = Attrs('self', exclude='test')
    variable6 = Attrs('self', exclude='test1')

    class TestClass(object):
        def __init__(self):
            self.variable1 = '1'
            self.variable2 = '2'

    def test_func():
        t = TestClass()
        var = t.variable1

    test_frame = sys._getframe()

    assert variable1.items(test_frame) == variable2.items(test_frame)
    assert variable1.items(test_frame) != variable3.items(test_frame)


# Generated at 2022-06-20 12:39:46.245400
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import builtins
    from .importator import Importator
    from .utils import get_shortish_repr

    frame = inspect.currentframe()
    builtins_frame = frame.f_back.f_back
    variable_source = 'test_data'
    variable_exclude = ['test_data1']
    variable_code = compile(variable_source, '<string>', 'eval')
    try:
        variable_value = eval(variable_code, builtins_frame.f_globals or {}, builtins_frame.f_locals)
        print (variable_value)
    except Exception:
        print ('BaseVariable.items: failed to fetch main value')

    basevariable = BaseVariable(variable_source, variable_exclude)

# Generated at 2022-06-20 12:39:55.354291
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a[b]') is False
    assert needs_parentheses('a()') is False
    assert needs_parentheses('a()[b]') is False
    assert needs_parentheses('a()().b') is False
    assert needs_parentheses('a()[b]()') is False

    assert needs_parentheses('a or b') is True
    assert needs_parentheses('a and b') is True

    assert needs_parentheses('a or b.c') is True
    assert needs_parentheses('a or b[c]') is True
    assert needs_parentheses('a().b') is True

# Generated at 2022-06-20 12:40:07.265594
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = sys._getframe()
    # test for class Attrs
    a = Attrs("a", ("a.py","a.y"))
    assert a.items(frame) ==\
           [("a", "Attrs('test_BaseVariable_items.py', ('test', 'a'))")]
    assert a.items(frame, normalize=True) == \
           [("a", "Attrs('test_BaseVariable_items.py', ('test', 'a'))")]
    # test for class Keys
    b = Keys("b", ("b.py","b.y"))
    assert b.items(frame) == \
           [("b", "Keys('test_BaseVariable_items.py', ('test', 'a'))")]

# Generated at 2022-06-20 12:40:10.024841
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') == BaseVariable('foo')
    assert BaseVariable('foo') != BaseVariable('bar')
    assert BaseVariable('foo') != BaseVariable('foo', 'x')
    assert BaseVariable('foo') != object()

# Generated at 2022-06-20 12:40:11.588851
# Unit test for constructor of class Attrs
def test_Attrs():
    my_var = Attrs("five")
    assert my_var.source == "five"
    assert my_var.exclude == ()


# Generated at 2022-06-20 12:40:21.755695
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('x.attribute') is False
    assert needs_parentheses('x.attribute.method()') is False
    assert needs_parentheses('x.attribute.method()') is False
    assert needs_parentheses('x.attribute[key]') is False

    assert needs_parentheses('x * y') is True
    assert needs_parentheses('x.attribute * x.attribute') is True
    assert needs_parentheses('(x.attribute.method()).attribute') is True
    assert needs_parentheses('x.attribute.method().(key)') is True
    assert needs_parentheses('x[y] * x[z]') is True

# Generated at 2022-06-20 12:40:27.860599
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('(a)') == False
    assert needs_parentheses('a.b') == True
    assert needs_parentheses('(a).b') == False
    assert needs_parentheses('a.b.c') == True
    assert needs_parentheses('(a.b).c') == False
    assert needs_parentheses('(a).b.c') == False

# Generated at 2022-06-20 12:40:36.676523
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert utils.get_shortish_repr([1, 2, 3]) == '[1, 2, 3]'
    assert utils.get_shortish_repr({'a': 'b', 'c': 'd'}) == "{'a': 'b', 'c': 'd'}"
    class a(object):
        def __init__(self):
            self.a = 'b'
            self.c = 'd'
    assert utils.get_shortish_repr(a()) == '{a: b, c: d}'

# Generated at 2022-06-20 12:40:54.110146
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import getouterframes, currentframe
    from pprint import pprint

    def _get_frame_locals(stack_level):
        frame = getouterframes(currentframe())[stack_level + 2][0]
        return frame.f_locals

    def pprint_items(variable, frame_locals):
        pprint(variable.items(frame_locals, normalize=True))

    # test class Keys
    x = {}
    x['a'] = 'A'
    x['b'] = ['B', 'BB']
    x['c'] = (1, 2, 3)
    x['d'] = set('def')
    x['e'] = {'eg'}
    x['f'] = {}
    x['g'] = ()

# Generated at 2022-06-20 12:40:57.412192
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'len'
    exclude = 1
    var = CommonVariable(source, exclude)
    assert source == var.source, "source should be equal"
    assert exclude == var.exclude, "exclude should be equal"


# Generated at 2022-06-20 12:41:04.656662
# Unit test for constructor of class Indices
def test_Indices():
    import pytest
    Indices_instance = Indices('')
    # Get full range of the indices
    with pytest.raises(AssertionError):
        Indices_instance[1:3]
    # Get range with negative indices
    with pytest.raises(AssertionError):
        Indices_instance[-1:1]
    # Get singular index
    with pytest.raises(AssertionError):
        Indices_instance[1]
    # Negative index skip steps
    with pytest.raises(AssertionError):
        Indices_instance[-1:-2:-2]
    # Negative index start and end step
    with pytest.raises(AssertionError):
        Indices_instance[-1:2:-2]

# Generated at 2022-06-20 12:41:08.534988
# Unit test for constructor of class Exploding
def test_Exploding():
    variable = Exploding('var')
    assert variable.source == 'var'
    assert variable.exclude == ()
    assert variable.code
    assert variable.unambiguous_source == 'var'

# Generated at 2022-06-20 12:41:10.746497
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x', exclude='y')) == hash(BaseVariable('x', exclude='y'))


# Generated at 2022-06-20 12:41:12.922828
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    str_source='test'
    exclude=('a',1,'2')
    with pytest.raises(TypeError):
        BaseVariable('test')



# Generated at 2022-06-20 12:41:19.641453
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def _test(klass, src, exc, exp_value):
        var = klass(src, exc)
        value = {}
        for k, v in var.items({'var': value}):
            if k == src:
                value = v
            else:
                print(k, v)
        assert value == exp_value
        value = []
        for k, v in var.items({'var': value}):
            if k == src:
                value = v
            else:
                print(k, v)
        assert value == exp_value
        value = ([1, 2], {'a': 3, 'b': 4})
        for k, v in var.items({'var': value}):
            if k == src:
                value = v
            else:
                print(k, v)

# Generated at 2022-06-20 12:41:22.720685
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()
    main_value = frame.f_locals
    print(BaseVariable.items(BaseVariable, frame, main_value, False))

# Generated at 2022-06-20 12:41:26.487557
# Unit test for constructor of class Indices
def test_Indices():
    import random
    import string
    for _ in range(100):
        L = int(random.uniform(1, 100))
        keys = list(string.ascii_lowercase[:L])
        value = list(keys)
        random.shuffle(value)
        v = dict(zip(keys, value))
        i = Indices("", ())
        l = list(i._items(v))
        assert l == [("[%d]" % (j), '%s' % (v[k])) for j, k in enumerate(keys)]


# Generated at 2022-06-20 12:41:28.621040
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('some_var')
    assert needs_parentheses('some_var.x')
    assert needs_parentheses('some_var or other_var')

# Generated at 2022-06-20 12:41:47.103311
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import variables
    from . import pycompat
    source = '__name__'
    exclude = ()
    code = pycompat.compile(source, '<variable>', 'eval')
    # if needs_parentheses(source):
    #     unambiguous_source = '({})'.format(source)
    # else:
    #     unambiguous_source = source
    assert CommonVariable(source, exclude).unambiguous_source == '__name__'
    assert CommonVariable('__name__', exclude).code == code
    assert CommonVariable(source, exclude).exclude == exclude
    assert CommonVariable(source, exclude)._fingerprint == (variables.CommonVariable, source, exclude)
    assert hash(CommonVariable(source, exclude)) == hash((variables.CommonVariable, source, exclude))

# Generated at 2022-06-20 12:41:54.630113
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from sys import modules

    """
    >>> d = {} # hash dict
    >>> a = BaseVariable('a')
    >>> a.__hash__() in d
    True
    >>> d[a.__hash__()] = 1
    >>> b = BaseVariable('a')
    >>> c = BaseVariable('a')
    >>> a == b
    True
    >>> a == c
    True
    >>> a == 'a'
    False
    >>> b.__hash__() in d
    True
    >>> c.__hash__() in d
    True
    """


# Generated at 2022-06-20 12:41:59.753754
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('(a') is True
    assert needs_parentheses('a)') is True
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('(a).b') is False
    assert needs_parentheses('a()') is False
    assert needs_parentheses('a().b') is False
    assert needs_parentheses('a()[0]') is False
    assert needs_parentheses('a[0]') is False
    assert needs_parentheses('(a[0])[1]') is False
    assert needs_parentheses('f(a)') is True
    assert needs_parentheses('f(a).b') is False

# Generated at 2022-06-20 12:42:02.728185
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys("a")
    assert a.source == 'a'
    assert a.exclude == ()


# Generated at 2022-06-20 12:42:06.536802
# Unit test for constructor of class Attrs
def test_Attrs():
    import inspect
    # Test needs to be run from parent directory
    frame = inspect.currentframe()
    attr = Attrs('frame').items(frame)
    assert(attr[0][0] == 'frame')



# Generated at 2022-06-20 12:42:07.449990
# Unit test for constructor of class Indices
def test_Indices():
    temp = Indices.__init__()
    print(temp)


# Generated at 2022-06-20 12:42:10.142437
# Unit test for constructor of class Attrs
def test_Attrs():
    start = Attrs(source='self', exclude=["test"])
    assert start.source == "self"
    assert start.exclude == ["test"]
    assert start.code.co_name == "self"
    assert start.unambiguous_source == "self"

# Generated at 2022-06-20 12:42:12.356640
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    assert hash(a) == hash(b)



# Generated at 2022-06-20 12:42:18.320903
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # The constructor should take two arguments
    try:
        CommonVariable()
    except TypeError as e:
        assert str(e) == "__init__() missing 2 required positional arguments: 'source' and 'exclude'"
    else:
        assert False
    # Should also take one positional argument
    try:
        CommonVariable('a')
    except TypeError as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'exclude'"
    else:
        assert False
    # Should take two positional arguments
    try:
        CommonVariable('a', 'b')
    except TypeError as e:
        assert False


# Generated at 2022-06-20 12:42:27.989451
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('x')
    assert x.source == 'x'
    assert x.exclude == ()
    assert x.code == compile('x', '<variable>', 'eval')
    assert x.unambiguous_source == 'x'
    #print(type(x.items))
    #print(type(x._items))
    #print(type(x.__init__))
    #print(type(x._safe_keys))
    #print(type(x._keys))
    #print(type(x._format_key))
    #print(type(x._get_value))
    #print(type(x._fingerprint))
    #print(type(x.__hash__))
    #print(type(x.__eq__))


# Generated at 2022-06-20 12:42:42.695524
# Unit test for constructor of class Keys
def test_Keys():
    import sys
    test_var = Keys('sys')
    assert test_var.source == 'sys'
    assert isinstance(test_var.exclude, tuple)
    assert isinstance(test_var.code, type(sys.version_info))
    assert test_var.unambiguous_source == 'sys'

# Generated at 2022-06-20 12:42:49.884402
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x*.y')
    assert needs_parentheses('x.y.z')
    assert not needs_parentheses('x[y]')
    assert not needs_parentheses('x[y].z')
    assert not needs_parentheses('x[y].z[t]')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x).y.z')
    assert not needs_parentheses('(x[y]).z')
    assert not needs_parentheses('(x).y[z]')
    assert not needs_parentheses('(x[y]).z[t]')

# Generated at 2022-06-20 12:42:56.216195
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = {}
    x['test'] = 1
    variable = CommonVariable('x', exclude=['test'])
    items = variable.items(frame=None)
    assert len(items) == 1
    assert items[0][1] == '{}'

    variable = CommonVariable('x', exclude='test')
    items = variable.items(frame=None)
    assert len(items) == 1
    assert items[0][1] == '{}'


# Generated at 2022-06-20 12:43:06.598480
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a', exclude=1)) == hash(BaseVariable('a', exclude=1))
    assert hash(BaseVariable('a', exclude=1)) == hash(BaseVariable('a', exclude=1.0))
    assert hash(BaseVariable('a', exclude=1.0)) == hash(BaseVariable('a', exclude=1.0))
    assert hash(BaseVariable('a', exclude=1)) != hash(BaseVariable('a', exclude=2))
    assert hash(BaseVariable('a', exclude=1)) != hash(BaseVariable('a'))
    assert hash(BaseVariable('a', exclude=1)) != hash(BaseVariable('b', exclude=1))
    assert hash(BaseVariable('a', exclude=1)) != hash(Keys('a', exclude=1))
    assert hash(BaseVariable('a', exclude=1)) != hash

# Generated at 2022-06-20 12:43:16.884024
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_frame():
        t = [0, 1]
        def called():
            raise RuntimeError

        return sys._getframe(4)

    frame = test_frame()
    locals = frame.f_locals
    globals = frame.f_globals

    # test for class Attrs
    test_attrs = Attrs('t')
    items = test_attrs.items(frame)

# Generated at 2022-06-20 12:43:17.858922
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    print(CommonVariable('a').items({'a': None}))

# Generated at 2022-06-20 12:43:23.180547
# Unit test for constructor of class Indices
def test_Indices():
    # Arrange
    source = "source"
    exclude = ["exclude"]
    indices = Indices(source, exclude)

    # Act
    # Nothing to do

    # Assert
    assert indices.source == source
    assert indices.exclude == exclude
    assert indices.code == compile(source, '<variable>', 'eval')
    assert indices.unambiguous_source == source


# Generated at 2022-06-20 12:43:28.941804
# Unit test for constructor of class Exploding
def test_Exploding():

    var_mapping_ex = Exploding('var_mapping', exclude='x')
    var_mapping_ex_list = [('var_mapping.y', 'excited'), ('var_mapping[z]', 'z')]
    assert var_mapping_ex.items(excited=1) == var_mapping_ex_list, "Constructor of class Exploding is wrong"


# Generated at 2022-06-20 12:43:34.391383
# Unit test for constructor of class Attrs
def test_Attrs():
    source = 'a.b'
    exclude = ()
    v = Attrs(source, exclude)
    assert v.source == source
    assert v.exclude == exclude
    assert v.code.co_code == compile(source, '<variable>', 'eval').co_code
    assert v.unambiguous_source == source 
    assert v.__class__.__name__ == 'Attrs'


# Generated at 2022-06-20 12:43:41.780331
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import random
    import copy
    import types
    import string
    
    # Generate random string from string module
    test_string=[]
    for i in range(100):
        test_string.append(''.join(random.choice(string.ascii_lowercase) for j in range(10)))

    # Unit test for method items of class Keys
    for i in range(100):
        # Create a random dict and copy to another dict    
        dict_1=dict(zip(test_string,random.sample(range(1000),len(test_string))))
        dict_2=copy.deepcopy(dict_1)
        # Create a random key and value
        rand_key=random.choice(test_string)
        rand_value=random.randint(0,2000)
        # Add the new key

# Generated at 2022-06-20 12:44:06.864273
# Unit test for constructor of class Indices
def test_Indices():
    
    def _(self, source, exclude=()):
        self.source = source
        self.exclude = utils.ensure_tuple(exclude)
        self.code = compile(source, '<variable>', 'eval')
        if needs_parentheses(source):
            self.unambiguous_source = '({})'.format(source)
        else:
            self.unambiguous_source = source

    def __hash__(self):
        return hash((type(self), self.source, self.exclude))

    def __eq__(self, other):
        return (isinstance(other, BaseVariable) and
                                       self._fingerprint == other._fingerprint)

    __init__ = _


# Generated at 2022-06-20 12:44:18.782451
# Unit test for constructor of class Attrs
def test_Attrs():
    # test __init__ of class Attrs
    # test that needs_parentheses returns true for a complex expression
    source = '__builtins__'
    assert needs_parentheses(source)
    # test that if the source doesn't need parentheses then the unambiguous_source is just the source
    assert source == Attrs(source).unambiguous_source
    # test that if the source needs parentheses then the unambiguous_source is the source between parentheses
    source = '5 + 3 / 2'
    assert Attrs(source).unambiguous_source == '({})'.format(source)
    # test that the unambiguous_source is only used for the Attrs class
    source = '5 + 3 / 2'
    assert Keys(source).unambiguous_source == source
    assert Indices(source).unambiguous_source == source
    assert Exploding

# Generated at 2022-06-20 12:44:23.043956
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert needs_parentheses('x[1]') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x[1].y') == True
    assert needs_parentheses('x[1][2]') == True
    assert needs_parentheses('x.y[1]') == True

test_BaseVariable()

# Generated at 2022-06-20 12:44:24.768161
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # assert getattr(BaseVariable, '__hash__', None) is None
    BaseVariable('a', 'b').__hash__()


# Generated at 2022-06-20 12:44:26.706041
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('a')
    globals = {"a": 3}
    locals = {}
    frame = utils.Frame(globals, locals)
    c.items(frame)

# Generated at 2022-06-20 12:44:36.966267
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == True
    assert needs_parentheses('(x)') == False
    assert needs_parentheses('_x') == False
    assert needs_parentheses('x[1]') == False
    assert needs_parentheses('x.y[1]') == True
    assert needs_parentheses('(x.y)[1]') == False
    assert needs_parentheses('(x or y)[1]') == False
    assert needs_parentheses('x.y.z[1]') == True
    assert needs_parentheses('x.y.z[0]') == True
    assert needs_parentheses('x.y[0].z') == True
    assert needs_parentheses('x.y.z') == True
    assert needs_parentheses

# Generated at 2022-06-20 12:44:38.941628
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()


# Generated at 2022-06-20 12:44:44.584791
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('test')
    print(a.source)
    print(a.exclude)
    print(a.unambiguous_source)
    # print(a.code)
    print(a._safe_keys)
    print(a._keys)
    print(a._format_key)
    print(a._get_value)
    print('\n')
    print(a.__hash__)
    print(a.__eq__)



# Generated at 2022-06-20 12:44:52.853543
# Unit test for function needs_parentheses
def test_needs_parentheses():
    x = 1
    assert needs_parentheses('x'), 'x should have parentheses'
    assert needs_parentheses('x.y'), 'x.y should have parentheses'
    assert not needs_parentheses('(x.y)'), 'explicit parentheses should be redundant'

    def _get_var_name(x):
        return x.__code__.co_names[0]

    assert not needs_parentheses('_get_var_name(x)'), 'function call wrapping does not need parentheses'
    assert not needs_parentheses('_get_var_name(_get_var_name(x))'), 'function call wrapping does not need parentheses'
    assert _get_var_name(_get_var_name(x)) == _get_var_name(x), 'function call wrapping sanity check'

# Generated at 2022-06-20 12:44:57.589182
# Unit test for constructor of class Keys
def test_Keys():

    key1 = Keys("key1", exclude=("exclude1",))
    assert key1.source == "key1"
    assert key1.exclude == ("exclude1",)

    key2 = Keys("key2")
    assert key2.source == "key2"
    assert key2.exclude == ()

# Generated at 2022-06-20 12:45:34.799283
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    b = BaseVariable(123)
    print(b.source)
    print(b.exclude)
    print(b.code)
    print(b.unambiguous_source)

# Generated at 2022-06-20 12:45:37.195945
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  item = slice(1,4,2)
  expected_result = slice(item.start,item.stop,item.step)
  var = Indices("var1")
  obj = var[item]
  assert obj._slice == expected_result

# Generated at 2022-06-20 12:45:41.362608
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('a.b().c')
    assert needs_parentheses('a.b.c()')
    assert not needs_parentheses('a().b.c')

# Generated at 2022-06-20 12:45:47.920437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Attrs('self.A')
    v2 = Attrs('v1.A')
    v3 = Attrs('self.A', ['A'])
    v4 = Attrs('self.A', ['B'])
    v5 = Attrs('self.A', ['A'])

    assert v1 == v1
    assert v1 != None
    assert v1 != v2
    assert v1 == v3
    assert v3 == v5
    assert v3 != v4

# Generated at 2022-06-20 12:45:55.989138
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable("eval_code", ("exclude_1", "exclude_2"))

    assert var.source == "eval_code"
    assert var.exclude == ("exclude_1", "exclude_2")
    assert var.code == compile("eval_code", '<variable>', 'eval')

    assert var.unambiguous_source == "(eval_code)"

    assert var.items("frame") == ()
    assert var._items("main_value") == NotImplementedError

    assert var._fingerprint == (BaseVariable, "eval_code", ("exclude_1", "exclude_2"))
    assert (hash(var) == hash(var._fingerprint))
    assert (var == BaseVariable("eval_code", ("exclude_1", "exclude_2"))) == True


# Generated at 2022-06-20 12:46:02.522356
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    def main():
        a = BaseVariable('a.b.c', 'b.a')
        a = BaseVariable('a.b.c', 'b.a')
        b = BaseVariable('a.b.c', 'b.a')
        assert a == b
        assert a is not b
        assert tuple(a._items('b.c', False)) == ()
        assert tuple(b._items('b.c', False)) == ()
    if __name__ == '__main__':
        main()

# Generated at 2022-06-20 12:46:06.243891
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('1')
    v2 = BaseVariable('1')
    v3 = BaseVariable('2')
    assert v1.__hash__() == v2.__hash__()
    assert v2.__hash__() != v3.__hash__()


# Generated at 2022-06-20 12:46:13.202570
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # create a frame
    def f():
        a = 1
        return 1
    frame = sys._getframe()
    frame = frame.f_back

    # create a class
    class TestClass(object):
        a = 2
        b = 'hello'
        def __init__(self):
            self.c = 3
            self.d = 'world'

    # create a list
    testlist = [1, 2, 3]

    # create a dict
    testdict = {'a': 1, 'b': 2, 'c': 3}

    # create a BaseVariable instance
    testa = BaseVariable('a')
    testb = BaseVariable('b')
    testc = BaseVariable('c')
    testd = BaseVariable('d')
    teste = BaseVariable('e')

# Generated at 2022-06-20 12:46:21.583332
# Unit test for constructor of class Keys
def test_Keys():

    # Creates a new instance of class Keys
    test1 = Keys("test", "test")
    print("test1 = ", test1)

    # Creates a new instance of class Keys with some arguments
    test2 = Keys("tester", ('name', ))
    print("test2 = ", test2)

    # Creates a new instance of class Keys with some arguments
    test3 = Keys("test", "test")
    print("test3 = ", test3)

    # Asserts whether the values are equal
    assert test1 == test2 and test2 != test3


# Generated at 2022-06-20 12:46:28.520723
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('1')
    assert not needs_parentheses('(1)')
    assert not needs_parentheses('[1]')
    assert not needs_parentheses('{1}')
    assert needs_parentheses('[1].x')
    assert not needs_parentheses('(1).x')
    assert needs_parentheses('1 + 1')
    assert not needs_parentheses('(1 + 1)')
    assert not needs_parentheses('(1 + 1).x')

# Generated at 2022-06-20 12:47:49.887703
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def BaseVariable_items(int_num, str_key):
        # create a variable
        variable = BaseVariable(int_num, str_key)
        # get the items of variable
        frame = frame_items(variable)
        return variable.items(frame)

    assert BaseVariable_items(10, 'x') == [(10, 10)]
    assert BaseVariable_items(10.5, 'x') == [(10.5, 10.5)]
    assert BaseVariable_items('x', 'x') == [('x', 'x')]
    assert BaseVariable_items(True, 'x') == [(True, True)]



# Generated at 2022-06-20 12:47:59.074783
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Setup
    v1 = BaseVariable('v1', ('a',))
    v2 = BaseVariable('v2')
    v3 = BaseVariable('v3')
    v4 = BaseVariable('v4')
    v5 = BaseVariable('v5', ('a',))

    frame = {'v1': {'a': 2, 'b': 3}, 'v2': [1, 2, 3], 'v3': (1, 2, 3), 'v4': {'a': 2, 'b': 3}, 'v5': (1, 2, 3)}

    # Exercise
    expected_v1 = [('v1', '{a: 2, b: 3}'),
                   ('v1.a', '2'),
                   ('v1.b', '3')]


# Generated at 2022-06-20 12:48:01.513687
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    IndicesRepr = repr(Indices)
    assert '<Indices' == IndicesRepr[:8]
    assert '>' == IndicesRepr[-1]

# Generated at 2022-06-20 12:48:06.516718
# Unit test for constructor of class Attrs
def test_Attrs():
    frame = sys._getframe(1)
    keys = Attrs("keys")._keys(frame)
    assert next(keys) == "keys"
    assert next(keys) == "f_locals"
    assert next(keys) == "f_globals"
    #assert next(keys) == "f_trace" # This one doesn't have a __dict__
    assert next(keys) == "f_back"
