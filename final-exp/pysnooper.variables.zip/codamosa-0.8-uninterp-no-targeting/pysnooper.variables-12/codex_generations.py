

# Generated at 2022-06-20 12:38:29.400301
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def call_items(basevariable, frame, normalize=False):
        return list(basevariable.items(frame, normalize=normalize))
    frame = sys._getframe()
    assert call_items(Attrs('__file__'), frame) == [('__file__', '<snip>/__init__.py')]
    assert call_items(Attrs('some_object.some_variable'), frame) == [('some_object.some_variable', '1')]
    assert call_items(Keys('some_dict'), frame) == [('some_dict[0]', '1'), ('some_dict[1]', '2'), ('some_dict[2]', '3')]

# Generated at 2022-06-20 12:38:39.274466
# Unit test for constructor of class CommonVariable

# Generated at 2022-06-20 12:38:49.600175
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def assert_equal_given(self, other):
        assert self == other
        assert not other != self
        assert hash(self) == hash(other)

    def assert_different_given(self, other):
        assert not self == other
        assert other != self
        assert hash(self) != hash(other)

    attrs = Attrs('foo')
    assert_equal_given(attrs, Attrs('foo'))
    assert_different_given(attrs, Attrs('foo', 'o'))
    assert_different_given(attrs, Attrs('foo', exclude=('d', 'o')))
    assert_different_given(attrs, Attrs('bar'))
    assert_different_given(attrs, Attrs('foo.bar'))
    assert_different_given(attrs, Keys('foo'))

# Generated at 2022-06-20 12:38:52.865676
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('b', 'a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')

# Generated at 2022-06-20 12:38:57.175449
# Unit test for constructor of class Keys
def test_Keys():
    x = {}
    x['foo'] = 'bar'
    x[(1,2)] = [3,4]
    keys = Keys('x')
    assert keys._items(x) == [('x', {}), ('x[foo]', 'bar'), ("x[(1, 2)]", '[3, 4]')]

# Generated at 2022-06-20 12:39:00.275337
# Unit test for constructor of class Indices
def test_Indices():
    obj = Indices(source="a", exclude=('b'))
    assert obj._slice == slice(None)
    assert obj.source == "a"
    assert obj.exclude == ('b',)


# Generated at 2022-06-20 12:39:03.659602
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert Attrs('some_variable', exclude='foo').exclude == ('foo',)
    assert Attrs('some_variable', exclude=('foo', )).exclude == ('foo',)


# Generated at 2022-06-20 12:39:11.473536
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def __init__(self, a, b, c):
            super(A, self).__init__(a)
            self.code = 'xx'
            self.exclude = b
            self.unambiguous_source = c
            self.source = a
            self.a = a
            self.b = b
            self.c = c

        @abc.abstractmethod
        def _items(self, key, normalize=False):
            pass

        @property
        def _fingerprint(self):
            return (type(self), self.source, self.exclude)

    def isinstance_a(x):
        return isinstance(x, A)

    assert(isinstance_a(A('a', 'b', 'c')))

# Generated at 2022-06-20 12:39:22.088684
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A:
        def __init__(self):
            self.x = 'x'
            self.y = 'y'
        def u(self):
            return self.z

    a = A()
    b = A()
    a.u = a.u
    a.z = a
    b.u = a.u
    b.z = b
    a.u.v = 'v'
    a.u.w = a

    x = Attrs('a')
    y = Keys('a')
    z = Indices('a')
    k = Exploding('a')
    l = Exploding('b', exclude=('x',))
    g = Exploding('a.u', exclude=('z',))

    # print(x.items(locals()))
    # print(y.items(locals

# Generated at 2022-06-20 12:39:29.307883
# Unit test for function needs_parentheses
def test_needs_parentheses():
    class C(object):
        def x(self):
            pass
    def x():
        pass
    x.x = x
    c = C()
    assert needs_parentheses('x')
    assert needs_parentheses('x.x')
    assert needs_parentheses('x.x.x')
    assert needs_parentheses('.x')
    assert needs_parentheses('x.x.x.x')
    assert not needs_parentheses('c.x')
    assert needs_parentheses('x().x.x')
    assert not needs_parentheses('x.x(x).x')

# Generated at 2022-06-20 12:39:51.164054
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # init frame and frame obj
    frame = utils.create_frame_on_current(
        'test_BaseVariable_items',
        'test_BaseVariable_items_frame.py',
        2)
    frame_obj = utils.Frame(frame)

    # test Attrs, Keys and Indices
    attrs = Attrs('main_value', exclude=('__element_len__',))
    keys = Keys('main_value')
    indices = Indices('main_value')

    assert list(attrs.items(frame)) == list(attrs.items(frame_obj)) == list(attrs.items(frame_obj))[:1] + list(attrs.items(frame_obj))[2:-2]+ list(attrs.items(frame_obj))[-1:] 


# Generated at 2022-06-20 12:39:53.551668
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys, types
    frame=sys._getframe()
    source='frame.f_locals'
    obj=BaseVariable(source, [])
    result=obj.items(frame)
    assert result


# Generated at 2022-06-20 12:39:59.402854
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable('a')
    assert bv1 == bv1
    bv2 = BaseVariable('a')
    assert bv1 == bv2
    assert bv2 == bv1
    bv3 = BaseVariable('b')
    assert bv1 != bv3
    assert bv3 != bv1
    bv4 = BaseVariable('b', 'a')
    assert bv1 != bv4
    assert bv4 != bv1
    bv5 = BaseVariable('b', 'b')
    assert bv4 != bv5
    assert bv5 != bv4
    bv6 = BaseVariable('a', ('b',))
    assert bv1 != bv6
    assert bv6 != bv1
    assert bv6 != bv4
    assert b

# Generated at 2022-06-20 12:40:09.725285
# Unit test for constructor of class Attrs
def test_Attrs():
    a1 = Attrs('a')
    assert a1.source == 'a'
    assert a1.exclude == ()
    a2 = Attrs('a', exclude=['b', 'c'])
    assert a2.source == 'a'
    assert a2.exclude == ('b', 'c')
    a3 = Attrs('a', exclude='b')
    assert a3.source == 'a'
    assert a3.exclude == ('b',)
    a4 = Attrs('a', 'b', 'c')
    assert a4.source == 'a'
    assert a4.exclude == ('b', 'c')
    assert a1 != a2
    assert a2 != a3
    assert a1 != a3
    assert a3 != a4
    

# Generated at 2022-06-20 12:40:13.801263
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a[1]')
    assert needs_parentheses('a.b + 1')
    assert needs_parentheses('(a.b) + 1')
    assert needs_parentheses('a.b + 1.c')
    assert needs_parentheses('(a.b + 1).c')

# Generated at 2022-06-20 12:40:27.358563
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A:
        def __init__(self, a):
            self.a = a
        def __repr__(self):
            return 'A'
    class B:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __repr__(self):
            return 'B'
    class C:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
        def __repr__(self):
            return 'C'
    class D:
        def __init__(self, a, b, c, d):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

# Generated at 2022-06-20 12:40:35.872660
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from hypothesis import given, assume, assume, settings
    from hypothesis.strategies import integers
    from hypothesis.stateful import RuleBasedStateMachine, Bundle, rule
    import hashlib
    import six

    # Variable used to store the test results for each BaseVariable object
    # Invariant: for every i, BaseVariable_hash_values[i] == hash(BaseVariable_objects[i])
    BaseVariable_hash_values = []

    # Variable used to store all BaseVariable objects created in the test
    # Invariant: len(BaseVariable_objects) == len(BaseVariable_hash_values)
    BaseVariable_objects = []

    # RuleBasedStateMachine used to model the testing algorithm
    class BaseVariable_hash_machine(RuleBasedStateMachine):
        def __init__(self):
            super(BaseVariable_hash_machine, self).__

# Generated at 2022-06-20 12:40:38.172613
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('foo'), Attrs)
    assert isinstance(Exploding('foo', exclude='bar'), Attrs)
    assert isinstance(Exploding('foo', exclude=('bar',)), Attrs)

# Generated at 2022-06-20 12:40:40.416832
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    """test __getitem__ method of class Indices"""

    myvar = Indices('a')
    mynewvar = myvar[1:3]

    assert(mynewvar._slice == slice(1, 3, None))

# Generated at 2022-06-20 12:40:42.292455
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    d = {}
    d[Keys('a')] = 1
    assert d.get(Keys('a'), None) == 1


# Generated at 2022-06-20 12:40:55.201035
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('test')

# Generated at 2022-06-20 12:40:56.154422
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a.b).c')

# Generated at 2022-06-20 12:41:02.493305
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from hypothesis import given
    from hypothesis.strategies import text, integers
    from .strategies import variables

    @given(variables(), text(), integers(min_value=0, max_value=1))
    def test_hypothesis(variable, txt, count):
        exclude = []
        for k in range(count):
            exclude.append(txt)
        exclude = tuple(exclude)
        bv = BaseVariable(variable, exclude=exclude)
        assert bv.__hash__() == hash(type(bv), variable, tuple(txt for k in range(count)))
    test_hypothesis()

# Generated at 2022-06-20 12:41:06.772890
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys("myvar")
    print("Variable object: ", keys)
    print("Code object: ", keys.code)
    print("Unambiguous source: ", keys.unambiguous_source)


# Generated at 2022-06-20 12:41:08.832396
# Unit test for constructor of class Attrs
def test_Attrs():
    with pytest.raises(TypeError):
        Attrs()  # missing required argument: 'source'



# Generated at 2022-06-20 12:41:17.046645
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('foo')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('(foo).bar')
    assert not needs_parentheses('foo.bar.baz')
    assert not needs_parentheses('(foo.bar).baz')
    assert needs_parentheses('(foo).bar.baz')
    assert needs_parentheses('foo.bar.baz.qux')
    assert needs_parentheses('(foo.bar.baz).qux')
    assert needs_parentheses('foo.bar.baz.qux.quux')
    assert needs_parentheses('(foo.bar.baz.qux).quux')
    assert needs_parentheses('(foo).bar.baz.qux.quux')

# Generated at 2022-06-20 12:41:27.854827
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable(1)
    b = BaseVariable(2)
    c = BaseVariable(1)
    d = BaseVariable(1)
    e = BaseVariable(1)
    f = BaseVariable(2)
    assert hash(a) == hash(c)
    assert hash(b) == hash(f)
    assert hash(a) != hash(b)
    assert hash(a) != hash(d)
    assert hash(a) != hash(e)
    assert hash(b) != hash(d)
    assert hash(b) != hash(e)
    assert hash(d) != hash(e)
    assert hash(a) == hash(a)
    assert hash(b) == hash(b)
    assert hash(c) == hash(c)
    assert hash(d) == hash(d)
   

# Generated at 2022-06-20 12:41:30.286189
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable = CommonVariable('test', 'exclude')
    assert variable.__init__('test', 'exclude')
    assert variable.__init__('test')
    assert variable.__init__('test', ('a', 'b'))



# Generated at 2022-06-20 12:41:35.338225
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    Here we do some monkey patch to fake a frame object directly
    since we use frame.f_globals and frame.f_locals for newly created
    variables, which are used by the eval function
    '''
    frame_mock = Mock()
    frame_mock.f_globals = {}
    frame_mock.f_locals = {}

    # For class CommonVariable
    # Class CommonVariable is an abstract class,
    # it must be inherit before being used
    class CommonVariable_mock(CommonVariable):
        def _keys(self, main_value):
            return ()
        def _format_key(self, key):
            return ""
        def _get_value(self, main_value, key):
            return ""

    cvm = CommonVariable_mock("abc")
    cvm

# Generated at 2022-06-20 12:41:37.310056
# Unit test for constructor of class Exploding
def test_Exploding():
    locals()[Exploding] = None
    assert Exploding(source='foo', exclude=('a',)).source == 'foo'
    assert Exploding(source='foo', exclude=('a',)).exclude == ('a',)


# Generated at 2022-06-20 12:42:11.646980
# Unit test for constructor of class Attrs
def test_Attrs():
    try:
        import numpy as np
    except ImportError:
        pass

    a = Attrs("a")
    b = Attrs("b")
    c = Attrs("c", exclude="__class__")

    assert a._fingerprint == (Attrs, "a", ())
    assert b._fingerprint == (Attrs, "b", ())
    assert c._fingerprint == (Attrs, "c", ("__class__",))

    for i in range(4):
        for j in range(4):
            assert (i == j) == (a == b)

    for i in range(4):
        for j in range(4):
            assert (i == j) == (a == c)

    # a.code == compile("a", '<variable>', 'eval')

# Generated at 2022-06-20 12:42:12.473528
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('a') == Indices('a')

# Generated at 2022-06-20 12:42:19.623687
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('"x"') is False
    assert needs_parentheses('"x".y') is False
    assert needs_parentheses('"x".y.z') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x.y.z') is False
    assert needs_parentheses('x[0]') is False
    assert needs_parentheses('x[0].y') is False
    assert needs_parentheses('x[0].y.z') is False

    assert needs_parentheses('x.y.z.x[0].y') is True
    assert needs_parentheses('x[0].y.z.x[0].y') is True

# Generated at 2022-06-20 12:42:22.499432
# Unit test for constructor of class Exploding
def test_Exploding():
    exploding = Exploding('x')
    assert exploding.source == 'x'
    assert exploding.code.co_name == '<module>'
    assert exploding.items(frame()) == []


# Generated at 2022-06-20 12:42:27.012172
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import test_utils
    import inspect
    import re
    case_insensitive_re = lambda x: re.compile(x, re.IGNORECASE)
    class A(object):
        a_str = "example string"
        a_num = "example number"
        a_list = [2, 3]
        a_dict = {"1": 1}

    def test_function(a):
        test_variable = BaseVariable
        test_variable.items(inspect.currentframe(), a)

    test_utils.check_function_in_traceback_re(test_function, A(), ['<variable>'],
                                              case_insensitive_re, test_function.__name__)


# Generated at 2022-06-20 12:42:34.703058
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame_glo_vars = {'x': 'global', 'y': 'global'}
    frame_loc_vars = {'x': 'local', 'z': 'local'}

    variable = BaseVariable('x')
    assert variable.source == 'x'
    assert variable.exclude == ()
    variable = BaseVariable('x', exclude=('y'))
    assert variable.source == 'x'
    assert variable.exclude == ('y',)
    assert variable.code == compile('x', '<variable>', 'eval')
    assert variable.unambiguous_source == 'x'
    assert variable.items(frame_glo_vars, frame_loc_vars) == ()
 
    variable = BaseVariable('y', exclude=('y'))
    assert variable.source == 'y'
    assert variable

# Generated at 2022-06-20 12:42:42.733765
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('x')
    assert BaseVariable('x', exclude=('x',))
    assert BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=())
    assert BaseVariable('x', exclude='x')
    assert BaseVariable('x', exclude=None)
    assert BaseVariable('x', exclude=0)
    assert BaseVariable('x', exclude=1)
    assert BaseVariable('x', exclude=True)
    assert BaseVariable('x', exclude=False)


# Generated at 2022-06-20 12:42:44.112839
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('a.b.c'), Exploding)

DEFAULT_ARGS = [
    'args',
    'kwargs'
]



# Generated at 2022-06-20 12:42:46.353939
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('a', ('c',))
    for i in range(1, 22):
        print(keys._format_key(i))


# Generated at 2022-06-20 12:42:51.447871
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs("object.name")
    assert attr.source == "object.name"
    assert attr.exclude == ()
    #assert attr.code == compile("object.name", '<variable>', 'eval')
    assert attr._fingerprint == (Attrs, 'object.name', ())
    assert attr.__hash__() == hash(attr._fingerprint)
    assert type(attr) == Attrs


# Generated at 2022-06-20 12:43:47.036852
# Unit test for constructor of class Attrs
def test_Attrs():
    import inspect
    import sys
    import os
    if sys.version_info[0] < 3:
        from inspect import getargspec
    else:
        from inspect import getfullargspec as getargspec
    test_list = ['self', 'source', 'exclude']
    test_list.sort()
    assert test_list == getargspec(Attrs.__init__).args, "__init__ method of the class Attrs has wrong argument list"
    try:
        Attrs()
        raise Exception("constructor of Attrs class does not work properly")
    except TypeError:
        pass


# Generated at 2022-06-20 12:43:49.173458
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    test_variable = BaseVariable('a')
    assert(hash(test_variable) == hash(('a',)))


# Generated at 2022-06-20 12:43:52.164462
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    inds = Indices('v', exclude=[])
    inds = inds[::2]
    assert inds._slice == slice(None, None, 2)

# Generated at 2022-06-20 12:43:56.972641
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def __init__(self):
            BaseVariable.__init__(self, source=10, exclude='')
    a = A()
    assert a == A()
    assert a == a
    assert not a == A(source=20)
    assert not a == A(exclude='hi')
    assert not a == ''



# Generated at 2022-06-20 12:44:01.257275
# Unit test for constructor of class Exploding
def test_Exploding():
    # The constructor of class Exploding has no explict test coverage in Python,
    # because it is hard to test. The test coverage report tell us that the
    # coverage of the constructor is 0%.
    #
    # This bug report was open at date of 2019/07/05:
    # https://bugs.gentoo.org/667024
    #
    # In Python, the issue does not occur at all. It is only a coverage issue.
    # The function _items() is also covered by the test of class Attrs and class
    # Keys.
    #
    # Side note: Python 3.9 will have better coverage reports.
    assert True


# Generated at 2022-06-20 12:44:02.512231
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert isinstance(Indices('a')[:], Indices)

# Generated at 2022-06-20 12:44:06.455592
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # BaseVariable instances are equal if they are instances of the same class
    # and have # equal _fingerprint
    v1, v2 = BaseVariable("v1"), BaseVariable("v2")
    assert v1 != v2

    v1_same = BaseVariable("v1")
    assert v1 == v1_same

    v1_different = BaseVariable("v1", exclude=("exc",))
    assert v1 != v1_different



# Generated at 2022-06-20 12:44:09.132332
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    A = BaseVariable("var.attr",("attr1","attr2"))
    B = BaseVariable("var.attr",("attr1","attr2"))
    assert A == B


# Generated at 2022-06-20 12:44:20.970756
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import unittest
    from contextlib import contextmanager
    from mock import patch
    from . import frames
    from .utils import PY3

    if PY3:
        # In Python 3 the name of the exception is just "SyntaxError"
        SyntaxError = SyntaxError
    else:
        class SyntaxError(SyntaxError):
            pass

    class MockedFrame(object):
        def __init__(self, f_globals=None, f_locals=None):
            self.f_globals = f_globals
            self.f_locals = f_locals


# Generated at 2022-06-20 12:44:25.911924
# Unit test for constructor of class Keys
def test_Keys():
    import pytest
    keys = Keys('y', exclude=('__repr__', '__dict__'))
    keys_nonexcluded = Keys('y')
    assert keys.items.__name__ == 'items'
    assert keys.__hash__.__name__ == '__hash__'
    assert keys.__eq__(keys_nonexcluded) == True
    assert keys_nonexcluded.__eq__(keys) == True
    with pytest.raises(Exception):
        keys._keys(1)


# Generated at 2022-06-20 12:46:14.160037
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def check_init(source, expected_source, expected_unambiguous_source, expected_exclude):
        var = CommonVariable(source)
        assert var.source == expected_source
        assert var.exclude == expected_exclude
        assert var.unambiguous_source == expected_unambiguous_source
        assert var._fingerprint == (CommonVariable, expected_source, expected_exclude)

    check_init('x', 'x', 'x', ())
    check_init('x', 'x', 'x', ())
    check_init('a[b]', 'a[b]', '(a)[b]', ())
    check_init('a[b]', 'a[b]', '(a)[b]', ())
    check_init('a.b', 'a.b', 'a.b', ())
    yield check_

# Generated at 2022-06-20 12:46:17.415038
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        BaseVariable('os.path')
    except TypeError:
        return True
    return False


# Generated at 2022-06-20 12:46:21.387163
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert not needs_parentheses('(a)')
    assert needs_parentheses('(a).b')
    assert not needs_parentheses('(a).b.c')

# Generated at 2022-06-20 12:46:31.711781
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class_name = 'BaseVariable'
    method_name = '__eq__'
    method = getattr(sys.modules[__name__], class_name).__dict__[method_name]
    # Test 1: Check type
    assert(hasattr(method, '__call__'))
    # Test 2: Check definition
    source1 = '1'
    source2 = '2'
    exclude1 = ('a', 'b')
    exclude2 = ('c', 'd')
    var1 = BaseVariable(source1, exclude1)
    var2 = BaseVariable(source2, exclude2)
    # Test 2.1
    assert(method(var1, var1) == True)
    # Test 2.2
    assert(method(var1, var2) == False)
    # Test 2.3
    var3

# Generated at 2022-06-20 12:46:33.793489
# Unit test for constructor of class Attrs
def test_Attrs():
    source = 'a.b.c'
    exclude = 'd'
    attrs = Attrs(source, exclude)
    attrs.source == 'a.b.c'
    attrs.exclude == 'd'
    # pass


# Generated at 2022-06-20 12:46:35.862907
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {}
    var = Exploding('x.y')
    print(var)

if __name__ == '__main__':
    test_Exploding()

# Generated at 2022-06-20 12:46:41.369302
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices('foo', 'bar')
    assert v.source == 'foo' and v.exclude == ('bar',)
    v = Indices('foo', ['bar'])
    assert v.source == 'foo' and v.exclude == ('bar',)
    assert v.code == compile('foo', '<variable>', 'eval')
    assert v.unambiguous_source == 'foo'
    v = Indices('foo[2][3].bar', 'bar')
    assert v.source == 'foo[2][3].bar' and v.exclude == ('bar',)
    assert v.code == compile('foo[2][3].bar', '<variable>', 'eval')
    assert v.unambiguous_source == 'foo[2][3].bar'

# Generated at 2022-06-20 12:46:42.775116
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    global source
    source = 'x'
    CommonVariable(source)


# Generated at 2022-06-20 12:46:51.220324
# Unit test for constructor of class Keys
def test_Keys():
    # dictionary
    t1 = Keys('{1:1}')
    assert t1.source == '{1:1}'
    assert t1.exclude == ()
    assert t1.code.co_code == b'|\x00\x00}\x01\x00\x17S'
    assert t1.unambiguous_source == '{1:1}'
    # tuple
    t2 = Keys('(1,)')
    assert t2.source == '(1,)'
    assert t2.exclude == ()
    assert t2.code.co_code == b')\x00\x00\x17S'
    assert t2.unambiguous_source == '(1,)'


# Generated at 2022-06-20 12:46:57.995311
# Unit test for constructor of class Indices
def test_Indices():
    a = [1, 2, 3, 4, 5]
    assert Indices("foo")._items(a) == [("foo[0]", "1"), ("foo[1]", "2"), ("foo[2]", "3"), ("foo[3]", "4"), ("foo[4]", "5")]
    assert Indices("foo", 0)[1:]._items(a) == [("foo[1]", "2"), ("foo[2]", "3"), ("foo[3]", "4"), ("foo[4]", "5")]
    assert Indices("foo", 0)[1:3]._items(a) == [("foo[1]", "2"), ("foo[2]", "3")]

if __name__ == '__main__':
    test_Indices()