

# Generated at 2022-06-20 12:38:17.431863
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v1 = Indices('x')
    v2 = v1[1:2]
    assert v1.source == 'x'
    assert v2.source == 'x'
    assert v1._slice == slice(None)
    assert v2._slice == slice(1, 2, None)


# Generated at 2022-06-20 12:38:25.078314
# Unit test for constructor of class Exploding
def test_Exploding():
    name = 'name'
    exclude = ['foo']
    main_value = None
    var = Exploding(name, exclude)
    assert isinstance(var, Exploding)
    assert var.source == name
    assert var.exclude == exclude
    assert var.code
    assert not var.code.co_consts
    assert not var.code.co_names
    assert not var.code.co_varnames
    assert not var.code.co_freevars
    assert not var._items(main_value)
    main_value = {'foo': 'bar'}
    assert not var._items(main_value)
    main_value = {'baz': 'quux'}
    assert not var._items(main_value)

# Generated at 2022-06-20 12:38:36.120624
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Test 1: after calling __hash__, the __hash__ method should return the correct hash value
    # Analyze Test 1:
    # Since the __hash__ method of BaseVariable will return the hash value of a tuple,
    # the correctness of this hash value depends on the correctness of the _fingerprint property
    # And there will be no problems in other parts of the code
    # So I don't need to write specific tests for the __hash__ method of other subclasses
    # The correctness of other parts of the code should be judged by test_BaseVariable___eq__() below and
    # test_BaseVariable_items() in test_utils.py
    var1 = BaseVariable('time')
    var2 = BaseVariable('time')
    assert hash(var1) == hash(var2)

    # Test 2: different types of variables should not be equal
    var

# Generated at 2022-06-20 12:38:42.237968
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('foo')
    b = BaseVariable('bar')
    c = BaseVariable('foo')

    assert a == c and c == a
    assert a != b and b != a
    # Failing if __eq__ does not return NotImplemented when arguments
    # are not instances of BaseVariable class
    from operator import __ne__
    assert __ne__(a, 0) is NotImplemented
    assert __ne__(0, a) is NotImplemented


# Generated at 2022-06-20 12:38:44.351592
# Unit test for constructor of class Exploding
def test_Exploding():
    x = []
    x[0] = '1'
    assert(len(Exploding('x')._items(x)) == 1)

# Generated at 2022-06-20 12:38:49.936146
# Unit test for constructor of class Attrs
def test_Attrs():
    test_source = 'testing'
    test_exclude = 'hello_list'
    test_variable = Attrs(test_source, test_exclude)
    assert test_variable.source == test_source
    assert test_variable.exclude[0] == test_exclude
    assert isinstance(test_variable, CommonVariable)
    assert isinstance(test_variable, BaseVariable)


# Generated at 2022-06-20 12:38:52.066019
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    idx = Indices('x', exclude=())
    assert idx[2:5] == Indices('x', exclude=())[2:5]

# Generated at 2022-06-20 12:38:58.987548
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import pycompat
    from . import utils
    import sys

    var = Keys('foo')
    assert var.items(sys._getframe()) == []

    var = Keys('[' '{"a": "b"}' ']')
    assert var.items(sys._getframe(), normalize=True) == \
           [('[{"a": "b"}]', utils.get_shortish_repr({'a': 'b'}, normalize=True)),
            ('[{"a": "b"}]["a"]', '"b"')]

    var = Indices('[' '{"a": "b"}' ']')

# Generated at 2022-06-20 12:39:00.758685
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'source'
    indices = Indices(source)
    indices = indices[:]
    assert indices.source == source

# Generated at 2022-06-20 12:39:04.092890
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('x.y', exclude=['z']).source == 'x.y'
    assert Exploding('x.y', exclude=['z']).exclude == ('z',)


# Generated at 2022-06-20 12:39:21.051904
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # The class CommonVariable accepts the input that have or have not the comma at the end.
    # For example:
    class CommonVariable_test(CommonVariable):
        def __init__(self, source, exclude=()):
            BaseVariable.__init__(self, source, exclude)
    # Accept to have the comma at the end of the input arguments.
    CommonVariable_obj1 = CommonVariable_test("self.source",())
    assert (CommonVariable_obj1 != None)
    # Accept to not have the comma at the end of the input arguments.
    CommonVariable_obj2 = CommonVariable_test("self.source")
    assert (CommonVariable_obj2 != None)

# Generated at 2022-06-20 12:39:25.955545
# Unit test for constructor of class Keys
def test_Keys():
    dict = {'key1':1,'key2':2}
    keys = Keys('a',exclude = ['key2'])
    # Keys should contains exclude key
    assert keys.exclude == ['key2']
    # self._keys should contains keys of dict
    assert keys._keys(dict) == dict.keys()


# Generated at 2022-06-20 12:39:33.366211
# Unit test for constructor of class Keys
def test_Keys():
    from collections import OrderedDict
    key1 = Keys('x', exclude='__class__')
    assert key1.source == 'x'
    assert key1.exclude == ('__class__',)
    assert key1.unambiguous_source == 'x'
    assert key1.code == compile('x', '<variable>', 'eval')
    assert key1._keys({'test1': 'test2'}) == ['test1']
    assert key1._format_key('test1') == '[test1]'
    assert key1._get_value({'test1': 'test2'}, 'test1') == 'test2'
    assert key1._safe_keys({'test1': 'test2'}) == ['test1']
    assert key1._fingerprint == (Keys, 'x', ('__class__',))

   

# Generated at 2022-06-20 12:39:38.341825
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    b = BaseVariable('foo')
    assert(b.source == 'foo')
    assert(b.exclude == ())
    assert(b.code.co_names[0] == 'foo')

    b = BaseVariable('foo', exclude='bar')
    assert(b.exclude == ('bar',))

    b = BaseVariable('(foo).bar')
    assert(b.source == '(foo).bar')
    assert(b.unambiguous_source == '(foo).bar')

    b = BaseVariable('foo.bar')
    assert(b.source == 'foo.bar')
    assert(b.unambiguous_source == '(foo).bar')

    b = BaseVariable('foo.bar.baz')
    assert(b.source == 'foo.bar.baz')

# Generated at 2022-06-20 12:39:46.161308
# Unit test for constructor of class Attrs
def test_Attrs():
    main_value = main_value = {"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10,"k":11,"l":12,"m":13,"n":14,"o":15,"p":16,"q":17,"r":18,"s":19,"t":20,"u":21,"v":22,"w":23,"x":24,"y":25,"z":26}
    cls = Attrs("main_value", exclude=())
    assert(set(cls._keys(main_value)) == set(main_value.keys()))

# Generated at 2022-06-20 12:39:50.643754
# Unit test for constructor of class Attrs
def test_Attrs():
    variable = Attrs("x", exclude=("y", "z"))
    assert repr(variable) == "Attrs('x')"
    assert variable == Attrs("x", exclude=("y", "z"))
    assert variable != Attrs("x", exclude=("x", "z"))
    assert hash(variable) > 0


# Generated at 2022-06-20 12:39:57.460105
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def _get_base_variable(source, exclude=()):
        class _Base(BaseVariable):
            _source = source
            _exclude = exclude

        return _Base

    class _Frame(object):
        _globals = {}
        _locals = {'a': 1, 'b': 2, 'c': 3}

    class _Frame2(object):
        _globals = {}
        _locals = {'a': {'d':4}, 'b': [1, 2, 3], 'c': {'e':5}}

    frame = _Frame()
    frame2 = _Frame2()
    assert _get_base_variable('a').items(frame) == [('a', 1)]
    assert _get_base_variable('a', exclude='b').items(frame) == [('a', 1)]


# Generated at 2022-06-20 12:40:08.300641
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .render import Frame
    from .utils import SimpleNamespace
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize):
            return []

    def test_frame():
        x = 1
        y = 2
        return Frame(test_frame.__code__, locals(), globals())
    frame = test_frame()
    frame.f_locals = SimpleNamespace(x=1, y=2)
    frame.f_globals = SimpleNamespace(x=3)

    expected = [
        ('x', '1'),
        ('globals().x', '3')
    ]
    assert TestVariable('x').items(frame) == expected


# Generated at 2022-06-20 12:40:12.228619
# Unit test for constructor of class Indices
def test_Indices():
    obj = Indices('this_is_source')
    # test __init__()
    assert obj.source == 'this_is_source'
    assert obj.exclude == ()
    assert isinstance(obj.code, type(compile('', '', 'eval')))
    assert obj.unambiguous_source == 'this_is_source'


# Generated at 2022-06-20 12:40:24.618162
# Unit test for constructor of class Exploding
def test_Exploding():
    class Test():
        pass
    test = Test()
    test.abc = 'abc'

# Generated at 2022-06-20 12:40:44.265389
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():

    class Sequence(object):

        def __init__(self, sequence):
            self.sequence = sequence

        def __len__(self):
            return len(self.sequence)

        def __getitem__(self, item):
            return self.sequence[item]

    sequence = Sequence(range(5))
    k1 = Indices("source")
    items1 = k1._items(sequence, normalize=False)
    assert items1 == [
        ('source', 'range(0, 5)'),
        ('source[0]', '0'),
        ('source[1]', '1'),
        ('source[2]', '2'),
        ('source[3]', '3'),
        ('source[4]', '4'),
    ]

    k2 = Indices("source")[2:]
    items2 = k2._

# Generated at 2022-06-20 12:40:46.785434
# Unit test for constructor of class Keys
def test_Keys():
    # Initialize some variables
    cls = Keys # choose class
    source = 'x' # choose string
    
    # Construct class
    cls(source)
    

# Generated at 2022-06-20 12:40:52.838379
# Unit test for constructor of class Keys
def test_Keys():
    t = Keys('t')
    assert t.source == 't'
    assert t.exclude == ()
    assert t.code.co_names == ('t',)
    assert t._fingerprint == (Keys, 't', ())
    t = Keys('t', exclude='b')
    assert t.exclude == ('b',)
    t = Keys('t', exclude=['a', 'b'])
    assert t.exclude == ('a', 'b')

# Generated at 2022-06-20 12:40:59.271067
# Unit test for constructor of class Attrs
def test_Attrs():
    class Foo():
        def __init__(self):
            self.x = 5
        y = 7
        @classmethod
        def add(cls, a, b):
            return a + b

    foo = Foo()
    a_cls = Attrs("foo")
    a = a_cls.items(foo)
    assert("foo.x" in a)
    assert("foo.y" in a)
    assert("foo.add" in a)


if __name__ == '__main__':
    test_Attrs()

# Generated at 2022-06-20 12:41:02.601617
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable("loop").source == "loop"
    assert CommonVariable("loop").exclude == ()
    # TODO: fix this test
    # assert CommonVariable("loop").code == compile('loop', '<variable>', 'eval')
    assert CommonVariable("loop").unambiguous_source == 'loop'


# Generated at 2022-06-20 12:41:06.185507
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = Attrs('self', exclude=('other', ))
    var2 = Attrs('self', exclude=('other',))
    assert var1 == var2



# Generated at 2022-06-20 12:41:09.659070
# Unit test for constructor of class Keys
def test_Keys():
    d = {'greeting': 'hello', 'user': 'world'}
    keys = Keys('d').items(d)
    assert keys == [('d', '{')]



# Generated at 2022-06-20 12:41:14.151040
# Unit test for constructor of class Attrs
def test_Attrs():
    var_name='_AttrsName0'
    var_value='_AttrsValue0'
    var_exclude='_AttrsExclude0'
    var_source=var_name+'.'+var_value
    test_attrs = Attrs(var_source, var_exclude)
    assert(test_attrs.source == var_source)
    assert(test_attrs.exclude == var_exclude)
    assert(test_attrs.code == compile(var_source, '<variable>', 'eval'))
    assert(test_attrs.unambiguous_source == var_source)


# Generated at 2022-06-20 12:41:17.264793
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = sys._getframe()
    bv = BaseVariable('sys.version')
    data = bv.items(frame)
    print(data)
    return True


# Generated at 2022-06-20 12:41:22.249295
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # test the constructor of class CommonVariable
    cv = CommonVariable(source="test", exclude=["test2"])
    print(cv)
    assert(cv is not None)
    print("test_CommonVariable: PASS")

if __name__ == '__main__':
    test_CommonVariable()

# Generated at 2022-06-20 12:41:39.617359
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import get_shortish_repr
    from .protocol import Source, Variable
    from .pycompat import is_py3
    from .version import __version__
    frame = _test_frame

    # Test for no exclude
    var = Variable(Source('account', '__dict__', None, None, None), False, (), 1)
    result = var.items(frame)
    expected = []
    if is_py3:
        expected.append(('account', '<Account username=...>'))
        expected.append(('account.username', "'John'"))
    else:
        expected.append(('account', '<Account object at 0x...>'))
        expected.append(('account.username', "'John'"))
    expected.append(('account.password', "u'qwerty'"))


# Generated at 2022-06-20 12:41:46.430691
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable("a.b").__eq__(BaseVariable("a.b")) == True
    assert BaseVariable("a.b").__eq__(BaseVariable("a.c")) == False
    assert BaseVariable("a.b").__eq__(Keys("a.c")) == False
    assert BaseVariable("a.b", ("x", "y")).__eq__(BaseVariable("a.b", ("y", "x"))) == True
    assert BaseVariable("a.b", ("x", "y")).__eq__(BaseVariable("a.b", ("y",))) == False


# Generated at 2022-06-20 12:41:50.388372
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("x")
    b = a[1:3]
    assert len(b._slice) == 2
    assert b._slice.start == 1
    assert b._slice.stop == 3
    assert b._slice.step is None


# Unit tests for method items of class Indices

# Generated at 2022-06-20 12:41:54.456399
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('variable').__init__, Exploding)
    assert isinstance(Exploding('variable', exclude=('x')).__init__, Exploding)
    assert isinstance(Exploding('variable', exclude='x').__init__, Exploding)

# Generated at 2022-06-20 12:42:00.017303
# Unit test for constructor of class Attrs
def test_Attrs():
    def __init__(self, source, exclude=()):
        self.source = source
        self.exclude = utils.ensure_tuple(exclude)
        self.code = compile(source, '<variable>', 'eval')
        if needs_parentheses(source):
            self.unambiguous_source = '({})'.format(source)
        else:
            self.unambiguous_source = source
    # Initialize test variable
    A = Attrs('root', 'exclude')
    A.__init__ = __init__
    assert hasattr(A, 'source')
    assert hasattr(A, 'exclude')
    assert hasattr(A, 'code')
    assert hasattr(A, 'unambiguous_source')


# Generated at 2022-06-20 12:42:06.238618
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import sys
    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    a = A()
    sys.frame = a
    print(sys._getframe())
    cv = CommonVariable('a')
    print(cv.items(sys._getframe()))


# Generated at 2022-06-20 12:42:15.078055
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class PrefixSeq(Sequence):
        def __init__(self, prefix, seq):
            self.prefix = prefix
            self.seq = seq

        def __getitem__(self, item):
            return self.prefix + self.seq[item]

        def __len__(self):
            return len(self.seq)

    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    v = Indices('seq')

# Generated at 2022-06-20 12:42:22.980761
# Unit test for function needs_parentheses
def test_needs_parentheses():
    # pylama:ignore=C0111
    assert needs_parentheses('self.foo')
    assert not needs_parentheses('self')
    assert needs_parentheses('self.foo.bar')
    assert not needs_parentheses('self[3]')
    assert needs_parentheses('self[3].bar')
    assert not needs_parentheses('self.foo[3]')
    assert not needs_parentheses('foo(3)')
    assert needs_parentheses('foo(3).x')
    assert not needs_parentheses('foo[3](4)')
    assert needs_parentheses('foo[3](4).x')

# Generated at 2022-06-20 12:42:24.183557
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable


# Generated at 2022-06-20 12:42:33.025659
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import utils
    main_value=[
        [1,2,3],
        ['a','b','c'],
        [{'d':4},{'e':5}],
        [{'f':{'g':6}},{'h':{'i':7}}]
    ]
    source = "a"
    exclude=()
    n = len(main_value)
    for i in range(n):
        cls = Keys
        if isinstance(main_value[i], Mapping):
            cls = Keys
        elif isinstance(main_value[i], Sequence):
            cls = Indices
        else:
            cls = Attrs
        result = cls(source, exclude)._items(main_value[i])
        expected = Exploding(source, exclude)._items

# Generated at 2022-06-20 12:42:42.095190
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('a')
    i_sub = i[1:10]
    assert isinstance(i_sub, Indices)
    assert i_sub.source == 'a'
    assert i_sub._slice == slice(1, 10)

# Generated at 2022-06-20 12:42:49.229024
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import MockFrame
    import sys
    v = BaseVariable('a')
    f = MockFrame({'a':12})
    assert v.items(f) == [('a', '12')]

    v = BaseVariable('a.b')
    f = MockFrame({'a':{'b':13}})
    assert v.items(f) == [('a.b', '13')]

    v = BaseVariable('a')
    f = MockFrame({'a':[1, [2], 3]})
    assert v.items(f) == [('a', '[1, [2], 3]')]

    v = BaseVariable('a.b')
    f = MockFrame({'a':{'b':[1, [2], 3]}})

# Generated at 2022-06-20 12:42:59.126382
# Unit test for constructor of class Attrs
def test_Attrs():
    # test constructor
    variableDefinitions = Attrs('f')

    assert variableDefinitions.source       == 'f'
    assert variableDefinitions.unambiguous_source  == 'f'
    assert variableDefinitions.exclude      == ()

    variableDefinitions = Attrs('f', exclude=('a',))

    assert variableDefinitions.source       == 'f'
    assert variableDefinitions.unambiguous_source  == 'f'
    assert variableDefinitions.exclude      == ('a',)

    variableDefinitions = Attrs('f', 'a')

    assert variableDefinitions.source       == 'f'
    assert variableDefinitions.unambiguous_source  == 'f'
    assert variableDefinitions.exclude      == ('a',)

test_Attrs()


# Generated at 2022-06-20 12:43:01.445014
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('request')
    assert var.source == 'request'


# Generated at 2022-06-20 12:43:07.415501
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import pycompat
    class A():
        __slots__ = ('a', 'b')
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
    a = A()
    if pycompat.PY2:
        assert Attrs('a')._keys(a) == ('a', 'b')
    else:
        assert Attrs('a')._keys(a) == ('__dict__', 'a', 'b')



# Generated at 2022-06-20 12:43:13.459006
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import utils
    from .breakpoint import Breakpoint
    from .frame import Frame

    utils.patch_frame_code(Frame)
    breakpoint = Breakpoint('', [])

    variables = Attrs('filename', exclude=('exclude',))
    assert variables.source == 'filename'
    assert variables.exclude == ('exclude',)
    assert variables.unambiguous_source == 'filename'


# Generated at 2022-06-20 12:43:17.056652
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable(None)
    var_2 = BaseVariable(None)
    var_3 = BaseVariable('sasdd')
    assert var_1 == var_2
    assert var_1 != var_3
    assert var_2 != var_3


# Generated at 2022-06-20 12:43:19.719505
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[1:] == Indices('a', _slice=slice(1,None))
    assert a[:3] == Indices('a', _slice=slice(0,3))

# Generated at 2022-06-20 12:43:23.641420
# Unit test for constructor of class Exploding
def test_Exploding():
    a = Exploding('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert type(a.code) == type(compile('','','eval'))
    assert a.unambiguous_source == 'a'
    assert a.items(None) == ()


# Generated at 2022-06-20 12:43:26.078571
# Unit test for constructor of class Attrs
def test_Attrs():
    import doctest
    print(doctest.testmod())


if __name__ == "__main__":
    test_Attrs()

# Generated at 2022-06-20 12:43:38.411956
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses("foo.bar")
    assert needs_parentheses("foo[0]")
    assert needs_parentheses("(foo).bar")
    assert not needs_parentheses("(foo.bar)")

# Generated at 2022-06-20 12:43:44.359717
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # BaseVariable.__eq__ is called when values are compared. 
    # Let's see what happens when __eq__ is never called. 
    alice = BaseVariable(source=None, exclude=('a', 1, 2.5, 'a', 1, 2.5, ))
    bob = BaseVariable(source=None, exclude=('a', 1, 2.5, 'a', 1, 2.5, ))
    print('alice == bob? {}'.format(alice == bob))
    # oh no!
    # the comparison is order dependent!
    # which is bad in many ways, especially for sets
    # we need to define __eq__

    # but how can we call it?
    print ('alice == alice? {}'.format(alice == alice))
    # oh no!
    # Python3 doesn't call __

# Generated at 2022-06-20 12:43:55.077973
# Unit test for function needs_parentheses
def test_needs_parentheses():
    ns = {'a': 'value', 'b': [1, 2, 3], 'c': 'c', 'd': 'd'}
    def check(source, expected):
        actual = needs_parentheses(source)
        assert actual == expected, '{!r} returned {!r}, expected {!r}'.format(source, actual, expected)
    check('a', False)
    check('b[1]', False)
    check('(b)[1]', False)
    check('c b[1]', True)
    check('c (b[1])', False)
    check('d[1] c b[2]', True)
    check('d[1] c (b[2])', False)
    check('(1 + 2)[1]', False)
    check('2 + 3 * 5', True)

# Generated at 2022-06-20 12:43:57.350719
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('foo'), BaseVariable)
    assert isinstance(Exploding('foo', exclude=[]), BaseVariable)

# Generated at 2022-06-20 12:43:58.874295
# Unit test for constructor of class Indices
def test_Indices():
    var1 = Indices('var1')
    assert len(var1._keys('abc')) == 3


# Generated at 2022-06-20 12:44:03.282368
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices("foo")
    assert isinstance(var, Indices)
    assert var.source == "foo"
    assert var.exclude == ()
    assert var.code.co_code == compile("foo", '<variable>', 'eval').co_code
    assert var.unambiguous_source == "foo"


# Generated at 2022-06-20 12:44:04.890776
# Unit test for constructor of class Attrs
def test_Attrs():
    dic = Attrs("frame")
    assert dic.source == "frame"
    assert dic.exclude == ()


# Generated at 2022-06-20 12:44:08.377992
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding("val")
    assert e.source == "val"
    assert e.exclude == ()
    assert e.code == compile('val', '<variable>', 'eval')
    assert e.unambiguous_source == 'val'


# Generated at 2022-06-20 12:44:18.480236
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')[1:3]
    assert v.source == 'a'
    assert v.exclude == ()
    assert v._slice == slice(1, 3)

    v = Indices('a', 'x')[1:3]
    assert v.source == 'a'
    assert v.exclude == ('x', )
    assert v._slice == slice(1, 3)

    v = Indices('a', ['x', 'y'])[1:3]
    assert v.source == 'a'
    assert v.exclude == ('x', 'y')
    assert v._slice == slice(1, 3)



# Generated at 2022-06-20 12:44:20.766138
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "a"
    exclude = ""
    variable = BaseVariable(source, exclude)
    assert variable.source == source
    assert variable.exclude == exclude
    assert variable.code == compile(source, '<variable>', 'eval')


# Generated at 2022-06-20 12:44:44.979229
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {'a': 1, 'b': 2}
    for key in a:
        Exploding(key)
    b = [1, 2]
    for key in b:
        Exploding(key)

# Generated at 2022-06-20 12:44:53.184683
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import collections
    import pprint
    frame = inspect.currentframe()
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals
    def add_frame_locals_to_frame(frame_locals, frame_globals):
        example_list = [1, 2, 3]
        frame_locals['example_list'] = example_list
        example_dict = {1: 1, 2: 2, 3: 3}
        frame_locals['example_dict'] = example_dict
        example_tuple = (1, 2, 3)
        frame_locals['example_tuple'] = example_tuple
        example_set = {1, 2, 3}
        frame_locals['example_set']

# Generated at 2022-06-20 12:45:04.088485
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import bdb
    import inspect

    class Foo:
        a = 1
        b = 2
        d = {'c': 3, 'e': 4}

    def run_func(func):
        def run_code(code, source):
            return eval(code, globals(), locals())

        fn_name, line_no = inspect.getsourcelines(func)
        fn_name = fn_name.strip()
        return run_code('{}()'.format(fn_name), fn_name)

    def main():
        return Foo()

    def func():
        return Foo().a + Foo().b + Foo().d.c + Foo().d['e'] + Foo().f

    def func_call():
        return main()

    def func_loop():
        a = 1
        a += 2
        a *= 3


# Generated at 2022-06-20 12:45:10.269581
# Unit test for constructor of class Keys
def test_Keys():
    x = {}
    x['a'] = x
    x['b'] = x
    x['c'] = x
    result = Keys(source='x', exclude='b').items({'x': x})
    assert len(result) == 3
    result = Keys(source='x', exclude='b').items({'x': x})
    assert result[0][0] == 'x'
    assert result[1][0] == 'x[a]'
    assert result[2][0] == 'x[c]'

# Generated at 2022-06-20 12:45:13.514977
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=('b', )) == BaseVariable('a', exclude=('b', ))
    assert BaseVariable('a') != BaseVariable('a', exclude=('b', ))
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude=('b', ))

# Generated at 2022-06-20 12:45:16.579787
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable("args", "self")
    variable1 = BaseVariable("args", "self")
    assert variable == variable1

    variable2 = BaseVariable("args", "self1")
    assert variable != variable2



# Generated at 2022-06-20 12:45:23.484448
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = [1, 2, 3, 4, 5]
    inds = Indices("main_value")
    inds_slice = inds[1::3]
    assert inds_slice._slice == slice(1, None, 3)
    result = []
    for var, val in inds_slice.items(None):
        result.append(val)
    assert result == [2, 5]

# Generated at 2022-06-20 12:45:25.614173
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    if sum([
        __name__ == '__main__',
    ]) == 1:
        # Test code ...
        pass
    # Test code ...


# Generated at 2022-06-20 12:45:28.330290
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("x")
    assert needs_parentheses("x.y")
    assert not needs_parentheses("(x)")
    assert not needs_parentheses("(x).y")

# Generated at 2022-06-20 12:45:31.273382
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    sliced_a = a[1:5]
    assert sliced_a.source == 'a'
    assert sliced_a.exclude == ()
    assert len(sliced_a._slice) == 4



# Generated at 2022-06-20 12:46:20.694864
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class MyVar(BaseVariable):
        def _items(self, key, normalize=False):
            return [(self.source, None)]
    var = MyVar('main_value')
    assert list(var.items(None)) == [('main_value', None)]


# Generated at 2022-06-20 12:46:22.351036
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    with pytest.raises(NotImplementedError):
        CommonVariable('a')


# Generated at 2022-06-20 12:46:29.317114
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        bv = BaseVariable('test')
    except Exception as e:
        if str(e) == 'Can\'t instantiate abstract class BaseVariable with abstract method _items':
            pass
        else:
            print('Fail!')
            print('Wrong exception:', e)
            exit(1)
    else:
        print('Fail!')
        print('No exception raised!')
        exit(1)
    print('Pass!')
test_BaseVariable()


# Generated at 2022-06-20 12:46:31.390104
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('name')
    a = Attrs('name','exclude_name')
    assert a.exclude == ('exclude_name', )

# Generated at 2022-06-20 12:46:38.368511
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import inspect
    import re

    def source_has_space(source):
        return re.match(re.compile(r'.*\s.*'), source)

    def source_has_no_space(source):
        return not source_has_space(source)

    def test_name(name):
        __tracebackhide__ = True

        class Test(BaseVariable):
            def __init__(self, source):
                super(Test, self).__init__(source)

            def items(self, frame, normalize=None):
                pass

            def _items(self, main_value, normalize=None):
                pass

        test_obj = Test('SOME_STRING')
        assert not inspect.isfunction(test_obj.items)
        assert inspect.ismethod(test_obj.items)

# Generated at 2022-06-20 12:46:48.113900
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import unittest
    import pprint
    from .test_utils import subTest

    class TestCase(unittest.TestCase):
        def assertEqual(self, expected, actual, msg=None):
            with subTest(actual=actual, msg=msg):
                return super().assertEqual(expected, actual)

    class BaseVariableTester(BaseVariable):

        def __init__(self):
            self.code = None
            self.source = None
            self.exclude = None

        def items(self, frame, normalize=False):
            return [
                (self.source, 'SomeValue'),
                ('some_attr', '-attr-'),
                ('[0]', '[0]')
            ]


# Generated at 2022-06-20 12:46:50.161228
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('abc', exclude='abc')
    v2 = BaseVariable('abc', exclude='abc')
    assert hash(v1) == hash(v2)

# Generated at 2022-06-20 12:46:57.167726
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    from . import utils
    source = "abc"
    explode = Indices(source)
    # Case 1
    start = 2
    stop = 3
    step = 1
    result = explode[start:stop:step]
    # Verification
    assert result == Indices(source, ())
    assert result.__getitem__(slice(2, 3, 1)) == Indices(source, ())
    # Case 2
    start = -6
    stop = -1
    step = 1
    result = explode[start:stop:step]
    # Verification
    assert result == Indices(source, ())
    assert result.__getitem__(slice(-6, -1, 1)) == Indices(source, ())
    # Case 3
    start = -1
    stop = None
    step = 1
   

# Generated at 2022-06-20 12:47:01.446219
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    loc = {}
    glob = {'a': 1}
    var = BaseVariable('1')
    print(var.items(frame=loc, normalize=False))
    print(var.items(frame=glob, normalize=False))


# Generated at 2022-06-20 12:47:11.922926
# Unit test for constructor of class Attrs
def test_Attrs():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import mock as Mock

    klass = Mock('Abc')
    instance = Mock('instance', __dict__={'a': 1, 'b': 2})
    klass.return_value = instance
    obj = Attrs('Abc()', exclude=['a'])
    klass.assert_called_once_with()
    assert obj._get_value(instance, 'a') == 1
    assert obj._get_value(instance, 'b') == 2
    assert obj._keys(instance) == ['a', 'b']
    assert obj._format_key('a') == '.a'