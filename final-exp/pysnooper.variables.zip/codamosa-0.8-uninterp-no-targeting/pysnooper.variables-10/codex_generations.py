

# Generated at 2022-06-20 12:38:20.035245
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'x': 10, 'a': 'hello', 'b': [1, 2, 3]}
    #print(BaseVariable('a').items(frame))
    #print(BaseVariable('b').items(frame))
    #print(BaseVariable('b[1]').items(frame))

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-20 12:38:22.496988
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != Attrs('x')
#------------


# Generated at 2022-06-20 12:38:33.016577
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .context import Context
    from . import conf
    from . import as_variables
    import logging

    conf.log_file_path = None
    conf.log_level = logging.DEBUG
    conf.exclude_variables = ()
    c = Context(1, as_variables.explode('l'), None)
    print(c.variables)

    assert c.variables == (
        ('[0]', repr((1,))),
        ('[1]', repr((2,))),
        ('[2]', repr((3,))),
    )
    c1 = Context(1, as_variables.explode('l[0:2]'), None)
    print(c1.variables)

# Generated at 2022-06-20 12:38:36.741485
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != Attrs('x')
    assert BaseVariable('x') != object()

# Generated at 2022-06-20 12:38:39.660349
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Indices('a') == Indices('a')
    assert Indices('a') != Indices('b')
    assert Indices('a') != Attrs('a')
    assert Indices('a') != Keys('a')
    assert Indices('a') != Exploding('a')

# Generated at 2022-06-20 12:38:41.725711
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('name')
    variable_slice = variable[1:10]
    assert variable_slice._slice == slice(1,10)

# Generated at 2022-06-20 12:38:43.686386
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('k[1]').items('k[2]') =='k[2]'


# Generated at 2022-06-20 12:38:49.042612
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('lala')
    assert x.source == 'lala'
    assert x.exclude == tuple()
    s = "'%r' is not defined" % 'lala'
    assert x.code == compile(s, '<variable>', 'eval')
    assert x.unambiguous_source == '(lala)'

    # Tests for _items
    def test_items_1(x):
        utils.my_keys = lambda x: {'a': 1, 'b':2}
        assert x.items({}) == []
        assert x.items({'lala': {}}) == []
        assert x.items({'lala': {'__keys__': utils.my_keys}}) == [('lala[a]', '1'), ('lala[b]', '2')]
        del ut

# Generated at 2022-06-20 12:38:52.691921
# Unit test for constructor of class Exploding
def test_Exploding():
    ex1 = Exploding('username')
    assert ex1.source == 'username'
    ex2 = Exploding('username', exclude=['username'])  # exclude should become a tuple
    assert ex2.source == 'username'
    assert ex2.exclude == ('username', )

# Generated at 2022-06-20 12:38:54.844684
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert compile("a", '<variable>', 'eval').co_code == compile("(a)", '<variable>', 'eval').co_code


# Generated at 2022-06-20 12:39:03.792380
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable('t')
    assert dict(v.items(None)) == {'t': 't'}

    with pytest.raises(NotImplementedError):
        v._items(None)



# Generated at 2022-06-20 12:39:05.836427
# Unit test for constructor of class Indices
def test_Indices():
    item = Indices("main_value")
    item._slice = slice(2, 5)
    assert item._slice == slice(2, 5)



# Generated at 2022-06-20 12:39:12.814111
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import utils
    from . import transforms
    from . import history
    import unittest

    class TestTrans(transforms.Transform):
        def __init__(self, frame, tb):
            pass

    def make_fake_frame(locals):
        """Makes a fake frame object for testing purposes."""
        import inspect
        import dis
        import six
        f_code = inspect.currentframe().f_code

# Generated at 2022-06-20 12:39:18.271092
# Unit test for constructor of class Exploding
def test_Exploding():
    e1 = Exploding('e1')
    assert e1.source == 'e1'
    assert e1.unambiguous_source == 'e1'

    e2 = Exploding('e2')
    assert e2.source == 'e2'
    assert e2.unambiguous_source == 'e2'

    assert e1 != e2



# Generated at 2022-06-20 12:39:20.850842
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a').items(None)
    b = [('a', '[]'), ('a[0]', 'IndexError')]
    assert a == b

# Generated at 2022-06-20 12:39:24.483264
# Unit test for constructor of class Keys
def test_Keys():
    dic = {'a': 1, 'b': 2}
    k = Keys("dic")
    assert len(k.items({'dic': dic})[1]) == 2


# Generated at 2022-06-20 12:39:31.107241
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('i', exclude=('a', 'b'))
    b = CommonVariable('i', exclude=('b', 'a'))
    assert isinstance(a, BaseVariable)

    assert a.source == 'i'
    assert a.exclude == ('a', 'b')
    assert a.code == compile('i', '<variable>', 'eval')
    assert a.unambiguous_source == 'i'

    assert a == b
    assert hash(a) == hash(b)
    assert (type(a), a.source, a.exclude) == (type(b), b.source, b.exclude)



# Generated at 2022-06-20 12:39:40.925486
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('')
    assert not needs_parentheses('x')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo.bar[42]')
    assert not needs_parentheses('foo.bar(42)')
    assert needs_parentheses('1')
    assert needs_parentheses('(x)')
    assert needs_parentheses('(x or y)')
    assert needs_parentheses('foo(x)')
    assert needs_parentheses('foo.bar(42).baz')
    assert needs_parentheses('foo.bar[baz]')
    assert needs_parentheses('foo.bar[(baz)]')
    assert needs_parentheses('foo.bar[b[az]]')

# Generated at 2022-06-20 12:39:47.911874
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('a', 'x')
    assert c.source == 'a'
    assert c.exclude == ('x',)
    assert c.code.co_code == b'e\x00\x00\x00\x00\x00'
    assert c.unambiguous_source == '(a)'

    c = CommonVariable('a', 'x')
    assert hash(c) == hash((CommonVariable, 'a', ('x',)))
    assert c == CommonVariable('a', 'x')
    assert c != CommonVariable('a', 'y')
    assert c != CommonVariable('a')
    assert c != 'a'


# Generated at 2022-06-20 12:39:49.022698
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices('some_var')

# Generated at 2022-06-20 12:40:00.414455
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a', ('a.b', 'a.c'))
    assert a.source == 'a'
    assert a.exclude == ('a.b', 'a.c')
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == '({})'.format('a')


# Generated at 2022-06-20 12:40:05.165511
# Unit test for constructor of class Indices
def test_Indices():
    frame_info = inspect.currentframe()
    locs = frame_info.f_locals
    indices = Indices('locs', exclude='__builtins__')
    print(indices._keys(locs))
    print(indices.items(frame_info, normalize=True))


# Generated at 2022-06-20 12:40:10.423012
# Unit test for constructor of class Exploding
def test_Exploding():
    exploded = Exploding(source='a', exclude='z')
    assert exploded.source == 'a'
    assert exploded.exclude == ('z',)
    assert exploded.unambiguous_source == 'a'
    assert not hasattr(exploded, 'code')
    assert not hasattr(exploded, '_fingerprint')
    assert not hasattr(exploded, '__hash__')
    assert not hasattr(exploded, '__eq__')


# Generated at 2022-06-20 12:40:20.410803
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # simple
    assert BaseVariable('x').source == 'x'
    assert BaseVariable('x', exclude='y').exclude == ('y',)
    assert BaseVariable('x', exclude=['y']).exclude == ('y',)
    assert BaseVariable('x', exclude=['y', 'z']).exclude == ('y', 'z')
    # error
    try:
        BaseVariable('')
    except SyntaxError:
        pass
    else:
        assert False
    # compile error
    try:
        BaseVariable('1 +')
    except SyntaxError:
        pass
    else:
        assert False
    try:
        BaseVariable('1 + 2')
    except SyntaxError:
        assert False


# Generated at 2022-06-20 12:40:28.157323
# Unit test for constructor of class Keys
def test_Keys():
    v1 = Keys('main_value')

    assert v1.source == 'main_value'
    assert v1.exclude == ()
    assert v1.code is not None
    assert v1.unambiguous_source == 'main_value'

    v2 = Keys('main_value', exclude=('a', 'b'))

    assert v2.source == 'main_value'
    assert v2.exclude == ('a', 'b')
    assert v2.code is not None
    assert v2.unambiguous_source == 'main_value'

# Generated at 2022-06-20 12:40:39.150915
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    class A():
        pass
    a = A()
    attr = Attrs('a')
    assert attr.items(sys._getframe()) == []

    a.b = 10
    a.d = 30
    assert attr.items(sys._getframe()) == [('a', '<A>'), ('a.b', '10'), ('a.d', '30')]

    dict_ = {'a':10, 'b':20, 'c':30}
    keys = Keys('dict_')
    assert keys.items(sys._getframe()) == [('dict_', '<dict>'), ('dict_[a]', '10'), ('dict_[b]', '20'), ('dict_[c]', '30')]
    
    g_0 = [1,2,3,4,5]

# Generated at 2022-06-20 12:40:39.918785
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
	pass


# Generated at 2022-06-20 12:40:41.130292
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert isinstance(BaseVariable("a").__hash__(), int)


# Generated at 2022-06-20 12:40:44.270332
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable(source='x', exclude=['e'])
    assert x.source == 'x'
    assert x.exclude == ('e',)
    assert x.code == compile('x', '<variable>', 'eval')
    assert x.unambiguous_source == '(x)'


# Generated at 2022-06-20 12:40:45.709893
# Unit test for constructor of class Keys
def test_Keys():
	k = Keys('a')
	print(k._fingerprint)

# Generated at 2022-06-20 12:41:03.770334
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # _safe_keys
    d = CommonVariable('d')
    assert d._safe_keys('test string') == []
    assert d._safe_keys(['a', 'b', 'c']) == range(3)
    assert d._safe_keys(['a', 'b', Exception]) == range(2)
    assert d._safe_keys([Exception, Exception, Exception]) == []

    # exception handling on _items
    d = CommonVariable('d')
    assert d._items(Exception) == []

    # _format_key
    d = CommonVariable('d')
    assert d._format_key('a') == ''

    # _get_value
    d = CommonVariable('d')
    assert d._get_value('d', 0) == ''

# Generated at 2022-06-20 12:41:11.074618
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var1 = BaseVariable('name')
    var2 = BaseVariable('name')
    var3 = BaseVariable('age', exclude='__repr__')
    var4 = BaseVariable('age', exclude='__repr__')

    assert(var1.__hash__() == var2.__hash__())
    assert(var3.__hash__() == var4.__hash__())
    assert(var1.__hash__() != var3.__hash__())



# Generated at 2022-06-20 12:41:16.430363
# Unit test for constructor of class Keys
def test_Keys():
    k1 = Keys('a')
    k2 = Keys('a')
    assert k1 is not k2
    assert k1 != k2
    assert hash(k1) == hash(k2)
    assert hash(Keys('a')) != hash(Keys('b'))
    assert hash(Keys('a')) != hash(Keys('a', exclude=['c']))
    assert hash(Keys('a', exclude=['c'])) == hash(Keys('a', exclude=('c',)))
    assert hash(Keys('a', exclude=['b', 'c', 'x'])) == hash(Keys('a', exclude=['c', 'b', 'x']))
    assert hash(Keys('a', exclude=['c'])) != hash(Keys('a', exclude=['c', 'b']))

# Generated at 2022-06-20 12:41:27.470386
# Unit test for constructor of class Attrs
def test_Attrs():
    # main_value: main_value to be evaluated
    main_value = len
    # source: source to be constructed
    source = 'len'
    attrs = Attrs(source)
    assert attrs.source == source
    # source_code: source code
    source_code = compile(source, '<variable>', 'eval')
    assert attrs.code == source_code
    # main_value_items: result from main_value.items
    main_value_items = attrs.items(main_value)
    assert main_value_items[0][0] == source
    assert main_value_items[0][1] == repr(main_value)
    assert main_value_items[1][0] == '(len).__call__'

# Generated at 2022-06-20 12:41:31.440020
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test():
        x = {'a': 'foo'}
        y = ['bar']
        variables = [
            Attrs('x'),
            Keys('x'),
            Indices('y'),
            Exploding('y'),
            Exploding('x')
        ]
        for v in variables:
            print('{}:'.format(str(v)))
            print(', '.join('{}: {}'.format(name, value) for name, value in v.items(locals())))
    test()



# Generated at 2022-06-20 12:41:37.478014
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable("a")) == hash(BaseVariable("a"))
    assert hash(BaseVariable("a")) != hash(BaseVariable("b"))
    assert hash(BaseVariable("a")) != hash(BaseVariable("a", ("a",)))
    assert hash(BaseVariable("a")) == hash(BaseVariable("a[a]"))
    assert hash(BaseVariable("a")) != hash(BaseVariable("a[b]"))
    assert hash(BaseVariable("a")) == hash(BaseVariable("a", ("a",))[1:])
    assert hash(BaseVariable("a")) != hash(BaseVariable("a", ("a",))[2:])


# Generated at 2022-06-20 12:41:46.146577
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert needs_parentheses('foo()')
    assert not needs_parentheses('(foo)')
    assert not needs_parentheses('(foo())')
    assert needs_parentheses('foo.bar')
    assert needs_parentheses('foo.bar()')
    assert not needs_parentheses('(foo).bar')
    assert not needs_parentheses('(foo).bar()')
    assert not needs_parentheses('(foo().bar)')
    assert not needs_parentheses('(foo().bar())')
    assert needs_parentheses('foo.bar.baz')
    assert needs_parentheses('foo.bar.baz()')
    assert not needs_parentheses('(foo).bar.baz')
    assert not needs_parentheses('(foo).bar.baz()')

# Generated at 2022-06-20 12:41:48.515145
# Unit test for constructor of class Exploding
def test_Exploding():
    e=Exploding("abc")
    print(type(e))
    print(e.source)
    print(e.exclude)
    print(e.code)


# Generated at 2022-06-20 12:41:53.492816
# Unit test for constructor of class Attrs
def test_Attrs():
    abc = Attrs('a.b.c')
    assert abc.source == 'a.b.c'
    assert abc.exclude == ()
    assert abc.code == compile('a.b.c', '<variable>', 'eval')
    assert abc.unambiguous_source == 'a.b.c'



# Generated at 2022-06-20 12:42:00.902344
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # if source is for Attrs (like 'a.')
    a=test_Class()
    a.b='test'
    assert CommonVariable('a')._items(a)==[
        ('a.', '<test_Class>'),
        ('a.b', 'test'),
    ]
    assert CommonVariable('a', exclude='b')._items(a)==[('a.', '<test_Class>')]
    assert CommonVariable('a', exclude=['b'])._items(a)==[('a.', '<test_Class>')]

    # if source is for Keys (like 'a[')
    a=dict(b='test')
    assert CommonVariable('a')._items(a)==[
        ('a[', '<dict>'),
        ('a["b"]', 'test'),
    ]

# Generated at 2022-06-20 12:42:26.420161
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('x')
    ans = k._keys({'a':1,'b':2,'c':3})
    assert ans == ['a','b','c']

# Generated at 2022-06-20 12:42:27.893335
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('foo')
    assert indices._slice == slice(None)
    indices = indices[1:4]
    assert indices._slice == slice(1, 4)

# Generated at 2022-06-20 12:42:30.385972
# Unit test for constructor of class Keys
def test_Keys():
    v = Keys('k1', exclude=['a', 'b'])
    assert v.source == 'k1', '%s != %s' % (v.source, 'k1')
    assert v.exclude == ('a', 'b'), '%s != %s' % (v.exclude, ('a', 'b'))

# Generated at 2022-06-20 12:42:36.502764
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert needs_parentheses('a().b')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a).b.c')
    assert needs_parentheses('a(b)')
    assert not needs_parentheses('(a)(b)')
    assert needs_parentheses('a[b]')
    assert not needs_parentheses('(a)[b]')
    assert needs_parentheses('a[b].x')
    assert not needs_parentheses('(a[b]).x')
    assert not needs_parentheses('((a[b])).x')


# Generated at 2022-06-20 12:42:44.569326
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    p = BaseVariable("a", (1,2))
    q = BaseVariable("a", (1,2))
    assert p.__hash__() == q.__hash__()
    q = BaseVariable("a", (1,))
    assert p.__hash__() != q.__hash__()
    q = BaseVariable("b", (1,2))
    assert p.__hash__() != q.__hash__()
    q = BaseVariable("a")
    assert p.__hash__() != q.__hash__()


# Generated at 2022-06-20 12:42:49.749739
# Unit test for constructor of class Attrs
def test_Attrs():
    test_dict = {}
    test_dict['a'] = 1
    test_dict['b'] = 2
    test_dict['c'] = 3
    test_dict_str = Attrs('test_dict')
    assert test_dict_str.items(locals()) == [('test_dict', '{...}'), ('test_dict.a', '1'), ('test_dict.b', '2'), ('test_dict.c', '3')]

# Generated at 2022-06-20 12:42:53.342917
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
	source = 'key1.subkey1'
	exclude = 'subkey1'
	variable = CommonVariable(source,exclude)
	assert variable.source == source
	assert variable.exclude == ('subkey1',)


# Generated at 2022-06-20 12:42:58.495195
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding("self", exclude="spam")
    assert var.__dict__ == {'source': 'self', 'exclude': ('spam',), 'code': compile('self', '<variable>', 'eval'), 'unambiguous_source': 'self'}
    assert var._items("self") == [('self', "'self'")]



# Generated at 2022-06-20 12:43:01.587580
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from pickle import loads, dumps
    assert loads(dumps(BaseVariable('x'))).__hash__() == BaseVariable('x').__hash__()


# Generated at 2022-06-20 12:43:04.527284
# Unit test for constructor of class Indices
def test_Indices():
    # Given
    a = Indices("i")

    # When
    b = a[:]

    # Then
    assert a._slice == slice(None)
    assert b._slice == slice(None)

# Generated at 2022-06-20 12:43:54.233060
# Unit test for constructor of class Indices
def test_Indices():
    indexes = Indices('', ())

    assert isinstance(indexes, Indices)
    assert isinstance(indexes, BaseVariable)
    assert indexes.source == ""
    assert indexes.exclude == ()



# Generated at 2022-06-20 12:44:03.731295
# Unit test for constructor of class Exploding
def test_Exploding():
    test_variable = {'a': {'b': [1, 2, 3]}}
    test_code = 'a.b[0]'
    assert Attrs(test_code, ('a.b',)).items(test_variable) ==\
                                                         [('a.b', '[1, 2, 3]')]
    assert Keys(test_code, ('a.b',)).items(test_variable) == [('a.b[0]', '1')]
    assert Indices(test_code, ('a.b',)).items(test_variable) == [('a.b[0]', '1')]
    assert Exploding(test_code, ('a.b',)).items(test_variable) == \
                                                            [('a.b[0]', '1')]
    # test __getitem__ method

# Generated at 2022-06-20 12:44:09.657432
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'a'
    exclude = ()
    source2 = 'b'
    exclude2 = ()
    variable = BaseVariable(source, exclude)
    variable2 = BaseVariable(source, exclude)
    variable3 = BaseVariable(source2, exclude)
    variable4 = BaseVariable(source, exclude2)
    variable5 = BaseVariable(source2, exclude2)

    assert variable == variable2
    assert variable != variable3
    assert variable != variable4
    assert variable != variable5


# Generated at 2022-06-20 12:44:16.670385
# Unit test for constructor of class Indices
def test_Indices():
    """ test the constructor of Indices
    """
    from . import pycompat

    # class Indices
    class_Indices = Indices('<arg>', exclude=())

    # object class object
    cls_object = object
    if pycompat.PY3:
        cls_object = type
    assert cls_object == type(class_Indices)

    return


# Generated at 2022-06-20 12:44:25.500016
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    d = {'a': 'b'}
    y = [1,2,3]
    x = 'abc'
    x = {'a': 'b', 'c': 'd'}
    key = 'a'

    t = Attrs('d')
    s = Keys('y')
    r = Indices('x')
    w = Attrs('x')
    v = Keys('x')
    u = Indices('x')
    a = Exploding('x')

    assert t.items(d) == s.items(y) == r.items(x) == w.items(x) == v.items(x) == u.items(x) == a.items(x)["y"] == [('d', "{'a': 'b'}"), ('d.a', "'b'")]
    assert t.items

# Generated at 2022-06-20 12:44:33.603144
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class SubClass(BaseVariable):
        def _items(self, main_value, normalize=False):
            return main_value
    o1 = SubClass('source')
    o2 = SubClass('source')
    o3 = SubClass('source', exclude='exclude')
    o4 = SubClass('source', exclude='exclude')
    o5 = SubClass('source2', exclude='exclude')
    o6 = SubClass('source2', exclude='exclude')
    assert o1 == o2
    assert o3 == o4
    assert o5 == o6
    assert o1 != o3
    assert o1 != o5
    assert o1 != o6

# Generated at 2022-06-20 12:44:38.561577
# Unit test for constructor of class Keys
def test_Keys():
    m = {'a':1, 'b':2}
    k = Keys('m')
    assert k.source == 'm'
    assert k._safe_keys(m) == ['a', 'b']
    assert k.items(m) == [('m', '{...}'), ('m[a]', '1'), ('m[b]', '2')]


# Generated at 2022-06-20 12:44:47.546891
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import utils
    x = Exploding('x')
    assert x._items(utils.DictObject(k=2)) == [('x', '{k: 2}'), ('x[k]', '2')]
    assert x._items(utils.DictObject(u=2)) == [('x', '{u: 2}'), ('x[u]', '2')]
    assert x._items({'k': 2}) == [('x', '{k: 2}'), ('x[k]', '2')]
    assert x._items(utils.ListObject(2)) == [('x', '[2]'), ('x[0]', '2')]
    assert x._items([2]) == [('x', '[2]'), ('x[0]', '2')]


# Generated at 2022-06-20 12:44:49.674372
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a', exclude='b')
    assert a.source == 'a'
    assert a.exclude == ('b',)
    assert a.code
    assert a._fingerprint == (Attrs, 'a', ('b',))
    assert a.__class__.__doc__
    assert a.__doc__

# Generated at 2022-06-20 12:44:51.561176
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))


# Generated at 2022-06-20 12:47:13.609020
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    Keys('x').items(None)
    Indices('x')[1:].items(None)
    Attrs('x').items(None)
    Exploding('x').items(None)

# Generated at 2022-06-20 12:47:20.517311
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('1') is False
    assert needs_parentheses('1+1') is False
    assert needs_parentheses('()') is False
    assert needs_parentheses('dict') is True
    assert needs_parentheses('[]') is True
    assert needs_parentheses('{}') is True
    assert needs_parentheses('(dict)') is False
    assert needs_parentheses('(dict,)') is True
    assert needs_parentheses('(dict, 1)') is False
    assert needs_parentheses('(dict, 1,)') is True
    assert needs_parentheses('(dict,)[a]') is True
    assert needs_parentheses('(dict, 1)[a]') is False

# Generated at 2022-06-20 12:47:30.631078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import logging
    logger = logging.getLogger(__name__)
    frame = logging.Logger.call(logger, "makeRecord", 'hello','world', '1')
    frame = frame.f_back
    print(frame) # debug
    print(frame.f_code)
    print(frame.f_code.co_name)
    print(frame.f_locals)
    print(frame.f_globals)
    print(dir(frame))
    if 'logger' in frame.f_code.co_names:
        class BaseVariable1(BaseVariable):
            def _items(self, key, normalize=False):
                return ()
        test = BaseVariable1(source='logger', exclude=())
        print(type(test))
        print(test.source)

# Generated at 2022-06-20 12:47:40.047237
# Unit test for constructor of class Attrs
def test_Attrs():

    # Initialize Attrs object attr_var with source as 'name' and exlude as 'phone'
    name = 'Dwayne'
    attr_var = Attrs('name', exclude='phone')
    # All the attributes in this case are private
    attr_var.__source__ = 'Dwayne'
    attr_var.__exclude__ = 'phone'

    # All the attributes of attr_var should match the attributes of name
    assert attr_var.__source__ == name
    assert attr_var.__exclude__ == 'phone'

    # Test the items method
    assert attr_var._items(name) == ['Dwayne']
    assert attr_var._format_key(name) == '.'
    assert attr_var._get_value(name) == 'Dwayne'

# Unit

# Generated at 2022-06-20 12:47:49.332370
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pytest
    from contextlib import contextmanager

    @contextmanager
    def no_stderr(monkeypatch):
        stderr = sys.stderr
        monkeypatch.setattr(sys, 'stderr', None)
        yield
        monkeypatch.setattr(sys, 'stderr', stderr)

    class dummy:
        pass

    with no_stderr(pytest.monkeypatch):
        a = dummy()
        a.b = 1
        a.c = None
        a.d = 'some string'


# Generated at 2022-06-20 12:47:54.760036
# Unit test for constructor of class Indices
def test_Indices():
    iv = Indices('foo')
    assert iv.source == 'foo'
    assert iv._slice == slice(None)
    iv = Indices('foo', exclude='bar')
    assert iv.source == 'foo'
    assert iv.exclude == ('bar',)
    assert iv._slice == slice(None)
    iv = Indices('foo', slice(1, 2))
    assert iv.source == 'foo'
    assert iv._slice == slice(1, 2)


# Generated at 2022-06-20 12:47:56.455183
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable("x")
    assert hash(v._fingerprint) == hash(v)


# Generated at 2022-06-20 12:48:00.908167
# Unit test for constructor of class Exploding
def test_Exploding():
    # Unit test for constructor of class Exploding
    test_variable = Exploding("a[0]")
    assert test_variable.source == "a[0]"
    assert test_variable.exclude == ()
    assert test_variable.code
    assert test_variable.unambiguous_source == '(a[0])'


# Generated at 2022-06-20 12:48:10.074477
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('x.')
    assert needs_parentheses('x.y.z.a[b]')
    assert needs_parentheses('x.y.z.a[b,c]')
    assert not needs_parentheses('x.y.z.a(b)')
    assert not needs_parentheses('x.y.z.a(b,c)')
    assert needs_parentheses('x.y.z.a(b,c).d')
    assert not needs_parentheses('x[y]')
    assert needs_parentheses('x[y].z')
    assert not needs_parentheses('x(y)')
    assert needs