

# Generated at 2022-06-20 12:38:27.846386
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    x = BaseVariable(source='name')
    assert hash(x) == hash(BaseVariable(source='name'))
    assert hash(x) != hash(BaseVariable(source='name1'))
    assert hash(x) == hash(BaseVariable(source='name', exclude=(1,)))

    x = Attrs(source='name')
    assert hash(x) == hash(Attrs(source='name'))
    assert hash(x) != hash(Attrs(source='name1'))
    assert hash(x) == hash(Attrs(source='name', exclude=(1,)))

    x = Keys(source='name')
    assert hash(x) == hash(Keys(source='name'))
    assert hash(x) != hash(Keys(source='name1'))

# Generated at 2022-06-20 12:38:38.088565
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    lst = []
    var1 = Attrs('a')
    lst.append(var1)
    var2 = Attrs('a')
    lst.append(var2)
    var3 = Attrs('b')
    lst.append(var3)
    var4 = Keys('c')
    lst.append(var4)
    var5 = Keys('c')
    lst.append(var5)
    var6 = Indices('d')
    lst.append(var6)
    var7 = Indices('d')
    lst.append(var7)
    var8 = Exploding('e')
    lst.append(var8)
    var9 = Exploding('e')
    lst.append(var9)
    var10 = Attrs('a', exclude='x')
   

# Generated at 2022-06-20 12:38:39.294921
# Unit test for constructor of class Indices
def test_Indices():
    obj = Indices("obj")
    assert(obj is not None)

# Generated at 2022-06-20 12:38:41.724828
# Unit test for constructor of class Exploding
def test_Exploding():
    from .utils import Frame
    e = Exploding('e')
    assert list(e.items(Frame(), normalize=True)) == [('e', '{}')]



# Generated at 2022-06-20 12:38:47.847312
# Unit test for constructor of class Indices
def test_Indices():

    #Case 1: slice starts from 0
    a = Indices(source="a", exclude="a")

    #Case 2: slice starts from 1
    b = Indices(source="a", exclude="a")[1:]
    assert isinstance(b, Indices)
    assert isinstance(b._slice, slice)
    assert b._slice.start == 1
    assert b._slice.stop == None
    assert b._slice.step == 1

# Generated at 2022-06-20 12:38:50.027358
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('a[0]', exclude=(1, 2)) != Indices('a[1]', exclude=(1, 2))



# Generated at 2022-06-20 12:38:54.537603
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {'key1' : 'value1', 'key2' : 'value2'}
    x = Exploding('test')
    x1 = x._items(main_value)
    if not isinstance(x1, tuple):
        raise RuntimeError("Exploding's constructor returns incorrect value")


# Generated at 2022-06-20 12:38:56.928090
# Unit test for constructor of class Exploding
def test_Exploding():
    assert (Exploding("x").items(sys._getframe(0))) == [(u'x', u'\'hello\'')]


# Generated at 2022-06-20 12:39:04.005167
# Unit test for constructor of class Attrs
def test_Attrs():
    main_value = dict(a=1, b=2, c=3)
    v = Attrs('main_value')
    assert v.items(dict(main_value=main_value, some_other_value=0)) == [
        ('main_value', '{a: 1, b: 2, c: 3}'),
        ('main_value.a', '1'),
        ('main_value.b', '2'),
        ('main_value.c', '3'),
    ]



# Generated at 2022-06-20 12:39:05.218699
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('x')
    a[3:5]



# Generated at 2022-06-20 12:39:21.493056
# Unit test for constructor of class Attrs
def test_Attrs():
    import os, sys

    # https://stackoverflow.com/questions/931092/reverse-a-string-in-python
    def reverse(string):
        return string[::-1]

    # https://stackoverflow.com/questions/19957962/how-to-use-sys-within-a-function
    def get_sys():
        return sys

    os_attr = Attrs('os')
    s = reverse('abc')
    sys_attr = Attrs('sys')
    module_name = 'builtins'
    sys_module_attr = Attrs('sys.modules')
    sys_module_module_attr = Attrs('sys.modules.' + module_name)

    # Test os_attr
    os_attr_result = os_attr.items(os)

# Generated at 2022-06-20 12:39:28.898949
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class MyBaseVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            return ()

    assert MyBaseVariable.__hash__ != BaseVariable.__hash__

# Generated at 2022-06-20 12:39:33.944973
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    def equal_hash(obj1, obj2):
        return hash(obj1) == hash(obj2)

    a1 = BaseVariable('a', 'b')
    assert equal_hash(a1, BaseVariable('a', 'b'))
    assert not equal_hash(a1, BaseVariable('a'))
    assert not equal_hash(a1, BaseVariable('b'))

    b1 = BaseVariable('b', ['c'])
    assert equal_hash(b1, BaseVariable('b', ['c']))
    assert not equal_hash(b1, BaseVariable('b'))
    assert not equal_hash(b1, BaseVariable('b', 'c'))
    assert not equal_hash(b1, BaseVariable('b', 'c', 'd'))


# Generated at 2022-06-20 12:39:39.092425
# Unit test for constructor of class Attrs
def test_Attrs():
    sut = Attrs('x')
    assert sut.source == 'x'
    assert sut.exclude == ()
    assert sut.code == compile('x', '<variable>', 'eval')
    assert sut.unambiguous_source == 'x'


# Generated at 2022-06-20 12:39:42.456213
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "a.b.c"
    exclude = ['b']
    test = BaseVariable(source, exclude)
    if isinstance(test, BaseVariable):
        print("Test of BaseVariable constructor is successful")


# Generated at 2022-06-20 12:39:43.435527
# Unit test for constructor of class Attrs
def test_Attrs():
    D = Attrs(0)


# Generated at 2022-06-20 12:39:50.503447
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('d')
    assert a.source == 'd'
    assert a.exclude == ()
    assert a.unambiguous_source == 'd'
    assert a.code == compile('d', '<variable>', 'eval')
    assert a._fingerprint == (Attrs, 'd', ())

    a = Attrs('d', 'foo')
    assert a.source == 'd'
    assert a.exclude == ('foo',)
    assert a.unambiguous_source == 'd'
    assert a.code == compile('d', '<variable>', 'eval')
    assert a._fingerprint == (Attrs, 'd', ('foo',))


# Generated at 2022-06-20 12:39:54.370139
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1] == Indices('a', slice(1,None))
    assert Indices('a')[1:] == Indices('a', slice(1,None))
    assert Indices('a')[::] == Indices('a', slice(None,None)) 
    assert Indices('a')[::-1] == Indices('a', slice(None,None, -1))

# Generated at 2022-06-20 12:39:57.801066
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'abc'
    frame = None
    normalize = None
    var = BaseVariable(source, exclude=())
    result = var.items(frame, normalize)
    assert result is not None


# Generated at 2022-06-20 12:40:06.011988
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('var1', '')
    var2 = BaseVariable('var2', '')
    var2_1 = BaseVariable('var1', '')
    var3 = BaseVariable('var3', '')
    assert(var1 == var2_1)
    assert(var2 == var2_1)
    assert(var1 != var2)
    assert(var1 != var3)
    assert(var2 != var3)
    assert(var2_1 != var3)

# Generated at 2022-06-20 12:40:13.429392
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('f')
    assert needs_parentheses('1')
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('(x).y')



# Generated at 2022-06-20 12:40:22.580478
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == 'a'
    assert a.exclude == ()
    assert Attrs('a', ('b', 'c')).exclude == ('b', 'c')
    assert Attrs('a', exclude=('b', 'c')).exclude == ('b', 'c')
    assert Attrs('a', 'b').exclude == ('b', )

# Generated at 2022-06-20 12:40:24.855961
# Unit test for constructor of class Keys
def test_Keys():
  k = Keys("my_key")
  assert k.source == "my_key"
  assert k.exclude == tuple()


# Generated at 2022-06-20 12:40:29.789034
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('keys', 'exclude')
    assert keys.source == 'keys'
    assert keys.exclude == 'exclude'
    assert keys.unambiguous_source == 'keys'
    assert keys._fingerprint[0] == Keys
    assert keys._fingerprint[1] == 'keys'
    assert keys._fingerprint[2] == 'exclude'


# Generated at 2022-06-20 12:40:38.068052
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a= {'x':1,'y':2}
    b = [1,2,3,4]
    c = (1,2,3,4)
    d = 1
    e = Attrs('a').items(1)
    f = Keys('a').items(a)
    g = Indices('b').items(b)
    h = Indices('c')[0:3].items(c)
    j = Indices('d')[0:3].items(d)
    k = Exploding('d').items(d)
    assert e == [('a', '1')], 'tests for method items of BaseVariable is failed!'
    assert f == [('a', "{'x': 1, 'y': 2}"), ("a['x']", '1'), ("a['y']", '2')]
    assert g

# Generated at 2022-06-20 12:40:40.595941
# Unit test for constructor of class Indices
def test_Indices():
    assert list(Indices('x')._items([1,2,3,4])) == [('x[0]', '1'), ('x[1]', '2'), ('x[2]', '3'), ('x[3]', '4')]

# Generated at 2022-06-20 12:40:44.167490
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    global class_BaseVariable
    class_BaseVariable = BaseVariable
    class_BaseVariable.__hash__ = BaseVariable.__hash__.im_func
    global _fingerprint
    _fingerprint = class_BaseVariable._fingerprint
    assert any([class_BaseVariable.__hash__(class_BaseVariable) is e for e in xrange(10000000)])


# Generated at 2022-06-20 12:40:48.077598
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('x')
    var = BaseVariable('x', exclude=['a'])
    assert needs_parentheses('x') == False
    assert needs_parentheses('x[1]') == True
    assert needs_parentheses('(x)') == False
    assert needs_parentheses('((x))') == True
    assert needs_parentheses('x.a') == False
    assert needs_parentheses('(x).a') == False



# Generated at 2022-06-20 12:40:57.076180
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo') == False
    assert needs_parentheses('foo.bar.baz') == False
    assert needs_parentheses('foo().bar') == True
    assert needs_parentheses('foo.bar().baz') == True
    assert needs_parentheses('foo[1].baz') == False
    assert needs_parentheses('foo[1:2:3].baz') == False
    assert needs_parentheses('foo[bar].baz') == True
    assert needs_parentheses('foo[bar:baz:bat].bat') == True
    assert needs_parentheses('foo.bar[1]') == True
    assert needs_parentheses('foo.bar[1:2:3]') == True
    assert needs_parentheses('foo.bar[bat]') == True

# Generated at 2022-06-20 12:41:06.086164
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'source'
    main_value = 'main_value'
    exclude = 'exclude'

    # test for Mapping
    main_value = {'a': 'b'}
    class_Exploding = Exploding(source, exclude)
    class_Keys = Keys(source, exclude)
    assert class_Exploding._items(main_value) == class_Keys._items(main_value)

    # test for Sequence
    main_value = ['a', 'b', 'c']
    class_Exploding = Exploding(source, exclude)
    class_Indices = Indices(source, exclude)
    assert class_Exploding._items(main_value) == class_Indices._items(main_value)

    # test for others
    main_value = 'abc'

# Generated at 2022-06-20 12:41:19.732687
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable("ERROR")
    b = BaseVariable("ERROR")
    c = BaseVariable("ERROR", "hello")
    print(hash(a) == hash(b), hash(a) == hash(c))

# Generated at 2022-06-20 12:41:29.543441
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from types import FrameType
    from inspect import getframeinfo
    frame = getframeinfo(FrameType(None, '/test.py', 'test_frame', 1, None, None))

    def _assert(var, expected):
        actual = Indices(var).items(frame)
        for i, (actual_key, actual_value) in enumerate(actual):
            expected_key, expected_value = expected[i]
            assert actual_key == expected_key, '{} vs. {}'.format(actual_key, expected_key)
            assert actual_value == expected_value, '{} vs. {}'.format(actual_value, expected_value)


# Generated at 2022-06-20 12:41:32.969011
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('variable')
    var[:]

    for i in range(-10, 10):
        var[:i]

# Generated at 2022-06-20 12:41:35.217269
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('source')
    result = indices[:]
    assert isinstance(result._slice, slice)


# Generated at 2022-06-20 12:41:38.957076
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs('self', ('exclude',))
    assert attr.source == 'self'
    assert attr.exclude == ('exclude',)
    assert attr.unambiguous_source == 'self'
    assert attr.code == compile('self', '<variable>', 'eval')


# Generated at 2022-06-20 12:41:47.837901
# Unit test for constructor of class Exploding
def test_Exploding():
    class MyExploding(Exploding):
        def __init__(self, source, exclude=()):
            super(Exploding, self).__init__(source, exclude)

    class MyMapping(Mapping):
        def __init__(self, items, exclude=()):
            self.items = items
            self.exclude = exclude

        def __len__(self):
            return len(self.items)

        def __iter__(self):
            return iter(self.items)

        def __getitem__(self, item):
            return self.items[item]

    me = MyExploding('name')
    assert(me._items({'a':1,'b':2}) == [('name', {'a':1,'b':2})])

# Generated at 2022-06-20 12:41:51.377896
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variablename = 'test_bv_items'
    classname = 'basevariable_testcase'

# Generated at 2022-06-20 12:41:59.759873
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    from . import utils

    def create_CommonVariable(source=None, exclude=None):
        variable = CommonVariable(source, exclude)
        variable.source = source
        variable.exclude = exclude
        variable.code = compile(source, '<variable>', 'eval')
        if needs_parentheses(source):
            variable.unambiguous_source = '(' + source + ')'
        else:
            variable.unambiguous_source = source
        return variable

    def create_dict(key, value):
        d = dict()
        d[key] = value
        return d

    # Test with basic assignment
    a = 3
    a_variable = create_CommonVariable('a')

# Generated at 2022-06-20 12:42:05.518125
# Unit test for constructor of class Keys
def test_Keys():
    s = 'pkt.protocol.etherType'
    keys = Keys(s)
    assert keys.source == s
    assert keys.exclude == ()
    assert keys.code == compile(s,'<variable>','eval')
    assert keys.unambiguous_source == 'pkt.protocol.etherType'


# Generated at 2022-06-20 12:42:08.423252
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable('source', 'name')
    b = BaseVariable('source', 'name')
    c = BaseVariable('source', 'name')

    assert hash(a) == hash(b) == hash(c)


# Generated at 2022-06-20 12:42:32.705329
# Unit test for constructor of class Attrs
def test_Attrs():
    try:
        import pprint
        pprint.pprint("test")
    except Exception as e:
        a = Attrs("pprint.pprint(\"test\")")
        print(a.items(e.__traceback__.tb_frame, normalize=False))

if __name__ == "__main__":
    test_Attrs()

# Generated at 2022-06-20 12:42:34.503558
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    CommonVariable("a",("b","c"))

# Unit tests for constructor of class Attrs

# Generated at 2022-06-20 12:42:42.485413
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'foo'
    # Check if isinstance of BaseVariable
    assert issubclass(Exploding, BaseVariable)
    # Check if instance of Exploding
    assert isinstance(Exploding(source), BaseVariable)
    # Check if instance of Exploding
    assert isinstance(Exploding(source), Exploding)
    # Check if instance of BaseVariable
    assert isinstance(Exploding(source), BaseVariable)
    # Check if it is a variable
    assert isinstance(Exploding(source), BaseVariable)


# Generated at 2022-06-20 12:42:49.891757
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = ["True", "False"]
    assert(BaseVariable("1") == BaseVariable("1"))
    assert(BaseVariable("1") == BaseVariable("2"))
    assert(BaseVariable("1", ("1",)) == BaseVariable("1", ("2",)))
    # assert(BaseVariable("asdfg", ("1",)) is BaseVariable("asdfg", ("2",)))
    x = ["True", "False"]
    assert(BaseVariable("asdfg", ("1",)) == BaseVariable("asdfg", ("2",)))
    # assert(BaseVariable("[1, 2]", ("1",)) is BaseVariable("[1, 2]", ("2",)))
    x = ["True", "False"]

# Generated at 2022-06-20 12:42:54.638142
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .pdb_clone import FakeFrame
    from . import utils
    #base_variable = BaseVariable()
    frame = FakeFrame(utils.python_file_for_test, 'main')
    source = "frame"
    exclude = ()
    base_variable = BaseFrame(source, exclude)
    #return base_variable.items(frame)

# Generated at 2022-06-20 12:43:00.568571
# Unit test for constructor of class Keys
def test_Keys():
    my_dict = {1:2, 3:4}
    my_attrs = Attrs('my_attrs')
    my_keys = Keys('my_keys')
    assert my_attrs._fingerprint == my_attrs._fingerprint
    assert my_keys._fingerprint == my_keys._fingerprint
    assert my_dict.keys() == [1, 3]

# Generated at 2022-06-20 12:43:09.128699
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo.bar') == Keys('foo.bar')
    assert Keys('foo.bar') != Keys('bar.bar')
    assert Keys('foo.bar') != Keys('foo.baz', exclude=('bar',))
    assert Keys('foo.bar', exclude=('bar',)) != Keys('foo.bar')

    assert (hash(Keys('foo.bar')) == hash(Keys('foo.bar')) ==
            hash(Keys('foo.bar', exclude=('bar',))) ==
            hash(Keys('foo.bar', exclude=('baz',))) !=
            hash(Keys('bar.bar')) !=
            hash(Keys('foo.baz', exclude=('bar',))))

    assert (Keys('foo.bar') != Attrs('foo.bar'))

# Generated at 2022-06-20 12:43:11.025911
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
	assert Indices('a', 'exclude').__getitem__(slice(None)) == Indices('a', 'exclude')

# Generated at 2022-06-20 12:43:20.035127
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def func(x):
        class A(object):
            def __init__(self, x):
                self.x = x
        return A(x)

    frame = inspect.currentframe()

# Generated at 2022-06-20 12:43:21.338095
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    print(a)



# Generated at 2022-06-20 12:44:05.280777
# Unit test for constructor of class Keys
def test_Keys():
    literal_eval("Keys('x')")
    literal_eval("Keys('x', exclude='y')")
    literal_eval("Keys('x', exclude=('y',))")
    literal_eval("Keys('x', exclude=('y', 'z'))")
    literal_eval("Keys('something.with_a_dot')")



# Generated at 2022-06-20 12:44:07.075190
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding("a").source == "a"
    assert Exploding("a", "b").exclude == ("b",)

# Generated at 2022-06-20 12:44:12.423445
# Unit test for constructor of class Exploding
def test_Exploding():
    assert type(Exploding('a').source) == type('a')
    assert type(Exploding(1).source) == type('1')
    assert type(Exploding(None).source) == type('None')
    assert type(Exploding(True).source) == type('True')
    assert type(Exploding(False).source) == type('False')


# Generated at 2022-06-20 12:44:23.552893
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = [1,2]
    g = {'x':x}
    l = {'x':x}
    frame = pycompat.next_frame(skip=1)
    frame.f_globals.update(g)
    frame.f_locals.update(l)
    # original version
    # bv_x = [BaseVariable(v) for v in ['x','x[0]','x[0].x','x[0].x[1]','x[1]','x[1].x','x[1].x[0]','x[1].x[1]']]
    # for bv in bv_x:
    #     assert type(bv.items(frame)) == tuple
    # bv = BaseVariable('x', exclude=['x[1]'])
    # assert type(b

# Generated at 2022-06-20 12:44:26.707180
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print('Start test_Indices___getitem__')
    var = BaseVariable('', '')
    var = Indices('', '')
    print(var)
    
    attrs = Attrs('','')
    print(attrs)
    print('End test_Indices___getitem__')


# Generated at 2022-06-20 12:44:35.316611
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    base = BaseVariable('source', 'exclude')
    assert base.source == 'source'
    assert base.exclude == 'exclude'
    assert base.code.co_code == compile('source','<variable>','eval').co_code
    assert base.unambiguous_source == 'source'

##############################################################################
# Python 2 backwards compatibility

if not pycompat.PY3:

    def compile(code, name, mode, flags=0, dont_inherit=0):
        return compile(code, name, mode)

##############################################################################
#

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 12:44:41.551237
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('a().b.c')
    assert not needs_parentheses('a(b).c')
    assert not needs_parentheses('a(b()).c')

    assert needs_parentheses('(a).b.c')
    assert needs_parentheses('(a.b).c')
    assert needs_parentheses('a(b).c.d')
    assert needs_parentheses('a().b.c().d')


# Generated at 2022-06-20 12:44:45.668867
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        name = "dexinyan"
        age = 18
    a = A()
    assert Attrs("a")._items(a) == [('a', '<A object>'), ('a.age', '18'), ('a.name', '"dexinyan"')]


# Generated at 2022-06-20 12:44:53.796752
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = {'a': 1}

    # Default exclude is ()
    variable = CommonVariable('x')
    assert variable.exclude == ()
    # Cannot get keys of x because _keys() is abstract method
    assert variable.items(None) == [('x', '{...}')]

    # When exclude is a str, it becomes a one-element tuple
    variable = CommonVariable('x', exclude='a')
    assert variable.exclude == ('a',)
    assert variable.items(None) == [('x', '{...}')]

    # When exclude is a list, it becomes a tuple
    variable = CommonVariable('x', exclude=['a'])
    assert variable.exclude == ('a',)
    assert variable.items(None) == [('x', '{...}')]

    # Useful test case

# Generated at 2022-06-20 12:44:58.547603
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable('a')
    assert var.source == 'a'
    assert var.code is not None
    assert var.unambiguous_source == 'a'
    assert var.exclude == ()
    assert var.items(None) == ()


# Generated at 2022-06-20 12:47:20.261475
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a')
    assert k.source == 'a'
    assert k.exclude == ()


# Generated at 2022-06-20 12:47:30.200220
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('(x.y)')
    assert not needs_parentheses('x.y.z')
    assert needs_parentheses('(x.y).z')

    assert not needs_parentheses('x[y]')
    assert needs_parentheses('x[y].z')
    assert not needs_parentheses('x[y][z]')
    assert needs_parentheses('x[y].z[t]')

    assert not needs_parentheses('x()')
    assert needs_parentheses('x()[y]')
    assert not needs_parentheses('x()[y][z]')
    assert needs_parentheses('x()[y].z')

    assert not needs_parentheses('x()()')


# Generated at 2022-06-20 12:47:33.452439
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert repr(BaseVariable('foo.bar')) == "<BaseVariable 'foo.bar'>"


# Generated at 2022-06-20 12:47:38.195310
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import dis
    def f():
        pass
    code = compile('f', '<variable>', 'eval')
    print(dis.dis(code))
    variable = BaseVariable('f')
    print(dis.dis(variable.code))
    variable = BaseVariable('a.b', exclude=['f1'])
    print(dis.dis(variable.code))
    print(variable.source, variable.exclude)



# Generated at 2022-06-20 12:47:47.443314
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def test(left, right, result):
        assert (left == right) == result
        assert (right == left) == result

    test(Indices("v"), Indices("v"), True)
    test(Indices("v"), Indices("a"), False)
    test(Indices("v"), Indices("v", exclude="a"), False)
    test(Indices("v")[1:2], Indices("v")[1:2], True)
    test(Indices("v")[1:2], Indices("v")[2:3], False)
    test(Indices("v")[1:2], Indices("a")[1:2], False)
    test(Indices("v")[1:2], Indices("v", exclude="a")[1:2], False)



# Generated at 2022-06-20 12:47:48.906047
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indexes = Indices('')
    indexes[1:3]
    assert indexes._slice == slice(1,3)

# Generated at 2022-06-20 12:47:58.020085
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import classes
    from .fake import Fake

    def new_Exploding(source):
        return Exploding(source)

    # data structure do not change after constructor
    v1 = new_Exploding("0")
    assert v1.source == "0"

    # id of v1 is not changed after change data structure of v1
    v2 = new_Exploding("1")
    assert id(v1) != id(v2)

    # exploding is set to default
    v3 = new_Exploding("2")
    assert v3.exclude == ()

    # Test with fake
    fake = Fake(name="fake")
    fake.x = "x"
    fake.y = "y"

# Generated at 2022-06-20 12:48:06.932843
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    array = np.array([[0,1],[2,3]], dtype=np.int)
    variable_A = BaseVariable('array')
    variable_B = BaseVariable('array')
    assert isinstance(variable_A, BaseVariable)
    assert variable_A.source == 'array'
    assert variable_A._fingerprint == variable_B._fingerprint
    assert variable_A == variable_B
    assert hash(variable_A) == hash(variable_B)
    assert variable_A.code.co_filename == '<variable>'
    assert variable_A.code.co_name == '<module>'
    assert variable_A.unambiguous_source == 'array'
    assert variable_A.exclude == ()