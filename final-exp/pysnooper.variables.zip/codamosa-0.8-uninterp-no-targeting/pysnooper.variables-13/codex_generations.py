

# Generated at 2022-06-20 12:38:17.904883
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.x')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('(x).x')

# Generated at 2022-06-20 12:38:23.191703
# Unit test for constructor of class Exploding
def test_Exploding():
    evariable = Exploding("var_source", exclude=("var_exclude_1", "var_exclude_2"))
    assert evariable.source == "var_source"
    assert evariable.exclude == ("var_exclude_1", "var_exclude_2")
    assert evariable.code == compile('var_source', '<variable>', 'eval')
    assert evariable.unambiguous_source == '({})'.format("var_source")


# Generated at 2022-06-20 12:38:26.226148
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    assert (v.source, v._slice) == ('x', slice(None))
    v = v[1:]
    assert (v.source, v._slice) == ('x', slice(1, None))


# Generated at 2022-06-20 12:38:36.573298
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestBaseVariable(BaseVariable):
        __test__ = False

        def items(self, frame, normalize=False):
            return ()

    # Test for the same value
    assert TestBaseVariable('a') == TestBaseVariable('a')

    # Test for different source
    assert TestBaseVariable('a') != TestBaseVariable('b')

    # Test for different exclude but same source
    assert TestBaseVariable('a', 'b') != TestBaseVariable('a', 'c')

    # Test for same exclude but different source
    assert TestBaseVariable('a', 'b') != TestBaseVariable('b', 'b')

    # Test for different exclude and different source
    assert TestBaseVariable('a', 'b') != TestBaseVariable('b', 'c')



# Generated at 2022-06-20 12:38:39.804485
# Unit test for constructor of class Exploding
def test_Exploding():
    a = Exploding('a')._items
    b = Attrs('a')._items
    c = Keys('a')._items
    d = Indices('a')._items
    assert a(None) == b(None)
    assert a({}) == c({})
    assert a([]) == d([])



# Generated at 2022-06-20 12:38:50.130091
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    #The class Indices
    variable = Indices('variable', exclude=('x', 'y'))
    #The variable variable is a list
    variable_variable = [1, 2, 3, 4]
    #The variable frame is a dummy frame
    frame = type('', (), {})
    #The variable frame.f_globals is a dict
    frame.f_globals = {}
    #The variable frame.f_locals is a dict
    frame.f_locals = {'variable': variable_variable}

    #The result of function Indices.items
    result = variable.items(frame)

    #The expected result

# Generated at 2022-06-20 12:38:52.236723
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices("i")
    assert isinstance(var, Indices)
    assert var.source == "i"



# Generated at 2022-06-20 12:38:59.083221
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class SubCommonVariable(CommonVariable):
        def _keys(self, main_value):
            return main_value

    s = SubCommonVariable('x', exclude='bar')
    assert s.source == 'x'
    assert s.exclude == ('bar',)
    s.items({'x':[1,'foo',3]},True)
    assert s._fingerprint == (SubCommonVariable, 'x', ('bar',))
    assert hash(s) != None
    assert str(s) != None
    assert repr(s) != None
    assert s == SubCommonVariable('x', exclude='bar')
    assert not (s == SubCommonVariable('y', exclude='bar'))
    assert not (s == SubCommonVariable('x', exclude='foobar'))
    assert not (s == SubCommonVariable('x'))
    assert s

# Generated at 2022-06-20 12:39:01.240785
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('event["event_type"]', exclude=('deploy')).items({}, True) == [('event["event_type"]', 'deploy')]

# Generated at 2022-06-20 12:39:10.154497
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = BaseVariable
    # Test case 1
    # x.source = 'foo'
    # x.exclude = ()
    # frame.f_locals = {'foo': 'bar'}
    # x.code = compile(x.source, '<variable>', 'eval')
    # x.code.co_name = 'foo'
    # frame.f_locals = {'foo': 'bar'}
    # frame.f_locals[x.code.co_name] = 'bar'
    # main_value = frame.f_locals[x.code.co_name]
    # main_value = 'bar'
    # result = [(x.source, utils.get_shortish_repr(main_value, normalize=False))]
    # result = [('foo', 'bar')]

# Generated at 2022-06-20 12:39:16.660469
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a[0]')
    assert i.source == 'a[0]'

test_Indices()

# Generated at 2022-06-20 12:39:24.672178
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # test slice(0,1) as item
    indices = Indices('main_value')
    sliced_Indices = indices.__getitem__(slice(0,1))
    assert isinstance(sliced_Indices, Indices)
    assert sliced_Indices._slice == slice(0,1)
    # test slice(0,None) as item
    sliced_Indices = indices.__getitem__(slice(0,None))
    assert isinstance(sliced_Indices, Indices)
    assert sliced_Indices._slice == slice(0,None)

# Generated at 2022-06-20 12:39:34.477692
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    mocker.patch('pdbpp.pycompat', autospec=True)

    mocker.patch('pdbpp.utils.AllLabels')
    # TODO: use the following code if it works
    # mocker.patch('pdbpp.utils.AllLabels.__contains__', side_effect=Exception)
    mocker.patch('pdbpp.utils.AllLabels.__contains__')
    mocker.patch('pdbpp.utils.get_shortish_repr')

    bv = BaseVariable('testBaseVariable.test_BaseVariable___hash__')
    with pytest.raises(NotImplementedError):
        bv.items('frame')
    assert hash(bv) == hash((type(bv), bv.source, bv.exclude))



# Generated at 2022-06-20 12:39:45.329287
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('key', exclude=('p1', 'p2'))[1:5]
    assert str(indices) == 'Indices(key[1:5], exclude=("p1", "p2"))'
    assert hash(indices) == hash('Indices(key[1:5], exclude=("p1", "p2"))')
    assert indices.source == 'key'
    assert indices.exclude == ('p1', 'p2')
    assert indices._keys(['p1', 'p2', 'p3']) == range(1, 5)
    assert indices._format_key(1) == '[1]'
    assert indices._get_value(['p1', 'p2', 'p3'], 1) == 'p2'

# Generated at 2022-06-20 12:39:54.462750
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        pass
    def localclass():
        class B:
            pass
        return B
    a = A()
    a.b = localclass()
    a.b.c = localclass()
    a.b.d = [A(), A(), A()]
    a.e = [A(), A()]
    attr_test_var = Attrs("a")
    print(attr_test_var.items(frame = None))
    key_test_var = Keys("a.b.d")
    print(key_test_var.items(frame = None))
    index_test_var = Indices("a.e")
    print(index_test_var.items(frame = None))
    explode_test_var = Exploding("a.b")

# Generated at 2022-06-20 12:40:03.614436
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('x')
    assert x.source == 'x'
    assert x.exclude == ()
    assert str(x.code) == "b'\\x64\\x00\\x00\\x00\\x00\\x00\\x00\\x00x'"
    assert x.unambiguous_source == 'x'
    assert x.items(None) == []
    assert x._safe_keys(None) == []
    assert x._keys({'a': 1}) == ['a']
    assert x._format_key('a') == '[a]'
    assert x._get_value({'a': 1}, 'a') == 1


# Generated at 2022-06-20 12:40:07.649484
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = Attrs("PYTHONPATH")
    b = Attrs("PYTHONPATH")
    c = Attrs("os.environ")
    d = Attrs("os.environ")
    assert a == b
    assert c == d

# Generated at 2022-06-20 12:40:11.264535
# Unit test for constructor of class Keys
def test_Keys():
    dict_ = {"a": 1, "b": 2}
    keys = Keys("x", exclude = ())
    #keys = Keys("x", exclude = ("b", ))
    x = keys.items(dict_, normalize = False)
    print(x)


# Generated at 2022-06-20 12:40:13.866202
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # sequence = [1, 2, 3, 4]
    # indices = Indices('my_sequence')
    # indices[1:3]._slice
    #
    # # --> slice(1, 3, None)
    pass

# Generated at 2022-06-20 12:40:20.925640
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    try:
        CommonVariable()
    except Exception as err:
        assert 'Can\'t instantiate abstract class CommonVariable with abstract methods' in str(err)
        print('test_CommonVariable successfully passed')
    else:
        raise ValueError('test_CommonVariable did not successfully pass')


# Generated at 2022-06-20 12:40:26.868064
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('exception')
    assert var[:] == Indexes('exception')

# Generated at 2022-06-20 12:40:28.827800
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('var')
    v2 = v[::2]
    assert v2 != v


# Generated at 2022-06-20 12:40:33.469651
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('source')) == hash(BaseVariable('source'))
    assert hash(BaseVariable('source', 'exclude')) != hash(BaseVariable('source'))
    assert hash(BaseVariable('source')) != hash(BaseVariable('source', 'exclude'))
    assert hash(BaseVariable('source', 'exclude')) != hash(BaseVariable('source', 'exclude2'))



# Generated at 2022-06-20 12:40:37.694791
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') != BaseVariable('bar')
    assert BaseVariable('foo') == BaseVariable('foo', exclude=['bar'])
    assert BaseVariable('foo', exclude=['bar']) != BaseVariable('foo', exclude=['baz'])
    assert BaseVariable('foo', exclude=['bar']) != Attrs('foo', exclude=['bar'])



# Generated at 2022-06-20 12:40:45.393501
# Unit test for constructor of class Exploding
def test_Exploding():
    frame = {
        'x': 1,
        'y': '2',
        'z': [1, 2, 3],
        'w': {'a': 1, 'b': 2}
    }
    def variables_test(variables):
        for variable in variables:
            for item in variable.items(frame):
                print(item)
    # Unit test for instance of class Exploding
    variables = [
        Exploding("x"),
        Exploding("y"),
        Exploding("z"),
        Exploding("w")
    ]
    variables_test(variables)
    # Unit test for instance of class CommonVariable
    variables = [
        Attrs("x"),
        Attrs("y"),
        Indices("z"),
        Keys("w")
    ]
    variables_test(variables)

# Unit

# Generated at 2022-06-20 12:40:53.862298
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x[0]') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('(x)') == True
    assert needs_parentheses('x.y if x else y') == True
    assert needs_parentheses('(x.y if x else y)') == False
    assert needs_parentheses('x + 1') == True
    assert needs_parentheses('(x + 1)') == False
    assert needs_parentheses('x[y]') == False
    assert needs_parentheses('x[y:z]') == False
    assert needs_parentheses('x[y:z:a]') == False
    assert needs_parentheses('x[y::a]') == False

# Generated at 2022-06-20 12:40:58.484860
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    instance = BaseVariable('a')
    assert instance == instance

    assert instance != BaseVariable('b')
    assert instance != BaseVariable('a', exclude='foo')
    assert instance != BaseVariable('a', exclude=())
    assert instance != BaseVariable('a', exclude=('foo',))
    assert instance != BaseVariable('a', exclude=('bar',))


# Generated at 2022-06-20 12:41:04.709392
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def t(source='foo', exclude=(), global_variables={}, local_variables={}, expected=()):
        frame = utils.MockFrame(global_variables, local_variables)
        res = BaseVariable(source, exclude).items(frame)
        assert res == expected

    t('foo', {'foo': 'bar'}, expected=[('foo', 'bar')])
    t('f["bar"]', {'f': {'bar': 'baz'}}, expected=[('foo["bar"]', 'baz')])
    t('foo.bar', {'foo': {'bar': 'baz'}}, expected=[('foo.bar', 'baz')])

# Generated at 2022-06-20 12:41:11.039916
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys("x")
    assert x.source == 'x'
    assert x.exclude == ()

    x = Keys("x", "y")
    assert x.source == 'x'
    assert x.exclude == "y"

    x = Keys("x", ("y", "z"))
    assert x.source == 'x'
    assert x.exclude == ("y", "z")


# Generated at 2022-06-20 12:41:15.721347
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('name')
    keys = k._keys({'a':1, 'b':2})
    for key in keys:
        print(key)

    keys = k._keys([1,2,3,4,5])
    for key in keys:
        print(key)


# Generated at 2022-06-20 12:41:27.219040
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("a")
    assert (v1 == v1) is True


# Generated at 2022-06-20 12:41:29.517876
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable("var", "var1")
    var.source == "var"
    var.exclude == ("var1",)

'''
Test for eval_source in the class BaseVariable
    eval_source: compile(source, '<variable>', 'eval').co_code
'''

# Generated at 2022-06-20 12:41:37.949806
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a()') is True
    assert needs_parentheses('a().b') is False
    assert needs_parentheses('a()[2]') is True
    assert needs_parentheses('a[2]()') is False
    assert needs_parentheses('(a)') is False
    assert needs_parentheses('(a())') is False
    assert needs_parentheses('a().b.c') is False



# Generated at 2022-06-20 12:41:46.740169
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    codes = (
        'a',
        '1',
        'a + b + c',
        'a + b + c.d'
    )
    obj1 = CommonVariable(codes[0])
    obj2 = CommonVariable(codes[1])
    obj3 = CommonVariable(codes[2])
    obj4 = CommonVariable(codes[3])
    assert obj1.source == codes[0]
    assert obj2.source == codes[1]
    assert obj3.source == codes[2]
    assert obj4.source == codes[3]
    assert obj1.exclude == ()
    assert obj2.exclude == ()
    assert obj3.exclude == ()
    assert obj4.exclude == ()
    assert obj1.code != obj2.code
    assert obj2.code != obj3.code
   

# Generated at 2022-06-20 12:41:48.433811
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('x', 'y')
    assert keys
    assert not keys.__doc__


# Generated at 2022-06-20 12:41:54.107281
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a', 'b')) == hash(BaseVariable('a', 'b'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('a', 'b'))
    assert hash(BaseVariable('a', 'b')) != hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))


# Generated at 2022-06-20 12:42:00.092936
# Unit test for constructor of class Exploding
def test_Exploding():
    x = Exploding('a')
    assert x.__repr__() == "<Exploding: a>"
    assert x.source == 'a'
    assert x.exclude == ()
    assert x.unambiguous_source == 'a'
    assert x.code == compile('a', '<variable>', 'eval')
    assert needs_parentheses(x.source) is False
    x = Exploding('(a)')
    assert x.__repr__() == "<Exploding: (a)>"
    assert x.source == '(a)'
    assert x.exclude == ()
    assert x.unambiguous_source == '(a)'
    assert x.code == compile('(a)', '<variable>', 'eval')
    assert needs_parentheses(x.source) is False

# Generated at 2022-06-20 12:42:03.987325
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from mock import MagicMock, patch
    var = MagicMock(BaseVariable)
    var._fingerprint = (1, 2)
    assert hash(var) == hash((1, 2))


# Generated at 2022-06-20 12:42:11.647116
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('a[1]')
    assert not needs_parentheses('a[1:2]')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('(d).b')
    assert needs_parentheses('(a')
    assert needs_parentheses('a[1')
    assert needs_parentheses('a[1:2')
    assert needs_parentheses('a.b')
    assert needs_parentheses('d).b')



# Generated at 2022-06-20 12:42:22.170551
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    global_var = BaseVariable("global_var")
    assert global_var.source == "global_var"

    # test exclude parameter
    assert global_var.exclude == ()
    global_var2 = BaseVariable("global_var", exclude="exclude_var")
    assert global_var2.exclude == ("exclude_var",)

    # test code
    assert global_var.code.co_code == b'd\x00\x00\x83\x01\x00GHd\x01\x00S'
    assert global_var2.code.co_code == b'd\x00\x00\x83\x01\x00GHd\x01\x00S'

    # test unambiguous_source
    assert global_var.unambiguous_source == "global_var"
    assert global_

# Generated at 2022-06-20 12:42:48.416809
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('TEST test_BaseVariable___eq__')
    try:
        assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
        assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
        assert BaseVariable('a', 'b') != BaseVariable('b', 'b')
    except:
        print('FAILED\n')
        return False

    print('PASSED\n')
    return True


# Generated at 2022-06-20 12:42:55.974133
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable('p', 'q')
    assert cv.source == 'p'
    assert cv.exclude == ('q',)
    assert cv.code == compile('p', '<variable>', 'eval')
    assert cv.unambiguous_source == 'p'
    assert not hasattr(cv, '_fingerprint')
    assert not hasattr(cv, '_safe_keys')
    assert not hasattr(cv, '_keys')
    assert not hasattr(cv, '_format_key')
    assert not hasattr(cv, '_get_value')

# Generated at 2022-06-20 12:43:06.107151
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source_pairs = [
        ('x', 'y'),
        ('x', 'x')
    ]
    exclude_pairs = [
        ('a', 'b'),
        ('a', 'a')
    ]
    for i in range(2):
        for j in range(2):
            base_variable1 = BaseVariable(source_pairs[i][j], exclude_pairs[i][j])
            base_variable2 = BaseVariable(source_pairs[i][j], exclude_pairs[i][j])
            if i == 0:
                assert(base_variable1.__hash__() != base_variable2.__hash__())
            else:
                assert(base_variable1.__hash__() == base_variable2.__hash__())


# Generated at 2022-06-20 12:43:08.190938
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('hello', exclude='exclude')
    assert e._fingerprint == (Exploding, 'hello', ('exclude', ))



# Generated at 2022-06-20 12:43:12.735576
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('Test - ', __name__, ' : ', inspect.stack()[0][3])

    x1 = BaseVariable('x', exclude=['a', 'b'])
    x2 = BaseVariable('x', exclude=['a', 'b'])
    print(x1 == x2)



# Generated at 2022-06-20 12:43:16.755679
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('a', exclude='b')
    assert a.__class__ == Keys
    assert a.source == 'a'
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.exclude == ('b',)
    assert a.unambiguous_source == 'a'

# Generated at 2022-06-20 12:43:21.102192
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import events

    frame = events.Frame(
        filename='/tmp/main.py',
        function='main',
        lineno=4,
        f_globals={'x': 5},
        f_locals={'a': 3, 'b': 4},
    )
    print(Attrs('x').items(frame))
    print(Attrs('a').items(frame))
    print(Attrs('b').items(frame))


# Generated at 2022-06-20 12:43:24.059347
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert BaseVariable.__hash__.__doc__ == '\n    '

    class A(BaseVariable):
        pass

    assert not hasattr(A.__hash__, '__doc__')



# Generated at 2022-06-20 12:43:25.151520
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('a')


# Generated at 2022-06-20 12:43:30.315754
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = [1, 2, 3, 4, 5]
    Index1 = Indices('main_value').__getitem__(slice(1, 4, 2))
    result = Index1._items(main_value)
    assert(result == [('main_value[1]', '2\n3')])



# Generated at 2022-06-20 12:44:18.739138
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from six import assertRaisesRegex
    from .utils import assertRaisesAny

    # empty
    assert BaseVariable.__hash__(BaseVariable(source='')) == hash((BaseVariable, '', ()))

    # non empty
    assert BaseVariable.__hash__(BaseVariable(source='a', exclude='b')) == hash((BaseVariable, 'a', ('b',)))

# Generated at 2022-06-20 12:44:26.469932
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('a.__dict__')
    assert not needs_parentheses('a.__dict__.b')
    assert not needs_parentheses('a.__dict__.b.c')
    assert not needs_parentheses('a.__dict__["b"]')
    assert not needs_parentheses('a.__dict__["b"].c')
    assert not needs_parentheses('a.__dict__["b"]["c"]')
    assert not needs_parentheses('a.__dict__["b"]["c"].d')
    assert not needs_parentheses('a.__dict__[b]')
    assert not needs_parentheses

# Generated at 2022-06-20 12:44:29.419818
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert Attrs('a').source == 'a'
    assert Attrs('a').exclude == ()
    assert Attrs('a', 'b').exclude == ('b',)


# Generated at 2022-06-20 12:44:38.981849
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v = CommonVariable('xyz')
    assert v.source == 'xyz'
    assert v.exclude == ()
    assert v.code == compile('xyz', '<variable>', 'eval')
    assert v.unambiguous_source == 'xyz'
    assert v.items(namedtuple('x', 'y'), normalize=False) == [('xyz', 'x(y=None)')]
    assert v.items(namedtuple('x', 'y'), normalize=True) == [('xyz', 'x')]
    assert v.__hash__() == hash(('type', 'xyz', ()))
    assert v.__eq__('any') == False
    assert v.__eq__(CommonVariable('xyz')) == True


# Generated at 2022-06-20 12:44:40.722138
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a=Attrs("a")
    b=Attrs("b")
    assert a.__hash__() == b.__hash__()



# Generated at 2022-06-20 12:44:48.125877
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main = {'a': 1}
    b = BaseVariable('main', 'main')
    assert list(b.items(b)) == [('main', '{...}'), ('main.a', '1')]

    main = {'a': 1}
    b = BaseVariable('main', 'main')
    c = Attrs('main.a', 'main')
    assert list(b.items(b)) == [('main', '{...}'), ('main.a', '1')]
    assert list(c.items(b)) == [('main.a', '1'), ('main.a.__dict__', '{...}')]

# Generated at 2022-06-20 12:44:54.363164
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys

# Generated at 2022-06-20 12:45:00.895160
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert indices.source == 'a'
    with pytest.raises(AttributeError):
        assert indices.exclude
    assert indices.unambiguous_source == 'a'
    result = indices._items(['[1]'])
    assert result == [('a', "['[1]']"), ('a[0]', "'[1]'")]


# Generated at 2022-06-20 12:45:10.486403
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from .pycompat import StringIO
    from .frame import Frame
    frame = Frame(utils.f, exclude_internal=False)
    frame.f_globals = globals()
    frame.f_lineno = 3
    out = StringIO()
    v = BaseVariable('a')
    result = v.items(frame)
    for i in result:
        print(i[0] + ":" + i[1])
        



# Generated at 2022-06-20 12:45:11.287818
# Unit test for constructor of class Indices
def test_Indices():
	print(Indices('a').source)

# Generated at 2022-06-20 12:46:01.561847
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('abc')


if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-20 12:46:08.773457
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('a')
    assert x.source == 'a'
    assert x.code.co_code == compile('a', '<variable>', 'eval').co_code
    assert x.exclude == ()
    assert x.unambiguous_source == 'a'
    x = CommonVariable('a', exclude='b')
    assert x.exclude == ('b',)
    x = CommonVariable('(a).b')
    assert x.unambiguous_source == '(a).b'
    x = CommonVariable('(a).b', exclude='b')
    assert x.source == '(a).b'


# Generated at 2022-06-20 12:46:12.700196
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():

    class A():
        def __getitem__(self, item):
            return item

    indices = Indices('a')
    indices._slice = slice(10)
    print(indices._slice)
    assert indices._slice == slice(10), 'Indices is a class of class Keys, not the other way around!'



# Generated at 2022-06-20 12:46:23.805908
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # function
    TestFunc = lambda x: x
    TestFunc.a = 1
    TestFunc.b = 2
    test_variable = BaseVariable(TestFunc.a)
    assert test_variable.source == TestFunc.a
    assert test_variable.exclude == ()
    assert isinstance(test_variable.code, type(compile('1', '<string>', 'eval')))
    assert needs_parentheses(TestFunc.a) == True
    assert needs_parentheses('1') == False
    assert test_variable.unambiguous_source == '({})'.format(TestFunc.a)

    test_variable.source = TestFunc.b
    assert test_variable.source == TestFunc.b
    assert needs_parentheses(TestFunc.b) == False
    assert test

# Generated at 2022-06-20 12:46:30.939509
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x().y')
    assert not needs_parentheses('f(x).y')
    assert not needs_parentheses('x(x).y')
    assert needs_parentheses('(x).y')
    assert needs_parentheses('y(x).y')
    assert needs_parentheses('x(x+y).y')
    assert needs_parentheses('x==1')
    assert needs_parentheses('x+1')

# Generated at 2022-06-20 12:46:38.639324
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import threading

    def frame_generator():
        test_frame = threading.current_thread().get_ident()
        yield test_frame,frame

    frame = {'x': {'y': [1, 2, 3]}}
    test_frame = threading.current_thread().get_ident()
    variables = [BaseVariable('x.y[0]', exclude=0), BaseVariable('x'), BaseVariable('x.y'), BaseVariable('x.y[2:]')]
    for i in variables:
        print(i)
        print(i.items(frame=frame_generator()))
        print(i.items(frame=frame_generator(), normalize=True))
        print(i.items(frame='test'))
        print(i.items(frame='test', normalize=True))



# Generated at 2022-06-20 12:46:40.527178
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    result = BaseVariable('x').items(__builtins__)
    assert result == [('x', 'builtins')]

# Generated at 2022-06-20 12:46:46.089096
# Unit test for constructor of class Keys
def test_Keys():
    import inspect
    test_var = Keys('dataframe')
    assert isinstance(test_var, BaseVariable)
    assert test_var.source == 'dataframe'
    assert inspect.ismethod(test_var.items)
    assert inspect.ismethod(test_var._keys)
    assert inspect.ismethod(test_var._format_key)
    assert inspect.ismethod(test_var._get_value)


# Generated at 2022-06-20 12:46:54.357401
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for class Attrs
    class TestAttrs(Attrs):
        def _keys(self, main_value):
            return ['a', 'b']

        def _get_value(self, main_value, key):
            return main_value['de']

    obj = dict(a='a', b='b')
    obj_a = TestAttrs('obj', exclude=('a'))
    assert obj_a.items({'obj': obj}) == [
        ('obj', "'{'a': 'a', 'b': 'b'}'"),
        ('obj.b', "'b'"),
    ]

    # Test for class Exploding
    class TestExploding(Exploding):
        def _keys(self, main_value):
            return ['a', 'b', 'c']


# Generated at 2022-06-20 12:46:56.762266
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('xyz') == Indices('xyz')
    assert Indices('xyz') != Indices('xyz', exclude=('a', 'b'))
