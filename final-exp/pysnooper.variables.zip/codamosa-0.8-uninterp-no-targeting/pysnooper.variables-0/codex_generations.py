

# Generated at 2022-06-20 12:38:17.985405
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a', exclude=('b', 'c'))
    assert a.source == 'a'
    assert a.exclude == ('b', 'c')

    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()



# Generated at 2022-06-20 12:38:25.462267
# Unit test for constructor of class Indices
def test_Indices():
    arr = [1, 2, 3]
    var = Indices('arr')
    assert [('arr[0]', '1'), ('arr[1]', '2'), ('arr[2]', '3')] == var.items(dict(arr=arr))

    var = Indices('arr', exclude='keys')
    assert [('arr[0]', '1'), ('arr[1]', '2'), ('arr[2]', '3')] == var.items(dict(arr=arr))
    var = Indices('arr', exclude=['keys'])
    assert [('arr[0]', '1'), ('arr[1]', '2'), ('arr[2]', '3')] == var.items(dict(arr=arr))

    var = Indices('arr', exclude=['items'])

# Generated at 2022-06-20 12:38:36.573039
# Unit test for constructor of class Attrs
def test_Attrs():

    # Test for code-line is not the source
    Main = Attrs('main_value')
    frame = None # frame is not needed here
    check = Main.items(frame)
    assert(check[0][0] == 'main_value')
    print('\nTest 1 passed')

    # Test for code-line is the source
    class Main(): # Here 'Main' is the code-line
        check = Attrs('Main')
        frame = None # frame is not needed here
        check = check.items(frame)
        assert(check[0][0] == 'Main')
    print('Test 2 passed')
    # print('\nIf the above test succeeded, the following dictionary should have changed accordingly:', check)

    # Test for source not containing period
    Main = Attrs('main_value')
    frame = None # frame is

# Generated at 2022-06-20 12:38:40.447116
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('x.y') is False

    assert needs_parentheses('x.y + z') is True
    assert needs_parentheses('x.y + z.w') is True
    assert needs_parentheses('x.y + z.w.u') is True
    assert needs_parentheses('x + y') is True

    assert needs_parentheses('-x') is True
    assert needs_parentheses('-x.y') is True
    assert needs_parentheses('-x.y - z') is True
    assert needs_parentheses('-x.y - z.w') is True
    assert needs_parentheses('-x.y - z.w.u') is True
    assert needs_parentheses('-x - y') is True



# Generated at 2022-06-20 12:38:46.935903
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import utils
    from . import pycompat
    from .evalcontext import EvalContext
    from .variable import Attrs

# Generated at 2022-06-20 12:38:55.996770
# Unit test for constructor of class Exploding
def test_Exploding():
    a = Attrs(Attrs)
    assert isinstance(a, Attrs)
    k = Keys(Keys)
    assert isinstance(k, Keys)
    i = Indices(Indices)
    assert isinstance(i, Indices)
    a = Attrs('ab')
    assert isinstance(a, Attrs)
    k = Keys('def')
    assert isinstance(k, Keys)
    i = Indices('abc')
    assert isinstance(i, Indices)
    a = Attrs('ab', ('c',))
    assert isinstance(a, Attrs)
    k = Keys('def', ('g',))
    assert isinstance(k, Keys)
    i = Indices('abc', ('d',))
    assert isinstance(i, Indices)

    a = Exploding(Attrs)
   

# Generated at 2022-06-20 12:38:58.656684
# Unit test for constructor of class Keys
def test_Keys():
    list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    Keys('list')
    assert True


# Generated at 2022-06-20 12:39:02.154574
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert indices.source == 'a'
    assert indices.exclude == ()
    assert indices.unambiguous_source == 'a'
    assert indices.code == compile('a', '<variable>', 'eval')

# Generated at 2022-06-20 12:39:10.643791
# Unit test for constructor of class Exploding
def test_Exploding():

    # Class containing a list, a dict and an attribute
    class Foo:
        def __init__(self):
            self.attribute = 1
            self.dict = {"key": "value"}
            self.list = ["list_value"]

        # Member method
        def member_method(self):
            return None

    foo = Foo()


# Generated at 2022-06-20 12:39:13.279302
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices("name")
    i[0:3]
    print(i._slice)

if __name__ == "__main__":
    test_Indices___getitem__()

# Generated at 2022-06-20 12:39:23.752885
# Unit test for constructor of class Attrs
def test_Attrs():
    try:
        from . import utils
    except:
        pass
    import dis
    a = Attrs('main_value')
    dis.dis(a.code)
    # a.__init__('main_value')
    # print(a.source)
    # print(a.code)

test_Attrs()

# Generated at 2022-06-20 12:39:29.307853
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test case 1 - input
    target = ['a', 'b', 'c', 'd', 'e', 'f']
    range_of_target = range(len(target))
    # Expected output
    expected = [target[0], target[1], target[2], target[3], target[4]]
    # Actual output
    actual = Indices(target).__getitem__(slice(0, 5))
    # Unit test
    assert actual == expected


# Generated at 2022-06-20 12:39:32.015534
# Unit test for function needs_parentheses
def test_needs_parentheses():
    code = compile('x.f', '<variable>', 'eval').co_code
    assert code == compile('(x).f', '<variable>', 'eval').co_code
    assert code != compile('(x.f)', '<variable>', 'eval').co_code

# Generated at 2022-06-20 12:39:34.733344
# Unit test for constructor of class Indices
def test_Indices():
    x = Indices("i")
    assert x.source == "i"
    assert x.exclude == tuple()
    assert x.code is not None
    assert x.unambiguous_source == "i"
    assert x._slice is not None
    assert x is not None
    assert x == Indices("i")


# Generated at 2022-06-20 12:39:45.329368
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = {"1": 1, "2": 2}
    l = [1, 2, 3, 4]
    assert BaseVariable("d").items(d) == (("d", "{'1': 1, '2': 2}"),)
    assert BaseVariable("d", exclude='2').items(d) == (("d", "{'1': 1, '2': 2}"), ("d.1", "1"))
    assert BaseVariable("d[1]").items(d) == (("d[1]", "1"),)
    assert BaseVariable("l").items(l) == (("l", "[1, 2, 3, 4]"),)

# Generated at 2022-06-20 12:39:54.463909
# Unit test for constructor of class Keys

# Generated at 2022-06-20 12:39:59.185026
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('x')
    assert i == Indices('x')
    assert i != Indices('y')
    assert i != Indices('x', 'y')
    assert i != Indices('x', 'y')
    assert i == i
    assert i != ''

    assert i[1:5] != i

# Generated at 2022-06-20 12:40:03.039051
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('var', exclude=['excluded_var'])
    v2 = BaseVariable('var', exclude=('excluded_var',))

    assert v1 == v2
    assert hash(v1) == hash(v2)

# Generated at 2022-06-20 12:40:11.425793
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from types import FunctionType
    import os
    import math
    import socket

    _ = FunctionType(lambda: 1, globals(), '_')
    for type1, type2 in itertools.combinations((int, os.scandir, math, socket), 2):
        assert type1 == type1
        assert type2 == type2
        assert type1 != type2
        assert type2 != type1

    _ = FunctionType(lambda: 1, globals(), '_')
    for type1, type2 in itertools.combinations((int, os.scandir, math, socket), 2):
        assert type1 == type1
        assert type2 == type2
        assert type1 != type2
        assert type2 != type1


# Generated at 2022-06-20 12:40:13.800965
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        bv = BaseVariable('aaa')
        raise AssertionError
    except NotImplementedError:
        pass


# Generated at 2022-06-20 12:40:33.333248
# Unit test for constructor of class Attrs
def test_Attrs():
    context_vars_0 = Attrs('var0')
    assert(context_vars_0.source == 'var0')
    assert(context_vars_0.exclude == ())

    context_vars_1 = Attrs('var1', '_')
    assert(context_vars_1.source == 'var1')
    assert(context_vars_1.exclude == ('_',))

    context_vars_2 = Attrs('var2', None)
    assert(context_vars_2.source == 'var2')
    assert(context_vars_2.exclude == ())

    try:
        Attrs('var1', ['_', '__'])
    except:
        print("Failed to construct Attrs('var1', ['_', '__'])")

# Generated at 2022-06-20 12:40:36.213784
# Unit test for constructor of class Attrs
def test_Attrs():
    def f():
        x = 'foo'
        return Attrs('x').items(inspect.currentframe())
    assert list(f()) == [('x', "'foo'")]


# Generated at 2022-06-20 12:40:42.032629
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def code(s):
        return compile(s, '<variable>', 'eval').co_code

    assert code('x') == code('(x)')
    assert code('x.y') != code('(x).y')
    assert code('x.y') == code('(x.y)')
    assert code('x.y().z') != code('(x.y()).z')
    assert code('x[0]') != code('(x)[0]')

# Unit tests for BaseVariable

# Generated at 2022-06-20 12:40:48.699699
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .testutils import FakeFrame
    from . import utils
    from .utils import IS_PY2
    v = BaseVariable(source='exc', exclude=('__traceback__',))
    frame = FakeFrame('x', {'exc': ZeroDivisionError('qqq')})
    v_items = v.items(frame)
    if IS_PY2:
        assert 'exc' in v_items[0][1]
    else:
        assert 'qqq' in v_items[0][1]
    assert '__traceback__' not in v_items[1][1]


# Generated at 2022-06-20 12:40:57.955971
# Unit test for function needs_parentheses
def test_needs_parentheses():
    names = ('a', 'b', 'c', 'd', 'e', 'f', 'g')
    ops = ('.', '+', '-', '*', '/', '%')

    for s in names:
        assert not needs_parentheses(s), '{} needs parens'.format(s)

    for e in '()':
        for s in names + ops:
            assert not needs_parentheses(e), '{} needs parens'.format(e)

    for s in ops:
        assert not needs_parentheses(s), '{} needs parens'.format(s)


# Generated at 2022-06-20 12:40:58.811721
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass


# Generated at 2022-06-20 12:41:02.775108
# Unit test for constructor of class Indices
def test_Indices():
    # Test_Target: This is a unit test for constructor of class Indices
    # Method:      test_Indices
    # Author:      Shaoqing.Zhang
    # Date:        2017.10.08
    indices = Indices('', '')
    try:
        indices[:]
    except Exception as e:
        print(e)
        return False
    return True

# Generated at 2022-06-20 12:41:07.268194
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('a')
    assert bv.source == 'a'
    assert bv.exclude == ()
    assert bv.code
    assert bv.unambiguous_source == 'a'


# Generated at 2022-06-20 12:41:16.197387
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import numpy as np
    from .utils import test_data_dir

    # test for class BaseVariable
    var = BaseVariable("1")
    assert var.items(object()) == ()

    # test for class Attrs
    var = Attrs("1")
    assert var.items(object()) == ()

    var = Attrs("np")  # var ---> numpy
    assert var.items(np) == [("np", "module 'numpy' from '{}/../lib/python/site-packages/numpy/__init__.py'".format(test_data_dir))]

    # test for class Keys
    var = Keys("{}")  # var ---> dict
    assert var.items({}) == [("{}", "dict()")]

# Generated at 2022-06-20 12:41:22.993120
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('x')
    y = BaseVariable('y')
    assert x.__eq__(x)
    assert not x.__eq__(y)
    y.source = 'x'
    assert x.__eq__(y)
    y.exclude = ('x', )
    assert not x.__eq__(y)
    x.exclude = ('x', )
    assert x.__eq__(y)


# Generated at 2022-06-20 12:42:07.851027
# Unit test for constructor of class Indices
def test_Indices():
    data = [1, 2, 3, 4, 5]
    source = 'data'
    exclude = ['x']
    print(Indices(source, exclude).items(data))
    source = 'data[::-1]'
    exclude = ['x']
    print(Indices(source, exclude).items(data))

# Generated at 2022-06-20 12:42:10.975530
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('a')
    assert a.source == 'a'
    assert a.code is not None
    assert a.exclude == ()
    assert a.unambiguous_source == 'a'


# Generated at 2022-06-20 12:42:15.827741
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('a', ['b'])
    assert a.source == 'a'
    assert a.exclude == ('b',)
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == 'a'
    assert a.items(None, False) == []
    #assert a._safe_keys(None) == []
    #assert a._keys(None) == []


# Generated at 2022-06-20 12:42:18.585550
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('xxx')
    assert isinstance(a[1:5], Indices)
    assert a._slice == slice(None)
    assert (a[1:5])._slice == slice(1, 5)

# Generated at 2022-06-20 12:42:19.968680
# Unit test for constructor of class Keys
def test_Keys():
    pass


# Generated at 2022-06-20 12:42:28.162227
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    dicts = Indices('d')._items(dict([(1,'a'),(2,'b'),(3,'c')]))
    assert dicts == [('d[0]', "'a'"),('d[1]', "'b'"),('d[2]', "'c'")]
    dicts = Indices('d')[::2]._items(dict([(1,'a'),(2,'b'),(3,'c')]))
    assert dicts == [('d[0]', "'a'"),('d[2]', "'c'")]



VARIABLE_CLASSES = (
    Attrs,
    Keys,
    Indices,
    Exploding
)

# Generated at 2022-06-20 12:42:33.006103
# Unit test for constructor of class Exploding
def test_Exploding():
    m = {'a':1, 'b':2}
    v = Exploding('v')
    assert v.source == 'v'
    assert v.items({'v':m}) == [(u'v', u'{u\'a\': 1, u\'b\': 2}'), 
            (u'v[u\'a\']', u'1'), (u'v[u\'b\']', u'2')]

# Generated at 2022-06-20 12:42:36.989246
# Unit test for constructor of class Attrs
def test_Attrs():

    at = Attrs('foobar')
    assert at._keys({1:2, 3:4}) == [1,3]
    assert at._get_value('foobar', 'badkey') == 'foobar' + '.' + 'badkey'



# Generated at 2022-06-20 12:42:47.399191
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    print('testing method __hash__ of class BaseVariable')
    excluder = utils.get_random_string()
    var_names = utils.get_random_string()
    var_names_copy = deepcopy(var_names)
    name_of_class = utils.get_random_string()
    source_of_class = utils.get_random_string()
    exclude_of_class = utils.get_random_string()
    assert (hash('{}({!r}, exclude={})'.format(name_of_class, source_of_class, exclude_of_class)) ==
            hash((name_of_class, source_of_class, exclude_of_class)))

# Generated at 2022-06-20 12:42:49.453930
# Unit test for constructor of class Indices
def test_Indices():
    # print 'Start unit test for Indices'
    source = "source"
    Indices(source)
    # print 'Passed unit test for Indices'


# Generated at 2022-06-20 12:43:33.776032
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = [1, 2, 3, 4, 5]
    vi = Indices(a)
    v1 = vi[1:3]
    v2 = Indices(a)[1:3]

    assert(v1 == v2)

# Generated at 2022-06-20 12:43:35.650432
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:1]._slice == slice(None, 1)

test_Indices___getitem__()

# Generated at 2022-06-20 12:43:39.265368
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    value = 0 # Variable set in __init__ method of class Indices
    test_value = slice(0,3,None) # Default for variable test_value
    value = test_value

    assert isinstance(value, slice)
    assert True
    assert True
    assert True

test_Indices___getitem__()


# Generated at 2022-06-20 12:43:41.287853
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a.b') == BaseVariable('a.b')
    assert BaseVariable('a.b') != BaseVariable('a.B')
    

# Generated at 2022-06-20 12:43:53.135132
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    with pytest.raises(TypeError):
        BaseVariable()
    BaseVariable('name')
    BaseVariable('name', exclude='attr')
    BaseVariable(source='name')
    BaseVariable(source='name', exclude='attr')
    BaseVariable(exclude=['attr'], source='name')
    BaseVariable(exclude=['attr'])
    BaseVariable(exclude='attr')
    BaseVariable()
    v = BaseVariable('name')
    assert v.source == 'name'
    assert v.exclude == ()
    assert v.unambiguous_source == 'name'
    v = BaseVariable('name', exclude='attr')
    assert v.exclude == ('attr',)
    assert v.unambiguous_source == 'name'
    v = BaseVariable('name.attr')
    assert v.unambiguous

# Generated at 2022-06-20 12:43:58.603194
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    attrs = Attrs('a')
    assert not attrs == 123

    assert attrs == Attrs('a')
    assert Attrs('a.b') == Attrs('a.b')
    assert Attrs('a.b') != Attrs('a.b', exclude='b')

    # two classes are different, even if they have the same source and exclude params
    assert Attrs('a.b') != Keys('a.b')


# Generated at 2022-06-20 12:44:06.670766
# Unit test for constructor of class Keys
def test_Keys():
    # test cases
    test_cases = [
        Keys('test_var', ['L', 'M']),
        Keys('test_var'),
        Keys('test_var', exclude=['L', 'M']),
        Keys('test_var', exclude=('L', 'M'))
    ]

    # for each test case, check the source, exclude and fingerprint
    for t in test_cases:
        assert t.source == 'test_var'
        assert t.exclude == ('L', 'M')
        assert t._fingerprint == (Keys, 'test_var', ('L', 'M'))
        assert hash(t) == hash(Keys('test_var', ['L', 'M']))

    # for the first test case, check the code, unambiguous source, and items

# Generated at 2022-06-20 12:44:10.240709
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    #def _items(self, key, normalize=False):
    #    raise NotImplementedError

    #assert isinstance(BaseVariable, BaseVariable())
    assert isinstance(BaseVariable(),BaseVariable)
    #assert isinstance(BaseVariable, BaseVariable)



# Generated at 2022-06-20 12:44:21.916936
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    eq_test_cases = (
        (BaseVariable('', None), BaseVariable('', None)),
        (BaseVariable(None, ''), BaseVariable(None, '')),
        (BaseVariable('', '', '', '', None, ''), BaseVariable('', '', '', '', None, '')),
        (BaseVariable('', None, '', '', None, ''), BaseVariable('', None, '', '', None, '')),
        (BaseVariable('', '', '', '', None, ''), BaseVariable('', '', '', '', None, '')),
    )

# Generated at 2022-06-20 12:44:23.007839
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    f = CommonVariable('x')
    assert hash(f) == hash((f._fingerprint))



# Generated at 2022-06-20 12:45:52.186558
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a': 1, 'b': 2, 'c': 3}
    print (Keys('d.keys()'))
    assert Keys('d.keys()').items(d) == [('d.keys()', 'dict_keys([\'a\', \'b\', \'c\'])')]

# Generated at 2022-06-20 12:45:57.914883
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a.b(1)') is False
    assert needs_parentheses('a().b') is True
    assert needs_parentheses('a[1]') is False
    assert needs_parentheses('a[1].b') is False
    assert needs_parentheses('a[1].b.c') is False
    assert needs_parentheses('a[1].b(2)') is False
    assert needs_parentheses('a[1]()') is True
    assert needs_parentheses('a()[1]') is True
    assert needs_parentheses('a[1]()[2]') is True

# Generated at 2022-06-20 12:45:58.855130
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable("sources")


# Generated at 2022-06-20 12:46:08.256565
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('a.b')), True)
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('a.b.c')), False)
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('a')), False)
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('b')), False)
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('a.b', exclude=('b',))), False)
    #self.assertEqual(BaseVariable('a.b').__eq__(BaseVariable('a.b', exclude=('not_b',))), True)
    return True

# Generated at 2022-06-20 12:46:11.369477
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable_name = 'BaseVariable'
    variable_source = variable_name
    variable = BaseVariable(variable_source)

    assert variable.source is variable_source
    assert variable.code is not None
    assert variable.unambiguous_source is variable_source


# Generated at 2022-06-20 12:46:13.230768
# Unit test for constructor of class Keys
def test_Keys():
	assert Keys("foo")
	assert type(Keys("foo")) == Keys
	assert Keys("foo").source == "foo"
	assert Keys("foo").exclude == ()

# Generated at 2022-06-20 12:46:17.893730
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ex1 = Indices("a")
    ex2 = ex1[1:]
    assert(len(list(ex2.items(None))[0]) == 2)
    assert(list(ex2.items(None))[0][1] == 'a[1:]')

# Generated at 2022-06-20 12:46:21.465712
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('main_value.x')
    assert a.source == 'main_value.x'
    assert a.exclude == ()
    assert isinstance(a.code, types.CodeType)


# Generated at 2022-06-20 12:46:28.001474
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable_1 = BaseVariable('source', exclude = ('a', 'b'))
    variable_2 = BaseVariable('source', exclude = ('b', 'a'))
    variable_3 = BaseVariable('source', exclude = ('b', 'a', 'd'))
    variable_4 = BaseVariable('sources', exclude = ('b', 'a'))
    assert variable_1 == variable_2
    assert variable_1 != variable_3
    assert variable_1 != variable_4


# Generated at 2022-06-20 12:46:30.589133
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    b = BaseVariable('some_variable_name')
    other_b = BaseVariable('some_variable_name')
    assert(b == other_b)
