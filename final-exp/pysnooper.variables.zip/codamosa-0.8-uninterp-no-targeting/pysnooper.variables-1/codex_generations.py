

# Generated at 2022-06-20 12:38:15.809835
# Unit test for constructor of class Keys
def test_Keys():
    import re
    assert not re.search(r'\d', '\n'.join(Keys('x').items(dict(x={'a': 1, 'b': 2}))))

# Generated at 2022-06-20 12:38:20.667958
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {'b':1, 'c':2}
    b = Exploding('a', ('a',))
    c = b.items(1)
    for k, v in c:
        assert isinstance(k, str)
        assert isinstance(v, str)
    assert (c[0][0] != c[1][0]) and (c[0][1] != c[1][1])


# Generated at 2022-06-20 12:38:24.332805
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
  f = Frame.from_string('''def f():
    import inspect_fixture
    inspect_fixture.a = 1
    return inspect_fixture''')
  bv = BaseVariable('inspect_fixture', exclude=())
  assert bv.__hash__() == hash(type(bv), 'inspect_fixture', ())


# Generated at 2022-06-20 12:38:28.077261
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys("x")
    assert var.source == "x"
    assert var.code
    assert var._fingerprint == (Keys, "x", ())
    assert var.unambiguous_source == "x"


# Generated at 2022-06-20 12:38:38.194188
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from hypothesis import given, assume, settings
    from hypothesis.strategies import one_of, characters, integers, tuples, \
        recursive, sampled_from, text, dictionaries, lists, floats
    from hypothesis.extra.pytest import register_assert_rewrite, assume
    from .._utils import noop_serializer

    register_assert_rewrite('_hypothesis_store.utils')

    @given(tuples(lists(characters()), lists(characters()), one_of(characters(), integers(), floats())))
    @settings(max_examples=200)
    def test_BaseVariable___hash__(source, exclude, normalize):
        assume(not normalize or isinstance(normalize, (int, float)))
        if not isinstance(exclude, tuple):
            exclude = (exclude,)

# Generated at 2022-06-20 12:38:40.662038
# Unit test for constructor of class Indices
def test_Indices():
    frame = sys._getframe(1)
    A = Indices('foo', exclude=['x', 'y'])
    print(A.items(frame, normalize=True))


# Generated at 2022-06-20 12:38:48.396474
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert i.source == 'a'
    assert i.unambiguous_source == '(a)'
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.exclude == ()

    i = Indices('a', 'b')
    assert i.source == 'a'
    assert i.unambiguous_source == '(a)'
    assert i.code == compile('a', '<variable>', 'eval')
    assert i.exclude == ('b',)

# Test getitem attribute of class Indices

# Generated at 2022-06-20 12:38:51.448494
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable(source="source", exclude="exclude")
    b = BaseVariable(source="source", exclude="exclude")
    print(a.__hash__())
    print(b.__hash__())
    assert a.__hash__() == b.__hash__()


# Generated at 2022-06-20 12:38:58.666521
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import mock
    from . import utils
    from .mock import call
    import types

    def test_function(*args, **kwargs):
        return args, kwargs

    def test_function_with_exception():
        raise ValueError

    def test_function_with_import_error():
        import no_such_module

    def test_function_with_unexpected_exc_info(exc_info):
        raise exc_info[1]

    @mock.patch('logging.exception')
    def test_BaseVariable_items_exception(log_exc):
        # Test case:
        # _items() raises an exception
        #
        # Expectation:
        # - Should not crash
        # - No variable should be printed
        env = {'__name__': '__main__'}

# Generated at 2022-06-20 12:39:08.278294
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable('a')
    assert(cv.source == 'a')
    assert(cv.exclude == ())
    assert(cv.code == compile('a', '<variable>', 'eval'))
    assert(cv.unambiguous_source == '(a)')

    cv = CommonVariable('a', exclude=['one', 'two'])
    assert(cv.source == 'a')
    assert(cv.exclude == ('one', 'two'))
    assert(cv.code == compile('a', '<variable>', 'eval'))
    assert(cv.unambiguous_source == '(a)')

    cv = CommonVariable('a.b')
    assert(cv.source == 'a.b')
    assert(cv.exclude == ())

# Generated at 2022-06-20 12:39:23.752885
# Unit test for constructor of class Attrs
def test_Attrs():
    class V:
        x = 1
        def __init__(self, y):
            self.y = y
    
    a = V(100)
    #print(type(a))
    #print(a.x)
    #print(a.y)
    
    #print(Attrs('a'))
    #print(Attrs('a').items(''))
    #print(Attrs('a').items('')[0])
    #print(Attrs('a').items('')[1])
    #print(Attrs('a').items('')[2])
    
    #print(Attrs('a').items('')[0][0])
    #print(Attrs('a').items('')[0][1])
    #print(Attrs('a').items('')[1][0])
    #print

# Generated at 2022-06-20 12:39:24.631812
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a[2]')
    assert i._slice == slice(None)


# Generated at 2022-06-20 12:39:27.993262
# Unit test for constructor of class Indices
def test_Indices():
    """Test __getitem__ of Indices.
    
    If a tuple is returned, that indicates that __getitem__ is working correctly.

    """
    assert isinstance(Indices("example").__getitem__(slice(0,None)), tuple), "Test failed."

# Generated at 2022-06-20 12:39:33.114539
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    hash_source = BaseVariable("a", ("key1", "key2"))
    hash_another = BaseVariable("a", ("key2", "key1"))
    hash_another1 = BaseVariable("b", ("key2", "key1"))
    assert hash_source.__hash__() == hash_another.__hash__()
    assert hash_source.__hash__() != hash_another1.__hash__()



# Generated at 2022-06-20 12:39:43.266215
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('a', exclude=('b',)) == Attrs('a', exclude=('b',))
    assert Attrs('a') != Attrs('b')
    assert Attrs('a') != Attrs('a', exclude=('b',))
    assert Attrs('a', exclude=('b',)) != Attrs('a', exclude=('c',))
    assert Keys('a') == Keys('a')
    assert Keys('a') != Keys('b')
    assert Indices('a') == Indices('a')
    assert Indices('a') != Indices('b')
    assert Exploding('a') == Exploding('a')
    assert Exploding('a') != Exploding('b')
    assert Attrs('a') != Keys('a')

# Generated at 2022-06-20 12:39:48.474387
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Normal cases
    assert BaseVariable('a').source == 'a'
    assert BaseVariable('a', 'b').source == 'a'
    assert BaseVariable('a', exclude=('b',)).source == 'a'
    assert BaseVariable('a', exclude=('b',)).exclude == ('b',)

    # Error cases
    with pytest.raises(RuntimeError):
        BaseVariable(123)
    with pytest.raises(RuntimeError):
        BaseVariable('a', 123)


# Generated at 2022-06-20 12:39:50.338027
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    try:
        CommonVariable('foo')
    except NotImplementedError as e:
        print('NotImplementedError:', e.args[0])

# Generated at 2022-06-20 12:39:54.264920
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=('u')) == BaseVariable('a', exclude=('u'))
    assert BaseVariable('a', exclude=('u')) != BaseVariable('a', exclude=('v'))



# Generated at 2022-06-20 12:39:56.252816
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a.b')
    assert needs_parentheses('(a.b)')
    assert not needs_parentheses('a')



# Generated at 2022-06-20 12:40:02.121203
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Setup
    class TestVariable(BaseVariable):
        def _items(key, normalize=False):
            pass

        def __init__(self, source, exclude=()):
            super(TestVariable, self).__init__(source, exclude)

    # Exercise
    a = TestVariable('var')
    b = TestVariable('var')
    c = TestVariable('var', exclude=('x',))

    # Verify
    assert a == b, 'test case failed: __eq__ method of class BaseVariable'
    assert a.__hash__() == b.__hash__(), 'test case failed: __hash__ method of class BaseVariable'
    assert a != c, 'test case failed: __eq__ method of class BaseVariable'

# Generated at 2022-06-20 12:40:08.151931
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('foo')
    assert hash(v) == hash((type(v), 'foo', ()))
test_BaseVariable___hash__()


# Generated at 2022-06-20 12:40:10.209928
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a').source == 'a'
    assert Keys('a').exclude == ()
    assert Keys('a', 'b').exclude == ('b',)


# Generated at 2022-06-20 12:40:16.265775
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    expected_source = 'source'
    expected_exclude = ('exclude1', 'exclude2')
    expected_code = 1234
    st = CommonVariable('source', ('exclude1', 'exclude2'))
    assert st.source == expected_source
    assert st.exclude == expected_exclude
    assert isinstance(st.code, types.CodeType)
    assert st.unambiguous_source == 'source'
    st = CommonVariable('(source)', ('exclude1', 'exclude2'))
    assert st.source == expected_source
    assert st.exclude == expected_exclude
    assert isinstance(st.code, types.CodeType)
    assert st.unambiguous_source == '(source)'
    st = CommonVariable('(source)', 'exclude1')
    assert st.source

# Generated at 2022-06-20 12:40:27.862749
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import console
    x = [{'a': 1}, {'b': 2}]
    v = Exploding('v')
    c = console.Console(record=True).__enter__()
    c.pycon(x, v)

# Generated at 2022-06-20 12:40:34.068335
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('v1')
    v2 = BaseVariable('v2')

    assert hash(v1)
    assert hash(v2)
    assert v1 == v1
    assert v1 != v2
    assert v1 != 'v1'


# Generated at 2022-06-20 12:40:39.591036
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    test_source = "dataset.dims"
    test_exclude = ["x"]
    variable = CommonVariable(test_source, test_exclude)
    expected = 'dataset.dims'
    assert variable.source == expected
    variable = CommonVariable(test_source, test_exclude)
    assert variable.source == test_source
    assert variable.exclude == test_exclude
    assert variable.code != ''
    assert variable.unambiguous_source != ''


# Generated at 2022-06-20 12:40:42.619530
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class Slice():
        start = 1
        stop = 10
        step = 1
    indices = Indices('x[1]')
    indices_slice = indices[Slice()]
    assert indices_slice._slice == Slice()
#Test end


# Generated at 2022-06-20 12:40:51.097029
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('x', ('fun',))
    assert x.source == 'x'
    assert x.exclude == ('fun',)
    assert x.code == compile('x', '<variable>', 'eval')
    assert x.unambiguous_source == 'x'
    assert x._fingerprint == (Keys, 'x', ('fun',))
    assert x._keys('x') == ()
    assert x._keys(('x',)) == range(1)
    assert x._keys({'x':1}) == ['x'].keys()
    assert x._format_key('x') == '[x]'
    assert x._get_value(('x', ), 0) == 'x'
    assert x._get_value({'x':1}, 'x') == 1


# Generated at 2022-06-20 12:41:00.391797
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class TestCommonVariable(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))

        def _get_value(self, main_value, key):
            return main_value[key]

    cv = TestCommonVariable('a', exclude='b')
    assert cv.source == 'a'
    assert cv.exclude == ('b',)
    assert cv.unambiguous_source == 'a'

    assert cv._items({'bbb': 'ccc', 'a': {'b': 'c'}}) == [
        ('a.b', 'c'),
        ('a[bbb]', 'ccc'),
    ]

# Generated at 2022-06-20 12:41:02.160305
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # instantiate the class
    basevariable=BaseVariable("hello.SayHello()")
    print(basevariable.source)


# Generated at 2022-06-20 12:41:13.079824
# Unit test for constructor of class Keys
def test_Keys():
    keys_obj = Keys("list1")
    assert keys_obj.source == "list1"


# Generated at 2022-06-20 12:41:19.752313
# Unit test for constructor of class Indices
def test_Indices():
    li = [1,2,3,4,5]
    idx = Indices('test_variable')
    assert idx.items(frame=None, normalize=None) == []
    idx = Indices('test_variable')[1:2]
    assert idx.source == 'test_variable'
    assert idx._slice == slice(1, 2)
    assert idx.items(frame=None, normalize=None) == []
    idx = Indices('test_variable')[:2]
    assert idx.source == 'test_variable'
    assert idx._slice == slice(None, 2)
    assert idx.items(frame=None, normalize=None) == []
    idx = Indices('test_variable')[2:]
    assert idx.source == 'test_variable'


# Generated at 2022-06-20 12:41:25.267262
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("i") is False
    assert needs_parentheses("(i)") is False
    assert needs_parentheses("(i).x") is False
    assert needs_parentheses("i.x") is True
    assert needs_parentheses("i[0]") is True
    assert needs_parentheses("'{i}'.format(i=x)") is True

# Generated at 2022-06-20 12:41:31.387256
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # No exception is raised
    variable = BaseVariable('a')
    assert variable.items({'a':1}) == [('a', '1')]
    assert variable.items({'a':[1,2,3]}) == [('a', '[1, 2, 3]')]
    assert variable.items({'a':[1,2,3]}) == [('a', '[1, 2, 3]')]
    assert variable.items({'a':[1,[1,2,3,4],3]}) == [('a', '[1, [...], 3]')]
    assert variable.items({'a':[1,2,[3,4,5,'test'],3]}) == [('a', '[1, 2, [3, 4, 5, ...], 3]')]

# Generated at 2022-06-20 12:41:33.986147
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('x', ('y', 'z'))
    a.source
    a.exclude
    a.code



# Generated at 2022-06-20 12:41:39.887816
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_object = Indices('a')
    orig, copy = dict(), dict()
    for key in 'abcde':
        orig[key] = copy[key] = '{}-value'.format(key)
    orig_items = orig.items()
    test_object['b':'d']
    assert orig_items == orig.items()  # unaffected
    assert orig_items == test_object['b':'d'].items(orig, normalize=True)
    assert orig_items == test_object[1:3].items(orig, normalize=True)

# Generated at 2022-06-20 12:41:48.808950
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 1. BaseVariable instances with different hash
    # Create the first BaseVariable instance
    base_variable_1 = BaseVariable(source='aaaa', exclude=('aaaa'))
    # Create the second BaseVariable instance
    base_variable_2 = BaseVariable(source='aabb', exclude=('bbbb'))
    # Compare
    assert(base_variable_1.__eq__(base_variable_2) == False)

    # 2. BaseVariable instances with the same hash
    # Create the first BaseVariable instance
    base_variable_1 = BaseVariable(source='aaaa', exclude=('aaaa'))
    # Create the second BaseVariable instance
    base_variable_2 = BaseVariable(source='aaaa', exclude=('aaaa'))
    # Compare
    assert(base_variable_1.__eq__(base_variable_2) == True)


# Generated at 2022-06-20 12:41:53.054045
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('abc') == BaseVariable('abc')
    assert BaseVariable('abc') != BaseVariable('def')
    assert BaseVariable('abc', 'a') == BaseVariable('abc', 'a')
    assert BaseVariable('abc', 'a') != BaseVariable('abc', 'b')

# Generated at 2022-06-20 12:41:59.265167
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types

    class DummyFrame:
        def __init__(self):
            self.f_locals = locals()
            self.f_globals = globals()

    dummy_frame = DummyFrame()

    def assert_variable_items(v, items):
        items_iter = iter(items)
        for source, value in v.items(dummy_frame):
            assert source == next(items_iter)
            assert value == next(items_iter)
        assert items_iter.__length_hint__() == 0

    def assert_normalized_variable_items(v, items):
        items_iter = iter(items)
        for source, value in v.items(dummy_frame, normalize=True):
            assert source == next(items_iter)

# Generated at 2022-06-20 12:42:07.569766
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('foo')
    assert a.source == 'foo'
    assert a.code == compile('foo', '<variable>', 'eval')
    assert a.exclude == ()
    assert a.unambiguous_source == 'foo'

    a = Attrs('foo', 'bar')
    assert a.source == 'foo'
    assert a.code == compile('foo', '<variable>', 'eval')
    assert a.exclude == ('bar',)
    assert a.unambiguous_source == 'foo'

# Generated at 2022-06-20 12:42:26.098852
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass

# Generated at 2022-06-20 12:42:30.542152
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect, pprint
    def test(source):
        print("source = %r" % source)
        src = compile(source, '<test>', 'eval')
        pprint.pprint(inspect.getclosurevars(src))
    test("x")
    test("x['y']")
    test("x.y")
    test("x[0]")

# Generated at 2022-06-20 12:42:36.807209
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # and case of class Attrs
    test_case1 = Attrs('test_case', "")
    test_case2 = Attrs('test_case', ())
    test_case3 = Attrs('test_case', "exclude")
    test_case4 = Attrs('test_case', ("exclude",))
    test_case5 = Attrs('test_case', "exclude1", "exclude2")
    test_case6 = Attrs('test_case', ("exclude1", "exclude2"))
    test_case7 = Attrs('test_case', "exclude1, exclude2")
    test_case8 = Attrs('test_case', ("exclude1", "exclude2"))

    assert test_case1.source == 'test_case'
    assert test_case1.exclude == ()
   

# Generated at 2022-06-20 12:42:42.241265
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('foo')
    assert i.source == 'foo'
    assert i.exclude == ()
    assert i.code is not None
    assert i.unambiguous_source is not None
    assert i._slice is not None
    assert i._fingerprint is not None



# Generated at 2022-06-20 12:42:46.847134
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # testing the source
    A = BaseVariable('a')
    a = 1
    assert A.items(locals()) == [('a', '1')]
    assert A.items(locals(), True) == [('a', 1)]

    # testing the exclude
    B = BaseVariable('a', exclude=('a', 'b'))
    b = 2
    assert B.items(locals()) == []



# Generated at 2022-06-20 12:42:49.387317
# Unit test for constructor of class Indices
def test_Indices():
    source = 'a'
    exclude = ('a')
    indice = Indices(source, exclude)
    print(indice)

if __name__=='__main__':
    test_Indices()

# Generated at 2022-06-20 12:42:59.711667
# Unit test for function needs_parentheses
def test_needs_parentheses():
    code = compile
    assert needs_parentheses('x') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x[y]') is False
    assert needs_parentheses('x()') is False
    assert needs_parentheses('x(y)') is False
    assert needs_parentheses('x.y()') is False
    assert needs_parentheses('x.y(z)') is False
    assert needs_parentheses('x()[y]') is False
    assert needs_parentheses('x()[y]()') is False
    assert needs_parentheses('x()[y][z]') is False
    assert needs_parentheses('x().y') is True
    assert needs_parentheses('x()[y].z') is True

# Generated at 2022-06-20 12:43:02.435712
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('').__getitem__(slice(1, 2)) == Indices('', exclude=())[1:2]


# Generated at 2022-06-20 12:43:06.453488
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('x').source == 'x'
    assert BaseVariable('x', ['a', 'b']).exclude == ('a', 'b')
    assert BaseVariable('x', 'a').exclude == ('a',)
    assert BaseVariable('x', 'a', 'b').exclude == ('a', 'b')


# Generated at 2022-06-20 12:43:13.687408
# Unit test for constructor of class Attrs
def test_Attrs():

    # Testing class Attrs
    class A:
        pass

    a = A()
    a.a = 1
    a.b = 2
    a.c = 3
    result1 = list(Attrs("a").items(frame=A.__dict__))

    assert result1 == [("a.a", "1"),("a.b", "2"),("a.c", "3")]
    assert result1 == [("a.a", "1"),("a.b", "2"),("a.c", "3")]



# Generated at 2022-06-20 12:43:57.692600
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x[y]')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert      needs_parentheses('x.y[z]')
    assert      needs_parentheses('x[y].z')
    assert      needs_parentheses('x[(y, z)]')
    assert      needs_parentheses('x[(y, z)].w')
    assert      needs_parentheses('x[y].z[w]')

# Generated at 2022-06-20 12:44:04.260131
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert needs_parentheses('foo.bar')
    assert needs_parentheses('i[4]')
    assert needs_parentheses('(foo)')
    assert not needs_parentheses('((foo))')
    assert not needs_parentheses('(foo).bar')
    assert not needs_parentheses('foo()')
    assert not needs_parentheses('foo(3)')
    assert not needs_parentheses('foo(bar=1)')
    assert not needs_parentheses('foo[4]')
    assert needs_parentheses('foo if bar')

# Generated at 2022-06-20 12:44:07.786360
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding("key")
    assert var.source == "key"
    assert var.code is not None
    assert var.exclude == ()
    assert var.unambiguous_source == "key"
    assert var._items("key") == []


# Generated at 2022-06-20 12:44:09.537341
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert(BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',)))

# Generated at 2022-06-20 12:44:21.375324
# Unit test for method __eq__ of class BaseVariable

# Generated at 2022-06-20 12:44:23.665170
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # variables of the same type but with different arguments are distinct
    assert BaseVariable('a') != BaseVariable('b')

    # variables of the same type and with the same arguments are equal
    assert BaseVariable('a') == BaseVariable('a')


# Generated at 2022-06-20 12:44:27.100363
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a[0]') == False
    assert needs_parentheses('~a') == True
    assert needs_parentheses('a + b') == True
    assert needs_parentheses('a[0] + b') == True

# Generated at 2022-06-20 12:44:29.420221
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    index = Indices("a")
    index2 = index[1:3]
    assert index != index2
    assert index2._slice.start == 1

# Generated at 2022-06-20 12:44:31.700234
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('source').keys()
    assert keys[0] == 'source'
    assert len(keys) == 1


# Generated at 2022-06-20 12:44:32.580040
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('var')


# Generated at 2022-06-20 12:46:31.091564
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'a': {'b': 'c'}, 'd': [{'e': 'f'}]}
    assert BaseVariable('a').items(frame) == [('a', '<dict>')]
    assert BaseVariable('a').items(frame, normalize=True) == [('a', {})]
    assert Keys('a').items(frame) == [('a', '<dict>'), ('a["b"]', "'c'")]
    assert Attrs('a').items(frame) == [('a', '<dict>'), ('a.__dict__', {})]
    assert Indices('d').items(frame) == [('d', '<list>'), ('d[0]', "<dict>")]
    assert type(BaseVariable('a')) == BaseVariable
    assert type(Attrs('a')) == Attrs

# Generated at 2022-06-20 12:46:37.958000
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import math
    import builtins

    math.pi = 3.0  # be naughty
    prev_pi = builtins.pi  # make sure we reset it

    def test_variable(variable, source, expected):
        code = compile('list({})'.format(source), '<test>', 'eval')
        result = variable.items(code.co_consts[1][0])
        assert result == expected

    test_variable(
        Keys('{}'),
        '{1: 2, 3: 4}',
        [('{1: 2, 3: 4}', '{1: 2, 3: 4}'),
         ('{1: 2, 3: 4}[1]', '2'),
         ('{1: 2, 3: 4}[3]', '4')]
    )

# Generated at 2022-06-20 12:46:39.223392
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    instance = BaseVariable('')
    assert isinstance(instance.__hash__(), int)


# Generated at 2022-06-20 12:46:44.194116
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class CustomBaseVariable(BaseVariable): pass
    var1 = CustomBaseVariable('foo')
    var2 = CustomBaseVariable('bar')
    var3 = CustomBaseVariable('foo')
    var4 = BaseVariable('foo')

    assert var1 == var1
    assert var1 != var2
    assert var1 != var4
    assert var1 == var3


# Generated at 2022-06-20 12:46:49.273527
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs("a")
    assert a.source == "a"
    assert a.exclude == ()
    assert isinstance(a.code, CodeType)
    assert a._keys({}) == ()
    assert a._format_key("b") == ".b"
    assert a._get_value({}, "c") is None
    assert a._items({}) == [('a', '{}')]

# Generated at 2022-06-20 12:46:56.414530
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import get_shortish_repr
    from . import pycompat
    main_value = [[]]

    main_value.append([get_shortish_repr(main_value)])
    main_value.append([])
    main_value[-1] = get_shortish_repr(main_value[-1])
    main_value[-1] = get_shortish_repr(main_value[-1])

    main_value.append([])
    main_value[-1] = main_value
    main_value.append(main_value[-1])

    main_value[-1][-1] = main_value
    main_value[-1].append(main_value)
    main_value[-1].append(main_value[-1])
    main_value

# Generated at 2022-06-20 12:47:06.844776
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    globals = {'x': 2}
    locals = {'c': {'a': 1, 'b': 2}, 'd': [1, 2], 'e': (1, 2), 'f': {'a': {'y': [1]}}}
    x = BaseVariable("c.a", exclude=['b'])
    assert x.items(globals, locals) == [("c.a", 1)]
    x = BaseVariable("c", exclude=['b'])
    assert x.items(globals, locals) == [("c", {'a': 1, 'b': 2})]
    x = BaseVariable("d", exclude=['b'])
    assert x.items(globals, locals) == [("d", [1, 2])]
    x = BaseVariable("e", exclude=['b'])


# Generated at 2022-06-20 12:47:16.571982
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pprint import pprint
    from . import utils
    from . import pycompat
    def abc():abcd='abcdefg'

    # Very simple case
    assert BaseVariable('abcd').items(locals()) == (('abcd', '\'abcdefg\''),)

    # Base case
    assert BaseVariable('abcd', exclude='abcd').items(locals()) == ()
    assert BaseVariable('abcd', exclude='b').items(locals()) == (('abcd', '\'abcdefg\''),)

# Generated at 2022-06-20 12:47:26.335951
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert needs_parentheses('foo.bar')
    assert not needs_parentheses('(foo)')
    assert not needs_parentheses('(foo.bar)')
    assert needs_parentheses('foo[1]')
    assert needs_parentheses('foo.bar[1]')
    assert not needs_parentheses('(foo[1])')
    assert not needs_parentheses('(foo.bar[1])')
    assert not needs_parentheses('foo().x')
    assert not needs_parentheses('foo.bar().x')
    assert not needs_parentheses('(foo()).x')
    assert not needs_parentheses('(foo.bar()).x')
    assert not needs_parentheses('foo[1].x')

# Generated at 2022-06-20 12:47:27.215253
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
   assert CommonVariable('expression')