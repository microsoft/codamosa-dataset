

# Generated at 2022-06-20 12:38:26.421806
# Unit test for constructor of class Exploding
def test_Exploding():
    class Dummy(object):
        def __init__(self):
            self.a = 1
            self.b = 'abc'

    d = Dummy()
    var = Exploding('d')
    assert len(var.items(locals())) == 3
    assert var.items(locals())[0][0] == 'd'
    assert var.items(locals())[0][1] == 'Dummy'
    assert var.items(locals())[1][0] == 'd.a'
    assert var.items(locals())[1][1] == '1'
    assert var.items(locals())[2][0] == 'd.b'
    assert var.items(locals())[2][1] == 'u"abc"'


# Generated at 2022-06-20 12:38:37.345111
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    class TestCommon(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))

        def _get_value(self, main_value, key):
            return main_value[key]

    test_dict = {'a': 1, 'b': 2}
    test_object = TestCommon('test_dict')

    assert test_object._keys(test_dict) == ['a', 'b']
    assert test_object._format_key('a') == '[\'a\']'
    assert test_object._get_value(test_dict, 'a') == 1
    assert test_object.source == 'test_dict'

# Generated at 2022-06-20 12:38:40.663319
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('var')
    assert var.source == 'var'
    assert var.code == compile(var.source, '<variable>', 'eval')
    assert var.exclude == ()


# Generated at 2022-06-20 12:38:51.162224
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
##    # !!! HERE ARE ALL THE IMPORTS
    import sys
    import unittest
    import types
    import inspect
    import pdb
    import re
    # !!! TO HERE
    
    # Test Case #1
    class Test1(CommonVariable):
    ##        def __init__(self):
    ##            CommonVariable.__init__(self, 'random.choice', exclude='abc')
    ##        self.source = 'random.choice'
    ##        self.exclude = 'abc'
    ##        self.unambiguous_source = 'random.choice'
        def _items(self, main_value, normalize):
            return [('random.choice', '<function random_choice>')]
    
    
    # Test Case #2

# Generated at 2022-06-20 12:38:58.491587
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    def test_source(source):
        v = BaseVariable(source)
        assert str(v.code) == "<code object <module> at 0x1043d5df0, file '<variable>', line 1>".format(source)
        assert v.source == source
        assert v.exclude == ()
        assert v.unambiguous_source == source
        assert v.__hash__() == 1394379563

    def test_source_parentheses(source):
        v = BaseVariable(source)
        assert str(v.code) == "<code object <module> at 0x1043d5df0, file '<variable>', line 1>".format(source)
        assert v.source == source
        assert v.exclude == ()
        assert v.unambiguous_source == '({})'.format(source)


# Generated at 2022-06-20 12:39:03.041945
# Unit test for constructor of class Exploding
def test_Exploding():
    # a = b = {} ; a['b'] = 99;
    # D[a]
    # D[a]['b']
    # D[[],[]]
    # D[{},[]]
    # D[{},{}]
    # D[[],[]]
    # D[[],[]]
    pass

# Generated at 2022-06-20 12:39:07.450796
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    b = BaseVariable('a', ('b'))
    try:
        b.items({'a':1})
    except NotImplementedError:
        print('test_BaseVariable_items PASSED')
    else:
        print('test_BaseVariable_items FAILED')


# Generated at 2022-06-20 12:39:10.979316
# Unit test for constructor of class Indices
def test_Indices():
    from .pycompat import unittest

    class IndiceTestCase(unittest.TestCase):
        def setUp(self):
            self.indices = Indices('x')

        def test_getitem(self):
            self.assertEqual(self.indices[1:3]._slice, slice(1, 3))

    return unittest.defaultTestLoader.loadTestsFromTestCase(IndiceTestCase)

# Generated at 2022-06-20 12:39:12.826027
# Unit test for constructor of class Attrs
def test_Attrs():
    from . import utils
    cls = Attrs('a')
    assert cls.source == 'a'
    assert cls.exclude == ()

# Generated at 2022-06-20 12:39:22.545692
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "request.headers.__dict__"
    # source = 'request.headers'
    frame = inspect.currentframe()
    fr = inspect.getouterframes(frame)
    print(fr)
    exclude = ('update',)
    # exclude = ()
    variable = BaseVariable(source, exclude)
    print('variable items: {}'.format(variable.items(frame)))


if __name__ == "__main__":
    class Foo(object):
        def __init__(self, bar='baz'):
            self.bar = bar

    def bar():
        pass

    a = {'1': 'a', '2': 'b', '3': 'c'}

    test_BaseVariable_items()

# Generated at 2022-06-20 12:39:33.199778
# Unit test for constructor of class Attrs
def test_Attrs():
    class A(object):
        x = 1

    assert Attrs("x").items(sys._getframe()) == [('x', '1')]
    assert Attrs("x").items(sys._getframe()) == [('x', '1')]
    assert Attrs("vars(x)").items(sys._getframe(1)) == [('vars(x)', "{'x': 1}")]
    assert Attrs("vars(x)").items(sys._getframe(1)) == [('vars(x)', "{'x': 1}")]



# Generated at 2022-06-20 12:39:37.444194
# Unit test for constructor of class Exploding
def test_Exploding():
    #! Mapping
    d = {"a":1,"b":2,"c":3}
    e = Exploding("d")
    #e.items(d)
    assert e._items(d) == Keys("d")._items(d)

    #! Sequence
    l = [1,2,3]
    e = Exploding("l")
    assert e._items(l) == Indices("l")._items(l)

    #! None
    e = Exploding("d")
    #e.items(d)
    assert e._items(d) == Attrs("d")._items(d)


# Generated at 2022-06-20 12:39:46.987075
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import itertools
    import sys
    import math
    import requests

    # unit test for explicit exception in special method _items
    class ExceptionVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            raise NotImplementedError

    print('\nTesting explicit exception in special method _items:')
    frame = sys._getframe()
    d = ExceptionVariable('d').items(frame)
    print('d -->', d, '\n')
    
    # unit test for implicit exception in special method _items
    class ImplicitExceptionVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return main_value.keys()

    print('\nTesting implicit exception in special method _items:')
    frame = sys._getframe()
    i = ImplicitException

# Generated at 2022-06-20 12:39:52.067049
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
  assert BaseVariable('foobar') == BaseVariable('foobar')
  assert BaseVariable('foobar') != BaseVariable('baz')
  assert BaseVariable('foobar', exclude=['a', 'b']) == BaseVariable('foobar', exclude=['b', 'a'])
  assert BaseVariable('foobar', exclude=['a', 'b']) != BaseVariable('foobar', exclude=['a', 'b', 'c'])

# Generated at 2022-06-20 12:39:57.168787
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    d = dict(a=1, b=2)
    assert Indices('d')._items(d) == [('d[0]', '1'), ('d[1]', '2'), ('d', "{'b': 2, 'a': 1}")]
    assert Indices('d')[-2:]._items(d) == [('d[0]', '1'), ('d[1]', '2')]
    assert Indices('d')[:0]._items(d) == []

# Generated at 2022-06-20 12:40:00.313015
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("myVar")
    assert a.code == compile("myVar", '<variable>', 'eval')
    assert a.source == "myVar"


# Generated at 2022-06-20 12:40:04.240173
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v1 = BaseVariable('foo')
    v2 = BaseVariable('foo')
    v3 = BaseVariable('foo', exclude=('bar',))
    assert v1 == v2, "Not same instance"
    assert v1 != v3, "Not same instance"

# Generated at 2022-06-20 12:40:07.860463
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    one = BaseVariable('a')
    two = BaseVariable('b')
    three = BaseVariable('a')
    assert hash(one) != hash(two)
    assert hash(one) == hash(three)


# Generated at 2022-06-20 12:40:17.600262
# Unit test for constructor of class Indices
def test_Indices():
    import numpy as np
    a = [1,2,3,4,5]
    b = np.array([1,2,3,4,5])
    assert Indices('a[:2]').items(locals()) == [('a[0]', '1'), ('a[1]', '2')]
    assert Indices('a[2:]').items(locals()) == [('a[2]', '3'), ('a[3]', '4'), ('a[4]', '5')]
    assert Indices('a[2:4]').items(locals()) == [('a[2]', '3'), ('a[3]', '4')]

# Generated at 2022-06-20 12:40:18.511068
# Unit test for constructor of class Exploding
def test_Exploding():
    x = Exploding("x")
    assert x.source == "x"


# Generated at 2022-06-20 12:40:38.776003
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('(x.y)') == False
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('x.y().z') == False
    assert needs_parentheses('x[1].y') == False
    assert needs_parentheses('(x)[1].y') == True
    assert needs_parentheses('x.y[1]') == False
    assert needs_parentheses('(x.y)[1]') == True



# Generated at 2022-06-20 12:40:40.735327
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'x'
    var1 = BaseVariable(source)
    var2 = var1
    assert hash(var1) == hash(var2)


# Generated at 2022-06-20 12:40:43.449318
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = Attrs('x', exclude='y')
    v2 = Attrs('x', exclude='y')
    v3 = Attrs('y', exclude='y')
    s = set([v1, v2, v3])
    assert len(s) == 2

# Generated at 2022-06-20 12:40:52.838755
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('a')
    assert bv._fingerprint == (BaseVariable, 'a', ())
    assert hash(bv) == hash(bv._fingerprint)
    assert bv == BaseVariable('a')
    assert bv == BaseVariable('a', None)
    assert bv == BaseVariable('a', ())
    assert bv == BaseVariable('a', ())
    assert bv == BaseVariable('a', [])
    assert bv != BaseVariable('a', ['b'])
    assert bv != BaseVariable('b')
    test_globals = {'a': 1}
    test_locals = {'a': 2}
    assert bv.items(utils.FakeFrame(test_globals, test_locals)) == [('a', '2')]

# Generated at 2022-06-20 12:40:58.005163
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'c'
    exclude = ('d', 'e')
    obj = BaseVariable(source, exclude)
    obj2 = BaseVariable(source, exclude)
    assert obj.__eq__(obj2)
    assert not obj.__ne__(obj2)
    assert obj.__hash__() == obj2.__hash__()
    assert obj._fingerprint == obj2._fingerprint


# Generated at 2022-06-20 12:40:59.596955
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('x', exclude='')
    assert isinstance(e, Exploding)
    assert e.source == 'x'
    assert e.exclude == tuple()

# Generated at 2022-06-20 12:41:08.979675
# Unit test for constructor of class Keys
def test_Keys():
    vars1 = Keys(1)
    vars2 = Keys(2, 3)
    vars3 = Keys(2, 3, 4)

    print(vars1.source)
    print(vars2.source)
    print(vars3.source)

    print(vars1.exclude)
    print(vars2.exclude)
    print(vars3.exclude)

    print(vars1.code)
    print(vars2.code)
    print(vars3.code)

    print(vars1._fingerprint)
    print(vars2._fingerprint)
    print(vars3._fingerprint)


# Generated at 2022-06-20 12:41:11.157131
# Unit test for constructor of class Indices
def test_Indices():
    v=Indices('x')
    assert v.source=='x'
    assert v.exclude==()
    assert v.code==compile('x', '<variable>', 'eval')
    assert v.unambiguous_source=='x'


# Generated at 2022-06-20 12:41:17.292365
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
        You can also use the case in the docstring of this method to write unit tests.
    """
    # case: BaseVariableA1 is equal to BaseVariableA2
    class BaseVariableA(BaseVariable):
        pass

    BaseVariableA1 = BaseVariableA('source')
    BaseVariableA2 = BaseVariableA('source')
    assert BaseVariableA1 == BaseVariableA2

    # case: BaseVariableA1 isn't equal to BaseVariableB1
    class BaseVariableB(BaseVariable):
        pass

    BaseVariableB1 = BaseVariableB('source')
    assert BaseVariableA1 != BaseVariableB1


# Generated at 2022-06-20 12:41:21.267954
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    obj = BaseVariable("a")
    assert obj.source == "a"
    assert obj.exclude == ()
    assert obj.code.co_names == ('a',)
    assert obj.unambiguous_source == "a"


# Generated at 2022-06-20 12:41:35.373167
# Unit test for constructor of class Exploding
def test_Exploding():
    one = Exploding('x')
    assert one.source == 'x'
    assert one.unambiguous_source == 'x'
    test_frame = {'x':{'y':123}}
    assert one.items(test_frame) == [('x', "{'y': 123}"), ('x.y', '123')]

# Generated at 2022-06-20 12:41:40.619450
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def call(source, expected):
        assert needs_parentheses(source) is expected
        assert needs_parentheses(source + '\n') is expected

    call('a', False)
    call('a.b', True)
    call('a[0]', True)
    call('a.b.c', True)
    call('a[2][1]', True)
    call('a.b[1].c', True)
    call('a[0].b', True)
    call('a.b[0]', True)



# Generated at 2022-06-20 12:41:47.964878
# Unit test for constructor of class Indices
def test_Indices():
    # code_object = compile(source, '<variable>', 'eval')
    # assert codeobject == Indices(source).code
    assert Indices('a')._slice == slice(None)
    assert Indices('a')[1:] == Indices('a', exclude=()).__getitem__(slice(1, None))
    assert Indices('a')[:] == Indices('a', exclude=()).__getitem__(slice(None, None, None))
    assert Indices('a')[1:3] == Indices('a', exclude=()).__getitem__(slice(1, 3, None))
    assert Indices('a')[1::2] == Indices('a', exclude=()).__getitem__(slice(1, None, 2))

# Generated at 2022-06-20 12:41:49.671746
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_1 = Indices('d', 'd.a')
    indices_1[:]


# Generated at 2022-06-20 12:41:51.331024
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    BaseVariable(source='', exclude=()).__hash__()


# Generated at 2022-06-20 12:41:53.298568
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('foo')
    assert isinstance(var, BaseVariable)



# Generated at 2022-06-20 12:41:57.130952
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('foo', 'bar') != Attrs('foo', 'barz')
    assert Attrs('foo', 'bar') == Attrs('foo', 'bar')
    assert Attrs('foo', 'bar') != Attrs('foo', 'barb')
    assert Attrs('foo', 'bar') == Attrs('foo', 'bar')

# Generated at 2022-06-20 12:42:05.312560
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('x', ())
    v2 = BaseVariable('x', ())
    v3 = BaseVariable('y', ())
    v4 = BaseVariable('x', ('y',))
    v5 = BaseVariable('y', ('x',))

    assert (v1 == v1)
    assert (v1 != v2)
    assert (v1 != v3)
    assert (v1 != v4)
    assert (v1 != v5)
    assert (v1 != None)



# Generated at 2022-06-20 12:42:06.794651
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('foo'), Exploding)


# Generated at 2022-06-20 12:42:08.522812
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))



# Generated at 2022-06-20 12:42:17.640683
# Unit test for constructor of class Attrs
def test_Attrs():
    assert not Attrs('foo').items({'foo': 'bar'})



# Generated at 2022-06-20 12:42:26.549960
# Unit test for function needs_parentheses
def test_needs_parentheses():
    vars = [
        # These should be always processed correctly
        'a', 'a.b', 'a[1]', 'a[1].b',
        # These are the tricky ones
        '(a)', '(a.b)', '(a[1])', '(a[1].b)',
        '((a))', '((a.b))', '((a[1]))', '((a[1].b))',
        '((a).b)', '((a[1]).b)',
        '((a.b))[1]', '((a)[1]).b',
    ]

    for i in vars:
        assert needs_parentheses(i) == (i.count('(') > 0)

# Generated at 2022-06-20 12:42:30.627104
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('f(x)')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.y(z, w)')
    assert not needs_parentheses('x[y]')
    assert not needs_parentheses('x[y](z, w)')

# Generated at 2022-06-20 12:42:41.366040
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def test_variable_init(source, exclude, unambiguous_source):
        assert CommonVariable(source, exclude).source == source 
        assert CommonVariable(source, exclude).unambiguous_source == unambiguous_source 
        assert CommonVariable(source, exclude).source == source 
        assert CommonVariable(source, exclude).exclude == utils.ensure_tuple(exclude)  
    test_variable_init('abc', (), 'abc')
    test_variable_init('abc', [], 'abc')
    test_variable_init('abc', 'def', 'abc')
    test_variable_init('abc', None, 'abc')
    test_variable_init('(abc)', (), '(abc)')
    test_variable_init('(abc)', [], '(abc)')

# Generated at 2022-06-20 12:42:44.271625
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[:] == Indices('a')
    assert Indices('a')[::-1] != Indices('a')
    assert Indices('a')[1::3] != Indices('a')

# Generated at 2022-06-20 12:42:48.111278
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class Foo(BaseVariable):
        def _items(self, main_value, normalize=False):
            return main_value

    foo1 = Foo('s')
    foo2 = Foo('s')
    assert foo1.source == 's'
    assert foo1 == foo2


# Generated at 2022-06-20 12:42:50.278532
# Unit test for constructor of class Keys
def test_Keys():
    k=Keys("params", exclude=(1,2))
    k.items(2)

if __name__ == "__main__":
    test_Keys()

# Generated at 2022-06-20 12:42:56.218810
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test variables used:
    source = 'a'
    exclude = 'y'
    var = BaseVariable(source, exclude)
    # test variables are correctly contained in the object:
    assert var.source == source
    assert var.exclude == (exclude,)
    # test common behaviour:
    assert var.items({}) == ()
    assert var.items({source: "val"}) == (('a', '"val"'),)


# Generated at 2022-06-20 12:43:04.267538
# Unit test for constructor of class Indices
def test_Indices():
    test_case = [
        ([1, 2], slice(0, 4), [0, 1]),
        ([1, 2], slice(0, 2, 2), [0]),
        ([1, 2], slice(0, 4, 2), [0, 2]),
        ([1, 2], slice(0, 3), [0, 1]),
    ]
    for lst, slc, target in test_case:
        assert list(Indices('x')[slc]._keys(lst)) == target
    

if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-20 12:43:06.833367
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    #test_source = "isinstance(x, Exception)"
    test_source = "x"
    test_basevariable = BaseVariable(test_source)
    assert test_basevariable

