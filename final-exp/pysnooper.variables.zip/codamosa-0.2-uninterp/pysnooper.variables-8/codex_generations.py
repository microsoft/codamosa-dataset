

# Generated at 2022-06-16 19:28:32.269673
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 'a'
    frame.f_locals['b'] = 'b'
    frame.f_locals['c'] = 'c'
    frame.f_locals['d'] = 'd'
    frame.f_locals['e'] = 'e'
    frame.f_locals['f'] = 'f'
    frame.f_locals['g'] = 'g'
    frame.f_locals['h'] = 'h'
    frame.f_locals['i'] = 'i'
    frame.f_locals['j'] = 'j'
    frame.f_locals['k'] = 'k'
    frame.f_locals['l'] = 'l'
    frame.f_loc

# Generated at 2022-06-16 19:28:44.917478
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:28:52.172894
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os

    def test_function():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33
        hh = 34
        ii = 35


# Generated at 2022-06-16 19:29:03.905634
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:29:14.983453
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins

    def get_frame(level=0):
        frame = inspect.currentframe()
        while level > 0:
            frame = frame.f_back
            level -= 1
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_locals_and_globals(level=0):
        frame = get_frame(level)
        return frame.f_locals, frame.f_globals

    def get_frame_locals_and_globals_and_code(level=0):
        frame

# Generated at 2022-06-16 19:29:25.469813
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import io
    import contextlib
    import unittest
    import unittest.mock

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = {'b': 'c'}
            self.frame.f_locals['d'] = ['e', 'f']
            self.frame.f_locals['g'] = (1, 2, 3)
            self.frame.f_locals['h'] = {1, 2, 3}

# Generated at 2022-06-16 19:29:36.462850
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import unittest
    import collections
    import datetime
    import time
    import random
    import math
    import decimal
    import fractions
    import itertools
    import functools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import json
    import pickle
    import csv
    import xml.etree.ElementTree
    import email.parser
    import email.policy
    import email.message
    import email.mime.multipart
    import email.mime.text
    import email.mime.base
    import email.mime.application
    import email.mime.audio

# Generated at 2022-06-16 19:29:42.637879
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:29:53.411165
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import Frame

# Generated at 2022-06-16 19:30:05.129537
# Unit test for method __getitem__ of class Indices

# Generated at 2022-06-16 19:30:21.112462
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:30:23.755149
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:2] == Indices('a', slice(1, 2))

# Generated at 2022-06-16 19:30:34.422956
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'd'))

# Generated at 2022-06-16 19:30:42.950975
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) == BaseVariable('x', exclude=['z', 'y'])

# Generated at 2022-06-16 19:30:54.665543
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')

# Generated at 2022-06-16 19:31:03.369934
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == indices.code
    assert indices_slice.unambiguous_source == indices.unambiguous_source
    assert indices_slice._fingerprint == indices._fingerprint
    assert indices_slice.__hash__() == indices.__hash__()
    assert indices_slice.__eq__(indices) == indices.__eq__(indices)

# Generated at 2022-06-16 19:31:14.917228
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:26.542016
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:31:30.573010
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice._fingerprint == indices._fingerprint
    assert indices_slice.source == indices.source
    assert indices_slice.exclude == indices.exclude
    assert indices_slice.code == indices.code
    assert indices_slice.unambiguous_source == indices.unambiguous_source

# Generated at 2022-06-16 19:31:42.021521
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from pprint import pprint
    from . import utils
    from . import pycompat
    from . import variables

    def test_items(variable, frame, normalize=False):
        print('{}'.format(variable))
        pprint(variable.items(frame, normalize=normalize))
        print()

    def test_items_all(frame, normalize=False):
        for variable in variables.ALL:
            test_items(variable, frame, normalize=normalize)

    def test_items_all_normalized(frame):
        test_items_all(frame, normalize=True)

    def test_items_all_not_normalized(frame):
        test_items_all(frame, normalize=False)


# Generated at 2022-06-16 19:31:59.916292
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import types
    import sys
    import os

    def get_frame(level=0):
        frame = inspect.currentframe()
        for i in range(level):
            frame = frame.f_back
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_code(level=0):
        return get_frame(level).f_code

    def get_frame_filename(level=0):
        return get_frame(level).f_code.co_filename

    def get_frame_lineno(level=0):
        return get_frame(level).f_lineno


# Generated at 2022-06-16 19:32:11.172336
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:20.890544
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins

    def get_frame(level=0):
        frame = inspect.currentframe()
        while level > 0:
            frame = frame.f_back
            level -= 1
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_builtins(level=0):
        return get_frame_globals(level).get('__builtins__', builtins.__dict__)

    def get_frame_code(level=0):
        return get_frame(level).f_code


# Generated at 2022-06-16 19:32:31.543019
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = old_stdout

    def test_func(a, b, c):
        print(a)
        print(b)
        print(c)

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back

# Generated at 2022-06-16 19:32:43.575635
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()

# Generated at 2022-06-16 19:32:51.046642
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import io
    import os
    import tempfile
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            self.assertEqual(
                list(BaseVariable('sys').items(frame)),
                [('sys', '<module \'sys\' (built-in)>')]
            )
            self.assertEqual(
                list(BaseVariable('sys.version_info').items(frame)),
                [('sys.version_info', 'sys.version_info(major=3, minor=6, micro=0, releaselevel=\'final\', serial=0)')]
            )

# Generated at 2022-06-16 19:32:59.220550
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import traceback
    import pprint
    import unittest
    import tempfile
    import contextlib
    import io
    import linecache
    import subprocess
    import time
    import random
    import string
    import warnings
    import platform
    import shutil
    import filecmp
    import stat
    import errno
    import gc
    import atexit
    import signal
    import functools
    import collections
    import weakref
    import copy
    import pickle
    import struct
    import array
    import mmap
    import faulthandler
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import selectors

# Generated at 2022-06-16 19:33:10.300498
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestCase(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f

# Generated at 2022-06-16 19:33:21.416363
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:30.847534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'abc'
    frame.f_locals['v'] = 1
    frame.f_locals['u'] = {'a': 1, 'b': 2}
    frame.f_locals['u'].__class__.__name__ = 'U'
    frame.f_locals['u'].__class__.__module__ = '__main__'
    frame.f_locals['u'].__class__.__qualname__ = 'U'
    frame

# Generated at 2022-06-16 19:33:53.879252
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import os
    import re
    import io
    import contextlib

    # Capture the output of the function
    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    # Test the function
    def test_items(self, frame, normalize=False):
        try:
            main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
        except Exception:
            return ()
        return self._items(main_value, normalize)

    # Test the function

# Generated at 2022-06-16 19:34:04.616919
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:34:15.065425
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import unittest.mock

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame_locals = frame.f_locals
            frame_globals = frame.f_globals
            frame_globals['__name__'] = '__main__'
            frame_globals['__file__'] = 'test_BaseVariable_items.py'
            frame_globals['__package__'] = None
            frame_globals['__cached__'] = None
            frame_globals['__doc__'] = None
            frame_globals['__spec__'] = None
            frame_globals['__loader__'] = None


# Generated at 2022-06-16 19:34:25.796155
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe(1)
        while frame.f_code.co_name != 'test_BaseVariable_items':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return dict(inspect.getargvalues(frame)[3])

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_locals_globals(frame):
        return get_frame_locals(frame), get_frame_globals(frame)

    def get_frame_locals_globals_normalize(frame):
        return get_frame_locals_globals

# Generated at 2022-06-16 19:34:36.741098
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:48.564738
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import os.path
    import re
    import types
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_globals = {
                '__name__': '__main__',
                '__file__': os.path.abspath(__file__),
                '__package__': None,
                '__cached__': None,
                '__doc__': None,
                '__builtins__': sys.modules['builtins'],
            }

# Generated at 2022-06-16 19:34:53.953650
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pprint
    import types
    import builtins
    import functools
    import operator
    import itertools
    import collections
    import datetime
    import decimal
    import fractions
    import io
    import os
    import re
    import socket
    import tempfile
    import threading
    import time
    import traceback
    import warnings
    import weakref
    import xml
    import xml.etree
    import xml.etree.ElementTree
    import xml.etree.cElementTree
    import xml.dom
    import xml.dom.minidom
    import xml.sax
    import xml.sax.handler
    import xml.sax.saxutils
    import xml.sax.xmlreader
    import xml.parsers
    import xml.parsers

# Generated at 2022-06-16 19:35:06.223635
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import math
    import random
    import string
    import os
    import re
    import datetime
    import time
    import functools
    import itertools
    import collections
    import operator
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import hashlib
    import hmac
    import uuid
    import socket
    import ssl
    import selectors
    import asyncio
    import threading
    import multiprocessing
    import subprocess
    import concurrent
    import concurrent.futures
    import contextlib
    import functools
    import it

# Generated at 2022-06-16 19:35:16.921932
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import re
    import os
    import io
    import tempfile
    import contextlib
    import unittest
    import collections
    import functools
    import itertools
    import operator
    import random
    import string
    import threading
    import time
    import datetime
    import decimal
    import fractions
    import math
    import cmath
    import numbers
    import json
    import pickle
    import base64
    import hashlib
    import hmac
    import binascii
    import zlib
    import unicodedata
    import codecs
    import encodings
    import io
    import locale
    import gettext
    import struct
    import copy
    import pprint
    import reprlib
    import abc

# Generated at 2022-06-16 19:35:29.301771
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    # print(frame.f_locals)
    # print(frame.f_globals)
    # print(frame.f_code)
    # print(frame.f_trace)
    # print(frame.f_lasti)
    # print(frame.f_lineno)
    # print(frame.f_builtins)
    # print(frame.f_restricted)
    # print(frame.f_exc_traceback)
    # print(frame.f_exc_type)
    # print(frame.f_exc_value)
    # print(frame.f_back)
    # print(frame.f_back.f_lineno)
    # print(frame.f_back.f_code)
    # print(frame.f_back.

# Generated at 2022-06-16 19:36:05.008453
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import math
    import random
    import datetime
    import time
    import functools
    import itertools
    import operator
    import collections
    import string
    import json
    import base64
    import hashlib
    import hmac
    import binascii
    import tempfile
    import shutil
    import socket
    import ssl
    import select
    import threading
    import multiprocessing
    import subprocess
    import logging
    import platform
    import ctypes
    import ctypes.util
    import ctypes.wintypes
    import ctypes.macholib
    import ctypes.macholib.dyld
    import ctypes.macholib.dylib
    import c

# Generated at 2022-06-16 19:36:15.012838
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'abc'
    frame.f_locals['v'] = {'a': 1, 'b': 2}
    frame.f_locals['v'].__class__.__name__ = 'V'
    frame.f_locals['v'].__class__.__module__ = '__main__'
    frame.f_locals['v'].__class__.__qualname__ = 'V'

# Generated at 2022-06-16 19:36:21.497661
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(func):
        return inspect.getouterframes(inspect.currentframe())[func.__code__.co_firstlineno + 1][0]

    def get_items(var, func):
        return var.items(get_frame(func))

    def test_items(var, func, expected):
        assert get_items(var, func) == expected

    def test_items_normalize(var, func, expected):
        assert get_items(var, func, normalize=True) == expected

    def test_items_exclude(var, func, expected):
        assert get_items(var, func, exclude=expected) == ()


# Generated at 2022-06-16 19:36:30.563236
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    from . import utils
    from . import pycompat
    from . import variables

    # Create a frame object, by calling a function
    def foo():
        bar(inspect.currentframe())
    def bar(frame):
        # Create a BaseVariable object
        var = variables.BaseVariable('sys')
        # Call method items of the BaseVariable object
        result = var.items(frame)
        # Check the result
        assert result == [('sys', '<module \'sys\' (built-in)>')]

    foo()



# Generated at 2022-06-16 19:36:40.603914
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import json
    import copy
    import types
    import functools
    import collections
    import itertools
    import operator
    import math
    import random
    import datetime
    import time
    import calendar
    import string
    import unicodedata
    import codecs
    import locale
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import selectors
    import asyncore
    import asynchat
    import signal
    import mmap
    import email
    import json
    import mailcap
    import mailbox
    import mimetypes
    import base64
    import binhex
    import binascii
    import quopri
    import uu
    import html
    import xml
   

# Generated at 2022-06-16 19:36:51.628492
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import numpy as np
    import pandas as pd
    import datetime
    import time
    import random
    import string
    import math
    import re
    import json
    import pickle
    import base64
    import bz2
    import zlib
    import gzip
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import hashlib
    import hmac
    import uuid
    import os.path
    import glob
    import shutil
    import subprocess
    import multiprocessing
    import threading
    import socket
    import select
    import mmap
    import email
    import email.message
    import email.parser
    import email.policy
    import email.utils
    import email.mime
   

# Generated at 2022-06-16 19:36:58.337383
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = [1, 2, 3]
    frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['c'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['d'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['e'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['f'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['g'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 19:37:10.443812
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe()
        while frame.f_code.co_name != 'test_BaseVariable_items':
            frame = frame.f_back
        return frame

    def test_items(variable, expected):
        frame = get_frame()
        result = variable.items(frame)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_normalize(variable, expected):
        frame = get_frame()
        result = variable.items(frame, normalize=True)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_exclude(variable, expected):
        frame = get_frame()


# Generated at 2022-06-16 19:37:20.377577
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions

    def test_items(variable, frame, expected):
        actual = variable.items(frame)
        assert actual == expected, '{} != {}'.format(actual, expected)

    def test_items_normalize(variable, frame, expected):
        actual = variable.items(frame, normalize=True)
        assert actual == expected, '{} != {}'.format(actual, expected)

    def test_items_exception(variable, frame, exception):
        try:
            variable.items(frame)
        except exception:
            pass
        else:
            assert False, '{} not raised'.format(exception)


# Generated at 2022-06-16 19:37:29.619763
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame