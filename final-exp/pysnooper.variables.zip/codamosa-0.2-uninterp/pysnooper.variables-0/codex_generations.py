

# Generated at 2022-06-16 19:28:28.143984
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'


# Generated at 2022-06-16 19:28:39.844743
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    from . import utils
    from . import pycompat

    def get_frame():
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_name == 'test_BaseVariable_items':
                return frame
            frame = frame.f_back

    frame = get_frame()
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals

    # Test for method items of class BaseVariable

# Generated at 2022-06-16 19:28:48.288796
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='b', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))

# Generated at 2022-06-16 19:28:55.571051
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:29:07.483778
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils

    class BaseVariableTestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = (1, 2, 3)

# Generated at 2022-06-16 19:29:16.721409
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import pytest
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(level=0):
        frame = inspect.currentframe()
        while level > 0:
            frame = frame.f_back
            level -= 1
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_code(level=0):
        return get_frame(level).f_code

    def get_frame_code_filename(level=0):
        return get_frame_code(level).co_filename


# Generated at 2022-06-16 19:29:26.954908
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:29:37.664281
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    from . import utils
    from . import pycompat

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back

# Generated at 2022-06-16 19:29:39.039972
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices[1:3] == Indices('x', slice(1, 3))

# Generated at 2022-06-16 19:29:46.270912
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:29:59.483950
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:30:10.043447
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import collections
    import types
    import functools
    import itertools
    import operator
    import json
    import datetime
    import time
    import math
    import random
    import cmath
    import decimal
    import fractions
    import io
    import zipfile
    import gzip
    import bz2
    import lzma
    import hashlib
    import hmac
    import tempfile
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import selectors
    import asyncio
    import contextlib
    import logging
    import logging.config
    import logging.handlers
    import getpass
    import pwd
    import grp
    import platform
    import err

# Generated at 2022-06-16 19:30:21.222554
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b']) != Base

# Generated at 2022-06-16 19:30:33.191253
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a')

# Generated at 2022-06-16 19:30:42.422049
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:30:54.517959
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'd')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable

# Generated at 2022-06-16 19:31:05.058628
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    from . import pycompat

    def get_frame_info(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_tb(frame):
        return inspect.getframeinfo(frame)[2]

    def get_frame_info_tb_lineno(frame):
        return inspect.getframeinfo(frame)[2].lineno

    def get_frame_info_tb_filename(frame):
        return inspect.getframeinfo(frame)[2].filename

    def get_frame_info_tb_function(frame):
        return inspect.getframeinfo(frame)[2].function

    def get_frame_info_tb_code_context(frame):
        return inspect.getframeinfo(frame)[2].code_context


# Generated at 2022-06-16 19:31:16.428324
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import re
    import os
    import io
    import tempfile
    import datetime
    import time
    import random
    import math
    import fractions
    import decimal
    import cmath
    import functools
    import itertools
    import operator
    import collections
    import collections.abc
    import contextlib
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import asyncore
    import asynchat
    import signal
    import email
    import email.message
    import email.parser
    import email.policy
    import email.utils
    import email.mime
    import email.mime.application
    import email.mime.audio
    import email.mime.base
    import email.mime

# Generated at 2022-06-16 19:31:27.661421
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:31:39.026141
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:32:00.756338
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f

# Generated at 2022-06-16 19:32:12.007046
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')
    assert BaseVariable('a') != Indices('a')
    assert BaseVariable('a') != Exploding('a')
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a', 'b') == Attrs('a', 'b')

# Generated at 2022-06-16 19:32:21.571009
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:32:32.807017
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:32:44.793609
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 'c'}
    assert Keys('a').items(frame) == [('a', "{'b': 'c'}")]
    assert Keys('a').items(frame, normalize=True) == [('a', '{...}')]
    assert Keys('a', exclude='b').items(frame) == [('a', "{'b': 'c'}")]
    assert Keys('a', exclude='b').items(frame, normalize=True) == [('a', '{...}')]
    assert Keys('a', exclude=('b',)).items(frame) == [('a', "{'b': 'c'}")]

# Generated at 2022-06-16 19:32:51.652189
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    def test_func():
        a = 1
        b = 2
        c = 3
        return a, b, c

    frame = inspect.currentframe()
    frame = inspect.getouterframes(frame)[1][0]
    variable = TestVariable('a')
    assert variable.items(frame) == [('a', '1')]
    variable = TestVariable('b')
    assert variable.items(frame) == [('b', '2')]
    variable = TestVariable('c')
    assert variable.items(frame) == [('c', '3')]

# Generated at 2022-06-16 19:32:59.579606
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pytest
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from copy import deepcopy


# Generated at 2022-06-16 19:33:10.535886
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:33:21.511628
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import pprint
    import unittest
    import pdb
    import functools
    import collections
    import itertools
    import abc
    import copy
    import contextlib
    import io
    import dis
    import ast
    import tokenize
    import keyword
    import token
    import traceback
    import linecache
    import warnings
    import weakref
    import gc
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import pprint
    import unittest
    import pdb
    import functools
    import collections
    import itertools
    import abc
    import copy
    import contextlib
    import io
    import dis


# Generated at 2022-06-16 19:33:30.950208
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:34:04.321694
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import datetime
    import time
    import math
    import random
    import string
    import json
    import collections
    import functools
    import itertools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import locale
    import codecs
    import encodings
    import encodings.aliases
    import encodings.utf_8
    import encodings.latin_1
    import encodings.ascii
    import encodings.base64_codec
    import encodings.base64_decode
    import encodings.base64_encode
    import encodings.binascii_a2

# Generated at 2022-06-16 19:34:14.995978
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:34:25.760212
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:36.739046
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b', 'c', 'd'])
    assert Base

# Generated at 2022-06-16 19:34:48.564962
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:56.981605
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import builtins
    import __main__
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    import matplotlib.image as mpimg
    import matplotlib.colors as mcolors
    import matplotlib.cm as cm
    import matplotlib.dates as mdates
    import matplotlib.ticker as mticker
    import matplotlib.transforms as mtransforms
    import matplotlib.text as mtext
    import matplotlib.font_manager as mfont_manager
    import matplotlib.path as mpath
    import matplotlib.patches as mpatches
    import matplotlib.lines as mlines
    import matplotlib.legend as m

# Generated at 2022-06-16 19:35:08.702947
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')

# Generated at 2022-06-16 19:35:18.766893
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:35:30.396017
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 'c'}
    assert Keys('a').items(frame) == [('a', "{'b': 'c'}"), ('a[b]', "'c'")]
    assert Keys('a', exclude=['b']).items(frame) == [('a', "{'b': 'c'}")]
    assert Indices('a').items(frame) == [('a', "{'b': 'c'}"), ('a[0]', "'b'"), ('a[1]', "'c'")]
    assert Indices('a', exclude=['b']).items(frame) == [('a', "{'b': 'c'}"), ('a[0]', "'b'")]
    assert Attrs('a').items

# Generated at 2022-06-16 19:35:36.051528
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:36:17.995436
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:36:30.225729
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import pytest

    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return []

    def test_frame():
        return inspect.currentframe()

    def test_variable():
        return TestVariable('test_variable')

    def test_exclude():
        return TestVariable('test_exclude', exclude=['test_exclude'])

    def test_exclude_tuple():
        return TestVariable('test_exclude_tuple', exclude=('test_exclude_tuple',))

    def test_exclude_list():
        return TestVariable('test_exclude_list', exclude=['test_exclude_list'])


# Generated at 2022-06-16 19:36:40.347069
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import pprint
    import unittest
    import types
    import functools
    import itertools
    import collections
    import operator
    import random
    import string
    import re
    import math
    import datetime
    import time
    import io
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import ssl
    import selectors
    import select
    import signal
    import curses
    import curses.ascii
    import curses

# Generated at 2022-06-16 19:36:51.298241
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import os.path
    import re
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back


# Generated at 2022-06-16 19:36:58.120601
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:37:10.360219
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'a': 1, 'b': 2}
    frame.f_locals['b'] = [1, 2, 3]
    frame.f_locals['c'] = 'abc'
    frame.f_locals['d'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['e'] = [1, 2, 3, 4]
    frame.f_locals['f'] = 'abcdef'
    frame.f_locals['g'] = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    frame.f_locals['h'] = [1, 2, 3, 4, 5]

# Generated at 2022-06-16 19:37:17.900446
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:37:24.935559
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', exclude=['a'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['a']) == BaseVariable('a', exclude=['a'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['a', 'b'])
    assert BaseVariable('a', exclude=['a', 'b']) == BaseVariable('a', exclude=['a', 'b'])
    assert BaseVariable('a', exclude=['a', 'b']) != BaseVariable('a', exclude=['a', 'b', 'c'])
    assert Base

# Generated at 2022-06-16 19:37:37.469404
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'd')
    assert BaseVariable('a', 'b', 'c')

# Generated at 2022-06-16 19:37:43.308333
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import collections
    from . import utils

    def get_frame():
        frame = sys._getframe(1)
        while frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_code(frame):
        return frame.f_code

    def get_frame_code_name(frame):
        return frame.f_code.co_name

    def get_frame_code_filename(frame):
        return frame.f_code.co_filename
