

# Generated at 2022-06-16 19:28:44.171300
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import collections
    import types
    import functools
    import itertools
    import operator
    import random
    import string
    import datetime
    import time
    import math
    import fractions
    import decimal
    import io
    import contextlib
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import signal
    import mmap
    import email
    import json
    import zlib
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import filecmp
    import stat
    import struct
    import hashlib
    import base64
    import binascii
    import csv
    import xml.etree.ElementTree

# Generated at 2022-06-16 19:28:46.080472
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var = var[1:3]
    assert var._slice == slice(1, 3)

# Generated at 2022-06-16 19:28:52.790958
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1:3]._slice == slice(1, 3)
    assert Indices('a')[:]._slice == slice(None)
    assert Indices('a')[::2]._slice == slice(None, None, 2)
    assert Indices('a')[1:3:2]._slice == slice(1, 3, 2)
    assert Indices('a')[::-1]._slice == slice(None, None, -1)
    assert Indices('a')[3:1:-1]._slice == slice(3, 1, -1)
    assert Indices('a')[3:1:-2]._slice == slice(3, 1, -2)
    assert Indices('a')[3:1:2]._slice == slice(3, 1, 2)

# Generated at 2022-06-16 19:28:58.727879
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice == slice(1, 3)
    assert v[1:3]._slice

# Generated at 2022-06-16 19:28:59.701187
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:29:11.637873
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['a'] = 'a'
            self.frame.f_locals['b'] = 'b'
            self.frame.f_locals['c'] = 'c'
            self.frame.f_locals['d'] = 'd'
            self.frame.f_locals['e'] = 'e'
            self.frame.f_locals['f'] = 'f'
            self.frame.f_locals['g'] = 'g'
            self.frame.f_locals['h'] = 'h'
            self.frame.f_locals['i']

# Generated at 2022-06-16 19:29:15.782941
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b', 'd'))

# Generated at 2022-06-16 19:29:22.364332
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:29:30.455549
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from .utils import get_shortish_repr
    from .pycompat import ABC
    from .pycompat import ensure_tuple
    from .pycompat import get_function_code
    from .pycompat import get_function_defaults
    from .pycompat import get_function_globals
    from .pycompat import get_function_locals
    from .pycompat import get_function_closure
    from .pycompat import get_function_annotations


# Generated at 2022-06-16 19:29:39.989495
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import functools
    import collections
    import itertools
    import operator
    import datetime
    import decimal
    import fractions
    import io
    import os
    import random
    import re
    import socket
    import string
    import struct
    import threading
    import time
    import traceback
    import types
    import warnings
    import weakref
    import xml.etree.ElementTree
    import xml.sax
    import xml.sax.saxutils
    import xml.sax.xmlreader
    import zipfile
    import zlib
    import unittest
    import doctest
    import pdb
    import pprint
    import pydoc
    import unittest.mock
    import unittest.result
    import unittest.runner

# Generated at 2022-06-16 19:29:55.578016
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pytest
    import pycompat
    import utils
    import BaseVariable
    import CommonVariable
    import Attrs
    import Keys
    import Indices
    import Exploding
    import inspect
    import sys
    import os
    import re
    import types
    import pytest
    import pycompat
    import utils
    import BaseVariable
    import CommonVariable
    import Attrs
    import Keys
    import Indices
    import Exploding
    import inspect
    import sys
    import os
    import re
    import types
    import pytest
    import pycompat
    import utils
    import BaseVariable
    import CommonVariable
    import Attrs
    import Keys
    import Indices
    import Exploding
    import inspect


# Generated at 2022-06-16 19:30:07.667427
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils
    from . import pycompat

    class BaseVariableTestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f

# Generated at 2022-06-16 19:30:19.298277
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:31.846810
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'd')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable

# Generated at 2022-06-16 19:30:41.805616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:30:51.070412
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'


# Generated at 2022-06-16 19:31:02.682274
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    def get_frame(level=1):
        frame = sys._getframe(level)
        if pycompat.PY2:
            frame = inspect.getouterframes(frame)[level][0]
        return frame

    def test_variable(variable, expected):
        frame = get_frame(2)
        result = variable.items(frame)
        assert result == expected

    test_variable(BaseVariable('a'), [('a', '1')])
    test_variable(BaseVariable('a.b'), [('a.b', '2')])
    test_variable(BaseVariable('a.b.c'), [('a.b.c', '3')])

# Generated at 2022-06-16 19:31:14.814404
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:31:26.417775
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable

# Generated at 2022-06-16 19:31:32.599918
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd', 'e')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd', 'e', 'f')
    assert BaseVariable

# Generated at 2022-06-16 19:31:55.459971
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y')

# Generated at 2022-06-16 19:32:01.581645
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('b', exclude=('b',))


# Generated at 2022-06-16 19:32:12.757014
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import collections
    import numpy as np
    import pandas as pd
    import xarray as xr
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim
    import torchvision
    import torchvision.transforms as transforms
    import torchvision.datasets as datasets
    import torchvision.models as models
    import torch.utils.data as data
    import torch.utils.data.dataloader as dataloader
    import torch.utils.data.sampler as sampler
    import torch.utils.data.distributed as distributed
    import torch.utils.data.dataset as dataset
    import torch.utils.data.random_sampler as random_sampler
    import torch.utils.data

# Generated at 2022-06-16 19:32:22.129905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:31.798589
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['a']) == BaseVariable('a', exclude=['a'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['a', 'b'])
    assert BaseVariable('a', exclude=['a', 'b']) != BaseVariable('a', exclude=['a'])


# Generated at 2022-06-16 19:32:43.797742
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:32:51.175161
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:32:59.302357
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    import unittest.mock as mock

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()

# Generated at 2022-06-16 19:33:10.369318
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pytest
    import pdb
    from . import utils
    from . import pycompat
    from . import variables
    from . import config
    from . import pdbpp
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion
    from . import importmagic
    from . import sticky
    from . import importcompletion

# Generated at 2022-06-16 19:33:21.451230
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:34:02.924067
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import collections
    import datetime
    import decimal
    import fractions
    import functools
    import itertools
    import operator
    import os
    import re
    import shutil
    import subprocess
    import sys
    import tempfile
    import threading
    import time
    import traceback
    import types
    import unittest
    import weakref
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.sax.handler
    import xml.sax.saxutils
    import xml.sax.xmlreader
    import zipfile
    import zlib
    import _ast
    import _bisect
    import _codecs
    import _collections
   

# Generated at 2022-06-16 19:34:13.399004
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:34:24.329811
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils

    def get_frame(level=0):
        frame = inspect.currentframe()
        while level > 0:
            frame = frame.f_back
            level -= 1
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_locals_and_globals(level=0):
        frame = get_frame(level)
        return frame.f_locals, frame.f_globals


# Generated at 2022-06-16 19:34:35.647517
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class BaseVariableTest(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:34:44.936632
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import functools
    import itertools
    import operator
    import os
    import random
    import re
    import string
    import time
    import datetime
    import math
    import fractions
    import decimal
    import cmath
    import io
    import json
    import pickle
    import zipfile
    import zlib
    import hashlib
    import hmac
    import base64
    import binascii
    import tempfile
    import threading
    import multiprocessing
    import subprocess
    import socket
    import ssl
    import select
    import asyncore
    import asynchat
    import signal
    import mmap
    import readline
    import rlcompleter
    import curses

# Generated at 2022-06-16 19:34:54.419639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    print(frame.f_code.co_name)
    print(frame.f_code.co_filename)
    print(frame.f_lineno)
    print(frame.f_locals)
    print(frame.f_globals)
    print(frame.f_back)
    print(frame.f_back.f_locals)
    print(frame.f_back.f_globals)
    print(frame.f_back.f_code.co_name)
    print(frame.f_back.f_code.co_filename)
    print(frame.f_back.f_lineno)
    print(frame.f_back.f_back)

# Generated at 2022-06-16 19:35:06.312278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import random
    import string
    import collections
    import datetime
    import decimal
    import fractions
    import uuid
    import numpy
    import pandas
    import pytz
    import pytest
    from . import utils

    def get_random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def get_random_dict(length):
        return {get_random_string(random.randint(1, 10)): random.randint(1, 10) for _ in range(length)}

    def get_random_list(length):
        return [random.randint(1, 10) for _ in range(length)]

    def get_random_tuple(length):
        return tuple

# Generated at 2022-06-16 19:35:17.003699
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(func):
        frame = sys._getframe()
        while frame.f_code.co_name != func.__name__:
            frame = frame.f_back
        return frame

    def get_frame_locals(func):
        frame = get_frame(func)
        return frame.f_locals

    def get_frame_globals(func):
        frame = get_frame(func)
        return frame.f_globals

    def get_frame_code(func):
        frame = get_frame(func)
        return frame.f_code

    def get_frame_code_name(func):
        frame = get_

# Generated at 2022-06-16 19:35:23.658977
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import numpy as np
    from . import utils
    from . import pycompat

    def get_frame(level=1):
        return inspect.getouterframes(inspect.currentframe())[level][0]

    def get_frame_locals(level=1):
        return inspect.getouterframes(inspect.currentframe())[level][0].f_locals

    def get_frame_globals(level=1):
        return inspect.getouterframes(inspect.currentframe())[level][0].f_globals

    def get_frame_builtins(level=1):
        return inspect.getouterframes(inspect.currentframe())[level][0].f_builtins


# Generated at 2022-06-16 19:35:32.929677
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint

# Generated at 2022-06-16 19:36:16.557113
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')
    assert var1 == var2
    assert var1 != var3


# Generated at 2022-06-16 19:36:28.117244
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:36:38.911523
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import re
    import os
    import io
    import tempfile
    import subprocess
    import builtins
    import math
    import functools
    import operator
    import collections
    import itertools
    import random
    import time
    import datetime
    import threading
    import multiprocessing
    import queue
    import asyncio
    import contextlib
    import json
    import pickle
    import base64
    import hashlib
    import hmac
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import zipapp
    import shutil
    import pathlib
    import tempfile
    import filecmp
    import stat
    import fnmatch
    import glob
    import os

# Generated at 2022-06-16 19:36:45.113023
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import types
    import functools
    import collections
    import itertools
    import operator
    import math
    import random
    import datetime
    import time
    import re
    import string
    import unicodedata
    import codecs
    import io
    import json
    import pickle
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import socket
    import select
    import mmap
    import ssl
    import hashlib
    import hmac
    import struct
    import base64
    import binascii
    import zlib
    import zipfile
    import tarfile
    import gzip
    import bz2
    import lzma
    import csv
    import xml.etree

# Generated at 2022-06-16 19:36:55.053377
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    class TestVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            super(TestVariable, self).__init__(source, exclude)

        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    def test_items(self):
        frame = inspect.currentframe()
        frame = frame.f_back
        frame = frame.f_back
        frame = frame.f_back
        frame = frame.f_back
        frame = frame.f_back
        frame = frame.f_back
        frame = frame.f_back
       

# Generated at 2022-06-16 19:37:06.592940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame_info = inspect.getframeinfo(self.frame)
            self.frame_locals = self.frame.f_locals
            self.frame_globals = self.frame.f_globals
            self.frame_code = self.frame.f_code
            self.frame_code_co_filename = self.frame_code.co_filename
            self.frame_code_co_name = self.frame_code.co_name
            self.frame_code_co_firstlineno = self.frame_code.co_firstlineno

# Generated at 2022-06-16 19:37:17.231059
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:37:24.578763
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:37:37.468799
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:37:43.284498
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame_locals = frame.f_locals
            frame_globals = frame.f_globals
            frame_builtins = frame_globals['__builtins__']
            frame_builtins_type = type(frame_builtins)
            frame_builtins_name = frame_builtins_type.__name__
            frame_builtins_module = frame_builtins_type.__module__
            frame_builtins_module_name = frame_builtins_module.split('.')[-1]
            frame_builtins_module_name = frame_builtins_