

# Generated at 2022-06-16 19:28:22.883300
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'x'

# Generated at 2022-06-16 19:28:24.853920
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:28:33.028842
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:28:42.231200
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('b', exclude=['b'])


# Generated at 2022-06-16 19:28:53.495541
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import itertools
    import collections
    import operator
    import fractions
    import decimal
    import io
    import json
    import pickle
    import zipfile
    import tempfile
    import shutil
    import subprocess
    import multiprocessing
    import threading
    import logging
    import socket
    import ssl
    import select
    import asyncore
    import asynchat
    import signal
    import email
    import email.parser
    import email.policy
    import email.message
    import email.mime
    import email.mime.text
    import email.mime.multip

# Generated at 2022-06-16 19:29:04.582621
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:29:08.363096
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[:] == indices
    assert indices[1:3] != indices
    assert indices[1:3]._slice == slice(1, 3)

# Generated at 2022-06-16 19:29:17.280986
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    assert var[1:3] == Indices('a', slice(1, 3))
    assert var[1:3] != Indices('a', slice(1, 2))
    assert var[1:3] != Indices('a', slice(1, 3, 2))
    assert var[1:3] != Indices('a', slice(1, 3, 1))
    assert var[1:3] != Indices('a', slice(1, 3, None))
    assert var[1:3] != Indices('b', slice(1, 3))
    assert var[1:3] != Indices('a', slice(1, 4))
    assert var[1:3] != Indices('a', slice(1, 3, 2))

# Generated at 2022-06-16 19:29:27.369264
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import functools
    import operator

    def get_frame():
        def f():
            return inspect.currentframe()
        return f()

    def get_frame_locals():
        return get_frame().f_locals

    def get_frame_globals():
        return get_frame().f_globals

    def get_frame_builtins():
        return get_frame_globals()['__builtins__']

    def get_frame_functions():
        return get_frame_globals().values()

    def get_frame_modules():
        return sys.modules.values()


# Generated at 2022-06-16 19:29:36.603337
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a', exclude=())
    assert BaseVariable('a', exclude=('a',)) == BaseVariable('a', exclude=('a',))
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a')
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:29:53.496007
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) == BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) != BaseVariable('x', exclude=['y'])

# Generated at 2022-06-16 19:30:05.280971
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')

# Generated at 2022-06-16 19:30:16.799517
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:25.850987
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:30:35.443030
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:30:46.742705
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_BaseVariable_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame

# Generated at 2022-06-16 19:30:52.276695
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:31:03.698704
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])

# Generated at 2022-06-16 19:31:14.965915
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('y', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('y', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'y', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'y', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'y', 'z')

# Generated at 2022-06-16 19:31:19.769185
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    from . import utils
    from . import pycompat
    from . import variables
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from .variables import needs_parentheses
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from .variables import needs_parentheses
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs


# Generated at 2022-06-16 19:31:44.120660
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import unittest
    import pprint
    import io
    import contextlib

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f

# Generated at 2022-06-16 19:31:54.855419
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 19:31:58.043036
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    assert v1 == v2
    assert v1 != v3


# Generated at 2022-06-16 19:32:09.544443
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')

# Generated at 2022-06-16 19:32:19.500508
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import sys
    import inspect
    import types
    import builtins
    import collections
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    from . import utils
    from . import pycompat

    def needs_parentheses(source):
        def code(s):
            return compile(s, '<variable>', 'eval').co_code

        return code('{}.x'.format(source)) != code('({}).x'.format(source))


    class BaseVariable(pycompat.ABC):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_t

# Generated at 2022-06-16 19:32:26.514912
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import datetime
    import decimal
    import fractions
    import functools
    import itertools
    import math
    import operator
    import os
    import random
    import re
    import string
    import time
    import unicodedata
    import zipfile
    import zlib
    import _thread
    import _threading_local
    import _weakref
    import _weakrefset
    import abc
    import array
    import ast
    import asyncio
    import asyncio.base_events
    import asyncio.base_futures
    import asyncio.base_subprocess
    import asyncio.base_tasks
    import asyncio.base_transports
    import asyncio.constants
    import asyncio.corout

# Generated at 2022-06-16 19:32:33.074368
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])


# Generated at 2022-06-16 19:32:45.060277
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'd'])

# Generated at 2022-06-16 19:32:54.813475
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import unittest
    from . import utils
    from . import pycompat
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import py

# Generated at 2022-06-16 19:33:00.200299
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))

# Generated at 2022-06-16 19:33:52.666961
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:03.994943
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:14.664540
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def test_items(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_normalize(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_exclude(variable, frame, expected):
        result = variable.items(frame, exclude=('a', 'b'))
        assert result == expected, '{} != {}'.format(result, expected)


# Generated at 2022-06-16 19:34:20.734575
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:34:28.831534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = [1, 2, 3]
            self.frame.f_locals['c'] = {'a': 1, 'b': 2}
            self.frame.f_locals['d'] = types.SimpleNamespace(a=1, b=2)
            self.frame.f_locals['e'] = sys
            self.frame.f_locals['f'] = 'abc'


# Generated at 2022-06-16 19:34:38.584714
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import functools
    import collections
    import itertools
    import operator
    import math
    import random
    import string
    import time
    import datetime
    import threading
    import queue
    import json
    import io
    import socket
    import select
    import subprocess
    import tempfile
    import shutil
    import zipfile
    import tarfile
    import gzip
    import bz2
    import lzma
    import hashlib
    import zlib
    import base64
    import binascii
    import codecs
    import csv
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat
   

# Generated at 2022-06-16 19:34:49.991703
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import random
    import string
    import collections
    import numbers
    import numpy as np
    import pandas as pd
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    import torch.optim as optim
    import torchvision
    import torchvision.transforms as transforms
    import torchvision.datasets as datasets
    import torchvision.models as models
    import torch.utils.data as data
    import torch.utils.data.sampler as sampler
    import torch.utils.data.dataloader as dataloader
    import torch.utils.data.distributed as distributed
    import torch.utils.data.dataset as dataset
    import torch.utils.data.sampler as sampler
    import torch.utils.data

# Generated at 2022-06-16 19:34:58.071821
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from collections import Mapping, Sequence
    import itertools
    import abc
    import sys
    import os
    import inspect
    import types
    import pytest
    import re
    import ast
    import astor
    import astunparse
    import astpretty
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse
    import astpretty
    import ast
    import astor
    import astunparse


# Generated at 2022-06-16 19:35:09.757324
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import io
    import contextlib
    import unittest
    from unittest import mock
    from unittest.mock import patch
    from io import StringIO
    from io import BytesIO
    from types import FrameType
    from types import TracebackType
    from types import CodeType
    from types import ModuleType
    from types import SimpleNamespace
    from types import GeneratorType
    from types import MethodType
    from types import BuiltinFunctionType
    from types import BuiltinMethodType
    from types import FunctionType
    from types import LambdaType
    from types import MappingProxyType
    from types import MemberDescriptorType
    from types import GetSetDescriptorType
    from types import WrapperDescriptorType
    from types import MethodWrapperType
    from types import MethodDescriptor

# Generated at 2022-06-16 19:35:19.592357
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b'], extra=1)
    assert BaseVariable('a', exclude=['b'], extra=1) == BaseVariable('a', exclude=['b'], extra=1)
    assert Base

# Generated at 2022-06-16 19:36:04.725799
# Unit test for method __eq__ of class BaseVariable

# Generated at 2022-06-16 19:36:14.453002
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def test_items(variable, frame, expected_items):
        items = variable.items(frame)
        assert items == expected_items, '{} != {}'.format(items, expected_items)

    def test_items_normalize(variable, frame, expected_items):
        items = variable.items(frame, normalize=True)
        assert items == expected_items, '{} != {}'.format(items, expected_items)

    def test_items_exclude(variable, frame, expected_items):
        items = variable.items(frame, exclude=('a', 'b'))
        assert items == expected_items, '{} != {}'.format(items, expected_items)


# Generated at 2022-06-16 19:36:25.995602
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    a = BaseVariable('a', exclude=['b'])
    assert a.items(frame) == [('a', '1')]
    b = BaseVariable('b', exclude=['b'])
    assert b.items(frame) == [('b', '2')]
    c = BaseVariable('c', exclude=['b'])
    assert c.items(frame) == [('c', '3')]
    d = BaseVariable('d', exclude=['b'])
    assert d.items(frame) == [('d', '4')]
    e = BaseVariable('e', exclude=['b'])
    assert e.items(frame) == [('e', '5')]
    f = BaseVariable('f', exclude=['b'])

# Generated at 2022-06-16 19:36:37.099694
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:36:44.180500
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    from . import utils

    def get_frame_info(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_2(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_3(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_4(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_5(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_6(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_7(frame):
        return inspect.getframeinfo(frame)


# Generated at 2022-06-16 19:36:54.618171
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:37:06.210625
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:37:16.698846
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import collections
    import itertools
    import functools
    import operator
    import math
    import random
    import datetime
    import time
    import io
    import json
    import pickle
    import hashlib
    import zlib
    import base64
    import codecs
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import glob
    import os.path
    import filecmp
    import pathlib
    import stat
    import errno
    import mmap
    import fcntl
    import subprocess
    import multiprocessing
    import concurrent
    import concurrent.futures


# Generated at 2022-06-16 19:37:27.034825
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt

    def test_func():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
       

# Generated at 2022-06-16 19:37:30.714333
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    assert v1 == v2
    assert v1 != v3
    assert v2 != v3
