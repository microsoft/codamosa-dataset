

# Generated at 2022-06-16 19:28:30.309337
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd', 'e')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c', 'd', 'e', 'f')
    assert BaseVariable

# Generated at 2022-06-16 19:28:43.164887
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('y', 'z'))
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x')
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x')

# Generated at 2022-06-16 19:28:53.714616
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils

    def get_frame():
        frame = sys._getframe()
        while frame.f_globals['__name__'] == 'inspect':
            frame = frame.f_back
        return frame

    def test_items(variable, expected):
        frame = get_frame()
        assert variable.items(frame) == expected

    def test_items_normalize(variable, expected):
        frame = get_frame()
        assert variable.items(frame, normalize=True) == expected

    def test_items_exclude(variable, expected):
        frame = get_frame()
        assert variable.items(frame, exclude=('x',)) == expected

    def test_items_exclude_normalize(variable, expected):
        frame

# Generated at 2022-06-16 19:28:55.715630
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    assert var[1:3] == Indices('x', slice(1, 3))

# Generated at 2022-06-16 19:28:58.613551
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)


# Generated at 2022-06-16 19:29:10.410255
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:29:18.392353
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    from . import utils
    from . import pycompat

    def get_frame(depth=0):
        frame = inspect.currentframe()
        for _ in range(depth + 1):
            frame = frame.f_back
        return frame

    def get_frame_locals(depth=0):
        return get_frame(depth).f_locals

    def get_frame_globals(depth=0):
        return get_frame(depth).f_globals

    def get_frame_code(depth=0):
        return get_frame(depth).f_code

    def get_frame_lineno(depth=0):
        return get_frame(depth).f_lineno


# Generated at 2022-06-16 19:29:20.672636
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    assert v[1:3] == Indices('x', slice(1, 3))

# Generated at 2022-06-16 19:29:29.039434
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pprint
    import types
    import builtins

    frame = sys._getframe()
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals
    frame_builtins = frame_globals['__builtins__']

    # Test for class BaseVariable
    # Test for method items of class BaseVariable
    # Test for method items of class BaseVariable when source is a variable
    # Test for method items of class BaseVariable when source is a variable and exclude is a variable
    # Test for method items of class BaseVariable when source is a variable and exclude is a variable and normalize is True
    # Test for method items of class BaseVariable when source is a variable and exclude is a variable and normalize is False
    # Test for method items of class BaseVariable when source is a

# Generated at 2022-06-16 19:29:31.400841
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var = var[1:3]
    assert var._slice == slice(1, 3)

# Generated at 2022-06-16 19:29:48.656336
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_frame(frame):
        frame.f_locals['a'] = 1
        frame.f_locals['b'] = 2
        frame.f_locals['c'] = 3
        frame.f_locals['d'] = 4
        frame.f_locals['e'] = 5
        frame.f_locals['f'] = 6
        frame.f_locals['g'] = 7
        frame.f_locals['h'] = 8
        frame.f_locals['i'] = 9
        frame.f_locals['j'] = 10
        frame.f_locals['k'] = 11
        frame.f_locals['l'] = 12
        frame.f_locals['m'] = 13
        frame.f_locals['n'] = 14

# Generated at 2022-06-16 19:29:57.235573
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:30:09.242019
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:30:12.039247
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:30:22.095373
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')

# Generated at 2022-06-16 19:30:33.430904
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:42.523528
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    def test_func():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_func2():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_func3():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_func4():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_func5():
        a = 1
        b = 2
        c = 3
        return a

# Generated at 2022-06-16 19:30:54.565903
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions
    from . import config
    from . import compat
    from . import filters
    from . import hooks
    from . import formatters
    from . import processors
    from . import post_mortem
    from . import debugger
    from . import cli
    from . import main
    from . import tests
    from . import version
    from . import __main__
    from . import __version__
    from . import __about__
    from . import __pdoc__
    from . import __init__
    from . import __all__
    from . import __author__
    from . import __copyright__
    from . import __license__
    from . import __title__


# Generated at 2022-06-16 19:31:05.057004
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        frame = sys._getframe(1)
        if pycompat.PY2:
            frame = inspect.getouterframes(frame)[1][0]
        return frame

    def test_variable(variable, expected):
        frame = get_frame()
        result = list(variable.items(frame))
        assert result == expected

    def test_variable_normalized(variable, expected):
        frame = get_frame()
        result = list(variable.items(frame, normalize=True))
        assert result == expected

    def test_variable_exclude(variable, exclude, expected):
        frame = get_frame()
        result = list(variable.items(frame))
        assert result

# Generated at 2022-06-16 19:31:16.422321
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    from . import pycompat

    def get_frame():
        frame = inspect.currentframe()
        while frame.f_back:
            frame = frame.f_back
        return frame

    def get_items(source, exclude=()):
        return BaseVariable(source, exclude).items(get_frame())

    def assert_items(source, expected, exclude=()):
        actual = get_items(source, exclude)
        assert actual == expected, '{} != {}'.format(actual, expected)

    assert_items('x', [('x', '1')])
    assert_items('x.y', [('x.y', '2')])
    assert_items('x.y.z', [('x.y.z', '3')])

# Generated at 2022-06-16 19:31:44.606948
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys
    import re
    import types
    import inspect
    import sys

# Generated at 2022-06-16 19:31:55.887865
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'y': 'z'}
    assert list(Keys('x').items(frame)) == [('x', "{'y': 'z'}")]
    assert list(Keys('x').items(frame, normalize=True)) == [('x', '{...}')]
    assert list(Keys('x').items(frame)) == [('x', "{'y': 'z'}")]
    assert list(Keys('x').items(frame, normalize=True)) == [('x', '{...}')]
    assert list(Keys('x').items(frame)) == [('x', "{'y': 'z'}")]

# Generated at 2022-06-16 19:32:06.166746
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9
            self.frame.f

# Generated at 2022-06-16 19:32:16.637905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:21.760133
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('a')
    d = BaseVariable('a', exclude=['b'])
    e = BaseVariable('a', exclude=['b'])
    f = BaseVariable('a', exclude=['c'])
    assert a == c
    assert d == e
    assert a != b
    assert a != d
    assert d != f


# Generated at 2022-06-16 19:32:33.118817
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import collections
    import types
    import datetime
    import time
    import math
    import random
    import string
    import itertools
    import functools
    import operator
    import json
    import pprint
    import copy
    import hashlib
    import base64
    import zlib
    import io
    import tempfile
    import subprocess
    import threading
    import multiprocessing
    import concurrent
    import concurrent.futures
    import asyncio
    import contextlib
    import socket
    import ssl
    import select
    import selectors
    import queue
    import urllib
    import urllib.request
    import urllib.parse
    import urllib.error
    import http
   

# Generated at 2022-06-16 19:32:45.060596
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 'a'
    frame.f_locals['b'] = 'b'
    frame.f_locals['c'] = 'c'
    frame.f_locals['d'] = 'd'
    frame.f_locals['e'] = 'e'
    frame.f_locals['f'] = 'f'
    frame.f_locals['g'] = 'g'
    frame.f_locals['h'] = 'h'
    frame.f_locals['i'] = 'i'
    frame.f_locals['j'] = 'j'
    frame.f_locals['k'] = 'k'
    frame.f_locals['l'] = 'l'
    frame.f_loc

# Generated at 2022-06-16 19:32:51.777500
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:32:59.651963
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os

    def test_function():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back

# Generated at 2022-06-16 19:33:10.595545
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 'b'
            self.frame.f_locals['c'] = {'c': 'c'}
            self.frame.f_locals['d'] = ['d']
            self.frame.f_locals['e'] = [1, 2, 3]
            self.frame.f_locals['f'] = (1, 2, 3)
            self.frame.f_locals['g'] = {'g': 'g'}
            self.frame.f

# Generated at 2022-06-16 19:33:36.858905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def get_frame_info(frame):
        return (frame.f_code.co_filename, frame.f_code.co_name, frame.f_lineno)

    def get_frame_info_from_traceback(tb):
        return get_frame_info(tb.tb_frame)

    def get_frame_info_from_frame(frame):
        return get_frame_info(frame)

    def get_frame_info_from_current_frame():
        return get_frame_info(inspect.currentframe())

    def get_frame_info_from_current_traceback():
        return get_frame_info_from_traceback(sys.exc_info()[2])

   

# Generated at 2022-06-16 19:33:48.644276
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')

# Generated at 2022-06-16 19:33:59.933245
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    from . import utils
    from . import pycompat

    class TestClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

    def test_function(x, y):
        return x + y

    def test_function_with_default_arg(x, y=1):
        return x + y

    def test_function_with_varargs(*args):
        return args

    def test_function_with_kwargs(**kwargs):
        return kwargs

    def test_function_with_default_kwargs(x, y=1, **kwargs):
        return x + y + sum(kwargs.values())


# Generated at 2022-06-16 19:34:07.356952
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import functools
    import collections
    import itertools
    import operator
    import random
    import string
    import datetime
    import time
    import os
    import io
    import tempfile
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import json
    import pickle
    import xmlrpc.client
    import xmlrpc.server
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.etree.cElementTree
    import xml.parsers.expat
    import xml.dom.pulldom
    import xml.dom.minidom
    import xml.dom.ext
    import xml.dom.xmlbuilder

# Generated at 2022-06-16 19:34:16.688947
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    from . import utils

    def test_function():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33

# Generated at 2022-06-16 19:34:27.011946
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:34:37.426824
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import io
    import contextlib
    import traceback
    import pprint
    import re
    import warnings
    import os
    import tempfile
    import shutil
    import subprocess
    import sysconfig
    import importlib
    import zipfile
    import tokenize
    import token
    import keyword
    import runpy
    import pkgutil
    import pkg_resources
    import distutils.util
    import distutils.sysconfig
    import distutils.core
    import distutils.errors
    import distutils.command.build_ext
    import distutils.command.build_py
    import distutils.command.build_scripts
    import distutils.command.install_lib
    import distutils.command.install_scripts

# Generated at 2022-06-16 19:34:49.212364
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types

    def test_frame():
        return inspect.currentframe().f_back

    def test_frame_with_locals():
        a = 1
        b = 2
        return inspect.currentframe().f_back

    def test_frame_with_globals():
        global c
        c = 3
        return inspect.currentframe().f_back

    def test_frame_with_builtins():
        return inspect.currentframe().f_back

    def test_frame_with_closure():
        def closure():
            return d
        return inspect.currentframe().f_back

    def test_frame_with_class():
        class TestClass(object):
            pass
        return inspect.currentframe().f_back

    def test_frame_with_instance():
        return inspect.current

# Generated at 2022-06-16 19:34:57.475920
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:35:09.211021
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    while frame:
        if frame.f_code.co_name == 'test_BaseVariable_items':
            break
        frame = frame.f_back
    assert frame
    assert frame.f_code.co_name == 'test_BaseVariable_items'
    assert frame.f_code.co_filename == __file__
    assert frame.f_code.co_firstlineno == __name__.count('.') + 1
    assert frame.f_code.co_varnames == ('frame',)
    assert frame.f_code.co_argcount == 1
    assert frame.f_code.co_flags == 67
    assert frame.f_code.co_nlocals == 1
    assert frame.f