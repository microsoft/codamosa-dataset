

# Generated at 2022-06-16 19:28:35.326182
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys

    def f():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33
        hh = 34
        ii = 35
        jj = 36


# Generated at 2022-06-16 19:28:46.884585
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:28:51.720338
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'
    assert indices_slice._fingerprint == (Indices, 'a', ())
    assert indices_slice._slice == slice(1, 3)

# Generated at 2022-06-16 19:28:59.352204
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('foo')
    assert var[1:3] == Indices('foo', slice(1, 3))
    assert var[1:3] != Indices('foo', slice(1, 4))
    assert var[1:3] != Indices('foo', slice(2, 3))
    assert var[1:3] != Indices('foo', slice(1, 3, 2))
    assert var[1:3] != Indices('foo', slice(1, 3, 1))

# Generated at 2022-06-16 19:29:11.273581
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[:] is indices
    assert indices[1:] is not indices
    assert indices[1:] == indices[1:]
    assert indices[1:] != indices[2:]
    assert indices[1:] != indices[1:2]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:] != indices[1:2:3]
    assert indices[1:]

# Generated at 2022-06-16 19:29:16.155484
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)
    assert var_slice.source == 'a'
    assert var_slice.exclude == ()
    assert var_slice.code == var.code
    assert var_slice.unambiguous_source == var.unambiguous_source
    assert var_slice._fingerprint == var._fingerprint

# Generated at 2022-06-16 19:29:22.411170
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('a')
    d = BaseVariable('a', exclude=('b',))
    e = BaseVariable('a', exclude=('b',))
    f = BaseVariable('a', exclude=('c',))
    assert a == c
    assert d == e
    assert a != b
    assert a != d
    assert d != f

# Generated at 2022-06-16 19:29:30.492241
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:29:35.977932
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')


# Generated at 2022-06-16 19:29:37.701918
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:2] == Indices('a', slice(1, 2))

# Generated at 2022-06-16 19:29:54.038967
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import collections
    from . import utils
    from . import pycompat
    from . import variables
    from . import config
    from . import frames
    from . import excinfo
    from . import traceback
    from . import runner
    from . import reporting
    from . import main
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion
    from . import assertion

# Generated at 2022-06-16 19:29:59.588499
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:30:10.134068
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:30:20.707339
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y')


# Generated at 2022-06-16 19:30:32.738855
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:30:42.211463
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import functools
    import collections
    import itertools
    import operator

    def get_frame_locals(frame):
        return {
            key: value
            for key, value in frame.f_locals.items()
            if key != '__builtins__'
        }

    def get_frame_globals(frame):
        return {
            key: value
            for key, value in frame.f_globals.items()
            if key != '__builtins__'
        }

    def get_frame_locals_and_globals(frame):
        return {
            **get_frame_locals(frame),
            **get_frame_globals(frame)
        }


# Generated at 2022-06-16 19:30:54.521742
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import pprint
    import io
    import contextlib
    import unittest
    import unittest.mock
    import pdb
    import pdb.tests.support

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals

# Generated at 2022-06-16 19:31:05.028587
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import doctest
    import pprint
    import contextlib
    import io
    import tempfile
    import shutil
    import subprocess
    import time
    import datetime
    import random
    import math
    import fractions
    import decimal
    import itertools
    import functools
    import operator
    import collections
    import collections.abc
    import array
    import weakref
    import weakproxy
    import abc
    import reprlib
    import enum
    import numbers
    import io
    import pickle
    import copy
    import gc
    import inspect
    import dis
    import keyword
    import token
    import tokenize
    import traceback
    import linecache
    import warnings
    import context

# Generated at 2022-06-16 19:31:14.704281
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:31:26.333550
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import time
    import datetime
    import math
    import random
    import functools
    import itertools
    import operator
    import collections
    import json
    import csv
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax.saxutils
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.client
    import email.message
    import email.parser
    import email.policy
    import email.utils
    import email.mime.text
    import email.mime.multipart
    import email.mime.application
    import email.mime.audio
    import email.m

# Generated at 2022-06-16 19:31:48.323274
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'hello'

# Generated at 2022-06-16 19:31:53.350015
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:32:02.402545
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:32:08.946401
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:32:19.026709
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:32:21.571124
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')
    assert var1 == var2
    assert var1 != var3


# Generated at 2022-06-16 19:32:32.852311
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:32:44.839364
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import operator
    import itertools
    import collections
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import asyncio
    import logging
    import traceback
    import pprint
    import pdb
    import bdb
    import code
    import codeop
    import dis
    import ast
    import symtable
    import symbol
    import token
    import keyword
    import tokenize
    import tabnanny
    import pyclbr
    import py_compile
    import compileall
    import zipimport
    import pkgutil
    import modulefinder
    import runpy


# Generated at 2022-06-16 19:32:50.419074
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('x')
    assert BaseVariable('x') != Attrs('x')
    assert BaseVariable('x') != Keys('x')
    assert BaseVariable('x') != Indices('x')
    assert BaseVariable('x') != Exploding('x')


# Generated at 2022-06-16 19:32:58.921587
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_globals['a'] = 1
            self.frame.f_globals['b'] = 2
            self.frame.f_globals['c'] = 3
            self.frame.f_globals['d'] = 4
            self.frame.f_globals['e'] = 5
            self.frame.f_globals['f'] = 6
            self.frame.f_globals['g'] = 7
            self.frame.f_globals['h'] = 8
            self.frame.f_globals['i'] = 9
            self.frame

# Generated at 2022-06-16 19:33:31.767134
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import time
    import datetime
    import random
    import string
    import math
    import functools
    import operator
    import itertools
    import collections
    import array
    import json
    import base64
    import hashlib
    import hmac
    import binascii
    import socket
    import ssl
    import selectors
    import threading
    import multiprocessing
    import concurrent
    import asyncio
    import aiohttp
    import contextlib
    import logging
    import traceback
    import warnings
    import weakref
    import gc
    import atexit
    import abc
    import numbers
    import fractions
    import decimal
    import io
   

# Generated at 2022-06-16 19:33:37.071048
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:33:43.123677
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:33:53.280074
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import numpy as np
    import pandas as pd
    import scipy as sp
    import matplotlib as mpl
    import matplotlib.pyplot as plt
    import sklearn as sk
    import sklearn.linear_model as sklm
    import sklearn.metrics as sklmtr
    import sklearn.model_selection as sklms
    import sklearn.neighbors as skln
    import sklearn.preprocessing as sklp
    import sklearn.svm as skls
    import sklearn.tree as sklt
    import sklearn.utils as sklu
    import sklearn.utils.estimator_checks as skluec
    import sklearn.utils.validation as skluv
    import sk

# Generated at 2022-06-16 19:34:03.213356
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:34:11.644737
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])


# Generated at 2022-06-16 19:34:22.667392
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys

    def test_items(self):
        frame = inspect.currentframe()
        frame = frame.f_back
        return self.items(frame)

    def test_items_normalize(self):
        frame = inspect.currentframe()
        frame = frame.f_back
        return self.items(frame, normalize=True)

    def test_items_exclude(self):
        frame = inspect.currentframe()
        frame = frame.f_back
        return self.items(frame, exclude=['__dict__'])

    def test_items_exclude_normalize(self):
        frame = inspect.currentframe()
        frame = frame.f_back
        return self.items(frame, exclude=['__dict__'], normalize=True)


# Generated at 2022-06-16 19:34:29.768341
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import pprint
    import types
    import builtins
    import functools
    import operator
    import collections
    import itertools
    import re
    import math
    import random
    import string
    import datetime
    import time
    import fractions
    import decimal
    import io
    import json
    import pickle
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax.saxutils
    import xml.parsers.expat
    import xml.etree.cElementTree
    import xml.etree.ElementInclude
    import xml.etree.ElementPath
    import xml.etree.ElementTree
    import xml.etree.SimpleXMLTreeBuilder
    import xml.etree.TreeBuilder


# Generated at 2022-06-16 19:34:39.244468
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:50.468056
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import collections

    # Get the current frame
    frame = inspect.currentframe()
    # Get the frame info
    info = inspect.getframeinfo(frame)
    # Get the source code
    source = inspect.getsource(info.function)
    # Get the source code lines
    lines = inspect.getsourcelines(info.function)[0]

    # Get the frame's globals
    frame_globals = frame.f_globals
    # Get the frame's locals
    frame_locals = frame.f_locals

    # Get the current file name
    file_name = info.filename
    # Get the current file directory
    file_dir = os.path.dirname(file_name)
    # Get the current file base name

# Generated at 2022-06-16 19:35:34.420277
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import functools
    import operator
    import itertools
    import collections
    import datetime
    import time
    import math
    import random
    import string
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import hashlib
    import hmac
    import uuid
    import socket
    import ssl
    import select
    import threading
    import multiprocessing
    import subprocess
    import concurrent
    import asyncio
    import aiohttp
    import urllib
    import urllib.request
    import ur

# Generated at 2022-06-16 19:35:47.879301
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:35:54.667515
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:36:04.676368
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def test_frame():
        def f():
            return inspect.currentframe()
        return f()

    def test_frame_with_locals():
        def f():
            a = 1
            return inspect.currentframe()
        return f()

    def test_frame_with_globals():
        def f():
            return inspect.currentframe()
        f.__globals__['a'] = 1
        return f()

    def test_frame_with_locals_and_globals():
        def f():
            a = 1
            return inspect.currentframe()
        f.__globals__['a'] = 1
        return f()


# Generated at 2022-06-16 19:36:12.047280
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    print(frame)
    print(frame.f_globals)
    print(frame.f_locals)
    print(frame.f_code)
    print(frame.f_code.co_name)
    print(frame.f_code.co_filename)
    print(frame.f_code.co_firstlineno)
    print(frame.f_code.co_varnames)
    print(frame.f_code.co_argcount)
    print(frame.f_code.co_flags)
    print(frame.f_code.co_lnotab)
    print(frame.f_code.co_freevars)

# Generated at 2022-06-16 19:36:20.215905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import math
    import time
    import datetime
    import random
    import string
    import hashlib
    import base64
    import binascii
    import json
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax.saxutils
    import urllib.parse
    import urllib.request
    import urllib.error
    import http.client
    import email.parser
    import email.policy
    import email.message
    import email.utils
    import email.mime.text
    import email.mime.multipart
    import email.mime.base
    import email.mime.application
    import email.mime.audio


# Generated at 2022-06-16 19:36:31.856634
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pdb
    import pprint
    import traceback
    import unittest
    import pytest
    import pytest_mock
    import pytest_mock.plugin
    import pytest_mock.plugin.mockfixture
    import pytest_mock.plugin.mockfixture.mock
    import pytest_mock.plugin.mockfixture.mock.mock
    import pytest_mock.plugin.mockfixture.mock.mock.mock
    import pytest_mock.plugin.mockfixture.mock.mock.mock.mock
    import pytest_mock.plugin.mockfixture.mock.mock.mock.mock.mock


# Generated at 2022-06-16 19:36:41.537711
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('a',)) == BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b', exclude=('b',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b')
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')


# Generated at 2022-06-16 19:36:52.401548
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:37:04.038575
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils
    from . import pycompat

    def get_frame(level=1):
        frame = sys._getframe(level)
        if pycompat.PY2:
            frame = types.FrameType(frame.f_code, frame.f_globals, frame.f_locals, frame.f_back)
        return frame

    def get_frame_locals(level=1):
        return get_frame(level).f_locals

    def get_frame_globals(level=1):
        return get_frame(level).f_globals

    def get_frame_locals_and_globals(level=1):
        frame = get_frame(level)
        return frame.f_locals