

# Generated at 2022-06-16 19:28:30.900454
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:28:43.763979
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import utils
    from . import pycompat
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables

# Generated at 2022-06-16 19:28:45.364030
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1:3] == Indices('a', slice(1, 3))


# Generated at 2022-06-16 19:28:52.462499
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))

# Generated at 2022-06-16 19:29:02.482599
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:29:14.039013
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:29:24.851711
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:29:35.676487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:29:42.347512
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))
    assert indices[1:3] != Indices('a', slice(1, 2))
    assert indices[1:3] != Indices('a', slice(1, 3, 2))
    assert indices[1:3] != Indices('a', slice(1, 3, 1))
    assert indices[1:3] != Indices('a', slice(1, 3, None))
    assert indices[1:3] != Indices('a', slice(1, 3, 0))
    assert indices[1:3] != Indices('a', slice(1, 3, -1))
    assert indices[1:3] != Indices('a', slice(1, 3, -2))
    assert indices[1:3]

# Generated at 2022-06-16 19:29:53.195391
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:30:05.380114
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'


# Generated at 2022-06-16 19:30:17.076153
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:30:28.453779
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])

# Unit

# Generated at 2022-06-16 19:30:36.669744
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test with two variables with the same source, exclude and type
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('a', 'b')
    assert var1 == var2

    # Test with two variables with the same source and exclude but different type
    var1 = BaseVariable('a', 'b')
    var2 = Attrs('a', 'b')
    assert not var1 == var2

    # Test with two variables with the same source but different exclude
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('a', 'c')
    assert not var1 == var2

    # Test with two variables with the same exclude but different source
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('c', 'b')
    assert not var1 == var2

   

# Generated at 2022-06-16 19:30:39.185481
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("a")
    assert indices[1:3] == Indices("a", slice(1, 3))

# Generated at 2022-06-16 19:30:40.653551
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:30:42.578727
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[1:3] == Indices('x', slice(1, 3))

# Generated at 2022-06-16 19:30:49.030302
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:31:00.703469
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'c', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a')
    assert BaseVariable('a', 'b', 'c') != BaseVariable

# Generated at 2022-06-16 19:31:06.776421
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice._fingerprint == (Indices, 'x', ())
    assert indices_slice.source == 'x'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('x', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'x'

# Generated at 2022-06-16 19:31:25.401742
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(func):
        frame = sys._getframe(1)
        while frame.f_code.co_name != func:
            frame = frame.f_back
        return frame

    def get_frame_locals(func):
        return get_frame(func).f_locals

    def get_frame_globals(func):
        return get_frame(func).f_globals

    def get_frame_code(func):
        return get_frame(func).f_code

    def get_frame_code_name(func):
        return get_frame_code(func).co_name

    def get_frame_code_filename(func):
        return get

# Generated at 2022-06-16 19:31:32.162575
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    def get_frame():
        # Get the frame of the caller of this function
        return inspect.currentframe().f_back

    def get_frame_locals(frame):
        # Get the locals of the caller of this function
        return frame.f_locals

    def get_frame_globals(frame):
        # Get the globals of the caller of this function
        return frame.f_globals

    def get_frame_code(frame):
        # Get the code of the caller of this function
        return frame.f_code

    def get_frame_code_name(frame):
        # Get the name of the caller of this function
        return frame.f_code.co_name


# Generated at 2022-06-16 19:31:41.188165
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')


# Generated at 2022-06-16 19:31:50.418007
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe(1)
        if pycompat.PY2:
            frame = inspect.getouterframes(frame)[1][0]
        return frame

    def test_items(variable, expected):
        frame = get_frame()
        result = variable.items(frame)
        assert result == expected

    def test_items_normalize(variable, expected):
        frame = get_frame()
        result = variable.items(frame, normalize=True)
        assert result == expected

    def test_items_exclude(variable, expected):
        frame = get_frame()
        result = variable.items(frame)
        assert result == expected


# Generated at 2022-06-16 19:32:00.719059
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import unittest.mock

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_globals = sys._getframe(0).f_globals
            self.frame.f_locals = sys._getframe(0).f_locals

        def test_BaseVariable_items(self):
            self.assertEqual(BaseVariable('a').items(self.frame), [('a', '1')])
            self.assertEqual(BaseVariable('a.b').items(self.frame), [('a.b', '2')])

# Generated at 2022-06-16 19:32:11.957453
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    import collections

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()

# Generated at 2022-06-16 19:32:20.178773
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:32:26.943436
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils

    def get_frame(level=0):
        frame = sys._getframe(level + 1)
        if frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    frame = get_frame()
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals

    # Test for class Attrs
    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    test_class = TestClass()
    test_class.d = 4
    test_class.e = 5
    test_class.f = 6
    test_class.g = 7


# Generated at 2022-06-16 19:32:38.932934
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:48.651611
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude=('y',))
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('y', 'z'))
    assert BaseVariable('x', exclude=('y', 'z')) == BaseVariable('x', exclude=('y', 'z'))
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x', exclude=('z', 'y'))

# Generated at 2022-06-16 19:33:10.228040
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:21.351100
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:33:30.814201
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import collections
    import functools
    import operator
    import itertools
    import math
    import random
    import string
    import time
    import datetime
    import calendar
    import threading
    import queue
    import weakref
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import glob
    import fnmatch
    import pathlib
    import os.path
    import filecmp
    import stat
    import errno
    import io
    import fcntl
    import mmap
    import select
    import socket
   

# Generated at 2022-06-16 19:33:40.910757
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils

    def test_frame():
        def func():
            return inspect.currentframe()
        return func()

    def test_frame_with_locals():
        def func():
            a = 1
            return inspect.currentframe()
        return func()

    def test_frame_with_globals():
        def func():
            return inspect.currentframe()
        func.b = 2
        return func()

    def test_frame_with_locals_and_globals():
        def func():
            a = 1
            return inspect.currentframe()
        func.b = 2
        return func()


# Generated at 2022-06-16 19:33:51.808905
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import math
    import numpy as np
    import pandas as pd
    import scipy as sp
    import scipy.stats as stats
    import scipy.special as special
    import scipy.integrate as integrate
    import scipy.optimize as optimize
    import scipy.interpolate as interpolate
    import scipy.linalg as linalg
    import scipy.sparse as sparse
    import scipy.sparse.linalg as splinalg
    import scipy.fftpack as fftpack
    import scipy.signal as signal
    import scipy.ndimage as ndimage
    import scipy.stats as stats
    import scipy.io

# Generated at 2022-06-16 19:34:03.375543
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import collections

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9
           

# Generated at 2022-06-16 19:34:14.381007
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import operator
    import itertools
    import collections
    import fractions
    import decimal
    import types
    import unittest
    import io
    import tempfile
    import contextlib
    import threading
    import subprocess
    import multiprocessing
    import socket
    import select
    import asyncore
    import asynchat
    import signal
    import email
    import json
    import email
    import email.parser
    import email.policy
    import email.generator
    import email.message
    import email.mime
    import email.mime.application

# Generated at 2022-06-16 19:34:25.213211
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import pdb
    import pprint
    import traceback
    import types
    import builtins
    import importlib
    import subprocess
    import tempfile
    import time
    import datetime
    import math
    import random
    import string
    import collections
    import functools
    import operator
    import itertools
    import contextlib
    import threading
    import multiprocessing
    import concurrent
    import asyncio
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import hashlib
    import hmac
    import uuid
    import ipaddress
    import socket
    import ssl

# Generated at 2022-06-16 19:34:30.650259
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:34:39.852013
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9

# Generated at 2022-06-16 19:35:09.620235
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import pprint
    import unittest
    import io

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_loc

# Generated at 2022-06-16 19:35:19.493399
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    from . import utils
    from . import pycompat

    class TestVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            super(TestVariable, self).__init__(source, exclude)

        def _items(self, main_value, normalize=False):
            return ()

    def get_frame():
        def f():
            return sys._getframe(0)
        frame = f()
        frame.f_globals = {'__name__': '__main__'}
        frame.f_locals = {'x': 1}
        return frame

    def test_items(variable, expected):
        assert variable.items(get_frame()) == expected

    def test_items_exclude(variable, exclude, expected):
        variable.exclude

# Generated at 2022-06-16 19:35:29.478041
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:35:38.038964
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:35:49.992212
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:35:57.061622
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('a')
    c = BaseVariable('b')
    d = BaseVariable('a', exclude=('b',))
    e = BaseVariable('a', exclude=('b',))
    f = BaseVariable('a', exclude=('c',))

    assert a == b
    assert a != c
    assert a != d
    assert d == e
    assert d != f


# Generated at 2022-06-16 19:36:06.451017
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:36:13.067882
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:36:20.694825
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import io
    from contextlib import redirect_stdout
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding


# Generated at 2022-06-16 19:36:31.895940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:37:17.501337
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import random
    import string
    import collections
    import itertools
    import numpy as np
    import pandas as pd
    import scipy as sp
    import scipy.sparse as sps
    import scipy.sparse.linalg as spla
    import scipy.linalg as sla
    import scipy.stats as stats
    import scipy.optimize as opt
    import scipy.integrate as integrate
    import scipy.interpolate as interpolate
    import scipy.signal as signal
    import scipy.fftpack as fftpack
    import scipy.ndimage as ndimage
    import scipy.spatial as spatial
    import scipy.special as special
   

# Generated at 2022-06-16 19:37:24.729404
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:37:37.469844
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:37:48.603701
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 1, 'c': 2}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = 'abc'
    frame.f_locals['f'] = object()
    frame.f_locals['g'] = object()
    frame.f_locals['g'].__dict__ = {'h': 1, 'i': 2}
    frame.f_locals['g'].__slots__ = ('j', 'k')
    frame.f_locals['g'].j = 3
    frame.f_locals['g'].k = 4
    frame.f_locals['l'] = object()
    frame.f_locals

# Generated at 2022-06-16 19:38:00.184006
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import io
    import contextlib
    import unittest
    import tempfile
    import shutil
    import collections
    import types
    import functools
    import itertools
    import operator
    import random
    import string
    import datetime
    import time
    import math
    import fractions
    import decimal
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import signal
    import selectors
    import asyncio
    import logging
    import logging.config
    import logging.handlers
    import json
    import pickle
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat

# Generated at 2022-06-16 19:38:11.520609
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))