

# Generated at 2022-06-16 19:28:30.628381
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:28:32.936599
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)

# Generated at 2022-06-16 19:28:45.365062
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import io
    import os
    import tempfile
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = (1, 2, 3)

# Generated at 2022-06-16 19:28:47.632499
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)


# Generated at 2022-06-16 19:28:53.668166
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test for slice object
    assert Indices('a')[1:2] == Indices('a', slice(1, 2))
    # Test for other object
    try:
        Indices('a')[1]
    except AssertionError:
        pass
    else:
        assert False, 'Should raise AssertionError'


# Generated at 2022-06-16 19:28:59.953759
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x')
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('z',))
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))


# Generated at 2022-06-16 19:29:11.870568
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f

# Generated at 2022-06-16 19:29:15.287132
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:29:25.779571
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:29:36.842895
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('a', 'b'))
    assert BaseVariable('a', exclude=('a', 'b')) != BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('a', 'b'))

# Generated at 2022-06-16 19:29:54.047068
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import io
    import tempfile
    import unittest
    import unittest.mock
    import contextlib
    import functools

    def get_frame(source):
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_filename == __file__:
                if source in frame.f_code.co_code:
                    return frame
            frame = frame.f_back
        raise ValueError('source not found')

    def get_frame_locals(source):
        return get_frame(source).f_locals

    def get_frame_globals(source):
        return get_frame(source).f_globals


# Generated at 2022-06-16 19:30:00.359770
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import types
    import builtins
    import re
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import operator
    import itertools
    import collections
    import array
    import fractions
    import decimal
    import cmath
    import numbers
    import io
    import json
    import pickle
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax.saxutils
    import xml.etree.cElementTree
    import xml.etree.ElementInclude
    import xml.etree.ElementPath
    import xml.parsers.expat
    import xml.dom.minidom
    import xml.dom.pulldom

# Generated at 2022-06-16 19:30:11.530808
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import collections
    import pprint
    import io
    import pytest
    import pycompat
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
    from . import pycompat
    from . import variables
    from . import utils
   

# Generated at 2022-06-16 19:30:20.630347
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:30:32.746338
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for class Attrs
    attrs = Attrs('a')
    assert attrs.items(None) == [('a', 'None')]
    assert attrs.items(None, normalize=True) == [('a', 'None')]
    assert attrs.items(None, normalize=False) == [('a', 'None')]

    # Test for class Keys
    keys = Keys('a')
    assert keys.items(None) == [('a', 'None')]
    assert keys.items(None, normalize=True) == [('a', 'None')]
    assert keys.items(None, normalize=False) == [('a', 'None')]

    # Test for class Indices
    indices = Indices('a')
    assert indices.items(None) == [('a', 'None')]


# Generated at 2022-06-16 19:30:42.211455
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))


# Generated at 2022-06-16 19:30:54.517465
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        frame = sys._getframe(1)
        while frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_code(frame):
        return frame.f_code

    def get_frame_code_name(frame):
        return frame.f_code.co_name

    def get_frame_code_filename(frame):
        return frame.f_code.co_filename


# Generated at 2022-06-16 19:31:05.028930
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:16.375165
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:31:23.613138
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:31:42.453236
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:31:47.158163
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:31:58.654185
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import functools
    import collections
    import itertools
    import operator
    import math
    import random
    import datetime
    import time
    import io
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import subprocess
    import multiprocessing
    import concurrent.futures
    import threading
    import asyncio
    import socket
    import ssl
    import select
    import signal
    import logging
    import logging.config
    import logging.handlers
    import traceback
    import pdb
    import pprint
    import code

# Generated at 2022-06-16 19:32:02.672938
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:32:12.292740
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    v4 = BaseVariable('a', exclude=['b'])
    v5 = BaseVariable('a', exclude=['b'])
    v6 = BaseVariable('a', exclude=['c'])
    assert v1 == v2
    assert v1 != v3
    assert v4 == v5
    assert v4 != v6
    assert v1 != v4
    assert v1 != v5
    assert v1 != v6
    assert v3 != v4
    assert v3 != v5
    assert v3 != v6
    assert v4 != v6


# Generated at 2022-06-16 19:32:21.797839
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd', 'e'))
    assert Base

# Generated at 2022-06-16 19:32:33.168139
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame_info = inspect.getframeinfo(frame)
    print(frame_info)
    print(frame_info.filename)
    print(frame_info.function)
    print(frame_info.lineno)
    print(frame_info.code_context)
    print(frame_info.index)
    print(frame_info.locals)
    print(frame_info.globals)
    print(frame_info.locals['frame'])
    print(frame_info.locals['frame'].f_locals)
    print(frame_info.locals['frame'].f_globals)
    print(frame_info.locals['frame'].f_back)

# Generated at 2022-06-16 19:32:45.104777
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pytest
    from . import utils
    from . import pycompat
    from . import variables
    from . import pycompat
    from . import utils

    def get_frame_info(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_tuple(frame):
        return get_frame_info(frame)[:3]

    def get_frame_info_tuple_str(frame):
        return str(get_frame_info_tuple(frame))

    def get_frame_info_tuple_repr(frame):
        return repr(get_frame_info_tuple(frame))

    def get_frame_info_tuple_repr_short(frame):
        return utils.get_short

# Generated at 2022-06-16 19:32:50.632481
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:32:58.954578
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('a',)) == BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('a', 'b'))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('b', exclude=('b',))

# Generated at 2022-06-16 19:33:18.426045
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:33:24.157015
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:33:32.102459
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import pprint
    import io
    import contextlib
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = {'x': 1, 'y': 2, 'z': 3}
            self.frame.f_locals['b'] = [1, 2, 3]
            self.frame.f_locals['c'] = (1, 2, 3)
            self.frame.f_locals['d']

# Generated at 2022-06-16 19:33:39.782786
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'hello'
    frame.f_locals['v'] = {'a': 1, 'b': 2}
    frame.f_locals['v'].__dict__['c'] = 3
    frame.f_locals['v'].__dict__['d'] = 4
    frame.f_locals['v'].__slots__ = ['e', 'f']
    frame.f_locals['v'].e = 5
    frame

# Generated at 2022-06-16 19:33:50.997055
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c'])

# Generated at 2022-06-16 19:34:03.050950
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import io
    import tempfile
    import contextlib
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = {'x': 1, 'y': 2, 'z': 3}
            self.frame.f_locals['b'] = [1, 2, 3]
            self.frame.f_locals['c'] = (1, 2, 3)

# Generated at 2022-06-16 19:34:14.344934
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import time
    import datetime
    import math
    import random
    import string
    import types
    import functools
    import itertools
    import collections
    import operator
    import json
    import pickle
    import base64
    import hashlib
    import zlib
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import subprocess
    import multiprocessing
    import threading
    import socket
    import ssl
    import select
    import asyncio
    import aiohttp
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.robotparser
    import http.client
   

# Generated at 2022-06-16 19:34:25.213682
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals = {'a': 1}
    assert BaseVariable('a').items(frame) == [('a', '1')]
    assert BaseVariable('a', exclude='a').items(frame) == []
    assert BaseVariable('a', exclude=('a',)).items(frame) == []
    assert BaseVariable('a', exclude=['a']).items(frame) == []
    assert BaseVariable('a', exclude=set(['a'])).items(frame) == []
    assert BaseVariable('a', exclude=frozenset(['a'])).items(frame) == []
    assert BaseVariable('a', exclude=('a', 'b')).items(frame) == [('a', '1')]

# Generated at 2022-06-16 19:34:33.941327
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:34:39.022064
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:35:15.805944
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:35:22.874195
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame_locals = frame.f_locals
            frame_globals = frame.f_globals

            # test for class BaseVariable
            self.assertEqual(BaseVariable('frame').items(frame), [('frame', '<frame object at 0x7f7e4d4c9d20>')])
            self.assertEqual(BaseVariable('frame.f_locals').items(frame), [('frame.f_locals', '{}')])

# Generated at 2022-06-16 19:35:32.541386
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'd'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))


# Generated at 2022-06-16 19:35:39.872347
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import io
    import os
    import tempfile
    import functools
    import contextlib
    import traceback
    import unittest
    import collections
    import itertools
    import random
    import string
    import re
    import math
    import fractions
    import decimal
    import datetime
    import time
    import calendar
    import json
    import pickle
    import base64
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import hashlib
    import hmac
    import uuid
    import socket
    import ssl
    import selectors
    import asyncio
    import threading
    import multiprocessing
    import subprocess
    import xml

# Generated at 2022-06-16 19:35:50.119292
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude='y') == BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('z',))
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))


# Generated at 2022-06-16 19:36:02.001926
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import functools
    import itertools
    import operator
    import os
    import random
    import re
    import string
    import time
    import datetime
    import math
    import unicodedata
    import codecs
    import locale
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat

# Generated at 2022-06-16 19:36:10.490968
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:36:16.436349
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:36:27.930439
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:36:38.748253
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b', 'c', 'd'])
    assert Base

# Generated at 2022-06-16 19:37:39.585471
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != Att

# Generated at 2022-06-16 19:37:51.547672
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import builtins
    import collections
    import unittest
    import io
    import tempfile
    import contextlib
    import functools
    import itertools
    import operator
    import random
    import string
    import time
    import datetime
    import numbers
    import math
    import cmath
    import decimal
    import fractions
    import hashlib
    import hmac
    import struct
    import binascii
    import base64
    import codecs
    import copy
    import copyreg
    import pickle
    import json
    import xmlrpc
    import xmlrpc.client
    import xmlrpc.server
    import xmlrpc.server
    import xmlrpc.client
    import xmlrpc.client
   

# Generated at 2022-06-16 19:38:02.022647
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:38:12.760869
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base