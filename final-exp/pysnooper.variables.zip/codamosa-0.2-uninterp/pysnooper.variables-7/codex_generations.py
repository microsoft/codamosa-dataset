

# Generated at 2022-06-16 19:28:21.265055
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[1:3]._slice == slice(1, 3)

# Generated at 2022-06-16 19:28:24.391919
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')
    assert var1 == var2
    assert var1 != var3


# Generated at 2022-06-16 19:28:32.760821
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 1}}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = 'abc'
    frame.f_locals['f'] = (1, 2, 3)
    frame.f_locals['g'] = {'h': 1, 'i': 2}
    frame.f_locals['j'] = {'k': 1, 'l': 2}
    frame.f_locals['m'] = {'n': 1, 'o': 2}
    frame.f_locals['p'] = {'q': 1, 'r': 2}

# Generated at 2022-06-16 19:28:37.199348
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[1:3]
    assert b._slice == slice(1, 3)
    assert b._fingerprint == (Indices, 'a', ())
    assert b._fingerprint == a._fingerprint

# Generated at 2022-06-16 19:28:48.714651
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()

# Generated at 2022-06-16 19:29:00.466783
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'd'))


# Generated at 2022-06-16 19:29:12.277138
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:29:24.403130
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import doctest
    import pprint


# Generated at 2022-06-16 19:29:35.306092
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals = {'a': 1, 'b': 2}
    frame.f_globals = {'c': 3}
    assert BaseVariable('a').items(frame) == [('a', '1')]
    assert BaseVariable('a').items(frame, normalize=True) == [('a', '1')]
    assert BaseVariable('a', exclude='a').items(frame) == []
    assert BaseVariable('a', exclude='a').items(frame, normalize=True) == []
    assert BaseVariable('a', exclude=('a',)).items(frame) == []
    assert BaseVariable('a', exclude=('a',)).items(frame, normalize=True) == []
    assert BaseVariable('a', exclude=('a', 'b')).items

# Generated at 2022-06-16 19:29:37.182628
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    assert var[1:2] == Indices('x', slice(1, 2))

# Generated at 2022-06-16 19:29:57.205983
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils
    from . import pycompat

    def test_items(variable, frame, expected):
        assert variable.items(frame) == expected

    def test_items_normalize(variable, frame, expected):
        assert variable.items(frame, normalize=True) == expected

    def test_items_exclude(variable, frame, expected):
        assert variable.items(frame) == expected

    def test_items_exclude_normalize(variable, frame, expected):
        assert variable.items(frame, normalize=True) == expected

    def test_items_exclude_normalize_2(variable, frame, expected):
        assert variable.items(frame, normalize=True) == expected


# Generated at 2022-06-16 19:30:09.191724
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:30:20.565419
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')

# Generated at 2022-06-16 19:30:32.745079
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import utils
    from . import pycompat
    from . import variables

    class BaseVariable(pycompat.ABC):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            try:
                main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
            except Exception:
                return ()
            return self._

# Generated at 2022-06-16 19:30:41.676749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:30:48.160701
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import unittest
    import io
    import contextlib
    from . import utils
    from . import pycompat
    from . import variables

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 'a'
            self.frame.f_locals['b'] = 'b'
            self.frame.f_locals['c'] = 'c'
            self.frame.f_locals['d'] = 'd'
            self.frame.f_locals['e'] = 'e'
            self.frame.f_locals['f'] = 'f'
            self.frame.f_locals['g'] = 'g'

# Generated at 2022-06-16 19:30:59.771964
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def test_items(self, source, expected):
        frame = inspect.currentframe()
        frame = frame.f_back
        result = self.items(frame)
        assert result == expected

    def test_items_normalize(self, source, expected):
        frame = inspect.currentframe()
        frame = frame.f_back
        result = self.items(frame, normalize=True)
        assert result == expected

    def test_items_exclude(self, source, expected):
        frame = inspect.currentframe()
        frame = frame.f_back
        result = self.items(frame, exclude=['a'])
        assert result == expected


# Generated at 2022-06-16 19:31:06.950704
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pprint

    def test_func():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        ab = 28
        ac = 29
        ad = 30
        ae = 31
        af = 32
        ag = 33
        ah = 34
        ai = 35
       

# Generated at 2022-06-16 19:31:19.372723
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable_test(BaseVariable):
        def __init__(self, source, exclude=()):
            super(BaseVariable_test, self).__init__(source, exclude)

        def _items(self, key, normalize=False):
            return ()

    assert BaseVariable_test('a') == BaseVariable_test('a')
    assert BaseVariable_test('a') != BaseVariable_test('b')
    assert BaseVariable_test('a') != BaseVariable_test('a', exclude=('a',))
    assert BaseVariable_test('a', exclude=('a',)) == BaseVariable_test('a', exclude=('a',))
    assert BaseVariable_test('a', exclude=('a',)) != BaseVariable_test('a', exclude=('b',))
    assert BaseVariable_test('a', exclude=('a',))

# Generated at 2022-06-16 19:31:28.904855
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:48.133727
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:31:58.781940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import os
    import re
    import types
    import io
    import tempfile
    import contextlib
    import unittest
    import unittest.mock

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7

# Generated at 2022-06-16 19:32:10.518060
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    import io
    import contextlib
    import pprint
    import functools
    import operator
    import itertools
    import collections
    import datetime
    import random
    import math
    import fractions
    import decimal
    import cmath
    import os
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import asyncio
    import socket
    import select
    import signal
    import time
    import json
    import pickle
    import hashlib
    import zlib
    import base64
    import binascii
    import codecs
    import re
    import sre_parse
    import sre_constants
    import sre_compile
   

# Generated at 2022-06-16 19:32:17.455140
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != object()
    assert BaseVariable('a') != 'a'



# Generated at 2022-06-16 19:32:25.270942
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import os
    import io
    import datetime
    import time
    import tempfile
    import re
    import math
    import random
    import decimal
    import fractions
    import functools
    import itertools
    import operator
    import collections
    import collections.abc
    import abc
    import types
    import weakref
    import gc
    import array
    import copy
    import pickle
    import struct
    import subprocess
    import threading
    import multiprocessing
    import socket
    import select
    import mmap
    import ssl
    import hashlib
    import hmac
    import binascii
    import base64
    import zlib
    import zipfile
    import tarfile
    import bz2
    import lzma

# Generated at 2022-06-16 19:32:35.666039
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:32:41.907683
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import types
    import re
    import pdb
    import time
    import datetime
    import math
    import random
    import string
    import functools
    import itertools
    import collections
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import json
    import marshal
    import pickle
    import struct
    import binascii
    import hashlib
    import hmac
    import zlib
    import base64
    import codecs
    import locale
    import gettext
    import locale
    import encodings
    import encodings.aliases
    import encodings.utf_8
    import encodings.latin_1
    import encod

# Generated at 2022-06-16 19:32:50.034044
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import re
    import os
    import io
    import tempfile
    import functools
    import collections
    import itertools
    import operator
    import contextlib
    import datetime
    import random
    import math
    import fractions
    import decimal
    import cmath
    import numbers
    import io
    import functools
    import operator
    import itertools
    import collections
    import contextlib
    import datetime
    import random
    import math
    import fractions
    import decimal
    import cmath
    import numbers
    import io
    import functools
    import operator
    import itertools
    import collections
    import contextlib
    import datetime
    import random
    import math
    import fractions
    import decimal
    import cmath
   

# Generated at 2022-06-16 19:32:58.374246
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:33:09.755930
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    from . import utils
    from . import pycompat

    def test_frame():
        def f():
            return inspect.currentframe()
        return f()

    frame = test_frame()
    frame.f_globals = sys.modules['__main__'].__dict__
    frame.f_locals = {'x': 1, 'y': 2, 'z': 3}

    # Test for method items of class BaseVariable
    def test_BaseVariable_items_case1():
        # Test for method items of class BaseVariable
        # Case 1: source = 'x'
        # Expected result: [('x', '1')]
        source = 'x'
        expected_result = [('x', '1')]
        variable = BaseVariable(source)

# Generated at 2022-06-16 19:33:33.731428
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    from . import utils
    from . import pycompat

    def get_frame(depth=0):
        frame = inspect.currentframe()
        while frame.f_back and depth > 0:
            frame = frame.f_back
            depth -= 1
        return frame

    def get_frame_locals(depth=0):
        return get_frame(depth + 1).f_locals

    def get_frame_globals(depth=0):
        return get_frame(depth + 1).f_globals

    def get_frame_locals_and_globals(depth=0):
        frame = get_frame(depth + 1)
        return frame.f_locals, frame.f_globals


# Generated at 2022-06-16 19:33:44.753946
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:49.808871
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:34:01.579485
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import types
    import collections
    import unittest
    import io
    import contextlib
    import tempfile
    import shutil
    import subprocess
    import time
    import datetime
    import random
    import string
    import math
    import fractions
    import decimal
    import functools
    import operator
    import itertools
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import selectors
    import ssl
    import email
    import json
    import xml
    import xml.etree
    import xml.dom
    import xml.sax
    import xml.parsers
    import xml.dom.minidom

# Generated at 2022-06-16 19:34:13.646599
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from pprint import pprint
    from . import utils

    def test_frame(source):
        frame = inspect.currentframe()
        frame = frame.f_back
        while frame:
            if frame.f_code.co_name == 'test_frame':
                frame = frame.f_back
                continue
            break
        assert frame
        return frame

    def test_variable(source):
        frame = test_frame(source)
        return BaseVariable(source).items(frame)

    def test_variable_normalize(source):
        frame = test_frame(source)
        return BaseVariable(source).items(frame, normalize=True)

    def test_variable_exclude(source, exclude):
        frame = test_frame(source)

# Generated at 2022-06-16 19:34:24.544828
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8
            self.frame.f_locals['i'] = 9
            self.frame.f

# Generated at 2022-06-16 19:34:35.827443
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()
    assert frame.f_code.co_name == 'test_BaseVariable_items'
    assert frame.f_code.co_filename == __file__

    def test(cls, source, exclude, expected):
        variable = cls(source, exclude)
        result = variable.items(frame)
        assert result == expected


# Generated at 2022-06-16 19:34:45.078211
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for class CommonVariable
    # test for class Attrs
    class A(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y
    a = A(1, 2)
    assert Attrs('a').items(a) == [('a', '<A object>'), ('a.x', '1'), ('a.y', '2')]
    assert Attrs('a', exclude=('x',)).items(a) == [('a', '<A object>'), ('a.y', '2')]
    assert Attrs('a', exclude=('x', 'y')).items(a) == [('a', '<A object>')]

# Generated at 2022-06-16 19:34:54.578225
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = {'b': 'c'}
            self.frame.f_locals['d'] = [1, 2, 3]
            self.frame.f_locals['e'] = (1, 2, 3)
            self.frame.f_locals['f'] = {'g': {'h': 'i'}}

# Generated at 2022-06-16 19:35:06.354824
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class Test(unittest.TestCase):
        def test_items(self):
            def test_func():
                a = 1
                b = 2
                c = 3
                d = {'a': 1, 'b': 2, 'c': 3}
                e = [1, 2, 3]
                f = (1, 2, 3)
                g = [1, 2, 3]
                g.append(g)
                h = {'a': 1, 'b': 2, 'c': 3}
                h['h'] = h
                i = [1, 2, 3]
                i.append(i)
                j = (1, 2, 3)
                j = (j, j)

# Generated at 2022-06-16 19:35:32.058655
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        frame = inspect.currentframe()
        while frame.f_back:
            frame = frame.f_back
        return frame

    def test_items(variable, expected):
        frame = get_frame()
        result = variable.items(frame)
        assert result == expected

    def test_items_normalized(variable, expected):
        frame = get_frame()
        result = variable.items(frame, normalize=True)
        assert result == expected

    def test_items_excluded(variable, expected):
        frame = get_frame()
        result = variable.items(frame)
        assert result == expected


# Generated at 2022-06-16 19:35:39.619436
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import json
    import types
    import datetime
    import time
    import math
    import random
    import string
    import collections
    import itertools
    import functools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import tempfile
    import shutil
    import zipfile
    import tarfile
    import gzip
    import bz2
    import lzma
    import hashlib
    import zlib
    import io
    import contextlib
    import urllib
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.robotparser
    import http.client

# Generated at 2022-06-16 19:35:43.845447
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import tempfile
    import contextlib
    import re
    import io
    import unittest

    @contextlib.contextmanager
    def temp_file(content):
        with tempfile.NamedTemporaryFile(mode='w+t', delete=False) as f:
            f.write(content)
            f.flush()
            yield f.name
        os.unlink(f.name)

    @contextlib.contextmanager
    def temp_module(content):
        with temp_file(content) as filename:
            module_name = os.path.splitext(os.path.basename(filename))[0]
            sys.path.insert(0, os.path.dirname(filename))

# Generated at 2022-06-16 19:35:53.030982
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:36:03.733730
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys

    def f():
        a = 1
        b = {'c': 2, 'd': 3}
        e = [4, 5, 6]
        return a, b, e

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back

# Generated at 2022-06-16 19:36:12.823949
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude=('y',))
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('z',))
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('y', 'z'))

# Generated at 2022-06-16 19:36:20.588009
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])

# Generated at 2022-06-16 19:36:31.895942
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = sys._getframe()
    frame = inspect.getouterframes(frame)[1][0]
    frame.f_locals['a'] = {'b': 'c'}
    assert BaseVariable('a').items(frame) == [('a', "{'b': 'c'}")]
    assert BaseVariable('a', 'b').items(frame) == [('a', "{'b': 'c'}")]
    assert BaseVariable('a.b').items(frame) == [('a.b', "'c'")]
    assert BaseVariable('a.b', 'c').items(frame) == [('a.b', "'c'")]
    assert BaseVariable('a.b.c').items(frame) == [('a.b.c', "")]

# Generated at 2022-06-16 19:36:41.571555
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import io
    import tempfile
    import contextlib
    import unittest
    import unittest.mock
    import builtins
    import types

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()

# Generated at 2022-06-16 19:36:52.439588
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'x': 1, 'y': 2, 'z': 3}
            self.frame.f_locals['c'] = {'x': 1, 'y': 2, 'z': 3}

# Generated at 2022-06-16 19:37:37.961183
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:37:43.538696
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import pdb
    import traceback
    import time
    import datetime
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 'b'
            self.frame.f_locals['c'] = [1, 2, 3]
            self.frame.f_locals['d'] = {'a': 1, 'b': 2}
            self.frame.f_locals['e'] = {'a': 1, 'b': 2}

# Generated at 2022-06-16 19:37:54.572706
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:38:04.550663
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import json
    import types
    import datetime
    import time
    import random
    import math
    import hashlib
    import functools
    import collections
    import itertools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import email
    import email.parser
    import email.policy
    import email.message
    import email.mime
    import email.mime.application
    import email.mime.audio
    import email.mime.base
    import email.mime.image
    import email.mime.message
    import email.mime.multipart
    import email.mime.nonmultipart
    import email.mime

# Generated at 2022-06-16 19:38:14.340666
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def test_items(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_normalize(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_with_exclude(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected, '{} != {}'.format(result, expected)
