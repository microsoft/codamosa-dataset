

# Generated at 2022-06-16 19:28:31.331197
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:28:44.098711
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame_info = inspect.getframeinfo(frame)
    frame_info.filename
    frame_info.function
    frame_info.lineno
    frame_info.code_context
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame_info.index
    frame

# Generated at 2022-06-16 19:28:48.422196
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')


# Generated at 2022-06-16 19:28:56.865502
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))
    assert hash(BaseVariable('a', exclude=['b'])) != hash(BaseVariable('a'))
    assert hash(BaseVariable('a', exclude=['b'])) != hash(BaseVariable('a', exclude=['c']))
    assert hash(BaseVariable('a', exclude=['b'])) == hash(BaseVariable('a', exclude=['b']))


# Generated at 2022-06-16 19:29:02.781076
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))
    assert hash(BaseVariable('a', exclude='b')) != hash(BaseVariable('a'))
    assert hash(BaseVariable('a', exclude='b')) != hash(BaseVariable('a', exclude='c'))


# Generated at 2022-06-16 19:29:14.236762
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions

    def get_frame():
        def f():
            return sys._getframe(0)
        return f()

    def get_frame_info(frame):
        return inspect.getframeinfo(frame)

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_builtins(frame):
        return frame.f_builtins

    def get_frame_code(frame):
        return frame.f_code

    def get_frame_code_name(frame):
        return frame

# Generated at 2022-06-16 19:29:20.056299
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:29:28.425230
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import datetime
    import decimal
    import fractions
    import io
    import os
    import re
    import socket
    import tempfile
    import threading
    import time
    import traceback
    import warnings
    import zipfile
    import gzip
    import bz2
    import lzma
    import hashlib
    import hmac
    import random
    import secrets
    import uuid
    import select
    import mmap
    import struct
    import array
    import ctypes
    import ctypes.util
    import ctypes.wintypes
    import ctypes.macholib
    import ctypes.macholib.dyld
    import ctypes.macholib.dylib
    import ctypes.macholib.framework

# Generated at 2022-06-16 19:29:38.865270
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[1:3] == Indices('a', slice(1, 3))
    assert a[1:3] != Indices('a', slice(2, 3))
    assert a[1:3] != Indices('a', slice(1, 4))
    assert a[1:3] != Indices('a', slice(2, 4))
    assert a[1:3] != Indices('a', slice(1, 3), slice(2, 4))
    assert a[1:3] != Indices('a', slice(2, 4), slice(1, 3))
    assert a[1:3] != Indices('a', slice(1, 3), slice(1, 3))

# Generated at 2022-06-16 19:29:50.274358
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import random
    import string
    import types
    import tempfile
    import shutil
    import subprocess
    import unittest
    import contextlib
    import io

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7

# Generated at 2022-06-16 19:30:00.411156
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    var = var[1:3]
    assert var._slice == slice(1, 3)

# Generated at 2022-06-16 19:30:02.663767
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)

# Generated at 2022-06-16 19:30:14.291348
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import unittest
    import types
    import os
    import tempfile
    import shutil
    import importlib
    import datetime
    import time
    import random
    import math
    import re
    import string
    import collections
    import itertools
    import functools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import signal
    import ctypes
    import ctypes.util
    import ctypes.wintypes
    import ctypes.macholib
    import ctypes.macholib.dyld
    import ctypes.macholib.dylib
    import ctypes.macholib.framework
    import ctypes.util
    import ctypes.wintypes
    import ctypes

# Generated at 2022-06-16 19:30:21.150044
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1:2]._slice == slice(1, 2)
    assert Indices('a')[:2]._slice == slice(0, 2)
    assert Indices('a')[1:]._slice == slice(1, None)
    assert Indices('a')[:]._slice == slice(None)
    assert Indices('a')[::2]._slice == slice(None, None, 2)
    assert Indices('a')[1:2:3]._slice == slice(1, 2, 3)

# Generated at 2022-06-16 19:30:33.154468
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins

    def get_frame():
        frame = sys._getframe(1)
        while frame.f_globals['__name__'] == __name__:
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return dict(inspect.getargvalues(frame)[3])

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_builtins(frame):
        return frame.f_globals.get('__builtins__', builtins.__dict__)

    def get_frame_locals_globals_builtins(frame):
        return get_frame_locals(frame), get_frame_globals(frame), get_frame

# Generated at 2022-06-16 19:30:42.423098
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame_info = inspect.getframeinfo(frame)
            frame_locals = frame.f_locals
            frame_globals = frame.f_globals
            frame_globals['__name__'] = '__main__'
            frame_globals['__file__'] = frame_info.filename
            frame_globals['__package__'] = None
            frame_globals['__doc__'] = None
            frame_globals['__builtins__'] = sys.modules['__builtin__']
            frame_globals['__loader__'] = None
            frame_globals

# Generated at 2022-06-16 19:30:54.517278
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import pytest
    import builtins

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_globals['a'] = 1
            self.frame.f_globals['b'] = 2
            self.frame.f_globals['c'] = 3
            self.frame.f_globals['d'] = 4
            self.frame.f_globals['e'] = 5
            self.frame.f_globals['f'] = 6
            self.frame.f_globals['g'] = 7
            self.frame.f_globals['h'] = 8
            self

# Generated at 2022-06-16 19:31:05.029362
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import types
    import unittest
    from . import utils
    from . import pycompat
    from . import variables


# Generated at 2022-06-16 19:31:16.376627
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import numpy as np
    import pandas as pd
    import datetime
    import time
    import random
    import string
    import os
    import re
    import math
    import itertools
    import functools
    import operator
    import collections
    import json
    import pickle
    import base64
    import zlib
    import bz2
    import gzip
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import concurrent
    import asyncio
    import socket
    import ssl
    import urllib
    import urllib.request
    import urllib.parse
    import urllib.error

# Generated at 2022-06-16 19:31:27.663073
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:44.610981
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:31:55.616677
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('a',)) == BaseVariable('a', exclude=('a',))
    assert BaseVariable('a', exclude=('a',)) != BaseVariable('a', exclude=('a', 'b'))
    assert BaseVariable('a', exclude=('a', 'b')) == BaseVariable('a', exclude=('a', 'b'))
    assert BaseVariable('a', exclude=('a', 'b')) != BaseVariable('a', exclude=('a', 'b', 'c'))
    assert Base

# Generated at 2022-06-16 19:32:05.378368
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 'd'}}
    assert BaseVariable('a').items(frame) == [('a', "{'b': {...}}")]
    assert BaseVariable('a', exclude=['b']).items(frame) == [('a', "{'b': {...}}")]
    assert BaseVariable('a.b').items(frame) == [('a.b', "{'c': 'd'}")]
    assert BaseVariable('a.b', exclude=['c']).items(frame) == [('a.b', "{'c': 'd'}")]
    assert BaseVariable('a.b.c').items(frame) == [('a.b.c', "'d'")]

# Generated at 2022-06-16 19:32:11.541092
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:32:21.180760
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    import unittest.mock
    from io import StringIO
    from contextlib import contextmanager

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3

        def tearDown(self):
            del self.frame

        @contextmanager
        def capture_stdout(self):
            old_stdout = sys.stdout
            sys.stdout = StringIO()
            try:
                yield sys.stdout
            finally:
                sys.stdout = old_stdout

# Generated at 2022-06-16 19:32:32.114681
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a') != Attrs('a')
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a', exclude=('b',)) == Attrs('a', exclude=('b',))
    assert Attrs('a', exclude=('b',)) != Attrs('a', exclude=('c',))
    assert Attrs('a') != Keys('a')
    assert Keys('a') == Keys('a')


# Generated at 2022-06-16 19:32:44.205543
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import re
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import config
    from . import exc
    from . import __version__
    from . import __main__
    from . import __init__
    from . import __pkginfo__
    from . import __about__
    from . import __future__
    from . import __config__
    from . import __all__
    from . import __builtins__
    from . import __doc__
    from . import __file__
    from . import __name__
    from . import __package__
    from . import __path__
    from . import __spec__
    from . import __test__
    from . import __version__

# Generated at 2022-06-16 19:32:51.349605
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('c', 'b')) != BaseVariable('a', exclude=('b',))
    assert Base

# Generated at 2022-06-16 19:32:59.432795
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import io
    import os
    import tempfile
    import shutil
    import unittest
    from . import utils

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'temp_file')
            self.temp_file_obj = open(self.temp_file, 'w')
            self.temp_file_obj.write('test')
            self.temp_file_obj.close()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_items(self):
            frame = inspect.currentframe()
            self.assertEqual

# Generated at 2022-06-16 19:33:10.437087
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:33:29.676942
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b', 'd'))

# Generated at 2022-06-16 19:33:35.929134
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:33:47.832246
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import re
    import types
    import os
    import io
    import tempfile
    import subprocess
    import threading
    import time
    import datetime
    import functools
    import itertools
    import collections
    import contextlib
    import decimal
    import fractions
    import random
    import math
    import operator
    import pickle
    import json
    import base64
    import binascii
    import zlib
    import hashlib
    import hmac
    import socket
    import ssl
    import select
    import asyncore
    import asynchat
    import signal
    import mmap
    import readline
    import rlcompleter
    import curses
    import curses.ascii
    import curses.panel
    import curses.textpad

# Generated at 2022-06-16 19:33:55.088842
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'd'])


# Generated at 2022-06-16 19:34:05.312386
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3

        def test_BaseVariable_items(self):
            self.assertEqual(BaseVariable('a').items(self.frame), [('a', '1')])
            self.assertEqual(BaseVariable('a', exclude=['a']).items(self.frame), [])
            self.assertEqual(BaseVariable('a', exclude=['b']).items(self.frame), [('a', '1')])

# Generated at 2022-06-16 19:34:13.769420
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != None


# Generated at 2022-06-16 19:34:24.661567
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    class BaseVariable(pycompat.ABC):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            try:
                main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
            except Exception:
                return ()

# Generated at 2022-06-16 19:34:30.756390
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')


# Generated at 2022-06-16 19:34:39.929058
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:45.891183
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:35:18.567697
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:35:30.395496
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import importlib
    import tempfile
    import shutil
    import subprocess
    import time
    import datetime
    import random
    import string
    import json
    import math
    import decimal
    import fractions
    import collections
    import itertools
    import functools
    import operator
    import contextlib
    import threading
    import multiprocessing
    import asyncio
    import socket
    import select
    import signal
    import mmap
    import ctypes
    import ctypes.util
    import ctypes.wintypes
    import ctypes.macholib
    import ctypes.macholib.dyld
    import ctypes.macholib.framework

# Generated at 2022-06-16 19:35:38.545752
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for class CommonVariable
    # test for class Attrs
    class TestAttrs(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
    test_attrs = TestAttrs()
    test_attrs_variable = Attrs('test_attrs')
    assert test_attrs_variable.items(None) == [('test_attrs', 'TestAttrs()'), ('test_attrs.a', '1'), ('test_attrs.b', '2'), ('test_attrs.c', '3')]
    # test for class Keys
    test_keys = {'a': 1, 'b': 2, 'c': 3}
    test_keys_variable = Keys('test_keys')

# Generated at 2022-06-16 19:35:50.286732
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude=('y', 'z')) == BaseVariable('x', exclude=('z', 'y'))
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x', exclude=('y', 'z', 'w'))
    assert BaseVariable('x', exclude=('y', 'z')) != BaseVariable('x', exclude=('y', 'z', 'w'))

# Generated at 2022-06-16 19:36:02.052511
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import traceback
    import io
    import contextlib
    import unittest
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_loc

# Generated at 2022-06-16 19:36:10.490949
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert Base

# Generated at 2022-06-16 19:36:16.436233
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:36:27.929342
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:36:36.688228
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:36:44.768581
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable

# Generated at 2022-06-16 19:37:17.817437
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = 'abc'
    frame.f_locals['w'] = (1, 2, 3)
    frame.f_locals['v'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['u'] = {'a': 1, 'b': 2, 'c': 3}
    frame.f_locals['t'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 19:37:24.903469
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))


# Generated at 2022-06-16 19:37:37.468450
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'y', 'z')
    assert BaseVariable('x', 'y', 'z') != BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'y', 'z')
    assert BaseVariable('x', 'y', 'z') != BaseVariable('x', 'y')

# Generated at 2022-06-16 19:37:43.205419
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(depth=0):
        frame = sys._getframe(depth + 1)
        if pycompat.PY2:
            frame = inspect.getinnerframes(frame)[0][0]
        return frame

    def test_items(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected

    def test_items_normalize(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected

    def test_items_exclude(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected


# Generated at 2022-06-16 19:37:54.123273
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])


# Generated at 2022-06-16 19:38:03.440801
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    def test_function():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        a

# Generated at 2022-06-16 19:38:09.800515
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
