

# Generated at 2022-06-16 19:28:29.976806
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[:] == indices
    assert indices[1:] == Indices('a', slice=slice(1, None))
    assert indices[1:2] == Indices('a', slice=slice(1, 2))
    assert indices[1:2:3] == Indices('a', slice=slice(1, 2, 3))
    assert indices[::-1] == Indices('a', slice=slice(None, None, -1))
    assert indices[1::-1] == Indices('a', slice=slice(1, None, -1))
    assert indices[1:2:-1] == Indices('a', slice=slice(1, 2, -1))

# Generated at 2022-06-16 19:28:42.429979
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def get_frame(f):
        if sys.version_info[0] == 2:
            return f
        else:
            return f.f_back

    def get_frame_locals(f):
        if sys.version_info[0] == 2:
            return f.f_locals
        else:
            return f.f_locals

    def get_frame_globals(f):
        if sys.version_info[0] == 2:
            return f.f_globals
        else:
            return f.f_globals

    def get_frame_code(f):
        if sys.version_info[0] == 2:
            return f.f_code
       

# Generated at 2022-06-16 19:28:51.054049
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('b', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:28:57.323249
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))
    assert indices[1:3] != Indices('a', slice(1, 2))
    assert indices[1:3] != Indices('b', slice(1, 3))
    assert indices[1:3] != Indices('b', slice(1, 2))

# Generated at 2022-06-16 19:29:09.300168
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:29:17.861507
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_

# Generated at 2022-06-16 19:29:21.750586
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice._fingerprint == (Indices, 'a', ())

# Generated at 2022-06-16 19:29:25.020523
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice._fingerprint == (Indices, 'a', ())


# Generated at 2022-06-16 19:29:29.197146
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)
    assert var_slice._fingerprint == (Indices, 'x', ())
    assert var_slice.source == 'x'
    assert var_slice.exclude == ()

# Generated at 2022-06-16 19:29:39.337414
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:29:53.110372
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')
    assert BaseVariable('a') != Indices('a')
    assert BaseVariable('a') != Exploding('a')
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:29:58.103349
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('b', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:30:09.282692
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame_locals = frame.f_locals
            frame_globals = frame.f_globals
            frame_code = frame.f_code
            frame_builtins = frame.f_builtins
            frame_back = frame.f_back
            frame_trace = frame.f_trace
            frame_lasti = frame.f_lasti
            frame_lineno = frame.f_lineno
            frame_restricted = frame.f_restricted
            frame_exc_type = frame.f_exc_type
            frame_exc_value = frame.f_exc_value

# Generated at 2022-06-16 19:30:20.592064
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:32.738906
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import collections
    import functools
    import itertools
    import operator
    import random
    import math
    import datetime
    import time
    import json
    import base64
    import zlib
    import hashlib
    import hmac
    import codecs
    import locale
    import contextlib
    import threading
    import logging
    import getpass
    import platform
    import subprocess
    import shlex
    import shutil
    import tempfile
    import filecmp
    import stat
    import errno
    import pwd
    import grp
    import select
    import signal
    import socket
    import ssl
    import email
    import mimetypes
    import email.message

# Generated at 2022-06-16 19:30:41.677154
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Unit

# Generated at 2022-06-16 19:30:54.065520
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 19:31:04.723726
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:16.105762
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 1}}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = [{'f': 1}, {'f': 2}]
    frame.f_locals['g'] = {'h': [1, 2, 3]}
    frame.f_locals['i'] = {'j': [{'k': 1}, {'k': 2}]}
    frame.f_locals['l'] = {'m': {'n': [1, 2, 3]}}
    frame.f_locals['o'] = {'p': {'q': [{'r': 1}, {'r': 2}]}}

# Generated at 2022-06-16 19:31:27.462746
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')

# Generated at 2022-06-16 19:31:48.725175
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc

# Generated at 2022-06-16 19:31:59.297273
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import pdb
    import pprint
    import types
    import traceback
    import unittest
    import io
    import contextlib
    import linecache
    import tokenize
    import token
    import keyword
    import builtins
    import dis
    import ast
    import collections
    import collections.abc
    import functools
    import itertools
    import operator
    import weakref
    import gc
    import inspect
    import types
    import pprint
    import re
    import sys
    import unittest
    import warnings
    import abc
    import datetime
    import decimal
    import fractions
    import io
    import itertools
    import numbers
    import operator
    import random
    import statistics
    import sys
    import types

# Generated at 2022-06-16 19:32:10.616348
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import pytest
    import pdb
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import pytest
    import pdb
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import pytest
    import pdb
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import pytest
    import pdb
    import pprint
    import inspect
    import sys
    import os
    import re
    import types
    import pprint
    import pytest
    import pdb
    import pprint

# Generated at 2022-06-16 19:32:20.429410
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import re
    import os
    import io
    import tempfile
    import contextlib

    def get_frame(level=0):
        frame = sys._getframe(level + 1)
        while frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    def get_locals(level=0):
        return get_frame(level + 1).f_locals

    def get_globals(level=0):
        return get_frame(level + 1).f_globals

    def get_source(level=0):
        frame = get_frame(level + 1)
        return inspect.getsource(frame.f_code)


# Generated at 2022-06-16 19:32:25.412898
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:32:37.480766
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 'd'}}
    frame.f_locals['e'] = ['f', 'g']
    frame.f_locals['h'] = 'i'
    frame.f_locals['j'] = 'k'
    frame.f_locals['l'] = 'm'
    frame.f_locals['n'] = 'o'
    frame.f_locals['p'] = 'q'
    frame.f_locals['r'] = 's'
    frame.f_locals['t'] = 'u'
    frame.f_locals['v'] = 'w'
    frame.f_locals['x'] = 'y'

# Generated at 2022-06-16 19:32:47.675350
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:57.140940
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back

# Generated at 2022-06-16 19:33:08.621393
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import os
    import re
    import math
    import random
    import string
    import collections
    import datetime
    import time
    import functools
    import itertools
    import operator
    import json
    import pickle
    import base64
    import zlib
    import hashlib
    import hmac
    import codecs
    import locale
    import gettext
    import threading
    import multiprocessing
    import subprocess
    import socket
    import ssl
    import select
    import selectors
    import asyncio
    import email
    import smtplib
    import imaplib
    import poplib
    import nntplib
    import ftplib
    import telnetlib
    import uuid
    import xmlrpc

# Generated at 2022-06-16 19:33:19.943887
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import math
    import numpy as np
    import pandas as pd
    import scipy as sp
    import scipy.stats as stats
    import scipy.special as special
    import scipy.integrate as integrate
    import scipy.optimize as optimize
    import scipy.interpolate as interpolate
    import scipy.linalg as linalg
    import scipy.sparse as sparse
    import scipy.sparse.linalg as splinalg
    import scipy.signal as signal
    import scipy.fftpack as fftpack
    import scipy.ndimage as ndimage
    import scipy.spatial as spatial
    import scipy.cluster as cluster

# Generated at 2022-06-16 19:33:47.166922
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    assert TestVariable('a') == TestVariable('a')
    assert TestVariable('a') != TestVariable('b')
    assert TestVariable('a', exclude=['b']) != TestVariable('a')
    assert TestVariable('a', exclude=['b']) != TestVariable('a', exclude=['c'])
    assert TestVariable('a', exclude=['b']) == TestVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:33:54.773626
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import io
    import os
    import re
    import random
    import string
    import tempfile
    import time
    import datetime
    import math
    import cmath
    import fractions
    import functools
    import operator
    import itertools
    import collections
    import heapq
    import bisect
    import array
    import weakref
    import gc
    import types
    import copy
    import pickle
    import struct
    import codecs
    import json
    import base64
    import binascii
    import hashlib
    import hmac
    import threading
    import multiprocessing
    import subprocess
    import socket
    import ssl
    import select
    import selectors
    import asyncio
    import context

# Generated at 2022-06-16 19:34:05.151953
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:34:15.484348
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    frame = inspect.currentframe()
    assert TestVariable('a').items(frame) == [('a', '1')]
    assert TestVariable('a.b').items(frame) == [('a.b', '2')]
    assert TestVariable('a.b.c').items(frame) == [('a.b.c', '3')]
    assert TestVariable('a.b.c.d').items(frame) == [('a.b.c.d', '4')]

# Generated at 2022-06-16 19:34:26.151883
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def capture_stdout():
        old = sys.stdout
        capturer = io.StringIO()
        sys.stdout = capturer
        try:
            yield capturer
        finally:
            sys.stdout = old

    def test_items(variable, frame, expected):
        with capture_stdout() as capturer:
            result = variable.items(frame)
        assert result == expected
        assert capturer.getvalue() == ''

    def test_items_normalize(variable, frame, expected):
        with capture_stdout() as capturer:
            result = variable.items(frame, normalize=True)
        assert result == expected
        assert capturer.getvalue() == ''


# Generated at 2022-06-16 19:34:36.782262
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back


# Generated at 2022-06-16 19:34:48.664082
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'abc'
    frame.f_locals['v'] = 1
    frame.f_locals['u'] = None
    frame.f_locals['t'] = object()
    frame.f_locals['s'] = object()
    frame.f_locals['s'].a = 1
    frame.f_locals['s'].b = 2
    frame.f_locals['r'] = object()
    frame.f_locals['r'].__

# Generated at 2022-06-16 19:34:54.076655
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:35:06.267255
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:35:16.956109
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe()
    var = BaseVariable('frame')
    assert var.items(frame) == [('frame', '<frame object at 0x7f3c7b3e3a98>')]
    var = BaseVariable('frame.f_locals')
    assert var.items(frame) == [('frame.f_locals', '{}')]
    var = BaseVariable('frame.f_locals', exclude=['frame'])
    assert var.items(frame) == [('frame.f_locals', '{}')]
    var = BaseVariable('frame.f_locals', exclude=['frame', 'var'])
    assert var.items(frame) == [('frame.f_locals', '{}')]

# Generated at 2022-06-16 19:36:02.446981
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:36:10.788740
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import pprint
    import pdb
    import traceback
    import types
    import dis
    import pprint
    import inspect
    import os
    import re
    import sys
    import types
    import dis
    import pprint
    import inspect
    import os
    import re
    import sys
    import types
    import dis
    import pprint
    import inspect
    import os
    import re
    import sys
    import types
    import dis
    import pprint
    import inspect
    import os
    import re
    import sys
    import types
    import dis
    import pprint
    import inspect
    import os
    import re
    import sys
    import types
    import dis
    import pprint
    import inspect
    import os

# Generated at 2022-06-16 19:36:19.718692
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:36:31.818286
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import collections
    import datetime
    import time
    import random
    import math
    import cmath
    import fractions
    import decimal
    import numbers
    import functools
    import operator
    import itertools
    import threading
    import asyncio
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import ssl
    import email
    import json
    import zlib
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import pathlib
    import glob
    import fnmatch
    import linecache
    import fileinput
    import atexit
   

# Generated at 2022-06-16 19:36:41.504249
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import unittest
    from . import utils
    from . import pycompat

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = (1, 2, 3)

# Generated at 2022-06-16 19:36:52.363970
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable

# Generated at 2022-06-16 19:37:03.872534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:37:15.251762
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import pprint
    import collections
    import types
    import functools
    import operator
    import itertools
    import random
    import string
    import datetime
    import time
    import os
    import io
    import math
    import fractions
    import decimal
    import re
    import json
    import base64
    import hashlib
    import hmac
    import binascii
    import tempfile
    import shutil
    import zipfile
    import zlib
    import gzip
    import bz2
    import lzma
    import platform
    import subprocess
    import multiprocessing
    import concurrent.futures
    import threading
    import socket
    import ssl
    import selectors
    import asyncio


# Generated at 2022-06-16 19:37:22.281780
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != 1
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:37:30.903722
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import types
    import unittest
    import tempfile
    import shutil
    import subprocess
    import json
    import time
    import random
    import string
    import copy
    import math
    import collections
    import itertools
    import functools
    import operator
    import contextlib
    import threading
    import queue
    import asyncio
    import aiohttp
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.client
    import email.utils
    import email.parser
    import email.policy
    import email.message
    import email.headerreg