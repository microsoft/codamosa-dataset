

# Generated at 2022-06-16 19:28:30.198828
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types

    def get_frame():
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_name == 'test_BaseVariable_items':
                return frame
            frame = frame.f_back

    frame = get_frame()
    assert frame is not None
    assert frame.f_code.co_name == 'test_BaseVariable_items'
    assert frame.f_code.co_filename == __file__

    # Test for class Attrs
    attrs = Attrs('sys')

# Generated at 2022-06-16 19:28:42.773597
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import os
    import re
    import datetime
    import time
    import math
    import random
    import string
    import collections
    import itertools
    import functools
    import operator
    import fractions
    import decimal
    import json
    import io
    import zipfile
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import ssl
    import selectors
    import sysconfig
    import platform
    import errno
    import ctypes
    import ctypes.util
    import ctypes.wintypes
    import ctypes.macholib
    import ctypes.macholib.dyld

# Generated at 2022-06-16 19:28:53.495758
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import unittest.mock as mock

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_globals = {'a': 1, 'b': 2, 'c': 3}

        def test_BaseVariable_items(self):
            self.assertEqual(BaseVariable('a').items(self.frame), [('a', '1')])
            self.assertEqual(BaseVariable('a', exclude='a').items(self.frame), [])

# Generated at 2022-06-16 19:29:04.583700
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import io
    import contextlib

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = '2'
            self.frame.f_locals['c'] = [3, 4, 5]
            self.frame.f_locals['d'] = {'6': 7, '8': 9}
            self.frame.f_locals['e'] = {'10': 11, '12': 13}
            self.frame.f_locals['f'] = {'14': 15, '16': 17}

# Generated at 2022-06-16 19:29:12.156427
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3]._slice == slice(1, 3)
    assert indices[:]._slice == slice(None)
    assert indices[1:]._slice == slice(1, None)
    assert indices[:3]._slice == slice(None, 3)
    assert indices[::2]._slice == slice(None, None, 2)
    assert indices[1:3:2]._slice == slice(1, 3, 2)

# Generated at 2022-06-16 19:29:23.922469
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')
    assert BaseVariable('a') != Indices('a')
    assert BaseVariable('a') != Exploding('a')


# Generated at 2022-06-16 19:29:26.110962
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)


# Generated at 2022-06-16 19:29:37.182805
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import io
    import contextlib
    import unittest
    import unittest.mock
    from . import utils
    from . import pycompat

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = 4
            self.frame.f_locals['e'] = 5
            self.frame.f_locals['f'] = 6
            self.frame.f_locals['g'] = 7
            self.frame.f_locals['h'] = 8

# Generated at 2022-06-16 19:29:42.302607
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:29:53.152870
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe()
        while frame.f_code.co_name != 'test_BaseVariable_items':
            frame = frame.f_back
        return frame

    def get_locals():
        frame = get_frame()
        return frame.f_locals

    def get_globals():
        frame = get_frame()
        return frame.f_globals

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_code(frame):
        return frame.f_code


# Generated at 2022-06-16 19:30:09.402166
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        return inspect.currentframe().f_back

    def get_globals():
        return get_frame().f_globals

    def get_locals():
        return get_frame().f_locals

    def get_globals_locals():
        return get_globals(), get_locals()

    def get_globals_locals_frame():
        return get_globals(), get_locals(), get_frame()

    def get_globals_locals_frame_normalize():
        return get_globals(), get_locals(), get_frame(), True


# Generated at 2022-06-16 19:30:20.672676
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('c')
    d = BaseVariable('d')
    e = BaseVariable('e')
    f = BaseVariable('f')
    g = BaseVariable('g')
    h = BaseVariable('h')
    i = BaseVariable('i')
    j = BaseVariable('j')
    k = BaseVariable('k')
    l = BaseVariable('l')
    m = BaseVariable('m')
    n = BaseVariable('n')
    o = BaseVariable('o')
    p = BaseVariable('p')
    q = BaseVariable('q')
    r = BaseVariable('r')
    s = BaseVariable('s')
    t = BaseVariable('t')

# Generated at 2022-06-16 19:30:30.201657
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != None


# Generated at 2022-06-16 19:30:37.340354
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:30:49.230994
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:31:00.954554
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = inspect.getouterframes(frame)[1][0]
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = {'c': 2}
    frame.f_locals['d'] = [3, 4]
    frame.f_locals['e'] = (5, 6)
    frame.f_locals['f'] = {'g': 7, 'h': 8}
    frame.f_locals['i'] = [9, 10]
    frame.f_locals['j'] = (11, 12)
    frame.f_locals['k'] = {'l': 13, 'm': 14}
    frame.f_locals['n'] = [15, 16]
    frame.f

# Generated at 2022-06-16 19:31:05.512681
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:31:15.103518
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:31:19.891440
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))


# Generated at 2022-06-16 19:31:25.802309
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:31:47.307933
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'abc'
    frame.f_locals['v'] = {'a': 1, 'b': 2}
    frame.f_locals['v'].__dict__['c'] = 3
    frame.f_locals['v'].__dict__['d'] = 4
    frame.f_locals['v'].__slots__ = ('e', 'f')
    frame.f_locals['v'].e = 5

# Generated at 2022-06-16 19:31:51.361935
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['y'])


# Generated at 2022-06-16 19:32:01.296961
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:12.573529
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import io
    import contextlib

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = {'b': 4, 'c': 5}
            self.frame.f_locals['d'] = [6, 7, 8]

        def test_BaseVariable_items(self):
            self.assertEqual(BaseVariable('x').items(self.frame), [('x', '1')])

# Generated at 2022-06-16 19:32:22.023618
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) == BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) != BaseVariable('x', exclude=['y'])


# Generated at 2022-06-16 19:32:33.415042
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:45.322060
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import collections
    import numpy as np
    import pandas as pd
    import xarray as xr
    import dask.array as da
    import dask.dataframe as dd
    import dask.bag as db
    import dask.delayed as dl
    import dask.distributed as dd
    import dask.dataframe as dd
    import dask.delayed as dl
    import dask.distributed as dd
    import dask.dataframe as dd
    import dask.delayed as dl
    import dask.distributed as dd
    import dask.dataframe as dd
    import dask.delayed as dl
    import dask.distributed as dd
    import dask.dataframe as dd
    import d

# Generated at 2022-06-16 19:32:51.894977
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b', 'c', 'd'])

# Generated at 2022-06-16 19:32:59.697341
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:10.595322
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:33:47.833194
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import re
    import os
    import io
    import tempfile
    import contextlib

    def get_frame():
        def foo():
            return inspect.currentframe()
        return foo()

    def get_frame_with_local_variable():
        def foo():
            x = 1
            return inspect.currentframe()
        return foo()

    def get_frame_with_local_variable_and_builtin_variable():
        def foo():
            x = 1
            return inspect.currentframe()
        return foo()

    def get_frame_with_local_variable_and_builtin_variable_and_global_variable():
        def foo():
            x = 1
            return inspect.currentframe()
        return foo()


# Generated at 2022-06-16 19:33:59.099750
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 'b'
            self.frame.f_locals['c'] = [1, 2, 3]
            self.frame.f_locals['d'] = {'a': 1, 'b': 2}
            self.frame.f_locals['e'] = {'a': 1, 'b': 2}
            self.frame.f_locals['e'].__class__.__name__ = 'e'

# Generated at 2022-06-16 19:34:01.333481
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    var = BaseVariable('frame')
    print(var.items(frame))


# Generated at 2022-06-16 19:34:07.912598
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import math
    import random
    import datetime
    import time
    import functools
    import itertools
    import operator
    import collections
    import json
    import pickle
    import base64
    import zlib
    import hashlib
    import hmac
    import binascii
    import tempfile
    import shutil
    import glob
    import filecmp
    import fnmatch
    import linecache
    import shutil
    import stat
    import webbrowser
    import platform
    import subprocess
    import multiprocessing
    import concurrent
    import socket
    import ssl
    import select
    import asyncio
    import email
    import smtplib
    import imaplib

# Generated at 2022-06-16 19:34:16.987017
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pytest
    from . import utils
    from . import pycompat

    def get_frame():
        frame = inspect.currentframe()
        while frame.f_back:
            frame = frame.f_back
        return frame

    def test_BaseVariable_items_with_frame(frame):
        def test_BaseVariable_items_with_frame_and_source(source):
            def test_BaseVariable_items_with_frame_and_source_and_exclude(exclude):
                variable = BaseVariable(source, exclude)
                items = variable.items(frame)
                assert isinstance(items, tuple)
                for item in items:
                    assert isinstance(item, tuple)
                    assert len(item) == 2
                    assert isinstance(item[0], str)

# Generated at 2022-06-16 19:34:27.011124
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import config

    def get_frame(source):
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_filename == __file__ and frame.f_code.co_name == 'get_frame':
                frame = frame.f_back
                continue
            if frame.f_code.co_filename == __file__ and frame.f_code.co_name == 'test_BaseVariable_items':
                frame = frame.f_back
                continue
            break
        return frame

    def get_frame_info(source):
        frame = get_frame(source)
        return frames.FrameInfo(frame, config.Config())


# Generated at 2022-06-16 19:34:30.851250
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    assert v1 == v2
    assert v1 != v3
    assert v2 != v3


# Generated at 2022-06-16 19:34:38.829132
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:34:50.252411
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:34:58.218744
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals
    frame_locals['sys'] = sys
    frame_locals['inspect'] = inspect
    frame_locals['frame'] = frame
    frame_locals['frame_locals'] = frame_locals
    frame_locals['frame_globals'] = frame_globals
    frame_locals['BaseVariable'] = BaseVariable
    frame_locals['CommonVariable'] = CommonVariable
    frame_locals['Attrs'] = Attrs
    frame_locals['Keys'] = Keys
    frame_locals['Indices'] = Indices
    frame_locals['Exploding'] = Exploding

# Generated at 2022-06-16 19:35:37.168820
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils

    def test_items(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_normalize(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_normalize_with_frame(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected, '{} != {}'.format(result, expected)

    def test_items_with_frame(variable, frame, expected):
        result = variable.items(frame)

# Generated at 2022-06-16 19:35:49.331489
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:36:01.416715
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import inspect
    import pytest
    from . import utils
    from . import pycompat
    from . import variables

    # Create a new frame object
    def foo():
        bar = 1
        return inspect.currentframe()
    frame = foo()

    # Create a new variable object
    var = variables.BaseVariable('bar')

    # Test if the method items of class BaseVariable works well
    def test_items():
        # Test if the method items of class BaseVariable works well
        # when the source is a variable
        assert var.items(frame) == [('bar', '1')]

        # Test if the method items of class BaseVariable works well
        # when the source is a function
        var = variables.BaseVariable('foo')

# Generated at 2022-06-16 19:36:10.099025
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import os
    import sys
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = 2
            self.frame.f_locals['c'] = 3
            self.frame.f_locals['d'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['e'] = [1, 2, 3]
            self.frame.f_locals['f'] = (1, 2, 3)

# Generated at 2022-06-16 19:36:19.554213
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import os
    import re
    import types
    import functools
    import collections
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy

    def needs_parentheses(source):
        def code(s):
            return compile(s, '<variable>', 'eval').co_code

        return code('{}.x'.format(source)) != code('({}).x'.format(source))


    class BaseVariable(pycompat.ABC):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)


# Generated at 2022-06-16 19:36:27.503527
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:36:38.409778
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    import unittest

    from . import utils

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = {'c': 2}
            self.frame.f_locals['d'] = [1, 2, 3]
            self.frame.f_locals['e'] = (1, 2, 3)
            self.frame.f_locals['f'] = 'abc'
            self.frame.f_locals['g'] = b'abc'
            self.frame.f_locals['h'] = types.SimpleNamespace(i=1)

# Generated at 2022-06-16 19:36:49.480468
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pytest
    import types
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(level=0):
        frame = inspect.currentframe()
        for _ in range(level):
            frame = frame.f_back
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_code(level=0):
        return get_frame(level).f_code

    def get_frame_code_name(level=0):
        return get_frame_code(level).co_name

   

# Generated at 2022-06-16 19:36:57.140641
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])

# Generated at 2022-06-16 19:37:09.335568
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
    import re
    import pprint
    import types
    import traceback
    import pdb
    import inspect
    import os
   