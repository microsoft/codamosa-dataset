

# Generated at 2022-06-16 19:28:29.940544
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return [(self.source, utils.get_shortish_repr(key, normalize=normalize))]

    frame = utils.Frame(None, {'a': 1, 'b': 2}, None)
    assert TestVariable('a').items(frame) == [('a', '1')]
    assert TestVariable('a').items(frame, normalize=True) == [('a', '1')]
    assert TestVariable('a').items(frame, normalize=False) == [('a', '1')]
    assert TestVariable('a').items(frame, normalize=True) == [('a', '1')]

# Generated at 2022-06-16 19:28:42.383377
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import dis
    import io
    import contextlib

    def _get_frame():
        frame = inspect.currentframe()
        while frame:
            if frame.f_code.co_name == 'test_BaseVariable_items':
                return frame
            frame = frame.f_back

    frame = _get_frame()
    assert frame
    frame = frame.f_back
    assert frame

    # Test for method items of class BaseVariable

# Generated at 2022-06-16 19:28:53.496983
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:29:04.583257
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = {'c': 2}
            self.frame.f_locals['d'] = [3, 4]
            self.frame.f_locals['e'] = (5, 6)
            self.frame.f_locals['f'] = {'g': 7, 'h': 8}
            self.frame.f_locals['i'] = [9, 10]
            self.frame.f_locals['j'] = (11, 12)
            self.frame.f_locals['k']

# Generated at 2022-06-16 19:29:14.236565
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariableSubclass(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    base_variable_subclass_1 = BaseVariableSubclass('source', 'exclude')
    base_variable_subclass_2 = BaseVariableSubclass('source', 'exclude')
    base_variable_subclass_3 = BaseVariableSubclass('source', 'exclude')

    assert base_variable_subclass_1 == base_variable_subclass_2
    assert base_variable_subclass_2 == base_variable_subclass_3
    assert base_variable_subclass_1 == base_variable_subclass_3


# Generated at 2022-06-16 19:29:24.542603
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:29:26.200940
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    assert var[1:3] == Indices('x', slice(1, 3))

# Generated at 2022-06-16 19:29:37.226023
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types

    def test_frame():
        return inspect.currentframe().f_back

    def test_frame_with_locals():
        x = 1
        return inspect.currentframe().f_back

    def test_frame_with_globals():
        global x
        x = 1
        return inspect.currentframe().f_back

    def test_frame_with_builtins():
        return inspect.currentframe().f_back

    def test_frame_with_traceback():
        try:
            raise Exception()
        except:
            return inspect.currentframe().f_back

    def test_frame_with_frame():
        return inspect.currentframe().f_back

    def test_frame_with_code():
        return inspect.currentframe().f_back


# Generated at 2022-06-16 19:29:40.471794
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices[1:3] == Indices('x', slice=slice(1, 3))
    assert indices[1:3]._slice == slice(1, 3)

# Generated at 2022-06-16 19:29:51.961473
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:06.304174
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:30:17.997135
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:30.408184
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:30:32.394631
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices[1:2] == Indices('x', slice(1, 2))

# Generated at 2022-06-16 19:30:41.119871
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude='y') == BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude=('y',)) != BaseVariable('x', exclude=('z',))
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))


# Generated at 2022-06-16 19:30:47.491382
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:59.542742
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 1}
    assert list(BaseVariable('a').items(frame)) == [('a', '{...}')]
    assert list(BaseVariable('a.b').items(frame)) == [('a.b', '1')]
    assert list(BaseVariable('a.b.c').items(frame)) == [('a.b.c', '...')]
    assert list(BaseVariable('a.b.c', exclude='b').items(frame)) == [('a.b.c', '...')]
    assert list(BaseVariable('a.b.c', exclude='c').items(frame)) == [('a.b.c', '...')]

# Generated at 2022-06-16 19:31:09.123635
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = {'c': 2}
    frame.f_locals['d'] = [3, 4]
    frame.f_locals['e'] = {'f': [5, 6]}
    frame.f_locals['g'] = {'h': {'i': 7}}
    frame.f_locals['j'] = {'k': {'l': [8, 9]}}
    frame.f_locals['m'] = {'n': {'o': {'p': 10}}}
    frame.f_locals['q'] = {'r': {'s': {'t': [11, 12]}}}

# Generated at 2022-06-16 19:31:20.136492
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices[:2] == Indices('x', slice=slice(None, 2, None))
    assert indices[2:] == Indices('x', slice=slice(2, None, None))
    assert indices[1:3] == Indices('x', slice=slice(1, 3, None))
    assert indices[::2] == Indices('x', slice=slice(None, None, 2))
    assert indices[1::2] == Indices('x', slice=slice(1, None, 2))
    assert indices[:3:2] == Indices('x', slice=slice(None, 3, 2))
    assert indices[1:3:2] == Indices('x', slice=slice(1, 3, 2))

# Generated at 2022-06-16 19:31:29.366293
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:31:48.686709
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[1:3]._slice == slice(1, 3)
    assert a[:3]._slice == slice(0, 3)
    assert a[1:]._slice == slice(1, None)
    assert a[:]._slice == slice(None)
    assert a[::2]._slice == slice(None, None, 2)
    assert a[1:3:2]._slice == slice(1, 3, 2)
    assert a[::-1]._slice == slice(None, None, -1)
    assert a[3:1:-1]._slice == slice(3, 1, -1)
    assert a[3:1:-2]._slice == slice(3, 1, -2)

# Generated at 2022-06-16 19:31:59.253154
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:10.566863
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pprint
    import json
    import datetime
    import collections
    import decimal
    import fractions
    import uuid
    import numpy as np
    import pandas as pd
    import xarray as xr
    import dask.array as da
    import dask.dataframe as dd
    import dask.bag as db
    import dask.delayed as dl
    import dask.dataframe.core as ddc
    import dask.dataframe.utils as ddu
    import dask.dataframe.groupby as ddg
    import dask.dataframe.io.parquet as ddip
    import dask.dataframe.io.csv as ddic
    import dask.dataframe.io.json as ddij

# Generated at 2022-06-16 19:32:20.387544
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:] == Indices('x')
    assert Indices('x')[1:] == Indices('x')[1:]
    assert Indices('x')[1:2] == Indices('x')[1:2]
    assert Indices('x')[1:2] != Indices('x')[1:3]
    assert Indices('x')[1:2] != Indices('x')[1:]
    assert Indices('x')[1:2] != Indices('x')[:]
    assert Indices('x')[1:2] != Indices('x')
    assert Indices('x')[1:2] != Indices('y')[1:2]
    assert Indices('x')[1:2] != Indices('x')[1:2,]
    assert Indices

# Generated at 2022-06-16 19:32:30.577995
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(level=1):
        frame = sys._getframe(level)
        if pycompat.PY2:
            frame = inspect.getargvalues(frame).frame
        return frame

    def get_items(source, exclude=()):
        return variables.BaseVariable(source, exclude).items(get_frame(2))

    assert get_items('a') == (('a', '1'),)
    assert get_items('a.b') == (('a.b', '2'),)
    assert get_items('a.b.c') == (('a.b.c', '3'),)

# Generated at 2022-06-16 19:32:34.866045
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils
    from . import pycompat

    class TestBaseVariable(unittest.TestCase):
        def test_BaseVariable_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back

# Generated at 2022-06-16 19:32:46.001916
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable('a', 'b', 'c', 'd') != BaseVariable('a', 'b', 'c')

# Generated at 2022-06-16 19:32:47.192349
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1:2]._slice == slice(1, 2)

# Generated at 2022-06-16 19:32:56.681068
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types

    def get_frame(depth=1):
        frame = inspect.currentframe()
        for i in range(depth):
            frame = frame.f_back
        return frame

    def get_frame_locals(depth=1):
        return get_frame(depth).f_locals

    def get_frame_globals(depth=1):
        return get_frame(depth).f_globals

    def get_frame_code(depth=1):
        return get_frame(depth).f_code

    def get_frame_code_name(depth=1):
        return get_frame_code(depth).co_name

    def get_frame_code_filename(depth=1):
        return get_frame_code(depth).co_

# Generated at 2022-06-16 19:33:08.451362
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:33:33.926579
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 1}}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = (1, 2, 3)
    frame.f_locals['f'] = 1
    frame.f_locals['g'] = 'abc'
    frame.f_locals['h'] = [1, 2, 3]
    frame.f_locals['i'] = {'b': {'c': 1}}
    frame.f_locals['j'] = {'b': {'c': 1}}
    frame.f_locals['k'] = {'b': {'c': 1}}

# Generated at 2022-06-16 19:33:44.946837
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_func():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26
        aa = 27
        bb = 28
        cc = 29
        dd = 30
        ee = 31
        ff = 32
        gg = 33
        hh = 34
        ii = 35
        jj = 36
        kk = 37


# Generated at 2022-06-16 19:33:54.166335
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    import io
    import contextlib

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = {'c': 2}
            self.frame.f_locals['d'] = [1, 2, 3]
            self.frame.f_locals['e'] = (1, 2, 3)
            self.frame.f_locals['f'] = {'g': {'h': 3}}
            self.frame.f_locals['i'] = [{'j': 4}, {'k': 5}]

# Generated at 2022-06-16 19:34:04.725297
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:34:08.454372
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    variable = BaseVariable('frame')
    assert variable.items(frame) == [('frame', '<frame object at 0x7f1b9d9f0f28>')]


# Generated at 2022-06-16 19:34:17.168438
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 1}
    frame.f_locals['c'] = [1, 2, 3]
    frame.f_locals['d'] = (1, 2, 3)
    frame.f_locals['e'] = {'f': {'g': 1}}
    frame.f_locals['h'] = [{'i': 1}, {'j': 2}]
    frame.f_locals['k'] = (1, {'l': 1}, 2)
    frame.f_locals['m'] = {'n': {'o': {'p': 1}}}
    frame.f_locals['q'] = [1, {'r': 1}, 2]
    frame.f_locals['s']

# Generated at 2022-06-16 19:34:27.042178
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:34:29.221320
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:34:36.958269
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:34:47.266948
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:36:04.841171
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycomp

# Generated at 2022-06-16 19:36:15.012718
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:36:26.335249
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['a'] = 1
            self.frame.f_locals['b'] = {'c': 2}
            self.frame.f_locals['d'] = [3, 4]
            self.frame.f_locals['e'] = (5, 6)
            self.frame.f_locals['f'] = {'g': 7, 'h': 8}
            self.frame.f_locals['i'] = [9, 10]
            self.frame.f_locals['j'] = (11, 12)
            self.frame.f_locals['k']

# Generated at 2022-06-16 19:36:37.351301
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:36:44.330356
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import unittest
    import unittest.mock
    import io
    import contextlib
    import re

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()

# Generated at 2022-06-16 19:36:50.532735
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'


# Generated at 2022-06-16 19:36:55.054025
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'x'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('x', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'x'


# Generated at 2022-06-16 19:36:56.713480
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:3] == Indices('a', slice(1, 3))

# Generated at 2022-06-16 19:37:08.809784
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:37:18.907837
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame_info = inspect.getframeinfo(frame)
    frame_locals = frame.f_locals
    frame_globals = frame.f_globals
    # test for class Attrs
    attrs = Attrs('frame_info')
    attrs_items = attrs.items(frame)

# Generated at 2022-06-16 19:38:04.519585
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe()
        while frame.f_globals['__name__'] == __name__:
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        if pycompat.PY3:
            return frame.f_locals
        else:
            return frame.f_locals.copy()

    def get_frame_globals(frame):
        if pycompat.PY3:
            return frame.f_globals
        else:
            return frame.f_globals.copy()

    def get_frame_locals_and_globals(frame):
        return get_frame_

# Generated at 2022-06-16 19:38:14.339925
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import os
    import re
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import itertools
    import operator
    import collections
    import json
    import base64
    import hashlib
    import hmac
    import pickle
    import tempfile
    import io
    import zipfile
    import zlib
    import gzip
    import bz2
    import lzma
    import shutil
    import tarfile
    import glob
    import pathlib
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.client
    import ftplib
    import telnetlib
    import poplib
    import imaplib
    import smtpl