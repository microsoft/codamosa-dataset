

# Generated at 2022-06-16 19:28:30.867046
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:28:43.717791
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('b', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != Base

# Generated at 2022-06-16 19:28:45.323499
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')
    assert v[1:3]._slice == slice(1, 3)

# Generated at 2022-06-16 19:28:49.212357
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:29:01.404630
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:29:08.946715
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)
    assert var_slice._fingerprint == (Indices, 'var', ())
    assert var_slice.source == 'var'
    assert var_slice.exclude == ()
    assert var_slice.code == compile('var', '<variable>', 'eval')
    assert var_slice.unambiguous_source == 'var'

# Generated at 2022-06-16 19:29:11.090951
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'


# Generated at 2022-06-16 19:29:18.703795
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:29:27.875446
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:29:38.431966
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:29:54.890244
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat
    from . import variables

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    class TestClass2(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    def test_function():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_function2():
        a = 1
        b = 2
        c = 3
        return a, b, c

    def test_function3():
        a = 1
        b = 2
        c = 3
        return a, b

# Generated at 2022-06-16 19:30:06.794988
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import time
    import datetime
    import random
    import string
    import math
    import functools
    import operator
    import itertools
    import collections
    import fractions
    import decimal
    import cmath
    import numbers
    import json
    import pickle
    import base64
    import hashlib
    import hmac
    import binascii
    import zlib
    import io
    import codecs
    import locale
    import gettext
    import struct
    import copy
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import mmap
    import email
    import smtplib
    import ssl
    import poplib
    import im

# Generated at 2022-06-16 19:30:13.405496
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-16 19:30:22.947268
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert Base

# Generated at 2022-06-16 19:30:28.142287
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a') != 'a'


# Generated at 2022-06-16 19:30:30.437791
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    assert v1 == v2
    assert v1 != v3
    assert v2 != v3


# Generated at 2022-06-16 19:30:37.154767
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:30:39.578059
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')
    assert var1 == var2
    assert var1 != var3


# Generated at 2022-06-16 19:30:51.571639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import datetime
    import time
    import math
    import random
    import string
    import collections
    import itertools
    import functools
    import operator
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import contextlib
    import tempfile
    import subprocess
    import io
    import zipfile
    import tarfile
    import gzip
    import bz2
    import lzma
    import zlib
    import hashlib
    import hmac
    import json
    import pickle
    import marshal
    import shelve
    import sqlite3
    import csv
    import configparser
    import netrc
    import getpass
    import gettext

# Generated at 2022-06-16 19:31:03.072993
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = {'c': 2}
    frame.f_locals['d'] = [3, 4]
    frame.f_locals['e'] = {'f': 5, 'g': 6}
    frame.f_locals['h'] = [7, 8]
    frame.f_locals['i'] = {'j': 9, 'k': 10}
    frame.f_locals['l'] = [11, 12]
    frame.f_locals['m'] = [13, 14]
    frame.f_locals['n'] = {'o': 15, 'p': 16}
    frame.f_locals['q'] = [17, 18]
   

# Generated at 2022-06-16 19:31:28.019165
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pprint
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_globals['a'] = 1
            self.frame.f_globals['b'] = 'abc'
            self.frame.f_globals['c'] = [1, 2, 3]
            self.frame.f_globals['d'] = {'a': 1, 'b': 2}
            self.frame.f_globals['e'] = (1, 2, 3)
            self.frame.f_globals['f'] = {1, 2, 3}
            self.frame.f_globals['g'] = types.Simple

# Generated at 2022-06-16 19:31:39.066227
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import builtins
    import functools
    import collections
    import datetime
    import time
    import random
    import math
    import itertools
    import operator
    import fractions
    import decimal
    import cmath
    import numbers
    import io
    import contextlib
    import threading
    import asyncio
    import subprocess
    import multiprocessing
    import socket
    import select
    import signal
    import mmap
    import json
    import pickle
    import marshal
    import code
    import codeop
    import zipfile
    import tarfile
    import bz2
    import gzip
    import lzma
    import zlib
    import hashlib
    import hmac
    import binascii


# Generated at 2022-06-16 19:31:49.144040
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:31:51.661529
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    a = A('a')
    b = A('b')
    c = A('a')
    assert a != b
    assert a == c
    assert b != c


# Generated at 2022-06-16 19:31:58.042556
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:32:04.500004
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import os
    import re
    import time
    import datetime
    import math
    import random
    import functools
    import operator
    import itertools
    import collections
    import threading
    import queue
    import asyncio
    import socket
    import ssl
    import select
    import subprocess
    import multiprocessing
    import multiprocessing.pool
    import multiprocessing.managers
    import multiprocessing.dummy
    import multiprocessing.sharedctypes
    import multiprocessing.connection
    import multiprocessing.synchronize
    import multiprocessing.heap
    import multiprocessing.process
    import multiprocessing.util
    import multiprocessing.forkserver

# Generated at 2022-06-16 19:32:15.105419
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:32:23.898468
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:35.966725
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils

# Generated at 2022-06-16 19:32:42.356453
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]
    test_variable = TestVariable('test_variable')
    assert test_variable.items(None) == [('test_variable', 'test_variable')]


# Generated at 2022-06-16 19:33:10.767233
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:33:21.601936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        frame = sys._getframe(1)
        while frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_code(frame):
        return frame.f_code

    def get_frame_code_name(frame):
        return frame.f_code.co_name

    def get_frame_code_filename(frame):
        return frame.f_code.co_filename


# Generated at 2022-06-16 19:33:29.827573
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['b', 'c'])


# Generated at 2022-06-16 19:33:39.925130
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:51.108229
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b', 'c', 'd'])

# Generated at 2022-06-16 19:34:03.050997
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import math
    import re
    import datetime
    import random
    import string
    import inspect
    import collections
    import functools
    import itertools
    import operator
    import types
    import builtins
    import contextlib
    import threading
    import time
    import logging
    import unittest
    import unittest.mock
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.sax.handler
    import xml.sax.saxutils
    import xml.sax.xmlreader
    import xml.parsers.expat
    import xml.dom
    import xml.dom.minidom
    import xml.dom.pulldom
    import xml.etree.ElementTree
   

# Generated at 2022-06-16 19:34:14.345259
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:34:25.172487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import json
    import types
    import numpy as np
    import pandas as pd
    import datetime
    import time
    import random
    import string
    import math
    import functools
    import operator
    import itertools
    import collections
    import contextlib
    import threading
    import queue
    import asyncio
    import multiprocessing
    import subprocess
    import socket
    import select
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.client
    import email.message
    import email.parser
    import email.policy
    import xml.etree.ElementTree
    import zipfile
    import tarfile
    import sqlite3
    import zlib
   

# Generated at 2022-06-16 19:34:36.566578
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs
    from .variables import Keys
    from .variables import Indices
    from .variables import Exploding
    from . import utils
    from . import pycompat
    from . import variables
    from .variables import BaseVariable
    from .variables import CommonVariable
    from .variables import Attrs

# Generated at 2022-06-16 19:34:45.651067
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = inspect.currentframe()
            self.frame.f_globals = sys._getframe(1).f_globals
            self.frame.f_locals = sys._getframe(1).f_locals

        def test_BaseVariable_items(self):
            self.assertEqual(BaseVariable('a').items(self.frame), [('a', '1')])
            self.assertEqual(BaseVariable('a.b').items(self.frame), [('a.b', '2')])

# Generated at 2022-06-16 19:35:31.102612
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins

    def get_frame(func):
        return inspect.getframeinfo(sys._getframe(1))

    def get_frame_locals(func):
        return get_frame(func).frame.f_locals

    def get_frame_globals(func):
        return get_frame(func).frame.f_globals

    def get_frame_code(func):
        return get_frame(func).code_context[0]

    def get_frame_code_locals(func):
        return get_frame(func).code_context[0].co_names

    def get_frame_code_globals(func):
        return get_frame(func).code_context[0].co_names


# Generated at 2022-06-16 19:35:38.990811
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:35:49.374006
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:36:01.512557
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pytest
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame():
        frame = sys._getframe()
        while frame.f_code.co_name != 'test_BaseVariable_items':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return dict(inspect.getargvalues(frame)[3])

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_locals_globals(frame):
        return get_frame_locals(frame), get_frame_globals(frame)

    def get_frame_locals_globals_normalize(frame):
        return get

# Generated at 2022-06-16 19:36:10.137119
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions
    from . import config
    from . import patch
    from . import hooks
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat
    from . import compat

# Generated at 2022-06-16 19:36:19.555281
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:36:31.770607
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 2
    frame.f_locals['c'] = 3
    frame.f_locals['d'] = 4
    frame.f_locals['e'] = 5
    frame.f_locals['f'] = 6
    frame.f_locals['g'] = 7
    frame.f_locals['h'] = 8
    frame.f_locals['i'] = 9
    frame.f_locals['j'] = 10
    frame.f_locals['k'] = 11
    frame.f_locals['l'] = 12
    frame.f_locals['m'] = 13
    frame.f_locals['n'] = 14
    frame.f

# Generated at 2022-06-16 19:36:41.469256
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys
    import os
    import re
    import types
    import pdb
    import pprint
    import traceback
    import time
    import datetime
    import math
    import random
    import string
    import io
    import array
    import collections
    import collections.abc
    import contextlib
    import functools
    import itertools
    import operator
    import threading
    import multiprocessing
    import subprocess
    import socket
    import select
    import selectors
    import asyncio
    import asyncore
    import asynchat
    import signal
    import fileinput
    import atexit
    import shutil
    import tempfile
    import glob
    import fnmatch
    import linecache
    import shlex
    import shutil

# Generated at 2022-06-16 19:36:52.327006
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    frame = sys._getframe()
    frame_info = inspect.getframeinfo(frame)
    frame_info_dict = utils.get_frame_info_dict(frame_info)
    frame_info_dict_items = frame_info_dict.items()
    frame_info_dict_items_list = list(frame_info_dict_items)
    frame_info_dict_items_list_list = [frame_info_dict_items_list]
    frame_info_dict_items_list_list_list = [frame_info_dict_items_list_list]
    frame_info_dict_items_list_list_list_list = [frame_info_dict_items_list_list_list]
    frame_

# Generated at 2022-06-16 19:36:58.683581
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 'a'
    frame.f_locals['b'] = 'b'
    frame.f_locals['c'] = 'c'
    frame.f_locals['d'] = 'd'
    frame.f_locals['e'] = 'e'
    frame.f_locals['f'] = 'f'
    frame.f_locals['g'] = 'g'
    frame.f_locals['h'] = 'h'
    frame.f_locals['i'] = 'i'
    frame.f_locals['j'] = 'j'
    frame.f_locals['k'] = 'k'
    frame.f_locals['l'] = 'l'
    frame.f_loc

# Generated at 2022-06-16 19:38:13.798471
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame