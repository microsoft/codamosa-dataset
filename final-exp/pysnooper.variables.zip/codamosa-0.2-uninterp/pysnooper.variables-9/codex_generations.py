

# Generated at 2022-06-16 19:28:30.628808
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:28:43.435590
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    import re
    import os
    import math
    import random
    import datetime
    import time
    import functools
    import operator
    import itertools
    import collections
    import string
    import json
    import io
    import zipfile
    import tempfile
    import threading
    import subprocess
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import selectors
    import ssl
    import email
    import email.message
    import email.utils
    import email.mime
    import email.mime.text
    import email.mime.multipart
    import email.mime.application
    import email.mime.audio
    import email.mime.image
   

# Generated at 2022-06-16 19:28:51.541913
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable_subclass(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    var1 = BaseVariable_subclass('a')
    var2 = BaseVariable_subclass('a')
    var3 = BaseVariable_subclass('b')
    assert var1 == var2
    assert var1 != var3
    assert var1 != 1
    assert var1 != None
    assert var1 != 'a'
    assert var1 != (1, 2)
    assert var1 != [1, 2]
    assert var1 != {1: 2}
    assert var1 != {1, 2}


# Generated at 2022-06-16 19:29:03.409797
# Unit test for method items of class BaseVariable

# Generated at 2022-06-16 19:29:10.540557
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:29:18.446312
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'
    assert indices_slice._fingerprint == (Indices, 'a', ())
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice._keys(['a', 'b', 'c', 'd']) == [1, 2]
    assert indices_slice._format_key(1) == '[1]'
    assert indices_slice._get_value(['a', 'b', 'c', 'd'], 1)

# Generated at 2022-06-16 19:29:27.792053
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'd'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:29:38.357954
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test for the case when the source is the same
    source = 'a'
    var1 = BaseVariable(source)
    var2 = BaseVariable(source)
    assert var1 == var2

    # Test for the case when the source is different
    source2 = 'b'
    var3 = BaseVariable(source2)
    assert var1 != var3

    # Test for the case when the exclude is the same
    exclude = 'a'
    var4 = BaseVariable(source, exclude)
    var5 = BaseVariable(source, exclude)
    assert var4 == var5

    # Test for the case when the exclude is different
    exclude2 = 'b'
    var6 = BaseVariable(source, exclude2)
    assert var4 != var6

    # Test for the case when the source and exclude are the same

# Generated at 2022-06-16 19:29:50.121750
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'a': 1, 'b': 2}
    frame.f_locals['b'] = [1, 2, 3]
    frame.f_locals['c'] = 'abc'
    frame.f_locals['d'] = {'a': {'a': 1, 'b': 2}, 'b': [1, 2, 3], 'c': 'abc'}
    frame.f_locals['e'] = [{'a': 1, 'b': 2}, [1, 2, 3], 'abc']
    frame.f_locals['f'] = {'a': [1, 2, 3], 'b': [1, 2, 3], 'c': 'abc'}

# Generated at 2022-06-16 19:29:55.242804
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')


# Generated at 2022-06-16 19:30:12.995450
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import os
    import re
    import unittest
    import functools
    import itertools
    import collections
    import operator
    import random
    import string
    import datetime
    import time
    import math
    import fractions
    import decimal
    import io
    import json
    import pickle
    import gzip
    import bz2
    import lzma
    import zipfile
    import tarfile
    import tempfile
    import shutil
    import subprocess
    import threading
    import multiprocessing
    import concurrent.futures
    import asyncio
    import socket
    import select
    import ssl
    import email
    import email.message
    import email.mime
    import email.parser
    import email

# Generated at 2022-06-16 19:30:22.719706
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    #print(frame.f_locals)
    #print(frame.f_globals)
    #print(frame.f_code)
    #print(frame.f_code.co_name)
    #print(frame.f_code.co_varnames)
    #print(frame.f_code.co_argcount)
    #print(frame.f_code.co_filename)
    #print(frame.f_code.co_firstlineno)
    #print(frame.f_code.co_lnotab)
    #print(frame.f_code.co_consts)
    #print(frame.f_code.co_names)
    #print(frame.f_code

# Generated at 2022-06-16 19:30:33.813235
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:30:42.724386
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))

# Generated at 2022-06-16 19:30:54.578368
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a') != Attrs('a')
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a', 'b') == Attrs('a', 'b')
    assert Attrs('a', 'b') != Attrs('a', 'c')
    assert Attrs('a') != Keys('a')
    assert Keys('a') == Keys('a')
    assert Keys('a') != Keys('b')

# Generated at 2022-06-16 19:31:05.086951
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'd'])


# Generated at 2022-06-16 19:31:14.814920
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:31:26.460073
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])

# Generated at 2022-06-16 19:31:32.622017
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import pprint
    import types
    import builtins
    import functools
    import operator
    import collections
    import itertools
    import random
    import string
    import time
    import datetime
    import math
    import fractions
    import decimal
    import io
    import json
    import pickle
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax.saxutils
    import xml.parsers.expat
    import xml.etree.cElementTree
    import xml.etree.ElementInclude
    import xml.etree.ElementPath
    import xml.etree.ElementTree
    import xml.etree.SimpleXMLTreeBuilder
    import xml.etree.XMLParser

# Generated at 2022-06-16 19:31:44.073022
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils
    from . import pycompat

    def get_frame():
        frame = sys._getframe()
        while frame.f_code.co_name == 'get_frame':
            frame = frame.f_back
        return frame

    def get_frame_locals(frame):
        return frame.f_locals

    def get_frame_globals(frame):
        return frame.f_globals

    def get_frame_builtins(frame):
        return frame.f_builtins

    def get_frame_code(frame):
        return frame.f_code

    def get_frame_code_name(frame):
        return frame.f_code.co_name

    def get_frame_code_filename(frame):
        return frame

# Generated at 2022-06-16 19:32:03.998833
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 1}}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = (1, 2, 3)
    frame.f_locals['f'] = 1
    frame.f_locals['g'] = 'abc'
    frame.f_locals['h'] = (1, 2, 3)
    frame.f_locals['i'] = [1, 2, 3]
    frame.f_locals['j'] = {'b': {'c': 1}}
    frame.f_locals['k'] = [1, 2, 3]

# Generated at 2022-06-16 19:32:14.663890
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("a", "b")
    b = BaseVariable("a", "b")
    assert a == b
    c = BaseVariable("a", "c")
    assert a != c
    d = BaseVariable("d", "b")
    assert a != d
    e = BaseVariable("a")
    assert a != e
    f = BaseVariable("a", "b", "c")
    assert a != f
    g = BaseVariable("a", ["b"])
    assert a == g
    h = BaseVariable("a", ["b", "c"])
    assert a != h
    i = BaseVariable("a", "b", ["c"])
    assert a != i
    j = BaseVariable("a", ["b", "c"])
    assert a != j

# Generated at 2022-06-16 19:32:23.563568
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:32.261657
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != None


# Generated at 2022-06-16 19:32:44.295810
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])

# Unit

# Generated at 2022-06-16 19:32:51.403143
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import types
    from . import utils
    from . import pycompat
    from . import variables

    def get_frame(func):
        return inspect.getouterframes(inspect.currentframe())[func.__code__.co_firstlineno + 1][0]

    def get_frame_locals(func):
        return get_frame(func).f_locals

    def get_frame_globals(func):
        return get_frame(func).f_globals

    def get_frame_locals_and_globals(func):
        return get_frame(func).f_locals, get_frame(func).f_globals


# Generated at 2022-06-16 19:32:59.435206
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import pytest
    from . import utils
    from . import pycompat

    def test_items(variable, frame, expected):
        result = variable.items(frame)
        assert result == expected

    def test_items_normalize(variable, frame, expected):
        result = variable.items(frame, normalize=True)
        assert result == expected

    def test_items_exclude(variable, frame, expected):
        result = variable.items(frame, exclude=['a'])
        assert result == expected

    def test_items_normalize_exclude(variable, frame, expected):
        result = variable.items(frame, normalize=True, exclude=['a'])
        assert result == expected

    def test_items_exclude_normalize(variable, frame, expected):
        result

# Generated at 2022-06-16 19:33:10.469753
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
   

# Generated at 2022-06-16 19:33:21.482531
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:30.950489
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = [1, 2, 3]
    frame.f_locals['b'] = {'a': 1, 'b': 2}
    frame.f_locals['c'] = {'a': 1, 'b': 2}
    frame.f_locals['d'] = {'a': 1, 'b': 2}
    frame.f_locals['e'] = {'a': 1, 'b': 2}
    frame.f_locals['f'] = {'a': 1, 'b': 2}
    frame.f_locals['g'] = {'a': 1, 'b': 2}
    frame.f_locals['h'] = {'a': 1, 'b': 2}
    frame.f_loc

# Generated at 2022-06-16 19:34:02.654072
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))


# Generated at 2022-06-16 19:34:14.233181
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:21.767121
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:34:31.904024
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:38.277402
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:34:49.948326
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable('a', 'b', 'c', 'd') == BaseVariable('a', 'b', 'c', 'd')
    assert BaseVariable

# Generated at 2022-06-16 19:34:58.043557
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
            self.j = 10
            self.k = 11
            self.l = 12
            self.m = 13
            self.n = 14
            self.o = 15
            self.p = 16
            self.q = 17
            self.r = 18
            self.s = 19
            self.t = 20
            self.u = 21
            self.v = 22

# Generated at 2022-06-16 19:35:09.717227
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['a']) == BaseVariable('a', exclude=['a'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['a']) != BaseVariable('a', exclude=['a', 'b'])
    assert BaseVariable('a', exclude=['a', 'b']) != BaseVariable('a', exclude=['a'])
    assert BaseVariable('a', exclude=['a', 'b']) == BaseVariable('a', exclude=['a', 'b'])

# Generated at 2022-06-16 19:35:19.559259
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['x'] = {'a': 1, 'b': 2}
    frame.f_locals['y'] = [1, 2, 3]
    frame.f_locals['z'] = (1, 2, 3)
    frame.f_locals['w'] = 'abc'
    frame.f_locals['v'] = 1
    frame.f_locals['u'] = object()
    frame.f_locals['t'] = object()
    frame.f_locals['t'].__dict__ = {'a': 1, 'b': 2}
    frame.f_locals['t'].__slots__ = ('a', 'b')
    frame.f_locals['t'].a = 1
    frame.f

# Generated at 2022-06-16 19:35:30.245193
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])


# Generated at 2022-06-16 19:36:39.859626
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils
    from . import pycompat

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.frame = sys._getframe()
            self.frame.f_locals['x'] = 1
            self.frame.f_locals['y'] = 2
            self.frame.f_locals['z'] = 3
            self.frame.f_locals['a'] = [1, 2, 3]
            self.frame.f_locals['b'] = {'a': 1, 'b': 2, 'c': 3}
            self.frame.f_locals['c'] = (1, 2, 3)

# Generated at 2022-06-16 19:36:50.778712
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('b', 'c', 'd'))
    assert Base

# Generated at 2022-06-16 19:36:57.867295
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for class CommonVariable
    class TestCommonVariable(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))

        def _get_value(self, main_value, key):
            return main_value[key]

    # test for class Attrs
    class TestAttrs(Attrs):
        pass

    # test for class Keys
    class TestKeys(Keys):
        pass

    # test for class Indices
    class TestIndices(Indices):
        pass

    # test for class Exploding
    class TestExploding(Exploding):
        pass

    # test for class CommonVariable

# Generated at 2022-06-16 19:37:10.096611
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back


# Generated at 2022-06-16 19:37:20.058554
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:37:29.546040
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import utils
    from . import pycompat
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycompat
    from . import utils
    from . import variables
    from . import pycomp

# Generated at 2022-06-16 19:37:39.450993
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import unittest
    import unittest.mock
    import tempfile
    import contextlib
    import io
    import dis
    import pprint
    import random
    import string
    import functools
    import operator
    import itertools
    import collections
    import datetime
    import time
    import math
    import fractions
    import numbers
    import enum
    import locale
    import codecs
    import copy
    import pickle
    import json
    import base64
    import zlib
    import zipfile
    import tarfile
    import shutil
    import hashlib
    import hmac
    import struct
    import socket
    import ssl
    import selectors
    import asyncio
    import thread

# Generated at 2022-06-16 19:37:51.416753
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib
    import inspect
    import sys
    import os
    import re
    import types
    import importlib

# Generated at 2022-06-16 19:37:55.922175
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != 'a'
    assert BaseVariable('a') != None


# Generated at 2022-06-16 19:38:04.674678
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from . import utils