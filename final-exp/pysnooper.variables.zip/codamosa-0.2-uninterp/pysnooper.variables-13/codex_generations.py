

# Generated at 2022-06-16 19:28:32.009192
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    from collections import Mapping, Sequence
    import itertools
    import abc
    import sys
    import os
    import io
    import re
    import types
    import builtins
    import inspect
    import traceback
    import contextlib
    import unittest
    import unittest.mock
    import tempfile
    import functools
    import subprocess
    import threading
    import time
    import random
    import string
    import warnings
    import abc
    import datetime
    import decimal
    import fractions
    import numbers
    import io

# Generated at 2022-06-16 19:28:38.860148
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'a'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('a', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'a'


# Generated at 2022-06-16 19:28:49.221950
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[1:2]._slice == slice(1, 2)
    assert indices[1:2].source == 'a'
    assert indices[1:2].exclude == ()
    assert indices[1:2].code == compile('a', '<variable>', 'eval')
    assert indices[1:2].unambiguous_source == 'a'
    assert indices[1:2]._fingerprint == (Indices, 'a', ())
    assert indices[1:2]._slice == slice(1, 2)
    assert indices[1:2]._keys(['a', 'b', 'c']) == [1]
    assert indices[1:2]._format_key(1) == '[1]'

# Generated at 2022-06-16 19:28:53.623343
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)
    assert var_slice._fingerprint == (Indices, 'x', ())

# Generated at 2022-06-16 19:29:04.728710
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import io
    import contextlib
    import unittest
    from . import utils
    from . import pycompat


# Generated at 2022-06-16 19:29:11.435034
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    indices_slice = indices[1:3]
    assert indices_slice._slice == slice(1, 3)
    assert indices_slice.source == 'x'
    assert indices_slice.exclude == ()
    assert indices_slice.code == compile('x', '<variable>', 'eval')
    assert indices_slice.unambiguous_source == 'x'


# Generated at 2022-06-16 19:29:15.628039
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:29:26.076224
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c', 'b'))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('b', 'c', 'd'))

# Generated at 2022-06-16 19:29:37.138983
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import unittest
    from . import utils

    class TestBaseVariable(unittest.TestCase):
        def test_items(self):
            frame = inspect.currentframe()
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_back
            frame = frame.f_

# Generated at 2022-06-16 19:29:39.876536
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('source')
    assert indices[:] == indices
    assert indices[1:2] != indices
    assert indices[1:2] == Indices('source')[1:2]
    assert indices[1:2] != Indices('source')[2:3]

# Generated at 2022-06-16 19:29:55.280998
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import os.path
    import re
    import types
    import unittest
    import pycompat
    import utils
    import BaseVariable
    import Attrs
    import Keys
    import Indices
    import Exploding
    import inspect
    import sys
    import os
    import os.path
    import re
    import types
    import unittest
    import pycompat
    import utils
    import BaseVariable
    import Attrs
    import Keys
    import Indices
    import Exploding


# Generated at 2022-06-16 19:30:07.258031
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:30:18.979619
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import builtins
    import __main__
    import functools
    import collections
    import itertools
    import operator
    import random
    import math
    import time
    import datetime
    import threading
    import subprocess
    import multiprocessing
    import socket
    import select
    import mmap
    import json
    import marshal
    import pickle
    import shelve
    import sqlite3
    import csv
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import html.parser
    import html.entities
    import html.entities
    import html.parser
    import http.client
    import urllib.request
    import urll

# Generated at 2022-06-16 19:30:31.452832
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b', 'c') == BaseVariable('a', 'b', 'c')
    assert BaseVariable('a', 'b', 'c') != BaseVariable('a', 'b', 'd')
    assert BaseVariable('a', 'b', 'c') != BaseVariable

# Generated at 2022-06-16 19:30:41.768662
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = 'a'
    frame.f_locals['b'] = 'b'
    frame.f_locals['c'] = 'c'
    frame.f_locals['d'] = 'd'
    frame.f_locals['e'] = 'e'
    frame.f_locals['f'] = 'f'
    frame.f_locals['g'] = 'g'
    frame.f_locals['h'] = 'h'
    frame.f_locals['i'] = 'i'
    frame.f_locals['j'] = 'j'
    frame.f_locals['k'] = 'k'
    frame.f_locals['l'] = 'l'
    frame.f_loc

# Generated at 2022-06-16 19:30:52.206793
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:31:03.618597
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    def test_func():
        return 1

    def test_func2():
        return 2

    def test_func3():
        return 3

    def test_func4():
        return 4

    def test_func5():
        return 5

    def test_func6():
        return 6

    def test_func7():
        return 7

    def test_func8():
        return 8

    def test_func9():
        return 9

    def test_func10():
        return 10

    def test_func11():
        return 11

    def test_func12():
        return 12


# Generated at 2022-06-16 19:31:14.976876
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 'c'}
    assert Keys('a').items(frame) == [('a', "{'b': 'c'}")]
    assert Keys('a').items(frame, normalize=True) == [('a', '{...}')]
    assert Keys('a', 'b').items(frame) == [('a', "{'b': 'c'}")]
    assert Keys('a', 'b').items(frame, normalize=True) == [('a', '{...}')]
    assert Attrs('a').items(frame) == [('a', "{'b': 'c'}")]
    assert Attrs('a').items(frame, normalize=True) == [('a', '{...}')]

# Generated at 2022-06-16 19:31:26.582465
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import io
    import pprint
    import unittest
    import unittest.mock

    class Test(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(types.CodeType, self.assertCodeEqual)
            self.addTypeEqualityFunc(types.FrameType, self.assertFrameEqual)
            self.addTypeEqualityFunc(types.TracebackType, self.assertTracebackEqual)
            self.addTypeEqualityFunc(types.ModuleType, self.assertModuleEqual)
            self.addTypeEqualityFunc(types.MethodType, self.assertMethodEqual)


# Generated at 2022-06-16 19:31:32.668387
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:31:49.417518
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:31:54.858037
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'b', 'd'])
    assert Base

# Generated at 2022-06-16 19:32:03.176061
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_

# Generated at 2022-06-16 19:32:13.908339
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import pprint
    import io
    from . import utils

    def get_frame(level=1):
        frame = inspect.currentframe()
        for _ in range(level):
            frame = frame.f_back
        return frame

    def get_locals(level=1):
        return get_frame(level).f_locals

    def get_globals(level=1):
        return get_frame(level).f_globals

    def get_code(level=1):
        return get_frame(level).f_code

    def get_module(level=1):
        return sys.modules[get_code(level).co_filename]

    def get_module_name(level=1):
        return get_module(level).__name__

   

# Generated at 2022-06-16 19:32:20.735732
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:31.280076
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import builtins
    frame = inspect.currentframe()
    frame = frame.f_back
    frame.f_globals.update(builtins.__dict__)
    frame.f_globals.update(sys.modules)
    frame.f_globals.update(types.__dict__)
    frame.f_globals.update(inspect.__dict__)
    frame.f_globals.update(__builtins__.__dict__)
    frame.f_globals.update(__builtins__.__dict__)
    frame.f_globals.update(__builtins__.__dict__)
    frame.f_globals.update(__builtins__.__dict__)
    frame.f_globals

# Generated at 2022-06-16 19:32:43.350745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:32:50.908961
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import utils
    from . import pycompat
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables
    from . import variables


# Generated at 2022-06-16 19:32:56.417076
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != 'a'


# Generated at 2022-06-16 19:33:08.190229
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': 1, 'c': 2}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = {'f': {'g': 1}}
    frame.f_locals['h'] = [{'i': 1}, {'j': 2}]
    frame.f_locals['k'] = [1, 2, {'l': 1}]
    frame.f_locals['m'] = {'n': [1, 2]}
    frame.f_locals['o'] = {'p': [1, 2]}
    frame.f_locals['q'] = {'r': [1, 2]}

# Generated at 2022-06-16 19:33:28.096780
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:33:34.516705
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('b', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != Base

# Generated at 2022-06-16 19:33:45.651951
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import types
    import builtins
    import re
    import math
    import random
    import string
    import datetime
    import time
    import functools
    import operator
    import itertools
    import collections
    import threading
    import asyncio
    import multiprocessing
    import concurrent.futures
    import subprocess
    import ctypes
    import cmath
    import decimal
    import fractions
    import io
    import json
    import pickle
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml.sax
    import xml.parsers.expat
    import xml.parsers.expat
    import xml.etree.ElementTree
    import xml.dom.minidom
    import xml

# Generated at 2022-06-16 19:33:54.554222
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import re
    import types
    import builtins
    import pprint
    import traceback
    import unittest

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(types.CodeType, self.assertCodeEqual)
            self.addTypeEqualityFunc(types.FrameType, self.assertFrameEqual)
            self.addTypeEqualityFunc(types.TracebackType, self.assertTracebackEqual)
            self.addTypeEqualityFunc(types.ModuleType, self.assertModuleEqual)

# Generated at 2022-06-16 19:34:04.937077
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])

# Generated at 2022-06-16 19:34:13.147143
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != object()


# Generated at 2022-06-16 19:34:24.095320
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    from . import utils

    def test_func():
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5
        f = 6
        g = 7
        h = 8
        i = 9
        j = 10
        k = 11
        l = 12
        m = 13
        n = 14
        o = 15
        p = 16
        q = 17
        r = 18
        s = 19
        t = 20
        u = 21
        v = 22
        w = 23
        x = 24
        y = 25
        z = 26

    frame = sys._getframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_

# Generated at 2022-06-16 19:34:35.603174
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions
    from . import config
    from . import patch
    from . import traceback
    from . import hooks
    from . import __main__

    # Create a frame object
    frame = inspect.currentframe()
    frame = frames.Frame(frame)
    frame.f_globals['__name__'] = '__main__'
    frame.f_globals['__file__'] = __file__
    frame.f_globals['__package__'] = __package__
    frame.f_globals['__doc__'] = __doc__
    frame.f_globals['__builtins__'] = __builtins__

    # Create a config

# Generated at 2022-06-16 19:34:43.420228
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables

    # Create a frame object
    def foo():
        a = 1
        b = 2
        c = 3
        return inspect.currentframe()
    frame = foo()

    # Create a BaseVariable object
    source = 'a'
    exclude = ('b',)
    variable = variables.BaseVariable(source, exclude)

    # Test items method
    result = variable.items(frame)
    expected = [('a', '1')]
    assert result == expected, '{} != {}'.format(result, expected)



# Generated at 2022-06-16 19:34:53.355307
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])
    assert BaseVariable('a', exclude=['b', 'c']) != BaseVariable('a', exclude=['c', 'd'])


# Generated at 2022-06-16 19:35:21.853878
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import tempfile
    import shutil
    import importlib
    from . import utils
    from . import pycompat
    from . import variables
    from . import test_utils

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)
            self.sys_path = sys.path[:]
            sys.path.insert(0, self.test_dir)
            self.addCleanup(sys.path.__setitem__, slice(None), self.sys_path)


# Generated at 2022-06-16 19:35:30.634868
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['b', 'c'])
    assert BaseVariable('a', exclude=['b', 'c']) == BaseVariable('a', exclude=['c', 'b'])


# Generated at 2022-06-16 19:35:38.698440
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:35:50.448039
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import BaseVariable
    from . import CommonVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

# Generated at 2022-06-16 19:36:02.045150
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils
    from . import pycompat
    from . import variables
    from . import frames
    from . import exceptions
    from . import config
    from . import compat
    from . import patch
    from . import hooks
    from . import processors
    from . import reporter
    from . import session
    from . import version
    from . import cli
    from . import main
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __author__
    from . import __author_email__
    from . import __license__
    from . import __url__
    from . import __description__
    from . import __keywords__
    from . import __classifiers__
    from . import __download_url__

# Generated at 2022-06-16 19:36:10.491565
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    frame.f_locals['a'] = {'b': {'c': 1}}
    frame.f_locals['d'] = [1, 2, 3]
    frame.f_locals['e'] = (1, 2, 3)
    frame.f_locals['f'] = {'b': {'c': 1}}
    frame.f_locals['g'] = [1, 2, 3]
    frame.f_locals['h'] = (1, 2, 3)
    frame.f_locals['i'] = {'b': {'c': 1}}
    frame.f_locals['j'] = [1, 2, 3]
    frame.f_locals['k'] = (1, 2, 3)
    frame.f_loc

# Generated at 2022-06-16 19:36:16.114688
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))

# Generated at 2022-06-16 19:36:27.552381
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import tempfile
    import os
    import contextlib

    def get_frame(level=0):
        return inspect.stack()[level + 1][0]

    def get_frame_locals(level=0):
        return inspect.stack()[level + 1][0].f_locals

    def get_frame_globals(level=0):
        return inspect.stack()[level + 1][0].f_globals

    def get_frame_code(level=0):
        return inspect.stack()[level + 1][0].f_code

    def get_frame_function(level=0):
        return inspect.stack()[level + 1][0].f_code.co_name

    def get_frame_filename(level=0):
        return inspect.stack

# Generated at 2022-06-16 19:36:38.409725
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame = frame.f_back
    frame

# Generated at 2022-06-16 19:36:41.637781
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')


# Generated at 2022-06-16 19:37:32.311141
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types
    import unittest
    import pdb
    import pprint
    import io
    import contextlib

    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None
            self.longMessage = True
            self.addTypeEqualityFunc(types.CodeType, self.assertCodeEqual)
            self.addTypeEqualityFunc(types.FrameType, self.assertFrameEqual)
            self.addTypeEqualityFunc(types.TracebackType, self.assertTracebackEqual)
            self.addTypeEqualityFunc(types.ModuleType, self.assertModuleEqual)

# Generated at 2022-06-16 19:37:40.886411
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import pdb
    import re

    def get_frame_info(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_by_frame(frame):
        return inspect.getframeinfo(frame)

    def get_frame_info_by_frame_by_frame(frame):
        return get_frame_info_by_frame(frame)

    def get_frame_info_by_frame_by_frame_by_frame(frame):
        return get_frame_info_by_frame_by_frame(frame)

    def get_frame_info_by_frame_by_frame_by_frame_by_frame(frame):
        return get_frame_info_by_frame_by_frame_by_frame(frame)


# Generated at 2022-06-16 19:37:52.720515
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import types
    import collections
    import numpy as np
    from . import utils
    from . import pycompat

    def get_frame(depth=1):
        frame = sys._getframe(depth)
        if pycompat.PY2:
            frame = types.FrameType(frame.f_code, frame.f_globals, frame.f_locals, frame.f_back)
        return frame

    def get_frame_locals(depth=1):
        return get_frame(depth).f_locals

    def get_frame_globals(depth=1):
        return get_frame(depth).f_globals

    def get_frame_locals_and_globals(depth=1):
        return get_frame_locals(depth), get

# Generated at 2022-06-16 19:38:02.675638
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import os
    import re
    import types

    def get_frame(level=0):
        frame = inspect.currentframe()
        for _ in range(level + 1):
            frame = frame.f_back
        return frame

    def get_frame_locals(level=0):
        return get_frame(level).f_locals

    def get_frame_globals(level=0):
        return get_frame(level).f_globals

    def get_frame_code(level=0):
        return get_frame(level).f_code

    def get_frame_code_name(level=0):
        return get_frame_code(level).co_name


# Generated at 2022-06-16 19:38:13.360476
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude=['y']) == BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['z'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x', exclude=['y', 'z'])
    assert BaseVariable('x', exclude=['y', 'z']) != BaseVariable('x', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('y', exclude=['y'])
    assert BaseVariable('x', exclude=['y']) != BaseVariable('x')
    assert BaseVariable('x', exclude=['y']) != Base