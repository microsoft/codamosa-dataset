

# Generated at 2022-06-22 18:25:49.538140
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('main')
    assert e.source == 'main'
    assert e.exclude == tuple()

    e = Exploding('main', ('exclude1', 'exclude2'))
    assert e.source == 'main'
    assert e.exclude == ('exclude1', 'exclude2')


# Generated at 2022-06-22 18:25:54.490564
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class TestClass(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))

        def _get_value(self, main_value, key):
            return main_value[key]
    # Test of items method
    # Case 1
    d = {'a': 1, 'b': 2, 'c': 3}
    var = TestClass('var', exclude=('a', 'c'))
    assert var.items({'var': d}) == [('var', utils.get_shortish_repr(d)),
                                      ('var[b]', utils.get_shortish_repr(2))]
    # Case 2
    d

# Generated at 2022-06-22 18:25:57.967966
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('main_value')
    x = CommonVariable('main', 'second')
    x = CommonVariable('main', ['second', 'third'])
    assert x.exclude == ('second', 'third',)


# Generated at 2022-06-22 18:26:03.093467
# Unit test for constructor of class Indices
def test_Indices():
	import unittest
	class TestIndices(unittest.TestCase):
	    def test_indices(self):
	        a=[1,2,3,4,5]
	        b = Indices("a")
	        self.assertEqual(b._slice,slice(None))
	        b= Indices("a[:-1]")	
	        self.assertEqual(b._slice,slice(None,-1))
	unittest.main()

# Generated at 2022-06-22 18:26:04.792272
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable('x')
    w = BaseVariable('y')
    assert v != w


# Generated at 2022-06-22 18:26:07.924413
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('foo')
    assert v[1:4]._slice == slice(1, 4, None)
    assert v[:4]._slice == slice(0, 4, None)
    assert v[:]._slice == slice(0, None, None)

# Generated at 2022-06-22 18:26:11.241470
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var = BaseVariable("a")
    var1 = BaseVariable("a")
    assert var==var1

    var2 = BaseVariable("b")
    assert not var==var2


# Generated at 2022-06-22 18:26:21.723750
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('1')
    assert x.source == '1'
    assert x.code == compile('1', '<variable>', 'eval')
    assert not needs_parentheses('1')
    assert x.unambiguous_source == '1'
    y = CommonVariable('x * y')
    assert y.source == 'x * y'
    assert y.code == compile('x * y', '<variable>', 'eval')
    assert needs_parentheses('x * y')
    assert y.unambiguous_source == '(x * y)'

    assert x.exclude == ()
    assert y.exclude == ()
    x = CommonVariable('1', exclude='1')
    assert x.exclude == ('1',)
    y = CommonVariable('1', exclude=('1',))
    assert y.exclude

# Generated at 2022-06-22 18:26:30.651617
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('1')
    assert needs_parentheses('a')
    assert needs_parentheses('-')

    assert needs_parentheses('1 + 1')
    assert needs_parentheses('(1) + (1)')
    assert needs_parentheses('1 + (1)')
    assert needs_parentheses('1 - (1)')

    assert needs_parentheses('1 +')
    assert not needs_parentheses('(1) +')
    assert needs_parentheses('1 -')
    assert not needs_parentheses('(1) -')

# Generated at 2022-06-22 18:26:37.449471
# Unit test for constructor of class Exploding
def test_Exploding():
    from .vars import Exploding
    from . import utils
    x = utils.AttrDict(a=1, b=2)
    var = Exploding('x')
    print(var._items(x))
    var = Exploding('x.c')
    print(var._items(x))
    var = Exploding('x["a"]')
    print(var._items(x))
    var = Exploding('x, x.a')
    print(var._items(x))

# Generated at 2022-06-22 18:26:38.988354
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('test'), BaseVariable)



# Generated at 2022-06-22 18:26:42.210057
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices(1)
    assert a.source == 1
    assert a.code == compile('1', '<variable>', 'eval')
    assert a.exclude == ()


# Generated at 2022-06-22 18:26:50.836970
# Unit test for constructor of class Exploding
def test_Exploding():
    class NameSpace(object):
        def __init__(self, data):
            self.data = data
        
        def __getitem__(self, key):
            return self.data[key]
        
        def __iter__(self):
            return iter(self.data)

    # Mapping
    mapping = NameSpace({'a': 1, 'b': 2, 'c': 3})
    
    # Mapping
    items = Exploding('mapping').items(sys._getframe(0))
    assert items == (
        ('mapping', '<Mapping>'),
        ("mapping[b']", '2'),
        ("mapping[a']", '1'),
        ("mapping[c']", '3'),
    )
    
    # Sequence

# Generated at 2022-06-22 18:26:54.740829
# Unit test for constructor of class Indices
def test_Indices():
    x = Indices('x')
    assert x._slice == slice(None)

    x = Indices('x')[3:6]
    assert x._slice == slice(3, 6)

# Generated at 2022-06-22 18:27:03.585719
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # We want to be able to import BaseVariable
    from .base import BaseVariable
    # We want to be able to simulate a frame
    # (from which we get the local and global dictionaries)
    from inspect import currentframe
    # We want to be able to get the value of an expression
    # in the context of the local and global dictionaries
    from pprint import pformat
    # We want to be able to compare the result of items
    # with a reference result
    from nose.tools import assert_equal

    # We define a subclass of BaseVariable
    class MyBaseVariable(BaseVariable):
        """This is a dummy class"""
        def _items(self, key, normalize=False):
            """This is a stub method to be overriden"""
            raise NotImplementedError

    # We get the current frame
    frame = current

# Generated at 2022-06-22 18:27:06.801146
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "sr"
    exclude = ()
    BaseVariable(source, exclude).items()


# Generated at 2022-06-22 18:27:10.303019
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('v1')._keys(['a', 'b', 'c']) == [0, 1, 2]
    assert Indices('v1')[0:2]._keys(['a', 'b', 'c']) == [0, 1]


# Generated at 2022-06-22 18:27:21.220563
# Unit test for constructor of class Attrs
def test_Attrs():
    test = Attrs('test')
    assert test.source == 'test' and test.exclude == ()
    test2 = Attrs('test2', exclude=['a', 'b'])
    assert test2.source == 'test2' and test2.exclude == ('a', 'b')
    class TestA(object):
        a = 1
        b = 2
        c = 3
        def __init__(self):
            self.d = 4
    test3 = Attrs('test3')
    assert test3.items(1) == [(u'test3', u'1')]

# Generated at 2022-06-22 18:27:23.160038
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('a')
    assert var.source == 'a'
    assert var.exclude == ()
    assert var._fingerprint == (Exploding, 'a', ())


# Generated at 2022-06-22 18:27:28.473479
# Unit test for function needs_parentheses
def test_needs_parentheses():
    global x, y

    x = 42
    y = 43
    assert not needs_parentheses('x')
    assert needs_parentheses('y')
    assert needs_parentheses('x_')
    assert not needs_parentheses('x.x')
    assert needs_parentheses('y.x')
    assert not needs_parentheses('x[x]')
    assert needs_parentheses('y[x]')
    assert not needs_parentheses('x.x().x')
    assert needs_parentheses('y.x().x')

# Generated at 2022-06-22 18:27:31.404102
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('x').source == 'x'
    assert CommonVariable('x', 'y').exclude == ('y',)

test_CommonVariable()


# Generated at 2022-06-22 18:27:36.162201
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = "varname"
    exclude = ["list", "of", "excluded", "keys"]
    code = compile(source, '<variable>', 'eval')
    a=CommonVariable(source, exclude)
    if a.source == source and a.exclude == exclude and a.code == code:
        print("Passed CommonVariable constructor test")
    else:
        print("Failed CommonVariable constructor test")


# Generated at 2022-06-22 18:27:41.701681
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('name', ['very-long-name'])
    assert bv.code is not None
    assert bv.unambiguous_source == 'name'

    bv = BaseVariable('very-long-name', ['very-long-name'])
    assert bv.code is not None
    assert bv.unambiguous_source == '(very-long-name)'



# Generated at 2022-06-22 18:27:49.084424
# Unit test for constructor of class Keys
def test_Keys():
    dict1 = dict()
    dict1['dict1_key'] = 'dict1_value'
    dict1['dict2_key'] = 'dict2_value'
    key = Keys('dict1', exclude='dict2_key')
    assert key.code == compile('dict1', '<variable>', 'eval')
    assert key.items(dict1) == [('dict1', 'dict1_value'), ('dict1[dict1_key]', "'dict1_value'")]


# Generated at 2022-06-22 18:27:55.922869
# Unit test for constructor of class Attrs
def test_Attrs():
    '''Test for Attrs'''
    class Foo(object):
        def __init__(self, x, y=None):
            self.x = x
            self.y = y
        @property
        def z(self):
            return self.x + self.y
    foo = Foo(1, y=2)
    foo_attrs = Attrs('foo')
    assert foo_attrs.items() == [('foo', '<Foo object at ...>'),
                                 ('foo.x', '1'),
                                 ('foo.z', '3'),
                                 ('foo.y', '2')]

# Generated at 2022-06-22 18:28:01.009624
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('abc', ('def',)) == Attrs('abc', ('def',))
    assert Attrs('abc', ('def',)) != Attrs('abcd', ('def',))
    assert Attrs('abc', ('def',)) != Attrs('abc', ('def1',))
    assert Keys('abc', ('def',)) == Keys('abc', ('def',))


# Generated at 2022-06-22 18:28:03.585864
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest

    indices = Indices('source')
    assert indices == indices[:]
    assert indices != indices[1:3]

    with pytest.raises(AssertionError):
        indices[1, 2]

# Generated at 2022-06-22 18:28:05.756635
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    instance = Indices('foo')
    assert isinstance(instance[0:1], Indices)
    assert instance[0:1]._slice == slice(0, 1)
    return True

# Generated at 2022-06-22 18:28:13.965915
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Test the original method
    base_variable_1 = BaseVariable(source=123, exclude=(1, 2, 3))
    base_variable_2 = BaseVariable(source=123, exclude=(1, 2, 3))
    assert hash(base_variable_1) == hash(base_variable_2)
    base_variable_3 = BaseVariable(source=123, exclude=(1, 2, 3))
    base_variable_4 = BaseVariable(source=123, exclude=(4, 5, 6))
    assert hash(base_variable_3) != hash(base_variable_4)
    # Test the modified method
    base_variable_1 = BaseVariable(source=123, exclude=(1, 2, 3))
    base_variable_2 = BaseVariable(source=123, exclude=(1, 2, 3))
    assert base_variable_1

# Generated at 2022-06-22 18:28:17.025358
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # __hash__ is implemented, so instances of BaseVariable should be hashable
    val = BaseVariable("source")
    _ = hash(val)



# Generated at 2022-06-22 18:28:18.375695
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo')[2:4]._slice == slice(2, 4)

# Generated at 2022-06-22 18:28:20.665250
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a': 'b'}

    variable = Keys('d')
    assert variable._keys(d) == ['a']


# Generated at 2022-06-22 18:28:24.994291
# Unit test for constructor of class Exploding
def test_Exploding():
    assert expl('abc')[0] == 'abc'
    assert expl('abc')[0:2] == 'abc'[0:2]
    assert expl([1,2,3])[0] == [1,2,3][0]
    assert expl({'key':1})['key'] == {'key':1}['key']


# Generated at 2022-06-22 18:28:28.617416
# Unit test for function needs_parentheses
def test_needs_parentheses():
    """
    >>> test_needs_parentheses()
    """
    assert not needs_parentheses('x')
    assert needs_parentheses('x+y')
    assert needs_parentheses('lambda x: x+1')
    assert needs_parentheses('x.y')

# Generated at 2022-06-22 18:28:31.008863
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for name in dir(needs_parentheses):
        _, source = name.split('_', 1)
        result = getattr(needs_parentheses, name)
        assert needs_parentheses(source) == result, result

# Generated at 2022-06-22 18:28:32.740839
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.unambiguous_source == 'a'


# Generated at 2022-06-22 18:28:36.040749
# Unit test for constructor of class Exploding
def test_Exploding():
    x = {'a':'a', 'b':'b', 'c':'c'}
    e = Exploding('x', 'b')
    assert e.items(x) == [('x', '{...}'),
                         ('x[a]', 'a'),
                         ('x[c]', 'c')]

# Generated at 2022-06-22 18:28:42.044057
# Unit test for constructor of class Indices
def test_Indices():
    assert repr(Indices('a[0]', None)) == "Indices('a[0]', ())"
    assert repr(Indices('a[1]', None)) == "Indices('a[1]', ())"
    assert repr(Indices('a[2]', None)) == "Indices('a[2]', ())"
    assert repr(Indices('a[3]', None)) == "Indices('a[3]', ())"
    assert repr(Indices('a[4]', None)) == "Indices('a[4]', ())"
    assert repr(Indices('a[5]', None)) == "Indices('a[5]', ())"
    assert repr(Indices('a[6]', None)) == "Indices('a[6]', ())"

# Generated at 2022-06-22 18:28:54.204495
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def print_vars(frame):
        locals = {k: utils.get_shortish_repr(v) for k, v in frame.f_locals.items()}
        print(locals)
    def test():
        a = 1
        b = [2, 3]
        c = {'c1': 4, 'c2': 5}
        d = {6, 7, 8}
        e = (9, 10, 11)
        f = {'g': 12, 'h': 13}
        print_vars(frame)

    frame = test.__code__.co_varnames
    locals = {k: v for k, v in frame.__dict__.items() if isinstance(v, int)}
    print_vars(locals)


# Generated at 2022-06-22 18:29:02.346111
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import math

    # Get the frame object
    frame = sys._getframe(1)

    # Create an object variable
    obj_attrs_var = Attrs('obj_attrs')

    # Get the variable values of obj_attrs
    obj_attrs_items = obj_attrs_var.items(frame)
    assert obj_attrs_items == [('obj_attrs', '<AttrClass>'), ('obj_attrs.a', '1'), ('obj_attrs.b', '2')]

    # Create an dict variable
    dict_keys_var = Keys('dict_keys')

    # Get the variable values of dict_keys
    dict_keys_items = dict_keys_var.items(frame)

# Generated at 2022-06-22 18:29:05.372908
# Unit test for constructor of class Keys
def test_Keys():
    t = Keys('keys')
    assert t.source == 'keys'
    assert t.exclude == tuple()

    t = Keys('keys', 'k')
    assert t.source == 'keys'
    assert t.exclude == ('k',)


# Generated at 2022-06-22 18:29:12.277591
# Unit test for constructor of class Exploding
def test_Exploding():
    import pprint
    M = {'A':{'a':1,'b':2,'c':3}}
    L = [['a',1],['b',2],['c',3]]
    C = object()

    pprint.pprint(Exploding('M').items(locals()))
    pprint.pprint(Exploding('L').items(locals()))
    pprint.pprint(Exploding('C').items(locals()))

# Generated at 2022-06-22 18:29:15.930741
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import importers
    from .. import source
    from .. import frames

    variable = BaseVariable("1+1")
    assert variable.items(importers.import_frame('def foo():\n    return 1+1'))==[('1+1', '2')]

# Generated at 2022-06-22 18:29:25.768420
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') == BaseVariable('foo')
    assert BaseVariable('foo') == BaseVariable('foo', exclude=('bar',))
    assert BaseVariable('foo') != BaseVariable('bar')
    assert BaseVariable('foo') != BaseVariable('foo', exclude=('bar',))
    assert BaseVariable('foo') != BaseVariable('foo', exclude=('bar', 'baz'))
    assert BaseVariable('foo', exclude=('bar',)) != BaseVariable('bar', exclude=('bar',))
    assert BaseVariable('foo', exclude=('bar',)) != BaseVariable('foo', exclude=('baz',))
    assert BaseVariable('foo', exclude=('bar',)) != BaseVariable('foo', exclude=('bar', 'baz'))

# Generated at 2022-06-22 18:29:29.436173
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # This function tests the constructor of class BaseVariable.
    # input: source = 'x'
    # expected output: instance of class BaseVariable
    baseVariable = BaseVariable('x')
    assert isinstance(baseVariable, BaseVariable)



# Generated at 2022-06-22 18:29:38.236590
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    b = BaseVariable(source='k', exclude=('y','z'))
    #Calling self.code and self.unambiguous_source are valid
    k = b.code
    k = b.unambiguous_source
    #Calling self.source and self.exclude are valid
    print(b.source)
    print(b.exclude)
    #Other class variables are invalid.
    try:
        k = b.a
    except Exception as e:
        print('Exception: {}'.format(e))
    b.a = 5
    try:
        k = b.a
    except Exception as e:
        print('Exception: {}'.format(e))
    b=BaseVariable('x', exclude='k')
    k = b.exclude
    b=BaseVariable('x')
    k = b.exclude



# Generated at 2022-06-22 18:29:43.886509
# Unit test for constructor of class Keys
def test_Keys():
    from pycallgraph import Config
    from pycallgraph.output import GraphvizOutput
    from pycallgraph import PyCallGraph
    with PyCallGraph(output=GraphvizOutput()):
        source = utils.ensure_tuple('abc', 'def')
        config = Config()
        keys = Keys(source, exclude=())

# Generated at 2022-06-22 18:29:48.812846
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'name'
    exclude = ('b', 'c')
    variable = BaseVariable(source, exclude)

    assert variable.source == source
    assert variable.exclude == exclude
    assert variable.code == compile(source, '<variable>', 'eval')
    assert variable.unambiguous_source == 'name'


# Generated at 2022-06-22 18:29:56.356263
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from six import BytesIO
    # Test simple equality
    assert Attrs('six.BytesIO.buf').__eq__(Attrs('six.BytesIO.buf'))

    # Test equality in case of children
    assert Attrs('six.BytesIO.buf').__eq__(Attrs('six.BytesIO.buf', exclude='closed'))
    assert not Attrs('six.BytesIO.buf').__eq__(Attrs('six.BytesIO.buf', exclude='name'))

    # Test equality not in case of children
    assert not Attrs('six.BytesIO.buf').__eq__(Attrs('six.StringIO.buf'))


# Generated at 2022-06-22 18:30:04.115852
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('abc') == BaseVariable('abc')
    assert BaseVariable('abc') != BaseVariable('abcd')
    assert BaseVariable('abc') != BaseVariable('abc', exclude=('a',))
    assert BaseVariable('abc', exclude=('a',)) == BaseVariable('abc', exclude=('a',))
    assert BaseVariable('abc', exclude=('a',)) != BaseVariable('abc', exclude=('b',))
    assert BaseVariable('abc', exclude=('a',)) != BaseVariable('abcd', exclude=('a',))



# Generated at 2022-06-22 18:30:12.634105
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('a1', exclude=('exclude_attr_a1'))
    a2 = BaseVariable('a2', exclude=('exclude_attr_a2'))
    b = BaseVariable('b', exclude=('exclude_attr_b'))
    assert a1 == a1
    assert a2 == a2
    assert b == b
    assert not (a1 == a2)
    assert not (a2 == b)
    assert not (b == a1)
    assert not (a1 != a1)
    assert not (a2 != a2)
    assert not (b != b)
    assert a1 != a2
    assert a2 != b
    assert b != a1

# Generated at 2022-06-22 18:30:22.734265
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    # Test 1: Constructor of class BaseVariable works correctly
    try:
        test_case = BaseVariable("Test", exclude=("1", "2"))
    except Exception:
        test_case = None
    assert test_case is not None

    # Test 2: Source must be valid
    try:
        test_case = BaseVariable("Test", exclude=("1", "2"))
    except Exception:
        test_case = None
    assert test_case is not None

    # Test 3: exclude must be valid
    try:
        test_case = BaseVariable("Test", exclude=("1", "2"))
    except Exception:
        test_case = None
    assert test_case is not None

    # Test 4: source changes

# Generated at 2022-06-22 18:30:33.829084
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    import os
    from .backend import Line
    from .utils import get_shortish_repr

    filename = os.path.abspath('test/test_BaseVariable_items.py')
    lines = []
    for num, line in enumerate(open(filename), 1):
        lines.append(Line(filename, num, line))

    # unit test for method items of class CommonVariable
    class CommonVariable_items(CommonVariable):
        def _keys(self, main_value):
            return range(len(main_value))[self._slice]

        def _format_key(self, key):
            return '[{}]'.format(key)

        def _get_value(self, main_value, key):
            return '{}{}'.format(main_value[key], main_value[key])

# Generated at 2022-06-22 18:30:44.343851
# Unit test for constructor of class Exploding
def test_Exploding():
    import StringIO # StringIO.StringIO does not exist in Python 3
    import sys
    dump = sys.stdout
    sys.stdout = StringIO.StringIO()
    # define a class with all types of attributes
    class Obj():
        pass

    # create an object
    obj = Obj()
    obj.a = 3
    obj.b = 4
    # create a dictionary
    d = {'a': 1, 'b': 2}
    # create a tuple
    t = (1, 2)

    # create an exploding attribute and the test data
    exp_attr = Exploding("obj")

# Generated at 2022-06-22 18:30:49.191594
# Unit test for constructor of class Indices
def test_Indices():
    i1 = Indices("a")
    i2 = Indices("a")[1:]
    assert i1 != i2
    assert i1 == Indices("a")
    assert i2 == Indices("a")[1:]

# Generated at 2022-06-22 18:31:00.286464
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect

    class DefiningFrame(object):
        def __init__(self, source, **local):
            self.f_globals = sys._getframe(1).f_globals
            self.f_locals = local

        def __eq__(self, other):
            return (self.f_globals is other.f_globals and
                    self.f_locals == other.f_locals)

    def test_case(var, frame, expected):
        result = list(var.items(frame))
        assert result == expected, "{} != {}".format(result, expected)


# Generated at 2022-06-22 18:31:03.188406
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs("x")
    assert(x.source == "x")
    assert(x.exclude == ())



# Generated at 2022-06-22 18:31:08.586793
# Unit test for constructor of class Indices
def test_Indices():
    from mock import Mock

    f_locals = {'a': [1, 2]}
    frame = Mock(f_locals=f_locals)
    variable = Indices('a')
    assert variable.items(frame) == [('a[0]', '1'), ('a[1]', '2')]

# Generated at 2022-06-22 18:31:11.636587
# Unit test for constructor of class Indices
def test_Indices():
    ind_1 = Indices("a")
    ind_2 = Indices("a")
    assert hash(ind_1._fingerprint) == hash(ind_2._fingerprint)
    assert ind_1 == ind_2

# Generated at 2022-06-22 18:31:15.709476
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a == Indices('a')
    a = a[:2]
    assert a != Indices('a')
    assert a._slice == slice(0, 2)

# Generated at 2022-06-22 18:31:26.815141
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    # Tests for class Attrs
    a = Attrs('a')
    assert tuple(a.items(inspect.currentframe())) == (('a', 'Attrs(...)'),)
    # Tests for class Keys
    d = {'a': 1, 'b': 2}
    k = Keys('d')
    assert tuple(k.items(inspect.currentframe())) == (('d', "{'a': 1, 'b': 2}"), ('d[a]','1'), ('d[b]','2'))
    # Tests for class Indices
    l = [3,4]
    i = Indices('l')
    assert tuple(i.items(inspect.currentframe())) == (('l', '[3, 4]'), ('l[0]','3'), ('l[1]','4'))


# Generated at 2022-06-22 18:31:36.384841
# Unit test for constructor of class Indices
def test_Indices():
    if __name__=="test_Indices":
        i=Indices('li')
        result=i._items([1,3,4])
        assert result==[('li', '[1,3,4]'), ('li[0]', '1'), ('li[1]', '3'), ('li[2]', '4')]
        result=i[1:4]._items([1,2,3,4])
        assert result==[('li', '[1,2,3,4]'), ('li[1]', '2'),('li[2]', '3'),('li[3]', '4')]

# To split the value of parameter 'exclude', which is a string, into a tuple
# A simple way to use this method is to split the value of parameter 'exclude' by itself

# Generated at 2022-06-22 18:31:39.384203
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices("main_value")[:5]
    items = ind.items("main_value")
    assert items[0][1] == 'main_value'
    assert len(items) <= 6



# Generated at 2022-06-22 18:31:50.663536
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from nose.tools import assert_equal, assert_false
    from copy import copy, deepcopy
    from .ensure_unicode import ensure_unicode
    from .utils import capture_locals

    # Test for BaseVariable class
    a = BaseVariable("def", [])
    b = BaseVariable("def", [])
    assert_equal(a.__hash__(), b.__hash__())

    c = BaseVariable("a", [])
    d = BaseVariable("b", [])
    assert_false(c.__hash__() == d.__hash__())
    
    def f():
        a = b = "hi"
        capture_locals(locals())
    
    def g():
        x = y = "hello"
        capture_locals(locals())
    

# Generated at 2022-06-22 18:31:54.970925
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Defining two variables
    var1 = BaseVariable("x")
    var2 = BaseVariable("y")

    # Checks item method
    assert(var1.items(x=1) == [("x", "1")])
    assert(var2.items(y=1) == [("y", "1")])

    # Check set of classes that are instances of abc.ABC
    assert(issubclass(BaseVariable, abc.ABC))


# Generated at 2022-06-22 18:31:57.239083
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    str = Indices('str')
    assert str[2:4]._slice == slice(2, 4)

# Generated at 2022-06-22 18:32:01.621013
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('test')
    assert var.source == 'test'
    assert var.exclude == ()
    assert var.code.co_code == b'x\x00d\x01\x00d\x00\x17'
    assert var.unambiguous_source == 'test'
    assert var.items(1) == ()


# Generated at 2022-06-22 18:32:07.289194
# Unit test for constructor of class Attrs
def test_Attrs():
    source="a"
    attrs=Attrs(source)

    assert attrs.source == source
    assert attrs.exclude == ()
    assert attrs.code == compile(source, '<variable>', 'eval')
    assert attrs.unambiguous_source == 'a'


# Generated at 2022-06-22 18:32:12.110084
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    variable1 = BaseVariable('source', exclude=('exclude'))
    variable2 = BaseVariable('source', exclude=('exclude'))
    variable3 = BaseVariable('source', exclude=())
    x = BaseVariable('source', exclude=()).__hash__()
    y = BaseVariable('source', exclude=('exclude')). __hash__()
    assert x == y
    assert hash(variable1) == hash(variable2)
    assert hash(variable3) != hash(variable1)


# Generated at 2022-06-22 18:32:18.563454
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('i')
    assert var.source == 'i'
    assert var.exclude == ()

    var = Exploding('i', exclude='x')
    assert var.source == 'i'
    assert var.exclude == ('x',)

    var = Exploding('i', exclude=['x'])
    assert var.source == 'i'
    assert var.exclude == ('x',)

# Generated at 2022-06-22 18:32:23.514507
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(999) == BaseVariable(999)
    assert not BaseVariable(999) == BaseVariable(888)
    assert not BaseVariable(999) == BaseVariable(999, exclude=999)

# Generated at 2022-06-22 18:32:27.661922
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():

    class MyVariable(BaseVariable):
        def __init__(self, source):
            super(MyVariable, self).__init__(source)

        def _items(self, main_value, normalize=False):
            return []

    assert hash(MyVariable('abc')) == hash(MyVariable('abc'))
    assert hash(MyVariable('abc')) != hash(MyVariable('xyz'))


# Generated at 2022-06-22 18:32:31.244155
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('abc')
    attrs = vars(k)
    assert 'source' in attrs
    assert 'exclude' in attrs
    assert 'code' in attrs

# Test for method _items of class Keys

# Generated at 2022-06-22 18:32:42.921246
# Unit test for constructor of class Keys
def test_Keys():
    # Test Keys()
    var = Keys("name")
    assert isinstance(var, BaseVariable)
    assert isinstance(var, Keys)
    assert var.source == "name"
    assert var.exclude == ()

    # Test Keys("name")
    var = Keys("name")
    assert isinstance(var, BaseVariable)
    assert isinstance(var, Keys)
    assert var.source == "name"
    assert var.exclude == ()

    # Test Keys("name", "fname")
    var = Keys("name", "fname")
    assert isinstance(var, BaseVariable)
    assert isinstance(var, Keys)
    assert var.source == "name"
    assert var.exclude == ("fname",)

    # Test Keys("name", ["fname", "lname"])
    var = Keys

# Generated at 2022-06-22 18:32:48.042111
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys()

    d = {"hi": "hi1", "hello": "hello1"}
    print(d)
    key = k._keys(d)
    print(key)
    for k in key:
        print(k)
    # formated_key = k._format_key(key)
    # print(formated_key)
    # key_value = k._get_value(d, key)
    # print(key_value)
    print()


# Generated at 2022-06-22 18:32:50.118897
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v1 = Indices('a')
    v2 = v1[2:5]
    assert(v2._fingerprint == (Indices, 'a', ()))
    assert(v2._slice == slice(2,5))
    assert(isinstance(v2, Indices))

# Generated at 2022-06-22 18:32:59.373372
# Unit test for constructor of class Keys
def test_Keys():
    # variable = Keys(source, exclude)
    variable = Keys('test_case', ('first_element', ('second_element', 'third_element')))
    variable_test = variable

    # test source variable
    source_result = variable.source
    assert source_result == 'test_case', 'source should be test_case'

    # test exclude variable
    exclude_result = variable.exclude
    assert exclude_result == ('first_element', ('second_element', 'third_element')), 'exclude should be <variable>'
    
    # test code variable
    code_result = variable.code
    assert code_result == compile('test_case', '<variable>', 'eval'), "code should return compile('test_case', '<variable>', 'eval')"

    # test unambiguous_source variable
    unambiguous_source_

# Generated at 2022-06-22 18:33:10.918509
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {'a':1,'b':2,'c':'3'}
    keys = Exploding('main_value')
    assert isinstance(keys, Keys)
    assert keys._items(main_value)[0] == ('main_value', "{'a': 1, 'b': 2, 'c': '3'}")
    assert keys._items(main_value)[1] == ('main_value[a]', '1')

    main_value = [1,2,3]
    indices = Exploding('main_value')
    assert isinstance(indices, Indices)
    assert indices._items(main_value)[0] == ('main_value', '[1, 2, 3]')
    assert indices._items(main_value)[1] == ('main_value[0]', '1')


# Generated at 2022-06-22 18:33:15.025068
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('abc')
    v2 = BaseVariable('abc')
    v3 = BaseVariable('abd')
    assert v1.__hash__() == v2.__hash__()
    assert v1.__hash__() != v3.__hash__()



# Generated at 2022-06-22 18:33:19.257219
# Unit test for constructor of class Attrs
def test_Attrs():
    class foo:
        def __init__(self):
            self.a = 1
            self.b = 2

    test = foo()
    test2 = Attrs('test', ('b',))
    assert test2.exclude == ('b',)
    assert test2.source == 'test'
    assert test2.unambiguous_source == 'test'


# Generated at 2022-06-22 18:33:30.602006
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .kivy_utils import Logger
    import inspect
    import time
    import numpy as np

    current_frame = inspect.currentframe()
    outer_frames = inspect.getouterframes(current_frame)

    class O:
        pass

    def f():
        pass

    e_dict = {"a": np.array([1,2,3]),
              "b": ["a", "b", "c"],
              "c": ('a', 'b', 'c')}

    e_list = [0,1,2,3,4,5]

    e_time = time.time()

    e_tuple = ("tuple", "tuple", "tuple")

    e_nparray = np.array([1, 2, 3, 4, 5, 6])

    e_str = "str"



# Generated at 2022-06-22 18:33:36.576859
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')[:10:2]
    assert a.source == 'a'
    assert a.unambiguous_source == 'a'
    assert a.exclude == ()
    assert a.code == compile('a', '<variable>', 'eval')
    assert a._slice == slice(0, 10, 2)

# Generated at 2022-06-22 18:33:46.906239
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    from contextlib import contextmanager
    from unittest import TestCase, skip
    from unittest.mock import MagicMock
    
    @contextmanager
    def capture_exception():
        try:
            yield None
        except Exception as exc:
            raise exc

    def assertRaises(exception_class, func, *args, **kwargs):
        with capture_exception() as got_exc:
            func(*args, **kwargs)
        if got_exc is None:
            raise AssertionError("{func}() did not raise {exc}".format(func=func, exc=exception_class))

# Generated at 2022-06-22 18:33:50.702878
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from . import utils
    v = BaseVariable('key')
    v._fingerprint = ('class', 'key', 'none')
    assert utils.hash_of(v) == '6f3a6e9d'

# Generated at 2022-06-22 18:33:52.422904
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('a').source # Test if BaseVariable raises an exception.


# Generated at 2022-06-22 18:33:55.713570
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    my_index = Indices('a')
    my_index_sliced = my_index[2:6]
    assert my_index_sliced._slice == slice(2, 6)

# Generated at 2022-06-22 18:33:57.809757
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    variable = BaseVariable('a','b')
    assert hash(variable) == hash(variable)


# Generated at 2022-06-22 18:34:04.026013
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import re

    def t(source, exclude=()):
        variable = CommonVariable(source, exclude)
        assert variable.source == source
        assert variable.exclude == utils.ensure_tuple(exclude)
        assert variable.unambiguous_source == source
        assert re.search(r'<.*?CommonVariable object at', str(variable))

    t('a')
    t('__import__("os").system("rm -rf /")')



# Generated at 2022-06-22 18:34:09.061278
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('abc')
    assert e.source == 'abc'
    assert e.exclude == ()
    assert e._fingerprint == (Exploding, 'abc', ())

    e = Exploding('abc', 'def')
    assert e.source == 'abc'
    assert e.exclude == ('def',)
    assert e._fingerprint == (Exploding, 'abc', ('def',))



# Generated at 2022-06-22 18:34:18.086605
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices("test.test")
    assert 'test.test[0]' == i._format_key(0)
    assert 'test.test[1]' == i._format_key(1)
    assert 'test.test[2]' == i._format_key(2)

    i = Indices("test.test")[2:]
    assert 'test.test[2]' == i._format_key(0)
    assert 'test.test[3]' == i._format_key(1)
    assert 'test.test[4]' == i._format_key(2)

# Generated at 2022-06-22 18:34:19.706648
# Unit test for constructor of class Indices
def test_Indices():
    assert str(Indices("a")) == "a[0] = ..."


# Generated at 2022-06-22 18:34:23.806426
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable(source='aa', exclude=())
    b = BaseVariable(source='aa', exclude=())
    c = BaseVariable(source='bb', exclude=())
    d = BaseVariable(source='aa', exclude=(1,))
    e = CommonVariable(source='aa', exclude=())

    assert a == b
    assert a != c
    assert a != d
    assert a != e


# Generated at 2022-06-22 18:34:32.705224
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def test_keys(source):
        """Generate the keys of a variable.

        Args:
            source (str): The source of variable.

        Returns:
            An iterable that generate the keys of variable.
        """
        variable = CommonVariable(source)
        main_value = eval(variable.code, {source: {'a': 1, 'b': [1, 2, 3]}})
        return variable._safe_keys(main_value)

    assert set(test_keys('v')) == set(['a', 'b'])



# Generated at 2022-06-22 18:34:37.032006
# Unit test for constructor of class Indices
def test_Indices():
    try:
        x = Indices('[1,2,3,4,5]')
        x = Indices('[1,2,3,4,5]', exclude=('[0]'))
    except TypeError:
        print('Constructor of Indices is incorrect!')

    assert True



# Generated at 2022-06-22 18:34:47.690954
# Unit test for constructor of class Attrs
def test_Attrs():
    source1 = 'a.b.c'
    source2 = 'a.b.c + 1'
    source3 = 'a.b.c()'
    exclusion = 'd'
    v1 = Attrs(source1)
    v2 = Attrs(source2)
    v3 = Attrs(source3)
    print(isinstance(v1, Attrs))
    print(isinstance(v2, Attrs))
    print(isinstance(v3, Attrs))
    print('v1.source = ', v1.source)
    print('v2.source = ', v2.source)
    print('v3.source = ', v3.source)
    print('v1.exclude = ', v1.exclude)
    print('v2.exclude = ', v2.exclude)
    print

# Generated at 2022-06-22 18:34:57.524807
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a()')
    assert not needs_parentheses('a()[b]')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('a().b')
    assert not needs_parentheses('a.b().c')
    assert not needs_parentheses('a[b].c')
    assert not needs_parentheses('a[b].c[d]')
    assert not needs_parentheses('a().b[c]')
    assert needs_parentheses('a[b]')
    assert needs_parentheses('a.b()')
    assert needs_parentheses('a[b]().c')

# Unit tests for class CommonVariable

# Generated at 2022-06-22 18:35:03.569166
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('a')
    a2 = BaseVariable('a', exclude='b')
    a3 = BaseVariable('a', exclude='b')
    a4 = BaseVariable('b', exclude='b')
    a5 = BaseVariable('b', exclude='a')
    a6 = BaseVariable('a')

    print(a1 == a2)
    print(a2 == a3)
    print(a3 == a4)
    print(a4 == a5)
    print(a5 == a6)

# Generated at 2022-06-22 18:35:11.157140
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class SubClassOfBaseVariable(BaseVariable):
        pass
    variable = BaseVariable(source='x')
    variable_output = variable.items(frame={'x':1})
    variable_expected = [('x', 1)]
    assert variable_output == variable_expected
    variable = SubClassOfBaseVariable(source='x')
    variable_output = variable.items(frame={'x':1})
    variable_expected = [('x', 1)]
    assert variable_output == variable_expected


# Generated at 2022-06-22 18:35:22.038074
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pprint
    import inspect
    import types
    import dis
    import test
    import os


# Generated at 2022-06-22 18:35:29.917407
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # It should check if two variables with the same source have the same code
    variable1 = Attrs('locals()')
    variable2 = Attrs('locals()')
    assert variable1.code == variable2.code
    assert variable1 == variable2

    variable1 = Keys('locals()')
    variable2 = Keys('locals()')
    assert variable1.code == variable2.code
    assert variable1 == variable2

    variable1 = Indices('locals()')
    variable2 = Indices('locals()')
    assert variable1.code == variable2.code
    assert variable1 == variable2

    variable1 = Exploding('locals()')
    variable2 = Exploding('locals()')
    assert variable1.code == variable2.code
    assert variable1 == variable2


# Generated at 2022-06-22 18:35:32.339536
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'abc'
    exclude = ('a', 'b', 'c')
    instance = BaseVariable(source, exclude)
    assert isinstance(instance, BaseVariable)
    assert instance.__hash__() == hash((type(instance), source, exclude))

# Generated at 2022-06-22 18:35:37.256355
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    test_data = [
        ('self', ('x', 'y'), 'self.x', ('x', 'y'), True),
        ('self', ('x', 'y'), 'self.x', ('z', 'y'), False),
        ('self', ('x', 'y'), 'self.x', [], True),
        ('self', ('x', 'y'), 'self.x', [1], False),
    ]

    for source1, exclude1, source2, exclude2, expected_result in test_data:
        variable1 = BaseVariable(source1, exclude1)
        variable2 = BaseVariable(source2, exclude2)
        assert variable1 == variable2 == expected_result

# Generated at 2022-06-22 18:35:44.745997
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('xyz')
    assert needs_parentheses('x.y(z)')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x.y)')
    assert needs_parentheses('(x).y(z)')
    assert not needs_parentheses('(x.y(z))')
    assert needs_parentheses('(x.y).z')

# Generated at 2022-06-22 18:35:50.766370
# Unit test for constructor of class Exploding
def test_Exploding():
    methods = {'class': None}
    assert isinstance(Exploding('methods').items({'methods': methods})[0][0], Keys)
    assert isinstance(Exploding('methods').items(methods)[0][0], Attrs)