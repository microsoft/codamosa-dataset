

# Generated at 2022-06-22 18:26:00.871209
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    #'''
    class CommonVariable:
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            try:
                main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
            except Exception:
                return ()
            return self._items(main_value, normalize)


# Generated at 2022-06-22 18:26:09.377991
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('"a"')
    assert needs_parentheses('."b"')
    assert needs_parentheses('(1).c')
    assert needs_parentheses('-d')
    assert not needs_parentheses('e.f')
    assert needs_parentheses('-g + h.j')
    assert needs_parentheses('k**2.3')
    assert not needs_parentheses('l.m[n]')
    assert not needs_parentheses('l.m[n].o')
    assert not needs_parentheses('l.m[n][o]')
    assert needs_parentheses('(l.m[n])[o]')
    assert not needs_parentheses('l[m].n')
    assert not needs_parentheses('l[m][n]')
    assert not needs_parentheses

# Generated at 2022-06-22 18:26:14.047167
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    v._slice == slice(None)
    v1 = v[2:5]; assert v1._slice == slice(2, 5)
    v2 = v1[::3]; assert v2._slice == slice(2, 5, 3)
    v3 = v2[::2]; assert v3._slice == slice(2, 5, 6)

# Generated at 2022-06-22 18:26:16.573332
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding("a") == Exploding("a")
    assert not Exploding("a") == Exploding("b")
    assert not Exploding("a") == None

# Generated at 2022-06-22 18:26:22.373310
# Unit test for constructor of class Exploding
def test_Exploding():
    x={"a":1,"b":2,"c":3}
    y=Exploding("x")
    assert y._items(x)==\
           [('x.a', '1'),
            ('x.b', '2'),
            ('x.c', '3')]

    z={"a":1,"b":2,"c":3}
    w=Exploding("x")
    assert w._items(z)==\
           [('x.a', '1'),
            ('x.b', '2'),
            ('x.c', '3')]

    p=[1,2,3,4]
    q=Exploding("x")

# Generated at 2022-06-22 18:26:26.608911
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('v')
    v1 = v[1:]
    assert isinstance(v1, Indices)
    assert v1._slice == slice(1, None)
    v2 = v[:10]
    assert isinstance(v2, Indices)
    assert v2._slice == slice(0, 10)
    v3 = v[1:10]
    assert isinstance(v3, Indices)
    assert v3._slice == slice(1, 10)

# Generated at 2022-06-22 18:26:29.923821
# Unit test for constructor of class Indices
def test_Indices():
    idx = Indices('a', exclude=('b',))
    assert idx.__getitem__(slice(2,4)) is not idx
    assert idx.__getitem__(slice(2,4))._slice == slice(2,4)

# Generated at 2022-06-22 18:26:34.429367
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert not BaseVariable('aaaa').__eq__(None)
    BaseVariable('aaaa') == BaseVariable('aaaa')
    assert not BaseVariable('aaaa') != BaseVariable('aaaa')
    BaseVariable('bbbb') == BaseVariable('aaaa')
    assert not BaseVariable('bbbb') != BaseVariable('aaaa')
    BaseVariable('aaaa', 'a') == BaseVariable('aaaa', 'a')
    assert not BaseVariable('aaaa', 'a') != BaseVariable('aaaa', 'a')
    BaseVariable('bbbb', 'b') == BaseVariable('aaaa', 'a')
    assert not BaseVariable('bbbb', 'b') != BaseVariable('aaaa', 'a')
    BaseVariable('aaaa', 'a') == BaseVariable('aaaa', 'a')
    assert not BaseVariable('aaaa', 'a') != BaseVariable('aaaa', 'a')

# Unit test

# Generated at 2022-06-22 18:26:39.228071
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('xxx', ('yyy', 'zzz'))
    assert var.source == 'xxx'
    assert var.exclude == ('yyy', 'zzz')
    assert var.code == compile('xxx', '<variable>', 'eval')

# Generated at 2022-06-22 18:26:40.505057
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs("main_value.data","data")

# Generated at 2022-06-22 18:26:49.686303
# Unit test for function needs_parentheses
def test_needs_parentheses():
    v = BaseVariable(source="something")
    assert needs_parentheses(v.source) == False
    assert needs_parentheses(v.unambiguous_source) == False
    # test with whitespaces
    v.source = "something "
    assert needs_parentheses(v.source) == True
    assert needs_parentheses(v.unambiguous_source) == False
    # test with newline
    v.source = "something\n"
    assert needs_parentheses(v.source) == True
    assert needs_parentheses(v.unambiguous_source) == False
    # test with keyword arguments
    v.source = "something(x=x)"
    assert needs_parentheses(v.source) == True
    assert needs_parentheses(v.unambiguous_source) == True
    # test with attributes


# Generated at 2022-06-22 18:26:52.765937
# Unit test for constructor of class Attrs
def test_Attrs():
    dict = {'b': [1,2,3], 'c': {'a': None}}
    attr = Attrs('a', '__dict__')
    assert attr.code.co_names[0] == 'a'
    assert attr.source == 'a'
    assert attr.exclude == ('__dict__',)
    assert attr.unambiguous_source == 'a'


# Generated at 2022-06-22 18:27:00.583359
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert needs_parentheses('self')
    assert needs_parentheses('self.x')
    assert needs_parentheses('foo.bar.baz.qux')

    assert not needs_parentheses('(foo)')
    assert not needs_parentheses('(self)')
    assert not needs_parentheses('(self.x)')
    assert not needs_parentheses('(foo.bar).baz.qux')
    assert not needs_parentheses('foo.bar.baz.qux')

# Generated at 2022-06-22 18:27:12.100888
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = ['a', 'b']
    source_tuple = ('t', 's')
    source_dict = {'a':'v', 'b':'h'}
    source_dict_normalize = {'a':'v', 'b':{'c':'w'}, 'e':['2','3','4']}
    
    # test for class Attrs
    av = Attrs('source')
    result = av.items(source)
    assert result == [('source', source)]
    result = av.items(source_tuple)
    assert result == [('source', source_tuple)]
    result = av.items(source_dict)
    assert result == [('source', source_dict)]
    
    # test for class Attrs with keyword normalize

# Generated at 2022-06-22 18:27:17.601467
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a.b.c') == False
    assert needs_parentheses('a()') == False
    assert needs_parentheses('a.b()') == False
    assert needs_parentheses('a().b') == True
    assert needs_parentheses('a().b.c') == True
    assert needs_parentheses('(a.b.c)') == False
    assert needs_parentheses('a(1)') == False
    assert needs_parentheses('a(1,2)') == False
    assert needs_parentheses('a(1,2).b') == False
    assert needs_parentheses('a.b(1)') == False

# Generated at 2022-06-22 18:27:20.448221
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    b1 = BaseVariable('a')
    b2 = BaseVariable('a')
    assert b1.__hash__() == b2.__hash__()



# Generated at 2022-06-22 18:27:28.798516
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a')
    b = Indices('a', exclude = 'b')
    c = Indices('a', exclude = ('b','c'))
    assert a._fingerprint == b._fingerprint
    assert a._slice == slice(None)
    assert b._slice == slice(None)
    assert c._slice == slice(None)
    assert a.source == 'a'
    assert b.source == 'a'
    assert c.source == 'a'
    assert a.exclude == ('__builtins__', )
    assert b.exclude == ('__builtins__', 'b')
    assert c.exclude == ('__builtins__', 'b', 'c')
    assert a.unambiguous_source == 'a'

    a = Indices('a', exclude = 'b')[1:5]

# Generated at 2022-06-22 18:27:29.869439
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    pass

# Generated at 2022-06-22 18:27:31.958400
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert BaseVariable("a").__hash__() == BaseVariable("a").__hash__()


# Generated at 2022-06-22 18:27:34.304716
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[::2]._slice == slice(None, None, 2)

# Generated at 2022-06-22 18:27:45.110071
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # __hash__方法必须返回整数，否则会抛出TypeError异常，以下代码测试抛出TypeError异常
    hash((type(BaseVariable), 'self.source', 'self.exclude'))
    # __hash__方法必须是可逆的，即a==b计算结果为True，则hash(a)==hash(b)应该计算结果为True，以下代码测试抛出AssertionError异常

# Generated at 2022-06-22 18:27:53.534624
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # type: () -> None
    # Test 1
    source1 = 'foo'
    source2 = 'bar'
    source3 = 'foo'
    exclude1 = 'a'
    exclude2 = 'b'
    exclude3 = 'a'
    variable1 = BaseVariable(source1, exclude1)
    variable2 = BaseVariable(source1, exclude1)
    variable3 = BaseVariable(source2, exclude2)
    variable4 = BaseVariable(source3, exclude3)
    assert variable1 == variable2
    assert variable1 != variable3
    assert variable1 == variable4


# Generated at 2022-06-22 18:27:56.476283
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    debug_var = BaseVariable("__file__")
    assert(debug_var.source == "__file__")
    assert(debug_var.exclude == ())

if __name__ == '__main__':
    test_BaseVariable()

# Generated at 2022-06-22 18:28:00.224794
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    b1 = BaseVariable("abc")
    b2 = BaseVariable("abc")
    b3 = BaseVariable("def")
    assert hash(b1) == hash(b2)
    assert hash(b1) != hash(b3)


# Generated at 2022-06-22 18:28:09.320520
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = 10
    y = 11
    z = 12
    def f(): pass

    def _test(source, expected):
        assert tuple(BaseVariable(source).items(f.__globals__)) == expected

    _test(
        'f',
        (('f', 'function <function f at 0x7f5e5a5e2a60>'),)
    )

    _test(
        'x',
        (
            ('x', '10'),
        )
    )


# Generated at 2022-06-22 18:28:16.922303
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable(source='foo.bar', exclude='baz') ==
                       BaseVariable(source='foo.bar', exclude='baz'))
    assert (BaseVariable(source='foo.bar', exclude='baz') !=
                       BaseVariable(source='foo.bar', exclude='qux'))
    assert (BaseVariable(source='foo.bar') ==
                       BaseVariable(source='foo.bar'))
    assert (BaseVariable(source='foo.bar') !=
                       BaseVariable(source='foo.bar', exclude='baz'))

# Generated at 2022-06-22 18:28:26.450241
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('2 + 2')
    assert var.source == '2 + 2'
    assert var.exclude == ()
    assert var.unambiguous_source == '2 + 2'
    assert isinstance(var.code, compile)
    assert needs_parentheses('2 + 2') is False

    var = BaseVariable('(2 + 2)')
    assert var.source == '(2 + 2)'
    assert var.exclude == ()
    assert var.unambiguous_source == '(2 + 2)'
    assert isinstance(var.code, compile)
    assert needs_parentheses('(2 + 2)') is False

    var = BaseVariable('a')
    assert var.source == 'a'
    assert var.exclude == ()
    assert var.unambiguous_source == '(a)'

# Generated at 2022-06-22 18:28:34.315685
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys('a')
    assert(var._keys({"name": "Dima"}) == dict.keys({"name": "Dima"}))
    assert(var._format_key("name") == "[name]")
    assert(var._get_value({"name": "Dima"}, "name") == {"name": "Dima"}["name"])
    assert(var._items({"name": "Dima"}, False) == [('a[name]', "'Dima'")])
    assert(var._items({"name": "Dima"}) == [('a[name]', '"Dima"')])
    assert(var._items({"name": "Dima"}, True) == [('a[name]', '"Dima"')])


# Generated at 2022-06-22 18:28:40.068966
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """BaseVariable.items"""
    # Arrange
    import sys
    import os
    import numpy as np

    frame = sys._getframe()
    avar = BaseVariable('sys')

    # Act
    result = avar.items(frame, True)

    # Assert
    assert len(result) == 5
    assert ('sys.version', '\'3.5.2...\'') in result

    # Arrange
    bvar = BaseVariable('os')

    # Act
    result = bvar.items(frame, True)

    # Assert
    assert len(result) == 6
    assert ('os.environ', "environ({\'...\'})") in result

    # Arrange
    cvar = BaseVariable('np')

    # Act
    result = cvar.items(frame, True)

    #

# Generated at 2022-06-22 18:28:45.064885
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a.b').items('') == [('a.b', '<UNKNOWN>')]
    assert Keys('a.b', 'b').items('') == [('a.b', '<UNKNOWN>')]
    assert Keys('a.b', 'b').items('') == [('a.b', '<UNKNOWN>')]

# Generated at 2022-06-22 18:28:53.780978
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class TestVariable(CommonVariable):
        pass
    
    test = TestVariable('')
    assert test.source == ''
    assert test.exclude == ()
    assert test._fingerprint == (TestVariable, '', ())
    assert hash(test) == hash(test._fingerprint)

    test = TestVariable('', 'exclude')
    assert test.exclude == ('exclude',)

    test = TestVariable('', ('exclude1', 'exclude2'))
    assert test.exclude == ('exclude1', 'exclude2')



# Generated at 2022-06-22 18:28:58.543750
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import pytest
    from . import utils
    from . import pycompat

    assert utils.is_hashable(BaseVariable('a')) is False
    assert utils.is_hashable(BaseVariable('a', 'b')) is False
    assert utils.is_hashable(BaseVariable('a', 'b', 'c')) is False

    assert utils.is_hashable(BaseVariable('a', 'b', 'c', 'd')) is False


# Generated at 2022-06-22 18:29:08.006343
# Unit test for constructor of class Exploding
def test_Exploding():
    from copy import deepcopy
    from .vars import Keys, Indices, Attrs, Exploding
    class Foo(object):
        pass
    foo = Foo()
    foo.x = 1
    foo.y = 'foo'
    foo.z = Foo()
    for main_value in [
        {'a': 1, 'b': 'foo', 'c': Foo()},
        [0, 1, 'a', Foo()]
    ]:
        for normalize in [True, False]:
            for exclude in [['x'], (['x'])]:
                v = Exploding('main_value', exclude=exclude)
                items = v._items(main_value, normalize)
                assert all(
                    isinstance(item, tuple) and len(item) == 2
                    for item in items), items

# Generated at 2022-06-22 18:29:08.895292
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    ...


# Generated at 2022-06-22 18:29:11.786367
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    f = inspect.currentframe()
    v = BaseVariable('v')
    v._items(f)
    assert True


if __name__ == "__main__":
    test_BaseVariable_items()

# Generated at 2022-06-22 18:29:16.792959
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x')._keys([1, 2, 3]) == range(3)
    assert Indices('x')[::2]._keys([1, 2, 3]) == range(0, 3, 2)
    assert Indices('x')[1:]._keys([1, 2, 3]) == range(1, 3)

# Generated at 2022-06-22 18:29:23.598637
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import inspect
    import os

    def a():
        return os.getpid()

    def b():
        return inspect.currentframe()

    var_a = BaseVariable(a)
    var_b = BaseVariable(b)

    assert var_a.__eq__(var_a)
    assert var_b.__eq__(var_b)
    assert var_a.__eq__(var_b) == False
    assert var_b.__eq__(var_a) == False



# Generated at 2022-06-22 18:29:25.270021
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert isinstance(Indices('a')[1:3], Indices)

# Generated at 2022-06-22 18:29:28.082411
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable("some_name")
    assert hash(v) != 0
    assert hash(v) == hash(BaseVariable("some_name"))


# Generated at 2022-06-22 18:29:34.962508
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('a', exclude='b')
    assert c.source == 'a'
    assert c.exclude == ('b',)
    assert c.unambiguous_source == 'a'
    assert c._fingerprint == (CommonVariable, 'a', ('b',))
    assert c == CommonVariable('a', exclude='b')
    assert c == CommonVariable('a', exclude=('b',))
    assert c != CommonVariable('b', exclude='b')
    assert c != CommonVariable('a', exclude='c')
    assert not isinstance(c, BaseVariable)


# Generated at 2022-06-22 18:29:43.247039
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    vs = (Keys('x'), Keys('x'), Keys('y'), Attrs('x'), Attrs('x'), Attrs('y'),
          Keys('x', exclude=['a']), Keys('x', exclude=['a']), Keys('x', exclude=['b']),
          Attrs('x', exclude=['a']), Attrs('x', exclude=['a']), Attrs('x', exclude=['b']))

    v1 = Keys('x')
    v2 = Keys('x')
    v3 = Keys('y')
    v4 = Attrs('x')
    v5 = Attrs('x')
    v6 = Attrs('y')
    v7 = Keys('x', exclude=['a'])
    v8 = Keys('x', exclude=['a'])

# Generated at 2022-06-22 18:29:46.517363
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert(isinstance(indices, Indices))

if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-22 18:29:55.505865
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    """Test method __hash__ of class BaseVariable"""
    # Test: only accepts instances of `BaseVariable`
    assert hash(BaseVariable) == hash(type)
    assert hash(1) != hash(1.0)
    assert hash(None) != hash(not None)
    assert hash('a') != hash(b'a')

    # Test: different values for `source` and `exclude`
    x1 = BaseVariable('source1', ('exclude1', 'exclude2'))
    x2 = BaseVariable('source2', ('exclude1', 'exclude2'))
    x3 = BaseVariable('source1', ('exclude3', 'exclude4'))
    x4 = BaseVariable('source1', ('exclude1', 'exclude2'))
    assert hash(x1) != hash(x2)
   

# Generated at 2022-06-22 18:30:03.518275
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('xxx')
    assert not needs_parentheses('xxx.yyy')
    assert needs_parentheses('(xxx)')
    assert needs_parentheses('((xxx))')
    assert needs_parentheses('((xxx.yyy))')
    assert needs_parentheses('xxx.yyy.zzz')
    assert not needs_parentheses('xxx.y(yy)')
    assert not needs_parentheses('xxx[1]')
    assert needs_parentheses('xxx[1].y(yy)')

# Generated at 2022-06-22 18:30:11.100671
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x.y').source == 'x.y'
    assert Keys('x.y').exclude == ()

    assert Keys('x.y', 'z').source == 'x.y'
    assert Keys('x.y', 'z').exclude == ('z',)

    assert Keys('x.y', ['z1', 'z2']).source == 'x.y'
    assert Keys('x.y', ['z1', 'z2']).exclude == ('z1', 'z2')


# Generated at 2022-06-22 18:30:20.018892
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y[0]')
    assert not needs_parentheses('x.y[:1]')
    assert needs_parentheses('x.y[0].z')
    assert needs_parentheses('x.y[0].z[foo]')
    assert needs_parentheses('x.y[0].z[foo].baz')
    assert needs_parentheses('foo[0]')
    assert needs_parentheses('foo[bar]')
    assert needs_parentheses('foo[bar][baz]')

# Generated at 2022-06-22 18:30:30.002517
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices('foo')
    assert v.source == 'foo'
    assert v.exclude == ()
    assert v._slice == slice(None)
    v = v[5:]
    assert v._slice == slice(5, None)
    v = Indices('bar', exclude=['baz'])
    assert v.source == 'bar'
    assert v.exclude == ('baz',)
    assert v._slice == slice(None)


_BUILTIN_TYPES = {
    'a': Attrs(),
    'k': Keys(),
    'i': Indices(),
    'e': Exploding(),
}

__all__ = list(_BUILTIN_TYPES) + ['BaseVariable']

# Generated at 2022-06-22 18:30:37.872937
# Unit test for constructor of class Exploding
def test_Exploding():
    my_var = Exploding('main_var')
    my_value = "Hello World"
    assert my_var._items(my_value) == [('main_var', my_value)]
    my_value = [my_value]
    my_var._items(my_value) == [('main_var[0]', my_value[0])]
    my_value = {'a': 'a'}
    my_var._items(my_value) == [('main_var[a]', my_value['a'])]


# Generated at 2022-06-22 18:30:42.412856
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print(isinstance(Attrs('a', exclude=('b',)), BaseVariable))
    assert Attrs('a', exclude=('b',)) == Attrs('a', exclude=('b',))
    assert not Attrs('a', exclude=('b',)) == Attrs('b', exclude=('b',))

# Generated at 2022-06-22 18:30:45.335979
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    b = BaseVariable("",())
    assert hash("abc") == BaseVariable("abc").__hash__()


# Generated at 2022-06-22 18:30:51.495229
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("a")
    assert a.source == "a"
    assert a.exclude == ()
    assert a.code.__str__() == '<code object <module> at 0x7fa158203d50, file "<variable>", line 1>'
    assert a.unambiguous_source == "a"
    assert a._fingerprint == (Indices, "a", ())

# Generated at 2022-06-22 18:30:59.650070
# Unit test for constructor of class Exploding
def test_Exploding():
   assert Exploding('z').source == 'z'
   assert str(Exploding('z')) == '<Exploding(z)>'
   assert str(Exploding('z', '__repr__')) == '<Exploding(z, exclude=__repr__)>'
   assert str(Exploding('z', ['__repr__', '__str__'])) == '<Exploding(z, exclude=__repr__, __str__)>'
   assert str(Exploding('z', '__repr__', '__str__')) == '<Exploding(z, exclude=__repr__, __str__)>'

test_Exploding()

# Generated at 2022-06-22 18:31:11.605550
# Unit test for constructor of class Attrs
def test_Attrs():
    # Test if an object is created.
    a = Attrs('foo')
    assert isinstance(a, Attrs)

    # Test if input source gets stored.
    assert a.source == 'foo'

    # Test if exclude attribute is set to empty tuple
    assert a.exclude == ()

    # Test if code attribute is correctly set
    assert a.code == compile('foo', '<variable>', 'eval')

    # Test if unambiguous_source attribute is correctly set
    assert a.unambiguous_source == 'foo'

    # Test if setting exclude works.
    a = Attrs('foo', exclude='bar')
    assert a.exclude == ('bar', )

    # Test if setting exclude works.
    a = Attrs('foo', exclude=['bar', 'bar2'])

# Generated at 2022-06-22 18:31:14.704139
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    test_source = "id"
    test_var = BaseVariable(test_source)
    assert test_var.source == "id"



# Generated at 2022-06-22 18:31:15.753818
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable("a")


# Generated at 2022-06-22 18:31:22.441619
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('f(x)')
    assert not needs_parentheses('x.y')
    assert needs_parentheses('x . y')
    assert needs_parentheses('f(x.y)')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(f(x).y)')
    assert needs_parentheses('f(x) . y')
    assert not needs_parentheses('(f(x)) . y')

# Generated at 2022-06-22 18:31:29.426691
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('a')
    assert var.source == 'a'
    assert var.code.co_code == compile('a', '<variable>', 'eval').co_code
    assert var._fingerprint[0] == Exploding
    assert var._fingerprint[1] == 'a'
    assert var._fingerprint[2] == ()
    assert var.unambiguous_source == 'a'
    assert needs_parentheses('a') == False



# Generated at 2022-06-22 18:31:37.259938
# Unit test for function needs_parentheses
def test_needs_parentheses():
    class A:
        pass

    b = A()
    b.name = 'b'
    c = A()

    assert needs_parentheses('1')
    assert needs_parentheses('False')
    assert needs_parentheses('None')
    assert needs_parentheses('True')
    assert needs_parentheses('list()')
    assert needs_parentheses('A')
    assert needs_parentheses('"abc"')
    assert needs_parentheses('b.name')
    assert needs_parentheses('c.name')

    assert not needs_parentheses('a')
    assert not needs_parentheses('b')
    assert not needs_parentheses('c')



# Generated at 2022-06-22 18:31:38.940626
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    vars = Indices('a')
    vars = vars[:]


# Generated at 2022-06-22 18:31:50.316099
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('foo') is False
    assert needs_parentheses('foo().bar') is False
    assert needs_parentheses('foo()[3].bar') is False
    assert needs_parentheses('foo().bar.baz') is False
    assert needs_parentheses('foo()[3].bar.baz') is False

    assert needs_parentheses('foo[2].bar') is True
    assert needs_parentheses('foo[2].bar.baz') is True
    assert needs_parentheses('foo[2].bar.baz.froz') is True
    assert needs_parentheses('foo[2].bar.baz.froz()') is True

# Generated at 2022-06-22 18:31:52.518644
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v = CommonVariable(source=None, exclude=None)
    assert(v.source == None)
    assert(v.exclude == ())


# Generated at 2022-06-22 18:32:02.826526
# Unit test for method __eq__ of class BaseVariable

# Generated at 2022-06-22 18:32:06.588639
# Unit test for constructor of class Attrs
def test_Attrs():
    class C:
        def __init__(self, a, b=3):
            self.a = a
            self.b = b
    obj = C(1)
    assert obj.a == 1
    assert obj.b == 3
    assert tuple(Attrs('obj').items(obj)) == (('obj', 'C(a=1, b=3)'),
                                              ('obj.a', '1'),
                                              ('obj.b', '3'))



# Generated at 2022-06-22 18:32:09.955354
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    b = a[1:3]
    assert b._slice == slice(1, 3)
    assert b._fingerprint == a._fingerprint

EXPLODING_VARIABLE = Exploding('_')
del Exploding



# Generated at 2022-06-22 18:32:16.196741
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from .utils import test_var

    assert test_var('foo') == []
    assert test_var('foo', 'bar') == []
    assert test_var('foo', 'bar', 'baz') == []
    assert test_var('foo.bar', 'foo.baz') == []

# Generated at 2022-06-22 18:32:24.146143
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class TestBaseVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source
    base_variable_a = TestBaseVariable('x')
    base_variable_b = TestBaseVariable('x')
    base_variable_c = TestBaseVariable('y')
    assert hash(base_variable_a) == hash(base_variable_b)
    assert hash(base_variable_a) != hash(base_variable_c)
    # test whether the

# Generated at 2022-06-22 18:32:30.737124
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class T(BaseVariable):
        def __init__(self, *args, **kwargs):
            self.category = utils.get_category(args[0])
            super(T, self).__init__(*args, **kwargs)

        def _items(self, main_value, normalize=False):
            return ()

    a = T('a')
    b = T('b')
    assert hash(a) == hash(a)
    assert hash(a) != hash(b)


# Generated at 2022-06-22 18:32:35.081688
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert (BaseVariable("test", exclude=("a",)).exclude == ("a",))
    assert BaseVariable("test", exclude="a").exclude == ("a",)
    assert BaseVariable("test").exclude == ()


# Generated at 2022-06-22 18:32:43.019073
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable_name = 'self.a'
    # Initialize a mock class
    class MockSequence(Sequence):
        def __init__(self):
            self.a = [1,2,3,4]
            self.exclude = ()

    # Initialize an instance 
    obj = MockSequence()
    # Initialize an indices variable
    indices_variable = Indices(variable_name, obj.exclude)
    # Try to apply the __getitem__ method
    test_obj = indices_variable[0:]
    assert test_obj._slice == slice(0)

# Generated at 2022-06-22 18:32:51.220901
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = {'a': [1, 2, 3]}
    class c(CommonVariable):
        def _keys(self, key):
            return {'a', 'b', 'c'}
        def _format_key(self, key):
            return key
        def _get_value(self, key, value):
            return key + value

    result = []
    for t in c('ddd').items(x, False):
        result.append(t)

    assert result == [('ddd', '{u\'a\': [1, 2, 3]}')]

# Generated at 2022-06-22 18:32:52.338371
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable("a")

# Generated at 2022-06-22 18:32:53.640178
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable(source="f.minx")
    assert len(list(v.items(object))) == 0

# Generated at 2022-06-22 18:32:57.953033
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {1:2, 3:4}
    e = Exploding(main_value)
    assert e.source == 'main_value'
    assert e.code == compile('main_value', '<variable>', 'eval')
    assert e.unambiguous_source == 'main_value'
    assert e.exclude == ()

# Generated at 2022-06-22 18:33:08.970739
# Unit test for constructor of class Attrs
def test_Attrs():
    code = compile('a', '<variable>', 'eval')
    a = Attrs('a')
    assert a.code == code
    assert a.source == 'a'
    assert a.exclude == ()
    assert repr(a) == 'Attrs(source=a)'
    assert a._fingerprint == (Attrs, 'a', ())
    assert hash(a) == hash(Attrs('a'))
    assert hash(a) != hash(Attrs('a', 'x'))
    assert a != Attrs('a')
    assert a == Attrs('a', 'x')
    assert a != object()
    assert str(a) == 'a'
    assert a != 'a'
    assert a != [1, 2]


# Generated at 2022-06-22 18:33:10.322591
# Unit test for constructor of class Indices
def test_Indices():
    test = Indices("example")
    assert True

# Generated at 2022-06-22 18:33:12.472143
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    assert not a == b


# Generated at 2022-06-22 18:33:13.688489
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x.y')

# Generated at 2022-06-22 18:33:14.534766
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('a')


# Generated at 2022-06-22 18:33:17.848491
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys(source = 'hello', exclude = [4])
    assert keys.source == 'hello'
    assert keys.exclude == [4]
    assert keys.code == compile(source = 'hello', filename = '<variable>', mode = 'eval')
    assert keys.unambiguous_source == 'hello'

# Generated at 2022-06-22 18:33:23.139058
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable('abc', 'ab')
    assert cv.source is 'abc'
    assert cv.exclude is 'ab'
    assert cv.code is compile('abc', '<variable>', 'eval')
    assert cv.unambiguous_source is 'abc'


# Generated at 2022-06-22 18:33:26.819291
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys("test")
    assert keys.source == "test"
    assert keys.exclude == ()
    assert keys.code == compile("test", '<variable>', 'eval')


# Generated at 2022-06-22 18:33:31.704341
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("test")
    indices_slice = indices[:]
    assert isinstance(indices_slice, Indices)
    assert indices._slice == indices_slice._slice == slice(None)
    indices_slice = indices[1:8:2]
    assert isinstance(indices_slice, Indices)
    assert indices_slice._slice == slice(1,8,2)

# Generated at 2022-06-22 18:33:42.025407
# Unit test for constructor of class Attrs
def test_Attrs():
    import inspect
    from . import utils
    Foo = utils.Foo
    a = Attrs('Foo')
    assert inspect.ismethod(a.items)
    assert inspect.ismethod(a._items)
    assert isinstance(a._items(Foo), Iterable)
    assert a._keys(Foo) == ('x', 'y')
    assert a._keys(Foo()) == ('x', 'y')
    assert a._format_key('x') == '.x'
    assert a._get_value(Foo, 'x') == Foo.x
    assert a._format_key('z') == '.z'
    assert a._get_value(Foo, 'z') == Foo.z


# Generated at 2022-06-22 18:33:47.660784
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .pycompat import builtins
    builtins.__debug__ = False
    for i in range(6):
        for j in range(6):
            assert list(Indices('x')['%s:%s' % (i,j)]._keys('123456')) == list(range(i,j))
    builtins.__debug__ = True

# Generated at 2022-06-22 18:33:52.333743
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert CommonVariable('', ()) == CommonVariable('', ())
    assert CommonVariable('', ()) != CommonVariable('x', ())
    assert CommonVariable('', ()) != CommonVariable('', ('x',))
    assert CommonVariable('', ()) != CommonVariable('x', ('x',))



# Generated at 2022-06-22 18:33:55.614317
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('my_var')
    # c = CommonVariable('my_var', exclude='a')     #TODO fix me
    assert c and isinstance(c, CommonVariable)


# Generated at 2022-06-22 18:33:59.530812
# Unit test for constructor of class Attrs
def test_Attrs():
    v = Attrs('object_name')
    assert v.source == 'object_name'
    assert v.exclude == ()
    assert v.code == compile('object_name', '<variable>', 'eval')
    assert v.unambiguous_source == 'object_name'
    

# Generated at 2022-06-22 18:34:02.637559
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    expect = []
    for i in range(10):
        expect.append(['a', '1'])
    v = BaseVariable('a')
    a = 10
    assert v.items(frame=None) == expect


# Generated at 2022-06-22 18:34:03.506204
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # TODO
    pass



# Generated at 2022-06-22 18:34:04.647497
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    _ = CommonVariable('a', exclude=['b'])


# Generated at 2022-06-22 18:34:10.248194
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    variable = BaseVariable(source='test_source')
    variable1 = BaseVariable(source='test_source')
    variable2 = BaseVariable(source='test_source')
    assert variable.__hash__() == variable1.__hash__() == variable2.__hash__(), \
        "hash of variable should be " + str(variable.__hash__()) + \
        ", but is " + str(variable1.__hash__()) + " and " + str(variable2.__hash__())


# Generated at 2022-06-22 18:34:15.840792
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from itertools import count

    a = []
    for i in count():
        if i == 5: break
        a.append(i)

    assert a[:] == [0, 1, 2, 3, 4]
    assert a[1:] == [1, 2, 3, 4]
    assert a[:5] == [0, 1, 2, 3, 4]
    assert a[1:5] == [1, 2, 3, 4]

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:34:26.709377
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('0') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x[0]') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('(x.y)') is False
    assert needs_parentheses('(x[0])') is False

    assert needs_parentheses('x + y') is True
    assert needs_parentheses('(x) + y') is True
    assert needs_parentheses('x + (y)') is True
    assert needs_parentheses('(x + y)') is False
    assert needs_parentheses('x * y') is True

    assert needs_parentheses('-x') is False
    assert needs_parentheses('x.y')

# Generated at 2022-06-22 18:34:35.382555
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a.b')
    assert attrs.source == 'a.b'
    assert attrs.exclude == ()
    assert attrs.code is not None
    assert attrs.unambiguous_source == '(a.b)'
    # TODO: check what frame it give
    assert attrs.items is not None
    assert attrs._items is not None
    assert attrs._fingerprint is not None
    assert attrs.__hash__() is not None
    assert attrs.__eq__() is not None

# Generated at 2022-06-22 18:34:45.245068
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))
    assert hash(BaseVariable('a', exclude=('b',))) == hash(BaseVariable('a', exclude=('b',)))
    assert hash(BaseVariable('a', exclude=('b',))) != hash(BaseVariable('a', exclude=(1,)))
    assert hash(BaseVariable('a', exclude=('b',))) != hash(BaseVariable('a', exclude=('b', 'c')))
    assert hash(Keys('a')) != hash(Attrs('a'))
    assert hash(Keys('a')) != hash(Indices('a'))
    assert hash(Keys('a')) != hash(Exploding('a'))
    assert hash(Attrs('a'))

# Generated at 2022-06-22 18:34:46.818851
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a').source == 'a'
    assert Keys('a').exclude == ()


# Generated at 2022-06-22 18:34:49.199872
# Unit test for constructor of class Indices
def test_Indices():
    updatedlist = []
    for i in Indices():
        updatedlist.append(i)
    assert updatedlist == list(range(len(updatedlist)))

# Generated at 2022-06-22 18:34:50.900931
# Unit test for constructor of class Attrs
def test_Attrs():
    variable = Attrs('hello')
    variable.__init__('hello')

# Generated at 2022-06-22 18:34:53.459926
# Unit test for constructor of class Keys
def test_Keys():
	v = Keys('x')
	assert v.source == 'x'
	assert v.exclude == ()
	assert v.unambiguous_source == 'x'


# Generated at 2022-06-22 18:34:58.780786
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')

    assert Keys('a') == Keys('a')
    assert Keys('a') != Keys('b')

    assert Indices('a') == Indices('a')
    assert Indices('a') != Indices('b')

    assert Exploding('a') == Exploding('a')
    assert Exploding('a') != Exploding('b')

# Generated at 2022-06-22 18:35:00.421284
# Unit test for constructor of class Exploding
def test_Exploding():
    Ex = Exploding('var')
    assert Ex.source == 'var'
    assert isinstance(Ex, Exploding)


# Generated at 2022-06-22 18:35:12.534386
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys, StringIO
    def run(python_code, variables=("_",), exclude=("_",)):
        frame = sys._getframe().f_back
        frame.f_locals["__tracebackhide__"] = True
        user_ns = {'_': None}
        user_ns.update(frame.f_globals)
        user_ns.update(frame.f_locals)
        code = compile("""exec compile(u'''{0}''',u'<string>','exec')""".format(python_code.replace("'","\\'")), '<input>', 'single')

# Generated at 2022-06-22 18:35:15.435944
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    s = BaseVariable('.source')
    assert s.__hash__() == hash(s._fingerprint)


# Generated at 2022-06-22 18:35:17.754893
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[:2][:3] == Indices('')[:2][:3]



# Generated at 2022-06-22 18:35:21.909311
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    """Test Coverage"""
    v = BaseVariable(source = "a.b")
    cls = type(v)
    assert hash(v) == hash(cls), "Failed on __hash__"


# Generated at 2022-06-22 18:35:29.810246
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestClass(object):
        test_class_var = 'var'
        test_class_attr = 'attr'
        test_class_key = 'key'

    x = 'x'
    a = {'b':'c'}

    t = TestClass()

    def test(variable, frame, result):
        assert variable.items(frame) == result

    test(Exploding('x'), t.__dict__, [('x', 'x')])
    test(Attrs('t'), t.__dict__, [('t', 'TestClass()'), ('t.test_class_var', 'var'), ('t.test_class_attr', 'attr')])
    test(Keys('a'), t.__dict__, [('a', "{'b': 'c'}"), ('a[b]', 'c')])
   

# Generated at 2022-06-22 18:35:38.828616
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('request')
    print(k.source) # 'request'
    print(k.exclude) # ()
    print(k.code) # <code object <module> at 0x0000000001DD10A0, file "<variable>", line 1>
    print(k.unambiguous_source) # '(request)'
    print(k.__hash__()) # -4631523102549494609
    print(k.__eq__(k)) # True
    print(k._safe_keys(k)) # <generator object _safe_keys at 0x0000000001A1F270>
    print(k._keys(k)) # ()
    print(k._format_key('request')) # NotImplementedError
    print(k._get_value(k, 'request')) # NotImplementedError

# Generated at 2022-06-22 18:35:48.565229
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame = inspect.currentframe()
    assert frame.f_code.co_name == 'test_BaseVariable'
    variable = BaseVariable("frame")
    assert variable.source == "frame"
    assert variable.exclude == ()
    variable_with_exclude = BaseVariable("frame", "f_code")
    assert variable_with_exclude.exclude == ("f_code",)
    assert variable.code == compile("frame", '<variable>', 'eval')
    assert variable.unambiguous_source == 'frame'
    assert variable.__hash__() == hash((type(variable), variable.source, variable.exclude))
    assert variable_with_exclude.__hash__() == hash((type(variable_with_exclude), variable_with_exclude.source, variable_with_exclude.exclude))
    variable

# Generated at 2022-06-22 18:35:53.151478
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    parent = Indices('x')
    child = parent[1:1]
    assert parent == parent
    assert parent != child
    assert child.source == 'x'
    assert parent._slice == slice(None)
    assert child._slice == slice(1, 1)
