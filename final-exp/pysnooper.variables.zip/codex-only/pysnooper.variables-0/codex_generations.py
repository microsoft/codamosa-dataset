

# Generated at 2022-06-22 18:25:54.945703
# Unit test for constructor of class Attrs
def test_Attrs():
    # Attrs('a')
    # Attrs('a', 'b')
    # Attrs('a', [])
    # Attrs('a', ['b'])
    # Attrs('a', exclude=[])
    # Attrs('a', exclude=['b'])
    assert True


# Generated at 2022-06-22 18:26:02.470961
# Unit test for constructor of class Keys
def test_Keys():
    # set up default test case
    dict_ = {"A": "B"}
    var = Keys('dict_')
    assert var.code == compile('dict_', '<variable>', 'eval')
    assert var.unambiguous_source == 'dict_'
    # test case for unambiguous_source
    var = Keys('dict_[i]')
    assert var.unambiguous_source == '(dict_[i])'

    # test case for _format_key
    assert var._format_key(0) == '[0]'
    assert var._format_key('A') == '[A]'

    # test case for _get_value
    assert var._get_value(dict_, 'A') == 'B'
    assert var._get_value(dict_, 'B') is KeyError

    # test case for _keys
   

# Generated at 2022-06-22 18:26:08.486575
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'x'
    exclude = 'y'
    variable = BaseVariable(source, exclude)
    assert isinstance(variable, BaseVariable)
    assert variable.source == source
    assert variable.exclude == ('y', )
    assert variable.code == compile(source, '<variable>', 'eval')
    assert variable._fingerprint == (BaseVariable, source, ('y', ))
    assert variable.unambiguous_source == 'x'


# Generated at 2022-06-22 18:26:14.578947
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    ## Test object
    class BaseVariableer(BaseVariable):
        pass

    bv = BaseVariableer("c.d")
    assert bv.source == "c.d"
    assert bv.unambiguous_source == "(c.d)"
    assert bv._fingerprint == (BaseVariableer, "c.d", ())


if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-s'])

# Generated at 2022-06-22 18:26:25.816635
# Unit test for constructor of class Attrs
def test_Attrs():
    # 1.1 initialize an instance of class Attrs
    print ("The class name of Attrs is "+Attrs.__name__)
    print ("The class name of Attrs is "+Attrs.__doc__)
    print(type(Attrs.__name__))
    print(type(Attrs.__doc__))
    print(Attrs.__doc__)
    print(Attrs.__name__)
    # 1.2 create an instance of class Attrs
    var = Attrs("x")
    print(var)
    print(type(var))
    # 1.3 test the method of class Attrs
    print(var.__doc__)
    print(var.__name__)
    print(var.__hash__())
    print(var.__eq__())
    print(var.__sizeof__())


# Generated at 2022-06-22 18:26:27.107632
# Unit test for constructor of class Indices
def test_Indices():
    Indices('this.is.a.source')


# Generated at 2022-06-22 18:26:32.698157
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert Attrs('a.b')._get_value(utils.DummyObject(x=1), 'x') == 1
    d = utils.DummyObject(x=1)
    assert Keys('d')._get_value(d, 'x') == 1
    x = [1, 2]
    assert Indices('x')._get_value(x, 0) == 1
    assert Exploding('x')._get_value(d, 'x') == 1

# Generated at 2022-06-22 18:26:37.500556
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('items')[0] == Indices('items[0]')
    assert Indices('items')[0:5] == Indices('items[0:5]')
    assert Indices('items')[::2] == Indices('items[::2]')

# Generated at 2022-06-22 18:26:43.229654
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Attrs('x', ())
    v2 = Attrs('x', ())
    v3 = Attrs('y', ())
    v4 = Attrs('x', ('y',))
    v5 = Keys('x', ())

    assert(v1 == v2)
    assert(v1 != v3)
    assert(v1 != v4)
    assert(v1 != v5)

# Generated at 2022-06-22 18:26:51.464682
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i=Indices("request")
    assert isinstance(i,Indices)
    i=Indices("request")[1:4]
    assert isinstance(i,Indices)
    assert i.source == "request"
    assert i._slice == slice(1,4)
    assert i._fingerprint == (Indices, 'request', ())
    assert i.code == compile("request", '<variable>', 'eval')
    assert i.unambiguous_source == "request"

# Generated at 2022-06-22 18:27:02.376144
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {
        "a": 1,
        "b": 2
    }
    b = [
        "b",
        "a",
        "c"
    ]
    c = ["a", "b", "c"]
    d = 0
    e = None
    f = "abc"
    g = True
    h = False

# Generated at 2022-06-22 18:27:09.136423
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {}
    a['b'] = {}
    a['b']['c'] = [1,2,3]

    result = []
    for x in range(3):
        result.append(Exploding(str(a)).items(a['b']['c'])[x][1])
    expected = ['1', '2', '3']
    assert result == expected

# Generated at 2022-06-22 18:27:20.079294
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = "index_var"
    exclude = ()
    index_var = [1, 2, 3, 4, 5, 6]
    index_var_slice_object = slice(1, 5)
    variable_item = Indices(source, exclude)[index_var_slice_object]
    variable_item_code = variable_item.code
    variable_item_unambiguous_source = variable_item.unambiguous_source
    variable_item_items = variable_item.items
    variable_item_items_result = variable_item_items(index_var, normalize=False)
    variable_item_result = variable_item.items(index_var, normalize=False)

# Generated at 2022-06-22 18:27:24.414187
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    expected = compile('x', '<variable>', 'eval')
    assert expected == BaseVariable('x').code
    assert expected == BaseVariable('(x)').code
    assert expected != BaseVariable('((x))').code
    assert expected != BaseVariable('x.y').code
    assert expected == BaseVariable('(x.y)').code
    assert expected == BaseVariable('((x.y))').code
    assert expected != BaseVariable('x[y]').code
    assert expected == BaseVariable('(x[y])').code
    assert expected == BaseVariable('((x[y]))').code
    assert expected == BaseVariable('x.y', exclude='abc').code
    assert expected == BaseVariable('x.y', exclude=('abc',)).code
    assert expected == BaseVariable('x.y', exclude=set('abc')).code

#

# Generated at 2022-06-22 18:27:35.597567
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Code coverage > 100% because of executing the code in assert statements
    from io import StringIO
    from coverage import Coverage

    cov = Coverage(include=['pystack.variables.BaseVariable'], omit=['*test*'])
    cov.start()

    def get_object_from_class(cls):
        return cls('x')

    class_list = [get_object_from_class(cls) for cls in
                  [CommonVariable, Attrs, Keys, Indices, Exploding, BaseVariable]]

    for obj1 in class_list:
        for obj2 in class_list:
            if obj1.__class__ == obj2.__class__:
                assert obj1 == obj2
            else:
                assert obj1 != obj2

    cov.stop()
    out = StringIO()

# Generated at 2022-06-22 18:27:37.999763
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import os
    import sys

    vars = BaseVariable('os')
    print(vars.items(sys._getframe()))
    print(vars.source)
    print(vars.unambiguous_source)
    print(vars.code)
    print(vars.exclude)

# Generated at 2022-06-22 18:27:43.172363
# Unit test for constructor of class Keys
def test_Keys():
    key = Keys('x')
    print(key)
    print(key._keys(5))
    print(key.source)
    print(key.exclude)
    key = Keys('x', 'y', 'z')
    print(key)
    print(key._keys(5))
    print(key.source)
    print(key.exclude)


# Generated at 2022-06-22 18:27:49.474772
# Unit test for constructor of class Indices
def test_Indices():
    m = [1, 2, 3]
    a = Indices("m", [0])._items(m)
    assert len(a) == 2
    assert a[0][1] == 1
    assert a[1][1] == 3
    a = Indices("m", [0])[1:]._items(m)
    assert len(a) == 1
    assert a[0][1] == 3

# Generated at 2022-06-22 18:27:52.548202
# Unit test for constructor of class Attrs
def test_Attrs():
    variable = Attrs('x')
    assert variable.source == 'x'
    assert variable.exclude == ()
    assert variable.code
    assert variable.unambiguous_source == 'x'


# Generated at 2022-06-22 18:27:56.417969
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test for True
    var_X = BaseVariable('X')
    var_Y = BaseVariable('Y')
    assert (var_X == BaseVariable('X'))
    # Test for False
    assert (var_X != var_Y)


# Generated at 2022-06-22 18:28:03.256996
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source="test";exclude="test1"
    assert Indices(source,exclude)._slice == slice(None)
    assert isinstance(deepcopy(Indices(source,exclude)),Indices)
    assert Indices(source,exclude)[slice(None)]._slice == slice(None)
    assert Indices(source,exclude)[0:1]._slice == slice(0, 1, None)
    assert Indices(source,exclude)[::1]._slice == slice(None, None, 1)


# Generated at 2022-06-22 18:28:12.075893
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pprint
    from .pycompat import collections
    from . import utils

    source = '"str"'
    source_len = len(source)
    source_unambiguous = source
    code = compile(source, '<str>', 'eval')
    exclude = ()

    # __init__
    elm = BaseVariable(source)
    assert (elm.source == source)
    assert len(elm.source) == source_len
    assert (elm.code == code)
    assert (elm.unambiguous_source == source_unambiguous)
    assert (elm.exclude == exclude)
    assert len(elm.exclude) == len(exclude)

    # _items
    assert elm._items(None) == ((),)

    # property _fingerprint
    assert elm

# Generated at 2022-06-22 18:28:19.794718
# Unit test for constructor of class Attrs
def test_Attrs():
    # Assert initialization of object Attrs with source=None
    var = Attrs(source=None)
    assert var.source == None
    assert var.exclude == ()
    # Assert initialization of object Attrs with source='a'
    var = Attrs(source='a')
    assert var.source == 'a'
    assert var.exclude == ()
    # Assert initialization of object Attrs with source='a', exclude='b'
    var = Attrs(source='a', exclude='b')
    assert var.source == 'a'
    assert var.exclude == ('b',)
    # Assert initialization of object Attrs with source='a', exclude=['b']
    var = Attrs(source='a', exclude=['b'])
    assert var.source == 'a'

# Generated at 2022-06-22 18:28:25.464195
# Unit test for constructor of class Attrs
def test_Attrs():
    # Construct object Attrs
    obj_Attrs = Attrs("a")
    # Check if the instance variables are defined correctly
    assert obj_Attrs.source == "a"
    assert obj_Attrs.exclude == ()
    assert obj_Attrs.code is not None
    assert obj_Attrs.unambiguous_source == "a"
    # Check if the method items returns correctly
    assert obj_Attrs.items(None) == ()


# Generated at 2022-06-22 18:28:27.176861
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('test_source', exclude=False)
    BaseVariable('test_source', exclude=True)

# Generated at 2022-06-22 18:28:33.366452
# Unit test for constructor of class Exploding
def test_Exploding():
  class TestClass:
    def __init__(self):
      self.a = "b"
  obj = TestClass()
  assert(Exploding('obj')._items(obj)[1] == ('obj.a', '"b"'))

explode = Exploding


# Just to confirm that things are working correctly
if __name__ == '__main__':
  class TestClass:
    def __init__(self):
      self.a = "b"
  obj = TestClass()
  assert(Exploding('obj')._items(obj)[1] == ('obj.a', '"b"'))

# Generated at 2022-06-22 18:28:40.367999
# Unit test for function needs_parentheses
def test_needs_parentheses():
    # See: https://github.com/mgedmin/wdb.server/issues/1
    from tests.utils import assert_iter_equal

# Generated at 2022-06-22 18:28:41.593683
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')



# Generated at 2022-06-22 18:28:46.509608
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('source')
    b = a[2:4]
    c = a[2:]
    d = Indices('source')[2:4]

    assert b._fingerprint == d._fingerprint
    assert b == d
    assert b._fingerprint != c._fingerprint
    assert b != c

# Generated at 2022-06-22 18:28:49.740421
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    obj = BaseVariable(source=u'', exclude=())
    # call the method
    result = obj.__hash__()
    assert result is None


# Generated at 2022-06-22 18:28:57.466511
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('().x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.y.z')
    assert not needs_parentheses('x[y]')
    assert not needs_parentheses('x[y][z]')
    assert not needs_parentheses('x[(y)]')
    assert not needs_parentheses('x[y].z')
    assert not needs_parentheses('x.y[z]')
    assert not needs_parentheses('x[y][z].w')
    assert not needs_parentheses('x[(y).z]')

# Generated at 2022-06-22 18:28:59.481037
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("main_value", "exclude")
    assert isinstance(a, Keys)


# Generated at 2022-06-22 18:29:10.391962
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        __slots__ = ('__dict__', 'm')
        def __init__(self):
            self.__dict__ = {'x': 1, 'y': 2}
            self.m = 3
        def f(self, arg):
            return arg

    a = A()

    assert a.f('abcd') == 'abcd'
    assert a.__dict__ == {'x': 1, 'y': 2}
    assert a.m == 3

    x = Attrs("a.f('abcd')")
    assert x.items(None) == [("a.f('abcd')", "'abcd'"), ('a.__dict__', '{\'x\': 1, \'y\': 2}'), ('a.m', '3')]



# Generated at 2022-06-22 18:29:12.693689
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'xxx'
    exclude = ['a', 'b']
    var = CommonVariable(source, tuple(exclude))
    assert var.source == source
    assert var.exclude == exclude
    assert not isinstance(var.source, tuple)
    assert isinstance(var.exclude, tuple)



# Generated at 2022-06-22 18:29:14.770452
# Unit test for constructor of class Keys
def test_Keys():
    v = Keys('test_keys')
    assert v.source == 'test_keys'


# Generated at 2022-06-22 18:29:25.592182
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    assert var[:] == Indices('x', slice(None))
    assert var[3:-1] == Indices('x', slice(3, -1))
    assert var[::2] == Indices('x', slice(None, None, 2))
    assert var[::-1] == Indices('x', slice(None, None, -1))
    assert var[::-2] == Indices('x', slice(None, None, -2))
    assert var[10:1:-1] == Indices('x', slice(10, 1, -1))
    assert var[10:1:-2] == Indices('x', slice(10, 1, -2))
    assert var[:-10:-1] == Indices('x', slice(-10, None, -1))

# Generated at 2022-06-22 18:29:35.329587
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a').items(dict(a=1)) == [
        ('a', '1')
    ]
    assert Keys('a').items(dict(a=dict(x=1))) == [
        ('a', '{...}'),
        ('a[\'x\']', '1')
    ]
    assert Indices('a').items(dict(a=(1, 2, 3))) == [
        ('a', '(1, 2, 3)'),
        ('a[0]', '1'),
        ('a[1]', '2'),
        ('a[2]', '3')
    ]
    assert Keys('a').items(dict(a=1)) == [
        ('a', '1')
    ]

# Generated at 2022-06-22 18:29:38.676211
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var_test = BaseVariable('var')
    var_test1 = BaseVariable('var1')
    var_test2 = BaseVariable('var')

    assert(hash(var_test) == hash(var_test2))
    assert(hash(var_test) != hash(var_test1))



# Generated at 2022-06-22 18:29:45.028116
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variables = [Attrs('main_value'), Keys('main_value'), Indices('main_value'), Exploding('main_value')]
    for var in variables:
        print('source:', var.source)
        print('raw code:', var.code)
        print('unambiguous_source:', var.unambiguous_source)
        print('exclude:', var.exclude)
        print()
    assert len(variables) == 4

# Generated at 2022-06-22 18:29:54.991610
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestClass(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
        def c(self):
            return 'c'

    def test_func():
        return 'test_func'

    t = TestClass()
    t.t = t
    t.func = test_func

# Generated at 2022-06-22 18:29:57.908819
# Unit test for constructor of class Keys
def test_Keys():
    d = Keys("key")
    assert d.source == "key"
    assert d.exclude == ()
    assert d.code == compile('key', '<variable>', 'eval')
    assert d.unambiguous_source == "key"
    

# Generated at 2022-06-22 18:30:03.802079
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a)')
    assert needs_parentheses('(a).b')
    assert needs_parentheses('(a.b)')
    assert not needs_parentheses('(a.b).c')

# Generated at 2022-06-22 18:30:07.252384
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('x', 'y')
    assert hash(v) == hash((type(v), 'x', ('y', )))


# Generated at 2022-06-22 18:30:10.943207
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('','')._slice == slice(None)
    assert Indices('','')[2:4]._slice == slice(2,4)

# Generated at 2022-06-22 18:30:21.652882
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    "Test that items() works correctly"
    # import sys
    # sys.stderr.write(__name__ + ':\n')
    class Local(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [('name', 'value')]

    var = Local('a')
    assert var.items({'a': 1}, normalize=True) == [('a', '1')], var
    assert var.items({'a': {'b': 2}}, normalize=True) == [('a', '{...}')], var
    assert var.items({'a': {'b': 2}}, normalize=False) == [('a', "{'b': 2}")], var
    # sys.stderr.write('\n')


# Generated at 2022-06-22 18:30:24.852477
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('a')
    print (var.source)
    print (var.exclude)
    print (var.code)
    print (var.unambiguous_source)
    print (var._slice)
    # print (var._keys)



# Generated at 2022-06-22 18:30:35.016945
# Unit test for constructor of class Keys
def test_Keys():
    source = 'abc'
    exclude = 123
    k = Keys(source, exclude)
    assert k.source == source
    assert k.exclude == (123,)
    assert k.code == compile(source, '<variable>', 'eval')
    assert k.unambiguous_source == 'abc'
    assert k._fingerprint == (Keys, 'abc', (123,))
    assert k._safe_keys == k.__class__._safe_keys
    assert k._keys == k.__class__._keys
    assert k._format_key == k.__class__._format_key
    assert k._get_value == k.__class__._get_value


# Generated at 2022-06-22 18:30:38.106991
# Unit test for constructor of class Indices
def test_Indices():
    index_object = Indices("index")
    assert index_object != Indices("index2")
    assert index_object == Indices("index")
    assert index_object[10] != index_object[5:10]

# Generated at 2022-06-22 18:30:45.191501
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable = CommonVariable('a')
    assert variable.source == 'a'
    variable = CommonVariable('a', exclude=['b', 'c'])
    assert variable.source == 'a'
    assert variable.exclude == ('b', 'c')
    variable = CommonVariable('a', exclude=['b', 'c'])
    assert variable.source == 'a'
    assert variable.exclude == ('b', 'c')
    variable = CommonVariable('a', exclude='b')
    assert variable.source == 'a'
    assert variable.exclude == ('b',)


# Generated at 2022-06-22 18:30:49.902510
# Unit test for constructor of class Keys
def test_Keys():
    var1 = Keys("b")
    b = [1, 2, 3, 4, 5]
    print(var1.items(b))

if __name__ == '__main__':
    # test_Keys()
    pass

# Generated at 2022-06-22 18:30:59.457923
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Create a Vars instance
    v = Indices("inst.sub_instances[0].sub_sub_instances", exclude="inst.sub_instances[0].sub_sub_instances[x].sub_sub_sub_instances")
    # Create a Vars instance with slice [0:2]
    v_slice = v.__getitem__(slice(0, 2))
    # Test if slice is correctly set
    assert(v_slice._slice == slice(0, 2))
    # Test if slice is not set for original vars instance
    assert(v._slice == slice(None))

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:31:11.268392
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import exc_info
    from . import frames
    from . import utils
    from . import traceback_utils
    import os

    if os.getenv('PYTHONBREAKPOINT'):
        # To avoid infinite recursion if $PYTHONBREAKPOINT is set to 'ipdb.set_trace'
        return

    def fail(exc_type, exc_val, exc_tb):  # noqa: F811
        exc_info.exc_info = exc_type, exc_val, exc_tb

    @traceback_utils.capture(fail, clear_exc_info=True)
    def foo():  # noqa: F811
        bar()


# Generated at 2022-06-22 18:31:13.451336
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var = BaseVariable('a', 'b')
    expected = hash(('source: a', 'exclude: b'))
    assert var.__hash__() == expected

# Generated at 2022-06-22 18:31:24.502374
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .fake import Frame

    variables = [
        ('var', 'var'),
        ('var.attr', 'var.attr'),
        ('var["attr"]', 'var["attr"]'),
        ('var.list[0]', 'var.list[0]'),
        ('var.list[0].attr', 'var.list[0].attr'),
        ('var[0].attr', 'var[0].attr'),
        ('var[0][0].attr', 'var[0][0].attr'),
    ]

    frame_locals = {
        'var': {
            'attr': 1,
            'list': [{'attr': 2}]
        },
        'var.list': [{'attr': 3}],
        'var["list"]': [{'attr': 4}]
    }

# Generated at 2022-06-22 18:31:28.135274
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys("abcd")
    assert type(a) == Keys
    assert a.source == "abcd"
    assert a._fingerprint == (Keys, "abcd", ())
    assert a._format_key("a") == "[a]"

# Generated at 2022-06-22 18:31:29.290391
# Unit test for constructor of class Attrs
def test_Attrs():
    string = "testAttrs"
    Attrs(string)



# Generated at 2022-06-22 18:31:32.297529
# Unit test for constructor of class Exploding
def test_Exploding():
    # Note: The way to test the constructor of a class
    #       is to call the constructor directly.
    #
    # Verify that constructor is not an empty function.
    # Just to make sure it is not an empty function.
    assert repr(Exploding('x'))

# Generated at 2022-06-22 18:31:39.566932
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = {"a": 1, "b": 2, "c": {"d": 3, "e": 4} }
    frame = { "d": d, "str": "str", "list": [1, 2, 3] }
    var = BaseVariable("d")
    assert sorted(var.items(frame)) == sorted([("d", "d"), ("d.a", "1"), ("d.b", "2"), ("d.c", "..."), ("d.c.d", "3"), ("d.c.e", "4")])


# test methods prettify and get_shortish_repr in utils
import sys

# Generated at 2022-06-22 18:31:41.276319
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[1:]

# Generated at 2022-06-22 18:31:48.491188
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert \
        BaseVariable('a') == BaseVariable('a') \
        == BaseVariable('a', exclude='b') \
        == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='b',)





# Generated at 2022-06-22 18:31:50.576171
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")
    assert BaseVariable("a", "b") == BaseVariable("a", "b")

# Generated at 2022-06-22 18:31:52.413415
# Unit test for constructor of class Exploding
def test_Exploding():
    v0 = Exploding(1)
    v1 = Exploding(1, 2)


# Generated at 2022-06-22 18:31:55.450630
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable(None)
    assert bv == bv
    assert bv != object()
    assert not (bv != bv)
    assert not (bv == object())

# Generated at 2022-06-22 18:32:00.873359
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a, b = BaseVariable("source_1", "exclude_1"), BaseVariable("source_1", "exclude_1")
    c, d = BaseVariable("source_1", "exclude_2"), BaseVariable("source_2", "exclude_1")
    assert (a == b) == True
    assert (a == c) == False
    assert (a == d) == False


# Generated at 2022-06-22 18:32:09.807611
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('self', exclude=['t'])
    assert a.source == 'self'
    assert a.unambiguous_source == '(self)'
    assert a.code
    assert a.code.co_name == 'self'
    assert a.code.co_names == ()
    assert a.exclude == ('t',)
    assert a.items
    assert a._fingerprint
    assert a.__hash__
    assert a.__eq__
    assert a._safe_keys
    assert a._keys
    assert a._format_key
    assert a._get_value


# Generated at 2022-06-22 18:32:22.092937
# Unit test for constructor of class Keys
def test_Keys():
    a = 'hello'
    b = 'world'

    # Test constructor of Keys
    var = Keys('a')
    assert var.exclude == ()
    assert var.source == 'a'
    assert var.code.co_code == b'q\x01d\x01\x83\x01\x01\x00d\x01\x00\x83\x01\x01\x00d\x02\x00S'

    # Test method items of class Keys
    k = Keys('a')
    assert k.items(globals()) == [('a', 'hello')]

    # Test method items of class Indices
    k = Indices('a')
    assert k.items(globals()) == [('a', 'hello')]

    # Test constructor of class Attrs
    k = Attrs

# Generated at 2022-06-22 18:32:26.024923
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('my_variable')
    indices_slice = indices[:1]
    assert indices_slice.__class__ == Indices
    assert indices_slice._slice == slice(None, 1, None)
    assert indices_slice.source == 'my_variable'
    assert indices_slice.exclude == ()


# Generated at 2022-06-22 18:32:37.218991
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable(source='source', exclude='')
    a1 = CommonVariable(source='source1', exclude=('a', 'b'))
    assert a == a, 'Test __eq__: a == a'
    assert a1 != a, 'Test __eq__: a1 != a'
    assert a.source == 'source', 'Test __init__: a.source == "source"'
    assert a.exclude == (), 'Test __init__: a.exclude == ()'
    assert a.code == compile('source', '<variable>', 'eval'), 'Test __init__: a.code == compile("source", "<variable>", "eval")'
    assert a.unambiguous_source == 'source', 'Test __init__: a.unambiguous_source == "source"'

# Generated at 2022-06-22 18:32:41.671523
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert 'a' in BaseVariable('a').items(None)
    assert 'b' in BaseVariable('a.b').items(None)
    assert 'c' in BaseVariable('a.b.c').items(None)
    assert 'd' in BaseVariable('a.b.c.d').items(None)
    assert 'e' in BaseVariable('a.b.c.d').items(None)


# Generated at 2022-06-22 18:32:42.776492
# Unit test for constructor of class Indices
def test_Indices():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 18:32:45.133748
# Unit test for constructor of class Indices
def test_Indices():
    ind = Indices('x')
    i = ind[1:2]
    assert isinstance(i, Indices)
    assert i._slice == slice(1, 2)

# Generated at 2022-06-22 18:32:56.219188
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('a').__eq__(Attrs('b')) == False
    assert Attrs('a.b').__eq__(Attrs('a.c')) == False
    assert Attrs('a.b', exclude='b') == Attrs('a.b', exclude='b')
    assert Attrs('a.b', exclude='b').__eq__(Attrs('a.b', exclude='x')) == False
    assert Attrs('a.b', exclude='b').__eq__(Attrs('a.b')) == False
    assert Attrs('a.b', exclude='b') != Exploding('a')
    assert Attrs('a').__eq__(Exploding('a')) == False

# Generated at 2022-06-22 18:32:57.831576
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_object = Indices('')
    assert test_object[0:2] == test_object[0:2]

# Generated at 2022-06-22 18:33:02.089936
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable("",())
    assert variable == variable
    assert variable == BaseVariable("",())
    assert variable != BaseVariable(" ",())
    assert variable != BaseVariable("",(""))
    assert variable != BaseVariable("",())

# Generated at 2022-06-22 18:33:04.600155
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices("obj")
    assert isinstance(obj[2:5], Indices)


# Generated at 2022-06-22 18:33:14.993314
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'d': {'a': 1, 'b': 2, 'c': 3}, 's': [1, 2, 3], 'a': (1, 2, 3)}
    assert Keys('d').items(frame) == [('d[a]', '1'), ('d[b]', '2'), ('d[c]', '3')]
    assert Attrs('a').items(frame) == [('a.x', '1'), ('a.y', '2'), ('a.z', '3')]
    assert Indices('s').items(frame) == [('s[0]', '1'), ('s[1]', '2'), ('s[2]', '3')]

# Generated at 2022-06-22 18:33:17.080384
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        BaseVariable("")
    except TypeError:
        print("BaseVariable constructor works")
    else:
        raise RuntimeError("BaseVariable constructor not working")


# Generated at 2022-06-22 18:33:25.378600
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable('a')
    assert(v.source == 'a')
    assert(v.exclude == ())
    assert(v.code == compile('a', '<variable>', 'eval'))
    assert(v.unambiguous_source == 'a')

    v1 = BaseVariable('a', 'b')
    assert(v1.source == 'a')
    assert(v1.exclude == 'b')
    assert(v1.code == compile('a', '<variable>', 'eval'))
    assert(v1.unambiguous_source == 'a')

# Generated at 2022-06-22 18:33:29.885882
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    C = CommonVariable("var","exclude")
    assert str(C.source) == "var"
    assert str(C.exclude) == "exclude"
    assert str(C.code) == "code object <variable> from '<variable>'"



# Generated at 2022-06-22 18:33:35.716685
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    eq_(BaseVariable('a.b'), BaseVariable('a.b'))
    eq_(BaseVariable('a.b', exclude=('c', 'd')), BaseVariable('a.b', exclude=('c', 'd')))
    assert not (BaseVariable('a.b') == 'a.b')
    assert not (BaseVariable('a.b') == BaseVariable('a.c'))
    assert not (BaseVariable('a.b') == BaseVariable('a.b', exclude='c'))
    assert not (BaseVariable('c.b') == BaseVariable('a.b'))
    assert not (BaseVariable('a.b', exclude='c') == BaseVariable('a.b'))



# Generated at 2022-06-22 18:33:38.862478
# Unit test for constructor of class Exploding
def test_Exploding():
    exp = Exploding('x')
    exp.source == 'x'
    exp.exclude == ()
    exp.unambiguous_source == 'x'
    exp.code == compile('x', '<variable>', 'eval')



# Generated at 2022-06-22 18:33:43.749362
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_var_explode = pycompat.check_unicode('var.explode', '')
    test_slice = slice(None, None, None)
    test_indices = Indices(test_var_explode)
    test_indices_copy = test_indices[test_slice]
    assert test_indices_copy._slice == test_slice
    assert test_indices.source == test_indices_copy.source
    assert test_indices.exclude == test_indices_copy.exclude

# Generated at 2022-06-22 18:33:56.071245
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('foo.bar') is False
    assert needs_parentheses('(foo).bar') is False
    assert needs_parentheses('x.y.z') is False
    assert needs_parentheses('(x.y).z') is False
    assert needs_parentheses('x[0]') is False
    assert needs_parentheses('x[0].y') is False
    assert needs_parentheses('x[0].y.z') is False
    assert needs_parentheses('x.y[0]') is False
    assert needs_parentheses('x.y.z[0]') is False
    assert needs_parentheses('x[0].y[0]') is False
    assert needs_parentheses('x.y[0].z[0]') is False


# Generated at 2022-06-22 18:34:03.789463
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import pycompat
    with pycompat.skip_if_py2():
        from .pycompat import unicode
        assert CommonVariable(unicode(''))._fingerprint == (CommonVariable, '', ())
        assert CommonVariable(unicode(''), ['a'])._fingerprint == (CommonVariable, '', ('a',))
        assert CommonVariable(unicode(''), unicode('a'))._fingerprint == (CommonVariable, '', ('a',))
        assert CommonVariable(unicode(''), unicode(''))._fingerprint == (CommonVariable, '', ())
        assert CommonVariable('abc', ['abc'])._fingerprint == (CommonVariable, 'abc', ('abc',))

# Generated at 2022-06-22 18:34:14.251147
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var1 = BaseVariable('a')
    assert var1.source == 'a'
    assert var1.exclude == ('',)
    assert var1.code == compile('a', '<variable>', 'eval')
    assert var1.unambiguous_source == 'a'
    # __init__(source, exclude=())
    var2 = BaseVariable('b', exclude='c')
    assert var2.source == 'b'
    assert var2.exclude == ('c',)
    assert var2.code == compile('b', '<variable>', 'eval')
    assert var2.unambiguous_source == 'b'
    var3 = BaseVariable('d', ('a', 'b', 'c'))
    assert var3.source == 'd'

# Generated at 2022-06-22 18:34:22.076505
# Unit test for constructor of class Attrs
def test_Attrs():
    class MyClass:
        x = 1
        y = 2
        __z = 0
        
    a = MyClass()
    avar = Attrs('a')
    assert avar._keys(a) == {'x', 'y'}
    assert avar._format_key('x') == 'x'
    assert avar._get_value(a, 'x') == 1
    assert avar._get_value(a, 'y') == 2
    assert avar._get_value(a, '__z') is None


# Generated at 2022-06-22 18:34:25.334774
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') is not BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('c', 'b'))



# Generated at 2022-06-22 18:34:28.371726
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable("sam", ()).source == "sam"
    assert CommonVariable("sam", ()).exclude == ()
    assert CommonVariable("sam", ()).unambiguous_source == "sam"



# Generated at 2022-06-22 18:34:33.692929
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('Indices', None)
    indices = indices[:]
    assert indices._slice == slice(None)
    indices = indices[:]
    assert indices._slice == slice(None)
    indices = indices[1:2]
    assert indices._slice == slice(1,2)

# Generated at 2022-06-22 18:34:39.848642
# Unit test for constructor of class Keys
def test_Keys():
    import os
    import re

    keys = Keys("os.environ")
    assert len(keys._keys(os.environ)) == len(os.environ)

    keys = Keys("os.environ", exclude="PYTHONPATH")
    pattern = re.compile(r'^.*os\.environ\[(.+)\].*$')
    for i in keys.items(globals()):
        match = pattern.match(i[0])
        assert match
        if match:
            key = match.group(1)
            assert key != 'PYTHONPATH'


# Generated at 2022-06-22 18:34:44.403750
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo') is False
    assert needs_parentheses('bar.foo') is False
    assert needs_parentheses('(bar).foo') is False
    assert needs_parentheses('(bar)') is True
    assert needs_parentheses('(bar).(foo)') is True
    assert needs_parentheses('(bar).foo.bar') is True



# Generated at 2022-06-22 18:34:53.291517
# Unit test for constructor of class Attrs
def test_Attrs():
    '''
    >>> source = 'name'
    >>> a = Attrs(source, ()).items(frame)
    >>> a[0][0], a[0][1] == ('name', "'herb'")
    True
    >>> a[1][0], a[1][1] == ('name.x', "2")
    True
    >>> a[2][0], a[2][1] == ('name.y', "3")
    True
    >>> a[3][0], a[3][1] == ('name.z', "4")
    True
    >>> a[4][0], a[4][1] == ('name.y', "3")
    True
    '''
    pass


# Generated at 2022-06-22 18:35:01.168564
# Unit test for constructor of class Keys
def test_Keys():
    test_obj = Keys('test', exclude='test_exclude')

    # Check items()
    test_dict = {'a': 'a', 'b': 'b'}
    expected_items = [
        ('test', utils.get_shortish_repr(test_dict)),
        ('test[a]', utils.get_shortish_repr(test_dict['a'])),
        ('test[b]', utils.get_shortish_repr(test_dict['b']))
    ]
    assert test_obj.items(None) == expected_items

    # Check __hash__()
    assert test_obj.__hash__() == BaseVariable('test').__hash__()

    # Check __eq__()
    assert test_obj.__eq__(BaseVariable('test'))

# Generated at 2022-06-22 18:35:04.840859
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a.b)')

# Generated at 2022-06-22 18:35:10.146964
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('request', exclude=('COOKIES', 'META'))
    assert a.source == 'request'
    assert a.exclude == ('COOKIES', 'META')
    assert a.code == compile('request', '<variable>', 'eval')
    assert a.unambiguous_source == 'request'


# Generated at 2022-06-22 18:35:17.479720
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable('var_name')
    var.__hash__()
    var.__eq__(var)
    var.items(1,2)
    var.source
    var.exclude
    var.code
    var.unambiguous_source
    var._fingerprint
    var._safe_keys(1)
    var._keys(1)
    var._format_key(1)
    var._get_value(1,2)
    

# Generated at 2022-06-22 18:35:23.204505
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Arrange
    class TestBaseVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ""
    frame = None
    # Act
    test_variable = TestBaseVariable(source="TestSource", exclude="TestExclude")
    test_variable.items(frame)
    # Assert



# Generated at 2022-06-22 18:35:28.283332
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import types
    bv = BaseVariable('hello')
    assert hash(bv) == hash(bv)
    assert hash(bv) != hash(None)
    assert hash(bv) == hash(BaseVariable('hello'))
    assert hash(bv) != hash(BaseVariable('world'))
    assert hash(bv) != hash(BaseVariable('hello', ['world']))
    assert hash(bv) != hash(BaseVariable('hello', 'world'))



# Generated at 2022-06-22 18:35:30.394364
# Unit test for constructor of class Attrs
def test_Attrs():
    variables = Attrs('my_dict')
    assert (variables.source == 'my_dict')
    assert (variables.exclude == ())


# Generated at 2022-06-22 18:35:35.931617
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    main_value = 'hello world'
    class A(BaseVariable):
        def items(self, frame, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value))]

    x = A('main_value')
    y = A('main_value')
    assert x == y
    assert x.__hash__() == y.__hash__()



# Generated at 2022-06-22 18:35:44.143214
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # nothings
    variable = CommonVariable('None')
    items = variable.items(None)
    assert items == [('None', 'None')]
    # A variable
    variable = CommonVariable('self.application')
    items = variable.items(None)
    assert items == [('self.application', '<Application at 0x7f2f93e82470>')]
    # A variable.
    variable = CommonVariable('self.application.name')
    items = variable.items(None)
    assert items == [('self.application.name', '<Application at 0x7f2f93e82470>.name')]



# Generated at 2022-06-22 18:35:51.323510
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # As a necessary condition,  __getitem__ method should return an object of class
    # Indices.
    indices = Indices(source='source', exclude='exclude')
    assert isinstance(indices.__getitem__(slice(None)), Indices)
    # As a necessary condition,  __getitem__ method should return an object which
    # has attribute _slice with value = slice object.
    indices = Indices(source='source', exclude='exclude')
    assert slice(None) == indices.__getitem__(slice(None))._slice
    assert slice(None) == indices[slice(None)]._slice
    # As a necessary condition,  __getitem__ method should return a shallow copy.
    indices_1 = Indices(source='source', exclude='exclude')
    indices_1._slice = slice(None)
   