

# Generated at 2022-06-22 18:25:54.388259
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("var")
    var_slice = var[1:-1]

    valid_var_slice = isinstance(var_slice, Indices) and var_slice._slice == slice(1, -1)
    assert valid_var_slice, "Invalid slice."

# Generated at 2022-06-22 18:25:59.531435
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert needs_parentheses('(x)')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x.y)')
    assert not needs_parentheses('(x.y).z')

    assert not needs_parentheses("'x'")
    assert not needs_parentheses("'x'.y")
    assert not needs_parentheses("'x'.y.z")
    assert needs_parentheses("('x')")
    assert not needs_parentheses("('x').y")
    assert not needs_parentheses("('x'.y)")
    assert not needs_parentheses("('x'.y).z")
    assert needs

# Generated at 2022-06-22 18:26:08.348763
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    #test fails
    for _test in (
            (lambda: CommonVariable('a'), 'source argument'),
            (lambda: CommonVariable('a', 'b'), 'exclude argument'),
            (lambda: CommonVariable('a', 'b'), 'exclude argument'),
            (lambda: CommonVariable('a', exclude='b'), 'exclude argument'),
            (lambda: CommonVariable('a', exclude=1), 'exclude argument'),
    ):
        try:
            _test[0]()
        except TypeError as e:
            assert e.args == (_test[1],)
        except Exception:
            assert False
import pytest
import sys
import utils
from inspect import iscoroutinefunction
from inspect import signature
from contextlib import contextmanager
from contextlib import nullcontext
from contextlib import ExitStack
from contextlib import suppress

# Generated at 2022-06-22 18:26:15.195884
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("a")
    b = Attrs("b")
    c = Keys("c")
    d = Indices("d")

    assert(a == BaseVariable("a"))
    assert(b == Attrs("b"))
    assert(c == Keys("c"))
    assert(d == Indices("d"))

    assert(a != b)
    assert(b != c)
    assert(c != d)
    assert(d != a)

if __name__ == '__main__':
    test_BaseVariable___eq__()

# Generated at 2022-06-22 18:26:26.371310
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def debug(num):
        raise ValueError('msg{}'.format(num))

    def func(a, b, c=1, d=2, *args, **kwargs):
        local = 'local'

# Generated at 2022-06-22 18:26:34.825747
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # 1. test source without parentheses
    except_source = "i"
    source_without_parentheses = "i"
    assert needs_parentheses(source_without_parentheses) == False

    # 2. test source with parentheses
    source_with_parentheses = "(i)"
    assert needs_parentheses(source_with_parentheses) == False

    # 3. test keywords

# Generated at 2022-06-22 18:26:46.258753
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    attrs = Attrs('a')
    assert attrs.source == 'a'
    assert attrs.exclude == ()
    assert attrs.code == compile('a', '<variable>', 'eval')
    assert attrs.unambiguous_source == 'a'

    keys = Keys('b')
    assert keys.source == 'b'
    assert keys.exclude == ()
    assert keys.code == compile('b', '<variable>', 'eval')
    assert keys.unambiguous_source == 'b'

    indc = Indices('c')
    assert indc.source == 'c'
    assert indc.exclude == ()
    assert indc.code == compile('c', '<variable>', 'eval')
    assert indc.unambiguous_source == 'c'


# Generated at 2022-06-22 18:26:49.756875
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable("Test1", "Test2")
    y = BaseVariable("Test3", "Test3")
    z = BaseVariable("Test1", "Test2")
    print(x == y)
    print(x == z)
    print(x.__eq__(y))
    print(x.__eq__(z))


# Generated at 2022-06-22 18:27:01.121074
# Unit test for constructor of class Keys
def test_Keys():
    import datetime
    k = Keys("x")

    class A(object):
        pass

    class B(object):
        def __getattr__(self, item):
            raise AttributeError('Oops')

    a = A()
    b = B()
    a.x = 'a'
    a.x2 = 'b'
    a.x3 = 'c'
    b.x = 'b'
    b.x2 = 'c'
    b.x3 = 'd'
    a.y = 100
    a.z = [1, 2, 3]
    a.d = datetime.datetime.now()
    a._p = a
    a.b = b
    a.a = a
    a.kx = k


# Generated at 2022-06-22 18:27:02.715613
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a' )
    print(a._items(1))
# test_Attrs()

# Generated at 2022-06-22 18:27:09.984680
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Constructor should take source and exclude as parameters
    v = BaseVariable("a")
    assert v.source == "a"
    assert v.exclude == ()

    v = BaseVariable("a", "b")
    assert v.source == "a"
    assert v.exclude == ("b",)

    # Can't create BaseVariable instance directly
    with pytest.raises(TypeError):
        b = BaseVariable("a")



# Generated at 2022-06-22 18:27:12.033868
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('a.b')
    assert keys.source == 'a.b'
# test_Keys()

# Generated at 2022-06-22 18:27:22.565906
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash((BaseVariable, 'a', ()))
    assert hash(BaseVariable('a', exclude=('a',))) == hash((BaseVariable, 'a', ('a',)))

    assert hash(Keys('a')) == hash((Keys, 'a', ()))
    assert hash(Attrs('a')) == hash((Attrs, 'a', ()))
    assert hash(Exploding('a')) == hash((Exploding, 'a', ()))

    assert hash(Indices('a')) == hash((Indices, 'a', ()))
    assert hash(Indices('a')[1:2]) == hash((Indices, 'a', (), slice(1, 2, None)))

    assert hash(Indices('a')) == hash(Indices('a'))

# Generated at 2022-06-22 18:27:28.507821
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable('foo')
    var_2 = BaseVariable('bar')
    var_3 = BaseVariable('foo')
    var_4 = BaseVariable('foo', exclude='z')

    assert var_1 == var_1
    assert var_1 != var_2
    assert var_1 == var_3
    assert var_2 != var_3
    assert var_1 != var_4
    assert var_3 != var_4


variables = {
    'attrs': Attrs,
    'explode': Exploding,
    'keys': Keys,
    'indices': Indices
}

# Generated at 2022-06-22 18:27:32.090938
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('foo', ['bar'])
    ind2 = ind[1:-1]
    assert ind2._slice == slice(1, -1)
    assert ind._slice == slice(None)

# Generated at 2022-06-22 18:27:38.714229
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('a.b.c', exclude=['foo','bar','baz'])
    assert variable.source == 'a.b.c'
    assert variable.exclude == ('foo','bar','baz')
    assert variable.code == compile('a.b.c', '<variable>', 'eval')
    assert variable.unambiguous_source == 'a.b.c'


# Generated at 2022-06-22 18:27:40.508590
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('x')['y':], Indices)


# Generated at 2022-06-22 18:27:51.546852
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'XXX'
    exclude = [3,4]
    a = BaseVariable(source, exclude)
    print(' \nsource= ', a.source, type(a.source), len(a.source))
    print(' \nexclude= ', a.exclude, type(a.exclude), len(a.exclude))
    print(' \na.code= ', a.code, type(a.code))
    print(' \na.unambiguous_source= ', a.unambiguous_source, type(a.unambiguous_source), len(a.unambiguous_source))
    print(' \na._fingerprint= ', a._fingerprint, type(a._fingerprint), len(a._fingerprint))

# Generated at 2022-06-22 18:27:56.187000
# Unit test for constructor of class Exploding
def test_Exploding():
    # Given
    main_value = {'foo':'bar'}
    expected = [['self.source', "<class '__main__.Exploding'>"], [".source", "'foo'"]]

    # When
    exploding = Exploding("self.source")
    actual = exploding._items(main_value)

    # Then
    assert actual == expected



# Generated at 2022-06-22 18:28:01.693385
# Unit test for constructor of class Exploding
def test_Exploding():
    foo = 'foo'
    variables = [(Exploding, 'foo'), (Exploding, 'foo', ('bar',)), (Exploding, 'foo', 'bar')]
    for item in variables:
        obj = item[0](*item[1:])
    assert obj.source == 'foo'
    assert obj.exclude == ('bar',)

# Unit tests for items method of class Exploding

# Generated at 2022-06-22 18:28:04.077299
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('abc')
    assert 'abc' in k.items({})
    #print(k.items({}))


# Generated at 2022-06-22 18:28:12.748439
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import sys
    class MyRepresentation(object):
        def __repr__(self):
            return 'repr'
        def __str__(self):
            return 'str'
    my_representation = MyRepresentation()
    class MyClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = my_representation
        def get_x(self):
            return 'x'
        def get_y(self):
            return 'y'
        @property
        def z(self):
            return 'z'
    my_object = MyClass()
    eval_code = compile('my_object', '<variable>', 'eval')
    eval_frame = sys._getframe()
    eval_frame.f_globals['my_object']

# Generated at 2022-06-22 18:28:18.444422
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
  rec = CommonVariable("args.abc")
  assert rec.source == "args.abc"
  assert rec.exclude == ()
  assert rec.code == compile("args.abc", '<variable>', 'eval')
  assert rec.unambiguous_source == "args.abc"
  assert rec._fingerprint == (CommonVariable, "args.abc", ())
  assert hash(rec) == hash(rec._fingerprint)
  assert isinstance(rec.__eq__(rec), bool)


# Generated at 2022-06-22 18:28:21.126167
# Unit test for constructor of class Keys
def test_Keys():
    # keys = Keys('x', ('values',))
    # print(keys._keys({'a': 1, 'b': 2}))
    pass


# Generated at 2022-06-22 18:28:24.405055
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert isinstance(i, Indices)
    assert isinstance(i, Keys)
    assert isinstance(i, CommonVariable)
    assert isinstance(i, BaseVariable)


# Generated at 2022-06-22 18:28:32.795152
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable(source="self", exclude=("exclude1", "exclude2")) ==\
    BaseVariable(source="self", exclude=("exclude1", "exclude2"))

    BaseVariable(source="self", exclude=("exclude1", "exclude2")) ==\
    BaseVariable(source="other", exclude=("exclude1", "exclude2"))

    assert BaseVariable(source="self", exclude=("exclude1", "exclude2")) ==\
           BaseVariable(source="self", exclude=("exclude1", "exclude2"))

    assert BaseVariable(source="self", exclude=("exclude1", "exclude2")) !=\
           BaseVariable(source="other", exclude=("exclude1", "exclude2"))


# Generated at 2022-06-22 18:28:35.509126
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys("l")
    assert keys.source == "l"
    assert keys.exclude == ()
    assert keys.code == compile("l", '<variable>', 'eval')
    assert keys.unambiguous_source == "l"


# Generated at 2022-06-22 18:28:45.220622
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a.b.c') == False
    assert needs_parentheses('a.b.c.d') == False
    assert needs_parentheses('a.b[1].c.d') == False
    assert needs_parentheses('a[1]') == False
    assert needs_parentheses('a[1][2]') == False
    assert needs_parentheses('a[1][2].b') == False
    assert needs_parentheses('(a)') == True
    assert needs_parentheses('(a)[1]') == True

# Generated at 2022-06-22 18:28:47.051375
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert BaseVariable('x').__hash__() == BaseVariable('x').__hash__()


# Generated at 2022-06-22 18:28:54.064722
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code == compile('a', '<variable>', 'eval')
    b = CommonVariable('b', 'c')
    assert b.source == 'b'
    assert b.exclude == ('c',)
    assert b.code == compile('b', '<variable>', 'eval')



# Generated at 2022-06-22 18:28:58.209238
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('a', exclude=('a', 'b', 'c'))
    b = CommonVariable('a', exclude=('a', 'b', 'c'))

# Generated at 2022-06-22 18:29:02.068003
# Unit test for constructor of class Indices
def test_Indices():
    idx = Indices('x')
    assert idx.source == 'x'
    assert idx.unambiguous_source == 'x'
    assert idx._slice == slice(None)
    assert idx.code


# Generated at 2022-06-22 18:29:04.049849
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('test')
    v2 = BaseVariable('test')
    assert v1 == v2
    assert v1 == BaseVariable('test', exclude=(1, 2, 3))

# Generated at 2022-06-22 18:29:11.706747
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_case_common_var(var_cls, main_value, source,
                        expected_items, normalize):
        def check_returned_items(returned_items):
            assert len(returned_items) == len(expected_items)
            for returned_item, expected_item in zip(returned_items, expected_items):
                assert len(returned_item) == len(expected_item)
                assert returned_item[0] == expected_item[0]
                assert returned_item[1] == expected_item[1]
                assert returned_item[0] == expected_item[0]
                assert returned_item[1] == expected_item[1]

        var = var_cls(source)
        returned_items = var.items(main_value, normalize)
        check_returned

# Generated at 2022-06-22 18:29:17.185474
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a or b')
    assert not needs_parentheses('a.b')
    assert needs_parentheses('a+b')
    assert needs_parentheses('a.b+c')
    assert needs_parentheses('a and b')
    assert needs_parentheses('a or b and c')

# Generated at 2022-06-22 18:29:22.335143
# Unit test for constructor of class Attrs
def test_Attrs():

    # Make sure that Attrs constructor works for the given object
    def check_constructor(obj):
        attr = Attrs(obj)
        assert isinstance(attr, Attrs)

    # Check constructor
    check_constructor(range(5))
    check_constructor({1: 1, 2: 2})
    check_constructor('abc')


# Generated at 2022-06-22 18:29:25.484961
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    A = BaseVariable('source', 'exclude')
    B = BaseVariable('source', 'exclude')
    C = BaseVariable('sources', 'exclude')
    assert B == A
    assert hash(A) == hash(B)
    assert A != C
    assert hash(A) != hash(C)

# Generated at 2022-06-22 18:29:27.921315
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    d = {}
    a = BaseVariable('a')
    d[a] = True

    assert d[a]




# Generated at 2022-06-22 18:29:35.111474
# Unit test for constructor of class Exploding
def test_Exploding():
    ex=Exploding("a.b[1]")
    assert (ex.source=="a.b[1]")
    assert str(ex)=="<Exploding: a.b[1]>"
    assert (ex.exclude==())
    assert ex.unambiguous_source=="a.b[1]"
    ex=Exploding("a.b[1]",exclude=("a.b[1].c",))
    assert (ex.source=="a.b[1]")
    assert (ex.exclude==("a.b[1].c",))
    

# Generated at 2022-06-22 18:29:39.725274
# Unit test for constructor of class Keys
def test_Keys():
    #keys = Keys(main_value, source, exclude=()):
    source = 'main_value'
    exclude = ()
    main_value = {'var1': 1, 'var2': 2}
    keys = Keys(source, exclude)
    assert keys.items(main_value) == [(source, '{var1: 1, var2: 2}', keys._fingerprint)]


# Generated at 2022-06-22 18:29:44.585043
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'x'
    exclude = ()
    exc = Exploding(source, exclude)
    assert exc.source == source
    assert exc.exclude == exclude
    assert exc.code == compile('x', '<variable>', 'eval')
    assert exc.unambiguous_source == 'x'
    return


# Generated at 2022-06-22 18:29:51.120215
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('a')
    assert(keys.source == 'a')
    assert(keys.unambiguous_source == 'a')
    assert(keys.code.co_name == 'co_name')
    assert(keys.code.co_varnames == ('a',))
    assert(keys.code.co_consts == ())
    assert(keys.code.co_filename == '<variable>')
    assert(keys.code.co_flags == 67)



# Generated at 2022-06-22 18:29:54.742678
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('a').__class__.__name__ # TODO: remove
    Indices('a')[1:2].__class__.__name__ # TODO: remove
    assert tuple(Indices('a')[1:2]._items(('123',))) == (('a[1]', "'2'"),)

# Generated at 2022-06-22 18:30:00.585676
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable("a.b");
    assert bv.source == "a.b";
    assert bv.exclude == ();
    bv = BaseVariable("a.b", ["a", "b"])
    assert bv.exclude == ("a", "b");


# Generated at 2022-06-22 18:30:07.299214
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    def test_variable(source, result):
        x = BaseVariable(source).items(frame)
        assert x == result

    test_variable('1', (('1', '1'),))
    test_variable('x', (('x', "NameError: \"name 'x' is not defined\""),))
    test_variable('x[1]', (('x[1]', '[]'),))
    test_variable('{}.y', (('{}.y', 'AttributeError: "{}"'),))

# Generated at 2022-06-22 18:30:17.809935
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    sys.path.append('D:\Documents\PycharmProjects\Projects')
    class test(BaseVariable):
        def __init__(self,source,exclude = ()):
            BaseVariable.__init__(self,source,exclude)
        def _items(self,main_value,normalize=False):
            pass
    t = test('a',('b','c'))
    t.source = 'a'
    t.code = compile('a','<variable>','eval')
    t.unambiguous_source = 'a'
    t._items('a')
    return t._fingerprint

# Generated at 2022-06-22 18:30:26.384807
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("x") is False
    assert needs_parentheses("x.y") is False
    assert needs_parentheses("x.y.z") is False
    assert needs_parentheses("x.y[1]") is False
    assert needs_parentheses("x.y[1].z") is False
    assert needs_parentheses("(x.y)[1].z") is False
    assert needs_parentheses("x.y()") is False
    assert needs_parentheses("x.y()[1].z") is False
    assert needs_parentheses("x[1]") is False
    assert needs_parentheses("x[1].y") is False
    assert needs_parentheses("x[1].y.z") is False
    assert needs_parentheses("x[1][2]") is False
    assert needs

# Generated at 2022-06-22 18:30:31.977247
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import variables

    var1 = variables.Exploding('a')
    var2 = variables.Exploding('a')
    assert var1 == var2
    var3 = variables.Exploding('b')
    assert var1 != var3
    assert var1 != object()


# vim:ts=4 sts=4 sw=4 et

# Generated at 2022-06-22 18:30:36.436530
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    aa = BaseVariable('a')

    assert a == a
    assert (a == b) == False
    assert a == aa
    assert hash(a) == hash(a)
    assert hash(a) == hash(aa)

# Generated at 2022-06-22 18:30:43.332465
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert isinstance(a.code, compile)
    assert a.unambiguous_source == 'a'

    b = Attrs('b', exclude="abc")
    assert b.source == 'b'
    assert b.exclude == ("abc",)
    assert isinstance(b.code, compile)
    assert b.unambiguous_source == 'b'


# Generated at 2022-06-22 18:30:53.844404
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import utils
    from .vars import BaseVariable, Attrs, Keys, Indices, Exploding

    # Inspect current module and find the source code of function test_BaseVariable_items
    test_BaseVariable_items_src = inspect.getsource(utils.get_func_by_name(test_BaseVariable_items.__name__))
    frame = inspect.currentframe()
    frame = inspect.getouterframes(frame, 1)[1][0]

    # Test the class Attrs
    main_value = 'abc'

# Generated at 2022-06-22 18:31:01.944887
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('x', exclude='y')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('(x)')
    assert BaseVariable('x') != BaseVariable('( x )')
    assert BaseVariable('x') != BaseVariable(' x ')
    assert BaseVariable('x') != BaseVariable('x ', exclude='y')
    assert BaseVariable('x') != BaseVariable('x ', exclude=('y',))
    assert BaseVariable('x') != Attrs('x')
    assert BaseVariable('x') != Keys('x')
    assert BaseVariable('x') != Indices('x')
    assert BaseVariable('x') != Exploding('x')
    assert BaseVariable('x') != object()

# Generated at 2022-06-22 18:31:13.155306
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x')
    assert ind._slice == slice(None)
    ind1 = ind[:]
    assert ind1._slice == slice(None)
    ind1 = ind[1:]
    assert ind1._slice == slice(1, None)
    ind1 = ind[:1]
    assert ind1._slice == slice(None, 1)
    ind1 = ind[1:2]
    assert ind1._slice == slice(1, 2)
    ind1 = ind[1:2:3]
    assert ind1._slice == slice(1, 2, 3)
    ind1 = ind[::3]
    assert ind1._slice == slice(None, None, 3)
    ind1 = ind[2:2:3]
    assert ind1._slice == slice(2, 2, 3)
    ind1

# Generated at 2022-06-22 18:31:24.151617
# Unit test for constructor of class Keys
def test_Keys():

    variable = Keys("key")
    if variable.exclude != ():
        raise Exception("exclude should be empty, not {}".format(variable.exclude))
    if variable.source != "key":
        raise Exception("source should be key, not {}".format(variable.source))

    variable = Keys("key", "exclude_key")
    if variable.exclude != ("exclude_key",):
        raise Exception("exclude should be exclude_key, not {}".format(variable.exclude))
    if variable.source != "key":
        raise Exception("source should be key, not {}".format(variable.source))

    variable = Keys("key", ("exclude_key1", "exclude_key2"))

# Generated at 2022-06-22 18:31:26.164746
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('hello')) == hash(BaseVariable('hello'))


# Generated at 2022-06-22 18:31:35.901670
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("d")
    assert a.source == "d"
    assert a.exclude == ()
    assert a.code == compile("d", '<variable>', 'eval')
    assert a.unambiguous_source == "d"
    assert a._slice == slice(None)
    assert a._fingerprint == (Indices, "d", ())
    assert type(a.__dict__) == dict
    assert all(hasattr(a, attr) for attr in ["source", "exclude", "code", "unambiguous_source", "_slice", "_fingerprint"])
    a = Indices("d", "e")
    assert a.source == "d"
    assert a.exclude == ("e",)
    a = Indices("d", ["e", "f"])

# Generated at 2022-06-22 18:31:41.671179
# Unit test for constructor of class Keys
def test_Keys():
    test_dict = {'a': 1,
                 'b': 2}
    test_Keys = Keys('test_dict')
    result = test_Keys.items(frame=frame, normalize=False)
    assert len(result) == 3, "len(_) == 3"
    for k, v in result:
        assert k in ('test_dict', 'test_dict[a]', 'test_dict[b]'), \
            "test_dict[k] in ('test_dict', 'test_dict[a]', 'test_dict[b]')"
        assert v in ('1', '2'), "test_dict[v] in ('1', '2')"

# Generated at 2022-06-22 18:31:47.171439
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('var')._get_class([]), Indices)
    assert isinstance(Exploding('var')._get_class({}), Keys)
    assert isinstance(Exploding('var')._get_class(''), Attrs)
    assert isinstance(Exploding('var')._get_class('123'), Attrs)



# Generated at 2022-06-22 18:31:50.869818
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert set(CommonVariable('var', 'exclude').items({'var': {'a': 'b', 'c': 'd'}})) == \
           {('var', '{...}'), ('var.a', "'b'"), ('var.c', "'d'")}



# Generated at 2022-06-22 18:31:53.559387
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class BaseVariableTest(BaseVariable):
        pass

    try:
        BaseVariableTest()
        assert False, 'Should have raised TypeError'
    except TypeError:
        pass


# Unit tests for constructor of class BaseVariable

# Generated at 2022-06-22 18:31:54.785832
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable("test")



# Generated at 2022-06-22 18:31:58.960127
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    B = BaseVariable('a','b')
    assert B.source == 'a'
    assert B.exclude == ('b',)
    assert B.code == compile('a', '<variable>', 'eval')
    assert B.unambiguous_source == 'a'


# Generated at 2022-06-22 18:32:10.848251
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Case: when comparing with non-BaseVariable variables, return False
    pbs_variable = BaseVariable('pbs', ())
    int_variable = 1
    assert pbs_variable.__eq__(int_variable) == False

    # Case: when comparing with two  variables of two different classes, return False
    another_pbs_variable = BaseVariable('pbs', ())
    different_variable = Attrs('pbs', ())
    assert pbs_variable.__eq__(different_variable) == False

    # Case: when comparing with two variables with same source and exclude, return True
    assert pbs_variable.__eq__(another_pbs_variable) == True

    # Case: when comparing with two variables with different exclude but same source, return False
    another_exclude = ("1", "2")
    another_pbs_variable_

# Generated at 2022-06-22 18:32:12.611053
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('x')



# Generated at 2022-06-22 18:32:19.405342
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
  x = BaseVariable(source='ans', exclude=('ans','s','es','s','es'))
  y = BaseVariable(source='ans', exclude=('ans','s','es','s','es'))
  assert(x==y)
  assert(x!=None)
  assert(x!=BaseVariable(source='ans'))
  assert(x!=BaseVariable(source='ans', exclude=('ans')))


# Generated at 2022-06-22 18:32:23.963858
# Unit test for constructor of class Attrs
def test_Attrs():
    foo = Attrs('foo')
    assert foo.source == 'foo'
    assert foo.exclude == ()
    assert foo.unambiguous_source == 'foo'
    assert foo.code == compile('foo', '<variable>', 'eval')
    assert foo._fingerprint == (Attrs, 'foo', ())
    assert foo._safe_keys != None
    assert foo._keys != None
    assert foo._format_key != None
    assert foo._get_value != None


# Generated at 2022-06-22 18:32:26.387239
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'a'
    variable = BaseVariable(source, exclude='hello.')
    assert hash(variable) == hash((BaseVariable, source, ('hello.',)))



# Generated at 2022-06-22 18:32:38.004996
# Unit test for constructor of class Exploding
def test_Exploding():
    class Foo:
        def __init__(self):
            self.x = 7
            self.y = 'foobar'
            self.z = [1, 2, 3]
    a = Foo()
    b = Exploding('a')
    # test mapping
    assert b._items({'x': 3, 'y': 'qwerty'}) == [('a', '{}'), ('a["x"]', '3'), ('a["y"]', '"qwerty"')]
    # test sequence
    assert b._items([1, 2, 3]) == [('a', '[1, 2, 3]'), ('a[0]', '1'), ('a[1]', '2'), ('a[2]', '3')]
    # test class object

# Generated at 2022-06-22 18:32:40.385937
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert set(CommonVariable('a.b.c', exclude='b').items(None)) == set([
        ('a.b.c', "unknown"),
        ('(a.b).c', "unknown")
    ])

# Generated at 2022-06-22 18:32:42.352167
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    test = BaseVariable('x')
    assert isinstance(test.__hash__(), int)


# Generated at 2022-06-22 18:32:49.924217
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .. import utils

    normalize = True
    values = list(range(11))
    indices = Indices(values, normalize=normalize)
    assert indices == (('[0]', '0'), ('[1]', '1'), ('[2]', '2'), ('[3]', '3'), ('[4]', '4'), ('[5]', '5'), ('[6]', '6'), ('[7]', '7'), ('[8]', '8'), ('[9]', '9'), ('[10]', '10'))

    indices2 = indices[1:4]
    assert indices2 == (('[1]', '1'), ('[2]', '2'), ('[3]', '3'))

    indices3 = indices[5:]

# Generated at 2022-06-22 18:32:54.025582
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class DummyPoint1(BaseVariable): pass

    class DummyPoint2(BaseVariable): pass

    d1 = DummyPoint1("1")
    d2 = DummyPoint2("1")
    d3 = DummyPoint1("1")
    assert d1 != d2
    assert d1 != d3

# Generated at 2022-06-22 18:33:00.975556
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Test method __eq__ of class BaseVariable
    >>> class Test(BaseVariable):
    ...     def _items(self, main_value, normalize=False):
    ...         pass

    # Test: two same variables are equal
    >>> v1 = Test('s1')
    >>> v2 = Test('s1')
    >>> v1 == v2
    True

    # Test: two variables with different source are not equal
    >>> v3 = Test('s2')
    >>> v1 == v3
    False

    # Test: two variables with different exclude are not equal
    >>> v4 = Test('s1', exclude=['e1'])
    >>> v1 == v4
    False
    """
    pass

# Generated at 2022-06-22 18:33:12.152803
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    frame = inspect.currentframe()
    variable_1 = BaseVariable('source_name')
    variable_2 = BaseVariable('source_name')
    variable_3 = BaseVariable('source_name', 'exclude_name')
    variable_4 = BaseVariable('source_name', 'exclude_name')
    variable_5 = BaseVariable('source_name', ['exclude_name'])
    variable_6 = BaseVariable('source_name', ['exclude_name'])
    variable_7 = BaseVariable('source_name', frame)
    variable_8 = BaseVariable('source_name', frame)

    assert (hash(variable_1) == hash(variable_2))
    assert (hash(variable_1) != hash(variable_3))
    assert (hash(variable_3) == hash(variable_4))

# Generated at 2022-06-22 18:33:15.781787
# Unit test for constructor of class Exploding
def test_Exploding():
    import pandas as pd
    arr = pd.Series([1, 2, 3])
    # in pandas 0.x, len(arr) is 1
    assert len(Exploding('arr').items(dict(arr=arr))[0][1]) > 1

# Generated at 2022-06-22 18:33:18.733089
# Unit test for constructor of class Indices
def test_Indices():
    var1 = Indices("item")
    assert var1._slice == slice(None)

    var2 = var1[1:5]
    assert var2._slice == slice(1,5)

# Generated at 2022-06-22 18:33:30.148349
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import pytest
    # Testing with class Attr
    a = Attrs('item')
    assert a.source == 'item'
    assert a.code == compile('item', '<variable>', 'eval')
    assert a.unambiguous_source == '(item)'
    with pytest.raises(NotImplementedError):
        a._items(4)
    # Testing with class Keys
    b = Keys('item')
    assert b.source == 'item'
    assert b.code == compile('item', '<variable>', 'eval')
    assert b.unambiguous_source == '(item)'
    with pytest.raises(NotImplementedError):
        b._items(4)
    # Testing with class Indices
    c = Indices('item')
    assert c.source == 'item'
    assert c

# Generated at 2022-06-22 18:33:34.175293
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('x', exclude=['a'])
    v2 = BaseVariable('x', exclude=['a'])
    assert hash(v1) == hash(v2)


# Generated at 2022-06-22 18:33:44.031774
# Unit test for constructor of class Exploding
def test_Exploding():
    # 1.
    class A():
        pass
    a = A()
    result = Exploding('a')._items(a)
    expected = [
        ('a', '<test_exploding.A object at 0x...>'),
        ('a.__class__', '<class \'test_exploding.A\'>'),
        ('a.__doc__', 'None'),
        ('a.__module__', 'test_exploding'),
    ]
    assert result == expected

    # 2.
    class B(dict):
        pass
    b = B()
    result = Exploding('b')._items(b)
    expected = [('b', '<test_exploding.B object at 0x...>')]
    assert result == expected

    # 3.
    class C(list):
        pass

# Generated at 2022-06-22 18:33:44.917316
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('a["b"]')

# Generated at 2022-06-22 18:33:57.337920
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import types
    import builtins

    frame = inspect.currentframe()
    d = {'param_1': 1, 'param_2': 2, 'param_3': 3}
    t = (1, 2, 3)
    l = [1, 2, 3]

    variable = BaseVariable('d', exclude='param_2')
    assert variable.items(frame) == [('d', '{...}'), ('d.param_1', '1'), ('d.param_3', '3')]
    variable = BaseVariable('t', exclude=1)
    assert variable.items(frame) == [('t', '(1, 2, 3)'), ('t[0]', '1'), ('t[2]', '3')]
    variable = BaseVariable('l')

# Generated at 2022-06-22 18:34:01.289766
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("local_var")
    assert needs_parentheses("42")
    assert needs_parentheses("x")
    assert not needs_parentheses("(local_var)")
    assert not needs_parentheses("(x)")

# Generated at 2022-06-22 18:34:04.550528
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Test for hash()
    var1 = BaseVariable('source', exclude='exclude')
    var2 = BaseVariable('source', exclude='exclude')
    assert var1.__hash__() == var2.__hash__()


# Generated at 2022-06-22 18:34:06.931237
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('foo')
    assert indices.source == 'foo'
    assert indices.unambiguous_source == 'foo'
    assert indices._slice == slice(None)


# Generated at 2022-06-22 18:34:15.620377
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import random
    frame = sys._getframe()
    f = lambda x: sorted(BaseVariable(x, xrange(10)).items(frame))

# Generated at 2022-06-22 18:34:17.623762
# Unit test for constructor of class Keys
def test_Keys():
    from .data import test_name

    Keys(test_name)

# Generated at 2022-06-22 18:34:26.740340
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('a', 'b').source == 'a'
    assert BaseVariable('a', 'b').exclude == ('b',)
    assert BaseVariable('a', exclude='b').exclude == ('b',)
    assert BaseVariable('a', exclude=['b']).exclude == ('b',)
    assert BaseVariable('a', 'b').code.co_code == compile('a', '<string>', 'eval').co_code
    assert BaseVariable('a', 'b').unambiguous_source == 'a'
    assert BaseVariable('(a)', 'b').unambiguous_source == '(a)'
    assert BaseVariable('a.b', 'b').unambiguous_source == '(a.b)'

# Generated at 2022-06-22 18:34:30.614345
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a':1, 'b':2}
    assert len(Keys('a', exclude=['a']).items(d)) == 3



# Generated at 2022-06-22 18:34:32.820721
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('a', 'b')
    frame = {}
    variable.items(frame)

# Generated at 2022-06-22 18:34:40.714303
# Unit test for constructor of class Keys
def test_Keys():
    kv = Keys("foo", ("b","c"))
    assert(kv.source=='foo')
    assert(kv.exclude==('b', 'c'))
    assert(kv.code==compile('foo', '<variable>', 'eval'))
    assert(kv.unambiguous_source=='foo')
    # Some items
    assert(kv._items('root') == [('foo', "'root'")])
    assert(kv._items({}) == [('foo', '{}')])
    assert(False == (kv._items({}) == [('bar', '{}')]))
    assert(kv._items({'a':1}) == [('foo', "{'a': 1}"), ('foo[a]', '1')])
    # _safe_keys

# Generated at 2022-06-22 18:34:42.848208
# Unit test for constructor of class Indices
def test_Indices():
    assert type(Indices('foo')[1:]) == Indices


# Generated at 2022-06-22 18:34:45.918212
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a = {'k1':'v1', 'k2':'v2'}
    source = 'a'
    exclude = ('k1',)
    var = BaseVariable(source, exclude)
    assert (var.items(a) == ())

# Generated at 2022-06-22 18:34:46.777647
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass


# Generated at 2022-06-22 18:34:49.157520
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Example 1
    v1 = Indices('x')
    assert v1[1] == Indices('x', slice(1, None))

# Generated at 2022-06-22 18:34:53.203283
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs.__init__.__doc__ == '''\
        @summary: Creates a new instance of Attrs.
        @param source: Source
        @param exclude: Iterable of extra arguments
        @raise  TypeError: If *source* is not a string'''

# Generated at 2022-06-22 18:34:59.439520
# Unit test for constructor of class Indices
def test_Indices():
    test_str1 = "a"*20
    test_str2 = "b"*40
    test_str3 = "c"*60
    test_str4 = "d"*80
    test_list = [test_str1, test_str2, test_str3, test_str4]
    print(Indices("")._items(test_list))
    print(Indices("")[:2]._items(test_list))
    print(Indices("")[:4:2]._items(test_list))

# Generated at 2022-06-22 18:35:02.283170
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a.b.c')
    assert(k.source == 'a.b.c')
    assert(k.unambiguous_source == 'a.b.c')
    assert(k.code is not None)


# Generated at 2022-06-22 18:35:09.829140
# Unit test for constructor of class Keys
def test_Keys():
    code = compile('main', '<variable>', 'eval')
    assert code.co_name == 'main'
    v = Keys('main')
    assert v.source == 'main'
    assert v.code == code
    assert v.unambiguous_source == 'main'
    assert isinstance(v.exclude, tuple)
    assert v.exclude == ()
    assert isinstance(v._fingerprint, tuple)
    assert v._fingerprint == (Keys, 'main', ())



# Generated at 2022-06-22 18:35:12.739026
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from inspect import currentframe
    cf = currentframe()
    assert CommonVariable('cf.f_lineno')
    for v in [Attrs, Keys, Indices]:
        assert CommonVariable(v)


# Generated at 2022-06-22 18:35:24.256861
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    while True:
        frame = sys._getframe(3)
        if frame is not None:
            break
    # set 3 levels above
    local_var_dict = inspect.trace()[2][0].f_locals
    frame.f_locals.update(local_var_dict)

    # test Attrs
    assert Attrs('sys').items(frame) == [('sys', '<module \'sys\' (built-in)>')]
    assert Attrs('sys.modules').items(frame) == [('sys.modules', '{}')]

# Generated at 2022-06-22 18:35:26.835880
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs("source")
    print(a.source)
    print(type(a.source))
    assert(a.source == "source")


# Generated at 2022-06-22 18:35:32.740553
# Unit test for constructor of class Exploding
def test_Exploding():
    print("Exploding test case 1:")
    print("Expected: 2, 1, one")
    ex = Exploding("ex")
    ex.items("")
    print("Actual:")
    print("Exploding test case 2:")
    print("Expected: 2, 1, one")
    ex = Exploding("ex")
    ex.items("")
    print("Actual:")
    print("Exploding test case 3:")
    print("Expected: 2, 1, one")
    ex = Exploding("ex")
    ex.items("")
    print("Actual:")


# Generated at 2022-06-22 18:35:35.038439
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('name')
    assert indices.__getitem__(slice(1, 7, 2))

# Generated at 2022-06-22 18:35:41.500533
# Unit test for constructor of class Attrs
def test_Attrs():
    from copy import deepcopy
    from .utils import ensure_tuple
    v = Attrs("a_string","a_string")
    assert(isinstance(v.source,"str"))
    assert(v.source=="a_string")
    assert(v.exclude==("a_string",))
    assert(isinstance(v.code,code))
    assert(v.code.co_filename=="<variable>")
    assert(v.code.co_firstlineno==1)
    assert(v.code.co_name=="<module>")
    assert(v.code.co_argcount==0)
    assert(v.code.co_varnames==())
    v = Attrs("a_string")
    assert(v.exclude==())

# Generated at 2022-06-22 18:35:49.780225
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert( (BaseVariable('x',exclude='y') == BaseVariable('x',exclude='y')) == True )
    assert( (BaseVariable('x',exclude='y')==BaseVariable('x',exclude='z')) == False )
    assert( BaseVariable('x',exclude='y') == BaseVariable('x') == False )
    assert( (BaseVariable('x',exclude='y') == BaseVariable('y',exclude='x')) == False )
    assert( (BaseVariable('x',exclude='y') == BaseVariable('x',exclude='y',source='y')) == False )
    assert( (BaseVariable('x',exclude='y') == BaseVariable('y',exclude='x',source='x')) == False )

test_BaseVariable___eq__()
