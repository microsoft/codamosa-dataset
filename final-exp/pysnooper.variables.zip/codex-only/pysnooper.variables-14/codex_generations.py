

# Generated at 2022-06-22 18:25:55.233488
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('a.b').items == Attrs('a.b').items
    assert Attrs('a.b').items != Attrs('a.c').items
    assert Attrs('a.b').items != Attrs('b.b').items
    assert Attrs('a.b').items != Keys('a.b').items

# Generated at 2022-06-22 18:26:04.509731
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Model(object):
        def __init__(self, f: int, name: str = 'abc'):
            self.f = f
            self.name = name

    model = Model(3)
    frame = inspect.currentframe()
    assert (type(frame).__name__ == 'frame')
    assert (frame.f_globals is not None)
    assert (type(frame.f_locals).__name__ == 'dict')
    model_dict = {'a': 'a', 'b': 'b', 'c': 'c'}
    model_list = ['a1', 'b1', 'c1']
    obj = {
        'model': model,
        'model_dict': model_dict,
        'model_list': model_list
    }

# Generated at 2022-06-22 18:26:09.926414
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('source')
    assert isinstance(i, Indices)
    assert len(i.__dict__) == 4
    assert i.source == 'source'
    assert i.exclude == ()
    assert i.code == compile('source', '<variable>', 'eval')
    assert i._slice == slice(None)
    assert i._fingerprint == (Indices, 'source', ())
    assert i.__hash__() == hash(i._fingerprint)
    assert i.__eq__(i) == True



# Generated at 2022-06-22 18:26:16.526117
# Unit test for constructor of class Exploding
def test_Exploding():
    assert sorted(list(Indices('*').items(0))) == sorted([('*', '0')])
    assert sorted(list(Keys('*').items({'a':1}))) == sorted([('*', "{'a': 1}"), ('*["a"]', '1')])
    assert sorted(list(Indices('*').items([1,2,3]))) == sorted([('*[0]' ,'1'), ('*[1]' ,'2'), ('*[2]' ,'3'), ('*', '[1, 2, 3]')])

# Generated at 2022-06-22 18:26:23.390915
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('abc').source == 'abc'
    assert CommonVariable('abc').exclude == ()
    assert CommonVariable('abc').unambiguous_source == 'abc'
    assert CommonVariable('(abc)').unambiguous_source == '(abc)'
    assert CommonVariable('(abc)').code == compile('(abc)', '<variable>', 'eval')


# Generated at 2022-06-22 18:26:28.329011
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != object()


# Generated at 2022-06-22 18:26:33.423305
# Unit test for constructor of class Attrs
def test_Attrs():
    import pytest

    class A:
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __repr__(self):
            return 'A({}, {})'.format(self.x, self.y)

    a = A(1, 2)
    assert Attrs('').source == ''
    assert Attrs('a').source == 'a'
    assert Attrs('a').exclude == ()
    assert Attrs('a', ()).source == 'a'
    assert Attrs('a', ()).exclude == ()
    assert Attrs('a', 'b').source == 'a'
    assert Attrs('a', 'b').exclude == ('b',)
    assert Attrs('a', 'b', 'c').source == 'a'
    assert Attrs

# Generated at 2022-06-22 18:26:37.968297
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('lambda x, y: x + y')
    assert not needs_parentheses('(lambda x, y: x + y)')



# Generated at 2022-06-22 18:26:48.131896
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TempVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    tempVariable = TempVariable("main_value", exclude='exclude')
    frame = {}
    frame['main_value'] = [1, 2, 3]
    assert tempVariable.items(frame, normalize=False) == [
        ('main_value', '[1, 2, 3]')]
    assert tempVariable.items(frame, normalize=True) == [
        ('main_value', '[1, 2, 3]')]
    frame['main_value'] = {}
    assert tempVariable.items(frame, normalize=False) == [
        ('main_value', '{}')]


# Generated at 2022-06-22 18:26:51.922625
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo.bar') == Keys('foo.bar')
    assert Keys('foo.bar') != Keys('bar.bar')
    assert Keys('foo.bar') != Keys('foo.bar', exclude=['a'])
    assert Keys('foo.bar') != Keys('foo.bar', exclude=('a',))
    assert Keys('foo.bar', exclude=['a']) == Keys('foo.bar', exclude=('a',))



# Generated at 2022-06-22 18:26:55.537791
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    a = Attrs('a', 'b')
    assert a.exclude == ('b',)

# Generated at 2022-06-22 18:27:03.746045
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    # Test that nothing raise an Exception
    ok_source_values = [
        'a',
        'a.b',
        'a.b[2]',
        'a.b[2].c',
        'a.b[2].c.d',
        'a.b[2].c.d()',
    ]
    for source in ok_source_values:
        class A(BaseVariable):
            pass
        A(source)

    # Test that some values raise an Exception
    wrong_source_values = [
        '.a',
        'a[2].b',
    ]
    for source in wrong_source_values:
        class A(BaseVariable):
            pass
        with pytest.raises(Exception):
            A(source)



# Generated at 2022-06-22 18:27:13.482610
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x(1)')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('(x)(1)')
    assert needs_parentheses('x.y[1]')
    assert needs_parentheses('(x).y[1]')
    assert not needs_parentheses('x[1].y')
    assert not needs_parentheses('(x[1]).y')
    assert not needs_parentheses('x.y(1)')
    assert not needs_parentheses('(x).y(1)')
    assert needs_parentheses('x[1].y(1)')
    assert needs_parentheses('(x[1]).y(1)')

# Generated at 2022-06-22 18:27:16.776921
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bv = BaseVariable('frame.f_abstractsyntax', exclude=(1,))
    print(bv.items(frame))
    print(bv.items(frame, normalize=True))


# Generated at 2022-06-22 18:27:19.611266
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('x', exclude=['yo'])
    x.source
    x.exclude
    x.code
    x.unambiguous_source


# Generated at 2022-06-22 18:27:25.325314
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def function(func):
        def wrapper(source, *args, **kwargs):
            assert func(source, *args, **kwargs) is True
        return wrapper

    @function
    def check(source, *args, **kwargs):
        variable = BaseVariable(source, *args, **kwargs)
        items = variable.items(sys._getframe())
        return items is not None
    
    check('1')
    check('1', ['a'])
    check('1', 'a')


# Generated at 2022-06-22 18:27:33.103927
# Unit test for constructor of class Indices
def test_Indices():
    from inspect import currentframe
    from string import ascii_uppercase

    # item slice not implemented yet
#    i = Indices('l')[0:3]
#    print(i._slice, i._keys(ascii_uppercase))
#    assert 0 == 1
    
    i = Indices('l')
    print(i._keys(ascii_uppercase))

if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-22 18:27:44.177233
# Unit test for constructor of class Attrs
def test_Attrs():
    keys = Attrs('a')._keys(None)
    assert next(keys) == '__dict__'

    keys = Attrs('a')._keys(object())
    assert next(keys) == '__dict__'

    class A(object):
        pass
    keys = Attrs('a')._keys(A())
    assert next(keys) == '__dict__'

    class A(object):
        __slots__ = ('b',)
    keys = Attrs('a')._keys(A())
    assert next(keys) == 'b'

    class A(object):
        __slots__ = ('b',)
        def __init__(self):
            self.b = 1
    keys = Attrs('a')._keys(A())
    assert next(keys) == 'b'


# Generated at 2022-06-22 18:27:49.334165
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('abc', exclude=('__class__',))
    assert set(indices._keys('hello')) == set(range(len('hello')))
    assert indices[2:3]._slice == slice(2, 3)
    assert indices[2:] ._slice == slice(2, None)

# Generated at 2022-06-22 18:27:58.525540
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    BaseVariable derived classes only add code for output string formatting and
    recursion, which is independently tested.
    This tests the functionality of method items common to all derived classes.
    '''
    _context = {'foo_1': 1, 'foo': {'bar': 2}, 'foo_2': 3, 'foobar': 4, 'bar_1': 5}
    _context['_context'] = _context
    _frame = {'f_locals': _context, 'f_globals': _context}
    # Test exclude attribute
    result = Attrs('', exclude='bar').items(_frame)
    assert 'bar' not in [v for k, v in result]
    result = Attrs('_context', exclude='bar').items(_frame)

# Generated at 2022-06-22 18:28:07.743268
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x')[:] == Indices('x')[:10] == Indices('x')[:100] == Indices('x')[-100:]
    assert Indices('x')[:] != Indices('y')
    assert Indices('x')[:10] != Indices('x')[:11]
    assert Indices('x')[:10] != Indices('x')[10:]
    assert Indices('x')[:10] != Indices('x')[11:]
    assert Indices('x')[:10] != Indices('x')[:10,]
    assert Indices('x')[:] != Indices('x')[:,]
    assert Indices('x')[:] != Indices('x')[:-1]

# Generated at 2022-06-22 18:28:12.004863
# Unit test for constructor of class Exploding
def test_Exploding():
    E = Exploding('foo')
    assert E.source == E.unambiguous_source == 'foo'
    assert E.exclude == ()
    assert E.code == compile('foo', '<variable>', 'eval')
    assert E.items is not Exploding.items
    assert isinstance(E.items, CommonVariable._items.__func__)



# Generated at 2022-06-22 18:28:14.152493
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('main_value', exclude=()).__getitem__(slice(4, 5)).items('main_value')

# Generated at 2022-06-22 18:28:24.272099
# Unit test for constructor of class Indices
def test_Indices():
    id1 = Indices('arg1')
    assert id1.source == 'arg1'
    assert not id1.exclude
    id2 = Indices('arg2', exclude=('b', 'a'))
    assert id2.source == 'arg2'
    assert id2.exclude == ('b', 'a')
    assert id2._slice == slice(None)
    assert not id2.unambiguous_source
    assert id1._slice == slice(None)
    # assert id1._keys('123') == [0, 1, 2]
    # assert id1._format_key('a') == a
    # assert id1._get_value('12', 'a') == None
    assert id1.items("123") == [('arg1', '\'123\'')]

# Generated at 2022-06-22 18:28:33.090005
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Note: this test only ensures that the constructor gives the right result
    # no internal check is made to see if the parent class of CommonVariable has the same code.
    
    # TODO : test the following conditions
    # 1. _keys: if value is not a dict or list
    # 2. _format_key: if key is not a str
    # 3. _get_value: if value is neither a dict nor a list

    # test CommonVariable class constructed with a dict
    a = {'a': 1, 'b': 2}
    v = CommonVariable('a', exclude='a')
    res = v._items(a, normalize=False)
    exp = [('a', '{...}'), ('a.b', '2')]
    assert res == exp

    # test CommonVariable class constructed with a list

# Generated at 2022-06-22 18:28:39.102001
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert(BaseVariable('a') == BaseVariable('a'))
    assert(BaseVariable('a') != BaseVariable('b'))
    assert(BaseVariable('a') != Attrs('a'))
    assert(Attrs('a') == Attrs('a'))
    assert(Attrs('a') != Attrs('b'))
    assert(Attrs('a') != Keys('a'))
    assert(Keys('a') == Keys('a'))
    assert(Keys('a') != Keys('b'))
    assert(Keys('a') != Indices('a'))
    assert(Indices('a') == Indices('a'))
    assert(Indices('a') != Indices('b'))
    assert(Indices('a') != Exploding('a'))

# Generated at 2022-06-22 18:28:50.406998
# Unit test for constructor of class Attrs
def test_Attrs():
    # Defining a dummy class with dummy members to test
    class Dummy(object):
        __dict__ = {'member_1': 1, 'member_2': 2}
        member_3 = 3
        def __init__(self):
            self.member_4 = 4
        def method_1(self):
            pass
    # Assigning a dummy class object to a variable
    dummy1 = Dummy()
    # Defining another object to test excluding a member
    dummy2 = Dummy()
    dummy2.member_2 = 'string'
    # Testing with a variable name and no excluded members
    variable = Attrs('dummy1')
    # Testing
    assert variable.source == 'dummy1'
    assert variable._fingerprint == (Attrs, 'dummy1', ())

# Generated at 2022-06-22 18:28:55.921158
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('var')
    assert var._slice == slice(None)
    var[2:4] = Indices('var[2:4]')
    assert var._slice == slice(2, 4)
    # Test of __getitem__ without argument
    with pytest.raises(AssertionError):
        var.__getitem__(Indices('var.__getitem__'))

# Generated at 2022-06-22 18:29:00.145115
# Unit test for constructor of class Keys
def test_Keys():
    class A(object):
        def __init__(self):
            self.x=1
            self.__y='y'
    a=A()
    assert Keys('a')._keys(a) == ['x','__y']

# Generated at 2022-06-22 18:29:08.065009
# Unit test for constructor of class Exploding
def test_Exploding():
    dict_ = dict(a=1)
    list_ = list(dict_)
    other = "a"
    assert Exploding("var", exclude="a").items(None, dict_) == [("var", "{'a': 1}")]
    assert Exploding("var", exclude="a").items(None, list_) == [("var", "[{'a': 1}]")]
    assert Exploding("var", exclude="a").items(None, other) == [("var", "'a'")]



# Generated at 2022-06-22 18:29:13.769953
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from post_mortem.config.variables import BaseVariable
    print(BaseVariable('test').__eq__(1))
    print(BaseVariable('test').__eq__('test'))
    print(BaseVariable('test').__eq__(BaseVariable('test')))
    print(BaseVariable('test').__eq__(BaseVariable('Test')))
    print(BaseVariable('test').__eq__(BaseVariable('test', 'test')))



# Generated at 2022-06-22 18:29:16.555252
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('a', exclude=('c', 'd'))
    source = var.source
    exclude = var.exclude


# Generated at 2022-06-22 18:29:23.349357
# Unit test for constructor of class Exploding
def test_Exploding():
    mapping = {'x': 0, 'y': 1}
    keys = Exploding('mapping')
    assert keys.source == 'mapping'
    assert keys.items(mapping) == Keys('mapping').items(mapping)
    assert keys.items(()) == Indices('mapping').items(())
    assert keys.items('') == Indices('mapping').items('')
    assert keys.items(object()) == Attrs('mapping').items(object())

test_Exploding()

# Generated at 2022-06-22 18:29:26.373231
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a', exclude=['a'])
    assert BaseVariable('b') != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude=['a', 'b'])


# Generated at 2022-06-22 18:29:28.489913
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding("v"), Exploding)
    assert isinstance(Exploding("v", "a"), Exploding)


# Generated at 2022-06-22 18:29:34.051376
# Unit test for constructor of class Attrs
def test_Attrs():
    class Foo:
        ''' class for unit test of Attrs'''
        def __init__(self):
            self.bar = 123
            self.baz = [1,2,3]

    f = Foo()
    with pytest.raises(AttributeError):
        a = Attrs("foo.bar", exclude=("bar"))
    with pytest.raises(AttributeError):
        a = Attrs("foo.bar", exclude=("qux"))

# Generated at 2022-06-22 18:29:38.783798
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "a"
    code = compile(source, '<variable>', 'eval')
    bv = BaseVariable(source)
    assert bv.source == source
    assert bv.exclude == ()
    assert bv.code == code
    assert bv._fingerprint == (BaseVariable, source, ())
    assert bv.unambiguous_source == source


# Generated at 2022-06-22 18:29:43.277194
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('testVar')
    assert a.source == 'testVar'
    assert a.exclude == []
    assert a._fingerprint == (Attrs, 'testVar', ())
    assert a.items(1) == [('testVar', '1')]


# Generated at 2022-06-22 18:29:44.186277
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('a').items(None) == []

# Generated at 2022-06-22 18:29:54.170489
# Unit test for constructor of class Exploding
def test_Exploding():
    d = {'a':1}
    assert Exploding('d')._items(d) == Keys('d')._items(d)
    assert Exploding('d[1]')._items(d) == Keys('d[1]')._items(d)
    assert Exploding('t[1]')._items(d) == Keys('t[1]')._items(d)
    assert Exploding('d.a')._items(d) == Attrs('d.a')._items(d)
    assert Exploding('a')._items(d) == Attrs('a')._items(d)
    assert Exploding('a')._items(d) == Attrs('a')._items(d)
    l = [1]
    assert Exploding('l')._items(l) == Indices('l')._items(l)
   

# Generated at 2022-06-22 18:30:00.968388
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = BaseVariable('x', exclude=())
    d = {'x':1}
    y = BaseVariable('y', exclude=())
    d['y'] = 2
    z = BaseVariable('z', exclude=())
    d['z'] = {'zz':3}
    d['z']['z'] = {'z2':4}
    w = BaseVariable('w', exclude=())
    d['w'] = [5, 6, 7]
    d['w'][1] = {'ww':8}
    d['w'][2] = [[9]]
    items = x.items(d)
    assert items == [('x', '1')]
    items = y.items(d)
    assert items == [('y', '2')]
    items = z.items(d)
    assert items

# Generated at 2022-06-22 18:30:03.517315
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("", ())
    indices_slice = indices[None]
    if not isinstance(indices_slice, Indices):
        raise AssertionError

# Generated at 2022-06-22 18:30:10.219430
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='z')
    assert BaseVariable('x', exclude=('y',)) == BaseVariable('x', exclude=('y',))


# Generated at 2022-06-22 18:30:13.277562
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('') == BaseVariable(''), 'First BaseVariable should be equal to Second BaseVariable'



# Generated at 2022-06-22 18:30:16.654013
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    s = 'x.y'
    var1 = CommonVariable(s)
    var2 = CommonVariable(s)
    assert var1 == var2
    assert hash(var1) == hash(var2)


# Generated at 2022-06-22 18:30:18.514873
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # assert BaseVariable.items()
    BaseVariable(source='x', exclude=None)


# Generated at 2022-06-22 18:30:20.630137
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('a')._slice == slice(None)
    assert Indices('a')[::2]._slice == slice(None, None, 2)

# Generated at 2022-06-22 18:30:28.012211
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source_variables, expected_variables = TestVariable.get_scenario(1)
    # Test method items of class BaseVariable
    variables = TestVariable.get_variable(1)
    # print("variables", variables)
    # Test method items of class Attrs
    attrs = Attrs(variables[0])
    # print("attrs", attrs)
    # Test method items of class Keys
    keys = Keys(variables[0])
    # print("keys", keys)
    # Test method items of class Indices
    indices = Indices(variables[0])
    # print("indices", indices)
    # Test method items of class Exploding
    exploding = Exploding(variables[0])
    # print("exploding", exploding)
    pass


# Test for class variables

# Generated at 2022-06-22 18:30:31.724142
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a=Indices('self.a')[2:5]
    #print(a)
    assert a._slice == slice(2,5)
    assert isinstance(a,Indices)



# Generated at 2022-06-22 18:30:42.550256
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame_locals = {}
    frame_locals['a'] = 'a1'
    frame_locals['b'] = 'b1'
    frame_locals['c'] = 'c1'
    frame_locals['d'] = 'd1'
    frame_locals['x'] = {}
    frame_locals['y'] = {}
    frame_locals['z'] = {}
    frame_locals['x']['b'] = 'b1'
    frame_locals['y']['b'] = 'b1'
    frame_locals['z']['b'] = 'b1'
    frame_locals['x']['c'] = 'c1'
    frame_locals['y']['c'] = 'c1'
    frame_locals['z']['c']

# Generated at 2022-06-22 18:30:49.232008
# Unit test for constructor of class Indices
def test_Indices():
    i1 = Indices('my_variable')
    assert i1._slice == slice(None)
    i2 = i1[::2]
    assert i2._slice == slice(None, None, 2)
    with pytest.raises(AssertionError):
        i2[0]


# Generated at 2022-06-22 18:30:51.762981
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('a')[0:1]

# Generated at 2022-06-22 18:30:54.159889
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))


# Generated at 2022-06-22 18:30:57.819299
# Unit test for constructor of class Indices
def test_Indices():
    a = [1,2,3]
    assert Indices('a')[0:2]._keys(a) == [0,1]
    assert Indices('a')._keys(a) == [0,1,2]
    assert Indices('a')[1:]._keys(a) == [1,2]

# Generated at 2022-06-22 18:31:01.089131
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('var1', ('a', 'b'))
    var2 = BaseVariable('var2', ('c', 'd'))
    var3 = BaseVariable('var1', ('a', 'b'))
    assert not var1 == var2
    assert var1 == var3



# Generated at 2022-06-22 18:31:02.868926
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("x")
    assert indices[1:] == indices[1:2]

# Generated at 2022-06-22 18:31:11.513301
# Unit test for constructor of class Attrs
def test_Attrs():
    d = {'hello':'world'}
    a = Attrs('d')
    assert a.source == 'd'
    assert a.code == compile('d', '<variable>', 'eval')
    assert a.unambiguous_source == 'd'
    assert a._fingerprint == (Attrs, 'd', ())
    assert a._safe_keys(d) == d.keys()
    assert a._format_key('hello') == '.' + 'hello'
    assert a._get_value(d, 'hello') == d['hello']


# Generated at 2022-06-22 18:31:15.054269
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable('a') == BaseVariable('a'))
    assert (BaseVariable('a', exclude=('attr1','attr2')) == BaseVariable('a', exclude=('attr2','attr1')))
    assert (BaseVariable('a') != BaseVariable('b'))



# Generated at 2022-06-22 18:31:17.715604
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert(BaseVariable("test") != BaseVariable("test2"))
    assert(BaseVariable("test") != Attrs("test"))
    assert(BaseVariable("test") == BaseVariable("test"))


# Generated at 2022-06-22 18:31:20.396749
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('x')
    assert e
    assert e.source == 'x'
    assert e.code



# Generated at 2022-06-22 18:31:29.639619
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # test the same instance
    v1 = BaseVariable("dict")
    v2 = v1
    assert v1 == v2

    # test the different type instances
    v2 = Keys("dict")
    assert v1 != v2

    # test the same type instances with different source
    v2 = BaseVariable("dict_new")
    assert v1 != v2

    # test the same type instances with different exclude
    v2 = BaseVariable("dict", exclude=['a'])
    assert v1 != v2

    # test the same type instances with different source and exclude
    v2 = BaseVariable("dict_new", exclude=['a'])
    assert v1 != v2

# Generated at 2022-06-22 18:31:34.813441
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('x().y') is False

    assert needs_parentheses('x[y]') is True
    assert needs_parentheses('x[y].z') is True
    assert needs_parentheses('x.y().z') is True
    assert needs_parentheses('x.y[z].w()') is True

# Generated at 2022-06-22 18:31:40.504984
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    result  = False
    class A(BaseVariable):
        def __init__(self, source):
            super(A, self).__init__(source)
            self.source = 'Source'

        def _items(self, key, normalize=False):
            return ('(A.source, A.source)', 'A.source')
    
    

    a = A('Source')
    b = A('Source')
    try:
        if a.__eq__(b):
            result = True
    except Exception:
        raise 
    finally:
        return result


# Generated at 2022-06-22 18:31:42.596583
# Unit test for constructor of class Keys
def test_Keys():
    a = {"keyname" : "keyvalue"}
    b = Keys(a,"keyname")
    print(b.items(a))

# Generated at 2022-06-22 18:31:45.566023
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a').items(frame_factory(a=1)) == [('a', '1')]


# Generated at 2022-06-22 18:31:50.046716
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('x')
    assert var.source == 'x'
    assert var.exclude == ()
    assert var._slice == slice(None)
    assert var.code.co_code == code('x').co_code
    assert var.unambiguous_source == 'x'



# Generated at 2022-06-22 18:31:58.819214
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('x')
    b = Indices('x')[:]
    c = Indices('x')[1:3]
    d = Indices('y')
    e = Indices('x')[0:2:1]

    assert a._slice.start == 0
    assert a._slice.stop == None
    assert a._slice.step == None

    assert a == b
    assert not a == c
    assert not a == d
    assert not a == e
    assert a._slice == b._slice
    assert a._slice == c._slice
    assert a._slice != d._slice
    assert a._slice != e._slice

# Generated at 2022-06-22 18:32:10.783081
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test case 1:
    # (1) main_value: dict
    # (2) expect result: tuple
    main_value = {'x': '1'}
    expect_result = [('x', '1')]
    result = Exploding('x').items(main_value)
    assert_result = result == expect_result
    assert assert_result

    # test case 2:
    # (1) main_value: list
    # (2) expect result: tuple
    main_value = [1,2,3]
    expect_result = [('x[0]','1'),('x[1]','2'),('x[2]','3')]
    result = Exploding('x').items(main_value)
    assert_result = result == expect_result
    assert assert_result

    # test case 3:

# Generated at 2022-06-22 18:32:19.084384
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    x = BaseVariable('x')
    assert hash(x) == hash(BaseVariable('x'))
    assert hash(x) != hash(BaseVariable('xx'))
    assert hash(x) != hash(BaseVariable('x', exclude=()))
    assert hash(x) != hash(BaseVariable('x', exclude=('a',)))
    assert hash(x) != hash(BaseVariable('x', exclude='a'))
    assert hash(x) != hash(type(x))


# Generated at 2022-06-22 18:32:24.573004
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable('foobar', 'ex')
    v2 = BaseVariable('foobar', 'ex')
    assert hash(v1) == hash(v2)

    assert hasattr(v1, '_fingerprint')
    assert hasattr(v2, '_fingerprint')



# Generated at 2022-06-22 18:32:27.457332
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    key = BaseVariable('source')
    dict = {}
    dict['code'] = key
    assert dict['code'] == key

if __name__ == '__main__':
    # Unit test for method __hash__ of class BaseVariable
    test_BaseVariable___hash__()

# Generated at 2022-06-22 18:32:38.926517
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    Source = CommonVariable
    frame = inspect.currentframe()
    yield lambda: Source('frame')
    yield lambda: Source('frame.f_back')
    yield lambda: Source('sys.modules')
    try:
        yield lambda: Source('1/0')
    except ZeroDivisionError:
        pass
    try:
        yield lambda: Source('a')
    except NameError:
        pass
    try:
        yield lambda: Source('frame.a')
    except AttributeError:
        pass
    try:
        yield lambda: Source('frame.f_globals')
    except Exception:
        pass
    yield lambda: Source('frame.f_globals["__name__"]')
    yield lambda: Source('frame.f_globals', exclude='__name__')

# Generated at 2022-06-22 18:32:43.893686
# Unit test for constructor of class Keys
def test_Keys():
    c = Keys("a.b", exclude=("1", "a"))
    assert c.source == "a.b"
    assert c.exclude == ("1", "a")
    assert c.code == compile('a.b', '<variable>', 'eval')
    assert c.unambiguous_source == "a.b"


# Generated at 2022-06-22 18:32:46.529952
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_object = Indices("a")[1::2]

    assert isinstance(test_object, Indices)
    assert test_object._slice == slice(1, None, 2)



# Generated at 2022-06-22 18:32:50.455532
# Unit test for constructor of class Exploding
def test_Exploding():
    explod = Exploding('explod')
    assert isinstance(explod, Exploding)
    print("Test for constructor of class Exploding : PASS")


# Generated at 2022-06-22 18:32:54.449933
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    main_value = {'a': 1, 'b': 2, 'c': 4}
    keys= main_value.keys()
    result = {'a': 1, 'b': 2, 'c': 3}
    for key in keys:
        assert key in result
        result[key]


# Generated at 2022-06-22 18:32:57.709251
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('x')
    assert k.source == 'x'
    assert k.exclude == ()
    assert k.unambiguous_source == 'x'
    assert isinstance(k.code, types.CodeType)


# Generated at 2022-06-22 18:33:00.900619
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a')[:]
    assert a.__class__.__name__ == 'Indices', 'It is not a class Indices.'


# Program 3

# Generated at 2022-06-22 18:33:07.692881
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    foo = BaseVariable('foo')
    bar = BaseVariable('bar')
    foo_dict = BaseVariable('foo', exclude=('dict',))
    bar_dict = BaseVariable('bar', exclude=('dict',))


    assert foo == foo
    assert foo != bar
    assert foo_dict != foo
    assert foo_dict != bar_dict



# Generated at 2022-06-22 18:33:16.121010
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('a')
    assert bv.source == 'a'
    assert bv.exclude == ()
    assert bv.unambiguous_source == 'a'
    assert bv.code == compile('a', '<variable>', 'eval')

    bv = BaseVariable('a.b')
    assert bv.source == 'a.b'
    assert bv.exclude == ()
    assert bv.unambiguous_source == '(a.b)'
    assert bv.code == compile('a.b', '<variable>', 'eval')


# Generated at 2022-06-22 18:33:20.502795
# Unit test for constructor of class Exploding
def test_Exploding():
    assert len(Exploding('x').items({'x': {}})) == 1
    assert len(Exploding('x').items({'x': []})) == 1
    assert len(Exploding('x').items({'x': ''})) == 1


_DEFAULT_VARIABLES = (
    Attrs('self'),
    Attrs('self.__class__'),
    Keys('locals()'),
    Indices('globals()'),
)



# Generated at 2022-06-22 18:33:30.559767
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v1 = BaseVariable('sys.__excepthook__', exclude=['__args__'])
    v2 = BaseVariable('sys.__excepthook__', exclude='__args__')
    v3 = BaseVariable('sys.__excepthook__', exclude=())
    v1 == v2 == v3
    assert not (v1 == 'sys.__excepthook__')
    v4 = BaseVariable('sys.__excepthook__', exclude=['__excepthook__'])
    assert not (v1 == v4)
    assert hash(v1) == hash(v2) == hash(v3)
    assert hash(v1) != hash(v4)

# Generated at 2022-06-22 18:33:41.860744
# Unit test for function needs_parentheses
def test_needs_parentheses():
    class C(object):
        def method(self):
            pass
    c = C()

    assert needs_parentheses('1')
    assert needs_parentheses('a')
    assert needs_parentheses('C')
    assert needs_parentheses('(1 + 2) * 3')
    assert needs_parentheses('a.b[1].c()')
    assert needs_parentheses('(a + b) * c')
    assert not needs_parentheses('1 - 2')
    assert not needs_parentheses('a + b')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b[1]')
    assert not needs_parentheses('c.method')
    assert not needs_parentheses('c.method()')
    assert not needs_parentheses('(a + b).c')

# Generated at 2022-06-22 18:33:42.814753
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('report', exclude=['test']).code

# Generated at 2022-06-22 18:33:48.360610
# Unit test for constructor of class Keys
def test_Keys():
    m = Keys('x', exclude=['b'])
    expected_result = {
        'source': 'x', 
        'exclude': ('b',),
        'unambiguous_source': 'x'
    }

    for key, value in expected_result.items():
        assert getattr(m, key) == value


# Generated at 2022-06-22 18:33:53.300699
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Create two instances of class BaseVariable
    base_variable_1 = BaseVariable('pytest.config')
    base_variable_2 = BaseVariable('pytest.config')

    assert base_variable_1 == base_variable_2 # assert that __eq__ method works as expected in class BaseVariable


# Generated at 2022-06-22 18:33:56.848910
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a', exclude='')
    assert('a.__dict__' in a.items(None))
    assert('a.__dict__' not in Attrs('a', exclude='__dict__').items(None))



# Generated at 2022-06-22 18:34:01.942519
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert eval(CommonVariable('a', exclude='__XXX__').code, {'a': 1}) == 1
    assert repr(CommonVariable('a', exclude='__XXX__').code) == "<code object <module> at 0x7f39f472d030, file '<variable>', line 1>"


# Generated at 2022-06-22 18:34:10.153617
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from .utils.tests.test_py3compat import Test_py3compat

    v1 = Attrs('a')
    v2 = Attrs('a')
    v3 = Attrs('b')
    v4 = Keys('a')
    v5 = Keys('b')
    v6 = Indices('a')
    v7 = Indices('b')
    v8 = Exploding('a')
    v9 = Exploding('b')

    Test_py3compat.test_set_equality(
        {v1, v2, v3, v4, v5, v6, v7, v8, v9},
        {v1, v2, v3, v4, v5, v6, v7, v8, v9}
    )

# Generated at 2022-06-22 18:34:18.434962
# Unit test for function needs_parentheses
def test_needs_parentheses():
    needs_parentheses_tests = [
        ('', False),
        ('x', False),
        ('x()', False),
        ('x[1]', False),
        ('x.y', False),
        ('x.y()', False),
        ('y[1](x)', False),
        ('x+y', True),
        ('x()+y', True),
        ('y[1]+y', True),
        ('x.y+y', True),
        ('x.y()+y', True),
        ('y[1](x)+y', True),
    ]
    for source, expected in needs_parentheses_tests:
        got = needs_parentheses(source)
        utils.assert_obj_equals(got, expected)

# Generated at 2022-06-22 18:34:20.904824
# Unit test for constructor of class Attrs
def test_Attrs():
    d = Attrs('a', exclude='b')
    print(d)
    d._keys()
    d._format_key()

# Generated at 2022-06-22 18:34:27.759782
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from .test_utils import assert_eq
    from . import utils; utils.silence_warnings()
    class Subclass(CommonVariable):
        def _keys(self, main_value):
            return range(len(main_value))

        def _format_key(self, key):
            return '.' + str(key)

        def _get_value(self, main_value, key):
            return main_value[key]

    var = Subclass('*.a', exclude='b')
    frame = pycompat.fakesys._getframe()
    assert_eq(var.items(frame), [
        ('*.a', '[]'),
        ('*.a.0', '1'),
        ('*.a.1', '2'),
    ])

# Generated at 2022-06-22 18:34:31.043078
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable('')
    w = BaseVariable('')
    assert v == w


# Generated at 2022-06-22 18:34:34.870563
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import FakeFrame
    b = BaseVariable('b')
    assert b.items(frame=dict(b=[1, 2, 3]), normalize=True) == [('b', '[1, 2, 3]')]



# Generated at 2022-06-22 18:34:40.482303
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('a.b')
    assert(bv.source == 'a.b')
    assert(bv.exclude == ())
    assert(bv.code == compile('a.b', '<variable>', 'eval'))
    assert(bv.unambiguous_source == '(a.b)')

    # TODO: Test __init__ for other classes in this file

# Generated at 2022-06-22 18:34:45.376027
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from .tests import BackendTest
    from . import backend
    from inspect import FrameInfo
    from .pycompat import string_types

    frame = FrameInfo(None, None, None, None, None, None)
    variables = [
        ('foo', 'foo'),
        ('foo.bar', 'foo.bar'),
        ('foo.1.2.3', 'foo.1.2.3'),
        ('foo[1]', 'foo[1]'),
        ('foo[1][2][3]', 'foo[1][2][3]'),
    ]
    for source, expected in variables:
        variable = backend.BaseVariable(source)
        assert(source == variable.source)

    # A variable with a keyword attribute should be accepted, otherwise it will
    # be rejected by the compiler.

# Generated at 2022-06-22 18:34:51.090352
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert needs_parentheses('a[b]')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a.b)')
    assert not needs_parentheses('(a.b).c')
    assert not needs_parentheses('(a).b.c')
    assert not needs_parentheses('(a[b]).c')
    assert not needs_parentheses('a.b[c]')
    assert not needs_parentheses('a[b].c')
    assert not needs_parentheses('(a).b[c]')

# Generated at 2022-06-22 18:34:53.683109
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    with pytest.raises(NotImplementedError):
        BaseVariable("src1", ("exclude1",))._items("key1", "normalize")


# Generated at 2022-06-22 18:34:55.401967
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert(a.source == 'a')


# Generated at 2022-06-22 18:35:00.323499
# Unit test for constructor of class Indices
def test_Indices():
    data = ['a', 'b', 'c']
    var = Indices('data')
    assert var.items(None) == [('data', '[0, 1, 2]')]
    var = var[1:2]
    assert var.items(None) == [('data', '[1]')]

    for i in range(3):
        assert var[i:i+1].items(None) == [('data', '[' + str(i) + ']')]

# Generated at 2022-06-22 18:35:01.579697
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert isinstance(BaseVariable('x').__hash__(), int)


# Generated at 2022-06-22 18:35:06.520555
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'x'
    exclude = '__dict__'
    v = BaseVariable(source, exclude=exclude)
    assert v._fingerprint == (BaseVariable, source, exclude)
    assert v.__hash__(), hash(v._fingerprint)


# Generated at 2022-06-22 18:35:11.624992
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices("x")
    assert a.source == "x"
    assert a._slice == slice(None)
    b = a[1:3]
    assert b.source == "x"
    assert b._slice == slice(1,3)
    assert b.items("x") == [("x[1]", "None"), ("x[2]", "None")]

# Generated at 2022-06-22 18:35:13.306519
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dic = {'a':10}
    var = BaseVariable(source='dic')
    assert var.items(dic) == [('dic', '{\'a\': 10}')]


# Generated at 2022-06-22 18:35:22.695180
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = compile('a', '<string>', 'eval')
    b = compile('a.b', '<string>', 'eval')
    c = compile('a.b', '<string>', 'eval')
    d = compile('a.b[0]', '<string>', 'eval')
    e = compile('(a.b[0])', '<string>', 'eval')
    f = compile('a.b.c', '<string>', 'eval')

    assert a != b
    assert b == c
    assert c != d
    assert d == e
    assert e != f

# Test for constructor of Attrs

# Generated at 2022-06-22 18:35:32.167077
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('foo').__getitem__(slice(1,2))._items('foo'), cls=Indices)
    assert isinstance(Exploding('foo').__getitem__(slice(1,2))._items([1,2,3]), cls=Indices)
    assert isinstance(Exploding('foo').__getitem__(slice(1,2))._items([[1]]), cls=Indices)
    assert isinstance(Exploding('foo').__getitem__(slice(1,2))._items({1:1}), cls=Keys)
    assert isinstance(Exploding('foo').__getitem__(slice(1,2))._items(1), cls=Attrs)

# Generated at 2022-06-22 18:35:39.403902
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    """
    test_BaseVariable():
    Test the constructor of class BaseVariable, 
    check if the internal variable 'source' and 'code' are as expected

    Args:
        None

    Returns: 
        None
    """
    source = '234'
    exclude = ('',)
    V = BaseVariable(source, exclude)
    assert isinstance(V, BaseVariable)
    assert V.source is not None
    assert V.code is not None
    #print(dir(V))
    #print(type(V.source))
    #print(V.code)
    #print(V.source)
    #print(V.exclude)


# Generated at 2022-06-22 18:35:46.505155
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys("a")
    assert a.__hash__() != 0
    assert a.__eq__("0") == False
    assert a.__eq__(Keys("a")) == True
    assert a.__eq__(Keys("b")) == False
    assert a.__eq__(Keys("a", exclude="b")) == False
    assert a.__eq__(Indices("a")) == False
    assert a.items("a") == ()
    assert a.items("a", normalize=True) == ()


# Generated at 2022-06-22 18:35:51.194457
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    """
    >>> s = 'abc!abc'
    >>> BaseVariable(s, exclude='ex')
    Traceback (most recent call last):
    ...
    Exception: exclude must be a tuple
    """
    pass