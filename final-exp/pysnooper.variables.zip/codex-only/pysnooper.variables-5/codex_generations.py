

# Generated at 2022-06-22 18:25:56.048856
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('x')
    assert i[2:5][2] == i[2:5]
    assert i[2:5][2] is not i
    assert i[2:5][2] is not i[2:5]

# Generated at 2022-06-22 18:26:02.903246
# Unit test for method __getitem__ of class Indices

# Generated at 2022-06-22 18:26:05.770241
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    input = Indices('a')
    assert input==input
    assert not(input==Keys('a'))


# Generated at 2022-06-22 18:26:09.268485
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('someVar')
    test_slice = slice(7, 19, 5)

    v_slice = v[test_slice]

    assert isinstance(v_slice, Indices)
    assert v_slice == v
    assert v_slice is not v
    assert v_slice._slice == test_slice
    assert v_slice._slice is not test_slice

# Generated at 2022-06-22 18:26:13.180590
# Unit test for constructor of class Keys
def test_Keys():
    keyTest = Keys('value')
    assert keyTest is not None
    keyTest1 = Keys('value', 'test')
    assert keyTest1 is not None
    keyTest2 = Keys('value', ['test1', 'test2'])
    assert keyTest2 is not None


# Generated at 2022-06-22 18:26:16.842115
# Unit test for constructor of class Indices
def test_Indices():
    dct = utils.ensure_tuple({'foo': 'bar'}).keys()
    # 		print(list(iter(dct)))
    if __name__ == '__main__':
        # Unit test
        assert test_Indices() == None

# Generated at 2022-06-22 18:26:23.718278
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def _test(source, exclude, code, unambiguous_source):
        v = CommonVariable(source, exclude)
        assert v.source == source
        assert v.exclude == exclude
        assert v.code == code
        assert v.unambiguous_source == unambiguous_source

    _test('(a', (), compile('(a', '<variable>', 'eval'), '(a)')
    _test('a', (), compile('a', '<variable>', 'eval'), 'a')
    _test('a', 'b', (), compile('a', '<variable>', 'eval'), 'a')
    _test('a', ['b'], (), compile('a', '<variable>', 'eval'), 'a')
    _test('a', set(['b']), (), compile('a', '<variable>', 'eval'), 'a')

# Generated at 2022-06-22 18:26:25.421076
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    def hash_code(code):
        return hash(code)
    bv = BaseVariable('code')
    assert hash_code(bv) == hash_code(bv)


# Generated at 2022-06-22 18:26:30.803984
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # normal case
    var = Indices("x")
    assert var[:] == Indices("x", _slice=slice(None))
    assert var[1:4] == Indices("x", _slice=slice(1, 4))
    assert var[:4] == Indices("x", _slice=slice(4))
    assert var[4:] == Indices("x", _slice=slice(4, None))
    assert var[4:4] == Indices("x", _slice=slice(4, 4))
    assert var[4:8:3] == Indices("x", _slice=slice(4, 8, 3))
    # input validation
    with pytest.raises(AssertionError):
        var[None]
    with pytest.raises(AssertionError):
        var['a']

# Generated at 2022-06-22 18:26:32.326389
# Unit test for constructor of class Exploding
def test_Exploding():
    var_exploding = Exploding('var')
    assert isinstance(var_exploding, BaseVariable)

# Generated at 2022-06-22 18:26:35.481104
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('key')
    assert indices is not None
    assert isinstance(indices, Indices)
    assert indices.source == 'key'
    assert indices._slice is None


# Generated at 2022-06-22 18:26:45.698637
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'x.y'
    exclude = ('b',)
    obj1 = BaseVariable(source, exclude)
    obj2 = BaseVariable(source, exclude)
    assert obj1 == obj2
    assert hash(obj1) == hash(obj2)
    assert obj1.source == 'x.y'
    assert obj1.exclude == ('b',)
    assert obj1.code == compile(source, '<variable>', 'eval')
    assert obj1.unambiguous_source == 'x.y'
    assert obj1._fingerprint == (BaseVariable, 'x.y', ('b',))
    assert obj1.items == BaseVariable.items.__get__(obj1)


# Generated at 2022-06-22 18:26:49.041285
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('x.__getitem__(y).z')
    assert needs_parentheses('(x.y).z')
    assert not needs_parentheses('x.y[z]')



# Generated at 2022-06-22 18:26:50.438012
# Unit test for constructor of class Exploding
def test_Exploding():
    exp = Exploding(None, exclude=None)
    assert isinstance(exp, BaseVariable)

# Generated at 2022-06-22 18:27:01.773777
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class SubBaseVariable(BaseVariable):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.args = args
            self.kwargs = kwargs

        def items(self, *args, **kwargs):
            return ()

    def _check(vars, yes_groups, no_groups):
        for yes_group in yes_groups:
            for a, b in itertools.combinations(yes_group, 2):
                assert a == b, '{} == {}'.format(a, b)
        for no_group in no_groups:
            for a, b in itertools.combinations(no_group, 2):
                assert a != b, '{} != {}'.format(a, b)


# Generated at 2022-06-22 18:27:03.142206
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('a', 'b').code is None


# Generated at 2022-06-22 18:27:12.930866
# Unit test for constructor of class Keys
def test_Keys():
    # Valid inputs
    key1 = Keys('self')
    assert key1.source == 'self'
    assert key1.unambiguous_source == 'self'
    assert key1.code is not None

    key2 = Keys('self', exclude=['__dict__'])
    assert key2.source == 'self'
    assert key2.unambiguous_source == 'self'
    assert key2.exclude == ('__dict__',)
    assert key2.code is not None

    # Invalid inputs
    with pytest.raises(ValueError):
        key = Keys('')
    with pytest.raises(ValueError):
        key = Keys('self', exclude='')



# Generated at 2022-06-22 18:27:23.269460
# Unit test for constructor of class Keys
def test_Keys():
    from .utils import nocache
    __, attrs = nocache()
    py3 = sys.version_info[0] == 3
    filename = '<unknown>' if py3 else '<stdin>'
    frame = inspect.currentframe()
    frame.f_code.co_filename = filename
    frame.f_globals = attrs
    frame.f_locals = attrs
    normal = 'name'
    attrs[normal] = [0, 1]
    keyname = '__a'
    attrs[keyname] = [0, 1]
    attrs['__b'] = [0, 1]
    a = Keys(normal)
    items = list(a.items(frame))
    assert len(items) == 2

# Generated at 2022-06-22 18:27:24.686548
# Unit test for constructor of class Attrs
def test_Attrs():
    from .tests.fixtures import test_environ
    b = Attrs('test_environ')
    print(b.items(test_environ))


# Generated at 2022-06-22 18:27:32.335626
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # try to initialize it
    bv = BaseVariable("some_source","some_exclude")
    # now use properties to check everything
    assert bv.source == "some_source"
    assert bv.exclude == ("some_exclude")
    assert bv.code == compile("some_source", '<variable>', 'eval')
    assert bv.unambiguous_source == "some_source"



# Generated at 2022-06-22 18:27:43.688778
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import os
    import inspect
    import resource
    import subprocess
    def subprocess_check_call():
        subprocess.check_call(['sleep', '10'], shell=False, close_fds=(os.name != 'nt'))

    frame = inspect.currentframe()
    frame = frame.f_back
    frame = frame.f_back
    local_variables = frame.f_locals.copy()

    # test source: main_value, main_value_name
    # test subprocess.check_call
    source = 'subprocess_check_call()'
    exlclude = ('stderr', 'stdin', 'stdout', 'pid', 'returncode', '_bufsize')

# Generated at 2022-06-22 18:27:50.015474
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('1') == False
    assert needs_parentheses('2 + 3') == False
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.a') == False
    assert needs_parentheses('x.map') == False
    assert needs_parentheses('(2 + 3)') == True
    assert needs_parentheses('x.map(a, b)') == True

# Generated at 2022-06-22 18:27:53.385471
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    assert x[1]._slice == slice(1)
    assert x[1:5]._slice == slice(1,5)
    assert x[1:5:2]._slice == slice(1,5,2)

# Generated at 2022-06-22 18:27:57.167038
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class BaseVariableTest(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    src = 'x'
    self = BaseVariableTest(src)
    # Test
    assert self.source == src
    assert self.code == compile(src, '<variable>', 'eval')


# Generated at 2022-06-22 18:28:04.992441
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    """
    Test output of BaseVariable.__hash__.
    """
    # Test with empty source
    var = BaseVariable('')
    assert hash(var) == hash((var._fingerprint))

    # Test with source
    var = BaseVariable('a')
    assert hash(var) == hash((var._fingerprint))

    # Test with empty exclude
    var = BaseVariable('', exclude=())
    assert hash(var) == hash((var._fingerprint))

    # Test with exclude
    var = BaseVariable('a', exclude=('x',))
    assert hash(var) == hash((var._fingerprint))


# Unit tests for method __eq__ of class BaseVariable

# Generated at 2022-06-22 18:28:06.927831
# Unit test for constructor of class Keys
def test_Keys():
    test_instance = Keys('a')
    assert(isinstance(test_instance, Keys))


# Generated at 2022-06-22 18:28:12.483109
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Create a dummy class
    class Dummy():
        def __init__(self, source, exclude):
            self.source = source
            self.exclude = exclude
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

    print('Test for CommonVariable constructor has been passed!')



# Generated at 2022-06-22 18:28:23.110955
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable) != hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('a', exclude='a'))
    assert BaseVariable('a').__hash__(
    ) != BaseVariable('b').__hash__()
    assert BaseVariable('a').__hash__(
    ) != BaseVariable('a', exclude='a').__hash__()
    assert BaseVariable('a', exclude='a').__hash__(
    ) == BaseVariable('a', exclude='a').__hash__()
    assert BaseVariable('a', exclude='a').__hash__(
    ) != BaseVariable('a', exclude='b').__hash__()
    assert BaseVariable('a', exclude='a').__hash__(
    )

# Generated at 2022-06-22 18:28:28.659356
# Unit test for constructor of class Attrs
def test_Attrs():
    string = "data.a.b"
    d = Attrs(string)
    assert d.source == string
    assert d.exclude == ()
    assert d.code.co_code == b'd'
    assert d.unambiguous_source == string
    assert d._fingerprint == (Attrs, string, ())
    assert str(hash(d)) is not None
    assert d != "a"


# Generated at 2022-06-22 18:28:35.911973
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('') == BaseVariable('')
    assert BaseVariable('') == BaseVariable('', '')
    assert BaseVariable('') != BaseVariable('', 'a')
    assert BaseVariable('', 'a') == BaseVariable('', 'a')
    assert BaseVariable('', 'a') != BaseVariable('', ('a',))
    assert BaseVariable('', ('a',)) == BaseVariable('', ('a',))
    assert BaseVariable('', ('a',)) != BaseVariable('', ('a', 'b'))
    assert BaseVariable('', ('a', 'b')) == BaseVariable('', ('a', 'b'))

    a = BaseVariable('')
    b = BaseVariable('')
    assert a is not b
    assert set([a, b]) == set((a, b, BaseVariable('')))

    a

# Generated at 2022-06-22 18:28:39.066455
# Unit test for constructor of class Exploding
def test_Exploding():
    assert set(Exploding('x').items(utils.frame(''))) == {('x', '1'), ('x.y', '2'), ('x.z', '3')}



# Generated at 2022-06-22 18:28:43.435226
# Unit test for constructor of class Exploding
def test_Exploding():
    v_exploding = Exploding('x')

# Generated at 2022-06-22 18:28:46.752974
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('y'))


# Generated at 2022-06-22 18:28:47.721855
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs('a', ('b', 'c'))

# Generated at 2022-06-22 18:28:51.753727
# Unit test for constructor of class Exploding
def test_Exploding():
    class A(object):
        __slots__ = ['y']
        def __init__(self, x):
            self.x = x

    assert set(Exploding('v').items(frame=None, main_value=A(x=1))[0]) == set(('v', '<Exploding at 0x10ceabe48>'))
    assert set(Exploding('v').items(frame=None, main_value={'a': 1})[0]) == set(('v', '<Exploding at 0x10ceabe48>'))
    assert set(Exploding('v').items(frame=None, main_value=[1])[0]) == set(('v', '<Exploding at 0x10ceabe48>'))

# Generated at 2022-06-22 18:28:53.251469
# Unit test for constructor of class Keys
def test_Keys():
    Keys(source = 'test_source', exclude = ('exclude_key', ))


# Generated at 2022-06-22 18:28:55.882137
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a.x') == True
    assert needs_parentheses('a.x.y.z') == True


# Generated at 2022-06-22 18:29:06.692885
# Unit test for constructor of class Exploding
def test_Exploding():
    try:
        # Python 3.5 and newer
        import xml.etree.ElementTree as ET
    except ImportError:
        # Python 3.3 and 3.4
        import xml.etree.cElementTree as ET

    root = ET.fromstring('<root><a>a</a><b>b</b></root>')
    source = "root"
    exclude = ['x']
    code = compile(source, '<variable>', 'eval')
    exp = Exploding(source, exclude)
    assert exp.source == source
    assert exp.exclude == exclude
    assert exp.code == code
    assert exp.unambiguous_source == source
    #
    # Test for a non-mapping non-sequence
    #
    main_value=source

# Generated at 2022-06-22 18:29:10.368356
# Unit test for constructor of class Exploding
def test_Exploding():
    ev = Exploding('variable', exclude='to_exclude')
    assert ev.source == 'variable'
    assert ev.exclude == ('to_exclude',)
    assert ev.code is not None
    assert ev.unambiguous_source == 'variable'


# Generated at 2022-06-22 18:29:21.239441
# Unit test for constructor of class Exploding
def test_Exploding():
    # The constructor of class Exploding relies on the method _items of its
    # subclasses, so we need to exercise its subclasses as well.
    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
        def __getitem__(self, idx):
            return self.a + self.b + self.c
        def keys(self):
            return range(3)
    testCases = [
        (["foo", "bar"], ["foo"]),
        ([TestClass(), TestClass()], []),
    ]
    for testCase in testCases:
        for tc in testCase[0]:
            ev = Exploding("tc", exclude=testCase[1]).items(tc)
    print("Passed the constructor of class Exploding")


# Generated at 2022-06-22 18:29:22.201473
# Unit test for constructor of class Indices
def test_Indices():
    iv = Indices("main_value")

# Generated at 2022-06-22 18:29:31.666658
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    variable = CommonVariable('a')
    variable1 = CommonVariable('a')
    variable2 = CommonVariable('\"a\"')
    variable3 = CommonVariable('b')
    variable4 = CommonVariable('b', ['b', 'c'])
    variable5 = CommonVariable('c', ['b', 'c'])
    variable6 = CommonVariable('b', ['a', 'c'])
    variable7 = CommonVariable('c', ['a', 'c'])
    assert variable==variable1
    assert variable!=variable2
    assert variable!=variable3
    assert variable!=variable4
    assert variable!=variable5
    assert variable!=variable6
    assert variable!=variable7


# Generated at 2022-06-22 18:29:35.484772
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable("main_value", "exclude")
    cv.source = "main_value"
    cv.exclude = ("exclude")
    cv.unambiguous_source = "(main_value)"


# Generated at 2022-06-22 18:29:38.558274
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    m = Indices('some_variable')
    m_slice = m[:]
    assert m_slice._slice == slice(None)
    m_slice = m[1:3:2]
    assert m_slice._slice == slice(1, 3, 2)

# Generated at 2022-06-22 18:29:44.261005
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x[1]')
    assert not needs_parentheses('x[1].y')
    assert needs_parentheses('(x)')
    assert needs_parentheses('x+1')
    assert needs_parentheses('x[y]')

# Generated at 2022-06-22 18:29:49.471059
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('test.x', exclude=['z']) == BaseVariable('test.x', exclude=['z'])
    assert BaseVariable('test.x', exclude=['z']) != BaseVariable('test.x', exclude=['a'])
    assert BaseVariable('test.x', exclude=['z']) != BaseVariable('test.y', exclude=['z'])


# Generated at 2022-06-22 18:29:53.488921
# Unit test for constructor of class Keys
def test_Keys():
    k=Keys('a.b')
    assert k.source=='a.b'
    assert k.exclude==()
    assert k.code==compile('a.b', '<variable>', 'eval')
    assert k.unambiguous_source=='a.b'


# Generated at 2022-06-22 18:30:00.904109
# Unit test for constructor of class Attrs
def test_Attrs():
    # Call the constructor
    attrs = Attrs(source='foo', exclude=())

    # Check the attributes
    assert attrs.source == 'foo'
    assert attrs.exclude == ()
    assert callable(attrs.items)
    assert getattr(attrs, '_items') is not None

    # Check the hash and equality
    assert attrs.__hash__() is not None
    attrs2 = Attrs(source='bar', exclude=())
    assert attrs == attrs2

# Generated at 2022-06-22 18:30:04.012749
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable("a")
    v2 = BaseVariable("a")
    v3 = BaseVariable("b")
    assert hash(v1) == hash(v2)
    assert hash(v1) != hash(v3)
    

# Generated at 2022-06-22 18:30:07.250429
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable('')
    b = BaseVariable('')
    print(hash(a))
    print(hash(b))


# Generated at 2022-06-22 18:30:14.243595
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import sample
    from . import utils
    from . import pycompat
    from . import exceptions
    from . import debug
    from . import config

    import sys
    import unittest
    import traceback
    import time

    class BaseVariableTest(unittest.TestCase):

        def test_get_shortish_repr_for_long_value(self):
            self.assertEqual(utils.get_shortish_repr(str(123) * 100), repr(str(123) * 100))

        def test_get_shortish_repr_for_dict(self):
            r = utils.get_shortish_repr(dict(a=123, b=456), normalize=False)
            self.assertEqual(r, "{'a': 123, 'b': 456}")



# Generated at 2022-06-22 18:30:23.832968
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a', (1,))
    items = sorted(indices.items({}))
    assert items == [(0, 'None'), (1, 'None'), (2, 'None'), (3, 'None'), (4, 'None'), (5, 'None'), (6, 'None'), (7, 'None'), (8, 'None'), (9, 'None'), ('a[0]', 'None'), ('a[2]', 'None'), ('a[3]', 'None'), ('a[4]', 'None'), ('a[5]', 'None'), ('a[6]', 'None'), ('a[7]', 'None'), ('a[8]', 'None'), ('a[9]', 'None')]
    print('success!')

    indices_slice = Indices('a')[1:5:2]
   

# Generated at 2022-06-22 18:30:26.959540
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('a')
    b = Keys('b')
    assert a is not b
    assert a != b
    assert a == Keys('a')
    assert hash(a) == hash(Keys('a'))
    assert hash(b) == hash(Keys('b'))
    assert hash(a) != hash(b)

# Generated at 2022-06-22 18:30:31.672812
# Unit test for constructor of class Indices
def test_Indices():
    '''_slice should be slice(None) by default'''
    var = Indices('v')
    assert(var._slice == slice(None))
    assert(var.source == 'v')

# Tests for __getitem__ method of class Indices

# Generated at 2022-06-22 18:30:42.503849
# Unit test for constructor of class Attrs
def test_Attrs():
    # test_Attrs()
    var = Attrs('var', exclude=('u', 'v'))
    assert var.items(frame=None) == [('var', None)]
    assert var.items(frame=None, normalize=True) == [('var', 'None')]
    assert var.items(frame=object()) == [('var', '<object>')]
    assert var.items(frame=object(), normalize=True) == [('var', '<object>')]

    class A:
        pass
    a = A()
    print('a=', a)
    a.x, a.y = 1, 2
    print('a=', a)
    assert 'x' not in utils.ensure_tuple(a.__slots__)
    assert 'y' not in utils.ensure

# Generated at 2022-06-22 18:30:53.811474
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # generator = BaseVariable.__hash__(BaseVariable)
    # call the method __hash__ of class BaseVariable with arguments and save the result as generator
    if callable(BaseVariable.__hash__):
        args = []
        generator = BaseVariable.__hash__(BaseVariable, *args)
    else:
        generator = None
    assert generator is not None

    # call the method _fingerprint of class BaseVariable with arguments and save the result as generator
    if callable(BaseVariable._fingerprint):
        args = []
        generator = BaseVariable._fingerprint(BaseVariable, *args)
    else:
        generator = None
    assert generator is not None

    # call the method __eq__ of class BaseVariable with arguments and save the result as generator
    if callable(BaseVariable.__eq__):
        args = []

# Generated at 2022-06-22 18:31:01.917076
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a', exclude='b')
    #print (k.source)
    #print (k.exclude)
    #print (k.code)
    #print (k.unambiguous_source)
    assert k.source == 'a'
    assert k.exclude == ('b',)
    assert k.code.co_code == b'd\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 18:31:09.447440
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from pycallgraph import PyCallGraph
    from pycallgraph.output import GraphvizOutput
    graphviz = GraphvizOutput(output_file='graph_hash.png')

    with PyCallGraph(output=graphviz):
        v1=BaseVariable('x','y')
        len(v1._fingerprint)
        print(v1.__hash__())
        print(v1._fingerprint)
    # graphviz.finish()


# Generated at 2022-06-22 18:31:14.745981
# Unit test for constructor of class Exploding
def test_Exploding():
    v=Exploding("foo")
    s=set(v.items)
    assert((foo.a,5) in s)
    assert((foo.b,bar) in s)
    assert((foo.c,"blah") in s)
    assert((foo.d,[1,2,3]) in s)

# Generated at 2022-06-22 18:31:16.518144
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable(source='a', exclude=())
    assert v.source == 'a'
    assert v.exclude == ()
    assert v.code is not None # code object

# Generated at 2022-06-22 18:31:23.835280
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def assert_needs(source, needs=True):
        if bool(needs) != needs_parentheses(source):
            raise AssertionError('{} should return {}'.format(
                repr(source), needs))
    assert_needs('x.y')
    assert_needs('x.1')
    assert_needs('x[2]')
    assert_needs('x[0:1]')
    assert_needs('x()')
    assert_needs('x(y)')
    assert_needs('x(1, 2, 3)')
    assert_needs('x(b=2)')
    assert_needs('')
    assert_needs('x', False)
    assert_needs('x.y', False)
    assert_needs('x.1', False)
    assert_needs('x[2]', False)


# Generated at 2022-06-22 18:31:25.164183
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'x'
    result = Indices(source)[:2]
    assert isinstance(result, Indices)
    assert result._slice == slice(None, 2)

test_Indices___getitem__()



# Generated at 2022-06-22 18:31:34.966828
# Unit test for constructor of class Keys
def test_Keys():
    m_dict = {"a":1, "b":2}
    m_list = [1, 2, 3]
    m_tuple = (1, 2)

    # Test constuctor of Keys for dictionary source
    var_d = Keys('a_dict')
    items = var_d.items({'a_dict':m_dict})
    assert(len(items) == 2)
    assert('a_dict' in items[0][0])
    assert(items[0][1] == "<dict{'a':1,'b':2}>")
    assert('a_dict[a]' in items[1][0])
    assert(items[1][1] == "1")
    assert('a_dict[b]' in items[1][0])
    assert(items[1][1] == "2")

    #

# Generated at 2022-06-22 18:31:41.952569
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import utils
    import pytest
    from collections import OrderedDict
    from . import pycompat
    get_shortish_repr = utils.get_shortish_repr

    a = {
        'b': {
            'c': 'd'
        },
        'e': [
            'f',
            {'g': [
                {'h': 'i'}
            ]}
        ]
    }

    # Test a Normal Mapping
    e = Exploding('a')
    x = e.items({'a': a})

# Generated at 2022-06-22 18:31:45.665675
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('d')
    i = i[...]
    assert i._slice == slice(None)
    i = i[1]
    assert i._slice == slice(1, 2)

# Generated at 2022-06-22 18:31:50.443749
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x[y]')
    assert needs_parentheses('x().y')
    assert needs_parentheses('x[y].z')
    assert not needs_parentheses('x().y[z]')

# Generated at 2022-06-22 18:31:52.942892
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = 'x.y'
    exclude = ('a', 'b')
    bv = BaseVariable(source, exclude)
    assert isinstance(bv.__hash__(), int)


# Generated at 2022-06-22 18:31:58.864948
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    s = Slice(2, 4, None)
    assert isinstance(s, slice)
    i = Indices('a')
    new_i = i[s]
    assert isinstance(new_i, Indices)
    assert new_i._slice == s


if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:32:05.025860
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding("a", exclude=("b",))
    assert e.source == "a"
    assert e.exclude == ("b",)
    assert e.code == compile("a", '<variable>', 'eval')
    assert e.unambiguous_source == "a"


# Generated at 2022-06-22 18:32:10.453437
# Unit test for constructor of class Attrs
def test_Attrs():
    var1 = Attrs('myvar')
    var2 = Attrs('myvar')
    myvalue = []
    assert var1.items(myvalue) == [('myvar', '[]')]
    assert var1.items(myvalue, normalize=True) == [('myvar', 'list()')]
    assert var1 == var2
    assert hash(var1) == hash(var2)


# Generated at 2022-06-22 18:32:21.879061
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a.b)')
    assert not needs_parentheses('(a).b.c')
    assert not needs_parentheses('(a.b).c')
    assert needs_parentheses('(a)x')
    assert needs_parentheses('(a.b)x')
    assert needs_parentheses('(a).bx')
    assert needs_parentheses('(a).b.cx')
    assert needs_parentheses('(a.b).cx')

# Generated at 2022-06-22 18:32:29.607718
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('')) == hash(BaseVariable(''))
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x', 'y')) == hash(BaseVariable('x', 'y'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('x', 'z'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('z', 'y'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('x'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('y'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('y', 'z'))

# Generated at 2022-06-22 18:32:38.884224
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'x'
    exclude = 'y'
    v = CommonVariable(source, exclude)
    assert v.source == source, "source is incorrect"
    assert v.exclude == exclude, "exclude is incorrect"
    assert isinstance(v.code, code), "v.code should be 'code' object"
    assert v.unambiguous_source == 'x', "unambiguous_source is incorrect"
    assert v._fingerprint == (CommonVariable, source, exclude), \
        "fingerprint is incorrect"
    assert hash(v) == hash(v._fingerprint), "hash is incorrect"
    assert v == v, "equality is incorrect"

# Generated at 2022-06-22 18:32:44.180797
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b().c(d)')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a).b().c(d)')



# Generated at 2022-06-22 18:32:55.164464
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .logging import find_caller
    from .utils import ensure_tuple
    from .models import Event
    assert isinstance(Attrs('foo'), BaseVariable)
    assert isinstance(Keys('foo'), BaseVariable)
    assert isinstance(Indices('foo'), BaseVariable)
    assert isinstance(Exploding('foo'), BaseVariable)
    assert isinstance(Indices('foo')[1], BaseVariable)
    assert isinstance(Attrs('foo'), BaseVariable)
    assert isinstance(Keys('foo'), BaseVariable)
    a = Indices(Attrs('foo')[1])[1]
    assert isinstance(a, BaseVariable)
    assert a._items({"f":1})  == (('foo[1]', '1'), ('foo[1].f', '1'))

# Generated at 2022-06-22 18:32:58.696131
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices(0, 0)
    assert var.source == 0
    assert var.exclude == (0,)
    assert var.code == compile(0, '<variable>', 'eval')
    assert var.unambiguous_source == 0



# Generated at 2022-06-22 18:33:08.080737
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def assert_needs_parentheses(source, needs):
        assert needs_parentheses(source) == needs, source

    assert_needs_parentheses('x', False)
    assert_needs_parentheses('x[y]', True)
    assert_needs_parentheses('x.y', False)
    assert_needs_parentheses('x.y[z]', True)
    assert_needs_parentheses('x()', False)
    assert_needs_parentheses('x().y', False)
    assert_needs_parentheses('x[y].z', True)

# Generated at 2022-06-22 18:33:16.475325
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import StringIO
    import sys

    # Mock the read_val method
    class FakeFrame(object):
        def __init__(self, name):
            self.f_locals = {name: ['a', 'b', 'c'],}
            self.f_globals = {'a': 'a', 'b': 'b', 'c': 'c'}

    frame = FakeFrame("it")
    variable = BaseVariable("it[1:2]")
    variable_items = variable.items(frame)
    assert variable_items == [("it[1:2]", "['b']")]



# Generated at 2022-06-22 18:33:24.079858
# Unit test for constructor of class Keys
def test_Keys():
    # 1. Test the default input
    var = Keys('dic')
    assert var.source == 'dic'
    assert var.exclude == ()
    assert var.unambiguous_source == 'dic'

    # 2. Test keys with exclude
    var = Keys('dic', exclude=['key1', 'key2'])
    assert var.source == 'dic'
    assert var.exclude == ('key1', 'key2')
    assert var.unambiguous_source == 'dic'


# Generated at 2022-06-22 18:33:33.401988
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    frame_info = {'x': 1}
    variable = BaseVariable('x')
    assert variable.source == 'x'
    assert variable.exclude == ()
    assert variable.code == compile('x', '<variable>', 'eval')
    assert variable.unambiguous_source == 'x'
    assert variable.items(frame_info) == [('x', 1)]
    variable = BaseVariable('str(x)', exclude = 'str')
    assert variable.source == 'str(x)'
    assert variable.exclude == ('str',)
    assert variable.code == compile('str(x)', '<variable>', 'eval')
    assert variable.unambiguous_source == 'str(x)'
    assert variable.items(frame_info) == []

# Generated at 2022-06-22 18:33:41.230903
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import utils
    from . import pycompat

    assert pycompat.ABC in CommonVariable.__bases__
    assert CommonVariable.__name__ == 'CommonVariable'

    assert CommonVariable(source='x').source == 'x'
    assert CommonVariable(source='x').exclude == ('',)

    assert CommonVariable(source='x', exclude='a').exclude == ('a',)
    assert CommonVariable(source='x', exclude=('a',)).exclude == ('a',)
    assert CommonVariable(source='x', exclude=['a']).exclude == ('a',)



# Generated at 2022-06-22 18:33:43.498010
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    x = BaseVariable('1')
    y = BaseVariable('2')
 
    print(x.__hash__())
    print(y.__hash__())


# Generated at 2022-06-22 18:33:55.763143
# Unit test for constructor of class Indices
def test_Indices():
    from . import test_utils
    import datetime
    a = [1, 2, 3]
    v = Indices('a')
    assert test_utils.assert_items(v, a, [('a[0]', '1'), ('a[1]', '2'), ('a[2]', '3')])
    b = [1, [1, 2], 3]
    v = Indices('b')
    assert test_utils.assert_items(v, b, [('b[0]', '1'), ('b[1]', '[1, 2]'), ('b[2]', '3')])

    v = Indices('c')
    c = {'a': datetime.datetime.now(), 'b': None}

# Generated at 2022-06-22 18:34:01.288355
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('[x]')
    assert not needs_parentheses('object')
    assert needs_parentheses('object.value')
    assert needs_parentheses('object()')
    assert not needs_parentheses('object().value')

# Unit tests for Attrs

# Generated at 2022-06-22 18:34:07.839912
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from copy import copy
    from random import sample
    from string import ascii_letters
    from types import SimpleNamespace

    for seed in range(1000):
        for source in sample(ascii_letters, k=5):
            for exclude in sample(ascii_letters, k=5):
                a = BaseVariable(source, exclude)
                assert a.__hash__() == a.__hash__()
                assert a.__hash__() == copy(a).__hash__()



# Generated at 2022-06-22 18:34:09.854230
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a')
    assert a.source == 'a'
    assert a.exclude == ()


# Generated at 2022-06-22 18:34:13.046158
# Unit test for constructor of class Keys
def test_Keys():
    s = Keys(source, exclude=())
    assert s.source == source
    assert s.exclude == ()
    assert s.code == compile(source, '<variable>', 'eval')
    assert s.unambiguous_source == '(source)'


# Generated at 2022-06-22 18:34:22.004554
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('foo')
    slice_obj = obj[:]
    assert obj is not slice_obj
    assert slice_obj._slice is slice(None)
    slice_obj = obj[1:10:2]
    assert obj is not slice_obj
    assert slice_obj._slice is slice(1,10,2)
    slice_obj = obj[-10:-1:2]
    assert obj is not slice_obj
    assert slice_obj._slice is slice(-10,-1,2)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:34:24.761446
# Unit test for constructor of class Indices
def test_Indices():
    # Create a new instance
    index = Indices('foo')
    # If the item is a slice
    assert isinstance(slice, slice)
    # If a new instance is created
    assert isinstance(index[1:3], Indices)


# Generated at 2022-06-22 18:34:26.185746
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a')
    assert indices._slice is slice(None)

# Generated at 2022-06-22 18:34:37.566685
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import sys
    import copy
    import types
    import functools

    # __hash__ of BaseVariable has no inputs and return a constant.
    # __hash__ is a pure function if we ignore the fact that it gets implicit
    #   parameter 'self' as its first argument and returns a constant.
    # So we define our own hash function and call it with the same argument 'self'
    #   from __hash__ of BaseVariable
    # Our own hash function first gets all the useful (changing) attributes of BaseVariable,
    #   then call __hash__ of tuple with those attributes as its elements
    #   and return the result.
    def fun(self):
        attributes = []
        attributes.append(type(self))
        attributes.append(self.source)
        attributes.append(self.exclude)
        ret = tuple.__hash__

# Generated at 2022-06-22 18:34:42.947224
# Unit test for constructor of class Indices
def test_Indices():
    source = "arr"
    exclude = []
    idx = Indices(source, exclude)
    print(source, exclude)
    print(idx.source)
    print(idx._slice)
    print(isinstance(idx, Keys))
    print(isinstance(idx, Indices))
    print(idx[1:10])


# Generated at 2022-06-22 18:34:45.674962
# Unit test for constructor of class Exploding
def test_Exploding():
    a = Exploding('a')
    b = Exploding('b')
    assert hash(a) != hash(b)
    assert a._fingerprint != b._fingerprint




# Generated at 2022-06-22 18:34:49.022284
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('main_value')
    var_slice = var[:2]
    assert var_slice._slice == slice(None, 2)
    assert var_slice._fingerprint == (Indices, 'main_value', ())

# Generated at 2022-06-22 18:34:58.926214
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(5) == BaseVariable(5)
    assert BaseVariable(5) != BaseVariable(6)
    assert Attrs('a', exclude=('b', 1)) == Attrs('a', exclude=('b', 1))
    assert Attrs('a') != Attrs('b')
    assert Keys('a', exclude=('b', 1)) == Keys('a', exclude=('b', 1))
    assert Keys('a') != Keys('b')
    assert Indices('a', exclude=('b', 1)) == Indices('a', exclude=('b', 1))
    assert Indices('a') != Indices('b')
    assert Exploding('a', exclude=('b', 1)) == Exploding('a', exclude=('b', 1))
    assert Exploding('a') != Exploding('b')


# Generated at 2022-06-22 18:35:06.929173
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x', 'y')) == hash(BaseVariable('x', 'y'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('y'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('x', 'y'))
    assert hash(BaseVariable('x', 'y')) != hash(BaseVariable('y', 'y'))


# Generated at 2022-06-22 18:35:10.713070
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    base_variable = BaseVariable('source', 'exclude')

    assert(base_variable.source == 'source')
    assert(base_variable.exclude == 'exclude')
    assert(base_variable.code == compile('source', '<variable>', 'eval'))


# Generated at 2022-06-22 18:35:21.809664
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x.y[0]') == False
    assert needs_parentheses('x.y()') == False
    assert needs_parentheses('x.y()[0]') == False
    assert needs_parentheses('x.y[0].z') == False
    assert needs_parentheses('x.y[0]().z') == False
    assert needs_parentheses('x.y[0]()[1].z') == False

    assert needs_parentheses('1') == True
    assert needs_parentheses('-1') == True
    assert needs_parentheses('(1)') == False
    assert needs_parentheses('(-1)') == False
    assert needs_parentheses('1 + 2')

# Generated at 2022-06-22 18:35:24.829458
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    x = BaseVariable('x','y')
    assert(hasattr(x,'source'))
    assert(hasattr(x,'exclude'))
    assert(hasattr(x,'code'))
    assert(hasattr(x,'unambiguous_source'))


# Generated at 2022-06-22 18:35:32.441405
# Unit test for constructor of class Keys
def test_Keys():
    # Should be a instance of class CommonVariable
    assert isinstance(Keys('total_bytes'), CommonVariable)
    # Should be a instance of class Keys
    assert isinstance(Keys('total_bytes'), Keys)
    # Should not be a instance of class Indices or Attrs
    assert not isinstance(Keys('total_bytes'), (Indices, Attrs))
    # Should call constructor of class CommonVariable
    with patch('insight.helpers.CommonVariable') as mock_common_variable:
        Keys('total_bytes')
        mock_common_variable.assert_called()
        assert mock_common_variable.call_args[1]['source'] == 'total_bytes'
    # Should return an iterable of keys for the sequential object

# Generated at 2022-06-22 18:35:40.395322
# Unit test for constructor of class Indices
def test_Indices():
    if __name__ == '__main__':
        v = Indices('a')
        assert v.source == 'a'
        assert v.exclude == tuple()
        assert v._slice == slice(None)

        v = Indices('a', exclude='a')
        assert v.source == 'a'
        assert v.exclude == ('a', )
        assert v._slice == slice(None)

        v = Indices('a', 'b')
        assert v.source == 'a'
        assert v.exclude == ('b', )
        assert v._slice == slice(None)

        v = Indices('a', exclude=['b', 'c'])
        assert v.source == 'a'
        assert v.exclude == ('b', 'c')
        assert v._slice == slice(None)


# Generated at 2022-06-22 18:35:46.428416
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():    
    class Obj(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
        
    assert Obj('source') == Obj('source')
    assert Obj('source1') != Obj('source2')
    assert Obj('source', 'exclude') == Obj('source', 'exclude')
    assert Obj('source') != Obj('source', 'exclude')
    assert Obj('source', 'exclude1') != Obj('source', 'exclude2')

# Generated at 2022-06-22 18:35:49.754071
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        BaseVariable('a')
    except Exception:
        pass
    else:
        raise Exception('expected an error')


# Generated at 2022-06-22 18:35:53.238438
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('dict')
    assert Attrs('dict', '__dict__')
    assert Attrs('dict', ('__dict__', '__weakref__'))
