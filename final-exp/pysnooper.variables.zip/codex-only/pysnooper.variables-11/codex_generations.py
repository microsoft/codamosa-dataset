

# Generated at 2022-06-22 18:25:48.232168
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices._slice == slice(None)

    indices = Indices('a')[1:3]
    assert indices._slice == slice(1, 3)

# Generated at 2022-06-22 18:25:51.158294
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo')[2] == Indices('foo', slice(2))
    assert Indices('foo')[2:4] == Indices('foo', slice(2, 4))
    assert Indices('foo')[:4:2] == Indices('foo', slice(None, 4, 2))
    assert Indices('foo')[2:4:2] == Indices('foo', slice(2, 4, 2))

# Generated at 2022-06-22 18:25:55.933223
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestClass:
        def __init__(self):
            self.x = 1

    globals_ = {'c': TestClass()}

    # use class BaseVariable directly
    class A(BaseVariable):
        pass
    a = A('c')
    items = a.items(globals_)
    assert len(items) == 1

    # test Attrs
    class A(Attrs):
        pass
    a = A('c')
    items = a.items(globals_)
    assert len(items) == 2

    # test Keys
    class A(Keys):
        pass
    d = {'a': 1}
    a = A('d')
    items = a.items(globals_)
    assert len(items) == 1
    a = A('c')
    items = a

# Generated at 2022-06-22 18:25:59.652288
# Unit test for constructor of class Keys

# Generated at 2022-06-22 18:26:08.445269
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from copy import copy
    from pickle import dumps, loads
    assert ID(BaseVariable('a', exclude=[])) == ID(BaseVariable('a', exclude=[]))
    assert ID(BaseVariable('a', exclude=['a'])) != ID(BaseVariable('a', exclude=[]))
    assert ID(BaseVariable('a', exclude=[])) != ID(BaseVariable('b', exclude=[]))
    assert ID(BaseVariable('a', exclude=[])) != ID(Attrs('a', exclude=[]))
    assert ID(BaseVariable('a', exclude=[])) != ID(Keys('a', exclude=[]))
    assert ID(BaseVariable('a', exclude=[])) != ID(Indices('a', exclude=[]))
    assert ID(BaseVariable('a', exclude=[])) != ID(Exploding('a', exclude=[]))
   

# Generated at 2022-06-22 18:26:18.570735
# Unit test for constructor of class Exploding
def test_Exploding():
    frame = stack.ExtractedFrame(None, None, None)
    frame.f_locals['x'] = 'x'
    frame.f_locals['y'] = 'y'

    v = Exploding('x[0].y', 'x.y')
    frame.f_locals['x'] = {0: {'y': 'a'}, 1: {'y': 'b'}}
    assert set(v.items(frame)) == {('x[0].y.y', '"a"'), ('x[1].y.y', '"b"')}

    v = Exploding('(x[0])[1].y', 'x.y')
    frame.f_locals['x'] = {0: [{'y': 'a'}, {'y': 'b'}]}

# Generated at 2022-06-22 18:26:29.623696
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # CommonVariable
    CommonVariable("request")
    CommonVariable("request", "request")
    CommonVariable("request", {"request"})
    CommonVariable("request", ["request"])
    CommonVariable("request", "request", "request")
    CommonVariable("request", "request", {"request"})
    CommonVariable("request", "request", ["request"])
    CommonVariable("request", {"request"}, "request")
    CommonVariable("request", {"request"}, {"request"})
    CommonVariable("request", {"request"}, ["request"])
    CommonVariable("request", ["request"], "request")
    CommonVariable("request", ["request"], {"request"})
    CommonVariable("request", ["request"], ["request"])

    # Attrs
    Attrs("request")
    Attrs("request", "request")
    Attrs("request", {"request"})

# Generated at 2022-06-22 18:26:34.240391
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import _utils
    from .utils import _normalize, get_shortish_repr

    # Attributes
    class A:
        def __init__(self):
            self.a=1
            self.b=2
            self.c=3
    A=A()

    # Test function
    def _check(result,v):
        assert len(result)==len(v)
        for i in range(len(result)):
            assert result[i][1]==v[i]

    # Basic test - var.a
    v=["a","b","c"]
    source = "A"
    a=CommonVariable(source)
    result = list(a.items(None))
    _check(result, v)

    # Basic test - b.a

# Generated at 2022-06-22 18:26:36.621352
# Unit test for constructor of class Attrs
def test_Attrs():
    myClass = Attrs("myClass")
    assert myClass.source == "myClass"


# Generated at 2022-06-22 18:26:39.702136
# Unit test for constructor of class Attrs
def test_Attrs():
    for i in range(10):
        assert Attrs("obj.i").source == "obj.i"
        assert Attrs("obj.i").exclude == ()


# Generated at 2022-06-22 18:26:41.761322
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import inspect
    assert inspect.getargspec(BaseVariable.__hash__)


# Generated at 2022-06-22 18:26:45.648509
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('1')
    assert needs_parentheses('self')
    assert needs_parentheses('1 + 1')
    assert not needs_parentheses('(1 + 1)')


# Test for function utils.get_shortish_repr

# Generated at 2022-06-22 18:26:47.910523
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    y = x[2:]
    assert y._fingerprint == (x._fingerprint[0], x._fingerprint[1], y._slice)

# Generated at 2022-06-22 18:26:57.473221
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert needs_parentheses('foo.bar')
    assert needs_parentheses('f(1)')
    assert needs_parentheses('f(1, 2)')
    assert needs_parentheses('(1, 2)')
    assert not needs_parentheses('foo.bar.baz')
    assert not needs_parentheses('foo.bar.baz[0]')
    assert not needs_parentheses('(w or x).y')
    assert not needs_parentheses('(w or x)[y]')
    assert not needs_parentheses('w or (x and y)')
    assert not needs_parentheses('(a, b).c')

# Generated at 2022-06-22 18:27:02.504951
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('b')
    assert not BaseVariable('a') == BaseVariable('c')
    assert not BaseVariable('b') == BaseVariable('a')
    assert BaseVariable('b') == BaseVariable('b')
    assert not BaseVariable('c') == BaseVariable('a')
    assert BaseVariable('c') == BaseVariable('c')



# Generated at 2022-06-22 18:27:08.577868
# Unit test for constructor of class Attrs
def test_Attrs():
    d = {'message':"hello world"}
    x = 'message'
    d1 = Attrs(x)
    assert d1.source == 'message'
    assert d1.exclude == ()
    assert d1.code == compile('message', '<variable>', 'eval')


# Generated at 2022-06-22 18:27:19.658393
# Unit test for constructor of class Keys
def test_Keys():
    # Testing correct key-value pairs
    assert Keys('a.b').items({'a': {'b': 5}}) == [
        ('a.b', '5')
    ]
    assert Keys('a.b').items({'a': {'b': {'c': 5}}}) == [
        ('a.b', '{...}'),
        ('a.b.c', '5')
    ]

# Generated at 2022-06-22 18:27:24.757895
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    temp = BaseVariable(source = "result['val'][frame.f_lineno]", exclude = "lineno")
    temp.code = compile("result['val'][frame.f_lineno]", '<variable>', 'eval')
    temp.unambiguous_source = "result['val'][frame.f_lineno]"
    assert temp.__hash__() == temp._fingerprint.__hash__()

# Generated at 2022-06-22 18:27:27.983484
# Unit test for constructor of class Indices
def test_Indices():
    assert 'slice' in dir(Indices) and '__init__' in dir(Indices)

# Generated at 2022-06-22 18:27:29.684385
# Unit test for constructor of class Indices
def test_Indices():
    assert type(Indices('a')[1]) == Indices

# Generated at 2022-06-22 18:27:33.144356
# Unit test for constructor of class BaseVariable
def test_BaseVariable(): # pragma: no cover
    local_varible = BaseVariable('local_varible')
    assert local_varible.source == 'local_varible'
    assert local_varible.unambiguous_source == 'local_varible'

# Generated at 2022-06-22 18:27:44.168352
# Unit test for constructor of class Keys
def test_Keys():
    var1 = Keys('a', exclude=('b',))
    # The following attribute should be replaced with property
    # when there are more attributes
    assert var1.source == 'a'
    assert var1.exclude == ('b',)
    # The following attribute should be replaced with property
    # when there are more attributes
    assert var1.unambiguous_source == 'a'
    D = {'a':'a value', 'b':'b value'}
    # The following attribute should be replaced with property
    # when there are more attributes
    assert var1._keys(D) == ('a', 'b')
    assert var1._format_key('key') == '[key]'
    assert var1._format_key(1) == '[1]'

# Generated at 2022-06-22 18:27:52.552716
# Unit test for constructor of class Indices
def test_Indices():
    """
    In this method, we test that the constructor of class Indices 
    works properly.
    """
    # Create the Index object
    newIndex = Indices('myMainVar', exclude=...)

    # Test if the variables have the expected values
    assert newIndex.source == 'myMainVar'
    assert newIndex.exclude == (...)
    assert newIndex.code == compile('myMainVar', '<variable>', 'eval')
    assert newIndex.unambiguous_source == 'myMainVar'
    assert newIndex._slice == slice(None)


# Generated at 2022-06-22 18:27:58.927813
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import pytest
    from .pycompat import ABC
    x = BaseVariable
    x1 = BaseVariable('a')
    x1_dup = BaseVariable('a')
    x2 = BaseVariable('b')
    
    assert x('a') == x('a')
    assert x('a') != x('b')
    assert hash(x) != hash(x1)
    assert hash(x1) == hash(x1_dup)
    assert x1 != x2
    assert isinstance(x1,x)
    assert isinstance(x1,ABC)

# Generated at 2022-06-22 18:28:00.504407
# Unit test for constructor of class Keys
def test_Keys():
    Keys(source).__init__(source)


# Generated at 2022-06-22 18:28:04.245961
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    test_source = "a+b"
    test_exclude = "a"
    test_obj = BaseVariable(test_source,test_exclude)
    assert test_obj.source == test_source
    assert test_obj.exclude == test_exclude
    assert test_obj.code == compile(test_source, '<variable>', 'eval')

# Generated at 2022-06-22 18:28:10.486659
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo(bar)')
    assert needs_parentheses('function(x)')
    assert needs_parentheses('lambda x: x')
    assert needs_parentheses('function(x=y)')
    assert needs_parentheses('(x)')
    assert needs_parentheses('function(*args)')
    assert needs_parentheses('function(**kwargs)')



# Generated at 2022-06-22 18:28:17.025349
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('format', 'style')
    y = Keys('format', 'style')

    assert x == y
    assert hash(x) == hash(y)

    assert x._fingerprint == y._fingerprint
    assert x._fingerprint[2] == 'style'
    assert x._fingerprint[1] == 'format'

    assert x.code.co_names == ('format', )
    assert x.code.co_varnames == ()

# Generated at 2022-06-22 18:28:21.552093
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = "x"
    exclude = "y"
    variable = CommonVariable(source, exclude)
    assert variable.source == source
    assert variable.exclude == (exclude,)
    assert variable.code
    assert variable.unambiguous_source == source
    assert variable.items(1, 2) == []


# Generated at 2022-06-22 18:28:24.135739
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v = CommonVariable('var', exclude=['a','b','c'])
    print('source: ', v.source)
    print('exclude: ', v.exclude)

# Generated at 2022-06-22 18:28:25.923081
# Unit test for constructor of class Indices
def test_Indices():
    variables = Indices('abcdef')
    print(variables)

# Generated at 2022-06-22 18:28:34.238046
# Unit test for constructor of class Keys
def test_Keys():
    dict_1 = {'a':1, 'b':2, 'c':3}
    keys_1 = Keys('dict_1').items({'dict_1': dict_1})
    dict_2 = dict(zip(keys_1, range(len(keys_1))))
    assert dict_1 == dict_2
    
    list_1 = [1, 2, 3]
    keys_2 = Keys('list_1').items({'list_1': list_1})
    dict_3 = dict(zip(keys_2, list_1))
    assert True == False

    class A:
        a = 1
        b = 2
        c = 3
    a = A()
    keys_3 = Keys('a').items({'a': a})
    dict_4 = {}

# Generated at 2022-06-22 18:28:44.962981
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import os
    import tempfile
    frame = sys._getframe(0)
    # Get file path of test_BaseVariable_items
    test_file_path = inspect.getsourcefile(test_BaseVariable_items)
    # Create a temporary file in test_BaseVariable_items's directory
    fd, temp_file_path = tempfile.mkstemp(dir=os.path.dirname(test_file_path))
    # Add the temporary file to frame.f_locals
    frame.f_locals['temp_file_path'] = temp_file_path
    # Remove the temporary file
    os.remove(temp_file_path)
    # List of tuples containing the source, exclude, frame and the expected items

# Generated at 2022-06-22 18:28:49.889026
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    dict1 = {'a':1, 'b':2, 'c':3}
    dict2 = {'a':1, 'b':2, 'c':3}
    dict3 = {'a':1, 'b':2, 'c':4}
    assert dict1 == dict2
    assert dict1 != dict3

# Generated at 2022-06-22 18:28:57.230740
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # This test should be in a class for unit test.
    # Here only for test_BaseVariable___hash__.
    from hypothesis import given
    from hypothesis import strategies as st

    @given(st.data())
    def test_BaseVariable___hash__(data):
        source = data.draw(st.text())
        exclude = data.draw(st.lists(st.text(), max_size=2))
        exclude = tuple(set(exclude))
        data_1 = BaseVariable(source, exclude)
        data_2 = BaseVariable(source, exclude)
        assert hash(data_1) == hash(data_2)
    try:
        test_BaseVariable___hash__()
    except BaseException:
        pass
    else:
        raise Exception('Except BaseException, but not raised.')




# Generated at 2022-06-22 18:29:03.723996
# Unit test for constructor of class Exploding
def test_Exploding():
    # Initializes a class of Exploding
    ev = Exploding('string')
    # Tests source of the class
    assert ev.source == 'string'
    # Tests exclude of the class
    assert ev.exclude == ()
    # Tests code of the class
    assert ev.code.co_name == '<module>'
    # Tests the value of unambiguous source
    assert ev.unambiguous_source == 'string'


# Generated at 2022-06-22 18:29:13.342133
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class Test(object):
        def __init__(self, name):
            self.name = name
    test = Test('test')

    # Test slice with 2 args
    test_slice = Indices('test[slice(1, 1)]')
    value = test_slice[slice(1, 1)]
    assert value._fingerprint == (Indices, 'test[slice(1, 1)]', ())
    assert value._slice == slice(1, 1)

    # Test slice with 1 arg
    test_slice = Indices('test[slice(1)]')
    value = test_slice[slice(1)]
    assert value._fingerprint == (Indices, 'test[slice(1)]', ())
    assert value._slice == slice(1)

    # Test slice with 3 args

# Generated at 2022-06-22 18:29:22.749168
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices(source='my_var', exclude='a',)
    assert i.source == 'my_var'
    assert i.exclude == ('a',)
    assert i.code == compile('my_var', '<variable>', 'eval')
    assert i.unambiguous_source == 'my_var'
    assert i._slice == slice(None)
    
    assert i._keys(['a', 'b', 'c']) == [0, 1, 2]
    assert i._format_key(1) == '[1]'
    assert i._get_value(['a', 'b', 'c'], 1) == 'b'


# Generated at 2022-06-22 18:29:33.205033
# Unit test for constructor of class Attrs
def test_Attrs():
    #initialize a variable
    main_value = {}
    main_value.__dict__ = {'a':'1','b':'2'}
    main_value.__slots__ = ('c','d')
    #initialize a variable variable
    variable = Attrs('main_value', ('a',))
    #check the output
    assert variable._keys(main_value) == ('b', 'a', 'c', 'd')
    assert variable._get_value(main_value, 'b') == '2'
    assert variable._format_key('b') == '.b'
    variable_items = variable.items(main_value)
    assert variable_items[1][0] == 'main_value.b'
    #check the fingerprint
    fingerprint = variable._fingerprint

# Generated at 2022-06-22 18:29:42.274338
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('(x)') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x().y') == True
    assert needs_parentheses('x().y.z') == False
    assert needs_parentheses('(x).y.z') == False
    assert needs_parentheses('x.y().z') == True
    assert needs_parentheses('(x()).y().z') == True
    assert needs_parentheses('(x.y()).z') == False
    assert needs_parentheses('x[y]') == False
    assert needs_parentheses('(x[y])') == False
    assert needs_parentheses('x().y[z]') == True

# Generated at 2022-06-22 18:29:47.095288
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class D(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()
        def _format_key(self, key):
            return '*' + key
        def _get_value(self, main_value, key):
            return main_value[key]
    source = 'd'
    exclude = ('ex', )
    d = {'a': 1, 'b': 2, 'ex': 'excluded'}
    expected = [('d', 'dict'), ('d*a', '1'), ('d*b', '2')]
    assert D(source, exclude).items(d) == expected

# Generated at 2022-06-22 18:29:51.632326
# Unit test for constructor of class Indices
def test_Indices():
    source = 'a_list'
    exclude = ()
    code = compile(source, '<variable>', 'eval')
    assert code.co_code == b'a_list\x00\x83\x01\x00\x00'
    obj = Indices(source, exclude)
    assert obj.source == source
    assert obj.exclude == exclude
    assert obj.code == code
    assert obj.unambiguous_source == source
    assert obj._slice == slice(None)
    assert obj._fingerprint == (Indices, source, exclude)

# Generated at 2022-06-22 18:29:59.470329
# Unit test for constructor of class Attrs
def test_Attrs():
    class Test(object):
        var1 = 'python'
        var2 = {'1': 'py'}
    var = Test()
    v_eval = Attrs('var')
    assert v_eval.source == 'var'
    assert v_eval.code == compile('var', '<variable>', 'eval')
    assert v_eval._fingerprint == (Attrs, 'var', ())
    v_eval_items = v_eval.items(Test().__dict__, normalize=False)
    assert v_eval_items == [('var', "Test()"), ('var.var1', "'python'"), ('var.var2', "{'1': 'py'}")]
    v_eval_items = v_eval.items(Test().__dict__, normalize=True)

# Generated at 2022-06-22 18:30:04.082372
# Unit test for constructor of class Keys
def test_Keys():
    d = {1:2,3:4}
    k = Keys('d')
    assert k.source == 'd'
    assert k.code.co_names[0] == 'd'
    assert k.exclude == ()
    assert k.unambiguous_source == 'd'

    assert k._keys(d) == [1,3]


# Generated at 2022-06-22 18:30:09.942935
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('request.POST[0]')
    assert isinstance(a, Indices)
    assert a.source == 'request.POST[0]'
    assert a.exclude == ()
    assert a.code == compile('request.POST[0]', '<variable>', 'eval')
    assert a.unambiguous_source == 'request.POST[0]'


# Generated at 2022-06-22 18:30:13.719343
# Unit test for constructor of class Attrs
def test_Attrs():
    a=Attrs('', ()).__init__(1)
    if a.source != 1:
        raise AssertionError()

    a=Attrs('', ()).__init__(1, ())
    if a.source != 1:
        raise AssertionError()

    a=Attrs('', ()).__init__(1, 2)
    if a.exclude != (2,):
        raise AssertionError()

test_Attrs()

# Generated at 2022-06-22 18:30:23.382407
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a', ('b', 'c')) == Attrs('a', ('b', 'c'))
    assert Attrs('a', ('b', 'c')) != Attrs('a', ('c', 'd'))
    assert Attrs('a', ('b', 'c')) != Attrs('b', ('b', 'c'))
    assert Attrs('a', ('b', 'c')) != Attrs('a', ('b'))
    assert Keys('a', ('b', 'c')) == Keys('a', ('b', 'c'))
    assert Keys('a', ('b', 'c')) != Keys('a', ('c', 'd'))
    assert Keys('a', ('b', 'c')) != Keys('b', ('b', 'c'))

# Generated at 2022-06-22 18:30:28.949083
# Unit test for constructor of class Exploding
def test_Exploding():
    assert issubclass(Attrs, CommonVariable)
    assert issubclass(Keys, CommonVariable)
    assert issubclass(Indices, Keys)
    assert issubclass(Exploding, BaseVariable)

    assert isinstance(Attrs, type)
    assert isinstance(Keys, type)
    assert isinstance(Indices, type)
    assert isinstance(Exploding, type)

# Generated at 2022-06-22 18:30:34.814193
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('self.some_value', exclude='__dict__')
    assert variable.source == 'self.some_value'
    assert variable.exclude == ('__dict__', )
    assert variable.code == compile('self.some_value', '<variable>', 'eval')
    assert variable.unambiguous_source == 'self.some_value'


# Generated at 2022-06-22 18:30:44.573898
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Stub(BaseVariable):
        def __init__(self, source, exclude=()):
            super(Stub, self).__init__(source, exclude)

        def items(self, frame, normalize=False):
            return self._items(None, normalize)

        def _items(self, main_value, normalize=False):
            return ()

    source = 'name'
    exclude = []
    var1 = Stub(source, exclude)
    var2 = Stub(source, exclude)
    assert var1 == var2

    var3 = Stub(source + '1', exclude)
    assert var1 != var3
    assert var2 != var3

    var4 = Stub(source, exclude + [1])
    assert var1 != var4
    assert var2 != var4

# Generated at 2022-06-22 18:30:54.350194
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('x')
    assert variable.source == 'x'
    assert variable.exclude == ()
    assert variable.code == compile('x', '<variable>', 'eval')
    assert variable.unambiguous_source == 'x'
    variable1 = BaseVariable('x', 'y')
    assert variable1.source == 'x'
    assert variable1.exclude == 'y'
    assert variable1.code == compile('x', '<variable>', 'eval')
    assert variable1.unambiguous_source == 'x'
    variable2 = BaseVariable('x', 'y', 'z')
    assert variable2.source == 'x'
    assert variable2.exclude == ('y', 'z')
    assert variable2.code == compile('x', '<variable>', 'eval')

# Generated at 2022-06-22 18:31:00.786413
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    variable1 = BaseVariable('variable1')
    variable1_copy = BaseVariable('variable1')
    variable2 = BaseVariable('variable2')

    dict_variables = {}
    dict_variables[variable1] = 'variable1'
    dict_variables[variable1_copy] = 'variable1_copy'
    dict_variables[variable2] = 'variable2'

    assert dict_variables[variable1] == 'variable1_copy'
    assert dict_variables[variable1_copy] == 'variable1_copy'
    assert dict_variables[variable2] == 'variable2'



# Generated at 2022-06-22 18:31:02.685268
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys("self", exclude='a')


# Generated at 2022-06-22 18:31:08.544873
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    """
    >>> test = CommonVariable("x")
    >>> test.code
    <code object <module> at 0x..., file "<variable>", line 1>
    >>> test.unambiguous_source
    'x'
    >>> test.source
    'x'
    >>> test.exclude
    ()
    """
    pass


# Generated at 2022-06-22 18:31:10.770698
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # Test code for constructor of class BaseVariable
    source = '__builtins__'
    BaseVariable(source)


# Generated at 2022-06-22 18:31:17.304426
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys("x").source == "x"
    assert Keys("x", "y", "z").exclude == ('y', 'z')
    assert Keys("x", "y", "z").code == compile('x', '<variable>', 'eval')
    assert Keys("x", "y", "z").unambiguous_source == 'x'
    assert Keys("longname.with.dots_and_underscores").unambiguous_source == '(longname.with.dots_and_underscores)'
    assert Keys("(longname.with_dots_and_underscores).x") == Keys("longname.with_dots_and_underscores.x")



# Generated at 2022-06-22 18:31:20.241114
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('self.context')
    assert x.source == 'self.context'
    result = eval(x.code)
    assert result


# Generated at 2022-06-22 18:31:26.008757
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c_var = CommonVariable('cs115.gpas', 'gpas.num_courses')
    assert c_var.source == 'cs115.gpas'
    assert c_var.exclude == ('gpas.num_courses',)
    assert c_var.code
    assert c_var.unambiguous_source == '(cs115.gpas)'



# Generated at 2022-06-22 18:31:35.784911
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import unittest
    class TestCase(unittest.TestCase):
        pass
    test_case = TestCase()
    frame = sys._getframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = [1, 2]
    frame.f_locals['c'] = 'abc'
    frame.f_locals['d'] = {'a': 1}
    def test_common(self, source, expected):
        test_case.assertEqual(expected, list(CommonVariable(source).items(frame)))

# Generated at 2022-06-22 18:31:42.376269
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import _test_utils
    import sys
    import unittest
    import mock

    class TestVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            pass

        def _items(self, key, normalize=False):
            return (('1', 1), ('2', 2,), ('3', 3))

    class BaseVariableTest(unittest.TestCase):
        def test_variable_items(self):
            frame = _test_utils.make_fake_frame()
            #monkey patch frame.f_locals and frame.f_globals

# Generated at 2022-06-22 18:31:52.943003
# Unit test for constructor of class Indices
def test_Indices():
    from mock import Mock
    from .pycompat import PY2

    mock = Mock()
    mock.__len__ = Mock()
    mock.__len__.return_value = None

    # Python 2
    if PY2:
        mock.__getslice__ = Mock()
        mock.__getslice__.return_value = None
        Indices('xx')
        mock.__len__.assert_called_once_with()
        mock.__getslice__.assert_called_once_with(0, mock.__len__.return_value)
    # Python 3
    else:
        Indices('xx')
        mock.__len__.assert_called_once_with()

# Generated at 2022-06-22 18:32:03.237370
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("var")
    result = var[1:2]
    assert(result._slice == slice(1, 2))
    assert(result._fingerprint == (Indices, "var", ()))
    assert(result.unambiguous_source == "(var)")
    assert(result.source == "var")
    assert(result.exclude == ())
    assert(Indices("var")[1:3][1:2]._slice == slice(1, 2))
    assert(Indices("var")[1:3][1:2]._fingerprint == (Indices, "var", ()))
    assert(Indices("var")[1:3][1:2].unambiguous_source == "(var)")
    assert(Indices("var")[1:3][1:2].source == "var")

# Generated at 2022-06-22 18:32:08.838286
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    Main = BaseVariable('main')
    Attr = BaseVariable('main.attr')
    Other = BaseVariable('other')

    assert Main == Main
    assert Attr == Attr
    assert Other == Other

    assert Main != Attr
    assert Main != Other
    assert Attr != Main
    assert Attr != Other
    assert Other != Main
    assert Other != Attr


# Generated at 2022-06-22 18:32:12.511892
# Unit test for constructor of class Attrs

# Generated at 2022-06-22 18:32:14.604887
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert len(Indices('i')[0:2].items('a')) == 2

# Generated at 2022-06-22 18:32:19.523491
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    try:
        from faulthandler import enable
    except ImportError:
        pass
    else:
        enable()

    test_list = [1, 2, 3, 4]
    test_slice1 = Indices('test_list')[2:5]
    assert test_slice1._slice == slice(2, 5)

# Generated at 2022-06-22 18:32:20.354590
# Unit test for constructor of class Indices
def test_Indices():
	indices = Indices('x', exclude='z')

# Generated at 2022-06-22 18:32:24.886618
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'foo'
    bv = BaseVariable(source)
    assert bv.source == source
    assert isinstance(bv, BaseVariable)
    assert bv.code == compile(source, '<variable>', 'eval')
    assert bv.unambiguous_source == '({})'.format(source)

# Generated at 2022-06-22 18:32:26.023898
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('this[is][a]test') is not None

# Generated at 2022-06-22 18:32:29.647601
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'x'; exclude = '__init__'
    BaseVariable = BaseVariable(source, exclude)
    assert BaseVariable.source == source
    assert BaseVariable.exclude == exclude or ()
    # TODO: remove if else

# Generated at 2022-06-22 18:32:36.707289
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', ['b'])
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', ['b']) != BaseVariable('a', 'c')
    assert BaseVariable('a', ['b']) != BaseVariable('b', ['b'])



# Generated at 2022-06-22 18:32:46.609380
# Unit test for constructor of class Keys
def test_Keys():
    mydict = {'x': 1, 'y': 2, 'z': 3}
    mylist = ['s', 't', 'u']
    s = {'mydict': mydict, 'mylist': mylist}
    g = {'__builtins__': __builtins__}
    l = {}
    keys = Keys('mydict')
    assert keys.source == 'mydict'
    assert keys.exclude == tuple()
    assert keys.unambiguous_source == 'mydict'
    #
    assert keys.items(frame=utils.Frame(s, g, l)) == [
        ('mydict', '{...}'),
        ('mydict[\'x\']', '1'),
        ('mydict[\'y\']', '2'),
        ('mydict[\'z\']', '3')
    ]

# Generated at 2022-06-22 18:32:49.749545
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'test.source'
    exclude = 'test.exclude'
    CommonVariable(source, exclude)

# Generated at 2022-06-22 18:32:52.089670
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding("a.b")._items({'a':{'b':'c'}})[0], tuple)

# Generated at 2022-06-22 18:33:00.445170
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert not needs_parentheses('(a)')
    assert needs_parentheses('[a]')
    assert not needs_parentheses('([a])')
    assert needs_parentheses('{a}')
    assert not needs_parentheses('({a})')
    assert not needs_parentheses('-1')
    assert needs_parentheses('-1.')
    assert not needs_parentheses('(-1)')
    assert needs_parentheses('[]')
    assert needs_parentheses('[][]')
    assert needs_parentheses('()')
    assert not needs_parentheses('([])')
    assert needs_parentheses('{}')
    assert needs_parentheses('{}()')
    assert needs_parentheses('{}[]')

# Generated at 2022-06-22 18:33:08.331485
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('x').source == 'x'
    assert BaseVariable('x').exclude == tuple()
    assert BaseVariable('x', 'y').exclude == ('y',)
    assert BaseVariable('x', 'y').source == 'x'
    assert BaseVariable('x', 'y').exclude == ('y',)
    assert BaseVariable('x', 'y').exclude == ('y',)
    assert BaseVariable('x', 'y', 'z').exclude == ('y', 'z')


# Generated at 2022-06-22 18:33:11.189033
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'foo'
    exclude = ('bar',)
    assert BaseVariable(source, exclude) == BaseVariable(source, exclude)

# Generated at 2022-06-22 18:33:19.787637
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_source = "my_list"
    test_value = [1, 2, 3, 4, 5]
    test_variable = Indices(test_source)


# Generated at 2022-06-22 18:33:21.205650
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source='abc'
    exclude=()
    variable = CommonVariable(source, exclude)
    assert variable.source == source
    assert variable.exclude == exclude


# Generated at 2022-06-22 18:33:27.420261
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x', exclude=('a', 'b')) == Keys('x', exclude=('a', 'b'))
    assert Keys('x', exclude=('a', 'b')) != Keys('y', exclude=('a', 'b'))
    assert Keys('x', exclude='a') == Keys('x', exclude=('a',))
    assert Keys('x', exclude='a') != Keys('x', exclude='b')

# Generated at 2022-06-22 18:33:29.091230
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # TODO
    assert False, "Test not implemented"



# Generated at 2022-06-22 18:33:31.473023
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('request.POST')
    assert a.source == 'request.POST'
    assert a.exclude == []


# Generated at 2022-06-22 18:33:42.772031
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from . import BaseVariable
    from . import Attrs
    from . import Keys
    from . import Indices
    from . import Exploding
    from . import utils
    from . import pycompat

    x = BaseVariable('x')
    assert x.__hash__() == BaseVariable('x').__hash__()

    x = Attrs('x')
    assert x.__hash__() == Attrs('x').__hash__()

    x = Keys('x')
    assert x.__hash__() == Keys('x').__hash__()

    x = Indices('x')
    assert x.__hash__() == Indices('x').__hash__()

    x = Exploding('x')
    assert x.__hash__() == Exploding('x').__hash__()


# Generated at 2022-06-22 18:33:48.902515
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    '''
    >> v1 = BaseVariable('a', 'b')
    >> v2 = BaseVariable('a', 'b')
    >> v3 = BaseVariable('a', 'c')
    >> hash(v1) == hash(v2)
    True
    >> hash(v1) == hash(v3)
    False
    '''


# Generated at 2022-06-22 18:34:00.529500
# Unit test for constructor of class Keys
def test_Keys():
    from . import lazy_object
    from . import library
    from . import utils
    import types
    import inspect
    import numpy as np

    def get_dict_from_map(map_object):
        return dict(zip(map_object.keys(), map_object.values()))
    def get_dict_from_map_mapping(map_mapping_object):
        return dict(zip(map_mapping_object.keys(), map_mapping_object.values()))
    def get_dict_from_map_mapping_protocol(map_mapping_protocol_object):
        return dict(zip(map_mapping_protocol_object.keys(), map_mapping_protocol_object.values()))

# Generated at 2022-06-22 18:34:04.723075
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('foo')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo().bar')
    assert not needs_parentheses('foo[1]')
    assert needs_parentheses('foo[1].bar')
    assert needs_parentheses('foo().bar[1]')

# Generated at 2022-06-22 18:34:06.119059
# Unit test for constructor of class Exploding
def test_Exploding():
    isinstance(Exploding('foo'), BaseVariable)



# Generated at 2022-06-22 18:34:09.558591
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    items = indices['1:4']
    for i in range(0, 4):
        assert(items.source == 'a')

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:34:15.678525
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class BaseVariable(BaseVariable):
        def __init__(self):
            self.source = 'a.b'
            self.code = compile(self.source, '<variable>', 'eval')

        def _items(self, key, normalize=False):
            pass

    b = BaseVariable()
    assert b.unambiguous_source == '(a.b)'


# Generated at 2022-06-22 18:34:26.600493
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class MockObject(object):
        pass
    mock = MockObject()
    basevar = BaseVariable('source')
    assert basevar.source == 'source'
    assert basevar.exclude == ()
    assert basevar.code == compile('source', '<variable>', 'eval')
    assert basevar.unambiguous_source == 'source'
    basevar = BaseVariable('source', 'mock')
    assert basevar.source == 'source'
    assert basevar.exclude == ('mock',)
    assert basevar.code == compile('source', '<variable>', 'eval')
    assert basevar.unambiguous_source == 'source'
    assert basevar.__eq__(basevar)
    assert not basevar.__eq__(mock)

# Generated at 2022-06-22 18:34:29.575346
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    uut = Indices('')
    assert uut[2:5]._slice == slice(2, 5)


# Generated at 2022-06-22 18:34:39.383782
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import collections
    import types
    import os
    import sys
    import re

    def test():
        import inspect
        import collections
        import types
        import os
        import sys
        import re

    class Foo(object):
        def __init__(self):
            self.x = 'a'
            self.y = {}
            self.z = 'b'
            self.w = 'c'

    foo = Foo()
    #print(Attrs('foo').items(inspect.currentframe()))
    print(Indices('foo.y').items(inspect.currentframe()))
    #print(Keys('foo.y').items(inspect.currentframe()))

    #print(Exploding('foo').items(inspect.currentframe()))
    #print(Exploding('foo.y').items

# Generated at 2022-06-22 18:34:47.812235
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import sys
    def callable_func():
        pass
    main_frame = sys._getframe()
    test_instance = BaseVariable('callable_func', exclude=('__name__',))
    assert test_instance.code.co_names == ('callable_func',)
    assert test_instance.source == 'callable_func'
    assert test_instance.unambiguous_source == 'callable_func'
    assert test_instance.exclude == ('__name__',)
    assert test_instance.items(main_frame) == (('callable_func', 'test_BaseVariable.<locals>.callable_func'),)
    assert test_instance._items(object) == ()
    

# Generated at 2022-06-22 18:34:56.698410
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    for variable_cls, variable_args, variable_kwargs in (
        (Attrs, (), {'source':'frame'}),
            (Keys, (), {'source':'frame', 'exclude':('foo', 'bar')}),
                (Indices, (), {'source':'frame'}),
                    (Exploding, (), {'source':'frame'}),
    ):
        assert variable_cls(*variable_args, **variable_kwargs) == variable_cls(*variable_args, **variable_kwargs)
        assert not (variable_cls(*variable_args, **variable_kwargs) == variable_cls())
#
# Unit tests for method __hash__ of class BaseVariable

# Generated at 2022-06-22 18:35:01.107167
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('tmp')
    assert Indices(tmp = 0)
    assert Indices(0)
    assert Indices([0])
    assert Indices((0,))
    assert Indices(slice(0, 1))
    return


# Generated at 2022-06-22 18:35:06.426328
# Unit test for constructor of class Attrs
def test_Attrs():
    class A(object):
        def __init__(self, d):
            self.__dict__ = d
            
    a = A({'x':10, 'y':20})
    ex = Attrs('a')
    print(ex.items(a))

# Generated at 2022-06-22 18:35:15.577631
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'c') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')
    assert BaseVariable('a') != Indices('a')
    assert BaseVariable('a') != Exploding('a')

# Generated at 2022-06-22 18:35:26.472135
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import types
    import inspect

    class TestClass(object):
        def __init__(self):
            self.attr1 = 1
            self.attr2 = 2

        def test_method(self):
            return 3

    instance = TestClass()

    assert isinstance(Attrs('instance'), CommonVariable)
    assert isinstance(Keys('instance'), CommonVariable)
    assert isinstance(Indices('instance'), CommonVariable)

    assert isinstance(Attrs('instance', exclude='attr1'), CommonVariable)
    assert isinstance(Keys('instance', exclude='attr1'), CommonVariable)
    assert isinstance(Indices('instance', exclude='attr1'), CommonVariable)

    assert isinstance(Attrs('instance', exclude=['attr1']), CommonVariable)
    assert isinstance(Keys('instance', exclude=['attr1']), CommonVariable)


# Generated at 2022-06-22 18:35:33.614773
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert needs_parentheses("x") == False
    assert needs_parentheses("(x)") == False
    assert needs_parentheses("x+1") == True
    assert needs_parentheses("x[0]") == True
    assert needs_parentheses("x.y") == True
    
    x = BaseVariable("x")
    assert x.source == "x"
    assert x.exclude == ()
    assert type(x.code) == types.CodeType

    x = BaseVariable("x", "y")
    assert x.source == "x"
    assert x.exclude == ("y",)

    x = BaseVariable("x", ("y", "z"))
    assert x.source == "x"
    assert x.exclude == ("y", "z")


# Generated at 2022-06-22 18:35:37.511345
# Unit test for constructor of class Attrs
def test_Attrs():
    v = Attrs("expression","a,b")
    assert v.source == "expression"
    assert v.exclude == ("a","b")
    assert v.unambiguous_source == "expression"
    assert v.code == compile("expression", '<variable>', 'eval')
    

# Generated at 2022-06-22 18:35:45.472333
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_Indices = Indices('a[1]')
    test_Indices_slice1 = test_Indices[2]
    assert test_Indices_slice1._keys(['a', 'b', 'c']) == [2, 3]
    test_Indices_slice2 = test_Indices[:4]
    assert test_Indices_slice2._keys(['a', 'b', 'c']) == [0, 1, 2]

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:35:48.732360
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable(source='', exclude=())

