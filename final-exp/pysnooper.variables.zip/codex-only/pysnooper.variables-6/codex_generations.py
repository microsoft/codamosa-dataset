

# Generated at 2022-06-22 18:25:58.767814
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    info = get_info()
    assert len(info) == 1
    (frame, locals) = info[0]
    assert frame.code.name == 'test_BaseVariable'
    assert locals == {'variable': Attrs('variable')}
    assert frame.f_locals['variable'].items(frame)[0] == ('variable', '<attribute>')

test_BaseVariable.__test__ = True


# Generated at 2022-06-22 18:26:03.370600
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v1 = CommonVariable("a","b")
    v2 = CommonVariable("a")
    v3 = CommonVariable("a")
    v4 = CommonVariable("b")

    assert v1 != v2
    assert v3 == v2
    assert v3 != v4

    assert v4 != v3
    assert v4 != v2
    assert v4 != v1
    assert v4 != 'b'
    assert v4 != 123



# Generated at 2022-06-22 18:26:11.449306
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    assert a[:]._slice == slice(None)

    a = Indices("a")
    assert a[:5]._slice == slice(None, 5)

    a = Indices("a")
    assert a[2:]._slice == slice(2, None)

    a = Indices("a")
    assert a[:-1]._slice == slice(None, -1)

    a = Indices("a")
    assert a[2:10]._slice == slice(2, 10)

    a = Indices("a")
    assert a[2:10:2]._slice == slice(2, 10, 2)

    a = Indices("a")
    assert a[10:2:-1]._slice == slice(10, 2, -1)

# Generated at 2022-06-22 18:26:15.051821
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    #instance of class Indices
    indices = Indices('args')

    #slice testing
    test_slice = slice(1,3,1)
    indices_with_slice = indices[test_slice]

    assert indices_with_slice._slice is test_slice, "incorrect slice"

# Generated at 2022-06-22 18:26:22.383696
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import numpy as np
    import yaml
    frame = None

# Generated at 2022-06-22 18:26:28.468803
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import pytest
    c = CommonVariable(source='abc')
    assert c.source == 'abc'
    assert c.exclude == ()
    try:
        assert isinstance(c.code, type(compile('1', '', 'eval')))
    except AssertionError as e:
        assert type(c.code) == type(compile('1', '', 'eval'))
    assert c.unambiguous_source == 'abc'
    with pytest.raises(NotImplementedError):
        c._items(1)
    assert c._fingerprint == (CommonVariable, 'abc', ())
    try:
        hash(c)
    except TypeError as e:
        assert e.args[0] == 'unhashable type: \'CommonVariable\''
    assert c == CommonVariable(source='abc')


# Generated at 2022-06-22 18:26:31.051117
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variables = pycompat.OrderedSet()
    variables.add(BaseVariable('a'))
    assert len(variables) == 1
    variables.add(BaseVariable('a', ('b',)))
    assert len(variables) == 1
    variables.add(BaseVariable('b'))
    assert len(variables) == 2


# Generated at 2022-06-22 18:26:33.440841
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Test if the constructor of class CommonVariable is valid
    dig = CommonVariable('dig', exclude=['age'])
    assert dig.source == 'dig'
    assert dig.exclude == ('age',)


# Generated at 2022-06-22 18:26:45.233310
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {'e': 1, 'f': 2}
    b = [1, 2, 3]
    c = object()
    d = {'a': 10, 'b': 20, 'c': a, 'd': b}
    e = [d, a, b]
    f = object()

    var_d = Exploding(source='d')
    var_d_e = Exploding(source='e')

    assert var_d.items({'d': d}) == var_d_e.items(d)
    assert var_d.items({'d': d}) == [('d[a]', '10'), ('d[b]', '20'), ('d[c]', '{...}'), ('d[d]', '[...]')]

# Generated at 2022-06-22 18:26:50.157147
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')._slice == slice(None)
    assert Indices('x')[1:2]._slice == slice(1,2)
    assert Indices('x')[:-1]._slice == slice(None,-1)
    assert Indices('x')[:3:2]._slice == slice(None,3,2)


VARS = {'A': Attrs, 'K': Keys, 'I': Indices, 'E': Exploding}



# Generated at 2022-06-22 18:26:50.865979
# Unit test for constructor of class Indices
def test_Indices():
    Indices(1,2)


# Generated at 2022-06-22 18:26:54.324876
# Unit test for constructor of class Exploding
def test_Exploding():
    result = Exploding('var').items(None)
    assert len(result) == 1
    assert 'var' in result[0]

# Generated at 2022-06-22 18:27:03.360398
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    def check(expected, value):
        assert BaseVariable(value).__hash__() == expected
    check(72, 'x')
    check(0, '_')
    check(201876687, 'x.y')
    check(168253377, 'x.y.z')
    check(115427882, 'a_1')
    check(1, '2')
    check(8, 'a[0]')
    check(8, 'a[0:1]')
    check(8, 'a[0:5]')
    check(8, 'a[:5]')
    check(8, 'a[5:]')
    check(8, 'a[:]')
    check(18, 'a[1:5]')
    check(105, 'a[x]')

# Generated at 2022-06-22 18:27:06.945017
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('a')
    assert a.source == 'a'
    assert a.exclude == ()


# Generated at 2022-06-22 18:27:08.530352
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable("a")
    BaseVariable("a", "a")



# Generated at 2022-06-22 18:27:11.167375
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    ls = BaseVariable.__init__(BaseVariable,'dfs','')
    assert str(ls) == 'dfs'


# Generated at 2022-06-22 18:27:21.473262
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .frame import Frame
    from . import eval_repr

    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return [(self.source, utils.get_shortish_repr(key, normalize=normalize))]
    v = TestVariable('x')

    frame = Frame(None, globals={'x': 5})
    assert v.items(frame) == [('x', '5')]

    frame.f_locals['x'] = 5
    assert v.items(frame) == [('x', '5')]

    frame.f_locals['x'] = eval_repr('lambda x: x', frame)
    assert v.items(frame) == [('x', 'lambda x: x')]

# Generated at 2022-06-22 18:27:26.940808
# Unit test for constructor of class Attrs
def test_Attrs():
    import inspect

    a = Attrs('a')
    assert a.source == 'a'
    assert a.__hash__() == hash(('a', ()))
    assert a._fingerprint == ('a', ())
    assert a.__eq__(Attrs('a'))

    sa = set([Attrs('a')])
    assert Attrs('a') in sa

    # default exclude value is empty tuple
    assert inspect.isfunction(a.items)
    assert a.items(inspect.currentframe()) == [('a', 'None')]

    # test call to _items
    b = Attrs('b', exclude=['__a'])
    assert b._items('abc') == [('b', "'abc'"), ('b.__c', "'str'")]



# Generated at 2022-06-22 18:27:29.206810
# Unit test for constructor of class Keys
def test_Keys():
    with pytest.raises(ValueError):
        Keys()

    with pytest.raises(ValueError):
        Keys(None)

    key = Keys(1.0)
    assert isinstance(key, BaseVariable)

    key = Keys([1,2,3])
    assert isinstance(key, BaseVariable)


# Generated at 2022-06-22 18:27:33.341052
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable("x")
    b = CommonVariable("x")
    assert(a == b)

    c = CommonVariable("y")
    assert(a != c)

    d = CommonVariable("x", exclude=["zz"])
    assert(d.exclude[0] == "zz")

# Generated at 2022-06-22 18:27:37.353358
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs('var')
    assert attr.source == 'var'
    assert attr.exclude == ()
    assert isinstance(attr.code, code)
    assert attr.unambiguous_source == 'var'



# Generated at 2022-06-22 18:27:41.351761
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('a')[1:10:2]
    assert ind.source == 'a'
    assert ind._slice == slice(1,10,2)
    assert ind._keys(ind.source) == [1,3,5,7,9]

# Generated at 2022-06-22 18:27:50.930564
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs('a')
    assert attr.source == 'a'
    assert attr.exclude == ()
    attr = Attrs('abc')
    assert attr.source == 'abc'
    assert attr.exclude == ()
    attr = Attrs('abc', excluded_attr=1)
    assert attr.source == 'abc'
    assert attr.exclude == ('excluded_attr', )
    attr = Attrs('abc', excl=['a', 'b', 'c'])
    assert attr.source == 'abc'
    assert attr.exclude == ('excl', )
    return True


# Generated at 2022-06-22 18:27:52.505507
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices(source=str())
    assert variable[1] == variable.__getitem__(slice(1, None, None))

# Generated at 2022-06-22 18:27:53.043323
# Unit test for constructor of class Exploding
def test_Exploding():
    pass

# Generated at 2022-06-22 18:27:59.021790
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('x[0]')
    assert not needs_parentheses('x[0].y')
    assert not needs_parentheses('x["key"]')
    assert needs_parentheses('x[0].y.z')
    assert needs_parentheses('x[0][1]')
    assert needs_parentheses('x["key"]["value"]')
    assert needs_parentheses('x.y[0]')
    assert needs_parentheses('x.y["key"]')

# Generated at 2022-06-22 18:28:02.317370
# Unit test for constructor of class Exploding
def test_Exploding():
    variable = Exploding('foo')
    source = variable.source
    assert source == 'foo'
    assert variable.exclude == ()
    assert variable.code is not None
    assert variable.unambiguous_source == 'foo'



# Generated at 2022-06-22 18:28:11.245015
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import inspect
    import pytest

    # parameter source has to be of type string
    with pytest.raises(TypeError):
        BaseVariable(123)
    # parameter exclude is ignored if it's not a tuple
    var = BaseVariable('globals()')
    assert var.source == 'globals()'
    assert var.exclude == ()
    var = BaseVariable('frame.f_globals', 'globals()')
    assert var.source == 'frame.f_globals'
    assert var.exclude == ()
    var = BaseVariable('frame.f_globals', 'frame.f_locals')
    assert var.source == 'frame.f_globals'
    assert var.exclude == ('frame.f_locals',)

# Generated at 2022-06-22 18:28:17.223554
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("")
    v2 = BaseVariable("")
    assert v1 == v2

    v2 = BaseVariable("ha")
    assert v1 != v2

    v2 = BaseVariable("", ("a"))
    assert v1 != v2

    v2 = BaseVariable("", ("a", "b"))
    assert v1 != v2


# Generated at 2022-06-22 18:28:26.720499
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses("foo") is False
    assert needs_parentheses("(foo)") is False
    assert needs_parentheses("foo.bar") is False
    assert needs_parentheses("(foo).bar") is False
    assert needs_parentheses("(foo).(bar)") is False
    assert needs_parentheses("(foo()).(bar())") is False
    assert needs_parentheses("foo.bar()") is False
    assert needs_parentheses("(foo.bar())") is False
    assert needs_parentheses("(foo).bar()") is False
    assert needs_parentheses("(foo()).bar()") is False
    assert needs_parentheses("(foo).bar().baz") is False
    assert needs_parentheses("(foo).(bar().baz)") is False

# Generated at 2022-06-22 18:28:29.260787
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable.items(BaseVariable(source='a[0][1:2]'), frame=None) == ()
    assert BaseVariable.items(BaseVariable(source='a'), frame=None) == ()



# Generated at 2022-06-22 18:28:33.607944
# Unit test for constructor of class Attrs
def test_Attrs():
    test_object = Attrs('test', exclude=('__slots__',))
    assert test_object.source == 'test'
    assert test_object.exclude == ('__slots__',)
    assert test_object.code == compile('test', '<variable>', 'eval')
    assert test_object.unambiguous_source == 'test'
    assert test_object._fingerprint == (Attrs, 'test', ('__slots__',))


# Generated at 2022-06-22 18:28:44.562754
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    class MyClass:
        def __init__(self, x):
            self.x = x

        def __eq__(self, other):
            return isinstance(other, MyClass) and self.x == other.x

        def __repr__(self):
            return 'MyClass({})'.format(repr(self.x))

        def __str__(self):
            return 'MyClass({})'.format(str(self.x))

    class TestClass(CommonVariable):
        def _keys(self, main_value):
            return ('a', 'b')

        def _format_key(self, key):
            return '.' + key

        def _get_value(self, main_value, key):
            return getattr(main_value, key)

    var = TestClass('something')
    var2 = Test

# Generated at 2022-06-22 18:28:49.013824
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs(123)
    assert a.source == 123
    assert a.exclude == ()
    assert a.code == compile('123', '<variable>', 'eval')
    assert a.unambiguous_source == '123'


# Generated at 2022-06-22 18:28:56.474373
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    A=[0,10,20,30]
    H=Indices('A')
    assert H[1:2]._slice == slice(1, 2, None)
    assert H[2:] ._slice == slice(2, None, None)
    assert H[:2] ._slice == slice(0, 2, None)
    assert H[:]  ._slice == slice(None, None, None)
    assert H[-2:] ._slice == slice(-2, None, None)
    assert H[-4:-2]._slice == slice(-4, -2, None)
    

# Generated at 2022-06-22 18:29:03.549241
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """Items method of the class BaseVariable"""
    class Derived(BaseVariable):
        def __init__(self, source, exclude=()):
            BaseVariable.__init__(self, source, exclude)

    var = Derived('request')
    frame = inspect.currentframe()
    result = var.items(frame)
    assert result[0][0] == 'request'
    assert result[0][1] == 'unittest.mock.MagicMock()'


# Generated at 2022-06-22 18:29:08.065771
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    input = ['one', 'two', 'tree']
    input_slice = slice(1, None, 2)
    output = [input[i] for i in range(len(input))[input_slice]]
    index = Indices('input')
    index_filtered = index[input_slice]
    assert output == index_filtered.items(None, normalize=True)

# Generated at 2022-06-22 18:29:18.642920
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        d = {'a': 1, 'b': 'first'}
        l = [2, 3, 4]
        c = [l, d]
        class A:
            a = 1
            b = None
            def __init__(self, a, b):
                self.a = a
                self.b = b
            def __str__(self):
                return 'str'
            def __repr__(self):
                return 'A(1, "first")'
        a = A(1, 'first')
        class B(A):
            z = 3
            def __repr__(self):
                return 'B(1, "first")'
        b = B(1, 'first')
        s = 'hello world'
        return locals()

# Generated at 2022-06-22 18:29:23.119483
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices("test", exclude=("x", "y"))
    assert indices.exclude == ("x", "y")
    assert indices.source == "test"
    assert indices._slice == slice(None)
    indices[1:4]
    assert indices._slice != slice(None)


# Generated at 2022-06-22 18:29:28.891489
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    def test1():
        item = slice(2, 3)
        print('item = ' + str(item))
        i = Indices('i')
        print('result = i[item]')
        result = i[item]
        print('result.source = ' + str(result.source))
        print('result._slice = ' + str(result._slice))
    test1()
    pass

# Generated at 2022-06-22 18:29:32.311918
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('x').source == 'x'
    assert Exploding('x', exclude=('y',)).exclude == ('y',)
    assert Exploding('x', exclude='y').exclude == ('y',)



# Generated at 2022-06-22 18:29:35.508580
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x.y')
    assert needs_parentheses('x.y.z')
    assert needs_parentheses('f(x)')
    assert needs_parentheses('f(x).y')
    assert needs_parentheses('x.y.f(z)')

# Generated at 2022-06-22 18:29:39.392221
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a').__getitem__(slice(1, 3)) == Indices('a', exclude=()).__getitem__(slice(1, 3))
    assert Indices('a').__getitem__(slice(1, 3)) != Indices('a', exclude=('b',)).__getitem__(slice(1, 3))

# Generated at 2022-06-22 18:29:50.417766
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    m = {'a': 1, 'b': 'hi', '__': 1}
    a = (1, 2, 'heey')
    b = ('hello', [1, 2, 3])
    d = ('hello', {1: 1, 2: 'hi'})
    class Bases(object):
        __bases__ = (Mapping, Sequence)
    bb = Bases()
    m_e = {'a': 1, 'b': 'hi'}
    d_e = ({1: 1, 2: 'hi'}, ['hello'])

    assert Attrs('m').items(locals()) == [('m', "{'a': 1, 'b': 'hi', '__': 1}")]

# Generated at 2022-06-22 18:29:52.217204
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable('a')
    v.source == 'a'
    v.exclude == ()


# Generated at 2022-06-22 18:29:54.742045
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys("aa", ["a"])
    assert keys.source == "aa"
    assert keys.exclude == ("a", )
    assert keys.code is not None


# Generated at 2022-06-22 18:30:03.299265
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable("foo",("bar","baz"))
    b = BaseVariable("foo",("bar","baz"))
    c = BaseVariable("foo",("bar","baz"))
    d = BaseVariable("foo",("bar","baz"))
    assert a.__hash__() != b.__hash__()
    assert b.__hash__() != c.__hash__()
    assert c.__hash__() != d.__hash__()
    assert d.__hash__() != a.__hash__()


# Generated at 2022-06-22 18:30:09.905446
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {'a':{'b':'b_value'}}
    b = Exploding('a',normalize=False)
    c = b._items(a)
    assert len(c) == 2
    assert c == [('a', "{{'b': 'b_value'}}"), ("a['b']", "'b_value'")]


# Generated at 2022-06-22 18:30:13.228036
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('var')
    assert(e.source == 'var')


# Generated at 2022-06-22 18:30:18.648959
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('1')
    assert needs_parentheses('(1)')
    assert not needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x[0]')
    assert not needs_parentheses('x.y[0]')
    assert needs_parentheses('x().y')
    assert not needs_parentheses('x()[0].y')

# Generated at 2022-06-22 18:30:24.779794
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('(a)') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a.b[c]') == False
    assert needs_parentheses('(a.b)[c]') == False

    assert needs_parentheses('a(b)') == True
    assert needs_parentheses('a(b)[0]') == True
    assert needs_parentheses('a.b(c).d(e)') == True

# Generated at 2022-06-22 18:30:31.572250
# Unit test for constructor of class Indices
def test_Indices():
    x = Indices("arr")
    assert(x.source == "arr")
    assert(x.exclude == ())
    x = Indices("arr", 4)
    assert(x.source == "arr")
    assert(x.exclude == (4,))
    assert(x[2:5][1:2]._slice == slice(3, 4))
    assert("_slice" in x.__dict__)

# Generated at 2022-06-22 18:30:34.814236
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # assert that compilation of self.code is correct
    # assert that the source is correct
    # assert that the exclusion is correct
    # assert that items return an empty tuple
    assert False


# Generated at 2022-06-22 18:30:37.014720
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys(source = 'x', exclude = 'y')


if __name__ == '__main__':
    test_Keys()

# Generated at 2022-06-22 18:30:43.824177
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global loc
    loc = 1
    def fail():
        global loc
        loc = 2
        raise RuntimeError

    class Fail(BaseVariable):
        def __init__(self, source):
            super(Fail,self).__init__(source)

        def _items(self, main_value, normalize=False):
            fail()

    o = Fail('haha')
    # log is an optional argument for this function
    assert o.items(o, normalize=False) == ()



# Generated at 2022-06-22 18:30:48.486582
# Unit test for constructor of class Exploding
def test_Exploding():
    x = Exploding("dir(0)")
    assert x.source == "dir(0)"
    assert x.exclude == ()
    assert x.code
    assert x.unambiguous_source == "(dir(0))"

# Generated at 2022-06-22 18:30:54.602002
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices('test', exclude='test')
    assert isinstance(v, Indices)
    assert v.source == 'test'
    assert v.exclude == ('test',)
    assert hasattr(v, '_slice')

# Generated at 2022-06-22 18:31:00.101331
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable("a", exclude=("b", "c"))
    v2 = BaseVariable("a", exclude=("b", "c"))
    v3 = BaseVariable("a", exclude=("b", ))
    v4 = BaseVariable("b", exclude=("b", "c"))
    assert (hash(v1) == hash(v2))
    assert (hash(v1) != hash(v3))
    assert (hash(v1) != hash(v4))


# Generated at 2022-06-22 18:31:12.166487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def dog():
        return 1
    def cat():
        return 2
    def fish():
        return 3


    f = {'dog': dog,'cat': cat,'fish': fish}

# Generated at 2022-06-22 18:31:18.492637
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    d = {"x":0, "y":3.1415}
    s = ["one", "two", "three"]
    t = (1,2,3)
    c = complex(10, -2)
    class A:
        pass
    A.a = 0
    A.b = 1.1
    A.c = "ccc"
    A.d = {"da":1, "db":2}
    a = A()
    a.x = 0
    a.y = 3.1415
    g = {}
    a.g = g
    g.x = 0
    g.y = 3.1415
    g.a = a

    # Mapping
    print("Mapping")
    v = BaseVariable('d', exclude=None)

# Generated at 2022-06-22 18:31:28.840270
# Unit test for constructor of class Keys
def test_Keys():
    a={'key1':'value1','key2':'value2'}
    b=Keys('a')
    print(b.items(a))
    print(b.source)
    print(b.exclude)
    print(b.unambiguous_source)
    print(b._safe_keys(a))
    print(b._keys(a))
    print(b._format_key('key1'))
    print(b._get_value(a,'key1'))
    print(b.__str__())
    print(b.__repr__())
    print(b._fingerprint)
    print(b._items(a))
# test_Keys()

# Generated at 2022-06-22 18:31:32.799253
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a.b')
    assert needs_parentheses('(a).b')
    assert not needs_parentheses('a.b.c')
    assert not needs_parentheses('(a.b).c')

# Generated at 2022-06-22 18:31:38.103757
# Unit test for constructor of class Exploding
def test_Exploding():
    # Setup
    class myclass(object):
        def __init__(self):
            self.a = 'hi'
            self.b = 'there'
    main_value = myclass()
    e = Exploding('main_value')._items(main_value)
    a = Attrs('main_value')._items(main_value)
    # Test
    assert e == a


# Generated at 2022-06-22 18:31:42.070991
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import inspect
    from . import utils
    local_variable = inspect.currentframe()
    code = compile('local_variable', '<variable>', 'eval').co_code
    assert code == utils.get_code(BaseVariable('local_variable').code)

# Generated at 2022-06-22 18:31:44.986211
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('a')
    print(x)
    print(x.__dict__)
    
test_Attrs()


# Generated at 2022-06-22 18:31:47.512799
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    test_variable = BaseVariable('test')
    assert test_variable.source == 'test'
    assert test_variable.exclude == ()


# Generated at 2022-06-22 18:31:49.329775
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    keys = Keys(source="main_value")
    attrs = Attrs(source="main_value")


# Generated at 2022-06-22 18:31:51.140431
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class T(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    a = T('a', 'b')
    b = T('a', 'b')
    assert a.__hash__() == b.__hash__()



# Generated at 2022-06-22 18:32:00.601972
# Unit test for function needs_parentheses
def test_needs_parentheses():
    variables = (
        ('x.y', True),
        ('x[y]', True),
        ('x()', True),
        ('x.y.z', True),
        ('x[y][z]', True),
        ('(x).y', False),
        ('(x)[y]', False),
        ('(x)()', False),
        ('(x).y.z', False),
        ('(x)[y][z]', False),
        ('x[y].z', True),
        ('(x[y]).z', True),
        ('x()[y]', True),
        ('x().y', True),
    )
    for source, result in variables:
        assert needs_parentheses(source) == result

# Generated at 2022-06-22 18:32:11.007337
# Unit test for constructor of class Indices
def test_Indices():
    input_list = ['a', 'b', 'c']
    var = Indices('input_list')
    # Test attribute `source`
    assert var.source == 'input_list'
    # Test attribute `slice`
    assert var._slice == slice(None)
    # Test method `_items`
    assert var._items(input_list) == [('input_list[0]', "'a'"), ('input_list[1]', "'b'"), ('input_list[2]', "'c'")]
    # Test method `__getitem__`
    var2 = var[1:2]
    assert var2._slice == slice(1, 2)
    assert var2._items(input_list) == [('input_list[1]', "'b'")]

# Generated at 2022-06-22 18:32:12.611571
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('foo')

# Generated at 2022-06-22 18:32:16.516026
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    line = inspect.currentframe()
    var = BaseVariable('var', exclude=['a', 'b'])
    assert hash(var) == hash((BaseVariable, 'var',('a', 'b')))


# Generated at 2022-06-22 18:32:24.494347
# Unit test for constructor of class Attrs
def test_Attrs():
    # assert key, source, exclude
    a = Attrs('foo', ['bar'])
    assert hash(a) == hash(Attrs('foo', ['bar']))
    assert hash(a) != hash(Attrs('foo', []))
    assert hash(a) != hash(Attrs('bar', []))
    assert hash(a) != hash(Attrs('bar', ['foo']))


# Generated at 2022-06-22 18:32:26.255051
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_ins = Indices('a')
    indices_ins['1:3:']
    indices_ins['1:4:']


# Generated at 2022-06-22 18:32:27.661635
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('a')
    assert isinstance(i, Indices)

# Generated at 2022-06-22 18:32:33.827277
# Unit test for constructor of class Indices
def test_Indices():
    list = ['a', 'b', 'c']
    indices_test = Indices('var')
    indices_test = indices_test[:-1]
    expected_result = [('var[0]', 'a'), ('var[1]', 'b'), ('var[2]', 'c')]
    assert expected_result == indices_test.items(list)


# Generated at 2022-06-22 18:32:44.100390
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    _BaseVariable_hash = hash(BaseVariable('a.b', ['a', 1]))
    assert _BaseVariable_hash != hash(BaseVariable('a.b', ['a', 1]))
    assert _BaseVariable_hash != hash(BaseVariable('a.b', ['a', 2]))
    assert _BaseVariable_hash != hash(BaseVariable('a.b', ['a']))
    assert _BaseVariable_hash != hash(BaseVariable('a.c', ['a', 1]))
    assert _BaseVariable_hash != hash(BaseVariable('c.b', ['a', 1]))
    assert _BaseVariable_hash != hash(BaseVariable('a.b', 'a'))
    assert _BaseVariable_hash != hash(BaseVariable('a.b', ('a', 1)))



# Generated at 2022-06-22 18:32:45.560552
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    c = BaseVariable('something')
    print(c.__hash__())


# Generated at 2022-06-22 18:32:50.506149
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('x')._items(dict())[0][1], str)
    assert isinstance(Exploding('x')._items(list())[0][1], str)
    assert isinstance(Exploding('x')._items(int())[0][1], str)

# Generated at 2022-06-22 18:32:55.414547
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    d = {
        'slice': slice(4, 6, 2),
        'start': 4,
        'stop': 6,
        'step': 2,
    }

    assert Indices('v')[d['slice']].source == 'v[{}:]'.format(d['start'])
    assert Indices('v[1]')[d['slice']].source == 'v[1][{}:]'.format(d['start'])



# Generated at 2022-06-22 18:33:03.913557
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo', exclude=['a', 'b']).source == 'foo'
    assert Indices('foo', exclude=['a', 'b'])[:] == Indices('foo', exclude=['a', 'b'])
    assert Indices('foo', exclude=['a', 'b'])[:2] != Indices('foo', exclude=['a', 'b'])
    assert Indices('foo', exclude=['a', 'b'])[2:4] != Indices('foo', exclude=['a', 'b'])

# Generated at 2022-06-22 18:33:08.970973
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    assert a != b
    c = BaseVariable('a')
    assert a == c
    d = BaseVariable('a', exclude=('b', ))
    assert a != d
    c = BaseVariable('a', exclude=('b', ))
    assert c == d

# Generated at 2022-06-22 18:33:11.370543
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('3')  # noqa
    indices_slice = indices[:]  # noqa



# Generated at 2022-06-22 18:33:13.810379
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('<TEST>').source == '<TEST>'
    assert Exploding('<TEST>').exclude == ()


# Generated at 2022-06-22 18:33:23.065662
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    import pytest
    from . import ctree

    ctree_var = ctree.variable("x[1][2]", exclude = ["x"])
    cmv = CommonVariable("x[1][2]", exclude = ["x"])

    with pytest.raises(NotImplementedError):
        cmv._keys()

    with pytest.raises(NotImplementedError):
        cmv. _format_key("key")

    with pytest.raises(NotImplementedError):
        cmv. _get_value("main_value", "key")

    try:
        cmv.source
    except AttributeError:
        assert False

    try:
        cmv.exclude
    except AttributeError:
        assert False


# Generated at 2022-06-22 18:33:29.014486
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices("variable")
    assert ind[:3] == Indices(source="variable", exclude=())
    assert ind[3:] == Indices(source="variable", exclude=())


__all__ = [
           'BaseVariable',
           'CommonVariable',
           'Attrs',
           'Keys',
           'Indices',
           'Exploding'
           ]

# Generated at 2022-06-22 18:33:34.956376
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable("a")
    assert BaseVariable("a", exclude='b')
    assert BaseVariable("a", exclude=('b'))
    assert BaseVariable("a", exclude=['b'])
    assert BaseVariable("a", exclude=('b', 'c'))
    assert BaseVariable("a", exclude='b', some_kwarg='c')
    assert BaseVariable("a", exclude=('b', 'c'), some_kwarg='d')
    assert BaseVariable("a", exclude=['b', 'c'], some_kwarg='d')
    assert BaseVariable("a", exclude=('b', 'c'), some_kwarg='d')


# Generated at 2022-06-22 18:33:39.060261
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("a")[1:3] == Indices("a")[slice(1,3)]
    assert Indices("a")[1:3] != Indices("b")[1:3]
    assert Indices("a")[1:3] != Indices("b")[3:5]

# Generated at 2022-06-22 18:33:46.041969
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    obj = BaseVariable('a')
    assert obj.source == 'a'
    obj = BaseVariable('a', exclude='a')
    assert obj.exclude == ('a',)
    obj = BaseVariable('a', exclude=('a',))
    assert obj.exclude == ('a',)
    assert obj.code.co_code == b'd\x01\x00d\x00\x00\x17\x83\x01\x00d\x00\x00S'
    assert obj.unambiguous_source == 'a'
    obj = BaseVariable('__main__.A', exclude=('a',))
    assert obj.unambiguous_source == 'a'
    obj = BaseVariable('(__main__.A)', exclude=('a',))

# Generated at 2022-06-22 18:33:50.204724
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('a')
    assert e.source == 'a'
    assert e.code == compile('a', '<string>', 'eval')

# Unit tests for function needs_parentheses()

# Generated at 2022-06-22 18:33:52.794508
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('variable')
    assert variable.source == 'variable'
    assert variable.exclude == ()


# Generated at 2022-06-22 18:33:56.060234
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable('a')
    assert bv == BaseVariable('a')
    assert not bv == BaseVariable('b')
    assert not bv == 'b'



# Generated at 2022-06-22 18:33:58.180411
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[2:5] == Indices('a')[slice(2, 5, None)]

# Generated at 2022-06-22 18:34:04.684531
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
	bv1 = BaseVariable('source', 'exclude')
	bv2 = BaseVariable('source', 'exclude')
	bv3 = BaseVariable('source_alt', 'exclude')
	bv4 = BaseVariable('source', 'exclude_alt')
	assert bv1 == bv2
	assert bv1 != bv3
	assert bv1 != bv4
	assert bv1 != 'source'
	assert bv1 != None
	assert bv1 != 0

# Generated at 2022-06-22 18:34:09.356385
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x()')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x()).y')
    assert not needs_parentheses('(x).y.z')
    assert not needs_parentheses('(x.y).z')

# Generated at 2022-06-22 18:34:12.151688
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    s = 'value'
    instance = BaseVariable(s)
    assert isinstance(instance.__hash__(), int)



# Generated at 2022-06-22 18:34:15.679601
# Unit test for constructor of class Indices
def test_Indices():
    assert list(Indices('x')._keys(range(100))) == list(range(100))
    assert list(Indices('x')[:80]._keys(range(100))) == list(range(80))

# Generated at 2022-06-22 18:34:21.394893
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Keys('source1', exclude='exclude1')
    assert v1 == v1
    assert v1 != 'different'
    assert v1 != Keys('source1', exclude='different')
    assert v1 != Keys('different', exclude='exclude1')
    assert v1 != Keys('source1', exclude='exclude1',
                     _exclude_something='different')

# Generated at 2022-06-22 18:34:28.160929
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    fail_msg = "Method BaseVariable.__eq__ failed. Check the correctness of method __eq__"
    first_variable = BaseVariable("", ())
    second_variable = BaseVariable("", ())
    third_variable = BaseVariable("", ())
    fourth_variable = BaseVariable("", ())
    fifth_variable = BaseVariable("", ())
    sixth_variable = BaseVariable("", ())
    seventh_variable = BaseVariable("", ())
    eighth_variable = BaseVariable("", ())
    ninth_variable = BaseVariable("", ())
    tenth_variable = BaseVariable("", ())
    eleventh_variable = BaseVariable("", ())

    assert first_variable == first_variable, fail_msg
    assert second_variable == second_variable, fail_msg
    assert third_variable == third_variable, fail_msg

# Generated at 2022-06-22 18:34:36.725605
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # BaseVariable 的 __hash__ 方法, 考虑了类型, source, exclude
    class Variable(BaseVariable):
        pass
    assert hash(Variable('x')) == hash(Variable('x'))
    assert hash(Variable('x')) != hash(Variable('y'))
    assert hash(Variable('x', 'y')) == hash(Variable('x', 'y'))
    assert hash(Variable('x', 'y')) != hash(Variable('y', 'z'))


# Generated at 2022-06-22 18:34:47.237950
# Unit test for constructor of class Attrs
def test_Attrs():
    av = Attrs(source='source', exclude=('EXCLUDE1', 'EXCLUDE2'))
    assert av.source == 'source'
    assert av.exclude == ('EXCLUDE1', 'EXCLUDE2')
    assert av.code == compile('source', '<variable>', 'eval')
    assert av.unambiguous_source == 'source'
    assert av._fingerprint == (Attrs, 'source', ('EXCLUDE1', 'EXCLUDE2'))
    assert av == Attrs(source='source', exclude=('EXCLUDE1', 'EXCLUDE2'))
    assert av != Attrs(source='source1', exclude=('EXCLUDE1', 'EXCLUDE2'))

# Generated at 2022-06-22 18:34:57.372369
# Unit test for constructor of class Keys
def test_Keys():
    # Testing keys
    l = {'a': 1, 'b': 2}
    k = Keys('l')
    assert k.items(None) == [('l', '{...}'), ('l[a]', '1'), ('l[b]', '2')]
    k = Keys('l', 'a')
    assert k.items(None) == [('l', '{...}'), ('l[b]', '2')]
    k = Keys('l', ('a',))
    assert k.items(None) == [('l', '{...}'), ('l[b]', '2')]
    # Testing indices
    t = tuple('abc')
    i = Indices('t')

# Generated at 2022-06-22 18:35:03.030359
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('request.user') == BaseVariable('request.user')
    assert BaseVariable('request.user') != BaseVariable('request.group')
    assert BaseVariable('request.user', 'user') != BaseVariable('request.user')
    assert BaseVariable('request.user') != BaseVariable('request.user', 'user')
    assert BaseVariable('request.user', 'user') == BaseVariable('request.user', 'user')



# Generated at 2022-06-22 18:35:06.051899
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    sys.path.append('../../test')
    from test_utils import test_common
    test_common(None)


# Generated at 2022-06-22 18:35:07.603853
# Unit test for constructor of class Keys
def test_Keys():
    assert len(Keys('foo').items(None)) == 1


# Generated at 2022-06-22 18:35:18.531550
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class CommonVariable_test(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))

        def _get_value(self, main_value, key):
            return main_value[key]

    a = CommonVariable_test('a')
    assert isinstance(a, BaseVariable)
    assert a.source == 'a'
    assert a.exclude == ()
    assert isinstance(a.code, type(compile('1+1', '<string>', 'eval')))
    assert a.unambiguous_source == 'a'

    b = CommonVariable_test('b', 'x')
    assert isinstance(b, BaseVariable)


# Generated at 2022-06-22 18:35:20.711015
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys(source = "a", exclude = ("a", "b"))


# Generated at 2022-06-22 18:35:23.242723
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a')
    assert attrs.source == 'a'
    assert attrs.exclude == ()
    assert attrs.unambiguous_source == 'a'


# Generated at 2022-06-22 18:35:24.754304
# Unit test for constructor of class Exploding
def test_Exploding():
    exp = Exploding('main')
    assert exp.source == 'main'


# Generated at 2022-06-22 18:35:26.937295
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    r = Indices('x', ()).__getitem__(slice(1,4))
    assert(isinstance(r, Indices))



# Generated at 2022-06-22 18:35:28.382393
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('x'), BaseVariable)


# Generated at 2022-06-22 18:35:33.670432
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class Foo(CommonVariable):
        pass
    # Successful construction
    assert Foo('x')
    # The constructor of class CommonVariable checks that the argument
    # source is a string
    with pytest.raises(ValueError):
        Foo(123)
    # The constructor of class CommonVariable checks that the argument
    # source is not the empty string
    with pytest.raises(ValueError):
        Foo('')


# Generated at 2022-06-22 18:35:35.300961
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('result')
    b = a[:]
    assert a is not b


if __name__ == '__main__':
    import pytest
    pytest.main(['-s', __file__])

# Generated at 2022-06-22 18:35:41.592379
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('x + 1') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('(x + 1)') is False
    assert needs_parentheses('x.y') is True
    assert needs_parentheses('x.y.z') is True
    assert needs_parentheses('x[0]') is True
    assert needs_parentheses('x[0].y') is True
    assert needs_parentheses('x[0][1]') is True
    assert needs_parentheses('x[y]') is True
    assert needs_parentheses('x[y].z') is True
    assert needs_parentheses('x[y[0]]') is True
    assert needs_parentheses('x.y + 1') is True
   

# Generated at 2022-06-22 18:35:49.830720
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('keys')
    assert keys.source == 'keys'
    assert keys.code == compile('keys', '<variable>', 'eval')
    assert keys.exclude == ()
    assert keys.unambiguous_source == 'keys'

    keys = Keys('keys', exclude='abc')
    assert keys.source == 'keys'
    assert keys.code == compile('keys', '<variable>', 'eval')
    assert keys.exclude == ('abc', )
    assert keys.unambiguous_source == 'keys'

    keys = Keys('keys', exclude=['abc'])
    assert keys.source == 'keys'
    assert keys.code == compile('keys', '<variable>', 'eval')
    assert keys.exclude == ('abc', )
    assert keys.unambiguous_source == 'keys'

# Unit

# Generated at 2022-06-22 18:35:54.465052
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class myVariable(BaseVariable):
        def __init__(self):
            pass
        def _items(self, key, normalize=False):
            return 0
    a = myVariable()
    b = myVariable()
    assert a == b
