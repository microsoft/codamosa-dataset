

# Generated at 2022-06-22 18:25:50.763407
# Unit test for constructor of class Attrs
def test_Attrs():
    var = Attrs.from_string('attrs', "attrs._values")
    assert var.source == "attrs._values"
    assert isinstance(var, Attrs)


# Generated at 2022-06-22 18:25:55.818139
# Unit test for constructor of class Keys
def test_Keys():
    key = 'keys'
    value = 123
    test_map = {}
    test_map[key]=value
    result = Keys(key).items(test_map)
    recv = utils.get_shortish_repr(value)
    assert('[\'keys\']'==result[1][0] and recv==result[1][1])

# Generated at 2022-06-22 18:26:02.856983
# Unit test for constructor of class Exploding

# Generated at 2022-06-22 18:26:09.862894
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = CommonVariable("x")
    v2 = CommonVariable("x")
    v3 = CommonVariable("y")
    v4 = CommonVariable("x", exclude="is_complete")
    # test: 2 objects of the same class + same source
    assert v1 == v2
    # test: 2 objects of the same class + different source
    assert v1 != v3
    # test: 2 objects of the same class + same source + different 'exclude'
    assert v1 != v4
    # test: 2 objects of different class + same source
    assert v1 != Keys("x")

test_BaseVariable___eq__()


# Generated at 2022-06-22 18:26:15.722030
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    for main_value in [{'a': 1}, [1]]:
        for cls in (Keys, Indices):
            source = 'main_value'
            variable = cls(source)
            assert variable.items(main_value) == cls(source, ()).items(main_value)

            source = 'main_value[1]'
            variable = cls(source)
            assert variable.items(main_value) == cls(source, ()).items(main_value)

# Generated at 2022-06-22 18:26:18.028562
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from nose.tools import assert_equal
    assert_equal(Indices('x')[::-1]._slice, slice(None, None, -1))

# Generated at 2022-06-22 18:26:21.506137
# Unit test for constructor of class Exploding
def test_Exploding():
    s = Exploding('a *b', 'b')
    result = s.items(None)
    assert result[0][0] == 'a *b'
    assert result[1][0] == 'a.b'

# Generated at 2022-06-22 18:26:27.685059
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Initialize the variable
    source = 'x'
    variable = CommonVariable(source)

    # Test variable
    assert isinstance(variable, BaseVariable)
    assert variable.source == source
    assert variable.exclude == ()
    assert variable.code.co_code == compile(source, '<variable>', 'eval').co_code
    assert variable.unambiguous_source == source

# Test for method items of class CommonVariable

# Generated at 2022-06-22 18:26:29.880765
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    actual = BaseVariable('') == BaseVariable('')
    expected = True
    assert actual == expected
    

# Generated at 2022-06-22 18:26:34.606190
# Unit test for constructor of class Attrs
def test_Attrs():
    d = {'x': 42, 'y': 43}
    d.__dict__ = {'z': 42}
    a = Attrs('d', 'x')
    assert a.__hash__() == hash((Attrs, 'd', ('x',)))
    assert a.__eq__(Attrs('d', 'x'))
    assert a.items(d) == [('d', "{'x': 42, 'y': 43}"), ('d.z', '42')]

# Generated at 2022-06-22 18:26:46.042312
# Unit test for constructor of class Attrs
def test_Attrs():
    atr1 = Attrs('i')
    assert atr1.source == 'i'
    assert atr1.exclude == ()
    assert atr1.code.co_code == (
        b'e\x00\x00d\x01\x00d\x00\x00S'
    )
    assert atr1.unambiguous_source == 'i'
    assert atr1._fingerprint == (Attrs, 'i', ())
    assert atr1.__hash__() == hash(atr1._fingerprint)

    atr1_ = Attrs('i', 'j')
    assert atr1_._fingerprint == (Attrs, 'i', ('j',))
    assert atr1_.unambiguous_source == 'i'
    assert atr1_.exclude == ('j',)

# Generated at 2022-06-22 18:26:49.075128
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    data = {'a': '1', 'b': '2', 'c': '3'}
    assert Indices('data').__getitem__(slice(2))[0].source == 'data'
    assert Indices('data').__getitem__(slice(2))[0].exclude == ()

# Generated at 2022-06-22 18:27:00.424315
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.y[1]')
    assert not needs_parentheses('x[0]')
    assert not needs_parentheses('x[0].y')
    assert not needs_parentheses('x[0].y.z')
    assert not needs_parentheses('x()')
    assert needs_parentheses('(x)')
    assert not needs_parentheses('(x[0])')
    assert not needs_parentheses('(x.y)')
    assert not needs_parentheses('(x.y.z)')
    assert not needs_parentheses('(x())')
    assert not needs_parentheses('(x)[0]')
    assert not needs_parentheses('(x)[0].y')

# Generated at 2022-06-22 18:27:09.656995
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable("abc") == CommonVariable("abc")
    assert CommonVariable("abc", exclude=()) == CommonVariable("abc", exclude=())
    assert CommonVariable("abc") != CommonVariable("def")
    assert CommonVariable("abc", exclude=()) != CommonVariable("abc", exclude=(1, 2, 3))
    assert CommonVariable("abc", exclude=(1, 2, 3)) != CommonVariable("abc", exclude=(1, 2))
    assert CommonVariable("abc", exclude=(1, 2)) != CommonVariable("abc")

    assert CommonVariable("abc") != 1


# Generated at 2022-06-22 18:27:11.213909
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    eq_(BaseVariable('x', 'y'), BaseVariable('x', 'y'))

# Generated at 2022-06-22 18:27:21.904017
# Unit test for constructor of class Attrs
def test_Attrs():
    #test object
    obj = [1, 2, 3, 4]
    #test object attribute
    obj_attr = Attrs("obj")

    #obj.should.be.a.list
    assert isinstance(obj, list)
    #obj_attr.should.equal.Attrs
    assert obj_attr.__class__ == Attrs
    #obj_attr.source.should.equal.obj
    assert obj_attr.source == "obj"
    #obj_attr.exclude.should.be.a.tuple
    assert isinstance(obj_attr.exclude, tuple)
    #obj_attr.code.should.be.a.code
    assert isinstance(obj_attr.code, code)
    #obj_attr.unambiguous_source.should.be.a.string

# Generated at 2022-06-22 18:27:24.568264
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo').source == 'foo'
    assert Keys('foo').code.co_code == compile('foo', '<variable>', 'eval').co_code
    assert Keys('foo').exclude == ()
    assert Keys('foo', 'bar', 'baz').exclude == ('bar', 'baz')


# Generated at 2022-06-22 18:27:35.666586
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        return {'a': {'b': 123, 'c': [1,2,3], 'd': [4,5,6], 'e': [7,8,9]}}

    frame = inspect.currentframe()
    frame.f_code = f.__code__

    assert list(BaseVariable('a').items(frame)) == [('a', '{...}')]
    assert list(BaseVariable('a.b').items(frame)) == [('a.b', '123')]
    assert list(BaseVariable('a.c').items(frame)) == [('a.c', '[1, 2, 3]')]
    assert list(BaseVariable('a.c[0]').items(frame)) == [('a.c[0]', '1')]

# Generated at 2022-06-22 18:27:39.841574
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('x')
    assert attrs.source == 'x'
    assert attrs.exclude == ()
    assert attrs.code == compile('x', '<variable>', 'eval')
    assert attrs.unambiguous_source == 'x'


# Generated at 2022-06-22 18:27:43.457299
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('main_value', 'exclude')
    assert isinstance(indices, Indices)
    assert isinstance(indices, Keys)
    assert isinstance(indices, CommonVariable)
    assert isinstance(indices, BaseVariable)


# Generated at 2022-06-22 18:27:47.963257
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices == indices[:]
    assert indices == indices[:100]
    assert indices == indices[0:]
    assert indices != indices[1:100]
    assert indices != indices[3:10]
    assert indices != indices[-1:]

# Generated at 2022-06-22 18:27:51.687507
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    s = BaseVariable('')
    assert s.source == ''
    assert s.exclude == ()
    assert s.unambiguous_source == '()'
    assert s._fingerprint == (BaseVariable, '', ())


# Generated at 2022-06-22 18:28:00.133628
# Unit test for constructor of class Exploding
def test_Exploding():
    assert len(Exploding("somelist", exclude = []).items("somelist")) == 1
    assert len(Exploding("somelist", exclude = ["len"]).items("somelist")) > 1
    assert len(Exploding("somelist", exclude = ["__dict__"]).items("somelist")) > 1
    assert len(Exploding("somelist", exclude = ["somelist"]).items("somelist")) == 1
    assert len(Exploding("somelist", exclude = ["len", "__dict__"]).items("somelist")) > 1
    assert len(Exploding("somelist", exclude = ["len", "__dict__", "somelist"]).items("somelist")) == 1


# Generated at 2022-06-22 18:28:06.546531
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable1 = BaseVariable('a')
    variable2 = BaseVariable('b')
    variable3 = BaseVariable('a')
    variable4 = BaseVariable('a', ('a', 'b'))
    variable5 = BaseVariable('a', ('a', 'b'))
    variable6 = BaseVariable('a', ('b', 'b'))

    assert (variable1 != variable2)
    assert (variable1 == variable3)
    assert (variable1 != variable4)
    assert (variable4 == variable5)
    assert (variable4 != variable6)


# Generated at 2022-06-22 18:28:11.060606
# Unit test for constructor of class Keys
def test_Keys():
    aDict = dict(key1 = 1, key2 = 2)
    aList = [1, 2, 3]

    aKey = Keys("aDict")
    for item in aKey.items(aDict):
        print(item)

    aKey = Keys("aList")
    for item in aKey.items(aList):
        print(item)



# Generated at 2022-06-22 18:28:22.073190
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """docstring for test_BaseVariable_items"""
    import inspect
    frame = inspect.currentframe()
    assert BaseVariable('a').items(frame) == (('a', '1'),)
    frame = inspect.currentframe()
    assert BaseVariable('(1, a)').items(frame) == (('(1, a)', '(1, 1)'),)
    frame = inspect.currentframe()
    assert BaseVariable('a').items(frame) == (('a', '1'),)
    frame = inspect.currentframe()
    assert BaseVariable('a').items(frame) == (('a', '1'),)
    frame = inspect.currentframe()
    assert BaseVariable('a').items(frame) == (('a', '1'),)
    frame = inspect.currentframe()

# Generated at 2022-06-22 18:28:23.157350
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable('foo') == BaseVariable('foo')

# Generated at 2022-06-22 18:28:26.175487
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('3')
    b = CommonVariable('3')
    assert a.__hash__() == b.__hash__()
    assert a == b



# Generated at 2022-06-22 18:28:27.878145
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable.__init__
    assert CommonVariable.items
    assert CommonVariable._items



# Generated at 2022-06-22 18:28:31.534448
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x.y')
    assert needs_parentheses('x.y.z')
    assert needs_parentheses('x[0]')
    assert not needs_parentheses('x["y"]')
    assert needs_parentheses('x["y"].z')
    assert needs_parentheses('x[0].z')

# Generated at 2022-06-22 18:28:36.076159
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Check it returns a new copy
    v = Indices('v')
    assert id(v) != id(v[:])

    # Check it works with slice
    assert v[:]._slice == slice(None)
    assert v[1:]._slice == slice(1, None)
    assert v[1:2]._slice == slice(1, 2)
    assert v[::2]._slice == slice(None, None, 2)

# Generated at 2022-06-22 18:28:47.306182
# Unit test for constructor of class Keys
def test_Keys():
    import types
    import inspect
    import sys
    import io
    from contextlib import redirect_stdout

    class Test:
        def __init__(self):
            self.test_key = 'test_value'

    values = {}
    values['test'] = Test()
    key = Keys('values.test', exclude=('test_key'))
    assert inspect.iscode(key.code)
    assert key.unambiguous_source == 'values.test'
    expected_keys = [('values.test', "{'test_key': 'test_value'}")]
    assert key.items(sys._getframe()) == expected_keys
    assert key.items(sys._getframe(), normalize=True) == expected_keys
    assert key in {key}
    assert hash(key) == hash(key)


# Unit

# Generated at 2022-06-22 18:28:49.385238
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    BaseVariable.__hash__(None)


# Generated at 2022-06-22 18:28:52.300221
# Unit test for constructor of class Exploding
def test_Exploding():
    expl = Exploding('x')
    original_source = expl.source
    assert(expl.source == 'x')


# Generated at 2022-06-22 18:29:02.437009
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('x', exclude=['y']).source == 'x'
    assert CommonVariable('x').source == 'x'
    assert CommonVariable('x', exclude=['y']).exclude == ('y',)
    assert CommonVariable('x').exclude == ()
    assert CommonVariable('x', exclude=['y'])._fingerprint == (CommonVariable, 'x', ('y',))
    assert CommonVariable('x')._fingerprint == (CommonVariable, 'x', ())
    assert CommonVariable('x', exclude=['y']).items == CommonVariable('x', exclude=['y']).items
    assert CommonVariable('x').items == CommonVariable('x').items
    assert CommonVariable('x', exclude=['y'])._items == CommonVariable('x', exclude=['y'])._items
    assert CommonVariable('x')._items == Common

# Generated at 2022-06-22 18:29:11.739517
# Unit test for constructor of class Exploding
def test_Exploding():
    # Exploding by default
    assert Exploding('x.y')._items([1,2,3,4,5])[0] == ('x.y', '[1, 2, 3, 4, 5]')
    assert Exploding('x.y')[:3]._items([1,2,3,4,5])[0] == ('x.y[:3]', '[1, 2, 3]')
    assert Exploding('x.y').items([1,2,3,4,5])[0] == ('x.y', '[1, 2, 3, 4, 5]')
    assert Exploding('x.y').items([1,2,3,4,5])[3] == ('x.y[3]', '4')

# Generated at 2022-06-22 18:29:17.015405
# Unit test for constructor of class Indices
def test_Indices():
	ind = Indices('my_var', exclude='my_value')
	assert len(ind.source) == 7
	assert ind.source == 'my_var'
	assert ind.exclude == ('my_value',)
	assert ind._slice == slice(None)
	assert ind.unambiguous_source == 'my_var'
	assert len(ind._fingerprint) == 3

# Generated at 2022-06-22 18:29:23.025593
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    try:
        # Python 3.3+
        from unittest.mock import sentinel
    except ImportError:
        from mock import sentinel

    seq = sentinel.seq
    slice = sentinel.slice
    result = Indices('').__getitem__(slice)
    assert hasattr(result, '_slice')
    assert result._slice is slice
    assert result._keys(seq) == range(len(seq))[slice]

# Generated at 2022-06-22 18:29:26.537743
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[0:2] == Indices('a', slice=slice(0,2))
    assert Indices('a')[1:2] == Indices('a', slice=slice(1,2))

# Generated at 2022-06-22 18:29:35.826197
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 调用 BaseVariable 类的 __eq__ 方法进行测试
    x = BaseVariable('__file__')
    y = BaseVariable('__file__')
    # 判断 x 和 y 对象是否相等
    print(x == y)
    # 判断 x 和 y 对象是否不相等
    print(x != y)
    # 判断 x 和 y 对象内存地址是否相等
    print(x is y)
    x = BaseVariable('__file__')
    y = BaseVariable('__name__')
    # 判断 x

# Generated at 2022-06-22 18:29:43.809103
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # __init__
    v = BaseVariable('x')
    assert v.source == 'x'
    assert v.exclude == ()
    assert v.code == compile('x', '<variable>', 'eval')
    assert v.unambiguous_source == 'x'

    # test unspecified exclude
    v = BaseVariable('x')
    assert v.exclude == ()
    assert v.source == 'x'
    assert v.code == compile('x', '<variable>', 'eval')
    assert v.unambiguous_source == 'x'

    # test
    v = BaseVariable('x', exclude = ('y',))
    assert v.exclude == ('y',)
    assert v.source == 'x'
    assert v.code == compile('x', '<variable>', 'eval')
    assert v.un

# Generated at 2022-06-22 18:29:49.856639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestBaseVariable(BaseVariable):
        def _items(self):
            return self.a, self.b

        def _second(self):
            return self.b

    v = TestBaseVariable()
    v.a = 1
    v.b = 2
    assert not v._second()
    assert not v._second()
    assert v._items() == (1, 2)
    assert v._items() == (1, 2)



# Generated at 2022-06-22 18:29:58.320400
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a + b') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a + b.c') == False
    assert needs_parentheses('a.b + c') == False
    assert needs_parentheses('(a)') == False
    assert needs_parentheses('(a) + b') == False
    assert needs_parentheses('a + (b)') == False
    assert needs_parentheses('a.b') == False
    assert needs_parentheses('a.b + c') == False
    assert needs_parentheses('(a + b).c') == False
    assert needs_parentheses('((a + b).c)') == False
    assert needs_parentheses('a[i]') == False
   

# Generated at 2022-06-22 18:30:05.142850
# Unit test for constructor of class Keys
def test_Keys():
    # Make an instance of class Keys
    v = Keys('f')
    assert v.source == 'f'
    assert v.code.co_names == ('f',)
    assert v.unambiguous_source == 'f'
    assert v.exclude == ()
    assert v._fingerprint == (Keys, 'f', ())
    assert v._safe_keys(range(10)) == range(10)
    assert v._format_key(2) == '[2]'
    assert v._get_value(range(10), 2) == 2

# Generated at 2022-06-22 18:30:13.590365
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import itertools

    class Scope(object):
        a = 1
        b = {
            'c': 2,
            'd': 3
        }
        e = [4, 5, 6]
    class List(object):
        def __init__(self):
            self.a = 1
    class List2(object):
        __slots__ = ['a']
        def __init__(self):
            self.a = 1
    class List3(object):
        __dict__ = {'a': 1}
    class List4(object):
        __dict__ = {'a': 1}
        __slots__ = ['a']

    assert(BaseVariable('a').items(inspect.currentframe()) == [('a', '1')])

# Generated at 2022-06-22 18:30:20.108040
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('x')
    b = BaseVariable('x')
    assert a == b

    c = BaseVariable('x', exclude='1')
    d = BaseVariable('x', exclude='1')
    assert c == d

    e = BaseVariable('x', exclude='1')
    f = BaseVariable('x', exclude='2')
    assert e != f

    g = BaseVariable('x', exclude='1')
    h = BaseVariable('y', exclude='1')
    assert g != h

# Generated at 2022-06-22 18:30:22.283060
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a_source')
    b = BaseVariable('a_source')
    assert a == b


# Generated at 2022-06-22 18:30:28.744719
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    exc = []
    def test_items():
        frame = type('Frame', (object,), dict(f_locals={}))
        variables = [
            Keys('a'), Keys('a', exclude='b'), Keys({'a': 'b'}),
            Indices('a'), Indices('a', exclude=3), Indices([1,2,3]),
            Attrs('a'), Attrs('a', exclude='b'), Attrs(object()),
            Exploding('a'), Exploding('a', exclude='b'), Exploding(object()),
        ]
        for variable in variables:
            try:
                variable.items(frame)
            except Exception as e:
                exc.append('{} cause {}'.format(variable, e))
    test_items()
    assert not exc, exc

# Generated at 2022-06-22 18:30:40.295096
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 1. Both arguements are BaseVariable instances
    # 1.1 both arguements are of the same class
    # 1.1.1 both source is the same
    # 1.1.1.1 both exclude is the same
    a = Attrs('a', exclude=['b'])
    b = Attrs('a', exclude=['b'])
    assert a == b
    # 1.1.1.2 exclude is different
    b = Attrs('a', exclude=['d'])
    assert a != b
    # 1.1.2 source is different
    b = Attrs('c', exclude=['b'])
    assert a != b
    # 1.2 both arguements are of different class
    b = Indices('a', exclude=['b'])
    assert a != b
    # 1.3 one

# Generated at 2022-06-22 18:30:47.741089
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a + b')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a.b)')
    assert needs_parentheses('(a.b).c')
    assert not needs_parentheses('((a.b)).c')
    assert not needs_parentheses('a.b().c')
    assert not needs_parentheses('a().b.c')
    assert needs_parentheses('a().b.c().d')
    assert needs_parentheses('a.b().c.d()')
    assert not needs_parentheses('((a).b).c')

# Unit tests for class BaseVariable

# Generated at 2022-06-22 18:30:55.455069
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys('.keys()')
    assert var.source == '.keys()'
    var2 = Keys('')
    assert var2.source == ''
    assert var.exclude == ()
    var3 = Keys('', (1, 2))
    assert var3.exclude == (1, 2)
    try:
        var4 = Keys()
        assert False
    except TypeError:
        pass
    var5 = Keys('', 1)
    assert var5.exclude == (1,)
    var6 = Keys('', 'a')
    assert var6.exclude == ('a',)
    var7 = Keys('', 'a', 'b', 'c')
    assert var7.exclude == ('a', 'b', 'c')

# Generated at 2022-06-22 18:31:02.777260
# Unit test for constructor of class Indices
def test_Indices():
    a = [1, 2, 3]
    ind = Indices('a')
    assert ind.source == 'a'
    assert ind._slice == slice(None, None, None)
    assert ind.items(dict(a=a), normalize=False) == [('a', utils.get_shortish_repr(a))]
    ind1 = ind[:]
    ind2 = ind[2:]
    assert ind1.source == ind.source
    assert ind1._slice == ind._slice
    assert ind2.source == ind.source
    assert ind2._slice == slice(2, None, None)
    ind3 = ind[:2]
    assert ind3.source == ind.source
    assert ind3._slice == slice(None, 2, None)
    ind4 = ind[::2]
    assert ind4

# Generated at 2022-06-22 18:31:13.729299
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('1') is False
    assert needs_parentheses('1 + 1') is True
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a[0]') is False
    assert needs_parentheses('a.b.c') is True
    assert needs_parentheses('(a.b.c)') is False
    assert needs_parentheses('a[1:2]') is False
    assert needs_parentheses('a[0][0]') is False
    assert needs_parentheses('"a".upper()') is True
    assert needs_parentheses('"a".upper()') is True
    assert needs_parentheses('(1 and 1) or 1') is False
    assert needs_parentheses('(1 or 1) and 1') is False

# Generated at 2022-06-22 18:31:19.425843
# Unit test for constructor of class Attrs
def test_Attrs():
    def func(x, y):
        return x, y
    return func(2, 3)

a1, a2 = test_Attrs()
attrs1 = Attrs("a1")
attrs2 = Attrs("a2")

print(list(attrs1.items(func.__code__.co_consts[0])))
print(list(attrs2.items(func.__code__.co_consts[0])))


# Generated at 2022-06-22 18:31:23.056244
# Unit test for constructor of class Attrs
def test_Attrs():
    # When
    source = 'test source'
    exclude = 'test exclude'
    v = Attrs(source, exclude)

    # Then
    assert v.source == source
    assert v.exclude == exclude
    assert callable(v.__init__)
    assert v.code is not None
    assert callable(v.items)
    assert callable(v._items)
    assert callable(v._safe_keys)
    assert callable(v._keys)
    assert callable(v._format_key)
    assert callable(v._get_value)


# Generated at 2022-06-22 18:31:26.504521
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert list(Indices('m').__getitem__(slice(3))) == [
        ('m[0]', ''), ('m[1]', ''), ('m[2]', '')]

# Generated at 2022-06-22 18:31:36.190254
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    b1 = BaseVariable("a")
    b2 = BaseVariable("a", exclude="b")
    b3 = BaseVariable("a", exclude=("a", "b"))
    assert b1.source == "a"
    assert b1.code == compile("a", '<variable>', 'eval')
    assert b1.exclude == ()
    assert b1.unambiguous_source == "a"
    assert b2.source == "a"
    assert b2.code == compile("a", '<variable>', 'eval')
    assert b2.exclude == ("b", )
    assert b2.unambiguous_source == "a"
    assert b3.source == "a"
    assert b3.code == compile("a", '<variable>', 'eval')

# Generated at 2022-06-22 18:31:38.952246
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')
    assert not needs_parentheses('(foo)')
    assert needs_parentheses('foo.x + bar.x')
    assert not needs_parentheses('(foo.x + bar.x)')

test_needs_parentheses()

# Generated at 2022-06-22 18:31:50.316127
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "class A: pass; a = A(); a.name = 'wangtao'; a.age = 23; a.skill = ['Python', 'C++']"
    exec(source)
    frame = locals()
    var_attrs = Attrs('a')
    res_attrs = tuple(var_attrs.items(frame, normalize=False))
    print(res_attrs)

    var_keys = Keys('a')
    res_keys = tuple(var_keys.items(frame, normalize=False))
    print(res_keys)

    var_indice = Indices('a')
    res_indice = tuple(var_indice.items(frame, normalize=False))
    print(res_indice)


if __name__ == "__main__":
    test_BaseVariable_items

# Generated at 2022-06-22 18:31:56.188432
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'x'
    exclude = ('a', 'b')
    e = Exploding(source, exclude)
    assert e.source == source
    assert e.exclude == exclude
    assert isinstance(e.code, object) # it's more complicated
    assert isinstance(e.unambiguous_source, str)
    assert e._items == BaseVariable._items # not implemented


# Generated at 2022-06-22 18:31:58.818129
# Unit test for constructor of class Indices
def test_Indices():
    x = [1,2,3,4,5]
    x = Indices(source = x)
    assert isinstance(x, Indices)



# Generated at 2022-06-22 18:32:03.255258
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    assert hash(a) == hash(b)


# Generated at 2022-06-22 18:32:04.119069
# Unit test for constructor of class Indices
def test_Indices():
    y = Indices('y')
    assert isinstance(y, Indices)

# Generated at 2022-06-22 18:32:06.726464
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('__builtins__')[3:7]._slice == slice(3, 7, None)


# Generated at 2022-06-22 18:32:08.412222
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('something')
    assert not needs_parentheses('(something)')


# Generated at 2022-06-22 18:32:13.180314
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # setup
    class TestClass(object):
        def __init__(self):
            self.a = 3
            self.b = 'str'
            self.c = [1,2,3]
        def hello(self):
            print('hello')

    instance = TestClass()
    frame = None # None works, it is actually not necessary for this unit test

    # test Attrs
    source = 'instance'
    va = Attrs(source)

# Generated at 2022-06-22 18:32:17.712068
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys("test")
    assert k.source == "test"
    assert k.code.co_names[0] == "test"
    assert not k.exclude
    assert k.unambiguous_source == "test"



# Generated at 2022-06-22 18:32:26.696998
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('x')
    assert str(e._get_value) == '<bound method Exploding._get_value of Exploding(x)>'
    assert isinstance(e, Exploding)

    e = Attrs('x')
    assert str(e.source) == 'x'
    assert isinstance(e, CommonVariable)

    e = Keys('x')
    assert str(e.source) == 'x'
    assert isinstance(e, CommonVariable)

    e = Indices('x')
    assert str(e.source) == 'x'
    assert isinstance(e, Keys)

# Generated at 2022-06-22 18:32:38.088497
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class CommonVariable_test(CommonVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    class CommonVariable_test_sub(CommonVariable_test):
        pass

    assert CommonVariable_test_sub() is not CommonVariable_test_sub()
    assert CommonVariable_test_sub() == CommonVariable_test_sub()
    assert CommonVariable_test_sub() == CommonVariable_test_sub('')
    assert CommonVariable_test_sub() != CommonVariable_test_sub('', '')
    assert CommonVariable_test_sub() != CommonVariable_test_sub('') != CommonVariable_test_sub('', '')

# Generated at 2022-06-22 18:32:43.769476
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import collections
    #test class BaseVariable
    #test method items
    #create BaseVariable obj
    #test_source = utils.get_string_repr("test")
    #test_exclude = utils.get_string_repr("test")
    #test_BaseVariable = BaseVariable(test_source, test_exclude)
    #test method items of class BaseVariable
    pass

# Generated at 2022-06-22 18:32:45.560879
# Unit test for constructor of class Exploding
def test_Exploding():
    a = {1, 2, 3}
    v = Exploding('a')
    print(v._items(a))



# Generated at 2022-06-22 18:32:56.724715
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    try:
        frame = sys._getframe(0)
    except AttributeError:
        frame = None
    f_locals = frame and frame.f_locals or {}
    f_globals = frame and frame.f_globals or {}
    d,e,f = "hello", "world", "!!!"
    f_locals["d"] = d
    f_locals["e"] = e
    f_locals["f"] = f
    variable_test = BaseVariable("e", exclude=["hello", "world"])
    assert(variable_test.source == "e")
    assert(variable_test.exclude == ["hello", "world"])
    assert(variable_test.code == compile("e", '<variable>', 'eval'))

# Generated at 2022-06-22 18:33:05.838432
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('Test').source == 'Test'
    assert BaseVariable('Test', ['x']).exclude == ('x',)

    # BaseVariable constructor should check whether source can be compiled to Python bytecode
    # successfully, if not, the constructor should raise ValueError exception
    # source is not in form of assignment expression
    try:
        BaseVariable('x = 1')
        assert False, 'BaseVariable constructor should check whether source can be compiled to Python bytecode, if not, the constructor should raise ValueError exception'
    except ValueError:
        pass



# Generated at 2022-06-22 18:33:09.889401
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('foo', 'bar')
    assert var.source == 'foo'
    assert var.exclude == ('bar',)
    assert var.code == compile('foo', '<variable>', 'eval')
    assert var.unambiguous_source == 'foo'


# Generated at 2022-06-22 18:33:17.042655
# Unit test for constructor of class Exploding
def test_Exploding():
    from types import SimpleNamespace
    # Empty variable
    v = Exploding('')
    assert(len(v.items(SimpleNamespace())) == 0)

    # Empty variable with children should be ignored
    v = Exploding('')
    assert(len(v.items(SimpleNamespace(a=1))) == 1)

    # Nested variable
    v = Exploding('b')
    assert(len(v.items(SimpleNamespace(a=SimpleNamespace(b=1)))) == 2)

if __name__ == '__main__':
    test_Exploding()

# Generated at 2022-06-22 18:33:22.741808
# Unit test for constructor of class Attrs
def test_Attrs():
    # test with instance method
    class TestClass(object): 
        def __init__(self):
            self.x = 42
        def __str__(self): 
            return "TestClass object"

    test_attrs = Attrs('self')
    x = TestClass()

    assert test_attrs.source == 'self'
    assert test_attrs.exclude == ()
    assert test_attrs._items(x) == [('self', 'TestClass object'),
                                    ('self.x', '42')]

    # test with class method
    class TestClass2(object): 
        x = 42
    test_attrs2 = Attrs('self')


# Generated at 2022-06-22 18:33:31.477851
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('a.b.c')
    assert x.source == 'a.b.c'
    assert x.code.co_names == ('a', 'b', 'c')
    assert x.exclude == ()
    assert x.unambiguous_source == 'a.b.c'

    x = CommonVariable('a[b]', exclude='b')
    assert x.source == 'a[b]'
    assert x.code.co_names == ('a', 'b')
    assert x.exclude == ('b', )
    assert x.unambiguous_source == '(a[b])'


# Generated at 2022-06-22 18:33:37.939991
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('x')
    b = BaseVariable('x')
    assert a == b
    assert a.source == 'x'
    assert b.source == 'x'
    assert a.exclude == ()
    assert b.exclude == ()
    assert a.unambiguous_source == 'x'
    assert b.unambiguous_source == 'x'


# Generated at 2022-06-22 18:33:45.280130
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    source = 'z'
    exclude = ['a']
    
    # Constructor of class BaseVariable
    BaseVariable(source, exclude)

    # get a BaseVariable object
    v = BaseVariable(source, exclude)
    v.source == source
    v.exclude == exclude
    v.code == compile(source, '<variable>', 'eval')
    v.unambiguous_source == 'z'
    # Unit test for __hash__
    # hash(v.code) != hash(v.source)
    # hash(hash(v.source)) == hash(v.source)
    # hash(v) != hash(v.source)
    # hash(v) == hash((type(v), v.source, v.exclude))

    # Unit test for __eq__
    # v == v.source

# Generated at 2022-06-22 18:33:53.582693
# Unit test for constructor of class Attrs
def test_Attrs():
    aa = Attrs('main_value', exclude=('a1', 'a2'))
    assert aa.source == 'main_value'
    assert aa.exclude == ('a1', 'a2')
    aa.code
    assert str(aa.code) == "<code object <module> at 0x7f180d556530, file '<variable>', line 1>"
    assert aa.unambiguous_source == 'main_value'


# Generated at 2022-06-22 18:34:04.263866
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b.c')
    assert needs_parentheses('(a.b).c')
    assert not needs_parentheses('a(123, foo = False)')
    assert needs_parentheses('a.b.c(123, foo = False)')
    assert not needs_parentheses('(a.b).c(123, foo = False)')


VARIABLES = {
    'a': (Attrs, Keys, Indices, Exploding),
    'k': (Keys, Indices, Exploding),
    'i': (Indices, Exploding),
    'x': (Exploding,),
}



# Generated at 2022-06-22 18:34:11.560034
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('a')._items(['b'])[0][1], str)


DEFAULT_VARIABLE_NAMES = dict(
    a=Attrs,
    k=Keys,
    i=Indices,
    e=Exploding,
)


# Generated at 2022-06-22 18:34:21.970407
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a.b', 'x')
    var2 = BaseVariable('a.b', 'x')
    var3 = BaseVariable('a.b', 'y')
    var4 = BaseVariable('a.c', 'x')
    assert var1 == var2
    assert var1 != var3
    assert var1 != var4
    assert var2 == var3
    assert var3 != var4
    assert var1 != 'a.b'
    assert var1 != None
    assert var2 != 'a.b'
    assert var2 != None
    assert var3 != 'a.b'
    assert var3 != None
    assert var4 != 'a.b'
    assert var4 != None



# Generated at 2022-06-22 18:34:25.209721
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'a'
    exclude = tuple('exclude')
    var = BaseVariable(source, exclude)
    var1 = BaseVariable(source, exclude)
    print(var == var1)
    print(var == 'abc')
    print(var == 5)

test_BaseVariable___eq__()


# Generated at 2022-06-22 18:34:36.917414
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('f(x)') == False
    assert needs_parentheses('f(x.y)') == False
    assert needs_parentheses('x.y + z') == False
    assert needs_parentheses('x.y.z + w') == False
    assert needs_parentheses('(x).y') == False
    assert needs_parentheses('(x.y).z') == False

    assert needs_parentheses('x.y + z.w') == True
    assert needs_parentheses('x.y.z + w.t') == True
    assert needs_parentheses('(x + y).z') == True
    assert needs_

# Generated at 2022-06-22 18:34:41.443632
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('foo')
    assert isinstance(e, Exploding)
    assert e.source == 'foo'
    assert e.exclude == ()
    assert e.unambiguous_source == 'foo'


# Generated at 2022-06-22 18:34:44.266826
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('x')
    assert attrs.source == 'x'
    assert isinstance(attrs.code, code)
    assert attrs.unambiguous_source == 'x'


# Generated at 2022-06-22 18:34:46.683900
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # assert BaseVariable('x', tuple()).__eq__(BaseVariable('x', tuple())) == True
    assert BaseVariable('x', tuple()).__eq__(BaseVariable('y', tuple())) == False


# Generated at 2022-06-22 18:34:56.899377
# Unit test for constructor of class Keys
def test_Keys():
    source = 'import numpy as np\nimport pandas as pd\n'
    source += '''
    class Foo:
        def __init__(self):
            self.a = 10
            self.b = 20
            self.bar = lambda: print('bar')
            self.baz = lambda x: x + 1
    '''
    source += 'foo = Foo()'
    frame = utils.get_frame(source)

    var = Keys('foo')
    assert var.items(frame) == [
        ('foo', 'Foo()'),
        ('foo.a', '10'),
        ('foo.b', '20'),
    ]

    # no actual keys
    var = Keys('foo.bar')

# Generated at 2022-06-22 18:35:04.874129
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('')
    assert needs_parentheses('()')
    assert needs_parentheses('(())')
    assert needs_parentheses('x')
    assert needs_parentheses('1')
    assert needs_parentheses('"x"')
    assert needs_parentheses('"x".y')
    assert needs_parentheses('"x"."y"')
    assert needs_parentheses('"x".y.z')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('x.y.z()')
    assert not needs_parentheses('x().y')
    assert not needs_parentheses('x()[y]')
    assert not needs_parentheses('x()["y"]')
    assert not needs_parent

# Generated at 2022-06-22 18:35:10.520853
# Unit test for constructor of class Indices
def test_Indices():
    # pylint: disable=unused-variable
    # pylint: disable=unsubscriptable-object
    Index1 = Indices('x')
    Index2 = Indices('x')[1:]
    Index3 = Indices('y')[1:3]
    assert Index1 == Index2
    assert Index1 != Index3
    assert Index2 != Index3

# Generated at 2022-06-22 18:35:21.656123
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    locals = {'x': 1, 'y': 2}
    globals = {'foo': 'bar', 'baz': 'qux'}

    bv = BaseVariable('y')
    assert bv.source == 'y'
    assert bv.exclude == ()
    assert bv.code == compile('y', '<variable>', 'eval')
    assert bv.unambiguous_source == 'y'

    bv2 = BaseVariable('x', 'y')
    assert bv2.source == 'x'
    assert bv2.exclude == ('y',)
    assert bv2.code == compile('x', '<variable>', 'eval')
    assert bv2.unambiguous_source == 'x'

    bv3 = BaseVariable('foo', 'baz')
    assert bv3

# Generated at 2022-06-22 18:35:23.213817
# Unit test for constructor of class Keys
def test_Keys():
    myVars = Keys('a')
    assert isinstance(myVars, Keys)

# Generated at 2022-06-22 18:35:24.899424
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    idx = Indices('a')[-50:-35]
    assert idx.source == 'a[-50:-35]'


# Generated at 2022-06-22 18:35:27.675837
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs("IMPORTANT_DATA")
    assert attr.source == "IMPORTANT_DATA"
    assert attr.exclude == ()
    #TODO: add more tests


# Generated at 2022-06-22 18:35:34.108514
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    cls = BaseVariable('x')
    cls.items = 'x'
    x = cls.items
    del frame.f_globals['x']
    frame.f_globals.clear()
    frame.f_locals.clear()
    x1 = cls.items
    del frame.f_globals['x']
    frame.f_globals.clear()
    frame.f_locals.clear()
    x == x1
    x2 = cls.items
    frame.f_globals['x'] = x
    frame.f_globals.clear()
    frame.f_locals.clear()
    x2 == x

# Generated at 2022-06-22 18:35:37.093108
# Unit test for constructor of class Indices
def test_Indices():
    expected = [
        ('obj', '[]'),
        ('obj[0]', ''),
        ('obj[1]', ''),
    ]
    assert list(Indices('obj').items({'obj': []})) == expected


# Generated at 2022-06-22 18:35:47.561660
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('x')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x', exclude='y')) == hash(BaseVariable('x'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('y'))
    assert hash(BaseVariable('x')) != hash(BaseVariable('x', exclude='y'))
    assert hash(BaseVariable('x', exclude='y')) != hash(BaseVariable('x', exclude='z'))
    assert hash(BaseVariable('x', exclude='z')) != hash(BaseVariable('y', exclude='y'))
    assert hash(BaseVariable('x')) != hash(Attrs('x'))
    assert hash(Attrs('x')) == hash(Attrs('x'))

# Generated at 2022-06-22 18:35:52.879769
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('a'), BaseVariable)
    assert not isinstance(Exploding('a'), CommonVariable)
    assert not isinstance(Exploding('a'), Keys)
    assert not isinstance(Exploding('a'), Indices)
    assert not isinstance(Exploding('a'), Attrs)