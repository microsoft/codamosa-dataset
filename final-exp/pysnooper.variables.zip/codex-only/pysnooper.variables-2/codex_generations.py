

# Generated at 2022-06-22 18:26:01.471001
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    frame = inspect.currentframe()
    assert frame is not None

    test_dict = {"a": 1, "b": 2}
    test_list = [1, 2, 3]
    source = 'test_dict'

    test_dict_keys = tuple(tuple((source, '{')) + tuple((f'{source}[{k}]', v) for k,v in test_dict.items()))
    keys = Keys(source).items(frame)
    assert keys == test_dict_keys

    source = 'test_list'
    test_list_keys = tuple(
        tuple((source, '[')) + tuple((f'{source}[{k}]', v) for k, v in enumerate(test_list)))
    keys = Indices(source).items(frame)
    assert keys == test_list

# Generated at 2022-06-22 18:26:07.303531
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('(') == True
    assert needs_parentheses('()') == True
    assert needs_parentheses('(x)') == True
    assert needs_parentheses('x[0]') == True
    assert needs_parentheses('x.y') == True

# Unit tests for classes: Attrs, Keys and Indices

# Generated at 2022-06-22 18:26:17.443684
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import hashlib
    import random
    import string
    import datetime

    if sys.version_info[0] == 2:
        ordered_set = set
    else:
        from collections import OrderedDict
        ordered_set = OrderedDict

    def random_string(length, charset=string.ascii_letters + string.digits):
        return ''.join(random.choice(charset) for _ in range(length))

    #Check if the hash of a variable that is not a BaseVariable returns the same value as the variable
    #We check integers and strings
    for i in range(1000):
        x = random.randint(0, 2**31)
        assert hash(x) == x,  'method __hash__ of class BaseVariable returns a wrong hash value. We expect the same value as the variable'



# Generated at 2022-06-22 18:26:22.372171
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Initialize variable to be tested
    variable = BaseVariable('foo', exclude=())
    variable1 = BaseVariable('foo', exclude=())
    variable2 = BaseVariable('foo', exclude=())
    variable3 = BaseVariable('foo', exclude=('bar'))
    variable4 = BaseVariable('foo', exclude=('bar'))

    # Call method to be tested
    eq_ = variable == variable1
    eq_1 = variable == variable2
    eq_2 = variable == variable3
    eq_3 = variable == variable4

    # Check if the results are as expected
    if (eq_ and eq_1 and not eq_2 and eq_3):
        print("Testing test_BaseVariable___eq__ PASSED")
    else:
        print("Testing test_BaseVariable___eq__ FAILED")



# Generated at 2022-06-22 18:26:24.620511
# Unit test for constructor of class Exploding
def test_Exploding():
    ev = Exploding('something')
    assert ev.source == 'something'
    assert not ev.exclude
    assert ev.unambiguous_source == 'something'


# Generated at 2022-06-22 18:26:27.706975
# Unit test for constructor of class Exploding
def test_Exploding():
    attrs = Attrs('a').items(frame=None)
    indices = Indices('a').items(frame=None)
    keys = Keys('a').items(frame=None)
    exploding = Exploding('a').items(frame=None)

    assert attrs == exploding
    assert indices == exploding
    assert keys == exploding



# Generated at 2022-06-22 18:26:33.147769
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[:] == Indices('a')[0:] == Indices('a')[:100] == Indices('a')
    assert Indices('a')[1:2] == Indices('a')[1:100]
    assert Indices('a')[1:2:1] == Indices('a')[1:100:1]
    assert Indices('a')[::-1] == Indices('a', exclude=slice(None, -1, -1))

# Generated at 2022-06-22 18:26:44.947285
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import numpy as np
    import pandas as pd

    def test(source, f_locals, expected):
        actual = BaseVariable(source).items(frame=None, f_locals=f_locals)
        assert actual == expected

    # test source
    test('x', {'x': 1}, [('x', '1')])  # simple variable
    test('x.y', {'x': 1}, [('x.y', 'None')])  # variable accessing an attribute of 1

    # test exclude
    test('x', {'x': 1}, [('x', '1')])  # no exclusion
    test('x', {'x': 1}, [('x', '1')])  # only exclude a value different from 1
    test('x', {'x': 1}, [('x', '1')]) 

# Generated at 2022-06-22 18:26:47.339921
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    bv = Keys('a').items(frame)
    assert len(bv) == 2


# Generated at 2022-06-22 18:26:49.008233
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a', exclude=tuple())
    assert a._fingerprint == (Attrs, 'a', tuple())



# Generated at 2022-06-22 18:27:00.342014
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pycallgraph
    class OtherModule(object):
        pass
    class Other(object):
        def __init__(self, x):
            self.x = x
        def foo(self):
            print(self.x)
    other = Other(3)
    var = pycallgraph.Config().variables['x']
    items = var.items({'x': 2, 'other': other, 'Other': Other, 'OtherModule': OtherModule})
    assert items == (('x', 2),) or items == (('x', '2'),)
    items = var.items({'x': {'y': 4, 'z': [1, '2', (1, 2)]},
                       'other': other, 'Other': Other, 'OtherModule': OtherModule})

# Generated at 2022-06-22 18:27:12.065566
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert len({BaseVariable('a')}) == 1
    assert len({BaseVariable('a'), BaseVariable('a')}) == 1
    assert len({BaseVariable('a'), BaseVariable('b')}) == 2
    assert len({BaseVariable('a.b')}) == 1
    assert len({BaseVariable('a.b'), BaseVariable('a.b')}) == 1
    assert len({BaseVariable('a.b'), BaseVariable('a.c')}) == 2
    assert len({BaseVariable('a', exclude='b')}) == 1
    assert len({BaseVariable('a', exclude='b'), BaseVariable('a', exclude='b')}) == 1
    assert len({BaseVariable('a', exclude='b'), BaseVariable('a', exclude='c')}) == 2

# Generated at 2022-06-22 18:27:18.724771
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('x')
    b = BaseVariable('x')
    c = BaseVariable('y')
    d = BaseVariable('x', ('a', 'b'))
    e = BaseVariable('x', ('a', 'b'))
    assert a == a
    assert a == b
    assert b == a
    assert a != c
    assert c != a
    assert a != d
    assert a != c
    assert d == e


# Generated at 2022-06-22 18:27:19.330136
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass

# Generated at 2022-06-22 18:27:26.604823
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
  assert BaseVariable(source = 'a') == BaseVariable(source = 'a')
  assert BaseVariable(source = 'a', exclude = 'b') != BaseVariable(source = 'a')
  assert BaseVariable(source = 'a') != BaseVariable(source = 'b')
  assert BaseVariable(source = 'a', exclude = 'b') != BaseVariable(source = 'a', exclude = 'c') 
  assert BaseVariable(source = 'a', exclude = 'b') == BaseVariable(source = 'a', exclude = 'b') 
  assert BaseVariable(source = 'a', exclude = 'b') != Attrs(source = 'a', exclude = 'b')


# Generated at 2022-06-22 18:27:28.370046
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 18:27:31.432240
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    f1 = BaseVariable("a","")
    f2 = BaseVariable("a","")
    f3 = BaseVariable("a","d")
    f4 = BaseVariable("b","")
    assert(f1 == f2)
    assert(f1 != f3)
    assert(f1 != f4)

# Generated at 2022-06-22 18:27:35.136685
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
	a = BaseVariable('test', 'a')
	assert a.source == 'test'
	assert a.exclude == 'a'

# Generated at 2022-06-22 18:27:45.816375
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('f')
    assert not needs_parentheses('f.x')
    assert not needs_parentheses('f("x")')
    assert not needs_parentheses('f("x", "y")')
    assert needs_parentheses('-f')
    assert needs_parentheses('+f')
    assert needs_parentheses('2 * f')
    assert needs_parentheses('f + 2')
    assert needs_parentheses('f(1 + 1)')
    assert needs_parentheses('f(1, 2, 3)')
    assert not needs_parentheses('f(a)')
    assert not needs_parentheses('f(a, b)')
    assert not needs_parentheses('f(a or b)')
    assert not needs_parentheses('f(1 or 2)')
    assert not needs

# Generated at 2022-06-22 18:27:47.865250
# Unit test for constructor of class Attrs
def test_Attrs():
    x=1
    a = Attrs("x")



# Generated at 2022-06-22 18:27:57.245266
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a["b"]')
    assert needs_parentheses('a()')
    assert needs_parentheses('a().b')
    assert needs_parentheses('a().b.c["d"]()')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a)["b"]')
    assert not needs_parentheses('(a())')
    assert not needs_parentheses('(a()).b')
    assert not needs_parentheses('(a().b).c["d"]()')
    assert needs_parentheses('int(a)')
    assert not needs_parentheses('int(a).b')
    assert needs_

# Generated at 2022-06-22 18:27:58.969446
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    INDICES = Indices('foo')
    assert INDICES[1:3]._slice == slice(1, 3)

# Generated at 2022-06-22 18:28:08.170492
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class Something(object):
        indices = Indices("x")
        __getitem__ = indices.__getitem__

    x = Something()
    x.x = [1, 2, 3, 4, 5]

    for i in (1, 2, 3):
        gen = x[1:i]
        assert gen.source == "x"
        assert gen.exclude == ()
        assert gen._slice == slice(1, i)

    for i in (1, 2, 3):
        gen = x[1:i:2]
        assert gen.source == "x"
        assert gen.exclude == ()
        assert gen._slice == slice(1, i, 2)

    gen = x[1::2]
    assert gen.source == "x"
    assert gen.exclude == ()

# Generated at 2022-06-22 18:28:13.126814
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')[1:2]
    assert var._slice == slice(1, 2)
    assert var.source == 'var'
    assert var.exclude == tuple()
    assert var.code == compile('var', '<variable>', 'eval')
    assert var.unambiguous_source == 'var'
    assert var.items(None) == tuple()


if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:28:19.149466
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable('path', 'file_name')
    var_2 = BaseVariable('path', 'file_name')
    assert var_1 == var_2
    var_3 = BaseVariable('path', 'file_name2')
    assert var_1 != var_3
    var_4 = BaseVariable('path2', 'file_name')
    assert var_1 != var_4


# Generated at 2022-06-22 18:28:24.672999
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('x', exclude=['_exclude'])
    assert attrs.source == 'x'
    assert attrs.exclude == ['_exclude']
    assert attrs.code is compile('x', '<variable>', 'eval')
    assert attrs.unambiguous_source == 'x'



# Generated at 2022-06-22 18:28:33.328617
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var1 = BaseVariable('var1')
    var2 = BaseVariable('var2')
    var3 = BaseVariable('var3')
    t1 = (var1, var2, var3)

    var1_copy = BaseVariable('var1')
    var2_copy = BaseVariable('var2')
    var3_copy = BaseVariable('var3')
    t2 = (var1_copy, var2_copy, var3_copy)

    # test 1: do tuples contain the same objects
    assert var1 in t1 and var2 in t1 and var3 in t1
    assert var1_copy in t2 and var2_copy in t2 and var3_copy in t2

    # test 2: objects have the same hash
    assert hash(var1) == hash(var1_copy)

# Generated at 2022-06-22 18:28:34.783263
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('a[1]')
    indices.__getitem__(slice(1,2))

# Generated at 2022-06-22 18:28:40.414365
# Unit test for constructor of class Indices
def test_Indices():
  i = Indices('main_value')
  assert i._slice == slice(None)
  assert i._source == 'main_value'
  # Test constructor with slice parameter
  i = Indices('main_value',exclude=('a'))
  assert i._slice == slice(None)
  assert i._source == 'main_value'
  assert i.exclude[0] == 'a'
  # Test constructor with slice parameter
  i = Indices('main_value',slice(1,2))
  assert i._slice == slice(1,2)
  assert i._source == 'main_value'
  i.exclude = ('a')
  assert i._slice == slice(1,2)
  assert i._source == 'main_value'
  assert i.exclude[0] == 'a'
  # Test

# Generated at 2022-06-22 18:28:44.435197
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('(a)') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('(a).b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('(a).b.c') is False
    assert needs_parentheses('a[1]') is False
    assert needs_parentheses('(a)[1]') is False
    assert needs_parentheses('a[1][2]') is False
    assert needs_parentheses('(a)[1][2]') is False
    assert needs_parentheses('(a[1])[2]') is False
    assert needs_parentheses('a[1].b') is False

# Generated at 2022-06-22 18:28:49.791155
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    obj0 = BaseVariable(exclude='exclude-dummy', source='source-dummy')
    obj1 = BaseVariable(exclude='exclude-dummy', source='source-dummy')
    if hash(obj0) != hash(obj1):
        raise AssertionError
test_BaseVariable___hash__()

# Generated at 2022-06-22 18:28:58.868786
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def check_items(cls, source, normalize=False):
        """return an list contains the items"""
        var = cls(source)
        # It's a little difficult to separate the code fragment of function items, 
        # so I simulate the method items by calling it directly
        if isinstance(cls, Exploding):
            return var.items(None, normalize)
        else:
            return var._items(None, normalize)
    def test_Attrs():
        assert check_items(Attrs, 'x', False) == [('x', 'None')]
        assert check_items(Attrs, 'spam', False) == [('spam', "'spam'")]
        assert check_items(Attrs, 'spam', True) == [('spam', 'str')]

# Generated at 2022-06-22 18:29:05.849438
# Unit test for constructor of class Attrs
def test_Attrs():
	assert Attrs('a').__dict__ == {'source': 'a', 'exclude': ()}
	assert Attrs('a',exclude=['b']).__dict__ == {'source': 'a', 'exclude': ('b',)}
	assert Attrs('a',exclude=('b')).__dict__ == {'source': 'a', 'exclude': ('b',)}
	assert Attrs('a',exclude=set('b')).__dict__ == {'source': 'a', 'exclude': ('b',)}


# Generated at 2022-06-22 18:29:06.423087
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    pass

# Generated at 2022-06-22 18:29:11.170995
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('main_value', 'exclude')
    assert k.source == 'main_value'
    assert k.exclude == ('exclude',)
    assert k.code is not None
    assert k._fingerprint == (Keys, 'main_value', ('exclude',))
    assert str(k) == 'Keys(main_value, exclude=exclude)'


# Generated at 2022-06-22 18:29:21.238955
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pdb  # noqa
    MESSAGE = 'Indices___getitem__'
    
    a = [1,2,3,4]
    # Example:
    # a = [1,2,3,4]
    # b = Indices(a)
    # c = b[0:2]
    # a.append(5)
    # d = c._items(a)
    # print(d)
    b = Indices('a')
    c = b[0:2]
    a.append(5)
    try:
      d = c._items(a)
    except:
      print(MESSAGE, 'Error')
    else:
      print(MESSAGE, 'Ok')

# Generated at 2022-06-22 18:29:24.251889
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('x', exclude = ['a','b','c'])
    assert x.source == 'x'
    assert x.exclude == ['a','b','c']
    print('done')


# Generated at 2022-06-22 18:29:34.419806
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    def items(source, frame):
        var = BaseVariable(source)
        return var.items(frame)


    class BaseMock(object):
        def __init__(self, result):
            self.result = result

        def __getattribute__(self, name):
            if name == '_exclude_result':
                return None
            if name == 'result':
                return object.__getattribute__(self, name)
            return object.__getattribute__(self, 'result')


    class AttrsMock(BaseMock):
        def _items(self, key, normalize=False):
            for k, v in iter(self.result):
                yield '{}.{}'.format(self.source, k), v


# Generated at 2022-06-22 18:29:41.634722
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('foo', exclude=['bar'])
    assert (attrs.source, attrs.exclude) == ('foo', ('bar',))
    assert attrs.code == compile('foo', '<variable>', 'eval')
    assert attrs.unambiguous_source == '(foo)'

    attrs = Attrs('foo.bar')
    assert (attrs.source, attrs.exclude) == ('foo.bar', ())
    assert attrs.code == compile('foo.bar', '<variable>', 'eval')
    assert attrs.unambiguous_source == '((foo).bar)'


# Generated at 2022-06-22 18:29:47.748676
# Unit test for constructor of class Exploding
def test_Exploding():
    obj = {
        'a': 'A',
        'b': [1, 2, 3],
        'c': {
            'd': 'D',
            'e': {
                'f': 'F',
                'g': 'G'
            }
        }
    }
    obj2 = [
        ['a', 'A'],
        ['b', [1, 2, 3]],
        ['c', [
            ['d', 'D'],
            ['e', [
                ['f', 'F'],
                ['g', 'G']
            ]]
        ]]
    ]

# Generated at 2022-06-22 18:29:48.993540
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable(1)
    assert a == a
    assert a != BaseVariable(2)



# Generated at 2022-06-22 18:29:57.692289
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class BaseVariable_mock(BaseVariable):
        def __init__(self, source, exclude=None):
            # Abstract method _items is not implemented
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

    v1 = BaseVariable_mock('a')
    v2 = BaseVariable_mock('a')
    v3 = BaseVariable_mock('b')
    v4 = BaseVariable_mock('a', exclude='x')
    v5 = BaseVariable_mock('a', exclude=['y'])



# Generated at 2022-06-22 18:30:06.690644
# Unit test for constructor of class CommonVariable
def test_CommonVariable():

    def test_valid(cls, value, *keys):
        var = cls('x')
        var.source = 'x'
        var.exclude = ()
        var.code = compile('x', '<variable>', 'eval')
        var.unambiguous_source = 'x'
        var.items(value)
        var.exclude = keys
        var.items(value)

    def test_invalid(cls, value):
        var = cls('x')
        var.items(value)

    # test valid values
    test_valid(Attrs, 'abc', '__dict__')
    test_valid(Keys, 'abc', '__dict__')
    test_valid(Keys, 'abc', '__dict__')
    test_valid(Indices, 'abc', '__dict__')
   

# Generated at 2022-06-22 18:30:09.371057
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('main_value')
    indices_obj = indices[2:10]
    assert indices_obj._slice.start == 2
    assert indices_obj._slice.stop == 10

# Generated at 2022-06-22 18:30:19.123273
# Unit test for constructor of class Indices
def test_Indices():
    #  Test validations for constructor of Indices
    # Test without parameters
    assert "test_arg" in str(Indices.__init__.__code__.co_varnames)
    # Test with one parameter
    assert "test_arg" in str(Indices.__init__.__code__.co_varnames)
    # Test with two parameters
    assert "test_arg" in str(Indices.__init__.__code__.co_varnames)
    # Test with three parameters
    assert "test_arg" in str(Indices.__init__.__code__.co_varnames)



# Generated at 2022-06-22 18:30:25.684010
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test(source, exclude, expected_items):
        actual_items = BaseVariable(source, exclude).items(None)
        assert actual_items == expected_items
    # test the first two if-statements in method items
    test('1', (), []) # source is a number
    test('[]', (), [('[]', '[]')]) # source is a list

    # test the for-loop in method items
    test('a.b', ('a.b.c',), [('a.b', utils.get_shortish_repr('b'))]) # source is a dict



# Generated at 2022-06-22 18:30:26.842716
# Unit test for constructor of class Exploding
def test_Exploding():
    Exploding('a.b')

# Generated at 2022-06-22 18:30:31.518681
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('a').source == 'a'
    assert Keys('a').exclude == ()

    assert Keys('a', 'b').exclude == ('b',)
    assert Keys('a', ['b', 'c']).exclude == ('b', 'c')


# Generated at 2022-06-22 18:30:35.557961
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable('source', exclude='x')
    assert v.source == 'source'
    assert v.exclude == ('x',)
    assert v.code.co_name == 'source'
    assert v.unambiguous_source == 'source'


# Generated at 2022-06-22 18:30:45.542394
# Unit test for constructor of class Keys
def test_Keys():
    source = 'a'
    exclude = []
    v = Keys(source, exclude)
    assert source == v.source
    assert exclude == v.exclude
    assert '<code object <module> at 0x7f3510eac1b0, file "<variable>", line 1>' == str(v.code)
    assert v.unambiguous_source == 'a'
    assert v.items({'a':{'b':1}}, True) == [('a', '{u\'b\': 1}')]
    assert v._safe_keys([1,2]) == [0, 1]
    assert v.items([1,2], True) == [('a', '[1, 2]'), ('a[0]', '1'), ('a[1]', '2')]

# Generated at 2022-06-22 18:30:48.356581
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    source = "test_BaseVariable___hash__()"
    exclude = [1,2,3]
    code = compile(source, '<variable>', 'eval')
    assert(code != code(('a')))

    test = BaseVariable(source, exclude)
    test.code = code
    assert(test.__hash__() == 2)


# Generated at 2022-06-22 18:30:53.666012
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    x = BaseVariable('1 + 1')
    x.code
    print(x.source)
    print(x.unambiguous_source)


# Generated at 2022-06-22 18:30:59.030766
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('a')
    assert ind.source == 'a'
    assert ind.exclude == ()
    assert ind._slice == slice(None)

    ind_new = ind[1:3]
    assert ind_new.source == 'a'
    assert ind_new.exclude == ()
    assert ind_new._slice == slice(1, 3)

    with pytest.raises(AssertionError):
        ind[1]



# Generated at 2022-06-22 18:31:00.988667
# Unit test for constructor of class Exploding
def test_Exploding():
    Exploding("var")
    Exploding("var", exclude=())
    Exploding("var", exclude="a")
    Exploding("var", exclude=["a", "b"])

# Generated at 2022-06-22 18:31:04.537123
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable('a')
    bv2 = BaseVariable('b')
    bv3 = BaseVariable('a')
    assert not bv1 == bv2
    assert bv1 == bv3

# Generated at 2022-06-22 18:31:08.389062
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    func_name = 'test_BaseVariable_items'
    func_code = """def {}():
    a = 1
    b = 2
    c = 3
    a.x = 5
    a.y = 6
    b.x = 7
    b.y = 8
    c.x = 9
    c.y = 10
""".format(func_name)
    func_code_obj = compile(func_code, '<string>', 'exec')
    l = {}
    exec(func_code_obj, globals(), l)
    func = l[func_name]
    func_code = func.__code__
    frame = sys._getframe()
    for n in list(frame.f_back.f_locals.keys()):
        frame.f_back.f_locals.pop(n)

# Generated at 2022-06-22 18:31:11.464994
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('a')
    assert a == c
    assert a != b
    assert a != object()


# Generated at 2022-06-22 18:31:13.332028
# Unit test for constructor of class Indices

# Generated at 2022-06-22 18:31:15.662519
# Unit test for constructor of class Indices
def test_Indices():
    variable = Indices('a', ('b'))
    assert variable.exclude == ('b',)
    assert variable.source == 'a'


# Generated at 2022-06-22 18:31:23.612164
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('(1)')
    assert needs_parentheses('(a)')
    assert needs_parentheses('(a.b)')
    assert needs_parentheses('(f(a, b, c))')
    assert needs_parentheses('a + b * c')

    assert not needs_parentheses('1')
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('f(a, b, c)')
    assert not needs_parentheses('a or b and c')

# Generated at 2022-06-22 18:31:26.152856
# Unit test for constructor of class Keys
def test_Keys():
    variable = Keys('main_value')
    assert variable.source == 'main_value'
    assert variable.exclude == ()


# Generated at 2022-06-22 18:31:32.835866
# Unit test for constructor of class Indices
def test_Indices():
  indices1 = Indices("a")
  assert indices1._fingerprint == (Indices, "a", ())
  assert indices1.code == compile("a", '<variable>', 'eval')
  assert indices1._slice == slice(None)
  assert indices1.unambiguous_source == "a"

  indices2 = Indices(source = "a", exclude = "b")
  assert indices2._fingerprint == (Indices, "a", ("b",))
  assert indices2.code == compile("a", '<variable>', 'eval')
  assert indices2._slice == slice(None)
  assert indices2.unambiguous_source == "a"


# Generated at 2022-06-22 18:31:38.412040
# Unit test for constructor of class Exploding
def test_Exploding():
    assert repr(Exploding('a')) == repr(Attrs('a'))
    assert repr(Exploding('a', ['b'])) == repr(Attrs('a', ['b']))
    assert repr(Exploding('a')[2:]) == repr(Indices('a')[2:])
    assert repr(Exploding('a', ['b'])[2:]) == repr(Indices('a', ['b'])[2:])

# Generated at 2022-06-22 18:31:39.471929
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVaria

# Generated at 2022-06-22 18:31:41.554630
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable("self.args")
    print(v.__hash__)


# Generated at 2022-06-22 18:31:46.498426
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import sys
    a = BaseVariable("hi")
    b = BaseVariable("hello")
    print(sys.getsizeof(a))
    print(sys.getsizeof(b))
    if a != b:
        print("FAILED")
    else:
        print("PASSED")


# Generated at 2022-06-22 18:31:53.153508
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'variable'
    exclude = ()
    base_variable = BaseVariable(source, exclude)
    base_variable_equal = BaseVariable(source, exclude)
    base_variable_different_source = BaseVariable('variable1', exclude)
    base_variable_different_exclude = BaseVariable(source, ('a',))
    assert base_variable == base_variable_equal
    assert base_variable != base_variable_different_source
    assert base_variable != base_variable_different_exclude
    assert base_variable != BaseVariable


# Generated at 2022-06-22 18:32:03.394378
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import currentframe
    from . import utils

    attrs = Attrs('main')
    keys = Keys('main')
    indices = Indices('main')
    exploding = Exploding('main')
    source = 'main'
    exclude = ()
    item = 'item'
    value = 32
    normalize = True

    def f():
        main = Dummy({'item': value, 'exclude': 3}, [6])
        frame = currentframe()

        assert attrs.items(frame, normalize) == [('main', utils.get_shortish_repr(main, normalize))]


# Generated at 2022-06-22 18:32:10.491430
# Unit test for constructor of class Keys
def test_Keys():
    # test for __init__
    k = Keys("a", "b")
    assert k.source == "a"
    assert k.exclude == ("b",)
    assert isinstance(k, BaseVariable)
    # test for __hash__
    assert hash(k) == hash((type(k), "a", ("b",)))
    # test for __eq__
    assert k == Keys("a", "b")
    assert k != Keys("a", "c")
    assert k != Keys("b", "b")


# Generated at 2022-06-22 18:32:16.646271
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('i')
    i2 = i[4:7]
    assert i2.source == i.source
    assert id(i2.exclude) == id(i.exclude)
    assert i2._slice == slice(4, 7)
    return


# Generated at 2022-06-22 18:32:18.888910
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'foo'
    a = BaseVariable(source)
    # Check member variable source
    assert source == a.source



# Generated at 2022-06-22 18:32:23.226121
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('a')
    assert hash(v._fingerprint) == hash(v)
    assert isinstance(hash(v), int)



# Generated at 2022-06-22 18:32:26.072528
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('') == BaseVariable('')
    assert BaseVariable('') != BaseVariable('a')
    assert BaseVariable('') != BaseVariable('', (),)


# Generated at 2022-06-22 18:32:30.829351
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = lambda: None
    x.y = 1
    x.z = None
    del x.__dict__['y']
    assert set(CommonVariable('x')._safe_keys(x)) == {'z'}
    x.__dict__ = None
    assert CommonVariable('x')._safe_keys(x) == ()


# Generated at 2022-06-22 18:32:34.020130
# Unit test for constructor of class Indices
def test_Indices():
    variable = Indices("x[2:5]")
    assert variable.source == "x[2:5]"

import pytest

# Generated at 2022-06-22 18:32:44.549084
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = "that"
    exclude = ("thing",)
    a = CommonVariable(source, exclude)
    assert_equals(a.source, "that")
    assert_equals(a.exclude, ("thing",))
    assert_equals(a.code, compile("that", '<variable>', 'eval'))
    assert_equals(a.unambiguous_source, "(that)")
    assert_equals(a._fingerprint, (CommonVariable, "that", ("thing",)))
    assert_equals(hash(a), hash((CommonVariable, "that", ("thing",))))
    assert_true(a == a)
    b = CommonVariable(source, exclude)
    assert_equals(a._fingerprint, b._fingerprint)
    assert_true(a == b)

# Generated at 2022-06-22 18:32:46.160513
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs('a')  # No exception should be thrown



# Generated at 2022-06-22 18:32:57.293979
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    test_case1 = (
        BaseVariable('1'),
        BaseVariable('1'),
        True
    )
    test_case2 = (
        BaseVariable('1'),
        BaseVariable('2'),
        False
    )
    test_case3 = (
        BaseVariable('1'),
        BaseVariable('1', ['1']),
        False
    )
    test_case4 = (
        Attrs('1'),
        Attrs('1'),
        True
    )
    test_case5 = (
        Attrs('1'),
        Attrs('2'),
        False
    )
    test_cases = (
        test_case1,
        test_case2,
        test_case3,
        test_case4,
        test_case5
    )

# Generated at 2022-06-22 18:33:01.087570
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import variables
    var = variables.Attrs('a')
    var2 = variables.Attrs('a')
    assert var == var
    assert var == var2
    assert var2 == var


# Generated at 2022-06-22 18:33:03.489433
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable("a")
    assert v.source == 'a'


# Generated at 2022-06-22 18:33:10.358256
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    '''
    Test for method ``__getitem__`` of class ``Indices``
    '''
    test_string = "This is a test string"
    test_sequence = [test_string]
    test_object = Indices(test_sequence)
    test_output = test_object[0:1]
    test_expected = Indices(test_sequence)[0:1]
    print(test_output)
    print(test_expected)
    assert test_output == test_expected
    print("Done")
    return


# Generated at 2022-06-22 18:33:17.485581
# Unit test for constructor of class Keys
def test_Keys():
	d = {}
	d['a'] = 5
	d['b'] = 5
	d['c'] = 5
	d['d'] = 5
	d['e'] = 5
	assert Keys('d').items(d)
	assert Keys('d').items(d,normalize=True)
	
	dict_data = {
		'a' : 5,
		'b' : 5,
		'c' : 5
	}
	
	assert Keys('dict').items(dict_data)
	assert Keys('dict').items(dict_data, normalize=True)
	

# Generated at 2022-06-22 18:33:21.612338
# Unit test for constructor of class Keys
def test_Keys():
    assert(Keys("this_one").source == "this_one")
    assert(Keys("this_one", "that_one").source == "this_one")
    assert(Keys("this_one", "that_one").exclude == ("that_one",))

# Generated at 2022-06-22 18:33:27.264265
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding(u'x')
    assert isinstance(e, BaseVariable)
    assert e.source == u'x'
    assert e.exclude == (u'x',)
    assert e.code == compile(u'x', '<variable>', 'eval')
    assert needs_parentheses(u'x') == True
    assert e.unambiguous_source == u'(x)'
    assert e.items(None) == []

    assert isinstance(Exploding([u'x']), BaseVariable)
    assert Exploding([u'x']).source == u'x'
    assert Exploding([u'x']).exclude == (u'x',)
    assert Exploding([u'x']).code == compile(u'x', '<variable>', 'eval')

# Generated at 2022-06-22 18:33:30.397188
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    x = BaseVariable('x')
    assert BaseVariable('x') == x
    assert x == BaseVariable('x')
    assert x == x

# Generated at 2022-06-22 18:33:41.663951
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    test_case = [
        (Attrs("a"),Attrs("a"),True),
        (Attrs("a",("b","c")),Attrs("a",("b","c")),True),
        (Indices("a"),Indices("a"),True),
        (Indices("a")[1:5],Indices("a")[1:5],True),
        (Indices("a")[1:5],Indices("a")[5:10],False),
        (Keys("a"),Keys("a"),True),
        (Keys("a",("b","c")),Keys("a",("b","c")),True),
        (Exploding("a"),Exploding("a"),True),
        (Exploding("a",("b","c")),Exploding("a",("b","c")),True),
    ]

# Generated at 2022-06-22 18:33:45.900775
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('7')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b[5]')

    # These don't need parentheses, because they're unambiguous:
    assert not needs_parentheses('(a.b).c')
    assert not needs_parentheses('(7).bit_length')
    assert not needs_parentheses('a[5]')
    assert not needs_parentheses('a[5][7]')

# Generated at 2022-06-22 18:33:51.157216
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[:]
    assert b.source == 'a'
    assert b._slice == slice(None)
    c = a[1:2]
    assert c.source == 'a'
    assert c._slice == slice(1,2)

# Generated at 2022-06-22 18:34:01.092139
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('x').__dict__ == {'source': 'x', 'exclude': (), 'code': compile('x', '<variable>', 'eval'), 'unambiguous_source': 'x'}
    assert Exploding('x', 'y').__dict__ == {'source': 'x', 'exclude': ('y',), 'code': compile('x', '<variable>', 'eval'), 'unambiguous_source': 'x'}
    assert Exploding('x', ['y', 'z']).__dict__ == {'source': 'x', 'exclude': ('y', 'z'), 'code': compile('x', '<variable>', 'eval'), 'unambiguous_source': 'x'}

# Generated at 2022-06-22 18:34:03.908940
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding('x').source == 'x'
    assert Exploding('y').source == 'y'
    assert Exploding('z').source == 'z'
# End unit test for constructor of class Exploding

# Generated at 2022-06-22 18:34:06.896438
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class MyIndices(Indices):
        def __init__(self, source):
            Indices.__init__(self, source)
            
    v = MyIndices("d")
    v[:]
    v[1:5]


# Generated at 2022-06-22 18:34:09.356556
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys("request.GET", exclude=("debug",))
    assert 'request.GET' in str(keys)
    assert 'debug' in str(keys)



# Generated at 2022-06-22 18:34:14.299215
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f(a, b='b'):
        x = {'k': {'l': 'v'}}
        y = [1]
        z = 'c'
        return locals()
    for key, value in BaseVariable('x').items(f()):
        print(key, value)


# Generated at 2022-06-22 18:34:23.893476
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import unittest
    from .test_utils import Py23DocTestSuite
    class BaseVariableTest(unittest.TestCase):
        def test_need_parenthesis(self):
            for source in ['x=1', 'def f(){}', '"123"']:
                self.assertTrue(needs_parentheses(source))
            for source in ['x', 'f', '123', 'None']:
                self.assertFalse(needs_parentheses(source))

    tests = Py23DocTestSuite(test_BaseVariable.__doc__)
    tests.addTests(unittest.makeSuite(BaseVariableTest))
    return tests


# Generated at 2022-06-22 18:34:26.553637
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) != hash(BaseVariable('b'))
    assert hash(BaseVariable('a')) != hash(BaseVariable('a', exclude='a'))
    assert hash(BaseVariable('a')) == hash(BaseVariable('a', exclude=''))


# Generated at 2022-06-22 18:34:35.561332
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    attrs_a = Attrs('a')
    attrs_a1 = Attrs('a')
    attrs_b = Attrs('b')
    attrs_a_b = Attrs('a.b')
    attrs_a_b_excluded = Attrs('a.b', exclude='b')

    assert(attrs_a == attrs_a1)
    assert(attrs_a != attrs_b)
    assert(attrs_a != attrs_a_b)
    assert(attrs_a_b != attrs_a_b_excluded)

# Generated at 2022-06-22 18:34:37.243221
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('lol')
    v[10:20:2]._slice == slice(10, 20, 2)

# Generated at 2022-06-22 18:34:41.176637
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("example")
    assert indices[:] is indices
    assert indices[2:4] is not indices
    assert indices[2:4]._slice == slice(2,4)


# Generated at 2022-06-22 18:34:47.278131
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import utils
    li = [5, 6, 7, 8, 9]
    result = Indices('li')[1:4]
    assert result._slice == slice(1, 4)
    expected = [('li[1]', utils.get_shortish_repr(6)), ('li[2]', utils.get_shortish_repr(7)), ('li[3]', utils.get_shortish_repr(8))]
    assert result.items(1)[1:] == expected


# Generated at 2022-06-22 18:34:57.373360
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') == False
    assert needs_parentheses('a.x') == False
    assert needs_parentheses('a.x()') == False
    assert needs_parentheses('a.x(y)') == False
    assert needs_parentheses('a[1]') == False
    assert needs_parentheses('a(1)') == False
    assert needs_parentheses('a(1 + 2)') == False
    assert needs_parentheses('a + b') == True
    assert needs_parentheses('a[1:2]') == True
    assert needs_parentheses('a(1, 2)') == True
    assert needs_parentheses('a(1 + 2, 3)') == True
    assert needs_parentheses('a(1, 2 + 3)') == True

# Generated at 2022-06-22 18:35:01.257931
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variables = Indices("attributes")
    assert variables[:] == Indices("attributes")
    assert variables[1:2] == Indices("attributes")[1:2]

test_Indices___getitem__()

# Generated at 2022-06-22 18:35:08.901908
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import debugger
    import os
    import tempfile
    import shutil

    for cls in (BaseVariable, Attrs, Keys, Indices, Exploding):
        with tempfile.TemporaryDirectory() as tmpdirname:
            tmpfilenm = os.path.join(tmpdirname, 'dbg.txt')
            dbg = debugger.Debugger(var=[cls('.x.v')])

# Generated at 2022-06-22 18:35:18.373293
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import re
    matcher = re.compile(r'<\w+\.')
    frame = utils.get_current_frame()
    v = BaseVariable('v', exclude=('x', 'z'))
    items = v.items(frame)
    item = items[0]
    key = item[0]
    value = item[1]
    results = []
    for i in range(len(items)):
        item = items[i]
        key = item[0]
        value = item[1]
        if not matcher.search(value):
            results.append((key, value))
    return results

# Generated at 2022-06-22 18:35:22.806244
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('name', exclude=('.__dict__', ))
    assert k.source == 'name'
    assert k.exclude == ('.__dict__', )
    assert k.code
    assert k.unambiguous_source == 'name'



# Generated at 2022-06-22 18:35:27.399693
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('"hello"')
    assert bv.source == '"hello"'
    assert bv.exclude == ()
    assert bv.code is not None
    assert bv.unambiguous_source == '"hello"'
    assert isinstance(eval(bv.code), str)


# Generated at 2022-06-22 18:35:33.020833
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        def __init__(self):
            self.a = 'abc'
            self.b = 'bcd'
    a = A()
    av = Attrs('a')
    assert av.items(a) == [('a', "'abc'")]
    assert av.items(a) == [('a', 'A object'), ('a.a', "'abc'"), ('a.b', "'bcd'")]
    assert Attrs('a', 'a').items(a) == [('a', 'A object'), ('a.b', "'bcd'")]


# Generated at 2022-06-22 18:35:40.798501
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pdbpp import add_hidden_attributes
    import inspect
    import six
    import sys
    import types
    import pytest

    class _Subclass(BaseVariable):
        _items = utils.NotImplemented

    class _C(object):
        pass

    _c = _C()
    frame = inspect.currentframe()
    _c.x = frame
    _c.y = frame
    _c.z = frame
    _c.w = frame

    _c2 = _C()
    setattr(_c, 'b', _c2)
    _c2.a = _c2
    add_hidden_attributes(_c2, {'_first_hidden': 1, '_last_hidden': 1})
    _c2.last_hidden = 1

# Generated at 2022-06-22 18:35:49.472476
# Unit test for constructor of class Exploding
def test_Exploding():
    # Test for Mapping
    test = Exploding('test')
    assert isinstance(test, Exploding)
    items = {'1': 1, '2': 2}
    assert test._items(items) == [('test', '{1: 1, 2: 2}'), ('test[1]', '1'), ('test[2]', '2')]

    # Test for Sequence
    test = Exploding('test')
    assert isinstance(test, Exploding)
    items = ['1', '2']
    assert test._items(items) == [('test', "['1', '2']"), ('test[0]', "'1'"), ('test[1]', "'2'")]

    # Test for Slice
    test = Exploding('test')[2:4]
    assert isinstance(test, Indices)
    items

# Generated at 2022-06-22 18:35:52.934362
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('a')
    variable = BaseVariable('a', 'b')
    variable = BaseVariable('a', ('b', 'c'))

