

# Generated at 2022-06-22 18:25:55.636363
# Unit test for constructor of class Keys
def test_Keys():
    class Dict:
        def keys(self):
            return ['abc', 'def', 'ghi']
    d = Dict()
    v = Keys('a', exclude=['abc'])
    assert v.items(d) == [('a', 'Keys'), ('a[def]', 'None'), ('a[ghi]', 'None')]


# Generated at 2022-06-22 18:25:59.425892
# Unit test for constructor of class Exploding
def test_Exploding():
    variable = Exploding('x')
    assert variable.source == 'x'
    assert variable.exclude == ()
    variable_with_exclude = Exploding('x', exclude=('y', 'z'))
    assert variable_with_exclude.source == 'x'
    assert variable_with_exclude.exclude == ('y', 'z')

# Generated at 2022-06-22 18:26:07.101716
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')
    var_copy = var[99:]
    assert isinstance(var_copy, Indices), 'Метод __getitem__ класса Indices должен возвращать объект класса Indices'
    assert var_copy._slice == slice(99, None), "Метод __getitem__ класса Indices возвращает некорректный результат"

# Generated at 2022-06-22 18:26:13.599376
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Exploding.__init__(Exploding, 'a', exclude = ())
    assert (Exploding.__init__(Exploding, 'a', exclude = None))
    assert (Exploding.__init__(Exploding, 'a.b', exclude = ()))
    assert (Exploding.__init__(Exploding, 'a', exclude = ('yxx',)))
    assert (Exploding.__init__(Exploding, 'a', exclude = 'yxx'))



# Generated at 2022-06-22 18:26:16.888735
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('source', 'exclude')
    var2 = BaseVariable('source', 'exclude')
    var3 = BaseVariable('source', 'exclude')
    print(var1 == var2)



# Generated at 2022-06-22 18:26:28.958967
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x[2]') == False
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('x[2][3]') == False
    assert needs_parentheses('x[2].z') == False
    assert needs_parentheses('x.y[3]') == False
    
    assert needs_parentheses('x*y') == True
    assert needs_parentheses('x*y.z') == True
    assert needs_parentheses('x*y.z + 1') == True
    assert needs_parentheses('x + y.z*3') == True
    assert needs_parentheses('x*y[2] + x[4].y') == True

# Generated at 2022-06-22 18:26:32.812212
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('func.a')
    assert type(a) == Attrs
    assert a.source == 'func.a'
    assert a.exclude == ()
    assert a.code == compile('func.a', '<variable>', 'eval')
    assert a.unambiguous_source == 'func.a'


# Generated at 2022-06-22 18:26:37.661127
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var = BaseVariable('foo')
    assert var.source == 'foo'
    assert var.exclude == ()
    assert var.code == compile('foo', '<variable>', 'eval')
    assert var.unambiguous_source == 'foo'



# Generated at 2022-06-22 18:26:47.609488
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    main_value = [object(), object()]
    main_value[0].attr = main_value[1]
    main_value[1]._private = object()

    class CommonVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            raise NotImplementedError
    
    common_variable = CommonVariable("main_value", exclude=["_private"])
    assert common_variable._items(main_value) == [
        ('main_value', '<list of 2 elements>'),
        ('main_value[0].attr', '<object object at 0x7f6d54776348>'),
        ('main_value[1]', '<object object at 0x7f6d54776348>')
    ]

# Generated at 2022-06-22 18:26:55.799438
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('1')
    x2 = BaseVariable('1')
    x3 = BaseVariable('2')
    x4 = BaseVariable('1', exclude='1')
    x5 = BaseVariable('1', ('1'))
    x6 = BaseVariable('1', ('2'))

    assert(x == x2)
    assert(not (x == x3))
    assert(x == x4)
    assert(x == x5)
    assert(not (x == x6))
    # assert(isinstance(x, BaseVariable))

test_BaseVariable___eq__()

# Generated at 2022-06-22 18:27:00.779186
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('a')
    assert x == x
    assert x == BaseVariable('a')
    assert x != BaseVariable('b')

    class X(BaseVariable):
        pass
    assert x != X('a')
    assert x != BaseVariable('a', 'b')

    with pytest.raises(TypeError):
        x == 'a'



# Generated at 2022-06-22 18:27:12.100517
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import dis
    import math
    def foo(a, b, c):
        return a + b*math.cos(c)
    dis.dis(foo)
    # Method items of BaseVariable
    class AttrsCase(object):
        attrs1 = 'attrs1'
        attrs2 = 'attrs2'
        def __init__(self):
            self.attrs3 = 'attrs3'
    class KeysCase:
        def __init__(self):
            self.keys = [1, 2, 3]
    class IndicesCase:
        def __init__(self):
            self.indices = [1, 2, 3]
    class ExplodingCase():
        def __init__(self):
            self.exploding = [1, 2, 3]

# Generated at 2022-06-22 18:27:14.858163
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x.y')
    assert not needs_parentheses('x[0].y')
    assert not needs_parentheses('(x[0]).y')

# Generated at 2022-06-22 18:27:17.191696
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert BaseVariable('x').source == 'x'
    assert BaseVariable('x', exclude='attr').exclude == ('attr',)



# Generated at 2022-06-22 18:27:23.585121
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a.b)')
    assert not needs_parentheses('((a))')
    assert not needs_parentheses('((a)).b')
    assert not needs_parentheses('(a).b.c')

# Generated at 2022-06-22 18:27:31.209289
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create the frame
    def f1(x): return x + 1;
    f1_code = f1.__code__
    f1_globals = f1.__globals__
    f1_globals['x'] = 1
    f1_locals = {'x': 2}
    f1_frame = frame_factory.Frame(f1_code, f1_globals, f1_locals, f1_frame)

    # Create the variable
    variable = BaseVariable(source="x")
    assert variable.items(f1_frame) == ()
    variable = BaseVariable(source="x", exclude=['x'])
    assert variable.items(f1_frame) == ()
    variable = BaseVariable(source="f1", exclude=['f1'])
    assert variable.items

# Generated at 2022-06-22 18:27:36.064915
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('1') == BaseVariable('1')
    assert BaseVariable('1') != BaseVariable('2')
    assert BaseVariable('1') != 1
    assert BaseVariable('1') != BaseVariable('1', exclude='a')
    assert BaseVariable('1') != BaseVariable('1', exclude=['a'])
    assert BaseVariable('1', exclude='a') != BaseVariable('1', exclude=['a'])


# Generated at 2022-06-22 18:27:40.604321
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test: case 1
    test_obj = Indices('a')
    test_input = slice(2, 3)
    expected_output = slice(2, 3)
    test_output = test_obj.__getitem__(test_input)
    assert test_output._slice == expected_output


# Generated at 2022-06-22 18:27:46.627834
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = "some_variable"
    exclude = "some_exclude"
    bv1 = BaseVariable(source, exclude=exclude)
    bv2 = BaseVariable(source, exclude=exclude)
    bv3 = BaseVariable(source)
    bv4 = BaseVariable(source, exclude=exclude)
    assert bv1 == bv2
    assert bv1 == bv4
    assert bv1 != bv3


# Generated at 2022-06-22 18:27:48.362976
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs("dict[key]").items(2)

# Generated at 2022-06-22 18:27:51.951878
# Unit test for constructor of class Keys
def test_Keys():
    k1 = Keys('foo')
    k2 = Keys('foo')
    assert k1 == k2


#############
# UNIT TESTS
#############
if __name__ == '__main__':
    import unittest

    class Test(unittest.TestCase):
        def test_keys(self):
            k1 = Keys('foo')
            k2 = Keys('foo')
            assert k1 == k2

    unittest.main()

# Generated at 2022-06-22 18:27:58.941009
# Unit test for constructor of class Exploding
def test_Exploding():
    import tempfile
    import shutil
    import os
    import sys
    import sys
    import pytest
    import pathlib
    import importlib

    # Create temporary directory
    tmp_dir_path = tempfile.mkdtemp()
    tmp_dir_path = pathlib.Path(tmp_dir_path)

    # Create temporary file in the directory
    tmp_file_path = tmp_dir_path / 'tmp_file.txt'
    tmp_file_path.touch()


# Generated at 2022-06-22 18:28:02.899687
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    with mock.patch('copy.deepcopy') as mock_deepcopy:
        mock_deepcopy.return_value = 'foo'
        x = BaseVariable('spam', 'egg')
        assert x.__hash__() == -2400960045297139467
test_BaseVariable___hash__()


# Generated at 2022-06-22 18:28:05.037001
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))
    assert hash(BaseVariable('a')) == hash(BaseVariable('a'))

# Generated at 2022-06-22 18:28:11.059945
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    lines = """
    x = 1
    def test():
        var1 = Attrs('x')
        var2 = Attrs('x')
        var3 = Attrs('x', exclude='x')
        var4 = Keys('y')
        print(var1 == var2)
        print(var1 == var3)
        print(var1 == var4)
    """
    utils.run_in_temp_dir(lines, locals())
# Expected:
# True
# False
# False



# Generated at 2022-06-22 18:28:22.073087
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    d = 1
    d_str = utils.get_shortish_repr(d)
    c = CommonVariable('d')
    assert c.items(locals()) == [('d', d_str)]

    c2 = CommonVariable('d', exclude='c')
    assert c2.items(locals()) == [('d', d_str)]

    b = 2
    b_str = utils.get_shortish_repr(b)
    c3 = CommonVariable('d', 'c')
    assert c3.items(locals()) == [('d', d_str), ('d.b', b_str)]

    e = utils.Object()
    e.b = b
    e.a = d
    e.d = e

# Generated at 2022-06-22 18:28:31.478331
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # -------------
    # -without-exclude-
    # -------------
    # Type: Mapping
    x = {'a': 1, 'b': 2}  # class: Mapping
    # source, source_value, source_exclude, source_exclude_value
    result = [('x', '{...}'),
              ('x[a]', '1'),
              ('x[b]', '2')]
    def compare(value, tup):
        return (value(tup[0]), value(tup[1]))
    for v in result:
        assert compare(BaseVariable, v) == compare(BaseVariable.items, v)
    # Type: Sequence

# Generated at 2022-06-22 18:28:36.943232
# Unit test for constructor of class Attrs
def test_Attrs():

    # Constructor with no parameter
    a = Attrs()
    assert isinstance(a, Attrs)

    # Constructor with parameters (py3)
    try:
        a = Attrs("self", exclude="exclude")
        assert isinstance(a, Attrs)
    except TypeError:
        pass
    # Constructor with parameters (py2)
    try:
        a = Attrs("self", exclude="exclude")
        assert isinstance(a, Attrs)
    except TypeError:
        pass


# Generated at 2022-06-22 18:28:41.139345
# Unit test for constructor of class Attrs
def test_Attrs():
    attr = Attrs('a')
    assert attr.code == compile('a', '<variable>', 'eval')
    assert attr.source == 'a'
    assert attr.exclude == ()
    assert attr.unambiguous_source == 'a'


# Generated at 2022-06-22 18:28:42.804706
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('source')) == hash(BaseVariable('source'))


# Generated at 2022-06-22 18:28:54.968180
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x + y')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('(x + y)')
    assert not needs_parentheses('(x + y).z')
    assert needs_parentheses('x()')
    assert needs_parentheses('x.y()')
    assert not needs_parentheses('(x)()')
    assert not needs_parentheses('(x).y()')
    assert not needs_parentheses('(x + y)()')
    assert not needs_parentheses('(x + y).z()')
    assert needs_parentheses('x.y[z]')
    assert not needs_parent

# Generated at 2022-06-22 18:28:58.104038
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    print('constructor of class BaseVariable')
    variable1 = BaseVariable('test', 'exclude')
    variable2 = BaseVariable('test', ['exclude'])
    variable3 = BaseVariable('test', ['exclude1','exclude2'])
    print('Finish constructor of class BaseVariable')


# Generated at 2022-06-22 18:29:03.895344
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    a = BaseVariable("a")
    b = BaseVariable("a")
    c = BaseVariable("a", exclude="a")
    d = BaseVariable("a", exclude="b")

    assert hash(a) == hash(b)
    assert hash(c) != hash(d)
    assert hash(a) != hash(c)
    assert hash(b) != hash(d)


# Generated at 2022-06-22 18:29:08.113414
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('', '')
    new_indices = indices[0: 5]
    assert not (indices is new_indices)
    assert new_indices._slice == slice(0,5)
    assert (indices._slice == slice(None))
    assert indices.exclude == new_indices.exclude

# Generated at 2022-06-22 18:29:13.009479
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    isinstance(CommonVariable(''), CommonVariable)
    isinstance(CommonVariable('', ''), CommonVariable)
    isinstance(CommonVariable('', 'a', 'b'), CommonVariable)
    with pytest.raises(TypeError):
        CommonVariable()
    with pytest.raises(TypeError):
        CommonVariable(1, 2, 3)


# Generated at 2022-06-22 18:29:23.528752
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    variables = [Keys('request.POST'), Keys('request.GET'), Keys('request.COOKIES'), Attrs('request')]
    dev_data = {
        'request.POST': {'a': '1'},
        'request.GET': {'a': '2'},
        'request.COOKIES': {'a': '3'},
        'request': object
    }
    """
    variables = [Exploding('request')]
    dev_data = {
        'request': {}
    }
    vars = {}
    for var in variables:
        vars.update(dict(var.items(dev_data)))
    print (vars)



if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-22 18:29:28.892587
# Unit test for constructor of class Keys
def test_Keys():
    x = {'a' : 1, 'b' : 2}
    x['c'] = 3
    k = Keys('x')

# Generated at 2022-06-22 18:29:30.014027
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass


# Generated at 2022-06-22 18:29:32.487290
# Unit test for constructor of class Exploding
def test_Exploding():
    Evar = Exploding('fun_container')
    assert Evar.source == 'fun_container'
    assert Evar.exclude == ()


# Generated at 2022-06-22 18:29:41.635528
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('a', ())
    obj_slice = obj[:]

    assert obj_slice._slice == slice(None)
    assert obj_slice._fingerprint == (Indices, 'a', ())
    obj_slice = obj[0:]
    assert obj_slice._slice == slice(0)
    obj_slice = obj[:0]
    assert obj_slice._slice == slice(None, 0)
    obj_slice = obj[-1:]
    assert obj_slice._slice == slice(-1)
    obj_slice = obj[:-1]
    assert obj_slice._slice == slice(None, -1)
    obj_slice = obj[0:1]
    assert obj_slice._slice == slice(0, 1)
    obj_slice = obj[-1:-1]
    assert obj_slice._slice == slice

# Generated at 2022-06-22 18:29:43.418738
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = 'a'
    exclude = 'exclude'
    CommonVariable(source, exclude)



# Generated at 2022-06-22 18:29:47.711338
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    BaseVariable('1') == BaseVariable('1')
    hash(BaseVariable('1')) == hash(BaseVariable('1'))
    BaseVariable('1') != BaseVariable('2')
    hash(BaseVariable('1')) != hash(BaseVariable('2'))

# Generated at 2022-06-22 18:29:50.471142
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
  var = CommonVariable('a.b', ['b'])
  assert var.unambiguous_source == 'a.b'
  assert var.code.co_code == compile('a.b', '<variable>', 'eval').co_code
  assert var.exclude == ('b',)



# Generated at 2022-06-22 18:29:58.752636
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
  def test_BaseVariable_items_sub(source, frame, normalize, expected):
    variable = BaseVariable(source, exclude=('text',))
    result = variable.items(frame, normalize)
    assert result == expected 

  frame = inspect.currentframe()
  test_BaseVariable_items_sub(
    source='a', 
    frame=frame, 
    normalize=False, 
    expected=[('a', '5')]
  )

# Generated at 2022-06-22 18:30:01.624461
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('a')
    assert keys.source == 'a'
    assert keys.exclude == ()


# Generated at 2022-06-22 18:30:05.078817
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  from .variables import Indices
  s = "Indices[{}:]"
  for num in [1, 2, 3, 4, 5]:
    result = eval(s.format(num))
    assert(result._slice.start == num)
    assert(result._slice.stop == None)
    assert(result._slice.step == None)

# Generated at 2022-06-22 18:30:09.905475
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('x', exclude=['_a'])
    assert x.source == 'x'
    assert x.exclude == ('_a',)
    assert x.code == compile('x', '<variable>', 'eval')
    assert x.unambiguous_source == 'x'


# Generated at 2022-06-22 18:30:21.403086
# Unit test for constructor of class Indices
def test_Indices():
    userInput  = "len(a[0])"
    variables = ['a']
    debug_variables = []
    exclude = ''
    indent = ' ' * 4
    source =  '%s%s' % (indent, userInput)
    result = []
    v = Indices(source)
    v._slice = slice(0)
    source = source.rstrip()
    if source in variables:
        result.append(source)
        continue
    
    if source in debug_variables:
        result.append('%s = %s' % (source, utils.get_shortish_repr(source)))
        continue
    
    if source in exclude:
        continue
    
    try:
        obj = eval(source)
    except:
        continue
    

# Generated at 2022-06-22 18:30:22.357176
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs('x')


# Generated at 2022-06-22 18:30:24.483994
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_obj = Indices('blah')
    result = test_obj[:]
    expected = Indices(source='blah', exclude=())
    assert result == expected



# Generated at 2022-06-22 18:30:36.192544
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pdb
    from . import frames, formatters
    from .formatters import BaseFormatter

    class TestFormatter(BaseFormatter):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def format_background(self, frame, tpl):
            return tpl.format(name=frame.f_code.co_name)
        def format_variables(self, frame):
            return ''

    def empty_f(): return None

    frame = utils.create_frame(empty_f)
    formatter = TestFormatter()
    frame_obj = frame.create_frame_object()
    frame_obj.list_lines = ()
    frame_obj.format_lines = ()
    frame_obj.event = pdb.Pdb.get_line
    frame_

# Generated at 2022-06-22 18:30:45.964773
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('v1') == BaseVariable('v1')
    assert BaseVariable('v1') == BaseVariable('v1', exclude=('d1'))
    assert BaseVariable('v1', exclude=('d1')) == BaseVariable('v1', exclude=('d1'))
    assert BaseVariable('v1', exclude=('d1')) == BaseVariable('v1', exclude=('d2'))
    assert BaseVariable('v1', exclude=('d1')) != BaseVariable('v2', exclude=('d1'))
    assert BaseVariable('v1', exclude=('d1', 'd2')) == BaseVariable('v1', exclude=('d2', 'd1'))

# Generated at 2022-06-22 18:30:52.750921
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('(x) + y') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x.y.z') is False
    assert needs_parentheses('x + y') is True
    assert needs_parentheses('x - y') is True
    assert needs_parentheses('x * y') is True
    assert needs_parentheses('x / y') is True

# Generated at 2022-06-22 18:30:55.513520
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:] == Indices('x')
    assert Indices('x')[1:] == Indices('x')[1:]


# Generated at 2022-06-22 18:31:03.079343
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # test for _keys
    assert 'abc' in list(Attrs('a', exclude='abc')._keys(str))
    assert 0 in list(Indices('a')._keys(str))
    assert 'a' in list(Keys('a')._keys({"a": 1}))

    # test for _safe_keys
    assert [] == list(CommonVariable('a')._safe_keys(object))

    # test for _get_value
    assert 1 == Attrs('a')._get_value({"a": 1}, "a")
    assert 1 == Indices('a')._get_value([1, 2], 0)
    assert 1 == Keys('a')._get_value({"a": 1}, "a")

    # test for _format_key
    assert '.' + 'b' == Attrs('a')._format_key

# Generated at 2022-06-22 18:31:09.214363
# Unit test for constructor of class Keys
def test_Keys():
    main_value = {"name": "Django", "age": "8", "address": "Shanghai"}
    print(Keys("main_value")._items(main_value))
    print(Keys("main_value", exclude=("name", "age"))._items(main_value))


if __name__ == '__main__':
    test_Keys()

# Generated at 2022-06-22 18:31:17.013012
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    with pytest.raises(NotImplementedError):
        CommonVariable('x')._items('x')
    with pytest.raises(NotImplementedError):
        CommonVariable('x')._keys('x')
    with pytest.raises(NotImplementedError):
        CommonVariable('x')._format_key('x')
    with pytest.raises(NotImplementedError):
        CommonVariable('x')._get_value('x', 'x')


# Generated at 2022-06-22 18:31:28.429898
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # 1
    # create a function, called test_BaseVariable.
    # def __init__(self, source, exclude=()):
    # self.source = source
    # self.exclude = utils.ensure_tuple(exclude)
    # self.code = compile(source, '<variable>', 'eval')
    # if needs_parentheses(source):
    #     self.unambiguous_source = '({})'.format(source)
    # else:
    #     self.unambiguous_source = source
    # use the function to test the constructor of class BaseVariable
    #  test1: source not in keys, exclude not in keys
    code = BaseVariable('d', 'd').code
    source = BaseVariable('d', 'd').source
    exclude = BaseVariable('d', 'd').exclude


# Generated at 2022-06-22 18:31:32.903063
# Unit test for constructor of class Attrs
def test_Attrs():
    frame = frame = inspect.currentframe()
    attr = Attrs("frame",("f_globals",))
    print(attr._fingerprint)
    print("\n".join("{}: {}".format(*kv) for kv in attr.items(frame)))



# Generated at 2022-06-22 18:31:39.785742
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pprint import pprint 

    frame = {'event_data': {'result': {'data': 123}}}
    frame['event_data']['result']['event_data'] = frame['event_data']

    base_var = BaseVariable('event_data')
    pprint(base_var.items(frame))

    base_var = BaseVariable('event_data.result')
    pprint(base_var.items(frame))

    base_var = BaseVariable('event_data[\'result\']')
    pprint(base_var.items(frame))


# Generated at 2022-06-22 18:31:48.779836
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # We will check if given source is correct or incorrect
    assert BaseVariable("test_source")
    # We will check if given source is correct or incorrect
    assert not BaseVariable("test_source").source
    # We will check if given source is correct or incorrect
    assert not BaseVariable("test_source").exclude
    # We will check if given source is correct or incorrect
    assert BaseVariable("test_source")._items()
    assert BaseVariable("test_source").items()
    assert isinstance(BaseVariable("test_source"), BaseVariable)
    assert BaseVariable("test_source").__init__("test_source")


# Generated at 2022-06-22 18:31:51.181423
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    common_variable = CommonVariable('a', ('b', 'c'))
    assert common_variable.source == 'a'
    assert common_variable.code == compile('a', '<variable>', 'eval')
    assert common_variable.exclude == ('b', 'c')
    assert common_variable.unambiguous_source == 'a'



# Generated at 2022-06-22 18:31:59.703205
# Unit test for constructor of class Exploding
def test_Exploding():
    mapping = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
    }
    mapping['f'] = mapping
    mapping['g'] = mapping['a']
    sequence = [
        'a',
        'b',
        'c',
        'd',
        'e',
    ]
    sequence.append(sequence)
    sequence.append(sequence[0])
    obj = Exploding(source='mapping')
    obj._items(mapping)
    obj_s = Exploding(source='sequence')
    obj_s._items(sequence)

# Generated at 2022-06-22 18:32:03.348140
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('variable')
    i[1:3]
    assert i._slice == slice(1, 3)

# Generated at 2022-06-22 18:32:07.860767
# Unit test for constructor of class Keys
def test_Keys():
    dic = {'key1':1,'key2':2}
    K = Keys('dic')
    #print(K._keys(dic))
    #print(K.items(dic))
    #print(K._fingerprint)
    #print(K.__hash__())

# Generated at 2022-06-22 18:32:13.962451
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    local = {"dic_item": "a"}
    global_ = {"global_item": "b"}
    import sys
    #sys.setrecursionlimit(1000)

    variable = BaseVariable("dic_item")

    result = variable.items(None, locals(), globals())
    assert result == "a"

    variable = BaseVariable("global_item")

    result = variable.items(None, locals(), globals())
    assert result == ("b",)

    variable = BaseVariable("c")

    result = variable.items(None, locals(), globals())
    assert result == ()

    variable = BaseVariable("c", exclude=["c"])

    result = variable.items(None, locals(), globals())
    assert result == ()

    variable = BaseVariable("a", exclude=["a"])

    result = variable.items

# Generated at 2022-06-22 18:32:23.235965
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for class CommonVariable
    print('\n')
    # Test for class Attrs
    print('------------Test for class Attrs-----------------')
    d = {'a':1, 'b':2}
    e = Attrs('d')
    print(e.items(d))
    print('\n')
    # Test for class Keys
    print('------------Test for class Keys-----------------')
    d = {'a':1, 'b':2}
    e = Keys('d')
    print(e.items(d))
    print('\n')
    # Test for class Indices
    print('------------Test for class Indices-----------------')
    d = {'a':1, 'b':2}
    e = Attrs('d')
    print(e.items(d))
    print('\n')
   

# Generated at 2022-06-22 18:32:28.315387
# Unit test for constructor of class Attrs
def test_Attrs():
    # use a dict to ensure no side-effect
    t = Attrs(dict(source="I am source ", exclude="exclude"))
    frame = dict(f_locals=dict(attr1=1,attr2=2,attr3=3),f_globals=dict())
    items = t.items(frame)
    for item in items:
        print(item)



# Generated at 2022-06-22 18:32:30.349373
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices(1)


if __name__ == '__main__':
    test_Indices()

# Generated at 2022-06-22 18:32:38.506701
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a[0]')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('a.x')
    assert not needs_parentheses('a().x')
    assert needs_parentheses('a()[0]')
    assert not needs_parentheses('a()')
    assert not needs_parentheses('(a()).x')
    assert needs_parentheses('a.x[0]')
    assert not needs_parentheses('(a.x)[0]')

# Generated at 2022-06-22 18:32:47.683680
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    """
    This unit test function is added to test the method __getitem__ of class Indices.
    This method needs to be tested because of the bug introduced while adding the function
    __setitem__ in the super class BaseVariable
    """

    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence

    from .pycompat import ABC
    import abc
    from .utils import ensure_tuple
    from . import utils
    from . import pycompat

    from .utils import ensure_tuple
    from .utils import get_shortish_repr
    from .utils import is_str
    from .utils import ensure_str
    from .utils import text_to_native
    from .utils import native_to_text
    from .utils import escape_string

# Generated at 2022-06-22 18:32:52.003205
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # if exclude is not iterable, it should be made iterable
    assert CommonVariable('test', '1').exclude == ('1',)

    # exclude should be a tuple
    assert type(CommonVariable('test', '1').exclude) == tuple

    # hash and == should be used in a set
    assert hash(CommonVariable('t', 'e')) == hash(CommonVariable('t', 'e'))
    assert CommonVariable('t', 'e') == CommonVariable('t', 'e')
    assert CommonVariable('t', 'e') in set([CommonVariable('t', 'e')])

# Generated at 2022-06-22 18:32:57.381545
# Unit test for constructor of class Indices
def test_Indices():
    a1 = Indices('i')
    a2 = Indices('i', exclude=['x'])
    a3 = Indices('i', exclude=['x', 'y'])
    assert a1._slice == slice(None)
    assert a1._exclude == ()
    assert a1._source == 'i'
    assert a2._exclude == ('x',)
    assert a3._exclude == ('x', 'y')


# Generated at 2022-06-22 18:33:07.648676
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('foo')
    assert indices.source == 'foo'
    assert indices.exclude == ()
    assert indices.code.co_code == compile('foo', '<variable>', 'eval').co_code
    assert indices.unambiguous_source == 'foo'
    assert indices._slice == slice(None)
    assert indices.items(None) == []

    indices[:]
    assert indices._slice == slice(None)
    assert indices.items(None) == []

    indices[1:3]
    assert indices._slice == slice(1, 3)
    assert indices.items(None) == []


# Generated at 2022-06-22 18:33:11.276085
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('z', 'ab')
    assert isinstance(i, Indices)
    assert i.source == 'z'
    assert i.exclude == 'ab'

# Generated at 2022-06-22 18:33:15.024873
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    list = list()
    a = CommonVariable(list, ())
    assert(a.source == list)
    assert(a.exclude == ())
    assert(a.code is not None)
    assert(a.unambiguous_source == "list")


# Generated at 2022-06-22 18:33:24.348964
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Create a variable
    var = Indices(source="source")
    var_copy = var[:]
    var_copy2 = var[:]

    # Test the identity of the variable and its copy
    assert(var is not var_copy)
    assert(var is var_copy2)
    assert(var_copy is var_copy2)

    # Test the equality of the variable and its copy
    assert(var == var_copy)
    assert(var == var_copy2)
    assert(var_copy == var_copy2)

    # Test the hash value of the variable and its copy
    assert(hash(var) == hash(var_copy))
    assert(hash(var) == hash(var_copy2))
    assert(hash(var_copy) == hash(var_copy2))

# Generated at 2022-06-22 18:33:25.888978
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    x = CommonVariable('x')

# Generated at 2022-06-22 18:33:29.375534
# Unit test for constructor of class Keys
def test_Keys():
    a = dict({"x": 1})
    var = Keys('a', exclude=())
    assert var.source == 'a'
    para = var.items(frame=a)
    var.source = 'b'
    assert var.source == 'b'
    var.exclude = 'x'
    assert var.exclude == 'x'

    def test_attrs(var):
        var.source = 'a'
        var.exclude = ()

    test_attrs(var)
    assert var.source == 'a'
    assert var.exclude == ()

# Generated at 2022-06-22 18:33:35.231552
# Unit test for constructor of class Exploding
def test_Exploding():
    from . import main
    from . import exceptions
    from . import utils
    from . import frame

    v = Exploding('value')

    with pytest.raises(NotImplementedError):
        v._items('str')

    assert v._items(main) == v._items({'x': 1}) == v._items([1, 2, 3])

# Generated at 2022-06-22 18:33:44.785839
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import inspect
    import builtins
    code_obj = compile('1', '<string>', 'single')

    x = BaseVariable('abc',None)
    x1 = BaseVariable('abc','exclude_param')
    assert inspect.ismethod(x.items)
    assert inspect.ismethod(x.__hash__)
    assert inspect.ismethod(x.__eq__)
    assert not inspect.ismethod(x.__init__)
    assert x.source == 'abc'
    assert x.source ==  'abc'
    assert x.exclude ==  ()
    assert x.code == code_obj
    assert x.source == 'abc'
    assert x.code == code_obj
    assert x.unambiguous_source == 'abc'

# Generated at 2022-06-22 18:33:49.628859
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.a')
    assert not needs_parentheses('(a)')
    assert needs_parentheses('a or b')
    assert needs_parentheses('a or b.c')
    assert not needs_parentheses('(a or b)')
    assert not needs_parentheses('(a or b).c')
    assert needs_parentheses('a.b()')
    assert needs_parentheses('a.b().c')
    assert needs_parentheses('a.b()[1]')
    assert needs_parentheses('a.b()[1].c')
    assert needs_parentheses('a.b(c)[1]')
    assert needs_parentheses('a.b(c)[1].d')

# Generated at 2022-06-22 18:33:52.382771
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable('arg')
    if v.source !='arg':
        raise RuntimeError('Incorrect source for variable')


# Generated at 2022-06-22 18:34:00.623964
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    evt = threading._Event()
    evt.set()
    var = BaseVariable('globals')
    assert var.items(frame=0) == [('globals', '{}')]
    assert var.items(frame=0, normalize=True) == [('globals', '<dict>')]
    assert var.items(frame=evt) == [('globals', '{}')]
    assert var.items(frame=evt, normalize=True) == [('globals', '<dict>')]



# Generated at 2022-06-22 18:34:09.684643
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    def test(source, exclude=()):
        return BaseVariable(source, exclude).__hash__()

    # make sure that hash value depends on source and exclude
    assert test('x') != test('y')
    assert test('x', 'y') != test('x', 'z')
    assert test('y', 'x') != test('z', 'x')

    # make sure that hash value does not depend on the way source is written
    assert test('y', 'x') == test('y   ', 'x')
    assert test('y', 'x') == test('y', '    x')
    assert test('y', 'x') == test(' y   ', 'x')
    assert test('y', 'x') == test(' y', '  x')
    assert test('y', 'x') == test('y   ', '  x')



# Generated at 2022-06-22 18:34:21.652687
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect

    def _add_frame(frame):
        def add_frame(x):
            return x
        add_frame._frame = frame
        return add_frame

    def get_frame():
        add_frame = _add_frame(inspect.currentframe())
        add_frame._frame_code = add_frame.__code__
        return add_frame._frame

    var_name = 'test_var'
    test_source = var_name
    test_data = dict()
    test_data[var_name] = 1
    test_variable = BaseVariable(test_source)
    test_items = test_variable.items(get_frame())
    assert test_items == tuple()

    var_name = 'test_var'
    test_source = var_name
    test_data = dict()
    test

# Generated at 2022-06-22 18:34:28.354556
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('foo')) == hash(BaseVariable('foo'))
    assert hash(Keys('foo')) == hash(Keys('foo'))
    assert hash(Attrs('foo')) == hash(Attrs('foo'))
    assert hash(Indices('foo')) == hash(Indices('foo'))
    assert hash(Exploding('foo')) == hash(Exploding('foo'))

    assert hash(BaseVariable('foo')) != hash(BaseVariable('bar'))
    assert hash(BaseVariable('foo')) != hash(BaseVariable('foo', exclude=['bar']))
    assert hash(Keys('foo')) != hash(Keys('bar'))
    assert hash(Attrs('foo')) != hash(Attrs('bar'))

# Generated at 2022-06-22 18:34:39.031040
# Unit test for constructor of class Attrs
def test_Attrs():
    class C:
        def __init__(self, v):
            self.v = v
        def __getattr__(self, k):
            assert k == 'e'
            return RuntimeError('fail')
    c = C(42)
    assert Attrs('c').items(frame=None, normalize=True) == [('c', 'C(.*)')]
    assert Attrs('c').items(frame=None, normalize=False) == [('c', 'C(v=42)')]
    assert Attrs('c').items(c, normalize=False) == [('c', 'C(v=42)'), ('c.v', '42'), ('c.__dict__', '{}')]

# Generated at 2022-06-22 18:34:47.756214
# Unit test for constructor of class Exploding
def test_Exploding():
    d = {'a':1}
    """
    expression = 'd'
    source = 'd'
    exclude = ()
    main_value = d
    _slice = slice(None)
    code = code object <module> at 0x7f6eceb6d120, file "<module>", line 2
    unambiguous_source = d
    """

    assert 'd' == d
    print('expression =', expression)
    print('source =', source)
    print('exclude =', exclude)
    print('main_value =', main_value)
    print('_slice =', _slice)
    print('code =', code)
    print('unambiguous_source =', unambiguous_source)



# Generated at 2022-06-22 18:34:57.601524
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    from . import params
    from . import utils
    from . import pycompat
    
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    
    class BaseVariable(pycompat.ABC):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source
    

# Generated at 2022-06-22 18:35:02.433265
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == 'a'
    assert a.exclude == ()
    assert a._fingerprint == (Attrs, 'a', ())
    assert hash(a) == hash(Attrs('a'))
    assert a == Attrs('a')
    assert a != 'a'
    assert a != Attrs('a', exclude='__dict__')
    assert a != Attrs('b')
    assert a != Attrs('a', exclude='__dict__')
    assert a != Keys('a')



# Generated at 2022-06-22 18:35:05.630953
# Unit test for constructor of class Exploding
def test_Exploding():
    a=Exploding("a", "b")
    assert a.__class__ == Exploding
    assert a.source == "a"
    assert a.exclude == ("b",)

# Generated at 2022-06-22 18:35:17.153333
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Attrs
    variable_attrs = Attrs("variables")
    assert variable_attrs.source == "variables"
    assert variable_attrs.exclude == ()
    assert variable_attrs.unambiguous_source == "variables"
    assert variable_attrs.code == compile("variables", '<variable>', 'eval')

    # Keys
    variable_keys = Keys("variables")
    assert variable_keys.source == "variables"
    assert variable_keys.exclude == ()
    assert variable_keys.unambiguous_source == "variables"
    assert variable_keys.code == compile("variables", '<variable>', 'eval')

    # Indices
    variable_indices = Indices("variables")
    assert variable_indices.source == "variables"
    assert variable_

# Generated at 2022-06-22 18:35:22.197041
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo').source == 'foo'
    assert Keys('foo').exclude == ()
    assert Keys('foo', 'ex').exclude == ('ex',)
    assert Keys('foo.bar.baz').source == 'foo.bar.baz'

# Generated at 2022-06-22 18:35:24.213367
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    a = A('a')
    a1 = A('a')
    b = A('b')

    assert a == a1
    assert not a == b

# Generated at 2022-06-22 18:35:31.840585
# Unit test for constructor of class Keys
def test_Keys():
    keys1 = Keys("foo")
    assert keys1.source == "foo"
    dict1 = {'a': 'b', 'c': 3, 'd': 4}
    assert [('c', '3'), ('d', '4'), ('a', 'b')] == keys1.items(dict1)

    dict3 = {'a': 'b', 0: 3, 1: 4}
    keys2 = Keys("foo")
    assert [('[0]', '3'), ('[1]', '4'), ('[\'a\']', 'b')] == keys2.items(dict3)

    keys3 = Keys("foo", exclude=0)
    assert [('[1]', '4'), ('[\'a\']', 'b')] == keys3.items(dict3)


# Generated at 2022-06-22 18:35:40.002985
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        x = object()
        def g():
            return x
        return g
    f().__code__.co_freevars = (b'x',)
    frame = f.__closure__[0].__granted__.tb_frame
    frame.f_locals['x'] = {'a':1}
    frame.f_locals['y'] = [1,2,3]
    frame.f_locals['z'] = 'abc'
    cls = globals()['BaseVariable']
    assert cls('x').items(frame) == [('x','{a: 1}')]
    assert cls('y').items(frame) == [('y', '[1, 2, 3]')]

# Generated at 2022-06-22 18:35:43.620880
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import re
    import string
    import random

    char_set = string.ascii_letters + string.digits + string.punctuation + ' '


# Generated at 2022-06-22 18:35:45.644607
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('person')
    print(ind.__getitem__(slice(3, 10, 2)))


# Generated at 2022-06-22 18:35:56.098581
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    
    # Test def _items
    # Test def _safe_keys
    # Test def _keys
    # Test def _format_key
    # Test def _get_value
    source = 'a.__dict__'
    #exclude = ()
    exclude = ('__bases__', '__name__', '__module__')
    var = CommonVariable(source, exclude)
    frame = {
        'a' : {
            'b' : 'c'
        }
    }
    var.items(frame)
    # Test def _keys
    # Test def _format_key
    # Test def _get_value
    
    
    