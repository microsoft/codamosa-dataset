

# Generated at 2022-06-22 18:25:53.817922
# Unit test for constructor of class Exploding
def test_Exploding():
    if __name__ == '__main__':
        # Unit test for constructor of class Exploding
        import doctest
        doctest.testmod(extraglobs={'exploding': Exploding})

# Generated at 2022-06-22 18:25:55.998096
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(Attrs('a')) == hash(Attrs('a'))
    assert hash(Attrs('a')) != hash(Attrs('b'))


# Generated at 2022-06-22 18:25:59.129839
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('A')
    assert a.source == 'A'
    assert a.exclude == ()

    b = CommonVariable('B', 'a')
    assert b.source == 'B'
    assert b.exclude == ('a',)


# Generated at 2022-06-22 18:26:03.024781
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code.co_name == 'a'

    a = Indices('a', 'b')
    assert a.source == 'a'
    assert a.exclude == ('b',)
    assert a.code.co_name == 'a'


# Generated at 2022-06-22 18:26:10.916442
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable('foo')
    assert a.source == 'foo'
    assert a.exclude == ()
    assert a.unambiguous_source == 'foo'
    assert a.code == compile('foo', '<variable>', 'eval')

    b = CommonVariable('foo', exclude='bar')
    assert b.source == 'foo'
    assert b.exclude == ('bar',)
    assert b.unambiguous_source == 'foo'
    assert b.code == compile('foo', '<variable>', 'eval')
    a = CommonVariable('foo', ('bar',))
    assert a.source == 'foo'
    assert a.exclude == ('bar',)
    assert a.unambiguous_source == 'foo'
    assert a.code == compile('foo', '<variable>', 'eval')


#

# Generated at 2022-06-22 18:26:14.530382
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    new = CommonVariable('var1')
    assert new.source =="var1"
    assert new.exclude == ()
    assert new.code == compile('var1', '<variable>', 'eval')
    assert new.unambiguous_source == 'var1'
    

# Generated at 2022-06-22 18:26:22.881729
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('x.y') == False
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('(x).y.z') == False
    assert needs_parentheses('x.y().z') == False
    assert needs_parentheses('(x.y).z') == False
    assert needs_parentheses('x().y.z') == True
    assert needs_parentheses('x().y().z') == True
    assert needs_parentheses('x()[1].z') == True
    assert needs_parenth

# Generated at 2022-06-22 18:26:27.848188
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import inspect
    import sys
    import io
    capture_output = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = capture_output
    try:
        a = CommonVariable('inspect.__dict__', exclude=('__dict__',))
        items = a.items(inspect.currentframe())
        assert items == [('inspect.__dict__', '<mappingproxy object at...>'), ('inspect.__dir__', '<built-in function ...>')]
    finally:
        sys.stdout = old_stdout
        print(capture_output.getvalue())


# Generated at 2022-06-22 18:26:35.688867
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable(
        'arg1',
        exclude=('a',)
    ).source == 'arg1'

    assert CommonVariable(
        'arg2',
        exclude=None
    ).source == 'arg2'

    assert CommonVariable(
        'arg3',
        exclude='a'
    ).source == 'arg3'

    assert CommonVariable(
        'arg4'
    ).source == 'arg4'

    assert CommonVariable(
        'arg5',
        exclude=('a', 'b')).source == 'arg5'

    assert CommonVariable(
        'arg6',
        exclude=('a', 'b', 'c')).source == 'arg6'

    assert CommonVariable(
        'arg7',
        exclude=('a', 'b', 'c')).source == 'arg7'

    assert Common

# Generated at 2022-06-22 18:26:40.148382
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('a')
    assert isinstance(i[2:4], Indices)
    assert i._slice == slice(None)
    assert i[2:4]._slice == slice(2, 4)


# Generated at 2022-06-22 18:26:42.431725
# Unit test for constructor of class Attrs
def test_Attrs():
    m = Attrs('x')
    assert m.source == 'x'
    assert isinstance(m, Attrs)


# Generated at 2022-06-22 18:26:47.029709
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # If a call to BaseVariable() succeeds, then we're good
    bv = BaseVariable("x['y'][1]")
    # If it throws an error, we're also good; that's what we expect in this
    # case.
    with pytest.raises(NameError):
        bv = BaseVariable("x['y'][1]")

# Generated at 2022-06-22 18:26:54.792216
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a[1]') is True
    assert needs_parentheses('(a[1])') is False
    assert needs_parentheses('a[1].b') is True
    assert needs_parentheses('(a[1]).b') is False
    assert needs_parentheses('a[1].b.c') is True
    assert needs_parentheses('(a[1]).b.c') is False

# Generated at 2022-06-22 18:26:57.892869
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import inspect, pdb
    frame = inspect.currentframe()
    print(frame)
    var = CommonVariable('', exclude=())
    print(inspect.currentframe())
    pdb.set_trace()

# Generated at 2022-06-22 18:27:01.456228
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from .packages import faulthandler
    if not faulthandler.is_enabled():
        return
    from . import load_module_name
    try:
        load_module_name('a')
    except SystemExit:
        pass

# Generated at 2022-06-22 18:27:08.151081
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for expr in ('a', 'a[0]',  'a.b', '(a)', 'a[(0)]', 'a.(b)'):
        assert not needs_parentheses(expr)

    for expr in ('a, b', 'a[0, 1]', 'a.b, c'):
        assert needs_parentheses(expr)



# Generated at 2022-06-22 18:27:19.281015
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Attrs('foo.bar').items({'foo':{'bar':'baz'}}) == [('foo.bar', "'baz'")]
    assert Keys('foo.bar').items({'foo':{'bar':'baz'}}) == [('foo.bar', "'baz'")]
    assert Indices('foo.bar').items({'foo':{'bar':'baz'}}) == [('foo.bar', "'baz'")]
    assert Exploding('foo.bar').items({'foo':{'bar':'baz'}}) == [('foo.bar', "'baz'")]
    assert Exploding('foo.bar').items({'foo':{'bar':[1,2,3]}}) == [('foo.bar', '[1, 2, 3]')]
    assert Exploding

# Generated at 2022-06-22 18:27:25.553271
# Unit test for constructor of class Keys
def test_Keys():
    import typing
    import collections

    d1 = {'a': 1, 2: 'a'}
    k1 = Keys('d1', exclude=['__init__'])
    k2 = Keys('d1', exclude=['a'])
    a1 = [1, 2]
    i1 = Indices('a1')

    D1 = collections.namedtuple('D1', 'a')
    d2 = D1(a='a')
    k3 = Keys('d2')

    D2 = typing.NamedTuple('D2', [('a',str)])
    d3 = D2(a='a')
    k4 = Keys('d3')


# Generated at 2022-06-22 18:27:36.225273
# Unit test for constructor of class Attrs
def test_Attrs():
    class Base(object):
        __slots__ = ('a', 'b')

        def __init__(self):
            self.a = 1
            self.b = 2

    Base()
    a = Attrs('Base()')
    # r = [('Base()', 'Base()'), ('Base().__slots__', "('a', 'b')"), ('Base().a', '1'), ('Base().b', '2')]
    r = list(a.items(Base()))
    assert r[0][0] == 'Base()'
    assert r[1][0] == 'Base().__slots__'
    assert r[2][0] == 'Base().a'
    assert r[3][0] == 'Base().b'
    assert r[0][1] == 'Base()'

# Generated at 2022-06-22 18:27:37.306933
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    CommonVariable(None,None)


# Generated at 2022-06-22 18:27:43.952799
# Unit test for constructor of class Exploding
def test_Exploding():
    source = ''
    exclude = ()
    v = Exploding(source, exclude)
    assert type(v) == Exploding
    # v.source == ''
    # v.exclude == ()

    source = 'xyz'
    exclude = 'xyz'
    v = Exploding(source, exclude)
    assert type(v) == Exploding
    # v.source == 'xyz'
    # v.exclude == ('xyz',)
    return
# test_Exploding()


# Generated at 2022-06-22 18:27:45.505190
# Unit test for constructor of class Exploding
def test_Exploding():
    e = Exploding('main_value')
    assert isinstance(e, Exploding)

# Generated at 2022-06-22 18:27:52.197531
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('"foo"')
    assert needs_parentheses('3')
    assert needs_parentheses('a')
    assert needs_parentheses('(a)')
    assert needs_parentheses('a[1]')

    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a[1][2]')
    assert not needs_parentheses('a.b.c.d')



# Generated at 2022-06-22 18:27:57.377114
# Unit test for constructor of class Exploding
def test_Exploding():
    # Test with a Mapping
    main_value = {}
    result = Exploding._items(main_value)
    print(result)
    # Test with a Sequence
    main_value = [1, 2, 3]
    result = Exploding._items(main_value)
    print(result)
    # Test with a non-Mapping, non-Sequence
    main_value = None
    result = Exploding._items(main_value)
    print(result)

# Generated at 2022-06-22 18:27:59.321851
# Unit test for constructor of class Exploding
def test_Exploding():
    expl=Exploding("test",())
    assert isinstance(expl, BaseVariable)

# Unit tests for method _items of class Exploding

# Generated at 2022-06-22 18:28:05.822711
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('foo.x')
    assert needs_parentheses('(foo).x')
    assert needs_parentheses('foo.bar.x')
    assert not needs_parentheses('(foo.bar).x')
    assert needs_parentheses('foo().x')
    assert not needs_parentheses('(foo()).x')
    assert needs_parentheses('foo.bar().x')
    assert not needs_parentheses('(foo.bar()).x')

# Generated at 2022-06-22 18:28:12.881639
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ()

    def test(first, second, expected):
        assert (TestVariable(first) == TestVariable(second)) == expected

    test('a', 'a', True)
    test('a', 'b', False)
    test('a', None, False)
    test(None, 'b', False)
    test('a', 'a', True)
    test('a', 'b', False)
    test('a', None, False)
    test(None, 'b', False)
test_BaseVariable___eq__()


# Generated at 2022-06-22 18:28:18.376238
# Unit test for function needs_parentheses
def test_needs_parentheses():
    """
    >>> assert needs_parentheses('x') is False
    >>> assert needs_parentheses('x[y]') is True
    >>> assert needs_parentheses('x[y].z') is True
    >>> assert needs_parentheses('x.y[z]') is True
    >>> assert needs_parentheses('x.y.z') is False
    """


# Generated at 2022-06-22 18:28:21.789974
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import pytest
    cv = CommonVariable('str(1)')
    assert cv.source == 'str(1)'
    with pytest.raises(NotImplementedError):
        cv._items({})


# Generated at 2022-06-22 18:28:25.283977
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a')

# Generated at 2022-06-22 18:28:33.654496
# Unit test for constructor of class Keys
def test_Keys():
    test_dict = {'a': 3, 'b': 4}
    k = Keys("test_dict")
    assert k.source == "test_dict"
    assert k.exclude == ()
    assert k.code.co_code == compile("test_dict", '<variable>', 'eval').co_code
    assert k.unambiguous_source == "test_dict"
    assert k.items(test_dict) == [('test_dict[a]', '3'), ('test_dict[b]', '4'), ('test_dict', "dict_keys(['a', 'b'])")]

# Generated at 2022-06-22 18:28:35.880350
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('string', 'exclude')
    assert keys.source == 'string'
    assert keys.exclude == ('exclude',)
    assert keys.code == compile('string', '<variable>', 'eval')



# Generated at 2022-06-22 18:28:47.052154
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'variable'
    exclude = 'exclude'
    code = compile(source, '<variable>', 'eval')
    assert needs_parentheses(source)
    unambiguous_source = '({})'.format(source)

    obj = BaseVariable(source, exclude)
    setattr(obj, 'source', source)
    setattr(obj, 'exclude', exclude)
    setattr(obj, 'code', code)
    setattr(obj, 'unambiguous_source', unambiguous_source)
    another_source = 'another variable'
    another_exclude = 'another exclude'
    another_code = compile(another_source, '<variable>', 'eval')
    assert needs_parentheses(another_source)
    another_unambiguous_source = '({})'.format(another_source)

    another_

# Generated at 2022-06-22 18:28:54.800707
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    a = range(3)
    assert indices._keys(a) == [0, 1, 2]
    assert list(indices[1:]._keys(a)) == [1, 2]
    assert list(indices[::2]._keys(a)) == [0, 2]
    assert list(indices[1::2]._keys(a)) == [1]
    assert list(indices[1:1]._keys(a)) == []


# Generated at 2022-06-22 18:28:56.546855
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('my_var')
    assert hash(v) == hash((type(v), 'my_var', ()))



# Generated at 2022-06-22 18:29:03.282135
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo.bar')
    assert needs_parentheses('foo().bar')
    assert needs_parentheses('foo[1]')
    assert needs_parentheses('foo[1:]')
    assert needs_parentheses('foo[1:].bar')
    assert not needs_parentheses('foo')
    assert not needs_parentheses('foo.bar[1]')
    assert not needs_parentheses('foo().bar[1]')

# Generated at 2022-06-22 18:29:06.531633
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    inst = CommonVariable("variable_name", "exclude_name")
    assert inst.source == "variable_name"
    assert inst.exclude == ("exclude_name",)
    assert inst.code != None
    assert inst.unambiguous_source != None


# Generated at 2022-06-22 18:29:11.358695
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    try:
        assert BaseVariable('a.b') == BaseVariable('a.b')
        assert BaseVariable('a.b') != BaseVariable('a.b', exclude=['c'])
        assert BaseVariable('a.b') != BaseVariable('a.c')
    except:
        print("Test for method __eq__ of class BaseVariable failed")


# Generated at 2022-06-22 18:29:16.984705
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'a'
    exclude = ['x', 'y']
    basvar = BaseVariable(source, exclude)
    assert basvar.source == source
    assert basvar.exclude == exclude
    assert basvar.code == compile(source, '<variable>', 'eval')
    assert basvar.unambiguous_source == 'a'


# Generated at 2022-06-22 18:29:27.804229
# Unit test for constructor of class Exploding
def test_Exploding():
    s = "test_Exploding"
    #test for keys of dict
    e = Exploding("test_Exploding['keys'][0]")
    assert next(e._items({'keys': [1]}, normalize=True))==('test_Exploding[\'keys\'][0]', '1')
    #test for indices of list
    e = Exploding("test_Exploding[0][0]")
    assert next(e._items([[1]], normalize=True))==('test_Exploding[0][0]', '1')
    #test for attrs of Object
    class T(object):
        a = 1
    e = Exploding("test_Exploding.a")
    assert next(e._items(T(), normalize=True))==('(test_Exploding).a', '1')
    #test

# Generated at 2022-06-22 18:29:31.944778
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a': 1, 'b': 2}
    if Keys('d', exclude='b')._items(d) != [('d', '{...}'), ('d.a', '1')]:
        print ('test_Keys FAILED')

if __name__ == "__main__":
    test_Keys()

# Generated at 2022-06-22 18:29:35.788713
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert (list(Indices('a')[0:2].items(None)) ==
            [Indices('a[0]', ()).items(None)[0], Indices('a[1]', ()).items(None)[0]])


# Generated at 2022-06-22 18:29:39.903872
# Unit test for constructor of class Keys
def test_Keys():
    sample_dict = {'a': 1, 'b': 2}
    # The test code is executed with the debugger and the frame's local variable "sample_dict" is passed
    # as the main_value and the expected result value is the list of keys
    test = Keys('sample_dict')
    assert list(test._keys(sample_dict)) == ['a', 'b']

# Generated at 2022-06-22 18:29:50.584675
# Unit test for constructor of class Keys
def test_Keys():
    x = {1:'a', 2:'b', 3:'c', 4:'d', 5:'e'}
    y = Keys('x', (3, 4)) # instance
    print('y: ', y)
    print('y.source: ', y.source)
    print('y.exclude: ', y.exclude)
    print('y.code: ', y.code)
    print('y.unambiguous_source: ', y.unambiguous_source)
    print('y.items(x): ', y.items(x))
    print('y._items(x): ', y._items(x))
    print('y._safe_keys(x): ', y._safe_keys(x))
    print('y._keys(x): ', y._keys(x))

# Generated at 2022-06-22 18:29:52.647412
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('foo', exclude=['bar'])
    assert k.source == 'foo'
    assert k.exclude == ('bar', )

# Generated at 2022-06-22 18:30:00.093683
# Unit test for constructor of class Exploding
def test_Exploding():
    exp_var = Exploding("request.data")

    assert str(exp_var.source) == "request.data"
    assert exp_var.exclude == ()
    assert str(exp_var.unambiguous_source) == "(request.data)"
    assert str(exp_var.code).startswith("<code object <module> at")
    assert exp_var.items({"request": {"data": {"a": 1, "b": 2}, "headers": []}}) == [
        ["request.data", "{'a': 1, 'b': 2}"],
        ["request.data.a", "1"],
        ["request.data.b", "2"]
    ]

    exp_var_with_exclude = Exploding("request.data", "a")

# Generated at 2022-06-22 18:30:03.696811
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys('var')
    assert var.source == 'var'
    assert var.code == compile('var', '<variable>', 'eval')
    assert var.unambiguous_source == 'var'
    assert var.exclude == ()


# Generated at 2022-06-22 18:30:07.660194
# Unit test for constructor of class Attrs
def test_Attrs():
    a1 = Attrs('a', 'b')
    a2 = Attrs('a', ('b', 'c'))
    #tuple
    assert a1._finge

# Generated at 2022-06-22 18:30:13.012024
# Unit test for constructor of class Exploding
def test_Exploding():
    cls = type('Exploding', (BaseVariable, ), {'_items': lambda x: None})
    assert isinstance(cls('a'), BaseVariable)
    assert isinstance(cls('a'), Exploding)


# Generated at 2022-06-22 18:30:19.269284
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x', 'y')._keys({'y': None}) != Keys('x', 'z')._keys({'y': None})
    assert Keys('x', 'y')._format_key('y') == Keys('x', 'z')._format_key('y')
    assert Keys('x', 'y')._get_value({'y': 1}, 'y') == Keys('x', 'z')._get_value({'y': 1}, 'y')



# Generated at 2022-06-22 18:30:22.775461
# Unit test for constructor of class Attrs
def test_Attrs():
    main_value = "main_value"
    variable = Attrs("a", exclude=())
    assert variable.source == "a"
    assert variable.code.co_name == '<module>'
    assert variable.unambiguous_source == 'a'



# Generated at 2022-06-22 18:30:33.875965
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo') is False
    assert needs_parentheses('foo.bar') is False
    assert needs_parentheses('foo[bar]') is False
    assert needs_parentheses('foo[bar].baz') is False
    assert needs_parentheses('foo(bar)') is False
    assert needs_parentheses('foo(bar).baz') is False
    assert needs_parentheses('foo(bar)[baz]') is False
    assert needs_parentheses('foo(bar)[baz].qux') is False
    assert needs_parentheses('foo.bar(baz)[qux]') is False
    assert needs_parentheses('lambda x: x') is True
    assert needs_parentheses('lambda x: x.a') is True
    assert needs_parentheses('lambda x: x[a]') is True


# Generated at 2022-06-22 18:30:35.087989
# Unit test for constructor of class Indices
def test_Indices():
	v1 = Indices("*args")
	print(v1[3:4].source)
	print(v1[3:4]._slice)
	print(v1._slice)

# Generated at 2022-06-22 18:30:44.186016
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert needs_parentheses('(a)')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a[b]')
    assert needs_parentheses('a().b')
    assert needs_parentheses('a().b[0]')
    assert not needs_parentheses('a[0]')
    assert not needs_parentheses('a.b()[0]')
    assert not needs_parentheses('a.b[0]()')
    assert needs_parentheses('a.b[0].d')
    assert needs_parentheses('a.b[0].d()')
    assert needs_parentheses('a.b[0].d().e')

# Generated at 2022-06-22 18:30:47.652392
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('foo', ['bar']).source == 'foo'
    assert Keys('foo', ['bar']).exclude == ('bar',)


# Generated at 2022-06-22 18:30:49.375006
# Unit test for constructor of class Keys
def test_Keys():
    class TestClass():
        d = {"a":1, "b":2}
        test = "test"
        def __init__(self):
            self.c = 3

    a = TestClass()
    res = Keys(a)
    assert res._fingerprint == (Keys, a)

# Generated at 2022-06-22 18:30:55.423224
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_variable = Indices("test_source")
    assert test_variable['1:2'] != test_variable['1:3']
    assert test_variable['1:2'] != test_variable
    assert test_variable['1:2'] == test_variable['1:2']


# Generated at 2022-06-22 18:30:57.629815
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('a')
    var_items = var.items(frame={})
    assert var_items[0] == ('a', 'None')


# Generated at 2022-06-22 18:31:03.912754
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class A(object):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

    def hash(a):
        return hash(a)

    def __hash__(self):
        return hash((type(self), self.source, self.exclude))

    a1 = A("xx")
    a2 = A("xx",("x","y"))
    a3 = A("xx")
    print(hash(a1))
    print(hash(a2))

# Generated at 2022-06-22 18:31:14.500220
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def test_case(a, b, expected):
        is_eq = (a == b) # Python 2
        if is_eq != expected:
            print('\n')
            print('>>>> a: {}'.format(a))
            print('>>>> b: {}'.format(b))
            print('>>>> expected: {}'.format(expected))
            print('>>>> result: {}'.format(is_eq))
            assert False

    test_case(Attrs('foo'), Attrs('foo'), True)
    test_case(Attrs('foo', exclude=['bar']), Attrs('foo'), False)
    test_case(Attrs('foo', exclude=['bar']), Attrs('foo', exclude=['bar']), True)

# Generated at 2022-06-22 18:31:19.382224
# Unit test for constructor of class BaseVariable
def test_BaseVariable(): 
    def test(): 
        v = BaseVariable("b", exclude=("a"))
        assert v.source == 'b'
        assert v.exclude == ('a',)
        assert v.code == compile('b', '<variable>', 'eval')
        assert v.unambiguous_source == 'b'
        assert v.items('something') == ()
    test()
            

# Generated at 2022-06-22 18:31:30.710815
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    var1 = BaseVariable("x", "y")
    assert var1.source == "x"
    assert var1.exclude == "y"
    assert var1.code == compile("x", '<variable>', 'eval')
    assert var1.unambiguous_source == "x"
    
    var2 = BaseVariable("(x)", "y")
    assert var2.source == "(x)"
    assert var2.exclude == "y"
    assert var2.code == compile("(x)", '<variable>', 'eval')
    assert var2.unambiguous_source == "(x)"
    
    # Test the code in needs_parentheses()
    code = compile("{}.x".format("x"), '<variable>', 'eval').co_code

# Generated at 2022-06-22 18:31:33.946438
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = {'a':1, 'b':2, 'c':3, 'd':4}
    print(len(main_value))
    i = Indices('x')
    print(int(i[0:3]))



# Generated at 2022-06-22 18:31:39.195010
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Foo(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass

    assert Foo('x') != Foo('y')
    assert Foo('x') != Foo('x', exclude=('x',))
    assert Foo('x', exclude=('x',)) != Foo('x', exclude=('y',))

    class Bar(Foo):
        pass

    assert Foo('x') != Bar('x')

    class Baz(Foo):
        def __eq__(self, other):
            return True

    assert Foo('x') == Baz('x')

# Generated at 2022-06-22 18:31:50.486562
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    
    # Test for Attrs
    # Test for class
    v = Attrs("self")
    d = {"x": "X"}
    f = inspect.currentframe()
    f.f_locals = {"self": d}
    assert v.items(f) == [("self", "{'x': 'X'}")]
    
    # Test for exception in _keys or _get_value
    f = inspect.currentframe()
    f.f_locals = {"self": r"\u"}
    assert v.items(f) == []

    # Test for Keys
    # Test for dict
    v = Keys("self")
    d = {"x": "X"}
    f = inspect.currentframe()
    f.f_locals = {"self": d}
    assert v.items(f)

# Generated at 2022-06-22 18:31:59.521045
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test the case when both instances are the same type with the same attributes
    class As(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    a = As('foo')
    b = As('foo')
    assert a == b
    assert a is not b
    b = As('foo', exclude=As)
    assert a != b
    # Test the case when the two instances are of different types
    class Bs(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    b = Bs('foo')
    assert a != b


# Generated at 2022-06-22 18:32:08.028913
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __str__(self):
            return self.a + ' ' + self.b
    a = A('1', '2')
    attr_output = Attrs('a', 'a.a').items(a)
    assert attr_output == [('a.a', '1'), ('a.b', '2')]



# Generated at 2022-06-22 18:32:10.498105
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1 = BaseVariable()
    v2 = BaseVariable()
    h1 = hash(v1)
    h2 = hash(v2)
    assert(h1 == h2)


# Generated at 2022-06-22 18:32:18.044009
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('1')
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b[c]')
    assert not needs_parentheses('a.b[c].d')
    assert needs_parentheses('a[b]')
    assert not needs_parentheses('a[b].c')



# Generated at 2022-06-22 18:32:24.612006
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert not needs_parentheses('a().b')
    assert not needs_parentheses('(a()).b')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a + b).c')
    assert needs_parentheses('a + b')

# Generated at 2022-06-22 18:32:30.497890
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # BaseVariable needs source and exclude as arguments.
    # Attribute 'source' is supposed to be accepted,
    # and then be compiled into code by compile()
    # Get attribute 'code' of the class BaseVariable,
    # and check if the type of 'code' is 'code'
    a = BaseVariable('test_var', 'var1')
    assert isinstance(a.code, type(CompileCode('test_var')))



# Generated at 2022-06-22 18:32:31.478674
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('bv_test')

# Generated at 2022-06-22 18:32:40.326839
# Unit test for constructor of class Exploding
def test_Exploding():
    class A(object):
        pass
    a = A()
    a.b = []
    a.b.append(1)
    a.b.append(2)

    a.c = {}
    a.c['x'] = 5
    a.c['y'] = 6

    x = Exploding('a')
    assert x.items(sys._getframe()) == [
        ('a', 'A()'),
        ('a.b', '[1, 2]'),
        ('a.c', "{'x': 5, 'y': 6}"),
        ('a.__dict__', '{}')]



# Generated at 2022-06-22 18:32:45.884470
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('x')
    var2 = BaseVariable('x')
    var3 = BaseVariable('x', exclude=['a'])
    var4 = BaseVariable('x', exclude=['b'])
    assert var1 == var2
    assert not var1 == var3
    assert not var1 == var4
    assert not var2 == var3
    assert not var2 == var4
    assert var3 == var4


# Generated at 2022-06-22 18:32:56.987749
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a.b.c')
    assert needs_parentheses('a.b[' ']')
    assert needs_parentheses('a.b[0]')
    assert not needs_parentheses('a')
    assert not needs_parentheses('a.b')
    assert not needs_parentheses('a.b[x]')
    assert needs_parentheses('a.b.c.d')
    assert not needs_parentheses('a.b.c[1]')
    assert not needs_parentheses('a.b.c[1].d')
    assert needs_parentheses('x.y.z[0].a')
    assert not needs_parentheses('z[0].a')
    assert not needs_parentheses('a.b[1][2]')

# Generated at 2022-06-22 18:33:07.509012
# Unit test for constructor of class Attrs
def test_Attrs():
    assert Attrs('x', 'y').exclude == ('y',)
    assert Attrs('x', ('y',)).exclude == ('y',)
    assert Attrs('x').source == 'x'
    assert Attrs('x').unambiguous_source == 'x'
    assert Attrs('(x)').unambiguous_source == '(x)'
    assert Attrs('x').code.co_code == b'dV'
    x = object()
    assert Attrs('x').items(sys._getframe(), x) == [('x', '<object object at ' + str(id(x)) + '>')]


# Generated at 2022-06-22 18:33:10.175705
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert len(set(BaseVariable("1") for _ in range(10))) == 1


# Generated at 2022-06-22 18:33:11.463985
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
  pass


# Generated at 2022-06-22 18:33:13.563441
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    """
    issue #6: method __getitem__ of class Indices
    """
    

# Generated at 2022-06-22 18:33:16.670683
# Unit test for constructor of class Keys
def test_Keys():
    source = "hello"
    exclude = ()
    keys = Keys(source, exclude)
    assert keys.source is source
    assert keys.exclude is exclude
    assert keys.code is not source
    assert keys.unambiguous_source == source


# Generated at 2022-06-22 18:33:19.119042
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    var = CommonVariable("abc", exclude=("b",))
    assert var.source == "abc"
    assert var.exclude == ("b",)
    assert var.unambiguous_source == "(abc)"


# Generated at 2022-06-22 18:33:21.573183
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a=Indices('a')
    b=a[1:2]
    assert b._slice == slice(1, 2, None)


# Generated at 2022-06-22 18:33:26.960119
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable("x", (1,2))
    y = BaseVariable("y", (1,2))
    z = BaseVariable("x", (3,4))
    w = BaseVariable("x", (1,2))
    assert not (x == y)
    assert not (x == z)
    assert (x == w)

# Generated at 2022-06-22 18:33:31.817718
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import utils
    cv = CommonVariable("test_source","test_exclude")
    assert cv.source == "test_source"
    assert cv.exclude == "test_exclude"
    assert cv.code == compile("test_source", '<variable>', 'eval')
    assert cv.unambiguous_source == "test_source"

# Generated at 2022-06-22 18:33:34.174993
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    result = BaseVariable("s")
    assert result.code is not None


# Generated at 2022-06-22 18:33:38.183943
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v=Indices('a')
    v2=v[1:-1]
    assert v2 is not v
    assert v2!=v
    assert v2.__class__==Indices
    assert v2._slice==slice(1, -1)



# Generated at 2022-06-22 18:33:41.469667
# Unit test for constructor of class Attrs
def test_Attrs():
    class _(object):
        field = 'test'
        def __init__(self):
            self.field = 'test_init'
    a = _()

    class_variable = Attrs('a')

    for v in class_variable._items(a):
        print(v)



# Generated at 2022-06-22 18:33:44.333498
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a + b')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a.b)')
    assert needs_parentheses('(a + b)')

# Generated at 2022-06-22 18:33:46.368318
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('Running '+test_BaseVariable___eq__.__name__)
    v1 = BaseVariable('a','b')
    v2 = BaseVariable('a','b')
    assert v1 == v2


# Generated at 2022-06-22 18:33:54.463069
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    f1 = FrameInfo(None, None, None, None, None,
                   "<ipython-input-3-a0c2dce913e9>",
                   40, None, None,
                   "yee = '2'",
                   "yee = '2'",
                   None, None, False, False)
    v1 = BaseVariable("yee", "")
    assert(v1.items(f1.f_trace, False) == [('yee', "'2'")])
    return True

# Generated at 2022-06-22 18:34:04.492160
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    import numpy as np
    from . import default
    from . import variable

    obj = variable.default_variables['_']
    obj._source = 'numpy.random.uniform(1,10,5)'
    obj._frame = np.random.uniform(1,10,5)
    obj._code = compile(obj._source, '<variable>', 'eval')
    obj._unambiguous_source = obj._source

    assert obj._code == compile('numpy.random.uniform(1,10,5)', '<variable>', 'eval')
    assert obj._unambiguous_source == 'numpy.random.uniform(1,10,5)'
    assert obj._source ==  'numpy.random.uniform(1,10,5)'


# Generated at 2022-06-22 18:34:15.552472
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import logging
    import requests
    import threading

    class OtherClass(object):
        def __init__(self, a, b):
            self.a, self.b = a, b

    class SomeClass(object):
        def __init__(self):
            self.x = OtherClass(1, 'foo')
            self.y = {'a': 1, 'b': 2}
            self.z = [1, 2, 3]
            self.p = (SomeClass(), SomeClass())


    frame = inspect.currentframe()
    frame.f_locals['a'] = 1
    frame.f_locals['b'] = 'foo'
    frame.f_locals['logging'] = logging
    frame.f_locals['requests'] = requests

# Generated at 2022-06-22 18:34:25.941388
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('z')
    assert BaseVariable('x') != BaseVariable('y', exclude=('y'))
    assert BaseVariable('x', exclude=('y')) != BaseVariable('x')
    assert BaseVariable('x', exclude=('y')) == BaseVariable('x', exclude=('y'))
    assert BaseVariable('x', exclude=('p', 'q')) == BaseVariable('x', exclude=('p', 'q'))
    assert BaseVariable('x', exclude=('p', 'q')) != BaseVariable('x', exclude=('p', 'r'))




# Generated at 2022-06-22 18:34:37.355686
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from mock import Mock

    globals_dict = {'f_globals':{}, 'f_locals':{}}
    for source, items in (
            ('1+1', [('1+1', '2')]),
            ('x', [('x', '1')]),
            ('x.y', [('x.y', 'None')]),
            ('x.y', [('x.y', 'None'), ('x[\'y\']', 'None')]),
            ('x[\'y\']', [('x.y', 'None'), ('x[\'y\']', 'None')])
    ):
        for exclude in (None, (), ('y')):
            for eval_result in (1, 2):
                eval_result = Mock()
                eval_result.y = None
                eval_result.__getitem__

# Generated at 2022-06-22 18:34:44.764821
# Unit test for constructor of class Indices
def test_Indices():
    # Test 1: Check that all arguments are initialized properly
    #by creating a new instance of the class
    test_instances = Indices('self', exclude='self')
    # Test 2: Check that the class is an instance of BaseVariable class
    assert isinstance(test_instances, BaseVariable)
    # Test 3: Check that the class is an instance of Keys class
    assert isinstance(test_instances, Keys)
    # Test 4: Check that the class is an instance of Indices class
    assert isinstance(test_instances, Indices)

# Generated at 2022-06-22 18:34:48.884616
# Unit test for constructor of class Indices
def test_Indices():
    test_variable = Indices('test_slicing[:3]')
    assert(test_variable._fingerprint == (Indices, 'test_slicing[:3]', tuple()))
    assert(type(test_variable) == Indices)
    assert(test_variable.source == 'test_slicing[:3]')
    assert(test_variable.exclude == tuple())
    assert(test_variable._slice == slice(None, 3, None))

# Generated at 2022-06-22 18:34:51.835539
# Unit test for constructor of class Exploding
def test_Exploding():
    x = Exploding('w')
    y = eval(repr(x))
    assert x == y
    x = eval(repr(x))
    assert x == y



# Generated at 2022-06-22 18:34:52.818186
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys()
    assert k is not None

# Generated at 2022-06-22 18:34:54.213216
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices('x')
    assert indices._slice == slice(None)

# Generated at 2022-06-22 18:34:59.338798
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') == BaseVariable('x', 'y')
    assert BaseVariable('x') != BaseVariable('x', 'y', 'z')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('x', 'z')
    assert BaseVariable('x') != object()

# Unit tests for method __hash__ of class BaseVariable

# Generated at 2022-06-22 18:35:05.494054
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('foo'), Keys)
    assert isinstance(Exploding('foo')[:], Keys)
    assert isinstance(Exploding('foo')[1:2], Keys)
    assert isinstance(Exploding('foo')[:2], Keys)
    assert isinstance(Exploding('foo')[0], Keys)

    assert isinstance(Exploding('foo')['bar'], Keys)
    assert isinstance(Exploding('foo')[5], Indices)
    assert isinstance(Exploding('foo')[1.0], Indices)
    assert isinstance(Exploding('foo')[1000], Indices)
    assert isinstance(Exploding('foo')[-1], Indices)
    assert isinstance(Exploding('foo')[-2], Indices)


# Generated at 2022-06-22 18:35:10.705662
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from inspect import isabstract
    from . import utils
    assert isabstract(BaseVariable) == True
    assert utils.hashable(BaseVariable) == True
    expected_value, actual_value = True, utils.hashable(BaseVariable)
    assert expected_value == actual_value
    assert utils.hashable(BaseVariable) == True


# Generated at 2022-06-22 18:35:15.188786
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('foo', 'bar')
    assert attrs.source=='foo'
    assert attrs.exclude==('bar', )
    assert attrs.code
    assert attrs.unambiguous_source=='foo'



# Generated at 2022-06-22 18:35:19.433063
# Unit test for constructor of class Attrs
def test_Attrs():
    class A:
        pass
    a = A()
    a.b = 1
    assert Attrs('a').items(sys.__getframe()) == [('a', '<__main__.A object at 0x000001B0B1B19EB8>'), ('a.b', '1')]


# Generated at 2022-06-22 18:35:22.072260
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_object = Indices("test_object")
    assert isinstance(test_object[:], Indices)
    assert isinstance(test_object[1:], Indices)

# Generated at 2022-06-22 18:35:29.608602
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('')
    assert needs_parentheses('1')
    assert needs_parentheses('()')
    assert not needs_parentheses('None')
    assert needs_parentheses('(None)')
    assert needs_parentheses('1.x')
    assert needs_parentheses('(1+2).x')
    assert needs_parentheses('1j.x')
    assert not needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x[y]')

# Generated at 2022-06-22 18:35:31.222389
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    result = Indices('test').__getitem__(slice(0,5))
    assert result._slice == slice(0,5)

# Generated at 2022-06-22 18:35:39.774641
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class MyCommonVar(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()
        def _format_key(self, key):
            return '[{}]'.format(utils.get_shortish_repr(key))
        def _get_value(self, main_value, key):
            return main_value[key]
    V = MyCommonVar("f", exclude=("b", "c"))
    assert V.source == "f"
    assert V.code == compile("f", '<variable>', 'eval')
    assert V.exclude == ("b", "c")
    assert V._fingerprint == (MyCommonVar, "f", ("b", "c"))
    assert V.__hash__() == hash((MyCommonVar, "f", ("b", "c")))


# Generated at 2022-06-22 18:35:41.110154
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    BaseVariable('a')


# Generated at 2022-06-22 18:35:45.480822
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = "my_dict"
    exclude = "value"
    bv = BaseVariable(source, exclude)

    assert bv.source == source
    assert bv.exclude == tuple(exclude)
    assert bv.code.co_names[0] == source
    assert bv.unambiguous_source == "(my_dict)"


# Generated at 2022-06-22 18:35:52.344910
# Unit test for constructor of class Exploding
def test_Exploding():
    assert Attrs('1') == Attrs('1')
    assert Attrs('1') != Attrs('2')
    assert Attrs('1') != Keys('1')
    assert Attrs('1') != Indices('1')

    assert Attrs('1').items(frame=None) != Keys('1').items(frame=None)

