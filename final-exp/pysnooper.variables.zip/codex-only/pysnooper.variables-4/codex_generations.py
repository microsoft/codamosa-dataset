

# Generated at 2022-06-22 18:25:50.558009
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    global varName
    varName = 'location'
    class CommonVariable(BaseVariable):
        def _keys(self, main_value):
            return ['a', 'b', 'c']

        def _format_key(self, key):
            return '.' + key

        def _get_value(self, main_value, key):
            return getattr(main_value, key)
    return CommonVariable(varName)

test_CommonVariable()

# Generated at 2022-06-22 18:25:55.915275
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    A = Indices('a')
    A1 = A[None:None:0]
    assert A1._fingerprint == (Indices, 'a', ())


# Generated at 2022-06-22 18:26:02.865888
# Unit test for constructor of class Keys
def test_Keys():
    local_variable = Keys('local_variable')
    print(local_variable)
    print(local_variable.__hash__())
    print(local_variable.__eq__(local_variable))
    print(local_variable.source)
    print(local_variable.exclude)
    print(local_variable.code)
    print(local_variable.unambiguous_source)
    print(local_variable._fingerprint)
    print(local_variable._safe_keys({'x':'hello', 'y':'world'}))
    print(local_variable._keys({'x':'hello', 'y':'world'}))
    print(local_variable._format_key('x'))
    print(local_variable._get_value({'x':'hello', 'y':'world'}, 'x'))
   

# Generated at 2022-06-22 18:26:10.377212
# Unit test for constructor of class Indices
def test_Indices():
    indices = Indices("indices")
    assert indices.exclude == ()
    assert indices.source == "indices"
    assert indices.code
    assert indices.unambiguous_source == indices.source

    indices = Indices("indices", exclude=("a", "b"))
    assert indices.exclude == ("a", "b")
    assert indices.source == "indices"
    assert indices.code
    assert indices.unambiguous_source == indices.source

    indices = Indices("indices", exclude="a")
    assert indices.exclude == ("a",)
    assert indices.source == "indices"
    assert indices.code
    assert indices.unambiguous_source == indices.source



# Generated at 2022-06-22 18:26:16.406746
# Unit test for constructor of class Attrs
def test_Attrs():
    def update_dict():
        d = {'b': 'B', 'c': 'C'}
        d.update({'a': 'A'})
    f, stack = utils.get_traceback_frames(update_dict)
    tb = stack[0]
    frame = tb.tb_frame
    items = Attrs('d').items(frame)
    assert items == [('d', '{}'), ('d.b', "'B'"), ('d.c', "'C'"), ('d.a', "'A'")]


# Generated at 2022-06-22 18:26:27.273535
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass
    #
    # We need to mock types to test.
    #
    # Mocked classes:
    #   class BaseVariable
    #   class CommonVariable
    #
    # Mocked functions:
    #   parse_as_type
    #   inspect.isfunction
    #
    # But 'pip install mock' is necessary, lets skip this for a moment
    # test code.
    #
    # my_variable = BaseVariable("a")
    # result = my_variable.__hash__()
    #
    # assert hash((type(my_variable), my_variable.source, my_variable.exclude)) == result
    #


# Generated at 2022-06-22 18:26:29.238116
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('test')
    assert isinstance(i, Keys)


# Generated at 2022-06-22 18:26:29.843898
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass



# Generated at 2022-06-22 18:26:33.267783
# Unit test for constructor of class Keys
def test_Keys():
    # Test if arguments are parsed correctly for Keys variable
    key_items = Keys('main_value', ['key1', 'key2']).items(None)
    exp_items = [('main_value', ''), ('main_value[key1]', '')]
    assert key_items == exp_items



# Generated at 2022-06-22 18:26:37.354385
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys("x", exclude=["a"])
    assert str(x.source) == "x"
    assert str(x.exclude) == "('a',)"


# Generated at 2022-06-22 18:26:47.730146
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable_test(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            try:
                main_value = eval(self.code, frame.f_globals or {}, frame.f_locals)
            except Exception:
                return ()
            return self._items(main_value, normalize)

        # @abc.abstractmethod

# Generated at 2022-06-22 18:26:49.575126
# Unit test for constructor of class Exploding
def test_Exploding():
    explode = Exploding(source='explode')
    assert type(explode) == Exploding
    assert type(explode) is not Keys


# Generated at 2022-06-22 18:26:54.589763
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    obj = BaseVariable('abc', 'abc')

    assert isinstance(obj.source, str)
    assert isinstance(obj.exclude, tuple)
    assert isinstance(obj.code, compile)
    assert obj.unambiguous_source == 'abc'


# Generated at 2022-06-22 18:27:03.503078
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a.b')
    assert needs_parentheses('a().b')
    assert needs_parentheses('a().b.c')
    assert not needs_parentheses('(a.b)')
    assert not needs_parentheses('(a().b)')
    assert not needs_parentheses('(a().b.c)')
    assert not needs_parentheses('a.b()')
    assert not needs_parentheses('a.b().c()')
    assert not needs_parentheses('a.b().c.d()')
    assert needs_parentheses('(a.b()).c')
    assert needs_parentheses('a()[0]')
    assert needs_parentheses('a()[0].b')
    assert needs_parentheses('a()[0].b.c')
    assert not needs

# Generated at 2022-06-22 18:27:13.823500
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    if frame is None:
        print("Impossible to find the current frame.")
    else:
        print("Find the current frame")

    print("\n")
    print("Test for BaseVariable")
    print("\n")
    print("Test for _items of BaseVariable")
    print("\n")
    print("Test for Attrs")
    print("\n")
    print("Test for _items of Attrs")
    a = Attrs("var[0]")
    print("\n")
    print("Test for var[0]")
    print("Expected output:('var[0]', '[1, 2, 3]')")
    print("Output:", a._items([1,2,3], True))
    print("\n")

# Generated at 2022-06-22 18:27:17.937824
# Unit test for constructor of class Indices
def test_Indices():
    assert repr(Indices('foo')) == "Indices('foo')"
    assert Indices('foo') == Indices('foo')
    assert Indices('foo') != Indices('bar')
    assert Indices('foo') != Indices('foo', exclude=('bar',))

# Generated at 2022-06-22 18:27:26.885647
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('x.y')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('x.y.z')
    assert not needs_parentheses('(x.y).z')
    assert needs_parentheses('x()')
    assert needs_parentheses('x().y')
    assert needs_parentheses('x()[0]')
    assert needs_parentheses('x.y[0]')
    assert not needs_parentheses('(x())[0]')
    assert not needs_parentheses('(x.y)[0]')
    assert not needs_parentheses('x()[0].y')
    assert not needs_parentheses('x.y[0].z')
   

# Generated at 2022-06-22 18:27:35.262768
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    from .pycompat import xrange

    v = Indices("a")
    assert v._slice is slice(None)
    for s in [slice(0, 5), slice(0, 10, 2)]:
        v1 = v[s]
        assert v1._slice == s
        assert v1._slice is not v._slice
        assert v1._slice.start == s.start
        assert v1._slice.stop == s.stop
        assert v1._slice.step == s.step
        assert isinstance(v1._slice, slice)
        assert isinstance(v._slice, slice)


# Generated at 2022-06-22 18:27:45.903234
# Unit test for constructor of class Exploding
def test_Exploding():
    # Source: https://github.com/tensorflow/tensorflow/blob/cff8f8a6d54a9305631e6aa47ff9bd1f9f21dc01/tensorflow/core/framework/tensor.h#L177
    class TensorProto(object):
        def __init__(self):
            self.version_number = None
            self.dtype = None
            self.tensor_shape = None
            self.tensor_content = None
            self.half_val = None
            self.float_val = None
            self.double_val = None
            self.int_val = None
            self.string_val = None
            self.scomplex_val = None
            self.int64_val = None
            self.bool_val = None
            self.d

# Generated at 2022-06-22 18:27:55.379108
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable('a')
    variable_1 = BaseVariable('a')

    # When you create an instance of a class, Python calls __new__ and passes it the class, then __init__ and passes it the instance.
    # __new__ is responsible for returning an instance, while __init__ can modify the instance that __new__ returns.
    # If __new__ returned an instance of a different class, __init__ won't be called.
    # https://stackoverflow.com/questions/674304/pythons-use-of-new-and-init
    assert variable == variable_1
    variable_2 = BaseVariable('a', ['b'])
    assert variable != variable_2
    assert variable_1 != variable_2



# Generated at 2022-06-22 18:27:59.992200
# Unit test for constructor of class Keys
def test_Keys():
    commonVarKey = Keys("request", ("data", ))
    assert commonVarKey.source == "request"
    assert commonVarKey.exclude == ("data", )
    assert commonVarKey.code == compile("request", '<variable>', 'eval')
    assert commonVarKey.unambiguous_source == "request"


# Generated at 2022-06-22 18:28:01.651430
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('variable')
    print(bv.source)
    print(bv.code)

# Generated at 2022-06-22 18:28:04.796358
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('a', exclude=('bar',))
    assert x.source == 'a'
    assert x.exclude == ('bar',)
    assert x.code == compile('a', '<variable>', 'eval')
    assert x.unambiguous_source == 'a'

# Generated at 2022-06-22 18:28:13.299416
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class DummyCommonVariable(CommonVariable):
        def _get_value(self, main_value, key):
            return main_value

        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return key

    variable = DummyCommonVariable("foo", exclude="bar")

    # Test if the constructor works
    assert isinstance(variable, CommonVariable)
    assert variable.source == 'foo'
    assert variable.exclude == ('bar',)
    assert variable.code == compile('foo', '<variable>', 'eval')
    assert variable.unambiguous_source == 'foo'

    # Test what is returned by method items()
    result = variable.items(frame=None)
    assert result == ('foo', 'foo')



# Generated at 2022-06-22 18:28:18.481792
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from hypothesis import given
    from hypothesis import strategies as st

    from . import pycompat

    @given(st.text())
    def test(source):
        obj = BaseVariable(source)
        assert len({obj}) == 1

        obj2 = BaseVariable(source)
        assert len({obj2}) == 1

    test()


# Generated at 2022-06-22 18:28:25.464258
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # To verify the method __init__
    assert isinstance(BaseVariable('k'), BaseVariable) == True
    # To verify the method __hash__
    assert hash(BaseVariable('k')) == hash((BaseVariable, 'k', ()))
    # To verify the method __eq__
    v1 = BaseVariable('k')
    v2 = BaseVariable('k')
    assert (v1 == v2) == True
    assert (v1 == 'not v') == False
    v3 = BaseVariable('k', 'k')
    assert (v1 == v3) == False

# Generated at 2022-06-22 18:28:28.912682
# Unit test for constructor of class Keys
def test_Keys():
    # example
    source = 'b'
    # variable with source
    variable = Keys(source)
    frame = {}
    variable.items(frame)
    # unit test
    assert variable._format_key(0) == '[0]'

# Generated at 2022-06-22 18:28:31.736479
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('a', 'b')) == hash(BaseVariable('a', 'b'))
    assert hash(BaseVariable('a', 'b')) != hash(BaseVariable('a', 'b', 'c'))


# Generated at 2022-06-22 18:28:34.476133
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_Indices = Indices("test_Indices",())
    test_slice = slice(1,5,2)
    test_Indices.__getitem__(test_slice)
    assert test_Indices._slice == test_slice

# Generated at 2022-06-22 18:28:40.183770
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class MyVariable(CommonVariable):
        def _keys(self, main_value):
            return main_value.keys()

        def _format_key(self, key):
            return '.{}'.format(key)

        def _get_value(self, main_value, key):
            return main_value[key]

    v = MyVariable('myvar', exclude=['exc'])

    def items():
        return v.items({'myvar': {'ignore': '', 'exc': ''}})

    assert items() == [('myvar', '{...}')]
    assert items() == [('myvar', '{...}')]
    assert items() == [('myvar', '{...}')]
    assert items() == [('myvar', '{...}')]

# Generated at 2022-06-22 18:28:43.897575
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # __getitem__ must return another Indices instance
    a = Indices('a')
    b = a[:]
    assert b is not a
    assert b is a[:]
    assert b is not a[0]
    assert b is not a[1:]
    assert b is not a[:-1]
    assert b is not a[:10]
    assert b is not a[:-20]
    assert b is not a[::]
    assert b is not a[::-1]
    assert b is not a[::-20]
    assert b is not a[::1]
    assert b is not a[::2]



# Generated at 2022-06-22 18:28:55.575707
# Unit test for constructor of class Attrs
def test_Attrs():
    #test_Attrs
    from . import utils
    from .utils import Attrs
    from .utils import VariablePutter
    import numpy as np
    import random
    ####################################################################################################################
    #general
    a1 = np.random.rand(5,5)
    b1 = Attrs('a1', exclude='x')
    frame1 = VariablePutter({'a1': a1}, exclude='x')
    print(b1.source)
    (b1.items(frame1))
    
    #exclude
    a1 = np.random.rand(5,5)
    b1 = Attrs('a1', exclude='x')
    frame1 = VariablePutter({'a1': a1, 'x':'exclude'}, exclude='x')
    (b1.items(frame1))

# Generated at 2022-06-22 18:29:06.692188
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from collections import namedtuple
    class A(object):
        def __init__(self):
            self.x = 1

        def foo(self):
            return 2

    class B(object):
        x = 3

    class C(object):
        def __init__(self):
            self.x = 4

        def __getattr__(self, item):
            return 10

    a = A()
    b = B()
    c = C()


# Generated at 2022-06-22 18:29:09.231345
# Unit test for constructor of class Indices
def test_Indices():
    mv = 3
    assert isinstance(mv, int)
    keys = Indices(mv)
    assert(keys.__getitem__(1) == 1)

# Generated at 2022-06-22 18:29:16.652150
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == 'a'
    a = Keys('a', exclude='a')
    assert a.source == 'a'
    assert a.exclude == ('a',)
    a = Keys('a', exclude=['a'])
    assert a.source == 'a'
    assert a.exclude == ('a',)



# Generated at 2022-06-22 18:29:18.058026
# Unit test for constructor of class Indices
def test_Indices():
    assert Indices('x', exclude=['a']).exclude == ('a',)

# Generated at 2022-06-22 18:29:28.844993
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class MyList(list): pass
    class MyDict(dict): pass
    class MyTuple(tuple): pass
    class MySet(set): pass
    class MyFrozenset(frozenset): pass
    class MyDeque(collections.deque): pass
    class MyCounter(collections.Counter): pass
    class MyOrderedDict(collections.OrderedDict):
        def _get_value(self, key):
            return self[key]
    class MyDefaultDict(collections.defaultdict): pass
    class MyUserDict(collections.UserDict): pass
    class MyUserList(collections.UserList): pass
    class MyUserString(collections.UserString): pass


# Generated at 2022-06-22 18:29:37.886524
# Unit test for constructor of class Attrs
def test_Attrs():
    # test model object's __dict__ attribute
    d = dict(a = 1, b = 2)
    attr = Attrs('d')
    assert attr.items(locals())[0] == ('d','{a: 1, b: 2}')
    assert attr.items(locals())[1] == ('d.a','1')
    assert attr.items(locals())[2] == ('d.b','2')
    assert len(attr.items(locals())) == 3

    class TestAttrs(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return self.name
        def __str__(self):
            return self.name

# Generated at 2022-06-22 18:29:49.102457
# Unit test for constructor of class Exploding
def test_Exploding():
    from gdb_wrapper import Frame
    frame = Frame('instruction pointer', 'frame pointer', 'stack pointer', 'frame base pointer', None,
                  {'x': {'a': 1, 'b': 2}}, {})
    var = Exploding('x')
    assert var.source == 'x'
    assert var.exclude == tuple()
    assert var.unambiguous_source == 'x'
    assert var._items(1) == [('x', '1')]
    assert var._items((1, 2)) == [('x[0]', '1'), ('x[1]', '2')]
    assert var._items({'a': 1, 'b': 2}) == [('x[a]', '1'), ('x[b]', '2')]

# Generated at 2022-06-22 18:29:50.501115
# Unit test for constructor of class Indices
def test_Indices():
  result = Indices('x[0]')
  assert result

# Generated at 2022-06-22 18:29:52.990846
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys("a","b") != Keys("a", "b")
    assert Keys("a", "b") == Keys("a", "b")


# Generated at 2022-06-22 18:30:00.295824
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import gc
    code = """def f():
        a = 1
        b = 2
        c = 3
        return locals()
    """

    context = {}
    exec(code, context)
    f = context['f']
    l = f()
    f = gc.get_referents(l)
    frame = inspect.currentframe()
    def item(name):
        return BaseVariable(name, ('x')).items(frame, normalize=True)
    assert item('l') == (
        ('l', '{\'a\': 1, \'b\': 2, \'c\': 3}'),
        ('l[\'a\']', '1'),
        ('l[\'b\']', '2'),
        ('l[\'c\']', '3'),
    )
    assert item

# Generated at 2022-06-22 18:30:03.194624
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('dict_')
    v[:]
    v[-1:]
    v[1:-1]
    v[3:1:2]
    v[:-1]

# Generated at 2022-06-22 18:30:13.065025
# Unit test for constructor of class Attrs
def test_Attrs():
    frame_variable = Attrs('frame')
    x = 1
    frame = inspect.currentframe()
    assert frame_variable.items(frame) == [('frame', 'frame'), ('frame.f_back', 'None'), ('frame.f_builtins', '{}'), ('frame.f_code', '<code {0}, file "<variable>", line 1>'), ('frame.f_exc_traceback', 'None'), ('frame.f_exc_type', 'None'), ('frame.f_exc_value', 'None'), ('frame.f_globals', '{}'), ('frame.f_lasti', '0'), ('frame.f_lineno', '1'), ('frame.f_locals', '{}'), ('frame.f_restricted', 'False'), ('frame.f_trace', 'None')]


# Generated at 2022-06-22 18:30:14.789551
# Unit test for constructor of class Indices
def test_Indices():
    i = Indices('key')
    assert i.source == 'key'
    assert isinstance(i, CommonVariable)

    j = i[0:2]
    assert j.source == 'key'
    assert j._slice == slice(0,2)

# Generated at 2022-06-22 18:30:19.358720
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    var = BaseVariable('a', 'b')
    class Person:
        def __init__(self, name):
            self.name = name
    a = Person('Tom')
    frame = {'a': a}
    keys = var.items(frame)
    assert keys == [('a', 'Tom')]



# Generated at 2022-06-22 18:30:25.874895
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    class base(BaseVariable):
        pass

    class base1(BaseVariable):
        pass

    class base2(BaseVariable):
        pass

    b = base(source='hello')
    b1 = base1(source='hello')
    b2 = base2(source='hello')
    #hashable
    assert hash(b)
    assert hash(b1)
    assert hash(b2)

    assert b == b1
    assert b1 != b2

    b3 = base(source='hello', exclude=['a'])
    assert hash(b3)
    assert b != b3

# Generated at 2022-06-22 18:30:33.456399
# Unit test for function needs_parentheses
def test_needs_parentheses():
    test_dict = {
        'a': 1,
        'b.c': 2,
        'd.__': 3,
        'd[1]': 4,
        'd[1].e': 5,
        '"d[1].e"': 6,
    }
    for source, expected in test_dict.items():
        assert needs_parentheses(source) == (expected % 2 == 0)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 18:30:35.975455
# Unit test for constructor of class Indices
def test_Indices():
     assert Indices("a")

# Generated at 2022-06-22 18:30:38.242735
# Unit test for constructor of class Exploding
def test_Exploding():
    main_value = {'test1':'test'}
    assert cls.source == 'main_value'


# Generated at 2022-06-22 18:30:44.723198
# Unit test for constructor of class Keys
def test_Keys():
    var = Keys('X')
    a = dict(x=1, y=2)
    result = dict(a.items())

    assert var.source == 'X'
    assert var._keys(a) == ['x', 'y']
    assert var._format_key('x') == '[x]'
    assert var._get_value(a, 'x') == result['x']
    assert var._safe_keys(a) == ['x', 'y']

#Unit test for constructor of class Attrs

# Generated at 2022-06-22 18:30:47.651811
# Unit test for constructor of class Exploding
def test_Exploding():
    assert(Exploding('').source == '')


# Unit tests for constructor of class Attrs

# Generated at 2022-06-22 18:30:55.401777
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    def frames():
        def f1():
            yield inspect.currentframe()
            1/0
        f1()
    for frame, exc in utils.get_frames_and_exceptions(frames()):
        break
    vars = (Attrs, Keys, Indices, Exploding)
    for var in vars:
        assert var('a').items(frame) == var('a').items(frame, normalize=True)

# Generated at 2022-06-22 18:31:00.717934
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys('x').source == 'x'
    assert Keys('x').exclude == ()
    assert Keys('x').code == compile('x', '<variable>', 'eval')
    assert Keys('x').unambiguous_source == 'x'
    assert Keys('x', 'y').exclude == ('y',)
    assert Keys('x.y').unambiguous_source == '(x.y)'
    assert Keys('x', exclude='y').exclude == ('y',)


# Generated at 2022-06-22 18:31:12.611218
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import fixtures
    from . import utils
    import sys

    def run(frame, text, result):
        result = '\n'.join(result)
        sys.stdout.write(text)
        sys.stdout.write('\n')
        actual_result = utils.indent(
            pprint.pformat(
                utils.format_variables(fixtures.Variable('x'), frame),
                width=100
            )
        )
        sys.stdout.write(actual_result)
        assert result == actual_result + '\n'

    run(
        {'x': 42},
        'Simple value',
        ['42']
    )


# Generated at 2022-06-22 18:31:20.736300
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code.co_code == compile('a', '<variable>', 'eval').co_code
    assert a.unambiguous_source == 'a'

    b = Attrs('b', 'c')
    assert b.source == 'b'
    assert b.exclude == ('c',)
    assert b.code.co_code == compile('b', '<variable>', 'eval').co_code
    assert b.unambiguous_source == 'b'


# Generated at 2022-06-22 18:31:27.847849
# Unit test for constructor of class Indices
def test_Indices():
    print ('Checking if the class Indices constructor does not fail')
    # Create a empty class
    class Empty:
        pass
    # Create a instance of the empty class
    empty = Empty()

    # Create a indices that uses the empty class instance
    indices = Indices('empty', exclude=())
    # Check if the items method returns a empty list
    if indices.items(empty) == ():
        print('Test succeeded')
    else:
        print('Test failed')


# Generated at 2022-06-22 18:31:28.677753
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('1 + 1')
    assert variable.items({}) == ''

# Generated at 2022-06-22 18:31:32.039978
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    result1 = Attrs('main_value').items(None)
    # print(result1)
    result2 = Attrs('main_value').items(None)
    # print(result2)
    result3 = Attrs('main_value').items(None)
    # print(result3)

# Generated at 2022-06-22 18:31:34.622762
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("var")
    # Any tests...
    assert isinstance(var[:], Indices)

test_Indices___getitem__()

# Generated at 2022-06-22 18:31:36.958824
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a',('a','b'))
    assert (attrs.source == 'a' and attrs.exclude == ['b','a'])

# Generated at 2022-06-22 18:31:45.144792
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable(source='user_name')
    v_source = v.source
    v_exclude = v.exclude
    v_code = v.code
    v_unambiguous_source = v.unambiguous_source
    assert v_source == v.source
    assert v_exclude == v.exclude
    assert v_code == v.code
    assert v_unambiguous_source == v.unambiguous_source
    assert hash(v) == hash(v_source)
    print('test_BaseVariable___hash__ passed')


# Generated at 2022-06-22 18:31:53.525301
# Unit test for function needs_parentheses
def test_needs_parentheses():
    needs = needs_parentheses

    assert needs('a')
    assert needs('a.b')
    assert needs('(a.b)')
    assert needs('a.b.c')
    assert not needs('(a).b.c')
    assert needs('a.b.c.d')
    assert not needs('(a.b).c.d')
    assert needs('a.b[c]')
    assert not needs('(a.b)[c]')
    assert needs('a.b[c].d')
    assert not needs('(a.b)[c].d')
    assert needs('a.b[c].d[e]')
    assert not needs('(a.b)[c].d[e]')

# Generated at 2022-06-22 18:32:03.139354
# Unit test for function needs_parentheses
def test_needs_parentheses():
    def foo():
        pass

    def foo1():
        return foo()

    def foo2():
        return foo()+'1'

    def foo3():
        return str(foo())

    def bar():
        pass

    assert needs_parentheses('x')
    assert needs_parentheses('function')
    assert needs_parentheses('foo1()')
    assert needs_parentheses('foo2()')
    assert needs_parentheses('foo3()')
    assert needs_parentheses('bar')
    assert not needs_parentheses('foo')
    assert not needs_parentheses('foo1().bar')
    assert not needs_parentheses('foo2().bar')
    assert not needs_parentheses('foo3().bar')
    assert not needs_parentheses('bar.foo')

# Generated at 2022-06-22 18:32:11.100854
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "mqtt_msg.payload"
    exclude = "mqtt_msg.payload.username"
    mqtt_msg = {
        "payload": {
            "username":"device_user",
            "password":"root",
            "imei":"1234567890"
        }
    }
    frame = {"mqtt_msg":mqtt_msg}
    result = BaseVariable(source, exclude).items(frame)
    base_var = BaseVariable(source, exclude)
    base_var.source = source
    base_var.exclude = exclude
    for s, v in result:
        print ({s:v})

# Generated at 2022-06-22 18:32:15.412579
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a=Exploding('a')
    b=Exploding('b')
    assert a==a
    assert b==b
    assert not a==b
test_BaseVariable___eq__()


# Generated at 2022-06-22 18:32:23.894610
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # BaseVariable.items function test
    # ============================================================
    # make sure the input parameter is suitable,
    # if not, raise a TypeError exception.
    # ============================================================
    frame = frame = f_globals = f_locals = {}
    frame['_x'] = x = {'a': 3}
    frame['_y'] = y = [4, 5]
    test_1 = Attrs('_x', exclude=())
    test_2 = Keys('_y', exclude=())
    test_3 = Indices('_y', exclude=('[0]',))
    test_4 = Exploding('_x', exclude=())

    assert test_1.items(frame) == \
           [('_x', '{}'), ('_x.a', '3')]

# Generated at 2022-06-22 18:32:30.114855
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def check(source, exclude=()):
        attrs = CommonVariable(source, exclude)
        assert attrs.source == source
        assert attrs.exclude == utils.ensure_tuple(exclude)
        assert isinstance(attrs.code, type(compile('1+1', '<string>', 'eval')))

    check('x')
    check('x', 'y')
    check('x', ('y', 'z'))



# Generated at 2022-06-22 18:32:40.221084
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert isinstance(BaseVariable("hello"), BaseVariable)
    assert isinstance(BaseVariable("hello, "), BaseVariable)
    assert isinstance(BaseVariable(""), BaseVariable)
    assert isinstance(BaseVariable("world"), BaseVariable)
    assert isinstance(BaseVariable("goodbye"), BaseVariable)
    assert isinstance(BaseVariable("?12"), BaseVariable)
    assert isinstance(BaseVariable("hello", ["hello"]), BaseVariable)
    assert isinstance(BaseVariable("hello", ["goodbye"]), BaseVariable)
    assert isinstance(BaseVariable("hello", ["world"]), BaseVariable)
    assert isinstance(BaseVariable("", [""]), BaseVariable)
    assert isinstance(BaseVariable("", [""]), BaseVariable)

# Generated at 2022-06-22 18:32:41.825043
# Unit test for constructor of class Keys
def test_Keys():
    keys = Keys('input')
    assert keys.source == 'input'



# Generated at 2022-06-22 18:32:47.384861
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'a.b.c'
    exclude = ('e', 'f')
    main_value = {'e': 'eleven', 'f': 'five'}
    x = Exploding(source, exclude)
    assert x.source == source
    assert x.exclude == exclude
    assert type(x.code) == type(compile('a', '<string>', 'eval'))

    assert x._items(main_value) == Keys(source, exclude)._items(main_value)

# Generated at 2022-06-22 18:32:58.224669
# Unit test for constructor of class Exploding

# Generated at 2022-06-22 18:33:03.713358
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    bv = BaseVariable('self')
    assert bv.source == 'self'
    assert bv.exclude == ()
    assert bv.code == compile('self', '<variable>', 'eval')
    assert bv.unambiguous_source == 'self'
    return bv


# Generated at 2022-06-22 18:33:06.995732
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding(source='**kwargs', exclude=[])
    assert isinstance(var,Exploding)
    assert isinstance(var,BaseVariable)



# Generated at 2022-06-22 18:33:09.828479
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    v = BaseVariable('x')
    assert v.source == 'x'
    assert v.exclude == ()
    assert v.code == compile('x', '<variable>', 'eval')
    assert v.unambiguous_source == 'x'

# Generated at 2022-06-22 18:33:18.943211
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for Attrs class
    from pprint import pprint
    from collections import namedtuple
    from .utils import get_shortish_repr
    from .variables import Attrs
    
    Test = namedtuple('Test', ('x', 'y'))
    foo = Test([1, 2], Test(3, 4))
    a = Attrs('foo')
    b = Attrs('foo', exclude='x')
    c = Attrs('foo', exclude=['x', 'y'])
    d = Attrs('foo', exclude=['x'])
    pprint(a.items(foo))
    pprint(b.items(foo))
    pprint(c.items(foo))
    pprint(d.items(foo))

    # test for Keys class
    from pprint import pprint

# Generated at 2022-06-22 18:33:24.349203
# Unit test for constructor of class Exploding
def test_Exploding():
    source = 'source'
    exclude = (1, 2)
    assert Exploding(source, exclude).source == source
    assert Exploding(source, exclude).exclude == exclude
    assert Exploding(source, exclude).code == compile(source, '<variable>', 'eval')
    assert Needs_parentheses(source)
    assert not Needs_parentheses('(source)')


# Generated at 2022-06-22 18:33:28.744025
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable("source", "exclude")
    assert(bv == bv)
    assert(not bv == "Source")
    bv1 = BaseVariable("source1", "exclude")
    assert(not bv == bv1)

# Generated at 2022-06-22 18:33:33.486933
# Unit test for constructor of class Exploding
def test_Exploding():
    test_case = [1, 2, 3]
    res = Exploding("test_case")
    assert res.source == "test_case"
    assert res.exclude == ()


# Generated at 2022-06-22 18:33:43.350093
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    def assert_source_code(source, wanted_code):
        wanted_code = wanted_code.replace(' ', '') # Remove spaces
        assert compile(source, '<variable>', 'eval').co_code == wanted_code
    assert_source_code('a', 'LOAD_NAME0STORE_NAME0')
    assert_source_code('({})', 'LOAD_NAME0STORE_NAME0')
    assert_source_code('(a)', 'LOAD_NAME0STORE_NAME0')
    assert_source_code('(a).b', 'LOAD_NAME0LOAD_ATTR1STORE_NAME0')
    assert_source_code('(a).b.c', 'LOAD_NAME0LOAD_ATTR1LOAD_ATTR2STORE_NAME0')

# Generated at 2022-06-22 18:33:55.614617
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    # needs_parentheses
    assert needs_parentheses('a.b')
    assert not needs_parentheses('a[0]')
    assert not needs_parentheses('a')
    assert not needs_parentheses('1')
    assert needs_parentheses('a and b[0]')
    assert needs_parentheses('a or b[0]')
    assert not needs_parentheses('a[0] or b[0]')

    # BaseVariable.__init__
    s = 'a[0]'
    var = BaseVariable(s)
    assert var.source == s
    assert var.exclude == ()
    assert var.code == compile(s, '<variable>', 'eval')
    assert var.unambiguous_source == s

    s = 'a.b'
    var = BaseVariable(s)

# Generated at 2022-06-22 18:34:05.729023
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('foo')

    assert not needs_parentheses('(foo)')
    assert not needs_parentheses('(foo().bar)')
    assert not needs_parentheses('(foo().bar().baz())')
    assert not needs_parentheses('type(foo)')
    assert not needs_parentheses('id(foo)')
    assert not needs_parentheses('foo.bar')
    assert not needs_parentheses('foo().bar')
    assert not needs_parentheses('foo[bar]')
    assert not needs_parentheses('foo()[bar]')
    assert not needs_parentheses('foo.bar.baz')
    assert not needs_parentheses('foo().bar.baz')
    assert not needs_parentheses('foo().bar().baz')

# Generated at 2022-06-22 18:34:08.868561
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert len(set([
        BaseVariable('foo.bar', ()),
        BaseVariable('foo.bar', ()),
        BaseVariable('foo.bar', ('baz',)),
        BaseVariable('foo.bar', ('baz',)),
    ])) == 3

# Generated at 2022-06-22 18:34:14.106075
# Unit test for constructor of class Indices
def test_Indices():
    a = [1,2,3,4,5]
    indices = Indices("a")
    assert(indices._slice == slice(None))
    indices_2 = indices[2:]
    assert(indices_2._slice == slice(2,None))
    assert(indices_2._keys(a) == [2,3,4])

# Generated at 2022-06-22 18:34:19.485227
# Unit test for constructor of class Exploding
def test_Exploding():
    from .utils import get_test_frame
    frame, frame_data = get_test_frame()
    variables = Exploding(frame_data['a']['b']['c']['d'].source, 'e').items(frame)
    assert len(variables) == 5, variables


# Generated at 2022-06-22 18:34:20.535946
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable("cv")


# Generated at 2022-06-22 18:34:21.338390
# Unit test for constructor of class Exploding
def test_Exploding():
    v = Exploding('foo')

var = Exploding

# Generated at 2022-06-22 18:34:28.110636
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    eq_(Attrs('a', 'b'), Attrs('a', 'b'))
    assert Attrs('a', 'b') != Attrs('a', 'c')
    assert Attrs('a', 'b') != Attrs('b', 'c')
    assert Attrs('a', 'b') != Attrs('a')
    assert Attrs('a', 'b') != Keys('a', 'b')
    assert Attrs('a', 'b') != Indices('a', 'b')
    assert Attrs('a', 'b') != Exploding('a', 'b')
    assert Attrs('a', 'b') != Keys('a', 'b')
    assert Attrs('a', 'b') != Indices('a', 'b')
    assert Attrs('a', 'b') != Exploding('a', 'b')

# Generated at 2022-06-22 18:34:33.545694
# Unit test for constructor of class Keys
def test_Keys():
    m = {'a': 1, 'b': 2, 'c': 3}
    source = 'm'
    exclude = {'b'}
    k = Keys(source, exclude)
    print(k.source, k.exclude, k._items(m))


# Generated at 2022-06-22 18:34:36.062362
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    variable = BaseVariable('a', 'b')
    assert variable.__hash__() == (-509414084, 'a', ('b',))


# Generated at 2022-06-22 18:34:38.541330
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('a')
    assert needs_parentheses('(a)')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a[0]')

# Generated at 2022-06-22 18:34:48.400666
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    # Class implementation of BaseVariable
    class Attrs(BaseVariable):
        def _items(self, main_value, normalize=False):
            result = [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]
            for key in self._safe_keys(main_value):
                try:
                    if key in self.exclude:
                        continue
                    value = self._get_value(main_value, key)
                except Exception:
                    continue
                result.append((
                    '{}{}'.format(self.unambiguous_source, self._format_key(key)),
                    utils.get_shortish_repr(value)
                ))
            return result


# Generated at 2022-06-22 18:34:58.111563
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import __main__
    class DummyVariable(BaseVariable):
        _items = BaseVariable._items
        def __call__(self, frame, normalize=False):
            return self.items(frame, normalize)
    class DummyVariableNoCall(DummyVariable):
        def __call__(self, frame, normalize=False):
            pass
    # Test BaseVariable instantiation
    var = DummyVariable(source='var', exclude=['var.x'])
    var.source == 'var'
    var.exclude == ('var.x',)
    var.code == compile('var', '<variable>', 'eval')
    var.unambiguous_source == 'var'
    assert isinstance(var, BaseVariable)
    # Test BaseVariable.items

# Generated at 2022-06-22 18:35:04.487675
# Unit test for constructor of class Exploding
def test_Exploding():
    test_dict={'k1':'v1','k2':'v2','k3':'v3'}
    test_list=['a','b','c']
    test_object=Exploding('test')
    assert test_object._items(test_dict) == Keys('test')._items(test_dict)
    assert test_object._items(test_list) == Indices('test')._items(test_list)



# Generated at 2022-06-22 18:35:11.522409
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable("line") == CommonVariable("line")
    assert CommonVariable("line") != CommonVariable("line1")
    assert CommonVariable("line") != None
    assert CommonVariable("line") != "line"
    assert CommonVariable("line", exclude = 'obj') != CommonVariable("line")
    assert CommonVariable("line", exclude = 'obj') == CommonVariable("line", exclude = 'obj')
    assert CommonVariable("line", exclude = 'obj') != CommonVariable("line", exclude = 'ob')

# Generated at 2022-06-22 18:35:22.293588
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('foo')
    assert needs_parentheses('(foo)')
    assert needs_parentheses('foo.x')
    assert needs_parentheses('foo()')
    assert needs_parentheses('foo().x')
    assert needs_parentheses('x[0]')
    assert needs_parentheses('x[0].y')
    assert not needs_parentheses('(x[0])')
    assert not needs_parentheses('(x[0])[1]')
    assert not needs_parentheses('((x)[0])[1]')
    assert not needs_parentheses('(x).y')
    assert not needs_parentheses('x.y[1]')
    assert not needs_parentheses('(x).y().z')
    assert not needs_parentheses('(x).y[1].z')

# Generated at 2022-06-22 18:35:27.694680
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    cases = [
        # inputs, expected
        (NeedsParentheses('foo'), True),
        (NeedsParentheses('foo'), True),
        (NeedsParentheses('bar'), True),
        (NeedsParentheses('bar'), True),
        (NeedsParentheses('foo', 1), True),
        (NeedsParentheses('foo', 2), True),
    ]
    for case in cases:
        inputs, expected = case
        assert hash(inputs) == hash(inputs), 'inputs: {}'.format(inputs)


# Generated at 2022-06-22 18:35:28.902446
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert isinstance(BaseVariable(''), BaseVariable)

# Generated at 2022-06-22 18:35:30.757717
# Unit test for constructor of class Keys
def test_Keys():
    main_value = {'x':3}
    print(Keys('x')._items(main_value))


# Generated at 2022-06-22 18:35:33.901412
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    dic = {'a':'aa'}
    assert Indices('', '')[1:] == dic[1:]
    assert Indices('', '')[2:4] == dic[2:4]


# Generated at 2022-06-22 18:35:35.038704
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('myobj'), BaseVariable)

# Generated at 2022-06-22 18:35:38.222396
# Unit test for constructor of class Exploding
def test_Exploding():
    ex = Exploding('ra')
    assert ex.source == 'ra'
    assert ex.exclude == ()
    assert ex.code == compile('ra', '<variable>', 'eval')
    assert ex.unambiguous_source == 'ra'
    assert ex._items(1) == [('ra', '1')]


# Generated at 2022-06-22 18:35:41.709741
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    for i in [10,30,50,250]:
        v = Indices('var')[i:]
        assert i == len(v.items(None)[-1][0])

# Generated at 2022-06-22 18:35:43.903538
# Unit test for constructor of class Indices
def test_Indices():
    Indices('foo')
    Indices('foo', 'bar')
    Indices('foo', ['bar'])
    Indices('foo', 'bar')

# Generated at 2022-06-22 18:35:45.563820
# Unit test for constructor of class Attrs
def test_Attrs():
    s = 'a.b'
    v = Attrs(s)
    assert (v.source == s)

# Generated at 2022-06-22 18:35:56.067501
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'source'
    exclude = 'exclude'
    # create base variable
    variables = [BaseVariable(source=source, exclude=exclude),
                 BaseVariable(source=source),
                 BaseVariable(exclude=exclude),
                ]
    # check if source and exclude is equals
    for v1 in variables:
        for v2 in variables:
            if v1.source == v2.source and v1.exclude == v2.exclude:
                assert v1 == v2
                assert hash(v1) == hash(v2)
            else:
                assert v1 != v2
                assert hash(v1) != hash(v2)