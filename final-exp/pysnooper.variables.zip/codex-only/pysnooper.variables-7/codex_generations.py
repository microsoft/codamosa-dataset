

# Generated at 2022-06-22 18:25:53.556430
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    print('Start test_BaseVariable')
    assert BaseVariable('a').__hash__() == BaseVariable('a').__hash__()

# Generated at 2022-06-22 18:26:02.426696
# Unit test for constructor of class Exploding
def test_Exploding():
    obj = {'a':5, 'b':{'c':10}}
    exp = Exploding('obj')
    assert exp._items(obj) == [('obj.a', '5'), ('obj.b', '{...}'), ('obj.b.c', '10')]

    arr = ['a']
    exp2 = Exploding('arr')
    assert exp2._items(arr) == [('arr', '["a"]'), ('arr[0]', '"a"')]

    class Test:
        x = 5
        def __init__(self):
            self.y = 10

    tst = Test()
    exp3 = Exploding('tst')
    assert exp3._items(tst) == [('tst', 'Test'), ('tst.x', '5'), ('tst.y', '10')]

# Generated at 2022-06-22 18:26:08.977412
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    # Test for method __hash__ of class BaseVariable (1/3)

    assert hash(BaseVariable('x', exclude=('y',))) == hash(BaseVariable('x', exclude=('y',)))
    assert hash(BaseVariable('x', exclude=('y',))) != hash(BaseVariable('x', exclude=('y', 'z')))
    assert hash(BaseVariable('x', exclude=('y',))) != hash(BaseVariable('x'))
    assert hash(BaseVariable('x', exclude=('y',))) != hash(Keys('x'))


# Generated at 2022-06-22 18:26:14.767896
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert not (Attrs('a') == Attrs('b'))
    assert Attrs('a', 'b') == Attrs('a', 'b')
    assert not (Attrs('a', 'b') == Attrs('a', 'c'))
    assert Attrs('a', exclude='b') == Attrs('a', exclude=['b'])
    assert Attrs('a').exclude == ()
    assert Attrs('a', ()).exclude == ()

# Generated at 2022-06-22 18:26:21.512833
# Unit test for constructor of class Keys
def test_Keys():
    test_value = {'key': 'value'}
    test_key = 'key'
    result_key_init = Keys('test_value')
    assert (result_key_init.source == 'test_value')
    result_key = Keys(test_value, test_value.keys())
    result_value = result_key.items(test_value)
    assert (result_value == [('test_value[\'key\']', '\'value\'')])


# Generated at 2022-06-22 18:26:28.629477
# Unit test for constructor of class Attrs
def test_Attrs():
    att = Attrs('x');
    assert att._fingerprint == (Attrs, 'x', tuple())
    assert att.__hash__() == hash(att._fingerprint)
    assert hash(att) == hash(att._fingerprint)
    att = Attrs('x', 'y')
    assert att._fingerprint == (Attrs, 'x', ('y',))
    assert att.__hash__() == hash(att._fingerprint)
    assert hash(att) == hash(att._fingerprint)

# Generated at 2022-06-22 18:26:36.017065
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pytest
    from . import utils

    variables = [('x', '1'), ('x.y', '2')]
    items = BaseVariable('x.y').items(variables)
    assert utils.sort(items, key=lambda x: x[0]) == [
        ('x', '1'), ('x.y', '2')]

    variables = [('x', {'y': {'z': '0'}}), ('x.y', {'z': '1'})]
    items = BaseVariable('x.y').items(variables)
    assert utils.sort(items, key=lambda x: x[0]) == [
        ('x', {'y': {'z': '0'}}), ('x.y', {'z': '1'})]


# Generated at 2022-06-22 18:26:47.068449
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import Frame
    from . import Code
    code = Code(
        "def funny(x):\n"
        "  for i in range(2):\n"
        "    locals()[i] = 'spam'[i]\n"
        "    for j in range(2):\n"
        "      locals()[i, j] = 'spam'[i + j]\n"
        "  return x + y\n"
        "funny(1)"
    )
    frame = Frame(code, {})
    frame.f_locals['x'] = 1
    frame.f_locals['y'] = 2

# Generated at 2022-06-22 18:26:55.747404
# Unit test for constructor of class Indices
def test_Indices():
    a = Indices('test')
    assert a.source == 'test'
    assert a.exclude == ()
    assert a.unambiguous_source == 'test'
    assert a.code is not None
    assert a._fingerprint == (Indices, 'test', ())
    assert hash(a) != 0
    assert a == Indices('test')
    assert a != Indices('test2')
    assert not isinstance(12, Indices)
    assert isinstance(Indices('test'), Indices)
    assert a[1:2] == Indices('test', ()).__getitem__(1)



# Generated at 2022-06-22 18:27:02.698311
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a[b]') is False
    assert needs_parentheses('a[b].c') is False
    assert needs_parentheses('f(a, b)') is False
    assert needs_parentheses('a(b)') is True
    assert needs_parentheses('a + b') is True
    assert needs_parentheses('a - b') is True
    assert needs_parentheses('-a') is True



# Generated at 2022-06-22 18:27:07.067186
# Unit test for constructor of class Indices
def test_Indices():
    index = Indices('__builtins__')[1:3]
    assert index == slice(1, 3, None)
    print(index)

# Generated at 2022-06-22 18:27:10.229257
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    expected = [('.x', '1'), ('.y', '2')]
    actual = Indices('main_value', exclude='__len__').__getitem__(slice(2)).items(main_value)
    assert expected == actual

# Generated at 2022-06-22 18:27:13.458922
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a_variable1 = BaseVariable(source=6, exclude=6)
    a_variable2 = BaseVariable(source=6, exclude=6)
    assert a_variable1 == a_variable2

# Generated at 2022-06-22 18:27:23.668561
# Unit test for constructor of class Keys
def test_Keys():
    k=Keys('a',('abc','def'))
    # test code compilation
    assert k.code == compile('a', '<variable>', 'eval')

    # test _safe_keys
    a = {'a':1,'b':2,'c':3}
    assert [key for key in k._safe_keys(a)] == ['a','b','c']
    a = []
    assert [key for key in k._safe_keys(a)] == []
    a = ''
    assert [key for key in k._safe_keys(a)] == []

    # test _keys
    assert [key for key in k._keys(a)] == []
    a = [1,2,3]
    assert [key for key in k._keys(a)] == [0,1,2]

# Generated at 2022-06-22 18:27:31.267217
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert Attrs('a', exclude=['b']).items({'a': {'b': 1}}) == [
        ('a', "{'b': 1}"),
        ('a.b', '1')
    ]
    assert Attrs('a[0]', exclude=['_'])({'a': [{'_':1}]}) == [
        ('a[0]', "{'_': 1}"),
        ('a[0]._', '1')
    ]

# Generated at 2022-06-22 18:27:38.359877
# Unit test for constructor of class Attrs
def test_Attrs():
    import sys
    import inspect
    from . import utils

    def test_Attrs_results(source, exclude):
        frame = inspect.currentframe()
        variable = Attrs(source, exclude)
        # variable.source:text, variable.exclude:tuple, variable.code:code
        print("(1)variable.source:{0}, variable.exclude:{1}, variable.code:{2}".format(variable.source, variable.exclude, variable.code))
        # variable.code:code -> eval -> code:code

# Generated at 2022-06-22 18:27:42.695416
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code == compile('a', '<variable>', 'eval')
    assert a.unambiguous_source == 'a'
    assert a.items(frame=0) == ()


# Generated at 2022-06-22 18:27:44.740659
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var = BaseVariable('b')
    assert var == var
    assert not (var == object())


# Generated at 2022-06-22 18:27:48.263322
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('mydict', exclude=('a',))
    var.source
    var.exclude
    var.code
    var.unambiguous_source
    return True


# Generated at 2022-06-22 18:27:53.935677
# Unit test for constructor of class Attrs
def test_Attrs():
    import unittest
    class TestAttrs(unittest.TestCase):
        def  setUp(self):
            pass
        def  tearDown(self):
            pass
        def test_newAttrs(self):
            var = Attrs("test")
            self.assertEqual(var.source, "test")
            mapper = {'test':'a', 'test2':'b'}
            print(var._items(mapper))
            self.assertEqual(var._items(mapper), [('test', "'a'"), ('test2', "'b'")])
    unittest.main()


# Generated at 2022-06-22 18:27:56.173860
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_Indices = Indices('a',())
    expected = Indices('a',())
    expected._slice = slice(1,4,2)
    assert test_Indices[1:4:2] == expected

# Generated at 2022-06-22 18:28:00.597691
# Unit test for constructor of class Keys
def test_Keys():
    # Creating an empty instance of Keys class
    k = Keys('1')
    # Asserting that the instance is an instance of CommonVariable
    assert isinstance(k, CommonVariable)
    # Asserting that the class of k is Keys
    assert k.__class__ == Keys


# Generated at 2022-06-22 18:28:02.524308
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable('a')
    assert hash(v) == hash((type(v), 'a'))


# Generated at 2022-06-22 18:28:06.927905
# Unit test for constructor of class Keys
def test_Keys():
    # Arrange
    items = [1, 2, 3]
    obj = Keys('items')

    # Act
    items = obj._items(items)

    # Assert
    assert items == [('items', '[1, 2, 3]'), ('items[0]', '1'), ('items[1]', '2'), ('items[2]', '3')]

# Generated at 2022-06-22 18:28:08.535772
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('0')
    var[5:7]
    var[::2]



# Generated at 2022-06-22 18:28:14.078709
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    main_value = {}
    keys_value = Keys('source')._items(main_value)
    assert keys_value == [('source', '{}')]
    indices_value = Indices('source')._items(main_value)
    assert indices_value == [('source', '[]')]
    attrs_value = Attrs('source')._items(main_value)
    assert attrs_value == [('source', '{}')]
    exploding_value = Exploding('source')._items(main_value)
    assert exploding_value == [('source', '{}')]

# Generated at 2022-06-22 18:28:20.015261
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    frame = sys._getframe()
    variable = BaseVariable(".f_globals['__name__']",)
    result = variable.items(frame, normalize=True)
    assert isinstance(result, tuple)
    assert result[0][0] == ".f_globals['__name__']"
    assert result[0][1] == "'__main__'"

# Generated at 2022-06-22 18:28:20.985791
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    a = CommonVariable("")


# Generated at 2022-06-22 18:28:30.661493
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    class A:
        x = 10
        y = 11
        z = 12
    a = A()
    with utils.captured_output() as (out, err):
        b = BaseVariable('a.x')
        b.items(a)
    output = out.getvalue().strip()
    assert output == 'a.x = 10'
    class B:
        x = A()
        z = 11
    b = B()

    with utils.captured_output() as (out, err):
        c = Keys('b')
        c.items(b)
    output = out.getvalue().strip()
    assert output == '''\
b[x] = <__main__.A object at 0x7f30d1a185f8>
b[z] = 11'''



# Generated at 2022-06-22 18:28:34.731040
# Unit test for constructor of class Keys
def test_Keys():
    d = {"a":1, "b":2}
    instance = Keys("keys", d)
    if instance.source != "keys":
        print("False")
    if instance._format_key("a") != "[a]":
        print("False")
    if instance._get_value(d, "a") != 1:
        print("False")
    if instance._keys(d) != ["a", "b"]:
        print("False")

# Generated at 2022-06-22 18:28:40.238462
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs("a")
    print(a.source)
    print(a.code)
    print(a.unambiguous_source)
    print(type(a).__name__)
    b = (a.source, Attrs.__name__)
    print(a._fingerprint)
    print(Attrs("a") == Attrs("a"))
    print(Attrs("a"))
    print(hash(Attrs("a")))
    print(Attrs("a", exclude="a"))
    print(Attrs("a", exclude=(1, 2)))
    print(Attrs("a").items(None))


# Generated at 2022-06-22 18:28:52.294430
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # test__getitem__(self: Indices[Tuple[int, int]]) -> None
    # source: source, source_type: source_type, target: target, member_result: member_result, target_count: target_count

    # setup
    source = 'source'
    source_type = 'source_type'
    target = 'target'
    member_result = 'member_result'
    target_count = 5

    indices = Indices(source_type)
    # temp method to generate temp global variables for test case
    def create_temp_variables():
        pass
    create_temp_variables.__code__ = compile('', '<string>', 'exec')
    frame = inspect.currentframe()
    frame.f_globals.update(locals())

    # act
    indices1 = indices

# Generated at 2022-06-22 18:28:55.998534
# Unit test for constructor of class Attrs
def test_Attrs():
    var = Attrs('foo', exclude=('__dict__',))
    assert var.source == 'foo'
    assert var.exclude == ('__dict__',)
    assert var.code == compile('foo', '<variable>', 'eval')
    assert var.unambiguous_source == 'foo'


# Generated at 2022-06-22 18:29:06.731194
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 验证方法__eq__()对对象属性source、exclude的处理
    # 验证方法__eq__()对对象类型的处理（需要判断是否属于类BaseVariable）
    # 验证方法__eq__()对None的处理
    # 验证方法__eq__()对属性source为整形、元组、字符串、列表等的处理
    assert BaseVariable('source', 'exclude') == BaseVariable('source', 'exclude')
   

# Generated at 2022-06-22 18:29:11.597655
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from inspect import isclass
    from .utils import get_shortish_repr
    assert 'CommonVariable' in str(CommonVariable)
    assert 'BaseVariable' in str(BaseVariable)
    assert isclass(CommonVariable)
    assert not isclass(CommonVariable('test'))
    assert '10' in get_shortish_repr(CommonVariable('test'))



# Generated at 2022-06-22 18:29:14.823616
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    assert v1 == v2 and v1 != v3



# Generated at 2022-06-22 18:29:21.045126
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'a'
    exclude = '__dict__', '__slots__'
    main_value = [0,1,2,3]
    result = Indices(source, exclude)
    item = slice(1,3)
    expected_value = Indices(source, exclude)[item]
    result_value = result.__getitem__(item)
    assert(result_value == expected_value)


# Generated at 2022-06-22 18:29:25.084472
# Unit test for constructor of class Keys
def test_Keys():
    d = {1:11, 2:22}
    d['a'] = 'aaa'
    d[None] = 'none'
    o = Keys('d', exclude='a')
    l = o.items(frame=None)
    assert len(l)==3



# Generated at 2022-06-22 18:29:34.925477
# Unit test for function needs_parentheses
def test_needs_parentheses():
    print('Test the function needs_parentheses()')
    assert needs_parentheses('a.b') == False, "needs_parentheses('a.b') is not False"
    assert needs_parentheses('a.b()') == True, "needs_parentheses('a.b()') is not True"
    assert needs_parentheses('a.b.c') == False, "needs_parentheses('a.b.c') is not False"
    assert needs_parentheses('a.b.c()') == True, "needs_parentheses('a.b.c()') is not True"
    assert needs_parentheses('a.b.c.d') == False, "needs_parentheses('a.b.c.d') is not False"

# Generated at 2022-06-22 18:29:37.716252
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo')[1:] == Indices('foo', slice(1, None))
    assert Indices('foo')[::-1] == Indices('foo', slice(None, None, -1))

# Generated at 2022-06-22 18:29:38.240896
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    pass

# Generated at 2022-06-22 18:29:49.260497
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from framequery.query import CommonVariable
    from framequery.qdata import Attrs, Keys, Indices
    import inspect
    
    # Test for constructor of class Attrs
    assert(type(CommonVariable('a', 'b')) == Attrs)
    
    # Test for constructor of class Keys
    def is_mapping_view(v):
        return inspect.isclass(type(v)) and issubclass(type(v), collections.abc.MappingView)
    
    assert(type(CommonVariable(dict(), 'b')) == Keys)
    assert(type(CommonVariable(collections.OrderedDict(), 'b')) == Keys)
    assert(type(CommonVariable(collections.Counter(), 'b')) == Keys)

# Generated at 2022-06-22 18:29:57.944481
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys

    class TestClass:
        a = 1
        b = [2, 3, 4]
        c = {'one': 5, 'two': 6}

    def test():
        a = 0
        b = [1, 2, 3]
        c = {'one': 4, 'two': 5}
        def inner():
            nonlocal a
            a += 1
            return a
        return inner()

    import warnings
    warnings.filterwarnings("error")
    sys.setcheckinterval(sys.maxsize)

    tc = TestClass()
    res1 = Attrs('tc').items(sys._getframe())
    res2 = Attrs('tc.a').items(sys._getframe())
    res3 = Attrs('tc.d').items(sys._getframe())

# Generated at 2022-06-22 18:30:06.690698
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class Var(CommonVariable):
        _keys = lambda *args: ()
        _format_key = lambda *args: ''
        _get_value = lambda *args: None

    value = {'a': 1, 'b': 2}
    source = 'value'
    exclude = ('b', 'b', 'a')
    var = Var(source, exclude)

    assert var.source == source
    assert var.exclude == exclude
    assert var.code == compile(source, '<variable>', 'eval')
    assert var.unambiguous_source == source

    assert var.items(1) == [('value', '{...}')]
    assert var._safe_keys(value) == ()
    assert var._format_key('') == ''
    assert var._get_value(1, '') is None


# Generated at 2022-06-22 18:30:14.010026
# Unit test for constructor of class Attrs
def test_Attrs():
    # create an instance of class Attrs
    # input the source code
    a = Attrs('a')
    # test the method '_keys'
    assert a._keys('ab') == ['__dict__', '__slots__']
    # test the method '_format_key'
    assert a._format_key('b') == '.b'
    # test the method '_get_value'
    class A:
        b = 'b'
    assert a._get_value(A(), 'b') == 'b'
    # test the method 'items'
    assert a.items({}) == [('a.__dict__', '{}'), ('a.__slots__', '()')]
    # test the method '__hash__'

# Generated at 2022-06-22 18:30:23.634773
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a') is False
    assert needs_parentheses('a.b') is False
    assert needs_parentheses('a.b.c') is False
    assert needs_parentheses('a.b["c"]') is False
    assert needs_parentheses('a.b.c[1]') is False

    # The needs_parentheses heuristics are not perfect and the following
    # examples need to be considered edge cases.
    assert needs_parentheses('a[1]') is True
    assert needs_parentheses('a.b[1]') is True
    assert needs_parentheses('a[1].b') is True
    assert needs_parentheses('a.b[1].c') is True

    assert needs_parentheses('a.b.c[1] + 1') is False
    assert needs_parentheses

# Generated at 2022-06-22 18:30:26.113084
# Unit test for constructor of class Attrs
def test_Attrs():
    class A(object):
        a = 1

    assert Attrs('.a').items(locals()) == [('.a', '1'), ('.a.a', '1')]

# Unit tests for constructor of class Keys

# Generated at 2022-06-22 18:30:37.601963
# Unit test for constructor of class Attrs
def test_Attrs():
    # Case1: has __dict__ and __slots__
    class A(object):
        __slots__ = 'a','b','c','d','e','f','g'
        def __init__(self):
            self.a = '1'
            self.b = '2'
            self.c = '3'
            self.d = '4'
            self.e = '5'
            self.f = '6'
    a = A()
    testA = Attrs('a',exclude=())

# Generated at 2022-06-22 18:30:41.062597
# Unit test for constructor of class Keys
def test_Keys():
    x = 5
    assert Keys('x').items(frame=None) == [('x', str(x))]
    assert Keys('x').items(frame=None, normalize=True) == [('x', '5')]

# Generated at 2022-06-22 18:30:42.038167
# Unit test for constructor of class Attrs
def test_Attrs():
    pass


# Generated at 2022-06-22 18:30:48.780553
# Unit test for constructor of class Exploding
def test_Exploding():
    # test for Mapping type
    assert(Exploding('a') == Keys('a'))
    assert(Exploding('a', exclude='b') == Keys('a', exclude='b'))
    assert(Exploding('a')[0:1] == Keys('a')[0:1])
    assert(Exploding('a', exclude='b')[0:1] == Keys('a', exclude='b')[0:1])
    
    # test for Sequence type
    assert(Exploding('a') == Indices('a'))
    assert(Exploding('a', exclude='b') == Indices('a', exclude='b'))
    assert(Exploding('a')[0:1] == Indices('a')[0:1])

# Generated at 2022-06-22 18:30:53.850254
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('x', exclude=['foo', 'bar'])
    assert a.source=='x'
    assert a.exclude==('foo', 'bar')

# Generated at 2022-06-22 18:30:57.855213
# Unit test for constructor of class Keys
def test_Keys():
    main_value = {'name':'Hai', 'number':23}
    # main_value = ('Tran', 23)
    data = Keys('main_value')
    assert data._keys(main_value) == main_value.keys()
    # assert data._keys(main_value) == range(len(main_value))



# Generated at 2022-06-22 18:31:04.014960
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('') is False
    assert needs_parentheses('x') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x.y.z') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('(x).y') is False
    assert needs_parentheses('x[0]') is False
    assert needs_parentheses('x[0].y') is False
    assert needs_parentheses('x.y[0]') is False
    assert needs_parentheses('(x)') is False
    assert needs_parentheses('{x}') is True
    assert needs_parentheses('{x}.y') is False
    assert needs_parentheses('{x}.y[0]') is False

# Generated at 2022-06-22 18:31:08.586312
# Unit test for constructor of class Indices
def test_Indices():
    iv = Indices('p', exclude=('__dict__', '__weakref__'))
    assert iv.source == 'p'
    assert iv.exclude == ('__dict__', '__weakref__')



# Generated at 2022-06-22 18:31:09.713064
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('x')
    

# Generated at 2022-06-22 18:31:11.466531
# Unit test for constructor of class Exploding
def test_Exploding():
    print(Exploding('b'))
    print(Exploding('b', exclude=['x']))

# Generated at 2022-06-22 18:31:18.165601
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('a')
    a2 = BaseVariable('a')
    assert a1 == a2
    a3 = BaseVariable('a', exclude=('a'))
    assert a1 != a3
    a4 = BaseVariable('a', exclude=('a'))
    assert a3 == a4
    a5 = BaseVariable('a', exclude=('a', 'b'))
    assert a3 != a5
    a6 = BaseVariable('a', exclude=('a', 'b'))
    assert a5 == a6
    b1 = BaseVariable('b')
    assert a1 != b1
    b2 = BaseVariable('b')
    assert b1 == b2
    assert a1 != b2
if __name__ == '__main__':
    test_BaseVariable___eq__()

# Generated at 2022-06-22 18:31:29.556146
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import SimpleNamespace
    frame = SimpleNamespace()
    frame.f_locals = {
        'a': 1,
        'b': 2,
        'c': 3,
        'mydict': {'a': 5, 'b': 6, 'c': 7},
        'mylist': [8, 9, 10]
    }
    frame.f_globals = {'d': 3, 'e': 4, 'f': 5}
    myobj = SimpleNamespace()
    myobj.__dict__ = {'d': 11, 'e': 12, 'f': 13}
    frame.f_locals['myobj'] = myobj
    # test for method items of class BaseVariable

# Generated at 2022-06-22 18:31:31.888608
# Unit test for constructor of class Indices
def test_Indices():
    i1 = Indices('main_value')
    assert i1._slice == slice(None, None)
    i2 = Indices('main_value')[3:]
    assert i2._slice == slice(3, None)

# Generated at 2022-06-22 18:31:36.309337
# Unit test for constructor of class Attrs
def test_Attrs():
    source = 'a'
    exclude = ('a', 'b')
    expected = (source, ('a', 'b'))

    attrs = Attrs(source, exclude)

    assert attrs.source == expected[0]
    assert attrs.exclude == expected[1]



# Generated at 2022-06-22 18:31:40.346675
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('x')
    var2 = BaseVariable('x')
    var3 = BaseVariable('x', exclude=('y'))
    assert (var1 == var2)
    assert (not (var1 == var3))
    assert (not (var1 == 'x'))


# Generated at 2022-06-22 18:31:51.210972
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    class TestBaseVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    variable_1 = TestBaseVariable('source', exclude=())
    variable_2 = TestBaseVariable('source', exclude=())
    variable_3 = TestBaseVariable('other', exclude=())
    variable_4 = TestBaseVariable('source', 'exclude')
    variable_5 = TestBaseVariable('source', 'exclude')
    variable_6 = TestBaseVariable('source', 'other')
    assert hash(variable_1._fingerprint) == hash(variable_2._fingerprint)
    assert hash(variable_1._fingerprint) != hash(variable_3._fingerprint)
    assert hash(variable_1._fingerprint) != hash(variable_4._fingerprint)

# Generated at 2022-06-22 18:32:00.680686
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v1:BaseVariable = BaseVariable('a');
    v2:BaseVariable = BaseVariable('b');
    v3:BaseVariable = BaseVariable('a');
    v4:BaseVariable = BaseVariable('b');
    print('hash_v1:', hash(v1))
    print('hash_v2:', hash(v2))
    print('hash_v3:', hash(v3))
    print('hash_v4:', hash(v4))
    assert(hash(v1) != hash(v2))
    assert(hash(v1) == hash(v3))
    assert(hash(v1) != hash(v4))
    assert(hash(v2) == hash(v4))


# Generated at 2022-06-22 18:32:07.200508
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    """Tests for CommonVariable constructor.

    """
    # Should fail if source is not string
    with pytest.raises(TypeError):
        CommonVariable(123)
    # Should fail if exclude is not iterable
    with pytest.raises(TypeError):
        CommonVariable('x', 123)


# Unit tests for method _safe_keys of class CommonVariable

# Generated at 2022-06-22 18:32:09.855000
# Unit test for constructor of class Indices
def test_Indices():
    var = Indices('var_name')
    assert var.source == 'var_name'
    assert var.exclude == ()
    assert var.code
    assert var.unambiguous_source == 'var_name'

# Generated at 2022-06-22 18:32:21.246586
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    assert needs_parentheses('x[1]')
    assert not needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.__getitem__(1)')

    source = 'xxx'
    exclude = 'yyy'
    v = BaseVariable(source, exclude=exclude)
    assert v.source == source
    assert v.exclude == (exclude,)
    code = compile(source, '<variable>', 'eval')
    assert v.code == code
    assert v.unambiguous_source == source

    assert v._fingerprint == (BaseVariable, source, (exclude,))

# Unit tests for class Attrs

# Generated at 2022-06-22 18:32:24.268720
# Unit test for constructor of class Indices
def test_Indices(): 
    from . import pycompat
    _ = pycompat
    assert Indices('foobar',exclude=('re'))
    assert not Indices('foobar',exclude=('re')).exclude
    assert Indices('foobar',exclude=('re')).source == 'foobar'


# Generated at 2022-06-22 18:32:27.580327
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('x')._fingerprint == (CommonVariable, 'x', ())
    assert CommonVariable('x', 'y')._fingerprint == (CommonVariable, 'x', ('y',))
    assert CommonVariable('x', ('y',))._finge

# Generated at 2022-06-22 18:32:32.990666
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('lambda: x') is True
    assert needs_parentheses('lambda x: x') is True
    assert needs_parentheses('(-1.0)') is False
    assert needs_parentheses('(-x)') is False
    assert needs_parentheses('-(-x)') is True

# Generated at 2022-06-22 18:32:38.852503
# Unit test for constructor of class Exploding
def test_Exploding():
    # Given
    source = "sample_source"
    exclude = ("exclude_1", "exclude_2")
    expected_exploding = Exploding(source, exclude)

    # When
    actual_exploding = Exploding(source, exclude)

    # Then
    assert expected_exploding.source == actual_exploding.source
    assert expected_exploding.exclude == actual_exploding.exclude
    assert expected_exploding.code == actual_exploding.code
    assert expected_exploding.unambiguous_source == actual_exploding.unambiguous_source


# Generated at 2022-06-22 18:32:45.409544
# Unit test for constructor of class Keys
def test_Keys():
    # Test keys with pycompat.iteritems
    TEST_KEY_1 = {"a": "b", "c": "d"}
    assert Keys(TEST_KEY_1).items(TEST_KEY_1) == [('"a"', '"b"'), ('"c"', '"d"')]
    # Test keys with pycompat.iterkeys
    TEST_KEY_2 = {}
    assert Keys(TEST_KEY_2).items(TEST_KEY_2) == []

# Generated at 2022-06-22 18:32:48.805700
# Unit test for constructor of class Attrs
def test_Attrs():
    a = Attrs('y', exclude='abc')
    assert a._fingerprint == (Attrs, 'y', ('abc',))


# Generated at 2022-06-22 18:32:51.450350
# Unit test for constructor of class Indices
def test_Indices():
    ind = Indices("{}", ())
    assert ind._slice == slice(None)
    ind2 = ind[4:8]
    assert ind2._slice == slice(4,8)

# Generated at 2022-06-22 18:32:54.917434
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # same class and same source
    assert BaseVariable('a') == BaseVariable('a')

    # different class
    assert BaseVariable('a') != Keys('a')

    # different source
    assert BaseVariable('a') != BaseVariable('b')



# Generated at 2022-06-22 18:32:58.146311
# Unit test for function needs_parentheses
def test_needs_parentheses():
    f = needs_parentheses
    assert not f('x')
    assert not f('x.y')
    assert not f('(x)')
    assert f('(x.y)')
    assert f('(x).y')

# Generated at 2022-06-22 18:33:09.155706
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    v0 = CommonVariable('a', exclude=('a', ))
    v1 = CommonVariable('a', exclude=())
    v2 = CommonVariable('a', exclude=('a', ))
    v3 = CommonVariable('b', exclude=())
    v4 = CommonVariable('a')
    v5 = CommonVariable('b')
    assert v0 == v2
    assert v0 == v1
    assert v0 != v3
    assert v0 != v4
    assert v0 != v5
    assert hash(v0) == hash(v1)
    assert hash(v3) != hash(v1)
    assert hash(v3) != hash(v4)
    assert hash(v3) != hash(v5)



# Generated at 2022-06-22 18:33:12.961765
# Unit test for constructor of class Attrs
def test_Attrs():
    import inspect
    frame = inspect.currentframe()
    args, _, _, locals = inspect.getargvalues(frame)
    av = Attrs('args')
    assert av.items(frame, normalize=True)

# Generated at 2022-06-22 18:33:16.160760
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices('x')
    assert v.source == 'x'
    assert v.unambiguous_source == 'x'
    assert v._slice is slice(None)

    v = Indices('x', exclude='y')
    assert v.exclude[0] == 'y'

# Generated at 2022-06-22 18:33:23.944734
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices("main_value")
    # check that i is changed
    i.__getitem__(slice(1,2))
    assert i._slice == slice(1,2), "i._slice is not changed after i[1:2]"
    # check that i is not changed
    j = i.__getitem__(slice(5,6))
    assert i._slice == slice(1,2), "i._slice is changed after i[5:6]"
    assert j._slice == slice(5,6), "j._slice is not changed after j[5:6]"

# Generated at 2022-06-22 18:33:27.258999
# Unit test for constructor of class Indices
def test_Indices():
    variable = Indices('logs')

    assert variable.source == 'logs'
    assert variable.unambiguous_source == 'logs'


# Generated at 2022-06-22 18:33:34.183342
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') == False
    assert needs_parentheses('(x)') == False
    assert needs_parentheses('x.y.z') == False
    assert needs_parentheses('x.y.z.3') == False
    assert needs_parentheses('x().z') == True
    assert needs_parentheses('x().z.3') == True
    assert needs_parentheses('x["y"]') == True
    assert needs_parentheses('x[2]') == True
    assert needs_parentheses('x[(2)]') == True
    assert needs_parentheses('x[(2)].y.z') == True

# Generated at 2022-06-22 18:33:36.626324
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert (Indices('x')[0] == Indices('x', slice(0, 1)))

test_Indices___getitem__()

# Generated at 2022-06-22 18:33:44.827111
# Unit test for constructor of class Exploding
def test_Exploding():
    obj = object()
    dct = {'hi': 'bye'}
    lst = [1, 2, 3]

    def assert_single_item(var, expected):
        assert list(var._items(obj)) == [(var.unambiguous_source, expected)]

    def assert_multiple_items(var, expected):
        it = var._items(obj)
        assert tuple(it) == expected

    assert_single_item(Exploding('obj'), '<object object at ...>')
    assert_multiple_items(Exploding('dct'), (('dct', '{...}'),))
    assert_multiple_items(Exploding('lst'), (('lst', '[...]'),))

# Generated at 2022-06-22 18:33:49.278232
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('main_value')
    assert var.source == 'main_value'
    assert var.code is not None
    assert var.unambiguous_source is not None


# Generated at 2022-06-22 18:33:52.903545
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('x.x')
    assert not needs_parentheses('(x)')
    assert needs_parentheses('x[x].x')

# Generated at 2022-06-22 18:33:59.148380
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert needs_parentheses('(a)')
    assert needs_parentheses('(a.b)')
    assert needs_parentheses('(a.b).c')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a).b.c')



# Generated at 2022-06-22 18:34:01.595391
# Unit test for constructor of class Exploding
def test_Exploding():
    print('Test passing constructors:')
    Exploding('')
    print('Passed')


# Generated at 2022-06-22 18:34:09.346214
# Unit test for constructor of class Keys
def test_Keys():
    mymap = {'key1': 1, 'key2': 2, 'key3': 3}
    mykeys = Keys('mymap')
    assert mykeys.source == 'mymap'
    assert mykeys.exclude == ()
    assert mykeys.code.co_filename == '<variable>'
    assert mykeys.items(sys._getframe(), normalize=False) == [('mymap', '{key1: 1, key2: 2, key3: 3}'),
                                                             ('mymap[key1]', '1'),
                                                             ('mymap[key2]', '2'),
                                                             ('mymap[key3]', '3')]


# Generated at 2022-06-22 18:34:12.853136
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    a = BaseVariable('a')
    assert a.source == 'a'
    assert a.exclude == ()
    assert a.code
    assert a.unambiguous_source == 'a'


# Generated at 2022-06-22 18:34:16.865453
# Unit test for constructor of class Keys
def test_Keys():
    k = keys("a")
    assert k.__class__.__name__ == "Keys"
    assert k.source == 'a'
    assert k.exclude == ()


# Generated at 2022-06-22 18:34:27.249891
# Unit test for constructor of class BaseVariable
def test_BaseVariable():

    # construct variable variable
    variable1 = BaseVariable(source="x", exclude="x.y")
    variable2 = BaseVariable(source="x.y", exclude="x")
    
    # construct variable variable
    variable_list = [variable1, variable2]
    variable_dict = {"x": variable1, "x.y": variable2}

    # make sure hash is deterministic
    assert(hash(variable1) == hash(variable1))
    assert(hash(variable2) == hash(variable2))

    # make sure hash values for different variables are different
    assert(hash(variable1) != hash(variable2))

    # make sure hash values for different variables are different
    assert(hash(variable1) in [hash(x) for x in variable_list])

# Generated at 2022-06-22 18:34:38.555693
# Unit test for constructor of class Indices
def test_Indices():
    indices_test = Indices('a', exclude=())
    assert isinstance(indices_test, Indices) == True
    assert indices_test.source == 'a'
    assert indices_test.exclude == ()
    assert indices_test.code == compile('a', '<variable>', 'eval')
    assert indices_test.unambiguous_source == 'a'
    assert indices_test._slice == slice(None)

    assert isinstance(indices_test._keys([1, 2, 3]), range) == True
    assert isinstance(indices_test._format_key(1), str) == True
    assert indices_test._get_value([1, 2, 3], slice(1, 2)) == [2]

    indices_test = Indices('a', exclude=())[1:2]

# Generated at 2022-06-22 18:34:48.364481
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('a')
    assert a.source == 'a', 'a.source == "a"'
    assert a.exclude == (), 'a.exclude == ()'
    assert a.code == compile('a', '<variable>', 'eval'), 'a.code == compile("a", "<variable>", "eval")'
    assert a.unambiguous_source == 'a', 'a.unambiguous_source == "a"'

    b = Keys('b', exclude=('x',))
    assert b.source == 'b', 'b.source == "b"'
    assert b.exclude == ('x',), 'b.exclude == ("x",)'
    assert b.code == compile('b', '<variable>', 'eval'), 'b.code == compile("b", "<variable>", "eval")'

# Generated at 2022-06-22 18:34:58.110748
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    def f(x):
        return x

    l = [1, 2]
    d = {'1': 'a', '2': 'b'}
    a = Attrs('f(l)')
    #attribute name
    assert(a._format_key('__repr__') == '.__repr__')
    assert(a._get_value(d, '__repr__') == dict.__repr__)
    assert(a._get_value(l, '__repr__') == list.__repr__)

    k = Keys('d')
    #key name
    assert(k._format_key('1') == '[1]')
    assert(k._get_value(d, '2') == d['2'])
    assert(k._get_value(l, '1') == l[1])

# Generated at 2022-06-22 18:35:03.265750
# Unit test for constructor of class Keys
def test_Keys():
    # throw error if we don't have a valid key
    m = {}
    a = Keys('m')
    assert a._keys(m) == iter(())

    # throw an exception if we have a valid key
    m = {"test" : "test"}
    assert a._keys(m) == iter(m.keys())


# Generated at 2022-06-22 18:35:08.032855
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('sigma')
    assert k.source == 'sigma'
    assert k.exclude == ()
    assert k.code == compile('sigma', '<variable>', 'eval')
    assert k.unambiguous_source == 'sigma'


# Generated at 2022-06-22 18:35:10.146754
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x1 = BaseVariable(1,2)
    x2 = BaseVariable(1,2)
    print(x1 == x2)


# Generated at 2022-06-22 18:35:20.047999
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x') is False
    assert needs_parentheses('-x') is False
    assert needs_parentheses('x.y') is False
    assert needs_parentheses('x[y]') is False
    assert needs_parentheses('x().y') is False
    assert needs_parentheses('x[y].z') is False
    assert needs_parentheses('x[y]()') is False

    assert needs_parentheses('-x.y') is True
    assert needs_parentheses('(x)') is True
    assert needs_parentheses('(-x).y') is True
    assert needs_parentheses('(-x.y)') is True
    assert needs_parentheses('(-x).y()') is True

# Generated at 2022-06-22 18:35:24.468534
# Unit test for constructor of class Indices
def test_Indices():
    # Create an object of class Indices with a slice object
    indices = Indices(source='source', exclude='exclude', slice=slice(3))

    # Test that slice object is stored in slice attribute of object
    assert indices.slice == slice(3)

    # Test that slice object is returned by __getitem__ method
    assert indices[3:] == slice(3,None)



# Generated at 2022-06-22 18:35:27.003776
# Unit test for constructor of class Keys
def test_Keys():
    x = Keys('x')
    assert x.source == 'x'
    assert x.unambiguous_source == 'x'
    assert x.exclude == ()


# Generated at 2022-06-22 18:35:36.603353
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A:
        pass

    class B:
        b = A()
        b.a = 1
        b.b = 2
        c = {'cc': 3}
        d = (5, 6)
        e = [7, 8]

    def func():
        pass

    import dis
    import types

    def get_frame():
        funcs = [test_BaseVariable_items, func]
        codes = [dis.Bytecode(func) for func in funcs]

        # find LOAD_GLOBAL
        for code in codes:
            for instruction in code:
                if instruction.opcode == dis.opmap['LOAD_GLOBAL']:
                    index = code.index(instruction)
                    break

            # find next CALL_FUNCTION

# Generated at 2022-06-22 18:35:45.181659
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class X(CommonVariable):
        def _keys(self, main_value):
            return range(5)

        def _format_key(self, key):
            return key

        def _get_value(self, main_value, key):
            return key

    variable = X('main', exclude=['main.exclude'])
    assert variable._items(1) == [
        ('main', '1'),
        ('main.0', '0'),
        ('main.1', '1'),
        ('main.2', '2'),
        ('main.3', '3'),
        ('main.4', '4'),
    ]

# Generated at 2022-06-22 18:35:55.390000
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('c', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('c', 'd')
