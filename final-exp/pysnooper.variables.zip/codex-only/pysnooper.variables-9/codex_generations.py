

# Generated at 2022-06-22 18:25:51.879552
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a')
    assert k.source == 'a'
    assert k.exclude == ()

# Generated at 2022-06-22 18:25:58.730767
# Unit test for constructor of class Attrs
def test_Attrs():
    assert issubclass(Attrs, BaseVariable)
    x = Attrs('a.b')
    assert x.source == 'a.b'
    assert x.unambiguous_source == 'a.b'
    assert x.code == compile('a.b', '<variable>', 'eval')
    assert x.exclude == ()



# Generated at 2022-06-22 18:26:01.516721
# Unit test for constructor of class Attrs
def test_Attrs():
    attrs = Attrs('a')
    assert attrs.source == 'a'
    assert attrs.code
    assert attrs.unambiguous_source == 'a'
    assert attrs.exclude == ()


# Generated at 2022-06-22 18:26:04.934670
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert tuple(CommonVariable('foo').items(None)) == (('foo', '<object>'),)


# Generated at 2022-06-22 18:26:08.293148
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('source')[1:3]
    assert variable.source == 'source'
    
    variable = Indices('source')[1:2]
    assert variable.source == 'source'

    variable = Indices('source')[:3]
    assert variable.source == 'source'

# Generated at 2022-06-22 18:26:09.530624
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices("a")[1:2]

# Generated at 2022-06-22 18:26:13.460447
# Unit test for constructor of class Indices
def test_Indices():
    from . import get_sample_variables
    from .sample_input import _attorneys
    kwargs = {'source':get_sample_variables}
    args = (_attorneys, )
    assert 'a' == Indices(*args, **kwargs)._items(*args)[0][0]

# Generated at 2022-06-22 18:26:16.754568
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'foo'
    exclude = 'bar'
    a = BaseVariable(source, exclude)
    assert a.source == source
    assert a.exclude == (exclude,)
    assert a.code != None


# Generated at 2022-06-22 18:26:21.887689
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('x')
    assert needs_parentheses('x.y')
    assert needs_parentheses('x.y().z')
    assert needs_parentheses('x.y()[1]')
    assert needs_parentheses('(x).y()[1]')
    assert not needs_parentheses('x()')
    assert not needs_parentheses('x().y()')
    assert not needs_parentheses('x()[1]')
    assert not needs_parentheses('(x()).y()[1]')
    assert needs_parentheses('x[1]')
    assert needs_parentheses('(x)[1]')
    assert not needs_parentheses('(x[1])')

# Generated at 2022-06-22 18:26:25.032646
# Unit test for constructor of class Keys
def test_Keys():
    dict_data = {'a':1,'b':2,'c':3}
    myKeys = Keys("Keys",("b",))
    assert (myKeys.items(dict_data) == [('Keys.a', 1), ('Keys.c', 3)])

# Generated at 2022-06-22 18:26:30.858666
# Unit test for function needs_parentheses
def test_needs_parentheses():
    for s in ('x', 'x.y', 'x[y]', 'x[foo.bar]', '(x)', '((x))', '(x.y)', '(x).y', 'x.y.z'):
        assert not needs_parentheses(s), s

    for s in ('((x.y))', '(3 + 2).imag', 'foo(bar.y)'):
        assert needs_parentheses(s), s



# Generated at 2022-06-22 18:26:41.846136
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    # Test exclusions
    assert Attrs('foo.bar', exclude=('baz',)).exclude == ('baz',)
    assert Attrs('foo.bar', exclude='baz').exclude == ('baz',)

    # Test instances are equal if they have equal members
    assert (Attrs('foo.bar') == Attrs('foo.bar'))
    assert (Attrs('foo.bar', exclude='baz') == Attrs('foo.bar', exclude=('baz',)))
    assert (Attrs('foo.bar', exclude='baz') != Attrs('foo.bar', exclude='qaz'))

    assert (Keys('foo.bar') == Keys('foo.bar'))
    assert (Keys('foo.bar', exclude='baz') == Keys('foo.bar', exclude=('baz',)))

# Generated at 2022-06-22 18:26:45.742644
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = utils.get_shortish_repr(Indices('self')._items(range(10))[1:2])
    b = utils.get_shortish_repr([(1, 1)])
    assert a == b


# Generated at 2022-06-22 18:26:51.254422
# Unit test for constructor of class Indices
def test_Indices():
    v = Indices("argv[1:3]")
    assert v.source == "argv[1:3]"
    assert v.exclude == ()
    assert v.code is not None
    assert v.unambiguous_source == "argv[1:3]"
    assert v._slice == slice(1, 3, None)
    assert v.__getitem__(slice(None)) == Indices("argv[1:3]")
    assert v.__getitem__(slice(1, 3, None)) == Indices("argv[1:3]")

# Generated at 2022-06-22 18:26:58.031989
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test the case whether the type of argument 'item' of method
    # Indices.__getitem__ is 'slice'

    # Get the member of class Indices
    indices = Indices('list', exclude=())
    # Call method __getitem__ on 'indices'
    indices[slice(1, 2, None)]

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-22 18:27:02.112808
# Unit test for constructor of class Attrs
def test_Attrs():
    source = 'request.args'
    exclude = 'foo'
    attrs = Attrs(source)
    assert attrs.source == source
    assert attrs.exclude == (exclude,)
    assert attrs.code == compile(source, '<variable>', 'eval')
    assert attrs.unambiguous_source == source


# Generated at 2022-06-22 18:27:08.155905
# Unit test for constructor of class Exploding
def test_Exploding():
    r = Exploding('a')
    assert r.source == 'a'
    assert isinstance(r.code, (type(None)))
    assert isinstance(r.exclude, tuple)
    assert r.exclude == ()
    assert r.unambiguous_source == 'a'


# Generated at 2022-06-22 18:27:14.962913
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source = "dict"
    exclude = ["a", "b", "c"]
    assert(CommonVariable(source, exclude).source == "dict")
    assert(CommonVariable(source, exclude).exclude == ('a', 'b', 'c'))
    assert(CommonVariable(source, exclude).code == 
        compile('dict', '<variable>', 'eval'))
    assert(CommonVariable(source, exclude).unambiguous_source == "(dict)")


# Generated at 2022-06-22 18:27:19.519143
# Unit test for constructor of class Attrs
def test_Attrs():
    var = Attrs('var', exclude='__dict__')
    assert var.source == 'var'
    assert var.exclude == ('__dict__',)
    assert var.code == compile('var', '<variable>', 'eval')
    assert var.unambiguous_source == 'var'



# Generated at 2022-06-22 18:27:27.946909
# Unit test for constructor of class Attrs
def test_Attrs():
    from .utils import get_shortish_repr
    import inspect
    def test(self_object, s, k, v):
        a = Attrs(s)
        assert a._get_value(self_object, k) == v
        assert a._format_key(k) == '.{}'.format(k)
        assert a.source == s
        assert a.unambiguous_source == s
        assert a._fingerprint == (Attrs, s, ())
        assert a.code == s
        assert a.exclude == ()
        assert a.items(inspect.currentframe()) == [(s, get_shortish_repr(self_object))]
        assert repr(a) == 'Attrs({})'.format(repr(s))

    test(1, '1', 'bit_length', 1)
    test

# Generated at 2022-06-22 18:27:35.045061
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    source = 'test_source'
    exclude = 'test_exclude'
    testVar = BaseVariable(source, exclude)
    assert testVar.source == source
    assert testVar.exclude == exclude
    assert testVar.code == compile(source, '<variable>', 'eval')
    #assert testVar.code == compile(source, '<variable>', 'eval')
    if needs_parentheses(source):
        assert testVar.unambiguous_source == '(' + source + ')'
    else:
        assert testVar.unambiguous_source == source

# Generated at 2022-06-22 18:27:38.378136
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    for cls in (Keys, Indices, Attrs, Exploding):
        a = cls('a')
        b = cls('b')
        assert a == a
        assert not a == b

# Generated at 2022-06-22 18:27:49.620196
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    import random
    # set random seed
    random.seed(3)

    # simulate a frame in memory
    frame_globals = {
        'x' : 1,
        'y' : 2,
    }
    frame_locals = {
        'frame_locals1' : 1,
        'frame_locals2' : 2,
    }
    frame = types.FrameType(None, '<frame>', False, False, None, None, None)
    frame.f_globals = frame_globals
    frame.f_locals = frame_locals

    # test BaseVariable
    # test with input source = 'x'
    # test with input source = 'y'
    # test with input source = '1'
    # test with input source = 'a

# Generated at 2022-06-22 18:27:53.989593
# Unit test for constructor of class Attrs
def test_Attrs():
    test_vars = ['__dict__','__slots__','test']
    main_value = 'string'
    attrs = Attrs('main_value')
    assert attrs._keys(main_value) == tuple(test_vars)
    assert attrs._fingerprint == (Attrs, 'main_value', ())


# Generated at 2022-06-22 18:28:00.039843
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")
    assert BaseVariable("a") != BaseVariable("b")
    assert (Attrs("a") == Attrs("a") and
            Attrs("a") != BaseVariable("a") and
            Attrs("a") != Keys("a") and
            Attrs("a") != Indices("a") and
            Attrs("a") != Exploding("a"))
    assert (Keys("a") == Keys("a") and
            Keys("a") != BaseVariable("a") and
            Keys("a") != Attrs("a") and
            Keys("a") != Indices("a") and
            Keys("a") != Exploding("a"))

# Generated at 2022-06-22 18:28:04.634393
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import dis
    frame = dis.stack()[1][0]
    assert frame.f_locals['test_BaseVariable_items']
    assert BaseVariable("test_BaseVariable_items",exclude=("test_BaseVariable_items",)).items(frame) == [("test_BaseVariable_items","<function test_BaseVariable_items at 0x10bcc3730>")]


# Generated at 2022-06-22 18:28:13.251420
# Unit test for constructor of class Keys
def test_Keys():
    test_class = Keys('a')
    assert test_class.source == 'a'
    assert test_class.exclude == tuple()
    assert test_class.code != None
    assert test_class.unambiguous_source == 'a'
    assert test_class._fingerprint == (Keys, 'a', tuple())
    assert test_class.items == CommonVariable.items
    assert test_class._safe_keys == CommonVariable._safe_keys
    assert test_class._keys == CommonVariable._keys
    assert test_class._format_key == CommonVariable._format_key
    assert test_class._get_value == CommonVariable._get_value
    assert test_class._keys == Keys._keys

# Generated at 2022-06-22 18:28:18.375942
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .stacked_frame import StackedFrame
    from .traceback_template import Frame
    frame = Frame({'a': 1})
    sframe = StackedFrame(frame)
    variable = BaseVariable(source='a')
    actual = variable.items(sframe)
    expected = ('a', '1')
    assert actual == expected

# Generated at 2022-06-22 18:28:20.290557
# Unit test for constructor of class Indices
def test_Indices():
    assert len(Indices('__code__').items(dict(__code__=1))) == 2

# Generated at 2022-06-22 18:28:29.681300
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class_1 = BaseVariable
    class_1.source = "1"
    class_1.exclude = ("1")
    class_1.code = compile("1", "", "eval")
    class_2 = BaseVariable
    class_2.source = "2"
    class_2.exclude = ("2")
    class_2.code = compile("2", "", "eval")
    assert not class_1 == class_2
    class_2.source = "1"
    assert not class_1 == class_2
    class_2.exclude = "1"
    assert not class_1 == class_2
    class_2.code = compile("1", "", "eval")
    assert class_1 == class_2


# Generated at 2022-06-22 18:28:40.662375
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    tracer = utils.Tracer()
    source = '''
result = {
    'x': {
        'y': 4
    }
}
result['x']['z'] = 5
    '''
    tracer.trace_code(source)()
    assert tracer.traced_variables == [
        ('result', '{\'x\': {\'y\': 4, \'z\': 5}}'),
        ('result.x', '{\'y\': 4, \'z\': 5}'),
        ('result.x.y', '4'),
        ('result.x.z', '5'),
    ]
    tracer.trace_code(source, variables=[Keys('result')])()

# Generated at 2022-06-22 18:28:43.178746
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    var = BaseVariable('foo')
    hash_foo = var.__hash__()

    var = BaseVariable('foo', exclude=('a', 'b'))
    hash_foo_a = var.__hash__()

    var = BaseVariable('foo', exclude='a')
    hash_foo_b = var.__hash__()

    assert hash_foo == hash_foo_a == hash_foo_b

# Generated at 2022-06-22 18:28:47.304382
# Unit test for constructor of class Indices
def test_Indices():
    L = list(range(10))
    indices = Indices('test')
    res = indices.items(None, False)
    assert len(res) == 10
    for r in res:
        assert len(r) == 2

# Generated at 2022-06-22 18:28:50.785105
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    import pytest
    s = BaseVariable("", ())
    with pytest.raises(NotImplementedError):
        s.__hash__()

# Generated at 2022-06-22 18:28:52.636495
# Unit test for constructor of class Attrs
def test_Attrs():
    print (Attrs('a'))

test_Attrs()

# Generated at 2022-06-22 18:28:54.716517
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('', ())
    assert list(k._keys({'a':1})) == ['a']


# Generated at 2022-06-22 18:29:01.568853
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    class TestVar(CommonVariable):
        def _keys(self, main_value):
            return ('a', 'b', 'c')

        def _format_key(self, key):
            return '.' + key

        def _get_value(self, main_value, key):
            return main_value + key

    test_var = TestVar('a', exclude=('b',))
    result = dict(test_var._items('test'))
    assert result['a'] == 'test'
    assert result['a.a'] == 'testa'
    assert result['a.c'] == 'testc'
    assert 'a.b' not in result


# Generated at 2022-06-22 18:29:04.567319
# Unit test for constructor of class Keys
def test_Keys():
    try:
        _ = Keys(1, 2)
    except Exception as ex:
        print(ex)
        assert "needs to be str" in str(ex)
    else:
        assert False, "Keys initialized with non-string source"


# Generated at 2022-06-22 18:29:08.895360
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    """
    It should return base hash
    """
    assert BaseVariable('foo').__hash__() == BaseVariable('foo').__hash__()
    assert BaseVariable('foo', ('bar',)).__hash__() == BaseVariable('foo', ('bar',)).__hash__()
    assert BaseVariable('foo', 'bar').__hash__() == BaseVariable('foo', 'bar').__hash__()


# Generated at 2022-06-22 18:29:09.670973
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    BaseVariable()
    return

# Generated at 2022-06-22 18:29:11.838920
# Unit test for constructor of class Exploding
def test_Exploding():
    cls = Attrs
    assert cls(self.source, self.exclude)._items(main_value, normalize)


# Generated at 2022-06-22 18:29:15.156091
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    c = CommonVariable('x', ('a', 'b'))
    assert (c.source, c.exclude, c.unambiguous_source) == ('x', ('a', 'b'), 'x')


# Generated at 2022-06-22 18:29:20.949580
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    idx = Indices('a')
    idx1 = idx[2:5]
    assert idx1._keys(['a', 'b', 'c', 'd', 'e', 'f']) == [2, 3, 4]
    assert idx1.source == 'a'
    assert idx1._slice == slice(2, 5)
    assert idx1._fingerprint == (Keys, 'a', ())

# Generated at 2022-06-22 18:29:22.291444
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('foo')
    indices['abc']


# Generated at 2022-06-22 18:29:27.765728
# Unit test for constructor of class Keys
def test_Keys():
    k1 = Keys()
    k2 = Keys()
    k3 = Keys('a')
    k4 = Keys('a')
    k5 = Keys('a', exclude=('b', ))
    k6 = Keys('a', exclude=('b', ))

    assert k1 == k2
    assert k3 == k4
    assert k5 == k6
    assert k1 != k3 != k5

    assert hash(k1) == hash(k2)
    assert hash(k3) == hash(k4)
    assert hash(k5) == hash(k6)
    assert hash(k1) != hash(k3) != hash(k5)

# Generated at 2022-06-22 18:29:32.264418
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    cv = CommonVariable('source', 'exclude')
    assert(cv.source == 'source')
    assert(cv.exclude == ('exclude',))
    assert(isinstance(cv.code, type(compile('', '', 'eval'))))
    assert(cv.unambiguous_source == 'source')


# Generated at 2022-06-22 18:29:34.577947
# Unit test for constructor of class Keys
def test_Keys():
    # None is tested for given as source for varialbe
    # so test None exists or not in the tuple of keys
    assert "None" not in keys(None)


# Generated at 2022-06-22 18:29:38.201691
# Unit test for constructor of class Keys
def test_Keys():
    d = {'a': 1, 'b': 2, 'c': 3}
    reach = Keys('d', exclude=('b',))
    assert sorted(reach.items(d)) == [('d.a', '1'), ('d.c', '3')]


# Generated at 2022-06-22 18:29:43.089022
# Unit test for constructor of class Exploding
def test_Exploding():
    frame = utils.FakeFrame()
    frame.f_locals = {'foo': {'bar': 'baz'}, 'bar': 1}
    ev = Exploding('foo')
    assert sorted(ev.items(frame)) == [('foo.bar', "'baz'"), ('foo[bar]', '1')]

# Generated at 2022-06-22 18:29:48.341786
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    from . import pycompat
    from . import utils
    from . import traceback_content as tc
    from . import variables
    from . import utils
    from . import frames
    import inspect
    import sys

    class DummyVariable(tc.CommonVariable):
        pass

    for klass in [DummyVariable, tc.Exploding]:
        variable = klass('var')
        assert variable.source == 'var'
        assert variable.exclude == ()
        variable = klass('var', ['exclude'])
        assert variable.exclude == ('exclude',)
        assert variable.unambiguous_source == 'var'
        assert variable._keys == ()
        assert variable._slice == slice(None)
        assert variable._fingerprint == (klass, 'var', ())

# Generated at 2022-06-22 18:29:54.720001
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    frame = inspect.currentframe()
    print(inspect.getframeinfo(frame))
    print(inspect.getframeinfo(frame.f_back))
    print(sys._getframe())
    print(getattr(os, '__dict__'))
    print(getattr(os, '__slots__'))
    print(getattr(os, '__annotations__'))
    print(os.__doc__)

    # 1. test method items of class BaseVariable
    # 2. test if the value can be mutated
    # 3. test if the value is local or from global scope
    class foo:
        def __init__(self):
            self.x = 1
            self.y = 2
    os_keys = Keys('os')
    os_keys_

# Generated at 2022-06-22 18:29:59.524427
# Unit test for constructor of class BaseVariable
def test_BaseVariable():
    variable = BaseVariable('x', exclude=('y'))
    assert variable.source == 'x', "Wrong variable source"
    assert variable.exclude == ('y',), "Wrong variable exclude, expected ('y')"
    assert variable.code == compile('x', '<variable>', 'eval'), "Wrong variable code, expected compile('x', '<variable>', 'eval')"
    assert variable.unambiguous_source == 'x', "Wrong variable unambiguous source, expected x"


# Generated at 2022-06-22 18:30:09.743843
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import variables

    # Test if BaseVariable._items get correct result
    base_var = BaseVariable('x')
    frame = utils.get_frame()
    result = base_var._items(frame.f_locals['x'], normalize=False)
    expect = [('x', 'instance of class <class \'A\'>'), ('x.x', '1'), ('x.y', '2'), ('x[0]', '[1 2]')]
    assert pycompat.izip_equal(result, expect)

    # Test if BaseVariable._items get correct result
    base_var = BaseVariable('x', exclude = ('x.x',))
    frame = utils.get_frame()

# Generated at 2022-06-22 18:30:19.928757
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert Attrs('a').source == 'a'
    assert Attrs('a').unambiguous_source == '(a)'
    assert Attrs('(a)').source == '(a)'
    assert Attrs('(a)').unambiguous_source == '((a))'
    assert Attrs('a[3]').source == 'a[3]'
    assert Attrs('a[3]').unambiguous_source == '(a[3])'
    assert Attrs('(a[3])').source == '(a[3])'
    assert Attrs('(a[3])').unambiguous_source == '((a[3]))'


# Unit tests for keys()

# Generated at 2022-06-22 18:30:26.670475
# Unit test for constructor of class Indices
def test_Indices():
    # NOTE: this test requires class Indices to be defined in this module
    # for the eval() to work.
    class TestableIndices(Indices):
        def __init__(self, source, exclude=()):
            super(TestableIndices, self).__init__(source, exclude)

    indices = TestableIndices('list_name')
    assert indices.source == 'list_name'
    assert indices._slice == slice(None)

    indices = TestableIndices('list_name', exclude=['key1', 'key2'])
    assert indices.source == 'list_name'
    assert indices.exclude == ('key1', 'key2')


# Generated at 2022-06-22 18:30:31.646508
# Unit test for constructor of class Exploding
def test_Exploding():
    e1 = Exploding('e[\'a\'])')
    assert e1.source == 'e[\'a\'])'
    assert e1.exclude == ()
    assert e1.code == compile('e[\'a\'])', '<variable>', 'eval')
    assert e1.unambiguous_source == '(e[\'a\'])'
    frame = {'e':{'a':'b'}}
    assert e1.items(frame) == [('e[\'a\'])', 'b')]
    e2 = Exploding('e[\'a\']', exclude='a')
    assert e2.source == 'e[\'a\']'
    assert e2.exclude == 'a'
    assert e2.code == compile('e[\'a\']', '<variable>', 'eval')
   

# Generated at 2022-06-22 18:30:35.313538
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    print(a)
    b = a[:2]
    print(b)
    c = Indices('a')[:2]
    print(c)
    assert c == b


# Generated at 2022-06-22 18:30:45.258071
# Unit test for constructor of class Exploding
def test_Exploding():
    var = "Globals"
    var2 = "Global.Variable"
    # var3 = "Global.Variable1.Variable2"

    e = Exploding(var)
    assert(e.source == var)
    assert(e.exclude == ())

    e = Exploding(var2)
    assert(e.source == var2)
    assert(e.exclude == ())

    e = Exploding(var, var2)
    assert(e.source == var)
    assert(e.exclude == (var2,))

    e = Exploding(var, (var2,))
    assert(e.source == var)
    assert(e.exclude == (var2,))

    # e = Exploding(var3, (var2,))
    # assert(e.source == var3)
    # assert

# Generated at 2022-06-22 18:30:54.775251
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    type_BaseVariable = type(BaseVariable)
    type_BaseVariable_Source = "BaseVariable_Source"
    type_BaseVariable_Exclude = tuple()
    data = (type_BaseVariable,
            type_BaseVariable_Source,
            type_BaseVariable_Exclude)
    # hash(data)
    # hash(data)
    class C(BaseVariable):
        def __init__(self):
            self.source = type_BaseVariable_Source
            self.exclude = type_BaseVariable_Exclude
            self.code = compile(self.source, '<variable>', 'eval')
            if needs_parentheses(self.source):
                self.unambiguous_source = '({})'.format(self.source)
            else:
                self.unambiguous_source = self.source

# Generated at 2022-06-22 18:30:57.708408
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("a")
    assert var[1:3] == (
        Indices("a[1]", "a[2]")
    )
    assert var[:3] == (
        Indices("a[0]", "a[1]", "a[2]")
    )
    assert var[1:] == (
        Indices("a[1]", "a[2]", "a[3]")
    )

# Generated at 2022-06-22 18:31:03.949675
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import logging
    import __main__
    class TestLogRecord(logging.LogRecord):
        def __init__(self,msg,loggerName='loggerName',levelNo=20,pathName='fileName',
                lineNo=10,module='module',funcName='funcName',stack_info=True,
                created=1234567890,msecs=1234.5,exc_info=None,exc_text=None,
                args=None,kwargs=None):
            self.msg = msg
            self.name = loggerName
            self.levelno = levelNo
            self.pathname = pathName
            self.lineno = lineNo
            self.module = __main__
            self.funcName = funcName
            self.stack_info = stack_info
            self.created = created


# Generated at 2022-06-22 18:31:09.814843
# Unit test for constructor of class Keys
def test_Keys():
    a = Keys('var')
    assert a.source == 'var'
    assert a.exclude == ()
    assert a.code

    a = Keys('var', ('key1', 'key2'))
    assert a.source == 'var'
    assert a.exclude == ('key1', 'key2')
    assert a.code



# Generated at 2022-06-22 18:31:17.399907
# Unit test for constructor of class Keys
def test_Keys():
    keys = "abcd"
    instance = Keys(source=keys, exclude=[])
    assert isinstance(instance, BaseVariable)
    assert isinstance(instance.source, str)
    assert isinstance(instance.exclude, tuple)
    assert isinstance(instance.code, code)
    assert isinstance(instance.unambiguous_source, str)
    assert isinstance(instance._fingerprint, tuple)
    assert isinstance(instance.__hash__(), int)
    assert isinstance(instance.__eq__(instance), bool)
    assert isinstance(instance._items(instance), tuple)
    assert isinstance(instance._safe_keys(instance), generator)
    assert isinstance(instance._format_key(source=keys), str)
    assert isinstance(instance._get_value(main_value=None, key=keys), object)

# Generated at 2022-06-22 18:31:28.839690
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from inspect import currentframe
    from pygments import highlight
    from pygments.lexers import PythonLexer
    from pygments.formatters import Terminal256Formatter
    from pudb import set_trace
    source = currentframe().f_code.co_name

    tmpl1 = '(lambda: None)'
    tmpl2 = '(lambda: None(%s))'
    tmpl3 = '(lambda: None(%s, %s))'

    def check(expected, tmpl, args=()):
        result = eval(tmpl % args)
        assert expected == result, highlight(
            '{}\n{}\n!=\n{}'
            .format(expected, tmpl % args, result),
            PythonLexer(), Terminal256Formatter()
        )


# Generated at 2022-06-22 18:31:37.286050
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import utils
    Indices_ = Indices('x')
    list_ = list(range(10))
    #
    # Test case 1
    Indices__ = Indices_[::2]
    assert Indices_.source == 'x'
    assert Indices_.exclude == ()
    assert Indices_._slice == slice(None)
    assert Indices__.source == 'x'
    assert Indices__.exclude == ()
    assert Indices__._slice == slice(None, None, 2)
    #
    # Test case 2
    Indices__ = Indices_[::-1]
    assert Indices_.source == 'x'
    assert Indices_.exclude == ()
    assert Indices_._slice == slice(None)
    assert Indices__.source == 'x'
    assert Indices__.ex

# Generated at 2022-06-22 18:31:48.348281
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    from pycallgraph import Config, PyCallGraph
    from pycallgraph.output import GraphvizOutput
    config = Config(include=['pycallgraph.*', 'pycallgraph.examples.test_BaseVariable___hash__'])
    graphviz = GraphvizOutput(output_file='test_BaseVariable___hash__.png')

    with PyCallGraph(output=graphviz, config=config):
        # test case
        a = BaseVariable('a')
        b = BaseVariable('b')
        c = BaseVariable('a')
        # logger
        print('hash of a: ' + str(hash(a)))
        print('hash of b: ' + str(hash(b)))
        print('hash of c: ' + str(hash(c)))


# Generated at 2022-06-22 18:31:51.789977
# Unit test for constructor of class Indices
def test_Indices():
    obj = object()
    v = Indices("x")
    v[1:3]
    assert_equal(v.items(obj), [(u'x[1]', u'<obj>'), (u'x[2]', u'<obj>')])

# Generated at 2022-06-22 18:31:56.030245
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    r = list(CommonVariable('foo').items(utils.Frame(f_locals={'foo': {'bar': 1, 'baz': 2}})))
    assert r == [('foo', '{\'bar\': 1, \'baz\': 2}')]


# Generated at 2022-06-22 18:32:02.145410
# Unit test for constructor of class CommonVariable

# Generated at 2022-06-22 18:32:12.049516
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('x', exclude='a')
    assert BaseVariable('x') != Attrs('x')
    assert BaseVariable('x') != Keys('x')
    assert BaseVariable('x') != Indices('x')
    assert BaseVariable('x') != Exploding('x')
    assert Attrs('x') == Attrs('x')
    assert Attrs('x') != Attrs('y')
    assert Attrs('x') != Attrs('x', exclude='a')
    assert Attrs('x') != Keys('x')
    assert Attrs('x') != Indices('x')
    assert Attrs('x') != Exploding('x')
    assert Keys('x') == Keys('x')

# Generated at 2022-06-22 18:32:22.497743
# Unit test for constructor of class Attrs
def test_Attrs():
    """
    >>> test_Attrs()
    """
    # Test 1: Attributes
    class Test_Attrs():
        def __init__(self):
            self.data = {'p': 1, 'q': 2}
            self.name = 'Attribute'
    t = Test_Attrs()
    v = Attrs('t', ('name'))
    print(v.items(t.__dict__, normalize=True))
    # Test 2: Slots
    class Test_Attrs_Slots():
        __slots__ = ['data', 'name']
        def __init__(self):
            self.data = {'p': 1, 'q': 2}
            self.name = 'Slot'
    t = Test_Attrs_Slots()
    v = Attrs('t', ('name'))
    print

# Generated at 2022-06-22 18:32:26.878612
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source1 = 'this'
    source2 = 'that'
    exclude1 = 'foo'
    exclude2 = 'bar'
    bv1 = BaseVariable(source1, exclude1)
    bv2 = BaseVariable(source2, exclude2)
    assert bv1.__eq__(bv1)
    assert not bv1.__eq__(bv2)


# Generated at 2022-06-22 18:32:29.237983
# Unit test for constructor of class Indices
def test_Indices():
    Indices(
        "args",
        exclude = ("kwargs",)
    )

test_Indices()



# Generated at 2022-06-22 18:32:40.526389
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind_var = Indices('x')
    assert ind_var[:3] == ind_var.__getitem__(slice(3))
    assert ind_var[:] == ind_var.__getitem__(slice(None))
    assert ind_var[1:2] == ind_var.__getitem__(slice(1, 2))
    assert ind_var[1:4] == ind_var.__getitem__(slice(1, 4))
    assert ind_var[1:20:2] == ind_var.__getitem__(slice(1, 20, 2))
    assert ind_var[1:20:20] == ind_var.__getitem__(slice(1, 20, 20))

# Generated at 2022-06-22 18:32:43.019302
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('a')
    i2 = i[:1]
    assert i2._slice is slice(0, 1, None)

# Generated at 2022-06-22 18:32:46.035121
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    assert hash(BaseVariable('__builtins__')) == hash(BaseVariable('__builtins__'))
    assert hash(BaseVariable('__builtins__')) != hash(BaseVariable('__builtins__', exclude=['mypy']))


# Generated at 2022-06-22 18:32:53.737812
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('x', exclude=['y'])
    assert i[3:7] == Indices('x', exclude=['y'], _slice=slice(3, 7))
    assert i[:7] == Indices('x', exclude=['y'], _slice=slice(0, 7))
    assert i[3:] == Indices('x', exclude=['y'], _slice=slice(3, None))
    assert i[:] == Indices('x', exclude=['y'], _slice=slice(None))

# Generated at 2022-06-22 18:32:54.958303
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(0, 0) == BaseVariable(0, 0)


# Generated at 2022-06-22 18:32:56.119864
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    pass


# Generated at 2022-06-22 18:33:08.249801
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    import unittest
    import sys

# Generated at 2022-06-22 18:33:09.887462
# Unit test for constructor of class Keys
def test_Keys():
    assert not needs_parentheses('a')
    assert needs_parentheses('(a)')

# Generated at 2022-06-22 18:33:16.437197
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    source, key = 'a', 'b'
    c = CommonVariable(source, [key])
    c.source = source
    c.exclude = [key]
    assert c.unambiguous_source is None
    assert c._fingerprint == (BaseVariable, source, [key])
    assert c._safe_keys is None
    assert c._keys is None
    assert c._format_key is None
    assert c._get_value is None
    assert c._items is None



# Generated at 2022-06-22 18:33:18.889093
# Unit test for constructor of class Exploding
def test_Exploding():
    var = Exploding('a', 'b')
    assert var.source == 'a'
    assert var.exclude == ('b',)



# Generated at 2022-06-22 18:33:22.753803
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    bv1 = BaseVariable('a', 'b')
    bv2 = BaseVariable('a', 'b')
    assert hash(bv1) == hash(bv2)

test_BaseVariable___hash__()



# Generated at 2022-06-22 18:33:32.982058
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    
    # first test that non BaseVariable objects are never equal
    not_a_BaseVariable = Attrs
    a_BaseVariable = Attrs('test')
    assert(a_BaseVariable != not_a_BaseVariable)
    
    # now test results for two BaseVariables with different source
    attrs1 = Attrs('test1')
    attrs2 = Attrs('test2')
    assert(attrs1 != attrs2)
    
    # now test results for two BaseVariables with different exclude
    attrs1 = Attrs('test1', 'test1')
    attrs2 = Attrs('test1', 'test2')
    assert(attrs1 != attrs2)
    
    # now test results for two BaseVariables with different type
    attrs1 = Attrs('test1', 'test1')
   

# Generated at 2022-06-22 18:33:35.936048
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "sys.modules"
    exclude = ()
    base_variable = BaseVariable(source, exclude)
    assert base_variable != None


# Generated at 2022-06-22 18:33:45.321493
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("x", exclude=('y', 'z')) == BaseVariable("x", exclude=('y', 'z'))
    assert BaseVariable("x", exclude=('y', 'z')) != BaseVariable("y", exclude=('y', 'z'))
    assert BaseVariable("x", exclude=('y', 'z')) != BaseVariable("x", exclude=('a', 'z'))
    assert BaseVariable("x", exclude=('y', 'z')) != BaseVariable("x", exclude=('y'))
    assert BaseVariable("x", exclude=('y', 'z')) != BaseVariable("x", exclude=('y', 'z', 'a'))
    assert BaseVariable("x", exclude=('y', 'z')) != BaseVariable("x")
    assert BaseVariable("x", exclude=('y', 'z'))

# Generated at 2022-06-22 18:33:50.350691
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding("abc")._items("abc"), tuple)
    assert isinstance(Exploding("abc")._items({"abc"}), tuple)
    assert isinstance(Exploding("abc")._items(["abc"]), tuple)


# Generated at 2022-06-22 18:33:56.732755
# Unit test for constructor of class Keys
def test_Keys():
    assert Keys("the source", ["the", "exclude"]).source == "the source"
    assert Keys("the source", ["the", "exclude"]).exclude == ("the", "exclude")
    assert Keys("the source", ["the", "exclude"]).code == compile("the source", '<variable>', 'eval')
    assert Keys("the source", ["the", "exclude"]).unambiguous_source == "the source"


# Generated at 2022-06-22 18:34:06.610798
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .frames import get_frame, get_parent_frame

    def a():
        return get_frame(1)

    def b():
        return get_frame(2)

    def c():
        return get_frame(3)
    # this test is a bit convoluted, but it helps ensure that we do not
    # break the API
    assert set(BaseVariable('a').items(a())) == set([('a', 'self')])
    assert set(BaseVariable('a.b').items(a())) == set([('a.b', 'b')])
    assert set(BaseVariable('a.c').items(a())) == set([('a.c', 'c')])
    assert set(BaseVariable('b').items(a())) == set([('b', 'parent')])

# Generated at 2022-06-22 18:34:07.184759
# Unit test for constructor of class Attrs
def test_Attrs():
    Attrs('x')

# Generated at 2022-06-22 18:34:15.900733
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert needs_parentheses('a')
    assert needs_parentheses('a[\'b\']')
    assert needs_parentheses('a.b')
    assert needs_parentheses('a.b.c')
    assert needs_parentheses('fn()')
    assert needs_parentheses('fn()[\'a\']')
    assert not needs_parentheses('(a)')
    assert not needs_parentheses('(a).b')
    assert not needs_parentheses('(a.b)')
    assert not needs_parentheses('(fn())')
    assert not needs_parentheses('(fn())[\'a\']')

# Generated at 2022-06-22 18:34:23.517443
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('1')
    assert not needs_parentheses('object.attr')
    assert not needs_parentheses('(1, 2, 3)')
    assert needs_parentheses('_self')
    assert needs_parentheses('"_self"')
    assert needs_parentheses('lambda: 1')
    assert needs_parentheses('{1}')
    assert needs_parentheses('[1]')
    assert not needs_parentheses('{1}.attr')
    assert not needs_parentheses('[1].attr')

# Generated at 2022-06-22 18:34:31.044219
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    v = BaseVariable(1,2)
    assert (isinstance(v, BaseVariable) and
            len(dir(v)) == 5 and
            getattr(v, "__module__") == "pyflame" and
            v.__hash__() == 22952233186 and
            BaseVariable(1,2) == BaseVariable(1,2) and
            BaseVariable(1,2) != BaseVariable(1) and
            BaseVariable(1,2) != 1)


# Generated at 2022-06-22 18:34:39.586824
# Unit test for function needs_parentheses
def test_needs_parentheses():
    assert not needs_parentheses('x')
    assert not needs_parentheses('get_x()')
    assert not needs_parentheses('x.y')
    assert not needs_parentheses('x.y.z')
    assert needs_parentheses('(x)')
    assert needs_parentheses('(1).x')
    assert needs_parentheses('[1].x')
    assert needs_parentheses('{1}.x')
    assert needs_parentheses('get_x()[0]')
    assert needs_parentheses('(x).y')
    assert needs_parentheses('-(x.y)')

# Generated at 2022-06-22 18:34:47.004109
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', exclude=['a', 'b'])
    var2 = BaseVariable('b', exclude=['b', 'c'])
    var3 = BaseVariable('c', exclude=['b', 'c'])
    var4 = BaseVariable('c', exclude=['c', 'b'])
    var5 = BaseVariable('c', 'b')
    var6 = BaseVariable('c')
    assert var1 == var1 and not var1 == var2 and var2 == var3
    assert not var1 == var5 and not var5 == var6 and not var2 == var5
    assert var3 == var4

# Generated at 2022-06-22 18:34:50.453378
# Unit test for constructor of class Keys
def test_Keys():
    x = {1:3, 2:5}
    # test that constructor of class Keys returns the expected output
    assert Keys(x).items(x) == [(1, 3), (2, 5)]

# Generated at 2022-06-22 18:34:59.717204
# Unit test for method __hash__ of class BaseVariable
def test_BaseVariable___hash__():
    print('test_BaseVariable___hash__()')
    source_a = 'a'
    source_b = 'b'
    exclude_a = 'a'
    exclude_b = 'b'

    v_ab = CommonVariable(source_a, exclude_a)
    v_bb = CommonVariable(source_b, exclude_b)
    v_ba = CommonVariable(source_b, exclude_a)
    h_ab = hash(v_ab)
    h_bb = hash(v_bb)
    h_ba = hash(v_ba)
    print((h_ab, h_bb, h_ba))
    print('h_ab:', h_ab)
    print('h_bb:', h_bb)
    print('h_ba:', h_ba)



# Generated at 2022-06-22 18:35:06.933723
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1= BaseVariable("x")
    var2= BaseVariable("x")
    var3= BaseVariable("y")
    var4= BaseVariable("x","y")
    var5= BaseVariable("x","z")

    assert var1==var1
    assert var1==var2
    assert var1!=var3
    assert var1!=var4
    assert var1!=var5

# Generated at 2022-06-22 18:35:11.972581
# Unit test for constructor of class Exploding
def test_Exploding():
    assert isinstance(Exploding('x')._items(dict())[0][0], str)
    assert isinstance(Exploding('x')._items([1])[0][0], str)
    assert isinstance(Exploding('x')._items(set([1]))[0][0], str)
    assert isinstance(Exploding('x')._items(object())[0][0], str)

# Generated at 2022-06-22 18:35:15.576666
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable('x')
    var_2 = BaseVariable('x')
    assert (var_1 == var_2) == True
    assert (var_1 == 'x') == False


# Generated at 2022-06-22 18:35:17.525039
# Unit test for constructor of class Keys
def test_Keys():
    k = Keys('a')
    assert isinstance(k, Keys)

# Generated at 2022-06-22 18:35:22.196854
# Unit test for constructor of class Keys
def test_Keys():
    with pytest.raises(NotImplementedError):
        Keys('x')._format_key('')

    with pytest.raises(NotImplementedError):
        Keys('x')._get_value(None, '')


# Generated at 2022-06-22 18:35:25.280857
# Unit test for constructor of class Exploding
def test_Exploding():
    assert 'a.b' in set([x[0] for x in Exploding('a', exclude='b').items(None)])



# Generated at 2022-06-22 18:35:32.841434
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test(variables, source, frame, expected_result, normalize=False):
        result = variables.items(source, frame, normalize)
        assert isinstance(result, tuple)
        assert len(result) == len(expected_result)
        for pair1, pair2 in zip(result, expected_result):
            assert pair1 == pair2

    class TestItem(dict):
        def __getattr__(self, item):
            return {item: item}

    class TestItem2(TestItem):
        __slots__ = ('a', 'b')

    class TestItem3(TestItem):
        __slots__ = ['b']

    class TestItem4(object):
        def __init__(self):
            self.a = self
        @property
        def b(self):
            return self

# Generated at 2022-06-22 18:35:38.732524
# Unit test for function needs_parentheses
def test_needs_parentheses():
    check_needs_parentheses = utils.Checker(needs_parentheses)
    check_needs_parentheses('x') == False, 'x'
    check_needs_parentheses('foo(1, 2)') == True, 'foo(1, 2)'
    check_needs_parentheses('foo(1)') == False, 'foo(1)'
    check_needs_parentheses('foo') == False, 'foo'
    check_needs_parentheses('foo()') == True, 'foo()'

# Generated at 2022-06-22 18:35:41.946104
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('my_var', exclude=())
    indices_slice = indices[0:1]
    assert indices_slice._slice == slice(0, 1)

# Generated at 2022-06-22 18:35:49.142812
# Unit test for constructor of class Exploding
def test_Exploding():
    """
    >>> e1 = Exploding("x")
    >>> e1._keys()
    Traceback (most recent call last):
        ...
    AttributeError: 'Exploding' object has no attribute '_keys'
    >>> e1._get_value()
    Traceback (most recent call last):
        ...
    AttributeError: 'Exploding' object has no attribute '_get_value'
    >>> e1._format_key()
    Traceback (most recent call last):
        ...
    AttributeError: 'Exploding' object has no attribute '_format_key'
    >>> e1.source
    'x'
    >>> e1.exclude
    ()
    """

# Generated at 2022-06-22 18:35:52.980397
# Unit test for constructor of class Exploding
def test_Exploding():
    a = Exploding('a')
    assert a._items(1) == [('a', '1')]
    assert a._items({'a': 1}) == [('a', '1')]

