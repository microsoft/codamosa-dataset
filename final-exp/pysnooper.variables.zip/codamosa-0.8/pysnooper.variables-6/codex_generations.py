

# Generated at 2022-06-10 21:45:20.554086
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable('x') == BaseVariable('x'))

    assert utils.isIterable(BaseVariable('x'), True)
    assert not utils.isIterable(BaseVariable('x'), False)


# Generated at 2022-06-10 21:45:32.623719
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Test case 1
    indices = Indices('test')
    indices_test1 = indices[:5:2]
    assert indices_test1._fingerprint == (Indices, 'test', ())
    assert indices_test1._slice == slice(0, 5, 2)
    # Test case 2
    indices = Indices('test')
    indices_test2 = indices[:5]
    assert indices_test2._fingerprint == (Indices, 'test', ())
    assert indices_test2._slice == slice(0, 5, 1)
    # Test case 3
    indices = Indices('test')
    indices_test3 = indices[:5:-1]
    assert indices_test3._fingerprint == (Indices, 'test', ())
    assert indices_test3._slice == slice(0, 5, -1)
    #

# Generated at 2022-06-10 21:45:40.795872
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test for equal variables
    s1 = 'zzz'
    s2 = ''
    v1 = BaseVariable(s1, exclude=())
    v2 = BaseVariable(s1, exclude=())
    assert v1 == v2
    v2 = BaseVariable(s2, exclude=())
    assert not v1 == v2
    v2 = BaseVariable(s1, exclude=(s2, ))
    assert not v1 == v2
    # Test for other class
    v2 = dict()
    assert not v1 == v2


# Generated at 2022-06-10 21:45:48.156858
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestBaseVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            BaseVariable.__init__(self, source, exclude)

        def _items(self, main_value, normalize=False):
            return []

    # test class with equal
    a = TestBaseVariable('test_variable')
    b = TestBaseVariable('test_variable')
    assert(a == b)

    # test class with equal
    a = TestBaseVariable('test_variable_1')
    b = TestBaseVariable('test_variable_2')
    assert(a != b)

    # test class with different type
    a = TestBaseVariable('test_variable_1')
    b = Indices('test_variable_1')
    assert(a != b)

# Generated at 2022-06-10 21:45:54.620283
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_a = BaseVariable('var_a')
    var_b = BaseVariable('var_b')
    var_c = BaseVariable('var_a')
    var_d = BaseVariable('var_a', 'b')
    var_e = BaseVariable('var_a', 'a')

    assert var_a != var_b
    assert var_a == var_c
    assert var_a != var_d
    assert var_a == var_e

# Generated at 2022-06-10 21:45:55.893644
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    if __name__ == "__main__":
        variable = BaseVariable('x')
        assert variable.items(frame=None) == ()

# Generated at 2022-06-10 21:45:59.888952
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Variable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]
    variable = Variable('x')
    variable.items(frame_info=None, normalize=False)
    variable.items(frame_info=None, normalize=True)

# Generated at 2022-06-10 21:46:02.566180
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert not BaseVariable('a') == 'a'
    assert not BaseVariable('a') == BaseVariable('b')

# Generated at 2022-06-10 21:46:06.113897
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('1') == BaseVariable('1')
    assert BaseVariable('1') != BaseVariable('2')
    assert BaseVariable('1', exclude=1) != BaseVariable('1')
    assert BaseVariable('1') != 1

# Generated at 2022-06-10 21:46:08.596859
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('iter')
    var_instance = var[::2]

# Generated at 2022-06-10 21:46:25.433789
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys,types
    x = BaseVariable('x')
    frm = sys._getframe()
    x.items(frm)

    x = BaseVariable('[1,2,3]')
    frm = sys._getframe()
    x.items(frm)

    x = BaseVariable('{1,2,3}')
    frm = sys._getframe()
    x.items(frm)

    x = BaseVariable(str)
    frm = sys._getframe()
    x.items(frm)


# Generated at 2022-06-10 21:46:30.454432
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert not BaseVariable('a') == 1

# Generated at 2022-06-10 21:46:38.847984
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe(0)
    v1 = BaseVariable('x')
    assert v1.items(frame, normalize=True) == [('x', '1')]
    v2 = BaseVariable('y')
    assert v2.items(frame, normalize=True) == [('y', '3')]
    v3 = BaseVariable('z')
    assert v3.items(frame, normalize=True) == [('z', '4')]
    v4 = BaseVariable('w')
    assert v4.items(frame, normalize=True) == [('w', '2')]
    v5 = BaseVariable('w', exclude=('x'))
    assert v5.items(frame, normalize=True) == [('w', '{y:3,z:4}')]


# Generated at 2022-06-10 21:46:50.181514
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import traceback_utils
    from . import pycompat
    from .exceptions import TracebackEntry
    from . import variables

    test_source = 'a'
    test_exclude = ('.exclude',)
    test_code = compile(test_source, '<variable>', 'eval')
    test_unambiguous_source = 'a'

    class BaseVariableTest(BaseVariable):
        def __init__(self, source, exclude=()):
            super(BaseVariableTest, self).__init__(source, exclude)

        def _items(self, key, normalize=False):
            pass

    test_obj = BaseVariableTest(test_source, test_exclude)
    assert test_obj.source == test_source
    assert test_obj.exclude == test_exclude
    assert test_obj

# Generated at 2022-06-10 21:46:55.411744
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('__main__.x', exclude=('x.foo',))
    assert indices[:] == Indices('__main__.x', exclude=('x.foo',))
    assert indices[1:-3:] == Indices('__main__.x', exclude=('x.foo',))[1:-3]



# Generated at 2022-06-10 21:47:00.561814
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    a2 = a[1:]
    assert (a2._slice.start == 1)
    assert (a2._slice.stop is None)
    assert (a2._slice.step is None)

    a3 = a[1:4:2]
    assert (a3._slice.start == 1)
    assert (a3._slice.stop == 4)
    assert (a3._slice.step == 2)

# Generated at 2022-06-10 21:47:12.488950
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    seq = range(10)
    vari = Indices('', ())
    result = vari._items(seq)
    expected = [('[0]', repr(seq[0])), ('[1]', repr(seq[1])), \
                ('[2]', repr(seq[2])), ('[3]', repr(seq[3])), \
                ('[4]', repr(seq[4])), ('[5]', repr(seq[5])), \
                ('[6]', repr(seq[6])), ('[7]', repr(seq[7])), \
                ('[8]', repr(seq[8])), ('[9]', repr(seq[9]))]
    assert result == expected
    vari = Indices('', ())[3:7]
    result = vari._items(seq)

# Generated at 2022-06-10 21:47:22.588708
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    li = [0, 1, 2, 3]
    i1 = Indices('li')
    assert i1._keys(li) == range(len(li))
    assert i1[0:2] is not i1
    assert i1[0:2]._keys(li) == range(len(li))[0:2]
    assert i1[0:2]._slice == slice(0, 2)
    li.append(4)
    assert i1._keys(li) == range(len(li))

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:47:24.756861
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices("main")
    print(i[1:7])
test_Indices___getitem__()

# Generated at 2022-06-10 21:47:27.465877
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('url')
    indices = indices[1:3]
    with pytest.raises(AssertionError):
        indices = indices['dummy']

# Generated at 2022-06-10 21:47:49.859936
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("var1")
    var2 = BaseVariable("var2")
    assert var1 != var2


# Generated at 2022-06-10 21:47:54.809644
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert isinstance(a[3:], Indices)
    assert (a[3:]._slice == slice(3, None, None))
    assert (a[:3]._slice == slice(None, 3, None))
    assert (a[3:6]._slice == slice(3, 6, None))


# Generated at 2022-06-10 21:47:58.840286
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Temp:
        pass
    
    temp = Temp()
    temp.a = 1
    temp.b = 2
    temp.c = 3
    source = 'temp'
    s = BaseVariable(source)
    found = s.items(source)
    assert type(found) == tuple
    assert len(found) == 1
    assert found[0][0] == source
    assert found[0][1] == 'Temp()'

# Generated at 2022-06-10 21:48:07.314274
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=('b')) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b')) == BaseVariable('a', exclude=('b'))
    assert BaseVariable('a', exclude=('b')) != BaseVariable('a', exclude=('c'))
    assert BaseVariable('a', exclude=('b')) != BaseVariable('a', exclude=())

# Generated at 2022-06-10 21:48:17.989476
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test true/false scenario of method __eq__
    var_1 = BaseVariable("a_param", ["a_param2"])
    var_2 = BaseVariable("a_param", ["a_param2"])
    var_3 = BaseVariable("a_param", ["a_param2"])
    var_3.exclude = ["a_param3"]

    assert var_1 == var_2
    assert var_1 == var_3 # == is implemented through __eq__
    assert var_2 == var_1
    assert var_2 == var_3
    assert var_3 == var_1
    assert var_3 == var_2
    assert len({var_1, var_2, var_3}) == 2


# Generated at 2022-06-10 21:48:29.438433
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A(object):
        def __init__(self):
            self.b = 1
            self.c = 2
            self.d = 3

    a = A()
    Avar = Attrs('a')
    assert Avar.items(a) == [('a', repr(a)), ('a.b', repr(a.b)), ('a.c', repr(a.c))]
    Avar = Attrs('a', exclude='b')
    assert Avar.items(a) == [('a', repr(a)), ('a.c', repr(a.c))]
    Avar = Attrs('a', exclude=['b'])
    assert Avar.items(a) == [('a', repr(a)), ('a.c', repr(a.c))]

# Generated at 2022-06-10 21:48:34.397177
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('source', exclude=('a'))
    var2 = BaseVariable('source', exclude=('a'))
    var3 = BaseVariable('source1', exclude=('a'))
    var4 = BaseVariable('source', exclude=('b'))
    assert var1 == var2
    assert var1 != var3
    assert var1 != var4


# Generated at 2022-06-10 21:48:39.149921
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    >>> a = BaseVariable('args[0]')
    >>> b = BaseVariable('args[0]')
    >>> a == b
    True

    >>> c = BaseVariable('args[0]')
    >>> a == c
    True
    """


# Generated at 2022-06-10 21:48:44.900773
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable(10)
    bv2 = BaseVariable(10)
    bv3 = BaseVariable('abc')
    bv4 = BaseVariable(10, 'abc')
    bv5 = BaseVariable('abc')
    assert bv1 == bv2
    assert not bv1 == bv3
    assert not bv1 == bv4
    assert bv3 == bv4
    assert bv4 == bv3
    assert bv3 == bv5
    assert bv5 == bv3


# Generated at 2022-06-10 21:48:48.997490
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('abc') == BaseVariable('abc')
    assert BaseVariable('abc') != BaseVariable('def')
    assert BaseVariable('abc') != BaseVariable('def', exclude='xyz')
    assert BaseVariable('abc') != BaseVariable('abc', exclude='xyz')

# Generated at 2022-06-10 21:49:13.820858
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    assert a[:]._slice == slice(None)
    b = a[1:]
    assert b._slice == slice(1, None, None)
    assert b._fingerprint == (Indices, "a", ())

# Generated at 2022-06-10 21:49:21.208729
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    "Test for BaseVariable.__eq__ method"
    import inspect
    import random
    from . import pycompat

    # Prepare list of classes to test
    cls_list = []
    for name, obj in inspect.getmembers(sys.modules[__name__]):
         if inspect.isclass(obj):
             if BaseVariable in obj.__bases__ and obj != BaseVariable:
                 cls_list.append(obj)
    # Test class against each other
    for cls in cls_list:
        for cls2 in cls_list:
            sample_list = [cls(1,2), cls("2",3), cls("3", "3")]
            sample_list.extend((cls("4", "4"), cls("5", "5"))*10)

# Generated at 2022-06-10 21:49:30.681573
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import threading
    from pprint import pprint
    from threading import Thread

    a,b,c = 1,2,3
    # Print a traceback only first call, every subsequent call is in tb.
    # t = Thread(target=a, name='test_BaseVariable', args=(b,c))
    t = Thread(target=a, name='test_BaseVariable')
    tb = types.TracebackType(t.ident, a, b, c)
    # tb = types.TracebackType(t.ident, a)
    pprint(inspect.getframeinfo(tb))
    pprint(inspect.getframeinfo(tb.tb_frame))

# Generated at 2022-06-10 21:49:41.810053
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class FakeFrame(object):
        def __init__(self, globals, locals):
            self.f_globals = globals
            self.f_locals = locals

    globals = {'list1': [1, 2, 3]}
    locals = {'list2': [4, 5, 6]}

    # Test case: the instance is of type Attrs
    a = Attrs('list1')
    items = a.items(FakeFrame(globals, locals))
    assert items[0][0] == 'list1'
    assert items[0][1] == '[1, 2, 3]'
    assert items[1][0] == 'list1.append'
    assert items[1][1] == '<built-in method append of list object at ...>'

# Generated at 2022-06-10 21:49:52.685942
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import variables
    import py
    import sys
    import abc
    from copy import deepcopy
    import types
    import itertools
    import abc
    try:
        from collections.abc import Mapping, Sequence
    except ImportError:
        from collections import Mapping, Sequence
    from copy import deepcopy
    
    def run(test):
        
        test.globals = globals()
        test.globals['run'] = run
        
        frame = sys._getframe()
        while frame.f_globals is globals():
            frame = frame.f_back
        test.globals['frame'] = frame
        
        pytest.test(test)
        
        del test.globals['frame']

# Generated at 2022-06-10 21:49:55.151822
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    baseVariable = BaseVariable('source')
    assert baseVariable.__eq__(baseVariable)
    assert baseVariable.__eq__(None) == False


# Generated at 2022-06-10 21:49:56.456117
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices1 = Indices('a')
    assert indices1[0] == 1


# Generated at 2022-06-10 21:50:06.414982
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os

    class BaseVariable_items_test1_class(object):
        def test_function(self, arg1, arg2, arg3):
            x=1+1
            y=2*2
            z=3*3
            return x+y+z

    class BaseVariable_items_test2_class(object):
        def test_function(self, arg1, arg2, arg3):
            x=1+1
            y=2*2
            z=3*3
            return x+y+z

    obj = BaseVariable_items_test1_class()
    obj.__dict__['my_var'] = 36
    #obj = BaseVariable_items_test2_class()
    #obj.__dict__['my_var'] = 36        
    dict = {}

# Generated at 2022-06-10 21:50:16.629919
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    # test the class CommonVariable
    class Base(object):
        pass

    x = {'a': 1}
    base = BaseVariable('x', exclude=['a'])
    assert base.items(Base().__dict__) == [('x', "{'a': 1}")]

    class Test1(CommonVariable):
        def _keys(self, main_value):
            return ['b']

        def _format_key(self, key):
            return '{0}'.format(key)

        def _get_value(self, main_value, key):
            return main_value[key]

    base1 = Test1('x')

# Generated at 2022-06-10 21:50:27.238549
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class SimpleVariable(BaseVariable):
        def __init__(self, source):
            self.source = source
            self.code = compile(source, '<variable>', 'eval')
    v = SimpleVariable('a')
    assert v.items(frame={'a': 1, 'b': 2}) == [('a', '1')]
    assert v.items(frame={'a': 'hello', 'b': 2}) == [('a', "'hello'")]
    assert v.items(frame={'a': [1, 2, 3], 'b': 2}, normalize=True) == [('a', '[1, 2, 3]')]
    assert v.items(frame={'a': [1, 2, 3], 'b': 2}) == [('a', '[...]')]

# Generated at 2022-06-10 21:50:52.356695
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class testVariable(CommonVariable):
        pass
    a = testVariable('a', exclude=())
    b = testVariable('a', exclude=('a', 'b'))
    c = testVariable('b', exclude=('a', 'b'))
    assert a == testVariable('a', exclude=())
    assert a != b
    assert b == c
    assert c != a
#-----------------------------------------------------------



# Generated at 2022-06-10 21:51:04.681511
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize a dict
    frame_locals = dict()
    frame_locals['x'] = 'x'
    frame_locals['y'] = 'y'
    frame_globals = dict()
    frame_globals['y'] = 'y'

    frame_globals['class'] = 'class' # Magic variable in pyhton
    frame_globals['yield'] = 'yield' # Magic variable in pyhton
    frame_globals['.trace_id'] = 'trace_id' # Magic variable in pyhton
    frame_locals['lambda'] = 'lambda' # Magic variable in pyhton
    frame_locals['._tag_'] = '_tag_' # Magic variable in pyhton
    frame_locals['time'] = 'time' # Magic variable in pyh

# Generated at 2022-06-10 21:51:12.554545
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    def my_func(*args):
        return args

    class MyClass:
        pass

    my_class = MyClass
    my_class.foo = "bar"
    my_class.__dict__['foo'] = "bar"
    my_class.__slots__ = ['foo']

    class MySlottedClass:
        __slots__ = ['foo']

    my_slotted_class = MySlottedClass
    my_slotted_class.foo = "bar"

    class MyClassWithSlottedDict(Mapping):
        __slots__ = ['__dict__']

    my_class_with_slotted_dict = MyClassWithSlottedDict()
    my_class_with_slotted_dict['foo'] = 'bar'


# Generated at 2022-06-10 21:51:19.456486
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    c = BaseVariable('a', 'c')
    assert a == b, "BaseVariable instance not equal to other identical BaseVariable instance."
    assert a != c, "BaseVariable instance equal to other BaseVariable instance with different exclude."
    assert a != "a", "String equal to BaseVariable instance."
    assert a != object(), "Object equal to BaseVariable instance."

# Generated at 2022-06-10 21:51:21.348387
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    assert indices[1:2] == indices[1:2]

# Generated at 2022-06-10 21:51:28.695953
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from sentry_sdk.hub import Hub
    from sentry_sdk.integrations import Integration

    # Default
    frame = Hub.current.get_connection().foreground_context.get_frame()
    v1 = BaseVariable("frame.f_locals")
    v2 = BaseVariable("frame.f_locals")
    assert v1 == v2

    # Not an instance
    v3 = {}
    assert v1 != v3

    # Change value of the variable source
    v4 = BaseVariable("frame.f_globals")
    assert v1 != v4

    # Change value of the variable exclude
    v5 = BaseVariable("frame.f_locals", exclude="f_locals")
    assert v1 != v5

    # Change type of the variable exclude

# Generated at 2022-06-10 21:51:37.524548
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Variable_(BaseVariable):
        def __init__(self, i, j):
            self.i = i
            self.j = j
            super(Variable_, self).__init__('source')

    assert Variable_('a', 'b') == Variable_('a', 'b')
    assert Variable_('a', 'b') != Variable_('a', 'c')
    assert Variable_('a', 'b') != Variable_('b', 'b')
    assert Variable_('a', 'b') != Attrs('source')

# Generated at 2022-06-10 21:51:45.241851
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # __eq__ should return True when both instances are the same
    bv1, bv2 = BaseVariable('a'), BaseVariable('a')
    assert bv1 == bv2

    # __eq__ should return False if the instances are different
    bv2 = BaseVariable('a')
    assert bv1 != bv2

    # __eq__ is commutative
    assert bv1 == bv2 and bv2 == bv1


# Generated at 2022-06-10 21:51:48.208529
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")[0:2]
    assert a._slice.start == 0
    assert a._slice.stop == 2
    assert a._slice.step == None


# Generated at 2022-06-10 21:51:49.401058
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-10 21:53:05.823328
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    method = getattr(BaseVariable, '__eq__', lambda self, other: None)
    assert method(BaseVariable('a'), BaseVariable('a')) is True
    assert method(BaseVariable('a'), BaseVariable('b')) is False
    assert method(BaseVariable('a'), BaseVariable('a', exclude='a')) is False
    assert method(BaseVariable('a'), BaseVariable('a', exclude='b')) is False


# Generated at 2022-06-10 21:53:15.194740
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pprint import pprint
    from . import mock
    local_vars = {'a': 'apple'}
    exp = BaseVariable('a').items(mock.Mock(f_locals=local_vars))
    assert len(exp) == 1
    assert exp[0][0] == 'a'
    assert exp[0][1] == 'apple'
    local_vars = {'a': ['apple', 'applet', 'appletree']}
    exp = BaseVariable('a').items(mock.Mock(f_locals=local_vars))
    assert len(exp) == 4
    assert exp[0][0] == 'a'
    assert exp[0][1] == "['apple', 'applet', 'appletree']"

# Generated at 2022-06-10 21:53:17.877648
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    m1 = BaseVariable("main_value", "exclude")
    m2 = BaseVariable("main_value", "exclude")
    assert m1 == m2

# Generated at 2022-06-10 21:53:28.114451
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable1 = BaseVariable("variable1")
    variable2 = BaseVariable("variable2")
    variable3 = BaseVariable("variable1")
    variable4 = BaseVariable("variable1", exclude=("exclude"))
    variable5 = BaseVariable("variable1", exclude=("exclude1"))
    variable6 = BaseVariable("variable1", exclude=("exclude"))

    assert variable1 == variable1
    assert variable1 == variable3
    assert variable1 != variable2
    assert variable1 != variable4
    assert variable1 != variable5
    assert variable4 == variable6
    return "test_BaseVariable___eq__ passed successfully"

print(test_BaseVariable___eq__())

# Generated at 2022-06-10 21:53:34.942907
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    for _ in range(1000):
        v1 = BaseVariable('a', 'b')
        v2 = BaseVariable('a', 'b')
        v3 = BaseVariable('a')
        v4 = BaseVariable('a', 'b')
        v5 = BaseVariable('c', 'd')

        assert v1 == v2
        assert v1 == v4
        assert v1 != v3
        assert v1 != v5


# Generated at 2022-06-10 21:53:39.739972
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .utils import get_shortish_repr
    def test(obj):
        print (obj[1:3])
        print (obj[:5])
        print (obj[5:])
        print (obj[1:6:2])

    x = list(range(6))
    test(Indices(x))
    test_Indices___getitem__.x = x
    test(Indices('x'))


test_Indices___getitem__()

# Generated at 2022-06-10 21:53:43.993144
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    print('Indices original', indices.source)
    new_indices = indices[10:20]
    print('Indices new', new_indices.source)
    print('Indices new slice', new_indices._slice)



# Generated at 2022-06-10 21:53:50.969933
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    temp = BaseVariable("source", "exclude")
    temp.source = "source"
    temp.exclude = "exclude"
    
    BaseVariable.__eq__(temp, BaseVariable("source", "exclude"))
    assert BaseVariable.__eq__(temp, BaseVariable("source2", "exclude")) == False
    assert BaseVariable.__eq__(temp, BaseVariable("source", "exclude2")) == False
    
# test for method __hash__ of class BaseVariable

# Generated at 2022-06-10 21:54:00.972140
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Case 1: 
    # source: 'self.main_value'
    # main_value: {'a': 10, 'b': 100}
    # frame: frame info
    #   frame.f_globals: None
    #   frame.f_locals: 
    #       'self': object
    #       'main_value': {'a': 10, 'b': 100}
    #   frame.f_back: None
    # 
    # expected: [('self.main_value', '{'a': 10, 'b': 100}')]
    frame = pycompat.get_frame().f_back
    self = object()
    main_value = {'a': 10, 'b': 100}
    source = 'self.main_value'
    exclude = 'key_c'
    frame

# Generated at 2022-06-10 21:54:04.880863
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('foo')[0:100]
    assert var.source == 'foo'
    assert var.exclude == ()
    assert var._slice == slice(0, 100, None)