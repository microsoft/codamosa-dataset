

# Generated at 2022-06-10 21:45:18.240728
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable(source = "main_value", exclude= ())
    bv2 = BaseVariable(source = "main_value", exclude= ())
    bv3 = BaseVariable(source = "main_valuem", exclude= ())

    assert bv1 == bv2
    assert bv1 != bv3


# Generated at 2022-06-10 21:45:23.429881
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Case(BaseVariable):
        def __init__(self, class_name, source, exclude):
            BaseVariable.__init__(self, source, exclude)
        def items(self, frame, normalize=False):
            return ()
    a = Case('Case', 'a.b.c', ('x', 'y'))
    b = Case('Case', 'a.b.c', ('x', 'y'))
    c = Case('Case', 'a.b.c', ('x',))
    assert (a == a)
    assert (a == b)
    assert (a != c)

# Generated at 2022-06-10 21:45:26.128677
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var_test = BaseVariable('data', 'excluded')
    assert var_test.items() == ()

# Generated at 2022-06-10 21:45:32.338085
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('foo')
    new_var = var[:1]
    assert (new_var.source == 'foo')
    a=[1,2,3]
    frame = pycompat.sys._getframe()
    frame.f_locals['foo'] = a
    assert (list(new_var.items(frame)) == [('foo[0]', '1')])



# Generated at 2022-06-10 21:45:44.032584
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test(var, frame, expected):
        assert list(var.items(frame)) == expected

    # Invoke the function with a sample of variables
    test(Attrs('x'), utils.make_fake_frame({'x': ComplexNumber(1, 2)}),
         [('x', 'ComplexNumber'), ('x.real', '1'), ('x.imag', '2')])

    test(Keys('x'), utils.make_fake_frame({'x': {1: 2, 'a': 'b'}}),
         [('x', "{1: 2, 'a': 'b'}"), ('x[1]', '2'), ("x['a']", "'b'")])


# Generated at 2022-06-10 21:45:49.125448
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a.b')[1:3]
    items = sorted(var.items(frame)[0] for frame in [
        frame_factory({'a': {'b': [6, 7, 8, 9]}})
    ])
    assert items == [('a.b[1]', '7'), ('a.b[2]', '8')]

# Generated at 2022-06-10 21:45:50.093381
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('')[:]


# Generated at 2022-06-10 21:45:57.555170
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    I = Indices('f')
    assert I[:]._slice == slice(None)
    assert I[1:5]._slice == slice(1, 5)
    assert I[1:]._slice == slice(1, None)
    assert I[:-5]._slice == slice(None, -5)
    assert I[:-5:2]._slice == slice(None, -5, 2)
    assert I[:5:2]._slice == slice(None, 5, 2)
    assert I[1::2]._slice == slice(1, None, 2)



# Generated at 2022-06-10 21:46:00.930249
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[:] is not indices
    assert indices[:] == indices
    assert indices[::2] == Indices('a', exclude=())._slice_obj(slice(0, None, 2))
    assert indices[1:100] == Indices('a', exclude=())._slice_obj(slice(1, 100))


# Generated at 2022-06-10 21:46:11.966624
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        a = {'b': 1}
        c = [1, 2]
        return (a, c)

    frame = inspect.currentframe().f_back.f_back

    # Items of variable 'a'
    variable = BaseVariable('a')
    print(variable.items(frame))
    assert variable.items(frame) == [('a', "{'b': 1}")]

    # Items of variable 'b'
    variable = BaseVariable('a.b')
    print(variable.items(frame))
    assert variable.items(frame) == [('a.b', '1')]

    # Items of variable '(a, c)'
    variable = BaseVariable('(a, c)')
    print(variable.items(frame))

# Generated at 2022-06-10 21:46:19.953930
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('abc')
    var2 = BaseVariable('abc')
    print('var1 == var2 = {}'.format(var1 == var2))
    var3 = BaseVariable('xyz')
    print('var1 == var3 = {}'.format(var1 == var3))


# Generated at 2022-06-10 21:46:25.643107
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Arrange
    explode = Exploding('x')
    x = [0, 1, 2, 3, 4]
    # Act
    rv = explode._items(main_value=x, normalize=False)
    # Assert
    assert(rv == [('x', '[0, 1, 2, 3, 4]'), ('x[0]', '0'),
                  ('x[1]', '1'), ('x[2]', '2'), ('x[3]', '3'),
                  ('x[4]', '4')])


# Generated at 2022-06-10 21:46:29.115845
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('x')[1::1]
    assert variable.items(None) == []
    variable = Indices('y')[1::1]
    assert variable.items(None) == []


# Generated at 2022-06-10 21:46:38.106437
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A:
        d = {'a': 1, 3:4}
        attr = 5
        @property
        def prop(self):
            return 'd' + str(len(self.d))

    class B(A):
        def __init__(self):
            self.prop2 = 7

    b = B()
    assert BaseVariable('a').items(locals()) == []
    assert BaseVariable('b').items(locals()) == [('b', '<object of class `B`>')]
    assert Attrs('b.d').items(locals()) == [('b.d', '{3: 4, \'a\': 1}')]

# Generated at 2022-06-10 21:46:46.290998
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import io
    test_code = '''
a = {'a': 1, 'b': 2}
'''
    backup = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = io.StringIO(), io.StringIO()

    vm = utils.steal_locals(test_code, globals())
    bv = BaseVariable('a', exclude=['b'])
    result = bv.items(vm.frame)
    print(result)

    sys.stdout, sys.stderr = backup

# Generated at 2022-06-10 21:46:49.299396
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    item = slice(0, 0, 1)
    Indices('Indices', exclude=()).__getitem__(item)



# Generated at 2022-06-10 21:46:52.150266
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', 'b')
    var2 = Attrs('a', 'b')
    assert var1 == var2 and var2 == var1


# Generated at 2022-06-10 21:46:54.971439
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x').__eq__(BaseVariable('y')) == False
    assert BaseVariable('x').__eq__(BaseVariable('x')) == True



# Generated at 2022-06-10 21:47:03.045036
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pdb
    # set b_source and frame to some hardcoded values
    b_source = 'x'
    frame = pdb.set_trace()
    frame.f_globals['x'] = 'dummy_value'
    base = BaseVariable(b_source)
    assert(base.items(frame) == [('x', "b'dummy_value'")])

    # set b_source and frame to some hardcoded values
    b_source = 'x'
    frame = pdb.set_trace()
    frame.f_globals['x'] = ['dummy_value', 'dummy_value2']
    keys = Keys(b_source)

# Generated at 2022-06-10 21:47:06.292639
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class MyVar(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()

    var = MyVar('abc')
    assert var.items({}) == ()

# Unit tests for function needs_parentheses

# Generated at 2022-06-10 21:47:27.759315
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a', 'b').items({'a':[1,2,3,4,5]}) == [('a', '[1, 2, 3, 4, 5]')]
    assert BaseVariable('a', 'b').items({'a':{'c':1}}) == [('a', '{}')]
    assert BaseVariable('a', 'b').items({'a':{'c':1, 'd':2}}) == [('a.c', '1'), ('a.d', '2')]
    assert BaseVariable('a', 'b').items({'a':[1,2,3,4,5]}, normalize=True) == [('a', '[1, 2, 3, 4, 5]')]

# Generated at 2022-06-10 21:47:34.916467
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Testing for different classes of the same type
    assert Keys('a', 'b') == Attrs('a', 'b')
    assert Attrs('a') == Indices('a')
    # Test for different attributes source
    assert Keys('a') != Keys('b')
    # Test for different attributes exclude
    assert Keys('a', 'b') != Keys('a')
    # Test for different classes
    assert Keys('a', 'b') != BaseVariable('a', 'b')
    # Test for True
    assert Keys('a') == Keys('a')
    assert Keys('a', 'b') == Keys('a', 'b')


# Generated at 2022-06-10 21:47:46.903269
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from collections import defaultdict

    main_value = defaultdict(lambda: defaultdict(str))
    for i in range(4):
        for j in range(4):
            main_value[i][j] = str(i) + '_' + str(j)

    variable = Indices(source = 'main_value')
    items = variable._items(main_value)
    assert len(items) == 16
    for (i, j) in itertools.product(range(4), range(4)):
        assert (items[i*4+j][0] == 'main_value[{}][{}]'.format(i, j))
        assert (items[i*4+j][1] == '{}_{}'.format(i, j))

    variable = variable[:2]
    items = variable._items

# Generated at 2022-06-10 21:47:53.417660
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    a_slice_1 = a[1:]
    assert a_slice_1.source == 'a'
    assert a_slice_1._slice == slice(1, None)
    a_slice_1_2 = a_slice_1[1:3]
    assert a_slice_1_2.source == 'a'
    assert a_slice_1_2._slice == slice(1, 3)

# Generated at 2022-06-10 21:47:55.708767
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    l = [1]
    d = {1:1}
    var = 'l[1]'
    assert len(Attrs(var).items(l))==0
    assert len(Attrs(var).items(d))==0
    assert len(Keys(var).items(l))==0
    assert len(Keys(var).items(d))==2
    assert len(Exploding(var).items(l))==0
    assert len(Exploding(var).items(d))==2


# Generated at 2022-06-10 21:47:59.256810
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Test(BaseVariable):
        def __init__(self, source, exclude=()):
            super(Test, self).__init__(source, exclude)

        def _items(self, main_value, normalize=False):
            return []

    v = Test('foo')
    expected = []
    actual = v.items({'foo': 'bar'})
    assert expected == actual



# Generated at 2022-06-10 21:48:04.519336
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable('a')
    variable_eq = BaseVariable('a')
    variable_not_eq = BaseVariable('a.x')

    result = []
    result.append(variable == variable_eq)
    result.append(variable != variable_not_eq)

    return result


# Generated at 2022-06-10 21:48:15.710019
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a'
    frame = {'a': 'a_value'}
    frame['a1'] = frame['a']
    frame['a2'] = frame
    frame['a3'] = frame['a1']
    exclude = {'a2'}
    variables = [Attrs(source, exclude), Keys(source, exclude), Indices(source, exclude), Exploding(source, exclude)]
    variables_name = ['Attrs', 'Keys', 'Indices', 'Exploding']

# Generated at 2022-06-10 21:48:18.286583
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
   indices = Indices('a')
   assert type(indices) == Indices
   result = indices[0:5]
   assert type(result) == Indices
   assert result._slice == slice(0,5)



# Generated at 2022-06-10 21:48:29.729848
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import Frame
    import sys
    class DummyClass(object):
        attr = 'dummy_attr_value'
        def __init__(self, id):
            self.id = id
        def dummy_method(self):
            pass
    dummy_instance = DummyClass(id='dummy_instance_id')
    dummy_instance_attr = dummy_instance.attr
    def dummy_func(text, pos=0,vars={}):
        '''
        this is a dummy function
        '''
        if '_globals' in vars:
            globals().update(vars['_globals'])
        print ('dummy function' + text + str(vars))

    frame_dummy_func = Frame(dummy_func)
    frame_dummy_func.f_

# Generated at 2022-06-10 21:48:52.502194
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    item = slice(1,5)
    result = Indices('timeline').__getitem__(item)
    assert(result._slice == item)

# Generated at 2022-06-10 21:48:57.974632
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('') == BaseVariable('')
    assert BaseVariable('', '') == BaseVariable('', '')
    assert BaseVariable('', ()) == BaseVariable('', ())

    assert BaseVariable('') != BaseVariable('', ())
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('', 'a') != BaseVariable('', 'b')
    assert BaseVariable('', 'a') != BaseVariable('', 'a', 'b')
    assert BaseVariable('', 'a') != BaseVariable('', ('a', 'b'))
    assert BaseVariable('', ('a', 'b')) != BaseVariable('', ('a', 'c'))

# Generated at 2022-06-10 21:49:02.320781
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    ob1 = BaseVariable("a")
    ob2 = BaseVariable("a")
    ob3 = BaseVariable("b")
    print(ob1 == ob1) # True
    print(ob1 == ob2) # True
    print(ob1 == ob3) # False


# Generated at 2022-06-10 21:49:12.833998
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    count = 0
    def fake_exec_statement(code, frame, namespace):
        global count
        count += 1
        if count == 1:
            return {'a': {'b': {'c': {'d': 'e'}, 'f': 'g'}}}

# Generated at 2022-06-10 21:49:15.300391
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('a', 'b')
    assert var1 == var2
    

# Generated at 2022-06-10 21:49:21.595444
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') == BaseVariable('a', ('b',))
    assert BaseVariable('a', ('b',)) == BaseVariable('a', 'b')
    assert BaseVariable('a', ('b', 'c')) == BaseVariable('a', ('c', 'b'))
    assert BaseVariable('a', ('b', ('c', 'd'))) == BaseVariable('a', ('c', ('b', 'd')))
    assert BaseVariable('a', ('b', ('c', 'd'))) != BaseVariable('a', ('d', ('b', 'c')))


# Generated at 2022-06-10 21:49:23.419719
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print(Indices('__name__')[1:])
    assert Indices('__name__')[1:] == Indices('__name__')[1:]
    assert hash(Indices('__name__')[1:]) == hash(Indices('__name__')[1:])

# Generated at 2022-06-10 21:49:31.509895
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from unittest import TestCase

    class Test(TestCase):
        def test_valid_case(self):
            indices = Indices('source', 'exclude')
            self.assertEqual(slice(0, 1), indices[0:1])

        def test_invalid_type(self):
            indices = Indices('source', 'exclude')

            with self.assertRaises(AssertionError):
                indices['0:1']

            with self.assertRaises(AssertionError):
                indices[0.0]

    Test().test_valid_case()
    Test().test_invalid_type()



# Generated at 2022-06-10 21:49:37.638731
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable("params")
    variable2 = BaseVariable("params")
    variable3 = BaseVariable("params", exclude=("name", "b", "c", "d", "e"))
    variable4 = BaseVariable("params", exclude=("name", "b", "c", "d", "e"))
    assert variable == variable2
    assert variable2 == variable
    assert variable3 == variable4
    assert variable4 == variable3

# Generated at 2022-06-10 21:49:46.219569
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Setup
    Idx = Indices('some_list')
    Idx.source = 'some_list'
    Idx.exclude = ()
    Idx.unambiguous_source = 'some_list'
    Idx.code = compile('some_list', '<variable>', 'eval')
    obj = Idx['x':'y']

    # Exercise SUT and verify
    assert obj._fingerprint == Idx._fingerprint

# Generated at 2022-06-10 21:50:01.563732
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    s = Indices('a')
    l1 = list(s._items(['a', 'b', 'c', 'd']))
    l2 = list(s[1:3]._items(['a', 'b', 'c', 'd']))
    assert l2 == [('a[1]', "'b'"), ('a[2]', "'c'")]


# Generated at 2022-06-10 21:50:07.514795
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    test_object = Indices('a')
    assert test_object[1:]._slice == slice(1, None)
    assert test_object[1:]._slice != slice(None)
    assert test_object[:]._slice != slice(1, None)
    assert test_object[4:]._slice != slice(1, None)

test_Indices___getitem__()

# Generated at 2022-06-10 21:50:17.496344
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    from . import utils

    var = Indices('a.b').__getitem__(slice(2,4))
    assert isinstance(var, Indices)
    assert var._slice == slice(2,4)
    res = var.items('a.b', {}, {'a': {'b': [0, 1, 2, 3, 4, 5]}})
    assert isinstance(res, tuple)
    assert res == (('a.b[2]', '2'), ('a.b[3]', '3'))
    var = Indices('a.b').__getitem__(slice(2,4))
    with pytest.raises(AssertionError) as excinfo:
        var.__getitem__('a')

# Generated at 2022-06-10 21:50:21.195207
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('obj')
    assert(obj[0] == Indices('obj[0:]'))
    assert(obj[0:1] == Indices('obj[0:1]'))



# Generated at 2022-06-10 21:50:23.493896
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .python import PythonExecutor

# Generated at 2022-06-10 21:50:31.383996
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .utils import Frame
    from .test_utils import dataset

    frame = Frame(('a', 'b', 'c'), {'a': [1, 2, 3], 'b': {'key': 'value'}, 'c': object()})
    a = Attrs('a', 'b')
    assert a.items(frame) == [('a', '[1, 2, 3]'), ('a.b', '{...}')]
    assert a.items(frame, normalize=True) == [('a', '[1, 2, 3]'), ('a.b', '{...}')]
    k = Keys('b')
    assert k.items(frame) == [('b', "{'key': 'value'}"), (r"b['key']", "'value'")]
    assert k.items(frame, normalize=True)

# Generated at 2022-06-10 21:50:36.104127
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices("source")[::2]._slice == slice(None, None, 2)
    assert Indices("source")[0:10]._slice == slice(0, 10, None)
    assert Indices("source")[10:]._slice == slice(10, None, None)


# Generated at 2022-06-10 21:50:41.214870
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    zero = BaseVariable("zero")
    one = BaseVariable("one", exclude=["zero"])
    two = BaseVariable("two", exclude=["zero", "one"])
    three = BaseVariable("three", exclude=["zero", "one", "two"])
    four = BaseVariable("four", exclude=["zero", "one", "two", "three"])
    five = BaseVariable("five", exclude=["zero", "one", "two", "three", "four"])
    six = BaseVariable("six", exclude=["zero", "one", "two", "three", "four", "five"])
    seven = BaseVariable("seven", exclude=["zero", "one", "two", "three", "four", "five", "six"])

# Generated at 2022-06-10 21:50:44.265204
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('args', exclude=['self'])
    assert(i[1:3]._slice == slice(1,3))


# Generated at 2022-06-10 21:50:47.007868
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable('a', 'b').__eq__(BaseVariable('a', 'b'))

test_BaseVariable___eq__()

# Generated at 2022-06-10 21:51:03.596401
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    d = Indices("d")
    assert d.__getitem__(slice(1,3)) == Indices("d", slice=slice(1,3))
    assert d.__getitem__(slice(2,4,4)) == Indices("d", slice=slice(2,4,4))


# Generated at 2022-06-10 21:51:07.365214
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable('b')
    assert v.items({'b':'c'}) == (('b', 'c'),)
    assert v.items({'b':'c', 'e':'f'}) == (('b', 'c'),)

# Generated at 2022-06-10 21:51:11.585932
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    print(frame)
    s = 'frame'
    _frame_obj = frame.f_locals['frame']
    _source = s
    _code = compile(source=_source, filename='test_BaseVariable.py', mode='eval')
    _main_value = eval(_code, frame.f_globals, frame.f_locals)
    print(_main_value)

# Generated at 2022-06-10 21:51:16.566868
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("x.y")
    assert a.__eq__(a)
    assert not a.__eq__(Keys("x.y"))
    assert not a.__eq__(Attrs("x.y"))
    assert not a.__eq__(Indices("x.y"))


# Generated at 2022-06-10 21:51:24.446783
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("a")
    var2 = BaseVariable("a")
    var3 = BaseVariable("b")
    var4 = BaseVariable("a",["c"])
    var5 = BaseVariable("a")
    var6 = BaseVariable("a",["d"])
    var7 = BaseVariable("a",["c","d"])

    assert var1 == var2
    assert not var1 == var3
    assert not var1 == var4
    assert var1 == var5
    assert not var1 == var6
    assert not var1 == var7


# Generated at 2022-06-10 21:51:28.580626
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    assert indices[2:4] != indices
    for i in range(10):
        assert indices[2:4][i] == indices[i]



# Generated at 2022-06-10 21:51:30.051050
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass
    # TODO

# Generated at 2022-06-10 21:51:33.237664
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var1 = Indices("a")
    var2 = var1[:]
    assert var1.source == var2.source
    assert var1._slice == var2._slice

# Generated at 2022-06-10 21:51:36.294280
# Unit test for method __getitem__ of class Indices

# Generated at 2022-06-10 21:51:47.145069
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    c = BaseVariable(source='1', exclude='2')
    d = BaseVariable(source='1', exclude='2')
    f = BaseVariable(source='1', exclude='3')
    g = BaseVariable(source='2', exclude='2')
    # BaseVariable(source='1', exclude='2') == BaseVariable(source='1', exclude='2')
    assert(c == d)
    # BaseVariable(source='1', exclude='2') != BaseVariable(source='1', exclude='3')
    assert(c != f)
    # BaseVariable(source='1', exclude='2') != BaseVariable(source='2', exclude='2')
    assert(c != g)


# Generated at 2022-06-10 21:52:13.106774
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    try:
        assert BaseVariable('x') == BaseVariable('x')
        assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
        assert BaseVariable('x') != BaseVariable('y')
        assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    except AssertionError as e:
        print(e)

# Generated at 2022-06-10 21:52:16.210617
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Variable('a')
    assert Indices(var)[:] == Indices(var)
    assert Indices(var)[::2] != Indices(var)

# Generated at 2022-06-10 21:52:21.654336
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    original_source = "p"
    frame = test_frame = frame_factory()
    exclude = ["x","y","z"]
    v = BaseVariable(original_source, exclude)
    assert isinstance(v, BaseVariable)
    assert v.items(test_frame) == [('p', '<module \'utils\' from \'' +
                                    utils.__file__ + '\'>')]
    assert v.items(frame, normalize=True) == [('p', '<module \'utils\' from \'' +
                                            os.path.abspath(utils.__file__) + '\'>')]

# Generated at 2022-06-10 21:52:26.279134
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return [(key, key+1)]

    v = TestVariable("x")
    assert v.items("1") == [("x",2)]


# Generated at 2022-06-10 21:52:34.821164
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('filtered_view_name') == BaseVariable('filtered_view_name')
    assert not BaseVariable('filtered_view_name') == 'filtered_view_name'
    assert BaseVariable('filtered_view_name') == BaseVariable('filtered_view_name', 'deleted')
    assert not BaseVariable('filtered_view_name', 'deleted') == BaseVariable('filtered_view_name')
    assert not BaseVariable('filtered_view_name', 'deleted') == BaseVariable('filtered_view_name', 'deleted')
    assert not BaseVariable('filtered_view_name', 'deleted') == BaseVariable('filtered_view_name', 'non_deleted')

# Generated at 2022-06-10 21:52:42.326127
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import unittest
    class TestCase(unittest.TestCase):
        def test_Indices__getitem__(self):
            index = Indices('a')
            index_slice = index[1:]
            self.assertEqual(index_slice.source, 'a')
            self.assertEqual(index_slice._slice, slice(1, None))
    unittest.main(module=__name__)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:52:49.158449
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from nose.tools import assert_is_instance
    # Test slice object
    indices = Indices('some_source')
    result = indices[::-1]
    assert_is_instance(result, Indices)
    assert result._slice == slice(None, None, -1)
    # Test non-slice object
    indices = Indices('some_source')
    try:
        indices[20]
    except AssertionError:
        pass
    else:
        raise AssertionError('AssertionError was not raised.')

# Generated at 2022-06-10 21:52:51.726310
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("var")
    new_var = var[1:]
    assert isinstance(new_var, Indices)
    assert new_var._slice == slice(1, None, None)

# Generated at 2022-06-10 21:52:58.779009
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = '__builtins__'
    source_other = '__builtins__'
    exclude = ('Variable', 'Key', 'Sequence', 'Index')
    exclude_other = ('Variable', 'Key', 'Sequence', 'Index')
    exclude_other_2 = ('Variable', 'Key', 'Sequence',)
    exclude_other_3 = ('Variable', 'Key', 'Sequence', 'Index',)

    baseVariable = BaseVariable(source=source,exclude=exclude)
    baseVariable_ = BaseVariable(source=source_other,exclude=exclude)
    baseVariable_2 = BaseVariable(source=source_other,exclude=exclude_other)
    baseVariable_3 = BaseVariable(source=source_other,exclude=exclude_other_2)

# Generated at 2022-06-10 21:53:00.974766
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('b')
    assert ind['c':'d'] == ind['c':'d']



# Generated at 2022-06-10 21:53:57.856267
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import pdb
    import inspect
    import dis

    class BaseVariableTest(BaseVariable):
        def __init__(self,source,exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def _items(self, key, normalize=False):
            return self.source

        def _fingerprint(self):
            return (type(self), self.source, self.exclude)

        # def __hash__(self):
        #     return hash(self._fingerprint)



# Generated at 2022-06-10 21:54:10.692123
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import print_exception_info
    from . import utils
    from . import pycompat
    from . import variables

    md = dict(globals())
    md.update(locals())
    md.update(dict(utils=utils, pycompat=pycompat, variables=variables))

# Generated at 2022-06-10 21:54:12.631308
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')


test_BaseVariable___eq__()

# Generated at 2022-06-10 21:54:20.206729
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class test:
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = exclude
    a = BaseVariable(test(source=1, exclude=2))
    b = BaseVariable(test(source=1, exclude=2))
    c = BaseVariable(test(source=1, exclude=3))
    d = BaseVariable(test(source=3, exclude=3))
    assert a == b
    assert not (a == c)
    assert not (a == d)
    # Test wrong type
    assert a != None
    assert a != 'Test'

# Generated at 2022-06-10 21:54:24.929285
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {
            'a': 1,
            'b': 2,
            'c': 3
    }
    var = BaseVariable('a')
    assert var.items(frame) == [('a', '1')]
    var = BaseVariable('a+b')
    assert var.items(frame) == [('(a+b)', '3')]
    var = BaseVariable('a+b', exclude=('c',))
    assert var.items(frame) == [('(a+b)', '3')]
    var = BaseVariable('c', exclude=('c',))
    assert var.items(frame) == [('c', '3')]


# Generated at 2022-06-10 21:54:29.417517
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('main_value')
    indices_slice = indices[0:3]

    assert len(indices_slice.source) > 0
    assert len(indices_slice.exclude) >= 0
    assert len(indices_slice._fingerprint) >= 3

# Generated at 2022-06-10 21:54:38.119023
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # The class inherits from abc, so testing is a bit tricky
    # https://github.com/dropbox/pytest-trio/issues/98

    class TestVariable(BaseVariable):
        def _items(self, main_value):
            return self.source, main_value

    # Testing abc type.
    assert isinstance(TestVariable('a') ,BaseVariable) is True

    # Testing items method.
    assert TestVariable('a').items(frame) == ('a', 'b')
    assert TestVariable('a').items(frame, normalize=True) == ('a', 'b')


# Generated at 2022-06-10 21:54:44.643522
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('entity.__dict__');
    obj1 = obj.__getitem__(slice(1,3))
    assert(str(obj1) == "Indices('entity.__dict__'[1:3])")
    assert(obj.__getitem__(slice(0,10)) ==
           Indices('entity.__dict__'[0:10]))
    assert(obj.__getitem__(slice(0,2)) ==
           Indices('entity.__dict__'[0:2]))

# Generated at 2022-06-10 21:54:56.718561
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from inspect import currentframe
    frame = currentframe()
    x = 10
    test = {'this_is': 'my_test',
            'name': 'Inspecting the source of this frame',
            'frame': frame}

    class MyClass():
        def __init__(self):
            self.c = 1

    myclass = MyClass()
    myclass.a = 2
    myclass.b = 3

    with pytest.raises(NotImplementedError):
        BaseVariable('x')._items(x, normalize=False)

# Generated at 2022-06-10 21:54:58.169556
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v1 = Indices('x')
    v2 = v1[2:5]
    assert isinstance(v2, Indices)
    assert v2._slice == slice(2,5)