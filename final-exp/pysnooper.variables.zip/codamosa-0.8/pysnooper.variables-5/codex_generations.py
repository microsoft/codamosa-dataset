

# Generated at 2022-06-10 21:45:32.904394
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import timeit
    frame_info = sys._getframe()
    a = 1
    b = 'abc'
    c = {'d': 2, 'e': 'fgh', 'g': [{'h': 3}, 3, 4]}

    # Test for class Attrs
    print('\nTest for class Attrs:')
    attrs = Attrs('c', exclude=('d', 'e'))
    print(attrs.items(frame_info))
    print('a.__dict__', attrs.items(frame_info, normalize=True))
    print('a.__slots__', attrs.items(frame_info, normalize=True))

    # Test for class Keys
    print('\nTest for class Keys:')

# Generated at 2022-06-10 21:45:36.936072
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test case 1
    a1 = 'function1'
    a2 = 'function2'
    result = utils.BaseVariable(a1,a2)
    expected = utils.BaseVariable(a1, a2)
    assert result == expected


# Generated at 2022-06-10 21:45:40.447972
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    b = BaseVariable(source='a', exclude='b')
    assert b.items(frame=None) == ()
    assert b.items(frame=None, normalize=True) == ()

# Generated at 2022-06-10 21:45:44.827298
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from types import SimpleNamespace
    a = SimpleNamespace()
    a.x = [1,2,3,4,5]
    ind = Indices('a.x')
    sliced = ind[2:4]
    assert isinstance(sliced, Indices)
    assert sliced != ind

test_Indices___getitem__()

# Generated at 2022-06-10 21:45:55.634562
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1
    # Setup test
    # Test object
    class SafeMapping(Mapping):
        def __getitem__(self, key):
            return None
        def __len__(self):
            return 1
        def __iter__(self):
            return iter(['a'])
    class TestObject():
        def __init__(self, v):
            self.a = v
        def __len__(self):
            return len(self.a)
        def __getitem__(self, key):
            return self.a[key]
    main_value = TestObject(SafeMapping())
    frame = None
    # Test
    items = BaseVariable('', '').items(frame, False)
    # Verification
    assert items == ()

    # Test 2
    # Setup test
    # Test object


# Generated at 2022-06-10 21:46:04.715605
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()
    keys = BaseVariable(frame.f_code.co_name).items(frame)
    names = []
    for name, _ in keys:
        names.append(name)
    assert names == [
        'keys',
        'frame.f_code.co_name',
        'frame.f_lineno',
        'frame.f_lasti',
        'frame.f_trace',
        'frame.f_exc_traceback',
        'frame.f_globals',
        'frame.f_locals'
    ]
    keys = BaseVariable('frame.f_locals', exclude='keys').items(frame)
    names = []
    for name, _ in keys:
        names.append(name)

# Generated at 2022-06-10 21:46:08.999146
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = Attrs('var1')
    var2 = Attrs('var2')
    var3 = Attrs('var1')
    print(var1==var2)
    print(var1==var3)


# Generated at 2022-06-10 21:46:14.376934
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("a ")
    v2 = BaseVariable("b")
    v3 = BaseVariable("b")
    assert (v1 == v2) == False
    assert (v2 == v3) == True
    assert (v1 == v3) == False

# Generated at 2022-06-10 21:46:25.522487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import string
    import random

    class Test:
        def __init__(self, max_depth, child_count, child_class, name=''):
            self.name = name
            if max_depth > 0:
                self.children = [
                    child_class(
                        max_depth - 1,
                        child_count,
                        child_class,
                        name + '{}.'.format(i)
                    )
                    for i in range(random.randrange(child_count) + 1)
                ]

        def __repr__(self):
            return '<{}: {}>'.format(type(self).__name__, self.name)


# Generated at 2022-06-10 21:46:30.131797
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # test
    x = BaseVariable("a", ["b"])
    x1 = BaseVariable("a", ["b"])
    x2 = BaseVariable("a", ["b", "c"])
    x3 = BaseVariable("a")

    # verify
    assert x == x1 and x != x2 and x != x3

# Generated at 2022-06-10 21:46:42.480475
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable('data', exclude=['d'])
    frame = type('Frame', (), {'f_locals': {'data': {'a': 1, 'b': 2, 'c': 3, 'd': 4}}})()
    assert v.items(frame) == [('data', '{...}'), ('data.a', '1'), ('data.b', '2'),
                              ('data.c', '3'), ('data[d]', '4')]

# Generated at 2022-06-10 21:46:44.339104
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('a')
    ind1 = ind[:]
    assert ind1 is not ind

# Generated at 2022-06-10 21:46:56.258682
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import ast
    import os
    import sys
    import inspect
    import types

    class Frame:
        def __init__(self, f_globals, f_locals):
            self.f_globals = f_globals
            self.f_locals = f_locals

    class FrameBuilder:
        def __init__(self):
            self.f_globals = {}
            self.f_locals = {}

        def return_frame(self):
            return Frame(f_globals=self.f_globals, f_locals=self.f_locals)

        def add_globals(self, name, value):
            self.f_globals[name] = value
            return self


# Generated at 2022-06-10 21:46:59.048701
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[::2]._slice == slice(None, None, 2)
    assert Indices('x')[2:4]._slice == slice(2, 4)

# Generated at 2022-06-10 21:47:04.996256
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable_one = BaseVariable('one')
    variable_one_same = BaseVariable('one')
    variable_two = BaseVariable('two')
    variable_one_different = BaseVariable('one', exclude=('two', 'three'))

    assert variable_one == variable_one_same
    assert variable_one != variable_two
    assert variable_one != variable_one_different


# Generated at 2022-06-10 21:47:13.181316
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_case(source, exclude, expected_result):
        variable = BaseVariable(source, exclude)
        frame = {}
        actual_result = variable.items(frame, normalize=False)
        if actual_result != expected_result:
            print(actual_result, expected_result)
    test_case('x', (), [])
    test_case('x', (), [('x', '<NotFound>')])
    test_case('x', (), [('x', 'x')])
    test_case('x', (), [('y', '<NotFound>')])



# Generated at 2022-06-10 21:47:17.383745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def items(self, frame, normalize=False):
            pass

    test_variable = TestVariable('a')
    test_variable.items(frame=None)


# Generated at 2022-06-10 21:47:28.618284
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for class Attrs
    attrs = Attrs("obj")
    a = {"a": 1, "b": 2, "c": 3}
    a_result = [("obj", "dict_keys(['a', 'b', 'c'])"), ("obj.a", "1"), ("obj.b", "2"), ("obj.c", "3")]
    assert attrs.items(a) == a_result
    b = [1, 2, 3]
    b_result = [("obj", "[1, 2, 3]"), ("obj[0]", "1"), ("obj[1]", "2"), ("obj[2]", "3")]
    assert attrs.items(b) == b_result
    c = (1, 2, 3, [4, 5, 6])

# Generated at 2022-06-10 21:47:29.632714
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert not (BaseVariable('x') == BaseVariable('y'))

# Generated at 2022-06-10 21:47:36.509586
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indice = Indices('x', ())
    indice_ = indice[:]
    assert indice_._fingerprint == (Indices, 'x', ())
    assert indice_._slice == slice(None)
    indice_ = indice[1:6]
    assert indice_._fingerprint == (Indices, 'x', ())
    assert indice_._slice == slice(1, 6)
    print("All tests of method __getitem__ of class Indices pass.")

test_Indices___getitem__()

# Generated at 2022-06-10 21:47:50.348250
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var = BaseVariable(source = 'x', exclude = 'y')
    assert var == var
    assert var == BaseVariable(source = 'x', exclude = 'y')

    assert var != BaseVariable(source = 'x', exclude = 'z')
    assert var != BaseVariable(source = 'z', exclude = 'y')
    assert var != Attrs(source = 'x', exclude = 'y')
    assert var != Keys(source = 'x', exclude = 'y')
    assert var != Indices(source = 'x', exclude = 'y')
    assert var != Exploding(source = 'x', exclude = 'y')

# Generated at 2022-06-10 21:47:54.545906
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('main_value')
    for x in [ind[0:10],
              ind[10:20],
              ind[20:30]]:
        print(x._slice)

# _slice
s = slice(0, 1, 2)
print(s)


# Generated at 2022-06-10 21:47:58.446356
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    frame = sys._getframe()
    while frame:
        frame.f_globals["__file__"] = __file__
        if frame.f_code.co_name == "test_BaseVariable_items":
            break
        frame = frame.f_back
    v = BaseVariable('x')
    print(v.items(frame, normalize=True))

# Generated at 2022-06-10 21:48:03.547401
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[:] == Indices('a', exclude=())[:]
    assert a[1:] == Indices('a', exclude=())[1:]
    assert a[:2] == Indices('a', exclude=())[:2]

# Generated at 2022-06-10 21:48:08.373956
# Unit test for method __getitem__ of class Indices

# Generated at 2022-06-10 21:48:14.382556
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariableSubclass(BaseVariable):
        pass
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariableSubclass('x') == BaseVariableSubclass('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariableSubclass('x') != BaseVariableSubclass('y')
    assert BaseVariable('x') != BaseVariableSubclass('x')

# Generated at 2022-06-10 21:48:15.851446
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('abba').items({'abba': 'zabba'}) == []


# Generated at 2022-06-10 21:48:21.691733
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def assert_equal(a, b):
        assert a == b and b == a and hash(a) == hash(b), (a, b)

    for cls in (Keys, Indices, Attrs, Exploding):
        assert_equal(cls('a'), cls('a'))
        assert_equal(cls('a', 'b'), cls('a', 'b'))
        assert_equal(cls('a', exclude=('b',)), cls('a', exclude=('b',)))
        assert_equal(cls('a', exclude=('b', 'c')), cls('a', exclude=('b', 'c')))
        assert_equal(cls('a', exclude='b'), cls('a', exclude='b'))

# Generated at 2022-06-10 21:48:31.947209
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import views
    from . import utils
    import itertools

    source = 'request'

    # Initialization
    variable = BaseVariable(source)
    tb = views.get_current_traceback()
    f = utils.Frame(tb.tb_frame)
    variable.source = 'request'
    variable.code = compile(source, '<variable>', 'eval')
    variable.unambiguous_source = 'request'

    # Test method items

# Generated at 2022-06-10 21:48:34.746432
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # just making sure it works before we throw it at an actual traceback

    indices = Indices('10')[1:3]
    assert (indices._slice == slice(1, 3))


# Generated at 2022-06-10 21:48:49.384873
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    '''
    >>> class DummyVariable(BaseVariable):
    ...     def _items(self, main_value, normalize=False):
    ...         assert main_value == 42
    ...         return [('source', '23')]

    >>> DummyVariable('main_value').items(None) == [('source', '23')]
    True
    '''

# Generated at 2022-06-10 21:48:57.295719
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_cases = [
        (Indices('x'), (slice(None), None), range(10)),
        (Indices('x'), (slice(0, 10), None), range(10)),
        (Indices('x'), (slice(0, 5), None), range(5)),
        (Indices('x'), (slice(-3, None), None), range(7, 10)),
    ]
    for var, test_slice, expected_items in test_cases:
        var = var[test_slice[0]]
        for result_var in expected_items:
            print(type(var), var._slice, expected_items)
            assert var._slice == result_var

# Generated at 2022-06-10 21:48:59.560115
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable('x') == BaseVariable('x')) is True
    assert (BaseVariable('x') == BaseVariable('y')) is False

# Generated at 2022-06-10 21:49:03.835415
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("1", exclude="one")
    var2 = BaseVariable("1", exclude="one")
    var3 = BaseVariable("2", exclude="two")
    assert(var1 == var2)
    assert(var1 != var3)


# Generated at 2022-06-10 21:49:12.833559
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Single stored variable
    v1 = Attrs('a')
    v2 = Attrs('a')
    assert v1 == v2

    v2 = Attrs('b')
    assert v1 != v2

    # Multiple stored variables
    v1 = Attrs('a', exclude=('a.one', 'a.two.three'))
    v2 = Attrs('a', 'a.one', 'a.two.three')
    assert v1 == v2
    assert v2 == v1

    v2 = Attrs('a', exclude=('a.one', 'a.two.four'))
    assert v1 != v2
    assert v2 != v1



# Generated at 2022-06-10 21:49:20.683168
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import variable # this file
    assert variable.BaseVariable('a').items({'a':1}) == []
    assert variable.BaseVariable('a').items({'a':{'b':1}}) == []
    assert variable.BaseVariable('a').items({'a':[1]}) == []
    assert variable.BaseVariable('a').items({'a':[1,2,3]}) == []
    assert variable.BaseVariable('a', exclude=['b']).items({'a':{'c':1,'d':2}}) == [('a.c', '1'), ('a.d', '2')]

# Generated at 2022-06-10 21:49:31.017974
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from copy import deepcopy

    class Indices(Keys):
        _slice = slice(None)

        def _keys(self, main_value):
            return range(len(main_value))[self._slice]

        def __getitem__(self, item):
            assert isinstance(item, slice)
            result = deepcopy(self)
            result._slice = item
            return result

    # Test slice(None)
    my_slice = slice(None)
    indices = Indices('my_slice')
    items = indices.items([1, 2, 3])
    assert items == [('my_slice[0]', '1'), ('my_slice[1]', '2'), ('my_slice[2]', '3')]

    # Test slice(1, 2, None)

# Generated at 2022-06-10 21:49:42.043576
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import local
    def func():
        a = {'key1': 'value1', 'key2': 'value2'}
        b = 'hello'
        c = [1, 2, 3, 4, 5]
        d = False
        e = None
        return locals()
    frame = utils.get_frame(func)
    keys = iter(func().keys())
    assert tuple(Attrs('a').items(frame)) == (
        ('a', "{'key1': 'value1', 'key2': 'value2'}"),
        ('a.key1', "'value1'"),
        ('a.key2', "'value2'"),
    )
    assert tuple(Attrs('b').items(frame)) == (
        ('b', "'hello'"),
    )

# Generated at 2022-06-10 21:49:47.079530
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('__x', exclude=['__dict__'])
    v_slice = v[:]
    assert(isinstance(v, Indices)) and (v._slice == slice(None))
    assert(isinstance(v_slice, Indices)) and (v_slice._slice == slice(None))

# Generated at 2022-06-10 21:49:48.619417
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    m_1 = Attrs("y")
    m_2 = Attrs("y")
    assert m_1 == m_2


# Generated at 2022-06-10 21:50:02.678854
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    assert(BaseVariable('a') == BaseVariable('a'))
    assert(BaseVariable('a') == BaseVariable('a', exclude=[]))

    assert(BaseVariable('a') != BaseVariable('a', exclude='b'))
    assert(BaseVariable('a') != BaseVariable('a', 'b'))

    assert(BaseVariable('a') != 'a')
    assert(BaseVariable('a') != 1)

    assert(BaseVariable('a') != Indices('a'))

# Generated at 2022-06-10 21:50:05.241825
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    cls = Indices('a', exclude=())
    assert cls['b':'c']._slice == slice('b', 'c')

# Generated at 2022-06-10 21:50:12.939738
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    my_obj = Indices('my_obj')
    my_obj[0]
    my_obj[:]
    my_obj[:1]


ALL = {
    'attrs': Attrs,
    'k': Keys,
    'keys': Keys,
    'i': Indices,
    'indices': Indices,
    'explode': Exploding,
}

try:
    from . import hive
except ImportError:
    hive = None
else:
    ALL['hive'] = hive.Hive

# Generated at 2022-06-10 21:50:15.177771
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import stack

    a = stack.Stack()
    b = stack.Stack()
    assert not a == b


# Generated at 2022-06-10 21:50:21.820003
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'x'
    x = BaseVariable(source, exclude=('a'))
    assert x == x
    y = BaseVariable(source, exclude=('a'))
    assert x == y
    z = BaseVariable(source, exclude=())
    assert not x == z
    z = BaseVariable('y', exclude=('a'))
    assert not x == z


# Generated at 2022-06-10 21:50:24.391404
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:] == Indices('x')
    assert Indices('x')[1:3] == Indices('x')[1:3]


# Generated at 2022-06-10 21:50:29.626454
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('a', 'b')
    d = BaseVariable('a')
    e = BaseVariable('b', 'a')
    f = BaseVariable('a', 'c')

    assert not a == b
    assert not a == c
    assert a == d
    assert not a == e
    assert not a == f
    assert not a == 1
    assert not a == 'a'
    assert not a == None


# Generated at 2022-06-10 21:50:38.704871
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variables = [
        Keys('d'),
        Indices('a'),
        Attrs('s'),
        Exploding('l'),
        Keys('d', exclude=['x', 'y']),
        Keys('d', exclude=set(['x', 'y'])),
    ]
    l = [1]
    d = {'x': 2, 'y': 3, 'z': 4}
    a = 'abcd'
    s = set([1, 2, 3])

    frames = [
        dict(globals=dict(l=l, d=d, a=a, s=s)),
        dict(f_globals=dict(l=l, d=d, a=a, s=s)),
    ]


# Generated at 2022-06-10 21:50:39.856482
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass # TODO


# Generated at 2022-06-10 21:50:45.701139
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable(source=None)
    v2 = BaseVariable(source=None)
    v3 = BaseVariable(source='something')
    v4 = BaseVariable(source='something', exclude=['ex1'])

    assert v1 == v2
    assert not v1 == v3
    assert not v1 == v4
    assert not v2 == v3
    assert not v2 == v4
    assert not v3 == v4



# Generated at 2022-06-10 21:51:12.115216
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable1 = BaseVariable('x', ('y', 'z'))
    variable2 = BaseVariable('x', ('y', 'z'))
    variable3 = BaseVariable('y', ('x', 'z'))
    variable4 = BaseVariable('x', ('y', 'z', 'z'))
    assert variable1 == variable2
    assert variable1 != variable3
    assert variable1 != variable4

# Generated at 2022-06-10 21:51:23.695528
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Here we will create a function that will be used to test the items method
    def test_items(self):
        # Here we create some local variables that will be used in the source
        a = 1
        b = (1, 2, 3, 4, 5)
        c = {
            'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5
        }
        # Here we create a list of source codes
        source = [
            'a',
            'b',
            'c'
        ]
        # here we create a list of expected output of the item method
        # of the objects produced by the variables

# Generated at 2022-06-10 21:51:29.288897
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('x', exclude='y')
    assert BaseVariable('x', exclude='y') != BaseVariable('x')
    assert BaseVariable('x', exclude='y') != BaseVariable('x', exclude='y')

# Generated at 2022-06-10 21:51:41.407254
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Method __eq__ should return True if the values of all attributes of instance of BaseVariable are completely equivalent; should return False otherwise.
    """
    dict1 = {'a': 1, 'b': 'str', 'c': 1.0}
    dict2 = {'a': 1, 'b': 'str', 'c': 1.0}
    dict3 = {'a': 2, 'b': 'str', 'c': 1.0}
    dict4 = {'a': 2, 'b': 'STR', 'c': 1.0}
    
    obj1 = BaseVariable(1, exclude=())
    obj2 = BaseVariable(1, exclude=())
    obj3 = BaseVariable(1, exclude=('a'))
    obj4 = BaseVariable(2, exclude=())
    

# Generated at 2022-06-10 21:51:51.964793
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x.y') == BaseVariable('x.y')
    assert BaseVariable('x.y', 'z') == BaseVariable('x.y', 'z')
    assert BaseVariable('x.y', 'z') != BaseVariable('x.y', 'a')

    assert Attrs('x') == Attrs('x')
    assert Attrs('x.y') == Attrs('x.y')
    assert Attrs('x.y', 'z') == Attrs('x.y', 'z')
    assert Attrs('x.y', 'z') != Attrs('x.y', 'a')

    assert Keys('x') == Keys('x')
    assert Keys('x.y') == Keys('x.y')
    assert Keys('x.y', 'z')

# Generated at 2022-06-10 21:52:00.432669
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class Container(object):
        def __len__(self):
            return 10

        def __getitem__(self, i):
            return i

    v = Indices('x')
    result = []

    for i in range(2):
        for j in range(2):
            for k in range(2):
                for l in range(2):
                    for m in range(2):
                        result.append(v[i:j:k][l:m:2].source)

# Generated at 2022-06-10 21:52:12.932410
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    def test_f():
        '''
        test function
        '''
        dct = {'a': 1, 'b': 2}
        dct['dct'] = dct
        return dct
    code = pycompat.get_code(test_f)
    func_globals = test_f.__globals__
    func_locals = test_f()
    frame = sys._getframe()
    frame.f_globals = func_globals
    frame.f_locals = func_locals

    source = 'dct'
    var = Attrs(source)
    for k, v in var.items(frame, normalize=True):
        print(k, v)
    source = 'dct.a'
    var = Attrs(source)
   

# Generated at 2022-06-10 21:52:18.865963
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    # Test that 2 variables with different source strings are not equal.
    v1 = BaseVariable('foo')
    w1 = BaseVariable('bar')
    assert(v1 != w1)

    # Test that 2 variables with different types are not equal.
    v2 = Attrs('foo')
    w2 = BaseVariable('foo')
    assert(v2 != w2)


# Generated at 2022-06-10 21:52:25.611446
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source ='1'
    exclude=(1,2,3)
    code = compile(source, '<variable>', 'eval')

    variable_1 = BaseVariable(source,exclude)
    variable_2 = BaseVariable(source,exclude)
    variable_3 = BaseVariable(source)

    assert variable_1 == variable_1
    assert variable_1 == variable_2
    assert variable_1 != variable_3


# Generated at 2022-06-10 21:52:34.431685
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Attrs.__name__ = 'Attrs'
    Keys.__name__ = 'Keys'
    Indices.__name__ = 'Indices'
    Exploding.__name__ = 'Exploding'
    def getitem_for_indices(item):
        indices = Indices('main_value')
        result = indices.__getitem__(item)
        return result

    first_three = getitem_for_indices(slice(3))
    assert first_three.source == 'main_value'
    assert first_three.exclude == ()
    assert first_three._slice == slice(3)

    the_first = getitem_for_indices(slice(1))
    assert the_first.source == 'main_value'
    assert the_first.exclude == ()
    assert the_first._slice == slice

# Generated at 2022-06-10 21:53:24.105826
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test_BaseVariable_items:
    # assert Attrs('a').items(frame) == ()
    # # assert Attrs('a.b').items(frame) == [('a', 'None')]
    # assert Keys('a').items(frame) == []
    # assert Keys('a[1]').items(frame) == []
    # assert Indices('a').items(frame) == []
    # assert Indices('a[1:2:3]').items(frame) == []
    return


# Generated at 2022-06-10 21:53:32.483353
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = ['a', 'b', 'c', 'd']
    v1 = Indices('a')
    v2 = v1[1:3]
    assert v1._slice == slice(None)
    assert v2._slice == slice(1, 3)
    assert v2.items(None) == [('a[1]', "'b'"), ('a[2]', "'c'")]


KEY_MAPPING = {
    'a': Attrs,
    'k': Keys,
    'i': Indices
}



# Generated at 2022-06-10 21:53:39.547251
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_sub = BaseVariable('sub')
    var_sub_sub = BaseVariable('subsub')
    var_sub_sub2 = BaseVariable('subsub2')
    var_sub_sub_sub = BaseVariable('subsubsub')

    assert var_sub == var_sub
    assert var_sub_sub == var_sub_sub
    assert var_sub_sub_sub == var_sub_sub_sub

    assert var_sub != var_sub_sub
    assert var_sub_sub != var_sub_sub2

    assert var_sub != var_sub_sub_sub



# Generated at 2022-06-10 21:53:42.909011
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('main_value')
    assert var[0] == (
        Indices(
            'main_value',
            exclude=()
        )
    )


# Generated at 2022-06-10 21:53:46.306557
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test = Indices('test')
    test[1:3] = Indices('test[1:3]')
    assert str(test[1:3]._slice) == '1:3'

# Generated at 2022-06-10 21:53:50.827591
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import unittest
    
    class indice(unittest.TestCase):
        def setUp(self):
            import inspect
            self.tester = inspect.currentframe()
            self.data = list(range(10))

        def test(self):
            # test class need to be initialized
            
            # data exist in frame
            self.assertTrue(self.tester.f_locals['self'].data, "data doesn't exist in frame")
            # test __getitem__ method
            self.assertTrue(self.tester.f_locals['self'].data[Indices(self.tester.f_locals['self'].data)][self.tester.f_locals['self'].data], "__getitem__ doesn't work")
            # test _items method

# Generated at 2022-06-10 21:53:52.987908
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('key').items({'key': 'value'}) == (('key', "'value'"),)

# Generated at 2022-06-10 21:53:55.450406
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print("*"*20)
    x = BaseVariable()
    print(x.items({}))


# Generated at 2022-06-10 21:53:58.597542
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('main_value', exclude=('exc'))
    var2 = BaseVariable('main_value', exclude=('exc'))
    assert var1.__eq__(var2) == True


# Generated at 2022-06-10 21:54:08.371175
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('test_BaseVariable___eq__...')
    assert Attrs('x') == Attrs('x')
    assert Attrs('x') != Attrs('y')
    assert Attrs('x', exclude=('x', )) == Attrs('x', exclude=('x', ))
    assert Attrs('x', exclude=('x', )) != Attrs('x', exclude=('y', ))
    assert Attrs('x') != Keys('x')
    assert Keys('x') != Attrs('x')
    print('    pass')

if __name__ == '__main__':
    test_BaseVariable___eq__()

# Generated at 2022-06-10 21:54:48.879296
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # 测试代码
    v = Indices('variable')
    v_slice = v[2:5]
    assert v_slice._keys([1,3,5,6,7,9]) == range(2,5)


# Generated at 2022-06-10 21:55:02.020688
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect

    def simple_func(*args, **kwargs):
        return 1

    import logging
    logging.basicConfig()
    logger = logging.getLogger('simple_func')
    logger.warning('test message')

    current_frame = inspect.currentframe()

# Generated at 2022-06-10 21:55:07.667049
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('a')
    c = BaseVariable('c')
    assert a == b
    assert a != c
    assert a != 'a'
    d = BaseVariable('a', ['d'])
    e = BaseVariable('a', ['d'])
    assert d == e
