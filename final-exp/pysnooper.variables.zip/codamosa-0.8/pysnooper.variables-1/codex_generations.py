

# Generated at 2022-06-10 21:45:32.728867
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a.b') == Attrs('a.b')
    assert Attrs('a.b') == Attrs('a.b', '__dict__')
    assert Keys('a') == Keys('a')
    assert Keys('a') == Keys('a', '__dict__')
    assert Indices('a') == Indices('a')
    assert Indices('a') == Indices('a', '__dict__')
    assert Indices('a')[1:] == Indices('a')[1:]
    assert Indices('a')[3:5] == Indices('a')[3:5]
    assert Indices('a')[3:5] != Keys('a')
    assert Indices('a') != Indices('a', '__dict__')

# Generated at 2022-06-10 21:45:44.033065
# Unit test for method items of class BaseVariable

# Generated at 2022-06-10 21:45:54.533789
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    from .frame import Frame
    # Test for function items() in class CommonVariable
    # Create an instance of CommonVariable
    CommonVar = CommonVariable("fruit")
    # Test for the exception case 1
    try:
        items = CommonVar.items("apple")
    # Test for the exception case 2
    except AttributeError:
        fruit = "apple"
        items = CommonVar.items(fruit)

    assert items == [('fruit', 'apple')]

    # Test for function items() in class BaseVariable
    # Create an instance of BaseVariable
    BaseVar = BaseVariable("fruit")
    # Test for the exception case 1
    try:
        items1 = BaseVar.items("apple")
    # Test for the exception case 2
    except AttributeError:
        fruit1 = "apple"
        items

# Generated at 2022-06-10 21:46:02.614254
# Unit test for method items of class BaseVariable

# Generated at 2022-06-10 21:46:13.356680
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import pprint
    
    def test_variable(source, expected, exclude=(), frame=inspect.currentframe()):
        actual = set(Attrs(source, exclude).items(frame))
        assert actual == set(expected), \
                '\n  Source: {}\n  Expected: {}\n       Got: {}'.format(source, pprint.pformat(expected), pprint.pformat(actual))


# Generated at 2022-06-10 21:46:23.328443
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # test for equal
    variable1 = BaseVariable(source = 'a', exclude = ())
    variable2 = BaseVariable(source = 'a', exclude = ())
    assert variable1 == variable2

    # test for different
    variable1 = BaseVariable(source = 'a', exclude = ())
    variable2 = BaseVariable(source = 'b', exclude = ())
    assert variable1 != variable2

    variable1 = BaseVariable(source = 'a', exclude = ())
    variable2 = BaseVariable(source = 'a', exclude = ('b'))
    assert variable1 != variable2


# Generated at 2022-06-10 21:46:34.205374
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Test the method BaseVariable.__eq__(self, other).

    """
    # Example 1.
    result = BaseVariable('foo') == BaseVariable('foo')
    assert result == True

    # Example 2.
    result = BaseVariable('foo') == BaseVariable('foo', exclude=())
    assert result == True

    # Example 3.
    result = BaseVariable('foo') == BaseVariable('foo', exclude='bar')
    assert result == False

    # Example 4.
    result = BaseVariable('foo') == BaseVariable('foo', exclude=None)
    assert result == True

    # Example 5.
    result = BaseVariable('foo') == BaseVariable('foo', exclude=['bar'])
    assert result == False

    # Example 6.

# Generated at 2022-06-10 21:46:38.598140
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class MyVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()

    source = 'foo'
    exclude = ('bar',)
    a = MyVariable(source, exclude)
    b = MyVariable(source, exclude)
    c = MyVariable(source, ('baz',))
    d = MyVariable('qux', exclude)
    assert a == b
    assert not a == c
    assert not a == d

# Generated at 2022-06-10 21:46:50.046970
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('foo') == BaseVariable('foo')
    assert BaseVariable('foo') != BaseVariable('bar')
    assert BaseVariable('foo', ('bar',)) == BaseVariable('foo', ('bar',))
    assert BaseVariable('foo', ('bar',)) != BaseVariable('foo', ('baz',))
    assert BaseVariable('foo', ('bar',)) != BaseVariable('foo', 'bar')

    assert Attrs('foo') == Attrs('foo')
    assert Attrs('foo') != Attrs('bar')
    assert Attrs('foo', ('bar',)) == Attrs('foo', ('bar',))
    assert Attrs('foo', ('bar',)) != Attrs('foo', ('baz',))
    assert Attrs('foo', ('bar',)) != Attrs('foo', 'bar')

    assert Keys('foo') == Keys('foo')

# Generated at 2022-06-10 21:46:58.891226
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class test(BaseVariable):
        def __init__(self):
            self.source = 'test'
            self.exclude = ()
            self.code = compile(self.source, '<variable>', 'eval')
            self.unambiguous_source = self.source
        def _items(self, key, normalize=False):
            return ()
    a = BaseVariable('a')
    b = BaseVariable('b')
    assert a == a
    assert a != b
    try:
        assert a == test()
        assert False
    except AssertionError:
        pass
    assert a != 10

# Generated at 2022-06-10 21:47:10.114705
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Attrs('a')
    v2 = Attrs('a')
    v3 = Attrs('b')
    v4 = Attrs('a', ['x'])
    v5 = Attrs('a', ['y'])

    assert(v1==v2)
    assert(v1!=v3)
    assert(v1!=v4)
    assert(v4!=v5)

# Generated at 2022-06-10 21:47:14.229067
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', ('x',)) != BaseVariable('x', ('x', 'y'))
    assert BaseVariable('x.y.z') != BaseVariable('x.y.z.z')


# Generated at 2022-06-10 21:47:20.383925
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    for i in list(range(20))+[-1, -2, -3]:
        s = slice(i, None, 3)
        print(slice(i, None, 3))
        print(list(range(20))[s])

if __name__ == "__main__":
    test_Indices___getitem__()

# Generated at 2022-06-10 21:47:27.247902
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude=()) != BaseVariable('a', exclude=('b', ))
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != Keys('a')
    assert BaseVariable('a') != Indices('a')
    assert BaseVariable('a') != Exploding('a')

# Generated at 2022-06-10 21:47:34.460455
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind1 = Indices("x")
    ind2 = ind1[:]
    ind2_slice = ind2._slice
    assert ind2_slice == slice(None)
    assert ind1 == ind2
    assert ind1.__getitem__(slice(1,2)) != ind2
    assert ind1.__getitem__(slice(1,2)).items("x") == ind2.items("x")
    assert ind1.__getitem__(slice(None,3,3)) != ind2
    assert ind1.__getitem__(slice(None,3,3)).items("x") == ind2.items("x")

# Generated at 2022-06-10 21:47:35.826727
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """Write a unit test for method items of class BaseVariable"""
    pass # TODO


# Generated at 2022-06-10 21:47:40.422222
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable1 = BaseVariable('a', exclude = ['b', 'c'])
    BaseVariable2 = BaseVariable('a', exclude = ['c', 'b'])

    if BaseVariable1 == BaseVariable2:
        assert True
    else:
        assert False
    

# Generated at 2022-06-10 21:47:45.604916
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('v')

    # Test the case with basic check where indices[1:10] is basically working
    indices_slice = indices[1:10]
    assert isinstance(indices_slice, Indices)
    assert indices_slice._slice == slice(1, 10)
    assert indices_slice._fingerprint == indices._fingerprint

# Generated at 2022-06-10 21:47:48.065486
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    assert var1.__eq__(var2) == True


# Generated at 2022-06-10 21:47:57.360032
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a'
    exclude = 'type'
    variable = BaseVariable(source, exclude)
    variable.type = 'test_BaseVariable_items'

    frame_info = inspect.getframeinfo(inspect.currentframe())
    frame = inspect.getframeinfo(inspect.currentframe())
    frame.f_code.co_filename = frame_info.filename
    frame.f_code.co_firstlineno = frame_info.lineno

    items = variable.items(frame)
    assert len(items) == 2
    assert items[0][0] == 'a'
    assert isinstance(items[0][1], str)
    assert items[1][0] == 'a.type'
    assert items[1][1] == 'test_BaseVariable_items'

# Generated at 2022-06-10 21:48:14.383159
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    class Demo(metaclass=types.TypeType):
        def __init__(self):
            self.a = 1
            self.b = [2, 3]
            self.c = {'1': 2, '2': 3}
            self.d = Demo2()
            self.e = {Demo2(): ['list']}

    class Demo2(metaclass=types.TypeType):
        def __init__(self):
            self.a = 1
            self.b = [2, 3]
            self.c = {'1': 2, '2': 3}
            self.d = Demo()
            self.e = {Demo(): ['list']}

    frame = utils.Frame(Demo)
    frame.f_locals['a'] = 10


# Generated at 2022-06-10 21:48:16.823099
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('var')['1:3']._slice == slice(1, 3)
    assert Indices('var')['1:3:2']._slice == slice(1, 3, 2)



# Generated at 2022-06-10 21:48:20.880677
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = [1, 2, 3, 4]
    bounds = slice(0, 3)
    result = Indices(source='main_value')[bounds]
    assert isinstance(result, Indices)
    assert result._slice == bounds

# Generated at 2022-06-10 21:48:26.660151
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    x1 = x[:]
    x2 = x[1:]
    assert x.__dict__['_slice'] == slice(None)
    assert x1.__dict__['_slice'] == slice(None)
    assert x2.__dict__['_slice'] == slice(1, None)

# Generated at 2022-06-10 21:48:30.127172
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('test')[:] == Indices('test')
    assert Indices('test')[:-1] != Indices('test')

test_Indices___getitem__()

# Generated at 2022-06-10 21:48:35.112437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
	
	a = BaseVariable('foo')
	b = BaseVariable('foo')
	c = BaseVariable('bar')
	d = BaseVariable('bar')
	
	print('Asserting true')
	assert a is not b
	assert a is not c
	assert a is not d
	assert c is not d
	assert b is not c
	assert b is not d
	
	print('Asserting equality')
	assert a == b
	assert a == a
	assert b == a
	assert b == b
	assert c == c
	assert d == d
	assert c == d
	
	print('Asserting inequality')
	assert a != c
	assert a != d
	assert c != a
	assert c != b
	assert b != c
	assert b != d
	

# Generated at 2022-06-10 21:48:37.507332
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('this') == BaseVariable('this')
    assert BaseVariable('this') != BaseVariable('that')


# Generated at 2022-06-10 21:48:45.987779
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    v4 = BaseVariable('a.b')
    v5 = BaseVariable('b.c')
    v6 = BaseVariable('a', False)
    v7 = BaseVariable('b.c', True)
    v8 = BaseVariable('a.b', False)
    v9 = BaseVariable('b.c', False)
    v10 = BaseVariable('a', True)

    assert(v1 == v2)
    assert(v1 != v3)
    assert(v1 != v4)
    assert(v1 != v6)
    assert(v1 != v10)
    assert(v4 != v5)
    assert(v7 != v9)
    assert(v8 != v9)

# Generated at 2022-06-10 21:48:55.158067
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') != Indices('b')
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a', exclude='x') != Attrs('a')
    assert Attrs('a', exclude='x') != Attrs('a', exclude='y')
    assert Attrs('a', exclude='x') == Attrs('a', exclude='x')
    assert Attrs('a', exclude='x') == Attrs('a', exclude=('x',))
    assert Attrs('a', exclude=('x',)) == Attrs('a', exclude=('x',))


# Generated at 2022-06-10 21:48:59.263346
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert isinstance(a, type(Indices))
    assert isinstance(a, Indices)
    assert isinstance(a[:1:1], type(Indices))
    assert isinstance(a[:1:1], Indices)

# Generated at 2022-06-10 21:49:19.258064
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from _pytest.python_api import assertrepr_compare
    import pytest
    def get_test_frame():
        def test_func():
            # Dummy function for code inspection
            name = "Abc"
            for a in range(1, 10):
                for b in range(a, 10):
                    for c in range(b, 10):
                        yield name, a, b, c
        gen = test_func()
        frame = gen.gi_frame
        while frame.f_code.co_name != 'test_func':
            gen.next()
            frame = gen.gi_frame
        return frame

    frame = get_test_frame()

# Generated at 2022-06-10 21:49:21.931182
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    if not (BaseVariable('') == BaseVariable('')):
        print('Test failed!')
        print('Expected: True')
        print('Got: False')



# Generated at 2022-06-10 21:49:31.873754
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import _ast
    # work in global frame of this function
    frame = types.getouterframes(types.currentframe(), 0)[0][0]
    # test Attrs class
    attrs = Attrs('a', exclude=['__dict__'])
    assert attrs.items(frame, normalize=True) == [
        ('a', '_ast.AST'),
        ('a.__class__', 'type'),
    ]
    # test Keys class
    keys = Keys('a', exclude=['__dict__'])
    assert keys.items(frame, normalize=True) == [
        ('a', '_ast.AST'),
        ('a[__class__]', 'type'),
    ]
    # test Indices class
    indices = Indices('a', exclude=['__dict__'])

# Generated at 2022-06-10 21:49:37.197535
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var=Indices('a')
    print(var._slice)
    print(var)
    print(var[:5])
    print(var._slice)
    a=[1,2,3,4,5]
    print(a[var[:5]])
    print(a[var._slice])


test_Indices___getitem__()

# Generated at 2022-06-10 21:49:46.072144
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Tests that BaseVariable.__eq__() works as expected
    """
    # Setup the enviroment
    bv = BaseVariable("x")
    bv1 = BaseVariable("x")
    bv2 = BaseVariable("y")
    bv3 = BaseVariable("x", exclude="x")
    bv4 = BaseVariable("x", exclude="x")
    bv5 = BaseVariable("x", exclude="y")

    # Run the checks
    assert bv == bv1
    assert bv != bv2
    assert bv3 != bv5
    assert bv3 == bv4


# Generated at 2022-06-10 21:49:52.500003
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Initialise some variables
    source = 'a'
    exclude = ()
    source_neg = 'b'
    exclude_neg = ('n')

    # Initialise a BaseVariable
    base = BaseVariable(source, exclude)
    base_neg = BaseVariable(source_neg, exclude_neg)

    # Create a dictionary containing all combination of variables
    vars_dict = {
        'base': base,
        'base_neg': base_neg,
        'source: source': source,
        'source: source_neg': source_neg,
        'exclude: exclude': exclude,
        'exclude: exclude_neg': exclude_neg
    }

    # Check for each combination of variables

# Generated at 2022-06-10 21:49:54.164052
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    a[0]
    a[1:4]


# Generated at 2022-06-10 21:50:00.824396
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a', 'bar').__eq__(Attrs('a', 'bar')) == True
    assert Attrs('a', 'bar').__eq__(Attrs('a', 'foo')) == False
    assert Attrs('a', 'bar').__eq__(Attrs('b', 'bar')) == False
    assert Attrs('a', 'bar').__eq__(Keys('a', 'bar')) == False
    assert Attrs('a', 'bar').__eq__(Indices('a', 'bar')) == False
    assert Attrs('a', 'bar').__eq__(Exploding('a', 'bar')) == False
    assert Attrs('a', 'bar').__eq__(None) == False



# Generated at 2022-06-10 21:50:06.554134
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pandas as pd
    dummy_frame = pd.DataFrame({"col_a": [1, 2, 3, 4], "col_b": [5, 6, 7, 8]})
    assert list(Indices('df')[:2].items(dummy_frame)) == list(Indices('df[:2]').items(dummy_frame))

# Generated at 2022-06-10 21:50:11.758569
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('x')
    import sys
    frame = sys._getframe()
    # source is valid
    assert variable.items(frame) == (('x', '<frame object>'),)
    # source is invalid
    variable = BaseVariable('y')
    assert variable.items(frame) == ()



# Generated at 2022-06-10 21:50:26.229544
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('my_obj', normalize=True)

    indices[1:3]

    assert indices._slice == slice(1, 3)
    assert indices.__getstate__() == (slice(1, 3),)
    assert indices.__setstate__((slice(1, 3),))
    assert indices._slice == slice(1, 3)


# Generated at 2022-06-10 21:50:33.113734
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frame

    def a():
        class A(object):
            def __init__(self):
                self.a = 1
                self.b = 2

        class B(object):
            def __init__(self):
                self.a = 10
                self.b = 20

        return A(), B()

    def b():
        class A:
            def __init__(self):
                self.a = 1
                self.b = 2

        class B:
            def __init__(self):
                self.a = 10
                self.b = 20

        return A(), B()

    def c():
        class A:
            def __init__(self):
                self.a = 1
                self.b = 2

        class B:
            def __init__(self):
                self.a = 10

# Generated at 2022-06-10 21:50:35.109139
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import variables

# Generated at 2022-06-10 21:50:39.674945
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('v[*]', '__class__')
    assert v[:3] == Indices('v[*]', '__class__')[:3]
    assert v == Indices('v[*]', '__class__')
    assert v[:3] != Indices('v[*]', '__class__')[:2]
    assert v[:3] != Indices('v[*]', '__class__')[0:-1]
    assert v[:3] == Indices('v[*]', '__class__')[:7]

# Generated at 2022-06-10 21:50:50.220493
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    stack = sys._getframe().f_back
    identifiers = ['a', 'b', "c['a']", "d.e.f", 'g[1]', 'h[None]',
                'i[len(g)]', 'j[None].k', 'l.m[-1]', 'n[None][0]']
    values = ['\'abc\'', '123', '1', '3.14', '"cde"', 'None', 'None', '4.12', '[]', '{}']
    source = '\n'.join(identifier + ' = ' + value for identifier, value in zip(identifiers, values))
    exec (source, stack.f_globals, stack.f_locals)

# Generated at 2022-06-10 21:50:58.027519
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('key').__getitem__(slice(0, 1)) is not Indices('key')
    assert Indices('key').__getitem__(slice(0, 1)) is not Indices('key')[slice(0, 1)]
    assert Indices('key').__getitem__(slice(0, 1)) is Indices('key')[slice(0, 1)]
    assert Indices('key')[slice(0, 1)]._slice == slice(0, 1)

# Generated at 2022-06-10 21:51:09.293660
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    foo = BaseVariable('foo')
    assert foo.items({'foo': 3}) == (('foo', '3'),)
    assert foo.items({'foo': {'bar': 'toto'}}) == (('foo', "'toto'"),)
    # Should not fail if foo does not exist
    foo.items({}) == ()

if __name__ == '__main__':
    foo = BaseVariable('foo')
    assert foo.items({'foo': 3}) == (('foo', '3'),)
    assert foo.items({'foo': {'bar': 'toto'}}) == (('foo', "'toto'"),)
    # Should not fail if foo does not exist
    foo.items({}) == ()
    
    
    
    
    
    
    




# Generated at 2022-06-10 21:51:14.203100
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    main_value = range(5)
    i = Indices("a")
    i2 = i[1:3]
    assert main_value[1:3] == i2.items(main_value)
    main_value[1:3] = ["b"]
    assert ["b"] == i2.items(main_value)

# Generated at 2022-06-10 21:51:25.508240
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    sys.ps1 = '>>'
    sys.ps2 = '..'
    x = [3, 4, 5]
    y = {'x': x}
    f = {'y': y}
    z = {'_z': z, '_y': y, '_x': x}

    frame = sys._getframe()

# Generated at 2022-06-10 21:51:33.074520
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices1 = Indices('foo')
    assert indices1[0] == Indices('foo')
    assert indices1[5:10] == Indices('foo')
    assert indices1[5:10] != Indices('baz')
    assert indices1 == Indices('foo')
    assert hash(indices1) == hash(Indices('foo'))
    assert hash(indices1) != hash(Indices('baz'))

# Generated at 2022-06-10 21:51:46.848781
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    try:
        list_obj = Indices('list_obj')
        list_obj[:2]
    except:
        assert False, 'Unexpected exception'
    return True

# Generated at 2022-06-10 21:51:55.591472
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import collections, types
    frame = types.FrameType(1, 1, 1)
    frame.f_globals = {}
    frame.f_locals = {}
    attrs = []
    for i in range(5):
        obj = collections.namedtuple('N', 'f0 f1 f2 f3 f4')(1, 2, 3, 4, 5)
        key = '.' + obj._fields[i]
        attrs.append((key, getattr(obj, obj._fields[i])))
    frame.f_locals['obj'] = obj
    variable = Attrs('obj')
    variable_test = variable.items(frame)
    variable_test = variable_test[1:]
    assert variable_test == attrs

# Generated at 2022-06-10 21:52:07.185046
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f(a, b, c):
        return a + b + c

    def g(x):
        return x + 1

    def h(y):
        return y + 1

    globals_ = {
        'x': "a",
        'y': [1,2,3],
        'z': [1,2,3,4],
        'func': f,
        'g': g,
        'h': h
    }

    local_ = {
        'a': 1,
        'b': 2,
        'c': 3
    }

    frame = utils.Frame(f.__code__, globals_, local_)

    # test for class Attrs
    attrs = Attrs("x")
    assert attrs.items(frame) == [('x', "'a'")]

   

# Generated at 2022-06-10 21:52:16.186567
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # 测试 BaseVariable.items() 方法

    # 以下测试 code 属性
    # 1. 不需要括号，比如 main_value
    source = "main_value"
    v = BaseVariable(source)
    assert v.code.co_name == source

    # 2. 需要括号，比如 main_value.attr
    source = "main_value.attr"
    v = BaseVariable(source)
    assert v.code.co_name == source


    # 以下测试 _items 方法
    # 1. 测试使用 Attrs 类，main_value 

# Generated at 2022-06-10 21:52:24.545161
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    sources = ['(1+2)**2', ' -1.6666666666666665',
               '{0:d}'.format(int(1e18)),
               'int(1e18)', 'float("nan")',
               'float("inf")']
    for source in sources:
        variable = BaseVariable(source)
        frame = inspect.currentframe()
        items = variable.items(frame)
        print(items)
        assert items[0][0] == source
        assert items[0][1] == str(eval(source))



# Generated at 2022-06-10 21:52:27.057383
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    frame = sys._getframe().f_back
    variable = BaseVariable('1')
    variable.items(frame)

# Generated at 2022-06-10 21:52:30.134873
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    t = Indices('var', exclude=('x',))['6:']
    assert isinstance(t, Indices)
    assert t._slice == slice(6, None)

test_module()

# Generated at 2022-06-10 21:52:33.166767
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = dict(a=1, b=3)
    print(a)
    a_items = Indices('a')[1:2]._items(a, normalize=True)
    print(a_items)

test_Indices___getitem__()

# Generated at 2022-06-10 21:52:36.636786
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = 100
    a = BaseVariable("x")
    # return a tuple
    assert(type(a.items(locals())) is tuple)
    # accept input "frame"
    # assert(a.items((x))[0] == ("x", "100"))
    # assert(a.items("x")[0] == ("x", "100"))
    # handle wrong input
    # if isinstance(a.items("x"), Exception): assert(True)
    # handle wrong input:
    # assert(a.items("NOT_EXIST_VARIABLE") == "")

# Generated at 2022-06-10 21:52:40.221185
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    sv1 = Indices('abc')[:]
    assert sv1.source == 'abc'
    sv2 = Indices('abc')[:10]
    assert sv2.source == 'abc'


# Generated at 2022-06-10 21:53:00.255511
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a') == Indices('a')[:]
    assert Indices('a') != Indices('a')[1:]
    assert Indices('a') != Indices('a')[::-1]

# Generated at 2022-06-10 21:53:10.338535
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .pycompat import IS_PY3
    import _ast
    if IS_PY3:
        load_name = _ast.Load()
        store_name = _ast.Store()
        expr = _ast.Expr()
    else:
        load_name = _ast.Load
        store_name = _ast.Store
        expr = _ast.Expr
    name = _ast.Name(id='test', ctx=load_name)
    main_value = ['test', 'test1', 'test2']
    keys = Indices('test')[0:2]
    keys = keys._keys(main_value)
    assert keys == [0, 1]


# Generated at 2022-06-10 21:53:13.338009
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert list(Indices('a')[3:5].items({'a':[1,2,3,4,5,6,7]})) == [('a[3]', '4'), ('a[4]', '5')]

# Generated at 2022-06-10 21:53:16.534268
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('asd')[1:2]
    assert(isinstance(v, Indices))


# Generated at 2022-06-10 21:53:25.120481
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    def get_slice(var, start, stop):
        return var[slice(start, stop)]._slice

    assert (get_slice(Indices('x'), 1, 9)      == slice(1, 9))
    assert (get_slice(Indices('x'), None, 9)   == slice(None, 9))
    assert (get_slice(Indices('x'), 1, None)   == slice(1, None))
    assert (get_slice(Indices('x'), None, None)== slice(None, None))


# Generated at 2022-06-10 21:53:28.591625
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    _slice = slice(None, None, None)
    result = Indices(None, None).__getitem__(_slice)
    assert result._slice is _slice

# Generated at 2022-06-10 21:53:32.339975
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    y = x[0:]
    assert y.source == 'x[0:]'
    z = x[1::2]
    assert z.source == 'x[1::2]'


# Generated at 2022-06-10 21:53:35.908080
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from unittest.mock import Mock
    v = BaseVariable('test')
    assert v.items(Mock()) == []
    assert v._items(Mock(), normalize=False) == []


# Generated at 2022-06-10 21:53:37.980057
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    it = Indices('s', exclude=())
    it1 = it[1:]
    assert it._slice == slice(None)
    assert it1._slice == slice(1, None)

# Generated at 2022-06-10 21:53:44.789365
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('data', exclude='x')
    var_slice = var[0:1]
    assert var.source == 'data'
    assert var_slice.source == 'data'
    assert var.exclude == ('x',)
    assert var_slice.exclude == ('x',)
    assert var._slice == slice(None)
    assert var_slice._slice == slice(0, 1)



# Generated at 2022-06-10 21:54:33.535714
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # - no exclude
    # - no frame
    # - no normalize
    iv = Indices('variable')
    iv_s1 = iv[1:3]
    iv_s2 = Indices('variable', exclude=())[1:2]
    assert iv_s1.source == iv_s2.source == 'variable[1:3]'
    assert iv_s1.exclude == iv_s2.exclude == ()
    assert iv_s1.code == iv_s2.code == iv.code
    assert iv_s1.unambiguous_source == iv_s2.unambiguous_source == iv.unambiguous_source
    assert iv_s1._keys(list(range(10))) == range(1,3)
    # - test the assert statement

# Generated at 2022-06-10 21:54:36.643215
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    var2 = var[0:-1]
    assert var2._slice == slice(0, -1, None)

# Generated at 2022-06-10 21:54:44.304635
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    """
    >>> v = Indices('a')
    >>> v['1']
    Traceback (most recent call last):
    ...
    AssertionError
    >>> v[slice(None, None)]
    <Indices 'a' exclude=()>
    >>> v[slice(1, None)]
    <Indices 'a' exclude=()>
    """
    pass


# Generated at 2022-06-10 21:54:56.516366
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import json
    from . import exception_handler

    # Get the stack frame of the caller
    frame = inspect.currentframe().f_back
    file = inspect.getframeinfo(frame).filename
    line = inspect.getframeinfo(frame).lineno

    global_vars = frame.f_globals
    local_vars = frame.f_locals

    # For the test_exc_handler method,
    # an exception handler that prints the traceback and the local and global variables after the exception is raised.
    def test_exc_handler(exc_tuple, exc_processor, traceback):
        print('\n\nTRACEBACK (most recent call last):')
        traceback.print_tb()
        print('\n\nERROR:', exc_tuple[0])

# Generated at 2022-06-10 21:55:04.382302
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import re
    import os
    import sys
    # make sure items returns a tuple
    assert isinstance(BaseVariable.items(None, inspect.currentframe()), tuple)
    # make sure items returns a tuple with pairs in the form (p,v).
    # where p represent a path, and v the value
    assert all(
        isinstance(pair, tuple) and len(pair) == 2 and isinstance(pair[0], str)
        for pair in BaseVariable.items(None, inspect.currentframe())
    )
    # make sure that in the path 'p', we can extract the variable name
    # and the item that was accessed
    destination = BaseVariable.items(None, inspect.currentframe())[0][0]