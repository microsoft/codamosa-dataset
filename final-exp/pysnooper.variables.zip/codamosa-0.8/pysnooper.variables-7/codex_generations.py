

# Generated at 2022-06-10 21:45:27.269407
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = "request.args.get('_id')"
    exclude = ['_id']
    frame = []
    normalize = False
    # 这个case有问题,不知道为什么
    # v = BaseVariable(source, exclude)
    # assert v._fingerprint == (BaseVariable, source, exclude)

    v = Attrs(source, exclude)
    v._keys = lambda a: ['_id']
    v._format_key = lambda key: '.' + key
    v._get_value = lambda m, k: m[k]
    assert v._items({}, normalize) == (('{}._id'.format(source), "{'_id':}"),)



# Generated at 2022-06-10 21:45:36.467853
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices(source = "x.name")
    indices_1 = indices[:] # test slice object
    indices_2 = indices[::-1] # test slice object
    indices_3 = indices[:12:2] # test slice object

    assert indices._slice == slice(None)
    assert indices[:] == indices_1
    assert indices_1._slice == slice(None)
    assert indices[::-1] == indices_2
    assert indices_2._slice == slice(None, None, -1)
    assert indices[:12:2] == indices_3
    assert indices_3._slice == slice(None, 12, 2)

# Generated at 2022-06-10 21:45:46.821552
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from sys import _getframe
    import frames
    import inspect
    import traceback

# Generated at 2022-06-10 21:45:57.217179
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def check(expected, a, b):
        # create a dict of subclass instances to verify that
        # the __eq__ method of BaseVariable is being used
        cases = {a: 'a', b: 'b'}
        # verify the expected result (with a useful error message
        # containing the string representation of the objects)
        assert cases[a] == cases[b], '{!r} != {!r}'.format(a, b)
        # verify that the expected boolean value was returned
        assert cases.get(a) == cases.get(b) == expected
    # test using various subclasses of BaseVariable
    check(True, Attrs('a.b'), Attrs('a.b'))
    check(True, Keys('a.b'), Keys('a.b'))

# Generated at 2022-06-10 21:46:07.950977
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import utils
    # <Test function> 1
    v1 = BaseVariable('a', exclude=['b'])
    v2 = BaseVariable('a', exclude=['b'])
    assert utils.eq(v1, v2)
    # <Test function> 2
    v3 = BaseVariable('a')
    assert not utils.eq(v1, v3)
    # <Test function> 3
    v3 = BaseVariable('a', exclude=['a'])
    assert not utils.eq(v1, v3)
    # <Test function> 4
    v3 = BaseVariable('b', exclude=['b'])
    assert not utils.eq(v1, v3)
    # <Test function> 5
    v1 = BaseVariable('a', exclude='b')
    v2 = Base

# Generated at 2022-06-10 21:46:22.087241
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        return {"a": 1, "b": {"i": 2}}

    f.x = {"a": 1, "b": {"i": 2}}
    v = BaseVariable("f()", exclude=("a", ))
    assert v.items({'f': f}) == [('f()', "{'b': {...}}"), ('f()["b"]', "{'i': 2}")]

    v = BaseVariable("f.x", exclude=("a", ))
    assert v.items({'f': f}) == [('f.x', "{'b': {...}}"), ('f.x["b"]', "{'i': 2}")]

    v = BaseVariable("f[5]()", exclude=("a", ))

# Generated at 2022-06-10 21:46:24.644833
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    c = BaseVariable('a')
    assert a == b
    assert a != c

# Generated at 2022-06-10 21:46:30.786918
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('x')
    assert v1 == BaseVariable('x')
    v2 = BaseVariable('x', exclude=('y',))
    assert v2 == BaseVariable('x', exclude=('y',))
    assert v2 != BaseVariable('x', exclude=())
    v3 = Keys('x')
    assert v3 == Keys('x')
    v4 = Indices('x')
    assert v4 == Indices('x')



# Generated at 2022-06-10 21:46:39.030450
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert list(Indices('x', exclude='_').items(None)[1:]) == \
    [('x[0]', '1'), ('x[1]', '2'), ('x[2]', '3')]
    assert list(Indices('x', exclude='_')[1:2].items(None)[1:]) == \
    [('x[1]', '2')]
    assert list(Indices('x', exclude='_')[:2].items(None)[1:]) == \
    [('x[0]', '1'), ('x[1]', '2')]
    assert list(Indices('x', exclude='_')[::2].items(None)[1:]) == \
    [('x[0]', '1'), ('x[2]', '3')]


# Generated at 2022-06-10 21:46:44.666317
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[1:]
    assert id(a) != id(b)
    assert a._slice == slice(None)
    assert b._slice == slice(1, None)
    assert b._fingerprint == (Indices, 'a', ())
    assert b._fingerprint != a._fingerprint
    assert a == Indices('a')
    assert a != Indices('b')

# Generated at 2022-06-10 21:46:55.753582
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'a': 10, 'b': 11, 'c': 12, 'd':13}
    print('\nDictionary in frame:', frame)
    variable = BaseVariable('a')
    result = variable.items(frame)
    print('\nitems of variable "a":\n', result)


# Generated at 2022-06-10 21:46:59.011978
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import base_variable

    result = base_variable.BaseVariable(
        source='repr(object())',
        exclude=['__weakref__', '__dict__']
    ).items(frame=None)
    assert len(result) == 1

# Generated at 2022-06-10 21:47:05.035126
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    local_var = {'x': 1}
    global_var = {'y': 2}
    eval_str = 'x+y'
    eval_result = local_var['x'] + global_var['y']
    eval_frame = utils.Frame(None, None, global_var, local_var)
    assert eval(eval_str) == eval_result
    user_source = 'x'
    expect_result = [('x', '1')]
    assert BaseVariable(user_source).items(eval_frame) == expect_result


test_data = {'test_BaseVariable_items': test_BaseVariable_items}

if __name__ == '__main__':
    func = test_data['test_BaseVariable_items']
    func()

# Generated at 2022-06-10 21:47:06.901028
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')

# Generated at 2022-06-10 21:47:12.436870
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('x')
    v2 = BaseVariable('z')
    v3 = BaseVariable('x', exclude=('a'))
    v4 = BaseVariable('x', exclude=('b'))
    assert v1 == v1
    assert not v1 == v2
    assert not v1 == v3
    assert not v3 == v4


# Generated at 2022-06-10 21:47:25.505410
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('c', exclude='d')
    assert BaseVariable('a') != BaseVariable('c', exclude=('d', 'e'))
    assert BaseVariable('a') == BaseVariable('a', exclude=('d', 'e'))
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a') != Attrs('c', exclude='d')
    assert Attrs('a') != Attrs('c', exclude=('d', 'e'))
    assert Attrs('a') == Attrs('a', exclude=('d', 'e'))
    assert Keys('a') == Keys('a')
    assert Keys

# Generated at 2022-06-10 21:47:31.802361
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global_dict = {"__builtins__": {}}
    local_dict = {"y": 2, "z": 3, "q": [0, 1, 2, 3, 4], "w": np.ones((2,2))}
    print(repr(local_dict))
    frame = types.FrameType(globals=global_dict, locals=local_dict)
    #object of class BaseVariable
    a = BaseVariable("x", None)
    print(repr(a))
    assert(a.source == "x")
    assert(a.exclude == None)
    # object of class Attrs
    b = Attrs("q", ["__builtins__"])
    print(repr(b))
    assert(b.source == "q")
    assert(b.exclude == ["__builtins__"])

# Generated at 2022-06-10 21:47:37.282540
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = Attrs('abcd')
    b = Attrs('abcd')
    c = Attrs('abcdefg')
    d = Attrs('abcd', 'abcdefg')
    e = Attrs('abcd', 'abcdefg')
    assert a == b
    assert a != c
    assert d == e


# Generated at 2022-06-10 21:47:47.618779
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Variable(BaseVariable):
        def _items(self, key, normalize=False):
            pass
    assert Variable('process_id') == Variable('process_id')
    assert Variable('process_id') != Variable('process_id_')
    assert Variable('process_id', exclude=('a')) == Variable('process_id', exclude=('a'))
    assert Variable('process_id', exclude=('a')) != Variable('process_id', exclude=('b'))
    assert Variable('process_id') != Variable('process_id', exclude=('a'))
    assert Variable('process_id', exclude=['a']) == Variable('process_id', exclude=['a'])

# Generated at 2022-06-10 21:47:57.326424
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    BaseVariable.items() 가 각각의 class에서 정상적으로 동작하는지 확인한다.
    :return:
    """
    base_variable = BaseVariable('a')
    frame = DummyFrame()
    frame.f_locals = {"a": "test"}
    print(base_variable.items(frame))
    assert base_variable.items(frame)[0][0] == "a" and base_variable.items(frame)[0][1] == 'test'

    common_variable = CommonVariable('a')
    frame = DummyFrame()
    frame.f_locals = {"a": [1, 2, 3]}
   

# Generated at 2022-06-10 21:48:18.345139
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def inner_test(source, exclude, *expected):
        v = BaseVariable(source, exclude)
        assert v.source == source
        assert v.exclude == exclude
        assert v.items({}) == expected

    yield inner_test, 'test', (), \
        (('test', ''),)
    yield inner_test, 'test', ['x'], \
        (('test', ''),)
    yield inner_test, 'test', ['test'], \
        ()
    yield inner_test, 'test', ['test'], \
        ()
    yield inner_test, 'test', ['test'], \
        ()
    yield inner_test, 'test.x', ['test.x'], \
        (('test', ''),)

# Generated at 2022-06-10 21:48:29.769560
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .test_utils import TestCase

    class TestVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return tuple(
                (key, utils.get_shortish_repr(value, normalize=normalize))
                for key, value in (('a', 1),
                                   ('b', '2'),
                                   ('c', Exception('asd')))
            )

    class TestCase(TestCase):
        def test_items(self):
            obj = TestVariable(1)
            self.assertEqual(obj.items(None), ('a', '1'), ('b', '2'), ('c', 'Exception("asd")'))

# Generated at 2022-06-10 21:48:34.975534
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global_a, global_b, global_c = 1, 2, 3
    def test_function(a, b):
        c = a + b
        class TestClass():
            def __init__(self):
                self.a = a
                self.b = b

            def test_method(self):
                return c

        instance = TestClass()
        return instance


# Generated at 2022-06-10 21:48:44.641881
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert Attrs('x') == Attrs('x')
    assert Attrs('x') != Attrs('y')
    assert Attrs('x', exclude='y') == Attrs('x', exclude='y')
    assert Attrs('x', exclude='y') != Attrs('x', exclude='z')
    assert Attrs('x', exclude=['y']) == Attrs('x', exclude='y')
    # next line is False but in Python 2.7 it returns True
    #assert Attrs('x', exclude=['y']) != Attrs('x', exclude=['y'])
    assert Attrs('x', exclude='y') != Attrs('y', exclude='y')

# Generated at 2022-06-10 21:48:47.469619
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indicesVariable = Indices(source="main_value")
    debugVariable = indicesVariable[1:3:1]
    assert debugVariable._slice == slice(1,3,1)

# Generated at 2022-06-10 21:48:57.321027
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.stack()[1].frame
    assert Keys('foo').items(frame) == [
        ('foo[None]', '0'),
        ('foo["a"]', '1'),
        ('foo["b"]', '2'),
        ('foo["c"]', '3')
    ]
    assert Indices('foo').items(frame) == [
        ('foo', '[0, 1, 2, 3]'),
        ('foo[0]', '0'),
        ('foo[1]', '1'),
        ('foo[2]', '2'),
        ('foo[3]', '3')
    ]

# Generated at 2022-06-10 21:49:08.367868
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import types
    from . import Tracer

    tracer = Tracer(variables=('var',))

    @tracer.wrap
    def f(var):
        var
        return var

    f(1)

    assert [x.locals['var'] for x in tracer.events] == [1, 1]

    def gen():
        x = 1
        yield x
        x += 1
        yield x

    @tracer.wrap
    def g(var):
        var
        return var

    g(gen())

    assert [x.locals['var'] for x in tracer.events] == ['<generator object {} at ...>'.format(gen.__name__),
                                                        '<generator object {} at ...>'.format(gen.__name__)]


# Generated at 2022-06-10 21:49:11.519323
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    vars = Indices("x[0]")
    vars[1:2]
    assert str(vars) == "Indices('x[0]', exclude=())[1:2]"


# Generated at 2022-06-10 21:49:16.266528
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'a'
    exclude = ()
    data = ('a', 'b', 'c', 'd')
    expected = [('a[1:3]', 'b'), ('a[1:3]', 'c')]

    v = Indices(source, exclude)
    actual = v[1:3].items(data)

    assert actual == expected


# Generated at 2022-06-10 21:49:22.072550
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create a simple function
    def test_function():
        return
    # Create a mock frame object
    mock_frame = utils.create_fake_frame('test_function', line_number=1)
    # Create a mock BaseVariable object
    mock_base_variable = BaseVariable('variable', ['test'])
    # Create a mock current_frame attribute
    mock_current_frame = utils.create_fake_frame('test_function', line_number=2)
    # Add the mock current_frame attribute to the mock frame object
    mock_frame.f_back = mock_current_frame
    # Call the items method from the mock BaseVariable object
    assert not mock_base_variable.items(mock_frame)


# Generated at 2022-06-10 21:49:53.818972
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for attributes
    import os
    print("==============test for attributes==================")
    v=Attrs("os")
    results=v.items(None)
    for one_result in results:
        print(one_result)
    # test for keys of a mapping
    print("==============test for keys==================")
    v=Keys("os.environ")
    results=v.items(None)
    for one_result in results:
        print(one_result)
    # test for indices of a sequence
    print("==============test for indices==================")
    v=Indices("os.getcwd()")
    results=v.items(None)
    for one_result in results:
        print(one_result)

# Generated at 2022-06-10 21:50:00.489960
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test for condition isinstance(other, BaseVariable)
    class Sub(BaseVariable):
        def __init__(self):
            pass
        def items(self, frame, normalize=False):
            return ()
        @abc.abstractmethod
        def _items(self, key, normalize=False):
            raise NotImplementedError
    v = BaseVariable('x')
    s = Sub()
    assert not v == s

    # Test for condition self._fingerprint == other._fingerprint
    v1 = BaseVariable('x')
    v2 = BaseVariable('x')
    assert v1 == v2
    v2.exclude = []
    assert v1 != v2



# Generated at 2022-06-10 21:50:12.125632
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect

    def unit_test_function():
        def inner_function():
            pass
        variable = BaseVariable("element")
        variable.code = "element"
        variable.unambiguous_source = "element"
        variable.exclude = []
        variable.source = "element"
        variable.items([1, 2, 3])
        variable.items((1, 2, 3))
        variable.items({1: 2, 3: 2})
        variable.items(1)
        variable.items(True)
        variable.items("string")
        variable.items(inner_function)

        variable.source = """
        def inner_function(a, b, c):
            print(a + b + c)
        inner_function(1, 2, 3)
        """

# Generated at 2022-06-10 21:50:14.187346
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('s')[:3]._slice == slice(3)


# Generated at 2022-06-10 21:50:26.093344
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import pycompat
    from . import utils
    from .explode import Attrs, Keys, Indices, Exploding, BaseVariable

    t = Indices('1[2]')
    t1 = t.__getitem__(pycompat.slice(None))
    assert type(t1) == Indices
    assert t1.source == '1[2]'
    assert t1.exclude == ()
    assert t1.code.co_names == ('1',)

    assert t._keys('123') == [0, 1, 2]

    assert t._format_key(0) == '[0]'
    assert t._format_key(1) == '[1]'
    assert t._format_key(2) == '[2]'

    assert t._get_value('123', 0) == '1'
    assert t

# Generated at 2022-06-10 21:50:27.786355
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = [123]
    var = Indices("a")
    var[0:1]
    assert var._slice == slice(0, 1)

# Generated at 2022-06-10 21:50:30.624421
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("x")[1:3]
    assert isinstance(a, Indices)
    assert a._slice == slice(1,3)


# Generated at 2022-06-10 21:50:41.814539
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import gc
    from . import spprint
    import random

    # Create data
    num = 500
    random.seed(0)
    data = [(random.randint(1,10), random.randint(1,10)) for i in range(num)]
    m = dict()
    for i in data:
        if i[0] in m:
            m[i[0]].append(i[1])
        else:
            m[i[0]] = [i[1]]
    s = sorted(m.items())
    with open('dict.txt','w') as f:
        for i in s:
            f.write('{}: {}\n'.format(i[0],i[1]))
    print('Generated dict.txt for checking')
    del data

    # Check the memory usage of dict

# Generated at 2022-06-10 21:50:47.208705
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable(1)
    bv2 = BaseVariable(2)
    bv3 = BaseVariable(1)
    bv4 = BaseVariable(2)

    assert not bv1 == bv2
    assert bv1 == bv3
    assert not bv2 == bv3
    assert not bv2 == bv4


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-10 21:50:51.337845
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    d = {'test': 1}
    e = Indices('d[test]')
    f = e[0:2]
    assert isinstance(f, Indices)
    assert f._slice == slice(0, 2)
    with pytest.raises(AssertionError):
        e[1]

# Generated at 2022-06-10 21:51:34.117419
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_indices = Indices('x', exclude=('y'))
    test_slice = slice(1, 2, 3)
    test_indices[test_slice]
    assert test_indices._slice == test_slice

# Generated at 2022-06-10 21:51:46.846484
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    #frame1 = sys._getframe(1)
    frame1 = inspect.currentframe()
    frame2 = sys._getframe(1)
    frame3 = sys._getframe(2)
    frame4 = sys._getframe(3)
    frame5 = sys._getframe(4)

    # test case 1
    variable1 = Attrs("sys")
    variable1_items = variable1.items(frame1)
    assert len(variable1_items) == 10
    assert variable1_items[0][0] == "sys"
    assert variable1_items[0][1] == "<module 'sys' (built-in)>"
    assert variable1_items[1][0] == "sys.version_info"

# Generated at 2022-06-10 21:51:54.219388
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('__doc__') == Attrs('__doc__')
    assert Attrs('__doc__') != Attrs('__name__')
    assert Attrs('__doc__') != Keys('__doc__')
    assert Attrs('__doc__') != Keys('__name__')
    assert Attrs('__doc__') != Attrs('__doc__', ['test'])
    assert Attrs('__doc__', ['test']) != Attrs('__doc__', ['test'])
    assert Attrs('__doc__', ['test']) != Attrs('__doc__', ['test', 'test'])

# Generated at 2022-06-10 21:52:06.163594
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def check_eq(var1, var2, eq=True):
        print("var1: %s", var1)
        print("var2: %s", var2)
        eq = var1 == var2
        print("eq: %s", eq)
        return eq

    # private variable
    var1 = BaseVariable("self.__attr")
    var2 = BaseVariable("self.__attr")
    assert check_eq(var1, var2)

    # general variable
    var1 = BaseVariable("var1")
    var2 = BaseVariable("var2")
    # should be not equal
    assert not check_eq(var1, var2)

    # general variable
    var1 = BaseVariable("var1")
    var2 = BaseVariable("var1")
    assert check_eq(var1, var2)



# Generated at 2022-06-10 21:52:13.430558
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    glb = {'a':10, 'b':20, 'c':30, 'd':40, 'e':50}
    loc = {'x':100, 'y':200}
    frm = sys._getframe()
    frm.f_globals = glb
    frm.f_locals = loc
    print(frm)
    print(BaseVariable('a').items(frm))
    print(BaseVariable('b').items(frm))
    print(BaseVariable('c').items(frm))
    print(BaseVariable('d').items(frm))
    print(BaseVariable('e').items(frm))
    print(BaseVariable('x').items(frm))
    print(BaseVariable('y').items(frm))

# Generated at 2022-06-10 21:52:23.398408
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    for i in range(10):
        for j in range(10):
            assert Indices("*")[i:j][i:j] is Indices("*")[i:j], "Test1 failed with i=%d,j=%d"%(i,j)
            assert Indices("*")[j:i][i:j] is Indices("*")[i:j], "Test2 failed with i=%d,j=%d"%(i,j)
            assert Indices("*")[0:0][i:j] is Indices("*")[i:j], "Test3 failed with i=%d,j=%d"%(i,j)

# Generated at 2022-06-10 21:52:30.314310
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    import pandas as pd
    df = pd.DataFrame({
        'a': [1, 2, 3],
    })
    m = Keys('m')
    print(m.items(frame, df))
    t = Indices('t')
    print(t.items(frame, df))
    v = Attrs('v')
    print(v.items(frame, df))
    e = Exploding('a')
    print(e.items(frame, df))

# Generated at 2022-06-10 21:52:34.169957
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    该函数用于测试类BaseVariable中method __eq__的函数
    :return:
    """
    pass


a = BaseVariable('a')
k = Keys('k')
assert a != k

a2 = BaseVariable('a')
assert a == a2



# Generated at 2022-06-10 21:52:45.349661
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # set up objects
    bv1 = BaseVariable('source', exclude=('a', 'b'))
    bv2 = BaseVariable('source', exclude=('a', 'b'))
    bv3 = BaseVariable('source', exclude=('a', 'b', 'c'))
    bv4 = BaseVariable('source', exclude=(('a', 'b')))
    bv5 = BaseVariable('source', exclude=(('a', 'b'), 'c'))
    bv6 = BaseVariable('source', exclude=('c', ('a', 'b')))
    bv7 = BaseVariable('source', exclude=('c', 'a', 'b'))
    # expected results
    expected = [False, True, False, True, True, True, True]
    # actual results

# Generated at 2022-06-10 21:52:48.375257
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    d = {'source': 'abc', 'exclude':['abc'], 'unambiguous_source':'abc', 'code':'def'}
    a = BaseVariable('abc', ['abc'])
    assert a.__dict__==d
    b = BaseVariable('abc',['abc'])
    assert a.__eq__(b) # 因为 __eq__ return True，所以 a == b



# Generated at 2022-06-10 21:54:06.273359
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind=Indices('x')
    ind[0:2]


# Generated at 2022-06-10 21:54:09.720976
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_ = Indices('haha')
    indices2_ = indices_[1:3]
    assert indices2_.source == 'haha[1:3]'
    assert indices2_._slice == slice(1, 3)

# Generated at 2022-06-10 21:54:18.181379
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class DummyVariable(BaseVariable):
        pass
        
    assert(BaseVariable('source', 'exclude') == BaseVariable('source', 'exclude'))
    assert(BaseVariable('source1', 'exclude1') != BaseVariable('source2', 'exclude2'))
    assert(BaseVariable('source', 'exclude') != DummyVariable('source', 'exclude'))
    assert(BaseVariable('source', 'exclude') != 'source')
    assert(BaseVariable('source', 'exclude') != None)
    assert(BaseVariable(None, None) == None)


# Generated at 2022-06-10 21:54:23.777550
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('foo')
    indices_1 = indices[1:2]
    assert(indices_1._slice == slice(1, 2))
    indices_2 = indices[:]
    assert(indices_2._slice == slice(None))
    indices_3 = indices[0:]
    assert(indices_3._slice == slice(0, None))
    indices_4 = indices[::2]
    assert(indices_4._slice == slice(None, None, 2))
    indices_5 = indices[::-1]
    assert(indices_5._slice == slice(None, None, -1))

# test if eval and compile are working
# if it is working, then return value should be True and else, False

# Generated at 2022-06-10 21:54:28.670989
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('x')
    y = BaseVariable('y')
    z = BaseVariable('z')
    w = BaseVariable('x')
    result = x == y
    assert result == False
    result = x == w
    assert result == False
    result = x == z
    assert result == False

# Generated at 2022-06-10 21:54:31.905708
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('v')
    variable2 = variable[2:]
    assert variable2._slice == slice(2, None)

# Generated at 2022-06-10 21:54:37.360871
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import os.path
    local_variable = BaseVariable('str')
    print(local_variable._items('test'))
    print(local_variable._items(os.sep))

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:54:48.519409
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert not (BaseVariable('x') != BaseVariable('x'))
    assert BaseVariable('x') != BaseVariable('y')
    assert not (BaseVariable('x') == BaseVariable('y'))
    assert BaseVariable('x') != BaseVariable('x', exclude=('exclude', ))
    assert not (BaseVariable('x') == BaseVariable('x', exclude=('exclude', )))
    assert BaseVariable('x', exclude=('exclude', )) != BaseVariable('x')
    assert not (BaseVariable('x', exclude=('exclude', )) == BaseVariable('x'))



# Generated at 2022-06-10 21:54:59.618902
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Tests whether __eq__() method of the class BaseVariable
    #   is defined correctly.
    var1 = BaseVariable('x')
    var2 = BaseVariable('y')
    var3 = BaseVariable('x', exclude=('a', 'b'))
    var4 = BaseVariable('x', exclude=('b', 'c'))
    assert var1 == var1
    assert not (var1 == var2)
    assert not (var1 == var3)
    assert not (var1 == var4)
    assert not (var2 == var3)
    assert not (var2 == var4)
    assert not (var3 == var4)
    return None


# Generated at 2022-06-10 21:55:06.055536
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    g = {'x': 'x_value', 'y': 'y_value'}
    l = {'z': 'z_value'}
    f = {'__globals__': g, '__locals__': l}

    # testing class BaseVariable and class Attrs
    assert Attrs('x').items(f) == [('x', "'x_value'")]
    assert Attrs('x', exclude=['x']).items(f) == []
    assert Attrs('x.lower').items(f) == [('x.lower', "TypeError")]
    assert Attrs('x', exclude=['x.lower']).items(f) == [('x', "'x_value'")]
    assert Attrs('g.x').items(f) == [('g.x', "'x_value'")]
