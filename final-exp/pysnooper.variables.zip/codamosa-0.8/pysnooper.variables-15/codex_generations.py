

# Generated at 2022-06-10 21:45:23.347367
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    global_variable = BaseVariable('global_variable')
    local_variable = BaseVariable('local_variable')

    print (global_variable.__eq__(local_variable))

# Generated at 2022-06-10 21:45:31.309098
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_instance = Indices("x")
    sliced_instance = test_instance[2:5]
    assert(isinstance(sliced_instance, Indices))
    assert(sliced_instance._slice == slice(2, 5))
    assert(sliced_instance.source == "x")
    assert(sliced_instance.exclude == ())
    assert(test_instance._slice == slice(None))
    assert(test_instance.source == "x")
    assert(test_instance.exclude == ())

# Generated at 2022-06-10 21:45:42.673817
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    frames = [
        {'a':1, 'b':2, 'c':3, 'd':4, 'e':5},
        {'a':1, 'b':2, 'c':3, 'd':4, 'e':5},
        {'a':1, 'b':2, 'c':3, 'd':4, 'e':5}]
    variables = [
        Indices('a', exclude='b'),
        Indices('a', exclude='e'),
        Indices('a', exclude='d')]
    expected = [
         {'a':1},
         {'a':1},
         {'a':1}]

    for frame, variable, expected in zip(frames, variables, expected):
        actual = variable._items(frame)
        print(actual)
        assert actual == expected



# Generated at 2022-06-10 21:45:47.584886
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class B(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [('x', main_value)]
    a = B('a')
    assert a.items(dict(a=3)) == [('a', '3')]
    assert a.items(dict(a=3), normalize=True) == [('a', '3')]

# Generated at 2022-06-10 21:45:52.275458
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    foo = BaseVariable('foo', 'exclude')
    assert foo == BaseVariable('foo', 'exclude')
    assert foo != BaseVariable('foo', 'exclude1')
    assert foo != BaseVariable('foo1', 'exclude')
    assert foo != BaseVariable('foo1', 'exclude1')


# Generated at 2022-06-10 21:45:55.083753
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base_var1 = BaseVariable('a.b')
    base_var2 = BaseVariable('a.b')
    assert base_var1 == base_var2


# Generated at 2022-06-10 21:45:56.374487
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a = BaseVariable('a')
    assert a.items({'a':'b'}) == [('a', 'b')]
    

# Generated at 2022-06-10 21:46:02.392050
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a'
    exclude = ()
    variable = BaseVariable(source, exclude)

    # Test that items(frame, normalize=False) raises NotImplementedError
    def code(s):
        return compile(s, '<variable>', 'eval').co_code

    frame = {'a': [1, 2, 3]}

    try:
        variable.items(frame, normalize=False)
    except Exception as err:
        assert isinstance(err, NotImplementedError)



# Generated at 2022-06-10 21:46:13.152038
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    name = "__main__"
    frame = sys._getframe(0)
    v1 = BaseVariable("frame")
    v2 = BaseVariable("frame.function")
    v3 = BaseVariable("frame.code")
    v4 = BaseVariable("frame.code.co_name")

    result = [v.items(frame) for v in [v1, v2, v3, v4]]

# Generated at 2022-06-10 21:46:23.132525
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ###   Arrange   ###
    vlist = list(range(10))
    indices = Indices('mylist')
    indices_slice = indices[2:6]
    ###   Act   ###
    result = indices_slice.items(vlist)
    ###   Assert   ###
    assert result is not None
    assert result == [('mylist[0]', '0'), ('mylist[1]', '1'), ('mylist[2]', '2'), ('mylist[3]', '3'), ('mylist[4]', '4'), ('mylist[5]', '5')]

# Generated at 2022-06-10 21:46:35.585277
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    test = BaseVariable('a')
    return True

# Generated at 2022-06-10 21:46:38.049537
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x') != BaseVariable('y')


# Generated at 2022-06-10 21:46:45.216365
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    from . import codeinfo

    items = pycompat.exec_("""
x = {'a': 'abc', 'bc': [1, 2, 3], 'cde': 'cde'}
x.e = 'e'
""")

    var = codeinfo.Variables([codeinfo.Attrs(), codeinfo.Indices(), codeinfo.Keys()])
    print(var.source)
    print(var.items(items))


# Generated at 2022-06-10 21:46:53.388745
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]
    a = TestVariable('a')
    dic = {'a': {}, 'b': [], 'c': ()}
    for key, value in a.items(dic, normalize=True):
        print('{} = {}'.format(key, value))


# Generated at 2022-06-10 21:47:02.136856
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = [1,2,3,4,5]
    v = Indices('a')
    v1 = v[1:]
    assert v1._slice == slice(1, None, None)
    v2 = v[::2]
    assert v2._slice == slice(None, None, 2)
    v3 = v[:-1]
    assert v3._slice == slice(None, -1, None)
    v4 = v[1:3]
    assert v4._slice == slice(1, 3, None)
    v5 = v[:3:2]
    assert v5._slice == slice(None, 3, 2)
    v6 = v[::-1]
    assert v6._slice == slice(None, None, -1)
    v7 = v[-2:-4:-1]


# Generated at 2022-06-10 21:47:06.481862
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('x').__getitem__(slice(None))
    x = Indices('x')
    y = x[:3]
    assert isinstance(y, Indices)
    assert x._slice == slice(None)
    assert y._slice == slice(None, 3)

# Generated at 2022-06-10 21:47:15.045972
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class TestVar(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [('a', 'b'), ('c', 'd')]

    frame = object()

    test_var = TestVar('abc')
    assert test_var.items(frame) == [('a', 'b'), ('c', 'd')]
    test_var = TestVar('abc', exclude=['b'])
    assert test_var.items(frame) == [('a', 'b'), ('c', 'd')]
    test_var = TestVar('abc', exclude='b')
    assert test_var.items(frame) == [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-10 21:47:27.620442
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import os
    import tempfile
    f = tempfile.NamedTemporaryFile()
    f.file.close()
    os.remove(f.name)

    initial_frame_locals = {}
    frame_variables = [
        ('', 'self'),
        ('self.', 'name'),
        ('self.name.', 'value'),
        ('self._variable', 'bar'),
        ('self._variable.bar.', 'baz'),
    ]

    def create_frame():
        frame = utils.Frame(0)
        frame.f_locals = initial_frame_locals
        return frame

    def get_frame_variables(frame):
        return [(name, BaseVariable(name).items(frame)) for name, _ in frame_variables]


# Generated at 2022-06-10 21:47:36.242535
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import pytest
    from .utils import ensure_tuple
    from .pycompat import builtins

    def make_frame(code):
        return types.FunctionType(
            code, builtins.__dict__,
            name='<variable>',
            argdefs=None,
            closure=None
        ).__code__.co_varnames

    def get_keys(instance):
        return ensure_tuple(
            tuple(key for key, value in instance.items(inspect.currentframe()))
        )

    def get_values(instance):
        return ensure_tuple(
            tuple(value for key, value in instance.items(inspect.currentframe()))
        )

    class TestClass:
        def __init__(self, d):
            self.__dict__

# Generated at 2022-06-10 21:47:48.008023
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from contextlib import contextmanager
    from io import StringIO
    from .utils import Frame

    def catch_output(func, *args, **kwargs):
        output = StringIO()
        with redirect_stdout(output):
            try:
                func(*args, **kwargs)
            except Exception:
                pass
        return output.getvalue()

    @contextmanager
    def redirect_stdout(fileobj):
        stdout = sys.stdout
        sys.stdout = fileobj
        try:
            yield fileobj
        finally:
            sys.stdout = stdout

    class Foo(object):
        a = 1
        b = 'abc'
        def __iter__(self):
            return iter([1, 2, 3])
        def __len__(self):
            return 3

    foo = Foo()


# Generated at 2022-06-10 21:48:11.796048
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariableSubclass(BaseVariable):
        def items(self, frame, normalize=False):
            return None

    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    v3 = BaseVariable('b')
    v4 = BaseVariableSubclass('a')
    v5 = BaseVariableSubclass('a')
    v6 = BaseVariableSubclass('b')
    check_equals(v1, v2)
    check_not_equals(v1, v3)
    check_equals(v4, v5)
    check_not_equals(v4, v6)
    check_not_equals(v1, v4)


# Generated at 2022-06-10 21:48:14.666693
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
  assert BaseVariable("a","b") == BaseVariable("a","b")
  assert BaseVariable("a","b") != BaseVariable("b","b")

# Generated at 2022-06-10 21:48:21.009385
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def assertEqual(first, second):
        assert first == second
        assert second == first
        assert not(first != second)
        assert not(second != first)
    assertEqual(
        BaseVariable('x'),
        BaseVariable('x')
    )
    assertEqual(
        BaseVariable('x', exclude=('y', 'z')),
        BaseVariable('x', exclude=('y', 'z'))
    )
    assertEqual(
        BaseVariable('x', exclude=(1, 2)),
        BaseVariable('x', exclude=(1, 2))
    )
    assertEqual(
        BaseVariable('x.y', exclude=('z', )),
        BaseVariable('x.y', exclude=('z', ))
    )

# Generated at 2022-06-10 21:48:28.218732
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    assert a[1:3] == Indices("a")[1:3]
    assert a[1:3]._slice == slice(1, 3)
    assert a[1:3]._fingerprint == (Indices, "a", ())
    assert a[1:3]._fingerprint != (Indices, "b", ())
    assert a[1:3]._fingerprint != (Indices, "a", (1,))

# Generated at 2022-06-10 21:48:39.626601
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global a, d
    a = 1
    b = 2
    c = 3
    d = {'x1': 1, 'x2': 2}
    e = [1,2,3]
    f = (1,2,3)
    g = '111'
    h = {'x1': 1, 'x2': 2}
    i = [1,2,3]
    j = (1,2,3)
    k = '111'
    l = [(1, 2, 3)]
    # test for method 'items':
    print(BaseVariable('a').items(locals()))
    print(BaseVariable('d.x2').items(locals()))
    print(BaseVariable('e').items(locals()))
    print(BaseVariable('l').items(locals()))

# Generated at 2022-06-10 21:48:45.858790
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import pprint
    frame = inspect.currentframe()
    vars = [
        Attrs('a'),
        Attrs('a.b'),
        Keys('a'),
        Indices('a'),
        Exploding('a'),
        Exploding('a.b'),
        Attrs('a', exclude='b'),
        Keys('a', exclude='b'),
        Exploding('a', exclude='b')
    ]
    for v in vars:
        print('%s:' % (v.source, ))
        for src, rep in v.items(frame):
            print('    %s = %s' % (src, rep))

# Generated at 2022-06-10 21:48:55.368647
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .utils import get_shortish_repr
    
    main_value = ['a', 'b', 'c']
    result = Indices('test_main_value').__getitem__(slice(1,3))
    assert result.source == 'test_main_value'
    assert result.exclude == ()
    assert result._slice == slice(1, 3)
    assert result._format_key(2) == '[2]'
    assert result._items(main_value) == [('test_main_value', '[]'), ('test_main_value[1]', "'b'"), ('test_main_value[2]', "'c'")]

# Generated at 2022-06-10 21:49:06.533078
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    foo = Attrs('foo', exclude=['bar'])
    globals()['foo'] = 1
    assert tuple(foo.items(sys._getframe())) == (('foo', '1'),)

    foo = Attrs('foo', exclude=['bar'])
    class Foo(object):
        bar = 1
        def __init__(self, baz):
            self.baz = baz
    globals()['foo'] = Foo(1)
    assert tuple(foo.items(sys._getframe())) == (
        ('foo', '<Foo at 0x{}>'.format(id(Foo))),
        ('foo.baz', '1'),
    )
    
    foo = Keys('foo', exclude=['bar'])

# Generated at 2022-06-10 21:49:11.007552
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = "a.keys()"
    exclude = "test_var"
    a = dict()
    a['test_var'] = 'test'
    indices = Indices(source, exclude)
    assert(indices.items(a) == ())


EXPLODE = Exploding



# Generated at 2022-06-10 21:49:17.772634
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    from . import pycompat
    g = globals()
    for name, cls in g.items():
        if not pycompat.PY2 and isinstance(cls, pycompat.abc.ABCMeta):
            if issubclass(cls, BaseVariable):
                i1 = cls('a').items(utils.get_sample_frame())
                assert isinstance(i1, tuple)
                i2 = cls('a.b').items(utils.get_sample_frame())
                assert isinstance(i2, tuple)


# Generated at 2022-06-10 21:49:31.863698
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var', ['x'])[1:3]
    assert var.source == 'var'
    assert var.exclude == ('x',)
    assert var._slice == slice(1, 3)

# Generated at 2022-06-10 21:49:42.158969
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a", ())
    a_slice = a[2:]
    assert a_slice.source == "a[2:]", 'Source is not expected'
    assert a_slice.exclude == (), 'Exclude is not expected'
    assert a_slice.code, 'Code is not expected'
    assert a_slice.unambiguous_source == "a[2:]", 'Unambiguous_source is not expected'

    assert a._fingerprint == (Indices, 'a', ())
    assert a._slice == slice(None)
    assert a_slice._slice == slice(2, None)
    assert a_slice.items(frame=None) == a[2:]._items(main_value=None) == [('a[2:]', 'None')]

# Generated at 2022-06-10 21:49:48.623028
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1, a2, a3 = Attrs('a'), Attrs('a'), Attrs('a')
    b1, b2, b3 = Attrs('b'), Attrs('b'), Attrs('b')
    assert a1 == a1
    assert a1 == a2
    assert a1 == a3
    assert b1 == b1
    assert b1 == b2
    assert b1 == b3
    assert a1 != b1

# Generated at 2022-06-10 21:49:54.672544
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('x')
    b = a[0:3]
    assert b._slice == slice(0,3)
    assert b.source == 'x'
    assert b.exclude == ()
    assert b.code == a.code
    assert b.unambiguous_source == a.unambiguous_source
    assert b._fingerprint == a._fingerprint
    assert b.__hash__() == a.__hash__()
    assert b.__eq__(a)

# Generated at 2022-06-10 21:49:57.376508
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('', ())
    actual = v.__getitem__(slice(1, 4))
    print(actual._slice)
    assert isinstance(actual, Indices)



# Generated at 2022-06-10 21:50:07.255103
# Unit test for method __eq__ of class BaseVariable

# Generated at 2022-06-10 21:50:08.898063
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('main')[1:3]._slice == slice(1, 3)


# Generated at 2022-06-10 21:50:18.704197
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    a = 10
    b = {'x': 'xp', 'y': 'yp'}
    c = ['a', 'b', 'c']
    d = [{'x1': 'xp1', 'y1': 'yp1'}, 'b', 'c']
    e = [{'x1': 'xp1', 'y1': 'yp1'}, ['b', 'c']]
    """
    d = {'a': 10, 'b': {'x': 'xp', 'y': 'yp'}, 'c': ['a', 'b', 'c'], 'd': [{'x1': 'xp1', 'y1': 'yp1'}, 'b', 'c'], 'e': [{'x1': 'xp1', 'y1': 'yp1'}, ['b', 'c']]}

# Generated at 2022-06-10 21:50:31.476202
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect

    def some_function(foo, bar=None, **kwargs) :
        return locals()

    frame = inspect.currentframe().f_back
    #vars = Attrs('')
    #print(vars.items(frame))
    #print(vars.items(frame, normalize=True))

    vars = Attrs('sys')
    print(vars.items(frame))
    print(vars.items(frame, normalize=True))

    vars = Attrs('foo')
    print(vars.items(frame))
    print(vars.items(frame, normalize=True))

    vars = Keys('kwargs')
    print(vars.items(frame))
    print(vars.items(frame, normalize=True))

    vars = Keys

# Generated at 2022-06-10 21:50:38.050394
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a[1:2][2:3][3:4].'
    exclude = ('abcd', 'a[1:2][2:3][3:4].f')
    v = BaseVariable(source, exclude)
    assert v.source == source
    assert v.exclude == exclude
    assert v.code == compile(source, '<variable>', 'eval')
    assert isinstance(v, BaseVariable)



# Generated at 2022-06-10 21:51:01.698491
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('variable')
    var = var[2:][2:-1]
    assert var._fingerprint == (Indices, 'variable', ())
    assert var._slice == slice(2, -1, None)

# Generated at 2022-06-10 21:51:03.647896
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    s = 'frame.f_locals'
    instance = BaseVariable(s)


# Generated at 2022-06-10 21:51:10.405629
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_case(source, frame):
        variable = BaseVariable(source, ('__dict__', '__class__'))
        print(list(variable.items(frame)))

    frame = sys._getframe()
    test_case('sys.exc_info()', frame)
    test_case('sys.__class__', frame)
    test_case('sys._getframe()', frame)
    test_case('sys._getframe().f_code', frame)
    test_case('sys._getframe().f_code.co_name', frame)

# Generated at 2022-06-10 21:51:22.650753
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import mockup
    from . import freeze

    class C(object):
        a = 1
        b = 2
    C_obj = C()

    frame = freeze.Frame()

    #Test 1:
    obj = BaseVariable('C_obj')
    result = obj.items(frame)
    print(result)
    assert result == (('C_obj', 'C_obj'),)

    #Test 2:
    obj = BaseVariable('C_obj', exclude=['a'])
    result = obj.items(frame)
    print(result)
    assert result == (('C_obj', 'C_obj'), ('C_obj.b', '2'))

    #Test 3:
    obj = BaseVariable('C_obj', exclude=['a', 'b'])
    result = obj.items(frame)
   

# Generated at 2022-06-10 21:51:31.224033
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('dict')
    assert isinstance(obj, BaseVariable)
    assert obj._source == 'dict'
    assert obj._exclude == ()
    assert obj._slice == slice(None)
    assert obj._code.co_filename == '<variable>'
    assert obj._code.co_name == '<module>'

    obj2 = obj[1:2]
    assert obj2._slice == slice(1, 2, None)
    assert obj2 is not obj

# Generated at 2022-06-10 21:51:33.709325
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('i')[1:3]._slice == slice(1,3)



# Generated at 2022-06-10 21:51:46.309108
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    import copy
    import pytest

    variable_name = "variable_name"
    
    variable_source = variable_name
    variable = BaseVariable(variable_source)
    
    variable_source1 = variable_name
    variable1 = BaseVariable(variable_source1)

    variable_source2 = "user"
    variable2 = BaseVariable(variable_source2)

    variable_source3 = variable_name
    variable3 = variable

    variable_source4 = variable_name
    variable4 = copy.deepcopy(variable)
    
    variable_source5 = variable_name
    variable5 = copy.copy(variable)

    variable_source6 = variable_name
    variable6 = BaseVariable(variable_source6, exclude = variable_name)

    variable_source7 = variable_name

# Generated at 2022-06-10 21:51:48.122199
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    assert var[:1] == Indices('a', slice=slice(None, 1, None))

# Generated at 2022-06-10 21:51:56.850018
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f():
        pass

    def g():
        pass

    from .frame import FrameObject
    # Bind self to the frame's locals
    frame = FrameObject(None, f.__code__, None, None, {'self': object()})

    def _test(cls, exclude=()):
        variable = cls('.self', exclude)
        assert variable.items(frame)[0] == ('.self', '<object>')

    def _test_all(cls):
        _test(cls)
        _test(cls, ('.x',))
        _test(cls, ['x'])

    _test_all(Attrs)
    _test_all(Keys)
    _test_all(Indices)
    _test_all(Exploding)


# Generated at 2022-06-10 21:52:02.708120
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for main_value is dict
    dict_variable = utils.DictVariable(source='abc')
    main_value = {'name':'John', 'dept':'IT'}
    dict_variable._items(main_value)
    # test for main_value is list
    list_variable = utils.ListVariable(source='abc')
    main_value = ['apple', 'banana', 'orange']
    list_variable._items(main_value)


# Generated at 2022-06-10 21:52:52.495517
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a'
    v = BaseVariable(source)
    a = {'a': 'g'}
    b = []
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    b.append(a)
    frame = {'b':b}
    result = v.items(frame, 1)
    print(result)
    for i,v in result:
        print(i, '=', v)
    source = 'b'
    v = BaseVariable(source)
    result = v.items(frame, 1)
    print(result)

# Generated at 2022-06-10 21:52:59.232859
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    val = 1
    var = BaseVariable('a')
    assert var.items({'a': val}) == [('a', '1')]
    assert var.items({'b': val}) == []

    var = BaseVariable('c')
    assert var.items({'c': val}) == [('c', '1')]
    assert var.items({'b': val}) == []

    var = CommonVariable('a')
    assert var.items({'a': val}) == [('a', '1')]
    assert var.items({'b': val}) == []

    var = CommonVariable('c')
    assert var.items({'c': val}) == [('c', '1')]
    assert var.items({'b': val}) == []

    var = Attrs('a')

# Generated at 2022-06-10 21:53:03.923856
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Arrange
    source = 'myvar'
    exclude = ()
    indices_variable = Indices(source, exclude)

    # Act
    result = indices_variable[:]

    # Assert
    assert isinstance(result, Indices)
    assert result._slice == slice(None)

# Generated at 2022-06-10 21:53:10.480201
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys, os
    # source is a python source code string and frame is a fake frame
    source = 'os.getcwd()'
    frame = sys._getframe()
    frame.f_locals['os'] = os
    frame.f_globals['os'] = os


    cla = BaseVariable(source)
    res = cla.items(frame)
    print(res)

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:53:18.005964
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import six
    from . import utils
    from . import pycompat

    import types
    import collections
    import numpy as np
    import pandas as pd
    import openpyxl
    import asyncio

    import unittest

    # Dummy class for testing
    class DummyClass:
        def __init__(self):
            self.b = 'John'

        def __getitem__(self, item):
            return item


# Generated at 2022-06-10 21:53:24.138905
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    my_var = Indices('x1')
    my_var_slice = my_var[1::2] 
    assert(isinstance(my_var_slice, Indices) == True)
    assert(my_var._slice == slice(None))
    assert(my_var_slice._slice == slice(1, None, 2))
    
    
    

# Generated at 2022-06-10 21:53:30.880034
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = ['a', 'b', 'c']
    indices = Indices('x')
    assert indices[:] == indices[0:3]
    assert indices[:] == Indices('x')
    assert indices[1:] == Indices('x')[1:]
    assert indices[1:3] == Indices('x')[1:3]
    assert isinstance(indices[:], Indices)

# Generated at 2022-06-10 21:53:40.047936
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import framevar

    frame = framevar.test_frame()

    def test(variable, expected):
        actual = list(variable.items(frame, normalize=True))
        assert set(expected) == set(actual), '{} -> {} != {}'.format(variable, expected, actual)

    test(Attrs('__builtin__'), [
        ('__builtin__', 'module'),
        ('__builtin__.pow', 'built-in function or method'),
        ('__builtin__.NotImplemented', 'NotImplemented'),
        ('__builtin__.int', 'type'),
    ])


# Generated at 2022-06-10 21:53:42.778125
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    example_indices = Indices('test')
    example_slice = slice(1,4,2)
    example_indices2 = example_indices[example_slice]
    assert(example_indices2._slice is example_slice)
    assert(example_indices is not example_indices2)

# Generated at 2022-06-10 21:53:43.589114
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices("", ()).__getitem__(slice(None))