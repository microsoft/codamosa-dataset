

# Generated at 2022-06-10 21:45:18.727373
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x', exclude=('a', 'b'))[:] == Indices('x', exclude=('a', 'b'))
    assert Indices('x', exclude=('a', 'b'))[::2] != Indices('x', exclude=('a', 'b'))

# Generated at 2022-06-10 21:45:31.094770
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    mylist = list(range(9))
    print([(x, mylist[x]) for x in range(len(mylist))])
    print([(x, mylist[x]) for x in range(len(mylist))[1:6:2]])
    print([(x, mylist[x]) for x in Indices('x')[1:6:2]])
    print('-'*50)
    try:
        print([(x, mylist[x]) for x in Indices('y')[1:6:2]])
    except NameError as e:
        print('caught NameError for Indices(y)')
        print(e)
        pass

if __name__ == '__main__':
    print('unit test Indices.__getitem__')
    test_Indices___getitem__

# Generated at 2022-06-10 21:45:33.681816
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')[1:3]
    assert isinstance(v, Indices)
    assert v._slice == slice(1, 3)

# Generated at 2022-06-10 21:45:44.592423
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import re
    import types

    class SomeVar(BaseVariable):
        pass

    class SomeAttr(object):
        _foo = 'foo'
        _bar = 'bar'
        _baz = 'baz'

        def __init__(self):
            self._init = 'init'

    class SomeDict(dict):
        _foo = 'foo'
        _bar = 'bar'
        _baz = 'baz'

    class SomeList(list):
        _foo = 'foo'
        _bar = 'bar'
        _baz = 'baz'

    class SomeTupl(tuple):
        _foo = 'foo'
        _bar = 'bar'
        _baz = 'baz'


# Generated at 2022-06-10 21:45:47.186281
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', ('b',))
    var2 = BaseVariable('a', ('b',))
    assert var1 == var2
    assert var1 == var1

# Generated at 2022-06-10 21:45:57.403959
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from types import ModuleType, FunctionType
    source = "__builtins__"
    exclude = []
    BaseVariableInstance = BaseVariable(source, exclude)
    # call the method in the class
    result = BaseVariableInstance.items(BaseVariableInstance)
    if not isinstance(result, tuple):
        print("The method in the class result type is not correct")
        return False
    if not (len(result) > 0):
        print("The method in the class result length is not correct")
        return False
    if not (len(result[0]) == 2):
        print("The method in the class result content is not correct")
        return False
    if not (result[0][0] == "__builtins__"):
        print("The method in the class result content of first item is not correct")
        return False

# Generated at 2022-06-10 21:46:01.704927
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():

    def generate_frame():
        x = 'Test'
        main_value = Attrs('x')
        return main_value.items(inspect.currentframe())

    assert generate_frame() == [('x', "'Test'")]

    def generate_frame():
        class A:
            pass
        x = A()
        main_value = Keys('x')
        return main_value.items(inspect.currentframe())

    assert generate_frame() == [('x', '{}')]

# Generated at 2022-06-10 21:46:07.461192
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'a_variable'
    code = compile(source, '<variable>', 'eval')
    frame = FakeFrame()
    frame.f_locals['a_variable'] = 'hello_world'
    var = BaseVariable(source)
    result = var.items(frame)
    for each in result:
        print(each)


# Generated at 2022-06-10 21:46:17.409786
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import builtins
    '''
    frame is the faked frame.
    frame.f_locals is a faked f_locals of frame.
    frame.f_locals['aa'] is a faked aa in f_locals of frame.
    frame.f_locals['aa']['bb'] is a faked bb in a faked aa in f_locals of frame.
    '''
    frame = {}
    frame.f_locals = {'aa': {'bb': 'cc'}}

    def test_func():
        '''
        This function is a faked function that create a fake frame.
        '''
        import logging

        logging.info('aa')
        '''Faked frame begins'''
        frame.f_globals = ''

# Generated at 2022-06-10 21:46:19.199592
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_var = Indices('a')[5:10:2]
    assert test_var._slice == slice(5,10,2)


# Generated at 2022-06-10 21:46:35.697754
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # 1. code: test_BaseVariable.items
    import os
    import inspect
    import collections
    global_var = os
    local_var = inspect
    obj_var = collections
    a = global_var
    b = local_var
    c = obj_var
    test_BaseVariable_items_frame = inspect.currentframe()
    test_BaseVariable_items_var_info = [('global_var', 'os'), ('local_var', 'inspect'), ('obj_var', 'collections'), ('a', 'os'), ('b', 'inspect'), ('c', 'collections')]
    # 1.1. code: test_BaseVariable.items:object_variable:Keys
    # 1.1.1. code: test_BaseVariable.items:object_variable:Keys:source
    a = Keys('obj_var')

# Generated at 2022-06-10 21:46:37.687129
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable("1")
    var.items(None)
    var._items(None)


# Generated at 2022-06-10 21:46:49.347558
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import enum
    from . import utils
    from .tracer import Tracer
    from .enum import find
    import inspect
    import os
    import sys
    import time
    import unittest

    class AssertRaisesContext(object):
        """A context manager used to implement TestCase.assertRaises* methods."""

        def __init__(self, expected, test_case, expected_regexp=None):
            self.expected = expected
            self.failureException = test_case.failureException
            self.expected_regexp = expected_regexp

        def __enter__(self):
            return self


# Generated at 2022-06-10 21:46:59.563378
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = '__name__'
    exclude = ('__dict__', '__module__')
    base_v1 = BaseVariable(source, exclude)
    base_v2 = BaseVariable(source, exclude)

    base_v1.__getitem__ = lambda self, item: Indices
    base_v2.__getitem__ = lambda self, item: Keys
    assert base_v1.__getitem__(base_v1, slice(None)) is Indices
    assert base_v2.__getitem__(base_v2, slice(None)) is Keys

    result_v1 = base_v1.items('0')
    result_v2 = base_v2.items('0')
    print(result_v1)
    print(result_v2)

# Generated at 2022-06-10 21:47:07.029811
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = {}
    d.update(eval("BaseVariable('a')").items(d))
    d.update(eval("BaseVariable('a')").items(d))
    d.update(eval("BaseVariable('a')").items(d))
    d.update(eval("BaseVariable('a')").items(d))
    assert d['a'] == 'None'
    del d['a']
    d.update(eval("BaseVariable('a')").items(d))
    assert d['a'] == 'None'

# Generated at 2022-06-10 21:47:12.687152
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a')==BaseVariable('a')
    assert BaseVariable('a')!=BaseVariable('b')
    assert BaseVariable('a')!=BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b'])!=BaseVariable('a', exclude=['c'])

# Unit tests for method __eq__ of class CommonVariable

# Generated at 2022-06-10 21:47:25.677822
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    class Test(object):
        def test(self):
            first = "first"
            second = {"second": "second"}
            third = ["third_1", "third_2", "third_3"]
            fourth = {"fourth_1": "fourth_1", "fourth_2": "fourth_2"}
            Test.test_stack = inspect.stack()
            return first, second, third, fourth

    variable_test = Test()
    variable_test.test()
    frame_test = variable_test.test_stack[0][0]
    frame_test.f_locals["variable_test"] = variable_test
    print(Attrs(source="variable_test").items(frame_test))
    print(Keys(source="variable_test").items(frame_test))

# Generated at 2022-06-10 21:47:30.866083
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    def test(in_slice, in_value, out_items):
        variable = Indices('x')[in_slice]
        assert variable.items(in_value) == out_items

    test(slice(0, 2, 1), 1, [])
    test(slice(0, 2, 1), range(3),
         [('x[0]', '0'), ('x[1]', '1')])

# Generated at 2022-06-10 21:47:38.080849
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    global frames
    frames=[]
    def testVariable(variable, value, normalize=False):
        frame = sys._getframe(1)
        frames.append((frame, variable, value, normalize))

    source = 'testVariable({}, {}, normalize={})'
    source = source.format(*repr(BaseVariable("Test").items.__code__))
    exec(compile(source, '<test_BaseVariable_items>', 'single'))
    from .utils import get_shortish_repr
    name = "testValues"
    strTest = "str"
    intTest = 0
    listTest = [0, 1]
    tupleTest = (0, 1)
    dictTest = {"a": 0, "b": 1}

    # Test with class BaseVariable

# Generated at 2022-06-10 21:47:44.706481
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = Keys("foo.bar")
    v2 = Keys("foo.bar")
    v3 = Keys("foo.bar.baz")
    assert v1 == v2
    assert not v1 == v3


_VARIABLE_CLASSES = {
    'attrs': Attrs,
    'keys': Keys,
    'indices': Indices,
    'explode': Exploding,
}



# Generated at 2022-06-10 21:47:56.276039
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class ConcreteVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ()
    assert ConcreteVariable('a').__eq__(ConcreteVariable('a'))
    assert not ConcreteVariable('a').__eq__(ConcreteVariable('b'))
    assert not ConcreteVariable('a').__eq__(ConcreteVariable('a', exclude='b'))
    assert not ConcreteVariable('a').__eq__(ConcreteVariable('b', exclude='a'))

# Generated at 2022-06-10 21:47:57.604712
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x', ('y', 'z'))


# Generated at 2022-06-10 21:48:08.893428
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pytest
    from .utils import hide_internal_attrs, remove_all_suffixes
    from .pycompat import PY3
    from .test_utils import minimize
    from . import pycompat

    def make_dict(**kwargs):
        return dict(kwargs) if PY3 else dict(pycompat.iteritems(kwargs))

    class DummyVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return ()

    @pytest.fixture(autouse=True)
    def run_around_tests(capfd):
        yield
        out, err = capfd.readouterr()
        assert not err


# Generated at 2022-06-10 21:48:14.868554
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 1. Test for True case
    var = BaseVariable('var')
    var_1 = BaseVariable('var')
    assert var == var_1

    # 2. Test for False case
    var_1 = BaseVariable('var', exclude=('a', 'b'))
    assert not (var == var_1)


# Generated at 2022-06-10 21:48:17.867453
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('b')
    assert Attrs('a') != Keys('a')
    assert Attrs('a') != 'a'


# Generated at 2022-06-10 21:48:28.176879
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    frame = None
    exclude = None
    source = 'a'
    var = BaseVariable(source, exclude)
    var_same = BaseVariable(source,exclude)
    var_diff1 = BaseVariable(source+'b',exclude)
    var_diff2 = BaseVariable(source,exclude+('a',))
    assert var == var_same
    assert not var != var_same
    assert var != var_diff1
    assert not var == var_diff1
    assert var != var_diff2
    assert not var == var_diff2

    assert not var == 'xyz'
    assert var != 'xyz'
    assert not var == 123
    assert var != 123


# Generated at 2022-06-10 21:48:35.685589
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('a', 'b')
    var3 = BaseVariable('a')
    var4 = BaseVariable('a', 'b')
    var4.__class__=Attrs
    var5 = BaseVariable('a', 'b')
    var5.__class__=Attrs
    var6 = Attrs('a', 'b')
    var7 = Attrs('a')
    var8 = Attrs('a', 'b')

    assert( var1==var2 and (var1==var3)==False and (var1==var4)==False and var4==var5 and (var4==var6)==False and (var6==var7)==False and var6==var8)


# Generated at 2022-06-10 21:48:44.911282
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('a','b')
    print(obj._slice)
    obj2 = obj[2:6]
    print(obj2._slice)
    assert isinstance(obj2, Indices) == True 
    obj2.__class__ == Indices
    obj2[1:3]
    print(obj2._slice) # expected result: slice(1, None, None)
    obj3 = obj[:]
    print(obj3._slice) # expected result: slice(None, None, None)
    obj4 = obj[2:]
    print(obj4._slice) # expected result: slice(2, None, None)
    obj5 = obj[::2]
    print(obj5._slice) # expected result: slice(None, None, 2)
    print(isinstance(obj[2:], Indices))

# Generated at 2022-06-10 21:48:48.055573
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import pytest
    a = BaseVariable('a')
    b = BaseVariable('b')
    assert a == a
    assert not (a == b)
    assert a != b
    assert not (a != a)

# Generated at 2022-06-10 21:48:52.294644
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert len(Indices('__name__', exclude=('im_self', 'im_func')) \
    .items(Indices.items)) == 12

test_BaseVariable_items()

# Generated at 2022-06-10 21:49:11.851999
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import utils
    import sys
    import os
    import inspect
    import re
    import tabulate
    from . import exceptions
    from . import config
    from . import debug
    from . import pycompat

    for item in [slice(1, 10, 2), slice(1, 10, 1),slice(10, 1, -1), slice(10, 1, 1), \
                 slice(1, 1, 1), slice(-1, -10, -2), slice(-1, -10, 2)]:
        Indices_instance = Indices('abc')

# Generated at 2022-06-10 21:49:17.229788
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # 1. test for different types
    # expected: False
    assert not BaseVariable('x') == Attrs('x')
    # 2. test for three variables
    # expected: True
    a_variable = BaseVariable('x')
    assert a_variable == BaseVariable('x')
    assert a_variable == BaseVariable('x', exclude=())
    assert a_variable == BaseVariable('x', exclude=('y', 'z'))

# Generated at 2022-06-10 21:49:23.035509
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    base = BaseVariable(".argv")
    assert base == base
    assert not (base == None)
    assert not (base == 0)
    assert not (base == "")
    assert not (base == [])
    assert not (base == {})
    assert not (base == Attrs())
    assert not (base == Indices())
    assert not (base == Keys())

# Generated at 2022-06-10 21:49:25.367767
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")
    assert BaseVariable("a") != BaseVariable("b")



# Generated at 2022-06-10 21:49:29.946239
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var = BaseVariable("frame", "f_locals")
    var2 = BaseVariable("frame", "f_locals")
    assert var == var2

    var = Attrs("frame", "f_locals")
    var2 = Attrs("frame", "f_locals")
    assert var == var2



# Generated at 2022-06-10 21:49:33.074761
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var_1 = BaseVariable('a')
    var_2 = BaseVariable('a')
    assert var_1 == var_2

    var_1 = BaseVariable('a')
    var_2 = BaseVariable('b')
    assert var_1 != var_2


# Generated at 2022-06-10 21:49:43.230220
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a').__eq__(Attrs('a')) # test value
    assert Attrs('a').__eq__(Attrs('b')) # test value
    assert Attrs('a').__eq__(Attrs('a', exclude=['b'])) # test value
    assert Attrs('a', exclude=['b']).__eq__(Attrs('a')) # test value
    assert Attrs('a', exclude=['b']).__eq__(Attrs('a', exclude=['b'])) # test value
    assert Attrs('a', exclude=['b']).__eq__(Attrs('a', exclude=['c'])) # test value
    assert Attrs('a', exclude=['b']).__eq__(Attrs('b', exclude=['b'])) # test value

# Generated at 2022-06-10 21:49:49.237364
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a.b') == BaseVariable('a.b')
    assert BaseVariable('a.b') != BaseVariable('a', exclude=('b'))
    assert BaseVariable('a', exclude=('b')) != BaseVariable('a')
    assert BaseVariable('a', exclude=('b')) == BaseVariable('a', exclude=('b'))

# Generated at 2022-06-10 21:49:52.996887
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize a class
    main_value = ['a', 'b', 'c']
    foobar=BaseVariable('main_value', 'exclude')
    # Test the case the result does not raise an exception
    assert foobar.items(frame=None, normalize=False)==[('main_value', "['a', 'b', 'c']")]
    # Test the case the result raises an exception
    del main_value
    assert foobar.items(frame=None, normalize=False)==()


# Generated at 2022-06-10 21:49:57.533842
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Create a sample frame
    def sample_func():
        return 3
    frame = sample_func.__code__.co_firstlineno - 1
    frame = inspect.currentframe().f_back.f_back
    var = BaseVariable(source='frame')
    items_list = var.items(frame)
    assert items_list, 'items list is empty'

# Generated at 2022-06-10 21:50:14.432210
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    assert x[::2] == Indices('x', exclude=())
    assert x[::2]._slice == slice(None, None, 2)

if __name__ == '__main__':
    pytest.main(__file__)

# Generated at 2022-06-10 21:50:16.908862
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('a')
    assert ind[1:]._slice == slice(1, None, None)

# Generated at 2022-06-10 21:50:27.679730
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class DummyVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass

    type_of_object = (type(1), type('1'))
    d = dict()
    d[0] = type_of_object[0]
    d[1] = type_of_object[1]
    list_of_object = [type_of_object[0], type_of_object[1]]
    set_of_object = set(type_of_object)
    variable = DummyVariable(source='d')
    variable.items(d, normalize=True)
    variable = DummyVariable(source='list_of_object')
    variable.items(list_of_object, normalize=True)
    variable = DummyVariable(source='set_of_object')


# Generated at 2022-06-10 21:50:29.211508
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[1:] == Indices('x[1:]')

# Generated at 2022-06-10 21:50:32.008454
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    a_ = a[1:3]
    assert a_.source == "a"
    assert a_._slice == slice(1, 3)



# Generated at 2022-06-10 21:50:43.926883
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')

    # test case: normal case
    var_slice = var[slice(0, 5)]
    result = [('.1', '2'), ('.2', '3'), ('.3', '4'), ('.4', '5'), ('.5', '6')]
    assert var_slice.items({'var': [1, 2, 3, 4, 5, 6]}) == result

    # test case: slice start < 0
    var_slice = var[slice(-2, 3)]
    result = [('.0', '1'), ('.1', '2'), ('.2', '3')]
    assert var_slice.items({'var': [1, 2, 3, 4, 5, 6]}) == result

    # test case: slice stop > length of list

# Generated at 2022-06-10 21:50:48.347702
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_source=Indices('a', 'b')
    assert test_source[1] == Indices('a', 'b')
    assert test_source[1:2] == Indices('a', 'b')


# Generated at 2022-06-10 21:50:49.435344
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    BaseVariable().items()


# Generated at 2022-06-10 21:51:01.912555
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def get_code(s):
        return compile(s, '<frame>', 'eval').co_code

    def test_variable(source, expected_source, expected_value, local_dict={}, global_dict={}):
        variable = BaseVariable(source)
        frame_dict = dict(local_dict, **global_dict)
        frame = type(
            'fake_frame',
            (object, ),
            {
                'f_locals': frame_dict,
                'f_globals': global_dict,
                'f_code': get_code(source),
            }
        )()
        result = variable.items(frame)
        assert result == (
            (expected_source,
             utils.get_shortish_repr(expected_value, normalize=False)),
        )

    test_

# Generated at 2022-06-10 21:51:03.892974
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bv = BaseVariable(source='a')
    assert bv.items(frame=None) == ()


# Generated at 2022-06-10 21:51:24.214257
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('x')
    b = a[:]
    assert a.source == b.source == 'x'
    assert a.exclude == b.exclude == ()
    assert a._slice == slice(None)
    assert b._slice == slice(0, len(b))
    assert a._format_key(5) == '[5]'
    assert b._format_key(5) == '[5]'
    c = a[-2:]
    assert c._slice == slice(-2, None)
    assert c._format_key(5) == '[5]'
    # for target in ('{}.x', '{}.y', '{}.z'):
    #     for index in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80

# Generated at 2022-06-10 21:51:28.329418
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('a')
    i1 = i[1:]
    assert isinstance(i1, Indices)
    assert i._slice == slice(None)
    assert i1._slice == slice(1,)

# Generated at 2022-06-10 21:51:33.237290
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('xx').__getitem__(slice(None))
    assert(var.source == 'xx')
    assert(var.unambiguous_source == 'xx')
    assert(var.code == compile('xx', '<variable>', 'eval'))

# Generated at 2022-06-10 21:51:36.438902
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .tests.test_vars import TestExploding
    assert TestExploding().items('self') == [('self', 'TestExploding()')]


# Generated at 2022-06-10 21:51:38.573666
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = "DICT"
    exclude = ("""attribute""")
    indices = Indices(source,exclude)
    assert indices == Indices(source,exclude)
    indices2 = indices[slice(1,8)]
    assert indices2 == Indices(source,exclude)[slice(1,8)]
    assert indices2._slice == slice(1,8)
    assert indices != Indices(source,exclude)[slice(1,8)]

# Generated at 2022-06-10 21:51:44.986526
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('args')
    assert indices[2:5] == Indices('args', slice=slice(2, 5))
    # Test: raise assert error
    try:
        indices[1,3]
    except AssertionError:
        print('AssertionError:')
        pass
    else:
        raise Exception('Not raised assert error.')



# Generated at 2022-06-10 21:51:47.719806
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')[:5]
    assert var.source == 'a'
    assert var._slice == slice(None, 5)

# Generated at 2022-06-10 21:51:54.520201
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = frame = inspect.currentframe()
    s = 'f("dd")'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'args'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items
    assert BaseVariable(s).items(frame) == []
    s = 'name'
    # items

# Generated at 2022-06-10 21:52:02.505077
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('$dns_cache')[2:5]
    assert a.source == '$dns_cache'
    assert a.exclude == ()
    assert a.code == compile('$dns_cache', '<variable>', 'eval')
    assert a.unambiguous_source == '$dns_cache'
    assert a._fingerprint == (Indices, '$dns_cache', ())
    assert a._slice == slice(2, 5, None)


# Generated at 2022-06-10 21:52:14.212828
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # set up a stub frame
    
    class Frame(object):
        def __init__(self):
            self.f_globals = {}
            self.f_locals = {}
            

    frame = Frame()
    frame.f_globals = {
        'foo': {
            'bar': {'baz': 'qux'},
            'quux': [1, 2, 'corge']
        },
        'grault': set([1, 2])
    }
    frame.f_locals = {
        'waldo': {
            'fred': 42,
            'plugh': [1, 2, 3],
            'thud': 'grunt'
        }
    }


# Generated at 2022-06-10 21:52:25.851421
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indVar = Indices('').__getitem__(slice(1,3))
    assert indVar._slice == slice(1,3)



# Generated at 2022-06-10 21:52:34.571002
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class MockFrame(object):
        def __init__(self, main_value):
            self.f_locals = {'pytest': main_value}

    class MockVariable(BaseVariable):
        def _items(self, main_value):
            return [(self.source, utils.get_shortish_repr(main_value))]

    class ExplodingVariable(BaseVariable):
        def _items(self, main_value):
            return [(self.source, repr(main_value))]

    class MockFrameException(MockFrame):
        f_locals = None

    # Exception in eval
    frame = MockFrameException()
    mock_variable = MockVariable('pytest')
    assert mock_variable.items(frame) == ()

    # Exception in _items
    mock_variable = MockVariable('pytest')
   

# Generated at 2022-06-10 21:52:37.298861
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = {'aaa': 'bbb', 'ccc': 'ddd'}
    a = x['aaa']
    e = None   # Expected result is stored in variable e.
    print('Expected result: {}'.format(e))
    print('Actual result:   {}'.format(BaseVariable('x').items(locals())))



# Generated at 2022-06-10 21:52:41.734039
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('a')
    variable_slice = variable[:3]
    assert variable_slice.__class__ == Indices
    assert variable_slice._slice == slice(None, 3)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:52:51.397906
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('foo')
    assert a[2:4] == Indices('foo', slice(2, 4))
    assert a[3:3] == Indices('foo', slice(3, 3))
    assert a[:-2] == Indices('foo', slice(None, -2))
    assert a[::2] == Indices('foo', slice(None, None, 2))
    assert a[::-1] == Indices('foo', slice(None, None, -1))
    with pytest.raises(AssertionError):
        a[0]
    with pytest.raises(AssertionError):
        a[0:2:3]
    with pytest.raises(AssertionError):
        a[0:3:-1]

# Generated at 2022-06-10 21:52:54.011037
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    var = BaseVariable('x')
    var.code = re.compile('x', re.I)
    assert_raises(NotImplementedError, var.items)

# Generated at 2022-06-10 21:52:56.936154
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_obj = Indices('1')
    print(test_obj[0:4])


if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:53:04.086834
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class MyVar(BaseVariable):
        def _items(self, key, normalize=False):
            return [(self.source, utils.get_shortish_repr(key, normalize=normalize))]

    myvar = MyVar('foo')
    result = dict(myvar.items(utils.generate_frame(), normalize=True))
    assert result == {'foo': '1'}, result


# Generated at 2022-06-10 21:53:13.970696
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('main_value')
    assert utils.same_dicts(obj._items('abcdefg'), [('main_value[0]', 'a'),
                                                    ('main_value[1]', 'b'),
                                                    ('main_value[2]', 'c'),
                                                    ('main_value[3]', 'd'),
                                                    ('main_value[4]', 'e'),
                                                    ('main_value[5]', 'f'),
                                                    ('main_value[6]', 'g')])
    sub_obj = obj.__getitem__(slice(4))
    assert sub_obj._slice == slice(4)

# Generated at 2022-06-10 21:53:16.479658
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("a")
    var[0:1]
    var[::1]
    var[0:10:2]

# Generated at 2022-06-10 21:53:37.517348
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Given
    indices_object = Indices('test_var')[1:3]

    # When
    expected_slice = slice(1,3)
    actual_slice = indices_object._slice

    # Then
    assert actual_slice == expected_slice

# Generated at 2022-06-10 21:53:49.756282
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # for Mapping
    # d = {'a':'b','c':'d'}
    d = {'a':'b','c':'d'}
    # variable = Keys('d')
    variable = Keys('d')
    # result = variable.items({'d':d})
    result = variable.items({'d':d})
    print(result)
    # result = variable.items({'d':d}, normalize=True)
    result = variable.items({'d':d}, normalize=True)
    print(result)
    # for Sequence
    # l = ['a','b','c']
    l = ['a','b','c']
    # variable = Indices('l')
    variable = Indices('l')
    # result = variable.items({'l':l})
    result = variable

# Generated at 2022-06-10 21:53:57.771595
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class A:
        def __init__(self):
            self.values = ['x1', 'x2', 'x3']
    a = A()
    v = Indices('names')[1:3]
    assert v._fingerprint == (Indices, 'names', ())
    assert v._slice == slice(1, 3)
    items = v._items(a.values)
    assert items == [
        ('names[1]', "'x2'"),
        ('names[2]', "'x3'")
    ]

# Generated at 2022-06-10 21:54:01.772023
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x')
    result = indices[1:]
    expected = Indices('x')
    expected._slice = slice(1, None)
    assert(result == expected)



# Generated at 2022-06-10 21:54:04.683683
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[1:] == Indices(source='a', exclude=()).__getitem__(slice(1, None, None))

# Generated at 2022-06-10 21:54:07.259284
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    attr = Indices('a')
    assert(str(attr[1:3]) == 'Indices(a[1:3], ())')



# Generated at 2022-06-10 21:54:11.624167
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Procedure
    dict_test_Indices_Indices_obj=Indices(0,0).__getitem__(slice(0,0,0))
    # Checkup
    assert(str(dict_test_Indices_Indices_obj)=="Indices(0,0)")

# Generated at 2022-06-10 21:54:15.896055
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a', exclude=('b',))
    assert a == a[2:4]
    assert a.exclude == a[2:4].exclude

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:54:23.772638
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils

    import sys

    class BaseVariable(utils.BaseVariable):
        def _create_code(self):
            self.code = compile(self.source, '<variable>', 'eval')

        def _items(self, main_value):
            return [(self.source, 'a')]

    class Test(object):
        def __init__(self):
            self.a = 'b'

        @property
        def c(self):
            return 'd'

    def test():
        a = 1
        b = 'c'
        c = Test()
        d = []

        test_frame = sys._getframe()
        return locals()

    locals_ = test()

    variable = BaseVariable('c')
    variable.items(sys._getframe())

    variable = BaseVariable('c.c')

# Generated at 2022-06-10 21:54:35.281298
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # This function tests the method items of the class BaseVariable.
    # First, we instantiate a test object t_obj of the class BaseVariable.
    t_obj = BaseVariable('test_obj')
    # We write test cases by calling the method items of the object t_obj.
    # We name each test case by giving it a number.
    # For each test case, the input is a list of variables,
    # and the output is a tuple of strings.
    test_case_1_inpt = [5]
    test_case_1_expct_outpt = ('test_obj', '5')
    print('Testing case 1')
    if test_case_1_expct_outpt == t_obj.items(test_case_1_inpt):
        print('Test passed')