

# Generated at 2022-06-10 21:45:16.810197
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    for i in range(len(Indices("x")[:])):
        assert i == Indices("x")[:][i]
        print("Iteration ", i, " successful")


# Generated at 2022-06-10 21:45:28.223308
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {}
    frame['var'] = 'value'
    frame['var_dict'] = {'var_dict_key': 'var_dict_value'}
    frame['var_list'] = ['var_list_value1', 'var_list_value2']
    frame['var_tuple'] = ('var_tuple_value1', 'var_tuple_value2')
    frame['var_class'] = TestClass()
    frame['var_exc'] = TestException('Test')
    frame['var_exc_value'] = 'Test'

    bv = BaseVariable('var')
    assert bv.items(frame) == ('var', 'value')

    bv = BaseVariable('var_dict')

# Generated at 2022-06-10 21:45:31.988185
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('arg')
    assert utils.get_shortish_repr(var.items) == '<function BaseVariable.items>'

test_BaseVariable_items()


# Generated at 2022-06-10 21:45:43.614755
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import itertools
    import traceback
    import inspect
    frames = inspect.getouterframes(traceback.extract_stack()[-1][0])
    # In current situation, the frame is:
    # 0: function test_BaseVariable_items
    # 1: function Items
    # 2: function test_Items
    # So, we need to take frame 2
    frame = inspect.getouterframes(traceback.extract_stack()[-1][0])[2][0]
    var_source = 'frame'
    var_exclude = 'f_locals'
    v = BaseVariable(var_source, var_exclude)
    # Iterate the result
    for k, v2 in v.items(frame):
        print((k, v2))


# Generated at 2022-06-10 21:45:44.288067
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    pass


# Generated at 2022-06-10 21:45:49.124566
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {
        'x': 1,
        'y': 'a',
        'z': ['a', 'b']
    }
    print(Attrs('x').items(frame))
    print(Attrs('z').items(frame))
    print(Indices('z').items(frame))
    print(Exploding('z').items(frame))

# Generated at 2022-06-10 21:45:57.148909
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Empty(BaseVariable):
        def _items(self, *args, **kwargs):
            return ()
    class NotEmpty(BaseVariable):
        def _items(self, *args, **kwargs):
            return ()

    assert Empty('a') == Empty('a')
    assert Empty('a') != NotEmpty('a')
    assert Empty('a') != Empty('b')
    assert Empty('a', 'b') == Empty('a', 'b')
    assert Empty('a', 'b') != Empty('a', 'c')
    assert Empty('a', 'b') != Empty('a')
    assert Empty('a') != Empty('a', 'b')

# Generated at 2022-06-10 21:46:03.099587
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("dct")
    assert var[0:5] == Indices("dct")[0:5]
    assert var[0:5] == Indices("dct", exclude=())[0:5]
    assert var[0:5] == Indices("dct", exclude="abc")[0:5]
    assert var[0:5] == Indices("dct", exclude=("abc",))[0:5]



# Generated at 2022-06-10 21:46:13.798953
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    name = '__test__'
    code = compile(name, '<variable>', 'eval')
    test_dict = {'__test__': 'test'}
    test_list = ['test']

    # test List
    l1 = List(name)
    assert l1.items(test_dict) == (('__test__', 'test'),)

    # test Dict
    d1 = Dict(name)
    assert d1.items(test_dict) == (('__test__', 'test'),)

    # test Keys
    k1 = Keys(name)
    assert k1.items(test_dict) == (('__test__', 'test'),)

    # test Attrs
    a1 = Attrs(name)

# Generated at 2022-06-10 21:46:22.215007
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x').__eq__(BaseVariable('x'))
    assert BaseVariable('x', exclude=['y']).__eq__(
        BaseVariable('x', exclude=['y']))
    assert not BaseVariable('x').__eq__(BaseVariable('x', exclude=['y']))
    assert not BaseVariable('x').__eq__(BaseVariable('y'))
    assert not BaseVariable('x').__eq__(Attrs('x'))


# Generated at 2022-06-10 21:46:29.566426
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a', exclude='ex') == BaseVariable('a', exclude='ex')


# Generated at 2022-06-10 21:46:38.398699
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # I can't test cases when __eq__ of self._fingerprint raises an exception, 
    # because I can't create explicit instances of classes (types)
    # But anyway, I suppose that those cases are very rare, so I leave them untested
    # For example, __eq__ of sets raises a TypeError if the two sets have different types
    # That's why I don't use utils.illegal_classes here
    # I only test cases when classes involved don't have __eq__ method
    # Otherwise, we will get recursion error when comparing variable and variable2
    classes = [object, int, str, tuple, dict, list, set, frozenset, object]

# Generated at 2022-06-10 21:46:43.914009
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('test')
    a2 = BaseVariable('test')
    b = BaseVariable('test', exclude='a')
    c = BaseVariable('test1')
    d = BaseVariable('test', exclude='b')
    assert a1 == a2
    assert a1 != b
    assert a1 != c
    assert b != d


# Generated at 2022-06-10 21:46:48.314804
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("test")
    other_type = type("test_class", (BaseVariable,), {})
    var2 = other_type("test")
    assert var1.__eq__(var2)



# Generated at 2022-06-10 21:46:55.346348
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("source", exclude="exclude")
    var2 = BaseVariable("source", exclude="exclude")
    var3 = BaseVariable("source1", exclude="exclude")
    var4 = BaseVariable("source", exclude="exclude1")

    var1_same = var1
    var2_same = var2

    assert var1 == var1_same
    assert var1 == var2
    assert var1 == var2_same
    assert var1 != var3
    assert var1 != var4

# Generated at 2022-06-10 21:47:02.541537
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
   # BaseVariable/BaseVariable
   a = BaseVariable("sources_a")
   b = BaseVariable("sources_a")
   assert a.__eq__(b)

   # BaseVariable/Attrs
   c = Attrs("sources_a")
   assert a.__eq__(c)

   # BaseVariable/Keys
   d = Keys("sources_a")
   assert a.__eq__(d)

   # BaseVariable/Indices
   e = Indices("sources_a")
   assert a.__eq__(e)

   # BaseVariable/Exploding
   f = Exploding("sources_a")
   assert a.__eq__(f)


# Generated at 2022-06-10 21:47:07.409512
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    test_obj = BaseVariable('test_source', ('test_exclude1', 'test_exclude2'))
    test_obj2 = BaseVariable('test_source', ('test_exclude1', 'test_exclude2'))
    assert(test_obj == test_obj2)
    test_obj3 = BaseVariable('test_source2', ('test_exclude1', 'test_exclude2'))
    assert(test_obj != test_obj3)
    test_obj4 = BaseVariable('test_source', ('test_exclude2', 'test_exclude1'))
    assert(test_obj == test_obj4)


# Generated at 2022-06-10 21:47:08.719295
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert list(BaseVariable("1", "2").items("3", "4")) == []

# Generated at 2022-06-10 21:47:13.512918
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = 'list(range(100))'
    v = Indices(source)
    frame = inspect.currentframe()
    frame.f_locals.update({
        'source': source,
        'v': v,
        'frame': frame,
    })
    print(v.items(frame))


# Generated at 2022-06-10 21:47:21.582001
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Setup:
    index_source = Indices('bar')
    index_sliced = Indices('bar')[2:7]
    index_sliced._slice = slice(2,7)

    # Exercise:
    index_sliced_2 = index_sliced[2:7]
    index_sliced_2._slice = slice(2,7)

    # Verify:
    assert index_sliced == index_sliced_2

# Generated at 2022-06-10 21:47:36.550442
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Arrange
    indices = Indices('main_value', tuple())
    slice_ = slice(1, 4, 2)

    # Act
    indices = indices[slice_]

    # Assert
    assert indices._slice == slice_, indices._slice

# Generated at 2022-06-10 21:47:48.348416
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable_foo(BaseVariable):
        def __init__(self):
            self.source = ""
            self.exclude = tuple()
            self.code = compile("", '<variable>', 'eval')
            self.unambiguous_source = ""

        @abc.abstractmethod
        def items(self):
            raise NotImplementedError

    var1 = BaseVariable("".join(["a", "b", "c"]))
    var2 = BaseVariable("abc")

    var3 = BaseVariable("".join(["a", "b", "c"]), "".join(["d", "e", "f"]))
    var4 = BaseVariable("abc", "def")

    var5 = BaseVariable("".join(["a", "b", "c"]), ("d", "e", "f"))
    var6

# Generated at 2022-06-10 21:47:55.229971
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    assert x[:1] == Indices('x', slice(None, 1))
    assert x[:-1] == Indices('x', slice(-1, None))
    assert x[1:] == Indices('x', slice(1, None))
    assert x[1:10] == Indices('x', slice(1, 10))
    assert x[2:6:2] == Indices('x', slice(2, 6, 2))

    assert x[:] == Indices('x')

# Generated at 2022-06-10 21:48:01.006437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable_child(BaseVariable):
        def __init__(self, *args, **kwargs):
            self.source += 'base'
            super(BaseVariable_child, self).__init__(*args, **kwargs)

    class BaseVariable_child2(BaseVariable):
        def __init__(self, *args, **kwargs):
            self.source2 = 'source2'
            self.source += 'base2'
            super(BaseVariable_child2, self).__init__(*args, **kwargs)

    class BaseVariable_child3(BaseVariable):
        def __init__(self, *args, **kwargs):
            self.source3 = 'source3'
            self.source += 'base3'
            super(BaseVariable_child3, self).__init__(*args, **kwargs)



# Generated at 2022-06-10 21:48:07.797461
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a.b') == BaseVariable('a.b')
    assert BaseVariable('a.b', exclude='c') == BaseVariable('a.b', exclude='c')

    assert BaseVariable('a.b') != BaseVariable('a.b', exclude='c')
    assert BaseVariable('a.b', exclude='c') != BaseVariable('a.b', exclude='x')
    assert BaseVariable('a.b', exclude='c') != BaseVariable('a.b.c')

# Generated at 2022-06-10 21:48:10.282249
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    docstring
    """
    base = BaseVariable
    assert base.items(base, frame=None) == ()

# Generated at 2022-06-10 21:48:13.697882
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import variables
    var = variables.Attrs('a')
    var2 = variables.Attrs('a')
    assert var == var2



# Generated at 2022-06-10 21:48:16.142480
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x', exclude=())
    result = var[0:]
    assert id(var) != id(result)
    assert result._fingerprint == (Indices, 'x', ())

# Generated at 2022-06-10 21:48:21.839873
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class fake_frame:
        def __init__(self, f_globals=None, f_locals=None):
            self.f_globals = f_globals
            self.f_locals = f_locals


    def test_common_variable(cls, source, exclude=(), f_globals=None, f_locals=None, normalize=False):
        cv = cls(source, exclude)
        frame = fake_frame(f_globals=f_globals, f_locals=f_locals)
        return list(cv.items(frame, normalize))


    class fake_cls:
        def __init__(self, testcase):
            self.testcase = testcase

# Generated at 2022-06-10 21:48:32.047916
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') == Attrs('a')
    assert BaseVariable('a', exclude='a') == Attrs('a', exclude='a')
    assert BaseVariable('a') == Keys('a')
    assert BaseVariable('a', exclude='a') == Keys('a', exclude='a')
    assert BaseVariable('a') == Indices('a')
    assert BaseVariable('a', exclude='a') == Indices('a', exclude='a')
    assert BaseVariable('a') == Exploding('a')
    assert BaseVariable('a', exclude='a') == Exploding('a', exclude='a')
    assert Attrs('a') == Attrs('a')
    assert Attrs('a', exclude='a') == Attrs('a', exclude='a')
    assert Attrs('a')

# Generated at 2022-06-10 21:49:04.668919
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import builtins
    frame = builtins.__dict__
    result = BaseVariable('globals()').items(frame)
    assert len(result) > 1
    assert result[0][0] == 'globals()'
    assert result[1][0] == 'globals().__dict__'
    assert result[2][0] == 'globals().__class__'
    result = BaseVariable('globals().__dict__').items(frame)
    assert len(result) > 1
    assert result[0][0] == 'globals().__dict__'
    assert result[1][0] == 'globals().__dict__.__builtins__'
    assert result[2][0] == 'globals().__dict__.__cached__'

# Generated at 2022-06-10 21:49:15.113205
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import dummy_module
    import sys
    import inspect
    import builtins
    var_name = 'dummy_module'
    module_obj = dummy_module # search the name in global namespace of the module
    frame = inspect.currentframe()
    args, _, _, values = inspect.getargvalues(frame)
    result = {}
    for i in args:
        result[i] = values[i]
    locals().update(result)
    result = {}
    for i in builtins.__dict__.keys():
        if i.startswith('__') and i.endswith('__'):
            continue
        result[i] = eval(i)
    locals().update(result)
    builtins_obj = sys.modules['builtins']

# Generated at 2022-06-10 21:49:21.883118
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frames
    from . import proxies
    from . import config

    frame_proxy = proxies.FrameProxy(frames.Frame(
        f_globals={'x': 'value'},
        f_locals={'y': 'other value'},
        f_code=None,
    ))

    x = BaseVariable('x')
    y = BaseVariable('y')
    py_x_y = BaseVariable('py.x', ['y'])
    py_y = BaseVariable('py', ['y'])
    x_y = BaseVariable('x', ['y'])

    assert x.items(frame_proxy) == [('x', "'value'")]
    assert y.items(frame_proxy) == []

# Generated at 2022-06-10 21:49:25.358554
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var')
    var1 = var[2:4]
    var2 = var[2:4]
    assert isinstance(var1, Indices)
    assert isinstance(var2, Indices)
    assert var1 == var2

# Generated at 2022-06-10 21:49:27.210361
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (
        BaseVariable("foo") ==
        BaseVariable("foo")
    )


# Generated at 2022-06-10 21:49:30.483000
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x', exclude='y')[1:-1]
    assert indices.source == 'x'
    assert indices.exclude == 'y'
    assert indices._slice == slice(1, -1)


# Generated at 2022-06-10 21:49:38.392744
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # setup
    obj = BaseVariable("test")
    obj2 = BaseVariable("test2")
    obj3 = BaseVariable("test3")
    obj4 = BaseVariable("test")
    obj5 = BaseVariable("test2","test")
    # act and assert
    assert(obj == obj)
    assert(obj != obj2)
    assert(obj != obj3)
    assert(obj == obj4)
    assert(obj != obj5)
    assert(obj3 != obj5)
    assert(obj2 != obj5)



# Generated at 2022-06-10 21:49:45.576338
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from . import pycompat
    # [pytest] section of the pytest configuration file.
    # pytestmark = pytest.mark.skip("skipping test for method _getitem_ of class Indices")

    indices = Indices("x")
    indices1 = indices[0:2]
    assert isinstance(indices1, Indices), "_getitem_ of class Indicies does not work"
    assert indices1._slice == slice(0, 2)


# Generated at 2022-06-10 21:49:49.140768
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indice = Indices("a")
    indice_slice = indice[0:1]
    if indice_slice._slice.start != 0 or indice_slice._slice.stop != 1:
        raise Exception("test_Indices___getitem__: slice not correct")

# Generated at 2022-06-10 21:49:54.245638
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x', [])
    vs = v[:]
    assert v._slice == slice(None)
    assert vs._slice == slice(None)

    v = Indices('x', [])
    vs = v[0:1]
    assert v._slice == slice(None)
    assert vs._slice == slice(0, 1)

    v = Indices('x', [])
    vs = v[-1:]
    assert v._slice == slice(None)
    assert vs._slice == slice(-1, None)

    v = Indices('x', [])
    vs = v[::]
    assert v._slice == slice(None)
    assert vs._slice == slice(None)

    v = Indices('x', [])
    vs = v[::2]

# Generated at 2022-06-10 21:50:39.148838
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass

# Generated at 2022-06-10 21:50:48.273265
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class VarSub1(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def _items(self, key, normalize=False):
            return ()

    class VarSub2(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')

# Generated at 2022-06-10 21:50:51.458803
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a','b')
    b = BaseVariable('a','b')
    c = BaseVariable('a','b')
    assert a is not b
    assert a is not c
    assert a == b
    assert a == c
    assert b == c


# Generated at 2022-06-10 21:50:56.325287
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)
    assert var_slice._fingerprint == var._fingerprint
    assert var_slice._fingerprint != var[3:5]._fingerprint

# Generated at 2022-06-10 21:51:08.328435
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    assert var[:] == Indices('a')
    assert var[::-1]._slice==slice(None,None,-1)
    assert var[1:5]._slice==slice(1,5)
    assert var[3:5]._slice==slice(3,5)
    assert var[3:6:2]._slice==slice(3,6,2)
    assert var[6:3:-1]._slice==slice(6,3,-1)
    assert var[:]._slice==slice(None)
    assert var[::]._slice==slice(None, None)
    assert var[::2]._slice==slice(None,None,2)
    assert var[2:3]._slice==slice(2,3)

# Generated at 2022-06-10 21:51:15.435469
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices("param[0]", exclude=('x', 'z'))
    assert ind.source == "param[0]"
    assert ind.exclude == ('x', 'z')
    ind1 = ind.__getitem__(slice(None))
    assert ind1._slice == slice(None)
    ind2 = ind.__getitem__(slice(-3, 3, None))
    assert ind2._slice == slice(-3, 3, None)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print("Everything passed")

# Generated at 2022-06-10 21:51:25.783539
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    _source_ = '_source_'
    _exclude_ = ('_exclude_',)
    _code_ = compile(_source_, '<variable>', 'eval')

    object_ = BaseVariable(_source_)
    assert object_.source == _source_
    assert object_.exclude == _exclude_
    assert object_.code == _code_
    assert object_.unambiguous_source == _source_

    another_object = BaseVariable(_source_)
    assert object_ == another_object
    assert hash(object_) == hash(another_object)

    another_object.source = 'another_source'
    assert object_ != another_object
    assert hash(object_) != hash(another_object)

    another_object.source = _source_
    assert object_ == another_object

# Generated at 2022-06-10 21:51:30.578585
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("var1.source")
    var2 = BaseVariable("var2.source")
    print("test_BaseVariable___eq__:", var1 == var2)
    print("test_BaseVariable___eq__:", var1 == var1)

test_BaseVariable___eq__()

# Generated at 2022-06-10 21:51:41.266783
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(source='self', exclude=['exclude']) == BaseVariable(source='self', exclude=['exclude'])
    assert BaseVariable(source='self', exclude=['exclude']) != BaseVariable(source='self', exclude=['exclude', 'exclude1'])
    assert BaseVariable(source='self', exclude=['exclude']) != BaseVariable(source='self1', exclude=['exclude'])
    assert BaseVariable(source='self', exclude=['exclude']) != CommonVariable(source='self', exclude=['exclude'])
    assert BaseVariable(source='self', exclude=['exclude']) != Keys(source='self', exclude=['exclude'])


# Generated at 2022-06-10 21:51:46.051385
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a', exclude='b')
    assert(v1 == v2)
    v3 = BaseVariable('b', exclude='b')
    assert(v1 != v3)

test_BaseVariable___eq__()

# Generated at 2022-06-10 21:53:21.034379
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('i')[10:100] == Indices('i', ())[10:100]
    assert Indices('i')[10:100] == Indices('i', '')[10:100]
    assert Indices('i')[10:100] == Indices('i', ())._slice == slice(10, 100)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:53:33.305735
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for class Attrs
    def test_source_of_class_Attrs(source,expected_result):
        test_base = Attrs(source)
        assert test_base.items(test_base.code.co_consts[2]) == expected_result

    class sample_class:
        def __init__(self,i):
            self.i = i
            self.j = i + 1

    sample_list_of_instance = [sample_class(i) for i in range(5)]

    sample_list_of_instance[2].k = sample_list_of_instance
    sample_frame = sample_list_of_instance[2].k

    test_source_of_class_Attrs('i',[('i', '0')])

# Generated at 2022-06-10 21:53:41.244328
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("", "") == BaseVariable("", "")
    assert BaseVariable("", "") == BaseVariable("", ())
    assert BaseVariable("", "") == BaseVariable("", ('',))
    assert BaseVariable("", "") == BaseVariable("", ('', ()))
    assert BaseVariable("", "") == BaseVariable("", (('',),))
    assert BaseVariable("", "") == BaseVariable("", ((('',),)))
    assert not (BaseVariable("", "") != BaseVariable("", ""))

    assert BaseVariable("a", "b") == BaseVariable("a", "b")
    assert BaseVariable("a", "b") == BaseVariable("a", ("b",))
    assert BaseVariable("a", "b") == BaseVariable("a", ((("b",),)))

# Generated at 2022-06-10 21:53:47.172300
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('Unit test for method __eq__ of class BaseVariable')

    import types

    a = Attrs('a')
    b = Attrs('a')
    print('Test 1')
    assert a == b

    c = Attrs('b')
    print('Test 2')
    assert a != c

    d = Keys('a')
    print('Test 3')
    assert a != d

    e = Indices('a')
    print('Test 4')
    assert a != e

    f = Exploding('a')
    print('Test 5')
    assert a != f

    g = BaseVariable('a')
    print('Test 6')
    assert a != g

    h = 123
    print('Test 7')
    assert a != h


# Generated at 2022-06-10 21:53:52.073720
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = {'a': 1, 'b': 2}
    s = BaseVariable('d', exclude=('a',))
    result = list(s.items(d))
    expected = [('d', '{\'a\': 1, \'b\': 2}')]
    assert result == expected

# Generated at 2022-06-10 21:53:59.917911
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    assert (BaseVariable('foo').__eq__(BaseVariable('foo'))) == True
    assert (BaseVariable('foo').__eq__(BaseVariable('bar'))) == False

    assert (BaseVariable('foo', 'bar').__eq__(BaseVariable('foo', 'bar'))) == True
    assert (BaseVariable('foo', 'bar').__eq__(BaseVariable('foo', 'baz'))) == False
    assert (BaseVariable('foo', 'bar').__eq__(BaseVariable('foo'))) == False
    assert (BaseVariable('foo').__eq__(BaseVariable('foo', 'bar'))) == False


# Generated at 2022-06-10 21:54:08.492180
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    out = Indices('request.data', 'request.FILES').items('xxx')
    print(out)
    out = Keys('request.data', 'request.FILES').items('xxx')
    print(out)
    out = Attrs('request.data', 'request.FILES').items('xxx')
    print(out)
    out = Exploding('request.data', 'request.FILES').items('xxx')
    print(out)
    
# Unit test
if __name__ == "__main__":
    test_BaseVariable_items()

# Generated at 2022-06-10 21:54:14.548718
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('0', 'bar')
    indices_slice = indices[1:3]

    assert indices_slice._slice == slice(1,3)
    assert indices_slice.source == '0'
    assert indices_slice.exclude == ('bar',)
    assert indices_slice.unambiguous_source == '0'
    assert indices_slice.code == compile('0', '<variable>', 'eval')

# Generated at 2022-06-10 21:54:19.604371
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a', exclude=['a'])
    b = BaseVariable('a', exclude=('a',))
    c = BaseVariable('a', exclude=())
    d = BaseVariable('b', exclude=())
    assert (a == b) is True
    assert (a == c) is True
    assert (a == d) is False


# Generated at 2022-06-10 21:54:25.748568
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # __init__()
    variable = BaseVariable("a.b")
    assert variable.source == "a.b"
    assert variable.code == compile("a.b", '<variable>', 'eval')
    assert variable.unambiguous_source == "a.b"
    # items()
    frame = {'a': {'b': 3}}
    assert variable.items(frame) == [('a.b', '3')]
    frame = {'a': {'b': "ab"}}
    assert variable.items(frame) == [('a.b', "'ab'")]
    frame = {'a': "ab"}
    assert variable.items(frame) == [('a.b', "'ab'")]
    # _items()