

# Generated at 2022-06-10 21:45:19.011588
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print(Indices('a').__getitem__(slice(2)))

    #output:
    #  a[0], a[1]


# Generated at 2022-06-10 21:45:32.401733
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class A:
        attr1 = 12
        _attr2 = 13
        def __init__(self):
            self.attr3 = 14

        def __repr__(self):
            return '<A>'

    assert BaseVariable('attr1').items(A.__dict__) == [('attr1', '12')]
    assert BaseVariable('x').items(A.__dict__) == []
    assert BaseVariable('a.attr1', exclude=('attr1',)).items(A.__dict__) == []
    assert BaseVariable('a.attr1', exclude=('attr2',)).items(A.__dict__) == [
        ('a.attr1', '12')]

    a = A()

# Generated at 2022-06-10 21:45:39.593346
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys

    class Test():
        x = 0
        def __init__(self):
            pass
    test = Test()
    v = BaseVariable('test')
    expected = [
        ('test', utils.get_shortish_repr(test))
    ]
    actual = v.items(sys._getframe())
    if actual != expected:
        raise Exception('method items of class BaseVariable does not operate correctly')


# Generated at 2022-06-10 21:45:45.428602
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("a")
    var1 = var[:]
    var2 = var[1:]
    var3 = var[1:4]
    assert var.__dict__['_slice'] == slice(None)
    assert var1.__dict__['_slice'] == slice(None)
    assert var2.__dict__['_slice'] == slice(1, None)
    assert var3.__dict__['_slice'] == slice(1, 4)


# Generated at 2022-06-10 21:45:53.456892
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    sys.path.append('..')
    from prettify import variables,utils
    import inspect
    import io
    import io, sys
    old_stdout = sys.stdout
    result = io.StringIO()
    sys.stdout = result
    foo = variables.BaseVariable('foo')
    print(foo.items('foo'))
    sys.stdout = old_stdout
    result_string = result.getvalue()
    print(result_string)

# Generated at 2022-06-10 21:46:01.191266
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d = dict()
    c = dict()
    e = dict()
    keys = list()
    for i in range(1, 10):
        d.update({"key{}".format(i): "value{}".format(i)})
        c.update({"key{}".format(i): "value{}".format(i)})
        e.update({"key{}".format(i): "value{}".format(i)})
        keys.append("key{}".format(i))
    d.update({"key{}".format(0): 'value{}'.format(0)})

    v = Keys(source='d', exclude=['key1'])
    assert v._keys(d) == keys
    assert v._format_key(keys[0]) == '[key0]'
    assert v._

# Generated at 2022-06-10 21:46:06.061209
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x')[:]
    assert var._slice == slice(None)
    var = Indices('x')[3:5]
    assert var._slice == slice(3,5)
    var = Indices('x')[3:5:2]
    assert var._slice == slice(3,5,2)

# Generated at 2022-06-10 21:46:09.817115
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
	x1 = BaseVariable("y")
	print(x1)
	x2 = BaseVariable("y")
	print(x2)
	assert x1 == x2

########################################################################################################################

# Generated at 2022-06-10 21:46:14.676980
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def items():
        variable = BaseVariable()
        variable.items()
    utils.assertRaisesWithMessage(NotImplementedError, "Can't instantiate abstract class BaseVariable with abstract methods _items", items)


# Generated at 2022-06-10 21:46:25.626403
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.stack()[0][0]
    bv = BaseVariable(source='x', exclude=(1, 'b'))
    assert bv.items(frame) == [('x', '2')]
    frame.f_locals['x'] = {'a': 1, 'b': 1, 'c': {}}
    assert bv.items(frame) == [('x', "{'a': 1, 'b': 1, 'c': {...}}"),
                               ('x[c]', '{...}')]
    frame.f_locals['x'] = [{1, 2}, {'a': 1, 'b': 2}, 's']

# Generated at 2022-06-10 21:46:36.891764
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import variables
    test_variable1 = variables.BaseVariable(source='test_variable1', exclude=())
    test_variable2 = variables.BaseVariable(source='test_variable2', exclude=())
    test_variable3 = variables.BaseVariable(source='test_variable1', exclude=())
    print(test_variable1 == test_variable2) # False
    print(test_variable1 == test_variable3) # True


# Generated at 2022-06-10 21:46:48.831635
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Variable(BaseVariable):
        source = 'a'
        exclude = ()
        code = compile('a', '<variable>', 'eval')
        unambiguous_source = 'a'
        def _items(self, main_value, normalize=False):
            return None

    v1 = Variable('a')
    v2 = Variable('b')
    v3 = Variable('a')
    v4 = Variable('a', ())
    v5 = Variable('a', ('a', ))
    v6 = Variable('a', ('b', ))
    v7 = Variable('a')
    v8 = Variable('b')
    v9 = Variable('b')
    assert v1 == v1
    assert v1 == v3
    assert v2 == v2
    assert v2 == v9
    assert v1 != v2

# Generated at 2022-06-10 21:46:59.452554
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('a')
    ind1 = ind.__getitem__(slice(0,0))
    assert ind1._slice == slice(0,0)
    ind2 = ind.__getitem__(slice(0,5))
    assert ind2._slice == slice(0,5)
    ind3 = ind.__getitem__(slice(5,5))
    assert ind3._slice == slice(5,5)
    ind4 = ind.__getitem__(slice(5,10))
    assert ind4._slice == slice(5,10)
    ind5 = ind.__getitem__(slice(10,100))
    assert ind5._slice == slice(10,100)
    ind6 = ind.__getitem__(slice(100,1000))

# Generated at 2022-06-10 21:47:05.277292
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    class Obj:
        def __getitem__(self, item):
            return item
    obj = Obj()
    assert Indices('obj')[0].items(obj) == [('obj', '0')]
    assert Indices('obj')[1].items(obj) == [('obj', '1')]
    assert Indices('obj')[:1].items(obj) == [('obj', '0')]
    assert Indices('obj')[1:].items(obj) == [('obj', '1')]
    assert Indices('obj')[1::2].items(obj) == [('obj', '1'), ('obj', '3')]

(Attrs, Keys, Indices, Exploding) = utils.namespace(_LOCAL, vars())
del _LOCAL

# Generated at 2022-06-10 21:47:07.730125
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    inds = Indices('list')
    assert len(inds.__getitem__([1,2,3])._fingerprint) == 3

# Generated at 2022-06-10 21:47:16.398787
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert_that(BaseVariable('x').items(frame(x=1)) == [('x', 1)])
    assert_that(BaseVariable('x', exclude=('x')).items(frame(x=1)) == [])
    assert_that(BaseVariable('x.y', exclude=('y')).items(frame(x=dict(y=1))) == [('x', '{}')])
    assert_that(BaseVariable('x.y').items(frame(x=dict(y=1))) == [('x.y', 1)])
    assert_that(BaseVariable('x[0]').items(frame(x=[1])) == [('x[0]', 1)])
    assert_that(BaseVariable('x[0]', exclude=('x[0]')).items(frame(x=[1])) == [])

# Generated at 2022-06-10 21:47:28.952909
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from . import debug
    from inspect import currentframe
    from . import inspect

    def f():
        x = dict(a=1)
        y = dict(b=2)
        z = dict(c=3)

        def g():
            return 'hello'

        for k in [x, y, 10]:
            #print(k)
            pass

    f()

    with debug.NoExceptHook():
        debug.set_trace()

    frame = sys._getframe()

    source = 'k'
    variable = Keys(source)
    items = variable.items(frame)
    assert len(items) == 1
    assert items[0][0] == source
    assert items[0][1] == 'dict(a=1)'

    source = 'k.a'

# Generated at 2022-06-10 21:47:36.930564
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('test_Var1', exclude=['test_key'])
    var2 = BaseVariable('test_Var1', exclude=['test_key'])
    var3 = BaseVariable('test_Var2', exclude=['test_key'])
    var4 = BaseVariable('test_Var1', exclude=['test_key2'])
    var5 = BaseVariable('test_Var1', exclude=['test_key'], test_var=2)
    assert var1 == var1 and var1 == var2 and var1 != var3 and var1 != var4 and var1 != var5

# Generated at 2022-06-10 21:47:44.264349
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None # Fake frame for test
    variable = BaseVariable("a", "b")
    variable2 = BaseVariable("a", ["b", "c"])
    variable3 = BaseVariable("a")
    variable4 = BaseVariable("a", "b", "c")

    # Use case: variable
    assert variable.items(frame) == ()
    assert variable2.items(frame) == ()
    assert variable3.items(frame) == ()
    assert variable4.items(frame) == ()

# Generated at 2022-06-10 21:47:55.230675
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .variables import BaseVariable, CommonVariable
    from copy import deepcopy
    import unittest
    import doctest

# Generated at 2022-06-10 21:48:01.955175
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass


# Generated at 2022-06-10 21:48:05.227324
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    code = eval('{}.items'.format('sys'))
    print(code)
    return code

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:48:08.030413
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('request')
    var1 = var[5:10]
    var2 = Indices('request', slice(5, 10))
    assert var1 == var2

# Generated at 2022-06-10 21:48:18.133958
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import unittest
    import types
    import sys
    class TestBaseVariable(unittest.TestCase):
        def setUp(self):
            self.pwd = TypesVariable('pwd')
            self.argv = TypesVariable('argv')
            self.pi = TypesVariable('pi')
            self.x= StructuredVariable('x')
            self.y= StructuredVariable('y')
            self.z= StructuredVariable('z')

# Generated at 2022-06-10 21:48:22.537944
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    indices_sliced = indices[::2]

    assert indices is not indices_sliced
    assert indices._slice == slice(None)
    assert indices_sliced._slice == slice(None, None, 2)


# Generated at 2022-06-10 21:48:29.395419
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def get_BaseVariable_instance():
        class DefineBaseVariable(BaseVariable):
            def __init__(self, source, exclude=()):
                pass

            def items(self, frame, normalize=False):
                pass

            def __hash__(self):
                return 1

        return DefineBaseVariable
    v1 = get_BaseVariable_instance()('test')
    v2 = get_BaseVariable_instance()('test')
    assert v1 == v2

# Generated at 2022-06-10 21:48:30.655530
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = '1'
    exclude = '2'
    a = BaseVariable(source,exclude)
    b = BaseVariable(source,exclude)
    assert a.__eq__(b)


# Generated at 2022-06-10 21:48:36.696390
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', ('b',)) == BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', ('b',))



# Generated at 2022-06-10 21:48:41.911984
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x', exclude='y') == BaseVariable('x', exclude='y')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('y', exclude='x')

    if pycompat.PY2:
        assert BaseVariable('x') != 'not a BaseVariable'

# Generated at 2022-06-10 21:48:45.478147
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('test')
    assert isinstance(obj[1:3], Indices)

__all__ = ['test_Indices___getitem__', 'Indices', 'Exploding', 'Keys', 'Attrs', 'BaseVariable']

# Generated at 2022-06-10 21:48:58.576178
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('a').items({}) == [('a', 'None')]


# Generated at 2022-06-10 21:49:09.371413
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
	variable1 = BaseVariable('a')
	variable2 = BaseVariable('a')
	variable3 = BaseVariable('b')
	variable4 = BaseVariable('b')
	variable5 = Attrs('a', exclude=('a', 'b'))
	variable6 = Attrs('a', exclude=('a', 'b'))
	variable7 = Attrs('a')
	variable8 = Attrs('b', exclude=('a', 'b'))
	variable9 = Keys('a')
	variable10 = Keys('a')
	variable11 = Keys('b')
	variable12 = Keys('b')
	variable13 = Indices('a')
	variable14 = Indices('a')
	variable15 = Indices('b')
	variable16 = Indices('b')

# Generated at 2022-06-10 21:49:17.884340
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    global1 = BaseVariable('a')
    global2 = BaseVariable('b')
    exclude1 = BaseVariable('a', exclude='q')
    exclude2 = BaseVariable('a', exclude=['q'])
    exclude3 = BaseVariable('a', exclude=['q', 'w'])
    exclude4 = BaseVariable('a', exclude=('q', 'w'))
    exclude5 = BaseVariable('a', exclude=['q', 'w', 'e'])
    
    assert global1 == global2
    assert not global1 == exclude1
    assert exclude1 == exclude2
    assert exclude2 == exclude3
    assert exclude3 == exclude4
    assert not exclude1 == exclude5
    
    
test_BaseVariable___eq__()

# Generated at 2022-06-10 21:49:28.440265
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from sys import version_info
    g = globals()
    for f, (output, expected) in [
        (lambda x:x.foo.bar, ([('x.foo.bar', '<unknown>')], True)),
        (lambda x:x.foo[[1,2,3]], ([('x.foo[[1, 2, 3]]', '<unknown>')], True)),
        (lambda x:x.foo(), ([('x.foo()', '<unknown>')], True)),
        (lambda x:x.foo(x=x.bar())[1], ([('x.foo(x=x.bar())[1]', '<unknown>')], True)),
    ]:
        variables = [f.__code__.co_varnames[i] for i in range(f.__code__.co_argcount)]

# Generated at 2022-06-10 21:49:29.829709
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        pass

    a = A('a')
    c = A('a', exclude='b')

    assert a == a
    assert a != c


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-10 21:49:33.036143
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('v')
    assert (v[3:4])._slice == slice(3,4)
    assert (v[:4])._slice == slice(0,4)
    assert (v[4:])._slice == slice(4,None)

# Generated at 2022-06-10 21:49:42.348397
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import frame_vars

    frame_info = frame_vars.FrameInfo(frame_vars.get_frame())
    frame_info.vars = [
        frame_vars.Exploding('ex'),
        frame_vars.CommonVariable('a'),
        frame_vars.CommonVariable('b.c'),
        frame_vars.CommonVariable('d.e.f')
    ]
    print(frame_info.get_frame_info())
    # Output:
    """
    a = '1'
    ex = dict(x = '2', y = '3')
    ex.x = '2'
    ex.y = '3'
    b.c = '4'
    d.e.f = '5'
    """

# Generated at 2022-06-10 21:49:52.011274
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from . import pycompat

    # Test function
    def _test(a, b, exp):
        act = a == b
        assert exp == act, 'exp: {}, act: {}'.format(exp, act)

    # Test
    _test(Attrs('a'), Attrs('a'), True)
    _test(Attrs('a', ('x',)), Attrs('a', ('x',)), True)
    _test(Attrs('a'), Attrs('b'), False)
    _test(Attrs('a', ('x',)), Attrs('a', ('y',)), False)
    _test(Attrs('a', ('x',)), Attrs('a'), False)


# Generated at 2022-06-10 21:49:57.612207
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')
    var_ = Indices('a')[:]
    var__ = Indices('a')[1:]
    assert(var._slice == slice(None))
    assert(var_._slice == slice(None))
    assert(var__._slice == slice(1, None))


VARIABLES = {
    'attrs': Attrs,
    'keys': Keys,
    'indices': Indices,
    'explode': Exploding,
}

# Generated at 2022-06-10 21:50:07.564706
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('a') == Attrs('a')
    assert Attrs('b') != Attrs('a')
    assert Attrs('a', exclude='x') == Attrs('a', exclude='x')
    assert Attrs('a', exclude='x') != Attrs('a', exclude='y')
    assert Attrs('a', exclude=('x', )) != Attrs('a', exclude=('x', 'y'))
    assert Attrs('a', exclude=('x', )) == Attrs('a', exclude=('x', ))
    assert Attrs('a') != Attrs('a', exclude='x')
    assert Keys('a') == Keys('a')
    assert Keys('a') != Attrs('a')
    assert Indices('a') == Indices('a')
    assert Indices('a') != Keys('a')

# Generated at 2022-06-10 21:50:38.098699
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    foo = BaseVariable('foo')
    foo2 = BaseVariable('foo')
    bar = BaseVariable('foo')
    assert foo==foo2
    assert foo==bar
    assert foo2==bar

# Generated at 2022-06-10 21:50:39.051984
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    assert v[:] == Indices('x')[:]

# Generated at 2022-06-10 21:50:40.209759
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('variable')['x':'y']

# Generated at 2022-06-10 21:50:50.591212
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .test_utils import mock_class, mock_module
    from . import utils
    from . import pycompat
    from . import frameinfo
    frameinfo.get_traceback_frames = mock_class('get_traceback_frames')
    utils.get_shortish_repr = mock_class('get_shortish_repr')
    pycompat.exec_ = mock_class('exec_')
    d = {'get_traceback_frames': [frameinfo.FrameInfo('test_frame', '', '', '', '', '', '', '', '')],
         'get_shortish_repr': [('test_object', 'test_repr')], 'exec_': [frameinfo.FrameInfo('test_frame', '', '', '', '', '', '', '', '')]}
   

# Generated at 2022-06-10 21:50:54.434985
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('self')
    result = a[1:3]
    assert type(result) == Indices
    assert result._slice == slice(1, 3)
    

# Generated at 2022-06-10 21:51:06.653221
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def check_eq(first, second, should_be_eq):
        first_eq_second = first == second
        second_eq_first = second == first
        if should_be_eq and (first_eq_second is not True or second_eq_first is not True):
            raise Exception('{first} should be equal to {second}'.format(first=first, second=second))
        if should_be_eq is False and (first_eq_second is not False or second_eq_first is not False):
            raise Exception('{first} should not be equal to {second}'.format(first=first, second=second))

    # Testing BaseVariable
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    c = BaseVariable('a', 'c')

# Generated at 2022-06-10 21:51:11.724226
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('list')
    slice_var = var.__getitem__(slice(1, 5, 2))
    assert slice_var._fingerprint == (Indices, 'list', ())
    assert slice_var._slice == slice(1,5,2)

# Generated at 2022-06-10 21:51:15.856391
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('x')
    assert obj[::2]._slice == slice(None, None, 2)
    assert obj[:]._slice == slice(None)
    assert obj[1:-1]._slice == slice(1, -1, None)

# Generated at 2022-06-10 21:51:22.896994
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Foo(BaseVariable):
        def _items(self, main_value, normalize=False):
            ...

    v_foo = Foo("source","exclude")
    v_bar = Foo("source","exclude")
    v_another = Foo("source","exclude")
    assert hash(v_foo) == hash(v_bar)
    assert v_bar == v_foo
    assert v_foo != v_another
    assert not (v_foo == v_another)

# Generated at 2022-06-10 21:51:31.408401
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    """
        This function is used to unit test method __getitem__ of class Indices.
    """
    source = 'abc'
    cls = Indices(source)
    assert cls._slice == slice(None)

    cls = cls[1:]
    assert cls._slice == slice(1, None)
    assert cls != Indices(source)

    cls = cls[2:]
    assert cls._slice == slice(3, None)

# Generated at 2022-06-10 21:52:20.167974
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    items = Indices('x')[1:7].items(None, normalize=True)
    assert items == [
        ('x[1]', ''),
        ('x[2]', ''),
        ('x[3]', ''),
        ('x[4]', ''),
        ('x[5]', ''),
        ('x[6]', '')
    ]

test_Indices___getitem__()

# Generated at 2022-06-10 21:52:29.636093
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = [1,2,3]
    assert Indices('a')[:1].items(1, normalize=True) == [('a[0]', '1')]
    assert Indices('a')[:2].items(1, normalize=True) == [('a[0]', '1'), ('a[1]', '2')]
    assert Indices('a')[1:].items(1, normalize=True) == [('a[1]', '2'), ('a[2]', '3')]
    assert Indices('a')[1:2].items(1, normalize=True) == [('a[1]', '2')]

# Generated at 2022-06-10 21:52:33.057972
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable(source="a")
    variable_ = variable
    variable__ = BaseVariable(source="a")
    variable___ = BaseVariable(source="b")

    assert variable == variable
    assert variable == variable_
    assert variable == variable__
    assert variable != variable___



# Generated at 2022-06-10 21:52:40.657257
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    bv = Attrs('x')
    print(bv.items(None))
    k = Keys('x',exclude=1)
    print(k.items(None))
    i = Indices('x',exclude=1)
    print(i.items(None))
    e = Exploding('x',exclude=1)
    print(e.items(None))
if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:52:44.533405
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
	indice_var = Indices('a')
	indice_var_getitem_result = indice_var.__getitem__(slice(1,5))
	assert indice_var_getitem_result._slice == slice(1,5)



# Generated at 2022-06-10 21:52:47.694501
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    values = [
        'a', 'b', 'c'
    ]
    variable = Indices('variable')
    res = variable._items(values)
    assert len(res) == 3
    
    variable = Indices('variable')[2:]
    res = variable._items(values)
    assert len(res) == 2
    assert res[0][0] == 'variable[2]'

# Generated at 2022-06-10 21:52:54.453998
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Foo(BaseVariable):
        def _items(self, main_value, normalize=False): pass

    a = Foo('abc', exclude=['def'])
    b = Foo('abc', exclude=['def'])
    assert a == b

    c = Foo('abc', exclude=['def'])
    d = Foo('abc', exclude=('def',))
    assert c == d

    e = Foo('abc', exclude=['d'])
    assert a == e

    f = Foo('ab')
    g = Foo('abc', exclude=['def'])
    assert f != g

# Generated at 2022-06-10 21:53:01.410427
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable("i") == BaseVariable("i"))
    assert not (BaseVariable("i") == BaseVariable("j"))
    assert (BaseVariable("i", "i") == BaseVariable("i", "i"))
    assert not (BaseVariable("i", "i") == BaseVariable("i", "j"))
    assert (BaseVariable("i") == Keys("i"))
    assert not (BaseVariable("i") == Attrs("i"))


# Generated at 2022-06-10 21:53:12.201227
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = Keys("mf.dis.bas6")
    assert var.items(1) == [("mf.dis.bas6[0]", '0')]

# Generated at 2022-06-10 21:53:18.897838
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from sys import getrecursionlimit
    class MyVariable(BaseVariable):
        def __init__(self, foo, bar=None):
            self.foo = foo
            self.bar = getrecursionlimit() if bar is None else bar

        def _items(self, key, normalize=False):
            return []

        @property
        def _fingerprint(self):
            return (self.foo, self.bar)

    var1 = MyVariable('x')
    var2 = MyVariable('x')
    var3 = MyVariable('x', bar=getrecursionlimit()+1)
    var4 = MyVariable('y')

    assert var1 == var1
    assert var1 == var2
    assert var2 == var1

    assert var1 != var3
    assert var3 != var1

    assert var1 != var4


# Generated at 2022-06-10 21:54:08.006904
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print('\n***test__getitem__***\n') 
    item = slice(0, 6, 2)  # item: 0, 2, 4
    indices1 = Indices('request')[item]
    indices2 = Indices('request').__getitem__(item)
    print('indices1: {}, indices2: {}'.format(indices1, indices2))
    assert indices1 == indices2


# Generated at 2022-06-10 21:54:14.114196
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from collections import deque
    from . import utils
    from copy import deepcopy
    def test_Indices___getitem__():
        x = [1, 2, "a", "b"]
        ind = Indices('x')
        assert len(ind[1:].items(x)) == 3
        assert len(ind[2:].items(x)) == 2

    test_Indices___getitem__()

# Generated at 2022-06-10 21:54:20.169402
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    d = {1: 100, 2: 200, 3: 300}
    frame = sys._getframe()
    b = BaseVariable('d', exclude='__doc__')
    assert b.code.co_names == ('d',)
    assert b.items(frame) == [('d', '{1: 100, 2: 200, 3: 300}')]
    assert '__doc__' not in b.items(frame)[0][0]



# Generated at 2022-06-10 21:54:25.698346
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def assertTrue(a):
        assert a
    def assertFalse(a):
        assert not a
    # Equivalence relationship
    class C1():
        pass
    class C2():
        pass
    vara = BaseVariable(object(),['a','b'])
    varb = BaseVariable(object(),['a','b'])
    assertTrue(vara == varb)
    assertTrue(vara == vara)
    assertTrue(varb == varb)
    assertFalse(vara != varb)
    assertFalse(vara != vara)
    assertFalse(varb != varb)
    # Reflexivity
    assertTrue(vara == vara)
    assertTrue(varb == varb)
    assertFalse(vara != vara)
    assertFalse(varb != varb)
    #

# Generated at 2022-06-10 21:54:29.319874
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    obj = BaseVariable(source='a.b.c', exclude=())
    key = "foo"
    obj2 = BaseVariable(source=key, exclude=obj)
    assert obj == obj2


# Generated at 2022-06-10 21:54:39.696934
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("i")
    b = BaseVariable("i")
    c = BaseVariable("i", exclude=['j'])
    d = BaseVariable("i", exclude=['j'])
    e = BaseVariable("i", exclude=['k'])
    f = BaseVariable("j")
    g = BaseVariable("j", exclude=['i'])
    h = BaseVariable("j", exclude=['j'])
    i = BaseVariable("k")
    j = BaseVariable("k", exclude=['j'])
    k = BaseVariable("k", exclude=['k'])

    assert a == b
    assert c == d
    assert c != e
    assert c != f
    assert c != g
    assert c != h
    assert c != i
    assert c != j
    assert c != k

# Generated at 2022-06-10 21:54:45.862251
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('some_str')
    assert indices[2:] == Indices('some_str', exclude=())
    assert indices[:3] == Indices('some_str', exclude=())
    assert indices[2:3] == Indices('some_str', exclude=())
    assert indices[:] == Indices('some_str', exclude=())
    assert indices[0:] == Indices('some_str', exclude=())
    assert indices[:0] == Indices('some_str', exclude=())
    assert indices[0:0] == Indices('some_str', exclude=())

# Generated at 2022-06-10 21:54:56.516204
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Variable(BaseVariable):
        def __init__(self, exclude):
            self.source = 'test'
            self.exclude = exclude
            self.code = compile('self.source', '<variable>', 'eval')
            self.unambiguous_source = 'self.source'

        def _items(self, key, normalize=False):
            return []

    # Different type
    assert Variable([]) != 0

    # Different source
    assert Variable(['a']) != Variable(['b'])

    # Different exclude
    assert Variable(['a']) != Variable(['b'])

    # Equal
    assert Variable(['a']) == Variable(['a'])


# Generated at 2022-06-10 21:55:01.672305
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(source = 'a') == BaseVariable(source = 'a')
    assert BaseVariable(source = 'a') != BaseVariable(source = 'b')
    assert BaseVariable(source = 'a', exclude = ('a',)) == BaseVariable(source = 'a', exclude = ('a',))
    assert BaseVariable(source = 'a', exclude = ('a',)) != BaseVariable(source = 'a', exclude = ('b',))


# Generated at 2022-06-10 21:55:06.828979
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def assert_eq(first, second, expected):
        assert (first == second) == expected, '{} != {} is {}'.format(first, second, expected)

    assert_eq(BaseVariable('a', 'b'), BaseVariable('a', 'b'), True)
    assert_eq(BaseVariable('a', 'b'), BaseVariable('a', 'c'), False)
    assert_eq(BaseVariable('a', 'b'), BaseVariable('b', 'b'), False)
    assert_eq(BaseVariable('a', 'b'), object(), False)