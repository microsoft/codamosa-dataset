

# Generated at 2022-06-10 21:45:24.901396
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {}
    frame["x"] = object()
    frame["y"] = {}
    frame["y"]["a"] = 1
    frame["y"]["b"] = 2
    frame["y"]["c"] = 3
    frame["y"]["d"] = 4
    frame["y"]["e"] = 5
    frame["z"] = []
    frame["z"].append(1)
    frame["z"].append(2)
    frame["z"].append(3)
    frame["z"].append(4)
    frame["z"].append(5)

    # check items created by Attrs
    assert list(Attrs("x").items(frame)) == [("x", object())]

# Generated at 2022-06-10 21:45:30.100660
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    test1 = BaseVariable('x')
    x = {'a': 'b'}
    y = 3
    result1 = test1.items(x)
    assert result1 == [('x', '{}')]
    result2 = test1.items(y)
    assert result2 == [('x', '3')]

# Generated at 2022-06-10 21:45:37.120140
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('main_value')
    i_slice = i[0:]
    print(i_slice)
    print(i._slice)
    print(i_slice._slice)
    print(i[0:]._slice)
    print(id(i))
    print(id(i[0:]))
    assert i[0:] is i
    print(type(i[0:]))
    print(type(i[0:2]))
    assert i[0:2] is not i

# Generated at 2022-06-10 21:45:46.878587
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import io
    import sys
    result = io.StringIO()
    save_stdout = sys.stdout
    sys.stdout = result
    # excute the method on the example of class Attrs

    def test_Attrs_items():
        source = '(1) if (2) else (3)'
        exclude = (1, 'val')

        def get_globals():
            globals_ = globals()
            globals_['val'] = 1
            return globals_

        def get_locals():
            locals_ = locals()
            locals_['val'] = 1
            print(locals_)
            return locals_

        key = (1) if (2) else (3)
        main_value = (1) if (2) else (3)
        globals_ = get_globals()

# Generated at 2022-06-10 21:45:57.292587
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable1 = BaseVariable(source='source', exclude='exclude')
    variable2 = BaseVariable(source='source', exclude='exclude')
    variable3 = BaseVariable(source='source', exclude='exclude')
    variable4 = BaseVariable(source='source', exclude='exclude')
    variable5 = BaseVariable(source='source', exclude='exclude')
    variable6 = BaseVariable(source='source', exclude='exclude')
    variable7 = BaseVariable(source='source', exclude='exclude')
    variable8 = BaseVariable(source='source', exclude='exclude')
    variable9 = BaseVariable(source='source', exclude='exclude')
    variable10 = BaseVariable(source='source', exclude='exclude')
    variable11 = BaseVariable(source='source', exclude='exclude')
    assert variable1 is not variable2
    assert variable

# Generated at 2022-06-10 21:46:00.034005
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import ipdb; ipdb.set_trace()
    a = Indices('x')
    assert a._slice == slice(None)
    b = a[20:40]
    assert b._slice == slice(20, 40)
    assert a._slice == slice(None)

# Generated at 2022-06-10 21:46:08.768827
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Unit tests for method __eq__ of class BaseVariable
    """
    print()
    print(test_BaseVariable___eq__.__doc__)
    # We test on two instances of a subclass of BaseVariable
    # but we could test on two instances of class BaseVariable
    exp1 = Exploding('param1')
    exp2 = Exploding('param2')
    # we compare instances of the same class but with different parameters
    assert exp1 != exp2
    # we compare instances of the same class and with the same parameters
    assert exp1 == exp1
    # we compare instances of different classes
    assert exp1 != object()

# Generated at 2022-06-10 21:46:12.513090
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert len(Indices('d')['1:3'].items({4, 5, 6, 7})[0][1]) == len('(4, 5, 6, 7)')

# Generated at 2022-06-10 21:46:24.934135
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    cls_cnt = 0
    class DummyBaseVariable(BaseVariable):
        def __init__(self, source, exclude=()):
            global cls_cnt
            cls_cnt += 1
            BaseVariable.__init__(self, source, exclude=())
    a1 = DummyBaseVariable("p1")
    a2 = DummyBaseVariable("p1")
    a3 = DummyBaseVariable("p2")
    a4 = DummyBaseVariable("p2", ["exc1"])
    a5 = DummyBaseVariable("p2", ["exc1"])
    a6 = DummyBaseVariable("p2", ["exc2"])

    assert a1 == a2
    assert a2 == a1
    assert not a1 == a3
    assert not a3 == a1
    

# Generated at 2022-06-10 21:46:35.472132
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from . import TerminalRepr
    from . import utils
    from . import pycompat
    from . import frames

    frame = inspect.currentframe()
    variables = [
        BaseVariable('var_str', 'some_str'),
        # BaseVariable('var_int', 'some_int'),
        # BaseVariable('var_float', 'some_float'),
        BaseVariable('var_list', 'some_list'),
        BaseVariable('var_tuple', 'some_tuple'),
        BaseVariable('var_dict', 'some_dict'),
        BaseVariable('var_set', 'some_set'),
        BaseVariable('var_object', 'some_object'),
        BaseVariable('var_rps', 'some_rps')]

    # create source variables to test items methods
    locals = frame.f_locals

# Generated at 2022-06-10 21:46:48.603605
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import pycompat
    source = 'pycompat.PY2'
    exclude = ('PY2',)
    instance = BaseVariable(source, exclude)
    Frame = pycompat.PY2 and types.FrameType or types.SimpleNamespace
    frame = Frame()
    frame.f_locals = {}
    frame.f_globals = dict(pycompat=pycompat)
    result = instance.items(frame)
    assert result == [('pycompat.PY2', 'True')]

# Generated at 2022-06-10 21:46:53.733808
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('abc', exclude=['a', 'b'])
    variable = variable[1:3]
    # variable.source => 'abc'
    # variable._slice => slice(1, 3, None)
    # variable.exclude => ('a', 'b')
    assert variable._slice == slice(1,3,None)


# Generated at 2022-06-10 21:46:55.111073
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    vars = Indices("a")
    vars[0]



# Generated at 2022-06-10 21:46:58.656812
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class SubClass(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass

    variable1 = SubClass('a')
    variable2 = SubClass('a')
    assert variable1 == variable2



# Generated at 2022-06-10 21:47:04.999291
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable('foo')
    bv2 = BaseVariable('bar')
    assert bv1 != bv2

    bv1 = BaseVariable('foo', exclude=['a'])
    bv2 = BaseVariable('foo', exclude=['b'])
    assert bv1 != bv2

    bv1 = BaseVariable('foo', exclude=['a'])
    bv2 = BaseVariable('bar', exclude=['a'])
    assert bv1 != bv2

    bv1 = BaseVariable('foo', exclude=['a'])
    bv2 = BaseVariable('foo', exclude=['a', 'b'])
    assert bv1 != bv2

    bv1 = BaseVariable('foo', exclude=['a'])

# Generated at 2022-06-10 21:47:08.512313
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # given
    var = Indices('a')
    expected = Indices('a')
    expected._slice = slice(1,4)
    # when
    actual = var[1:4]
    # then
    assert actual == expected
    # then

# Generated at 2022-06-10 21:47:16.884026
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect, linecache, os, sys
    from .var import Keys, Attrs, Indices, Exploding

    def _find_line(filename, lineno):
        line = linecache.getline(filename, lineno).strip()
        if line.endswith(','):
            line = line[:-1]
        return line

    def _get_global_vars(filename, func_name):
        g = {}
        filename = os.path.abspath(filename)
        with open(filename, 'r') as f:
            exec(f.read(), g)
        func = g[func_name]
        print(func.__code__.co_varnames)
        print(func.__code__.co_consts)
        return g


# Generated at 2022-06-10 21:47:18.804068
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable("target") == BaseVariable("target")) == True


# Generated at 2022-06-10 21:47:23.080416
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Test(BaseVariable):
        def _items(self, key, normalize=False):
            pass
    a=Test('a','b')
    b=Test('a','b')
    print (a==b)

# Generated at 2022-06-10 21:47:33.073637
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    "Unit test for method __getitem__ of class Indices"
    foo = Indices('foo')
    bar = foo[:]
    res = foo._keys('hello')
    try:
        assert res == [0,1,2,3,4]
    except Exception as e:
        print('ERROR: unit test error! ' + str(e))
    res = bar._keys('hello')
    try:
        assert res == [0,1,2,3,4]
    except Exception as e:
        print('ERROR: unit test error! ' + str(e))
    foo = Indices('foo')
    bar = foo[:3]
    res = foo._keys('hello')

# Generated at 2022-06-10 21:47:50.027019
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from random import randint
    from . import pprint
    from . import pycompat
    from .utils import normalize

    def random_slice(highest):
        return slice(randint(0, highest - 1), randint(0, highest))

    ns = {
        'attrs': Attrs,
        'keys': Keys,
        'indices': Indices,
        'exploding': Exploding,
    }


# Generated at 2022-06-10 21:47:58.608210
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    g = BaseVariable('g', exclude=[])
    h = BaseVariable('h', exclude=[])
    i = BaseVariable('i', exclude=[])
    l = Attrs('l', exclude=[])
    m = Attrs('m', exclude=[])
    n = Attrs('n', exclude=[])
    o = BaseVariable('o', exclude=[1])
    p = BaseVariable('p', exclude=[1])
    q = BaseVariable('q', exclude=[1])
    x = BaseVariable('x', exclude=[1, '2'])
    y = BaseVariable('y', exclude=[1, '2'])
    z = BaseVariable('z', exclude=[1, '2'])
    assert g == g
    assert h == h
    assert i == i
    assert l == l
    assert m == m
    assert n == n
   

# Generated at 2022-06-10 21:48:12.025366
# Unit test for method __eq__ of class BaseVariable

# Generated at 2022-06-10 21:48:22.908555
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Attrs("a", ["__class__", "__dict__"])
    a_dict = a.items({'a': 'hello world'})
    assert (a_dict == [('a', "'hello world'"), ('a.__class__', "'str'")])

    a = Keys("a")
    a_dict = a.items({'a': {'b': 'hello world'}})
    assert (a_dict == [('a', "{'b': 'hello world'}"), ('a[b]', "'hello world'")])

    a = Indices("a")
    a_dict = a.items({'a': (1, 2)})
    assert (a_dict == [('a', "(1, 2)"), ('a[0]', '1'), ('a[1]', '2')])

    a

# Generated at 2022-06-10 21:48:32.861094
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('foo')
    var2 = BaseVariable('foo')
    result = var1 == var2
    expected = True
    assert result == expected

    var1 = BaseVariable('foo', exclude='bar')
    var2 = BaseVariable('foo', exclude='bar')
    result = var1 == var2
    expected = True
    assert result == expected

    var1 = BaseVariable('foo', exclude='bar')
    var2 = BaseVariable('foo', exclude='qux')
    result = var1 == var2
    expected = False
    assert result == expected

    var1 = BaseVariable('foo', exclude='bar')
    var2 = BaseVariable('foo', exclude=('bar',))
    result = var1 == var2
    expected = True
    assert result == expected

    result = var1 == 'foo'
    expected

# Generated at 2022-06-10 21:48:41.034816
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    all_variables = [Attrs('a'), Attrs('a'), Attrs('a', exclude=('b',)), Attrs('a'), Attrs('a', exclude=('b',))]
    assert all(variables[0] == variables[1] for variables in zip(all_variables, all_variables))
    assert not any(variables[0] == variables[1] for variables in zip(all_variables, reversed(all_variables)))
    assert not any(all_variables[0] == variable for variable in all_variables[2:])




# Generated at 2022-06-10 21:48:42.640333
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices(1)
    assert isinstance(ind[:], Indices)


# Generated at 2022-06-10 21:48:48.125100
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = 'abcd'
    v = Indices('v')
    a = v[1:3]
    assert a._slice == slice(1, 3)
    b = v[:]
    assert b._slice == slice(None)
    c = v[2:]
    assert c._slice == slice(2, None)
    d = v[:1]
    assert d._slice == slice(None, 1)

# Generated at 2022-06-10 21:48:54.442020
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('foo', exclude='bar')
    b = BaseVariable('foo', exclude='bar')
    assert a == b
    c = BaseVariable('foo', exclude='baz')
    assert a != c
    d = BaseVariable('bar', exclude='bar')
    assert a != d
    e = Attrs('foo', exclude='bar')
    assert a != e


# Generated at 2022-06-10 21:48:59.138795
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('var1', ['exclude0'])
    y = BaseVariable('var1', ['exclude0'])
    z = BaseVariable('var2', ['exclude0'])
    assert (x == y)
    assert (y == x)
    assert (x != z)
    assert (y != z)



# Generated at 2022-06-10 21:49:13.363077
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'Frame.f_code'
    exclude = 'co_filename'
    obj1 = BaseVariable(source=source, exclude=exclude)
    obj2 = BaseVariable(source=source, exclude=exclude)
    assert obj1 == obj2



# Generated at 2022-06-10 21:49:15.433869
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('foo').__getitem__(slice(0, 9)) == Indices('foo', slice=slice(0, 9))

# Generated at 2022-06-10 21:49:21.666482
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariable0(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    class BaseVariable1(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    class BaseVariable2(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    base_variable0 = BaseVariable0(None)
    base_variable1 = BaseVariable1(None)
    assert (base_variable0 == base_variable1) is False
    base_variable2 = BaseVariable2(None)
    assert (base_variable0 == base_variable2) is False
    assert (base_variable1 == base_variable2) is False



# Generated at 2022-06-10 21:49:25.182992
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != Attrs('a')
    assert BaseVariable('a') != object()



# Generated at 2022-06-10 21:49:28.668782
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    expected_result = True

    base_variable1 = BaseVariable('base_variable1')
    base_variable2 = BaseVariable('base_variable2')

    assert expected_result == (base_variable1 == base_variable2)



# Generated at 2022-06-10 21:49:36.570772
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = None
    a = 1
    b = 2
    c = 3
    d = 4
    e = 5
    f = 6
    aa = {'b': b, 'c': c, 'e': e}
    bb = [1, 2, 3]
    cc = (1, 2, 3)
    dd = [a, b, [aa, bb], cc]
    ee = {1: 1, 2: 2, 3: {4: 4}}
    ff = None
    gg = Attrs('ff')
    gg.items(frame) == [('ff', 'None')]
    hh = Keys('aa')

# Generated at 2022-06-10 21:49:47.285452
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(source='test_source', exclude='test_exclude') \
           == BaseVariable(source='test_source', exclude='test_exclude')
    assert BaseVariable(source='test_source', exclude='test_exclude') \
           != BaseVariable(source='test_source2', exclude='test_exclude')
    assert BaseVariable(source='test_source', exclude='test_exclude') \
           != BaseVariable(source='test_source', exclude='test_exclude2')
    assert BaseVariable(source='test_source', exclude='test_exclude') \
           != BaseVariable(source='test_source2', exclude='test_exclude2')
    assert BaseVariable(source='test_source', exclude='test_exclude') \
           != Attrs(source='test_source', exclude='test_exclude')


# Generated at 2022-06-10 21:49:49.328131
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('test')
    v_result = v[1:3]
    assert isinstance(v_result, Indices)
    assert v_result._fingerprint == v._fingerprint
    assert v_result._slice == slice(1, 3)

# Generated at 2022-06-10 21:49:52.011175
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test = Indices('y').__getitem__(slice(0, 1))
    assert isinstance(test, Indices)
    assert test._slice == slice(0, 1)

# Generated at 2022-06-10 21:49:52.949819
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('i')[2:4]



# Generated at 2022-06-10 21:50:10.157157
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    global getitem_flag
    getitem_flag = 0
    Indices('a').__getitem__(5)
    if getitem_flag == 1:
        print('Unit test for method __getitem__ of class Indices succeed')
    else:
        print('Unit test for method __getitem__ of class Indices fail')

# Generated at 2022-06-10 21:50:19.336081
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frame
    def func(*args, **kwargs):
        return args + tuple(kwargs.values())
    def mytestfunc(a, b, c=3, d=4):
        return func(a, b, c, d)

    frame = frame.Frame(mytestfunc, (1, 2), {'d': 42, 'b': 'foo'})
    v = BaseVariable('a')
    print(v.items(frame))
    assert v.items(frame) == (('a', '1'),)

    v = BaseVariable('b')
    print(v.items(frame))
    assert v.items(frame) == (('b', "'foo'"),)

    v = BaseVariable('c')
    print(v.items(frame))

# Generated at 2022-06-10 21:50:24.181538
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('f', exclude=['foo'])[1::2]
    res = indices.items({'f':[1,2,3,4,5]})
    assert res == [('f[1]', '2'), ('f[3]', '4')]

# Generated at 2022-06-10 21:50:35.105893
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('basevar')
    assert obj[:].__class__ is Indices
    assert obj[0:].__class__ is Indices
    obj = obj[0:1]
    assert obj[:].__class__ is Indices
    assert obj[:1].__class__ is Indices
    assert obj[:3].__class__ is Indices
    assert obj[::-1].__class__ is Indices
    assert obj[:0].__class__ is Indices
    assert obj[-10:].__class__ is Indices
    assert obj[-10:10].__class__ is Indices
    assert obj[-10:10:1].__class__ is Indices


# Generated at 2022-06-10 21:50:39.814162
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices("source", ())
    res = obj[:]
    assert isinstance(res, Indices)
    assert res._slice is slice(None)
    res = obj[1:2:1]
    assert isinstance(res, Indices)
    assert res._slice == slice(1, 2, 1)

# Generated at 2022-06-10 21:50:43.895673
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert not BaseVariable('x') == BaseVariable('y')
    assert BaseVariable('x') == BaseVariable('x', exclude=())
    assert not BaseVariable('x') == BaseVariable('x', exclude=('y',))
    assert not BaseVariable('x') == object()


# Generated at 2022-06-10 21:50:52.466053
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # first case - two equal BaseVariable objects
    a = BaseVariable('a')
    b = BaseVariable('a')
    assert(a == b)
    # second case - two not equal BaseVariable objects
    a = BaseVariable('a')
    b = BaseVariable('b')
    assert(a != b)
    # third case - two equal BaseVariable objects with different exclude
    a = BaseVariable('a', 'x')
    b = BaseVariable('a', 'x')
    assert(a == b)
    # fourth case - two not equal BaseVariable objects with different exclude
    a = BaseVariable('a', 'x')
    b = BaseVariable('a', 'y')
    assert(a != b)


# Generated at 2022-06-10 21:50:57.868888
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def create_frame():
        def f():
            x = 1
            y = {'a':[1,2,3]}
            z = [1,2,3]
            return 1
        frame = sys._getframe()
        while frame.f_code.co_name != 'f':
            frame = frame.f_back
        return frame

    frame = create_frame()
    result = Attrs('y',exclude=['a']).items(frame, True)
    assert result == [('y', '{...}'), ("y.keys", "['a']")]

    result = Keys('y',exclude=['a']).items(frame, True)
    assert result == [('y', '{...}'), ("y['a']", '[...]'), ("y['keys']", "['a']")]


# Generated at 2022-06-10 21:51:01.544451
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    result = indices[1:2]
    assert isinstance(result, Indices)
    assert result._slice == slice(1, 2)


# Generated at 2022-06-10 21:51:02.560169
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    pass



# Generated at 2022-06-10 21:51:26.640336
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x')
    assert ind['slice'] == ind['slice']

# Generated at 2022-06-10 21:51:39.913147
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    class TestVariable(BaseVariable):
        def __init__(self, *args, **kwargs):
            self.var_name = kwargs.pop('var_name')
            self.var_value = kwargs.pop('var_value')
            super(TestVariable, self).__init__(*args, **kwargs)
            
        def _items(self, main_value, normalize=False):
            return [(self.var_name, utils.get_shortish_repr(self.var_value, normalize=normalize))]
    
    test_var = TestVariable('sfdsf', var_name='var_name', var_value=123)
    test_var.code = compile('var_value', '<variable>', 'eval')
    # the following variables' names should be consistent with

# Generated at 2022-06-10 21:51:42.149198
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('variable')
    i = i[10:]
    assert i._slice == slice(10, None, None)

# Generated at 2022-06-10 21:51:48.994964
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x1 = Indices(u"a")
    x2 = Indices(u"a")
    x3 = x1[1:3]
    x4 = x1[1:3]
    assert x1 != x2
    assert x1 != x3
    assert x3 != x4
    assert x2 != x3
    assert x4 != x2
    assert x4 == x3


# Generated at 2022-06-10 21:51:53.738192
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        pass

    v1 = A(source='foo', exclude='bar')
    v2 = A(source='foo', exclude='bar')

    assert v1 == v2
    assert not (v1 != v2)

# Generated at 2022-06-10 21:51:57.272590
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices(...)[1:3]
    assert var._slice == slice(1, 3)
    assert var.__getitem__ == Indices.__getitem__

# Generated at 2022-06-10 21:52:10.234373
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    import re
    import pytest
    # Test on a sample function.
    def sample_func(a, b, c):
        return a + b + c
    sample_func_code = sample_func.__code__
    # Fake a frame.
    frame = type('frame', (object,), {'f_globals': globals(), 'f_locals': locals()})
    # Main test.
    def do_test(variable, expected):
        result = variable.items(frame)
        assert expected == result
    # Test variables.
    var_a = BaseVariable('a')
    var_a_expected = [('a', '1')]
    var_a_plus = BaseVariable('a + 1')

# Generated at 2022-06-10 21:52:15.152296
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    current_frame = inspect.currentframe()
    previous_frame = inspect.getouterframes(current_frame, 2)
    assert len(previous_frame) == 2, \
        "This test case must run in the same frame as the calling code"

    origin_current_frame = current_frame.f_locals['current_frame']
    current_frame.f_locals['current_frame'] = previous_frame[1][0]
    assert current_frame.f_locals['current_frame'] is previous_frame[1][0]


# Generated at 2022-06-10 21:52:16.882807
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var').__getitem__(slice(0, 5))
    assert var._slice == slice(0, 5)
    assert var.unambiguous_source == 'var'

# Generated at 2022-06-10 21:52:21.431388
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print('test_Indices___getitem__')
    # test 1
    indicies = Indices(source='a')
    print(list(indicies.items(None)))
    indicies = indicies[::-1]
    print(list(indicies.items(None)))
    print()


# Generated at 2022-06-10 21:53:10.760282
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # BaseVariable.__eq__ is only used for identity comparison so far.
    assert BaseVariable("v") == BaseVariable("v")
    # But it is assured that cls is checked as well.
    assert BaseVariable("v") != Attrs("v")
    # Constructors arguments are not considered
    assert BaseVariable("v", exclude=("attr1",)) == BaseVariable("v")
    assert BaseVariable("v") != BaseVariable("v", exclude=("attr1",))
    # Check the fingerprint function
    assert BaseVariable("v", exclude=("attr1",))._fingerprint == BaseVariable("v")._fingerprint

# Generated at 2022-06-10 21:53:20.405746
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    f_code = compile('None', '', 'exec')
    f_globals = {}
    f_locals = {}
    f_back = {}
    f_builtins = {}
    f_restricted = {}
    f_trace = None
    f_exc = None
    f_lasti = None
    f_lineno = None
    f_trace_lines = None
    f_trace_opcodes = None

# Generated at 2022-06-10 21:53:25.260275
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """Test __eq__ method of BaseVariable."""
    assert not BaseVariable('var', 'excl').__eq__('Argument is not an instance of BaseVariable.')
    assert BaseVariable('var', 'excl').__eq__(BaseVariable('var', 'excl')) == True



# Generated at 2022-06-10 21:53:27.777092
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices('x[:2]')[20:]._slice == slice(20, None)


# Generated at 2022-06-10 21:53:30.817836
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[:] == a
    assert a[1:] == Indices('a', exclude=())[1:]


# Generated at 2022-06-10 21:53:39.995810
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('spam')
    indices_ = indices[:]
    assert indices._slice == slice(None)
    assert indices_._slice == slice(None)
    assert indices == indices_
    indices_ = indices[1:]
    assert indices._slice == slice(None)
    assert indices_._slice == slice(1, None)
    assert indices != indices_
    indices_ = indices[:1]
    assert indices._slice == slice(None)
    assert indices_._slice == slice(0, 1)
    assert indices != indices_
    indices_ = indices[::]
    assert indices._slice == slice(None)
    assert indices_._slice == slice(None, None, None)
    assert indices == indices_
    indices_ = indices[::2]
    assert indices._slice == slice(None)
    assert indices_

# Generated at 2022-06-10 21:53:43.327324
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # First argument of eval must be a str or code object.
    source = "v"
    code = compile(source, '<variable>', 'eval')
    frame = {'v': ['A', 'B', 'C']}
    result = BaseVariable(source).items(frame)
    expected_result = [('v', 'list(3)')]
    assert result == expected_result


# Generated at 2022-06-10 21:53:55.395948
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import builtins
    from io import StringIO
    from . import util

    def my_eval(s):
        import ast
        return eval(ast.parse(s, mode='eval').body)

    def items(source):
        frame = sys._getframe().f_back
        vars = BaseVariable(source)
        for source, value in vars.items(frame):
            yield source, value

    # Capture standard output.
    old_stdout, sys.stdout = sys.stdout, StringIO()

    items('builtins')
    builtins_items = sys.stdout.getvalue()

    items('builtins.dir()')
    dir_items = sys.stdout.getvalue()

    # Restore standard output.
    sys.stdout = old_stdout


# Generated at 2022-06-10 21:53:57.221891
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('foo')
    result = indices[1:2]
    assert isinstance(result, Indices)

# Generated at 2022-06-10 21:54:00.186914
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable("x")
    another_variable = BaseVariable("x")
    assert variable == another_variable
