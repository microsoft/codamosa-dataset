

# Generated at 2022-06-10 21:45:16.677978
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
	assert Indices('a')[1:4]._slice == slice(1,4)

# Generated at 2022-06-10 21:45:25.701791
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    #Valid cases
    v1 = Indices('a')
    v1[1:2]
    v2 = Indices('a')
    v2[5:9]
    v3 = Indices('a')
    v3[:]

    #Invalid cases
    v4 = Indices('a')
    try:
        v4[1.2]
    except AssertionError:
        e=1
    try:
        v4['a']
    except AssertionError:
        e=1
    try:
        v4[1,2]
    except AssertionError:
        e=1

# Generated at 2022-06-10 21:45:36.891188
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert list(Indices('x')[:2]._items([1,2,3])) == [('x[0]',  '1'), ('x[1]', '2')]
    assert list(Indices('x')[1:]._items([1,2,3])) == [('x[1]', '2'), ('x[2]', '3')]
    assert list(Indices('x')[1:-1]._items([1,2,3])) == [('x[1]', '2')]
    assert list(Indices('x')[:]._items([1,2,3])) == [('x[0]', '1'), ('x[1]', '2'), ('x[2]', '3')]

# Generated at 2022-06-10 21:45:39.975459
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('x.y.z', 'a') != Attrs('z.y.x', 'a')


# Generated at 2022-06-10 21:45:47.955863
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestCaseBaseVariable(BaseVariable, object):
        def _items(self, main_value, normalize=False):
            return ()
    x = TestCaseBaseVariable('hogehoge')
    y = TestCaseBaseVariable('hogehoge')
    z = TestCaseBaseVariable('hogehoge')
    z2 = TestCaseBaseVariable('hogehoge', 'hogehoge')
    z3 = TestCaseBaseVariable('hogehoge2')
    z4 = TestCaseBaseVariable('hogehoge2', 'hogehoge')
    z5 = TestCaseBaseVariable('hogehoge2', 'hogehoge2')
    z6 = TestCaseBaseVariable('hogehoge2', ('hogehoge2'))

# Generated at 2022-06-10 21:45:55.549587
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != Exploding('a')
    assert BaseVariable('a') != 1
    assert BaseVariable('a') != object()
    assert BaseVariable('a') != type(None)
    assert BaseVariable('a') != BaseVariable


# Generated at 2022-06-10 21:46:04.581336
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = inspect.currentframe()

# Generated at 2022-06-10 21:46:10.462768
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices(source='foo')
    assert variable[1:4] is not variable
    assert isinstance(variable[1:4], Indices)
    assert variable[1:4].source == 'foo'
    assert variable[1:4].exclude == ()
    assert variable[1:4]._slice == slice(1,4)


# Generated at 2022-06-10 21:46:24.189653
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import array
    import random
    import unittest

    class Test(unittest.TestCase):
        def test_Indices___getitem__(self):
            a = array.array('i', [random.randrange(0, 100) for _ in range(10)])
            s = Indices('a')
            slice1 = slice(1, 3, 1)
            slice2 = slice(None)
            slice3 = slice(-1, -10, -2)
            p1 = s[slice1]
            p2 = s[slice2]
            p3 = s[slice3]
            item_list_1 = [(i, v) for i, v in p1.items(None)]
            item_list_2 = [(i, v) for i, v in p2.items(None)]
            item_list_

# Generated at 2022-06-10 21:46:34.839881
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert (Indices('x').items(utils.build_frame('x'), normalize=True) ==
    [('x', 'list_of_10'), ('x[0]', '0'), ('x[1]', '1'), ('x[2]', '2'), ('x[3]', '3'), ('x[4]', '4'), ('x[5]', '5'), ('x[6]', '6'), ('x[7]', '7'), ('x[8]', '8'), ('x[9]', '9')])


# Generated at 2022-06-10 21:46:51.275531
# Unit test for method items of class BaseVariable

# Generated at 2022-06-10 21:47:01.267165
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', ('x', 'y'))
    assert BaseVariable('a', ('x', 'y')) != BaseVariable('a', ('x', 'y', 'z'))

    assert Attrs('a') == Attrs('a')
    assert Attrs('a') != Attrs('a', ('x', 'y'))
    assert Attrs('a', ('x', 'y')) != Attrs('a', ('x', 'y', 'z'))

    assert Keys('a') == Keys('a')
    assert Keys('a') != Keys('a', ('x', 'y'))
    assert Keys('a', ('x', 'y')) != Keys('a', ('x', 'y', 'z'))

    assert Indices('a')

# Generated at 2022-06-10 21:47:06.856045
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("a")
    a = [0, 1, 2, 3, 4]
    indices[1:4].items({'a': a}) == [
        ("a[1]", '1'),
        ("a[2]", '2'),
        ("a[3]", '3')
    ]



# Generated at 2022-06-10 21:47:14.501550
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    empty_var = Attrs()
    other_var = Attrs('x')
    assert not(empty_var == other_var)

    assert not(Attrs('x') == other_var)
    assert Attrs('x') == Attrs('x')

    assert not(Keys('x') == other_var)
    assert Keys('x') == Keys('x')

    assert not(Indices('x') == other_var)
    assert Indices('x') == Indices('x')

    assert not(Exploding('x') == other_var)
    assert Exploding('x') == Exploding('x')

# Generated at 2022-06-10 21:47:19.224969
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable(source="a+b",exclude=1)
    frame = {"a":3,"b":2}
    print(v.items(frame))

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:47:26.065022
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a.b')[::1]._slice == slice(None, None, 1)
    assert Indices('a.b')[::2]._slice == slice(None, None, 2)
    assert Indices('a.b')[1:]._slice == slice(1, None)
    assert Indices('a.b')[1:3]._slice == slice(1, 3)

# Generated at 2022-06-10 21:47:31.179879
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Unit test for method __getitem__ of class Indices
    indices = Indices('foo')
    assert indices[:] is indices

    assert indices[1:2] is not indices
    assert indices[1:2] is not indexes
    assert indices[1:2]._slice == slice(1, 2)
    assert indices[1:2].source == 'foo'

test_Indices___getitem__()

# Generated at 2022-06-10 21:47:35.466223
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("v1", exclude=["e1"])
    var2 = BaseVariable("v1", exclude=["e1"])
    assert var1 == var2
    var3 = BaseVariable("v1", exclude=["e2"])
    assert not (var1 == var3)
    var4 = BaseVariable("v2", exclude=["e1"])
    assert not (var1 == var4)

# Generated at 2022-06-10 21:47:43.440960
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert not BaseVariable('b') == BaseVariable('a')
    assert not BaseVariable('a', ('a',)) == BaseVariable('a')
    assert not BaseVariable('a') == BaseVariable('a', ('a',))
    assert BaseVariable('a', ('a',)) == BaseVariable('a', ('a',))
    assert not BaseVariable('a', ('a',)) == BaseVariable('a', ('a', 'b'))
    assert BaseVariable('a') == Attrs('a')


# Generated at 2022-06-10 21:47:51.532865
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    c = BaseVariable('a')
    d = BaseVariable('a', exclude='b')
    e = BaseVariable('a', exclude='a')
    f = BaseVariable('a', exclude=('a', 'b'))
    print(a == b) # False
    print(a == c) # True
    print(a == d) # False
    print(a == e) # False
    print(a == f) # False



# Generated at 2022-06-10 21:48:07.982951
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    # set source
    source = 'inspect.getouterframes(inspect.currentframe())'
    # set exclude
    exclude = ('f_lasti', 'f_trace')
    # create BaseVariable
    bv = BaseVariable(source, exclude)
    # get items
    items = bv.items(inspect.currentframe())
    # assert
    assert len(items) == 2


# Generated at 2022-06-10 21:48:17.519864
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils

    class BaseVariable_items_test(BaseVariable):
        def __init__(self, source, exclude=()):
            super(BaseVariable_items_test, self).__init__(source, exclude)

        def _items(self, key, normalize=False):
            return self.source + key

        def _fingerprint(self):
            return [self.source, self.exclude]

    basevariable_items_test = BaseVariable_items_test('test')
    assert basevariable_items_test.items('test') == 'testtest'

    p = utils.FrameVarParams(None, None)
    assert basevariable_items_test.items(p) == 'testtest'



# Generated at 2022-06-10 21:48:23.833739
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable("1")
    bv2 = BaseVariable("1")
    assert bv1 == bv2
    bv3 = BaseVariable("1", "a")
    assert bv1 != bv3
    bv4 = BaseVariable("1", "b")
    assert bv3 != bv4
    bv5 = BaseVariable("1", "a")
    assert bv3 == bv5


# Generated at 2022-06-10 21:48:33.530463
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():

    from . import pycompat

    class IndexVariable(Indices):
        pass

    # Test for IndexVariable.__getitem__
    for i in [0, 1, -1]:
        var1 = IndexVariable('strict.Indices', exclude='__getitem__')
        var2 = var1[i:]

        assert isinstance(var2, IndexVariable)
        assert isinstance(var2._slice, slice)
        assert var2._slice.start == i
        assert var2._slice.stop is None
        assert var2._slice.step is None

    # Test for IndexVariable.__getitem__
    for i in [0, 1, -1]:
        var1 = IndexVariable('strict.Indices', exclude='__getitem__')
        var2 = var1[:i]


# Generated at 2022-06-10 21:48:43.092847
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import unittest
    class Tests(unittest.TestCase):
        def test_single_digit_slice(self):
            v = Indices('x')[2:7]
            self.assertEqual(v.source, 'x[2:7]')
            self.assertEqual(v._slice, slice(2, 7))
        def test_slice(self):
            v = Indices('x')[2:7:1]
            self.assertEqual(v.source, 'x[2:7:1]')
            self.assertEqual(v._slice, slice(2, 7, 1))
    unittest.main(verbosity=2)


# Generated at 2022-06-10 21:48:45.053966
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')
    v = v[0:3]
    assert v._slice == slice(0,3)

# Generated at 2022-06-10 21:48:53.049694
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('foo')
    assert var1 == var1
    var2 = BaseVariable('foo')
    assert var1 == var2
    assert not var1.__eq__('foo')
    var3 = BaseVariable('foo', exclude=['bar'])
    assert var1 != var3
    assert var2 != var3
    assert var2.__eq__(var1)
    assert var1.__eq__(var2)



# Generated at 2022-06-10 21:49:01.654556
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("print('hello world')")
    v2 = BaseVariable("print('hello world')")
    v3 = BaseVariable("print('hello world')", exclude="exclude")
    v4 = BaseVariable("print('hello world')", exclude="exclude")
    v5 = BaseVariable("print('hello world')", exclude="exclude1")
    v6 = BaseVariable("print('hello world')", exclude="exclude2")
    assert v1 == v2
    assert v3 == v4
    assert v1 != v3
    assert v3 != v5
    assert v3 != v6


# Generated at 2022-06-10 21:49:12.133298
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    code = compile('{1,2,3}', '<variable>', 'eval')
    for main_value in [eval(code), eval(code).items()]:
        for exclude in [[], (1,)]:
            for normalize in [False, True]:
                assert [('{1,2,3}', '{1,2,3}'),
                                           ('{1,2,3}[0]', '2'),
                                           ('{1,2,3}[1]', '1')] == \
                                                Indices('{1,2,3}', exclude).items(main_value, normalize)

# Generated at 2022-06-10 21:49:20.085203
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = utils.fake_frame(
        {'a': {'b': {'c': 0}}}
        )
    source = 'a[b]'
    key = Keys(source).items(frame)
    assert key == [('a[b]', '{...}'), ('a[b].c', '0')]
    attrs = Attrs(source).items(frame)
    assert attrs == [('a[b]', '{...}')]
    indices = Indices(source).items(frame)
    assert indices == [('a[b]', '{...}')]
    exploding = Exploding(source).items(frame)
    assert exploding == [('a[b]', '{...}'), ('a[b].c', '0')]


# Generated at 2022-06-10 21:49:40.962833
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')
    assert BaseVariable('a', exclude='b') != BaseVariable('a', exclude='c')
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) != BaseVariable('a', exclude=('c',))
    assert BaseVariable('a', exclude=('b', 'c')) == BaseVariable('a', exclude=('b', 'c'))
    assert BaseVariable('a', exclude=('b', 'c')) != BaseVariable('a', exclude=('c', 'd'))
    assert BaseVariable('a') != 'a'

# Generated at 2022-06-10 21:49:46.217816
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('arg')
    var2 = BaseVariable('arg', exclude=())
    assert var1 == var2

    var3 = BaseVariable('arg', exclude=())
    var4 = BaseVariable('arg', exclude=('request', ))
    assert var3 != var4


# Generated at 2022-06-10 21:49:48.279394
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a.get', exclude=())
    v2 = BaseVariable('a.get', exclude=())
    assert v1 == v2

# Generated at 2022-06-10 21:49:51.791343
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'x'
    assert BaseVariable(source) == BaseVariable(source)
    assert BaseVariable(source) != BaseVariable(source + '1')
    assert BaseVariable(source) != BaseVariable(source, exclude='y')



# Generated at 2022-06-10 21:49:59.555780
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import os
    import re

    frames = []
    for filename, line in utils.extract_frames(inspect.stack()):
        abs_filename = os.path.abspath(filename)
        if re.match('.*pudb[/\\\\]?'+re.escape(os.sep), abs_filename):
            continue
        frames.append((abs_filename, line))

    item = BaseVariable(frames[-1][0], exclude=('__file__',))
    items = item.items(None)
    assert len(items) == 1
    assert items[0][0] == '__file__' and items[0][1] == frames[-1][0]



# Generated at 2022-06-10 21:50:00.381651
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")

# Generated at 2022-06-10 21:50:06.652554
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("a.b.c",("x","y","z"))
    var2 = BaseVariable("a.b.c",("x","y","z"))
    assert var1 == var2
    var3 = BaseVariable("a.b.c",("x","y","z"))
    var4 = BaseVariable("a.b.c",("x","y"))
    assert var3 != var4

# Generated at 2022-06-10 21:50:11.472463
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    foo = BaseVariable('foo')
    bar = BaseVariable('bar')
    baz = BaseVariable('foo')
    assert (foo == bar) == False
    assert (foo != bar) == True
    assert (foo == baz) == True
    assert (foo != baz) == False



# Generated at 2022-06-10 21:50:20.079520
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable('a', exclude='b') == BaseVariable('a', exclude='b')) == True, 'The method __eq__ of class BaseVariable is not right'
    assert (BaseVariable('a', exclude='b') == BaseVariable('a', exclude='c')) == False, 'The method __eq__ of class BaseVariable is not right'
    assert (BaseVariable('a', exclude='b') == BaseVariable('b', exclude='c')) == False, 'The method __eq__ of class BaseVariable is not right'
    assert (BaseVariable('a', exclude='b') == BaseVariable('b', exclude='b')) == False, 'The method __eq__ of class BaseVariable is not right'
    assert (BaseVariable('a', exclude='b') == 'a') == False, 'The method __eq__ of class BaseVariable is not right'




# Generated at 2022-06-10 21:50:22.498708
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('self')[2:10]
    assert i._slice == slice(2, 10, None)

# Generated at 2022-06-10 21:50:49.651825
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    from .utils import bytes_to_int, get_shortish_repr

    class Test():
        pass

    var_test = Test()
    var_test.var1 = '12345'
    var_test.var2 = 67890
    var_test.var3 = ['var_test.var3.1', 'var_test.var3.2']

    frame = sys._getframe()
    frame.f_locals = {'var_test': var_test}


# Generated at 2022-06-10 21:51:02.102161
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .utils import get_shortish_repr
    from .pycompat import OrderedDict
    from .indices import Indices
    S = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    source = get_shortish_repr(S)

# Generated at 2022-06-10 21:51:08.205770
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    all_frame = inspect.currentframe()
    frame = all_frame.f_back
    locals = frame.f_locals
    keys = sys._getframe().f_code.co_names
    expected = [(k, repr(locals[k])) for k in keys]
    assert BaseVariable('locals').items(frame) == expected


# Generated at 2022-06-10 21:51:10.263308
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices("test_frame.f_locals").__getitem__(slice(1, 2))



# Generated at 2022-06-10 21:51:14.133440
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('request')
    b = a[1:2]
    assert a.source == 'request'
    assert b.source == 'request'
    assert a._slice == slice(None)
    assert b._slice == slice(1, 2)


# Generated at 2022-06-10 21:51:18.344758
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert not BaseVariable('a') == BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('b')



# Generated at 2022-06-10 21:51:27.181956
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('x').__eq__(Attrs('x')) is True
    assert Attrs('x').__eq__(Attrs('y')) is False
    assert Attrs('x').__eq__(Attrs('x', exclude=['y'])) is True
    assert Attrs('x').__eq__(Attrs('x', exclude=['y', 'z'])) is False
    assert Attrs('x', exclude=['y', 'z']).__eq__(Attrs('x', exclude=['y', 'z'])) is True
    assert Attrs('x', exclude=['y', 'z']).__eq__(Attrs('x', exclude=['y'])) is False
    assert Attrs('x', exclude=['y']).__eq__(Attrs('x', exclude=['y', 'z'])) is False
   

# Generated at 2022-06-10 21:51:36.471345
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # BaseVariable can only be subclassed, so we test it by calling its method.
    # It requires a frame for its source.
    source = 'hello'
    frame = {'hello': 'world'}
    assert BaseVariable(source).items(frame) == [(source, 'world')]
    assert BaseVariable(source, exclude='world').items(frame) == []
    assert BaseVariable(source, exclude='hello').items(frame) == [(source, 'world')]
    assert BaseVariable(source, exclude=('hello', 'world')).items(frame) == []

# Generated at 2022-06-10 21:51:41.266285
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Attrs('foo') == Attrs('foo')
    assert Attrs('foo', 'bar') == Attrs('foo', 'bar')
    assert Attrs('foo') != Attrs('bar')
    assert Attrs('foo') != Attrs('foo', 'bar')
    assert Attrs('foo') != 1

# Generated at 2022-06-10 21:51:42.742344
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable.__eq__(BaseVariable, BaseVariable)


# Generated at 2022-06-10 21:52:05.799037
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():

    indices = Indices('x', '')
    indices[1:2]
    if not hasattr(indices, '_slice'):
        raise AssertionError()

# Generated at 2022-06-10 21:52:11.331628
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = BaseVariable("test",exclude=("testex"))
    assert v.source == "test"
    assert v.exclude == ("testex",)
    assert v.code.co_name == "test"
    assert v.unambiguous_source == "test"
    #assert v.items("test") == "test"


# Generated at 2022-06-10 21:52:18.873275
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = {'a': {'b': 1}, 'c': 2}
    frame = {'x': x}
    assert (Keys('x', exclude='a').items(frame) ==
            [('x[a]', '{...}'), ('x[c]', '2')])
    assert (Keys('x').items(frame, normalize=True) ==
            [('x', '{...}'), ('x[a]', '{...}'), ('x[c]', '2')])

# Generated at 2022-06-10 21:52:30.006709
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import io
    import contextlib

    class StdOutWrapper:
        def __init__(self, stdout):
            self.stdout = stdout
            self._content = io.BytesIO()

        def __getattr__(self, attr):
            return getattr(self.stdout, attr)

        def write(self, value):
            self._content.write(value.encode())

    @contextlib.contextmanager
    def capture_stdout():
        sys.stdout = StdOutWrapper(sys.stdout)
        try:
            yield sys.stdout
        finally:
            sys.stdout = sys.stdout.stdout


# Generated at 2022-06-10 21:52:36.821527
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    assert BaseVariable('foo', exclude=('__dict__',)).items(None) == [('foo', '???')]
    assert BaseVariable('foo.bar').items(None) == []
    assert BaseVariable('foo.bar', exclude=('bar',)).items(None) == [('foo.bar', '???')]
    assert Keys('foo').items({'bar': 'baz'}) == \
                                            [('foo', repr({'bar': 'baz'})), ('foo[bar]', "'baz'")]
    assert Indices('foo').items(['bar', 'baz']) == \
                                            [('foo', repr(['bar', 'baz'])),('foo[0]','\'bar\''),('foo[1]','\'baz\'')]
    assert Attrs('foo').items(object())

# Generated at 2022-06-10 21:52:39.187992
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert str(Indices('x')[1:-1][1:-1]._slice) == 'slice(1, -2, None)'



# Generated at 2022-06-10 21:52:44.581238
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
	from datadiff.tools import diff
	from datadiff.tools.indices import Indices
	assert Indices('x')[:1] == Indices('x', slice(None, 1))
	assert diff({
		'a': Indices('x')[:1],
		'b': Indices('x', slice(None, 1))
	}) == ''

# Generated at 2022-06-10 21:52:49.737317
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = {'x': {}, 'y': {'a': 1}}
    assert BaseVariable(source='x').items(frame) == [('x', '{}')]
    assert BaseVariable(source='y').items(frame) == [('y', "{'a': 1}")]

    assert Attrs(source='x').items(frame) == [('x', '{}')]
    assert Keys(source='x').items(frame) == [('x', '{}')]
    assert Indices(source='x').items(frame) == [('x', '{}')]
    assert Exploding(source='x').items(frame) == [('x', '{}')]


# Generated at 2022-06-10 21:52:51.981139
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Tmp(BaseVariable):
        pass

    t = Tmp('a.b', exclude=['c'])
    assert t.items(None, normalize=False) == ()

# Generated at 2022-06-10 21:52:55.637865
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert(str(Indices('a')[1:3]) == '<Indices source=a>')
    assert(str(Indices('a')[1:]) == '<Indices source=a>')
    assert(str(Indices('a')[::-1]) == '<Indices source=a>')

# Generated at 2022-06-10 21:53:18.704887
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a[1]')[2:4] == Indices('a[1][2:4]')

# Generated at 2022-06-10 21:53:31.083262
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    def tester(slice, length, start, stop, step):
        indices = Indices("foo")
        indices = indices[slice]
        assert indices._slice.start == start
        assert indices._slice.stop == stop
        assert indices._slice.step == step
        keys = indices._keys("foo" * length)
    # 1. No step
    # 1.1. start == None, stop == None
    tester(slice(None, None), 5, None, None, None)
    # 1.2. start == None, stop == N
    tester(slice(None, 3), 5, None, 3, None)
    # 1.2. start == N, stop == None
    tester(slice(2), 5, 2, None, None)
    # 1.3. start == None, stop == N

# Generated at 2022-06-10 21:53:36.850244
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var_name = 'eagle'
    sequence = (1, 2, 3, 4, 5)
    exclude = '5'
    slice_obj = slice(2, 4)
    indices = Indices(var_name, exclude)
    result = indices.__getitem__(slice_obj)
    assert type(result) == Indices
    assert result._slice == slice_obj


# Generated at 2022-06-10 21:53:39.496628
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    assert isinstance(x[7:], Indices)


# Generated at 2022-06-10 21:53:43.772072
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = Attrs('self')
    for i in v.items():
        print(i)
    v.source = 'self.ctx'
    for i in v.items():
        print(i)

if __name__ == '__main__':
    test_BaseVariable_items()

# Generated at 2022-06-10 21:53:46.664701
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = Indices('a')
    assert source == source[:]
    assert source.__getitem__(slice(1, 2)) == Indices('a[1:2]')
    assert source.__getitem__(slice(1, -1)) == Indices('a[1:-1]')

# Generated at 2022-06-10 21:53:58.219533
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import os
    import sys
    import pandas as pd

    def test_call_items(items, frame, normalize):
        for var, expect in items:
            if type(var) == types.CodeType:
                obj = BaseVariable(var, ())
            elif type(var) == types.FunctionType:
                obj = var()
            else:
                raise Exception("Invalid type of var")
            result = obj.items(frame, normalize)
            assert result == expect

    def _make_frame(func):
        def make_frame(**kwargs):
            frame = inspect.currentframe()
            while frame and frame.f_back and frame.f_code.co_name != func:
                frame = frame.f_back

# Generated at 2022-06-10 21:54:10.945502
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    if not hasattr(Indices, "_slice"):
        raise RuntimeError("Indices.__getitem__() is not implemented")
    if not hasattr(Indices, "_keys"):
        raise RuntimeError("Indices._keys() is not implemented")
    indices = Indices("_")
    indices_2 = indices[:]
    assert indices._slice == slice(None)
    assert isinstance(indices_2, Indices)
    assert indices_2._slice == slice(None)
    assert indices_2 is not indices
    indices_2 = indices[:-1]
    assert indices._slice == slice(None)
    assert isinstance(indices_2, Indices)
    assert indices_2._slice == slice(None, -1)
    assert indices_2 is not indices
    indices_2 = indices[None:2]


# Generated at 2022-06-10 21:54:13.665004
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    my_variable = BaseVariable('x')
    try:
        my_variable.items()
    except NotImplementedError:
        return True

    return False


# Generated at 2022-06-10 21:54:19.488391
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    def assert_slice(left, right, expected_slice):
        variables = Indices('a')
        variables = variables[left:right]
        assert variables._slice == expected_slice

    assert_slice(None, None, slice(None))
    assert_slice(1, None, slice(1, None))
    assert_slice(None, 3, slice(None, 3))
    assert_slice(1, 3, slice(1, 3))

# Generated at 2022-06-10 21:55:05.527290
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("a")
    assert a[1:2]._slice == slice(1,2)
    assert a[2:]._slice == slice(2, None)
    assert a[:]._slice == slice(None)
    assert a[1:]._slice == slice(1, None)