

# Generated at 2022-06-10 21:45:32.728999
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    print ("Executing Unit Test for method items of class BaseVariable")

    # First test (Keys)
    print ("\tTest 1 of 3 - Keys")
    key_var = Keys('x')
    test_dict = {'a' : 1, 'b' : 2}
    frame = _Frame(x = test_dict)
    print ("\t\tSource = %s" % key_var.source)
    print ("\t\tExclude = %s" % key_var.exclude)
    print ("\t\tFrame = %s" % frame.f_locals)
    items1 = key_var.items(frame)
    print ("\t\tItems = %s" % items1)

# Generated at 2022-06-10 21:45:36.300733
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    """
    测试 BaseVariable.items 方法
    实际是测试了继承 BaseVariable 的子类 CommonVariable 的 _items 方法
    """
    dic = {'a': 1, 'b': '2', 'c': [1, 2], 'd': {'ddd': 'iii'}}

    def testfunc():
        x = '1'
        return dic['a']

    def testfunc2():
        lst = [1, 2]
        return lst[1]

    frame = types.FunctionType(testfunc.__code__, testfunc.__globals__)
    frame.f_locals = testfunc.__globals__

# Generated at 2022-06-10 21:45:46.821556
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('main_value')
    indices[:2]
    assert indices._slice == slice(None,2)
    indices[2:]
    assert indices._slice == slice(2)
    indices[1::2]
    assert indices._slice == slice(1, None, 2)
    indices[:]
    assert indices._slice == slice(None)
    indices[::2]
    assert indices._slice == slice(None, None, 2)
    indices[0:10:2]
    assert indices._slice == slice(0, 10, 2)
    indices[10:0:2]
    assert indices._slice == slice(10, 0, 2)
    indices[::-1]
    assert indices._slice == slice(None, None, -1)
    indices[-1:2:-1]
    assert indices._slice

# Generated at 2022-06-10 21:45:54.577181
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Create instance of class Indices with empty source,
    # empty exclude
    v = Indices("", [])
    # Assign to variable _slice the slice of v
    _slice = slice(1, 2, 1)
    # Call method __getitem__ of v with argument _slice
    result = v.__getitem__(_slice)
    # Check that result is instance of Indices
    assert(isinstance(result, Indices))
    # Check that result._slice is equal to _slice
    assert(result._slice == _slice)

# Generated at 2022-06-10 21:46:02.694954
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import dummy
    from . import exception
    from . import frame
    import re

    m = dummy.DummyModule()
    f = frame.Frame(m.a)
    l = f.f_locals

    assert m.a.x.items(f) == [('a.x', '<DummyModule.a.x>')]
    assert re.search(r"^<DummyModule.a\.x\[['\"]a['\"]\] = <DummyModule\.a\.x\.a>$", m.a.x['a'].items(f)[0][-1])

# Generated at 2022-06-10 21:46:04.948109
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable('1')
    bv2 = BaseVariable('1')
    assert bv1 == bv2


# Generated at 2022-06-10 21:46:07.879248
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    instance = Indices("I.source[1:2]", exclude = ())
    assert isinstance(instance, Indices)


# Generated at 2022-06-10 21:46:11.352629
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('foo')
    assert isinstance(a[2:4], Indices)
    assert a[2:4]._slice is slice(2, 4)

# Generated at 2022-06-10 21:46:24.126526
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    l = ['a', 'b', 'c']

    v = Indices('mylist')
    assert v.__getitem__(slice(1, 2)) == ['b']
    assert v.__getitem__(slice(0, 2)) == ['a', 'b']
    assert v.__getitem__(slice(0, 3)) == ['a', 'b', 'c']
    assert v.__getitem__(slice(1, 3)) == ['b', 'c']
    assert v.__getitem__(slice(1, 4)) == ['b', 'c']
    assert v.__getitem__(slice(2, 5)) == ['c']
    assert v.__getitem__(slice(2, 6)) == ['c']



# Generated at 2022-06-10 21:46:34.795918
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import math
    import random
    import collections
    import os

    class A(object):
        def __init__(self, x, y=1):
            self.x = x
            self.y = y

    a = A(math.pi)

    print(BaseVariable('a').items(dict(a=a, math=math)))
    # [('a', '<__main__.A object at 0x10f6a1060>'), ('a.x', 'math.pi'), ('a.y', '1')]

    print(Attrs('a').items(dict(a=a, math=math)))
    # [('a', '<__main__.A object at 0x10f6a1060>'), ('a.x', 'math.pi'), ('a.y', '1')]


# Generated at 2022-06-10 21:46:43.820275
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    result = Indices([1, 2, 3])[1:]
    assert isinstance(result, Indices)
    assert result._slice == slice(1, None)

# Generated at 2022-06-10 21:46:46.986641
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def eval(source):
        return compile(source, '<variable>', 'eval').co_code
    assert eval('{}.x'.format(source)) != eval('({}).x'.format(source))

# Generated at 2022-06-10 21:46:58.656737
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Variable-related symbols for testcases
    a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z = range(26)

    def check(expr, frame, expected):
        variable = BaseVariable(expr)
        assert variable.items(frame) == expected

    check('a', frame=dict(a=1), expected=[('a', '1')])
    check('a', frame=dict(a=dict(b=2, c=3)), expected=[('a', '<dict>'), ('a.b', '2'), ('a.c', '3')])

# Generated at 2022-06-10 21:47:03.127754
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a')
    slice1 = slice(1,2)
    indices1 = indices.__getitem__(slice1)
    assert isinstance(indices1, Indices)
    assert isinstance(indices1._slice, slice)
    assert indices1._slice == slice1

# Generated at 2022-06-10 21:47:06.420971
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('x', ('__repr__',))
    result = var[:]
    assert isinstance(result, Indices)
    assert result._slice == slice(None)

test_Indices___getitem__()

# Generated at 2022-06-10 21:47:15.809028
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect

    frame = inspect.currentframe()

    source_1 = '__name__'
    checker_1 = lambda x: x[0][0] == source_1 and len(x) == 1
    t1 = BaseVariable(source_1).items(frame)
    assert checker_1(t1)

    source_2 = '__builtins__'
    checker_2 = lambda x: x[0][0] == source_2 and len(x) == 1
    t2 = Attrs(source_2).items(frame)
    assert checker_2(t2)

    source_3 = '__xxx__'
    checker_3 = lambda x: len(x) == 0
    t3 = BaseVariable(source_3).items(frame)
    assert checker_3(t3)

   

# Generated at 2022-06-10 21:47:21.674366
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Given
    sut = Indices('a')
    # When
    actual = sut[5:10]
    # Then
    assert actual._slice == slice(5, 10, None)


if __name__ == '__main__':
    pytest.main(['-v', '-s', __file__])

# Generated at 2022-06-10 21:47:27.660753
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """ Test __eq__ method of class BaseVariable. """
    variable = BaseVariable("variable", exclude=("exclude", ))
    variable1 = BaseVariable("variable", exclude=("exclude", ))
    variable2 = BaseVariable("variable", exclude=("exclude", "variable"))
    assert variable.__eq__(variable1) is True
    assert variable.__eq__(variable2) is False


# Generated at 2022-06-10 21:47:30.609138
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('abc')
    y = BaseVariable('abc')
    z = BaseVariable('abc', ('a', 'b'))

    assert x == y
    assert x != z



# Generated at 2022-06-10 21:47:34.384538
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[0:2] == Indices('a', exclude=())[0:2]
    assert Indices('a')[0:2] != Indices('b', exclude=())[0:2]
    assert Indices('a', exclude=('a',))[0:2] != Indices('a', exclude=())[0:2]

# Generated at 2022-06-10 21:47:42.625779
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import os
    import sys
    v = BaseVariable("os.path")
    print(v.items(sys._getframe()))
    v = BaseVariable("os.path", exclude=["curdir"])
    print(v.items(sys._getframe()))


# Generated at 2022-06-10 21:47:46.805345
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a', exclude=(1,))
    v2 = BaseVariable('a', exclude=(1,))
    v3 = BaseVariable('a', exclude=2)
    assert v1 == v2
    assert v1 != v3

# Generated at 2022-06-10 21:47:54.296678
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable('a')
    assert (bv == BaseVariable('a', ('x',)))
    assert (bv == BaseVariable('b', ('x',)))
    assert (bv == BaseVariable('a', ('y',)))
    assert (not (bv == BaseVariable('a', ('x', 'y'))))
    assert (not (bv == BaseVariable('b', ('x', 'y'))))
    assert (not (bv == BaseVariable('c')))
    assert (not (bv == BaseVariable('b')))

# Generated at 2022-06-10 21:48:00.524141
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def func(x, a=1, b=2):
        return x + a + b
    import inspect
    import dis
    # inspect.getsourcelines: Return a list of source lines and starting line number for an object.
    print(inspect.getsourcelines(func))
    print(dis.dis(func))

    bv = BaseVariable('x', exclude={'a'})
    import pdb
    # pdb.set_trace()
    print([x for x in bv.items(inspect.currentframe())])
    dict_ = {'a': 1, 'b': 2, 'x': 3}
    print([x for x in bv.items(inspect.currentframe())])

    bv = BaseVariable('a', exclude=['x'])

# Generated at 2022-06-10 21:48:08.077141
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('var') == BaseVariable('var')
    assert BaseVariable('var') != BaseVariable('var', ['*'])
    assert BaseVariable('var') != BaseVariable('var', ['*'], ['*'])
    assert BaseVariable('var', ['*']) == BaseVariable('var', ['*'])
    assert BaseVariable('var', ['*']) != BaseVariable('var', ['*'], ['*'])
    assert BaseVariable('var', ['*'], ['*']) == BaseVariable('var', ['*'], ['*'])


# Generated at 2022-06-10 21:48:13.220169
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('test_BaseVariable___eq__():', end=' ')
    # v1 is equal to v2
    v1 = Keys('main')
    v2 = Keys('main')
    assert v1 == v2
    print('pass')


# Generated at 2022-06-10 21:48:18.345759
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable("foo") == BaseVariable("foo")
    BaseVariable("foo") == Attrs("foo")
    BaseVariable("foo") == Keys("foo")

    assert BaseVariable("foo") == BaseVariable("foo")
    assert BaseVariable("foo") == Attrs("foo")
    assert BaseVariable("foo") == Keys("foo")
    assert BaseVariable("foo")._fingerprint == BaseVariable("foo")._fingerprint

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-10 21:48:27.940823
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', exclude=['b']) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=('b',))
    assert BaseVariable('a', exclude=('b',)) == BaseVariable('a', exclude=['b'])
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', exclude=['b'])
    assert BaseVariable('a', exclude=['b']) != BaseVariable('a', exclude=['c'])


# Generated at 2022-06-10 21:48:35.783174
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    def cmp(a, b, expect):
        result = a.__eq__(b)
        if expect != result:
            print(a._fingerprint)
            print(b._fingerprint)
            print(expect)
        assert expect == result

    a = Keys('test')
    b = Keys('test')
    c = Keys('test', exclude='a')
    d = Keys('test', exclude='a')
    e = Attrs('test')
    f = Indices('test')
    g = Attrs('test2')
    h = Attrs('test', exclude='a')

    cmp(a, a, True)
    cmp(a, b, True)
    cmp(a, c, False)
    cmp(a, e, False)
    cmp(a, g, False)
   

# Generated at 2022-06-10 21:48:41.865635
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')

    assert BaseVariable('a') != BaseVariable('abc')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')

    assert BaseVariable('a') != 5
    assert BaseVariable('a') != object()



# Generated at 2022-06-10 21:48:58.288212
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return []

    assert TestVariable('module.var') == TestVariable('module.var')
    assert TestVariable('module.var') != TestVariable('module.var1')

    assert TestVariable('module.var', exclude=['key']) == TestVariable('module.var', exclude=['key'])
    assert TestVariable('module.var', exclude=['key']) != TestVariable('module.var', exclude=['key1'])
    assert TestVariable('module.var', exclude=['key']) != TestVariable('module.var1', exclude=['key'])
    assert TestVariable('module.var1', exclude=['key']) != TestVariable('module.var1', exclude=['key1'])

# Generated at 2022-06-10 21:49:02.961929
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices(source = u"params", exclude = ())
    indices1 = Indices(source = u"params", exclude = ())
    result = indices[:]
    assert isinstance(result, Indices)
    assert result.source == u"params"
    assert result == indices1

# Generated at 2022-06-10 21:49:09.367893
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('', ())
    x = indices[:]  # noqa
    assert x._slice == slice(None)
    x = indices[:-1]  # noqa
    assert x._slice == slice(None, -1)
    x = indices[:2]  # noqa
    assert x._slice == slice(None, 2)
    x = indices[::2]  # noqa
    assert x._slice == slice(None, None, 2)


# Generated at 2022-06-10 21:49:18.729302
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a', 'b')
    b = BaseVariable('a', 'b')
    c = BaseVariable('a', 'b')
    a1 = BaseVariable('a', 'b')
    b1 = BaseVariable('b', 'b')
    c1 = BaseVariable('a', 'a')
    assert a == a1
    assert a == b
    assert b == a
    assert hash(a) == hash(a1)
    assert hash(a) == hash(b)
    assert hash(a) == hash(c)
    assert a != b1
    assert b != b1
    assert a != c1
    assert b != c1
    assert c != c1
    assert a != 1
    assert a != 'a'
    assert a != 'b'
    assert a != 1.0

# Unit

# Generated at 2022-06-10 21:49:21.665471
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def _items(self, key, normalize=False):
            pass
    a = A('x')
    b = A('x')
    assert a == b


# Generated at 2022-06-10 21:49:23.987986
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('source','exclude')
    v2 = BaseVariable('source','exclude')
    assert v1 == v2


# Generated at 2022-06-10 21:49:33.448992
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .testing import assert_equal

# Generated at 2022-06-10 21:49:46.261292
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .formatter import format_frame
    from .tracer import Tracer
    import logging
    import json

    def main():
        log = logging.getLogger("main")
        log.debug("1")
        log.debug("2")
        log.debug("3")

    tracer = Tracer(
        format_frame=format_frame,
        frame_variables=dict(
            frame=Indices()[2:]
        ),
        logger_name='log',
        log_level=logging.DEBUG
    )

    with tracer:
        main()

    logs = json.loads(tracer.logger.handlers[0].records[0]['msg'])
    assert logs[1]['frame'] == '0'
    assert logs[2]['frame'] == '1'

# Generated at 2022-06-10 21:49:48.089218
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('b')
    print(b == a)


# Generated at 2022-06-10 21:49:51.649835
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('a')
    v2 = BaseVariable('a')
    assert v1 == v2

    v1 = BaseVariable('b')
    v2 = BaseVariable('a')
    assert not v1 == v2



# Generated at 2022-06-10 21:50:03.402769
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import ipdb; ipdb.set_trace()


# Generated at 2022-06-10 21:50:08.427666
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variables = Indices('')
    variables[0:5] == Indices('', slice(0, 5))
    Indices('', slice(0, 1)) == Indices('', slice(0, 5))[0:1]
    Indices('', slice(0, 5))[0:5] == Indices('', slice(0, 5))

# Generated at 2022-06-10 21:50:18.173771
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  indexes = Indices('.data')._items(numpy.arange(100))._getitem__(slice(0,1))

# Generated at 2022-06-10 21:50:31.300686
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from inspect import currentframe
    frame = currentframe()
    # store the current number of watchers
    num_watchers = len(frame.f_back.f_locals)
    # create a test class
    class TestIndices(Indices):
        def __init__(self, source, exclude=()):
            Indices.__init__(self, source, exclude)


# Generated at 2022-06-10 21:50:36.413671
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class C(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    a = C('a')
    b = C('b')
    c = C('a')
    assert a != b
    assert a == c
    assert a != object()
    assert a != None


# Generated at 2022-06-10 21:50:39.765295
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("a", ())
    var2 = BaseVariable("a", ())
    var3 = BaseVariable("b", ())
    var4 = BaseVariable("a", ())
    var4.exclude = ("c",)

    assert (var1 == var2)
    assert (var1 != var3)
    assert (var1 != var4)
    assert (var3 != var4)


# Generated at 2022-06-10 21:50:50.331444
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # class BaseVariable is an abstract class, so I create a common subclass of BaseVariable and implement its methods to test its abstract method.
    class Variable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return tuple()
    # create a instance of class Variable
    v = Variable('a')
    frame = {'a': 1}
    # method items only has one parameter, frame, here I create a frame for testing method items.
    assert v.items(frame) == tuple()
    # method items has a default parameter, normalize, which makes the value of parameter normalize = False, so I set it to True to test it.
    assert v.items(frame, True) == tuple()
    # method items will use the source to get its value and return a tuple containing this source and its value

# Generated at 2022-06-10 21:51:02.764457
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from pycallgraph import Config
    from pycallgraph.output import GraphvizOutput
    from pycallgraph.output.graphviz import Node
    from .runtime import RuntimeConfig

    Frame = utils.Frame
    config = Config(groups=['pycallgraph'], max_depth=3, include_stdlib=False)
    runtime_config = RuntimeConfig()
    graphviz = GraphvizOutput(config)
    runtime_config.trace_filter = graphviz.create_filter(config)
    runtime_config.max_depth = config.max_depth

    node = Node(graphviz, Frame('', None, ''), '', [], 0, -1, runtime_config)
    frame = Frame('', None, '')
    var_1 = BaseVariable('x', 'y')

# Generated at 2022-06-10 21:51:05.391346
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable('a')
    bv2 = BaseVariable('a')
    assert bv == bv2


# Generated at 2022-06-10 21:51:11.922753
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x') != BaseVariable('x', 'a')
    assert BaseVariable('x') != BaseVariable('x', ('a',))
    assert BaseVariable('x') != 'foobar'
    assert BaseVariable('x') != object()


# Generated at 2022-06-10 21:51:46.243255
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Parent(object):
        def __eq__(self, other):
            return True

    class Child(Parent):
        pass

    parent = Parent()
    assert parent == parent

    child = Child()
    assert child == child

    assert parent != child
    assert child != parent

    # Test __eq__ of BaseVariable
    base_variable = BaseVariable('abc')
    assert base_variable == base_variable

    another_base_variable = BaseVariable('def')
    assert base_variable != another_base_variable
    assert another_base_variable != base_variable

    attrs = Attrs('xyz')
    assert attrs == attrs

    another_attrs = Attrs('zzz')
    assert attrs != another_attrs
    assert another_attrs != attrs

    assert attrs == base_variable

# Generated at 2022-06-10 21:51:53.941300
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class BaseVariableTestHelper(BaseVariable):
        def __init__(self, source, exclude=()):
            BaseVariable.__init__(self, source, exclude)
    # basic properties
    v = BaseVariable("source", "exclude")
    assert isinstance(v, BaseVariable)
    assert v.source == "source"
    assert v.exclude == ("exclude",)
    assert v.code
    assert 'source' in v.unambiguous_source
    assert v.unambiguous_source.startswith('(')
    assert v.unambiguous_source.endswith(')')

    # test method __eq__ of class BaseVariable
    assert v.__eq__(v)
    assert not v.__eq__(1)
    assert not v.__eq__(None)
    assert v.__

# Generated at 2022-06-10 21:51:56.378297
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    assert a[1:3]._slice == slice(1, 3)

# Generated at 2022-06-10 21:52:03.475422
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    d = {}
    v = BaseVariable('d')
    assert v == v
    assert v != 1
    assert v == BaseVariable('d')
    assert v != BaseVariable('d', 'x')
    assert v != BaseVariable('d', 'x', 'y')
    assert v != BaseVariable('ddd')
    assert v != Attrs('d')
    assert v != Keys('d')
    assert v != Indices('d')
    assert v != Exploding('d')


# Generated at 2022-06-10 21:52:07.923960
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('main_value')
    i2 = i[1:3]
    assert i2._slice == slice(1,3)
    i3 = i2[2:]
    assert i3._slice == slice(2, None)

# Generated at 2022-06-10 21:52:11.997046
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('a', 'b')
    indices_s = indices[2:-2]
    assert isinstance(indices_s, Indices)
    assert indices_s._slice == slice(2,-2)



# Generated at 2022-06-10 21:52:20.631360
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('name')
    v2 = BaseVariable('name')
    v3 = BaseVariable('name', ['name'])
    v4 = BaseVariable('name', ['name'])
    v5 = BaseVariable('signal_channel_name')
    v6 = BaseVariable('signal_channel_name')
    v7 = BaseVariable('name')

    assert v1 == v2
    assert v1 != v3
    assert v1 != v4
    assert v1 != v5
    assert v5 != v6
    assert v1 != v7


# Generated at 2022-06-10 21:52:23.349073
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (
        BaseVariable('foo') == BaseVariable('foo')
    ), 'Two instances of BaseVariable with same source are not equal'



# Generated at 2022-06-10 21:52:26.619999
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    A = BaseVariable("1")
    B = BaseVariable("1")
    C = BaseVariable("2")
    assert A == B
    assert A != C
    assert C == C



# Generated at 2022-06-10 21:52:28.938648
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
	v1 = Keys('x')
	v2 = Keys('x')
	assert (v1 == v2)


# Generated at 2022-06-10 21:53:19.264467
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('[1, 2, 3]')[2:]._slice == slice(2, None)

# Generated at 2022-06-10 21:53:25.050545
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('1', exclude=())
    var2 = BaseVariable('1', exclude=())
    var3 = BaseVariable('1', exclude=('1',))
    var4 = BaseVariable('2', exclude=())
    assert var1 == var2
    assert var1 != var3
    assert var1 != var4
    assert var1 != 1
    assert var1 != object()

# Generated at 2022-06-10 21:53:31.764769
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a') != object()

# Generated at 2022-06-10 21:53:35.387592
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('', ())
    b = BaseVariable('', ())
    c = BaseVariable('', [])
    assert(a == b and b == c and c == a)


# Generated at 2022-06-10 21:53:42.474667
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("args[0]", exclude=("foo", "bar"))
    b = BaseVariable("args[0]")
    c = BaseVariable("args[0]", exclude=("foo", "bar"))
    d = BaseVariable("args[1]", exclude=("foo", "bar"))
    e = BaseVariable("args[1]")
    f = BaseVariable("args[1]", exclude=("foo", "bar"))

    assert a == c
    assert a != d
    assert a != e
    assert a != f
    assert a != b
    assert a != "args[0]"
    assert d != a
    assert d != c
    assert d == f
    assert d != e
    assert d != b
    assert d != "args[1]"
    assert e != a
    assert e != c
    assert e

# Generated at 2022-06-10 21:53:45.684020
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    Indices_obj = Indices('main')
    slice_obj = slice(1,5)
    actual_result = Indices_obj.__getitem__(slice_obj)
    assert isinstance(actual_result, Indices)
    assert actual_result._slice == slice_obj
    assert actual_result.source == 'main'
    assert actual_result.exclude == ()

# Generated at 2022-06-10 21:53:49.143032
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    cls = Indices('', ())
    cls = cls[:2]
    assert repr(cls).index('slice(None, 2)')
    assert repr(cls).index('Indices')

# Generated at 2022-06-10 21:53:59.841834
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    f_locals_parent = {'a':1, 'b':2, 'c':3}
    f_locals = {'a':4, 'd':5, 'e':6}
    f_globals = {'a':7, 'g':8, 'h':9}
    f_locals_parent.update(f_locals)

    frame = {}
    frame['f_locals'] = f_locals_parent
    frame['f_globals'] = f_globals

    for class_variable in (BaseVariable, CommonVariable, Attrs, Keys, Indices, Exploding):
        variable = class_variable('a')
        assert variable.items(frame) == [('a', '4')]

        variable = class_variable('b')

# Generated at 2022-06-10 21:54:05.788856
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indice = Indices('')
    assert indice.source == ''
    assert indice.exclude == ()
    assert indice._fingerprint == (Indices, '', ())
    assert indice._slice == slice(None)
    indice = indice[1:4]
    assert indice._slice == slice(1,4)

# Generated at 2022-06-10 21:54:17.199100
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import pluggy
    pm = pluggy.PluginManager('dummy')
    class DummyBaseVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    class DummyBaseVariable1(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass
    class Dummy1(object):
        pass
    class Dummy1_1(object):
        pass
    pm.register(DummyBaseVariable)
    pm.register(DummyBaseVariable1)
    pm.register(Dummy1)
    pm.register(Dummy1_1)
    d = DummyBaseVariable('dummy')
    d1 = DummyBaseVariable1('dummy')
    d2 = DummyBaseVariable('dummy')