

# Generated at 2022-06-10 21:45:17.569286
# Unit test for method items of class BaseVariable

# Generated at 2022-06-10 21:45:24.365358
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_list = ['a', 'b', 'c', 'd']
    test_list_variable = Indices("test_list")
    new_test_list = test_list_variable[0:2]
    assert new_test_list._fingerprint == (Indices, 'test_list', ())
    assert new_test_list._slice == slice(0, 2, None)
    assert new_test_list.source == 'test_list'
    assert new_test_list.code == compile("test_list", '<variable>', 'eval')
    assert new_test_list.unambiguous_source == 'test_list'

    test_list_variable_dict = test_list_variable.__dict__
    for key in test_list_variable_dict:
        if key != '_slice':
            new_test_

# Generated at 2022-06-10 21:45:36.063672
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import dis
    import opcode
    code = compile('main', '<variable>', 'eval')
    stack = []
    co_varnames = code.co_varnames
    co_names = code.co_names
    co_const = code.co_consts
    for instruction in dis.get_instructions(code):
        if instruction.opname == 'STORE_NAME':
            index = instruction.arg
            name = co_names[index]
            if name in ('frame', 'normalize'):
                continue
            stack.append(co_names[index])
        elif instruction.opname == 'LOAD_NAME':
            index = instruction.arg
            name = co_names[index]
            if name in ('frame', 'normalize'):
                continue

# Generated at 2022-06-10 21:45:45.538708
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print('running ', inspect.stack()[0][3], end='')
    (i1, i2, i3) = (Indices('a'), Indices('a')[1:2], Indices('a')[1:])
    assert i1 == i2 == i3
    assert i1.items(None) == i2.items(None) == i3.items(None)
    assert i2.items(None) == [('a[1]', '...')]
    assert i3.items(None) == [('a[1]', '...'), ('a[2]', '...')]
    return

# Generated at 2022-06-10 21:45:54.758320
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import os
    import inspect
    import dis
    
    def f():
        sys.exit()
    
    frame = inspect.currentframe()
    source = "frame"
    exclude = ()
    test_base_variable = BaseVariable(source, exclude)
    test_base_variable.items(frame, normalize=False)
    
    # Test for exception in case of wrong data type
    try:
        test_base_variable.items()
    except TypeError as e:
        assert type(e) == TypeError
    
    # Test return value
    assert type(test_base_variable.items(frame, normalize=False)) == tuple


# Generated at 2022-06-10 21:45:57.281615
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('the_list')
    indices.source = '[1, 2, 3]'
    indices = indices[:]
    assert indices._slice is not None
    assert indices._slice.start is None
    assert indices._slice.stop is None
    assert indices._slice.step is None


# Generated at 2022-06-10 21:46:01.247681
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class B(BaseVariable):
        def _items(self, main_value, normalize=False):
            return True

    b = B('a')
    assert b == B('a')
    assert b == B('a', exclude=(1, 2))
    assert b != B('a', exclude=1)

# Generated at 2022-06-10 21:46:05.558960
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class MyVariable(BaseVariable):
        def _items(self, key):
            yield (self.source, key)
    frame = {}
    assert MyVariable('1').items(frame) == [('1', 1)]
    assert MyVariable('1').items(frame, normalize=True) == [('1', '1')]

# Generated at 2022-06-10 21:46:11.089171
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    source = 'main_value'
    main_value = [1]
    exclude = ()
    indices = Indices(source, exclude)
    indices_1 = indices.__getitem__(slice(None))
    result_1 = '.'.join(source.split('.')[1:])
    print(result_1)


# Generated at 2022-06-10 21:46:14.380298
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("i")
    v2 = BaseVariable("i")
    print(v1 == v2)


# Generated at 2022-06-10 21:46:20.528888
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'a.b.c'
    exclude = ['c']
    var1 = BaseVariable(source, exclude)
    var2 = BaseVariable(source, exclude)
    assert var1 == var2

# Generated at 2022-06-10 21:46:29.555427
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class MyVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return (('1', '1'), ('2', '2'))
    v1 = MyVariable('x')
    v2 = MyVariable('x')
    v3 = MyVariable('y')
    v4 = MyVariable('x', exclude=('2',))
    v5 = MyVariable('z')

    assert (v1 == v1) is True
    assert (v1 == v2) is True
    assert (v1 == v3) is False
    assert (v1 == v4) is False
    assert (v1 == v5) is False

    assert (v2 == v3) is False
    assert (v2 == v4) is False
    assert (v2 == v5) is False


# Generated at 2022-06-10 21:46:38.398788
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable('a')
    # test if v is equal to itself
    assert v == v, 'test 1 for method __eq__ of class BaseVariable failed'
    # test if v is not equal to None
    assert not v == None, 'test 2 for method __eq__ of class BaseVariable failed'
    # test if v is not equal to an instance of a different class
    assert not v == 'a', 'test 3 for method __eq__ of class BaseVariable failed'
    # test if v is not equal to an instance of the same class with different source
    assert not v == BaseVariable('b'), 'test 4 for method __eq__ of class BaseVariable failed'
    # test if v is not equal to an instance of the same class with different exclude

# Generated at 2022-06-10 21:46:40.315452
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('a')
    variable[:]



# Generated at 2022-06-10 21:46:45.307351
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert(BaseVariable('x') == BaseVariable('x'))
    assert(BaseVariable('x', exclude='a') != BaseVariable('x'))
    assert(BaseVariable('x', exclude='b') != BaseVariable('x', exclude='a'))
    assert(BaseVariable('x') != BaseVariable('a'))
    assert(BaseVariable('x') != 'a')

# Generated at 2022-06-10 21:46:48.614750
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices=Indices('a')
    b=indices[1:-1]
    assert b._slice==slice(1,-1)

# Generated at 2022-06-10 21:46:53.731420
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result = list(Indices('a')[0:2]._items(a))
    assert result == [('a[0]', '1'), ('a[1]', '2')]

test_Indices___getitem__()

# Generated at 2022-06-10 21:46:57.791203
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = types.SimpleNamespace(f_globals={'test': {'test2': [1,2,3]}}, f_locals={})
    v = BaseVariable('test', 'test2')
    v.items(frame)



# Generated at 2022-06-10 21:47:04.470776
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = Keys('vars')
    vars = {'vars': {'no': 'normalize'}, 
            'a': 'normalize_me', 
            'no': {'normalize': 'me'}}
    for key, value in var.items(vars):
        assert(key in ('vars[no]', 'vars')), 'key: %s' % (key)
        assert(value in ('no', 'normalize_me', 'me')), \
                'value: %s' % (value)
    for key, value in var.items(vars, normalize=True):
        assert(key in ('vars[no]', 'vars')), 'key: %s' % (key)

# Generated at 2022-06-10 21:47:12.994971
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def __init__(self, source, exclude=()):
            super(A, self).__init__(source, exclude)
        def _items(self, main_value, normalize=False):
            pass

    assert A('a', ('ex1', 'ex2')) == A('a', ('ex2', 'ex1'))
    assert not A('a', ('ex1', 'ex2')) == A('b', ('ex1', 'ex2'))
    assert not A('a', ('ex1', 'ex2')) == A('a', ('ex1', 'ex2', 'ex3'))



# Generated at 2022-06-10 21:47:24.814384
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', exclude=['x'])
    var2 = BaseVariable('a', exclude=['x'])
    var3 = BaseVariable('a', exclude=['y'])
    var4 = BaseVariable('b', exclude=['x'])
    assert var1 == var2
    assert var1 != var3
    assert var1 != var4
    assert var2 != var3
    assert var2 != var4
    assert var3 != var4


# Generated at 2022-06-10 21:47:34.195175
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    dict_data = {'key1': 'value1', 'key2': 'value2'}
    list_data = ['value1', 'value2']

    # The method .items() of class Keys is tested
    key = Keys('dict_data')
    assert key.items(dict_data) == [('dict_data', '{...}'), ('dict_data[key1]', "'value1'"), ('dict_data[key2]', "'value2'")]
    assert key.items(list_data) == [('list_data', '[...]')]
    key = Keys('dict_data', exclude=('key2',))
    assert key.items(dict_data) == [('dict_data', '{...}'), ('dict_data[key1]', "'value1'")]

    # The method .items() of class

# Generated at 2022-06-10 21:47:42.533837
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Initialize a new BaseVariable object
    bv = BaseVariable('x', 'y')
    # Initialize a new dictionary
    dictionary = {'x': 1, 'y': 2}
    # Initialize a new frame object
    from collections import namedtuple
    frame = namedtuple('frame', ['f_globals', 'f_locals'])
    frame = frame({}, dictionary)
    # Test the items method
    assert bv.items(frame) == [('x', '1'), ('x.x', '1')]

# Generated at 2022-06-10 21:47:46.705024
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = Attrs('main')
    b = Attrs('main')
    c = Attrs('other')
    d = Attrs('main', exclude='a')
    assert a == b
    assert a != c
    assert a != d


# Generated at 2022-06-10 21:47:49.349400
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('source', exclude=())
    j = i[::-1]
    assert j._slice == slice(None, None, -1)

# Generated at 2022-06-10 21:47:52.724007
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')

    assert (var1 == var2)
    assert not (var1 == var3)

# Generated at 2022-06-10 21:47:59.745235
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('', ())
    b = BaseVariable('', ())
    c = BaseVariable('', ())
    d = BaseVariable('', ())
    e = BaseVariable('', ())
    #duplicate code
    f = BaseVariable('', ())

    a.source = 'a'
    b.source = 'a'
    c.source = 'c'
    d.source = 'a'
    d.exclude = ['a']
    e.source = 'a'
    e.exclude = ['b']
    f.source = 'a'


    assert (a == b) == True
    assert (a == c) == False
    assert (a == d) == False
    assert (a == e) == False
    assert (a == f) == True
    assert (a == 1) == False

# Generated at 2022-06-10 21:48:04.516968
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(1) == BaseVariable(1)
    assert BaseVariable(1) != BaseVariable(2)
    assert BaseVariable(1) != BaseVariable(1, exclude=1)
    assert BaseVariable(1, exclude=1) == BaseVariable(1, exclude=1)

# Generated at 2022-06-10 21:48:15.706126
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    """
    Test example:
        def myfunc(a, b):
            c = 3
            d = {'key1' : 1, 'key2' : 2, 'key3' : 3}
            e = ('value1', 'value2', 'value3')
            f = [1, 2, 3]
            g = 1+2j
            h = [1, 2, 3, {1 : 1, 2 : 2}, [1, 2, 3]]
            i = None
            j = 0/0
            return {'a' : a, 'b' : b, 'c' : c, 'd' : d, 'e' : e, 'f' : f, 'g' : g, 'h' : h, 'i' : i, 'j' : j}

        myfunc(1, 2)
    """


# Generated at 2022-06-10 21:48:27.293043
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Keys('self').__eq__(Keys('self')) == True
    assert Keys('self').__eq__(Attrs('self')) == False
    assert Keys('self').__eq__(Indices('self')) == False
    assert Keys('self').__eq__(Exploding('self')) == False
    
    assert Attrs('self').__eq__(Keys('self')) == False
    assert Attrs('self').__eq__(Attrs('self')) == True
    assert Attrs('self').__eq__(Indices('self')) == False
    assert Attrs('self').__eq__(Exploding('self')) == False
    
    assert Indices('self').__eq__(Keys('self')) == False
    assert Indices('self').__eq__(Attrs('self')) == False

# Generated at 2022-06-10 21:48:37.826607
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    attribute = Indices("a[i]")
    result = attribute[0:1]
    assert isinstance(result, Indices) and result._slice == slice(0, 1)


# Generated at 2022-06-10 21:48:46.127176
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    import sys
    import traceback
    import contextlib
    import builtins

    # Hack the parser so that we can create a fake exception traceback.
    # The parser holds a reference to the traceback object and so if we
    # don't hack it, it will hold a reference to the real traceback
    # object and not the one we have constructed.
    def get_exception_format(cls):
        """Create and save a new exception formatter."""
        def exc_formatter(*args, **kwargs):
            return '{}'.format(*args)
        return exc_formatter

    def set_exception_format(cls, exc_formatter):
        """Set the formatter for exceptions of type cls."""
        return None

    tb_frame = inspect.currentframe()

# Generated at 2022-06-10 21:48:49.172385
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[1:5]._slice == slice(1, 5)

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:48:53.226728
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    I = Indices(1, 2).__getitem__(slice(0,1))
    assert I._slice == slice(0,1)
    assert isinstance(I, Indices)

# Generated at 2022-06-10 21:49:03.989254
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('test')
    var[2:5]
    var[1:]
    var[:-2]
    var[::2]
    var[::-1]
    var[1:5:2]
    var[5:1:-2]
    var[5:1:-1]
    var[5:1:1]
    var[5]

    try:
        var[None]
        assert False
    except AssertionError:
        pass
    except:
        assert False

    try:
        var['slice']
        assert False
    except AssertionError:
        pass
    except:
        assert False

    try:
        var['2', '3']
        assert False
    except AssertionError:
        pass
    except:
        assert False


# Generated at 2022-06-10 21:49:14.519424
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import builtins
    # Case 1:
    c = Indices('a[1:]')
    c[1]
    assert str(c._slice) == 'slice(1, None, None)'
    # Case 2:
    c = Indices('a[1:]')
    c[:2]
    assert str(c._slice) == 'slice(None, 2, None)'
    # Case 3:
    c = Indices('a[1:]')
    c[:]
    assert str(c._slice) == 'slice(None, None, None)'
    # Case 4:
    c = Indices('a[1:]')
    c[1:2]
    assert str(c._slice) == 'slice(1, 2, None)'

if __name__ == '__main__':
    test_Indices___getitem

# Generated at 2022-06-10 21:49:16.220051
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices("arg")
    indices = indices[1:-1]
    assert indices[1:-1] is indices

# Generated at 2022-06-10 21:49:18.032185
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    x = BaseVariable('x')
    assert x.items({'x': 1}) == [
        ('x', '1'),
    ]



# Generated at 2022-06-10 21:49:24.783863
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    variable = BaseVariable('a', exclude=['b'])
    frame = type('', (object,), {
        'f_globals': {'a': {'x': 1, 'y': 2, 'b': 3}},
        'f_locals': {}
    })
    items = variable.items(frame)

    assert len(items) == 3
    assert items[1] == ('a.x', '1')
    assert items[2] == ('a.y', '2')



# Generated at 2022-06-10 21:49:34.035700
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print(Indices('t')[1:2])
    print(Indices('t')[0:1])

    # test
    print(Indices('t')[1])
    print(Indices('t')[0])


if __name__ == '__main__':
    class bar(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y


    class foo(object):
        def __init__(self):
            self.bar = bar(1, 2)
            self.a = 1
            self.b = 2
            self.c = [3, 4]


    a = [1, 2]
    t = foo()
    print(Keys('t'))
    print(Attrs('t'))

# Generated at 2022-06-10 21:49:57.573588
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class Test(BaseVariable):
        def __init__(self, source):
            super(Test, self).__init__(source)

        def _items(self, key, normalize=False):
            return ()

    test = Test('this is source')

    def _items(source, frame, normalize=False):
        return test.items(frame, normalize)

    # Test items of class BaseVariable
    def test_items():
        def get_frame():
            def x():
                y = 1
                return x

            return x()

        frame = get_frame()
        # Test BaseVariable.items()
        assert _items('x', frame) == (('x', '<function>'),)
        assert _items('y', frame) == (('y', '1'),)
        assert _items('z', frame) == ()

# Generated at 2022-06-10 21:49:59.726440
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('x')
    s = slice(1, -1, 2)
    assert v._slice == slice(None)
    assert v[s]._slice == s



# Generated at 2022-06-10 21:50:02.863671
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    obj = Indices('main', exclude=('a', 'b'))
    start = 1
    stop = 2
    step = None
    assert obj[start:stop:step] == list(range(start, stop, step))

# Generated at 2022-06-10 21:50:07.604877
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('foo')[::-1][1:4]
    y = Indices('foo')

    y._slice = slice(None)
    y._slice = slice(None, None, -1)
    y._slice = slice(1, 4)

    assert x._fingerprint == y._fingerprint

# Generated at 2022-06-10 21:50:09.286130
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a[1]')
    assert var[0] == Indices('a[1][0]')

# Generated at 2022-06-10 21:50:11.768170
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:3]._slice == slice(None, 3)



# Generated at 2022-06-10 21:50:20.348961
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import sys
    import random
    function_to_call = inspect.currentframe().f_back.f_back
    print(sys._getframe().f_lineno)
    print(function_to_call.f_locals)
    print(function_to_call.f_globals)
    print(function_to_call.f_back.f_locals)
    print(function_to_call.f_back.f_globals)
    print(function_to_call.f_back.f_back.f_locals)
    print(function_to_call.f_back.f_back.f_globals)
    print(function_to_call.f_back.f_back.f_back.f_locals)

# Generated at 2022-06-10 21:50:33.355919
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import re
    from types import CodeType, FrameType
    # 0 - 2 can be obtained via dis.get_instructions(fn).opname
    _POP_TOP = 1
    _LOAD_CONST = 100
    _LOAD_NAME = 101
    ops = [
        (_POP_TOP, None),
        (_LOAD_CONST, 'hello world'),
        (_LOAD_NAME, 're'),
        (_LOAD_NAME, 're'),
        (_LOAD_CONST, 'h.*?'),
    ]
    test_fn = re.compile('test')
    test_fn.match = lambda: 'match'
    test_fn.search = lambda: 'search'

    # Simulate a instruction sequence [[_POP_TOP, None], [_LOAD_CONST, 'hello world'],
    # [_LOAD_

# Generated at 2022-06-10 21:50:44.833681
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import traceback
    import io

    class A:
        x = 10
        y = 20

    class B:
        pass

    B.x = A()
    B.x.a = A()
    B.x.a.a = A()
    B.x.a.a.q = A()
    B.x.a.a.q.a = A()
    B.x.a.a.q.a.a = A()
    B.x.a.a.q.a.a.a = A()


    def test_get_variables_from_stack():
        with io.StringIO() as f:
            traceback.print_stack(f)
            stack = f.getvalue()
        return list(utils.get_variables_from_stack(stack))

   

# Generated at 2022-06-10 21:50:53.804339
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .api import from_frame
    import inspect
    import collections.abc
    import builtins
    frame = inspect.currentframe()
    builtins_variable = from_frame(frame, 'builtins')
    assert isinstance(builtins_variable, BaseVariable)
    builtins_items = builtins_variable.items(frame)
    assert len(builtins_items) > 0
    assert isinstance(builtins_items[0], collections.abc.Sequence)
    assert len(builtins_items[0]) == 2
    assert builtins_items[0][0] == 'builtins'
    assert builtins_items[0][1] == '<module \'builtins\' (built-in)>'
    builtins_mapping_variable = builtins_variable.Keys('dict')

# Generated at 2022-06-10 21:51:28.872399
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # Testcase 1
    a = Indices('abc')
    assert a[:2] == Indices('abc', (), slice(0, 2))
    assert a[1:3] == Indices('abc', (), slice(1, 3))
    # Testcase 2
    b = Indices('abc')[2:]
    assert b == Indices('abc', (), slice(2, None))
    # Testcase 3
    c = Indices('abc', (), slice(0, 2))
    assert c[1:] == Indices('abc', (), slice(1, 2))
    assert c[1:3] == Indices('abc', (), slice(1, 3))
    # Testcase 4
    d = Indices('abc', (), slice(2, None))

# Generated at 2022-06-10 21:51:34.819857
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices('_')
    assert i[:] is i
    i2 = i[1:]
    assert i2 is not i
    assert i2._slice is slice(1, None)
    i3 = i[1:2]
    assert i3 is not i
    assert i3._slice is slice(1, 2)


# Generated at 2022-06-10 21:51:47.414275
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import os

    os.environ['key'] = 'value'

    class TestCase(object):
        def get_params(self):
            return ['param1', 'param2']

        @property
        def prop(self):
            return 'property_value'

        @staticmethod
        def function():
            return 'method_value'

        def method(self):
            return 'method_value'

    test_case = TestCase()

    local_vars = {
        'x': 'x_value',
        'y': 'y_value',
        'test_case': test_case,
    }

    env_var = BaseVariable('os.environ')
    assert list(env_var.items(locals(), normalize=True)) == [('os.environ', "['key']")]

    global_v

# Generated at 2022-06-10 21:51:54.386932
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def __init__(self, source, exclude=()):
        self.source = source
        self.exclude = utils.ensure_tuple(exclude)
        self.code = compile(source, '<variable>', 'eval')
        if needs_parentheses(source):
            self.unambiguous_source = '({})'.format(source)
        else:
            self.unambiguous_source = source

    def __update__(self, **kwargs):
        for arg, value in kwargs.items():
            setattr(self, arg, value)

    def _items(self, main_value, normalize=False):
        result = [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

# Generated at 2022-06-10 21:51:57.070543
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('x', ['y'])
    indices2 = indices[::2]
    assert indices.source == indices2.source
    assert indices.exclude == indices2.exclude
    assert indices._slice == slice(None)
    assert indices2._slice == slice(None, None, 2)

# Generated at 2022-06-10 21:51:59.024611
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test_Indices=Indices("test_Indices",exclude="test_Indices")
    test_Indices[2:5]


# Generated at 2022-06-10 21:52:01.162158
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert list(Indices('foo')[2:5]._keys('abcd')) == [2,3,4]

# Generated at 2022-06-10 21:52:09.409942
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i1 = Indices('')
    assert i1[:] is i1
    i2 = Indices('x')
    assert i2[:] is i2
    i3 = i1[1:3]
    assert i3[:] is not i3
    assert i3[:] is i1[1:3]
    assert i3[1:3] is not i3
    assert i3[1:3] is not i1[1:3]
    assert i3[1:3] is i3



# Generated at 2022-06-10 21:52:13.811168
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from .frame import Frame
    frame = Frame('', inspect.currentframe())

    for i in range(1,10):
        for j in range(i, 10):
            for step in [-1, 1]:
                frame.f_locals['my_list'] = list(range(10))
                item = Indices('my_list')[i:j:step]
                assert item.items(frame)[1:] == [('my_list[{}]'.format(x), str(x)) for x in range(i, j, step)]


# Generated at 2022-06-10 21:52:16.372118
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')[1:3]

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:52:53.318474
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def items_test(name, source, normalize=False):
        with open(os.path.join(os.path.dirname(__file__), 'test_source', name)) as f:
            source = f.read()
        code = compile(source, '<variable>', 'exec')
        globs = {}
        eval(code, globs)
        var = globs['var']
        items = var.items(globs['frame'], normalize)
        if normalize:
            return repr(items)
        return repr(repr(items))

    assert os.path.exists(os.path.join(os.path.dirname(__file__), 'test_source'))
    for i in range(1000):
        assert items_test('CommonVariable.test_normalize.py', True).startswith

# Generated at 2022-06-10 21:52:56.927476
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('foo')
    result = indices[0:5]
    # Check the type of the result
    assert type(result) is Indices
    # Check the attributes of the result
    assert result.source == 'foo'
    assert result._slice == slice(0, 5)
    print('Passed!')


# Generated at 2022-06-10 21:53:00.112245
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    d = Indices('d')[1:3]
    assert 'd[1]' in d._keys
    assert 'd[2]' in d._keys


# Generated at 2022-06-10 21:53:11.342107
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import test_utils
    def f():
        a = 5
        b = 7
        return a, b
    frame, total_arguments = test_utils.call_and_capture(f)
    variable_name = 'a, b'
    variable = BaseVariable(variable_name)
    variable_items = variable.items(frame)
    assert variable_items == [(variable_name, '(5, 7)')]
    variable_name = 'a'
    variable = BaseVariable(variable_name)
    variable_items = variable.items(frame)
    assert variable_items == [(variable_name, '5')]
    variable_items = variable.items(frame, normalize=True)
    assert variable_items == [(variable_name, '5')]
    variable_name = 'b'
    variable = BaseVariable

# Generated at 2022-06-10 21:53:16.088546
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_frame():
        def func(x, y, z):
            return x, y, z
        x = y = z = 1
        frame = sys._getframe()
        return frame
    frame = test_frame()
    v = BaseVariable("func(x, y, z)", exclude=('x', 'y'))

# Generated at 2022-06-10 21:53:20.469533
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('', '')[1:3] == Indices('', '')
    assert Indices('', '')[0:0] == Indices('', '')


__all__ = ['Attrs', 'Keys', 'Indices', 'Exploding']

# Generated at 2022-06-10 21:53:32.530399
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    context = {'a': {'b': {'c': 'c'}, 'd': 'd'}, 'e': 'e'}
    frame = utils.SimpleFrame(context)
    #*******************************
    # Test for class Attrs, Keys and Indices
    #*******************************
    #test for class Attrs
    attrs_test_var = Attrs('a', exclude=('b', 'd'))
    print(attrs_test_var.items(frame))
    attrs_test_var = Attrs('a')
    print(attrs_test_var.items(frame))
    class A(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

# Generated at 2022-06-10 21:53:37.944128
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import frames
    v1 = BaseVariable('main_value')
    assert v1.items(frames.call(0)) == [('main_value', 'None')]

    v2 = BaseVariable('main_value')
    v2.items(frames.call(1))
    assert v2.items(frames.call(1)) == [('main_value', '1')]



# Generated at 2022-06-10 21:53:41.125414
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('a')[1:4]
    assert var._slice == slice(1,4)
    assert isinstance(var, Indices)

# Generated at 2022-06-10 21:53:44.049795
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  ind = Indices('i')[2:4]
  assert ind.source == 'i'
  assert ind._slice == slice(2, 4)

# Generated at 2022-06-10 21:54:43.867395
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test the method items() of class BaseVariable
    # Code to test
    frame = utils.Frame('frame')
    x = BaseVariable('', exclude='a')
    # Test
    assert x.items(frame) == ()



# Generated at 2022-06-10 21:54:49.797109
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')[2:5]
    items = a.items(None)
    assert items[0][1] == '[2]'
    assert items[-1][1] == '[5]'
    assert all(i[1] == '[{}]'.format(j) for i, j in zip(items, range(2, 6)))

# Generated at 2022-06-10 21:54:53.930768
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('../adapters/file/file.py')
    indices = indices[1:4]
    for item in indices._items(indices, True):
        print(item)


# Generated at 2022-06-10 21:54:58.179749
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable('var',exclude=[])
    assert(var.items([]) == tuple([(var.source, None)]))
    assert(var.__class__.__name__ == "BaseVariable")



# Generated at 2022-06-10 21:55:05.315951
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect

    class MyClass:
        a = 1
        b = 2

    my_obj = MyClass()

    obj = BaseVariable(source='my_obj', exclude='b')
    frame = inspect.currentframe()
    items = obj.items(frame)
    sys.stdout.write(str(items))
    assert items == [('my_obj', '<MyClass>'),
                     ('my_obj.a', '1')]

