

# Generated at 2022-06-10 21:45:25.383122
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class SubVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            pass

    assert SubVariable('foo') == SubVariable('foo')
    assert SubVariable('foo') != SubVariable('bar')
    assert SubVariable('foo', 'bar') != SubVariable('foo')
    assert SubVariable('foo', 'bar') != SubVariable('foo', 'baz')
    assert SubVariable('foo', 'bar') != SubVariable('foo', 'bar', 'baz')
    assert SubVariable('foo') != BaseVariable('foo')

# Generated at 2022-06-10 21:45:36.606402
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import utils
    import inspect
    import sys

    class Node(object):
        def __init__(self, name):
            self.name = name
            self.children = []

        def __repr__(self):
            return 'Node({})'.format(self.name)

        def __getstate__(self):
            return {'name': self.name, 'children': self.children}

        def __setstate__(self, d):
            self.__init__(d['name'])
            self.children = d['children']

        @property
        def parent(self):
            return self._parent

        @parent.setter
        def parent(self, value):
            self._parent = value
            self._parent.children.append(self)

    # Build a tree that looks like this:
    #

# Generated at 2022-06-10 21:45:40.796983
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    e = Indices('e')
    assert e[:2] is not e
    assert e[:2]._slice == slice(0, 2)
    assert e._slice == slice(None)

# Generated at 2022-06-10 21:45:42.165527
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    exp = Indices('a')[3:100:2]
    assert exp._fingerprint == ((Keys, 'a', ()), 'a', ()), 'Test failed'
    print('Method __getitem__: OK')

test_Indices___getitem__()

# Generated at 2022-06-10 21:45:46.557277
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable('QQQ')
    assert v == v
    assert v == BaseVariable('QQQ')
    assert v != 'QQQ'
    assert v != BaseVariable('XYZ')
    assert v != BaseVariable('QQQ', 'QQQ')
    assert v != BaseVariable('QQQ', 'XYZ')
    assert v != BaseVariable('QQQ', 'XYZ')



# Generated at 2022-06-10 21:45:56.982999
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # (self, source, exclude=()):
    """
    :param source:
    :param exclude:
    :return:
    """
    import sys
    import inspect
    import linecache
    current_frame = inspect.currentframe()
    outer_frames = inspect.getouterframes(current_frame)
    frame = outer_frames[1][0]

    variable = Attrs('variable', exclude=())
    variable.items(frame, normalize=False)
    variable.items(frame, normalize=True)

    variable = Keys('variable', exclude=())
    variable.items(frame, normalize=False)
    variable.items(frame, normalize=True)

    variable = Indices('variable', exclude=())
    variable.items(frame, normalize=False)
    variable.items(frame, normalize=True)

# Generated at 2022-06-10 21:46:04.133032
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    try:
        import numpy as np
    except ImportError:
        print('Please install numpy to test exploding in numpy arrays')
    else:
        from . import _render
        frame = utils.NestedDict(
            x=np.arange(100),
            y=np.arange(100)
        )
        result = _render.render_value(frame, 'x[::10]')
        assert result == '10\n20\n30\n40\n50\n60\n70\n80\n90'



# Generated at 2022-06-10 21:46:14.778541
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def check(expected, local_vars):
        frame = inspect.currentframe().f_back

        assert list(BaseVariable("a").items(frame, True)) == expected
        assert list(BaseVariable("a").items(frame)) == expected
        assert list(Attrs("a").items(frame, True)) == expected
        assert list(Attrs("a").items(frame)) == expected

        #var = Attrs('var')
        #print(var.unambiguous_source)
        #print(var.code)
        #print(var.source)
        #print(dir(var))

    class A(object):
        def __init__(self, b):
            self.b = b

    a = A(A(1))

    def f():
        return 1, {'a': 1}


# Generated at 2022-06-10 21:46:18.852518
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    idx = Indices('a')
    idx1 = idx[:]
    assert idx1.source == 'a[:]'
    idx2 = idx[1:]
    asser

# Generated at 2022-06-10 21:46:22.280420
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    var = BaseVariable("a")
    assert var.items(pycompat.FakeFrame(a = 'b')) == [('a', 'b')]



# Generated at 2022-06-10 21:46:36.726282
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from nose.tools import assert_equal
    from . import Variable, VariableArg
    a = Variable('a')[4:10]
    assert_equal(a.source, 'a[4:10]')
    assert_equal(a.unambiguous_source, 'a[4:10]')

    va = VariableArg([a, 'b', 5])
    assert_equal(va.args[0].source, 'a[4:10]')
    assert_equal(va.args[0].unambiguous_source, 'a[4:10]')
    assert_equal(va.args[1].source, 'b')
    assert_equal(va.args[1].unambiguous_source, 'b')
    assert_equal(va.args[2].source, '5')

# Generated at 2022-06-10 21:46:44.293169
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('x')[:] == Indices('x')[::] == Indices('x')[::1] == Indices('x')[::-1] == Indices('x') == Indices('x', exclude=())
    assert Indices('x')[::2] == Indices('x', exclude=(1,))
    assert Indices('x')[1::-1] == Indices('x', exclude=(0,))
    assert Indices('x')[1::2] == Indices('x', exclude=(0,))

# Generated at 2022-06-10 21:46:48.314697
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('x')
    b = BaseVariable('x')
    c = BaseVariable('y')
    assert(a == b)
    assert(a != c)


# Generated at 2022-06-10 21:46:57.028228
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('foo')
    assert(var.run() == [('foo[0]', ''), ('foo[1]', '')])
    copy = var[:]
    assert(isinstance(copy, Indices))
    copy[:] = ('a', 'b')
    assert(var.run() == [('foo[0]', ''), ('foo[1]', '')])
    assert(copy.run() == [('foo[0]', 'a'), ('foo[1]', 'b')])
    assert(var[:] is var)
    assert(var[:] is not copy)

# Generated at 2022-06-10 21:47:04.001063
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .frame import Frame
    from .context import Context
    from .color import AnsiColorizer
    from . import loader
    import sys
    import os
    c = Context()
    c.config['auto_var_explode'] = 3
    loader.load_plugins(c)
    c.config['auto_var_explode'] = 3
    AnsiColorizer.enabled = False
    c.config['print_heading'] = False

    def test(source_code, frame, event_index, expected_variable_values, excluded_variable_values=(), arg_names=[]):

        # Also tests method _items of claas BaseVariable
        actual_variable_values = BaseVariable().items(frame)
        assert actual_variable_values == expected_variable_values
        # Also tests method items of class VariableExplorer
        actual_variable_

# Generated at 2022-06-10 21:47:09.727330
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x', 'y') == BaseVariable('x', 'y')
    assert BaseVariable('x', 'y') != BaseVariable('x', 'z')
    assert BaseVariable('x', 'y') != BaseVariable('y', 'y')
    assert BaseVariable('x', 'y') != 1

# Generated at 2022-06-10 21:47:15.318416
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from os import path
    from inspect import Parameter
    b = BaseVariable('path.__file__')
    bb = BaseVariable('path.__file__')
    c = BaseVariable('path.__file__.b')
    d = Parameter('path.__file__')
    assert(b == bb)
    assert(b != c)
    assert(b != d)
    assert(c != d)
    assert(b == b)
    assert(c == c)
    assert(d == d)

# Generated at 2022-06-10 21:47:23.800525
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class DummyVariable(BaseVariable):
        def __init__(self, source):
            super(DummyVariable, self).__init__(source)
        def _items(self, key, normalize=False):
            pass
    v1 = DummyVariable('s1')
    v2 = DummyVariable('s2')
    assert v1 != v2
    assert v1 == DummyVariable('s1')
    assert len({v1, v1}) == 1
    assert len({v1, v2, DummyVariable('s1')}) == 2

# Generated at 2022-06-10 21:47:29.138490
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    b = BaseVariable('a')
    c = BaseVariable('b')
    assert a == b
    assert b == a
    assert a != c
    assert c != a
    assert a != "a"
    assert a != 1
    assert a != None
    assert a != {}
    assert a != []


# Generated at 2022-06-10 21:47:36.378075
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable_1 = BaseVariable('a', ('b', ))
    BaseVariable_2 = BaseVariable('a', ('b', ))
    BaseVariable_3 = BaseVariable('b', ('b', ))
    BaseVariable_4 = BaseVariable('b', ('a', ))
    BaseVariable_5 = BaseVariable('a', ('c', ))
    assert BaseVariable_1 == BaseVariable_2
    assert BaseVariable_1 != BaseVariable_3
    assert BaseVariable_1 != BaseVariable_4
    assert BaseVariable_1 != BaseVariable_5


# Generated at 2022-06-10 21:47:47.480921
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("var1", "exclude1")
    var2 = BaseVariable("var1", "exclude1")
    assert var1 == var2


# Generated at 2022-06-10 21:47:54.212437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    source = 'jig'
    exclude = ['ducks', 'pigs']
    base_variable = BaseVariable(source, exclude)
    base_variable_a = BaseVariable(source, exclude)
    assert base_variable == base_variable_a
    base_variable_b = BaseVariable(source, 'chickens')
    assert base_variable != base_variable_b

if __name__ == '__main__':
    test_BaseVariable___eq__()

# Generated at 2022-06-10 21:47:56.534691
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')[::-1]
    print(a.items('list'))

if __name__ == '__main__':
    test_Indices___getitem__()

# Generated at 2022-06-10 21:47:58.142338
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable('x')
    bv2 = BaseVariable('y')
    print(bv1 == bv2)


# Generated at 2022-06-10 21:48:01.657781
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('item')
    indices_pass = indices[:2]
    assert indices_pass._slice == slice(0, 2)


# Generated at 2022-06-10 21:48:14.837602
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def test_attrs(test_params):
        foo_attribute_1 = test_params[0]
        foo_attribute_2 = test_params[1]
        foo_attribute_3 = test_params[2]
        x = test_params[3]
        # We make x an object which has three attributes: attr1, attr2 and attr3.
        x.attr1 = foo_attribute_1
        x.attr2 = foo_attribute_2
        x.attr3 = foo_attribute_3

        # We create an Attributes variable with source 'x' and we check that the method
        # returns the tuple of items containing the relevant information.
        attrs = Attrs('x')
        var_items = attrs.items(locals())

        # We compute the expected set of items

# Generated at 2022-06-10 21:48:17.518688
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
  indices = Indices("x")
  slice = slice(2, 6, 3)
  indices = indices[slice]
  assert indices._slice == slice, "AssertionError: {} != {}".format(indices._slice, slice)


# Generated at 2022-06-10 21:48:28.931748
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv = BaseVariable('a','b')
    bv_same = BaseVariable('a','b')
    bv_different = BaseVariable('a','c')
    
    assert(bv == bv_same)
    assert(not bv == bv_different)
    assert(not bv == 'str')

    # test with subclass
    bv_sub = Attrs('a','b')
    bv_sub_same = Attrs('a','b')
    bv_sub_different1 = Attrs('a','b')
    bv_sub_different2 = Keys('a','b')

    assert(bv_sub == bv_sub_same)
    assert(not bv_sub == bv_sub_different1)
    assert(not bv_sub == bv_sub_different2)


# Generated at 2022-06-10 21:48:30.320575
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass



# Generated at 2022-06-10 21:48:41.188282
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from pdb import Pdb
    from io import StringIO

    class Pdb(Pdb):
        def __init__(self, *args, **kwargs):
            # We don't want to actually enter post-mortem debugging
            kwargs.update(skip=True)
            super(Pdb, self).__init__(*args, **kwargs)

    testing_locals = {
        'a': {'b': 'c', 'd': 'c'},
        'e': [{'f': 'g'}],
        'h': (1, '2', 3),
        'i': sum
    }

    class TestPdb(Pdb):
        def __init__(self, *args, **kwargs):
            kwargs.update(skip=True)
            super(TestPdb, self).__init__

# Generated at 2022-06-10 21:49:08.010248
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Test method __eq__
    """
    b1 = BaseVariable('test', exclude=('a', 'b'))
    b2 = BaseVariable('test', exclude=('a', 'b'))
    b3 = BaseVariable('test', exclude=('b', 'a'))
    b4 = BaseVariable('test', exclude=('a', ))
    b5 = BaseVariable('test', exclude=())
    b6 = BaseVariable('test')
    b7 = BaseVariable('test', exclude=('a', 'b'))
    b8 = BaseVariable('test', exclude=('b',))
    assert b1.__hash__() == b2.__hash__()
    assert b1.__eq__(b2) == b2.__eq__(b1)

# Generated at 2022-06-10 21:49:17.745305
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    class MyClass:
        def __init__(self, x):
            self.x = x
        def hello(self):
            return 'hello'
    names = {'c': MyClass(5)}
    names.update(sys.modules)
    d = {'a': 1, 'b': {'e': 5, 'f': MyClass(8)}}
    assert (BaseVariable('c').items(sys._getframe()) ==
            (('c', '<MyClass at 0x{:x}>'.format(id(names['c']))),
             ('c.hello', '<function hello at 0x{:x}>'.format(id(MyClass.hello))),
             ('c.x', '5')))

# Generated at 2022-06-10 21:49:28.438257
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable = BaseVariable('a', 'b')
    variable1 = BaseVariable('a', 'b')
    variable2 = BaseVariable('a', 'c')
    variable3 = BaseVariable('b', 'c')
    variable4 = BaseVariable('b', 'c')
    variable5 = BaseVariable('b', 'a')
    variable6 = BaseVariable('b', 'a')
    assert variable != variable1
    assert variable != variable2
    assert variable != variable3
    assert variable != variable4
    assert variable != variable5
    assert variable != variable6
    assert variable1 != variable2
    assert variable1 != variable3
    assert variable1 != variable4
    assert variable1 != variable5
    assert variable1 != variable6
    assert variable2 != variable3
    assert variable2 != variable4
    assert variable2 != variable5
    assert variable

# Generated at 2022-06-10 21:49:36.450249
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect

    class BaseVariable_test(BaseVariable):
        def __init__(self,source,exclude=()):
            super(BaseVariable_test,self).__init__(source,exclude)
        def _items(self,main_value,exclude=()):
            return ()

    def test_base_variable_items(source):
        def test_func(self,source=source):
            for k,v in self.base_variable.items(self.frame):
                pass

        test_func_code = test_func.__code__
        frame = types.FrameType(
            None, None,
            test_func_code.co_filename,
            test_func_code.co_name,
            test_func.__defaults__,
            None,
        )
        base_

# Generated at 2022-06-10 21:49:39.714931
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
   pass
   """
   ids = Indices('ids')
   a = [1, 2, 3, 4, 5]
   exp = [2, 3]
   ids._slice = slice(1, 3)
   assert ids._keys(a) == exp
   """

# Generated at 2022-06-10 21:49:49.871174
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    """
    Test method BaseVariable.__eq__().
    """
    source = 'a.b.c'
    exclude = ['b']

    # test equivalent objects
    var_0 = BaseVariable(source, exclude)
    var_1 = BaseVariable(source, exclude)
    assert (var_0 == var_1) == True

    # test different exclude
    var_1.exclude = ['c']
    assert (var_0 == var_1) == False

    # test different source
    var_1.source = 'a'
    var_1.exclude = exclude
    assert (var_0 == var_1) == False

    # test different type
    assert BaseVariable('a') == 'a' == False


# Generated at 2022-06-10 21:49:56.943617
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test the statement "return (isinstance(other, BaseVariable) and \
    # self._fingerprint == other._fingerprint)" in method __eq__ of class BaseVariable
    # Test a normal case
    BaseVariable1 = BaseVariable("abc")
    BaseVariable2 = BaseVariable("abc")
    assert BaseVariable1.__eq__(BaseVariable2) == True
    
    # Test a normal case
    BaseVariable1 = BaseVariable("abc")
    BaseVariable2 = BaseVariable("d")
    assert BaseVariable1.__eq__(BaseVariable2) == False
    
    

# Generated at 2022-06-10 21:50:00.850452
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable(source='__package__') == BaseVariable(source='__package__')
    assert not (BaseVariable(source='__package__') == BaseVariable(source='__name__'))
    assert not (BaseVariable(source='__package__') == 'string')

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-10 21:50:11.892401
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestVariable(BaseVariable):
        def __init__(self, source, exclude=(), attr=''):
            super(TestVariable, self).__init__(source, exclude)
            self.attr = attr

        @property
        def _fingerprint(self):
            return (type(self), self.source, self.exclude, self.attr)

    t1 = TestVariable('a', attr='a')
    t2 = TestVariable('a', attr='b')
    t3 = TestVariable('b', attr='a')
    t4 = TestVariable('a', attr='a')
    print(t1 == t2)
    print(t1 == t3)
    print(t1 == t4)


test_BaseVariable___eq__()

# Generated at 2022-06-10 21:50:13.875408
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('a')
    assert a.__eq__(BaseVariable('a')) == True

# Generated at 2022-06-10 21:50:53.472286
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert (BaseVariable('a') == BaseVariable('a'))
    assert (BaseVariable('a') == BaseVariable('a', exclude=('c',)))
    assert (BaseVariable('a', exclude=('c',)) == BaseVariable('a', exclude=('c',)))
    assert (BaseVariable('a') != BaseVariable('b'))
    assert (BaseVariable('a') != BaseVariable('a', exclude=('b',)))
    assert (BaseVariable('a') != BaseVariable('a', exclude=('a', 'b')))
    assert (BaseVariable('a', exclude=('c',)) != BaseVariable('a', exclude=('b',)))
    assert (BaseVariable('a', exclude=('c',)) != BaseVariable('a', exclude=('b', 'c')))


# Generated at 2022-06-10 21:51:05.615716
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import common
    import sys
    import subprocess

    # define a function to use for testing
    def test_func(x, y=1, z=3):
        return x

    def test_method(self, x, y=1, z=3):
        return x

    def test_lambda(x):
        return x

    # use inspect_variables to get items from a test_func
    frame = sys._getframe(0)
    v1 = common.local_variables(frame)['test_func']
    v2 = common.arguments(frame)['x']
    v3 = common.arguments(frame)['y']
    v4 = common.arguments(frame)['z']
    with pytest.raises(NotImplementedError):
        v1.items(frame)

# Generated at 2022-06-10 21:51:11.101089
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("1") == BaseVariable("1")
    assert BaseVariable("1") == BaseVariable("1",exclude="2")
    assert BaseVariable("1", exclude="2") == BaseVariable("1",exclude="2")
    assert not BaseVariable("1") == BaseVariable("2")
    assert not BaseVaria

# Generated at 2022-06-10 21:51:14.444144
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    with pytest.raises(NotImplementedError, match=r".*_items.*"):
        object.__eq__(BaseVariable(), BaseVariable())


# Generated at 2022-06-10 21:51:23.510917
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import sys
    code = types.CodeType(10, 0, 1, 0, "abcd", ("a", ), (None, ), (), "", "", 0, "", (), ())
    globals_ = {"code": code}
    frame = types.FrameType(None, globals_, "", ("code",), ())
    frame.f_code = code
    assert "code" in globals_
    
    test_variable = BaseVariable("a")
    items = test_variable.items(frame)
    assert (items == (('a', 'code'),))



# Generated at 2022-06-10 21:51:29.601009
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    sample_class1 = BaseVariable('p', ['key1'])
    sample_class2 = BaseVariable('p', ['key2'])
    assert(sample_class1 == sample_class1)
    assert(sample_class1 == BaseVariable('p', ['key1']))
    assert(sample_class1 != sample_class2)

# Generated at 2022-06-10 21:51:41.590007
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import types
    import itertools
    
    
    class Test():
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return 'Test<{}>'.format(self.name)
        def __repr__(self):
            return 'Test<{}>'.format(self.name)

        def test(self):
            return self.name

    t = Test('Leon')
    t1 = Test('Leon1')
    t2 = Test('Leon2')
    t3 = Test('Leon3')
    t.t1 = t1
    t.t2 = t2
    t.t3 = t3
    t.t4 = [t1, t2, t3]
    
    

    # Attrs

# Generated at 2022-06-10 21:51:54.644393
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Test 1: Two EmptyVariable
    assert EmptyVariable('abc') == EmptyVariable('abc')
    # Test 2: Two Attrs
    assert Attrs('abc') == Attrs('abc')
    # Test 3: Two Keys
    assert Keys('abc') == Keys('abc')
    # Test 4: Two Indices
    assert Indices('abc') == Indices('abc')
    # Test 5: Two Exploding
    assert Exploding('abc') == Exploding('abc')
    # Test 6: Two EmptyVariable with different source
    assert EmptyVariable('abc') != EmptyVariable('123')
    # Test 7: Two Attrs with different source
    assert Attrs('abc') != Attrs('123')
    # Test 8: Two Keys with different source
    assert Keys('abc') != Keys('123')
    # Test 9: Two Indices with different source


# Generated at 2022-06-10 21:52:00.407065
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('a', exclude='b')
    class Subclass(BaseVariable):
        def __init__(self):
            super(Subclass, self).__init__('a')
        pass
    assert BaseVariable('a') == Subclass()

# Generated at 2022-06-10 21:52:06.683570
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Test(BaseVariable):
        def _items(self, main_value, normalize=False):
            return ()
    t = Test('source')
    print(t == Test('source'))
    print(t == Test('source',exclude = 'a'))
    print(t == Test('source2',exclude = 'a'))
    print(t == Test('source',exclude = 'b'))


# Generated at 2022-06-10 21:53:17.203451
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import pdb as pdb_module
    import __builtin__
    class Pdb(pdb_module.Pdb):
        def __init__(self, *args, **kwargs):
            kwargs['completekey'] = kwargs.get('completekey', 'tab')
            pdb_module.Pdb.__init__(self, *args, **kwargs)
        def do_test(self, arg):
            return 'test'
        def postcmd(self, stop, line):
            return 2
        def parseline(self, line):
            return '', 'test', line

    class PdbOverrides(Pdb):
        def _get_c(self):
            return 't'
        def _set_c(self, value):
            pass

# Generated at 2022-06-10 21:53:22.880308
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    v = Indices('a')
    v1 = v[2:8:2]
    v2 = Indices('a')[2:8:2]
    assert v1 is not v2
    assert v1._slice == slice(2, 8, 2)
    assert v2._slice == slice(2, 8, 2)

# Generated at 2022-06-10 21:53:30.563476
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    A = BaseVariable('1==1')
    B = BaseVariable('2==2')
    C = BaseVariable('1==1')
    D = BaseVariable('1.2')

    assert (hash(A) == hash(B) and hash(B) == hash(C) and hash(C) == hash(A)
            and hash(D) == hash(D))
    assert (A == B and B == C and C == A and A == A and D == D)

# Generated at 2022-06-10 21:53:33.555483
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') != 'a'


# Generated at 2022-06-10 21:53:37.907440
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('A', exclude=['a'])
    # test case 1: no exclusion
    assert indices[1:3] == Indices('A', exclude=['a'])[1:3]
    # test case 2: with an exclusion
    assert indices[1:3] == Indices('A', exclude=['a'])[1:3]

# Generated at 2022-06-10 21:53:40.665856
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')[1:3]
    assert isinstance(a, Indices)



# Generated at 2022-06-10 21:53:50.825789
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    d={'b':'b'}
    c=['a','b','c']
    l=['a','b','c']
    base_var=BaseVariable('c')
    result=base_var.items(d)
    print(result)
    #my output is [('c', "['a', 'b', 'c']"), ('c[0]', "'a'"), ('c[1]', "'b'"), ('c[2]', "'c'")]
    #if not using eval,the output will be [('c', "['a', 'b', 'c']"), ('c[0]', 'a'), ('c[1]', 'b'), ('c[2]', 'c')]

# Generated at 2022-06-10 21:53:58.256964
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = Attrs('a')
    b = Attrs('a')
    c = Attrs('c')
    assert (a == b)
    assert (b == a)
    assert (a != c)
    assert (c != a)
    assert (b != c)
    assert (c != b)
    assert (a == a)
    assert (b == b)
    assert (c == c)
    assert (a == 'a.x')
    assert ('a.x' == a)


# Generated at 2022-06-10 21:54:06.670016
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    BaseVariable('main_value', 'exclude')
    #  test for different source
    assert not BaseVariable('main_value', 'exclude') == BaseVariable('main_value1', 'exclude')
    # test for different exclude
    assert not BaseVariable('main_value', 'exclude') == BaseVariable('main_value', 'exclude1')
    # test if all are the same
    assert BaseVariable('main_value', 'exclude') == BaseVariable('main_value', 'exclude')


# Generated at 2022-06-10 21:54:11.963758
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('source', exclude=('exclude',))
    result = variable[1:2]
    assert result.source == 'source'
    assert result.exclude == ('exclude',)
    assert result._slice == slice(1, 2)
    assert result._fingerprint == (Indices, 'source', ('exclude',))