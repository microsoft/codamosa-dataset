

# Generated at 2022-06-10 21:45:19.687437
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('Testing BaseVariable.__eq__')
    var1 = BaseVariable('a')
    var2 = BaseVariable('a')
    var3 = BaseVariable('b')
    var4 = BaseVariable('a', exclude=['b'])
    var5 = BaseVariable('a', exclude='b')
    assert var1 == var2
    assert var1 == var1
    assert not var1 == var3
    assert not var1 == var4
    assert var1 == var5



# Generated at 2022-06-10 21:45:28.664489
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("a.b", ('foo',))
    v2 = BaseVariable("a.b", ('foo',))
    assert v1 == v2

    v3 = BaseVariable("a.b", ('bar',))
    assert v1 != v3

    v4 = BaseVariable("c.d", ('foo',))
    assert v1 != v4

    v5 = BaseVariable("a.b", 'foo')
    assert v1 == v5

    v6 = BaseVariable("a.b")
    assert v1 != v6



# Generated at 2022-06-10 21:45:33.563036
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('main_value')

    # When
    result = indices[1:5]

    # Then
    assert isinstance(result, Indices)
    assert result.source == 'main_value'
    assert result._fingerprint == indices._fingerprint
    assert result._slice == slice(1, 5)

# Generated at 2022-06-10 21:45:43.940644
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    a = dict(key1 = "value1", key2 = "value2")
    b = dict(key3 = "value3", key4 = "value4")
    c = {"inner": b, "outer": a}
    frame = dict(a = a, b = b, c = c)
    print(Indices("c['inner'][0]").items(frame))
    print(Indices("c['inner']").items(frame))
    print(Indices("c").items(frame))
    print(Keys("c").items(frame))
    print(Indices("c[0]").items(frame))
    print(Indices("c").items(frame))

if __name__ == "__main__":
    test_BaseVariable_items()

# Generated at 2022-06-10 21:45:45.090446
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert not BaseVariable('a') == BaseVariable('a')


# Generated at 2022-06-10 21:45:54.851616
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')[2:4] == Indices('a')[slice(2,4)]
    assert Indices('a')[0:4] == Indices('a')[:4]
    assert Indices('a')[None:4] == Indices('a')[:4]
    assert Indices('a')[2:100] == Indices('a')[2:]
    assert Indices('a')[2:None] == Indices('a')[2:]
    assert Indices('a')[None:None] == Indices('a')
    assert Indices('a')[None:None:2] == Indices('a')[::2]

test_Indices___getitem__()

# Generated at 2022-06-10 21:46:03.153514
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from copy import copy
    from . import utils

    vars = [Attrs('foo'), Keys('foo'), Indices('foo'), Exploding('foo')]
    for vartype in vars:
        try:
            test_var = vartype['12:20']
            assert False
        except TypeError:
            pass
        new_var = vartype[12:20]
        assert isinstance(new_var, Indices)
        assert new_var._fingerprint[1:] == vartype._fingerprint[1:]
        assert new_var._slice == slice(12, 20)

    # copy
    d = {'foo': 42}
    k = Indices('foo')
    d2 = {'bar': 'baz'}
    k2 = k[:]
    k3 = k[12:20]

# Generated at 2022-06-10 21:46:05.042982
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    vars = Indices('x').items(None)
    assert vars == [('x', '[]')]


# Generated at 2022-06-10 21:46:10.942714
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable
    var2 = Keys
    var3 = Indices
    var4 = Attrs
    var5 = Exploding
    assert var1.__eq__(var2) == False
    assert var1.__eq__(var3) == False
    assert var1.__eq__(var4) == False
    assert var1.__eq__(var5) == False

# Generated at 2022-06-10 21:46:14.830258
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x', 'y') != BaseVariable('x')

# Generated at 2022-06-10 21:46:27.407837
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('test')
    assert a[2:6] == Indices('test', slice(2,6))
    assert a[:6] == Indices('test', slice(0,6))
    assert a[:] == Indices('test', slice(0,None))
    assert a[::4] == Indices('test', slice(0,None,4))
    assert a[2:6:2] == Indices('test', slice(2,6,2))



# Generated at 2022-06-10 21:46:30.746060
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    x = BaseVariable('x')
    y = BaseVariable('y')
    x1 = BaseVariable('x')
    assert x == x1
    assert x != y

test_BaseVariable___eq__()

# Generated at 2022-06-10 21:46:36.309743
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    from .test_tb_formatter import exception_with_extended_locals
    with exception_with_extended_locals() as (ex_type, ex_val, tb):
        debug_var = BaseVariable(source='a', exclude='b')
        items = debug_var.items(tb.tb_frame)
        for item in items:
            sys.stdout.write(str(item))



# Generated at 2022-06-10 21:46:48.365931
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import datetime
    from .utils import get_shortish_repr


# Generated at 2022-06-10 21:46:50.409159
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('request')
    var_slice = var[1:3]
    assert var_slice._slice == slice(1, 3)

# Generated at 2022-06-10 21:46:55.841588
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test 1
    test_sel = BaseVariable('x', exclude=())
    main_value = [1, 2, 3]
    # Try to run the method
    try:
        test_sel.items(main_value)
    except Exception as e:
        print('BaseVariable -> items: {}'.format(e))
        return



# Generated at 2022-06-10 21:47:03.448495
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    # use a list of numbers as test data
    indices = Indices("i")
    data = [1, 2, 3, 4, 5]
    # do a seris of tests
    test_cases = [
        (slice(1, 4, 2), ['i[1]', 2]),
        (slice(0, 4, 2), ['i[0]', 1]),
        (slice(1, 4, 1), ['i[1]', 2]),
        (slice(1, 4, -1), []),
        (slice(1, 4), ['i[1]', 2]),
        (slice(None, 1, None), ['i[0]', 1]),
    ]
    for slice, expected in test_cases:
        result = list(indices[slice].items(utils.FakeFrame(globals(), locals())))

# Generated at 2022-06-10 21:47:08.060647
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    bv = Indices('data')
    # Test if the item is a slice
    assert isinstance(bv[:], Indices)
    assert bv[:]._slice == slice(None)
    assert isinstance(bv[:2], Indices)
    assert bv[:2]._slice == slice(None, 2)


# Generated at 2022-06-10 21:47:10.578658
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices("a","b")
    print(ind._slice)
    print(ind[0:3]._slice)



# Generated at 2022-06-10 21:47:17.653372
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable(source=None)
    a.source = 1
    a.exclude = (1, 2, 3)
    a.unambiguous_source = None
    a.code = None
    # BaseVariable(object) has no _items() method, hence no _keys(), hence no _format_key().
    # BaseVariable(object) has no _get_value() method.
    # BaseVariable(object) has no _safe_keys() method.

    # Unit test for method __hash__ of class 
    def test_BaseVariable___hash__():
        a = BaseVariable(source=None)
        a.source = 1
        a.exclude = (1, 2, 3)
        a.unambiguous_source = None
        a.code = None
        # BaseVariable(object) has no _items() method,

# Generated at 2022-06-10 21:47:29.845713
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a.b') != BaseVariable('a.c')
    assert BaseVariable('a.b') != BaseVariable('a.b', exclude=['b'])
    assert BaseVariable('a.b', exclude=['b']) == BaseVariable('a.b', exclude=['b'])



# Generated at 2022-06-10 21:47:33.966585
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable("x", "d")
    var2 = BaseVariable("x", "d")
    var3 = BaseVariable("x", "c")

    assert(var1 == var2)
    assert(var3 != var1)
    assert(var3 != var2)



# Generated at 2022-06-10 21:47:38.932483
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    test = Indices('x', [])
    assert test[3:6] is not test
    assert test[3:6]._fingerprint == Indices('x', [])._fingerprint
    assert test[3:6]._slice == slice(3, 6)

# Generated at 2022-06-10 21:47:46.164662
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from .debugger import make_frame
    from .utils import get_random_python_path
    
    x = 4
    y = 5
    frame = make_frame(get_random_python_path())
    frame.f_locals['x'] = x
    xv = BaseVariable('x')
    xyv = BaseVariable('x,y')
    xyv._items(frame)
    xv.source
    #import pdb; pdb.set_trace()
    pass

# Generated at 2022-06-10 21:47:56.386580
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    array = [3,7,1,8,2,7,9]
    assert Indices('x')[2:5].items(None, None) == [
        ('x[2]', '1'),
        ('x[3]', '8'),
        ('x[4]', '2'),
    ]
    assert Indices('x')[3:].items(None, None) == [
        ('x[3]', '8'),
        ('x[4]', '2'),
        ('x[5]', '7'),
        ('x[6]', '9'),
    ]

# Generated at 2022-06-10 21:47:58.009782
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('x').__getitem__(2)
    assert isinstance(a, Indices)
    assert a._slice == slice(2)

# Generated at 2022-06-10 21:48:02.534133
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    i = Indices(source=1, exclude=2)
    j = i[1:]
    assert j._slice.start == 1
    assert j._slice.stop is None
    assert j._slice.step is None



# Generated at 2022-06-10 21:48:09.527222
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') == BaseVariable('a', 'b')
    assert BaseVariable('a') != BaseVariable('a', 'b')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')

# Generated at 2022-06-10 21:48:19.086621
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    variable1 = BaseVariable('x')
    variable2 = BaseVariable('y')
    variable3 = BaseVariable('x')
# variable1 != variable2
    if variable1 != variable2:
        print('SUCCESS: variable1 != variable2')
    else:
        print('FAILURE: variable1 != variable2')
# variable1 != variable3
    if variable1 != variable3:
        print('FAILURE: variable1 != variable3')
    else:
        print('SUCCESS: variable1 != variable3')
# variable3 == variable3
    if variable3 == variable3:
        print('SUCCESS: variable3 == variable3')
    else:
        print('FAILURE: variable3 == variable3')

# Generated at 2022-06-10 21:48:28.309801
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    b = BaseVariable("asd",exclude=())
    b_1 = BaseVariable("asd",exclude=())
    b_2 = BaseVariable("asdf",exclude=())
    b_3 = BaseVariable("asd",exclude=(1,2))
    def wrap_type(b):
        return (type(b), b.source, b.exclude)
    assert wrap_type(b) == wrap_type(b_1)
    assert wrap_type(b) != wrap_type(b_2)
    assert wrap_type(b) != wrap_type(b_3)

# Generated at 2022-06-10 21:48:43.202803
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') != BaseVariable('b')
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a') != BaseVariable('b', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')
    assert BaseVariable('a', 'b') != BaseVariable('a', ['c'])
    assert BaseVariable('a', 'b') == BaseVariable('a', ('b',))
    assert BaseVariable('a', ['b']) == BaseVariable('a', ('b',))
    assert BaseVariable('a', 'b') != BaseVariable('a', ['c'])
    assert not (BaseVariable('a') == 1)


# Generated at 2022-06-10 21:48:53.624168
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('base_variable')
    b = BaseVariable('base_variable')
    c = BaseVariable('base_variable')
    assert a == b == c
    assert not (a == b != c)
    assert hash(a) == hash(b) == hash(c)

    d = BaseVariable('b')
    e = BaseVariable('b')
    assert d is not e
    assert d == e

    f = BaseVariable('c', exclude=['d'])
    g = BaseVariable('c', exclude=['d'])
    assert f == g

    h = BaseVariable('d', exclude='e')
    i = BaseVariable('d', exclude='e')
    assert h == i


# Generated at 2022-06-10 21:48:56.137454
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import variables_for_tests

    for variable in variables_for_tests.__all__:
        var = getattr(variables_for_tests, variable)()
        var.items("")

# Generated at 2022-06-10 21:48:58.046866
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    pass
# vi: ts=4 sw=4 et ft=python

# Generated at 2022-06-10 21:49:03.922044
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('x')
    sub_x = x[3:]
    assert sub_x._slice == slice(3, None)
    assert sub_x.source == 'x'
    assert sub_x.exclude == ()
    assert sub_x.code == compile('x', '<variable>', 'eval')
    assert sub_x.unambiguous_source == 'x'


# Generated at 2022-06-10 21:49:11.378116
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    values = []
    a = {'one': 1}
    b = {'two': 2, 'three': 3}
    values = values + list(BaseVariable('a').items(locals()))
    values = values + list(BaseVariable('a', exclude=('one', 'two')).items(locals()))
    values = values + list(BaseVariable('b').items(locals()))
    values = values + list(BaseVariable('b', exclude=('two', 'three')).items(locals()))
    print(values)


# Generated at 2022-06-10 21:49:18.070915
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable("1", ("2",))
    v2 = BaseVariable("1", ("2",))
    assert v1 == v1
    assert v1 == v2
    assert v2 == v1

    v3 = BaseVariable("2", ("1",))
    assert v3 != v1

    v4 = BaseVariable("1", ("3",))
    assert v1 == v4

    v5 = BaseVariable("2", ("2",))
    assert v1 != v5

    v6 = BaseVariable("2", ("2",))
    assert v6 == v5

# Generated at 2022-06-10 21:49:22.735232
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('abc', 'edf')
    v2 = BaseVariable('abc', 'edf')
    v3 = BaseVariable('abc', 'def')

    assert v1.__eq__(v2)
    assert not v1.__eq__(v3)
    assert not v1.__eq__(1)

# Generated at 2022-06-10 21:49:26.209143
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import dis
    from .utils import get_bytecode

    assert dis.cmp_op[get_bytecode(lambda: compile("1+2", "<variable>", "eval"))[2][0][0]][4] == '<'

# Generated at 2022-06-10 21:49:34.436712
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class A(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = utils.ensure_tuple(exclude)
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def __eq__(self, other):
            return (isinstance(other, BaseVariable) and
                                           self._fingerprint == other._fingerprint)

    a = A('foo')
    b = A('bar')

    assert a == a
    assert a != b


# Generated at 2022-06-10 21:49:49.044454
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    instance = Indices("source",)
    assert isinstance(instance, Indices)
    slice1 = slice(1, 10, 1)
    result = instance.__getitem__(slice1)
    assert isinstance(result, Indices)
    assert(result._slice == slice1)

# Generated at 2022-06-10 21:49:58.411916
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    # Nominal case
    var1 = BaseVariable('x', 'y')
    var2 = BaseVariable('x', 'y')
    try:
        assert var1 == var2
    except AssertionError:
        print('Case failed : method __eq__ of class BaseVariable : nominal case failed')
        raise AssertionError

    # Assertion var1
    var3 = BaseVariable('x', 'z')
    try:
        assert var1 != var3
    except AssertionError:
        print('Case failed : method __eq__ of class BaseVariable : assertion var1 failed')
        raise AssertionError
    # Assertion var2
    var4 = BaseVariable('y', 'x')

# Generated at 2022-06-10 21:50:08.589168
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # test for a simple string
    str_x = "hello"
    var = BaseVariable("x")
    test_case = var.items(frame=None, normalize=False)
    assert test_case == (('x', "'hello'"),)

    # test for a long-length string
    random_str = "".join([random.choice(string.ascii_letters) for _ in range(1000)]) 
    var = BaseVariable("x")
    test_case = var.items(frame=None, normalize=False)
    assert test_case == (('x', "'{}'".format(random_str[:50])),)

    # test for a simple integer
    x = 5
    var = BaseVariable("x")
    test_case = var.items(frame=None, normalize=False)
   

# Generated at 2022-06-10 21:50:16.592297
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable('a', 'b')
    var2 = BaseVariable('a', 'b')
    var3 = BaseVariable('a', ['b'])
    var4 = BaseVariable('a', ('b'))
    var5 = BaseVariable('a')

    print(var1 == var2)
    print(var1 == var3)
    print(var2 == var3)
    print(var2 == var4)
    print(var3 == var4)
    print(var1 == var5)
    print(var4 == var5)

# Test for method __hash__ of class BaseVariable

# Generated at 2022-06-10 21:50:27.496991
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    from pprint import pprint
    from .utils import get_shortish_repr
    # Test __getitem__ of class Indices
    indices_source_01 = 's'
    indices_exclude_01 = ()
    indices_source_02 = 's'
    indices_exclude_02 = ()
    indices_01 = Indices(indices_source_01,indices_exclude_01)
    indices_02 = Indices(indices_source_02,indices_exclude_02)
    # Test __getitem__ of class Indices
    indices_01[0:3] = indices_02[0:3]
    print("indices_01._slice: ")
    pprint(indices_01._slice)
    print("indices_02._slice: ")

# Generated at 2022-06-10 21:50:30.262684
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable('a')
    assert v == BaseVariable('a')
    assert v != BaseVariable('b')
    assert v != BaseVariable('a', exclude='b')



# Generated at 2022-06-10 21:50:34.559302
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    var1 = BaseVariable(source='a', exclude='c')
    var2 = BaseVariable(source='a', exclude='b')
    var3 = BaseVariable(source='a', exclude='c')
    assert var1 == var3
    assert not var1 == var2


# Generated at 2022-06-10 21:50:40.113140
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("a") == BaseVariable("a")
    assert BaseVariable("a") == BaseVariable("a", ["b"])
    assert BaseVariable("a", ["b"]) == BaseVariable("a", ["b"])
    assert BaseVariable("a") != BaseVariable("b", ["b"])
    assert BaseVariable("a", ["b"]) != BaseVariable("b", ["b"])

# Generated at 2022-06-10 21:50:50.601710
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    from .constants import Test
    from .utils import get_shortish_repr
    from . import pycompat

    class TestVariable(BaseVariable):
        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    file_path = inspect.stack()[0].filename

    class TestDict(dict):
        pass

    class TestList(list):
        pass

    test_dict = TestDict({"k1": "v1", "k2": "v2", "k3": "v3"})
    test_dict['k4'] = "v4"
    test_dict_keys = ["k1", "k2", "k3", "k4"]



# Generated at 2022-06-10 21:50:54.022244
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    m = Indices("test")
    m[0:1]
    with pytest.raises(AssertionError):
        m[1]

# Generated at 2022-06-10 21:51:21.401853
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v1 = BaseVariable('1')
    v2 = BaseVariable('1')
    assert v1 == v2

    v3 = BaseVariable('1')
    v4 = BaseVariable('2')
    assert v3 != v4

    v5 = BaseVariable('1', exclude=['2'])
    v6 = BaseVariable('1', exclude=['2'])
    assert v5 == v6


# Generated at 2022-06-10 21:51:26.485896
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('{}', exclude=['a'])
    variable_items = variable.items(frame=None)
    variable_items2 = variable[2:4].items(frame=None)


if __name__ == '__main__':
    variable = Indices('{}', exclude=['a'])
    variable_items = variable.items(frame=None)
    variable_items2 = variable[2:4][5:7].items(frame=None)

# Generated at 2022-06-10 21:51:29.964666
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    source = ['A']
    # if 'A' in source, compile as <variable>
    variable = BaseVariable('A')
    variable.code = compile('A', '<variable>', 'eval')
    # test for items of variable
    assert variable.items(frame={'A': 1}) == ('A', '1')


# Generated at 2022-06-10 21:51:35.174382
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    variable = Indices('main_value')
    variable = variable[1:10:2]
    assert variable.code == compile('main_value[1:10:2]', '<variable>', 'eval')

if __name__=="__main__":
    test_Indices___getitem__()

# Generated at 2022-06-10 21:51:46.161778
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    import inspect
    from . import utils_test

    def test_function(a, b=1, *args, **kwargs):
        c = a + b
        for c in [c]:
            d = c + args[0]
            return d + kwargs.get('d')

    frame_info = inspect.getouterframes(inspect.currentframe())[1]

    test_attr = Attrs('a')
    test_index = Indices('b')
    test_key = Keys('kwargs')
    test_explode = Exploding('args')

    # frame = frame_info[0]
    frame = frame_info[0]
    test_attr_items = [i for i in test_attr.items(frame)]

# Generated at 2022-06-10 21:51:49.602527
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable('aaa')
    b = BaseVariable('aaa')
    assert a == b
    c = BaseVariable('bbb')
    assert a != c


# Generated at 2022-06-10 21:51:51.497417
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a')['b':'c'] is None

# Generated at 2022-06-10 21:51:57.240372
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable("x") == BaseVariable("x")
    assert BaseVariable("x") != BaseVariable("y")
    assert BaseVariable("x", exclude='__iter__') == BaseVariable("x", exclude='__iter__')
    assert BaseVariable("x", exclude='__iter__') != BaseVariable("x", exclude=('__iter__',))



# Generated at 2022-06-10 21:52:00.937269
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices("a")
    var1 = var[1:2]
    assert var != var1
    assert var.source == var1.source
    assert var1._fingerprint == (Indices, "a", ())

# Generated at 2022-06-10 21:52:10.981877
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import operator
    import sys
    import types

    class Foo(object):
        def __init__(self, x, s=None, foo=None):
            self.x = x
            self.s = s
            self.foo = foo

        def __str__(self):
            return 'Foo({})'.format(self.x)

        def __repr__(self):
            return '<Foo(x={}, s={})>'.format(self.x, self.s)

    class Bar(object):
        def __init__(self, x):
            self.x = x
        def __getattr__(self, name):
            if name == 's':
                return 'Bar.s'
            raise AttributeError


# Generated at 2022-06-10 21:52:57.628401
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    v = BaseVariable("kmer") 
    v1 = BaseVariable("kmer") 
    v2 = BaseVariable("kmer",("k","m")) 
    v3 = BaseVariable("k")

    assert v == v1
    assert not v == v2
    assert not v == v3
    v4 = BaseVariable("kmer",("k","m","n")) 
    assert not v == v4



# Generated at 2022-06-10 21:53:09.176045
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    frame = inspect.currentframe()
    source = ['foo.bar', 'foo[0]', 'foo.bar[0]', 'foo.bar.baz']
    foo = [0, 1, 2]
    foo.bar = [0]
    foo.bar.baz = 0
    for varaible in source:
        print ('------ for source:', varaible)
        print ('source:', varaible, 'items:', BaseVariable(varaible).items(frame))
    print ('------ test empty varaible')
    print ('source:', '', 'items:', BaseVariable('').items(frame))
    print ('------ test wrong varaible')
    print ('source:', 'foo(1)', 'items:', BaseVariable('foo(1)').items(frame))

# Generated at 2022-06-10 21:53:17.457852
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    c1 = CommonVariable('a.b.c')
    c2 = CommonVariable('a.b.c')
    c3 = CommonVariable('a.b.c', exclude=['a'])
    c4 = CommonVariable('a.b.c', exclude=['a'])
    c5 = CommonVariable('a.b.c', exclude=['b'])
    c6 = CommonVariable('a.b.c', exclude=['c'])
    c7 = CommonVariable('a.b.c', exclude=['a', 'b'])
    c8 = CommonVariable('a.b.c', exclude=['a', 'b'])

    assert(c1 == c2)
    assert(c3 == c4)
    assert(c7 == c8)

    assert(c1 != c3)

# Generated at 2022-06-10 21:53:23.091284
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert BaseVariable('a') == BaseVariable('a')
    assert BaseVariable('a.b') == BaseVariable('a.b')
    assert BaseVariable('a') != BaseVariable('a.b')
    assert BaseVariable('a', 'b') != BaseVariable('a')
    assert BaseVariable('a', 'b') != BaseVariable('a', 'c')

# Generated at 2022-06-10 21:53:25.675415
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('request')
    assert slices.Indices('request')[1:3]._slice == slice(1, 3)

# Generated at 2022-06-10 21:53:30.565135
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    #create instance of BaseVariable
    test1 = BaseVariable('a')
    test2 = BaseVariable('a')
    #test
    if test1.__eq__(test2):
        print('test: successfull')
    else:
        print('test: failed')

# Generated at 2022-06-10 21:53:39.849890
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():

    class Dummy(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    var1 = Dummy('x')
    var2 = Dummy('x')
    var3 = Dummy('y')
    var4 = Dummy('x', exclude='c')
    var5 = Dummy('x', exclude=['c'])

    assert var1 == var2, 'Unit test for BaseVariable failed'
    assert var2 == var1, 'Unit test for BaseVariable failed'
    assert not var1 != var2, 'Unit test for BaseVariable failed'
    assert not var2 != var1, 'Unit test for BaseVariable failed'

    assert var1 != var3, 'Unit test for BaseVariable failed'
    assert not var1 == var3, 'Unit test for BaseVariable failed'

    assert var4 == var5

# Generated at 2022-06-10 21:53:51.549307
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    print("Testing method __getitem__ of class Indices ...", end="")
    test_Indices = Indices("var", exclude=())
    assert test_Indices.source == "var"
    assert test_Indices.exclude == ()
    assert test_Indices._slice == slice(None)
    assert test_Indices._fingerprint == (Indices, "var", ())
    assert test_Indices.__hash__() == hash((Indices, "var", ()))
    assert test_Indices.__eq__(Indices("var", exclude=()))
    assert not test_Indices.__eq__(Indices("var1", exclude=()))
    assert not test_Indices.__eq__(Indices("var", exclude=(1,)))
    assert not test_Indices.__eq__(object())

# Generated at 2022-06-10 21:53:55.672018
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    iv = Indices('foo')
    iv_slice = iv[1:]
    # Check whether method __getitem__ of class Indices can realize slice '1:'
    assert(iv_slice._slice == slice(1, None, None))


# Generated at 2022-06-10 21:53:57.858150
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    b = a[:]
    assert a[1:] == b
    assert type(a[1:]) == Indices

# Generated at 2022-06-10 21:54:43.437869
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    def f(x):
        return x + 1
    source = 'f.__code__.co_code'
    var = BaseVariable(source)
    var.items()
    source = 'f.__globals__[\'f\']'
    var = BaseVariable(source)
    var.items()

# Generated at 2022-06-10 21:54:55.517121
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # Test for class CommonVariable
    # Test for class Attrs
    class TestClass(object):
        def __init__(self, a=1, b=2):
            self.a = a
            self.b = b
            self.c = [1, 2]


    test_class = TestClass()
    attrs = Attrs('test')
    assert attrs.items(test_class) == [('test', 'test_class'),
                                       ('test.__dict__', '{}'),
                                       ('test.a', '1'),
                                       ('test.b', '2'),
                                       ('test.c', '[1, 2]')]

    attrs = Attrs('test', exclude='c')

# Generated at 2022-06-10 21:54:57.110590
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    # TODO: write test code
    pass


# Generated at 2022-06-10 21:54:59.859897
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('dict_')
    assert var['new_slice'] == slice('new_slice')

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-10 21:55:05.848303
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect

    frame = inspect.currentframe()
    f_locals = frame.f_locals

    local_var = Variable('local_var', exclude=['private_var'])
    for key, value in local_var.items(frame):
        print(key)
        print(value)
        print()

    member_var = Variable('member_var', exclude=['private_var'])
    for key, value in member_var.items(frame):
        print(key)
        print(value)
        print()

    items_var = Variable('items_var', exclude=['private_var'])
    for key, value in items_var.items(frame):
        print(key)
        print(value)
        print()

