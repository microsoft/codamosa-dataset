

# Generated at 2022-06-10 21:45:18.137333
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices('a')
    a_slice = a[:]
    assert a._slice == slice(None)
    assert a_slice._slice == slice(None)
    a[2:5]
    assert a._slice == slice(2,5)
    assert a_slice._slice == slice(None)

# Generated at 2022-06-10 21:45:21.212248
# Unit test for constructor of class Attrs
def test_Attrs():
    x = Attrs('_')
    assert x.source == '_'
    assert x.exclude == ()
    assert x.code == compile('_', '<variable>', 'eval')
    assert x.unambiguous_source == '_'

# Generated at 2022-06-10 21:45:33.011416
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    frame = utils.FakeFrame(locals())
    mapping1 = {'key1': 1, 'key2': 2, 'key3': 3}
    mapping2 = {'key1': 1, 'key2': 2, 'key3': 3, 'key4': 4}
    assert Keys('mapping1').items(frame) == [('mapping1', '{}'), ('mapping1[key1]', '1'), ('mapping1[key2]', '2'), ('mapping1[key3]', '3')]

# Generated at 2022-06-10 21:45:44.195492
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class VariableTest(BaseVariable):
        def __init__(self, source, exclude=()):
            self.source = source
            self.exclude = exclude
            self.code = compile(source, '<variable>', 'eval')
            if needs_parentheses(source):
                self.unambiguous_source = '({})'.format(source)
            else:
                self.unambiguous_source = source

        def items(self, frame, normalize=False):
            return []

    var1 = VariableTest('var1')
    var2 = VariableTest('var2')
    assert var1 != var2
    assert not var1 == var2
    var3 = Attrs('attr')
    assert var1 != var3
    assert not var1 == var3
    var4 = VariableTest('var1')
    assert var1

# Generated at 2022-06-10 21:45:51.339889
# Unit test for constructor of class CommonVariable
def test_CommonVariable():
    assert CommonVariable('this') != CommonVariable('that')
    assert CommonVariable('this') == CommonVariable('this')
    assert CommonVariable('this', exclude=['x']) == CommonVariable('this', exclude=['x'])
    assert CommonVariable('this', exclude=['x']) == CommonVariable('this', exclude=('x',))
    assert CommonVariable('this', exclude=['x']) != CommonVariable('this', exclude=['y'])
    assert CommonVariable('this', exclude=['x']) != CommonVariable('this', exclude=[])

# Generated at 2022-06-10 21:45:59.521958
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    import pytest
    from .utils import get_shortish_repr
    from .variables import Indices
    # __getitem__ does not exist in class Attrs and Keys
    with pytest.raises(AttributeError):
        attrs = Attrs('A').__getitem__(slice(4))
    with pytest.raises(AttributeError):
        attrs = Keys('A').__getitem__(slice(4))
    # __getitem__ works well   
    assert Indices('A')[slice(0, 2)].items({'A': [1,2,3]}) == [('A[0]', get_shortish_repr(1)), ('A[1]', get_shortish_repr(2))]



# Generated at 2022-06-10 21:46:10.561621
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    from . import protocol
    from . import pycompat
    from .utils import shortish_repr


# Generated at 2022-06-10 21:46:24.233289
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys, os
    # case 1: a variable with no attributes
    # expected output: ('x', x's repr)
    x = 1
    assert BaseVariable('x').items(sys._getframe())[0][0] == 'x'

    # case 2: a variable with attributes
    # expected output: ('x', x's repr), ('x.a', x.a's repr), ('x.__dict__.items', x.__dict__.items's repr)
    x = types.SimpleNamespace(a = 1)
    y = types.SimpleNamespace(b = 1)
    x.__dict__ = y
    result = BaseVariable('x').items(sys._getframe())
    assert ("x" == result[0][0])
    assert (".a" == result[1][0][-2:])

# Generated at 2022-06-10 21:46:32.092557
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    v = Attrs('p')
    assert v.items(dict(p=dict(a=1, b=2))) == [
        ('p', '<dict>'),
        ('p.a', '1'),
        ('p.b', '2')
    ]

    assert v.items(dict(p=dict(a=1, b=2), a=[1,2,3])) == [
        ('p', '<dict>'),
        ('p.a', '1'),
        ('p.b', '2')
    ]
    
    


# Generated at 2022-06-10 21:46:39.342866
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    f_locals = locals()
    assert BaseVariable('__builtins__').items(f_locals) == (
        ('__builtins__', utils.get_shortish_repr(__builtins__)),
    )
    assert BaseVariable('__builtins__.len').items(f_locals) == (
        ('__builtins__.len', utils.get_shortish_repr(__builtins__.len)),
    )
    assert BaseVariable('__builtins__.len(__builtins__)').items(f_locals) == (
        ('__builtins__.len(__builtins__)', utils.get_shortish_repr(__builtins__.len(__builtins__))),
    )
    


# Generated at 2022-06-10 21:46:57.284653
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import io
    import io
    import _io
    frameinfo = inspect.getframeinfo(inspect.currentframe())
    current_frame = inspect.currentframe()
    a = io.BytesIO()
    a.write(b'abc')
    a.seek(0)
    a.name = 'test.txt'
    a.buffer.raw._base = '123'
    a.buffer.raw.name = current_frame.f_code.co_filename
    a.buffer.raw.tell()
    a.buffer.raw.tell()
    a.buffer.raw.tell()
    a.buffer.raw.close()
    a.buffer.raw.closed
    current_frame.f_code.co_filename


# Generated at 2022-06-10 21:46:59.121811
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import sys
    src = "sys.modules['loguru']"
    variable = BaseVariable(src)
    print(variable.items(sys._getframe()))



# Generated at 2022-06-10 21:47:01.052785
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('a').__getitem__(slice(1,3))._slice == slice(1,3)


# Generated at 2022-06-10 21:47:05.269598
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class TestBaseVariable(BaseVariable):
        def _items(self, key, normalize=False):
            pass
    var_one = TestBaseVariable()
    var_two = TestBaseVariable()
    assert var_one == var_two

# Generated at 2022-06-10 21:47:08.429186
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('var[1]')
    assert var[2:5] == Indices('var[1]', exclude=()).__getitem__(slice(2,5))


# Generated at 2022-06-10 21:47:14.704884
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    a = Indices("args")
    a_slice = a[1:3]
    assert a_slice.source == "args"
    assert a_slice._slice == slice(1, 3)
    a_slice = a[1:]
    assert a_slice._slice == slice(1, None)
    a_slice = a[:3]
    assert a_slice._slice == slice(None, 3)
    a_slice = a[:]
    assert a_slice._slice == slice(None)

# Generated at 2022-06-10 21:47:27.432679
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import doctest
    doctest.testmod()
    assert BaseVariable('x') == BaseVariable('x')
    assert BaseVariable('x')[:] == BaseVariable('x')[:]
    assert BaseVariable('x') != BaseVariable('y')
    assert BaseVariable('x')[:] != BaseVariable('x')
    assert BaseVariable('x') != BaseVariable('x', exclude='y')
    assert BaseVariable('x') != BaseVariable('x.y')
    assert BaseVariable('x') != BaseVariable('x[y]')
    assert BaseVariable('x') != BaseVariable('x.y', exclude='z')
    assert BaseVariable('x') != BaseVariable('x[y]', exclude='z')
    assert BaseVariable('x.y') != BaseVariable('x[y]')
    assert BaseVariable('x.y', exclude='z')

# Generated at 2022-06-10 21:47:30.398682
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    var = Indices('', exclude=())
    var = var[1:3]
    assert var._slice.start == 1 and var._slice.stop == 3

test_Indices___getitem__()

# Generated at 2022-06-10 21:47:32.019229
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('my_dict')[1:3]
    assert ind._slice == slice(1,3,None)

# Generated at 2022-06-10 21:47:43.948922
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a1 = BaseVariable('level_name')
    a2 = BaseVariable('level_name', 'empty_field')
    a3 = BaseVariable('level_name', ('empty_field',))
    a4 = BaseVariable('level_name', (int(1.0),))
    a5 = BaseVariable('level_name', int(1.0))
    b = BaseVariable('level_name')
    c = BaseVariable('level_name', ('empty_field',))
    d = BaseVariable('level_name')

# Generated at 2022-06-10 21:47:57.908752
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Cls(BaseVariable):
        def _items(self, key, normalize=False):
            pass
    v1 = Cls('a','b')
    v2 = Cls('a','b')
    assert v1 == v2

# Generated at 2022-06-10 21:48:01.912555
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert isinstance(Indices("x")[3:5], Indices)
    assert isinstance(Indices("x")[1:], Indices)
    assert isinstance(Indices("x")[:5], Indices)

# Generated at 2022-06-10 21:48:07.172888
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class Foo(BaseVariable):
        pass

    class Bar(BaseVariable):
        pass

    var1 = Foo(None, None)
    var2 = Bar(None, None)
    assert var1 == var1
    assert var2 == var2
    assert not var1 == var2

# Generated at 2022-06-10 21:48:11.798169
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('main_value')
    assert x._slice == slice(None)
    y = x[1:3]
    assert x._slice == slice(None)
    assert y._slice == slice(1,3)

# Generated at 2022-06-10 21:48:17.862850
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    class BaseVar(BaseVariable):
        def __init__(self, source):
            self.source = source

        def _items(self, main_value, normalize=False):
            return [(self.source, utils.get_shortish_repr(main_value, normalize=normalize))]

    Variable1 = BaseVar('main_value')
    frame = get_frame_object()
    frame.f_locals['main_value'] = 2
    assert Variable1.items(frame) == [('main_value', '2')]



# Generated at 2022-06-10 21:48:27.801269
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices_0_4 = Indices('', [])[:4]
    assert indices_0_4._fingerprint == (Indices, '', ())
    assert indices_0_4._slice == slice(0, 4)
    indices_5_9 = Indices('', [])[5:10]
    assert indices_5_9._fingerprint == (Indices, '', ())
    assert indices_5_9._slice == slice(5, 10)
    indices_5_5 = Indices('', [])[5:5]
    assert indices_5_5._fingerprint == (Indices, '', ())
    assert indices_5_5._slice == slice(5, 5)

# Generated at 2022-06-10 21:48:32.678299
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('test')
    assert indices._slice == slice(None)
    assert isinstance(indices[slice(1, 2)], Indices)
    assert indices[slice(1, 2)]._slice == slice(1, 2)
    assert indices[slice(1, 2)]._fingerprint[2] == (slice(1, 2), )
    assert indices[slice(1, 2)]._fingerprint[1] == 'test'


# Generated at 2022-06-10 21:48:40.812725
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    from .utils import ensure_tuple

    """
    Method __eq__ of BaseVariable should return True for variables with the same 'source' and 'exclude'
    parameters and of the same type.
    """
    class CustomVariable(BaseVariable):
        def _items(self, key, normalize=False):
            return []
        
    s = "source"
    ex = ("a", "b", "c")
    v1 = CustomVariable(s, ex)
    v2 = CustomVariable(s, ex)
    assert v1 == v2



# Generated at 2022-06-10 21:48:42.796900
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    a = BaseVariable("source")
    b = BaseVariable("source")
    assert a.__eq__(b)


# Generated at 2022-06-10 21:48:49.110422
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    indices = Indices('lst[0]')
    slice_ = slice(0, 2, None)
    result = indices[slice_]
    expected = '[0, 1]'
    assert result._slice == slice_, 'AssertionError: %s != %s' % (result._slice, slice_)
    assert str(result._slice) == expected, 'AssertionError: %s != %s' % (str(result._slice), expected)

# Generated at 2022-06-10 21:49:30.714093
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    x = Indices('a')
    assert x[:] == Indices('a', slice(None))
    assert x[1:3] == Indices('a', slice(1, 3))
    assert x[:] is not Indices('a')

# Generated at 2022-06-10 21:49:39.580935
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    ind = Indices('x')[1:3]
    assert ind.code == compile('x', '<variable>', 'eval')
    assert ind.source == 'x'
    assert ind.unambiguous_source == 'x'
    assert not ind.exclude
    assert ind._keys(['0', '1', '2', '3', '4']) == [1, 2]
    assert ind._slice == slice(1, 3, None)
    assert ind._format_key(0) == '[0]'
    assert ind._get_value(['0', '1', '2', '3', '4'], 1) == '1'

# Generated at 2022-06-10 21:49:45.724149
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    class AClass(BaseVariable):
        def _items(self, key, normalize=False):
            pass

    from nose import with_setup
    from nose.tools import assert_equals

    # setup
    base_variable2 = AClass("hello")

    # test
    assert_equals(base_variable2 == base_variable2, True)


# Generated at 2022-06-10 21:49:55.111805
# Unit test for method __getitem__ of class Indices
def test_Indices___getitem__():
    assert Indices('1')[:] == Indices('1[:]')
    assert Indices('1')[::] == Indices('1[::]')
    assert Indices('1')[1:] == Indices('1[1:]')
    assert Indices('1')[:2] == Indices('1[:2]')
    assert Indices('1')[1:2] == Indices('1[1:2]')
    assert Indices('1')[1::2] == Indices('1[1::2]')

if __name__ == '__main__':
    # Unit test of method __getitem__ of class Indices
    test_Indices___getitem__()
    print('Unit test of method __getitem__ of class Indices is finished.')

# Generated at 2022-06-10 21:49:58.297710
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    bv1 = BaseVariable("a")
    bv2 = BaseVariable("a")
    bv3 = BaseVariable("a.b")

    assert (bv1 == bv2) == True
    assert (bv2 == bv3) == False


# Generated at 2022-06-10 21:50:01.301391
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    assert Indices('x') == Indices('x')
    assert Indices('x') != Indices('y')
    assert Indices('x', exclude=['a']) != Indices('x')
    assert Indices('x') != Attrs('x')

# Generated at 2022-06-10 21:50:03.450011
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    print('testing __eq__...')
    # todo: implement unit test: BaseVariable.__eq__
    print('OK')


# Generated at 2022-06-10 21:50:13.248318
# Unit test for method __eq__ of class BaseVariable
def test_BaseVariable___eq__():
    import random
    
    BaseVariable_instance_0 = BaseVariable(
        'x',
        exclude=['x']
    )
    BaseVariable_instance_1 = BaseVariable(
        'x',
        exclude=['x']
    )
    assert BaseVariable_instance_0 == BaseVariable_instance_1

    BaseVariable_instance_0 = BaseVariable(
        'x',
        exclude=['x']
    )
    BaseVariable_instance_1 = BaseVariable(
        'x',
        exclude=['y']
    )
    assert BaseVariable_instance_0 != BaseVariable_instance_1

    # __ne__ = lambda self, other: not self == other



# Generated at 2022-06-10 21:50:21.436361
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import types
    import inspect
    import sys

    class A: pass
    a = A()
    a.b = 1
    a.c = 2
    a.d = '3'

    def test_func(a):
        frame = inspect.currentframe()
        # print('f_locals:', frame.f_locals)
        # print('f_globals:', frame.f_globals)

        # 'source' is a string that indicates the varible you want to get the items from
        # 'exclude' is a string or tuple of strings indicating the varible or collection of variables that you don't want to see
        # The following test would return a list of tuples
        # The first element of each tuple is the variable name
        # The second element of each tuple is the variable value

# Generated at 2022-06-10 21:50:29.990387
# Unit test for method items of class BaseVariable
def test_BaseVariable_items():
    import inspect
    import linecache
    def get_caller_frame():
        caller_frame = inspect.currentframe().f_back
        while caller_frame.f_back:
            caller_frame = caller_frame.f_back
        return caller_frame
    frame = get_caller_frame()
    print(frame)
    linecache.checkcache()
    filename = frame.f_code.co_filename
    co = frame.f_code
    start_line = co.co_firstlineno
    end_line = start_line + co.co_lnotab.count(b'\n')
    print(filename, start_line, end_line)
    linecache.updatecache(filename)
    print(linecache.getlines(filename))

    from .utils import get_caller_frame