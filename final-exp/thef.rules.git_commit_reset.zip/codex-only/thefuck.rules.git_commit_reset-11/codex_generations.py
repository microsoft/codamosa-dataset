

# Generated at 2022-06-24 06:24:58.450807
# Unit test for function match
def test_match():
    assert match('git commit -a')
    assert match('git commit')
    assert not match('git status')
    assert not match('git commit -am "Тут кирилица и пробелы"')


# Generated at 2022-06-24 06:25:00.383521
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert not match(Command('git commit -m message', '', r'fatal: need merge (HEAD or --all) and commit'))

# Generated at 2022-06-24 06:25:05.630004
# Unit test for function match
def test_match():
    command = Command('', '')
    # check that it fails if there is no 'commit' word in the command
    command.script_parts = ['git', 'add', 'index.py']
    assert not match(command)

    # check that it passes if there is a 'commit' word in the command
    command.script_parts = ['git', 'commit', '-am', '"new commit"']
    assert match(command)


# Generated at 2022-06-24 06:25:07.282432
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test commit"', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:08.591511
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit --message "hello"')
    assert 'git reset HEAD~' == get_new_command(command)

# Generated at 2022-06-24 06:25:10.192203
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert (get_new_command(Command('git commit', '')) ==
            'git reset HEAD~')



# Generated at 2022-06-24 06:25:12.546536
# Unit test for function match
def test_match():
    assert (match(Script('git commit', '')))
    assert not (match(Script('git status', '')))


# Generated at 2022-06-24 06:25:16.588077
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', None))
    assert match(Command('git stash commit', '', None))
    assert match(Command('git commit -C HEAD', '', None))
    assert match(Command('git stash', '', None)) is False


# Generated at 2022-06-24 06:25:18.862996
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit')) != 'git reset HEAD'

# Generated at 2022-06-24 06:25:20.908026
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit") == "git reset HEAD~"
    assert get_new_command("git commit -m 'test'") == "git reset HEAD~"

# Generated at 2022-06-24 06:25:24.379230
# Unit test for function get_new_command
def test_get_new_command():
    command_git = Command('git commit -m "test"', '', '')
    assert get_new_command(command_git) == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:25.415040
# Unit test for function get_new_command

# Generated at 2022-06-24 06:25:27.526928
# Unit test for function match
def test_match():
    assert match(Command('git commit -a', '', ''))
    assert not match(Command('git push origin master', '', ''))


# Generated at 2022-06-24 06:25:30.044826
# Unit test for function match
def test_match():
    assert(match(Command('git commit -m "message"')))
    assert(not match(Command('git help')))
    assert(match(Command('git commit -a')))


# Generated at 2022-06-24 06:25:31.206320
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git reset HEAD~' == get_new_command(Command('git commit'))

# Generated at 2022-06-24 06:25:35.020347
# Unit test for function match
def test_match():
    assert match(Command('git commit --amend'))
    assert match(Command('git commitmsg -f'))
    assert not match(Command('git branch -f'))


#Unit test for function get_new_command

# Generated at 2022-06-24 06:25:36.498613
# Unit test for function match
def test_match():
    assert (match(Command('git commit -m hello world', '',
                         '/root/repo')))



# Generated at 2022-06-24 06:25:38.593115
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m msg', '', 0, '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:43.192381
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "commit"') == 'git reset HEAD~'
    assert get_new_command('git commit -m') == ''
    

# Generated at 2022-06-24 06:25:46.750243
# Unit test for function match
def test_match():
    command = Command('git commit')
    assert match(command)
    command = Command('git commit --amend')
    assert match(command)
    command = Command('git commit -m "commit"')
    assert match(command)
    command = Command('git log')
    assert not match(command)



# Generated at 2022-06-24 06:25:49.874737
# Unit test for function get_new_command
def test_get_new_command():
    # Valid type of command
    command = Command('git commit -m "test"')
    assert get_new_command(command) == 'git reset HEAD~'

    # Invalid type of command
    command = Command('test')
    assert get_new_command(command) == command.script



# Generated at 2022-06-24 06:25:51.555906
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "message"', '', '')) == 'git reset HEAD~'



# Generated at 2022-06-24 06:25:54.284650
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git commit -m", "git commit -m test")) == "git reset HEAD~"
    assert get_new_command(Command("g commit", "g commit -m")) == "git reset HEAD~"

# Generated at 2022-06-24 06:25:56.670620
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))

# Generated at 2022-06-24 06:25:59.952911
# Unit test for function match
def test_match():
    assert match(Command('commit', '', '/bin/ls'))
    assert not match(Command('commit', '', '/bin/ls'))


# Generated at 2022-06-24 06:26:02.434376
# Unit test for function match
def test_match():
    assert match(Command('git commit -am "new commit"', '',
                         '/usr/bin/git config --get user.email', 0))



# Generated at 2022-06-24 06:26:07.070992
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('ls', '', '/usr/bin/ls'))


# Generated at 2022-06-24 06:26:08.293889
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -a') == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:12.756672
# Unit test for function match
def test_match():
	assert match(Command('git commit', 'git commit'))
	assert match(Command('git commit', None))
	assert not match(Command('git add', None))
	assert not match(Command('git push', None))
	assert not match(Command('git merge', None))
	assert not match(Command('git checkout', None))


#Unit test for function get_new_command

# Generated at 2022-06-24 06:26:14.358125
# Unit test for function match
def test_match():
    command = Command(script='git commit -m "The message"')
    assert match(command)



# Generated at 2022-06-24 06:26:16.241305
# Unit test for function match
def test_match():
    assert match('git commit')
    assert match('git commit -m "my message"')
    assert not match('git add .')


# Generated at 2022-06-24 06:26:17.780040
# Unit test for function get_new_command
def test_get_new_command():
    assert "git reset HEAD~" == get_new_command("git commit")

# Generated at 2022-06-24 06:26:21.086455
# Unit test for function get_new_command
def test_get_new_command():
    git_command = "git commit -m 'added new test files'"
    assert git_support(git_command)
    assert 'git reset HEAD~' == get_new_command(git_command)

# Generated at 2022-06-24 06:26:23.336670
# Unit test for function match
def test_match():
    assert (match(Command('commit', '', '/bin/ls')))
    assert (not match(Command('pull', '', '/bin/ls')))


# Generated at 2022-06-24 06:26:29.117719
# Unit test for function match
def test_match():
    assert match(Command())
    assert not match(Command('pwd'))
    assert match(Command('git commit'))


# Generated at 2022-06-24 06:26:33.955386
# Unit test for function match
def test_match():
    # Test 1
    command = Command(script='git commit', stderr='', stdout='')
    assert match(command) is True

    # Test 2
    command = Command(script='commit', stderr='', stdout='')
    assert match(command) is False



# Generated at 2022-06-24 06:26:38.305944
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m"Fixed all bugs"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit ')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:39.559321
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:41.267324
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:26:44.621742
# Unit test for function match
def test_match():
    assert_true(match(Command('git commit')))
    assert_true(match(Command('git commit -am "first commit"')))
    assert_false(match(Command('git commit -am "first commit"', 'cd /home/me/myrepo')))



# Generated at 2022-06-24 06:26:47.725693
# Unit test for function match
def test_match():
    # Test 1 for when git commit command goes wrong
    assert match(Command('git commit'))
    # Test 2 for when git commit command is correct
    assert not match(Command('git commit -m "something"'))

# Generated at 2022-06-24 06:26:49.749247
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/tmp')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:52.253661
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git ', ''))
    assert not match(Command('commit', ''))



# Generated at 2022-06-24 06:26:53.750585
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('git commit -m "test"') == 'git reset HEAD~')

# Generated at 2022-06-24 06:26:57.759392
# Unit test for function match
def test_match():
    from thefuck.specific.git import git_support
    from thefuck.types import Command
    assert match(Command('git commit', '', ''))
    assert not match(Command('git log'))


# Generated at 2022-06-24 06:27:01.250958
# Unit test for function match
def test_match():
    import os
    assert match(Command(script='git commit'))
    assert not match(Command(script='commit'))
    assert not match(Command(script='foo'))


# Generated at 2022-06-24 06:27:05.951345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/tmp/')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:27:07.703971
# Unit test for function match
def test_match():
    command = Command('git commit')
    assert(match(command))



# Generated at 2022-06-24 06:27:14.594896
# Unit test for function get_new_command
def test_get_new_command():
    command_git_cancel = Command('git commit -m "first commit"', '', 0, '')
    assert get_new_command(command_git_cancel) == 'git reset HEAD~'
    command_git_cancel2 = Command('git commit -m "secound commit"', '', 0, '')
    assert get_new_command(command_git_cancel2) == 'git reset HEAD~'
    command_git_cancel3 = Command('git commit --message "first commit"', '', 0, '')
    assert get_new_command(command_git_cancel3) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:15.089343
# Unit test for function match

# Generated at 2022-06-24 06:27:17.431403
# Unit test for function match
def test_match():
    assert match(Command(script='commit', stderr="fatal: Unable to create '/root/dew/.git/index.lock': File exists.\n"))

# Generated at 2022-06-24 06:27:19.773016
# Unit test for function get_new_command
def test_get_new_command():
    assert('git reset HEAD~') == get_new_command(Command('git commit'))


# Generated at 2022-06-24 06:27:21.825041
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit -m 'Added hello.txt'", "", 0)
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:23.791622
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command('git commit', '')),
                  'git reset HEAD~')



# Generated at 2022-06-24 06:27:26.573119
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert match(Command('git cOmmit'))
    assert not match(Command('git'))
    assert not match(Command('commit'))


# Generated at 2022-06-24 06:27:27.741617
# Unit test for function match
def test_match():
    assert match('git status')
    assert not match('ls')


# Generated at 2022-06-24 06:27:31.100838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "Test"') == 'git reset HEAD~'
    assert get_new_command('git commit - m "Test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "Test" && git push -u origin master') == 'git reset HEAD~ && git push -u origin master'

# Generated at 2022-06-24 06:27:32.362684
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:27:38.916912
# Unit test for function match
def test_match():
    """
    Unit test for match()
    """
    c = Command("git commit hello world", "")
    assert match(c) is True
    c = Command("git commit", "")
    assert match(c) is True
    c = Command("git reset HEAD~", "")
    assert match(c) is False
    c = Command("git push", "")
    assert match(c) is False


# Generated at 2022-06-24 06:27:44.253309
# Unit test for function match
def test_match():
    assert(match(Command('git commit', '', '')) == True)
    assert(match(Command('git commit -a', '', '')) == True)
    assert(match(Command('a', '', '')) == False)
    assert(match(Command('git diff', '', '')) == False)
    assert(match(Command('git', '', '')) == False)



# Generated at 2022-06-24 06:27:45.822465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:49.895176
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit',
                                   'git: \'commit\' is not a git command. See \'git --help\'.')) == 'git reset HEAD~'
    assert get_new_command(Command('gitl commit',
                                   'git: \'commit\' is not a git command. See \'git --help\'.')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:57.425864
# Unit test for function match
def test_match():
    command = Command('git commit')
    assert match(command)
    command = Command('git commit -a')
    assert not match(command)
    command = Command('git commit -a --verbose')
    assert not match(command)
    command = Command('git commit --allow-empty')
    assert match(command)
    command = Command('git commit --get-regexp')
    assert not match(command)
    command = Command('git commit --gpg-sign=0x12345678')
    assert match(command)

# Unit tests for function get_new_command

# Generated at 2022-06-24 06:27:59.858794
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commitm', '', '/tmp'))

# Generated at 2022-06-24 06:28:01.457844
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'



# Generated at 2022-06-24 06:28:03.286467
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'git commit '
    new_cmd = get_new_command(cmd)
    assert new_cmd == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:04.542477
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp/'))


# Generated at 2022-06-24 06:28:06.038820
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/home/xyz/')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:07.815468
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('commit', '', '/tmp'))

# Generated at 2022-06-24 06:28:09.168942
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "hello" file1 file2',
                      '', '', '', 4, None)
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:11.484984
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('commit') == 'git reset HEAD~'
    assert get_new_command('commit -a') == 'git reset HEAD~'

# match function unit test

# Generated at 2022-06-24 06:28:13.746160
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "foo"', '', '/bin/git'))
    assert not match(Command('git reset HEAD~', '', '/bin/git'))

# Generated at 2022-06-24 06:28:19.257960
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit index.html',
                                   'git commit index.html\nerror: pathspec'
                                   ' \'index.html\' did not match any file(s) '
                                   'known to git.\nfatal: cannot do a partial '
                                   'commit during a merge.\n')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:28:21.411081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git add foo', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:29.615835
# Unit test for function match
def test_match():
    assert match(Command(script='git commit',
                    stderr='''error: failed to push some refs to 'https://github.com/nghiattran/test.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.'''))

# Generated at 2022-06-24 06:28:32.009081
# Unit test for function match
def test_match():
    assert match(Command('git commit', None))
    assert match(Command('git commit something', None))
    assert not match(Command('git', None))

# Generated at 2022-06-24 06:28:34.038776
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git', '', ''))


# Generated at 2022-06-24 06:28:38.506348
# Unit test for function get_new_command
def test_get_new_command():

    from thefuck.specific.git import git_support
    command = Command('commit -am "Some commit message"', '',
        script_parts=['git', 'commit', '-am', 'Some commit message'])

    assert git_support(command) is True
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:41.005379
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit -m 'some Message'") == "git reset HEAD~"
    assert get_new_command("git commit") == "git reset HEAD~"

# Generated at 2022-06-24 06:28:42.288781
# Unit test for function match
def test_match():
    assert match(Command('commit',
                         'git commit -m "KABOOOM!"'))



# Generated at 2022-06-24 06:28:44.320656
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "bye"', 'traceback')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:45.538090
# Unit test for function match
def test_match():
    assert match(Command('git commit'))



# Generated at 2022-06-24 06:28:49.742656
# Unit test for function match
def test_match():
    new_command_1 = 'git commit -m "some message"'
    new_command_2 = 'git branch'
    assert match(Command(new_command_1))
    assert not match(Command(new_command_2))


# Generated at 2022-06-24 06:28:51.052963
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "Mensagem Teste"') == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:52.305765
# Unit test for function match
def test_match():
    assert git.match("git commit -m message")
    assert git.match("git commit")



# Generated at 2022-06-24 06:28:54.399504
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit --help', '', '/bin/git'))


# Generated at 2022-06-24 06:29:00.490761
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit file1 file2') == 'git reset HEAD~'
    assert get_new_command('git commit -m message file1 file2') == 'git reset HEAD~'
    assert get_new_command('git commit -m message file1 file2 --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'


# Generated at 2022-06-24 06:29:05.293455
# Unit test for function get_new_command
def test_get_new_command():
    # Unit test 1
    command_one = Command('git commit --amend --no-edit', '', '')
    assert get_new_command(command_one) == 'git reset HEAD~'

    # Unit test 2
    command_two = Command('git commit --amend --no-edit', '', '')
    assert get_new_command(command_two) == 'git reset HEAD~'

# Generated at 2022-06-24 06:29:06.942608
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit lala.txt") == "git reset HEAD~"

# Generated at 2022-06-24 06:29:13.048166
# Unit test for function get_new_command
def test_get_new_command():
    # command = Command('git commit -m "test"')
    # assert get_new_command(command) == 'git reset HEAD~'
    pass



# Generated at 2022-06-24 06:29:20.824399
# Unit test for function get_new_command
def test_get_new_command():
    command_git_uncommit = Command("git status", "git: 'uncommit' is not a git command. See 'git --help'.")
    command_git_commit = Command("git commit", "On branch master\nYour branch is up to date with 'origin/master'.\n\nnothing to commit, working tree clean")
    command_git_commit_m = Command("git commit -m", "On branch master\nYour branch is up to date with 'origin/master'.\n\nnothing to commit, working tree clean")
    command_git_commit_amend = Command("git commit --amend", "On branch master\nYour branch is up to date with 'origin/master'.\n\nnothing to commit, working tree clean")

# Generated at 2022-06-24 06:29:24.375429
# Unit test for function get_new_command
def test_get_new_command():
    test_command1 = 'git commit'
    assert match(test_command1) is True
    assert get_new_command(test_command1) == 'git reset HEAD~'

    test_command2 = 'cd /home/michael/Desktop; ls -l; git commit'
    assert match(test_command2) is False
    assert get_new_command(test_command2) == 'cd /home/michael/Desktop; ls -l; git reset HEAD~'

# Generated at 2022-06-24 06:29:33.233177
# Unit test for function match
def test_match():
    assert_true(match(Command('git commit', '')))
    assert_true(match(Command('git commit -a', '')))
    assert_true(match(Command('git commit --amend', '')))
    assert_true(match(Command('git commit --dry-run', '')))
    assert_true(match(Command('git commit --no-dry-run', '')))
    assert_true(match(Command('git commit --status', '')))
    assert_true(match(Command('git commit --no-status', '')))
    assert_true(match(Command('git commit -m', '')))
    assert_true(match(Command('git commit -m ""', '')))
    assert_true(match(Command('git commit -m "foo"', '')))

# Generated at 2022-06-24 06:29:34.771232
# Unit test for function match
def test_match():
    assert match('git commit -m "my first commit"')


# Generated at 2022-06-24 06:29:43.839279
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git commit', 'git commit', 'git commit')) == 'git reset HEAD~'
    assert get_new_command(
        Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(
        Command('asdf git commit', 'asdf git commit', 'asdf git commit')) == 'git reset HEAD~'
    assert get_new_command(
        Command('git commit -m "commit message"', 'git commit -m "commit message"', 'git commit -m "commit message"')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:29:45.371177
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "message"') == 'git reset HEAD~'



# Generated at 2022-06-24 06:29:50.696168
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command( "git commit -m 'The message of a commit'" ) \
	== "git reset HEAD~"
    assert get_new_command( "git commit -m The message of a commit" ) \
	== "git reset HEAD~"
    assert get_new_command( "git commit" ) \
	== "git reset HEAD~"
    assert not get_new_command( "git" )
    assert not get_new_command( "commit" )

# Generated at 2022-06-24 06:29:52.627433
# Unit test for function match
def test_match():
    command = Command('git commit')
    assert match(command)

    command = Command('git commit --amend')
    assert not match(command)



# Generated at 2022-06-24 06:29:54.514082
# Unit test for function match
def test_match():
    command=Command('git commit 5678')
    assert match(command)


# Generated at 2022-06-24 06:29:57.707639
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m', '', ''))
    assert not match(Command('git  commit', '', ''))
    assert not match(Command('git  commit -m', '', ''))



# Generated at 2022-06-24 06:30:00.563394
# Unit test for function match
def test_match():
    command = Command("git commit -m 'foo'", "")
    assert match(command)

    command = Command("git add .", "")
    assert not match(command)


# Generated at 2022-06-24 06:30:02.405096
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit hello') == 'git reset HEAD~'
    assert get_new_command('git commit hello') == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:04.745666
# Unit test for function match
def test_match():
    assert match(Command('git commit --amend', ''))
    assert not match(Command('ls -la', ''))


# Generated at 2022-06-24 06:30:08.602201
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', ''))
    assert not match(Command('git add .', ''))
    assert not match(Command('git reset HEAD~', ''))


# Generated at 2022-06-24 06:30:13.613934
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -ma "asd"',
                      'error: please tell me who you are.\nRun git config --global user.email "you@example.com"\nRun git config --global user.name "Your Name"\nTo set your account\'s default identity.\nOmit --global to set the identity only in this repository.')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:16.791541
# Unit test for function get_new_command
def test_get_new_command():
    # Test normal case
    assert get_new_command('git commit -m') == 'git reset HEAD~'

    # Test failure case
    assert get_new_command('gits commit -m') == ''

# Generated at 2022-06-24 06:30:19.872544
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit file1 file2 file3')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:23.876808
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command_auto_correct = 'git reset HEAD~'
    command = Command('commit -m "First commit"', '/usr/bin/git commit -m "First commit"')
    assert(get_new_command(command) ==  get_new_command_auto_correct)

# Generated at 2022-06-24 06:30:25.853710
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git reset HEAD~' == get_new_command(Command(script='git commit', stderr='error: empty commit message'))

# Generated at 2022-06-24 06:30:27.459964
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit -m 'test'")
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:30.141379
# Unit test for function match
def test_match():
	assert match(Command('git commit', ''))
	assert match(Command('commit', ''))
	assert not match(Command('git commit --amend', ''))
	assert not match(Command('git commit -a', ''))
	assert not match(Command('git commit -m "hello"', ''))


# Generated at 2022-06-24 06:30:33.753844
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m')
    assert get_new_command(command) == 'git reset HEAD~'
    command = Command('commit -m')
    assert get_new_command(command) == 'reset HEAD~'


# Generated at 2022-06-24 06:30:34.833344
# Unit test for function match
def test_match():
    assert GitReset(None).match('''
    git commit --amend
    ''')


# Generated at 2022-06-24 06:30:38.869101
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert match(Command('git commit -m "test"'))
    assert match(Command('git commit -m test'))
    assert not match(Command('git commit -a'))
    assert not match(Command('commit'))


# Generated at 2022-06-24 06:30:41.046938
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"',  None))
    assert not match(Command('git log', None))


# Generated at 2022-06-24 06:30:44.616280
# Unit test for function match
def test_match():
    # testing for match function
    assert match(Command('git commit', '', '', 3, 3)) == True
    assert match(Command('git commit -m "Message"', '', '', 3, 3)) == True
    assert match(Command('git log', '', '', 3, 3)) == False


# Generated at 2022-06-24 06:30:49.679067
# Unit test for function match
def test_match():
    test1 = Command('git commit -m "message"',
                    'On branch master\n'
                    'Untracked files:\n'
                    '\t.gitignore\n'
                    '\t.travis.yml\n'
                    '\tlicence.license\n'
                    'nothing added to commit but untracked files present\n')
    assert match(test1)



# Generated at 2022-06-24 06:30:56.791501
# Unit test for function match
def test_match():
    command = Command('git commit file -m "Message"')
    assert match(command) == True
    command = Command('git commit --amend -m "Message"')
    assert match(command) == True
    command = Command('git commit --amend --no-edit')
    assert match(command) == True
    command = Command('git log')
    assert match(command) == False
    command = Command('git add file && git commit -m "Message"')
    assert match(command) == True
    command = Command('git add file && git commit file -m "Message"')
    assert match(command) == True
    command = Command('git add file && git commit file --amend -m "Message"')
    assert match(command) == True
    command = Command('git add file && git commit file --amend --no-edit')

# Generated at 2022-06-24 06:30:58.436924
# Unit test for function match
def test_match():
    command_input = Command('git commit', '', None)
    assert(not match(command_input))


# Generated at 2022-06-24 06:31:01.880794
# Unit test for function match
def test_match():
    assert match(Command('git commit -a', ''))
    assert not match(Command('git pull', ''))
    assert not match(Command('git commit -m', ''))
    assert not match(Command('git push', ''))


# Generated at 2022-06-24 06:31:03.222357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:11.704663
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "fix #420"', '', 0)
    assert get_new_command(command) == 'git reset HEAD~'

    command = Command('git commit', '', 0)
    assert get_new_command(command) == 'git reset HEAD~'

    command = Command('git commit', '', 0)
    assert get_new_command(command) == 'git reset HEAD~'

    command = Command('git commit -a', '', 0)
    assert get_new_command(command) == 'git reset HEAD~'

    command = Command('git commit -am', '', 0)
    assert get_new_command(command) == 'git reset HEAD~'

    command = Command('git commit -am "fix #420"', '', 0)

# Generated at 2022-06-24 06:31:13.714244
# Unit test for function get_new_command
def test_get_new_command():
    assert_equal('git reset HEAD~',get_new_command(Command('git commit','')))

# Generated at 2022-06-24 06:31:16.626768
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-24 06:31:21.609476
# Unit test for function get_new_command
def test_get_new_command():
    command_list = [
        "git commit",
        "git commit -a",
        "git commit -v"
    ]
    new_command_list = [
        "git reset HEAD~",
        "git reset HEAD~",
        "git reset HEAD~"
    ]
    for command, new_command in zip(command_list, new_command_list):
        assert (get_new_command(Command(command)) == new_command)


# Generated at 2022-06-24 06:31:25.096492
# Unit test for function match
def test_match():
    assert match(Command(script='git commit -m'))
    assert match(Command(script='git commit --amend'))
    assert match(Command(script='git commit -am'))


# Generated at 2022-06-24 06:31:27.639406
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/'))
    assert not match(Command('git commit', '', '/'))


# Generated at 2022-06-24 06:31:29.069068
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit file') == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:30.830777
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("commit -m 'Some message'", "")
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:31:33.687728
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
    Command('git commit -m "initial commit"',
    '',
    'fatal: please supply the commit message using either -m or -F option\n')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:37.985746
# Unit test for function match
def test_match():
    assert match(Command('git commit foobar', '', '', 1, None))
    assert not match(Command('git checkout HEAD~', '', '', 1, None))
    assert not match(Command('git branch', '', '', 1, None))


# Generated at 2022-06-24 06:31:40.007307
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -a -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:42.597070
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert not match(Command('git add'))


# Generated at 2022-06-24 06:31:44.935004
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit --amend -m 'hello'", "")
    print(get_new_command(command))



# Generated at 2022-06-24 06:31:47.144233
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'


# Generated at 2022-06-24 06:31:48.433160
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:58.611443
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit -m hello", "", "/root", "")
    assert get_new_command(command) == "git reset HEAD~"

    command = Command("git commit -m hello", "", "/root", "")
    assert get_new_command(command) == "git reset HEAD~"

    command = Command("git commit -m hello", "", "/root", "")
    assert get_new_command(command) == "git reset HEAD~"

    command = Command("git add hello.py", "", "/root", "")
    assert get_new_command(command) is None

# Generated at 2022-06-24 06:32:03.587016
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/home'))
    assert not match(Command('git reset', '', '/home'))
    assert not match(Command('git commit', '', '/home'))


# Generated at 2022-06-24 06:32:07.834408
# Unit test for function match
def test_match():
    assert match(Command("git commit", "git commit -m \"first commit\""))
    assert match(Command("git commit -m \"first commit\"", "git commit -m \"first commit\""))
    assert not match(Command("git commit", ""))
    assert not match(Command("git commit -m \"first commit\"", ""))
    assert not match(Command("git commit", "git commit -m \"first commit\"\ngit push"))


# Generated at 2022-06-24 06:32:09.986617
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("git commit -m 'test'"))=='git reset HEAD~')


# Generated at 2022-06-24 06:32:11.377632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command) == 'git reset HEAD~'



# Generated at 2022-06-24 06:32:12.902924
# Unit test for function match
def test_match():
    res = match(command = Command('git commit -am "abc"'))
    assert res == True


# Generated at 2022-06-24 06:32:22.786721
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="git commit --amend",
    stdout=r'fatal: commit is not possible because you have unmerged files.\n'
    'please, fix them up in the work tree, and then use '
    'git add/rm <file>... as appropriate to mark resolution, '
    'or use git commit -a',
    stderr='''fatal: commit is not possible because you have unmerged files.\n'''
    '''please, fix them up in the work tree, and then use '''
    '''git add/rm <file>... as appropriate to mark resolution, '''
    '''or use git commit -a''')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:25.277869
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("gigt commit -m ''") == 'git reset HEAD~'
    assert get_new_command("gigt commit") == 'git reset HEAD~'


# Generated at 2022-06-24 06:32:26.772895
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command('git commit -m "test test"') == 'git reset HEAD~')

# Generated at 2022-06-24 06:32:28.862365
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "hotfix: text" ') == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:31.643578
# Unit test for function match
def test_match():
    # Test when function match should return False
    assert not match(Command())

    # Test when function match should return True
    command = Command('git commit', '')
    assert match(command)
    command = Command('git commit', '')
    assert match(command)


# Generated at 2022-06-24 06:32:35.687339
# Unit test for function match
def test_match():
    # Make sure that match does not return True if "commit" is not in the
    # script_parts list
    assert(match(Command('git log', "")) is False)
    # Make sure that match returns True if "commit" is in the script_parts
    assert(match(Command('git commit', "")) is True)

# Generated at 2022-06-24 06:32:36.932565
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:41.225821
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "fail"'))
    assert match(Command('git commit -m fail'))
    assert not match(Command('git commit'))
    assert not match(Command('git add'))
    assert not match(Command('commit'))


# Generated at 2022-06-24 06:32:50.409010
# Unit test for function match
def test_match():
    # simple string
    assert match(Command('git commit -F tmpfile'))

    # string with space
    assert match(Command('git commit -a -m "fixed this and this"'))

    # string with double quote
    assert match(Command('git commit -a -m "fixed this and this'))

    # string with escaped double quote
    assert match(Command('git commit -a -m \"fixed this and this'))

    # string with back slash
    assert match(Command('git commit -a -m C:\\temp'))

    # string with escaped back slash
    assert match(Command('git commit -a -m C:\\temp'))

    # string with single quote
    assert match(Command('git commit -a -m \'fixed this and this'))

    # string with escaped single quote

# Generated at 2022-06-24 06:32:51.905741
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "yo"') == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:55.903024
# Unit test for function get_new_command
def test_get_new_command():
    assert_equals(get_new_command(Command(script='git commit -am "test"',
                                          stderr='error: src refspec master does not match any')),
                  'git reset HEAD~')


# Generated at 2022-06-24 06:33:01.446673
# Unit test for function match
def test_match():
    # GIVEN: the class GitCommand
    # WHEN: we call match(GitCommand('git commit'))
    # THEN: we must return True
    assert match(Command('git commit'))
    
    # GIVEN: the class GitCommand
    # WHEN: we call match(GitCommand('git reset'))
    # THEN: we must return False
    assert match(Command('git reset'))



# Generated at 2022-06-24 06:33:09.091266
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('git commit', env={'HOME': '/home/mjheagle'})) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "hello"', env={'HOME': '/home/mjheagle'})) == 'git reset HEAD~'
    assert get_new_command(Command('git commit foo', env={'HOME': '/home/mjheagle'})) == 'git reset HEAD~'
    assert get_new_command(Command('git commit --amend', env={'HOME': '/home/mjheagle'})) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:11.700949
# Unit test for function match
def test_match():
    assert match(Command('git commit', '/home/fakedir')) is True
    assert match(Command('git commit -m "my first commit"', '/home/fakedir')) is True

# Generated at 2022-06-24 06:33:14.491284
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "an initial commit"')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:22.511881
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git config core.editor') == 'git reset HEAD~'
    assert get_new_command('git commit -m') == get_new_command('git commit')
    assert get_new_command('git commit -m') == 'git reset HEAD~'
    assert get_new_command('git commit -m"foo') == 'git reset HEAD~'
    assert get_new_command('git commit -m ') == 'git reset HEAD~'
    assert get_new_command('git commit -m "foo') == 'git reset HEAD~'
    assert get_new_command('git commit -m "foo bar') == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:24.881947
# Unit test for function match
def test_match():
    assert match(Command('commit'))
    assert match(Command('commit -a'))
    assert not match(Command('git commit'))



# Generated at 2022-06-24 06:33:26.908427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m someMessage')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:29.234349
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git', 'commit', '-m "My commit"')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:33:34.589107
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit --amend')) == 'git reset HEAD~'
    assert get_new_command(Command(script='git ci --amend')) == 'git reset HEAD~'
    assert get_new_command(Command(script='git ci --amend -m blah blah blah')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:36.520794
# Unit test for function match
def test_match():
    assert match("git commit")
    assert not match("python test.py")


# Generated at 2022-06-24 06:33:39.915107
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git push', '', '/usr/bin/git'))
    assert not match(Command('commit', '', '/usr/bin/git'))


# Generated at 2022-06-24 06:33:41.009128
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', ''))


# Generated at 2022-06-24 06:33:42.770229
# Unit test for function match
def test_match():
    assert match(Command('git commit -a', ''))
    assert match(Command('git commit .', ''))



# Generated at 2022-06-24 06:33:44.185084
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command("git commit") == 'git reset HEAD~')


# Generated at 2022-06-24 06:33:45.799171
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:48.197460
# Unit test for function get_new_command
def test_get_new_command():
    script = "git commit -m 'Add hello' --amend; git commit --amend"
    assert get_new_command(Command('commit', script=script)) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:49.476526
# Unit test for function match
def test_match():
	assert match(Command('git commit',''))


# Generated at 2022-06-24 06:33:55.606705
# Unit test for function match
def test_match():
    assert(match(Command('git commit -am "message" ')) == True)
    assert(match(Command('git commit -am "message" ', None)) == True)
    assert(match(Command('git commit -am "message" ', None, None)) == True)
    assert(match(Command('echo commit', None, None)) == False)
    assert(match(Command('commit', None, None)) == False)


# Generated at 2022-06-24 06:33:59.057651
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert match(Command('git commit -v'))
    assert not match(Command('commit'))


# Generated at 2022-06-24 06:34:01.514320
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit',
        stderr='fatal: empty commit message')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:03.177811
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:04.343036
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:08.985492
# Unit test for function match
def test_match():
    command = Command("commit -a -m 'message'")
    assert match(command) == True
    command = Command("git commit -a -m 'message'")
    assert match(command) == True
    command = Command("git add . & git commit -m 'message'")
    assert match(command) == True
    command = Command("git status")
    assert match(command) == False
    command = Command("git add . & git commit")
    assert match(command) == False


# Generated at 2022-06-24 06:34:12.166600
# Unit test for function match
def test_match():
    assert git_support(match)(Command('git commit',''))
    assert not git_support(match)(Command('git add',''))
    assert not git_support(match)(Command('git checkout',''))


# Generated at 2022-06-24 06:34:16.947008
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit", "git commit -m \"initialize\"")
    assert get_new_command(command) == "git reset HEAD~"



# Generated at 2022-06-24 06:34:17.910534
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == "git reset HEAD~"

# Generated at 2022-06-24 06:34:20.564746
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert match(Command('commit', ''))
    assert not match(Command('g commit', ''))


# Generated at 2022-06-24 06:34:24.043710
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', stderr=None))
    assert match(Command('git commit', '', stderr=''))
    assert not match(Command('git add', '', stderr=''))  


# Generated at 2022-06-24 06:34:29.728962
# Unit test for function get_new_command
def test_get_new_command():
     assert(get_new_command(Command('git commit', '', '')) == 'git reset HEAD~')
     assert(get_new_command(Command('git commit ', '', '')) == 'git reset HEAD~')
     assert(get_new_command(Command('git commit.', '', '')) == 'git reset HEAD~')


# Generated at 2022-06-24 06:34:33.189547
# Unit test for function match
def test_match():
    # TODO: improve test coverage
    assert match(Command('git commit'))
    assert match(Command('git push'))
    assert not match(Command('git comit'))
    assert not match(Command('git something'))


# Generated at 2022-06-24 06:34:35.016157
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git commit -m')) == 'git reset HEAD~')

# Generated at 2022-06-24 06:34:41.077372
# Unit test for function match
def test_match():
    s = '''
Please enter the commit message for your changes. Lines starting
with '#' will be ignored, and an empty message aborts the commit.
On branch master
Your branch is up-to-date with 'origin/master'.
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)
  modified:   README
    '''
    command = Command(script=s, stderr=s)
    assert match(command)



# Generated at 2022-06-24 06:34:44.972206
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "My commit message"'))
    assert match(Command('git ci -m "My commit message"'))
    assert match(Command('git commit -am "fixed stuff"'))
    assert match(Command('git ci -am "fixed stuff"'))
    assert match(Command('git commit -am "fixed stuff" foo'))
    assert match(Command('git commit -am "fixed stuff" foo'))


# Generated at 2022-06-24 06:34:49.565014
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "local test"', '',
                         '/home/blahblah/pycharm-community-2017.2.4/bin/'))
    assert not match(Command('git status', '', ''))

# Generated at 2022-06-24 06:34:51.900182
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git commit -m "Make everything better"',
                '',
                'gni: command not found')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:58.298497
# Unit test for function match
def test_match():
    # Matches successfully
    command = 'git commit --amend -m "This is a test"'
    assert git_amend_commit.match(command)

    # Matches successfully
    command = 'git commit --amend --no-edit'
    assert git_amend_commit.match(command)

    # Fails to match
    command = 'echo "This is a test"'
    assert not git_amend_commit.match(command)
