

# Generated at 2022-06-24 06:24:55.907363
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git committ")
    new_command = get_new_command(command)
    assert new_command == "git reset HEAD~"

# Generated at 2022-06-24 06:24:57.812185
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert match(Command('git yolo', ''))
    assert not match(Command('gib commit', ''))


# Generated at 2022-06-24 06:24:59.489363
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-24 06:25:00.698795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -am "forgot to add a file"') == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:01.938752
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:03.728678
# Unit test for function match
def test_match():
    command = Command('git commit -m "Initial commit"')
    assert(match(command))


# Generated at 2022-06-24 06:25:06.710535
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "message"',
                                   'git commit -m "message"')) == 'git reset HEAD~',\
        "get_new_command method failed to return the correct message"


# Generated at 2022-06-24 06:25:08.834071
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m Hell yeah', 'moo', 'git', '/git')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:09.939150
# Unit test for function match
def test_match():
    match(Command('commit -m "message"', '', None))


# Generated at 2022-06-24 06:25:11.419050
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "some message"', '', ''))
    assert not match(Command('git commit --amend', '', ''))



# Generated at 2022-06-24 06:25:12.622144
# Unit test for function match
def test_match():
    assert(match(command) == ('commit' in command.script_parts))



# Generated at 2022-06-24 06:25:15.860446
# Unit test for function get_new_command
def test_get_new_command():
    command_input = "git commit -m 'Just testing'"
    command_output = "git reset HEAD~"
    assert get_new_command(command_input) == command_output



# Generated at 2022-06-24 06:25:17.766714
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "new commit"') == 'git reset HEAD~'


# Generated at 2022-06-24 06:25:21.764170
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1: success
    assert get_new_comm

# Generated at 2022-06-24 06:25:24.419140
# Unit test for function match
def test_match():
    assert match('git commit -m "fehlerhafter commit"')
    assert not match('git commit -a')



# Generated at 2022-06-24 06:25:26.246427
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:25:27.526364
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Script('commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:29.442509
# Unit test for function match
def test_match():
    assert match(Command('git commit file1 file2'))
    assert not match(Command('git push'))



# Generated at 2022-06-24 06:25:35.670771
# Unit test for function match
def test_match():
    command = Command(script='commit -am "test"')
    assert match(command)
    command = Command(script='git commit -am "test"')
    assert match(command)


# Generated at 2022-06-24 06:25:40.184019
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', None))
    assert not match(Command('', '', None))
    assert not match(Command('ls', '', None))
    assert not match(Command('git checkout', '', None))


# Generated at 2022-06-24 06:25:42.760648
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git push', '', '/bin/git'))



# Generated at 2022-06-24 06:25:44.079131
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:45.896817
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command.get_new_command('git commit ')
    assert new_cmd == 'git reset HEAD~'

# Generated at 2022-06-24 06:25:48.810203
# Unit test for function match
def test_match():
    command = Command('commit', '', ('You are currently editing a commit while'
                                     ' '
                                     'rebasing branch \'foo\' on \'bar\'. '
                                     'Please, commit or stash them.'),
                             '', '/')
    assert match(command)


# Generated at 2022-06-24 06:25:51.976165
# Unit test for function match
def test_match():
    assert match(Command(script='git commit'))
    assert match(Command(script='git commit -m "Commit Message"'))
    assert not match(Command(script='git branch'))
    assert not match(Command(script='git push'))

# Generated at 2022-06-24 06:25:55.181023
# Unit test for function match
def test_match():
    command = Command('git commit -m "hello"', '')
    assert match(command)
    command_false = Command('git commit -a -m "hello"', '')
    assert not match(command_false)
    command_empty = Command('', '')
    assert not match(command_empty)


# Generated at 2022-06-24 06:26:01.290461
# Unit test for function match
def test_match():
    assert_true(match(Command('git commit', '')))
    assert_true(match(Command('git commit -a', '')))
    assert_true(match(Command('git commit -m "test"', '')))
    assert_false(match(Command('ls -l file', '')))
    assert_false(match(Command('git commit -m', '')))


# Generated at 2022-06-24 06:26:09.173089
# Unit test for function get_new_command
def test_get_new_command():
    '''
    A function that tests the get_new_command() function.
    '''
    assert get_new_command('git commit ') == 'git reset HEAD~'
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') != 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git commit --amend'



# Generated at 2022-06-24 06:26:14.605006
# Unit test for function get_new_command
def test_get_new_command():
    (assert_equal(get_new_command(Command('git commit -m', '')), 'git reset HEAD~'))
    (assert_equal(get_new_command(Command('ls git commit -m', '')), 'ls git reset HEAD~'))
    (assert_equal(get_new_command(Command('commit -m', '')), None))
    (assert_equal(get_new_command(Command('ls git commit -m', '')), 'ls git reset HEAD~'))


# Generated at 2022-06-24 06:26:15.840964
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('commit')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:19.667720
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "Message"', '', ''))
    assert match(Command('git commit', '', ''))
    assert not match(Command('git log', '', ''))



# Generated at 2022-06-24 06:26:21.453187
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git status', ''))



# Generated at 2022-06-24 06:26:27.002010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git commit -am 'Initial commit'", "", "", 3)) == "git reset HEAD~"
    assert get_new_command(Command("git commit -am", "", "", 3)) == "git reset HEAD~"
    assert get_new_command(Command("git commit", "", "", 3)) == "git reset HEAD~"
    assert get_new_command(Command("git commit --amend", "", "", 3)) == "git reset HEAD~"


# Generated at 2022-06-24 06:26:29.895472
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git st', '', ''))


# Generated at 2022-06-24 06:26:32.955428
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert not match(Command('git commit -m "update README.md"',
                             'utf-8'))


# Generated at 2022-06-24 06:26:35.786666
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(git.GitCommand(script='git commit -m')) == 'git reset HEAD~')

# Generated at 2022-06-24 06:26:38.064577
# Unit test for function get_new_command
def test_get_new_command():
    # Tests get_new_command function when git commit is entered
    assert get_new_command(Command('git commit')) == 'git reset HEAD~'



# Generated at 2022-06-24 06:26:40.496729
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git status'))


# Generated at 2022-06-24 06:26:46.857992
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('git commit -m "test"',
                       'error: failed to push some refs to \'/path/to/repo/\'',
                       '')
    command2 = Command('git commit',
                       'On branch master\n'
                       'nothing to commit, working directory clean',
                       '')
    command3 = Command('ls', 'Please, commit message')
    assert get_new_command(command1) == 'git reset HEAD~'
    assert get_new_command(command2) == 'git reset HEAD~'
    assert get_new_command(command3) == None


# Generated at 2022-06-24 06:26:50.638898
# Unit test for function match
def test_match():
    assert match(Command('git commit hello.py'))
    assert not match(Command('git commit'))
    assert not match(Command('git co hello.py'))
    assert not match(Command('echo hello'))


# Generated at 2022-06-24 06:26:52.611171
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -am "fixed typos"', '', None)
    assert get_new_command(command).script == 'git reset HEAD~'

# Generated at 2022-06-24 06:26:55.101566
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m test',
                                   'There are no staged files\n'
                                   'Use -a to add all files and then commit')) \
        == 'git reset HEAD~'



# Generated at 2022-06-24 06:26:57.968417
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:01.452468
# Unit test for function match
def test_match():
    assert match(Command('commit'))
    assert match(Command('git commit'))
    assert not match(Command('git commit --amend'))
    assert not match(Command('git status'))


# Generated at 2022-06-24 06:27:04.989363
# Unit test for function match
def test_match():
    with patch('os.path.exists') as path_exists:
        path_exists.return_value = True
        assert match(Command('git reset HEAD~1'))
        assert not match(Command('git rset HEAD~1'))


# Generated at 2022-06-24 06:27:06.146525
# Unit test for function get_new_command
def test_get_new_command():
     assert get_new_command(Command('commit')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:08.247747
# Unit test for function get_new_command
def test_get_new_command():
    command = 'git commit'
    output = 'git reset HEAD~'

    assert get_new_command(command) == output

# Generated at 2022-06-24 06:27:11.488188
# Unit test for function match
def test_match():
    git_commit_msg = ("git commit -m 'this is a test\n'")
    assert match(Command(script=git_commit_msg))

# Generated at 2022-06-24 06:27:13.155956
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:14.935388
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "Test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:27:17.163922
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/b'))
    assert not match(Command('commit', '', '/b'))



# Generated at 2022-06-24 06:27:22.557879
# Unit test for function match
def test_match():
    assert not match(Command())
    assert match(Command('git commit', ''))
    assert match(Command('git commit "first"', ''))
    assert match(Command('git commit -a', ''))
    assert match(Command('git commit -m "first"', ''))
    assert match(Command('git commit foo.txt -m "first"', ''))



# Generated at 2022-06-24 06:27:26.334598
# Unit test for function match
def test_match():
    match_output = ['git commit']
    none_match_output = ['git commitm']

    for cmd in match_output:
        assert(match(Command(script=cmd)) != None)

    for cmd in none_match_output:
        assert(match(Command(script=cmd)) == None)


# Generated at 2022-06-24 06:27:28.447364
# Unit test for function match
def test_match():
    assert match(Command('commit -m "yes"',
			 ''))
    assert not match(Command('commit abcd',
			     ''))


# Generated at 2022-06-24 06:27:30.317426
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('git commit',
                                    'git commit -am "test2"')) ==
            'git reset HEAD~')



# Generated at 2022-06-24 06:27:32.164512
# Unit test for function get_new_command

# Generated at 2022-06-24 06:27:34.220321
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:27:35.185690
# Unit test for function get_new_command

# Generated at 2022-06-24 06:27:41.073940
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit test', script='git commit test')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit test', script='git commit test', stderr='fatal: garbage after')) == 'git reset HEAD~'
    assert not get_new_command(Command('git commit test', script='git commit test', stderr='fatal: unknown command'))


# Generated at 2022-06-24 06:27:46.159979
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit -m "some message"', '', '/bin/git'))
    assert not match(Command('echo git commit', '', '/bin/echo'))
    assert not match(Command('git commit', '', '/bin/echo'))


# Generated at 2022-06-24 06:27:51.937345
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message" a.txt b.txt', '', 0, None))
    assert match(Command('commit -m "message" a.txt b.txt', '', 0, None))
    assert not match(Command('git commit -m "message"', '', 0, None))
    assert not match(Command('commit -m "message"', '', 0, None))
    assert not match(Command('git coomit -m "message"', '', 0, None))
    assert not match(Command('commit', '', 0, None))



# Generated at 2022-06-24 06:27:54.425189
# Unit test for function match
def test_match():
        assert match('git reset HEAD~')
        assert not match('commit')

# Generated at 2022-06-24 06:28:03.919439
# Unit test for function match
def test_match():
    assert match(Command('git reset HEAD~', '', ''))
    assert match(Command('git reset HEAD~1', '', ''))
    assert match(Command('git reset HEAD~5', '', ''))
    assert match(Command('git reset HEAD~1 --hard', '', ''))
    assert match(Command('git checkout HEAD~', '', ''))
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m', '', ''))
    assert not match(Command('git log', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git push', '', ''))


# Generated at 2022-06-24 06:28:05.526462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m message', '', None)) == "git reset HEAD~"

# Generated at 2022-06-24 06:28:06.558458
# Unit test for function match
def test_match():
    m = match(create_command('git commit'))
    assert(m)



# Generated at 2022-06-24 06:28:07.961286
# Unit test for function match
def test_match():
    assert match(Command('git commit', None))
    assert not match(Command('git branch', None))


# Generated at 2022-06-24 06:28:09.581065
# Unit test for function match
def test_match():
    assert match(Command('c'))
    assert match(Command('git commit'))
    assert not match(Command('git br'))



# Generated at 2022-06-24 06:28:13.581055
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -a -m "a message"',
                      'git-commit: Your local changes to the following files would be overwritten by merge:\n\t\t\n\t\tPlease commit your changes or stash them before you merge.\n\t\tabort: cannot do a partial commit during a merge.')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:16.400039
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('pyenv virtualenvwrapper', '', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:28:20.880436
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('gir commit', '', ''))


# Generated at 2022-06-24 06:28:24.161703
# Unit test for function match
def test_match():
	command = Command('git commit -m "asdf"', '')
	assert match(command)

	command = Command('git add', '')
	assert not match(command)



# Generated at 2022-06-24 06:28:29.190820
# Unit test for function match
def test_match():
	assert match(Command('git commit', '', ''))
	assert not match(Command('git init', '', ''))


# Generated at 2022-06-24 06:28:32.374742
# Unit test for function get_new_command
def test_get_new_command():
	assert(get_new_command('git commit -m "message"') == 'git reset HEAD~')
	assert(get_new_command('git commit -m "message" ') == 'git reset HEAD~')

# Generated at 2022-06-24 06:28:34.453091
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('commit -m "test"', '')
    assert('git reset HEAD~' == get_new_command(command))



# Generated at 2022-06-24 06:28:36.561392
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "asdf"', '', None)
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:39.561917
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git commit file')
    assert('git reset HEAD~' == get_new_command(command))

    command = Command(script='git status')
    assert(None == get_new_command(command))

# Generated at 2022-06-24 06:28:43.039442
# Unit test for function match
def test_match():
    assert match(Command(script='git commit asdf', stdout='', stderr=''))
    assert not match(Command(script='git commit -m asdf', stdout='', stderr=''))


# Generated at 2022-06-24 06:28:49.147246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit xyz', '/')) == 'git reset HEAD~'
    assert get_new_command(Command('commit', '/')) == 'git reset HEAD~'
    assert get_new_command(Command('git add cde', '', '/')) == 'git add cde'
    assert get_new_command(Command('git add cde', '/')) == 'git add cde'

# Generated at 2022-06-24 06:28:55.496831
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "df"',
        '')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:28:58.527429
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "hello world"') == 'git reset HEAD~'


# Generated at 2022-06-24 06:29:00.727983
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit") == "git reset HEAD~"
    assert get_new_command("git add --all && git commit -m 'Message' ") == "git reset HEAD~"

# Generated at 2022-06-24 06:29:03.094840
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert not match(Command('commit'))
    assert not match(Command('git log'))
    assert not match(Command('git status'))
    assert not match(Command('git push'))


# Generated at 2022-06-24 06:29:05.293532
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("git commit -m 'test_commit'", "", "")) == 'git reset HEAD~'

# Generated at 2022-06-24 06:29:07.588754
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command(Command('git commit', '', ''))
    assert new_command == 'git reset HEAD~', new_command

# Generated at 2022-06-24 06:29:09.908817
# Unit test for function get_new_command
def test_get_new_command():
    commands = ['git commit']
    for command in commands:
        command = Command(command)
        assert_equals(get_new_command(command), 'git reset HEAD~')

# Generated at 2022-06-24 06:29:12.976923
# Unit test for function match
def test_match():
    f = match
    assert f(Command('git commit', ''))
    assert f(Command('git commit -m "test"', ''))
    assert not f(Command('git commit --amend', ''))
    assert not f(Command('git checkout master', ''))


# Generated at 2022-06-24 06:29:20.759975
# Unit test for function match
def test_match():
    assert match('git commit')
    assert match('git commit -m msg')
    assert match('git commit -am "msg"')
    assert match('git commit --amend --no-edit')
    assert match('git commit --amend -m "msg"')
    assert match('git commit --amend')
    assert match('git commit -C HEAD')
    assert match('git commit --author "name"')
    assert match('git commit --no-post-rewrite')
    assert match('git commit --reedit-message HEAD')
    assert match('git commit --amend --no-post-rewrite')
    assert match('git commit --amend --author "name"')
    assert match('git commit --amend --reedit-message HEAD')
    assert match('commit .')

# Generated at 2022-06-24 06:29:23.211226
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'some_output')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:29:25.832779
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m test',
                                   'Not a git repository')) == 'git reset HEAD~'



# Generated at 2022-06-24 06:29:35.050971
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit -m 'commit'") == 'git reset HEAD~'
    assert get_new_command("git commit") == 'git reset HEAD~'
    assert get_new_command("git --commit") == git_not_found
    assert get_new_command("commit") == not_git_repo


# Generated at 2022-06-24 06:29:36.694169
# Unit test for function get_new_command
def test_get_new_command():
    command = git.Command('git commit M')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:29:37.560579
# Unit test for function get_new_command

# Generated at 2022-06-24 06:29:40.598090
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='git commit')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:29:42.302426
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:29:46.604400
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m') == 'git reset HEAD~'
    assert get_new_command('git commit --all') == 'git reset HEAD~'
    assert get_new_command('git commit --all -m') == 'git reset HEAD~'



# Generated at 2022-06-24 06:29:48.028781
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("commit") == "git reset HEAD~"

# Generated at 2022-06-24 06:29:50.470623
# Unit test for function match
def test_match():
    assert match(Command(script='git commit --amend', stderr='Error:', env=None))
    assert not match(Command(script='git status', stderr='Error:', env=None))


# Generated at 2022-06-24 06:29:52.503518
# Unit test for function match
def test_match():
    command = Command('git commit -m "mess"')
    assert match(command)
    command = Command('git commit')
    assert match(command)


# Generated at 2022-06-24 06:29:55.876499
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "msg"', '', '/'))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git', '', ''))



# Generated at 2022-06-24 06:29:57.466423
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'


if __name__ == '__main__':
    import sys
    print(get_new_command(sys.argv[1]))

# Generated at 2022-06-24 06:29:59.704714
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git push') == 'git push'

# Generated at 2022-06-24 06:30:01.305656
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -a --amend', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:04.954002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "foo"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "foo"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'



# Generated at 2022-06-24 06:30:06.927695
# Unit test for function match
def test_match():
    true_command = Command('git commit', '', None)
    fake_command = Command('git', '', None)
    assert(match(true_command) == True)
    assert(match(fake_command) == False)


# Generated at 2022-06-24 06:30:09.778921
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git status') == 'git reset HEAD~'
    assert get_new_command('git commit -m Hello') == 'git reset HEAD~'


# Generated at 2022-06-24 06:30:11.823811
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "fixed bug"')
    assert 'git reset HEAD~' == get_new_command(command)



# Generated at 2022-06-24 06:30:13.199354
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit --amend") == "git reset HEAD~"

# Generated at 2022-06-24 06:30:17.973828
# Unit test for function match
def test_match():
    assert match(Command('git test',
            '',
            '',
            '/usr/bin/git'))
    assert not match(Command('git commit -m "test"',
            '',
            '',
            '/usr/bin/git'))



# Generated at 2022-06-24 06:30:19.828626
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:30:24.170301
# Unit test for function match
def test_match():
    # Function match requires git
    if not which('git'):
        pytest.skip('git not installed.')
    # Simple test
    assert match(Command('git commit'))
    # Bad test
    assert not match(Command('git coomit'))
    assert not match(Command('git comit'))

# Generated at 2022-06-24 06:30:34.567406
# Unit test for function match
def test_match():
    command = Command('git commit --amend -m "My commit message"',
                      'git commit --amend -m "My commit message"',
                      'echo "My commit message"')
    assert match(command)
    command = Command('commit --amend -m "My commit message"',
                      'commit --amend -m "My commit message"',
                      'echo "My commit message"')
    assert match(command)
    command = Command('commit -m "My commit message"',
                      'commit -m "My commit message"',
                      'echo "My commit message"')
    assert match(command)
    command = Command('commit -m "My commit message""',
                      'commit -m "My commit message""',
                      'echo "My commit message""')
    assert not match(command)



# Generated at 2022-06-24 06:30:36.009286
# Unit test for function get_new_command
def test_get_new_command():
    assert git_fuck("commit", 'git commit') == "git reset HEAD~"



# Generated at 2022-06-24 06:30:38.869423
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git push', '', ''))


# Generated at 2022-06-24 06:30:41.046620
# Unit test for function get_new_command
def test_get_new_command():
    assert(match('git commit') == True)
    assert(get_new_command('git commit') == 'git reset HEAD~')

# Generated at 2022-06-24 06:30:44.302532
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit", "git: 'commit' is not a git command. See 'git --help'.\n\nDid you mean this?\n\tcommit")
    assert get_new_command(command) == 'git reset HEAD~'



# Generated at 2022-06-24 06:30:46.040418
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "message"', '')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:47.880264
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m', 'git')) == 'git reset HEAD~'


# Generated at 2022-06-24 06:30:49.804768
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('', '', '')
    ) == 'git reset HEAD~'


# Generated at 2022-06-24 06:30:52.694118
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "This is a commit message"', ''))
    assert not match(Command('other git commit -m "This is a commit message"', ''))
    assert not match(Command('git commit -m "This is a commit message"', ''))


# Generated at 2022-06-24 06:30:53.989341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit --amend --all -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-24 06:30:55.505594
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git reset HEAD~', ''))


# Generated at 2022-06-24 06:31:00.797630
# Unit test for function match
def test_match():
    
    # Test if match is true when there is the word 'commit'
    # in the command script
    assert match(Command('git commit', '', ''))

    # Test if match is false when there is the word 'commit'
    # in the command script
    assert not match(Command('git add', '', ''))
    

# Generated at 2022-06-24 06:31:03.028358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('commit') == 'git reset HEAD~'
    assert get_new_comma

# Generated at 2022-06-24 06:31:04.738727
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command('/test/test git commit -m "test"')
    assert new_command == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:06.973339
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert match(Command('git commit -a', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-24 06:31:08.448002
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', 'git commit')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:09.852402
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:19.784986
# Unit test for function match
def test_match():
    from mock import Mock
    assert not match(Mock(script='git status',
                          script_parts=['git', 'status'],
                          stderr='',
                          stdout=''))
    assert not match(Mock(script='git commit',
                          script_parts=['git', 'commit'],
                          stderr='',
                          stdout=''))
    assert match(Mock(script='git commit -m "message"',
                      script_parts=['git', 'commit', '-m', 'message'],
                      stderr='',
                      stdout=''))
    assert not match(Mock(script='git commit -m message',
                          script_parts=['git', 'commit', '-m', 'message'],
                          stderr='',
                          stdout=''))

# Generated at 2022-06-24 06:31:23.176499
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.git_commit_all_untracked_files_error import get_new_command
    assert "git reset HEAD~" in get_new_command(
        Command('git commit -m "Commit Message"', "", "", "", "", "")
    ).script

# Generated at 2022-06-24 06:31:25.282035
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('test git commit -m "test message"')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:31:27.994968
# Unit test for function match
def test_match():
    assert match(Command('git commit -m', '')) is True
    assert match(Command('git commit -m', '')) is not False


# Generated at 2022-06-24 06:31:29.840845
# Unit test for function match
def test_match():
    assert match(Command('git commit -m msg', '', stderr='fatal: cannot do a partial commit during a merge\n'))


# Generated at 2022-06-24 06:31:38.624417
# Unit test for function match
def test_match():
    assert match(Command('git commit hello.txt',
                         'git commit hello.txt\n  (use "git push" to publish your local commits)\n\nChanges not staged for commit:\n  (use "git add <file>..." to update what will be committed)\n  (use "git checkout -- <file>..." to discard changes in working directory)\n\n\tmodified:   hello.txt\n\nUntracked files:\n  (use "git add <file>..." to include in what will be committed)\n\n\tbello.txt\n\nno changes added to commit (use "git add" and/or "git commit -a")\n'))
    assert not match(Command('git checkout hello.txt', ''))

# Generated at 2022-06-24 06:31:43.491199
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -a') == 'git reset HEAD~'


# Generated at 2022-06-24 06:31:44.841426
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:47.564329
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('', '')
    command.script_parts = ['commit']
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:50.563855
# Unit test for function match
def test_match():
    # Last command is a git command
    assert match(Command('git commit', '', ''))
    # Last command is not a git command
    assert not match(Command('commit', '', ''))
    # No command
    assert not match(Command('', '', ''))


# Generated at 2022-06-24 06:31:51.568777
# Unit test for function match
def test_match():
    pass


# Generated at 2022-06-24 06:31:54.586974
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    
    correct_output = 'git reset HEAD~'
    given_command = Command('git commit -m "Add some new features"', '', '')
    new_command = get_new_command(given_command)

    assert new_command == correct_output

# Generated at 2022-06-24 06:31:55.991410
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit')
    new_command = get_new_command(command)
    assert new_command == 'git reset HEAD~'

# Generated at 2022-06-24 06:31:59.906742
# Unit test for function match
def test_match():
    command = Command('git commit', '', '')
    assert "commit" in command.script_parts
    assert match(command)

    command_2 = Command('git commit hello', '', '')
    assert "commit hello" in command_2.script_parts
    assert match(command_2)

    command_3 = Command('git commit', '', '')
    assert "commit" not in command_3.script
    assert not match(command_3)


# Generated at 2022-06-24 06:32:03.785300
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("commit --message \"Hello Git\"", "", "", 0, "")
    assert get_new_command(command) == 'git reset HEAD~'



# Generated at 2022-06-24 06:32:07.768887
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m commit', 'ssh: Could not resolve hostname github.com: nodename nor servname provided, or not known\ngit: \'commit\' is not a git command. See \'git --help\'.\n\nThe most similar command is\nclone\n')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:12.877433
# Unit test for function match
def test_match():

    # Test 1
    command = Command('git commit -m "test"', '', 0)
    assert(match(command) == True)
    

    # Test 2
    command = Command('git logger', '', 0)
    assert(match(command) == False)


    # Test 3
    command = Command('git', '', 0)
    assert(match(command) == False)


# Generated at 2022-06-24 06:32:15.540259
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'


# Generated at 2022-06-24 06:32:18.082676
# Unit test for function get_new_command
def test_get_new_command():
    assert('git reset HEAD~1' == get_new_command(
        Command('git commit', '', '/some/path')))

# Generated at 2022-06-24 06:32:21.424251
# Unit test for function match
def test_match():
    assert match(Command('git commit'))
    assert match(Command('git commit --message "my commit"'))
    assert match(Command('git commit --amend'))
    assert not match(Command('git reset --hard'))


# Generated at 2022-06-24 06:32:23.262654
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "hello"')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:24.366242
# Unit test for function get_new_command
def test_get_new_command():
    assert 'git reset HEAD~' == get_new_command(Command('commit'))

# Generated at 2022-06-24 06:32:26.344240
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "test"', '')
    assert c.get_new_command(command).script == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:29.608971
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('git commit -am "new commit"', '', '')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:32:31.419962
# Unit test for function match
def test_match():
	assert match(Command("commit", "git commit -m \"foo bar", None))
	assert not match(Command("status", "git commit -m \"foo bar", None))


# Generated at 2022-06-24 06:32:35.726567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='git commit', stderr='error: failed to push some refs to', env={},)) == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:40.359883
# Unit test for function match
def test_match():
    assert match(Command(script='git coomit -m "commit message"',
                         stderr='error: pathspec \'coomit\' did not match any file(s) known to git.\n'))
    assert not match(Command(script='git commit -m "commit message"'))



# Generated at 2022-06-24 06:32:49.876149
# Unit test for function match
def test_match():
    assert(match(Command('git commit', '', '')))
    assert(match(Command('git commit -am "Initial commit"', '', '')))
    assert(match(Command('git commit', '', '')))
    assert(match(Command('git commit -m', '', '')))
    assert(match(Command('git commit -q', '', '')))
    assert(match(Command('g commit', '', '')))
    assert(not match(Command('git status', '', '')))
    assert(not match(Command('git log', '', '')))
    assert(not match(Command('git diff', '', '')))
    assert(not match(Command('git commit', '', '')))
    assert(not match(Command('git checkout', '', '')))
    assert(not match(Command('git branch', '', '')))

# Generated at 2022-06-24 06:32:51.518954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('commit', '')) == 'git reset HEAD~'

# Unit t

# Generated at 2022-06-24 06:32:54.183940
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', 'git commit\ngit push')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:57.354450
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "my message"',
                      'bash: git: command not found')
    actual = get_new_command(command)
    assert actual == 'git reset HEAD~'

# Generated at 2022-06-24 06:32:59.564105
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "message"')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:33:01.356441
# Unit test for function match
def test_match():
	match_test = match(Command('git commit'))
	assert match_test is True


# Generated at 2022-06-24 06:33:02.672700
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:05.359241
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit blah blah blah') == 'git reset HEAD~'
    
    

# Generated at 2022-06-24 06:33:10.618999
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('commit "as"') == 'git reset HEAD~'
    assert get_new_command('commit as') == 'git reset HEAD~'
    assert get_new_command('commit') == 'git reset HEAD~'


# Generated at 2022-06-24 06:33:17.204128
# Unit test for function match
def test_match():
    command = Command('git commit -m "oops"', '')
    assert match(command)
    command = Command('git commit', '')
    assert match(command)
    command = Command('git add', '')
    assert not match(command)
    command = Command('git help commit', '')
    assert not match(command)


# Generated at 2022-06-24 06:33:22.919169
# Unit test for function match
def test_match():
    # Command which will match and produce a new command
    assert match(Command('git commit messages.txt', ''))

    # Command which will not match
    assert not match(Command('git add messages.txt', ''))


# Generated at 2022-06-24 06:33:28.260555
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', '')
    assert git_support(get_new_command, command) == 'git reset HEAD~'

    # Test for when command included other text
    command = Command('git commit -m "inital commit"', '')
    assert git_support(get_new_command, command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:33:32.430606
# Unit test for function get_new_command
def test_get_new_command():
    """test_get_new_command tests function `get_new_command`
        Args:
 
        Returns:
            none
        """	
    assert(get_new_command("git commit") == "git reset HEAD~")
	

# Generated at 2022-06-24 06:33:35.084630
# Unit test for function get_new_command
def test_get_new_command():
    assert git_support
    assert match("git commit -m 'hello world'")
    assert get_new_command("git commit -m 'hello world'") == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:39.790369
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -a') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --all') == 'git reset HEAD~'



# Generated at 2022-06-24 06:33:41.453496
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('git commit -m fix spelling', stderr='fatal')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:42.761861
# Unit test for function match
def test_match():
    command = Command(script='commit')
    assert match(command)



# Generated at 2022-06-24 06:33:46.603288
# Unit test for function match
def test_match():
    assert(not match(Command('ls', 'git status')))
    assert(match(Command('git add -p', 'git commit')))
    assert(match(Command('git commit', 'git commit -a')))
    assert(match(Command('commit', 'git commit')))
    assert(match(Command('git status', 'git commit')))
    assert(not match(Command('git commit')))


# Generated at 2022-06-24 06:33:48.118010
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('commit -m test', '', None)) == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:51.481870
# Unit test for function match
def test_match():
    git_commit_command = Command("git commit -m $'hey'")
    assert match(git_commit_command)

    git_reset_command = Command("git reset HEAD~")
    assert not match(git_reset_command)



# Generated at 2022-06-24 06:33:53.658961
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -am "message"') == 'git reset HEAD~'

# Generated at 2022-06-24 06:33:55.690909
# Unit test for function match
def test_match():
	assert match(Command("git commit -m 'message'", ""))
	assert not match(Command("git status", ""))


# Generated at 2022-06-24 06:33:59.506244
# Unit test for function match
def test_match():
    assert match(Command('git commit -m test', '', '/tmp'))
    assert not match(Command('git add file1.txt file2.txt', '', '/tmp'))



# Generated at 2022-06-24 06:34:03.416342
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" --amend') == 'git reset HEAD~'
    assert get_new_command('commit -m "test"') == ''

# Generated at 2022-06-24 06:34:04.915681
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m aaaaa')) == "git reset HEAD~"

# Generated at 2022-06-24 06:34:06.065365
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commmit') == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:09.951695
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "blah blah blah"',
            '', '/Users/Shared/repo'))
    assert match(Command('git commit foo', '', '/Users/Shared/repo'))
    assert not match(Command('git commit foo', '', '/Users/Shared'))
    assert not match(Command('git commit foo', '', '/Users/Shared/repo/'))


# Generated at 2022-06-24 06:34:11.762675
# Unit test for function match
def test_match():
    assert match(Command('git commit', None)) == True
    assert match(Command('git add -A', None)) == False

# Generated at 2022-06-24 06:34:16.434874
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', '')
    assert(get_new_command(command) == 'git reset HEAD~')

# Generated at 2022-06-24 06:34:19.348517
# Unit test for function match
def test_match():
    assert match(Command('git status'))
    assert not match(Command('git commit -m "initial commit"'))



# Generated at 2022-06-24 06:34:24.231578
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit', '', '/bin/ls')) == False
    assert match(Command('git commit', '', '/bin/git-commit')) == False
    assert match(Command('git commit', '', '/bin/git-commit', '/bin/ls'))
    assert match(Command('git commit', '', '/bin/ls', '/bin/ls')) == False


# Generated at 2022-06-24 06:34:26.705976
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "first commit"')
    assert('git reset HEAD~' == get_new_command(command))

# Generated at 2022-06-24 06:34:29.264014
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'


enabled_by_default = True

# Generated at 2022-06-24 06:34:30.294757
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('commit -m "test"') == "git reset HEAD~"


# Generated at 2022-06-24 06:34:32.455972
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '',
                         '/home/bhavesh/Documents/test'))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git log', '', ''))


# Generated at 2022-06-24 06:34:34.791128
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))



# Generated at 2022-06-24 06:34:36.641648
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "fail"')) == 'git reset HEAD~'

# Generated at 2022-06-24 06:34:41.734700
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git commit") == "git reset HEAD~"
    assert get_new_command("git commit -m""") == "git reset HEAD~"
    assert get_new_command("git commit -m 'test'") == "git reset HEAD~"
    assert get_new_command("git commit -m 'test' -m 'test'") == "git reset HEAD~"


# Generated at 2022-06-24 06:34:43.914730
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        ["git", "commit", "x", "--", "y"]) == "git reset HEAD~"

# Generated at 2022-06-24 06:34:45.425915
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("git reset HEAD~") == "git reset HEAD~"

# Generated at 2022-06-24 06:34:49.004987
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("git commit file.txt -m 'file created'", "")
    assert get_new_command(command) == "git reset HEAD~"


# Generated at 2022-06-24 06:34:51.065817
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m test')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-24 06:34:52.930522
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit', '', None)
    assert 'git reset HEAD~' == get_new_command(command)

# Generated at 2022-06-24 06:34:55.798732
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', None))
    assert match(Command('git commit', '', 'git'))
    assert not match(Command('git', '', 'git-commit'))

