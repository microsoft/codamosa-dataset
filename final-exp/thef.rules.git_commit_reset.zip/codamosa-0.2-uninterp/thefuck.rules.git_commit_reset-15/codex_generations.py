

# Generated at 2022-06-18 08:01:10.030867
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:01:14.320206
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'


# Generated at 2022-06-18 08:01:22.943985
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a -m test3') == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:26.666256
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git commit -m "test"', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', ''))


# Generated at 2022-06-18 08:01:35.960883
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:01:46.236699
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message" file', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5 file6', ''))

# Generated at 2022-06-18 08:01:48.245314
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:01:57.586605
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:00.629891
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:02:02.907840
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:02:09.013975
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:02:18.215287
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:02:20.055901
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:29.593822
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:31.520573
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:02:33.687039
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:02:35.310331
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:02:37.822044
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '', '', None, None))
    assert not match(Command('git commit', '', '', '', None, None))


# Generated at 2022-06-18 08:02:40.272908
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "test"', '', '')
    assert get_new_command(command) == 'git reset HEAD~'


# Generated at 2022-06-18 08:02:42.423165
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:02:46.825481
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:02:55.829308
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m "message"', '', ''))
    assert match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend -m "message" file1 file2', '', ''))
    assert not match(Command('git commit --amend --no-edit', '', ''))
    assert not match(Command('git commit --amend --no-edit file1 file2', '', ''))
    assert not match(Command('git commit --amend --no-edit -m "message"', '', ''))


# Generated at 2022-06-18 08:02:58.385254
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:03:09.026853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:11.045915
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', ''))
    assert not match(Command('git status', ''))


# Generated at 2022-06-18 08:03:12.636477
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/tmp')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:21.578886
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:03:24.992123
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/svn'))


# Generated at 2022-06-18 08:03:26.766649
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:28.935518
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:03:31.779615
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:33.203633
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:35.377944
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:03:44.338747
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:54.257055
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a -m test3') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:55.823223
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:04:04.265689
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:05.467183
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:07.545776
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:04:15.239888
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git add', '', ''))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git pull', '', ''))
    assert not match(Command('git checkout', '', ''))
    assert not match(Command('git branch', '', ''))
    assert not match(Command('git merge', '', ''))
    assert not match(Command('git stash', '', ''))
    assert not match(Command('git rebase', '', ''))

# Generated at 2022-06-18 08:04:19.800880
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:28.249041
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/tmp')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '/tmp')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '/tmp')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '', '/tmp')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a -m test', '', '/tmp')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2', '', '/tmp')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:37.062375
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:38.751932
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:04:40.727103
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:04:50.128573
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:51.699691
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:54.012258
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:04:56.081088
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:59.295473
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:05:10.745385
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -m test3') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -m test3 -m test4') == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:13.271008
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') != 'git commit -m "test"'

# Generated at 2022-06-18 08:05:15.668054
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:05:25.106552
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:27.042851
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:05:28.180892
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:05:39.038801
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:05:47.995328
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit -m "message"', '', '/bin/git'))
    assert not match(Command('git status', '', '/bin/git'))
    assert not match(Command('git add', '', '/bin/git'))
    assert not match(Command('git add .', '', '/bin/git'))
    assert not match(Command('git add -A', '', '/bin/git'))
    assert not match(Command('git add -u', '', '/bin/git'))
    assert not match(Command('git add --all', '', '/bin/git'))
    assert not match(Command('git add --update', '', '/bin/git'))

# Generated at 2022-06-18 08:05:54.192372
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message" file', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5 file6', ''))

# Generated at 2022-06-18 08:05:56.230917
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:06:03.680582
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:06:05.846047
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:06:13.933276
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~1'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~2'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~3'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~4'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~5'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~6'

# Generated at 2022-06-18 08:06:15.317702
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:18.832380
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:06:19.830472
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:20.900091
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:06:26.048084
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2 -m test3', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:33.991466
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))

# Generated at 2022-06-18 08:06:41.961660
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -a', '', ''))
    assert not match(Command('git commit -a -m "message"', '', ''))
    assert not match(Command('git commit -m "message" -a', '', ''))
    assert not match(Command('git commit -m "message" -a -m "message"', '', ''))
    assert not match(Command('git commit -m "message" -a -m "message" -a', '', ''))
    assert not match(Command('git commit -m "message" -a -m "message" -a -m "message"', '', ''))

# Generated at 2022-06-18 08:06:55.222995
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:07:03.988902
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:14.303270
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))

# Generated at 2022-06-18 08:07:15.830884
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:17.491632
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:07:24.092027
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:26.053742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "message"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:07:36.248909
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', '', ''))
    assert not match(Command('git commit', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:07:44.366477
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:46.508995
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD'

# Generated at 2022-06-18 08:08:15.790522
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:08:23.071509
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:08:24.445278
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:08:26.083300
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:08:32.740260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2 -a', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:33.833856
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:41.096839
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:48.113453
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git push', '', ''))
    assert not match(Command('git pull', '', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git add', '', ''))
    assert not match(Command('git checkout', '', ''))
    assert not match(Command('git branch', '', ''))
    assert not match(Command('git merge', '', ''))
    assert not match(Command('git stash', '', ''))

# Generated at 2022-06-18 08:08:49.423634
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'


# Generated at 2022-06-18 08:08:50.679362
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:46.064317
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:09:47.389334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:50.384796
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit -m "message"', '', '/tmp'))
    assert not match(Command('git commit --amend', '', '/tmp'))


# Generated at 2022-06-18 08:09:57.558798
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:59.082052
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:10:04.865462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2" -m "test3"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:10:06.262681
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:10:10.903518
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:10:13.679106
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:17.034470
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~1'
