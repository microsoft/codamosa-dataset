

# Generated at 2022-06-18 08:01:09.767835
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:01:11.240428
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:19.580841
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:01:28.610767
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message" file') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message" file1 file2') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message" file1 file2 file3') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message" file1 file2 file3 file4') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message" file1 file2 file3 file4 file5') == 'git reset HEAD~'
    assert get_new_command

# Generated at 2022-06-18 08:01:30.606826
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:01:34.855577
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git add', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:01:36.422177
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:38.767817
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:01:39.990079
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:50.212945
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:01.597021
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2" -a', '', '')) == 'git reset HEAD~'
    assert get_new_command

# Generated at 2022-06-18 08:02:03.840852
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:02:05.415019
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:14.279222
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:24.290090
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:02:26.042125
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:27.634379
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:29.419484
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:31.372638
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:02:40.953051
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))

# Generated at 2022-06-18 08:02:43.690661
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:02:52.765211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:54.320469
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:04.043079
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:03:09.200311
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert match(Command('git commit -m "test"', '', '', '', '', ''))
    assert not match(Command('git commit'))
    assert not match(Command('git commit -m "test"', '', '', '', '', ''))


# Generated at 2022-06-18 08:03:11.223349
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git commit'))


# Generated at 2022-06-18 08:03:12.473530
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:21.411276
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:03:23.365690
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:03:25.377406
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:03:35.791699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:44.976927
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))
    assert not match(Command('git commit -m "test"', '', None))

# Generated at 2022-06-18 08:03:47.666489
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:03:49.612288
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:03:52.722059
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))
    assert not match(Command('git commit', '', '/bin/echo'))


# Generated at 2022-06-18 08:03:54.285029
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:55.824225
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:04.265199
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file1 file2', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" -- file1 file2', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" -- file1 file2', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:05.751434
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:07.849807
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:04:12.180066
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:20.286366
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))

# Generated at 2022-06-18 08:04:28.785848
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend --no-edit', '', ''))
    assert not match(Command('git commit --amend -m "message" --no-edit', '', ''))
    assert not match(Command('git commit --amend --no-edit -m "message"', '', ''))
    assert not match(Command('git commit --no-edit', '', ''))

# Generated at 2022-06-18 08:04:30.781443
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:39.642874
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:04:41.875413
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:45.104380
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))


# Generated at 2022-06-18 08:04:49.173971
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', '', ''))


# Generated at 2022-06-18 08:04:58.654822
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:05:00.353520
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:05:05.076768
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:05:07.405477
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))


# Generated at 2022-06-18 08:05:09.366233
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:11.021978
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:14.585231
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:05:18.431400
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~1'


# Generated at 2022-06-18 08:05:27.280080
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD~1'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD~2'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD~3'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD~4'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD~5'

# Generated at 2022-06-18 08:05:28.515297
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:34.731870
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:05:43.681838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:49.087153
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))
    assert not match(Command('git', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:54.890344
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:06:03.386988
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:05.260948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:06:07.150042
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:06:09.183416
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:06:17.198072
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:06:20.350809
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))


# Generated at 2022-06-18 08:06:26.488867
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:28.560317
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:06:34.517439
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))
    assert not match(Command('git commit', '', '/bin/echo'))


# Generated at 2022-06-18 08:06:36.433890
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))

# Generated at 2022-06-18 08:06:44.399092
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2 -a', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:45.994973
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git status', '', '/tmp'))


# Generated at 2022-06-18 08:06:52.841955
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2" -m "test3"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:07:01.601119
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))

# Generated at 2022-06-18 08:07:04.420340
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))


# Generated at 2022-06-18 08:07:14.858093
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~1'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~2'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~3'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~4'

# Generated at 2022-06-18 08:07:16.622700
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:07:19.865143
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', ''))
    assert match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))


# Generated at 2022-06-18 08:07:32.362737
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test test2 test3') == 'git reset HEAD~'
    assert get_new_command('git commit -m test test2 test3 test4') == 'git reset HEAD~'
    assert get_new_command('git commit -m test test2 test3 test4 test5') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:41.131154
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:42.843861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:07:43.955116
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:45.323230
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:53.870367
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:55.348235
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:56.985645
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:59.620794
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:07.161828
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:08:13.332272
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:08:14.821172
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "message"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:22.131591
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:08:28.891735
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:30.170336
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:37.206771
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))
    assert not match(Command('git commit --amend --no-edit', '', ''))
    assert not match(Command('git commit --amend --no-edit -m "test"', '', ''))
    assert not match(Command('git commit --amend --no-edit --no-post-rewrite', '', ''))
    assert not match(Command('git commit --amend --no-edit --no-post-rewrite -m "test"', '', ''))

# Generated at 2022-06-18 08:08:43.332692
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'


# Generated at 2022-06-18 08:08:45.036958
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))

# Generated at 2022-06-18 08:08:46.033456
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:53.339914
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:59.045703
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))



# Generated at 2022-06-18 08:09:06.865730
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:09:08.349623
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:09.668114
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:10.956054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:09:19.871918
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -amend', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test --amend', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:22.303992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:09:29.833756
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a -m test2 -m test3', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:31.788557
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:34.229958
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:09:39.701671
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:09:43.798879
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))


# Generated at 2022-06-18 08:09:46.325916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD'

# Generated at 2022-06-18 08:09:47.915979
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:49.438297
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:51.157962
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:09:58.228496
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message"', ''))

# Generated at 2022-06-18 08:10:00.479232
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))
    assert not match(Command('git commit', '', '/bin/echo'))


# Generated at 2022-06-18 08:10:01.611632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:10:07.469401
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:10:14.744930
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:10:17.009427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:10:18.879749
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:10:21.260539
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:10:28.733103
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -a -m test3') == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:32.732592
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:10:34.193392
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:10:36.285235
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:10:43.731913
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', '', ''))
    assert not match(Command('git commit', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', '', ''))
    assert not match(Command('git commit', '', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:10:51.875009
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -m test2 -m test3')

# Generated at 2022-06-18 08:10:57.883045
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:10:59.585388
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:11:02.032211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:11:08.799779
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))