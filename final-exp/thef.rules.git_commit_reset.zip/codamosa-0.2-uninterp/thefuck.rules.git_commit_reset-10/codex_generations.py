

# Generated at 2022-06-18 08:01:15.454443
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/home/user/git/repo')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '/home/user/git/repo')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '/home/user/git/repo')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '/home/user/git/repo')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '/home/user/git/repo')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:24.062686
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', '', ''))

# Generated at 2022-06-18 08:01:25.723795
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:34.949189
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file1 file2', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -am "message"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:45.021812
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match

# Generated at 2022-06-18 08:01:46.824858
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:01:50.125521
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:02:00.251610
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:01.897894
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:04.151945
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:02:07.753358
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git add', '', ''))

# Generated at 2022-06-18 08:02:16.947922
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:18.626252
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:28.372153
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:30.360464
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:02:32.374580
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:02:34.878892
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:02:37.065435
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))



# Generated at 2022-06-18 08:02:39.460615
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:02:41.735329
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:02:53.450934
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', '', ''))

# Generated at 2022-06-18 08:02:55.422307
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:02:57.579702
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:02:59.138151
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:00.800637
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:03:11.497446
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:20.206742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" file') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" file1 file2') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a file') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a file1 file2') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:22.047785
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:31.338694
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))

# Generated at 2022-06-18 08:03:34.574687
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:03:39.961787
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git commit -m "test"', '', '', '', '', ''))


# Generated at 2022-06-18 08:03:41.483034
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:03:43.153705
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:03:44.573948
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:47.540791
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:03:49.500780
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:03:51.890445
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:53.767204
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:04:02.477816
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:04:05.467465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:04:12.647079
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:04:20.757838
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file.txt', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:29.254954
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2" -a -m "test3"') == 'git reset HEAD~'


# Generated at 2022-06-18 08:04:31.216438
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:04:40.092571
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', '', ''))

# Generated at 2022-06-18 08:04:42.214366
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:44.224698
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git add .', '', ''))


# Generated at 2022-06-18 08:04:46.606037
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:04:48.539913
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:51.432195
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:57.959787
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:01.197592
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))
    assert not match(Command('git reset', '', ''))


# Generated at 2022-06-18 08:05:09.681448
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:05:11.955436
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:05:21.396789
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"')

# Generated at 2022-06-18 08:05:23.048148
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:05:24.610910
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:27.416735
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:05:30.333070
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:33.056441
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:05:45.740897
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:53.043395
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:54.399741
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:56.417124
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:06:04.756104
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:12.916623
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match

# Generated at 2022-06-18 08:06:20.961599
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend --no-edit', '', ''))
    assert not match(Command('git commit --amend --no-edit -m "message"', '', ''))
    assert not match(Command('git commit --no-edit', '', ''))
    assert not match(Command('git commit --no-edit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:06:27.343703
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:29.136854
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:06:37.191745
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:06:50.255084
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:06:51.766580
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:06:53.562401
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:06:56.129408
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))


# Generated at 2022-06-18 08:06:57.278799
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:05.701572
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file1 file2', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file1 file2 file3', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "message" file1 file2 file3 file4', ''))

# Generated at 2022-06-18 08:07:16.143454
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:19.433792
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:07:25.173379
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:07:35.538881
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2" -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" -a -m "test2" -a -m "test3"') == 'git reset HEAD~'
    assert get

# Generated at 2022-06-18 08:08:02.642057
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:04.173939
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))



# Generated at 2022-06-18 08:08:05.890319
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:08:07.306710
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:08:12.336733
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', 'git commit -m test')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', 'git commit -m test', 'git commit -m test')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:14.290871
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:08:15.535977
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:17.246673
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git status', '', ''))


# Generated at 2022-06-18 08:08:18.364071
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:20.494399
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:09:18.369289
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:09:25.903702
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"')

# Generated at 2022-06-18 08:09:28.948553
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:09:31.657490
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:09:33.271797
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '/home/user/')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:41.801026
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', '', ''))

# Generated at 2022-06-18 08:09:43.842497
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:09:52.272980
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message" file', '', ''))
    assert not match(Command('git commit -m "message" file1 file2', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4', '', ''))
    assert not match(Command('git commit -m "message" file1 file2 file3 file4 file5', '', ''))

# Generated at 2022-06-18 08:09:59.328063
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:10:05.026082
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))