

# Generated at 2022-06-18 08:01:09.741839
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:01:18.137618
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -am "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -am "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -am "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:26.953245
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))
    assert not match(Command('git commit -m test', '', ''))

# Generated at 2022-06-18 08:01:28.106057
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:37.496549
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_

# Generated at 2022-06-18 08:01:39.310768
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:01:40.879727
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:42.445005
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:52.228044
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:01:59.331775
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit -m "test"', '', '/bin/git'))
    assert not match(Command('git commit -m "test"', '', '/bin/ls'))
    assert not match(Command('git commit -m "test"', '', '/bin/git', '--version'))
    assert not match(Command('git commit -m "test"', '', '/bin/git', '--version', '--help'))


# Generated at 2022-06-18 08:02:03.011476
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:02:04.913686
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/'))
    assert not match(Command('git commit', '', '/'))


# Generated at 2022-06-18 08:02:13.770725
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))
    assert not match(Command('git commit --amend -m "test"', '', ''))

# Generated at 2022-06-18 08:02:15.565313
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:17.444967
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:02:20.007792
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:02:29.550635
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"'))
    assert not match(Command('git commit -m "test"', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', '', '', ''))
    assert not match(Command('git commit -m "test"', '', '', '', '', '', '', '', '', ''))

# Generated at 2022-06-18 08:02:31.079704
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:32.371051
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:02:42.115559
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:02:45.512486
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:02:54.533323
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit -m "test"', '', '/tmp'))
    assert not match(Command('git commit --amend', '', '/tmp'))
    assert not match(Command('git commit --amend -m "test"', '', '/tmp'))
    assert not match(Command('git commit --amend --no-edit', '', '/tmp'))
    assert not match(Command('git commit --amend --no-edit -m "test"', '', '/tmp'))
    assert not match(Command('git commit --amend --no-edit -m "test"', '', '/tmp'))

# Generated at 2022-06-18 08:02:56.881792
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:02:58.602422
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:09.246558
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:12.635803
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:03:21.578708
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))
    assert not match(Command('git commit -m "hello"', ''))

# Generated at 2022-06-18 08:03:30.959168
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test" --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" --no-edit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:40.047334
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:42.170676
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:03:47.275988
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:03:56.245718
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit --amend', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))
    assert not match(Command('git commit --amend -m "message"', '', ''))

# Generated at 2022-06-18 08:04:04.631277
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:04:12.717245
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:04:14.362081
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:04:16.312298
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:04:24.414323
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:26.150211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:04:34.905688
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~1'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~2'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~3'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~4'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~5'
    assert get_new_command('git commit -m "test"') != 'git reset HEAD~6'

# Generated at 2022-06-18 08:04:43.825864
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/home/user/git-repo'))
    assert not match(Command('git commit', '', '/home/user/git-repo',
                             stderr='fatal: Not a git repository'))
    assert not match(Command('git commit', '', '/home/user/git-repo',
                             stderr='fatal: Not a git repository (or any of the parent directories): .git'))
    assert not match(Command('git commit', '', '/home/user/git-repo',
                             stderr='fatal: Not a git repository (or any of the parent directories): .git'))

# Generated at 2022-06-18 08:04:48.788610
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:04:51.358657
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))


# Generated at 2022-06-18 08:04:52.947216
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:01.827111
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:05:03.880527
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))



# Generated at 2022-06-18 08:05:12.570561
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:15.129007
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', '/home/user/test'))
    assert not match(Command('git status', '', '/home/user/test'))


# Generated at 2022-06-18 08:05:17.130015
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:05:18.925731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:20.607254
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:30.484006
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" file1 file2', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit file1 file2', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -am "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:34.565279
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))
    assert not match(Command('git commit', '', '/bin/git', '--help'))


# Generated at 2022-06-18 08:05:35.819405
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:37.668238
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:39.488738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:41.773717
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/usr/bin/git'))
    assert not match(Command('git commit', '', '/usr/bin/ls'))


# Generated at 2022-06-18 08:05:43.683715
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:05:46.647462
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD~1'


# Generated at 2022-06-18 08:05:48.182473
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:49.189731
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:05:53.324271
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:54.676379
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:05:57.000846
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:05:58.659022
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:06:00.308018
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:06:01.468726
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:03.459927
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:06:11.846889
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit --amend', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit --amend -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit --amend --no-edit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit --amend --no-edit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:19.929657
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))
    assert not match(Command('git commit -m "test"', ''))

# Generated at 2022-06-18 08:06:21.981435
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD~1'


# Generated at 2022-06-18 08:06:27.343527
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:06:29.137342
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('git commit -m "test"', '', '')
    assert get_new_command(command) == 'git reset HEAD~'

# Generated at 2022-06-18 08:06:30.509428
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:06:32.254095
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git add', '', '/tmp'))


# Generated at 2022-06-18 08:06:40.347137
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"')

# Generated at 2022-06-18 08:06:42.005853
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))



# Generated at 2022-06-18 08:06:43.831850
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:06:45.465693
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:06:48.031102
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:06:54.181761
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:01.196549
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:10.639877
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:07:13.638724
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:07:15.790094
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:07:22.923605
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:32.859102
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m test') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -m test3') == 'git reset HEAD~'
    assert get_new_command('git commit -m test -a -m test2 -m test3 -m test4') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:35.731201
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "message"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:07:43.813944
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:07:50.895897
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test" -a -m "test2" -m "test3"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:07:52.803040
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:08:03.751575
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert match(Command('git commit -m "test"', '', '/bin/git'))
    assert not match(Command('git commit -m "test"', '', '/bin/ls'))
    assert not match(Command('git commit -m "test"', '', '/bin/git', '--git-dir=/tmp/test/.git'))


# Generated at 2022-06-18 08:08:10.076518
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:17.567504
# Unit test for function match
def test_match():
    assert match(Command('git commit', ''))
    assert not match(Command('git commit -m', ''))
    assert not match(Command('git commit -m "message"', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))
    assert not match(Command('git commit -m "message" file1 file2', ''))


# Generated at 2022-06-18 08:08:19.303985
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:08:26.525598
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp/'))
    assert not match(Command('git commit', '', '/tmp/test'))
    assert not match(Command('git commit', '', '/tmp/test/'))
    assert not match(Command('git commit', '', '/tmp/test/test'))
    assert not match(Command('git commit', '', '/tmp/test/test/'))
    assert not match(Command('git commit', '', '/tmp/test/test/test'))
    assert not match(Command('git commit', '', '/tmp/test/test/test/'))
    assert not match(Command('git commit', '', '/tmp/test/test/test/test'))

# Generated at 2022-06-18 08:08:28.785450
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) != 'git reset HEAD'

# Generated at 2022-06-18 08:08:30.046529
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:08:33.022874
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))


# Generated at 2022-06-18 08:08:40.292855
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test" file') == 'git reset HEAD~'
    assert get_new_command('git commit --amend') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit --amend -m "test" file') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit') == 'git reset HEAD~'
    assert get_new_command('git commit --amend --no-edit file') == 'git reset HEAD~'
   

# Generated at 2022-06-18 08:08:41.438635
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:57.442444
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m test -a', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a -m test', '', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -a -m test -a', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:08:59.086155
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/tmp'))
    assert not match(Command('git commit', '', '/tmp'))


# Generated at 2022-06-18 08:09:00.687424
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:08.350029
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:09:09.668485
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:11.369074
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))



# Generated at 2022-06-18 08:09:12.922260
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:15.118605
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:09:16.650218
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:09:24.653402
# Unit test for function match
def test_match():
    assert match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:09:33.645203
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git add', '', ''))


# Generated at 2022-06-18 08:09:42.268959
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))

# Generated at 2022-06-18 08:09:51.062699
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'
    assert get_new_command('git commit -m "test"') == 'git reset HEAD~'

# Generated at 2022-06-18 08:09:58.160777
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:09:59.920972
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', '/bin/git'))
    assert not match(Command('git commit', '', '/bin/ls'))


# Generated at 2022-06-18 08:10:01.324317
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:10:06.162910
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"', 'git commit -m "test"')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:06.897843
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:08.478187
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) != 'git reset HEAD'


# Generated at 2022-06-18 08:10:09.355017
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:19.103042
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:10:20.528352
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:22.490287
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:29.567794
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))
    assert not match(Command('git commit -m "test"', '', ''))

# Generated at 2022-06-18 08:10:30.927025
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:10:38.461599
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:39.427394
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('git commit') == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:41.142130
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:10:42.624712
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '', '')) == 'git reset HEAD~'

# Generated at 2022-06-18 08:10:44.200444
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit', '', ''))


# Generated at 2022-06-18 08:11:01.390893
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('git commit -m "test"', '')) == 'git reset HEAD~'


# Generated at 2022-06-18 08:11:08.286830
# Unit test for function match
def test_match():
    assert match(Command('git commit', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))
    assert not match(Command('git commit -m "message"', '', ''))