

# Generated at 2022-06-24 22:50:40.591737
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    macs = {
        'lo': '00:00:00:00:00:00',
        'eth0': '00:00:00:00:00:00',
    }
    hurd_network_0 = HurdPfinetNetwork({}, macs)

# Generated at 2022-06-24 22:50:47.137014
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': '!all,!min',
        'gather_timeout': 1,
    }
    # FIXME: THIS WILL FAIL, BECAUSE WE NEED TO MOCK /servers/socket
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)


# Generated at 2022-06-24 22:50:57.176202
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork()
    assert(hurd_pfinet_network.__class__.__name__ == HurdPfinetNetwork.__name__)
    assert(hurd_pfinet_network.__doc__ == HurdPfinetNetwork.__doc__)
    assert(hurd_pfinet_network._socket_dir == HurdPfinetNetwork._socket_dir)
    assert(hurd_pfinet_network.platform == HurdPfinetNetwork.platform)
    assert(hurd_pfinet_network.assign_network_facts.__doc__ == HurdPfinetNetwork.assign_network_facts.__doc__)

# Generated at 2022-06-24 22:50:59.677347
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:51:07.394603
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Options(object):
        def __init__(self, module_name):
            self.module_name = module_name
    class Module(object):
        def __init__(self, run_command_method, get_bin_path_method):
            self.run_command = run_command_method
            self.get_bin_path = get_bin_path_method
    module_ex_1 = Module(run_command_method_ex_1, get_bin_path_method_ex)
    options_ex_1 = Options('test_module')
    test_hurd_pfinet_network_ex_1 = HurdPfinetNetwork(module_ex_1, options_ex_1)

# Generated at 2022-06-24 22:51:10.308988
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:51:20.274222
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/hurd/fsysopts'
    socket_path = '/servers/socket/inet'
    out_mock = '--interface=/dev/eth0 --address=172.16.1.113 --netmask=255.255.255.0 --address6=fe80::20c:29ff:fe7f:d3f3/64 --address6=fc00::21:b68a:80d1:b1f6/64'
    err_mock = ''
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, out_mock, err_mock)
    hurd_network_collector_0 = HurdPfinetNetwork(module_mock)
    res = hurd_network_

# Generated at 2022-06-24 22:51:29.881606
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    # No file named /servers/.../inet
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/nopath'
    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    assert hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path) == {}
    # Create fake /servers/.../inet
    os.makedirs('/servers/socket')
    with open('/servers/socket/inet', 'w') as f:
        f.write('fake inet')
    assert hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:51:32.102923
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert hasattr(HurdNetworkCollector, '_platform')
    assert hasattr(HurdNetworkCollector, '_fact_class')


# Generated at 2022-06-24 22:51:43.188691
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)
    assert hurd_network_collector_0.platform == 'GNU'
    assert hurd_network_collector_0.fact_class == HurdPfinetNetwork
    assert isinstance(hurd_network_collector_0.facts['default'], HurdPfinetNetwork)


if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:51:57.356407
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_1 = HurdPfinetNetwork(module=None)
    assert(hurd_pfinet_network_0.module is not None)
    assert(hurd_pfinet_network_1.module is None)

# Generated at 2022-06-24 22:52:05.843297
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    lines = '''--interface=/dev/eth0
--address=10.0.0.203
--netmask=255.255.255.0
--address6=fe80::223:6cff:fe96:1810/64'''.splitlines()
    pfinet = HurdPfinetNetwork(module=None)
    iface = pfinet.assign_network_facts({}, None, None)
    assert iface['interfaces'] == ['eth0']
    assert 'ipv4' in iface['eth0']
    assert 'ipv6' in iface['eth0']
    assert 'address' in iface['eth0']['ipv4']
    assert 'netmask' in iface['eth0']['ipv4']

# Generated at 2022-06-24 22:52:10.536663
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork({})
    network_facts = {}
    fsysopts_path = os.path.join("hurd","fsysopts")
    socket_path = "/servers/socket"
    hurd_pfinet_network_0.assign_network_facts(network_facts,fsysopts_path,socket_path)


# Generated at 2022-06-24 22:52:12.838544
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-24 22:52:20.665372
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts_0 = {}
    fsysopts_path_0 = 'fsysopts'
    socket_path_0 = '/servers/socket/inet'
    return_value_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:52:21.913250
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Unit test of assign_network_facts()

# Generated at 2022-06-24 22:52:23.872346
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert hurd_network_collector_0.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-24 22:52:26.398886
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()


# Generated at 2022-06-24 22:52:29.615865
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    gnu_pfinet_network_0 = HurdPfinetNetwork(dict(), 'ansible.module_utils.facts.system.gnu.gnu')

if __name__ == '__main__':
    test_case_0()

    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:52:30.143867
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-24 22:52:47.133148
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '7'
    str_1 = '5eoU6jYU6'
    str_2 = 'MjIX'
    str_3 = 'r,Wx'
    str_4 = 'gY@tw\nH'
    str_5 = '~q>'
    str_6 = 'Z+gT(/2'
    str_7 = '9_p'
    str_8 = 'sM,W'
    str_9 = '#6v,=J'
    str_10 = '+'
    str_11 = 'W'
    str_12 = 'Y1%K;!a'
    tuple_0 = ()
    str_13 = '{VrwFt'
    str_14 = 'o'
    str_15 = 'b'
   

# Generated at 2022-06-24 22:52:48.210308
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:52:56.624239
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    str_0 = '-L'
    str_1 = '/dev/pty'
    list_0 = []
    str_2 = 'interface=--/dev/eth0'
    list_0.append(str_2)
    str_3 = 'address=--192.168.1.42'
    list_0.append(str_3)
    str_4 = 'netmask=--255.255.255.0'
    list_0.append(str_4)
    str_5 = 'address6=--fe80::20c:29ff:fe63:40a9%eth0/64'
   

# Generated at 2022-06-24 22:53:04.026249
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_1 = 'j(}'
    hurd_pfinet_network_1 = HurdPfinetNetwork(str_1)
    fsysopts_path_1 = None
    socket_path_1 = None

    def run_command_mock(self, cmd):
        return 0, 'i=val_i\ni=val_i\ni=val_i\ni=val_i\ni=val_i\n', None
    hurd_pfinet_network_1.run_command = run_command_mock.__get__(hurd_pfinet_network_1)

    var_1 = hurd_pfinet_network_1.assign_network_facts({}, fsysopts_path_1, socket_path_1)
    assert(var_1 == {'interfaces': []})

# Generated at 2022-06-24 22:53:14.795932
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Load test data
    config_path = os.path.join(os.path.dirname(__file__), 'assign_network_facts.json')
    import json

    with open(config_path, 'r') as config_file:
        config_data = json.load(config_file)

    # Call assign_network_facts function
    # Assign returned object to a variable
    for test in config_data:
        network_facts = test['input']['network_facts']
        fsysopts_path = test['input']['fsysopts_path']
        socket_path = test['input']['socket_path']
        output = HurdPfinetNetwork.assign_network_facts(network_facts, fsysopts_path, socket_path)
        # compare the dictionary result and output


# Generated at 2022-06-24 22:53:24.636936
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Setup
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    network_facts_0 = {}
    fsysopts_path_0 = '\td \x1d\x14\rP'
    socket_path_0 = '\x1b\x02l\x12I'
    # Call the method
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)
    # Assertions
    assert var_0 == {}


# Generated at 2022-06-24 22:53:27.171228
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:53:33.546513
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    var_1 = 'XJ8l1%Ogk?A\f'
    hurd_pfinet_network_1 = HurdPfinetNetwork(var_1)
    assert isinstance(hurd_pfinet_network_1, HurdPfinetNetwork)
    # call method populate
    var_2 = hurd_pfinet_network_1.populate()


# Generated at 2022-06-24 22:53:40.245423
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = '\x0c'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    var_0 = hurd_network_collector_0._fact_class
    str_1 = '\x0c'
    str_2 = '\x0c'

    # Test with valid arguments
    var_1 = hurd_network_collector_0.collect(str_1, str_2)
    # Test with invalid arguments
    # var_2 = hurd_network_collector_0.collect(str_2)


# Generated at 2022-06-24 22:53:44.889875
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:54:00.244712
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)

# Generated at 2022-06-24 22:54:01.253218
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()



# Generated at 2022-06-24 22:54:04.010295
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)


# Generated at 2022-06-24 22:54:08.017102
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()
    # Test with the following argument: collected_facts
    # FIXME: How to create an object of type 'collected_facts' ?
    #
    #assert isinstance(var_0, Network)
    assert var_0 is None


# Generated at 2022-06-24 22:54:13.692385
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)

if __name__ == "__main__":
    test_case_0()
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:54:15.179632
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:54:22.024932
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_1 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_1 = HurdPfinetNetwork(str_1)
    str_2 = 'KX9*wi3q,7:Q\'f["a'
    hurd_pfinet_network_2 = HurdPfinetNetwork(str_2)
    str_3 = 'nq,\'Y>$"l=xF%@<L'
    hurd_pfinet_network_3 = HurdPfinetNetwork(str_3)


# Generated at 2022-06-24 22:54:27.165247
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert hurd_network_collector_0._fact_class == HurdPfinetNetwork, 'Unable to initialize class HurdNetworkCollector'
    assert hurd_network_collector_0._platform == 'GNU', 'Unable to initialize class HurdNetworkCollector'


# Generated at 2022-06-24 22:54:31.169632
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    assert hurd_pfinet_network_0.module == str_0


# Generated at 2022-06-24 22:54:33.840350
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    var_0 = hurd_network_collector_0.get_facts()

# Generated at 2022-06-24 22:55:02.688046
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    _platform = '_nB1.:\rHq"#1ik\t&Q0'
    _fact_class = HurdPfinetNetwork
    obj = HurdNetworkCollector(_platform, _fact_class)
    # Testing if instance created properly
    assert(isinstance(obj, HurdNetworkCollector))


# Generated at 2022-06-24 22:55:05.589696
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'L-\x00\x00\x00\x80\x00\x00'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    var_0 = hurd_network_collector_0.collect()

# Generated at 2022-06-24 22:55:06.195706
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:55:07.231918
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:55:11.694113
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'GR\x7f)\x0cU'
    hurd_network_collector_0 = HurdNetworkCollector(str_0, str_0)
# AssertionError: (var_1 != var_2)


# Generated at 2022-06-24 22:55:18.258800
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '*@FnXC!0(!|f+G$\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    collected_facts_0 = set()
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = ''
    var_0 = hurd_pfinet_network_0.assign_network_facts({}, fsysopts_path_0, socket_path_0)
    assert len(var_0) == 1


# Generated at 2022-06-24 22:55:23.225726
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '`rFPlKH%c1'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    fsysopts_path = '/bin/fsysopts'
    socket_path = '@Jc'
    var_0 = hurd_pfinet_network_0.assign_network_facts(None, fsysopts_path, socket_path)



# Generated at 2022-06-24 22:55:26.411119
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'VrO;*l`s%>M"y\n%'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    network_facts_0 = {}
    fsysopts_path_0 = '/usr/local/sbin/fsysopts'
    socket_path_0 = '*.>/A0vC"W]F=}'
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:55:35.999464
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    cmd = 'fsysopts -L /servers/socket/inet'
    current_if = None
    from ansible.module_utils.facts import default_collector
    default_collector.module.run_command = lambda x: ('', '--interface=/dev/eth0\n--address=127.0.0.1\n--netmask=255.0.0.0\n', '')
    network_facts = default_collector.populate()
    assert(network_facts['interfaces'] == ['eth0'])
    assert(network_facts['default_ipv4']['interface'] == 'eth0')
    assert(network_facts['default_ipv4']['address'] == '127.0.0.1')

# Generated at 2022-06-24 22:55:43.359096
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'
    var_3 = hurd_pfinet_network_0.assign_network_facts({}, fsysopts_path_0, socket_path_0)
    assert var_3 == {}



# Generated at 2022-06-24 22:56:53.158503
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)



# Generated at 2022-06-24 22:56:55.997962
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_1 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_network_collector_0 = HurdNetworkCollector(str_1)
# Class attribute, size is 1
    var_1 = HurdNetworkCollector._platform
# Class attribute, size is 1
    var_2 = HurdNetworkCollector._fact_class

# Generated at 2022-06-24 22:56:58.943782
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:57:00.317678
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:57:05.954281
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'O[|Wx1@"F&\t$pY'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    assert isinstance(hurd_network_collector_0, NetworkCollector)


# Generated at 2022-06-24 22:57:12.559881
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    print("test_HurdPfinetNetwork_populate")
    str_0 = '\x1c'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()
    print(var_0)


# Generated at 2022-06-24 22:57:16.098322
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:57:24.960623
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    network_facts_0 = dict()
    collected_facts_0 = dict()
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'

    # Call assign_network_facts
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)
    assert var_0 is not None

# Generated at 2022-06-24 22:57:29.112232
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'K!D'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    dict_0 = dict()
    str_1 = ')'
    str_2 = ':'
    var_0 = hurd_pfinet_network_0.assign_network_facts(dict_0, str_1, str_2)


# Generated at 2022-06-24 22:57:32.286249
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    HurdPfinetNetwork_instance = HurdPfinetNetwork('')
    test_case_0()

# Generated at 2022-06-24 23:00:03.979853
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    a = HurdNetworkCollector()
    b = HurdNetworkCollector()
    c = HurdNetworkCollector()
    assert (a != b)
    assert (a != c)
    assert (b != c)


# Generated at 2022-06-24 23:00:07.220518
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 23:00:16.562347
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert var_0 == {u'interfaces': [u'eth0']}
    str_1 = '_nB1.:\rHq"#1ik\t&Q0'
    hurd_pfinet_network_1 = HurdPfinetNetwork(str_1)
    var_1 = hurd_pfinet_network_1.populate()
    assert var_1 == {u'interfaces': [u'eth0']}

# Generated at 2022-06-24 23:00:26.856951
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'a: yP7j4A'
    str_1 = '`"u'
    str_2 = '--interface=/dev/eth0'
    str_3 = '--address=10.0.2.15'
    str_4 = '--netmask=255.255.255.0'
    str_5 = '--interface=/dev/lo'
    str_6 = '--address=127.0.0.1'
    str_7 = '--netmask=255.0.0.0'
    str_8 = '--address6=::1/128'
    str_9 = '--address6=fe80::a00:27ff:fe76:5a5/64'
    str_10 = 'A7?d3t'
    str_11 = '-L'
