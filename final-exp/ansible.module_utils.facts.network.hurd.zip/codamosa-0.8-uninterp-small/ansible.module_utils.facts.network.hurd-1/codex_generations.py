

# Generated at 2022-06-24 22:50:40.591196
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector = HurdNetworkCollector()

# Generated at 2022-06-24 22:50:43.278685
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a HurdPfinetNetwork object
    # and run the populate method on it
    # check the result with: assertEqual(first, second, msg)
    module = FakeModule()
    hurd_network_0 = HurdPfinetNetwork(module=module)
    # FIXME: run network populate!
    result = hurd_network_0.populate()
    # ...


# Generated at 2022-06-24 22:50:50.725812
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys
    if sys.platform.startswith('gnu'):
        from ansible.module_utils.facts import collector
        from ansible.modules.system.testing.test_test_module import TestModule

        test_module = TestModule({})
        collect = collector.collect
        facts = collect(test_module)
    else:
        facts = {'network': {'interfaces': {}}}
    return facts

if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork_populate()

# Generated at 2022-06-24 22:50:57.005449
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    collected_facts = {}
    test_obj = HurdPfinetNetwork()
    test_obj.module.get_bin_path = MagicMock(side_effect=[None])
    test_obj.assign_network_facts = MagicMock(return_value={})
    output = test_obj.populate(collected_facts)
    assert(output == {})
    assert(test_obj.module.get_bin_path.call_count == 1)
    assert(test_obj.assign_network_facts.call_count == 0)


# Generated at 2022-06-24 22:50:58.322944
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Unit test of function HurdPfinetNetwork.populate

# Generated at 2022-06-24 22:51:06.331468
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    # initialize
    hurd_pfinet_network = HurdPfinetNetwork()
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    # Test the first interface
    out = '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe2b:cb7/64'
    rc = 0
    err = ''
    network_facts = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
   

# Generated at 2022-06-24 22:51:08.421157
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    if '__init__' in dir(HurdNetworkCollector):
        assert(set(['platform', 'fact_class']) == set(HurdNetworkCollector.__init__.__code__.co_varnames))
    else:
        assert False


# Generated at 2022-06-24 22:51:12.410382
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Constructor needs to be called.
    # Just assert that it returns something.
    assert(HurdNetworkCollector() is not None)


# Generated at 2022-06-24 22:51:14.055064
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    assert False, 'HurdPfinetNetwork::assign_network_facts not implemented'


# Generated at 2022-06-24 22:51:20.835269
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:51:33.841190
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:51:44.393465
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_2 = b'\xb9R\x9d}\xdf\xe8\xf6\x1f\xdd\xbd\x02\xec\x9b\x9eN\x8b\x91\xfa\xd4\xec\x8d\x0f^\xdc\xbe\x1b\xf7\xfc\x97\xe5\xf1\x16\x06'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_2)
    var_1 = hurd_pfinet_network_2.populate()
    dict_1 = {var_1: hurd_pfinet_network_2, bytes_2: var_1}

# Generated at 2022-06-24 22:51:48.187898
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:51:50.204477
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test case 0: Class should not fail with default arguments
    network_collector_0 = HurdNetworkCollector()

    # Test case 1: Class should not fail with custom arguments
    network_collector_1 = HurdNetworkCollector("test_case_1")

# Generated at 2022-06-24 22:51:58.349188
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:52:08.845761
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/sbin/fsysopts'
    socket_path = '/servers/socket/inet'
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    try:
        var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
        assert var_0 == {}
    except:
        assert False


# Generated at 2022-06-24 22:52:14.167282
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert callable(HurdPfinetNetwork)
    assert isinstance(HurdPfinetNetwork, type)
    assert hasattr(HurdPfinetNetwork, 'assign_network_facts')
    assert callable(HurdPfinetNetwork.assign_network_facts)
    assert hasattr(HurdPfinetNetwork, 'populate')
    assert callable(HurdPfinetNetwork.populate)
    assert hasattr(HurdPfinetNetwork, '_socket_dir')
    assert hasattr(HurdPfinetNetwork, 'platform')


# Generated at 2022-06-24 22:52:25.721106
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    str_0 = 'fsysopts'
    str_1 = '/servers/socket/inet6'
    str_2 = '#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)
    var

# Generated at 2022-06-24 22:52:33.527362
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-24 22:52:44.930298
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'R\x9a\x1e\x16\x07\xc5\x8f\x81\xe5\x1cQ\x88\x9a\x98\x84\xc7\x1c\xac\x86\xff\x81F\x9e\xad\x9e\x15\xc4\x1eK\xd2\x00\x1e[\x83\x90\xab\xbe\xc0\\\x8e\x1b'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    hurd_pfinet_network_0.assign_network_facts(bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-24 22:53:01.413265
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:53:05.695387
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'


# Generated at 2022-06-24 22:53:14.285956
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)
    print(str(var_0))
    print(str(var_0))
    assert False


# Generated at 2022-06-24 22:53:23.419745
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:53:30.526271
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\xdd\xdf\xe8\xed\xf4\xec\x1b\xdc\xf9\x91\xea\xdbQs\xc8\x97\xb7\x85\x03\xdd\x9b\x91\xcf\x9b\xd6'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert var_0 is None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:53:35.145916
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-24 22:53:37.605585
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    yaml_0 = HurdNetworkCollector()
    assert isinstance(yaml_0, HurdNetworkCollector)


# Generated at 2022-06-24 22:53:38.905381
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    cases = [test_case_0]

    for case in cases:
        case()

# Generated at 2022-06-24 22:53:47.200515
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\x0c\x0f\x8c\x84\xdc\x96\xee\x8du\xb2\xeb\xbe\xfe_\x8bBk\xc1'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    # assert var_0['interfaces'] == ['lo', 'eth0']
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)

# Generated at 2022-06-24 22:53:54.935411
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    str_0 = '6'
    str_1 = ''
    str_2 = "l'"
    str_3 = ''
    str_4 = 'E'

# Generated at 2022-06-24 22:54:22.240988
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x1b\x1b\xb6\xaa\xdd\x9c9\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    # Assign call arguments
    hurd_pfinet_network_0.network_facts = dict()
    hurd_pfinet_network_0.fsysopts_path = None
    hurd_pfinet_network_0.socket_path = None


# Generated at 2022-06-24 22:54:32.244984
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_1 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_1)
    var_1 = hurd_pfinet_network_2.populate()
    dict_1 = {var_1: hurd_pfinet_network_2, bytes_1: var_1}
    hurd_pfinet_network_3 = HurdPfinetNetwork(dict_1)
    return hurd_pfinet_network_3
    #assert isinstance(hurd_pfinet_network_3, )


# Generated at 2022-06-24 22:54:43.341495
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)
    network_facts = {}
    fsysopts_path = '/dev'
    socket_path = '/lib/libc.a'

# Generated at 2022-06-24 22:54:53.147740
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\xc6\x80\xe9\x8c\x81\x0b\x91\x1c\x00\xee\xb4\x0f\x9a\x1c\xa6\x04C\x8fD\xd6\xad\xc2\x9b\x8d\xdc\x1e'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:55:02.896109
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)

    bytes_0 = b"interface="
    str_1 = '--interface'
    str_2 = '--netmask'
    str_3 = '--address'
    str_4 = '--address6'
    var_0 = '/servers/socket/inet'
    bytes_1 = b'--interface=/dev/eth0'
    bytes_2 = b'--netmask=FFFFFFFF'
    bytes_3 = b'--address=1.2.3.4'

# Generated at 2022-06-24 22:55:09.721037
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Testing constructor of class HurdNetworkCollector
    hurd_network_collector_0 = HurdNetworkCollector()
    return


if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:55:12.159036
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()

# Generated at 2022-06-24 22:55:20.920196
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\xa0\x02\xfe\x04P\xca\xda\x17\x9c]\xdc\x03\xc5J5\x8d\x0f'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    out_0 = b''
    with open(r'/dev/pty', 'rb') as file_0:
        var_0 = file_0.read()
        file_0.close()
    var_1 = hurd_pfinet_network_0.module
    var_1.run_command = lambda *arg_0: (0, out_0, b'')
    var_2 = None

# Generated at 2022-06-24 22:55:28.961236
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = bytes([124, 109, 37, 103, 62, 65, 107, 109, 140, 79, 68, 108, 118, 35, 35, 35])
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)
    hurd_network_collector_1 = HurdNetworkCollector(dict())
    dict_0 = {hurd_network_collector_0: hurd_network_collector_1, bytes_0: hurd_network_collector_0}

# Generated at 2022-06-24 22:55:29.837134
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork
    

# Generated at 2022-06-24 22:56:30.805202
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_1 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_1)
    var_1 = hurd_pfinet_network_2.populate()
    dict_1 = {var_1: hurd_pfinet_network_2, bytes_1: var_1}
    hurd_pfinet_network_3 = HurdPfinetNetwork(dict_1)


# Generated at 2022-06-24 22:56:36.665383
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:56:43.399442
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x88\xa7\x0b\x07\xf6\x00\x1d\x89\x96E\x8a\x95\xbc\xad\x11'
    os_0 = os.urandom(bytes_0)

# Generated at 2022-06-24 22:56:44.200056
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:56:45.891496
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert test_case_0() == None, "Constructor of class HurdPfinetNetwork"


# Generated at 2022-06-24 22:56:49.132380
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass


# Generated at 2022-06-24 22:56:52.932418
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:56:57.903699
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Test HurdPfinetNetwork.assign_network_facts()
    """

    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)

    # Example from the docs
    hurd_pfinet_network_0.assign_network_facts(None, b'/file/system/options', b'/link/to/interface')
    # Asserts that the created interface is 'eth0'
    assert 'eth0' in hurd_pfinet_network_0.populate()



# Generated at 2022-06-24 22:57:05.765820
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x9d\x81\x94\xfd\x1c\xa8u\xb3\xf7l\xd2\xb3\xba2'
    int_0 = HurdNetworkCollector(bytes_0)
    int_0.populate()
    dict_0 = {bytes_0: int_0}
    int_1 = HurdNetworkCollector(dict_0)


# Generated at 2022-06-24 22:57:14.370034
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'#\xd7\xdd\x19\x9f\x1f\xd5\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    dict_0 = {}
    str_0 = hurd_pfinet_network_0.assign_network_facts(dict_0, '', '', )
    assert dict_0[0][0] == ';'


# Generated at 2022-06-24 22:59:19.177571
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    HurdPfinetNetwork.assign_network_facts()


# Generated at 2022-06-24 22:59:25.867176
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Init class
    hurd_pfinet_network = HurdPfinetNetwork()

    # Call method
    result = hurd_pfinet_network.populate()

if __name__ == '__main__':
    # print(test_case_0())
    test_HurdPfinetNetwork_populate()

# Generated at 2022-06-24 22:59:28.797174
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:59:38.152468
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_1 = b'\x0f\x99\xf8\x00\x80\x00\x01\x00\x00\x00\x00\x01\x00\x00\x00'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_1)
    var_1 = hurd_pfinet_network_2.populate()
    # FIXME: verify all attributes
    # assert var_1 == ...
    # print(var_1)
    var_2 = HurdPfinetNetwork(var_1)
    # assert var_2 == ...
    # print(var_2)


# Generated at 2022-06-24 22:59:44.555835
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert hasattr(HurdPfinetNetwork, '_platform') == True
    assert hasattr(HurdPfinetNetwork, '_fact_class') == True
    assert hasattr(HurdPfinetNetwork, '__init__') == True
    assert hasattr(HurdPfinetNetwork, 'populate') == True
    assert callable(HurdPfinetNetwork.__init__) == True
    assert callable(HurdPfinetNetwork.populate) == True


# Generated at 2022-06-24 22:59:52.365884
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    file_0 = open('facts_d/network/HurdPfinetNetwork.populate()/input_0.txt', 'rb')
    bytes_0 = file_0.read()
    if not file_0.close():
        file_0.close()
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)


# Generated at 2022-06-24 22:59:57.715956
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\xac\xdc\xff\x82\x8f\x05\x1f\xfe\x9f\x82\xdb\xff\x08i\xd0\x01\xc0\xbf'
    dict_0 = {bytes_0: None}
    dict_1 = {bytes_0: None}
    dict_2 = {bytes_0: None}
    var_0 = HurdPfinetNetwork(dict_1)
    var_0 = var_0.assign_network_facts(dict_0, dict_1, dict_2)
    dict_3 = {var_0: var_0, dict_0: var_0, dict_1: var_0, dict_2: var_0}


# Generated at 2022-06-24 22:59:58.857329
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        assert False
    except:
        pass


# Generated at 2022-06-24 23:00:07.655351
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_1 = b'\xda\xdd\x18\x9f\x9e\xda\xf9\xa1p<\x83 u\x99\x98'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_1)
    inputs = {'network_facts': dict, 'fsysopts_path': '/dev/socket/inet', 'socket_path': 'dummy_value'}
    output = hurd_pfinet_network_2.assign_network_facts(**inputs)
    return output


# Generated at 2022-06-24 23:00:16.579909
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x04\xf9\x9f\xc7\x04\x8c\x97\x90\x0c\xbe_\x9f\xe9\xf0\x03\x93\x05\xf4>\xfb\xb4\xf4#\x9b\xcd\xea\x03\x97\xab\xd3\x04,}'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    dict_0 = {var_0: hurd_pfinet_network_0, bytes_0: var_0}
    hurd_pfinet_network_1 = HurdPfinetNetwork(dict_0)

#