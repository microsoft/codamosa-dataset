

# Generated at 2022-06-24 22:50:29.801181
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    hurd_network_collector_0 = HurdNetworkCollector(hurd_pfinet_network_0)


# Generated at 2022-06-24 22:50:40.615383
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    network_facts = {}
    fsysopts_path = "/run/current-system/sw/bin/fsysopts"
    socket_path = "/servers/socket/inet"
    ret = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert ret['interfaces'] == ['eth0', 'eth1', 'eth2'], '\nAssertion failed'

# Generated at 2022-06-24 22:50:49.913600
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)

    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)

    # Test empty network_facts
    network_facts_0 = {}
    fsysopts_path_0 = '--address6'
    socket_path_0 = '<function _unmarshal at 0xb724bce4>'

    result = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:50:53.188511
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Input parameters and expected result.
    bytes0 = b'\x8e\\'
    obj = HurdNetworkCollector(bytes0)

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:50:55.774781
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)


# Generated at 2022-06-24 22:51:05.389132
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    dict_0 = dict
    str_0 = 'ipv6'
    list_0 = list
    str_1 = 'netmask'
    str_2 = 'address'
    str_3 = 'address6'
    str_4 = 'interface'
    dict_1 = dict
    str_5 = 'ipv4'
    str_6 = 'interfaces'
    str_7 = '/dev/eth0'
    str_8 = 'active'
    str_9 = 'device'
    dict_2 = dict
    dict_3 = dict
    dict_4 = dict
    dict_5 = dict
    dict_6 = dict

    assert hurd_pfin

# Generated at 2022-06-24 22:51:07.729760
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\x8e\\'
    assert isinstance(HurdPfinetNetwork(bytes_0), HurdPfinetNetwork)


# Generated at 2022-06-24 22:51:12.875596
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    byte_0 = b'\x8e\\'
    arg_0 = ['arg_0']
    hurd_network_collector_0 = HurdNetworkCollector(byte_0, arg_0)


# Generated at 2022-06-24 22:51:20.678411
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    fsysopts_path = None
    socket_path = None
    network_facts = {}
    assert len(hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)) == 0
    fsysopts_path = '--interface=eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=0a00:0001:0002:0003:cafe:babe:0000:0001/64'
    socket_path = '10.0.0.1'

# Generated at 2022-06-24 22:51:30.201984
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    spaces_0 = '  '
    prefix_0 = '--'
    length_0 = 2
    string_0 = 'dummy'
    length_1 = 4
    string_1 = 'dev'
    string_2 = 'lo'
    string_3 = 'enp0s3'
    string_4 = '127.0.0.1/8'
    string_5 = '255.0.0.0'
    string_6 = '::1/128'
    string_7 = '10.0.2.15/24'
    string_8 = '255.255.255.0'

    # Init HurdPfinetNetwork
    hr_pfnet_nw_0 = HurdPfinetNetwork(bytes_0)

    # Mock

# Generated at 2022-06-24 22:51:43.437371
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}

    fsysopts_path = 'test_bin_path/fsysopts'
    socket_path = 'test_bin_path/socket'

    returned_network_facts = HurdPfinetNetwork.assign_network_facts(HurdPfinetNetwork(), network_facts, fsysopts_path, socket_path)

    print(returned_network_facts)
    assert returned_network_facts is not None


# Generated at 2022-06-24 22:51:46.607458
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        test_case_0()
    except NameError:
        return False
    return True



# Generated at 2022-06-24 22:51:53.014702
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {
        'interfaces': []
    }
    fsysopts_path = '/directory/fsysopts'
    socket_path = '/socket/path'
    out = '--interface=/dev/eth0 --address6=fe80::5054:ff:feaf:5e0a/64 --address=192.168.1.211 --netmask=255.255.255.0'
    err = ''
    rc = 0
    module_name = 'ansible.modules.network.gnu'
    module_mock = MagicMock(name=module_name)
    module_mock.run_command = MagicMock(return_value = (rc, out, err))

    network_0 = HurdPfinetNetwork(module_mock)

    result = network_0.assign_network_

# Generated at 2022-06-24 22:51:53.885558
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()


# Generated at 2022-06-24 22:52:01.901644
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    import sys
    import os

    modules_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    import json
    import traceback
    import ansible_module_HurdNetworkCollector

    if not os.path.exists(modules_path):
        print("Module for test does not exists")
        sys.exit(1)
    sys.path.append(modules_path)

    # Load the module to test
    module_to_test = ansible_module_HurdNetworkCollector
    class TestModule(object):
        def __init__(self):
            self.params = {}


# Generated at 2022-06-24 22:52:05.876966
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    answ = hurd_pfinet_network_0.populate()
    answ = hurd_pfinet_network_0.populate()
    assert answ != None

# Generated at 2022-06-24 22:52:13.745041
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    out = {'interfaces': ['eth0'],
        'eth0': {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '192.168.1.10',
            'netmask': '255.255.255.0'
        },
        'ipv6': [{
            'address': '2001:4860:4860::8888',
            'prefix': '64'
        },
        {
            'address': '2001:4860:4860::8844',
            'prefix': '64'
        },
        {
            'address': 'fe80::4e2:c9ff:fe19:7a72',
            'prefix': '64'
        }]
    }}


# Generated at 2022-06-24 22:52:25.357343
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    ansible_os_family = 'RedHat'
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = 'ethernet'
    network_facts = {}
    setattr(hurd_pfinet_network_0, 'module', lambda: None)
    setattr(hurd_pfinet_network_0, 'module', lambda: None)
    hurd_pfinet_network_0.module.run_command = lambda *args, **kwargs: (0, '', '')
    setattr(hurd_pfinet_network_0, 'module', lambda: None)
    setattr(hurd_pfinet_network_0, 'module', lambda: None)
    network_

# Generated at 2022-06-24 22:52:33.135121
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/servers/socket/inet'
    socket_path = '/servers/socket/inet'

# Generated at 2022-06-24 22:52:44.851355
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test input
    hurd_pfinet_network = HurdPfinetNetwork({},{'module_setup': True})

    # test input
    network_facts = {}
    fsysopts_path = '/hurd/pfinet'
    socket_path = '/hurd/pfinet/socket'

    # test output
    expected_output = {'interfaces': ['eth0'], 'eth0': {'ipv4': {'address': '172.16.22.185', 'netmask': '255.255.254.0'}, 'device': 'eth0', 'active': True, 'ipv6': [{'prefix': '64', 'address': 'fe80::e562:daff:fe7c:1b2e'}]}}

    # test execution
    real_output = hurd_pfinet

# Generated at 2022-06-24 22:52:55.513593
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # FIXME: Actually test something
    HurdPfinetNetwork().populate()

# Generated at 2022-06-24 22:52:58.418693
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_obj = HurdPfinetNetwork()
    # FIXME: mock module ?
    # FIXME: check datastructures ?
    assert test_obj.assign_network_facts(None, None, None) is not None

# Generated at 2022-06-24 22:53:07.212181
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    h = HurdPfinetNetwork()
    network_facts = {
        'interfaces': [],
    }

    h.assign_network_facts(network_facts, '/bin/false', 'socket_path')
    assert network_facts == {
        'interfaces': [],
    }

    h.assign_network_facts(network_facts, '/bin/true', 'socket_path')

# Generated at 2022-06-24 22:53:08.286994
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # FIXME: create a test file (perhaps in a temp directory) containing
    #        the response from fsysopts.
    pass


# Generated at 2022-06-24 22:53:16.644824
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Dummy objects.
    test_module = type('', (), dict(
        run_command=lambda *args, **kw: (0, '', '')))
    test_class = type('', (HurdPfinetNetwork,), dict(
        module=test_module()))
    # Test with no interfaces.
    network_facts = {}
    test_class.assign_network_facts(network_facts, '', '')
    assert 'interfaces' not in network_facts
    # Test with one interface.
    network_facts = {}
    test_class.assign_network_facts(network_facts, '', '')
    assert 'interfaces' not in network_facts
    # Test with one interface.
    network_facts = {}
    network_facts['interfaces'] = []
    test_class.assign_network

# Generated at 2022-06-24 22:53:27.256588
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    pfnet_0 = HurdPfinetNetwork()
    # Test case #0
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet6'
    result_0 = pfnet_0.assign_network_facts({}, fsysopts_path_0, socket_path_0)

# Generated at 2022-06-24 22:53:37.914927
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork({
        'ansible_facts': {},
        'ansible_modules': {
            'fsysopts': '/usr/bin/fsysopts',
            'get_bin_path': lambda a: '/usr/bin/fsysopts',
        },
        'ansible_module_utils': {
            'basic': {
                'run_command': lambda a: (
                    0,
                    'interface=--/dev/eth0 address=192.168.1.10 netmask=255.255.255.0 address6=2001:db8::56/64',
                    '',
                ),
            }
        },
    })

# Generated at 2022-06-24 22:53:39.944177
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """ Test constructor of class HurdNetworkCollector """
    assert HurdNetworkCollector()

# Make sure it does not break with an empty string

# Generated at 2022-06-24 22:53:41.899965
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test with class HurdNetworkCollector
    hurd_network_collector_0 = HurdNetworkCollector()



# Generated at 2022-06-24 22:53:50.455445
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    with open(os.path.join(os.path.dirname(__file__), 'Fsysopts_Output.txt')) as f:
        fsysopts_out = f.read()
    hurd_network_collector_0 = HurdNetworkCollector()
    network_facts = {}
    fsysopts_path = '/dev/null'
    socket_path = 'test:test:test:test:test:test:test'
    network_facts = hurd_network_collector_0.fact_class.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['lo', 'pflocal', 'eth0', 'eth1']
    assert network_facts['lo']['active'] == True

# Generated at 2022-06-24 22:54:01.030153
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert var_0 == None


# Generated at 2022-06-24 22:54:02.108037
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Test case 0
    test_case_0()

# Generated at 2022-06-24 22:54:05.061433
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:54:09.778060
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)
    var_0 = hurd_network_collector_0.collect()
    assert var_0.keys() == ['interfaces']
    var_1 = var_0['interfaces']
    assert var_1 == []

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:54:18.442636
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    os_path_exists_0 = os.path.exists
    os_path_exists_1 = os.path.exists
    os_path_exists_1 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0 = os.path.exists
    os_path_exists_0

# Generated at 2022-06-24 22:54:21.999429
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:54:32.632550
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0._ansible_version
    # '2.2.0',
    string_0 = '2.2.0'
    var_0 = var_0 == string_0
    assert var_0
    var_0 = hurd_pfinet_network_0._module_version
    # '2.2.0.0',
    string_0 = '2.2.0.0'
    var_0 = var_0 == string_0
    assert var_0
    var_0 = hurd_pfinet_network_0.module
    # hurd_pfinet_network_0.module,
    assert var

# Generated at 2022-06-24 22:54:43.373190
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network import Network, NetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork, HurdNetworkCollector
    from ansible.module_utils._text import to_bytes
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    # Test for potentially null path in constructor
    bytes_1 = b'r'
    hurd_pfinet_network_1 = HurdPfinetNetwork(bytes_1)
    # Test for potentially null path in constructor
    bytes_2 = b'#\x9a'
    hurd_pfinet_network_2 = HurdPfinetNetwork(bytes_2)

# Generated at 2022-06-24 22:54:47.659045
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    # real code to test:
    # assert_equal(network_facts, hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path))
    # assert_equal(network_facts['interfaces'], [])


# Generated at 2022-06-24 22:54:58.461131
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_1 = '/servers/socket/inet'
    network_facts_0 = {}
    rc_0, out_0, err_0 = hurd_pfinet_network_0.module.run_command([fsysopts_path_0, '-L', socket_path_1])
    network_facts_0['interfaces'] = []
    var_0 = iter(out_0.split())
    for i_0 in var_0:
        if '=' in i_0:
            if i_0.startswith('--'):
                k_0,

# Generated at 2022-06-24 22:55:21.887304
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    fsysopts_path_0 = hurd_pfinet_network_0.module.get_bin_path('fsysopts')
    assert fsysopts_path_0 is not None
    socket_path_0 = ''
    for l_0 in ('inet', 'inet6'):
        link_0 = os.path.join(hurd_pfinet_network_0._socket_dir, l_0)
        if os.path.exists(link_0):
            socket_path_0 = link_0
            break
    network_facts_0 = test_case_0()
    rc_0, out_0, err_0 = hurd_pfin

# Generated at 2022-06-24 22:55:24.677347
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:55:30.520101
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)

    # Call method assign_network_facts of class HurdPfinetNetwork
    assert False



# Generated at 2022-06-24 22:55:32.114845
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)


# Generated at 2022-06-24 22:55:38.174663
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    fsysopts_path = 'fpath'
    socket_path = 'spath'
    network_facts = {}
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:55:45.261159
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\xf1\xbf\n'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    fsysopts_path_0 = '/v\x7f\x11\x17\x1c'
    socket_path_0 = '\x1fE\x00U\x08'
    var_0 = hurd_pfinet_network_0.assign_network_facts(None, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:55:51.455423
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    if not isinstance(hurd_pfinet_network_0, HurdPfinetNetwork):
        fail("Type mismatch: {}".format(type(hurd_pfinet_network_0)))

# Generated at 2022-06-24 22:55:52.759723
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    pass


# Generated at 2022-06-24 22:55:55.992393
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)
    var_0 = hurd_network_collector_0.populate()

# Generated at 2022-06-24 22:56:00.244146
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)


# Generated at 2022-06-24 22:56:39.164548
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
#    var_0 = hurd_pfinet_network_0.populate()
    assert True == False


# Generated at 2022-06-24 22:56:40.546391
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:56:44.139027
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    var_0 = HurdNetworkCollector()
    var_0.populate()
    var_0.populate()
    var_0.populate()
    var_0.populate()


# Generated at 2022-06-24 22:56:46.106643
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bytes_0 = b'\xa0\x1a\x97\x9a\x80'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    # No test for __init__


# Generated at 2022-06-24 22:56:51.135129
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:56:55.407605
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)
    assert isinstance(hurd_network_collector_0._fact_class, HurdPfinetNetwork)


# Generated at 2022-06-24 22:57:00.221753
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:57:06.385236
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    # execute test for populate
    result = hurd_pfinet_network_0.populate()
    assert isinstance(result, dict)
    assert len(result) == 0


# Generated at 2022-06-24 22:57:09.669961
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert True == True


# Generated at 2022-06-24 22:57:18.045785
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    expected_0 = {
        'interfaces': [
            'pfinet',
        ],
        'pfinet': {
            'active': True,
            'device': 'pfinet',
            'ipv4': {
                'address': '10.0.2.15',
                'netmask': '255.255.255.0',
            },
            'ipv6': [
                {
                    'address': 'fe80::a00:27ff:fe2d:b449',
                    'prefix': '64',
                }
            ],
        },
    }
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    result_0 = hurd_pfinet_network_0.populate()
   

# Generated at 2022-06-24 22:58:51.268132
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:58:54.881903
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_network_collector_0 = HurdNetworkCollector(bytes_0)

# Generated at 2022-06-24 22:59:04.627807
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_1 = b'\x8e\\'
    hurd_pfinet_network_1 = HurdPfinetNetwork(bytes_1)
    var_1 = '1'
    var_2 = '/servers/socket/inet'
    var_3 = hurd_pfinet_network_1.assign_network_facts(var_1, var_1, var_2)

# Generated at 2022-06-24 22:59:11.837483
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    bytes_1 = b'\x8e\\'
    var_0 = hurd_pfinet_network_0.assign_network_facts(bytes_1, bytes_1, bytes_0)


# Generated at 2022-06-24 22:59:17.293955
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:59:22.548863
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    str_0 = 'FSYSOPTS'
    str_1 = '/servers/socket/'
    str_2 = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts('', str_0, str_1)
    var_1 = hurd_pfinet_network_0.assign_network_facts('', str_0, str_2)


# Generated at 2022-06-24 22:59:28.611716
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bytes_0 = b'\x8e\\'
    hurd_net_collector_0 = HurdNetworkCollector(bytes_0)
    assert hurd_net_collector_0 is not None
# End of test of HurdNetworkCollector

# Run test suite
if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:59:32.634137
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:59:36.217816
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bytes_0 = b'\x8e\\'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bytes_0)
    asser_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:59:39.563917
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    a = HurdNetworkCollector()
    print(a)
    # assert a == '<ansible.module_utils.facts.network.hurd.hurd.HurdNetworkCollector object at 0x7f1ccdade810>'