

# Generated at 2022-06-24 22:50:31.560975
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:50:41.321462
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    out = '''\
--interface=/dev/eth0 --address=10.30.4.126 --netmask=255.255.255.0 --address6=fe80::2fe0:4ff:fe2b:d07e/64
'''
    out = out.encode()
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/'

# Generated at 2022-06-24 22:50:48.649254
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    # TODO: initialize modules dict
    ansible_module_0 = {}
    hurd_network_collector_0.module = ansible_module_0
    # test the method assign_network_facts
    hurd_pfinet_network_0.assign_network_facts()


# Generated at 2022-06-24 22:50:51.195434
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert(HurdNetworkCollector._platform == 'GNU')
    assert(HurdNetworkCollector._fact_class == HurdPfinetNetwork)


# Generated at 2022-06-24 22:50:52.916348
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)
    # TODO: Additional tests needed


# Generated at 2022-06-24 22:50:53.653513
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_0 = HurdPfinetNetwork()

# Generated at 2022-06-24 22:51:03.308464
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {'interfaces': []}
    fsysopts_path = 'spec/fixtures/fsysopts'
    socket_path = 'spec/fixtures/socket'
    results = HurdPfinetNetwork().assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert 'en0' in results['interfaces']
    assert results['en0']['ipv4']['address'] == '10.0.0.8'
    assert results['en0']['ipv4']['netmask'] == '255.255.255.0'
    assert results['en0']['ipv6'][0]['address'] == 'fe80::215:5dff:fe28:b6a'



# Generated at 2022-06-24 22:51:10.370456
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_0._module = MagicMock()
    hurd_pfinet_network_0._module.run_command = MagicMock(return_value=(0, '--interface=eth0 --address=10.0.0.10 --netmask=255.255.255.0 --address6=2001:db8:1234::1/64', ''))
    network_facts = {}
    fsysopts_path = '/servers/socket/'
    socket_path = '/servers/socket/inet6'

# Generated at 2022-06-24 22:51:13.546923
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h_pfinet_network_0 = HurdPfinetNetwork()

if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:51:18.538667
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # create an instance of the HurdPfinetNetwork class with the module patched to run_command
    # so we are in control of what it returns
    hurd_pfinet_network_0 = HurdPfinetNetwork({'module': {'run_command': run_command_mock}})
    # run the populate method using the data that I want to test and capture what it returns
    # to test that it is correct
    facts = hurd_pfinet_network_0.populate()
    # assert that the methods return is correct

# Generated at 2022-06-24 22:51:32.064547
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_1 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
    assert len(var_1) == 17


# Generated at 2022-06-24 22:51:40.839150
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)



# Generated at 2022-06-24 22:51:49.272043
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    if (hurd_network_collector_0 is not None):
        if (not isinstance(dict_0, dict)):
            raise TypeError("Argument dict_0 must be type dict")
        if (not isinstance(bytes_0, str)):
            raise TypeError("Argument bytes_0 must be type str")

# Generated at 2022-06-24 22:51:53.264476
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:52:00.408655
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
    assert True
    # Unit test for method populate of class HurdPfinetNetwork


# Generated at 2022-06-24 22:52:08.766087
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:52:13.715487
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    dict_0 = None
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)

# Generated at 2022-06-24 22:52:22.556252
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:52:25.502617
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(collector_0)
    assert isinstance(hurd_pfinet_network_0.populate(), dict)


# Generated at 2022-06-24 22:52:30.571962
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.populate(set_0)

# Generated at 2022-06-24 22:52:46.852997
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:52:52.244257
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    set_0 = None
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.populate(set_0)

if __name__ == '__main__':
    test_HurdPfinetNetwork_populate()

# Generated at 2022-06-24 22:52:57.877150
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # TODO: this test should be in the constructor test of Network
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:53:06.157212
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)



# Generated at 2022-06-24 22:53:08.832319
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'e\x8e\xb5\x99\xea\nX\x89\xff\xa0\x97\xd2\x8bG\x94'
    hurd_network_collector_1 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_1, HurdNetworkCollector)


# Generated at 2022-06-24 22:53:11.242782
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)



# Generated at 2022-06-24 22:53:16.971594
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:53:26.709629
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    set_1 = None
    dict_1 = {
        'ans_distribution_version': '0.2',
        'ans_distribution_release': '6'
    }
    bytes_1 = b'V\x1d\x1f\x8a\x01\xcc*\x1b\x10\x08\x7f\x01'
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    var_1 = hurd_pfinet_network_1.populate(set_1, dict_1, bytes_1)



# Generated at 2022-06-24 22:53:37.471506
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():

    # using mock module to mock inner class
    from mock import Mock
    from mock import MagicMock
    from mock import patch
    from mock import mock_open
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    with patch("ansible.module_utils.facts.network.gnu.HurdNetworkCollector", new=Mock(return_value=HurdNetworkCollector())):
        with patch("ansible.module_utils.facts.network.gnu.HurdPfinetNetwork", new=Mock(return_value=HurdPfinetNetwork(HurdNetworkCollector()))):
            assert(HurdPfinetNetwork(HurdNetworkCollector()))



# Generated at 2022-06-24 22:53:45.990793
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\xd5N\xc5y\xb8\xa0\x00\x10@\xb7\x8d\x00{\xe0\x19\x00\x00\x00\x00\x00\x90H\xc0\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00P\xd9\xc7\x8d\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network

# Generated at 2022-06-24 22:54:17.473897
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test with a HurdNetworkCollector instance
    hurd_network_collector_0 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)
    # Test with a HurdPfinetNetwork instance
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    # Virtual method tests
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'

# Generated at 2022-06-24 22:54:24.883335
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    set_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:54:33.999827
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'd\xe3\x17\x8a\xe0\xb5\xc1\xdf[\x1a\x9d\xea\x04\xac\x15\xaa7\x90\x14\x89\x9f\xff\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    set_1 = None
    dict_1 = None
    bytes_1 = b'\x1bq\xc3\x08\x83\xdf9\xfb\xe1\xec\x00\xd3\xf3\xb3\x12P\xfa|\xfa\xcc\x90'
    hurd_network_collector_1 = Hurd

# Generated at 2022-06-24 22:54:40.461206
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0, set_0, dict_0, bytes_0)

# Generated at 2022-06-24 22:54:47.992265
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    assert (isinstance(hurd_pfinet_network_0, HurdPfinetNetwork))


# Generated at 2022-06-24 22:54:52.052236
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        HurdNetworkCollector()
    except TypeError as err:
        assert False, "Unexpected TypeError: {}".format(err)


# Generated at 2022-06-24 22:54:58.629979
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    dict_1 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:55:06.745476
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    set_0 = None
    dict_0 = None
    bytes_0 = b'j\x8e\x1f\xaa\x1d\x8f\x0ee\x16o\xdfc\x87'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)

# Generated at 2022-06-24 22:55:16.538052
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = dict()
    dict_0 = dict()
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)

    expected = dict()
    expected['interfaces'] = ['eth0']

# Generated at 2022-06-24 22:55:20.788527
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = None
    for l in ('inet', 'inet6'):
        link = os.path.join('/servers/socket/', l)
        if os.path.exists(link):
            socket_path = link
            break
    if socket_path is None:
        return
    network_facts = {}
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:56:16.071205
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )
    collector = HurdNetworkCollector()
    collector.populate(module)
    # test if execution was successful
    assert not module.fail_json.called
    # test if facts were added
    assert 'ansible_net_interfaces' in module.exit_json.called[0][0]['ansible_facts']

# Generated at 2022-06-24 22:56:23.643862
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_pfinet_network_0 = HurdNetworkCollector()
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
    test_var_0 = None
    assert test_var_0 == var_0, 'Assert failed testing assign_network_facts of class HurdNetworkCollector'


# Generated at 2022-06-24 22:56:31.114127
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)

    # call the method
    set_return = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
    assert set_return is None, "Return value is not as expected"

# Generated at 2022-06-24 22:56:32.086630
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:56:36.955935
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)

# Test case for method 'get_bin_path' of class 'Network'

# Generated at 2022-06-24 22:56:41.922995
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:56:44.107298
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    assert callable(HurdPfinetNetwork.assign_network_facts)


# Generated at 2022-06-24 22:56:50.049743
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)

    assert True


# Generated at 2022-06-24 22:56:58.185118
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
    print (var_0) # test assertion 1
    print (set_0) # test assertion 2
    print (dict_0) # test assertion 3
    print (bytes_0) # test assertion 4


# Generated at 2022-06-24 22:57:02.206424
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:59:04.579746
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert true # TODO: implement your test here


# Generated at 2022-06-24 22:59:13.679249
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)


# Generated at 2022-06-24 22:59:16.904559
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)



# Generated at 2022-06-24 22:59:22.296158
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    set_1 = None
    dict_1 = None
    bytes_1 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    var_1 = hurd_pfinet_network_1.assign_network_facts(set_1, dict_1, bytes_1)


# Generated at 2022-06-24 22:59:29.995113
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)

    # Unit test for method assign_network_facts of class HurdPfinetNetwork
    test_case_0()



# Generated at 2022-06-24 22:59:37.631221
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:59:40.917347
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    if isinstance(HurdNetworkCollector, object):
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:59:43.841140
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    set_1 = None
    dict_1 = None
    bytes_1 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_pfinet_network_1 = HurdPfinetNetwork(set_1, dict_1, bytes_1)


# Generated at 2022-06-24 22:59:46.637257
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    #FIXME:
    assert hasattr(hurd_network_collector_0, '_fact_class')


# Generated at 2022-06-24 22:59:54.315715
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    set_0 = None
    dict_0 = None
    bytes_0 = b'\x1c\x15\xdce\xbe\xe17s\x1b\xffv\xcc\x90'
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(set_0, dict_0, bytes_0)
