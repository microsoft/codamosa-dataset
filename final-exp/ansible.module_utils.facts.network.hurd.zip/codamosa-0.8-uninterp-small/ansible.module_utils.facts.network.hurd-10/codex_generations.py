

# Generated at 2022-06-24 22:50:34.645597
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-24 22:50:42.192131
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    params = {
        'fsysopts_path': 'fsysopts',
        'socket_path': '/servers/socket/inet'
    }
    results = {
        'interfaces': [],
    }

    hurd_pfinet_network_0 = HurdPfinetNetwork(None, None)
    results = hurd_pfinet_network_0.assign_network_facts(results, params['fsysopts_path'], params['socket_path'])
    # check interface
    assert results['interfaces'][0] == 'eth0'
    # check ipv4
    assert results['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-24 22:50:49.186345
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_HurdPfinetNetwork = HurdPfinetNetwork({})
    test_network_facts = {}
    test_fsysopts_path = 'fsysopts_path'
    test_socket_path = 'socket_path'
    assert test_HurdPfinetNetwork.assign_network_facts(test_network_facts, test_fsysopts_path, test_socket_path) == test_network_facts


# Generated at 2022-06-24 22:50:56.907771
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork(module=None)
    hurd_pfinet_network_1 = HurdPfinetNetwork(module=None)

    # Test return of method populate when no fact_class is provided
    assert not hurd_pfinet_network_0.populate()

    # Test return of method populate when fact_class is provided
    assert not hurd_pfinet_network_1.populate()



# Generated at 2022-06-24 22:51:03.304688
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Note: This test can be run on GNU platforms only"""
    hurd_network_0 = HurdPfinetNetwork()
    assert(hurd_network_0.platform == 'GNU')
    assert(hurd_network_0._socket_dir == '/servers/socket/')

    # TODO: need to find a way to mock fsysopts, fsysopts is not a standard GNU utility.

# Generated at 2022-06-24 22:51:06.991337
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts = hurd_pfinet_network_0.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')

# Generated at 2022-06-24 22:51:16.578765
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    hurd_network_0 = HurdPfinetNetwork(module=module)

# Generated at 2022-06-24 22:51:19.025389
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:20.878212
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)

# Generated at 2022-06-24 22:51:22.087982
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# vim: expandtab filetype=python:

# Generated at 2022-06-24 22:51:32.189690
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork() is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:51:34.318819
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    _mod = __import__('ansible.module_utils.facts.network.hurd', fromlist=['NetworkCollector'])
    assert type(_mod.NetworkCollector) == type(HurdNetworkCollector)


# Generated at 2022-06-24 22:51:35.935396
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdPfinetNetwork().platform == 'GNU'


# Generated at 2022-06-24 22:51:45.786524
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Test with empty facts, without fsysopts (fail)
    hurd_network_0 = HurdPfinetNetwork({}, {'path': None})
    ret = hurd_network_0.assign_network_facts({}, None, '')
    assert ret == {}

    # Test with empty facts and fsysopts, without socket file (fail)
    hurd_network_1 = HurdPfinetNetwork({}, {'path': '/tmp'})
    ret = hurd_network_1.assign_network_facts({}, '/bin/true', '/tmp/socket')
    assert ret == {}

    # Test with empty facts and fsysopts, with socket file (success)
    hurd_network_2 = HurdPfinetNetwork({}, {'path': '/tmp'})
    ret = hurd_network_2.assign_network

# Generated at 2022-06-24 22:51:51.337002
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    mock_module = Mock(**{'run_command.return_value': (0, '', '')})
    mock_module.get_bin_path.return_value = ""
    hurd_network_collector_1 = HurdNetworkCollector(mock_module)
    assert len(hurd_network_collector_1.fact_classes) == 1
    assert isinstance(hurd_network_collector_1.fact_classes[0], HurdPfinetNetwork)
    assert hurd_network_collector_1.fact_classes[0].module == mock_module


# Generated at 2022-06-24 22:51:59.605976
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {
        'interfaces': [],
    }

    fsysopts_path = os.path.join(os.path.dirname(__file__), 'assign_network_facts_case_0.txt')
    socket_path = os.path.join(os.path.dirname(__file__), 'assign_network_facts_case_0')

    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:52:01.621002
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:52:11.375348
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fixture = os.path.join(os.path.dirname(__file__), 'fixtures', 'test_HurdPfinetNetwork_fsysopts.txt')
    with open(fixture, 'rb') as f:
        content = f.read()

    fact_module = MockFactModule()
    fact_module.run_command_output = content

    hurd_pfinet_network_0 = HurdPfinetNetwork(fact_module)
    result = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:52:13.233315
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:52:15.345310
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_instance = HurdPfinetNetwork()
    assert isinstance(hurd_pfinet_network_instance.populate(), dict)

# Generated at 2022-06-24 22:52:34.626744
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    return_value = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert len(return_value) == 2
    assert return_value['interfaces'] == [
        'eth0',
    ]

# Generated at 2022-06-24 22:52:37.209357
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()

    assert True


# Generated at 2022-06-24 22:52:45.859552
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # pfinet facts (ipv4)
    network_facts = {}
    fsysopts_path = '/hurd/pfinet'
    socket_path = '/servers/socket/inet'
    out = ('--interface=/dev/eth0 '
            '--address=192.168.56.15 '
            '--netmask=255.255.255.0 ')
    expected = {'interfaces': ['eth0'],
                'eth0': {'active': True,
                         'device': 'eth0',
                         'ipv4': {'address': '192.168.56.15',
                                  'netmask': '255.255.255.0'},
                         'ipv6': []}}
    test0 = HurdPfinetNetwork()
    test0.module = object()

# Generated at 2022-06-24 22:52:49.826622
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    type:
    - ini
    - pfinet
    - hurd
    - collect
    - module
    - network
    """
    pfinet_network_0 = HurdPfinetNetwork(module=None)
    HurdPfinetNetwork.populate(pfinet_network_0)

# Generated at 2022-06-24 22:52:56.547002
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    def __init__(self):
        self.run_command_results = list()
        self.run_command_results.append(
            (0, '', '')
        )

    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    assert(hurd_pfinet_network_0.assign_network_facts({}, '', '') == {})

# Generated at 2022-06-24 22:52:58.137698
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:53:01.698872
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), HurdNetworkCollector)

# Generated at 2022-06-24 22:53:05.381683
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_0 = HurdPfinetNetwork(None)
    assert isinstance(network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:53:06.865006
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork()
    assert isinstance(m, HurdPfinetNetwork)


# Generated at 2022-06-24 22:53:13.504797
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hn = HurdPfinetNetwork()
    hn.module = MagicMock()
    hn.module.get_bin_path.return_value = '/bin'
    hn.module.run_command.return_value = (0, '--interface=/dev/eth0', '')

    network_facts = hn.populate()

    assert (network_facts == {'interfaces': ['eth0'],
                              'eth0': {'active': True,
                                       'device': 'eth0',
                                       'ipv4': {},
                                       'ipv6': []}})

# Generated at 2022-06-24 22:53:45.861001
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    network = HurdPfinetNetwork(module)

    # Test empty input
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert {} == network_facts

    # Test ifconfig return is not empty

# Generated at 2022-06-24 22:53:48.457976
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pfinet_network_0 = HurdPfinetNetwork()
    assert pfinet_network_0.platform == 'GNU'
    assert pfinet_network_0._socket_dir == '/servers/socket/'


# Generated at 2022-06-24 22:53:57.993798
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts_0 = {}
    fsysopts_path_0 = "E8+Ar`T0T'T$B:I;+#=F&P$Z/Y?Yb+!o)W8xXUy^>Jf507:U+?%\CQO&Z.3HJ.(U"
    socket_path_0 = 'fU_e6-:0gW%\8aH]@q3rBF#v<T{n+8^X<n@T2T;~fck'

# Generated at 2022-06-24 22:53:59.572019
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:54:00.450944
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:54:08.963083
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network = HurdPfinetNetwork()
    network_facts = {}
    fsysopts_path = '/usr/sbin/fsysopts'
    socket_path = '/servers/socket'
    network_facts = hurd_pfinet_network.assign_network_facts(network_facts,
            fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert '--interface' in network_facts['eth0']
    assert '--address' in network_facts['eth0']
    assert '--netmask' in network_facts['eth0']
    assert '--address6' in network_facts['eth0']
    assert network_facts['eth0']['--interface'] == '--interface=eth0'

# Generated at 2022-06-24 22:54:16.091542
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_0 = HurdPfinetNetwork()
    hurd_network_0.module = AnsibleModuleFake()
    hurd_network_0.module.run_command = AnsibleModuleFake.run_command
    hurd_network_0.module.get_bin_path = AnsibleModuleFake.get_bin_path
    hurd_network_0.module.run_command = AnsibleModuleFake.run_command
    # FIXME: write test for the populate method
    hurd_network_0.populate()


# Generated at 2022-06-24 22:54:22.320937
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create an instance of HurdPfinetNetwork
    hurd_pfinet_network_0 = HurdPfinetNetwork()

    # Create a dummy module
    class dummy_module:
        def __init__(self):
            pass
        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args, **kwargs):
            pass
        def run_command(self, *args, **kwargs):
            pass

    # Set the module to the instance
    hurd_pfinet_network_0.module = dummy_module()

    # Check result
    assert(hurd_pfinet_network_0.populate() == {})


# Generated at 2022-06-24 22:54:32.859874
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleMock(object):
        def __init__(self, commands):
            self.commands = commands

        def run_command(self, args):
            if args[2] in self.commands.keys():
                return 0, self.commands[args[2]], None
            else:
                return 0, '', None

    module = ModuleMock({
        # pfinet socket
        '/servers/socket/inet': '',
        # fsysopts output
        '/servers/socket/inet': '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0',
        '/servers/socket/inet6': '--interface=/dev/eth0 --address=/2001:db8::1/64',
    })
    network = HurdPfinet

# Generated at 2022-06-24 22:54:34.680637
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert (HurdNetworkCollector.__name__ == 'HurdNetworkCollector')


# Generated at 2022-06-24 22:55:00.731360
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = -2147483648
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    var_0 = hurd_network_collector_0.get_facts()


# Generated at 2022-06-24 22:55:02.910813
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = HurdPfinetNetwork(0)
    var_0 = int_0.populate()

# Generated at 2022-06-24 22:55:11.774477
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = -2043
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    mock_network_facts = unittest_helper_make_mock_network_facts()
    str_0 = unittest_helper_make_string()
    str_1 = unittest_helper_make_string()
    var_0 = hurd_pfinet_network_0.assign_network_facts(mock_network_facts, str_0, str_1)


# Generated at 2022-06-24 22:55:21.805014
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = -2146
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    str_0 = 'd:\\\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 22:55:27.933440
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.module
    network_facts_0 = {}
    string_0 = module_0.get_bin_path('fsysopts')
    hurd_pfinet_network_0.assign_network_facts(network_facts_0, string_0, '/servers/socket/inet')
    assert isinstance(network_facts_0, dict), 'Expected dict, received %s' % type(network_facts_0)


# Generated at 2022-06-24 22:55:33.498436
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_14 = -642
    hurd_pfinet_network_14 = HurdPfinetNetwork(int_14)
    var_14 = hurd_pfinet_network_14.populate()
    # assert var_14 == NotImplemented
    # assert var_14 == TypeError


# Generated at 2022-06-24 22:55:42.856303
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
  data = HurdNetworkCollector()
  assert data.network_collector_platform == "Linux"
  assert data.network_collector_subplatform == "none"
  assert data.network_collector_distribution == "none"
  assert data.network_collector_major_version == -1
  assert data.network_collector_minor_version == -1
  assert data.network_collector_network_facts == {}
  assert data.network_collector_collector_obj == None
  assert data.network_collector_cache == None
  assert data.network_collector_cache_expiration == 3600
  assert data.network_collector_check_timestamp == False

# Generated at 2022-06-24 22:55:49.116417
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = -989
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()
    # expected_result = None
    assert var_0 is not None


# Generated at 2022-06-24 22:55:53.614819
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = -450
    hurd_network_collector_0 = HurdNetworkCollector(int_0)

# Generated at 2022-06-24 22:55:59.166667
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = -227
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    str_0 = hurd_pfinet_network_0._platform
    assert str_0 == 'GNU'
    str_1 = hurd_pfinet_network_0._socket_dir
    assert str_1 == '/servers/socket/'
    assert isinstance(hurd_pfinet_network_0, Network)
    # Set up method populate of class HurdPfinetNetwork with arguments.
    collected_facts_0 = {}
    # Call method populate of class HurdPfinetNetwork with arguments.
    hurd_pfinet_network_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:57:02.738761
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = -675
    assert isinstance(HurdPfinetNetwork(int_0), HurdPfinetNetwork) == True


# Generated at 2022-06-24 22:57:13.109548
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    # Arrange
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    arg_0 = os.path.join(HurdPfinetNetwork._socket_dir, 'inet', 'fsysopts')
    arg_1 = '--interface=eth0  --address=192.168.2.100  --netmask=255.255.255.0  --address6=fe80::215:5dff:fe33:c9a/64'  # noqa: E501
    rv = None
    collected_facts = {'network': {}}

# Generated at 2022-06-24 22:57:15.882952
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = -659
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    int_1 = -164
    var_0 = hurd_network_collector_0.collect_network_facts(int_1)

# Generated at 2022-06-24 22:57:19.461963
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)

    # Populate cannot be tested because it is using run_command
    # var_0 = hurd_pfinet_network_0.populate()



# Generated at 2022-06-24 22:57:22.517310
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert (isinstance(hurd_pfinet_network_0, HurdPfinetNetwork))

# Generated at 2022-06-24 22:57:31.903999
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = -1
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0._platform, str)
    assert not hasattr(hurd_pfinet_network_0, 'var_0')
    assert not hasattr(hurd_pfinet_network_0, 'var_1')
    assert isinstance(hurd_pfinet_network_0._socket_dir, str)
    assert not hasattr(hurd_pfinet_network_0, 'var_2')
    int_1 = 0
    hurd_pfinet_network_1 = HurdPfinetNetwork(int_1)
    assert isinstance(hurd_pfinet_network_1._platform, str)
    assert not has

# Generated at 2022-06-24 22:57:36.310155
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

if __name__ == '__main__':
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:57:37.727728
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:57:42.759693
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 531
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    str_0 = 'RcX~7V'
    str_1 = 'ejw'
    str_2 = 'sY]'
    var_1 = hurd_pfinet_network_0.assign_network_facts(str_0, str_1, str_2)


# Generated at 2022-06-24 22:57:52.144863
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    list_0 = []
    list_1 = []
    list_1.append('--interface')
    list_1.append('--address')
    list_1.append('--netmask')
    list_1.append('--address6')
    list_1.append('--interface')
    list_1.append('--address')
    list_1.append('--netmask')
    list_1.append('--address6')
    list_1.append('--interface')
    list_1.append('--address')
    list_1.append('--netmask')
    list_1.append('--address6')

    string_0 = hurd_pfinet_network_0.ass

# Generated at 2022-06-24 23:00:14.849870
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_1 = -471
    hurd_pfinet_network_1 = HurdPfinetNetwork(int_1)

    fsysopts_path = '/servers/socket/inet'
    socket_path = '--interface=/dev/eth0'
    var_1 = hurd_pfinet_network_1.assign_network_facts(fsysopts_path, socket_path)


# Generated at 2022-06-24 23:00:17.163936
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 23:00:23.919098
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Construct with arguments
    int_0 = -642
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    # No arguments
    hurd_pfinet_network_1 = HurdPfinetNetwork()
    assert isinstance(hurd_pfinet_network_1, HurdPfinetNetwork)

