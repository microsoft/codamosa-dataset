

# Generated at 2022-06-24 22:50:31.661008
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # FIXME: requires a mocked module
    pass

# Generated at 2022-06-24 22:50:34.786932
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fact_name = 'network'
    hurd_pfinet_network_0 = HurdPfinetNetwork(fact_name)


# Generated at 2022-06-24 22:50:36.680988
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()

# Generated at 2022-06-24 22:50:41.916120
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork(module=None)
    assert not hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:50:52.083332
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = "/servers/socket/inet"

    pfinet = HurdPfinetNetwork(module='mock')
    network_facts = pfinet.assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert "interfaces" in network_facts
    assert "eth0" in network_facts["interfaces"]
    assert "eth0" in network_facts
    assert "ipv4" in network_facts["eth0"]
    assert "ipv6" in network_facts["eth0"]
    assert "address" in network_facts["eth0"]["ipv4"]
    assert "netmask" in network_facts["eth0"]["ipv4"]
   

# Generated at 2022-06-24 22:50:54.590319
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pfinet_network_0 = HurdPfinetNetwork()

if __name__ == '__main__':
    # test_case_0()
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:50:59.125277
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    #print('\n UNIT TESTING HurdPfinetNetwork')

    # test case 1 - constructor
    network_0 = HurdPfinetNetwork()
    #print(' network_0 = HurdPfinetNetwork()', '\n')


# Generated at 2022-06-24 22:51:06.985514
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork

# Generated at 2022-06-24 22:51:13.076033
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Test case for the method HurdPfinetNetwork.populate of class HurdPfinetNetwork
    """
    network_facts = {}
    network_0 = HurdPfinetNetwork()
    network_facts_0 = network_0.populate(network_facts)

    assert network_facts_0 == {}



# Generated at 2022-06-24 22:51:19.906791
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # The resulting network_facts should be the same as in test_case_1.
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_0.module = MagicMock()
    hurd_pfinet_network_0.module.run_command = MagicMock(return_value=(0,
        '--interface=/dev/eth0 --address=123.123.123.123 --netmask=255.255.255.0 --address6=2001:abc:abc:abc::1/64\n',
        ''))
    hurd_pfinet_network_0.module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
   

# Generated at 2022-06-24 22:51:29.720293
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)

# Generated at 2022-06-24 22:51:34.548302
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, dict)


# Generated at 2022-06-24 22:51:37.444509
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    int_0 = -203
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0, int_0)

# Generated at 2022-06-24 22:51:43.276435
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:51:50.399252
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = -1
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    var_0 = hurd_pfinet_network_0.assign_network_facts(dict_0, tuple_0, dict_0)
    assert var_0 == dict_0


# Generated at 2022-06-24 22:51:55.983075
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)


# Generated at 2022-06-24 22:52:00.620112
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

# Generated at 2022-06-24 22:52:06.956878
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)



# Generated at 2022-06-24 22:52:12.043100
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    var_0 = hurd_network_collector_0.assign_network_facts(tuple_0, dict_0, dict_0)

## Unit test for assign_network_facts of class HurdNetworkCollector

# Generated at 2022-06-24 22:52:13.502368
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = 13155
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    return


# Generated at 2022-06-24 22:52:28.804305
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert puser_0.module == int_0

# Generated at 2022-06-24 22:52:32.137151
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)

# Uunit test for constructor of class HurdNetworkCollector

# Generated at 2022-06-24 22:52:36.045061
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

# Generated at 2022-06-24 22:52:44.295890
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    # Constructor test case for class HurdPfinetNetwork
    assert callable(getattr(HurdPfinetNetwork, '__init__'))
    assert hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0) == tuple_0


# Generated at 2022-06-24 22:52:52.616970
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = (1, 3, 3, 7)
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:52:58.260035
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    # Unit test for assign_network_facts
    assert(hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0) is not None)

# Generated at 2022-06-24 22:53:07.349189
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.platform = 'GNU'
    hurd_pfinet_network_0._socket_dir = '/servers/socket/'
    tuple_1 = ()
    dict_1 = {tuple_1: tuple_1, tuple_1: tuple_1}
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_1, dict_1, dict_1)
    assert var_0 == tuple_1

# Generated at 2022-06-24 22:53:10.908060
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    if __name__ == '__main__':
        # Unit test for constructor of class HurdPfinetNetwork
        print('Test constructor...')
        print(test_case_0())

# Generated at 2022-06-24 22:53:17.546751
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    # assert class of `hurd_pfinet_network_0` is `HurdPfinetNetwork`
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:53:26.608085
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():    
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    msg = "The __init__() method of HurdPfinetNetwork class returns: "
    returned_obj = HurdPfinetNetwork(int_0)
#    is_instance_0 = isinstance(returned_obj, HurdPfinetNetwork)
#    assert is_instance_0, msg + str(type(returned_obj))
    assert isinstance(returned_obj, HurdPfinetNetwork), msg + str(type(returned_obj))


# Generated at 2022-06-24 22:53:53.592919
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:54:02.326167
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    int_1 = 110
    hurd_pfinet_network_1 = HurdPfinetNetwork(int_1)
    hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    hurd_pfinet_network_1.assign_network_facts(tuple_0, dict_0, dict_0)
    assert int_0 == 110


# Generated at 2022-06-24 22:54:07.824938
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert type(hurd_pfinet_network_0) is HurdPfinetNetwork
    assert hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0) is None


# Generated at 2022-06-24 22:54:14.967581
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)



# Generated at 2022-06-24 22:54:16.373040
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert(isinstance(HurdNetworkCollector({}, {}), HurdNetworkCollector))

# Generated at 2022-06-24 22:54:21.428526
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.populate(dict_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

# Generated at 2022-06-24 22:54:26.248995
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate(tuple_0)

# Generated at 2022-06-24 22:54:32.598274
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    int_0 = -15
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    assert var_0 is tuple_0
    assert False


# Generated at 2022-06-24 22:54:39.212548
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    tuple_0 = ()
    tuple_1 = ()
    hurd_pfinet_network_1 = HurdPfinetNetwork()
    hurd_pfinet_network_1.populate(tuple_1)
    tuple_2 = ()
    hurd_pfinet_network_0.populate(tuple_2)


# Generated at 2022-06-24 22:54:43.885812
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

# Generated at 2022-06-24 22:55:35.852204
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ('\x00\x00\x00\x00', '\x00\x00\x00\x00')
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -897
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    dict_1 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    var_0 = '\x00\x00\x00\x00'
    dict_2 = dict_1[var_0]
    var_1 = '\x00\x00\x00\x00'
    var_2 = dict_2[var_1]
    assert var_2

# Generated at 2022-06-24 22:55:42.436027
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:55:48.158664
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(tuple_0)



# Generated at 2022-06-24 22:55:57.824142
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # tuple_0 = ()
    # dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    # int_0 = -203
    # hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    # assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    # var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    # assert var_0 == (-203, {tuple_0: tuple_0})
    pass


# Generated at 2022-06-24 22:56:02.628726
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

# Generated at 2022-06-24 22:56:08.548309
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert hurd_pfinet_network_0.populate(dict_0) == dict_0

# Generated at 2022-06-24 22:56:13.981472
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert hurd_pfinet_network_0.module is not None
    assert len(hurd_pfinet_network_0.all_ipv4_addresses) == 0
    assert len(hurd_pfinet_network_0.all_ipv6_addresses) == 0


# Generated at 2022-06-24 22:56:20.790484
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:56:24.117669
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:56:29.783588
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)


# Generated at 2022-06-24 22:58:40.151252
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate(dict_0)
    assert var_0 == None


# Generated at 2022-06-24 22:58:50.750039
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    var_1 = hurd_pfinet_network_0.populate(tuple_0)
    # Verify that var_1 is an instance of the class HurdPfinetNetwork or is inherited
    # from it by verifying that it's a subclass
    assert isinstance(var_1, HurdPfinetNetwork) or issubclass(type(var_1), HurdPfinetNetwork)

# test_case_0()
# test_HurdPfinetNetwork_

# Generated at 2022-06-24 22:58:54.784499
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = -816
    hurd_network_collector_0 = HurdNetworkCollector(int_0)


# Generated at 2022-06-24 22:58:56.476253
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = 0
    hurd_network_collector_0 = HurdNetworkCollector(int_0)



# Generated at 2022-06-24 22:59:02.346112
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0}
    dict_1 = {}
    dict_2 = {}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(dict_0, dict_1, dict_2)
    return None


# Generated at 2022-06-24 22:59:08.852665
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)

if __name__ == "__main__":
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()

# Generated at 2022-06-24 22:59:14.589656
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)
    assert var_0 is not None
    assert var_0 is not False

# Generated at 2022-06-24 22:59:20.164392
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(tuple_0, dict_0, dict_0)



# Generated at 2022-06-24 22:59:28.490142
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    var_0 = hurd_network_collector_0.get_network_interfaces()
    var_1 = hurd_network_collector_0.get_facts(dict_0, dict_0)
    var_2 = hurd_network_collector_0.get_network_facts(dict_0, dict_0)


if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:59:34.632675
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module_args = {}
    set_module_args(module_args)

    tuple_0 = ()
    dict_0 = {tuple_0: tuple_0, tuple_0: tuple_0}
    int_0 = -203
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.populate()
