

# Generated at 2022-06-24 22:50:40.474838
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork(dict(ANSIBLE_MODULE_ARGS={}), dict())
    with patch("ansible.module_utils.facts.network.base.Network.module.get_bin_path") as get_bin_path_mock:
        with patch("os.path.exists") as os_path_exists_mock:
            with patch("ansible.module_utils.facts.network.base.Network.module.run_command") as run_command_mock:
                with patch("os.path.join") as os_path_join_mock:
                    get_bin_path_mock.return_value = 'fsysopts_path'
                    os_path_exists_mock.return_value = True

# Generated at 2022-06-24 22:50:46.650771
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)
    assert hurd_network_collector_0._platform == 'GNU'
    assert hurd_network_collector_0._fact_class == HurdPfinetNetwork


hurd_network_collector_0 = HurdNetworkCollector()

# Generated at 2022-06-24 22:50:51.997636
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    print('Test constructor of HurdNetworkCollector')
    hurd_network_collector_1 = HurdNetworkCollector()
    assert(isinstance(hurd_network_collector_1, HurdNetworkCollector))
    print('Passed constructor of HurdNetworkCollector')


# Generated at 2022-06-24 22:50:57.077680
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # given
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)
    module.get_bin_path = Mock(return_value=None)

    # when
    result = hurd_pfinet_network_0.populate()

    # then
    assert result == {}


# Generated at 2022-06-24 22:51:02.133439
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_network_0 = HurdPfinetNetwork()
    hurd_network_0.module = Mock()
    hurd_network_0.module.run_command = Mock(side_effect=[(0, '--interface=/dev/eth0 --address=192.168.122.57 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fea6:b2f7/10 ', ''), (0, '--interface=/dev/lo --address=127.0.0.1 --netmask=255.0.0.0 --address6=::1/128 --address6=fe80::1/64 ', '')])

# Generated at 2022-06-24 22:51:07.850097
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # init the class
    hurd_pfinet_network = HurdPfinetNetwork(module=AnsibleModule(argument_spec={}))
    # check for None for the case when no file exists
    assert hurd_pfinet_network.populate() is None


# Generated at 2022-06-24 22:51:11.867458
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork({}, {})


# Generated at 2022-06-24 22:51:17.773975
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # This is a GNU Hurd specific subclass of Network. It use fsysopts to
    # get the ip address and support only pfinet.
    hurd_pfinet_network = HurdPfinetNetwork()
    # Assign network facts from output of fsysopts
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    result = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    # Expected result

# Generated at 2022-06-24 22:51:18.767022
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:51:19.626524
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:30.962584
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_HurdPfinetNetwork_assign_network_facts_0 = HurdPfinetNetwork(module=None)
    test_HurdPfinetNetwork_assign_network_facts_0.assign_network_facts(network_facts=None,fsysopts_path=None,socket_path=None)

# Generated at 2022-06-24 22:51:32.065840
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    netif = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:33.835273
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        test_case_0()
    except Exception as e:
        print ('FAILURE: exception testing constructor %s' % \
               str(e))



# Generated at 2022-06-24 22:51:35.411808
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:40.518148
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert type(hurd_network_collector_0) is HurdNetworkCollector


# Generated at 2022-06-24 22:51:43.028265
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_populate_0 = HurdPfinetNetwork()
    assert hurd_pfinet_network_populate_0.populate() == {}

# Generated at 2022-06-24 22:51:45.630996
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork(True, True)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)

# Test populate() of class HurdPfinetNetwork

# Generated at 2022-06-24 22:51:47.299901
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        test_case_0()
    except Exception as e:
        return False
    else:
        return True


# Generated at 2022-06-24 22:51:53.436481
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network = HurdPfinetNetwork()
    collected_facts = {};
    # No socket directory in server process
    os.environ['_ANSIBLE_TEST_HURD_NETWORK_COLLECTOR_POPULATE'] = '0'
    result = hurd_pfinet_network.populate(collected_facts)
    assert {} == result
    # No socket directory in server process
    os.environ['_ANSIBLE_TEST_HURD_NETWORK_COLLECTOR_POPULATE'] = '1'
    result = hurd_pfinet_network.populate(collected_facts)
    assert {} == result
    os.environ['_ANSIBLE_TEST_HURD_NETWORK_COLLECTOR_POPULATE'] = '2'
    result

# Generated at 2022-06-24 22:52:01.643414
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # This method is difficult to test, because it depends on
    # the underlying network configuration. So the best we can
    # do is to check the return value looks like a dictionary
    # and that there is a key called "interfaces" in it.
    # An unnecessary limitation of this method is it only
    # work with pfinet.
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)

    fsysopts_path = hurd_pfinet_network_1.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return

    socket_path = None


# Generated at 2022-06-24 22:52:10.730160
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:52:17.769137
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_network_collector_1.facts['network'] = HurdPfinetNetwork()
    hurd_network_collector_1.facts['network'].module = FakeModule()


# Generated at 2022-06-24 22:52:27.248238
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facts = dict()
    def run_command(self, args, check_rc=True):
        return 0, '--interface=/dev/eth0 --address=10.1.1.1 --netmask=255.255.255.0 --address6=fe80::5e5e:1fff:fe01:18b6/64', ''

    hurd_network_0 = HurdPfinetNetwork(facts, None)
    hurd_network_0.module.run_command = run_command

# Generated at 2022-06-24 22:52:28.633140
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    result = HurdPfinetNetwork()
    assert isinstance(result, HurdPfinetNetwork)


# Generated at 2022-06-24 22:52:35.240354
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')

    hurd_network_collector = HurdNetworkCollector()
    hurd_network_collector._module = module
    facts = hurd_network_collector.populate()
    #assert facts == {'interfaces': ['eth0'], 'eth0': {'active': True, 'ipv4': {'address': 'dhcp', 'netmask': '255.255.255.0'}, 'ipv6': [{'prefix': '64', 'address': '2001:db8:0:f101::1'}], 'device': 'eth0'}}
    assert facts == {}

# Generated at 2022-06-24 22:52:44.597247
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    rc, out, err = hurd_pfinet_network_0.module.run_command([hurd_pfinet_network_0.module.get_bin_path('fsysopts'),
                                                             '-L',
                                                             '/servers/socket/inet'
                                                             ])
    hurd_pfinet_network_0.assign_network_facts({},
                                               hurd_pfinet_network_0.module.get_bin_path('fsysopts'),
                                               '/servers/socket/inet')

# Generated at 2022-06-24 22:52:49.936655
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network = HurdPfinetNetwork()
    return_value = hurd_pfinet_network.populate()
    assert return_value is None


# Generated at 2022-06-24 22:52:57.364336
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork(dict(module=HurdNetworkCollector.module))
    collected_facts=None
    fsysopts_path=None
    socket_path=None
    returned_value=hurd_pfinet_network_0.assign_network_facts(collected_facts, fsysopts_path, socket_path)
    assert type(returned_value) == dict


# Generated at 2022-06-24 22:53:01.701022
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().__class__.__name__ == 'HurdPfinetNetwork'



# Generated at 2022-06-24 22:53:02.571553
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()

# Generated at 2022-06-24 22:53:14.891586
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:53:16.248084
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:53:21.216562
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    assert 1 == 1
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None
    # assert var_0 == None


# Generated at 2022-06-24 22:53:28.740606
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    int_1 = 3680
    hurd_network_collector_0 = HurdNetworkCollector(int_1, hurd_pfinet_network_0)
    assert hurd_network_collector_0._platform == 'GNU'
    assert hurd_network_collector_0._subclasses['system'] == [hurd_pfinet_network_0]


# Generated at 2022-06-24 22:53:34.566896
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(None, None, None)


# Generated at 2022-06-24 22:53:40.629407
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:53:43.586416
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    arg_0 = 1058
    obj_0 = HurdPfinetNetwork(arg_0)
    res_0 = obj_0.populate()

# Generated at 2022-06-24 22:53:48.976617
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1035
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    str_0 = '/usr/bin/fsysopts'
    str_1 = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts({}, str_0, str_1)
    assert isinstance(var_0, dict)


# Generated at 2022-06-24 22:53:51.880791
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 0
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert var_0 == {'interfaces': [],}


# Generated at 2022-06-24 22:53:55.800714
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 9095
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:54:13.159313
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_cases_0()


# Generated at 2022-06-24 22:54:16.178202
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1235
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:54:19.796563
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:54:30.441340
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1037
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    str_0 = 1039
    str_1 = 1040
    str_2 = 1041
    str_3 = 1042
    var_0 = hurd_pfinet_network_0.assign_network_facts(None, str_1, str_3)
    assert var_0 == {'interfaces': ['eth0']}, 'incorrect return value encountered'
    assert str_0 == '', 'incorrect return value encountered'
    assert str_1 == '/var/run/fsysopts', 'incorrect return value encountered'
    assert str_2 == '', 'incorrect return value encountered'
    assert str_3 == '/var/run/socket/inet', 'incorrect return value encountered'


# Generated at 2022-06-24 22:54:32.426006
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)


# Generated at 2022-06-24 22:54:36.460779
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert True


# Generated at 2022-06-24 22:54:43.142677
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    network_facts_0 = {}
    fsysopts_path_0 = None
    socket_path_0 = None
    assert list(hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)) == []


# Generated at 2022-06-24 22:54:46.497060
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1038
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert type(var_0) is dict
    assert var_0['eth0']['device'] == 'eth0'


# Generated at 2022-06-24 22:54:52.545962
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    # Verify member variables of class instance hurd_pfinet_network_0
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0.module, AnsibleModule)
    assert hurd_pfinet_network_0._tmpdir is None
    assert hurd_pfinet_network_0.platform == 'GNU'
    assert hurd_pfinet_network_0._socket_dir == '/servers/socket/'
    assert hurd_pfinet_network_0._config_file is None
    assert hurd_pfinet_network_0._config_data is None


# Generated at 2022-06-24 22:54:55.218478
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1058
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts({}, fsysopts_path_0, socket_path_0)
    assert var_0 is not None
    assert var_0['interfaces'] is not None


# Generated at 2022-06-24 22:55:22.824103
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
  obj = HurdNetworkCollector()


# Generated at 2022-06-24 22:55:25.534982
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    try:
        HurdPfinetNetwork(0)
        print("Unit test for constructor of class HurdPfinetNetwork passed")
    except:
        print("Unit test for constructor of class HurdPfinetNetwork failed")


# Generated at 2022-06-24 22:55:27.824113
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:55:35.314492
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1039
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)

    assert hurd_pfinet_network_0.assign_network_facts({}, '', '') == {'dns': {}, 'all_ipv4_addresses': [], 'default_ipv4': {'interface': '', 'netmask': '', 'address': '', 'gateway': ''}, 'interfaces': [], 'all_ipv6_addresses': [], 'default_ipv6': {'interface': '', 'prefixlen': '', 'address': '', 'gateway': ''}}


# Generated at 2022-06-24 22:55:40.763100
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:55:44.954748
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)


# Generated at 2022-06-24 22:55:47.934667
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_1 = 4 
    hurd_network_collector_1 = HurdNetworkCollector(int_1)
    assert isinstance(hurd_network_collector_1, (HurdNetworkCollector))

# Generated at 2022-06-24 22:55:50.946713
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    valid_socket_path = '/servers/socket/inet'
    valid_fsysopts_path = '/bin/fsysopts'
    # The method assign_network_facts must return a dictionary
    assert isinstance(HurdPfinetNetwork.assign_network_facts('network_facts', valid_fsysopts_path, valid_socket_path), dict)

# Generated at 2022-06-24 22:55:53.337943
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:55:59.305144
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = '--net-type=inet'
    var_1 = '--interface=/dev/eth0'
    var_2 = '--address=192.168.1.2'
    var_3 = '--netmask=255.255.255.0'
    var_4 = '--address6=81.64.1.20/16'
    var_5 = '--net-type'
    var_6 = '--address6=81.64.2.20/16'
    var_7 = '--address6'
    var_8 = '--address6=81.64.3.20/16'

# Generated at 2022-06-24 22:57:20.901053
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
  int_0 = 1036
  hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
  fsysopts_path = 'c:\\dev\\fsysopts'
  socket_path = 'c:\\dev\\socket_path'
  var_0 = hurd_pfinet_network_0.assign_network_facts({}, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:57:28.397746
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    hurd_pfinet_network_0.populate()
    var_0 = hurd_pfinet_network_0.get_network_facts().get('netmask')
    assert var_0 == '255.255.255.0'


# Generated at 2022-06-24 22:57:32.897678
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    try:
        var_0 = hurd_pfinet_network_0.populate()
    except NameError:
        var_0 = False
    assert var_0


# Generated at 2022-06-24 22:57:40.747235
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = 8187
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0, Network)
    assert isinstance(hurd_pfinet_network_0, NetworkCollector)


# Generated at 2022-06-24 22:57:45.625761
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = 1040
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    assert isinstance(hurd_network_collector_0._fact_class, HurdPfinetNetwork)


# Generated at 2022-06-24 22:57:50.303534
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fsysopts_path_0 = '/path/to/fsysopts'
    module_0 = AnsibleModule()
    module_0.run_command(fsysopts_path_0)

    hurd_pfinet_network_0 = HurdPfinetNetwork(module_0)



# Generated at 2022-06-24 22:57:51.435434
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert True

# Generated at 2022-06-24 22:57:55.338130
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_random = 58417
    hurd_pfinet_network_random = HurdPfinetNetwork(int_random)

    # Test with a fake fsysopts command path
    var_0 = hurd_pfinet_network_random.assign_network_facts({}, '/bin/fsysopts', '/servers/socket/inet')
    assert var_0 == {}

# Generated at 2022-06-24 22:58:03.806920
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    int_0 = 1036
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    var_0 = None
    var_1 = '/usr/bin/fsysopts'
    network_facts_0 = None
    socket_path_0 = 'soc/3/192.168.0.1'
    var_2 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, var_1, socket_path_0)


# Generated at 2022-06-24 22:58:05.767997
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    int_0 = 1036
    hurd_network_collector_0 = HurdNetworkCollector(int_0)
    var_0 = hurd_network_collector_0.collect()