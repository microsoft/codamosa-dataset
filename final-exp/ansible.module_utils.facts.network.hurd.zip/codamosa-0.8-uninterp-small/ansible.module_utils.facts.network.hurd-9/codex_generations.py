

# Generated at 2022-06-24 22:50:35.631877
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bool_0 = False
    hurd_network_0 = HurdPfinetNetwork(bool_0)
    dict_0 = {}
    str_0 = "'"
    str_1 = "'"
    str_2 = 'fsysopts'
    str_3 = '-L'
    str_4 = 'pfinet'
    str_5 = str_2 + ' ' + str_3 + ' ' + str_4
    str_6 = 'eth0'
    hurd_network_0.assign_network_facts(dict_0, str_0, str_1)
    hurd_network_0.assign_network_facts(dict_0, str_5, str_6)


# Generated at 2022-06-24 22:50:42.835913
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bool_0 = False
    hurd_network_collector_0 = HurdNetworkCollector(bool_0)
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)
    assert isinstance(hurd_network_collector_0._fact_classes, dict)
    assert len(hurd_network_collector_0._fact_classes) == 1
    assert 'HurdPfinetNetwork' in hurd_network_collector_0._fact_classes
    assert hurd_network_collector_0._fact_classes['HurdPfinetNetwork'] == HurdPfinetNetwork

# Generated at 2022-06-24 22:50:52.841638
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    list_0 = [dict_11, dict_12]
    dict_10['_ansible_verbosity'] = dict_9
    dict_10['_ansible_version'] = dict_8
    dict_10['_ansible_no_log'] = dict_7
    dict_10['_ansible_debug'] = dict_6
    dict_10['_ansible_selinux_special_fs'] = dict_5
    dict_10

# Generated at 2022-06-24 22:50:57.004860
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {
    }
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    HurdPfinetNetwork_instance = HurdPfinetNetwork()
    HurdPfinetNetwork_instance.module = MockModule({})
    HurdPfinetNetwork_instance.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:50:58.323501
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:51:00.782595
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    HurdPfinetNetwork_populate_out = HurdPfinetNetwork(None).populate()
    assert HurdPfinetNetwork_populate_out == {}


# Generated at 2022-06-24 22:51:06.989459
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Test with collect default facts.
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    collected_facts = {
        'kernel': 'GNU-Mach',
    }
    hurd_pfinet_network_0.populate(collected_facts)


# Generated at 2022-06-24 22:51:16.579477
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Init
    network_facts_0 = NetworkCollector.populate(network_facts_0)
    # Execute
    network_facts_0 = HurdPfinetNetwork.populate(network_facts_0)
    assert type(network_facts_0) is dict
    assert type(network_facts_0['interfaces']) is list
    assert type(network_facts_0['lo']) is dict
    assert type(network_facts_0['lo']['device']) is str
    assert network_facts_0['lo']['device'] == 'lo'
    assert type(network_facts_0['lo']['active']) is bool
    assert network_facts_0['lo']['active'] is True
    assert type(network_facts_0['lo']['ipv4']) is dict
   

# Generated at 2022-06-24 22:51:19.025648
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    m = module_mock()
    assert HurdNetworkCollector(m)


# Generated at 2022-06-24 22:51:23.033575
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    collected_facts = None
    return_value_0 = hurd_pfinet_network_0.populate(collected_facts)
    return_value_1 = hurd_pfinet_network_0.populate(collected_facts)


# Generated at 2022-06-24 22:51:41.993852
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts_dict_0 = {'ansible_eth0': {'ipv4': {'netmask': '255.255.255.0', 'address': '192.0.2.18'}, 'ipv6': [{'address': '2001:db8:8::18', 'prefix': '64'}], 'active': True, 'device': 'eth0'}, 'ansible_lo': {'ipv4': {'netmask': '255.0.0.0', 'address': '127.0.0.1'}, 'ipv6': [{'address': '::1', 'prefix': '128'}], 'active': True, 'device': 'lo'}}
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    hurd_p

# Generated at 2022-06-24 22:51:49.595758
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = 'fsysopts -L /servers/socket/inet'
    hurd_network_collector_0 = HurdNetworkCollector(True)
    network_facts = hurd_network_collector_0.facts['ansible_network'].assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert('ansible_eth0' in network_facts['interfaces'])

if __name__ == "__main__":
    print('Test for class HurdPfinetNetwork')
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()

# Generated at 2022-06-24 22:51:55.501146
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bool_0 = False
    hurd_pfinet_network_obj_0 = HurdPfinetNetwork(bool_0)
    hurd_pfinet_network_obj_0.populate()


# Generated at 2022-06-24 22:52:02.794943
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Expected values for unit test
    expected_i = 0  # expected number of interfaces

    # Check if the class HurdPfinetNetwork exists
    assert 'HurdPfinetNetwork' in globals()

    # Check attributes of class HurdPfinetNetwork
    assert getattr(HurdPfinetNetwork, 'platform', None) == (
        'GNU'
    )
    assert getattr(HurdPfinetNetwork, '_socket_dir', None) == (
        '/servers/socket/'
    )

    # Check if the method populate (and all parent methods) exists
    assert 'populate' in dir(HurdPfinetNetwork) and callable(getattr(HurdPfinetNetwork, 'populate'))

    # Check if the class method populate is callable

# Generated at 2022-06-24 22:52:04.968501
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    x = HurdPfinetNetwork()
    x.assign_network_facts()
    x.populate()


# Generated at 2022-06-24 22:52:08.369369
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:52:09.003588
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    case_0()

# Generated at 2022-06-24 22:52:10.729131
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Indication of tests to run

# Generated at 2022-06-24 22:52:13.856875
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert(not (HurdPfinetNetwork(None, None)._socket_dir is None))


# Generated at 2022-06-24 22:52:25.431057
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module_0 = object()
    hurd_pfinet_network_0 = HurdPfinetNetwork(module_0)
    fsysopts_path_0 = '/etc/network/if-up.d'
    socket_path_0 = 'Hurd Networking'
    # Verify that the method 'assign_network_facts' is called with the expected parameters
    with patch.object(HurdPfinetNetwork, 'assign_network_facts', autospec=True) as mock_assign_network_facts:
        hurd_pfinet_network_0.populate()
        mock_assign_network_facts.assert_called_with(hurd_pfinet_network_0, {}, fsysopts_path_0, socket_path_0)
        # Verify that the expected value is returned from the method call


# Generated at 2022-06-24 22:52:39.840242
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork
    test_case_0()


# Generated at 2022-06-24 22:52:43.824087
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork()
    assert(hurd_pfinet_network.platform == 'GNU')
    assert(hurd_pfinet_network._socket_dir == '/servers/socket/')

# Generated at 2022-06-24 22:52:52.624270
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    run_module = {
        'ansible_collections.ansible.netcommon.plugins.module_utils.network.common.fsysopts': {
            'run_command.return_value': (0, '--interface=/dev/eth0 --address=1.2.3.4 --netmask=255.255.255.0 --address6=2a00:1450:4001:813::200e/64 --address6=fe80::200:5aee:feaa:20a2/64', '')
        }
    }
    network_facts = {}
    module = MockModule(run_module=run_module)
    hurd_pn = HurdPfinetNetwork(module=module)


# Generated at 2022-06-24 22:52:55.135025
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    print('Test: class HurdNetworkCollector, constructor')
    hurd_network_collector_0 = HurdNetworkCollector()
    assert(hurd_network_collector_0._platform == 'GNU')

# Generated at 2022-06-24 22:52:56.831331
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Test the method HurdPfinetNetwork.populate
    """
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:53:07.194842
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = 'path/to/fsysopts'
    socket_path = 'path/to/socket'

    # Test when there is one interface.
    out = [
        '--interface=/dev/eth0',
        '--address=192.168.1.1',
        '--netmask=255.255.255.0',
        '--address6=2002:836b:4179:8000:9cf3:a8b6:c84d:7c18/64',
    ]
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_0.module.run_command = lambda x: (0, '\n'.join(out), '')
    result = hurd_pfinet_network_0

# Generated at 2022-06-24 22:53:08.516975
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()


# Generated at 2022-06-24 22:53:16.846885
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_fsysopts_path = '/usr-hurd/servers/socket/'
    hurd_socket_path = '/usr-hurd/servers/socket/inet6'
    hurd_network_facts = {}
    hurd_out = '''--interface=/dev/eth0 --address=10.0.0.2 --netmask=255.255.255.0 --address6=2001:db8:a0b:12f0::1/64
'''
    hurd_network_facts['interfaces'] = ['eth0']
    hurd_network_facts['eth0'] = {'active': True, 'device': 'eth0', 'ipv4': {}, 'ipv6': []}
    hurd_current_if = 'eth0'
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:53:20.891076
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    if os.path.exists('/servers/socket'):
        test_case_0()
    else:
        pass

if __name__ == '__main__':
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:53:29.896292
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_0 = HurdPfinetNetwork()
    network_facts_0 = {}
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/var/run/vpn/client.sock'
    network_facts_1 = hurd_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)
    assert network_facts_1['interfaces'] == ['eth0', 'eth1', 'eth2']
    assert network_facts_1['eth0'] == {'ipv6': [], 'ipv4': {'netmask': '255.255.255.0', 'address': '192.168.1.10'}, 'device': 'eth0', 'active': True}
    assert network

# Generated at 2022-06-24 22:53:51.807576
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_facts = HurdPfinetNetwork()
    network_facts.module.run_command = MagicMock()
    network_facts.module.run_command.return_value = (0, '--address=192.168.1.2 --interface=/dev/eth0 --netmask=255.255.255.0 --address6=2a02:8a0:16c6:3010::1/64\n', '')
    network_facts.populate()
    assert network_facts.dict['interfaces'][0] == 'eth0'
    assert network_facts.dict['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts.dict['eth0']['ipv4']['netmask'] == '255.255.255.0'
   

# Generated at 2022-06-24 22:53:55.331017
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    res = hurd_pfinet_network_0.populate()
    assert isinstance(res, dict)


# Generated at 2022-06-24 22:54:04.348654
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    cmd_data = {
        'fsysopts': 'fsysopts',
    }

    for s in ('inet', 'inet6'):
        f = '/servers/socket/{}'.format(s)
        os.makedirs(os.path.dirname(f))
        with open(f, 'w') as fd:
            fd.write("pfinet")


# Generated at 2022-06-24 22:54:05.228773
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass



# Generated at 2022-06-24 22:54:08.077643
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert callable(HurdPfinetNetwork), "Configure fail, the HurdPfinetNetwork is not callable."
    assert callable(HurdNetworkCollector), "Build fail, the HurdNetworkCollector is not callable."

# Generated at 2022-06-24 22:54:11.161748
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    a = HurdNetworkCollector()
    assert a is not None


# Generated at 2022-06-24 22:54:20.419039
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    hurd_pfinet_network_0 = HurdPfinetNetwork()

    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts_0 = {}

# Generated at 2022-06-24 22:54:25.026209
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = type('', (), {})()
    module.get_bin_path = lambda x: 'fsysopts_path'
    module.run_command = lambda x: ['rc', 'out', 'err']

    hurd_network_collector_0 = HurdNetworkCollector()
    # FIXME: assert something here


# Generated at 2022-06-24 22:54:34.022250
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_0 = HurdPfinetNetwork()
    network_facts_0 = {}
    fsysopts_path_0 = 'fsysopts'
    socket_path_0 = '/servers/socket/inet'
    return_value_0 = hurd_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)

# Generated at 2022-06-24 22:54:35.828620
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    my_module = HurdPfinetNetwork(None)


# Generated at 2022-06-24 22:54:57.199680
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_1 = 1000.0
    list_1 = [float_1, float_1, float_1, float_1]
    hurd_pfinet_network_1 = HurdPfinetNetwork(float_1, list_1)
    if (not isinstance(hurd_pfinet_network_1, object)):
        print('Failed to create instance of class HurdPfinetNetwork')
        sys.exit(1)
    if (not (hurd_pfinet_network_1.populate() == {})):
        print('Failed to populate HurdPfinetNetwork')
        sys.exit(1)
    return True

# Generated at 2022-06-24 22:55:03.439585
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    network_facts = dict()
    fsysopts_path = '/sbin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:55:08.118131
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:55:19.014240
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    str_0 = '--address=192.168.1.113'
    str_1 = '--netmask=255.255.255.0'
    str_2 = '--address6=fe80::60f5:49ff:fe0e:e0a9/64'
    str_3 = '--address6=2001:660:3005:1::a7a:2b5a/64'
    str_4 = '--address6=2001:660:3005:1::a7a:2b5a/64'

# Generated at 2022-06-24 22:55:23.348052
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_network_collector_0 = HurdNetworkCollector(float_0, list_0)
    var_0 = hurd_network_collector_0.get_facts()
    var_1 = hurd_network_collector_0.collect()

# Generated at 2022-06-24 22:55:30.153810
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_network_collector_0 = HurdNetworkCollector(float_0, list_0)
    test_case_0()


# Generated at 2022-06-24 22:55:35.190865
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    assert isinstance(HurdNetworkCollector.create(float_0, list_0), HurdPfinetNetwork) == True

if __name__ == '__main__':
    test_HurdNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 22:55:41.673228
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_network_collector_0 = HurdNetworkCollector(float_0, list_0)

if __name__ == '__main__':
    test_case_0()

# vim:set shiftwidth=4 softtabstop=4 expandtab:

# Generated at 2022-06-24 22:55:46.346964
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    print("testing constructor of HurdPfinetNetwork")
    test_case_0()
    test_case_0()

# Generated at 2022-06-24 22:55:51.481189
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1.1
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:56:29.790535
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():

    # Create the object with defaults
    hurd_network_collector_0 = HurdNetworkCollector()

    # Check the attributes
    assert isinstance(hurd_network_collector_0, NetworkCollector)

    # Check the method populate
    var_0 = hurd_network_collector_0.populate()

    # Check the method get_fact_class
    var_1 = hurd_network_collector_0.get_fact_class()


# Generated at 2022-06-24 22:56:37.438751
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    network_facts = dict()
    network_facts['interfaces'] = []
    fsysopts_path = '/servers/pfinet'
    socket_path = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:56:38.181086
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:56:38.957518
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:56:43.710161
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)



# Generated at 2022-06-24 22:56:50.821397
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    assert callable(hurd_pfinet_network_0.populate)
    assert callable(hurd_pfinet_network_0.assign_network_facts)
    with pytest.raises(AttributeError) as excinfo:
        hurd_pfinet_network_0.module
    if error_test(excinfo):
        assert False
    with pytest.raises(AttributeError) as excinfo:
        hurd_pfinet_network_0._socket_dir
    if error_test(excinfo):
        assert False

# Generated at 2022-06-24 22:56:53.757950
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    assert float_0 == float_0
    assert list_0 == list_0
    assert isinstance(hurd_pfinet_network_0.populate(), dict)

# Generated at 2022-06-24 22:56:58.983455
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0, Network)
    var_0 = hurd_pfinet_network_0.populate()
    test_case_0()


# Generated at 2022-06-24 22:57:05.790669
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    hurd_pfinet_network_0.assign_network_facts(float_0, float_0)


# Generated at 2022-06-24 22:57:16.799019
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class_0 = HurdPfinetNetwork
    hurd_network_collector_0 = HurdNetworkCollector(fact_class_0, 1)
    assert not hasattr(hurd_network_collector_0, '_fact_class')
    assert not hasattr(hurd_network_collector_0, '_platform')
    assert not hasattr(hurd_network_collector_0, '_fact_class')
    assert not hasattr(hurd_network_collector_0, '_platform')
    assert not hasattr(hurd_network_collector_0, '_fact_class')
    assert not hasattr(hurd_network_collector_0, '_platform')
    assert not hasattr(hurd_network_collector_0, '_fact_class')
    assert not hasattr

# Generated at 2022-06-24 22:58:39.349347
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    assert(hurd_pfinet_network_0 is not None)


# Generated at 2022-06-24 22:58:40.377346
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert True == True


# Generated at 2022-06-24 22:58:46.625112
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    assert hurd_pfinet_network_0._device_index == 1000.0
    assert hurd_pfinet_network_0._link_files == list_0


# Generated at 2022-06-24 22:58:53.835978
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Testing for exception in populate
    try:
        test_case_0()
        # Initialize class
        test_HurdNetworkCollector = HurdNetworkCollector()
        test_HurdPfinetNetwork = HurdPfinetNetwork(None, None)
        # Testing for method __init__
        test_HurdPfinetNetwork = HurdPfinetNetwork(None, None)
        # Testing for method populate
        var_0 = test_HurdPfinetNetwork.populate()
    except NameError:
        pass

# Generated at 2022-06-24 22:58:59.228308
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    var_0 = hurd_pfinet_network_0.populate()



# Generated at 2022-06-24 22:59:05.255785
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_network_collector_0 = HurdNetworkCollector(float_0, list_0)
    assert hurd_network_collector_0.platform == 'GNU'
    assert hurd_network_collector_0.fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:59:10.993312
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)



# Generated at 2022-06-24 22:59:21.847200
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    arg_0 = {'interfaces': []}
    set_0 = set(arg_0)
    set_1 = set(['lo', 'eth1', 'eth3', 'eth2', 'eth0'])
    set_0.update(set_1)
    var_0 = hurd_pfinet_network_0.assign_network_facts(arg_0, '', '')
    set_0.update(set(var_0))

# Generated at 2022-06-24 22:59:28.841521
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert var_0 == {}

if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:59:35.816476
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    list_0 = [float_0, float_0, float_0, float_0]
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, list_0)
    hurd_network_collector_0 = HurdNetworkCollector(hurd_pfinet_network_0)

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()