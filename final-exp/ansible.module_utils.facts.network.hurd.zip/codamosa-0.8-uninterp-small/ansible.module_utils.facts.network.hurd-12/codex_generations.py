

# Generated at 2022-06-24 22:50:29.404558
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Create an object of HurdPfinetNetwork
    network = HurdPfinetNetwork(module=None)
    # Check if it is an instance of class Network
    assert isinstance(network, Network)
    # Check if it is an instance of class HurdPfinetNetwork
    assert isinstance(network, HurdPfinetNetwork)


# Generated at 2022-06-24 22:50:32.205224
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    HurdPfinetNetwork().populate()


# Generated at 2022-06-24 22:50:41.388357
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    network_obj = HurdPfinetNetwork()
    network_obj.module = AnsibleModule(argument_spec={})
    hardcoded_socket_path = "/servers/socket/inet"
    network_obj.module.run_command = MagicMock(return_value=(0,
        '--interface=eth0 --address=192.168.1.9 --netmask=255.255.255.0 --address6=2001:db8:0:f101::1/64 --address6=2001:db8:0:f102::1/64 --address6=2001:db8:0:f103::1/64',
        ''))
    collected_facts = network_obj.assign_network_facts(network_facts, 'fsysopts', hardcoded_socket_path)
    assert collected_

# Generated at 2022-06-24 22:50:42.835262
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork(None)


# Generated at 2022-06-24 22:50:52.841748
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-24 22:50:54.097820
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:00.747282
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    network_facts = {}
    hurd_pfinet_network = HurdPfinetNetwork(network_facts)
    fsysopts_path = '/usr/bin/fsysopts'
    result = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, '/servers/socket/inet')
    assert result is network_facts



# Generated at 2022-06-24 22:51:04.731012
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # test_case_0
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:13.173953
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)

    network_facts_0 = {}
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'

    out_0 = '--pfinet=socket --address=127.0.0.1 --netmask=255.255.255.0 --interface=eth0 --servicing=0 --default-route=0 --ifstat_bucketsize=2048 --ifstat_max_bytes=0 --ifstat_max_buckets=1000 --address6=::1/128'

# Generated at 2022-06-24 22:51:16.015829
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    HurdPfinetNetwork class constructor test
    """
    assert HurdPfinetNetwork().platform == 'GNU'



# Generated at 2022-06-24 22:51:31.271634
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts = {'interfaces': []}
    network_facts = hurd_pfinet_network_0.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')

    assert 'interfaces' in network_facts
    assert 'eth0' in network_facts
    assert 'eth0' in network_facts['interfaces']
    assert 'active' in network_facts['eth0']
    assert network_facts['eth0']['active'] is True
    assert 'device' in network_facts['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert 'ipv4' in network_facts['eth0']

# Generated at 2022-06-24 22:51:37.318187
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    hurd_pfinet_network = HurdPfinetNetwork(None)
    out = '''--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8::1/64'''
    ret = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:51:40.879837
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Unit test for method populate of class HurdPfinetNetwork
    hurd_network_collector_0 = HurdPfinetNetwork()
    assert hurd_network_collector_0.populate() is None


# Generated at 2022-06-24 22:51:42.079207
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:51.457128
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network = HurdPfinetNetwork()
    fsysopts_path = hurd_pfinet_network.module.get_bin_path('fsysopts')
    if fsysopts_path is not None:
        # FIXME: this test is platform dependent, so not portable
        socket_path = '/servers/socket/inet'
        assert socket_path is not None
        rc, out, err = hurd_pfinet_network.module.run_command([fsysopts_path, '-L', socket_path])
        assert rc is not None
        assert out is not None
        assert err is not None
    else:
        pass



# Generated at 2022-06-24 22:52:00.378252
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-24 22:52:02.078252
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector()


# Generated at 2022-06-24 22:52:07.875273
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts = {}
    fsysopts_path = '/servers/socket/'
    socket_path = '/servers/socket/'
    return_value = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:52:14.861079
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.mock_bin_path = {'fsysopts': '/bin/fsysopts'}
    module.mock_run_command = {'fsysopts -L c': 0, 'fsysopts -L /servers/socket/inet': 0, 'fsysopts': 0, 'fsysopts -L /servers/socket/inet6': 0}
    module.mock_os_path_exists = {'c': True, '/servers/socket/inet': True}
    module.mock_os_listdir = {'/servers': ['socket']}
    hurd_network_collector_0 = HurdNetworkCollector()
    network_facts_0 = {}
    network_facts_1 = hurd_network_collector_0._fact_class

# Generated at 2022-06-24 22:52:16.249255
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:52:28.703920
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector = HurdNetworkCollector()
    hurd_pfinet_network = hurd_network_collector._fact_class()
    assert hurd_pfinet_network.populate() == {}

# Generated at 2022-06-24 22:52:30.842212
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_collector = HurdNetworkCollector()
    network = HurdPfinetNetwork(module=None)
    network.populate()


# Generated at 2022-06-24 22:52:34.045773
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test = HurdPfinetNetwork()
    test.module = {}
    test.params = { 'gather_network_resources': [ 'interfaces', 'ipv4' ] }
    test.module.get_bin_path = mock_get_bin_path
    test.populate()


# Generated at 2022-06-24 22:52:40.729897
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )

    hurd_network_collector_0 = HurdNetworkCollector()
    facts = hurd_network_collector_0.collect(module)
    # TODO: a better way to test
    assert isinstance(facts, dict) is True


# Generated at 2022-06-24 22:52:48.210342
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-24 22:52:49.946852
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)


# Generated at 2022-06-24 22:53:00.382026
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {
        'interfaces': [],
    }

    fsysopts_path = '/path/to/fsysopts'
    socket_path = '/path/to/socket'

    hurd_pfinet_network = HurdPfinetNetwork()
    result = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:53:07.431656
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    facts = {'ansible_' + HurdPfinetNetwork._platform: {
        'interfaces': [],
        'default_ipv4': {},
    }}
    hurd_pfinet = HurdPfinetNetwork(facts)
    hurd_pfinet.populate()
    network_facts = facts['ansible_' + HurdPfinetNetwork._platform]
    assert 'interfaces' in network_facts
    assert len(network_facts['interfaces']) == 1
    for iface in network_facts['interfaces']:
        assert 'ipv4' in network_facts[iface]
        assert 'address' in network_facts[iface]['ipv4']
        assert 'netmask' in network_facts[iface]['ipv4']

# Generated at 2022-06-24 22:53:15.011249
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    import json

    hurd_pfinet_network_0 = HurdPfinetNetwork('module_0')

    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet6'


# Generated at 2022-06-24 22:53:25.931431
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # create fake module and inputs
    class FakeModule_1():
        def __init__(self):
            self.run_command = test_HurdPfinetNetwork_assign_network_facts_run_command
        def get_bin_path(self, arg1):
            return '/bin/fsysopts'
    module_1 = FakeModule_1()

    # create fake input
    collected_facts_1 = None
    fsysopts_path_1 = '/bin/fsysopts'
    socket_path_1 = '/servers/socket/inet'

    hurd_network_0 = HurdPfinetNetwork(module_1)
    result = hurd_network_0.assign_network_facts(collected_facts_1, fsysopts_path_1, socket_path_1)

    rc,

# Generated at 2022-06-24 22:53:45.882589
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fsysopts_data = """
    --interface=eth0
    --address=192.168.1.1
    --netmask=255.255.255.252
    --address6=fe80::ea60:6cff:fe05:8a85/64
    """
    module = get_module_mock(params={
        'fsysopts_data': fsysopts_data,
    })
    module.run_command = Mock(return_value=(0, fsysopts_data, ''))
    network_facts = HurdPfinetNetwork(module=module).populate()
    assert network_facts['kernel'] == 'GNU'
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']

# Generated at 2022-06-24 22:53:50.678907
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork(None)
    assert hurd_pfinet_network.platform != 'Linux'
    assert hurd_pfinet_network.platform != 'AIX'
    assert not hurd_pfinet_network.is_linux()
    assert not hurd_pfinet_network.is_bsd()
    assert not hurd_pfinet_network.is_aix()

# Generated at 2022-06-24 22:53:56.764977
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert 'network' in globals(), "network is not defined"
    assert 'HurdNetworkCollector' in globals(), "HurdNetworkCollector is not defined"
    global hurd_network_collector_0
    hurd_network_collector_0 = HurdNetworkCollector()
    assert '_platform' in dir(hurd_network_collector_0), "_platform is not defined"
    assert '_fact_class' in dir(hurd_network_collector_0), "_fact_class is not defined"
    assert hurd_network_collector_0._platform == 'GNU', "_platform should be 'GNU'"
    assert hurd_network_collector_0._fact_class == HurdPfinetNetwork, "_fact_class should be HurdPfinetNetwork"


# Generated at 2022-06-24 22:53:57.700238
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()

# Generated at 2022-06-24 22:53:59.625426
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test constructor of class HurdNetworkCollector
    """
    tester = HurdNetworkCollector()
    assert tester is not None

# Generated at 2022-06-24 22:54:05.444842
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network = HurdPfinetNetwork(None)

    # Test 0
    # data generated from hurd-pfinet.py
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet6'
    network_facts = {}


# Generated at 2022-06-24 22:54:08.163739
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork(module=None)
    test_network_facts_0 = hurd_pfinet_network_0.populate()
    assert test_network_facts_0 == {}

# Generated at 2022-06-24 22:54:17.664922
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    os.environ['PATH'] = '/usr/bin/'
    os.environ.pop('__ansible_test_interfaces', None)
    hurd_collector_0 = HurdPfinetNetwork()
    collected_facts = hurd_collector_0.populate()
    assert collected_facts['interfaces'] == ['eth0']
    assert collected_facts['eth0']['ipv4']['address'] == '192.168.1.125'
    assert collected_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert collected_facts['eth0']['ipv6'] == [{'address': 'fe80::250:56ff:fe93:14a6', 'prefix': '64'}]


# Generated at 2022-06-24 22:54:22.520545
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    # FIXME: This test is not valid with the new code
    hurd_pfinet_network_0 = HurdPfinetNetwork({
        'PATH': '',
    })
    # FIXME: This test is not valid with the new code
    # assert hurd_pfinet_network_0.populate() == json.loads('{"interfaces": ["lo0", "eth0"]}')



# Generated at 2022-06-24 22:54:23.981814
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector().platform == "GNU"



# Generated at 2022-06-24 22:54:52.178404
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    class FakeModule(object):
        def run_command(self, args):
            rc = 0
            out = '--address=10.0.0.1 --netmask=255.255.255.0 --address6=2001:db8::222/64 --address6=fe80::222/64'
            err = ''
            return rc, out, err

        def get_bin_path(self, binary):
            return binary

    class FakeNetwork(HurdPfinetNetwork):
        def __init__(self):
            self.module = FakeModule()

    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'

    fake_network = FakeNetwork()

# Generated at 2022-06-24 22:54:53.726560
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:55:02.666143
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test case 1
    module = MockModule()
    fsysopts_path = '/path/to/fsysopts'
    socket_path = '/path/to/socket/'
    hurd_pfinet_network = HurdPfinetNetwork(module)
    network_facts = {}
    out = '--interface=/dev/eth0 --address=10.10.10.20 --netmask=255.255.255.0 --address6=10.10.10.20/24'
    module.run_command.return_value = (0, out, '')
    result = hurd_pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:55:07.641292
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''Unit test'''
    hurd_network_0 = HurdPfinetNetwork()

    # The fsysopts command returns the following output
    #
    # --interface=/dev/eth0 --address=192.168.0.5 --netmask=255.255.255.0
    # --interface=/dev/eth1 --address=10.0.0.14 --netmask=255.255.255.0
    # --interface=/dev/eth0 --address6=fe80::215:5dff:fe28:6e90/64
    # --interface=/dev/eth1 --address6=fe80::215:5dff:fe28:6e91/64
    #
    # Will create a dict that looks like the following.
    #
    #     {
    #         "interfaces": [
    #            

# Generated at 2022-06-24 22:55:16.537284
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_0 = HurdPfinetNetwork()

    network_facts_0 = {}

    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'

    # Assignment
    result = hurd_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)

    # Tests for the method assign_network_facts
    # Assertion error: AssertionError: assert result == network_facts_0
    assert result == network_facts_0

#######################################################################


# Generated at 2022-06-24 22:55:25.037510
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_args = dict(
        gather_network_resources=dict(
            interfaces=dict(required=False),
            config=dict(required=False),
            routes=dict(required=False)
        )
    )
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    hn = HurdPfinetNetwork(module)
    #
    # Test individual methods in class HurdPfinetNetwork
    #
    # def assign_network_facts(self, network_facts, fsysopts_path, socket_path):
    # def populate(self, collected_facts=None):
    #
    # FIXME: the indentation below is for testing the code coverage
    # require more work to get it right.

# Generated at 2022-06-24 22:55:30.549303
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert(HurdNetworkCollector().__dict__ == {'_fact_class': HurdPfinetNetwork, '_fact_class_name': 'hurd_pfinet', '_platform': 'GNU'})


# Generated at 2022-06-24 22:55:38.288981
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()

    # test assign_network_facts.
    assert network.assign_network_facts({}, 'fsysopts', '/servers/socket/inet') == {
        'interfaces': ['eth0'],
        'eth0': {
            'device': 'eth0',
            'ipv4': {'address': '192.168.122.94', 'netmask': '255.255.255.0'},
            'active': True,
            'ipv6': []
        }
    }

# No problem if no module arguments passed

# Generated at 2022-06-24 22:55:41.220809
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = NetworkCollector()
    hurd = HurdPfinetNetwork(module)


# Generated at 2022-06-24 22:55:51.555406
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fsysopts_path = '/etc/fsysopts'
    fsysopts_path_return = '/etc/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = {}
    assign_facts = {'interfaces': [], 'lo': {'device': 'lo', 'active': True, 'ipv4': {}, 'ipv6': []}}


# Generated at 2022-06-24 22:56:50.862467
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert hurd_network_collector_0.platform == 'GNU'
    assert hurd_network_collector_0.fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:56:53.555787
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    global hurd_network_collector
    hurd_network_collector = HurdPfinetNetwork({}, {})
    out = hurd_network_collector.module.run_command(['fsysopts', '-L', '/servers/socket/inet'])
    assert out.split()[0] == "--interface=/dev/eth0"


# Generated at 2022-06-24 22:57:01.597284
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_iface0 = HurdPfinetNetwork(dict(module=dict()))
    # assign
    hurd_iface0.module = dict(run_command=lambda command: (0, '', ''))
    # act
    result = hurd_iface0.populate()
    # assert
    assert result == dict(interfaces=[])



# Generated at 2022-06-24 22:57:06.793786
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_net = HurdPfinetNetwork(module=None)
    assert hurd_net.populate()['interfaces'] == []

# AnsibleModule test for HurdPfinetNetwork

# Generated at 2022-06-24 22:57:17.350182
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    network_facts['interfaces'] = []
    fsysopts_path = "./tests/unit/module_utils/facts/network/ansible_test_fsysopts"
    socket_path = "./tests/unit/module_utils/facts/network/ansible_test_socket"

# Generated at 2022-06-24 22:57:23.305064
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    network_facts_0 = {}
    fsysopts_path_0 = ''
    socket_path_0 = ''
    network_facts_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0,
        fsysopts_path_0, socket_path_0)
    assert(network_facts_0 == {})


# Generated at 2022-06-24 22:57:26.089003
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:57:27.759415
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()

# vim: et ts=4 sw=4

# Generated at 2022-06-24 22:57:33.711247
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts_0 = dict()
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'
    network_facts_1 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:57:36.358762
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Test passing and failing
    pass

# Generated at 2022-06-24 22:58:59.234633
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bool_0 = True
    str_0 = 'CONNECT %s:%s HTTP/1.0\r\n'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0, str_0)
    network_facts = {}
    fsysopts_path = '/dev/'
    socket_path = '/dev/'
    var_0 = hurd_pfinet_network_0.assign_network_facts(
        network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:59:07.184198
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bool_0 = True
    str_0 = 'CONNECT %s:%s HTTP/1.0\r\n'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0, str_0)
    list_0 = list()
    int_0 = 0
    fsysopts_path = list_0[int_0]
    socket_path = list_0[int_0]
    network_facts = dict()
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:59:10.129075
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass


# Generated at 2022-06-24 22:59:14.651656
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        test_case_0()
    except Exception as exception:
        print('FAILURE - Exception occured:')
        print(str(exception))

# Generated at 2022-06-24 22:59:15.860473
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test constructor
    assert HurdNetworkCollector() is not None


# Generated at 2022-06-24 22:59:19.832907
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

if __name__ == '__main__':
    for t in dir():
        if t.startswith('test_'):
            eval(t)()

# Generated at 2022-06-24 22:59:26.082117
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bool_0 = True
    str_0 = 'CONNECT %s:%s HTTP/1.0\r\n'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0, str_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:59:29.594959
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        test_case_0()
    except Exception as err:
        print(err)


# Generated at 2022-06-24 22:59:30.743248
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert True

# Generated at 2022-06-24 22:59:37.179831
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bool_0 = True
    str_0 = 'CONNECT %s:%s HTTP/1.0\r\n'
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0, str_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0, Network)
