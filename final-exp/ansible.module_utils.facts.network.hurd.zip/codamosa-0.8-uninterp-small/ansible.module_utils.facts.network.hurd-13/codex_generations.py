

# Generated at 2022-06-24 22:50:35.095156
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Class for Hurd Network Facts
    """
    # Create an instance of class HurdNetworkCollector
    hurd_network_collector_0 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)


# Generated at 2022-06-24 22:50:37.019973
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    out = HurdPfinetNetwork()


# Generated at 2022-06-24 22:50:45.043685
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    network_facts_0 = {}
    fsysopts_path_0 = '/home/someuser/bin/fsysopts'
    socket_path_0 = '/home/someuser/bin/socket'
    hurd_network_collector_0._fact_class.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:50:53.143344
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockAnsibleModule()
    ifs = {"lo": {"device": "lo", "active": True, "ipv4": {"address": "127.0.0.1", "netmask": "255.0.0.0"}, "ipv6": []}, "eth0": {"device": "eth0", "active": True, "ipv4": {"address": "192.168.1.10", "netmask": "255.255.255.0"}, "ipv6": [{"prefix": "64", "address": "fe80::a00:27ff:fe6b:3e2d"}, {"prefix": "64", "address": "fe80::219:d7ff:fe01:79f7"}]}}

# Generated at 2022-06-24 22:50:55.286518
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_0 = hurd_network_collector_1.get_network_collector()


# Generated at 2022-06-24 22:51:00.055767
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector is not None


# Generated at 2022-06-24 22:51:02.376719
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    assert isinstance(hurd_pfinet_network_0, dict)


# Generated at 2022-06-24 22:51:06.241036
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts_0 = {}

    assert(type(hurd_pfinet_network_0.assign_network_facts(
        network_facts_0,
        'fsysopts_path',
        'socket_path'
    )) is dict)


# Generated at 2022-06-24 22:51:12.873770
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    assert HurdPfinetNetwork.assign_network_facts(None, '/usr/bin/fsysopts', '/servers/socket/') == {'interfaces': ['eth0'], 'eth0': {'ipv4': {'netmask': '255.0.0.0', 'address': '10.0.2.15'}, 'active': True, 'device': 'eth0', 'ipv6': [{'address': 'fe80::a00:27ff:fe3e:64c3', 'prefix': '64'}, {'address': 'fd00:1::2', 'prefix': '7'}]}}

# Generated at 2022-06-24 22:51:18.317631
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork(file)
    network_facts_0 = {}
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/servers/socket/inet'
    assert (hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0) != None)


# Generated at 2022-06-24 22:51:24.825836
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # TODO: write it
    return

# Generated at 2022-06-24 22:51:27.409201
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.collector.network.gnu.pfinet import HurdPfinetNetwork
    HurdPfinetNetwork()

# Generated at 2022-06-24 22:51:34.136280
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    class FakeModule():
        def get_bin_path(self, *args, **kwargs):
            pass
        def run_command(self, *args, **kwargs):
            pass
    class FakeNetworkCollector():
        def _get_interface_name(self, *args, **kwargs):
            return 'eth0'
    fake_module = FakeModule()
    fake_network_collector = FakeNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(fake_module, fake_network_collector, 'eth0')

# Generated at 2022-06-24 22:51:36.948855
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_obj_0 = HurdPfinetNetwork()
    assert 'GNU' in hurd_pfinet_network_obj_0.platform


# Generated at 2022-06-24 22:51:42.910207
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts, fsysopts_path, socket_path = {}, '/foo', '/bar'
    hurd_pfinet_network_0 = HurdPfinetNetwork(module=None)
    network_facts_updated = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert 'interfaces' in network_facts_updated

# Generated at 2022-06-24 22:51:48.186126
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector


# Generated at 2022-06-24 22:51:53.796612
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_object = HurdPfinetNetwork(None)
    network_facts = {}
    fsysopts_path = '/foo/bar/fsysopts'
    socket_path = '/foo/bar/some/socket/path'
    test_object.module.run_command = lambda x, check_rc=True: (0, '--interface=dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64\n', '')
    network_facts['interfaces'] = []
    network_facts = test_object.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'


# Generated at 2022-06-24 22:51:56.476101
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network_0 = HurdPfinetNetwork()
    assert hurd_network_0.platform == 'GNU'
    assert hurd_network_0._socket_dir == '/servers/socket/'



# Generated at 2022-06-24 22:51:58.733777
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    network_facts = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:52:10.036787
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    In this test we mock the system and see if we get the expected results.
    '''
    # Some test data to use with our mock.
    socket_path = None
    fsysopts_path = '/usr/bin/fsysopts'
    network_facts = {}
    output = '''--interface=/dev/eth0 --address=172.26.0.46 --broadcast=172.26.0.255 --netmask=255.255.0.0 --address6=fe80::a00:27ff:fe82:51ba/64 --address6=2a03:2260:102:1:a00:27ff:fe82:51ba/64
'''

# Generated at 2022-06-24 22:52:26.960618
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    tuple_1 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_1)
    tuple_2 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_2)
    tuple_3 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_3)
    tuple_4 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_4)
    tuple_5 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_5)
    tuple_6 = ()
    hurd_pfinet

# Generated at 2022-06-24 22:52:27.753629
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:52:33.484173
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    assert tuple_0 == () and hurd_pfinet_network_0._platform == 'GNU'
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)


# Generated at 2022-06-24 22:52:44.932254
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'rqj)aCQ-L<,]:H;+bKOD*'
    tuple_0 = ()
    var_0 = HurdPfinetNetwork(tuple_0)
    var_1 = var_0.populate(str_0)
    # Returns None
    assert var_1 == None, 'Return value of HurdPfinetNetwork.populate(str_0) is not None'

    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_2 = hurd_pfinet_network_0.populate(str_0)


# Generated at 2022-06-24 22:52:54.242478
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'J/^|>G/}Mel;?\tfkI'
    str_1 = '7XoJ*\t0T0\x0c\x0e\x0f'
    str_2 = '^4QL~H0\t*{z?\x00'
    tuple_0 = (str_0, )
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    dict_0 = dict()
    dict_0[str_0] = dict()
    dict_0[str_0]['interface'] = str_1
    dict_0[str_0]['address'] = str_1
    dict_0[str_0]['netmask'] = str_1

# Generated at 2022-06-24 22:52:55.673242
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert callable(HurdPfinetNetwork)


# Generated at 2022-06-24 22:52:59.450246
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    # Arrange
    collected_facts = None
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)

    # Act
    out_0 = hurd_pfinet_network_0.populate(collected_facts)

    # Assert
    assert out_0 != None


# Generated at 2022-06-24 22:53:07.252117
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    str_0 = 'zp~mR'
    str_1 = 'kMq'
    str_2 = 'Hi'
    str_3 = 'aaa=bbb'
    str_4 = 'bbb=ccc'
    hurd_pfinet_network_0.assign_network_facts(str_0, str_1, str_2)
    hurd_pfinet_network_0.assign_network_facts(str_3, str_4, str_3)


if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()

# Generated at 2022-06-24 22:53:08.060780
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-24 22:53:10.711104
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    # FIXME: build test string, then call method under test
    # and verify result.
    pass


# Generated at 2022-06-24 22:53:30.890541
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fsysopts_path = '--interface=eth0 --netmask=255.255.255.0'
    socket_path = '--interface=eth0 --netmask=255.255.255.0'
    # Test for presence of 'interface' in out
    # Test for presence of 'address' in out
    # Test for presence of 'netmask' in out
    # Test for presence of 'address6' in out
    # Test normalize of address, prefix
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # Assign network_facts
    # return network_facts
   

# Generated at 2022-06-24 22:53:33.300226
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Case 0
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)



# Generated at 2022-06-24 22:53:35.671976
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '8WJ]nNvC'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)
    assert var_0 == {}


# Generated at 2022-06-24 22:53:44.605149
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    collected_facts_0 = str()
    fsysopts_path_0 = 'DgW*9X$HG"C%f}7g^&'
    socket_path_0 = 'q\rp)zMH}E@1L!y[{r'
    var_0 = hurd_pfinet_network_0.assign_network_facts(collected_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:53:47.643972
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)
    assert hurd_network_collector_0._fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:53:53.740824
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    print('')
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts()
    if var_0 is None:
        print('')
        test_case_0()

test_case_0()

# Generated at 2022-06-24 22:53:56.305340
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '*'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)


# Generated at 2022-06-24 22:53:59.338442
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork) is True


# Generated at 2022-06-24 22:54:02.411332
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)
    assert isinstance(hurd_network_collector_0._fact_class, HurdPfinetNetwork)


# Generated at 2022-06-24 22:54:05.302368
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'Dej;2D[xEcw0J\r)rJ\r^rX\r{5y'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    hurd_pfinet_network_0.assign_network_facts(str_0, str_0, str_0)


# Generated at 2022-06-24 22:54:32.353792
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)

# Generated at 2022-06-24 22:54:33.334290
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass


# Generated at 2022-06-24 22:54:38.715108
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    input_0 = 'fsysopts-Lsocket'
    output_0 = 'data'
    hurd_pfinet_network_0 = HurdPfinetNetwork(input_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(output_0, input_0, input_0)


# Generated at 2022-06-24 22:54:46.010523
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    str_0 = 'NnQ_RPu_d'

# Generated at 2022-06-24 22:54:47.816968
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    try:
        x = HurdPfinetNetwork()
    except:
        assert False


# Generated at 2022-06-24 22:54:51.930802
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:54:55.539492
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)

# Generated at 2022-06-24 22:54:59.104062
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'W0\rZfu[9Xq3'
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)
    hurd_network_collector_0.populate(str_0)


# Generated at 2022-06-24 22:55:07.151814
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    str_0 = 'L0xg]J~7.@3Wt.!7Xvi'
    str_1 = 'L0xg]J~7.@3Wt.!7Xvi'
    str_2 = '5g&N(J#%cB1/2Gx0o+w'
    str_3 = '9Z.N:.p[rFwd8Pvzd#p'
    str_4 = 'ER}+m$Dyr:n:lX2_/+o'

# Generated at 2022-06-24 22:55:08.438694
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)

# Generated at 2022-06-24 22:56:04.523787
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Create a blank HurdNetworkCollector object
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:56:07.488543
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)


# Generated at 2022-06-24 22:56:14.951946
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'N%5#5y5N5N5'
    list_0 = ['(LY', 'j{', 'TL', ';', '@[5j5Y5N5d5', 'I']
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    assert hurd_pfinet_network_0.assign_network_facts(list_0, list_0, str_0) == list_0


# Generated at 2022-06-24 22:56:15.631823
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:56:19.480062
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)


# Generated at 2022-06-24 22:56:21.831299
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)


# Generated at 2022-06-24 22:56:28.584450
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)


# Generated at 2022-06-24 22:56:35.622417
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0_0 = ()
    hurd_pfinet_network_0_0 = HurdPfinetNetwork(tuple_0_0)
    assert type(hurd_pfinet_network_0_0) == HurdPfinetNetwork
    assert "tuple_0" in globals() or "tuple_0" in locals()
    assert "hurd_pfinet_network_0" in globals() or "hurd_pfinet_network_0" in locals()
    assert "str_0" in globals() or "str_0" in locals()


# Generated at 2022-06-24 22:56:38.051744
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    # Test method populate of class HurdPfinetNetwork
    test_case_0()


# Generated at 2022-06-24 22:56:38.821919
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:58:54.501718
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    tuple_0 = ()
    hurd_network_collector_0 = HurdNetworkCollector(tuple_0)

# Generated at 2022-06-24 22:58:58.829986
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)


# Generated at 2022-06-24 22:59:04.847272
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    var_0 = hurd_pfinet_network_0.populate(str_0)

# Generated at 2022-06-24 22:59:15.302708
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'fvG~E[pw,yj\x7f^D'
    str_1 = 'fvG~E[pw,yj\x7f^D'
    str_2 = ''
    dict_0 = {}
    int_0 = 8
    int_1 = 8
    int_2 = 8
    int_3 = 8
    list_0 = ['', '', '', '', '', '', '', '']
    list_1 = ['', '', '', '', '', '', '', '']
    list_2 = ['', '', '', '', '', '', '', '']
    tuple_0 = ()
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}

# Generated at 2022-06-24 22:59:21.340571
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    tuple_0 = ()
    str_0 = 'nUD9!^'
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)
    tuple_1 = (1, 2, 3)
    hurd_pfinet_network_1 = HurdPfinetNetwork(tuple_1)
    var_1 = hurd_pfinet_network_1.assign_network_facts(str_0, tuple_0, tuple_1)
    list_0 = []
    hurd_pfinet_network_2 = HurdPfinetNetwork(list_0)
    var_2 = hurd_pfinet_network_2.populate(str_0)

# Generated at 2022-06-24 22:59:30.674853
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    std_out_0, std_err_0 = b'', b''
    round_trip_0 = {'ipv6': [{'prefix': '64', 'address': 'fe80::a00:27ff:fee7:f2d9'}], 'ipv4': {'netmask': '255.255.255.0', 'address': '192.168.1.7'}, 'active': True, 'device': 'eth0'}
    tuple_0 = (std_out_0, std_err_0)
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:59:41.763814
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_2 = 'e.)WHrctDCRN.);\rYQ}d'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    module_0 = type('', (), {'get_bin_path': hurd_pfinet_network_0.get_bin_path, 'run_command': lambda path: (0, '', '')})
    hurd_pfinet_network_0.module = module_0()
    str_3 = 'gXux%#F`&'
    str_4 = 'A)UOd>lHk'
    str_0 = 'e.)WHrctDCRN.);\rYQ}d'
    var_0 = hurd_pfinet_network_0.assign_network

# Generated at 2022-06-24 22:59:44.359141
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:59:53.425259
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    str_0 = 'Mtu'
    str_1 = 'T'
    tuple_1 = (str_0, str_1)
    str_2 = '=P'
    str_3 = '4L'
    str_4 = 'N=bkH!y'
    str_5 = '\x1c'
    str_6 = 'd4'
    str_7 = 'k'
    str_8 = 'd'
    str_9 = 'J'
    str_10 = 'IN'
    str_11 = 'o}#'
    str_12 = 'R9'
    str_13 = 'e'
    str_14 = 'N'
    str

# Generated at 2022-06-24 23:00:00.333950
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '$CNQYcZ~Fz*Qx}qF^f%G'
    tuple_0 = ()
    hurd_pfinet_network_0 = HurdPfinetNetwork(tuple_0)
    var_0 = hurd_pfinet_network_0.populate(str_0)
