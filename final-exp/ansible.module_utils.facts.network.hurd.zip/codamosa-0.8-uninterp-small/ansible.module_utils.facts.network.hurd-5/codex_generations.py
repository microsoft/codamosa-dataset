

# Generated at 2022-06-24 22:50:32.010032
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fact_class_0 = HurdPfinetNetwork()


# Generated at 2022-06-24 22:50:34.811355
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert hurd_network_collector_0._platform == 'GNU'

# Generated at 2022-06-24 22:50:36.680478
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()


# Generated at 2022-06-24 22:50:38.305568
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork(module=None)


# Generated at 2022-06-24 22:50:40.493212
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    result = hurd_pfinet_network_0.populate()
    assert result is None


# Generated at 2022-06-24 22:50:50.272379
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_object = HurdPfinetNetwork()
    test_object._socket_dir = '/usr/lib/python2.7/unittest/data/network_tests/'
    test_object.module = MagicMock()
    test_object.module.get_bin_path.return_value = '/usr/lib/python2.7/unittest/data/network_tests/fsysopts'

# Generated at 2022-06-24 22:50:57.245491
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    arguments = {'module_name': 'setup', 'module_args': '', '_ansible_check_mode': False, '_ansible_debug': True, '_ansible_diff': False, '_ansible_verbosity': 3, '_used_image_module': False, '_uses_shell': False, '_ansible_module_name': 'setup', '_ansible_syslog_facility': 'LOG_USER', '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p'], '_ansible_no_log': False, '_ansible_socket': None, '_ansible_string_conversion_action': 'warn', '_ansible_module_skeleton_ignore': []}

# Generated at 2022-06-24 22:51:05.465037
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    interface = 'eth0'
    address = '10.0.0.1'
    netmask = '255.255.255.0'
    address6 = '2002:c0a8:101::1'
    prefix = '64'

    module_args = {
        'run_command': lambda x, y: (0, interface, ''),
    }
    module_facts = {
        'get_bin_path': lambda x: '',
    }
    network = HurdPfinetNetwork(module=module_args, facts=module_facts)
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, '', '')
    assert interface in network_facts['interfaces']
    assert network_facts[interface]['ipv4']['address'] == address

# Generated at 2022-06-24 22:51:08.088541
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork
    assert isinstance(HurdNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:51:14.202028
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hostvars = {}
    facts = {'network': {}}
    facts['network'] = HurdPfinetNetwork().assign_network_facts(facts['network'], 'fsysopts', '/servers/socket/inet')
    assert 'interfaces' in facts['network']
    assert 'enp0s3' in facts['network']['interfaces']

# Generated at 2022-06-24 22:51:22.088816
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass


if __name__ == '__main__':
    import pytest

    pytest.main(['-s', __file__])

# Generated at 2022-06-24 22:51:26.611457
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass


# Generated at 2022-06-24 22:51:28.643908
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert hasattr(HurdNetworkCollector(),'populate')


# Generated at 2022-06-24 22:51:33.160220
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:51:34.089702
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()

# Generated at 2022-06-24 22:51:36.899482
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = MockModule()
    if HurdPfinetNetwork(module).platform == 'GNU':
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:51:39.467626
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)


# Generated at 2022-06-24 22:51:46.602546
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class ModuleMock0:
        def __init__(self):
            self.run_command_calls = 0
            self.params = {}
            self.command = None
            self.rc = None
            self.out = None
            self.err = None
            self.run_command_values = {
                ['fsysopts', '-L', '/servers/socket/inet']: (0, '--interface=/dev/eth0 --address=192.168.1.10 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe66:8c58/64', ''),
            }
        def get_bin_path(self, arg):
            if arg == 'fsysopts':
                return '/foo/fsysopts'

# Generated at 2022-06-24 22:51:49.341436
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    try:
        # Initialize object
        hurd_network_collector_0 = HurdNetworkCollector()
    except:
        print("Initializing object of class HurdNetworkCollector failed... ")
        raise


# Generated at 2022-06-24 22:51:51.374452
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_pfinet_network = HurdPfinetNetwork()

    # TODO: test



# Generated at 2022-06-24 22:51:58.770767
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:52:05.832243
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = dict()
    var_0 = hurd_pfinet_network_0.assign_network_facts(var_0, '--freq', '/servers/socket')


# Generated at 2022-06-24 22:52:09.600371
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    out_0, err_0 = capsys.readouterr()
    assert out_0 == "", "Expected nothing to be outputted to stdout"
    assert err_0 == "", "Expected nothing to be outputted to stderr"
#vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-24 22:52:17.696222
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    # Get the HurdPfinetNetwork object
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)

    # Set a known value for network_facts
    network_facts_dict = {}
    network_facts_dict['interfaces'] = []
    #network_facts_dict['interfaces'].append('en0')
    #network_facts_dict['en0'] = {}
    #network_facts_dict['en0']['ipv4'] = {}
    #network_facts_dict['en0']['ipv4']['address'] = '192.168.1.1'
    #network_facts_dict['en0']['ipv4']['netmask'] = '

# Generated at 2022-06-24 22:52:20.441732
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    g_param = {
        'fsysopts': '/bin/fsysopts',
        'socket_path': 'dummy value',
    }
    g_result_expected = 'dummy value'
    g_result = HurdPfinetNetwork.populate(g_param)
    assert g_result == g_result_expected


# Generated at 2022-06-24 22:52:21.412941
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # FIXME: implement this test
    pass

# Generated at 2022-06-24 22:52:22.684722
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    collect_network = HurdPfinetNetwork()
    assert collect_network.populate()

# Generated at 2022-06-24 22:52:23.957204
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:52:28.300941
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pfinet_network_collector = HurdNetworkCollector()
    pfinet_network = HurdPfinetNetwork(pfinet_network_collector)
    assert pfinet_network.populate() is not None


# Generated at 2022-06-24 22:52:30.141327
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

if __name__ == "__main__":
    import pytest
    pytest.main([__file__, '-v'])

# Generated at 2022-06-24 22:52:42.698289
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass


# Generated at 2022-06-24 22:52:46.089554
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    res = assign_network_facts(network_facts=None, fsysopts_path=None, socket_path=None)
    if res is not None:
        print('Assign network facts should return None')
    print('Test 2 passed')


# Generated at 2022-06-24 22:52:49.557250
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert var_0 is None


# Generated at 2022-06-24 22:52:54.991385
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = hurd_pfinet_network_0.populate()
    assert isinstance(var_0, dict)

if __name__ == '__main__':
    test_HurdPfinetNetwork_assign_network_facts()
    test_case_0()

# Generated at 2022-06-24 22:52:58.418372
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network_collector = HurdNetworkCollector()
    hurd_pfinet_network = HurdPfinetNetwork(hurd_network_collector)
    assert isinstance(hurd_pfinet_network, HurdPfinetNetwork)


# Generated at 2022-06-24 22:53:02.998040
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert (hurd_network_collector_0._fact_class.__name__ == 'HurdPfinetNetwork')
    assert (hurd_network_collector_0._platform == 'GNU')


# Generated at 2022-06-24 22:53:07.018863
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = {}
    # FIXME: should be a different test
    # assert hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path) == {}
    # FIXME: should be a different test
    # assert hurd_pfinet_network_0.populate() == {}


# Generated at 2022-06-24 22:53:14.581276
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    ansible_module_0 = AnsibleModule(
        argument_spec={
        }
    )
    # Test using fsysopts.
    if not os.path.exists(hurd_pfinet_network_0.module.get_bin_path('fsysopts')):
        ansible_module_0.exit_json(
            skipped=True, msg="Fsysopts not found, skipping tests"
        )
    else:
        hurd_pfinet_network_0.module = ansible_module_0
        for x in range(10):
            arg = {}
            with pytest.raises(AnsibleFailJson):
                hurd_pfinet_network_0.assign_network_facts(**arg)

# Generated at 2022-06-24 22:53:18.802307
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    assert isinstance(hurd_pfinet_network_1.populate(), dict)


# Generated at 2022-06-24 22:53:29.858824
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    network_facts_0 = {}
    # FIXME: 'fsysopts_path' should be a command result
    fsysopts_path_0 = 'fsysopts'
    socket_path_0 = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()
    print('test completed')

# Generated at 2022-06-24 22:53:54.488480
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-24 22:53:57.352184
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)


# Generated at 2022-06-24 22:54:06.219755
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fsysopts_path = '/gnumach-1.8/sbin/fsysopts'
    socket_path = '/hurd/pfinet/0/inet'
    collected_facts = None
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var1 = hurd_pfinet_network_0.populate()
    var2 = HurdPfinetNetwork.assign_network_facts(hurd_pfinet_network_0, fsysopts_path, socket_path)
    var2['interfaces'].sort()
    var1['interfaces'].sort()

    assert var1 == var2
    assert hurd_pfinet_network_0.platform

# Generated at 2022-06-24 22:54:13.499280
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)

    # modify class attributes
    hurd_pfinet_network_1._socket_dir = '/servers/socket/'
    # call method
    var_1 = hurd_pfinet_network_1.populate()

# Generated at 2022-06-24 22:54:19.275726
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create some variables
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    # Call method
    var_1 = hurd_pfinet_network_1.populate()
    # Assert the expected result
    # assert var_1 == {'interfaces': ['eth0', 'eth1'], 'eth0': {'ipv4': {'address': '192.168.1.2', 'netmask': '255.255.255.0'}, 'ipv6': [{'address': 'fe80::226:9bff:fed4:34d7', 'prefix': '64'}], 'device': 'eth0', 'active': True}, 'eth1': {'ipv4':

# Generated at 2022-06-24 22:54:21.585985
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    '''
    assert True

# Generated at 2022-06-24 22:54:32.281904
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from mock import Mock, create_autospec, sentinel
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)
    var_0 = {'test': sentinel.sentinel_0}
    var_1 = sentinel.sentinel_1
    var_2 = sentinel.sentinel_2

    with create_autospec(hurd_pfinet_network_0.module, spec_set=True, instance=True) as mock_module:
        mock_module.run_command.return_value = var_0, sentinel.sentinel_3, sentinel.sentinel_4
        mock_module.get_bin_path.return_value = sentinel.sentinel_5
       

# Generated at 2022-06-24 22:54:43.341359
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from units.mock.proc import MockProcess
    from ansible.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd.pfinet import test_case_0
    import sys
    import types

    MockProcess.use_mock_subprocess()

    # Constructor test case 0
    setattr(sys.modules[__name__], 'ansible_module', types.ModuleType(u'ansible_module'))
    setattr(sys.modules[u'ansible_module'], 'run_command', types.FunctionType(test_case_0.func_code, test_case_0.func_globals))
    HurdPfinetNetwork(ansible_module=ansible_module)

    # Clean up


# Generated at 2022-06-24 22:54:53.146708
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)

    var_1 = {
        'interfaces': [],
        'default_ipv4': {
            'gateway': None,
        },
        'all_ipv4_addresses': [],
    }

    var_2 = '/tmp/fsysopt_mock'
    var_3 = '/tmp/sock_mock'

    def mock_run_command_1(module, *args, **kwargs):
        out = '--interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=[::1]/64'

# Generated at 2022-06-24 22:55:02.894476
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    from ansible.module_utils.facts.network.base import Network

    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0)

    req_args = [
        'fsysopts',
        '/servers/socket/inet',
    ]


# Generated at 2022-06-24 22:55:58.456440
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # mock module
    module = MagicMock()

    module.run_command = MagicMock(return_value=['', '', ''])

    # mock network_facts
    network_facts = {'interfaces': []}

    # mock fsysopts_path
    fsysopts_path = ''

    # mock socket_path
    socket_path = ''

    # create result object
    result = {'interfaces': []}

    # call method
    HurdPfinetNetwork(module).assign_network_facts(
        network_facts,
        fsysopts_path,
        socket_path
    )

    # assert resul object
    assert result == network_facts

# Generated at 2022-06-24 22:56:00.037500
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-24 22:56:06.080297
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0, Network)


# Generated at 2022-06-24 22:56:06.977880
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:56:09.320875
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    if hasattr(HurdPfinetNetwork, 'platform'):
        var_1 = HurdPfinetNetwork.platform
        assert var_1 == 'GNU', var_1


# Generated at 2022-06-24 22:56:10.615880
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:56:17.671607
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fact_file = '/etc/ansible/facts.d/os_facts.fact'
    if os.path.exists(fact_file):
        os.remove(fact_file)
    # Create test object
    network_collector = HurdNetworkCollector()
    assert network_collector is not None
    # Call method populate
    network_collector.populate()
    # Write facts to file
    network_collector.write_facts_file('os_facts')
    # Read facts from file
    facts = network_collector.read_facts_file('os_facts')
    assert ('ansible_eth0' in facts)
    assert ('ansible_eth1' in facts)
    assert ('ansible_epair0a' in facts)
    assert ('ansible_epair0b' in facts)

# Generated at 2022-06-24 22:56:20.197146
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_case_0()

# Generated at 2022-06-24 22:56:21.792812
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)


# Generated at 2022-06-24 22:56:25.493218
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:58:48.161078
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    var_1 = {'version': 2}
    var_2 = 'fsysopts'
    var_3 = '/servers/socket/inet'
    var_1 = hurd_pfinet_network_1.assign_network_facts(var_1, var_2, var_3)
    var_1 = hurd_pfinet_network_1.populate()


# Generated at 2022-06-24 22:58:53.979031
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    if True:
        var_1 = hurd_pfinet_network_1.populate()
        assert var_1 == {}, 'If the fsysopts command is not found, an empty dict is returned'

# Generated at 2022-06-24 22:58:55.115195
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
  pass

# Generated at 2022-06-24 22:59:00.352308
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network_collector_1 = HurdNetworkCollector()
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_1)
    assert isinstance(hurd_pfinet_network_1, HurdPfinetNetwork)

if __name__ == "__main__":
    test_case_0()
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:59:04.624611
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    arg_0 = HurdNetworkCollector()
    arg_1 = None
    obj = HurdPfinetNetwork(arg_0, arg_1)
    assert isinstance(obj, HurdPfinetNetwork)


# Generated at 2022-06-24 22:59:08.103941
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass

# Generated at 2022-06-24 22:59:14.303310
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    var_1 = 'tmp/test_answer.txt'
    var_2 = 'tmp/test_answer.txt'
    var_3 = dict()
    var_3 = hurd_pfinet_network_0.assign_network_facts(var_3, var_1, var_2)
    assert var_3['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert var_3['eth0']['active'] is True


# Generated at 2022-06-24 22:59:17.697952
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    pass


# Generated at 2022-06-24 22:59:20.477856
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()
    assert hurd_network_collector_0._platform == 'GNU'
    assert hurd_network_collector_0._fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:59:21.653317
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    result = test_case_0()
    assert True

