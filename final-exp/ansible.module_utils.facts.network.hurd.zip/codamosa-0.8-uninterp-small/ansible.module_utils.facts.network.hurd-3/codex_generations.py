

# Generated at 2022-06-24 22:50:32.544824
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # net_collector = HurdNetworkCollector()
    assert(True), "Unit test for constructor of class HurdNetworkCollector"


# Generated at 2022-06-24 22:50:33.747894
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()


# Generated at 2022-06-24 22:50:41.804727
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    # Check : Result of assign_network_facts for eth0, ipv4 and ipv6 
    #         are returned.
    network_facts = {
        "interfaces": [],
        "lo": {
            "active": True,
            "device": "lo",
            "ipv4": {},
            "ipv6": []
        }
    }
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    hpn = HurdPfinetNetwork(module=None)
    network_facts = hpn.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-24 22:50:51.944522
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    ansible_module_0 = AnsibleModule(argument_spec=dict())
    fsysopts_path = None
    socket_path = '/servers/socket/inet'
    network_facts_0 = dict()
    network_facts_1 = dict()

    ansible_module_0.params = dict(format='json')
    hurd_pfinet_network_0 = HurdPfinetNetwork(ansible_module_0)

    def run_command(*args, **kwargs):
        return (0, 'interface=--/dev/eth0', '')

    ansible_module_0.run_command = run_command
    network_facts_0 = hurd_pfinet_network_0.populate(network_facts_1)

    assert network_facts_0['interfaces'] == ['eth0']

# Generated at 2022-06-24 22:50:53.382845
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)


# Generated at 2022-06-24 22:50:59.809545
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Generate fake facts
    fake_facts = {}
    expected_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    # Test case without fsysopts_path
    result_facts = HurdPfinetNetwork.populate(None, fake_facts)
    assert_facts(result_facts, fake_facts)
    # Test case without socket_path
    # FIXME: need a different way around this
    fake_facts['fsysopts_path'] = fsysopts_path
    # result_facts = HurdPfinetNetwork.populate(None, fake_facts)
    # assert_facts(result_facts, fake_facts)
    # Test case with real values

# Generated at 2022-06-24 22:51:00.941258
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert test_case_0() is None

# unit test for the first test case

# Generated at 2022-06-24 22:51:11.629982
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()

    assert hurd_network_collector._platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork
    assert len(hurd_network_collector._fallback_factsets) == 0
    assert 'default' not in hurd_network_collector._collector_platforms
    assert 'BSD' not in hurd_network_collector._collector_platforms
    assert 'Linux' not in hurd_network_collector._collector_platforms
    assert 'SunOS' not in hurd_network_collector._collector_platforms
    assert 'Darwin' not in hurd_network_collector._collector_platforms
    assert 'NetBSD' not in hurd_network_collector._collector_platforms

# Generated at 2022-06-24 22:51:13.070147
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()


# Generated at 2022-06-24 22:51:17.172909
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    x = HurdPfinetNetwork()
    assert x.platform == 'GNU', "Testcase 0 failed."



# Generated at 2022-06-24 22:51:30.676303
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.populate(str_0, list_0, str_1)


# Generated at 2022-06-24 22:51:39.610016
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Input parameters testing
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)

# Generated at 2022-06-24 22:51:43.818835
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
  # Create a module fixture
  module = AnsibleModule(argument_spec={})

  # Create a HurdPfinetNetwork object
  hpnet = HurdPfinetNetwork(module)

  # Test the attributes
  assert hpnet.platform == 'GNU'
  assert hpnet._socket_dir == '/servers/socket/'




# Generated at 2022-06-24 22:51:50.278613
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module_0 = AnsibleModule(
        argument_spec=dict(
        )
    )
    float_0 = -5545.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0, module_0)
    hurd_network_collector_0 = HurdNetworkCollector(hurd_pfinet_network_0)
    assert(hurd_network_collector_0.platform == 'GNU')
    assert(hurd_network_collector_0._fact_class == HurdPfinetNetwork)
    assert(hurd_network_collector_0.default_collectors() == ['HurdNetworkCollector'])

# Generated at 2022-06-24 22:51:55.016909
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    _module = AnsibleModule(
        argument_spec = dict()
    )

    network_collector = HurdNetworkCollector()
    network = HurdPfinetNetwork(_module)

    expected_data = {
        'interfaces': [],
    }
    assert_equal(network.populate(), expected_data)


# Generated at 2022-06-24 22:52:02.083906
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:52:04.387925
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = -2743.0
    hurd_network_collector_0 = HurdNetworkCollector()
    return


# Generated at 2022-06-24 22:52:08.143454
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # TODO:
    # test the constructor of HurdNetworkCollector
    pass


# Generated at 2022-06-24 22:52:15.015019
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.populate(str_0, list_0, str_1)

if __name__ == '__main__':
    import datetime
    begin = datetime.datetime.now()
    test_case_0()
   

# Generated at 2022-06-24 22:52:26.204491
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    try:
        var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)
    except:
        var_0 = False
    assert var_0


# Generated at 2022-06-24 22:52:39.273857
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    print('test_HurdPfinetNetwork')
    test_case_0()


# Generated at 2022-06-24 22:52:48.148051
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    int_0 = -1
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_0, Network)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    assert isinstance(hurd_pfinet_network_1, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network_1, Network)

# Generated at 2022-06-24 22:52:49.032485
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    pass


# Generated at 2022-06-24 22:52:53.068356
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    int_0 = 0
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(int_0)
    result = hurd_pfinet_network_0.populate(None)
    assert result is not None


# Generated at 2022-06-24 22:53:01.444912
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '\x0b'
    list_0 = []
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    assert isinstance(hurd_pfinet_network_1, HurdPfinetNetwork)
    # Test assign_network_facts method
    str_1 = '~.K66ccywRHC+IKlT!'
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:53:11.793675
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    _str_0 = '<oHjK\x7f@e'
    _list_0 = []
    _list_1 = []
    _list_2 = []
    _list_3 = []
    _list_4 = []
    _list_5 = []
    _list_6 = []
    _list_7 = []
    _list_8 = []
    _list_9 = []
    _list_10 = []
    _tuple_0 = (2080.468, -0.4985)
    _tuple_1 = (3279, 2.771307157422398)
    _tuple_2 = (-1928, 26.126)
    _tuple_3 = (4524, -0.2)
    _tuple_4 = (-2492, -0.54)

# Generated at 2022-06-24 22:53:14.218468
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    print('\nTesting constructor for class HurdPfinetNetwork')
    test_case_0()
    print('\nEnd of testing constructor for class HurdPfinetNetwork')



# Generated at 2022-06-24 22:53:20.274798
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)



# Generated at 2022-06-24 22:53:21.319563
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_1 = HurdNetworkCollector()


# Generated at 2022-06-24 22:53:29.785585
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    map_0 = {'S@Yt|Gp': 'l\x0b', '4$': '~.K66ccywRHC+IKlT!'}
    str_0 = 'Qc%l0a'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.populate(map_0, str_0)

# Generated at 2022-06-24 22:53:51.107013
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    assert True


# Generated at 2022-06-24 22:53:56.254879
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    list_0 = []
    float_0 = -1031.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_pfinet_network_0)
    assert True


# Generated at 2022-06-24 22:54:00.520124
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    HurdPfinetNetwork.populate()
    assert True


# Generated at 2022-06-24 22:54:02.401683
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    b = HurdPfinetNetwork(None)
    assert b.populate() == {}



# Generated at 2022-06-24 22:54:04.010805
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_1 = 'e'
    HurdPfinetNetwork(str_1)


# Generated at 2022-06-24 22:54:05.228339
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:54:14.863403
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    instance0 = HurdPfinetNetwork()

    module0 = AnsibleModule(
        argument_spec = dict(
            collected_facts=dict(type='dict', required=True),
            fsysopts_path=dict(type='str', required=True),
            socket_path=dict(type='str', required=True)
        )
    )
    if not module0.check_mode:
        result = instance0.assign_network_facts(module0.params['collected_facts'], module0.params['fsysopts_path'], module0.params['socket_path'])

    clean_facts = dict(changed=False, ansible_facts=dict(ansible_network_resources=dict(interfaces=[])))
    assert result == clean_facts


# Generated at 2022-06-24 22:54:24.852311
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = -2743.0
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    var_0 = hurd_pfinet_network_0.assign_network_facts(str_0, list_0, str_1)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_1 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)

# Generated at 2022-06-24 22:54:31.747455
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    collection_0 = HurdNetworkCollector()
    module_0 = AnsibleModuleMock()
    module_0.run_command = mock_run_command
    hurd_pfinet_network_0 = HurdPfinetNetwork(module_0, collection_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts('~.K66ccywRHC+IKlT!', [], '\x0b')
    # assert var_0 ==


# Generated at 2022-06-24 22:54:38.294949
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(float_0)
    dict_0 = {}
    dict_1 = hurd_pfinet_network_1.populate(dict_0)


# Generated at 2022-06-24 22:55:28.216264
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_1 = '\x0b'
    list_1 = []
    str_2 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_1, list_1, str_2)
    var_1 = hurd_pfinet_network_1.module

# Generated at 2022-06-24 22:55:30.364375
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = -2743.0
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:55:36.350629
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bool_0 = bool(0)
    try:
        hurd_network_collector_0 = HurdNetworkCollector(bool_0)
    except Exception:
        pass
    float_0 = float(0)
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    hurd_network_collector_1 = HurdNetworkCollector()
    if isinstance(hurd_network_collector_1, HurdNetworkCollector):
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:55:42.278593
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = ''
    list_0 = []
    str_1 = ''
    hurd_pfinet_network_0 = HurdPfinetNetwork(None)
    var_0 = hurd_pfinet_network_0.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:55:43.535746
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()

# Generated at 2022-06-24 22:55:47.971406
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    print("prueba de inicio ")
    test_case_0()
    print("prueba de fin ")

if __name__ == '__main__' :
    test_HurdPfinetNetwork()

# Generated at 2022-06-24 22:55:49.873968
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = -2743.0
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:55:52.615823
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_case_0()


# Generated at 2022-06-24 22:55:55.629111
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    mod = AnsibleModule(
              argument_spec = dict(),
              supports_check_mode = False
          )
    x = HurdNetworkCollector(module=mod)


# Generated at 2022-06-24 22:56:00.445590
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
  # assert that the method populate of class HurdPfinetNetwork exists
  collector = HurdNetworkCollector()
  network = HurdPfinetNetwork(collector)
  network.populate()
  assert network.populate() is not None

# Generated at 2022-06-24 22:58:05.098845
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:58:08.246008
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
  try:
    HurdNetworkCollector()
  except Exception as e:
    assert(False)


# Generated at 2022-06-24 22:58:16.574976
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:58:18.781817
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    Unit test for method assign_network_facts of class HurdPfinetNetwork.
    '''
    test_case_0()


# Generated at 2022-06-24 22:58:26.144967
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Placeholder for test
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:58:30.251131
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.facts == {}
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-24 22:58:31.101397
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()



# Generated at 2022-06-24 22:58:35.510264
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '\x0b'
    list_0 = []
    str_1 = '~.K66ccywRHC+IKlT!'
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(hurd_network_collector_0, hurd_pfinet_network_0)
    var_0 = hurd_pfinet_network_1.assign_network_facts(str_0, list_0, str_1)


# Generated at 2022-06-24 22:58:46.855470
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # step 1
    hurd_network_collector_0 = HurdNetworkCollector()
    collected_facts_0 = {'fact_0': 'value_1', 'fact_1': 'value_2'}
    dict_0 = {}
    dict_0.update(collected_facts_0)
    hurd_pfinet_network_0 = HurdPfinetNetwork(hurd_network_collector_0, collected_facts_0)
    float_0 = 5.0
    hurd_pfinet_network_1 = HurdPfinetNetwork(float_0, collected_facts_0)
    list_0 = ['foo', 'bar']
    str_0 = '~.K66ccywRHC+IKlT!'

# Generated at 2022-06-24 22:58:54.051966
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    hurd_network_collector_0 = HurdNetworkCollector()
    float_0 = -2743.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_1 = HurdPfinetNetwork(module_0, hurd_network_collector_0, hurd_pfinet_network_0)

