

# Generated at 2022-06-24 22:50:31.560591
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:50:35.430404
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facter_network_0 = HurdNetworkCollector()
    facts = dict()
    facts['network'] = dict()
    result = facter_network_0.populate(facts)
    assert result is not None, 'The HurdNetworkCollector instance is null.'


# Generated at 2022-06-24 22:50:41.288397
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:50:46.811283
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    # AssertionError: AssertionError
    assert False


# Generated at 2022-06-24 22:50:53.537608
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/proc/net/dev'
    hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
    return


# Generated at 2022-06-24 22:50:56.717747
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    try:
        hurd_pfinet_network_0.populate()
    except:
        pass


# Generated at 2022-06-24 22:51:03.478085
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    assert not hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:51:11.116966
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts_dict_0 = dict()
    fsysopts_path_str_0 = str()
    socket_path_str_0 = str()
    HurdPfinetNetwork_0 = HurdPfinetNetwork(module=network_facts_dict_0)
    HurdPfinetNetwork_0.assign_network_facts(network_facts=network_facts_dict_0, fsysopts_path=fsysopts_path_str_0, socket_path=socket_path_str_0)
    HurdPfinetNetwork_0.populate()

    assert HurdPfinetNetwork_0.module is network_facts_dict_0



# Generated at 2022-06-24 22:51:16.341283
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts_0 = {}
    fsysopts_path_0 = '/bin/fsysopts'
    socket_path_0 = '/dev/null'
    network_facts_1 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0) # FIXME: test for failure
    assert network_facts_1 is not None


# Generated at 2022-06-24 22:51:24.373231
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    print('test_HurdPfinetNetwork_populate')

    hurd_pfinet_network_0 = HurdPfinetNetwork(1000.0)
    hurd_pfinet_network_0.module.exit_json = mock_exit_json
    hurd_pfinet_network_0.module.run_command = mock_run_command
    hurd_pfinet_network_0.get_bin_path = mock_get_bin_path
    hurd_pfinet_network_0.module.run_command.return_value = (0, 'foo', '')

    hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:51:31.991613
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # TODO: export test-stubs/GNU-Hurd/* to ansible/test/unit/module_utils/network/facts/
    pass


# Generated at 2022-06-24 22:51:36.282007
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hurd_network_collector_0 = HurdNetworkCollector()
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    hurd_pfinet_network_1 = HurdPfinetNetwork()
    # Fails because the fsysopts command is not present in the system.
    assert hurd_pfinet_network_0.populate() == {}
    # Fails because the socket directory is not present in the system.
    assert hurd_pfinet_network_0.populate() == {}

# Generated at 2022-06-24 22:51:40.670599
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ..network.linux import LinuxNetwork
    # FIXME: this should be done by mocking out fsysopts to return some output
    # for this test
    x = HurdPfinetNetwork(None, LinuxNetwork.fallback_interface_names())
    assert x.populate() == {}

# Generated at 2022-06-24 22:51:47.820735
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hurd_pfinet_network_0 = HurdPfinetNetwork()
    fsysopts_path = '/bin/fsysopts'
    socket_path = 'server/socket/interface'
    assertion_message = "AssertionError : the method assign_network_facts is not working properly"
    assert hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path) is None, assertion_message

# Generated at 2022-06-24 22:51:53.632766
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    ifname0 = 'eth0'
    ipv4_address0 = '192.168.1.3'
    ipv4_netmask0 = '255.255.255.0'
    ipv6_address0 = 'fe80::9a86:f7ff:fe48:d44f'
    ipv6_prefix0 = '64'
    ifname1 = 'eth1'
    ipv4_address1 = '192.168.2.3'
    ipv4_netmask1 = '255.255.255.0'
    ipv6_address1 = 'fe80::7a86:f7ff:fe48:d44f'
    ipv6_prefix1 = '64'
    ifname2 = 'eth2'

# Generated at 2022-06-24 22:51:54.982370
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert (test_case_0.__name__, None) == test_case_0()



# Generated at 2022-06-24 22:52:00.081171
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Unit test to test constructor of class HurdPfinetNetwork"""
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    # Can't run this unit test without a module since a module is required to
    # provide data for the constructor.
    hurd_pfinet_network_0 = HurdPfinetNetwork(module_0)



# Generated at 2022-06-24 22:52:02.571862
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), HurdNetworkCollector)


# Generated at 2022-06-24 22:52:03.176869
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass

# Generated at 2022-06-24 22:52:12.363861
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_class = HurdPfinetNetwork()

# Generated at 2022-06-24 22:52:27.248047
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Assign a few arguments.
    fsysopts_path = 'cUtFJf3'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    # Assign a value.
    fsysopts_path_0 = 'VZp[@EHwoY?tc/'
    int_1 = 77
    str_0 = 'k}`B`'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'm6=)k^~Z'
    int_2 = 817
    str_2 = ''

# Generated at 2022-06-24 22:52:29.940692
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'm=xCj)>'
    int_0 = 23
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:52:32.816464
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '4)4e>I9'
    bool_0 = True
    # Call the constructor of class HurdPfinetNetwork
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:52:42.836452
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    str_0 = 'hVp9{9[x+'
    int_0 = 2217
    str_1 = '|L*jqn >r'
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_pfinet_network_0, str_0, int_0)
    assert var_0 == str_1
    str_2 = '1L+DzA8`'
    int_1 = 2183
    str_3 = '\tPd!T%'

# Generated at 2022-06-24 22:52:49.284048
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    str_1 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_1)
    str_2 = '4)4e>I9'
    hurd_network_collector_1 = HurdNetworkCollector(str_2)


# Generated at 2022-06-24 22:52:53.990978
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    hurd_network_collector_0 = HurdNetworkCollector('G9#v)8W@')
    var_0 = hurd_pfinet_network_0.populate(hurd_network_collector_0)
    print(var_0)

# Generated at 2022-06-24 22:53:02.092417
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bool_0 = True
    int_0 = 0
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)
    assert hasattr(hurd_pfinet_network_0, 'platform')
    assert isinstance(hurd_pfinet_network_0.platform, str)
    assert hasattr(hurd_pfinet_network_0, 'module')
    assert isinstance(hurd_pfinet_network_0.module, int)
    assert hasattr(hurd_pfinet_network_0, '_socket_dir')
    assert isinstance(hurd_pfinet_network_0._socket_dir, str)


# Generated at 2022-06-24 22:53:10.119905
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)



# Generated at 2022-06-24 22:53:14.261642
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork()


# Generated at 2022-06-24 22:53:15.688007
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    bool_0 = False
    var_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:53:34.268781
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = 'A\t>P'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'Em*'
    int_0 = 486
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.populate(hurd_network_collector_0)
    print(var_0)


# Generated at 2022-06-24 22:53:36.677027
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:53:37.597935
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert True == True


# Generated at 2022-06-24 22:53:45.207363
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'hV7>g8e'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'M\rNQxNq?e'
    int_0 = 150
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)
    assert (var_0 == hurd_network_collector_0), 'The returned value should be equal to the value of argument passed to function'


# Generated at 2022-06-24 22:53:46.909673
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = ',;9bMF'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:53:48.159713
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:53:50.637298
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:53:52.692076
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector(None)
    # assert False
    

# Generated at 2022-06-24 22:53:56.846462
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '/t:Nb+^'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:54:03.401234
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)


# Generated at 2022-06-24 22:54:31.832211
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)

# Generated at 2022-06-24 22:54:35.287293
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'lh/V?9X'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)


# Generated at 2022-06-24 22:54:43.430554
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'EK>|s?tQ`#0&'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'OuP7|<$!\t1"i'
    int_0 = 55
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)


# Generated at 2022-06-24 22:54:50.539584
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'D&eQVu>'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'W6M+ePZ'
    int_0 = 706
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)


# Generated at 2022-06-24 22:54:56.457155
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'Y;MLf~'
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:55:04.902200
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
  str_0 = '4)4e>I9'
  hurd_network_collector_0 = HurdNetworkCollector(str_0)
  str_1 = 'v%|Q!m^\tw[p'
  int_0 = 817
  bool_0 = True
  hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
  # Test Exception condition: fsysopts_path must exist.
  try:
    hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)
  except:
    pass
  # Test Exception condition: fsysopts_path must be executable.
  str_4 = os.path.abspath(__file__)

# Generated at 2022-06-24 22:55:08.920488
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:55:17.327585
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '4)4e>I9'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    hurd_pfinet_network_0.setup()
    str_1 = 'v%|Q!m^\tw[p'
    str_2 = '%cE\x1c6'
    int_0 = 817
    str_3 = '~y\npc'
    hurd_pfinet_network_0.assign_network_facts(str_1, str_2, int_0, str_3)


# Generated at 2022-06-24 22:55:23.144189
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Stub for test_HurdNetworkCollector
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:55:30.457044
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_1 = 'v%|Q!m^\tw[p'
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    str_0 = '4)4e>I9'
    float_0 = 0.02112413652920544
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    float_1 = 0.9227261564905062
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, float_0)
    assert var_0['interfaces'] == [], 'interfaces == list()'

# Generated at 2022-06-24 22:56:32.212913
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    bool_0 = False
    str_0 = 'I#t2%Kt'
    str_1 = 'XKqqe|1c'
    str_2 = ':$/]%;K'
    str_3 = 'A5OydVy'
    str_4 = '.KjM6c'
    str_5 = '16rK'
    str_6 = 'H'
    str_7 = '!'
    str_8 = '3p,*J_x'
    str_9 = '2?'
    str_10 = '$j<a'
    str_11 = '-M{'
    str_12 = 'Y'
    str_13 = '\rp%IV'
    str_14 = 'rj;$'
    str_15 = 'c%'
    str

# Generated at 2022-06-24 22:56:38.779349
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)


# Generated at 2022-06-24 22:56:40.535523
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = '3^BJ}G'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:56:43.813660
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'XtA<^t1'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)


# Generated at 2022-06-24 22:56:50.488603
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_0 = '<>8Fpi$'
    hurd_pfinet_network_0 = HurdPfinetNetwork(str_0)
    str_1 = 'Gw\nC.~}'
    hurd_network_collector_0 = HurdNetworkCollector(str_1)
    str_2 = '4)4e>I9'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_2, int_0)


# Generated at 2022-06-24 22:56:56.937353
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = '4)4e>I9'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)

# Generated at 2022-06-24 22:57:00.348802
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'N6r>Uw%'
    int_0 = 1318
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)


# Generated at 2022-06-24 22:57:07.721305
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'YF983qKx'
    int_0 = 758
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    str_1 = '>'
    hurd_network_collector_0 = HurdNetworkCollector(str_1)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_0, int_0)


# Generated at 2022-06-24 22:57:13.301356
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'S~h|5B5m#0'
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    assert (hurd_pfinet_network_0.module.module_name == str_0)


# Generated at 2022-06-24 22:57:14.209975
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_case_0()


# Generated at 2022-06-24 22:59:21.778578
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = 'd<2:^qCG1'
    hurd_network_collector_0 = HurdNetworkCollector(str_0)
    str_1 = 'm@\r\\$P}p'
    int_0 = -1732872905
    bool_0 = False
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(hurd_network_collector_0, str_1, int_0)


# Generated at 2022-06-24 22:59:29.745754
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    str_0 = '~I=w'
    int_0 = 934820
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    str_1 = '6U'
    int_1 = 900
    str_2 = '2i!1D'
    bool_1 = False
    hurd_pfinet_network_0.assign_network_facts(str_0, int_0, str_1, int_1, str_2, bool_1)


# Generated at 2022-06-24 22:59:40.569353
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = ('hurd','pfinet')
    module = ('gnu', 'pfinet')
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)
    module = ('gnu', 'pfinet')
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)
    str_0 = '#y*O#H1'
    module = ('gnu', 'pfinet')
    hurd_pfinet_network_0 = HurdPfinetNetwork(module)
    network_facts = hurd_pfinet_network_0.populate(str_0)
    network_facts = hurd_pfinet_network_0.populate(str_0)
    network_facts = hurd_pfinet_network_0.populate(str_0)
    network_facts

# Generated at 2022-06-24 22:59:46.773749
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # 1. Let
    str_0 = 'l'
    bool_0 = True
    # 2. Arrange
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    # 3. Act
    hurd_pfinet_network_0.assign_network_facts(bool_0, str_0, bool_0)
    # 4. Assert
    # verify expected result
    test_case_0()
    return 0

# Generated at 2022-06-24 22:59:51.121869
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    str_1 = 'v%|Q!m^\tw[p'
    int_0 = 817
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
    var_0 = hurd_pfinet_network_0.populate(int_0, str_1)


# Generated at 2022-06-24 22:59:52.371771
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:59:55.386898
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a HurdPfinetNetwork object for testing.
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)

    # test the method populate of class HurdPfinetNetwork
    assert True == True


# Generated at 2022-06-24 23:00:05.071908
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    str_0 = 'dvD(h;>'
    str_1 = '='
    # Test condition where paths is not a list.
    # Variable used in the assert statement
    assert_val = True
    try:
        hurd_network_collector_0 = HurdNetworkCollector(str_0, str_1)
    except Exception:
        assert_val = False
    finally:
        assert assert_val

    # Test condition where paths is a list.
    # Variable used in the assert statement
    assert_val = True
    try:
        hurd_network_collector_0 = HurdNetworkCollector(str_0)
    except Exception:
        assert_val = False
    finally:
        assert assert_val


# Generated at 2022-06-24 23:00:10.482346
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    arg_1 = '{'
    hurd_network_collector_0 = HurdNetworkCollector(arg_1)
    assert(hurd_network_collector_0.module.__class__.__name__ == 'AnsibleModule')


# Generated at 2022-06-24 23:00:14.668917
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    str_0 = 'v%|Q!m^\tw[p'
    bool_0 = True
    hurd_pfinet_network_0 = HurdPfinetNetwork(bool_0)
