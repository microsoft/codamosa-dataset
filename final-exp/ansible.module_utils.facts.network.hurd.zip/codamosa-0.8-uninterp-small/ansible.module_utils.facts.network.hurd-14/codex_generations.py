

# Generated at 2022-06-24 22:50:40.474223
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-24 22:50:49.863389
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts_0 = {}
    fsysopts_path_0 = './ansible_collections/ansible/netcommon/tests/units/module_utils/facts/network/hurd/fsysopts'
    socket_path_0 = './ansible_collections/ansible/netcommon/tests/units/module_utils/facts/network/hurd/socket'
    network_facts_1 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:50:51.873925
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:50:59.592003
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    collected_facts_0 = {}
    hurd_pfinet_network_0.populate(collected_facts_0)
    collected_facts_0 = {
        'interfaces': ['']
    }
    hurd_pfinet_network_0.populate(collected_facts_0)
    collected_facts_0 = {
        'interfaces': ['asdfasd']
    }
    hurd_pfinet_network_0.populate(collected_facts_0)
    collected_facts_0 = {
        'interfaces': ['']
    }
    hurd_pfinet_network_0.populate(collected_facts_0)
    collected_facts

# Generated at 2022-06-24 22:51:01.332136
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:51:04.337314
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()


# Generated at 2022-06-24 22:51:07.596752
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    bool_0 = False
    hurd_pfinet_network_0.populate(bool_0)

test_case_0()
test_HurdPfinetNetwork_populate()

# Generated at 2022-06-24 22:51:14.020751
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_collector_0 = HurdNetworkCollector()
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    network_collector_0._module = module_0
    collected_facts = dict()
    # Call method
    network_collector_0.populate(collected_facts)


# Generated at 2022-06-24 22:51:14.499016
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass


# Generated at 2022-06-24 22:51:23.937005
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = dict()
    fsysopts_path = "/usr/bin/fsysopts"
    socket_path = "/servers/socket/"
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    return_value = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert return_value is not None

if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()

# Generated at 2022-06-24 22:51:32.685556
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    # test if it returns something
    assert(hurd_pfinet_network_0.populate() is not None)

# Generated at 2022-06-24 22:51:34.085978
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:51:36.082545
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)

# Generated at 2022-06-24 22:51:39.419016
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    return_0 = hurd_network_collector_0.collect()

# Generated at 2022-06-24 22:51:47.919911
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    str_0 = 'asd'
    str_1 = '/as'
    dict_0 = {}
    dict_3 = {}
    dict_3['ipv4'] = dict_0
    dict_3['ipv6'] = [{}, {}]
    dict_3['device'] = str_1
    dict_3['active'] = False
    dict_3['ipv4'] = dict_3['ipv4']
    dict_3['ipv6'] = dict_3['ipv6']
    dict_2 = {}
    dict_2['interfaces'] = [str_0]
    dict_2[str_0] = dict_3
    dict_1 = {}
   

# Generated at 2022-06-24 22:51:50.150250
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:51:58.365154
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    var_0 = isinstance(hurd_network_collector_0, HurdNetworkCollector)
    assert var_0 == True
    var_1 = hurd_network_collector_0._platform
    assert var_1 == 'GNU'
    var_2 = hurd_network_collector_0._fact_class
    assert var_2 == HurdPfinetNetwork

# Generated at 2022-06-24 22:52:03.124102
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    assert isinstance(hurd_pfinet_network_0, HurdPfinetNetwork)


# Generated at 2022-06-24 22:52:04.502218
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    var_1 = HurdNetworkCollector()


# Generated at 2022-06-24 22:52:08.926797
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    var_0 = isinstance(hurd_network_collector_0, HurdNetworkCollector)
    if var_0:
        assert True
    else:
        assert False


# Generated at 2022-06-24 22:52:24.208462
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    assert (hurd_pfinet_network_0.module == 1000)
    assert (hurd_pfinet_network_0.platform == 'GNU')
    assert (hurd_pfinet_network_0._socket_dir == '/servers/socket/')


# Generated at 2022-06-24 22:52:34.635741
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    modules_mock = {'run_command': {'return_value': (0, '', '')}, 'get_bin_path': {'return_value': ''}}

    # creating a class instance for the case data
    hurd_pfinet_network_obj = HurdPfinetNetwork(modules_mock)

    # assigning verify_files to the mock object because it is not yet tested
    hurd_pfinet_network_obj.verify_files = unittest.mock.MagicMock()

    # test case 1 :
    # check if _populate_facts is called
    # assigning is data to a local var
    result = hurd_pfinet_network_obj.populate()

    # checking if the result is empty
    assert not result

    # test case 2:

# Generated at 2022-06-24 22:52:44.467329
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()
    #  {'interfaces': ['eth0'], 'eth0': {'active': True, 'device': 'eth0', 'ipv4': {'address': '192.168.0.11', 'netmask': '255.255.255.0'}, 'ipv6': [{'address': 'fe80::5454:caff:fe09:3c70', 'prefix': '64'}]}}
    print(var_0)



# Generated at 2022-06-24 22:52:50.152077
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:52:58.260446
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts_0 = {}
    fsysopts_path_0 = '/usr/bin/fsysopts'
    socket_path_0 = '/d/socket'
    var_0 = hurd_pfinet_network_0.assign_network_facts(
        network_facts_0, fsysopts_path_0, socket_path_0
    )



# Generated at 2022-06-24 22:53:02.622588
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Test for existence of required keys in return value.
    # Test for existance of optional keys in return value.
    # Test for existence of required keys in return value.
    # Test for existance of optional keys in return value.
    pass

# Generated at 2022-06-24 22:53:08.432585
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    # Call test case 0, this is expected to return dictionary with all empty interfaces
    test_case_0()
    # Call test case 1, this is expected to return an empty dictionary
    test_case_1()


# Generated at 2022-06-24 22:53:12.588981
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class_0 = HurdPfinetNetwork
    hurd_network_collector_0 = HurdNetworkCollector(fact_class_0)
    var_0 = hurd_network_collector_0._platform

if __name__ == '__main__':
    test_case_0()
    test_HurdNetworkCollector()

# Generated at 2022-06-24 22:53:14.957041
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:53:17.305345
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:53:39.414373
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector = HurdNetworkCollector(float_0)
    assert hurd_network_collector is not None


# Generated at 2022-06-24 22:53:43.055035
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Populate facts
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_3 = test_case_0()
    assert var_3 == {}, 'Expected return value is {}'.format(var_3)

# Generated at 2022-06-24 22:53:52.168723
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_1 = 1000.0
    hurd_pfinet_network_1 = HurdPfinetNetwork(float_1)
    network_facts_1 = {'interfaces': []}
    fsysopts_path_1 = './bin/fsysopts'
    socket_path_1 = './servers/socket/inet'
    return_value_1 = '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=2001:0db8:0000:0000:0000:ff00:0042:8329/64'

# Generated at 2022-06-24 22:53:56.520401
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    hurd_network_collector_0.collect()

if __name__ == "__main__":
    import sys
    sys.exit(0)

# Generated at 2022-06-24 22:54:00.803999
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:54:06.943751
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    current_if_0 = 'br0'
    network_facts_0 = {}
    fsysopts_path_0 = 'fsysopts'
    socket_path_0 = '/servers/socket/inet'
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:54:12.425471
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collected_facts = None
    hurd_network_collector_0 = HurdNetworkCollector(collected_facts)
    assert isinstance(hurd_network_collector_0, HurdNetworkCollector)

# Generated at 2022-06-24 22:54:15.322571
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:54:16.019941
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert True

# Generated at 2022-06-24 22:54:20.127591
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_1 = 1000.0
    hurd_pfinet_network_1 = HurdPfinetNetwork(float_1)
    assert not hurd_pfinet_network_1.populate()


# Generated at 2022-06-24 22:55:00.708402
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:55:02.548057
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:55:05.156971
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:55:09.115956
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1.2
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)


# Generated at 2022-06-24 22:55:16.274931
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    arg_0 = {
        'default_gateway': '',
        'default_interface': ''
    }
    arg_1 = 'fsysopts'
    arg_2 = '/servers/socket/inet'
    hurd_pfinet_network_0.assign_network_facts(arg_0, arg_1, arg_2)


# Generated at 2022-06-24 22:55:17.806341
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)

# Generated at 2022-06-24 22:55:19.290820
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)

# Generated at 2022-06-24 22:55:20.481615
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector_0 = HurdNetworkCollector()

# Generated at 2022-06-24 22:55:24.444480
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    os.environ['PATH'] = '/usr/bin:/bin:/usr/sbin:/sbin'
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    assert isinstance(hurd_pfinet_network_0.populate(), dict)


# Generated at 2022-06-24 22:55:25.268369
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_case_0()


# Generated at 2022-06-24 22:57:19.614747
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    str_1 = 'dGhlIGNoYW5nZSBpcyBhbGwgZm9yIHRoZSBiZXR0ZXIuLi4gdG8gYWZ0ZXJhbGw='
    list_0 = [str_1]
    str_2 = 'dGhlIGNoYW5nZSBpcyBhbGwgZm9yIHRoZSBiZXR0ZXIuLi4gdG8gYWZ0ZXJhbGw='
    list_1 = [str_2]

# Generated at 2022-06-24 22:57:23.507813
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Create an instance of HurdNetworkCollector for testing
    float_0 = 1000.0
    hurd_network_collector_0 = HurdNetworkCollector(float_0)
    # Update the attribute fact_class of class HurdNetworkCollector
    hurd_network_collector_0.fact_class = HurdPfinetNetwork


# Generated at 2022-06-24 22:57:28.027392
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    network_facts_0 = {}
    fsysopts_path_0 = module_0.get_bin_path('fsysopts')
    socket_path_0 = '/servers/socket/inet'
    assert hurd_pfinet_network_0.assign_network_facts(network_facts_0, fsysopts_path_0, socket_path_0)


# Generated at 2022-06-24 22:57:32.642192
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()


# Generated at 2022-06-24 22:57:41.527064
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    string_0 = 'fsysopts'
    string_1 = '/servers/socket/inet'
    hurd_pfinet_network_0.assign_network_facts(None, string_0, string_1)

if __name__ == '__main__':
    test_case_0()
    test_HurdPfinetNetwork_assign_network_facts()

# Generated at 2022-06-24 22:57:45.435225
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()

# Generated at 2022-06-24 22:57:54.293059
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModuleMock()
    module_ansible_mock_0 = {'run_command': run_command_mock}
    module_mock_0 = {'AnsibleModuleMock': module_ansible_mock_0}
    module.params = module_mock_0
    socket_dir = '/servers/socket/'
    ansible_module_mock_0 = {'get_bin_path': get_bin_path_mock}
    ansible_module_mock_1 = {'run_command': run_command_mock_1}
    module_ansible_mock_1 = {'AnsibleModuleMock': ansible_module_mock_0, 'run_command': run_command_mock_1}

# Generated at 2022-06-24 22:58:02.390637
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = "/bin/fsysopts"
    socket_path = "/servers/socket"
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-24 22:58:05.250420
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)



# Generated at 2022-06-24 22:58:09.631288
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    float_0 = 1000.0
    hurd_pfinet_network_0 = HurdPfinetNetwork(float_0)
    var_0 = hurd_pfinet_network_0.populate()
