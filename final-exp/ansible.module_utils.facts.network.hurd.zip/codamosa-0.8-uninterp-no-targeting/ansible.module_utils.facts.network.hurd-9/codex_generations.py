

# Generated at 2022-06-20 18:09:39.215310
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''
    unit test for class HurdPfinetNetwork
    '''
    hn = HurdPfinetNetwork({})
    assert isinstance(hn, HurdPfinetNetwork)


# Generated at 2022-06-20 18:09:48.432197
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    import pytest
    import os
    import sys

    class AnsibleModuleMock:
        def __init__(self, params=None):
            if params:
                self.params = params
            else:
                self.params = {
                    'name': 'eth0',
                    'state': 'present',
                    'type': 'eth',
                    'hotplug': False,
                    'mtu': 1500,
                    'macaddress': '00:11:22:33:44:55',
                    'address': '192.168.99.1',
                    'netmask': '255.255.255.0',
                }

            self.run_command_calls = []

        def get_bin_path(self, command):
            return '/path/to/bin/%s' % command


# Generated at 2022-06-20 18:10:00.278435
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.generic import NetworkModule
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    module = NetworkModule()
    module.params = {}
    module.run_command = lambda x: (0, to_bytes(x[2]), '')
    basic._ANSIBLE_ARGS = to_bytes('')

    network_facts = {}
    network = HurdPfinetNetwork(module)
    network.assign_network_facts(network_facts, '/fake/path', '/fake/path')

# Generated at 2022-06-20 18:10:01.324621
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork(None)

# Generated at 2022-06-20 18:10:02.682008
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector is not None


# Generated at 2022-06-20 18:10:06.395187
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == "GNU" and h._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:10:08.755851
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    nm = HurdPfinetNetwork({
        'module': None,
    })
    assert nm.platform == 'GNU'
    assert nm.interfaces == []

# Generated at 2022-06-20 18:10:15.027186
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class FakeModule:
        class FakeFailJson:
            def __init__(self, module, msg):
                self.module = module
                self.msg = msg
                self.called = False

            def __call__(self, *args, **kwargs):
                self.called = True
                self.module.fail_json(msg=self.msg)

        def __init__(self, *args, **kwargs):
            self.params = {}
            self.fail_json = self.FakeFailJson(self, 'test HurdPfinetNetwork failed')
            self.called = False

        def run_command(self, args, check_rc=True):
            self.called = True

# Generated at 2022-06-20 18:10:26.351412
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Create a HurdPfinetNetwork instance
    net = HurdPfinetNetwork(None)

    # Create a network datastructure
    network_facts = {}
    network_facts['interfaces'] = []

    # Create a test output for fsysopts
    out = '''--interface=/dev/eth0
--address=10.66.0.0
--netmask=255.255.0.0
--interface=/dev/eth1
--address=10.77.0.0
--netmask=255.255.0.0
--address6=fe80::2e0:4cff:fe62:a710/64
--address6=fe80::2e0:4cff:fe62:a711/64'''

    # Assign the network facts

# Generated at 2022-06-20 18:10:31.042870
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    obj = HurdPfinetNetwork(module=module)
    assert obj._platform == 'GNU'

# Generated at 2022-06-20 18:10:47.164243
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)

# Generated at 2022-06-20 18:10:57.835862
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    """
    network_facts = {}
    network = HurdPfinetNetwork(None)
    fsysopts_path = "echo"
    socket_path = "/servers/socket/inet"
    fsysopts_output = """--interface=/dev/eth0
--address=192.168.1.12
--netmask=255.255.255.0
--address6=/fe80::94a2:26ff:feca:8fce/64
--address6=/2620:10a:8001:1::14c1:1d40/64"""
    network.module.run_command = lambda args, **kwargs: (0, fsysopts_output, "")
    result = network.assign_network_

# Generated at 2022-06-20 18:11:07.934152
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    This test simulate the output of `fsysopts -L /servers/socket/inet`
    and check if the method populate of class HurdPfinetNetwork
    build the network_facts datastructure correctly.
    """
    from ansible.module_utils._text import to_text

    class ModuleStub:
        """
        This class stub the module object
        """
        def __init__(self):
            self._stdout = to_text('''--interface=/dev/eth0 --netmask=255.255.255.0 --address=192.168.3.1 --address6=fe80::a00:27ff:fe1d:16c8/64 --address6=2001:470:28:2b8::2/64''')
            self._rc = 0
            self._stderr = to

# Generated at 2022-06-20 18:11:17.313799
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    args = {'module': MockModule(**{'run_command.return_value':
                                    ('0', '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0 --address6=::1/128', None)})}
    network = HurdPfinetNetwork(**args)
    network.populate()
    assert network.out_interface == 'eth0'
    assert network.out_address == '127.0.0.1'
    assert network.out_netmask == '255.0.0.0'
    assert network.out_gateway == None



# Generated at 2022-06-20 18:11:29.116489
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.basic import AnsibleModule
    import os
    from tempfile import NamedTemporaryFile

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=False,
    )

    temp_file = NamedTemporaryFile(delete=False)
    temp_file.close()
    temp_path = temp_file.name

    test_input = get_file_content('tests/unit/module_utils/facts/network/fixtures/fsysopt_in')
    test

# Generated at 2022-06-20 18:11:33.731136
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert type(obj) == HurdNetworkCollector
    assert obj._fact_class == HurdPfinetNetwork
    assert obj._platform == 'GNU'



# Generated at 2022-06-20 18:11:42.041842
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    test_data = {
        '_socket_dir': './tests/unit/module_utils/facts/network/hurd_mock/servers/socket/',
        'module': {
            'run_command': lambda x, check_rc=False, environ_update=None: (0, '', ''),
            'get_bin_path': lambda x: './tests/unit/module_utils/facts/network/hurd_mock/fsysopts',
        },
    }
    test_obj = HurdPfinetNetwork(**test_data)
    test_obj.populate()
    assert isinstance(test_obj.facts, dict)
    assert test_obj.facts['default_ipv4']['address'] == '192.168.2.2'

# Generated at 2022-06-20 18:11:44.854325
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:53.014366
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    dM = DummyModule()
    dM.run_command = DummyRunCommand()
    nC = HurdPfinetNetwork(dM)
    # should create nC._socket_dir
    assert nC._socket_dir == '/servers/socket/'
    # should create nC._platform
    assert nC._platform == 'GNU'



# Generated at 2022-06-20 18:11:59.031441
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import basic


# Generated at 2022-06-20 18:12:19.633764
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    instance = HurdPfinetNetwork(module)

    with patch('ansible.module_utils.facts.network.base.NetworkCollector.get_fact_class',
               return_value=HurdPfinetNetwork):

        with patch("ansible.module_utils.facts.network.hurd.HurdPfinetNetwork.assign_network_facts") as assign_network_facts:

            with patch("ansible.module_utils.facts.network.hurd.HurdPfinetNetwork.module") as module:

                with patch("ansible.module_utils.facts.network.hurd.HurdPfinetNetwork.module.run_command") as run_command:
                    run_command.return_value = (1, '', '')
                    assert not instance._populate

# Generated at 2022-06-20 18:12:21.695738
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()


# Generated at 2022-06-20 18:12:31.869758
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """ Unit test for method populate of class HurdPfinetNetwork
    """
    from ansible.utils.module_docs import get_docstring
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    # Create class instance
    modulestub = AnsibleModuleStub()
    modulestub.params = {}
    hurd_network = HurdPfinetNetwork(module=modulestub)

    # Prepare test data
    docstring = get_docstring(hurd_network.__class__, verbose=False, metadata=True)
    options = docstring['options']
    test_data = dict()
    test_data['inputs'] = dict()

# Generated at 2022-06-20 18:12:44.549904
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_network = HurdPfinetNetwork(NetworkCollector())

    # Test with a correct command output
    ipv4_address = '10.0.0.1'
    ipv4_netmask = '255.255.255.0'
    ipv6_address = '2001:db8:dead:beef::1'
    ipv6_prefix = '64'
    out = '''interface=/dev/eth0
    address=%s
    netmask=%s
    address6=%s/%s
    ''' % (ipv4_address, ipv4_netmask, ipv6_address, ipv6_prefix)
    network_facts = test_network.assign_network_facts({}, 'fsysopts', 'inet')

# Generated at 2022-06-20 18:12:46.948537
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_obj = HurdPfinetNetwork()
    assert network_obj.platform == 'GNU'
    assert network_obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:12:59.280113
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    def assign_network_facts(self, network_facts, fsysopts_path, socket_path):
        return {'comment': 'GNU Hurd'}

    from ansible.module_utils.facts import injector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    f = injector.get_fake_module()
    h = HurdPfinetNetwork(f)
    f.run_command = lambda x: (0, '--address=1.2.3.4', '')
    h.assign_network_facts = assign_network_facts
    network_facts = h.populate()
    assert network_facts == {'comment': 'GNU Hurd'}



# Generated at 2022-06-20 18:13:02.257652
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()
    net = HurdPfinetNetwork(module)
    net.populate()
    # FIXME: check the results



# Generated at 2022-06-20 18:13:09.039460
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # test the empty constructor
    new_HurdPfinetNetwork = HurdPfinetNetwork()

    # test the constructor with a module fixture
    from ansible.module_utils.facts.network.linux.version import NetworkModuleFactsVersion
    from ansible.module_utils.facts.network.linux.version import OperatingSystemRelease
    from ansible.module_utils.facts.network.linux.version import OVirtNodeOsInfo
    from ansible.module_utils.facts.network.linux.version import PlatformDistributionLinux
    from ansible.module_utils.facts.network.linux.version import PlatformDistributionNameLinux
    from ansible.module_utils.facts.network.linux.version import PlatformDistributionVersionLinux
    from ansible.module_utils.facts.network.linux.version import AnsibleModuleVersion

# Generated at 2022-06-20 18:13:13.778403
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    from ansible_collections.community.general.tests.unit.compat import unittest

    class AnsibleModule():
        def __init__(self, args=None, supports_check_mode=False):
            self.args = args

        def run_command(self, args, check_rc=False):
            if args[1] != '-L':
                raise AssertionError(
                    'expected fsysopts -L but got %s' % (' '.join(args),)
                )

# Generated at 2022-06-20 18:13:20.251249
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)

    fsysopts_path = network.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        assert network.populate() == {}

    socket_path = None

    for l in ('inet', 'inet6'):
        link = os.path.join(network._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break

    if socket_path is None:
        assert network.populate() == {}


# Generated at 2022-06-20 18:13:42.619014
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert isinstance(HurdPfinetNetwork({}, {}), Network)


# Generated at 2022-06-20 18:13:44.345334
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork._platform == 'GNU'

# Generated at 2022-06-20 18:13:47.675494
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:13:58.123550
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModuleMock('HurdPfinetNetwork')
    m._ansible_version = '2.10.0'
    m._ansible_module_name = 'test'
    m.params = {'gather_network_resources': 'any'}
    s = HurdPfinetNetwork(m)
    m.get_bin_path = lambda x: x
    m.run_command = lambda x: None
    m.run_command.__dict__.update({
        'rc': 0,
        'out': '--interface=eth0 --address=127.1.2.3 --netmask=255.255.255.0 --address6=::/0',
        'err': '',
    })
    result = s.populate()
    assert('interfaces' in result)

# Generated at 2022-06-20 18:14:01.469373
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = MockModule()
    network = HurdPfinetNetwork(module)
    assert network
    assert network.module == module


# Generated at 2022-06-20 18:14:11.139107
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a mock module to be used for testing
    from ansible.module_utils.facts import module_facts

    class Module:
        def __init__(self):
            self.run_command = lambda x, check_rc=True: (0, '', '')

        def get_bin_path(self, executable, required=False):
            if executable == 'fsysopts':
                return executable

        def fail_json(self, *args, **kwargs):
            pass

    module = Module()
    network_facts = HurdPfinetNetwork(module=module)

    # Check that HurdPfinetNetwork._socket_dir is equal to
    # '/servers/socket/'
    assert network_facts._socket_dir == '/servers/socket/'

    # Create a directory with name /servers/socket/ that

# Generated at 2022-06-20 18:14:13.915820
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    m = HurdNetworkCollector.load_collector(None, None)
    assert HurdNetworkCollector == m.__class__


# Generated at 2022-06-20 18:14:19.319514
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_mock = object()
    HurdPfinetNetwork(module_mock)
    x = HurdPfinetNetwork(module_mock)
    assert x.platform == 'GNU'
    assert x._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:14:25.950716
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    obj = HurdPfinetNetwork()
    obj.module = module
    fsysopts_path = obj.module.get_bin_path('fsysopts')
    network_facts = {}
    socket_path = '/servers/socket/inet'
    out = """--interface=/dev/eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=::1/128
--address6=fe80::1/128"""
    ret = (0, out, None)

    # patching module run_command

# Generated at 2022-06-20 18:14:28.601766
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector()._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:15:13.827007
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModuleMock()
    fact_class = HurdPfinetNetwork(module)
    assert fact_class.platform == 'GNU'


# Generated at 2022-06-20 18:15:17.715679
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''
    Verify that the constructor of HurdNetworkCollector works
    '''
    instance = HurdNetworkCollector()
    assert isinstance(instance, NetworkCollector)
    assert hasattr(instance, '_platform')
    assert hasattr(instance, '_fact_class')
    assert instance._platform == 'GNU'
    assert instance._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:15:18.104962
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass

# Generated at 2022-06-20 18:15:28.152759
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import tempfile
    import textwrap

    module = FakeAnsibleModule()
    facts = dict()
    facts['interface'] = 'eth0'
    facts['address'] = '192.168.1.2'
    facts['netmask'] = '255.255.255.0'
    facts['address6'] = 'dead::beaf/64'

    network_facts = dict()
    network_facts['interfaces'] = []

    fd, path = tempfile.mkstemp()

    # Create a fake fsysopts output

# Generated at 2022-06-20 18:15:35.717236
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = Mock(run_command=Mock(return_value=(0, '--interface=/dev/eth0 --address=10.1.1.17 --netmask=255.255.255.0', '')))
    HurdPfinetNetwork(module).populate()
    module.run_command.assert_called_with(['fsysopts', '-L', '/servers/socket/inet'])


# Generated at 2022-06-20 18:15:49.225627
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes

    m = collector.FactsCollector()
    m.get_bin_path = lambda x: '/bin/fsysopts'
    m.run_command = lambda x: (0, to_bytes('''
--interface=/dev/eth0
--address=10.0.0.1
--netmask=255.255.255.0
--address6=fe80::3bbd:f865:cefc:6f74/64
'''), None)

    f = HurdPfinetNetwork(m)
    f.populate()

# Generated at 2022-06-20 18:15:51.065958
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:15:56.102156
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork('testmodule', 'testmodule.run_command').platform == 'GNU'
    assert HurdPfinetNetwork('testmodule', 'testmodule.run_command')._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:15:58.078721
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc.platform == 'GNU'
    assert nc.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:16:02.010805
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    a = HurdNetworkCollector()
    assert a.platform == 'GNU'
    assert a.fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:17:57.633833
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Setup test data
    fsysopts_path = '/servers/socket/inet'
    socket_path = '/servers/socket/inet'

    # Setup test module
    from ansible.module_utils.facts import ansible_collector
    tmpfile = ansible_collector.get_platform_directory() + '/' + 'HurdPfinetNetwork.py'

# Generated at 2022-06-20 18:18:10.090725
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.hurd.pfinet.pfinet_network_facts import HurdPfinetNetwork
    from ansible.module_utils.six.moves import builtins

    module = type('AnsibleModule', (object, ), {
        'run_command': lambda cmd: (0, '', ''),
        'get_bin_path': lambda cmd: cmd,
        '_socket_dir': '/servers/socket/',
    })()

    class TestAddress(object):
        def __init__(self, address):
            self.address = address

    class TestNetmask(object):
        def __init__(self, netmask):
            self.netmask = netmask


# Generated at 2022-06-20 18:18:13.130405
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:18:23.048936
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys
    import tempfile

    if sys.platform != 'gnu0':
        return

    from ansible.module_utils.facts.network.collectors import HurdPfinetNetwork

    try:
        with tempfile.NamedTemporaryFile(delete=False) as inet:
            inet.write('a\n')
            inet.flush()
        os.symlink(inet.name, '/servers/socket/inet')
    except:
        pass

    try:
        with tempfile.NamedTemporaryFile(delete=False) as inet6:
            inet6.write('a\n')
            inet6.flush()
        os.symlink(inet6.name, '/servers/socket/inet6')
    except:
        pass


# Generated at 2022-06-20 18:18:32.316547
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.generic_bsd import BsdIfconfigNetwork
    from ansible.module_utils.facts.network.generic_bsd import BsdLanNetwork
    from ansible.module_utils.facts.network.generic_bsd import BsdNetworkCollector

    pfinet_network = HurdPfinetNetwork()
    network = Network()
    bsd_network_collector = BsdNetworkCollector()
    bsd_ifconfig_network = BsdIfconfigNetwork()
    bsd_lan_network = BsdLanNetwork()

    ifconfig_path = bsd_network_collector.module.get_bin

# Generated at 2022-06-20 18:18:43.065522
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.interfaces.hurd import HurdInterface, HurdPfinetNetwork
    from ansible.module_utils.facts.network.interfaces.hurd import HurdPfinetNetwork as HurdPfinetNetworkUtils
    from ansible.module_utils.facts.network.interfaces.hurd import HurdPfinetNetwork as HurdPfinetNetworkUtils1
    from ansible.module_utils.facts.network.interfaces.hurd import HurdPfinetNetwork as HurdPfinetNetworkUtils2
    x = HurdPfinetNetwork(HurdInterface)
    x = HurdPfinetNetworkUtils()
    x = HurdPfinetNetworkUtils1()
    x = HurdPfinetNetworkUtils2()

# Generated at 2022-06-20 18:18:44.400933
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:18:54.819678
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Unit test of method populate of class HurdPfinetNetwork
    """
    class MockModule():
        def __init__(self):
            self.params = {'configure_default_route': True}
            self.run_command = run_command
        def get_bin_path(self, command):
            if command == 'fsysopts':
                return '/usr/bin/fsysopts'
            return None
        def fail_json(self, *args, **kwargs):
            raise Exception(kwargs['msg'])

    class MockCollector(HurdPfinetNetwork):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 18:18:59.240603
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd_pfinet import HurdPfinetNetwork

    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:19:11.379284
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command = MagicMock(return_value=(0,
                                                 '--interface=/dev/eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe2c:bf1e/64 --mtu=1500',
                                                 ''))

    o = HurdPfinetNetwork(module)
    o.populate()
    assert module.exit_json.called