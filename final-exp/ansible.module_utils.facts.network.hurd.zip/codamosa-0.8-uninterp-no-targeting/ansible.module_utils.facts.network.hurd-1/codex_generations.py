

# Generated at 2022-06-20 18:09:47.769662
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )

    ansible_module.run_command = MagicMock(return_value=(0, '', ''))
    ansible_module.get_bin_path = MagicMock(return_value='/usr/bin/fsysopts')

    network = HurdPfinetNetwork(ansible_module)
    result = network.populate()

    assert result['interfaces'] == ['lo', 'eth0']
    assert result['eth0']['active'] == True
    assert result['eth0']['ipv4']['address'] == '192.168.1.1'
    assert result['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:09:50.337166
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector', 'The facts class does not inherit from HurdNetworkCollector'

# Generated at 2022-06-20 18:10:02.270278
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = MockModule()
    f = HurdPfinetNetwork(m)

    m.get_bin_path.return_value = None
    assert f.populate() == {}

    m.get_bin_path.return_value = 'fsysopts'
    assert f.populate() == {}

    link = os.path.join(f._socket_dir, 'none')
    m.run_command.return_value = 0, '', ''
    m.os.path.exists.side_effect = lambda x: False if x == link else True

# Generated at 2022-06-20 18:10:14.692787
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    # Mock fsysopts command
    fsys_mock = MagicMock()

# Generated at 2022-06-20 18:10:26.194158
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Construct a HurdPfinetNetwork object with a well-formed output from fsysopts
    and verify that the populate method correctly assigns the network facts.
    """
    import ansible.module_utils.facts.network.gnu.hurd
    ansible.module_utils.facts.network.gnu.hurd.HurdPfinetNetwork._socket_dir = 'test/python/unit/ansible/module_utils/facts/network/gnu/hurd'

    h = HurdPfinetNetwork({})
    network_facts = h.populate()

# Generated at 2022-06-20 18:10:28.789801
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork()
    assert net.platform == 'GNU'


# Generated at 2022-06-20 18:10:33.170205
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork()

    assert network_facts
    assert network_facts.platform == 'GNU'
    assert isinstance(network_facts._socket_dir, str)



# Generated at 2022-06-20 18:10:45.977048
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    eth0 = {
        'active': True,
        'device': 'eth0',
        'ipv4': {'address': '192.168.31.1', 'netmask': '255.255.255.0'},
        'ipv6': [{'address': '::1', 'prefix': '128'},
                 {'address': 'fe80::1', 'prefix': '64'}],
    }
    lo = {
        'active': True,
        'device': 'lo',
        'ipv4': {'address': '127.0.0.1', 'netmask': '255.0.0.0'},
        'ipv6': [{'address': '::1', 'prefix': '128'}],
    }

# Generated at 2022-06-20 18:10:46.830866
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass

# Generated at 2022-06-20 18:10:57.711962
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.network import NetworkModule

    module = NetworkModule(argument_spec={}, supports_check_mode=True)
    module.run_command = mock.Mock()
    module.run_command.return_value = (0, to_bytes(PFINET_INET_OUTPUT), to_bytes(''))

    network = HurdPfinetNetwork()
    network.module = module

    interface = HurdPfinetNetwork.get_interface_info('eth0')
    assert interface['ipv4']['address'] == '192.168.1.1'
    assert interface['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:11:04.604239
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector
    assert collector.platform == 'GNU'
    assert collector.fact_class.platform == 'GNU'

# Test the facts of HurdPfinetNetwork

# Generated at 2022-06-20 18:11:07.148339
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork()
    assert obj is not None

# Generated at 2022-06-20 18:11:09.148444
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    result = HurdNetworkCollector()
    assert result._platform == 'GNU'

# Generated at 2022-06-20 18:11:14.700298
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class test_module:
        def get_bin_path(self, _):
            return 'fsysopts_path'
        def fail_json(self, **kwargs):
            raise Exception('failed')
        def run_command(self, cmd):
            if cmd == ['fsysopts_path', '-L', '/servers/socket/inet']:
                return 0, 'interface=/dev/eth0 address=1.1.1.1 netmask=255.255.255.0 address6=2:2:2:2:2:2:2:2/64 address6=2:2:2:2:2:2:2:1/64', ''

# Generated at 2022-06-20 18:11:17.839469
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj.platform == 'GNU'


# Generated at 2022-06-20 18:11:29.397535
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                0,
                '--interface=/dev/eth0',
                '--address=192.168.1.1',
                '--netmask=255.255.255.0',
                '',
            ]

        def get_bin_path(self, path):
            return '/usr/bin/fsysopts'

        def run_command(self, command):
            return self.run_command_results.pop(0)

    fake_module = TestModule()
    fake_network = HurdPfinetNetwork(fake_module)
    res = fake_network.populate()

    # This is the response we expect from the method populate

# Generated at 2022-06-20 18:11:39.631469
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )


# Generated at 2022-06-20 18:11:41.967250
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:11:45.040351
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, {})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'



# Generated at 2022-06-20 18:11:49.013050
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    x1 = HurdNetworkCollector()
    assert x1._platform == 'GNU'
    assert x1._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:12:02.608768
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector.platform == 'GNU'
    assert HurdNetworkCollector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:12:05.251886
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    HurdPfinetNetwork(module, ["eth0"], {})

# Generated at 2022-06-20 18:12:12.755198
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    Test assign_network_facts if the output of fsysopts is correct
    '''
    network_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    current_if = "eth0"
    output = ["--interface=/dev/" + current_if,
              "--address=10.0.0.1", "--netmask=255.255.255.0",
              "--address6=fe80::a00:20ff:feb4:e916/64"]

    network_facts['interfaces'] = [current_if]
    network_facts['eth0'] = {'active': True, 'device': 'eth0', 'ipv4': {}, 'ipv6': []}

    hurd_p

# Generated at 2022-06-20 18:12:20.350805
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import mock
    module = mock.Mock()
    fsysopts_path = "fake_fsysopts_path"
    socket_path = "fake_socket_path"
    fake_output_fsysopts_L = ("--interface=/dev/eth0 --address=192.168.1.1 "
                              "--netmask=255.255.255.0 --address6=2607:f0d0:1002:51::4/64")
    module.run_command.return_value = (0, fake_output_fsysopts_L, '')
    test_pfinet = HurdPfinetNetwork(module)
    network_facts = {}
    test_pfinet.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_

# Generated at 2022-06-20 18:12:24.841723
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test that it return HurdNetworkCollector class
    """
    obj = HurdNetworkCollector()
    assert obj.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-20 18:12:37.668681
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    network = HurdPfinetNetwork()
    test_data = ('--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=fe80::bbcc:ddff:fe00:1122/64')
    network_facts = {
        'interfaces': [],
    }

# Generated at 2022-06-20 18:12:40.334190
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    result = HurdNetworkCollector()
    assert isinstance(result, HurdNetworkCollector)

# Generated at 2022-06-20 18:12:47.123375
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    '''
    Function to test the class HurdPfinetNetwork.
    '''
    Network_data = HurdPfinetNetwork(None)
    assert Network_data.populate() == {
      'interfaces': [],
      'localhost': {'active': True, 'device': 'localhost', 'ipv4': {}, 'ipv6': []},
    }

# Generated at 2022-06-20 18:12:59.361280
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnuhurd.collector import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnuhurd.collector import HurdNetworkCollector
    import ansible.module_utils.facts.network.base
    import ansible.module_utils.facts.network.linux.collector
    import ansible.module_utils.facts.network.linux.interfaces
    import ansible.module_utils.facts.network.bsd.collector
    import ansible.module_utils.facts.network.bsd.interfaces
    import ansible.module_utils.facts.network.posix.collector
    import ansible.module_utils.facts.network.posix.interfaces

# Generated at 2022-06-20 18:13:08.086249
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_facts_output = {
        "interfaces": [
            "eth0"
        ],
        "eth0": {
            "active": True,
            "device": "eth0",
            "ipv4": {
                "address": "10.0.2.15",
                "netmask": "255.255.255.0"
            },
            "ipv6": [
                {
                    "address": "fe80::a00:27ff:feba:4f4b",
                    "prefix": "64"
                }
            ]
        }
    }
    network_facts = HurdPfinetNetwork()
    assert network_facts._socket_dir == '/servers/socket/'

    mock_module = MagicMock()

# Generated at 2022-06-20 18:13:38.250869
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class TestModule:
        def get_bin_path(self, arg):
            return 'fsysopts'

        def run_command(self, arg):
            if arg[-1] == '/servers/socket/inet':
                return (0, '', '')
            elif arg[-1] == '/servers/socket/inet6':
                return (1, '', '')
        # FIXME: fix this mock
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path
    test_module = TestModule()
    test_HurdPfinetNetwork = HurdPfinetNetwork(test_module)


# Generated at 2022-06-20 18:13:46.064968
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import FactCollector
    import ansible.module_utils.basic

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    fact_collector = FactCollector(
        module=module,
        network_collectors=['network.HurdNetworkCollector']
    )
    fact_collector.collect()

    fact_collector.populate_facts()

    fact_collector.get_facts()

# Generated at 2022-06-20 18:13:47.605140
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector is not None

# Generated at 2022-06-20 18:13:48.247426
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    HurdNetworkCollector().populate()

# Generated at 2022-06-20 18:13:57.275774
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    # We have to mock module_utils/facts/network/base.py because
    # otherwise we would have to create actual file system structure.
    from ansible.module_utils.facts import network
    original_base_network = network.base.Network
    original_base_network_collector = network.base.NetworkCollector

    import mock
    import collections
    module = mock.MagicMock(name='module')
    module.run_command.return_value = (0, """--interface=eth0 --address=192.168.1.1 --netmask=255.255.255.0
    --interface=lo --address=127.0.0.1 --netmask=255.0.0.0""", "")
    module.get_bin_path.return_value = "fsysopts"
    module.params = {}


# Generated at 2022-06-20 18:14:04.807283
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)

    # When fsysopts is not found, return an empty dict
    module.run_command = lambda *arg, **kwarg: (1, '', '')
    assert network.populate() == {}

    # FIXME: test the actual case
    pass



# Generated at 2022-06-20 18:14:08.233755
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:13.390818
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'
    assert collector._platform == 'GNU'
    assert collector._fact_class.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-20 18:14:18.676751
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = None # FIXME: provide instance of a module class
    network = HurdPfinetNetwork(module)
    module.run_command = lambda x: (0, 'interface=test interface=test2 --interface=test3 --address=192.168.1.10 --netmask=255.255.255.0 --address6=192.0.0.1/12 --address6=192.0.0.2/12')

    network_facts = network.populate()
    assert network_facts['interfaces'] == ['test', 'test2', 'test3']
    assert network_facts['test3']['device'] == 'test3'
    assert network_facts['test3']['ipv4']['address'] == '192.168.1.10'

# Generated at 2022-06-20 18:14:26.786459
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.posix.base import get_file_content
    from ansible.module_utils.facts.network.posix import NormalNetworkConfig
    import os
    import sys

    class FakeModule:

        def __init__(self):
            pass

        def run_command(self, *args, **kwargs):
            return 0, '', ''

        def get_bin_path(self, *args, **kwargs):
            return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fi')

   

# Generated at 2022-06-20 18:15:18.352803
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.exit_json = lambda **kwargs: None

    network = HurdPfinetNetwork(module)
    network_facts = {'interfaces': []}

    network_facts = network.assign_network_facts(network_facts,
                                                 '/bin/fsysopts',
                                                 '/servers/socket/inet6')
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.2'

# Generated at 2022-06-20 18:15:28.758728
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    class MockModule(object):
        command_results = {}

        def run_command(self, args):
            #print ("Running command %s" % args)
            return self.command_results[args]

        def get_bin_path(self, arg):
            try:
                return self.bin_paths[arg]
            except KeyError:
                return None

    class MockFactCollector(object):
        def populate(self):
            return {}

    module = MockModule()

    # Test without fsysopts
    module.bin_paths = { 'fsysopts': None }
    module.command_results = {}
    device = HurdPfinetNetwork(module, MockFactCollector)
    network_facts = device.populate()
    assert network_facts == {}

    # Test with fsysopts,

# Generated at 2022-06-20 18:15:39.807968
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    This function test assign network facts of class HurdPfinetNetwork by
    passing good and bad values.
    '''

    # Creating instance of module and class
    module = AnsibleModule(
        argument_spec=dict(
            foo=dict(type='str', required=True),
            bar=dict(type='bool', required=False, default=False),
        )
    )
    obj = HurdPfinetNetwork(module)


    # Testing with good and bad values

    network_facts = dict()
    fsysopts_path = "/path/to/fsysopts"
    socket_path = "/path/to/socket"
    out = "--address=192.168.1.1 --interface=/dev/pfinet0"

    res_network_facts = obj.assign_network_facts

# Generated at 2022-06-20 18:15:43.823418
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-20 18:15:47.742127
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd_pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector

    networkcollector = NetworkCollector()
    network_facts = networkcollector.get_network_facts()

    hurdpfinetnetwork = HurdPfinetNetwork()

    assert isinstance(hurdpfinetnetwork, NetworkCollector)
    assert isinstance(hurdpfinetnetwork, HurdPfinetNetwork)
    assert isinstance(hurdpfinetnetwork, NetworkCollector)
    assert isinstance(hurdpfinetnetwork.fact_class, HurdPfinetNetwork)
    assert hurdpfinetnetwork.platform == 'GNU'

# Generated at 2022-06-20 18:15:50.441329
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test instantiation of class HurdNetworkCollector
    """
    c = HurdNetworkCollector()

# Generated at 2022-06-20 18:16:00.879062
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile
    import shutil
    from ansible.module_utils.facts.network import Network as NetworkMod
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork as HurdPfinetNetworkMod
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector as HurdNetworkCollectorMod
    from ansible.module_utils.facts.network.base import NetworkCollector as NetworkCollectorMod
    from ansible.module_utils.facts.network.base import Network as NetworkBaseMod
    from ansible.module_utils.facts.utils import Facts as FactsMod

    # setup
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:16:11.949121
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import FactCollector

# Generated at 2022-06-20 18:16:15.721967
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    (mock_module, network_facts) = NetworkCollector.prepare_mock(None, 'GNU')
    pfinet_network_facts = HurdPfinetNetwork(mock_module)
    pfinet_network_facts.populate(network_facts)
    assert pfinet_network_facts.facts['network'] == {'interfaces': [], 'primary': None}

# Generated at 2022-06-20 18:16:24.165800
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    This test is part of the GNU Hurd Network module.
    Unit test for the HurdPfinetNetwork assign_network_facts method.
    '''
    tmodule = FakeAnsibleModule()
    network = HurdPfinetNetwork(tmodule)

    # sample data
    output = '''--netif=eth0
--address=10.0.0.1
--netmask=255.255.255.0
--address6=fc00::1/128
'''

    # check the result
    facts = network.assign_network_facts(dict(), 'fsysopts', 'pfinet')

# Generated at 2022-06-20 18:18:18.907492
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Test assign_network_facts method of HurdPfinetNetwork
    """
    class ModuleFake:
        def __init__(self):
            self.run_command_value = (0, '', '')

        def fail_json(self, **kwargs):
            raise Exception('fail_json should not be called')

        def get_bin_path(self, binary, required=True, opt_dirs=[]):
            return None

        def run_command(self, args, **kwargs):
            return self.run_command_value
    module = ModuleFake()

    class HurdPfinetNetworkFake(HurdPfinetNetwork):
        def __init__(self):
            self.module = ModuleFake()

    hurd_pfinet_network = HurdPfinetNetworkFake()
    fsysopts

# Generated at 2022-06-20 18:18:20.688354
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-20 18:18:25.864269
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    import ansible_module_pifpaf

    platform = 'GNU'
    module = ansible_module_pifpaf.MyModule('setup')

    network = HurdPfinetNetwork(module)
    assert network._platform == platform

# Generated at 2022-06-20 18:18:30.865876
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    # FIXME: Do not need to do monkey patching if we use pytest.
    module.run_command = run_command
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    print(json.dumps(network_facts, indent=4))



# Generated at 2022-06-20 18:18:38.147395
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    facts = {}
    network_object = HurdPfinetNetwork(module)


# Generated at 2022-06-20 18:18:41.277481
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU', 'test_HurdNetworkCollector: ' + \
        'constructor of HurdNetworkCollector failed'
    assert obj._fact_class == HurdPfinetNetwork, 'test_HurdNetworkCollector: ' + \
        'constructor of HurdNetworkCollector failed'


# Generated at 2022-06-20 18:18:48.565953
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet6'
    fact_class = HurdPfinetNetwork(module)
    network_facts = {'interfaces': []}

# Generated at 2022-06-20 18:18:56.153397
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''Unit test for method populate of class HurdPfinetNetwork'''
    actual_network_facts = HurdPfinetNetwork().populate()

# Generated at 2022-06-20 18:19:01.148768
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    network_facts = {
        'interfaces': [],
    }
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    network = HurdPfinetNetwork(module=module)
    result = network.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-20 18:19:09.408098
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    This function unit test function for constructor of class HurdPfinetNetwork
    """
    import os
    socket_dir = '/servers/socket'
    os.makedirs(socket_dir)
    hurd_pfinet_network = HurdPfinetNetwork()

    # if directory doesn't exit
    os.rmdir(socket_dir)
    assert hurd_pfinet_network._socket_dir == None