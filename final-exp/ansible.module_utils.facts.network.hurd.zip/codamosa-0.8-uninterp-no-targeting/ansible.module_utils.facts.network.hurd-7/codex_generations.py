

# Generated at 2022-06-20 18:09:40.893973
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    class TestModule(object):
        def run_command(self, args):
            return 0, 'key=value', ''
        def get_bin_path(self, arg):
            return arg
    module = TestModule()
    hnc = HurdNetworkCollector(module)
    assert hnc._platform == 'GNU'
    assert hnc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:09:49.668732
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import collections

    mocked_module = collections.namedtuple('mocked_module', ['run_command', 'get_bin_path'])

    fsysopts_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'hacking', 'fsysopts')
    socket_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', 'hacking', 'socket_path')


# Generated at 2022-06-20 18:09:53.342199
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork

    assert HurdPfinetNetwork(None).platform == 'GNU'

# Generated at 2022-06-20 18:09:57.685635
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import doctest
    from ansible.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork
    os = HurdPfinetNetwork()
    # This is the content of /servers/socket/inet fsysopts -L /servers/socket/inet
    # output
    # --interface=/dev/eth0 --address=192.168.1.1 --address6=fe80::ba27:ebff:fe22:7f3c/64
    # --netmask=255.255.255.0

# Generated at 2022-06-20 18:10:03.872121
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Test class HurdPfinetNetwork
    """
    inet_link = os.path.join(HurdPfinetNetwork._socket_dir, 'inet')
    assert True == os.path.exists(inet_link)
    inet6_link = os.path.join(HurdPfinetNetwork._socket_dir, 'inet6')
    assert False == os.path.exists(inet6_link)

# Generated at 2022-06-20 18:10:05.277508
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'

# Generated at 2022-06-20 18:10:08.756228
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd.pfinet.plugins.test.test_collector import CollectedFacts
    obj = HurdPfinetNetwork({}, CollectedFacts())
    assert obj.platform == 'GNU'


# Generated at 2022-06-20 18:10:12.278431
# Unit test for constructor of class HurdPfinetNetwork

# Generated at 2022-06-20 18:10:21.216449
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class ModuleMock:
        def get_bin_path(self, name):
            return '/bin/fsysopts'

        def run_command(self, args):
            return (0, '--interface=/dev/eth0', '')
    class FactsMock:
        def __init__(self):
            self.hw = {
                'network': {
                    'interfaces': [],
                },
            }
    class AnsibleModuleMock:
        def __init__(self):
            self.facts = FactsMock()
        def run_command(self, args):
            return (0, '--interface=/dev/eth0', '')
    class AnsibleModuleUtilsNetworkModuleTestFrameworkMock:
        def __init__(self):
            self.module = ModuleMock()

# Generated at 2022-06-20 18:10:22.824879
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    res = {}
    module = MockModule()
    class_ = HurdPfinetNetwork(module)
    class_.populate()

# Generated at 2022-06-20 18:10:29.889644
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hd = HurdPfinetNetwork(None)
    assert hd.platform == 'GNU'
    assert hd._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:10:38.668339
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module=module)
    network_facts = {}
    out = '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fd00:1:2:3:4:5:6:7/64'
    socket_path = '/servers/socket/inet'
    fsysopts_path = '/usr/bin/fsysopts'
    network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-20 18:10:40.840348
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None


# Generated at 2022-06-20 18:10:48.769875
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.six import PY3, BytesIO

    if PY3:
        fsysopts_return = b"""--interface=/dev/eth0
  --active
  --link=up
  --address=192.168.1.2
  --netmask=255.255.255.0
  --address6=fc00:1111:2222:3333::1/64
"""
    else:
        fsysopts_return = """--interface=/dev/eth0
  --active
  --link=up
  --address=192.168.1.2
  --netmask=255.255.255.0
  --address6=fc00:1111:2222:3333::1/64
"""

    network = HurdPfinetNetwork(module=None)
    network_facts = {}


# Generated at 2022-06-20 18:10:50.253958
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()


# Generated at 2022-06-20 18:10:55.031893
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hpn = HurdPfinetNetwork({})
    hpn._socket_dir = '/tmp/servers/socket/'
    os.mkdir('/tmp/servers/socket')
    os.symlink('/tmp/pfinet_domain', '/tmp/servers/socket/inet')
    f = open('/tmp/pfinet_domain', 'w')
    f.write('1\n')
    f.close()
    hpn.module.run_command = lambda x, check_rc=True: (0, '--interface=/dev/foo --address=127.0.0.1 --netmask=255.0.0.0 --address6=::1/128 --address6=fe80::1/64', '')

# Generated at 2022-06-20 18:11:03.713669
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.pfinet.collector import HurdPfinetNetwork
    network = HurdPfinetNetwork()
    network.module = MockModule({
        '/servers/socket/inet': True,
        '/servers/socket/inet6': False,
        'fsysopts -L /servers/socket/inet': (0, '', ''),
    })

    network.populate()

# Generated at 2022-06-20 18:11:10.485979
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    with open('/proc/sys/kernel/osrelease') as f:
        lines = f.readlines()
    assert isinstance(HurdNetworkCollector, object)
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:13.811457
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModuleMock()
    hn = HurdPfinetNetwork(module)
    hn.populate()



# Generated at 2022-06-20 18:11:17.915585
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():

    class AnsibleModuleMock():

        def get_bin_path(self, f):
            return f

        def run_command(self, c):
            return (1, 'out', 'err')

    class AnsibleModuleLoaderMock():

        module = AnsibleModuleMock()

    n = HurdPfinetNetwork(AnsibleModuleLoaderMock())
    assert n is not None, 'failed to create object'

# Generated at 2022-06-20 18:11:37.853657
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = MockModule()
    network = HurdPfinetNetwork(module)
    assert network.module == module

my_network_facts = {
    'interfaces': [
        'eth0',
    ],
    'eth0': {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '192.168.0.1',
            'netmask': '255.255.255.0',
        },
        'ipv6': [
            {
                'prefix': '24',
                'address': 'fe80::a00:20ff:fe02:1',
            },
        ],
    }
}


# Generated at 2022-06-20 18:11:47.997909
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import os
    import shutil
    import sys
    import tempfile
    import platform
    import AnsibleModule
    from ansible.module_utils.facts import Network

    if platform.system() != 'GNU':
        print('')
        print('test_HurdPfinetNetwork_populate: skipping test as platform is not GNU')
        print('')
        return

    test_vars = Network.init_module_vars()
    test_vars['gather_subset'] = 'all'
    test_vars['gather_timeout'] = 0
    test_vars['filter'] = '*'

    module = AnsibleModule.AnsibleModule(argument_spec=test_vars)

    test_dir = tempfile.mkdtemp()
    test_socket_dir = os.path.join

# Generated at 2022-06-20 18:11:49.734634
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()

# Generated at 2022-06-20 18:11:54.721596
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = "AnsibleModule"
    obj = HurdPfinetNetwork(module)
    for attr in ['_platform', '_fact_class']:
        assert getattr(obj, attr) is not None


# Generated at 2022-06-20 18:12:02.014942
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network import Network
    import pytest
    h_network = HurdPfinetNetwork(object())
    network_facts = {}
    fsysopts_path = '/hurd/pfinet/fsysopts'
    socket_path = '/hurd/pfinet/inet/128.0.0.0'
    output = """--interface=/dev/eth0 --address=128.0.0.1 --netmask=255.255.255.0 --address6=2001:db8::1/64"""
    network_facts = h_network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts is not None
    assert 'interfaces' in network_facts

# Generated at 2022-06-20 18:12:11.659430
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network import Network
    import ansible.module_utils.facts.network.hurd
    import os

    def _cmd(path):
        return ['fsysopts', '-L', path]

    module = ansible.module_utils.facts.network.hurd.HurdPfinetNetwork(None, None, None)

    cwd = os.getcwd()
    os.chdir('/servers/socket')
    os.symlink('/servers/socket/pfinet', 'inet6')

# Generated at 2022-06-20 18:12:13.237377
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = NetworkCollector()
    assert nc._platform == 'GNU'
    assert nc.fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:12:20.906147
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket'
    out = '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=2001:db8::1/64'
    module.run_command = Mock(return_value=(0, out, ''))

    n = HurdPfinetNetwork(module)
    result = n.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-20 18:12:24.768563
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork



# Generated at 2022-06-20 18:12:33.225748
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    ansible_module = FakeAnsibleModule([])
    net = HurdPfinetNetwork(ansible_module)

    facts = {}

    out = '--address=192.168.1.56 --netmask=255.255.255.0 --interface=/dev/eth0 --mtu=1500 --address6=fe80::3c07:aaff:fe56:3317/64 --address6=2a01:e34:eabf:ce20:3c07:aaff:fe56:3317/128'
    net.assign_network_facts(facts, out)

    assert facts['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:13:05.967448
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Unit test for method populate of class HurdPfinetNetwork
    """
    class Test_module:
        def __init__(self):
            pass
        def get_bin_path(self, arg):
            if arg == 'fsysopts':
                return '/hurd/fsysopts'
            return None
        def run_command(self, cmd):
            out = ''
            if cmd[-1].endswith('/inet'):
                out = '--interface=/dev/eth1 --address=10.0.2.15 --netmask=255.255.255.0'
            elif cmd[-1].endswith('/inet6'):
                out = '--interface=/dev/eth1 --address6=fdf9:0d74:2a0b:bc20::1/64'

# Generated at 2022-06-20 18:13:07.241209
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector is not None

# Generated at 2022-06-20 18:13:12.683254
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of class HurdPfinetNetwork must set platform to 'GNU'
    :return:
    """
    assert HurdPfinetNetwork().platform == 'GNU'


# Generated at 2022-06-20 18:13:14.445304
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.get_facts() is None

# Generated at 2022-06-20 18:13:17.117649
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:13:21.452679
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.network.gnu.distro.hurd import HurdNetworkCollector
    obj = HurdNetworkCollector()

# Generated at 2022-06-20 18:13:22.928654
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert not HurdNetworkCollector()


# Generated at 2022-06-20 18:13:31.416968
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # In this unit test we mock class ansible.module_utils.facts.network.Network
    # and the related methods. In order to test the method assign_network_facts
    # of class HurdPfinetNetwork, we fake the results of its submethods.
    class ModuleFake:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = "--interface=lo --address=127.0.0.1 --netmask=255.0.0.0\n"
            self.run_command_err = ""

        def run_command(self, args):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class NetworkFake:
        def __init__(self, module):
            self.module

# Generated at 2022-06-20 18:13:37.532273
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
    )
    module.run_command = mock.Mock(return_value=(0, '', ''))
    hp = HurdPfinetNetwork(module)
    hp.populate()
    module.run_command.assert_called_once_with(
        [module.get_bin_path('fsysopts'), '-L', '/servers/socket/inet'])

# Generated at 2022-06-20 18:13:38.858021
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-20 18:14:21.952864
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert issubclass(HurdNetworkCollector, NetworkCollector)
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:25.062323
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.facts_class is HurdPfinetNetwork
    assert network_collector.platform == 'GNU'


# Generated at 2022-06-20 18:14:37.121127
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    from ansible.module_utils.facts import collector

    # Monkey patch the module
    import ansible.module_utils.facts.network.hurd_pfinet
    test_module = ansible.module_utils.facts.network.hurd_pfinet
    test_module.AnsibleModule = collector.get_ansible_module_mock()

    # Set up object
    facts_module = collector.get_network_collector('hurd_pfinet',
                                                   test_module)['instance']

    # Set up return values
    test_module.run_command.return_value = (0, '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.0.0 --address6=2001::1/64', '')
    network_facts = {}

    expected

# Generated at 2022-06-20 18:14:38.554892
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()

# Generated at 2022-06-20 18:14:39.811321
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Tests for constructor of HurdNetworkCollector class"""
    obj = HurdNetworkCollector()
    assert obj



# Generated at 2022-06-20 18:14:49.325130
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    collect_obj = HurdPfinetNetwork()
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/xyz'
        def run_command(self, arg):
            stdout = '--interface=/dev/eth0 --address=127.0.0.1 --address6=::1/128 --netmask=255.0.0.0'
            return (0, stdout, '')
    collect_obj.module = MockModule()

    result = collect_obj.populate()
    assert result
    assert result['interfaces'] == ['eth0']
    assert result['eth0']
    assert result['eth0']['ipv4']
    assert result['eth0']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:14:59.195933
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    """
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible.module_utils import basic

    class TestModule(object):
        def run_command(self, cmd):
            if cmd[0] == 'fsysopts' and cmd[1] == '-L' and cmd[2] == '/servers/socket/inet':
                return 0, "interface = /dev/eth0 \
                    address = 10.20.30.40 \
                    netmask = 255.255.255.0 \
                    address6 = 2001:db8::1/64", ''
           

# Generated at 2022-06-20 18:15:00.576860
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None

# Generated at 2022-06-20 18:15:04.086102
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector is not None
    assert collector._platform == 'GNU'

# Units test for HurdPfinetNetwork

# Generated at 2022-06-20 18:15:06.954159
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import Facts
    import ansible.module_utils.facts.network.hurd.pfinet as pfin
    import ansible.module_utils.facts.network.system as system

    obj = pfin.HurdPfinetNetwork()
    iface = system.Interface()
    facts = Facts()
    iface.populate(facts)
    obj.populate(facts)



# Generated at 2022-06-20 18:16:37.090111
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

    obj = HurdNetworkCollector(params={'gather_network_resources': 0})
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdNetworkCollector._fact_class

# Generated at 2022-06-20 18:16:41.683181
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModuleMock('test_hurd_pfinet_network')
    network = HurdPfinetNetwork(module)
    assert network != None


# Generated at 2022-06-20 18:16:51.356725
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Let's use a modified version of bin/ansible to get the module
    # autoloader
    import sys
    sys.modules['ansible'] = type(sys)('ansible')
    sys.modules['ansible.module_utils'] = type(sys)('ansible.module_utils')
    sys.modules['ansible.module_utils.facts'] = type(sys)('ansible.module_utils.facts')
    sys.modules['ansible.module_utils.facts.network'] = type(sys)('ansible.module_utils.facts.network')
    sys.modules['ansible.module_utils.facts.network.base'] = type(sys)('ansible.module_utils.facts.network.base')
    from ansible.module_utils.facts.network.base import Network

# Generated at 2022-06-20 18:17:00.570144
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module(object):
        def __init__(self):
            self.run_command_expectations = {
                'run_command-fsysopts -L /servers/socket/inet': (0, '--interface=/dev/eth0 --address=10.0.1.1 --netmask=255.255.255.0 --address6=fc00::1/64', ''),
            }

        def run_command(self, args):
            key = 'run_command-' + ' '.join(args)
            return self.run_command_expectations[key]

        def get_bin_path(self, arg):
            return 'fsysopts'

    m = Module()
    n = HurdPfinetNetwork(m)
    network_facts = {}
    fsysopts_path = m.get

# Generated at 2022-06-20 18:17:09.906295
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Arguments for instantiation
    module = None
    p = HurdPfinetNetwork(module)
    # make sure module is set
    assert p.module == module
    # make sure platform is set
    assert p.platform == 'GNU'
    # make sure fsysopts is set to a correct value
    assert p._socket_dir == '/servers/socket/'
    # make sure no network facts is assigned yet
    assert 'all_ipv4_addresses' not in p.facts


# Generated at 2022-06-20 18:17:12.388776
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h_p_n = HurdPfinetNetwork({})
    assert h_p_n.platform == 'GNU'

# Generated at 2022-06-20 18:17:21.227999
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    def mock_run_command(self):
        return (0, '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::2aa:15ff:fe2a:9d13/64', '')
    import ansible.modules.system.network
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    ansible.modules.system.network.HurdPfinetNetwork = HurdPfinetNetwork
    HurdPfinetNetwork.populate = mock_run_command
    res = HurdPfinetNetwork().populate()

# Generated at 2022-06-20 18:17:30.891548
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network_facts = HurdPfinetNetwork(module).populate()
    assert module.run_command.call_count == 1
    # Test for sample output. This is incomplete
    assert network_facts == {'interfaces': ['eth0'], 'eth0': {'device': 'eth0', 'ipv4': {'address': '192.168.125.9', 'netmask': '255.255.255.0'}, 'active': True, 'ipv6': [{'prefix': '64', 'address': 'fe80::68b3:eaff:fe00:2b5'}, {'prefix': '64', 'address': 'fe80::68b3:eaff:fe00:2b6'}]}}

# Generated at 2022-06-20 18:17:41.891689
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # tests use the module_utils.facts.network.base.Network
    # to get the same results as the code used in the platform code
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)

    network_facts = network.populate()
    assert network_facts == {}

    module = FakeAnsibleModule()
    module.run_command_results = []
    network = HurdPfinetNetwork(module)

    network_facts = network.populate()
    assert network_facts == {}


# Generated at 2022-06-20 18:17:50.903075
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock({}, {
        "fsysopts": "fsysopts"
    })
    module.run_command = AnsibleModuleMock.run_command

    def mock_run_command(cmd, path_check=True, data=None, binary_data=False):
        (rc, out, err) = (0, '', '')