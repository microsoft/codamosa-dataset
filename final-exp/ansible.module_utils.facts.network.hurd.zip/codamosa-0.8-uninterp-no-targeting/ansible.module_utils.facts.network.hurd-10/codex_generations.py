

# Generated at 2022-06-20 18:09:46.472972
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    mod_utils = AnsibleModuleUtils(module)

    socket_dir_resources = (
        'inet',
        'inet6',
    )
    socket_dir = tempfile.mkdtemp("socket")
    for r in socket_dir_resources:
        f = open(os.path.join(socket_dir, r), 'a')
        f.close()

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value="/bin/fsysopts")
    facts = HurdPfinetNetwork().populate()
    module.get_bin_path.assert_any_call('fsysopts')


# Generated at 2022-06-20 18:09:50.048583
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    instance = HurdPfinetNetwork()
    assert isinstance(instance, HurdPfinetNetwork)
    assert instance.platform == 'GNU'
    assert instance._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:09:52.584027
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:09:55.591260
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert(HurdNetworkCollector._platform == 'GNU')
    assert(HurdNetworkCollector._fact_class == HurdPfinetNetwork)


# Generated at 2022-06-20 18:10:05.969795
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import os
    from ansible.module_utils.facts import collector

    if 'GNU' in collector.NetworkCollector.collectors:
        del collector.NetworkCollector.collectors['GNU']
    network_collector = collector.NetworkCollector()
    gnu_network_collector = HurdPfinetNetwork()

    assert 'GNU' in collector.NetworkCollector.collectors

    os.path.isfile = lambda x: True
    os.access = lambda x, y: True
    result = gnu_network_collector.populate()
    assert result == {}
    result = network_collector.get_network_facts()
    assert result == {}

    def get_bin_path(x):
        if x == 'fsysopts':
            return '/bin/fsysopts'

    gnu_

# Generated at 2022-06-20 18:10:15.509143
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    """
    class Module():
        """
        Class to construct a module stub
        """
        def __init__(self, opts):
            self.params = opts

        def get_bin_path(self, arg):
            """
            Stub method
            """
            return "/bin/fsysopts"

        def run_command(self, arg):
            """
            Stub method
            """
            return (0, "--interface=/dev/eth0 --address=10.0.0.3 --netmask=255.255.255.0 --address6=fe80::1/64 --address6=fe80::2/64", "")


# Generated at 2022-06-20 18:10:24.841065
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={'path': dict(default=None)}, supports_check_mode=True)
    if _module is None:
        module.exit_json(failed=True, msg='ansible.module_utils.facts.network.pfioh.HurdPfinetNetwork class cannot be loaded. Check if python-pfioh module is installed.')
    network_facts = _fact_class(module)
    network_facts.populate()



# Generated at 2022-06-20 18:10:28.060069
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    h = HurdNetworkCollector()
    assert h._platform == 'GNU' and h._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:10:36.170133
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

    assert network_facts['interfaces'], 'HurdPfinetNetwork should populate interfaces'
    assert 'eth0' in network_facts, 'HurdPfinetNetwork should populate interfaces'
    assert 'eth0' in network_facts['interfaces'], 'HurdPfinetNetwork should populate interfaces'
    assert 'ipv4' in network_facts['eth0'], 'HurdPfinetNetwork should populate interfaces'
    assert 'address' in network_facts['eth0']['ipv4'], 'HurdPfinetNetwork should populate interfaces'
    assert 'netmask' in network_facts['eth0']['ipv4'], 'HurdPfinetNetwork should populate interfaces'


# Generated at 2022-06-20 18:10:37.603624
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-20 18:10:49.187077
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    HurdPfinetNetwork.assign_network_facts(
        network_facts={},
        fsysopts_path=None,
        socket_path=None,
    )
    # TODO: more unit tests

# Unit tests for method populate of class HurdPfinetNetwork

# Generated at 2022-06-20 18:10:51.366354
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:10:54.994513
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_obj = HurdPfinetNetwork({})
    assert network_obj.platform == 'GNU'
    assert network_obj._socket_dir == '/servers/socket/'
    assert network_obj._iface_prefixes == []

# Generated at 2022-06-20 18:11:06.919106
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Import needed objects from ansible.module_utils.facts.network.gnu
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    # Create a HurdPfinetNetwork object for test
    network_collector = HurdPfinetNetwork()

    # Set valid values to the module_args of the object
    network_collector.module.run_command = lambda args: (0, '--interface=eth0 --address=10.0.2.15 --netmask=255.255.255.0', '')
    network_collector.module.get_bin_path = lambda args: '/usr/bin/fsysopts'
    network_collector.module.params = {}

    # Create a facts object to store collected facts
    collected_facts = {}

    # Call the populate method to populate the

# Generated at 2022-06-20 18:11:18.086186
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # run_command will return the lines of output as follows
    # ['--interface=/dev/eth0', '--address=192.168.0.30', '--netmask=255.255.255.255', '--address6=2a00:a840:5020:101:20c:29ff:fe8b:49b5/64']
    # run_command returns a tuple of return code, standard output and standard error
    run_command_result = (0, '--interface=/dev/eth0 --address=192.168.0.30 --netmask=255.255.255.255 --address6=2a00:a840:5020:101:20c:29ff:fe8b:49b5/64', '')
    # module_utils.basic.AnsibleModule.run_command is called and it should return the

# Generated at 2022-06-20 18:11:20.945431
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facts = HurdPfinetNetwork(None)
    assert facts.platform == 'GNU'

# Generated at 2022-06-20 18:11:31.039475
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def run_command(self, args):
            return (0, b"interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=ff00::/64", b"")

    class FakeNetwork(HurdPfinetNetwork):
        def __init__(self):
            pass

    network = FakeNetwork()
    network.module = FakeModule()
    network = network.assign_network_facts({}, b"/bin/fsysopts", b"/servers/socket/inet")

    assert network['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:11:40.278764
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import argparse

    mod = argparse.ArgumentParser()
    mod.add_argument('-L')

    # Create a module object
    class ClassModule:
        def __init__(self):
            self.run_command = mod.run_command

        def get_bin_path(self, cmd):
            return '/bin/' + cmd

    module = ClassModule()

    # Create a network object
    network = HurdPfinetNetwork(module)

    # Create the socket file
    sock = open('/tmp/sock', 'w')

# Generated at 2022-06-20 18:11:49.204805
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    class Module:
        def run_command(s, cmd):
            return (0, '--netmask 255.255.255.0 --address 192.0.0.1', '')
    class TestNetwork(HurdPfinetNetwork):
        module = Module()
    network_facts = {}
    network_facts = TestNetwork.assign_network_facts(network_facts, '', '')
    if sys.version_info < (2, 7):
        assert 'interfaces' in network_facts
    else:
        assert 'interfaces' in network_facts and network_facts['interfaces'] == ['eth0']
        assert 'eth0' in network_facts['interfaces']
        assert {'address': '192.0.0.1', 'netmask': '255.255.255.0'} == network_

# Generated at 2022-06-20 18:11:55.563484
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import hashlib
    from ansible_collections.testns.testcoll.plugins.module_utils.facts import Network
    c = Network()

    fsysopts_path = c.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return None

    socket_path = os.path.join(os.environ['HOME'], '.ansible_module_facts', 'pfinet_foo')

    network_facts = {}
    network_facts['interfaces'] = []


# Generated at 2022-06-20 18:12:18.228893
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    This unit test create a module that mocks the run_command method and returns a fixed output
    obtained from GNU Hurd host with only eth0 configured.

    It calls the assign_network_facts method and assert the data structure obtained is what we expect.
    """
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, '{ "--interface" : "/dev/eth0" , "--address" : "10.0.1.4" , \
                                           "--netmask" : "255.255.255.0" }', '')
            self.get_bin_path = lambda x: '/bin/fsysopts'

    module = MockModule()
    network = HurdPfinetNetwork

# Generated at 2022-06-20 18:12:30.385446
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module(object):
        def get_bin_path(self, command, opt_dirs=[]):
            return '/usr/bin/fsysopts'

        def run_command(self, command):
            return (0, '''--interface=/dev/eth0
--address=10.10.10.10
--netmask=255.255.255.0
--address6=1fe80::cafe:5:5:5/64''', '')

    class FakeHurdPfinetNetwork(HurdPfinetNetwork):
        def __init__(self, module):
            self.module = module

    module = Module()
    network = FakeHurdPfinetNetwork(module)
    network_facts = {}

# Generated at 2022-06-20 18:12:32.068153
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Constructor test for HurdPfinetNetwork
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-20 18:12:33.123327
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork()

    assert net.platform == 'GNU'

# Generated at 2022-06-20 18:12:46.181809
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fact_class = HurdPfinetNetwork
    network_facts = {}

    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    output = '--interface=/dev/eth0 --address=192.168.10.3 --netmask=255.255.255.0 --address6=2001:db8:1::1/64'
    rc, out, err = (0, output, '')
    network_facts = fact_class.assign_network_facts(fact_class, network_facts, fsysopts_path, socket_path)

    assert network_facts
    assert network_facts['eth0']['ipv4']['address'] == '192.168.10.3'

# Generated at 2022-06-20 18:12:58.410557
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    example_data = [
        ['--interface=/dev/eth0', '--address=10.1.1.2', '--netmask=255.0.0.0', '--address6=2607:f0d0:1002:0011::4e/64'],
        ['--interface=/dev/eth1', '--address=10.2.2.2', '--netmask=255.255.0.0'],
        ['--interface=/dev/eth2', '--address6=2607:f0d0:1002:0011::4e/64'],
    ]
    m = MagicMock()

    def mock_run_command(args):
        example_data_index = int(args[2][-1]) - 1

# Generated at 2022-06-20 18:13:00.261826
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert(HurdPfinetNetwork(None))


# Generated at 2022-06-20 18:13:02.043371
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    cls = HurdNetworkCollector()
    assert cls._platform == 'GNU'
    assert cls._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:13:06.964252
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Test assign_network_facts method of class HurdPfinetNetwork
    :return:
    """
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module=module)
    network.assign_network_facts(network_facts={}, fsysopts_path='fsysopts_path', socket_path='/servers/socket/inet')

# Generated at 2022-06-20 18:13:08.734760
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # builtin class method - can't be tested
    pass

# Generated at 2022-06-20 18:13:33.005750
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mod = AnsibleModule(argument_spec={})
    fn = HurdPfinetNetwork(mod)
    facts = fn.populate()
    assert 'interfaces' in facts
    assert facts['interfaces'][0] in facts


# Generated at 2022-06-20 18:13:33.977444
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()

    assert collector is not None


# Generated at 2022-06-20 18:13:38.174414
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Test HurdPfinetNetwork class
    """
    network = HurdPfinetNetwork(dict(module=None))
    assert isinstance(network, HurdPfinetNetwork)
    assert isinstance(network, Network)

# Generated at 2022-06-20 18:13:47.882795
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.ansible.community.tests.unit.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    import json
    import sys

    def run_command_fn(*args, **kwargs):
        inet_home_response = b'--interface=/dev/eth0 \
--address=192.168.1.101 \
--address6=fe80::219:9bff:fe5b:d5ce/64 \
--netmask=255.255.255.0'

# Generated at 2022-06-20 18:13:50.367056
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None, None).platform == 'GNU'


# Generated at 2022-06-20 18:13:53.063349
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    list_instances = HurdNetworkCollector()
    assert list_instances._platform == 'GNU'

# Generated at 2022-06-20 18:13:55.034144
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()

    assert network.platform == 'GNU'
    assert network._fact_class == HurdPfinetNetwork



# Generated at 2022-06-20 18:13:59.350294
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector('', '')
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:10.223633
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    network = HurdPfinetNetwork(module)

    facts = {'network': {}}
    facts['network'] = network.populate(facts)

    assert len(facts['network']['interfaces']) == 1
    assert 'eth0' in facts['network']['interfaces']
    inter = facts['network']['eth0']
    assert inter['ipv4']['address'] == '192.168.0.1'
    assert inter['ipv4']['netmask'] == '255.255.255.0'
    assert len(inter['ipv6']) == 1
    ipv6 = inter['ipv6'][0]

# Generated at 2022-06-20 18:14:16.772492
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json

    # Ensure we have the same output as we would get from the module
    with open('tests/unit/module_utils/network/tests/fixtures/hurd_pfinet.ansible_facts') as facts_file:
        facts = json.load(facts_file)
    network_facts = HurdPfinetNetwork().populate()
    assert network_facts == facts['ansible_network_resources']

# Generated at 2022-06-20 18:15:05.728924
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.pfinet_network import HurdPfinetNetwork
    import ansible.module_utils.facts.network.base
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts

    # the following is required to test the module
    module = ansible.module_utils.facts.AnsibleModule(
        argument_spec=ansible.module_utils.facts.FactsArgsSpec(),
        supports_check_mode=True
    )

    network = HurdPfinetNetwork(module)

# Generated at 2022-06-20 18:15:09.795790
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:15:19.106646
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Initialize test context
    module.params = {}
    module._ansible_cwd = os.path.dirname(__file__)
    module._ansible_no_log = False
    module._ansible_debug = False
    module._ansible_verbosity = 0
    module._ansible_socket = None
    module._ansible_socket_path = None
    module._ansible_selinux_special_fs = None
    module._ansible_diff = False
    module.run_command = MagicMock(return_value=("", "", ""))


# Generated at 2022-06-20 18:15:26.613737
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Test the constructor."""
    def fake_module_init(self, module_arguments, temp_path):
        pass

    HurdPfinetNetwork.__init__ = fake_module_init
    _platform = 'GNU'
    hurd_pfinet_network = HurdPfinetNetwork(_platform)
    assert isinstance(hurd_pfinet_network, HurdPfinetNetwork)
    assert isinstance(hurd_pfinet_network.platform, str)
    assert hurd_pfinet_network.platform == 'GNU'


# Generated at 2022-06-20 18:15:39.459427
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fsysopts_path = '/boot/servers/fsysopts'
    socket_path = '/boot/servers/socket'

    hurd = HurdPfinetNetwork({}, {}, {}, {}, {})
    hurd.assign_network_facts({}, fsysopts_path, socket_path)

    # Test constructed dictionay
    assert hurd.network_facts.get('interfaces') == ['eth0', 'wlan0']

    # Test the device eth0
    assert hurd.network_facts['eth0']['active'] == True
    assert hurd.network_facts['eth0']['device'] == 'eth0'
    assert hurd.network_facts['eth0']['ipv4']['address'] == '192.168.1.2'

# Generated at 2022-06-20 18:15:39.949617
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork != None

# Generated at 2022-06-20 18:15:45.199159
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class = HurdPfinetNetwork
    network_collector = HurdNetworkCollector
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class is fact_class

# Generated at 2022-06-20 18:15:53.071479
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    import tempfile

    # This is data returned by fsysopts -L /servers/socket/inet
    output = '''
    --interface=/dev/eth0
    --address=10.20.30.40
    --netmask=16
    --address6=fe80::1/64
    '''

    # fysopts_path is a file with output
    fsysopts_path = tempfile.NamedTemporaryFile()
    fsysopts_path.write(output)
    fsysopts_path.flush()
    # socket_path is a file with path
    socket_path = tempfile.NamedTemporaryFile()
    socket_path.write('/servers/socket/inet')
    socket_

# Generated at 2022-06-20 18:15:55.032103
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector._platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:15:56.870572
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == 'GNU'

# Generated at 2022-06-20 18:17:41.723791
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_mock = MockModule()
    network_facts = HurdPfinetNetwork(module_mock)

    assert network_facts.platform == 'GNU'



# Generated at 2022-06-20 18:17:50.845588
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_collector, ansible_version
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes

    list_network_interfaces = []

    def my_run_command_mock(args):
        if args[0] == 'fsysopts':
            return (0, '--interface=eth0 --address=10.0.0.1 --netmask=255.0.0.0 --address6=2001:db8::/64', '')
        else:
            return (1, '', '')

    module_mock = AnsibleModuleMock()

# Generated at 2022-06-20 18:17:58.942023
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module_args = dict()
    module = FakeAnsibleModule(**module_args)
    # FIXME: This isn't a good fact to test. There are many ways to get
    # the networking facts. This test would have to become dynamic to
    # detect the actual implementation.
    fsysopts_path = module.get_bin_path('fsysopts')
    network_facts = dict()
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)

    input_strings = dict()
    input_strings['assign_network_facts'] = '''--interface=eth0 --address=192.168.1.10 --netmask=255.255.255.0 --address6=2001:db8::ff00:42:8329/64'''
    module.run_

# Generated at 2022-06-20 18:18:02.314830
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:18:06.244011
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork(None)
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:18:14.498704
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_object = HurdPfinetNetwork(None)
    test_object.assign_network_facts = HurdPfinetNetwork.assign_network_facts.im_func
    test_object.module = None

    test_interfaces_dict = {'interfaces': []}
    test_pfinet_out = '--interface=/dev/eth0 --address=192.168.179.42 --netmask=255.255.255.0 --address6=::ffff:192.168.179.42/96 --address6=fe80::a00:27ff:fe0b:e56c/128 --mtu=1500'
    test_fsysopts_path = '/hurd/pfinet'
    test_socket_path = '/servers/socket/inet'


# Generated at 2022-06-20 18:18:23.478562
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Provide a string to fsysopts output, and then check if assign_network_facts will
    generate the right interfaces and ip informations.
    """
    test_out = "--link-mtu=1500 --device=eth0 --interface=eth0 --address=192.0.2.15 --netmask=255.255.255.0 --address6=2001:db8:10::15/64"
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    test_inst = HurdPfinetNetwork()

# Generated at 2022-06-20 18:18:26.819730
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector._fact_class.platform == 'GNU'


# Generated at 2022-06-20 18:18:33.416787
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = Mock(name='ansible_module',
                  run_command=Mock(side_effect=[
                      ('0', '--interface=/dev/eth1 --address=10.1.2.3 --netmask=255.255.255.0', ''),
                      ('0', '--interface=/dev/eth2 --address=10.2.2.3 --netmask=255.255.255.0 --address6=2001:db8:1::1/64', ''),
                      ('0', '--interface=/dev/eth3 --address6=2001:db8:2::2/64 --address=10.3.2.3 --netmask=255.255.255.0', '')]),
                  params=dict())

    fsysopts_path='/bin/fsysopts'


# Generated at 2022-06-20 18:18:35.121704
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class is HurdPfinetNetwork