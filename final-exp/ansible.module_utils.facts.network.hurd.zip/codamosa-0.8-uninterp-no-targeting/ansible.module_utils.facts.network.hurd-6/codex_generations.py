

# Generated at 2022-06-20 18:09:47.728988
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    pfinetNet = HurdPfinetNetwork(module)
    class FakeSys(object):
        def __init__(self, link):
            self.link = link
        def readlink(self, path):
            if path == '/servers/socket/inet':
                return '/servers/socket/2'
            if path == '/servers/socket/inet6':
                return '/servers/socket/3'
    class FakeOs(object):
        def __init__(self, link):
            self.link = link
        def path(self, path1, path2):
            if path2 == 'inet' or path2 == 'inet6':
                return True
    module.os = FakeOs('/servers/socket/2')

# Generated at 2022-06-20 18:09:59.539172
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    # Create an instance of class HurdPfinetNetwork
    hurd_network_obj = HurdPfinetNetwork({})
    # Test assign_network_facts method of class HurdPfinetNetwork

# Generated at 2022-06-20 18:10:02.221246
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:10:06.948043
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:10:07.745103
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

# Generated at 2022-06-20 18:10:12.298976
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc.__class__.__name__ == 'HurdNetworkCollector'
    assert hnc.get_facts().__class__.__name__ == 'HurdPfinetNetwork'

# Generated at 2022-06-20 18:10:21.216098
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''Unit test for method populate of class HurdPfinetNetwork'''
    module = FakeModule()
    # FakeModule method run_command will raise RuntimeError if called with this argument
    module.run_command.register_failed_command(['fsysopts'])
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts == {}
    # FakeModule method run_command will return this argument when called with 'fsysopts''

# Generated at 2022-06-20 18:10:22.263511
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert(isinstance(HurdPfinetNetwork(), HurdPfinetNetwork))

# Generated at 2022-06-20 18:10:28.087769
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_class = HurdPfinetNetwork()

    test_class.module = MockModule()
    test_class.module.run_command = Mock(return_value = [0, MOCK_RETURN_VALUE, ''])

    test_class_return = test_class.assign_network_facts({}, '/usr/sbin/fsysopts', '/servers/socket/inet')


# Generated at 2022-06-20 18:10:28.704072
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork()
    assert m

# Generated at 2022-06-20 18:10:46.322039
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleMock:
        def __init__(self, out):
            self.out = out

        def run_command(self, command):
            out, err = self.out, ''
            rc = 0
            return rc, out, err

    # Test case 1: no interface
    module = ModuleMock(
        out="""--foo=bar""",
    )
    network = HurdPfinetNetwork(module)
    network_facts = {
        'interfaces': [],
    }
    expected_network_facts = {
        'interfaces': [],
    }
    path = '/foo/bar/fsysopts'
    socket_path = '/foo/bar/inet'
    actual_network_facts = network.assign_network_facts(network_facts, path, socket_path)

# Generated at 2022-06-20 18:10:57.450355
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    try:
        import StringIO
        StringIO = StringIO.StringIO
    except ImportError:
        import io
        StringIO = io.StringIO

    from ansible.module_utils.facts.network.hurd.facts import HurdPfinetNetwork
    from ansible.module_utils.facts import ModuleTestCase

    network_facts = {}

    fsysopts_path = '/servers/socket/inet'
    socket_path = '/servers/socket/inet6'


# Generated at 2022-06-20 18:11:03.003236
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork

    test_object = HurdPfinetNetwork()
    test_object.module = Mock()

    # Case 1: ansible_fsysopts_path is None
    test_object.module.run_command.return_value = None, None, None

    res = test_object.assign_network_facts(None, None, None)

    assert {} == res

    # Case 2: ansible_fsysopts_path is something

# Generated at 2022-06-20 18:11:04.626931
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()
    assert network.network_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:17.384781
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import ansible.module_utils.facts.network.hurd as module

# Generated at 2022-06-20 18:11:19.554924
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-20 18:11:30.210094
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = type('AnsibleModule', (object,), {'run_command': lambda x, y=None, z=None: (0, "--interface=eth0 --address=192.0.2.1 --netmask=255.255.255.0 --address6=2001:db8::1/64\n", None)})
    network = HurdPfinetNetwork(module)
    network_facts = {}
    network.assign_network_facts(network_facts, 'fsysopts', '/socket/eth0')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-20 18:11:32.495423
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network = HurdPfinetNetwork({'ansible_facts':{'os_family':'GNU'}}, {}, {})
    assert isinstance(hurd_network, HurdPfinetNetwork)

# Generated at 2022-06-20 18:11:35.609953
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})

    assert(network.module is not None)
    assert(network.platform == 'GNU')
    assert(network._socket_dir == '/servers/socket/')

# Generated at 2022-06-20 18:11:40.715659
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork({}).platform == 'GNU'
    assert HurdPfinetNetwork({})._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:11:58.996954
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert hasattr(HurdNetworkCollector, '_platform'), 'Class HurdNetworkCollector does not have attribute _platform'
    assert hasattr(HurdNetworkCollector, '_fact_class'), 'Class HurdNetworkCollector does not have attribute _fact_class'
    assert HurdNetworkCollector._platform == 'GNU', 'Value of HurdNetworkCollector._platform is not "GNU"'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork, 'Value of HurdNetworkCollector._fact_class is not HurdPfinetNetwork'



# Generated at 2022-06-20 18:11:59.799857
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

# Generated at 2022-06-20 18:12:10.655445
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Use tmux to run these tests in parallel since they hang on hurd
    # tmux new-session 'python -m ansible.module_utils.facts.network.gather.network.tests.test_HurdPfinetNetwork'
    # tmux new-window 'python -m ansible.module_utils.facts.network.gather.network.tests.test_HurdPfinetNetwork'

    module = FakeModule()

    network = HurdPfinetNetwork(module)

    fsysopts_path = network.module.get_bin_path('fsysopts')

    socket_path = '/servers/socket/inet'

    network_facts = {
        'interfaces': [],
    }


# Generated at 2022-06-20 18:12:12.108220
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({})
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:12:19.564075
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule({})
    facts = HurdPfinetNetwork(module)
    method = getattr(facts, 'assign_network_facts')
    network_facts = {}
    input_values = ('fsysopts_path','/servers/socket/inet')
    network_facts = method(network_facts, *input_values)
    assert network_facts['lo'] == {
        'active': True,
        'device': 'lo',
        'ipv4': {'address': '127.0.0.1', 'netmask': '255.0.0.0'},
        'ipv6': [{'address': '::1', 'prefix': '128'},
                 {'address': 'fe80::1', 'prefix': '64'}],
    }

# Generated at 2022-06-20 18:12:29.893330
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from collections import Mapping
    from ansible.module_utils.facts import FactCollector
    h = HurdPfinetNetwork()
    assert isinstance(h.get_device(), (list, tuple))
    assert isinstance(h.get_device_info(), Mapping)
    assert h.get_ifconfig_path() is None

    fc = FactCollector(
        module_name='fake_ansible_module',
        module_args=dict(),
        timeout=5,
        executable='/usr/bin/python'
    )
    h.set_module(fc)
    assert h.module.module_name == 'fake_ansible_module'

# Generated at 2022-06-20 18:12:32.986161
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork({}, {}, {})
    assert(m.platform == 'GNU')


# Generated at 2022-06-20 18:12:36.434319
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert issubclass(HurdNetworkCollector, NetworkCollector)
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:12:39.049890
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:12:42.258730
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = None # we don't have a module, this is just for test
    facts = HurdPfinetNetwork(module)
    network_facts = facts.populate()
    print(network_facts) # will print the network facts

# Generated at 2022-06-20 18:13:10.120155
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    result = {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '12.34.56.78',
                'netmask': '255.255.255.0'
            },
            'ipv6': [
                {
                    'address': '2001:db8:8:4::2',
                    'prefix': '64'
                }
            ]
        }
    }

    # FIXME: Don't mock what you don't own

# Generated at 2022-06-20 18:13:11.857516
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    hpn = HurdPfinetNetwork(module)
    assert hpn.interfaces == []
    assert hpn.facts == {'interfaces': []}


# Generated at 2022-06-20 18:13:13.728815
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    h = HurdNetworkCollector()
    assert h.platform == 'GNU'

# Generated at 2022-06-20 18:13:20.219200
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MyModule(object):
        def get_bin_path(self, arg):
            return '/bin/fsysopts'
        def run_command(self, argv):
            return (0,
                    '--interface=/dev/eth0 --address=10.10.10.10 --netmask=255.255.255.0 --broadcast=10.10.10.255 --address6=::/0\n',
                    '')

    class Facts(object):
        def __init__(self):
            self.facts = { 'network': {} }
    facts = Facts()

    n = HurdPfinetNetwork(MyModule)
    n.assign_network_facts(facts.facts['network'], '/bin/fsysopts', '/servers/socket/inet')

# Generated at 2022-06-20 18:13:25.244064
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork(None)
    assert network_facts.device == 'eth0'
    assert network_facts.params['required_one_of'][0] == 'interfaces'
    assert len(network_facts.params['required_one_of']) == 1

# Generated at 2022-06-20 18:13:30.333723
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()

    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:13:41.336884
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module_mock = AnsibleModuleMock()
    fsysopts_path = '/hurd/pfinet'
    socket_path = '/servers/socket/inet'

    network_facts = {
        'interfaces': [],
    }

    # Test IPv4 facts
    module_mock.run_command_output = (0, 'interface=ether0 --address=192.168.1.1 --netmask=255.255.255.0', '')
    nm = HurdPfinetNetwork(module_mock)
    network_facts = nm.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['ether0']

# Generated at 2022-06-20 18:13:52.900246
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = type('', (), {})()
    module.run_command = lambda cmd: (0, '--interface=eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::a00:27ff:febf:765d/64', '')
    network_facts = {}

# Generated at 2022-06-20 18:14:00.148245
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = NetworkCollector.get_network_facts(None, {
        'ANSIBLE_NET_FACT_PATH': os.path.join(os.path.dirname(__file__), 'network_fact_data'),
        'ANSIBLE_NET_CONFIG_PATH': os.path.join(os.path.dirname(__file__), 'network_config_data'),
    }, {})

    assert facts['interfaces'] == ['eth0']
    assert facts['eth0']['device'] == 'eth0'
    assert facts['eth0']['active'] is True
    assert facts['eth0']['ipv4']['address'] == '10.1.2.3'
    assert facts['eth0']['ipv4']['netmask'] == '24'

# Generated at 2022-06-20 18:14:05.605166
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Verify HurdPfinetNetwork object is created successfully
    """
    ansible_module_instance = None
    network = HurdPfinetNetwork(ansible_module_instance)

    assert isinstance(network, Network)
    assert isinstance(network, HurdPfinetNetwork)


# Generated at 2022-06-20 18:14:51.408808
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork("foo", "bar")
    assert network.module.params['gather_subset'] == ['!all', '!min']
    assert network.module._name == 'ansible.module_utils.facts.network.hurd.HurdPfinetNetwork'
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:14:52.184456
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network



# Generated at 2022-06-20 18:14:53.583277
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # TODO: write unit test
    assert False

# Generated at 2022-06-20 18:14:55.526063
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork({}, module="")
    assert m


# Generated at 2022-06-20 18:15:00.370846
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    my_HurdNetworkCollector = HurdNetworkCollector()
    assert my_HurdNetworkCollector._platform is 'GNU'
    assert my_HurdNetworkCollector._fact_class is HurdPfinetNetwork

# Generated at 2022-06-20 18:15:09.169838
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import pytest
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    module = pytest.Mock()
    module.run_command = pytest.Mock()
    module.run_command.return_value = (0, '--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --broadcast=192.168.1.255 --gateway=0.0.0.0 --address6=fe80::47b8:25e0:6d98:6b0a/64', '')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network._facts == network.populate()

# Generated at 2022-06-20 18:15:18.853915
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_arg = {
        '/servers/socket/inet': '''--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=2a00:ff40:f123:300::/64 --address6=fe80::123:456:789:0/64''',
    }

    test = HurdPfinetNetwork()
    test.module = AnsibleModuleFake(**test_arg)
    test.module.run_command = run_command

    result = test.populate()

    assert result['interfaces'] == ['eth0']
    assert result['eth0']['ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-20 18:15:19.941394
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({})
    h.__dict__


# Generated at 2022-06-20 18:15:24.933062
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork('dummy')._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:15:28.946748
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:17:08.488015
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-20 18:17:13.263151
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict())
    assert network
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Collect facts with GNU/Hurd

# Generated at 2022-06-20 18:17:17.518781
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an object of HurdNetworkCollector and verify its attributes
    """
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:17:23.958675
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Python 2.7
    fakemodule1 = type('FakeModule', (), {})
    fakemodule1.get_bin_path = lambda self, x: '/bin/fsysopts'
    fakemodule1.run_command = lambda self, x: (0, '--interface=eth0 --address=192.168.0.15 --netmask=255.255.255.0 --address6=[2001:db8:1f70::999:d123:42:1]/64', '')
    network_facts1 = HurdPfinetNetwork(fakemodule1)

    # Python 3.4
    fakemodule2 = type('FakeModule', (), {})
    fakemodule2.get_bin_path = lambda self, x: '/bin/fsysopts'

# Generated at 2022-06-20 18:17:27.489752
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    def test():
        assert HurdNetworkCollector._platform == 'GNU'
        assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

    test()

# Generated at 2022-06-20 18:17:28.498436
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({})
    assert obj.platform

# Generated at 2022-06-20 18:17:32.228619
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()

    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:17:42.868599
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''Test populate method from class HurdPfinetNetwork'''
    # We need a ModuleUtil instance to use the get_bin_path helper
    class ModuleUtil:
        def __init__(self, module):
            self._module = module

        def get_bin_path(self, bin_name):
            return '/bin/' + bin_name

    # We need a module instance to test the populate method
    class Module:
        # We need a module to mock the run_command method
        def __init__(self):
            self.run_command = lambda x: ([0, None, None], '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe17:f77d/64'.split())


# Generated at 2022-06-20 18:17:45.851601
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # This will fail if no subclasses are registered
    c = HurdNetworkCollector()
    assert c.platform == 'GNU'

# Generated at 2022-06-20 18:17:53.079090
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu_hurd import HurdPfinetNetwork
    class FakeModule():
        def __init__(self):
            self.run_command = None
        def run_command(self, command):
            if command == ['fsysopts', '-L', '/servers/socket/inet']:
                return (0,
                        '--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=fe80::217:e2ff:fe22:3a71/64',
                        '')
            return (0, '', '')
    module = FakeModule()
    network_facts = {}
    fsysopts_path = '/pfinet'
    socket_path = '/servers/socket/inet'
