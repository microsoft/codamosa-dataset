

# Generated at 2022-06-20 18:09:39.826940
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:09:41.574043
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(dict())

    assert h.populate() == {}


# Generated at 2022-06-20 18:09:42.552792
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # FIXME: implement test
    pass

# Generated at 2022-06-20 18:09:54.807742
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils import basic
    from ansible.module_utils.six import StringIO

    class AnsibleModuleMock:
        def __init__(self):
            self.run_command_mock = self.mock_run_command()

        def run_command(self, *args, **kwargs):
            return self.run_command_mock(*args, **kwargs)

        def mock_run_command(self):
            class SideEffect:
                def __call__(self, *args, **kwargs):
                    class Buffer:
                        def __init__(self, data):
                            self.data = data


# Generated at 2022-06-20 18:10:00.057015
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.run_command.return_value = 0, '', ''
    module.get_bin_path.return_value = None

    network_facts = HurdPfinetNetwork(module).populate()

    assert network_facts == {}



# Generated at 2022-06-20 18:10:09.457904
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule
    module.run_command = MagicMock(return_value=[0, "--interface=/dev/eth0 --address=192.168.122.37 --netmask=255.255.255.0 --address6=fe80::c0a8:7a25/64", ""])
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.122.37'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:10:11.978737
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    This is a unit test for testing constructor of class HurdPfinetNetwork.
    """
    # Testing constructor of class HurdPfinetNetwork
    HurdPfinetNetwork(None)

# Generated at 2022-06-20 18:10:15.893805
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    inst = HurdPfinetNetwork({'module': None})

    assert type(inst) == HurdPfinetNetwork
    assert inst._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:10:23.783806
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hostname = 'test-host'
    module = AnsibleModuleMock(subset=['fsysopts'], redhat_release='')
    module.run_command = run_command_mock
    network_facts = {}
    network_facts['local'] = {}
    network_facts['local']['hostname'] = hostname
    network_facts['all_ipv4_addresses'] = []
    network_facts['all_ipv6_addresses'] = []
    network = HurdPfinetNetwork(module, network_facts)
    network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['active'] is True

# Generated at 2022-06-20 18:10:36.285271
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule()

    class FakeFile(object):
        def __init__(self, f):
            self.f = f

    with open('tests/unit/module_utils/facts/network/linux/assign_network_facts.test') as f:
        assign_network_facts = HurdPfinetNetwork(module).assign_network_facts
        network_facts = {}
        network_facts = assign_network_facts(network_facts, '', '', FakeFile(f))
        f.close()


# Generated at 2022-06-20 18:10:49.452878
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """Unit test for method assign_network_facts of class HurdPfinetNetwork."""

    class FakeModule(object):
        """Fake ansible Module object."""

        def __init__(self, *args, **kwargs):
            self.run_command = kwargs.get('run_command', None)

    class FakeArgs(object):
        """Fake ansible Module argument object."""

        def __init__(self):
            self.check_invalid_arguments = None
            self.fail_on_missing_params = None


# Generated at 2022-06-20 18:10:53.069266
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj is not None


# Generated at 2022-06-20 18:11:05.661642
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import os
    import tempfile

    test_dir = tempfile.mkdtemp()

    # Write a fake socket in test directory
    socket_dir = os.path.join(test_dir, 'servers', 'socket')
    os.makedirs(socket_dir)

    test_socket = os.path.join(socket_dir, 'inet')
    with os.fdopen(os.open(test_socket, os.O_RDWR | os.O_CREAT | os.O_TRUNC, 0o644), 'w+') as f:
        f.write("""--interface=eth0
--address=192.168.0.5
--netmask=255.255.255.0
--address6=fe80::dead::beef::5/64""")

    # Write a fake fsys

# Generated at 2022-06-20 18:11:10.719996
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Test constructor of class HurdNetworkCollector"""
    if not NetworkCollector.registered_collectors:
        NetworkCollector.load_collectors()

    assert HurdPfinetNetwork.__name__ in NetworkCollector.registered_collectors

# Generated at 2022-06-20 18:11:15.091722
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test the constructor of HurdNetworkCollector class
    :return:
    """
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:28.036876
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fake_module = type('module', (), {'run_command': lambda self, args: (0, '--address=192.168.2.2 --netmask=255.255.255.0 --address6=fc00::/64', '')})
    network_facts = HurdPfinetNetwork(fake_module).populate()


# Generated at 2022-06-20 18:11:32.014069
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:11:40.747266
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    res = HurdPfinetNetwork.populate(module)

    assert res['interfaces'] == ['eth0', 'eth1']
    eth0 = res['eth0']
    assert eth0['active'] == True
    assert eth0['device'] == 'eth0'
    assert eth0['ipv4']['address'] == '192.168.1.1'
    assert eth0['ipv4']['netmask'] == '255.255.255.0'
    assert eth0['ipv6'][0]['address'] == 'fe80::a00:27ff:fe91:d60'
    assert eth0['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-20 18:11:48.712081
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # The instantiation of AnsibleModule and AnsibleModule's params are mocked by AnsibleModuleMock
    # The AnsibleModuleMock is used to test the constructor of class HurdPfinetNetwork
    class AnsibleModuleMock(object):
        def __init__(self, dict):
            self.params = dict

        def get_bin_path(self, path):
            self.bin_path = path
            if path == 'fsysopts':
                return '/hurd/fsysopts'
            else:
                return None

        def run_command(self, command):
            self.command = command

# Generated at 2022-06-20 18:11:51.402984
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpn = HurdPfinetNetwork('/dev/null')
    assert isinstance(hpn, Network)

# Generated at 2022-06-20 18:12:04.268009
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc.platform == "GNU"

# Generated at 2022-06-20 18:12:12.430545
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network = HurdPfinetNetwork({'ansible_facts': {}})
    def run_command(cmd):
        out_file = '../fixtures/ansible_facts/network_Hurd_pfinet.fsysopts'
        with open(out_file, 'r') as f:
            out = f.read()
        return 0, out, ''
    network.module.run_command = run_command
    result = network.populate()

    assert result['interfaces'] == ['eth0']

    assert 'eth0' in result
    assert result['eth0']['device'] == 'eth0'
    assert result['eth0']['active'] is True
    assert 'ipv4' in result['eth0']
    assert 'ipv6' in result['eth0']


# Generated at 2022-06-20 18:12:20.672980
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = '/bin/fsysopts'

    # A complete test, everything is set and working as designed
    test_data = """[--interface=eth0]
[--address=192.168.0.4]
[--netmask=255.255.255.0]
[--broadcast=192.168.0.255]
[--address6=fe80::4d6e:c6ff:fe01:af77/64]
[--address6=dead:beef::1234/64]"""
    test_socket_path = '/servers/socket/inet'

# Generated at 2022-06-20 18:12:31.418399
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    This is a unit test for HurdPfinetNetwork.populate.
    """
    # Setup testcase.
    import platform
    os.environ['PATH'] = '/sbin'
    module = AnsibleModuleMock()
    class_under_test = HurdPfinetNetwork(module)
    # Mock the platform.uname()
    platform.uname = lambda: ('GNU', 'Arcturus', '0.3-637-g9305e8b', '#29-Ubuntu SMP Wed Aug 7 15:32:06 UTC 2013', 'i686-pc-gnu')
    module.run_command = lambda args, check_rc=True: (0, '', '')
    # Mock the os.path.exists()
    os.path.exists = lambda path: True
    # Mock the

# Generated at 2022-06-20 18:12:32.417175
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    test_obj = HurdNetworkCollector()
    assert test_obj._platform == 'GNU'


# Generated at 2022-06-20 18:12:36.398633
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork('module')
    assert isinstance(obj, HurdPfinetNetwork)
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:12:42.508615
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Normally this would be supplied by AnsibleModule
    module = type('DummyModule', (object,), dict(run_command=lambda *args, **kwargs: (0, '', '')))()

    # Normally this would be a subclass of AnsibleModule
    class DummyGNU(object):
        pass

    facts = DummyGNU()
    facts.ansible_module = module
    facts.network = HurdPfinetNetwork(facts)

    # Create a stub for fsysopts
    def stub_run_command(*args, **kwargs):
        if args == ('/hurd/fsysopts', '-L', '/servers/socket/inet'):
            return (0, """\
interface=--interface
address=--address
netmask=--netmask
address6=--address6
""", '')


# Generated at 2022-06-20 18:12:45.927658
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.platform == 'GNU'
    assert network_collector.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-20 18:12:58.264781
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    n = HurdPfinetNetwork(module)

    # create fake fsysopts, socket and interface
    # module.run_command return a triplet (rc, out, err), here we return
    # the content of fsysopts as out and an empty string as err
    fsysopts_path = '/usr/bin/fsysopts'
    module_map = {
        'run_command.return_value': (0, "--addr=/dev/eth0 --address=192.168.1.14 --address6=2001:db8:1::1/64 --netmask=255.255.255.0", "")
    }
    module.params = {}

# Generated at 2022-06-20 18:13:07.724462
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    h = HurdPfinetNetwork(module)
    fsysopts_path = '/sbin/fsysopts'
    socket_path = '/servers/socket/inet'

# Generated at 2022-06-20 18:13:37.975415
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network import Network, NetworkCollector
    import ansible.module_utils.facts.network.base
    import ansible.module_utils.facts.network.linux
    import ansible.module_utils.facts.network.bsd
    import ansible.module_utils.facts.network.generic

    module = FakeModule()

    #module.run_command.return_value = (0, '', '')

# Generated at 2022-06-20 18:13:38.790573
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

# Generated at 2022-06-20 18:13:45.110094
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    def get_bin_path(path):
        return '/bin/path'

    def run_command(command):
        return 0, '', ''

    module = type('SysModule', (object,), {
        'get_bin_path': classmethod(get_bin_path),
        'run_command': run_command,
    })()

    facts = {
        'interface': 'eth0',
        'address': '192.168.1.1',
        'netmask': '255.255.255.0',
        'address6': '2607:f0d0:1002:0051:0000:0000:0000:0004/64',
    }

    input_network_facts = {}


# Generated at 2022-06-20 18:13:57.210731
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    test the method assign_network_facts of class HurdPfinetNetwork
    """
    network_facts = {}
    # test assign_network_facts with fake facts
    fsysopts_path = "fsysopts"
    socket_path = "socket"
    network_facts['interfaces'] = []
    for i in "--interface=/dev/eth0 --address=192.0.2.0 --netmask=255.255.255.0 --address6=2001:db8::/64".split():
        if '=' in i and i.startswith('--'):
            k, v = i.split('=', 1)
            # remove '--'
            k = k[2:]

# Generated at 2022-06-20 18:14:00.619020
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()
    assert network._platform == 'GNU'
    assert network._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:04.075766
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact = HurdNetworkCollector()
    assert fact.platform == 'GNU'
    assert fact._fact_class is HurdPfinetNetwork

# Generated at 2022-06-20 18:14:13.402416
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    # Test that populate() fails if fsysopts is not installed
    def side_effect_module_run_command_fsysopts_missing(self, params):
        if 'fsysopts -L' in params:
            return 1, '', ''

    def side_effect_module_get_bin_path_fsysopts_missing(self, name):
        if name == 'fsysopts':
            return None

    def side_effect_os_path_exists_fsysopts_missing(self, name):
        if name == 'servers/socket/inet':
            return True


# Generated at 2022-06-20 18:14:24.335244
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()

    def fake_fsysopts(module, socket_path):
        out = '''--interface=/dev/eth0
        --address=192.168.1.2
        --netmask=255.255.255.0
        --address6=fe80::cafebabe/64
        '''
        return 0, out, ''

    def fake_fsysopts_no_inet(module):
        return None, '', ''

    module.run_command = fake_fsysopts

    f = HurdPfinetNetwork(module)
    eth0 = f.populate()['interfaces'][0]
    assert eth0 == 'eth0'
    assert f['eth0']['ipv4']['address'] == '192.168.1.2'

# Generated at 2022-06-20 18:14:34.213386
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """Unit test for method assign_network_facts"""
    network_facts = {
        'interfaces': [],
    }
    fsysopts_path = '/server/socket/'
    socket_path = 'inet'

    module = MockModule()
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']



# Generated at 2022-06-20 18:14:47.601096
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    facter_instance = HurdPfinetNetwork(module)

    network_facts = facter_instance.assign_network_facts(
        {'interfaces': []}, "fsysopts_path", "/servers/socket/inet")

    assert len(network_facts['interfaces']) == 2
    assert len(network_facts['eth0']['ipv4']) == 2
    assert network_facts['eth0']['ipv4']['address'] == '192.168.178.20'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert len(network_facts['eth0']['ipv6']) == 2


# Generated at 2022-06-20 18:15:39.842969
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.generic import assign_network_facts
    _assign_network_facts = HurdPfinetNetwork(dict()).assign_network_facts
    test_data = '''--interface=eth0 --address=192.168.0.1 --netmask=255.255.255.0
--interface=eth1 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8:1:1::1/64
'''
    facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    assign_network_facts(facts, test_data, 'lo', 'Ethernet', False, None, None, 'GNU')
    _

# Generated at 2022-06-20 18:15:43.184588
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:15:53.071479
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import mock

    # Change this to your own module.
    class MockModule:
        """
        Mock module.
        """
        def __init__(self):
            ansible_module_facts = dict()
            ansible_module_facts['ansible_facts'] = dict()
            self.ansible_module_facts = ansible_module_facts

        def get_bin_path(self, tool, opts=None):
            return '/usr/bin/fsysopts'

        def run_command(self, command_line, check_rc=True):
            """
            Mock the module.run_command method.
            """

# Generated at 2022-06-20 18:15:54.238409
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert isinstance(HurdPfinetNetwork(), HurdPfinetNetwork)



# Generated at 2022-06-20 18:15:56.171480
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network is not None

# Generated at 2022-06-20 18:16:01.265882
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fake_module = type('FakeModule', (), {'run_command': lambda self, args: (0, '', '')})()
    fake_module.get_bin_path = lambda self, name: None
    h = HurdPfinetNetwork(module=fake_module)
    assert h.populate() == {}

    fake_module.get_bin_path = lambda self, name: 'fsysopts'

    fake_module.run_command = lambda self, args: (0,
                                                  '--interface=/dev/eth0 --address=192.168.0.42 --netmask=255.255.255.0 --address6=::1/0 --address6=fe80::3/64 --address6=2002::1/0',
                                                  '')

# Generated at 2022-06-20 18:16:12.026396
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class TestModule():
        def run_command(self, cmd):
            return ('fsysopts', '--interface=pfinet --address=127.0.0.1 --netmask=255.255.255.255', '')
    class TestNetwork(HurdPfinetNetwork):
        def __init__(self, module):
            self.module = module
    module = TestModule()
    test = TestNetwork(module)
    result = test.assign_network_facts({}, 'fsysopts', '/servers/socket/inet')
    assert result['interfaces'] == ['pfinet']
    assert result['pfinet']['device'] == 'pfinet'
    assert result['pfinet']['active'] == True

# Generated at 2022-06-20 18:16:22.620880
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module_mock = DummyModule()
    network_obj = HurdPfinetNetwork(module_mock)
    network_facts = {}
    network_obj.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert 'interfaces' in network_facts
    assert 'ipv6' in network_facts['eth0']
    assert 'ipv4' in network_facts['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:16:24.364706
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test with Hurd.
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork
    assert obj._fact_class.platform == 'GNU'



# Generated at 2022-06-20 18:16:24.958958
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork(dict())

# Generated at 2022-06-20 18:18:13.841240
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    np = HurdPfinetNetwork(module)
    assert np.platform == 'GNU'
    assert np._socket_dir == '/servers/socket/'
    assert np.module is module

# Generated at 2022-06-20 18:18:17.222953
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd_pfinet import HurdPfinetNetwork as My_class
    my_obj = My_class(None)
    assert my_obj


# Generated at 2022-06-20 18:18:30.367265
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import os
    import tempfile
    from collections import namedtuple

    # Sample output of fsysopts -L /servers/socket/inet
    sample_output = '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0'

    # Helper so we can run an instance method as a test case
    class _RunMethod(object):
        def __init__(self, obj, method, args):
            self.obj = obj
            self.method = method
            self.args = args

        def __call__(self, *args, **kwargs):
            return getattr(self.obj, self.method)(*self.args)

    # Set up the module_utils
    MockModule = namedtuple('MockModule', ['run_command'])
    module_

# Generated at 2022-06-20 18:18:42.513782
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # gather facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.linux.distro import LinuxDistroNetwork
    from ansible.module_utils.facts.network.openbsd.pf import OpenBSDpfNetwork
    from ansible.module_utils.facts.network.netbsd.sysctl import NetBSDsysctlNetwork
    from ansible.module_utils.facts.network.freebsd.sysctl import FreeBSDsysctlNetwork
    from ansible.module_utils.facts.network.freebsd.rtsold import FreeBSDrtsoldNetwork

# Generated at 2022-06-20 18:18:45.512579
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector class
    """
    HurdNetworkCollector()


# Generated at 2022-06-20 18:18:48.149129
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
  assert HurdPfinetNetwork is not None, "Failed to find HurdPfinetNetwork class"

# Generated at 2022-06-20 18:18:50.376331
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hn = HurdNetworkCollector()
    assert hn is not None
    assert hn._platform == 'GNU'
    assert hn._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:18:58.836263
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # FIXME: more thorough unit testing
    facts = HurdPfinetNetwork().populate()
    assert 'lo' in facts.keys()
    assert isinstance(facts['lo'], dict)
    assert isinstance(facts['lo']['ipv4'], dict)
    assert isinstance(facts['lo']['ipv6'], list)
    assert 'active' in facts['lo']
    assert 'device' in facts['lo']
    # assert 'interfaces' in facts.keys()

# Generated at 2022-06-20 18:19:03.579566
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# FIXME: tests for assign_network_facts

# Generated at 2022-06-20 18:19:07.989638
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork
