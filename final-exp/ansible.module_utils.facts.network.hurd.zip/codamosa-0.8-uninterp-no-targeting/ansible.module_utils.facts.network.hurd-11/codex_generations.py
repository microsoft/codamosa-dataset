

# Generated at 2022-06-20 18:09:45.626118
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test without any network interface
    network_facts = {}
    ipv6_enabled = False
    network_facts = HurdPfinetNetwork.assign_network_facts(network_facts, '', '')
    assert network_facts == {'interfaces': []}

    # test with only one interface (eth0 with ipv4)
    network_facts = {'interfaces': []}
    ipv6_enabled = False
    network_facts = HurdPfinetNetwork.assign_network_facts(network_facts, '', '--interface=/dev/eth0 --address=192.168.1.10 --netmask=255.255.255.0')

# Generated at 2022-06-20 18:09:47.572834
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """ test assign_network_facts method of class HurdPfinetNetwork """
    # FIXME: implement test
    return True

# Generated at 2022-06-20 18:09:50.485965
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_info = HurdPfinetNetwork({'module': None})
    assert network_info.platform == 'GNU'
    assert network_info._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:09:59.122326
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    This is a unit test for assign_network_facts method of class HurdPfinetNetwork.
    It test the return value of the method with a different inputs.
    '''
    network = HurdPfinetNetwork()
    output = network.assign_network_facts({}, None, None)
    assert output == {}
    output = network.assign_network_facts({}, '', '')
    assert output == {}
    output = network.assign_network_facts({}, '/foo', '/bar')
    assert output == {}

# Generated at 2022-06-20 18:10:08.513966
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = {'interfaces': [],
             'all_ipv4_addresses': [],
             'all_ipv6_addresses': []}
    fsysopts_path = 'bin/fsysopts'
    socket_path = 'path/to/inet/socket/file'
    class MockModule:
        def run_command(self, arg):
            return (0, '--interface=eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=2001:db8:0:f101::1/64 --address6=2001:db8:0:f101::1/64', '')

    class MockNetwork(HurdPfinetNetwork):
        def __init__(self, hostname=None):
            self.module = MockModule()


# Generated at 2022-06-20 18:10:12.047466
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector.__module__ == 'ansible.module_utils.facts.network.gnu_hurd.pfinet'
    assert HurdNetworkCollector._platform == 'GNU'
    c = HurdNetworkCollector()
    assert type(c) == HurdNetworkCollector


# Generated at 2022-06-20 18:10:15.326304
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Test creation of a HurdNetworkCollector object"""

    hurd_network_collector = HurdNetworkCollector()
    assert isinstance(hurd_network_collector, HurdNetworkCollector)


# Generated at 2022-06-20 18:10:19.147949
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_net = HurdPfinetNetwork(dict())
    assert isinstance(hurd_net, HurdPfinetNetwork)
    assert hurd_net.platform == 'GNU'

# Generated at 2022-06-20 18:10:22.972768
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    k = HurdNetworkCollector()
    assert k.__class__.__name__ == 'HurdNetworkCollector'

# Unit test to check if the class HurdNetworkCollector can be instantiated

# Generated at 2022-06-20 18:10:35.793912
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    class MyMockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.exit_json_calls = []
            self.fail_json_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            if command[-1] == 'eth0':
                return 0, """--interface=/dev/eth0 --address=192.168.45.10 --netmask=255.255.255.0 --address6=fe80::223:aff:fe22:440d/64 --address6=2804:14d:2e2d:4c4::2/64""", ''


# Generated at 2022-06-20 18:10:44.592243
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = None
    facts = HurdPfinetNetwork(module)
    assert facts.platform == 'GNU'
    assert facts._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:10:47.833264
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector(None)
    assert type(hnc) == HurdNetworkCollector


# Generated at 2022-06-20 18:10:58.139574
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Create a fake module.
    from ansible.module_utils.basic import AnsibleModule, ModuleDeprecationWarning
    from warnings import simplefilter
    import sys
    simplefilter("ignore", ModuleDeprecationWarning)

    class FakeModule(AnsibleModule):
        def __init__(self, **kwargs):
            self.result = dict(changed=False)
            self.params = {}
            super(FakeModule, self).__init__(**kwargs)

        def exit_json(self, **kwargs):
            self.exit_args = kwargs
            sys.exit(0)

        def fail_json(self, **kwargs):
            self.fail_args = kwargs
            sys.exit(1)

    module = FakeModule(argument_spec={})

# Generated at 2022-06-20 18:11:01.807689
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    try:
        HurdPfinetNetwork().populate(collected_facts=None)
    except ImportError:
        # This can happen on non Hurd platform
        assert True

# Generated at 2022-06-20 18:11:09.769980
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    import json
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(
        argument_spec={},
    )


# Generated at 2022-06-20 18:11:10.166269
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-20 18:11:15.487939
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()

    # An empty result is expected as there is no pfinet installed
    result = {}
    hn = HurdPfinetNetwork(module)
    assert hn.populate() == result

    # An empty result is expected as there is no pfinet installed
    result = {}
    hn = HurdPfinetNetwork(module, '/dev/null')
    assert hn.populate() == result

    # An empty result is expected as there is no pfinet installed
    result = {}
    hn = HurdPfinetNetwork(module, 'echo')
    assert hn.populate() == result

    # A non empty result is expected

# Generated at 2022-06-20 18:11:18.200569
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork(dict())
    assert network_facts.platform == 'GNU'

# Generated at 2022-06-20 18:11:21.654132
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    testobj = HurdNetworkCollector()
    assert testobj._platform == 'GNU'
    assert testobj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:30.587763
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Prerequisites for a successful run
    #  - The module is run/called from GNU Hurd
    #  - fsysopts is installed so that it can be used to get ip address
    #    of interfaces.

    # FIXME: For now, find if fsysopts is in path and run tests only if it is present
    fsysopts_path = '/usr/bin/fsysopts'
    if os.path.exists(fsysopts_path):
        network_facts = {}
        network = HurdPfinetNetwork(None)
        network.assign_network_facts(network_facts, fsysopts_path, '/servers/socket/inet')

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 18:11:45.921954
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:11:58.622139
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda *args, **kwargs: (0, ['--interface=/dev/eth0', '--address=127.0.0.1', '--netmask=255.0.0.0', '--address6=::1/128'])
            self.get_bin_path = lambda *args: '/servers/socket/inet'
            self.get_bin_path.__name__ = 'get_bin_path'
    module = DummyModule()
    obj = HurdPfinetNetwork(module)
    assert obj.populate()['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:12:10.052179
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = get_module_mock({})
    network = HurdPfinetNetwork(module)

    # no fsysopts
    network.module.get_bin_path.return_value = None
    assert network.populate() == {}

    # no inet or inet6
    network.module.get_bin_path.return_value = 'fsysopts'
    network._socket_dir = './testdir'
    assert network.populate() == {}

    # inet exist but no interfaces
    network.module.get_bin_path.return_value = 'fsysopts'
    network.module.run_command.return_value = (0, '', '')
    network._socket_dir = './testdir'
    os.path.exists = lambda x: True
    assert network.populate

# Generated at 2022-06-20 18:12:13.551546
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == 'GNU'
    assert HurdPfinetNetwork()._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:12:16.413468
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:12:18.394270
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = None
    # FIXME: implement
    assert False

# Generated at 2022-06-20 18:12:21.548080
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert HurdPfinetNetwork is collector._fact_class

# Generated at 2022-06-20 18:12:25.840919
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    network = HurdPfinetNetwork(module)

    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:12:28.122077
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None


# Generated at 2022-06-20 18:12:39.267214
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.generic_bsd import GenericBsdIfconfigNetwork
    from ansible.module_utils.facts.network.linux import LinuxDfNetwork
    import tempfile

    fd, fd_path = tempfile.mkstemp()

    out = '''--interface=eth0
--address=192.168.0.1
--netmask=255.255.255.0
--address6=2001:db8:1::1/64
--address6=fe80::21c:42ff:fe02:3c32/64'''

    network_facts = {}
    network_facts['interfaces'] = []

# Generated at 2022-06-20 18:13:02.892365
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector(None)
    assert isinstance(collector._fact_class, HurdPfinetNetwork)
    assert collector._platform == 'GNU'

# Generated at 2022-06-20 18:13:06.845922
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all'], type='list'),
        'filter': dict(default='', type='str'),
    }, supports_check_mode=True)

    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts == {}

# Generated at 2022-06-20 18:13:17.747954
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_facts = HurdPfinetNetwork().populate()

    # test ipv4
    assert 'interfaces' in network_facts
    assert 'eth0' in network_facts['interfaces']
    assert 'eth0' in network_facts
    assert 'ipv4' in network_facts['eth0']
    assert 'address' in network_facts['eth0']['ipv4']
    assert 'netmask' in network_facts['eth0']['ipv4']

    # test ipv6
    assert 'ipv6' in network_facts['eth0']
    assert 'address' in network_facts['eth0']['ipv6'][0]
    assert 'prefix' in network_facts['eth0']['ipv6'][0]

# Generated at 2022-06-20 18:13:20.340228
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-20 18:13:30.278523
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    os.makedirs(tmpdir + '/servers/socket/inet')
    o = open(tmpdir + '/servers/socket/inet', 'w')
    o.write('/dev/eth0')
    o.close()
    o = open(tmpdir + '/dev/eth0', 'w')
    o.write('/servers/socket/14/0')
    o.close()
    os.symlink('/lib/libc.so.0.3', tmpdir + '/lib/libc.so.0')
    os.symlink('/lib/libc.so.0', tmpdir + '/lib/libc.so')
    os.makedirs(tmpdir + '/hurd')

# Generated at 2022-06-20 18:13:39.867619
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.base import Network
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/unknown'
    network = Network()
    network._socket_dir = '/servers/socket/'

    network.run_command = lambda x: (0, ('--interface=/dev/eth0 --address=10.0.0.101 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe12:78ab/64 --address6=fe80::5054:ff:fe12:78ac/64'), '')
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert network_facts['interfaces']

# Generated at 2022-06-20 18:13:49.940607
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    hostname = 'gnu'
    l_fake_socket = ['inet', 'inet6']
    l_fake_net = ['lo', 'eth0', 'eth1']
    l_fake_net6 = ['lo', 'eth0', 'eth1']
    m_fake_fsysopts = ('fsysopts', '-L', '/servers/socket/inet6', '--interface=/dev/eth0', '--address=10.10.10.10', '--netmask=255.255.255.0', '--interface=/dev/eth1', '--address6=fe80::1/64', '--address6=fe80::2/64', '--address6=fe80::3/64')

# Generated at 2022-06-20 18:13:53.916433
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    This will test the constructor of HurdNetworkCollector.
    :return:
    """
    networkcollector = HurdNetworkCollector()
    assert networkcollector, "NetworkCollector object not created"


# Generated at 2022-06-20 18:14:00.436441
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    mock_module = Mock(
        run_command=Mock(
            return_value=(
                0,
                """
--interface=eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=fe80::5c5c:ff:fe29:f3b3/64
--address6=2a02:8071:4b4:2287:a5b:8f23:9178:9f3c/64
""",
                ""
            )
        )
    )
    pfinet_facts = HurdPfinetNetwork()
    pfinet_facts.module = mock_module
    network_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'

# Generated at 2022-06-20 18:14:11.295874
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = Mock()
    module.run_command.return_value = (0, "--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8::1/64", '')

    # load module_utils/facts/network/gnu.py
    m_gnu = __import__('ansible.module_utils.facts.network.gnu', globals(), locals(), ['object'], 0)
    # create a new global module object
    g = type.__new__(type, "ansible_gnu_mock")
    g.__module__ = __name__
    g.module = module
    sys.modules['ansible.module_utils.facts.network.gnu'] = g

    # Create a new instance of HurdPfinetNetwork
    obj

# Generated at 2022-06-20 18:15:07.829597
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module_args = dict()
    module = FakeModule(module_args)
    network = HurdPfinetNetwork(module=module)
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts != {}
    assert network_facts['eth0']['ipv4']['address'] == '127.0.0.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.0.0.0'

# Generated at 2022-06-20 18:15:11.434944
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({}, None)
    assert isinstance(obj, HurdPfinetNetwork)


# Generated at 2022-06-20 18:15:23.337568
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch

    # import module
    import ansible_collections.ansible.community.plugins.module_utils.network.common.network

    module = MagicMock(name='Module')
    fsysopts_path = ansible_collections.ansible.community.plugins.module_utils.network.common.network.HurdPfinetNetwork.module.get_bin_path('fsysopts')
    module.run_command = MagicMock(return_value=(0, '--address=192.168.0.1 --netmask=255.255.255.0', ''))

    # set up class
    _network

# Generated at 2022-06-20 18:15:26.527917
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hud = HurdPfinetNetwork()
    assert hud.platform == 'GNU'
    assert hud._socket_dir == '/servers/socket/'
    return hud

# Smoke test for constructor of class HurdPfinetNetwork

# Generated at 2022-06-20 18:15:28.589017
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector

# Generated at 2022-06-20 18:15:34.059628
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector.__name__ == 'HurdNetworkCollector'
    assert HurdNetworkCollector._fact_class._platform == 'GNU'
    assert HurdNetworkCollector._fact_class.__name__ == 'HurdPfinetNetwork'

# Generated at 2022-06-20 18:15:40.327047
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_collector = HurdNetworkCollector()
    network_facts = network_collector.populate_network_facts(None)
    assert isinstance(network_facts['interfaces'], list)
    assert isinstance(network_facts['interfaces'][0], str)
    assert isinstance(network_facts['interfaces'][0], str)
    assert isinstance(network_facts[network_facts['interfaces'][0]], dict)
    assert isinstance(network_facts[network_facts['interfaces'][0]]['ipv4'], dict)

# Generated at 2022-06-20 18:15:48.396772
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import ModuleFactsService
    from ansible.module_utils.facts.collector.network.base import Network

    module_base = ModuleFactsService(
        module=None,
        runner=None,
        suboption='',
        configfile='non-existent',
    )

    net = HurdPfinetNetwork(module_base)
    assert net is not None
    assert isinstance(net, Network)
    assert net.platform == 'GNU'

# Generated at 2022-06-20 18:15:51.636669
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert isinstance(network, HurdPfinetNetwork)


# Generated at 2022-06-20 18:15:56.173217
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork

    x = HurdPfinetNetwork({})
    assert x.get_platform() == "GNU"

# Generated at 2022-06-20 18:17:57.668326
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Test method populate of class HurdPfinetNetwork
    """
    n = HurdPfinetNetwork()
    n.module.run_command = lambda x: (0, '--interface=eth0 --address=192.168.10.1 --netmask=255.255.255.0 --mtu=1500 --address6=fe80::215:5dff:fe12:b301/64 --address6=2a00:1450:4839:0908:215:5dff:fe12:b301/64 --address6=2a00:1450:4839:0908::1/64', '')

# Generated at 2022-06-20 18:18:10.090758
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0 --address6=::1/128 --address6=fe80::b55f:3035:57ce:6073/64', ''))
    i = HurdPfinetNetwork(module)
    i.assign_network_facts({}, '/bin/fsysopts', '/servers/socket/inet')
    assert module.run_command.called
    assert module.run_command.call_args == call(['/bin/fsysopts', '-L', '/servers/socket/inet'])

# Generated at 2022-06-20 18:18:19.681773
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import tempfile

    module_args = dict(
        gather_subset=[],
    )
    required_if = [
        ['gather_subset', 'all', ['gather_network_resources']],
        ['gather_network_resources', 'all', ['gather_subset']],
    ]
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            gather_network_resources=dict(default='all', type='list'),
        ),
        required_if=required_if,
    )

    facts = dict()
    network_collector = HurdNetworkCollector(module=module)
    result = network_collector.populate()


# Generated at 2022-06-20 18:18:24.173617
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector
    """
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:18:32.644414
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec=dict())
    networks = HurdPfinetNetwork()
    networks.module = module
    module.run_command = mock.Mock(side_effect=[(0, to_bytes('--interface=/dev/eth0 --address=10.57.12.163 --netmask=255.255.255.0'), ''),
                                                (0, to_bytes('--interface=/dev/eth1 --address=10.57.12.162 --netmask=255.255.255.0'), '')])
    network_facts = {'interfaces': ['eth0', 'eth1']}

# Generated at 2022-06-20 18:18:34.547803
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork({}, {}, {}, {})

# Generated at 2022-06-20 18:18:43.902925
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # pylint: disable=too-few-public-methods
    # this class is intended to be used with the HurdPfinetNetwork class only
    class MockModule:
        def __init__(self):
            self.rc = 0
            self.out = None
            self.err = None

        def run_command(self, args):
            return self.rc, self.out, self.err

    # pylint: disable=invalid-name
    class MockFacts:
        def __init__(self):
            self.ansible_interfaces = []

    network_facts = MockFacts()

    # Test default case: no interfaces
    m = MockModule()
    h = HurdPfinetNetwork(m)

# Generated at 2022-06-20 18:18:46.482537
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_network = HurdPfinetNetwork()
    assert hurd_network.platform == 'GNU'
    assert isinstance(hurd_network._socket_dir, str)
    assert hurd_network._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:18:48.564131
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork(dict(module=None))
    assert network_facts.interfaces == []


# Generated at 2022-06-20 18:18:52.264130
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = HurdPfinetNetwork()
    assert module.platform == 'GNU'
    assert module._socket_dir == '/servers/socket/'
