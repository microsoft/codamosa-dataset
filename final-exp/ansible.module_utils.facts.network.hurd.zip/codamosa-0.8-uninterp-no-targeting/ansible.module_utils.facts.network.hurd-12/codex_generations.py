

# Generated at 2022-06-20 18:09:45.625516
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = {
        'interfaces': [],
        'pfinet': {
            'interfaces': [],
        }
    }
    network = HurdPfinetNetwork({}, facts)
    network._socket_dir = '/socket_dir/'
    network.assign_network_facts(facts['pfinet'], '/fsysopts', '/socket/inet')
    print(facts)

# Generated at 2022-06-20 18:09:49.119234
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''
    Constructor of class HurdPfinetNetwork
    '''

    obj = HurdPfinetNetwork({})
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:09:51.920983
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_facts = HurdNetworkCollector(None)
    assert network_facts._fact_class
    assert network_facts._fact_class.platform == 'GNU'



# Generated at 2022-06-20 18:09:54.349734
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hc = HurdNetworkCollector()
    assert hc._platform == 'GNU'
    assert hc._fact_class is HurdPfinetNetwork

# Generated at 2022-06-20 18:09:56.435246
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:10:07.076636
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Unit test for constructor of class HurdPfinetNetwork
    """
    # Find and remove if gnu hurd file exists in module_utils/facts/network
    hurd_pfinet_network_file = os.path.join(os.path.expanduser('~'), '.ansible_module_generated')
    if os.path.exists(hurd_pfinet_network_file):
        os.remove(hurd_pfinet_network_file)

    # Create instance of HurdPfinetNetwork
    pfinet_network = HurdPfinetNetwork(module=None)

    # Check if the socket_path is same as the path in which it has to be
    assert pfinet_network._socket_dir == '/servers/socket/'

    # Check if platform returned by the HurdPfinetNetwork

# Generated at 2022-06-20 18:10:09.580711
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    args = {
        'fsysopts_path': 'path_to_fsysopts',
        'socket_path': 'path_to_socket',
    }
    HurdPfinetNetwork(None, args)

# Generated at 2022-06-20 18:10:10.616163
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({'module': True})
    assert obj.platform == "GNU"
    assert isinstance(obj, HurdPfinetNetwork)

# Generated at 2022-06-20 18:10:16.678123
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import pytest
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network

    network = HurdPfinetNetwork(pytest.Mock())
    network.module.get_bin_path = lambda x: 'fsysopts'
    network.module.run_command = lambda x: (0, '--address=192.168.1.1 --netmask=255.255.255.0', '')
    assert isinstance(network, Network)

# Generated at 2022-06-20 18:10:27.022787
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.params['gather_subset'] = ['!all', '!min']
    output = {
        'interfaces': ['hurdif0'],
        'hurdif0': {
            'active': True,
            'device': 'hurdif0',
            'ipv4': {
                'address': '192.168.1.1',
                'netmask': '255.255.255.0'
            },
            'ipv6': [
                {
                    'address': 'ffff::ffff:ffff',
                    'prefix': '64'
                }
            ]
        }
    }
    obj = HurdPfinetNetwork(module)

# Generated at 2022-06-20 18:10:47.163796
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test with only one interface in /servers/socket/inet
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0,
                                                 '--interface=/dev/eth0 --address=192.168.0.2 --netmask=255.255.255.0 --broadcast=192.168.0.255 ',
                                                 ''))
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_collector = HurdPfinetNetwork(module)
    network_facts = network_collector.assign_network_facts({}, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:10:57.836178
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile

    tmpdir = tempfile.mkdtemp()
    module = type('test_module', (object,), {
        'get_bin_path': lambda s, x: '/bin/true',
        'run_command': lambda s, x: ('1', '--interface=eth0 --address=192.168.1.1 --netmask=255.255.255.0', None),
    })
    m = HurdPfinetNetwork(module)
    os.symlink('/servers/socket', os.path.join(tmpdir, 'inet'))
    collected_facts = m.populate(collected_facts={})
    assert collected_facts['interfaces'] == ['eth0']
    eth0 = collected_facts['eth0']
    assert eth0['active']

# Generated at 2022-06-20 18:11:07.933979
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # set up
    class FakeModule(object):
        def __init__(self):
            self.run_command_value = (0, "--interface=eth0 --address=10.10.10.10 --netmask=255.255.255.0 --interface=eth1 --address=10.10.10.11 --netmask=255.255.255.0  --interface=eth2 --address=10.10.10.12 --netmask=255.255.255.0 --interface=lo --address=127.0.0.1 --netmask=255.0.0.0", '')

        def get_bin_path(self, test):
            return 'fsysopts'

        def run_command(self, cmd):
            return self.run_command_value

    facts = {}

# Generated at 2022-06-20 18:11:13.200877
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    my_class = HurdPfinetNetwork(module)
    assert my_class.__class__.__name__ == 'HurdPfinetNetwork'



# Generated at 2022-06-20 18:11:15.999480
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    nm = HurdPfinetNetwork()
    nm.module = module
    nm.populate()
    assert module.exit_json.called

# Generated at 2022-06-20 18:11:21.955542
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    np = HurdPfinetNetwork()
    assert np.platform == "GNU"
    assert np._socket_dir == '/servers/socket/'

    assert np.assign_network_facts({}, "path", "path") == {}
    assert np.populate() == {}

# Generated at 2022-06-20 18:11:26.388076
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    This method is used as a unit test for the class HurdPfinetNetwork.
    """
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:11:28.868190
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert isinstance(obj, NetworkCollector)


# Generated at 2022-06-20 18:11:39.081665
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    class AnsibleModuleMock():
        def __init__(self):
            self.params = {}
            self.run_command = lambda cmd, check_rc=True: [0, '', ''] if cmd[0] == '/bin/fsysopts' else [1, '', '']

    module.params = {}
    module.run_command = lambda cmd, check_rc=True: [0, '', ''] if cmd[0] == '/bin/fsysopts' else [1, '', '']

    network = HurdPfinetNetwork(AnsibleModuleMock())
    collected_facts = network.populate()

    assert 'active' in collected_facts['interfaces'], "active interface not found !"

# Generated at 2022-06-20 18:11:48.639753
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    ''' Unit test for method populate of class HurdPfinetNetwork '''
    pfinet_network = HurdPfinetNetwork()
    pfinet_network.module = FakeAnsibleModule()

    # test if method return a empty dict
    assert pfinet_network.populate() == {}

    # test if method return a dict with the correct interfaces
    pfinet_network.module.run_command = lambda x: (0, '', '')
    pfinet_network.module.get_bin_path = lambda x: True
    result = pfinet_network.populate()
    assert result['lo']['ipv4']['address'] == '127.0.0.1'
    assert result['lo']['ipv4']['netmask'] == '255.0.0.0'


# Generated at 2022-06-20 18:12:10.402046
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Test bad fsysopt path
    module = FakeAnsibleModule({})
    network_facts = HurdPfinetNetwork(module)
    facts = network_facts.populate()
    assert len(facts) == 0

    # Test without any interface
    module = FakeAnsibleModule({'fsysopts': '/bin/true'})
    network_facts = HurdPfinetNetwork(module)
    facts = network_facts.populate()
    assert len(facts) == 0

    # Test with a single ethernet interface
    module = FakeAnsibleModule({'fsysopts': '/bin/cat', 'shell': '/bin/sh'})

# Generated at 2022-06-20 18:12:14.457208
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
    )
    network = HurdPfinetNetwork(module)
    facts = network.populate()
    assert facts == {}


# Generated at 2022-06-20 18:12:21.200913
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.base import Network

    module = MockAnsibleModule({
        'ansible_os_family': 'GNU/Hurd',
        'ansible_system': 'GNU',
    })

    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    pfinet_network = HurdPfinetNetwork(module=module)
    network_facts = pfinet_network.assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:12:31.666663
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fact = HurdPfinetNetwork()
    fsysopts_path = None
    socket_path = None
    network_facts = {'interfaces': {}}
    network_facts_result = {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {'address': '192.168.122.200', 'netmask': '255.255.255.0'},
            'ipv6': [{'address': 'fe00::212:4b00:0:316', 'prefix': '64'}]
        }
    }

# Generated at 2022-06-20 18:12:37.667805
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector
    """
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector
    assert hurd_network_collector.platform == 'GNU'
    assert hurd_network_collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:12:43.333040
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class fake_module:
        def __init__(self):
            self.run_command = lambda x, module='fsysopts', check_rc=True: (0,
                "--interface=/dev/eth0 --address=1.2.3.4 --netmask=255.255.255.0 --max-mtu=1500 --max-mru=1500",
                "")
        def get_bin_path(self, module='fsysopts'):
            return "fsysopts"
    module = fake_module()
    network_class = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = "fsysopts"
    socket_path = "/servers/socket/inet"

# Generated at 2022-06-20 18:12:43.886451
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()

# Generated at 2022-06-20 18:12:48.375451
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    facter_network = HurdPfinetNetwork(module=module)

    socket_path = '/servers/socket/inet'
    fsysopts_path = '/path/to/fsysopts'

    # Setup method run_command to return the needed values
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=1.2.3.4 --netmask=255.255.255.0', ''))
    network_facts = {}
    network_facts = facter_network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-20 18:13:00.410434
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(basic.AnsibleModule):
        def run_command(self, cmd, **kwargs):
            class FakePopen(object):
                def __init__(self, cmd, **kwargs):
                    self.cmd = cmd
                    self.params = kwargs
                    self.stdout = to_bytes('''
--interface=eth0 --address=10.0.0.1  --netmask=255.255.255.0
--interface=eth1 --address=10.0.0.2  --netmask=255.255.255.0 --address6=2001::1/64 --address6=2002::1/64''')

                rc = 0


# Generated at 2022-06-20 18:13:05.899752
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.run_command.return_value = 0, ['--interface=/dev/eth0 --address=10.0.0.10 --netmask=255.255.255.0 --address6=fc00::/64'], ''
    module.get_bin_path.return_value = 'fsysopts'

    network = HurdPfinetNetwork(module)
    facts = network.populate()

# Generated at 2022-06-20 18:13:20.866034
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    args = {}
    network = HurdPfinetNetwork(args)
    network.populate()

# Generated at 2022-06-20 18:13:26.736405
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.run_command = Mock()

    # if fsysopts is not found, HurdPfinetNetwork.populate must not
    # perform any call to run_command and return an empty dict
    module.get_bin_path = Mock(return_value=None)

    network_facts = HurdPfinetNetwork(module)
    assert not module.run_command.called
    assert {} == network_facts.populate()

    # if socket path does not exists, HurdPfinetNetwork.populate must not
    # perform any call to run_command and return an empty dict
    module.get_bin_path = Mock(return_value='fsysopts')

    network_facts = HurdPfinetNetwork(module)
    assert not module.run_command.called

# Generated at 2022-06-20 18:13:34.941116
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # mock module
    class MockModule:
        def get_bin_path(self, executable):
            return '/bin/fsysopts'

        def run_command(self, cmd):
            if cmd == ['/bin/fsysopts', '-L', '/servers/socket/inet']:
                return 0, "--interface=/dev/eth0 --address=10.10.10.10 --netmask=255.255.255.0 --address6=2001:db8::5054:ff:fefb:5678/64", ""

        def fail_json(self, *args, **kwargs):
            pass

    # mock facts
    class MockFacts:
        def __init__(self):
            self.data = {}

    # create class obj
    obj = HurdPfinetNetwork(MockModule())



# Generated at 2022-06-20 18:13:40.800464
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert HurdNetworkCollector is c.__class__
    assert c.__class__.__name__ == 'HurdNetworkCollector'
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork



# Generated at 2022-06-20 18:13:51.835247
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create mock module
    m = AnsibleModuleMock()

    # Create mock filesystem
    patcher = mock_open()
    patcher.start()
    # Mocking filesystem
    os.path.exists = MagicMock(return_value=True)
    # Mocking os.access
    os.access = MagicMock(return_value=True)
    # Mocking filesystem
    os.listdir = MagicMock(return_value=['socket'])

    # Create Facts collector
    f = HurdPfinetNetwork(m)

    # Populate facts
    facts = f.populate()

    # Assert facts are populated
    assert facts is not None
    assert 'interfaces' in facts
    assert 'lo0' in facts['interfaces']
    assert 'lo0' in facts

# Generated at 2022-06-20 18:13:55.631738
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    o = HurdNetworkCollector()
    assert o.__class__.__name__ == 'HurdNetworkCollector'
    assert o._platform == 'GNU'
    assert o._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:13:58.611267
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc
    assert isinstance(nc,NetworkCollector)

# Generated at 2022-06-20 18:14:09.838884
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import tempfile
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # make it current so we can populate /servers/socket/
    os.chdir(tmpdir)
    # mkdir /servers/socket/inet
    os.mkdir('/servers/socket/inet')
    # create a fake fsysopts
    open('fsysopts', 'w').write(
'''#!/usr/bin/env python

# Simple Python program which just prints some args.

import sys

args = sys.argv[1:]
for i in args:
    print(i)
'''
    )
    # make it executable

# Generated at 2022-06-20 18:14:11.139245
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork()
    assert type(net) == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:15.737950
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector
    """
    net_collector = HurdNetworkCollector()
    assert net_collector.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-20 18:14:40.250012
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:14:49.456788
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fake_network_facts = {'interfaces': [], 'all_ipv4_addresses': [], 'all_ipv6_addresses': [], 'local': []}
    fake_fsysopts_path = 'fake_fsysopts_path'
    fake_socket_path = 'fake_socket_path'

    fake_out = ('--address=192.168.1.1 --netmask=255.255.255.0 '
                '--address6=2001:db8::1 --address6=fc00::1/7 --interface=/dev/eth0')


# Generated at 2022-06-20 18:14:51.745292
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert isinstance(HurdPfinetNetwork(), HurdPfinetNetwork)

# Generated at 2022-06-20 18:14:56.831701
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import inference
    import pytest

    class ActionModule:
        def get_bin_path(self, cmd, required=True):
            return '/sbin/fsysopts'

        def run_command(self, cmd):
            return (0, """--interface=eth0 --address=1.2.3.4 --netmask=255.255.255.0 --address6=fe80::212:9fff:fe8c:f79/128 --dns=3.4.5.6""", None)

    class ModuleExecutor:
        def __init__(self, action_module, facts):
            self.action_module = action_module
            self.facts = facts

    class AnsibleModule:
        def __init__(self, executor):
            self.executor = executor

# Generated at 2022-06-20 18:15:08.132073
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # the next line is needed for testinfra to be able to find test_module
    from ansible.module_utils.facts import network
    network.HurdPfinetNetwork._socket_dir = 'test/test_facts/network/test/servers/socket/'

    hn = network.HurdPfinetNetwork({})
    nf = hn.populate()

    assert nf['interfaces'] == ['eth0']


# Generated at 2022-06-20 18:15:14.609564
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Test method populate of class HurdPfinetNetwork

    Input:
        - An instance on the class HurdPfinetNetwork.

    Test procedure:
        - Run the method populate of the class with
          her the value False for the variable collected_facts.
        - Check if the method return the var network_facts.

    Expected result:
        - The method populate should return the var network_facts.
    """
    import sys
    import os
    from ansible.module_utils.facts import facts
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    if sys.platform == 'gnu':
        module = facts.AnsibleModule(
            argument_spec={},
            supports_check_mode=True
        )


# Generated at 2022-06-20 18:15:19.740574
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''Test instantiating class HurdNetworkCollector'''
    loader, network_provider = NetworkCollector._get_platform_network_module()
    assert isinstance(network_provider, HurdNetworkCollector)

# Generated at 2022-06-20 18:15:27.701114
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # Create a fake module and a instance of HurdPfinetNetwork
    f = HurdPfinetNetwork(module)

    # Mock fsysopts
    fsysopts_path = module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return network_facts
    fsysopts_mock_path = '/tmp/fsysopts.mock'
    fsysopts_mock = open(fsysopts_mock_path, 'w')

# Generated at 2022-06-20 18:15:39.254880
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = NetworkCollector()
    fake_module = {
        'run_command': lambda x: (0, '--interface=loopback --address=127.0.0.1 --netmask=255.0.0.0 --address6=::1 --prefix6=128', None),
        'get_bin_path': lambda x: '/var/run/netif'
    }
    network_obj = HurdPfinetNetwork(fake_module)
    for interface in network_obj.populate():
        if interface['interfaces'][0] == 'lo':
            assert interface['lo']['ipv4']['address'] == '127.0.0.1'
            assert interface['lo']['ipv4']['netmask'] == '255.0.0.0'

# Generated at 2022-06-20 18:15:47.342007
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''Unit test constructor of class HurdPfinetNetwork'''
    from ansible.module_utils.facts.network import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network

    # test for the class HurdPfinetNetwork
    assert isinstance(HurdPfinetNetwork(), HurdPfinetNetwork)

    # test for the class Network
    assert isinstance(HurdPfinetNetwork(), Network)

# Generated at 2022-06-20 18:16:36.084512
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector()

# Generated at 2022-06-20 18:16:49.726856
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd.pfinet.config import HurdPfinetNetworkConfig
    from ansible.module_utils.facts.network.hurd.pfinet.interfaces import HurdPfinetNetworkInterfaces
    from ansible.module_utils.facts.network.hurd.pfinet.routes import HurdPfinetNetworkRoutes
    from ansible.module_utils.facts.network.hurd.pfinet.sysctl import HurdPfinetNetworkSysctl
    from ansible.module_utils.facts.network.ibm.pfinet.config import IBMPfinetNetworkConfig
    from ansible.module_utils.facts.network.ibm.pfinet.interfaces import IBMPfinetNetworkInterfaces

# Generated at 2022-06-20 18:16:53.125888
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.network_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:16:58.200849
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector

    hurdNetwork = HurdPfinetNetwork(dict())
    assert hurdNetwork.collector == HurdNetworkCollector

# Generated at 2022-06-20 18:16:59.917026
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    x = HurdPfinetNetwork({})



# Generated at 2022-06-20 18:17:04.849651
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-20 18:17:09.491959
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()

    # test if the subclass of NetworkCollector is HurdNetworkCollector
    assert isinstance(collector, NetworkCollector)
    assert type(collector) == HurdNetworkCollector


# Generated at 2022-06-20 18:17:20.117676
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """Tests for method populate of class HurdPfinetNetwork"""
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    module = FakeModule()
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

    FakeModule.run_command.assert_called_once()
    assert network_facts['interfaces'] == ['lo', 'eth0']
    assert network_facts['lo']['device'] == 'lo'
    assert network_facts['lo']['active'] is True
    assert network_facts['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:17:25.173697
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)
    # Test the check_os method
    assert network.check_os() is True

# Generated at 2022-06-20 18:17:32.257907
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class ModuleMock(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, command):
            return '/bin/' + command

        def run_command(self, command):
            if command == 'fsysopts -L /servers/socket/inet':
                return 0, ('--address=10.0.0.1', '--netmask=255.255.255.0', '--interface=/dev/eth0', '--address6=fe80::a00:27ff:fe9a:5b2f/64'), ''

# Generated at 2022-06-20 18:19:13.218097
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModuleMock()
    m.run_command = run_command_mock
    m.get_bin_path = get_bin_path_mock
    os.path.exists = path_exists_mock

    # Build object
    fact_class = HurdPfinetNetwork(m)
    # Call populate
    fact_class.populate()

    # Asserts
    assert fact_class.facts['interfaces'] is not None
    assert fact_class.facts['eth0'] is not None
    assert fact_class.facts['eth0']['active'] is not None
    assert fact_class.facts['eth0']['device'] is not None
    assert fact_class.facts['eth0']['ipv4'] is not None

# Generated at 2022-06-20 18:19:15.400489
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None


# Generated at 2022-06-20 18:19:23.510342
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    network = HurdPfinetNetwork(module=module)
    network_facts = network.populate()

    if network_facts:
        assert network_facts['interfaces']

    module.exit_json(ansible_facts=dict(network=network_facts or {}))

# Unit test case
from ansible.module_utils.basic import *
main = lambda args, kwargs: test_HurdPfinetNetwork_populate()
if __name__ == '__main__':
    main(ArgumentParser().parse_args(), dict(foo='bar'))

# Generated at 2022-06-20 18:19:33.319933
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network = HurdPfinetNetwork(dict(module=dict(run_command=run_command)))
    if_data = dict(
        iface='lo',
        inet='127.0.0.1',
        netmask='255.0.0.0',
        broadcast='127.255.255.255'
    )
    if_data['iface_list'] = [if_data['iface']]
    if_data['ipv4'] = dict()
    if_data['ipv4']['address'] = if_data['inet']
    if_data['ipv4']['netmask'] = if_data['netmask']
    if_data['ipv4']['broadcast'] = if_data['broadcast']
    if_data['ipv6'] = []
    interfaces = dict()