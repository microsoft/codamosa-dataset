

# Generated at 2022-06-20 18:09:47.670594
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Setup a mock module
    from ansible.module_utils.facts.utils import ANSIBLE_LOCALHOST
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts import collector
    module_collector = ModuleFactCollector()
    # We need to monkey patch ModuleFactCollector.get_bin_path(),
    # otherwise we get a sys.exit() call when the binary is not found
    module_collector.get_bin_path = lambda x: '/usr/bin/fsysopts'

    # First test the normal case
    example_output = '--interface=/dev/eth0\n--address=10.0.0.7\n--netmask=255.255.255.0\n'

# Generated at 2022-06-20 18:09:50.245033
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({},{},{})
    assert network
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:09:57.976374
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    module.run_command = MagicMock(return_value=(0, 'foo', ''))

    network = HurdPfinetNetwork(module)
    network.module.get_bin_path = MagicMock(return_value='/')
    res = network.populate()

    module.fail_json.assert_called_with(msg='fsysopts binary does not exist in path')

# Generated at 2022-06-20 18:09:59.845412
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector().fact_class is HurdPfinetNetwork

# Generated at 2022-06-20 18:10:01.722355
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModuleMock()
    network = HurdPfinetNetwork(module)
    assert(network)

# Generated at 2022-06-20 18:10:12.200868
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_mock = MockModule()
    fsysopts = ANSIBLE_HURD_FSYSOPTS.split()
    module_mock.run_command = MagicMock(return_value=(0, '\n'.join(fsysopts), ""))
    network_collector = HurdPfinetNetwork(module_mock)
    network_facts = network_collector.populate()
    assert network_facts == EXPECTED_HURD_NETWORK_FACTS


# Generated at 2022-06-20 18:10:15.882397
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__ == HurdNetworkCollector
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork
    assert collector._fact_class.platform == 'GNU'

# Generated at 2022-06-20 18:10:22.021844
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Check if the fact ``network`` for GNU Hurd is computed correctly
    """

    # Given a GNU Hurd server without advanced networking,
    # When I run the code to compute the ``network`` fact,
    # Then The ``network`` fact is computed correctly
    assert HurdPfinetNetwork.populate({}) == {}

# Generated at 2022-06-20 18:10:27.943156
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)

    fsysopts_path = network.module.get_bin_path('fsysopts')

    current_path = os.path.dirname(os.path.realpath(__file__))
    socket_path = os.path.join(current_path, 'assign_network_facts_test_fixtures')

    # run test case
    network_facts = network.assign_network_facts({}, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == ['eth0', 'lo']
    assert network_facts['lo']['ipv4'] == {'address': '127.0.0.1', 'netmask': '255.0.0.0'}

# Generated at 2022-06-20 18:10:32.045092
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    instance = HurdNetworkCollector()
    assert instance.platform == 'GNU'
    assert isinstance(instance.fact_class(), HurdPfinetNetwork)


# Generated at 2022-06-20 18:10:49.703952
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.collector.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.collector.network.gnu import HurdNetworkCollector
    import os
    import tempfile
    import shutil

    network_collected_facts = HurdNetworkCollector()
    network_collected_facts.populate()

    # Network facts should not have any interfaces
    assert not network_collected_facts.interfaces

    has_fsysopts = False
    fsysopts_path = '/usr/bin/fsysopts'
    if os.path.isfile(fsysopts_path):
        has_fsysopts = True

    if has_fsysopts:
        hurd_pfinet_network = HurdPfinetNetwork()

        basedir

# Generated at 2022-06-20 18:10:54.521136
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    import shutil
    import tempfile
    import json
    import errno
    try:
        import contextlib
    except ImportError:
        import backports.contextlib as contextlib

    test_input = '''\
--interface=/dev/eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=::1/128
--address6=fe80::3e97:eff:feae:c328/64
'''.encode('ascii')

    class AnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = {}
            self.check_mode = False

# Generated at 2022-06-20 18:10:56.824922
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    o = HurdNetworkCollector()
    assert o


# Generated at 2022-06-20 18:11:02.538485
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    instance = HurdPfinetNetwork(module)
    network_facts = instance.populate()
    assert network_facts['interfaces'] == ['eth0', 'lo']
    assert network_facts['eth0'] == {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '10.0.2.15',
            'netmask': '255.255.255.0',
        },
        'ipv6': [
            {
                'address': 'fe80::a00:27ff:fe0f:2b76',
                'prefix': '64',
            },
        ]
    }

# Generated at 2022-06-20 18:11:04.033502
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert isinstance(HurdPfinetNetwork(), Network)


# Generated at 2022-06-20 18:11:09.507105
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj._socket_dir == '/servers/socket/'
    obj = HurdPfinetNetwork(None)
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:11:18.877949
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fake_module = get_fake_module()
    fake_module.get_bin_path = lambda x: "/bin/true"

    fake_out = """--interface=/dev/eth0
--address=10.0.0.7
--netmask=255.0.0.0
--address6=fe80::5e5:5fff:fe5e:7bef/64
--address6=2001:470:1f0a:8a3::2/64
--address6=2001:470:1f0a:8a3::3/64
"""
    fake_module.run_command = lambda x: (0, fake_out, "")

    net = HurdPfinetNetwork(fake_module)
    network_facts = net.populate()
    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-20 18:11:21.661333
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    # FIXME: add tests once assign_network_facts is implemented
    assert True

# Generated at 2022-06-20 18:11:26.603176
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert issubclass(HurdPfinetNetwork, Network)
    # HurdPfinetNetwork(module=None)
    assert HurdPfinetNetwork(module=None)
    # HurdPfinetNetwork(module='foo')
    assert HurdPfinetNetwork(module='foo')

# Generated at 2022-06-20 18:11:29.663815
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:11:45.349878
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert type(hnc) is HurdNetworkCollector
    assert hnc.network_class is HurdPfinetNetwork


# Generated at 2022-06-20 18:11:58.337530
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # facts is the a dict of the network facts
    facts = {'interfaces': [], 'ipv4': {}, 'ipv6': []}
    # fsysopts_path is a path to the fsysopts executable
    fsysopts_path = '/bin/fsysopts'
    # socket_path is the path to the socket that we use to collect the ip address
    socket_path = '/servers/socket/inet'
    # pfinet_out is the output of fsysopts -L socket_path
    pfinet_out = '--interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0'
    test_HurdPfinetNetwork = HurdPfinetNetwork()

# Generated at 2022-06-20 18:12:09.901419
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile

    module = FakeModule()

    socket_dir = tempfile.mkdtemp()

    fd1 = os.open(os.path.join(socket_dir, 'inet'), os.O_CREAT | os.O_TRUNC)
    fd2 = os.open(os.path.join(socket_dir, 'inet6'), os.O_CREAT | os.O_TRUNC)
    os.close(fd1)
    os.close(fd2)

    with open(os.path.join(socket_dir, 'inet'), 'w') as fd:
        fd.write('foo')

    fsys = os.path.join(tempfile.mkdtemp(), 'fsysopts')

    instance = HurdPfinetNetwork(module=module)
    instance._socket_dir

# Generated at 2022-06-20 18:12:19.739420
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import os
    os.geteuid = lambda : 0

    class HurdPfinetNetwork():
        def assign_network_facts(self, network_facts, fsysopts_path, socket_path):
            return network_facts

    network_facts = {
        'interfaces': [],
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
        'default_ipv4': {},
        'default_ipv6': {},
    }

    fsysopts_path = '/bin/fsysopts'

    # first call is to populate which returns network_facts
    # second call is to populate_fav_ip which also returns network_facts and tests that _populate was called
    assert HurdPfinetNetwork().populate() == HurdPfin

# Generated at 2022-06-20 18:12:22.283368
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(dict(module=dict()))

# Generated at 2022-06-20 18:12:23.613453
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork
    assert isinstance(c.facts, HurdPfinetNetwork)

# Generated at 2022-06-20 18:12:32.730705
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes

    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    test_lines = [
        to_bytes("""Setting GNU/Hurd options:
--interface=/dev/eth0
--address=10.0.2.15
--netmask=255.255.255.0
--address6=fe80::a00:27ff:fe37:d90a/64
--address6=2607:f0d0:1002:51::4/64"""),
    ]

    for line in test_lines:
        mock_module = MagicMock()
        mock_module.run_command = Magic

# Generated at 2022-06-20 18:12:45.782578
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    module = AnsibleModuleMock()
    network_facts['interfaces'] = []
    network_facts['eth0'] = {
        'active': True,
        'device': 'eth0',
        'ipv4': {},
        'ipv6': [],
    }
    test_if = 'eth0'
    HurdPfinetNetwork(module).assign_network_facts(network_facts, '/bin/fsysopts', '/servers/socket/inet')
    assert network_facts[test_if]['ipv4']['address'] == '192.168.1.1'
    assert network_facts[test_if]['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:12:51.693244
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''Test constructor of HurdPfinetNetwork'''
    c = HurdNetworkCollector()
    assert c.platform == 'GNU'
    assert c._socket_dir == '/servers/socket/'
    assert c._fact_class is HurdPfinetNetwork

# Generated at 2022-06-20 18:12:54.290333
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc.platform == 'GNU'


# Generated at 2022-06-20 18:13:17.825197
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Stub module and environment.
    module = AnsibleModuleStub()
    os.environ['PATH'] = '/nonexistent'
    # Stub command execution.
    module.run_command = lambda cmd: (0, '--interface=/dev/eth0 --address=10.1.2.3 --netmask=255.255.255.0 --address6=dead::beef/64', '')

    # Stub ipset.
    ipset = set()
    # Stub glob.glob.
    import glob
    glob.glob = lambda x: ['/servers/socket/inet']

    # Create collector and test.
    collector = HurdNetworkCollector(module)
    facts = collector.collect(ipset, None)

    assert 'interfaces' in facts

# Generated at 2022-06-20 18:13:29.531451
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Function to test HurdPfinetNetwork.populate method.
    """
    module = FakeModule()
    obj = HurdPfinetNetwork(module)
    obj.assign_network_facts = Mock(return_value={'interfaces': ['eth0']})
    obj.module.get_bin_path = Mock(return_value=None)
    obj.populate()
    obj.module.get_bin_path.assert_called_with('fsysopts')
    obj.assign_network_facts.assert_not_called()
    obj.module.get_bin_path = Mock(return_value='/gnu/store/...-fsysopts-1.7')
    obj.populate()
    obj.module.get_bin_path.assert_called_with('fsysopts')


# Generated at 2022-06-20 18:13:33.147339
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict())
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-20 18:13:41.205582
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile
    import os

    # create fake fsysopts
    (fd, fsysopts_path) = tempfile.mkstemp(prefix='ansible_fsysopts_')
    os.close(fd)
    with open(fsysopts_path, 'w', 0) as f:
        f.write('#!/bin/sh\n');
        f.write('if [ "$1" == "-L" ]; then\n');
        f.write('    echo "--interface=dev/eth0 --address=172.16.2.1 --netmask=255.255.0.0"\n');
        f.write('    echo "--interface=dev/eth1 --address=172.16.2.1 --netmask=255.255.0.0"\n');

# Generated at 2022-06-20 18:13:49.932746
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleStub:
        def run_command(self, args):
            with open(args[2], 'r') as f:
                return 0, f.read(), ''

    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    network_facts = {}
    fsysopts_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fsysopts')
    socket_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'inet_socket')
    m = ModuleStub()

# Generated at 2022-06-20 18:13:59.251991
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import funcs
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    test_output = '''
--interface=/dev/eth0
--address=10.10.10.1
--netmask=255.255.255.0
--broadcast=10.10.10.255
--address6=2001::3/64
--address6=fe80::1/64
--address6=2001:db8:0:f101::1/64
    '''.strip()


# Generated at 2022-06-20 18:14:02.561790
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = HurdPfinetNetwork(module)
    assert network is not None

# Generated at 2022-06-20 18:14:04.362148
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj

# Generated at 2022-06-20 18:14:05.804560
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpf = HurdPfinetNetwork({})
    assert hpf.module is not None, "Module is not defined"

# Generated at 2022-06-20 18:14:08.642353
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None)._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:14:29.368718
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    interface_socket = 'eth0'
    module = MockModule()
    network_collector = HurdNetworkCollector(module)

    setattr(network_collector, '_interface_socket_map', {interface_socket: '/servers/socket/'})

    HurdPfinetNetwork.populate(network_collector, {})
    assert (network_collector['ansible_facts']['ansible_interfaces'] == ['eth0'])
    assert (network_collector['ansible_facts']['ansible_all_ipv4_addresses'] == ['10.0.0.42'])
    assert (network_collector['ansible_facts']['ansible_eth0']['ipv4']['address'] == '10.0.0.42')

# Generated at 2022-06-20 18:14:38.404428
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Options:
        def __init__(self):
            self.fsysopts = 'fsysopts'

    module = Options()
    obj = HurdPfinetNetwork(module=module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    rc, out, err = obj.module.run_command([fsysopts_path, '-L', socket_path])

    obj.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts["eth0"]["ipv4"]["address"] == '192.168.0.1'

# Generated at 2022-06-20 18:14:48.721559
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import FactCollector
    import re

    f = open('/tmp/hurd-fsysopts-inet6.txt')
    inet6 = f.read()
    f.close()

    f = open('/tmp/hurd-fsysopts-inet.txt')
    inet = f.read()
    f.close()

    f = open('/tmp/ansible_collected_network_facts.py')
    expected_network_facts = f.read()
    f.close()

    # This module is in Python2 compatibility mode, the import of
    # json will be done in Ansible 2.0, it is just to allow testing
    # without actually installing ansible
    expected_network_facts = re.sub(r"import json", "", expected_network_facts)

# Generated at 2022-06-20 18:14:49.987130
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork



# Generated at 2022-06-20 18:14:58.369288
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = type('', (), {
        'run_command': lambda *args, **kwargs: (0, 'valid out', 'valid err'),
        'get_bin_path': lambda *args, **kwargs: 'valid path'
    })

    AnsibleModule = type('', (), {
        'params': {
            'gather_subset': '',
            'gather_timeout': 5
        }
    })

    setattr(module, 'AnsibleModule', AnsibleModule)

    network_module = HurdPfinetNetwork(module=module)
    assert network_module.module == module
    assert network_module._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:15:08.753243
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mod = AnsibleModuleMock(dict(ANSIBLE_MODULE_ARGS={}), check_invalid_arguments=False)
    mod.run_command = run_command_mock(
        (0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0', ''),
        (0, '--interface=/dev/eth1 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''),
    )
    mod.get_bin_path = lambda x: '/bin/' + x if x in ('fsysopts', 'route') else None

    network = HurdPfinetNetwork(module=mod)
    network.collect_from = lambda x, y=None: True



# Generated at 2022-06-20 18:15:12.886756
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Constructor of class HurdPfinetNetwork"""
    obj = HurdPfinetNetwork()

    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-20 18:15:20.276516
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network_facts = {}

    def fsysopts_path_helper(module):
        return '/servers/socket/internet'

    def run_command_helper(module, command):
        return 0, '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe44:9a9a/64', ''

    pfinet = HurdPfinetNetwork(module)
    pfinet.module.get_bin_path = fsysopts_path_helper
    pfinet.module.run_command = run_command_helper

    network_facts = pfinet.populate(network_facts)

# Generated at 2022-06-20 18:15:30.729139
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # we don't want to actually run commands
    module = DummyAnsibleModule()
    module.get_bin_path = lambda x: ''
    collector = HurdPfinetNetwork(module, run_command_environ_update={})
    network_facts = collector.populate()
    assert network_facts == {}

    collector.module.run_command = lambda x: (0, '--address=10.0.0.3 --netmask=255.255.255.0 --interface=/dev/eth0 --address6=2001:638:708:30c7::/64', '')
    # have to emulate the run_command method of AnsibleModule
    network_facts = collector.populate()

# Generated at 2022-06-20 18:15:40.655033
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class TestModule:
        def __init__(self):
            self.params = {
                'module_name': 'test_module',
            }

        def get_bin_path(self, arg):
            return {
                'fsysopts': 'tests/unittests/module_utils/facts/network/../../files/fsysopts',
            }[arg]


# Generated at 2022-06-20 18:15:56.029729
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None

# Generated at 2022-06-20 18:15:58.653027
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test for HurdNetworkCollector
    """
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:16:10.983446
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = [0, '--interface=/dev/eth0 --address=192.168.0.254 --netmask=255.255.255.0 --address6=fe80::250:56ff:fe75:3e31/64', '']

    network_facts = {}
    network = HurdPfinetNetwork(module)

    network_facts = network.assign_network_facts(network_facts, '/fsysopts', '/socket')

    assert network_facts is not None
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.254'
   

# Generated at 2022-06-20 18:16:20.640845
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.network import NetworkCollectorBase
    from ansible.module_utils.six import PY2

    assert issubclass(HurdNetworkCollector, NetworkCollectorBase) is True
    if PY2:
        assert HurdNetworkCollector.__bases__[0].__name__ == 'object'
    else:
        assert HurdNetworkCollector.__bases__[0].__name__ == 'NetworkCollectorBase'
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:16:25.331084
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'
    assert collector._platform == 'GNU'
    assert collector._fact_class.__name__ == 'HurdPfinetNetwork'



# Generated at 2022-06-20 18:16:37.319832
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock
    from ansible.module_utils.facts.network import HurdPfinetNetwork, NetworkCollector
    module = Mock()
    collector = NetworkCollector()
    mock_args = ['fsysopts', '-L', '/servers/socket/inet']

# Generated at 2022-06-20 18:16:43.558670
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Test the method assign_network_facts of class HurdPfinetNetwork.
    It returns dict {interfaces: [], interface0: {ipv4: {address: ip_address, netmask: subnet_mask},
                                                  ipv6: [{address: ip_address, prefix: prefix_address}]},
                                interface1: {ipv4: {address: ip_address, netmask: subnet_mask},
                                             ipv6: [{address: ip_address, prefix: prefix_address}]}}
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    class _HurdPfinetNetwork(HurdPfinetNetwork):
        def __init__(self, module, network_facts):
            self.module = module
            self.network_

# Generated at 2022-06-20 18:16:47.449760
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector()._platform == 'GNU'
    assert HurdNetworkCollector()._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:16:51.077368
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of class HurdPfinetNetwork
    """
    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'

# Generated at 2022-06-20 18:16:55.042386
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-20 18:17:34.753191
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-20 18:17:43.648495
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Without fsysopts
    module = MockModule({})
    network = HurdPfinetNetwork(module)
    network.populate(None)
    assert module.params == {}

    # With fsysopts
    module = MockModule({
        'fsysopts': './plugins/modules/fsysopts',
        '_socket_dir': './plugins/modules/servers/socket',
        'ls': './plugins//ls',
    })
    module.run_command = Mock(return_value=(0, """\
--interface=/dev/eth0
--address=192.0.2.42
--netmask=255.255.255.0
--address6=fd00::01/64
""", ""))

    network = HurdPfinetNetwork(module)
    network.populate(None)

# Generated at 2022-06-20 18:17:55.356748
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fact = HurdPfinetNetwork()
    fact.module = FakeAnsibleModule()
    fact.module.run_command = FakeRunCommand()
    collected_facts = {}
    expected_facts = {
        'interfaces': ['eth0'],
        'eth0': {
            'device': 'eth0',
            'active': True,
            'ipv4': {
                'address': '192.168.1.42',
                'netmask': '255.255.255.0',
            },
            'ipv6': [{
                'address': '2001:db8::1',
                'prefix': '64',
            }],
        },
    }
    assert expected_facts == fact.populate(collected_facts)


# Generated at 2022-06-20 18:17:57.508923
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.platform == 'GNU'
    assert network_collector.fact_class == HurdPfinetNetwork



# Generated at 2022-06-20 18:18:02.085400
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    mod_obj = HurdPfinetNetwork('foo', module)

    assert mod_obj.populate() == {}



# Generated at 2022-06-20 18:18:11.732648
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # run a first time with a path to a fsysopts dummy
    # to check that the condition works
    class DummyModule():
        def __init__(self):
            self.params = dict()
            self.params['_ansible_check_mode'] = True

        def fail_json(self, *args, **kwargs):
            raise Exception('fail_json should not be called')

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/fsysopts'


# Generated at 2022-06-20 18:18:19.373079
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hostname = 'testhost'
    module = MagicMock()
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/bin/fsysopts'
    network_collector = HurdPfinetNetwork(module)
    out = network_collector.populate()
    assert network_collector._socket_dir == '/servers/socket/'
    assert out['interfaces'][0] == 'eth0'

# Generated at 2022-06-20 18:18:31.095504
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    m = AnsibleModule(
        argument_spec={
            'path': {
                'type': 'str',
                'required': True,
            },
            'socket': {
                'type': 'str',
                'required': True,
            },
        },
    )

    h = HurdPfinetNetwork(m)

    network_facts = {}
    network_facts = h.assign_network_facts(network_facts, '/usr/bin/fsysopts', '/servers/socket/inet6')
    assert network_facts['interfaces'] == ['eth0', 'lo']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-20 18:18:38.221549
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, """--interface=/dev/eth0 --address=10.0.0.2 --netmask=255.255.255.0 --address6=0::1/64 --interface=/dev/eth1 --address=10.0.0.3 --netmask=255.255.255.0 --address6=0::2/64""", ""))
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-20 18:18:39.644240
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class.__name__ == 'HurdPfinetNetwork'