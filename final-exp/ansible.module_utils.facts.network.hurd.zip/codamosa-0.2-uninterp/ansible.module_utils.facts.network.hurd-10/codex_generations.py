

# Generated at 2022-06-17 00:53:36.418919
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:53:39.981763
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:53:48.526430
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake module
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')

    # Create a fake os.path.exists
    os.path.exists = MagicMock(return_value=True)

    # Create a fake socket
    socket_path = '/servers/socket/inet'

    # Create a fake fsysopts
    fsysopts_path = '/bin/fsysopts'

    # Create a fake network_facts
    network_facts = {}

    # Create a fake assign_network_facts
    assign_network_facts = MagicMock

# Generated at 2022-06-17 00:53:59.775474
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

# Generated at 2022-06-17 00:54:05.640228
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:54:17.093223
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fea6:8c6f/64', ''))
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
   

# Generated at 2022-06-17 00:54:22.077814
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'
    assert HurdPfinetNetwork(None)._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:54:34.054510
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HurdNetworkCollector(module=module)
    network_collector.collect()
    assert network_collector.network_facts['interfaces'] == ['eth0']
    assert network_collector.network_facts['eth0']['active'] == True
    assert network_collector.network_facts['eth0']['device'] == 'eth0'
    assert network_collector.network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_collector.network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:54:36.989016
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:54:48.862787
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    network = HurdPfinetNetwork(module)
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-17 00:54:56.323510
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:54:58.883567
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:55:03.257476
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HurdPfinetNetwork(module)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:55:13.510172
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network
    from ansible.module_utils.facts.network.gnu import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

# Generated at 2022-06-17 00:55:24.398004
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:55:32.315728
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe9c:b9e8/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active']
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address']

# Generated at 2022-06-17 00:55:37.778220
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:55:41.112691
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:55:52.278458
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fea5:b1a3/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active']
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address']

# Generated at 2022-06-17 00:55:55.195204
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:15.227135
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Address
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6AddressPrefix

# Generated at 2022-06-17 00:56:19.622638
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:22.036750
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:25.661595
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HurdPfinetNetwork(module).populate()

    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe7c:f8d1'


# Generated at 2022-06-17 00:56:34.970017
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_get_device_to_ip_interfaces
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_get_interfaces_to_ip

# Generated at 2022-06-17 00:56:46.343391
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Address
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv

# Generated at 2022-06-17 00:56:49.313320
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:55.695209
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkEnvironmentError
    from ansible.module_utils.facts.network.base import NetworkParseError
    from ansible.module_utils.facts.network.base import NetworkNotImplementedError

    # Test with no fsysopts
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    network = HurdPfin

# Generated at 2022-06-17 00:56:59.022418
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:57:07.843127
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fea1:8f0b/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:57:39.437507
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

# Generated at 2022-06-17 00:57:41.763452
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:57:52.357977
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active'] is True
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address'] == '10.0.0.1'


# Generated at 2022-06-17 00:57:54.720586
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:58:06.864649
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:58:08.683425
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:58:18.980143
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.0.2'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network.facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe4c:e9e8'
    assert network.facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:58:28.340344
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFact
    from ansible.module_utils.facts.network.base import NetworkInterfaceFactError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFactIPv4

# Generated at 2022-06-17 00:58:34.518565
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkSettings
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6

    class MockModule(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-17 00:58:46.110739
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network
    from ansible.module_utils.facts.network.gnu import NetworkCollector
    from ansible.module_utils.facts.network.gnu import NetworkFacts
    from ansible.module_utils.facts.network.gnu import NetworkInterface
    from ansible.module_utils.facts.network.gnu import NetworkInterfaceFacts
    from ansible.module_utils.facts.network.gnu import NetworkInterfaceIPv4Facts
    from ansible.module_utils.facts.network.gnu import NetworkInterfaceIPv6Facts
    from ansible.module_utils.facts.network.gnu import NetworkInterface

# Generated at 2022-06-17 00:59:39.776798
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts == {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '192.168.1.2',
                'netmask': '255.255.255.0',
            },
            'ipv6': [
                {
                    'address': 'fe80::a00:27ff:fe1a:a9a8',
                    'prefix': '64',
                },
            ],
        },
    }

# Generated at 2022-06-17 00:59:42.466498
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:59:51.698022
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIP
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6

# Generated at 2022-06-17 00:59:52.507674
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 00:59:58.504093
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

# Generated at 2022-06-17 01:00:10.840047
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8:1::1'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'


# Generated at 2022-06-17 01:00:12.754365
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == 'GNU'
    assert h._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:00:19.604170
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::5054:ff:fe12:3456'

# Generated at 2022-06-17 01:00:21.806108
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 01:00:30.891459
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network

    # Test the constructor of HurdPfinetNetwork class
    network = HurdPfinetNetwork(None)
    assert isinstance(network, Network)

    # Test the constructor of HurdNetworkCollector class
    network_collector = HurdNetworkCollector(None)
    assert isinstance(network_collector, NetworkCollector)

# Generated at 2022-06-17 01:02:35.229196
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 01:02:46.173533
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:02:47.402804
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 01:02:53.337504
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_module
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdNetworkCollector

    # create a module
    module = test_module.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # create a NetworkCollector
    network_collector = HurdNetworkCollector(module=module)



# Generated at 2022-06-17 01:02:55.233195
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 01:03:05.393975
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:03:07.189308
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 01:03:10.858935
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:03:12.902368
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 01:03:22.988885
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork