

# Generated at 2022-06-17 00:53:36.147631
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network.facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fea5:5e5a'
    assert network.facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:53:44.906268
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8::1'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'


# Generated at 2022-06-17 00:53:49.436387
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:53:56.891279
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceFacts
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4Facts
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Facts
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6AddressFacts

# Generated at 2022-06-17 00:54:04.302602
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::1'

# Generated at 2022-06-17 00:54:15.873777
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock module.run_command
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Mock module.get_bin_path
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')

    # Mock os.path.exists
    os.path.exists = MagicMock(return_value=True)

    # Create HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Call populate method
    network.populate()

    # Assert module.run_command has been called

# Generated at 2022-06-17 00:54:28.474060
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

# Generated at 2022-06-17 00:54:30.752173
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:54:41.649172
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import tempfile
    import shutil
    import os
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    class FakeModule:
        def __init__(self):
            self.run_command = lambda x: (0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fea7:f8a0/64', '')
            self.get_bin_path = lambda x: '/bin/fsysopts'

    class FakeFacts:
        def __init__(self):
            self.network = HurdPfinetNetwork(FakeModule())

    facts = FakeFacts()
    network_facts = facts.network.populate()


# Generated at 2022-06-17 00:54:50.196351
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.pfinet import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollectorException
    from ansible.module_utils.facts.network.base import NetworkException
    from ansible.module_utils.facts.network.base import NetworkParseException
    from ansible.module_utils.facts.network.base import NetworkUnknownFactsException
    from ansible.module_utils.facts.network.base import NetworkUnsupportedFactsException

# Generated at 2022-06-17 00:55:07.962721
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
        def get_bin_path(self, x):
            return '/bin/fsysopts'

    # Create a fake network
    class FakeNetwork(Network):
        def __init__(self):
            self.module = FakeModule()

    # Create a fake collector
    class FakeCollector(HurdNetworkCollector):
        def __init__(self):
            self.module = FakeModule()

    # Create a

# Generated at 2022-06-17 00:55:15.885676
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Mock fsysopts
    fsysopts_path = module.get_bin_path('fsysopts')

# Generated at 2022-06-17 00:55:25.383914
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe4f:d5e4'

# Generated at 2022-06-17 00:55:33.954553
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active'] is True
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network.facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe3c:3c3d'

# Generated at 2022-06-17 00:55:36.813127
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor test of HurdNetworkCollector
    """
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:55:48.792540
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')
    # Create a fake socket
    socket_path = os.path.join(os.path.dirname(__file__), 'socket')

    # Call the populate method
    network_facts = network.assign_network_facts({}, fsysopts_path, socket_path)

    # Check the result
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True


# Generated at 2022-06-17 00:55:52.929809
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'

# Generated at 2022-06-17 00:55:54.838687
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:55:56.627787
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:55:58.348938
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:56:16.790183
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe5f:f8c5'

# Generated at 2022-06-17 00:56:18.218156
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 00:56:28.424300
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFact

# Generated at 2022-06-17 00:56:31.480372
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:35.262866
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict())
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:37.903569
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:48.950844
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'


# Generated at 2022-06-17 00:56:55.402755
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:56:58.718122
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == 'GNU'
    assert h._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:57:07.715763
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:57:31.763546
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test the constructor of class HurdNetworkCollector
    """
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:57:40.288270
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_get_device_to_ip_map
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_get_interfaces

# Generated at 2022-06-17 00:57:43.182223
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:57:53.533441
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Address
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6AddressPrefix

# Generated at 2022-06-17 00:58:05.923298
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:58:08.758199
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:58:11.721223
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 00:58:15.680097
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HurdPfinetNetwork(module)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:58:18.324452
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:58:27.084761
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFact
    from ansible.module_utils.facts.network.base import NetworkInterfaceFactError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFacts

# Generated at 2022-06-17 00:59:25.521155
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active'] == True
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network.facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe6c:9f8a'

# Generated at 2022-06-17 00:59:31.471353
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'

# Generated at 2022-06-17 00:59:33.442749
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:59:44.520475
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '10.0.2.15'

# Generated at 2022-06-17 00:59:53.194717
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8:0:1::1/64', ''))
    network_facts = {}
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, '/usr/bin/fsysopts', '/servers/socket/inet')

# Generated at 2022-06-17 01:00:01.203915
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface

# Generated at 2022-06-17 01:00:03.871329
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 01:00:10.257254
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:00:14.682484
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:00:21.082054
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts command
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')

    # Create a fake socket directory
    socket_dir = os.path.join(os.path.dirname(__file__), 'socket')

    # Create a fake socket
    socket_path = os.path.join(socket_dir, 'inet')

    # Create a fake interfaces datastructure

# Generated at 2022-06-17 01:02:27.601910
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:02:29.780018
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 01:02:38.432313
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_fail
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_no_socket
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_no_fsysopts

# Generated at 2022-06-17 01:02:48.682721
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts command
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')
    os.chmod(fsysopts_path, 0o755)

    # Create a fake socket directory
    socket_dir = os.path.join(os.path.dirname(__file__), 'socket')
    os.mkdir(socket_dir)

    # Create a fake socket
    socket_path = os.path.join(socket_dir, 'inet')

# Generated at 2022-06-17 01:03:00.094634
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 01:03:09.318755
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8::1/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:03:12.022564
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 01:03:22.284723
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollectorFact
    from ansible.module_utils.facts.network.base import NetworkCollectorModule
    from ansible.module_utils.facts.network.base import NetworkCollectorModuleFact
    from ansible.module_utils.facts.network.base import NetworkCollectorModuleFacts
    from ansible.module_utils.facts.network.base import NetworkCollectorModuleFactsCollector
    from ansible.module_utils.facts.network.base import NetworkCollectorModuleFactsCollectorFact