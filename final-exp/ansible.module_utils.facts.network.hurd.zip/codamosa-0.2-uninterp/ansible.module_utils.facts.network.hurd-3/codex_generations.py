

# Generated at 2022-06-17 00:53:28.957540
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:53:31.896301
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:53:42.490777
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdNetworkCollector_populate

# Generated at 2022-06-17 00:53:51.844131
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts
    fsysopts_path = '/tmp/fsysopts'
    fsysopts_content = """
--interface=/dev/eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=2001:db8::1/64
"""
    with open(fsysopts_path, 'w') as f:
        f.write(fsysopts_content)

    # Create a fake socket
    socket_path = '/tmp/socket'
    socket_content = """
/dev/eth0
"""

# Generated at 2022-06-17 00:54:00.237181
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    network_facts = {}
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-17 00:54:02.778942
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'

# Generated at 2022-06-17 00:54:05.810587
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:54:17.214015
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fea8:b9e0'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:54:29.483969
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_collector = HurdNetworkCollector(module=module)
    network_collector.collect()

    assert network_collector.facts['interfaces'] == ['eth0']
    assert network_collector.facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_collector.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_collector.facts['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert network_collector.facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:54:35.018978
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector

    assert issubclass(HurdPfinetNetwork, Network)
    assert issubclass(HurdNetworkCollector, NetworkCollector)
    assert issubclass(HurdPfinetNetwork, BaseNetwork)
    assert issubclass(HurdNetworkCollector, BaseNetworkCollector)


# Generated at 2022-06-17 00:54:50.766280
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')

    # Create a fake socket
    socket_path = os.path.join(os.path.dirname(__file__), 'socket')

    # Create a fake interfaces

# Generated at 2022-06-17 00:55:01.346462
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe5e:8f6d'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'


# Generated at 2022-06-17 00:55:04.892923
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:55:14.468768
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network
    from ansible.module_utils.facts.network.gnu import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

# Generated at 2022-06-17 00:55:17.677156
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:55:27.855995
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import unittest
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork

    class TestHurdPfinetNetwork(unittest.TestCase):
        def setUp(self):
            self.network = HurdPfinetNetwork(None)

        def test_assign_network_facts(self):
            network_facts = {}
            fsysopts_path = '/bin/fsysopts'
            socket_path = '/servers/socket/inet'
            out = '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64'

# Generated at 2022-06-17 00:55:38.490709
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollectorException
    from ansible.module_utils.facts.network.base import NetworkException
    from ansible.module_utils.facts.network.base import NetworkLegacyCollector
    from ansible.module_utils.facts.network.base import NetworkLegacyException
    from ansible.module_utils.facts.network.base import NetworkLegacyFact
    from ansible.module_utils.facts.network.base import NetworkLegacyFacts


# Generated at 2022-06-17 00:55:41.385342
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:55:52.278077
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Address
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6LinkLocalAddress

# Generated at 2022-06-17 00:56:00.126500
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of class HurdPfinetNetwork
    """
    module = AnsibleModule(argument_spec={})
    network_collector = HurdNetworkCollector(module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8::1'

# Generated at 2022-06-17 00:56:16.833025
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe8e:b1f0/64', ''))
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 00:56:25.144293
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe1f:7a0d'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'

# Unit

# Generated at 2022-06-17 00:56:27.500416
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:30.545102
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:42.697264
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    obj = HurdPfinetNetwork(module)

    # Create a fake fsysopts
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')

    # Create a fake socket
    socket_path = os.path.join(os.path.dirname(__file__), 'socket')

    # Create a fake interfaces
    interfaces = ['eth0', 'eth1']

    # Create a fake network_facts
    network_facts = {
        'interfaces': [],
    }

    # Call assign_network_facts

# Generated at 2022-06-17 00:56:52.255702
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts command
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts')
    os.chmod(fsysopts_path, 0o755)

    # Create a fake socket directory
    socket_dir = os.path.join(os.path.dirname(__file__), 'socket')
    os.makedirs(socket_dir)

    # Create a fake socket
    socket_path = os.path.join(socket_dir, 'inet')

# Generated at 2022-06-17 00:56:55.670434
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:58.563719
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.populate()

# Generated at 2022-06-17 00:57:07.645574
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_assign_network_facts
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector

    class TestNetwork(Network):
        platform = 'GNU'

    class TestNetworkCollector(NetworkCollector):
        _platform = 'GNU'
        _fact_class = TestNetwork

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err

# Generated at 2022-06-17 00:57:18.756557
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts
    fsysopts_path = '/tmp/fsysopts'
    fsysopts_content = '''--interface=/dev/eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=2001:db8::1/64
'''
    fsysopts_file = open(fsysopts_path, 'w')
    fsysopts_file.write(fsysopts_content)
    fsysopts_file.close()

    # Create a fake socket

# Generated at 2022-06-17 00:57:44.111624
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIP

# Generated at 2022-06-17 00:57:45.653888
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'

# Generated at 2022-06-17 00:57:51.422108
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of HurdPfinetNetwork class
    """
    obj = HurdPfinetNetwork({}, {}, {})
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:57:53.831144
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:58:06.136267
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network
    from ansible.module_utils.facts.network.gnu import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector

    assert issubclass(HurdPfinetNetwork, Network)
    assert issubclass(HurdNetworkCollector, NetworkCollector)
    assert issubclass(HurdPfinetNetwork, BaseNetwork)
    assert issubclass(HurdNetworkCollector, BaseNetworkCollector)

    # FIXME: mock module


# Generated at 2022-06-17 00:58:08.028568
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:58:13.486481
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:58:20.178419
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

# Generated at 2022-06-17 00:58:27.534367
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)

    fsysopts_path = network.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return {}

    socket_path = None

    for l in ('inet', 'inet6'):
        link = os.path.join(network._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break

    if socket_path is None:
        return {}

    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-17 00:58:29.734206
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:59:22.539757
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:59:26.524014
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HurdPfinetNetwork(module)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:59:38.778950
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    network = HurdPfinetNetwork(module)
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-17 00:59:48.891904
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'


# Generated at 2022-06-17 00:59:55.453836
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # create a instance of HurdPfinetNetwork
    network = HurdPfinetNetwork(None)
    # test the platform
    assert network.platform == 'GNU'
    # test the _socket_dir
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:59:58.626143
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_facts = HurdPfinetNetwork(module)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:00:01.492864
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 01:00:12.755043
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Address
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6Prefix
    from ansible.module_utils.facts.network.base import Network

# Generated at 2022-06-17 01:00:13.742006
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None)

# Generated at 2022-06-17 01:00:15.768632
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'
    assert HurdPfinetNetwork(None)._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:02:33.846349
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkRunner
    from ansible.module_utils.facts.network.base import NetworkSettings
    from ansible.module_utils.facts.network.base import NetworkUnix
    from ansible.module_utils.facts.network.base import NetworkWindows

# Generated at 2022-06-17 01:02:36.247087
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test the constructor of the class HurdNetworkCollector
    """
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 01:02:47.206055
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network.facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network.facts['eth0']['ipv6'][0]['address'] == 'fe80::1'

# Generated at 2022-06-17 01:02:53.257440
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_collector = HurdNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fea7:f9d9'

# Generated at 2022-06-17 01:02:54.327324
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:02:58.024473
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 01:03:01.613703
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'

# Generated at 2022-06-17 01:03:03.404313
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 01:03:14.054699
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'] == [{'address': 'fe80::a00:27ff:fe8d:b0a6', 'prefix': '64'}]


# Generated at 2022-06-17 01:03:25.161084
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector as BaseNetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork