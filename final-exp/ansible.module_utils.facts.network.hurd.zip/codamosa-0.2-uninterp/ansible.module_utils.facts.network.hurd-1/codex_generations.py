

# Generated at 2022-06-17 00:53:30.025797
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:53:32.433846
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:53:33.888095
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:53:44.115079
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_fail
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_no_interfaces
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate_no_ipv4

# Generated at 2022-06-17 00:53:55.041190
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_module
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_module_utils
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_module_utils_facts

# Generated at 2022-06-17 00:54:06.580728
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:54:11.565598
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:54:17.203884
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:54:22.100233
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:54:34.104766
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe9f:8d0b'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:54:41.866388
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:54:43.967898
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:54:45.979476
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:54:57.364459
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

# Generated at 2022-06-17 00:54:58.792224
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 00:55:10.886372
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HurdNetworkCollector(module=module)
    network_collector.collect()
    network_facts = network_collector.get_facts()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8::1'
    assert network

# Generated at 2022-06-17 00:55:15.947004
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector
    """
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-17 00:55:25.421928
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8:1::2'

# Generated at 2022-06-17 00:55:29.226731
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:55:32.026957
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 00:55:52.410612
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet'
    network_facts = {}
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask']

# Generated at 2022-06-17 00:55:55.639963
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of class HurdNetworkCollector
    """
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector.platform == 'GNU'
    assert hurd_network_collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:55:57.407964
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:56:06.213293
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkCollectorFact
   

# Generated at 2022-06-17 00:56:09.802606
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:56:16.231361
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet'
    network_facts = {}
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.2'

# Generated at 2022-06-17 00:56:24.806751
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts binary
    fsysopts_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fsysopts')
    os.chmod(fsysopts_path, 0o755)

    # Create a fake socket directory
    socket_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'socket')
    os.mkdir(socket_dir)

    # Create a fake socket
    socket_path = os.path.join(socket_dir, 'inet')


# Generated at 2022-06-17 00:56:34.727994
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts command
    fsysopts_path = '/bin/fsysopts'
    fsysopts_content = """#!/bin/sh
echo --interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=fe80::1/64
"""
    fsysopts_file = open(fsysopts_path, 'w')
    fsysopts_file.write(fsysopts_content)
    fsysopts_file.close()

# Generated at 2022-06-17 00:56:38.625638
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test the constructor of class HurdNetworkCollector
    """
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:56:43.613629
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, {})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:57:10.114887
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:57:21.241089
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'


# Generated at 2022-06-17 00:57:25.735860
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:57:28.088940
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:57:32.406935
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of class HurdNetworkCollector
    """
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector._platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:57:40.788109
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::1/64', ''))
    module.get_bin_path = MagicMock(return_value='/bin/fsysopts')
    network = HurdPfinetNetwork(module)
    network.populate()
    assert network.facts['interfaces'] == ['eth0']
    assert network.facts['eth0']['active']
    assert network.facts['eth0']['device'] == 'eth0'
    assert network.facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:57:51.494607
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkFacts

    class FakeModule:
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeNetworkCollector(NetworkCollector):
        def __init__(self):
            self.facts = NetworkFacts()


# Generated at 2022-06-17 00:58:03.404964
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts_2
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts_3
    from ansible.module_utils.facts.network.gnu.hurd import test_HurdPfinetNetwork_assign_network_facts_4

# Generated at 2022-06-17 00:58:07.378613
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector class.
    """
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector.platform == 'GNU'
    assert hurd_network_collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-17 00:58:13.410504
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:59:02.800551
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)

# Generated at 2022-06-17 00:59:13.749878
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_assign_network_facts
    from ansible.module_utils.facts.network.gnu import test_HurdPfinetNetwork_populate
    from ansible.module_utils.facts.network.gnu import test_HurdNetworkCollector_populate
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkRunner
    from ansible.module_utils.facts.network.base import NetworkSettings


# Generated at 2022-06-17 00:59:16.487775
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 00:59:27.273335
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFact
    from ansible.module_utils.facts.network.base import NetworkInterfaceFactError
    from ansible.module_utils.facts.network.base import NetworkInterfaceFacts

# Generated at 2022-06-17 00:59:40.322336
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fe4b:d9c0'
    assert network_facts['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-17 00:59:50.123492
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 00:59:51.885024
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-17 00:59:52.948931
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 00:59:58.904645
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::a00:27ff:fea6:f2f2'

# Generated at 2022-06-17 01:00:04.274436
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)
    network.populate()
    assert module.params['gather_subset'] == ['!all', '!min']
    assert module.params['gather_network_resources'] == ['interfaces']


# Generated at 2022-06-17 01:02:14.727474
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # create a fake module
    class FakeModule:
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/bin/fsysopts'

        def run_command(self, args, check_rc=True):
            if args == ['/bin/fsysopts', '-L', '/servers/socket/inet']:
                return (0, '--interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=fe80::1/64', '')

# Generated at 2022-06-17 01:02:17.052373
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == 'GNU'
    assert h._socket_dir == '/servers/socket/'

# Generated at 2022-06-17 01:02:28.095368
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a fake fsysopts command
    fsysopts_path = '/bin/fsysopts'
    fsysopts_content = '''#!/bin/sh
echo --interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=2001:db8::1/64
'''
    fsysopts_file = open(fsysopts_path, 'w')
    fsysopts_file.write(fsysopts_content)
    fsysopts_file.close()

# Generated at 2022-06-17 01:02:34.395615
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a HurdPfinetNetwork object
    network = HurdPfinetNetwork(module)

    # Create a HurdNetworkCollector object
    collector = HurdNetworkCollector(module)

    # Call method populate of HurdPfinetNetwork
    network_facts = network.populate()

    # Call method populate of HurdNetworkCollector
    network_facts = collector.populate()

    # Assert that network_facts is not empty
    assert network_facts != {}

# Generated at 2022-06-17 01:02:36.488236
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:02:40.413651
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:02:44.237213
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-17 01:02:52.097404
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkError
    from ansible.module_utils.facts.network.base import NetworkInterfaceError
    from ansible.module_utils.facts.network.base import NetworkInterface
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv4
    from ansible.module_utils.facts.network.base import NetworkInterfaceIPv6
    from ansible.module_utils.facts.network.base import NetworkInterfaceIP

# Generated at 2022-06-17 01:02:54.680304
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-17 01:03:04.797836
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork