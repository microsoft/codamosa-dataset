

# Generated at 2022-06-22 23:56:15.279713
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_module = FakeModule({})
    obj = HurdPfinetNetwork(module=test_module)
    # Assign the output of fsysopts to out
    obj.module.run_command = lambda cmd: (0, cmd[2], '')
    path = '/servers/socket/inet'
    network_facts = {}

    # Asserts
    res = obj.assign_network_facts(network_facts, 'fsysopts', path)
    assert 'interfaces' in res
    assert 'lo' in res
    assert 'eth0' in res
    assert 'ipv4' in res['lo']
    assert 'netmask' in res['lo']['ipv4']
    assert 'address' in res['lo']['ipv4']
    assert 'ipv6' in res['lo']

# Generated at 2022-06-22 23:56:17.744914
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork


# Generated at 2022-06-22 23:56:20.402365
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurdpn = HurdPfinetNetwork({}, '/dev/null')
    assert isinstance(hurdpn, HurdPfinetNetwork)
    assert hurdpn.platform == 'GNU'

# Generated at 2022-06-22 23:56:24.062536
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()

    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-22 23:56:27.251140
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'


# Generated at 2022-06-22 23:56:37.954585
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import collector
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    module = Mock()
    network_fact = HurdPfinetNetwork(module)

    def side_effect_run_command(args):
        return '', "--interface=/dev/eth0 --address=10.0.0.10 --netmask=255.255.255.0 --address6=fe80::1/64", ''


# Generated at 2022-06-22 23:56:47.836440
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})

    m_call = mock.Mock()
    m_call.return_value = (0, '--interface=eth0 --address=10.1.1.1 --netmask=255.0.0.0 '
                               '--address6=2a00:1450:4001:804::1002/64', '')
    with mock.patch("ansible.module_utils.facts.network.gnu_hurd.HurdPfinetNetwork.module", module):
        with mock.patch("ansible.module_utils.facts.network.gnu_hurd.HurdPfinetNetwork.module.run_command", m_call):
            network_facts = HurdPfinetNetwork().assign_network_facts({}, 'fsysopts', 'socket_path')
           

# Generated at 2022-06-22 23:56:50.397265
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.fact_class.platform == 'GNU'

# Generated at 2022-06-22 23:57:00.917260
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys, pprint
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network import NetworkCollector

    class FakeModule(object):
        def __init__(self, params={}):
            self.params = params
            self.run_command_calls = []

        def get_bin_path(self, binary, required=False):
            return binary

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            rc = 0

# Generated at 2022-06-22 23:57:06.790401
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from units.modules.utils import set_module_args
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_network_resources=['interfaces'],
                         gather_subset='!all',
                         filter=['lo']))
    result = HurdPfinetNetwork(module)
    assert 'interfaces' in result
    assert 'eth0' in result
    assert 'lo' not in result

#

# Generated at 2022-06-22 23:57:18.054432
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mod = AnsibleModule(argument_spec=dict())
    # FIXME: use mock
    mod.run_command = lambda x: (0, '', '')
    mod.get_bin_path = lambda x: '/bin'
    collect = HurdNetworkCollector(mod).collect()
    assert 'interfaces' in collect
    assert len(collect['interfaces']) > 0
    assert 'lo' in collect['interfaces']
    assert 'eth0' in collect['interfaces']
    assert 'ipv4' in collect['eth0']
    assert 'address' in collect['eth0']['ipv4']
    assert 'netmask' in collect['eth0']['ipv4']
    assert 'ipv6' in collect['eth0']



# Generated at 2022-06-22 23:57:25.958279
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.run_command = params['run_command']
            self.get_bin_path = params['get_bin_path']

    fsysopts_path = 'fsysopts'
    socket_path = 'foo'
    out_text = (
        "--interface=/dev/eth0 "
        "--address=10.0.0.1 "
        "--netmask=255.255.254.0 "
        "--address6=2a0a:1450:4009:80b::200e/64 "
    )


# Generated at 2022-06-22 23:57:33.406446
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # GIVEN class HurdNetworkCollector
    # WHEN construct object of class
    test_collector = HurdNetworkCollector()

    # THEN class contains method get_facts
    assert 'GNU' == test_collector._platform
    assert HurdPfinetNetwork == test_collector._fact_class
    assert 'get_facts' in test_collector.__dict__
    assert 'supports' in test_collector.__dict__
    # AND object is instance of NetworkCollector class
    assert isinstance(test_collector, NetworkCollector)

# Generated at 2022-06-22 23:57:39.170242
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class = 'ansible.module_utils.facts.network.hurd.HurdNetworkCollector'
    instance = HurdNetworkCollector()
    assert isinstance(instance, HurdNetworkCollector)
    assert instance._platform == 'GNU'
    assert instance._fact_class == HurdPfinetNetwork
    assert len(instance._collectors) == 1
    assert instance._collectors[0] == HurdPfinetNetwork

# Generated at 2022-06-22 23:57:43.887621
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_HurdPfinetNetwork = HurdPfinetNetwork(None)
    assert test_HurdPfinetNetwork.platform == 'GNU'
    assert test_HurdPfinetNetwork._socket_dir.startswith('/servers/socket/')


# Generated at 2022-06-22 23:57:44.853352
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-22 23:57:48.583710
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert issubclass(HurdNetworkCollector, NetworkCollector)
    collector = HurdNetworkCollector()
    collector.populate()

    assert issubclass(HurdNetworkCollector._fact_class, Network)

# Generated at 2022-06-22 23:57:52.258967
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import NetworkFacts
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.basic import AnsibleModule

    MOCK_PATH = ['/bin', '/sbin', '/usr/bin', '/usr/sbin']

    # mock the module object
    module = AnsibleModule(argument_spec={})

    # mock the network object
    network = Network(module)

    # mock the base class
    base_network = NetworkFacts(module, network)

    # mock the subsystem object
    network = HurdPfinetNetwork(base_network)

    # we don't have the binary fsysopts
    network._bin_path

# Generated at 2022-06-22 23:58:03.831942
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    d1 = dict(device='eth0', macaddress='00:00:00:00:00:00', ipv4={'address': '10.0.0.1', 'netmask': '255.255.255.0'}, ipv6=[{'address': '1234:1234:1234:1234:1234:1234:1234:1234', 'prefix': '64'}], active=True)

    d2 = HurdPfinetNetwork()
    d2.module = True
    d2.module.run_command = lambda x: (0, '--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=1234:1234:1234:1234:1234:1234:1234:1234/64', '')

# Generated at 2022-06-22 23:58:15.325356
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.pf import PfNetwork
    from ansible.module_utils.facts.network.netinfo import NetinfoNetwork
    from ansible.module_utils.facts.network.bsd import BsdNetwork
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.aix import AIXNetwork
    from ansible.module_utils.facts.network.sunos import SunOSNetwork
    from ansible.module_utils.facts.network.windows import WindowsNetwork
    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'
    obj

# Generated at 2022-06-22 23:58:22.922041
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import doctest
    from ansible.module_utils.facts.network.gnu_hurd import HurdPfinetNetwork
    m = HurdPfinetNetwork({})
    f = open('/tmp/hurd.network.out', 'r')
    results = m.assign_network_facts({}, '/usr/bin/fsysopts', '/servers/socket/inet')
    out = f.read()
    f.close()
    assert doctest.testmod(m, out, optionflags=doctest.ELLIPSIS)[0] == 0
    return results

# Generated at 2022-06-22 23:58:33.384536
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MockNetwork:
        def run_command(self, args):
            if args[0] == '/bin/fsysopts':
                return 0, '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.255.255.0 --address6=::/0', ''
            else:
                return 1, '', 'command not found'

    # TODO: mock Module(run_command=MockNetwork().run_command, params={})
    #       fsysopts_path = self.module.get_bin_path('fsysopts')
    network_facts = {}

# Generated at 2022-06-22 23:58:35.494705
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork('ansible_network_resources','/path/to/module')


# Generated at 2022-06-22 23:58:47.531271
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork

    class FakeModule(object):
        def run_command(self, cmd):
            if cmd[-1] == '/servers/socket/inet':
                return (0, '', '')
            return (0, '--interface=/dev/eth0 --netmask=255.255.252.0 --address=10.11.240.10 '
                       '--interface=/dev/eth1 --netmask=255.255.255.0 --address=10.11.240.11 '
                       '--interface=/dev/eth2 --netmask=255.255.255.0 --address=10.11.240.12 ', '')

    module = FakeModule()
    harv = HurdPfinetNetwork(module)

# Generated at 2022-06-22 23:58:54.497239
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Return a filtering function that can be used to generate a subset of
    interface names based on a list of 'interesting' interface prefixes.
    """
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # Create a test instance
    result = HurdPfinetNetwork(module)
    # Create test data
    facts = dict()
    facts['ansible_collector'] = 'GNU'
    # Run the populate method
    result = result.populate()
    # Test assertions
    assert isinstance(result, dict)


# Generated at 2022-06-22 23:59:06.101781
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {
        'devices': [],
        'interfaces': [],
    }
    tmp_path = '/tmp/foo'
    socket_path = '/var/run/network'

    class TmpModule:
        class TmpRunCommand:
            def __call__(self, args, **kwargs):
                assert args == [tmp_path, '-L', socket_path]
                return 0, '--interface=/dev/eth0 --address=192.168.0.1 --netmask=255.255.255.0 --address6=fe80::1%eth0/64', ''
        run_command = TmpRunCommand()
        get_bin_path = lambda self, utility: tmp_path

    tmp_obj = HurdPfinetNetwork(TmpModule())
    assert tmp_obj.assign_

# Generated at 2022-06-22 23:59:08.463757
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    os_facts = {'distribution': 'GNU'}
    HurdNetworkCollector(None, os_facts, None).collect()

# Generated at 2022-06-22 23:59:16.931154
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hostname = os.uname()[1]
    n = HurdPfinetNetwork(dict(module=dict()), dict(ansible_facts=dict(ansible_hostname=hostname, ansible_system='GNU')))
    assert n.module is not None
    assert n.platform == 'GNU'
    assert n.facts is not None and hostname in n.facts

    # Assign the platform and facts to the object
    n = HurdPfinetNetwork(dict(), dict(ansible_facts=dict(ansible_system='GNU')))
    assert n.module is None
    assert n.platform == 'GNU'
    assert n.facts is None


# Generated at 2022-06-22 23:59:23.640394
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    result = HurdPfinetNetwork(module).populate()

    assert result['interfaces'] == ['lo', 'eth0']
    assert result['ipv4']['address'] == '127.0.0.1'
    assert result['ipv4']['netmask'] == '255.0.0.0'

# Generated at 2022-06-22 23:59:33.670567
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork

    test_module = FakeAnsibleModule()
    test_module.run_command = lambda args, check_rc=False: [ 0, args[2], '' ]

    network = HurdPfinetNetwork(test_module)
    network_facts = {}

    network_facts = network.assign_network_facts(network_facts,
                                                 'fake_path_to_fsysopts',
                                                 'fake_path_to_socket')

    assert network_facts['interfaces'] == [ 'eth0' ]
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-22 23:59:43.877352
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.facts import FactCollector

    # use the ansible version for testing purposes
    # ansible_version = 'v2.4.1.0-1-g87e8b6a'
    version_info = tuple(int(i) for i in ansible_version.split('.')[0:3])
    fc = FactCollector(version_info)
    facts = fc.collect(['network'])

    assert isinstance(facts['network'], HurdPfinetNetwork)
    assert facts['network'].platform == 'GNU'
    assert facts['network']._socket_dir

# Generated at 2022-06-22 23:59:45.269259
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(dict(module=None))

# Generated at 2022-06-22 23:59:47.783488
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    gnu_network = HurdPfinetNetwork()
    assert gnu_network.platform == 'GNU'


# Generated at 2022-06-22 23:59:55.191228
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    module.exit_json = exit_json
    module.fail_json = fail_json

    fsysopts_path = module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        raise SkipTest('Binary `fsysopts` is not available in the PATH.')

    socket_path = '/servers/socket/inet'  # FIXME: we need to test inet6 as well

    obj = HurdPfinetNetwork()
    obj.module = module
    facts = obj.assign_network_facts({}, fsysopts_path, socket_path)


# Generated at 2022-06-23 00:00:05.615373
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0,
        "--interface=/dev/eth0 --address=172.31.42.1 --netmask=255.255.255.0 --broadcast=172.31.42.255 --gateway=172.31.42.255",
        ""))
    routec = HurdPfinetNetwork(module)

    network_facts = routec.assign_network_facts({}, "/path/to/fsysopts", "")

    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-23 00:00:08.772128
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-23 00:00:11.170741
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # JBEISSINGER: I don't know how to test the __init__ method
    assert True


# Generated at 2022-06-23 00:00:14.129215
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork(None, None)
    assert hn._socket_dir == '/servers/socket/'
    assert hn.platform == 'GNU'

# Generated at 2022-06-23 00:00:15.086644
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    NetworkCollector(HurdPfinetNetwork)

# Generated at 2022-06-23 00:00:17.733087
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    # FIXME: find a nice way of testing this method.
    #        The problem is that module_utils.facts.network.base expect SystemExit to be raised if module.run_command fails.

# Generated at 2022-06-23 00:00:29.720936
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(
            argument_spec={},
            supports_check_mode=True
    )
    n = HurdPfinetNetwork(module)
    network_facts = {}
    test_string = '--interface=/dev/eth0 --address=10.0.2.15 --netmask=255.255.255.0 '
    test_string += '--address6=fe80::5054:ff:fedf:ed10/64 --address6=fe80::5054:ff:fe98:6fbc/64 '
    test_string += '--address6=fe80::5054:ff:fe2c:33df/64 --address6=fe80::5054:ff:fef4:8e4/64 '

# Generated at 2022-06-23 00:00:31.930646
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork


# Generated at 2022-06-23 00:00:36.110134
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Unit test for constructor of class HurdNetworkCollector"""
    _platform = 'GNU'
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == _platform
    assert HurdNetworkCollector._platform == _platform


# Generated at 2022-06-23 00:00:38.785334
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.fact_class._platform == 'GNU'

# Generated at 2022-06-23 00:00:47.504688
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    collected_facts = {
        "network": {},
        "dns": {
            "nameservers": [
                "192.168.1.254",
                "8.8.8.8"
            ]
        }
    }
    test_object = HurdPfinetNetwork(None)
    result = test_object.populate(collected_facts)

# Generated at 2022-06-23 00:00:58.248163
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    network_facts = {}
    hurd_pfinet_network = HurdPfinetNetwork()
    out = '''--interface=eth0 --address=192.168.1.70 --netmask=255.255.255.0 --addresses6=2a00:1450:4006:813::200e/64'''
    network_facts = hurd_pfinet_network.assign_network_facts(network_facts, '/bin/fsysopts', '/some/file')
    assert network_facts.get('interfaces') == ['eth0']

# Generated at 2022-06-23 00:01:08.980045
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector

    # FIXME: Unit tests for network system facts should be integrated in test/units/module_utils/facts/network/
    # Please see https://github.com/ansible/ansible-modules-core/issues/2812
    network_facts = {}
    network_facts['interfaces'] = []

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # First test
    # FIXME: mock fsysopts command output instead of fsysopts_path

# Generated at 2022-06-23 00:01:17.004901
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import ansible.module_utils.facts.network.gnu.hurd.pfinet as pfinet
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_obj = pfinet.HurdPfinetNetwork()

    # Create a fake module class
    class FakeModule():
        def __init__(self):
            self.argument_spec = {}
            self.params = {
                'gather_subset': '!all,!min'
            }
            self.fail_json = basic.fail_json
            self.run_command = basic.run_command

    # Create a fake command call list

# Generated at 2022-06-23 00:01:18.511351
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facts_module = HurdPfinetNetwork(None)
    assert facts_module.platform == 'GNU'

# Generated at 2022-06-23 00:01:29.519869
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Setup a test environment similar to GNU Hurd
    from ansible_collections.ansible.hurd.tests.unit.compat.mock import patch
    from ansible_collections.ansible.hurd.plugins.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork
    from ansible_collections.ansible.hurd.tests.unit.module_utils import basic as hurd_module_utils

    mocked_module = hurd_module_utils.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        check_invalid_arguments=False,
        bypass_checks=True
    )


# Generated at 2022-06-23 00:01:34.513474
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-23 00:01:37.603753
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class = HurdNetworkCollector.fact_class()
    assert fact_class.platform == 'GNU'
    assert fact_class._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:01:39.360941
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()

# Generated at 2022-06-23 00:01:41.859841
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    a = HurdPfinetNetwork('module', {})
    attributes = dir(a)
    assert 'platform' in attributes
    assert '_socket_dir' in attributes

# Generated at 2022-06-23 00:01:43.267289
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    x = HurdPfinetNetwork()
    assert x
    assert isinstance(x, Network)


# Generated at 2022-06-23 00:01:44.493591
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet_network = HurdPfinetNetwork()
    assert isinstance(hurd_pfinet_network, HurdPfinetNetwork)

# Generated at 2022-06-23 00:01:52.318910
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MagicMock()
    mod_stdout = """--interface=/dev/eth0
--address=10.15.106.111
--netmask=255.255.0.0
--address6=2001:470:3:11:216:3eff:fe46:3001/64
--address6=2001:470:3:11:216:3eff:fe46:3002/64"""
    module.run_command.return_value = (0, mod_stdout, '')
    mod_path = '/bin'
    module.get_bin_path.return_value = mod_path
    hn = HurdPfinetNetwork(module)
    collected_facts = {}
    fsysopts_path = module.get_bin_path('fsysopts')

# Generated at 2022-06-23 00:01:58.615637
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = 'ansible_test_mock.HurdPfinetNetwork'
    m = __import__(m, globals(), locals(), ['object'], 0)
    instance = Network(mock_module=m)
    assert isinstance(instance, Network)
    assert instance.platform == 'GNU'
    assert instance._socket_dir == '/servers/socket/'


# Unit test the assign_network_facts method of the class HurdPfinetNetwork

# Generated at 2022-06-23 00:02:06.644762
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class_ = HurdPfinetNetwork()
    fsysopts_path = 'fsysopts'
    socket_path = 'socket'

    output = ('--address=127.0.0.1 --netmask=255.0.0.0 --interface=/dev/eth0 '
              '--address6=::1/128 --address6=2a03:2880:2040:3f07:face:b00c::1/64')

    class_.module.run_command = Mock(return_value=(0, output, ''))

    network_facts = {}
    network_facts = class_.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-23 00:02:16.170781
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModuleMock()
    # create a fake GNU Hurd environment
    tmp_dir = tempfile.mkdtemp()
    socket_dir = tmp_dir + '/servers/socket/'
    os.makedirs(socket_dir)
    os.symlink('../../devices/eth0', socket_dir + '/inet')
    m.run_command.return_value = 0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8::42/64', ''
    f = HurdPfinetNetwork(module=m)

# Generated at 2022-06-23 00:02:21.032785
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.__class__.__name__ == "HurdNetworkCollector"
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class.__name__ == "HurdPfinetNetwork"


# Generated at 2022-06-23 00:02:31.989991
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    # trick the module into thinking it's running on GNU Hurd
    module.run_command = lambda x: (0, 'foo bar'.join(x), '')
    module.get_bin_path = lambda x: 'fsysopts'
    class_instance = HurdPfinetNetwork(module)
    expected_interfaces = ['lo', 'eth0', 'eth1']
    expected_ipv4 = {
        'address': '10.11.1.2',
        'netmask': '255.255.255.255'
    }

# Generated at 2022-06-23 00:02:41.634347
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})

    hn = HurdPfinetNetwork(module=module)

    assert hn.populate() == {
        'interfaces': [
            'eth0'
        ],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '10.0.2.15',
                'netmask': '255.255.255.0'
            },
            'ipv6': [
                {
                    'address': 'fe80::a00:27ff:fe98:e258',
                    'prefix': '64'
                }
            ]
        }
    }

# Generated at 2022-06-23 00:02:43.110790
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network is not None

# Generated at 2022-06-23 00:02:46.101989
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({})
    assert(h.platform == 'GNU')
    assert(h._socket_dir == '/servers/socket/')

# Generated at 2022-06-23 00:02:47.502313
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-23 00:02:58.548606
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # FIXME: create and populate fsysopts output file
    # Collect networks data
    net = HurdPfinetNetwork(dict(), dict())

    fsysopts_path = net.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return False

    socket_path = None

    for l in ('inet', 'inet6'):
        link = os.path.join(net._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break

    if socket_path is None:
        return False

    network_facts = {}
    network_facts = net.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-23 00:03:07.123050
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    _network_facts = {
        'interfaces': [],
    }

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    def run_command(*args, **kwargs):
        return 0, to_bytes('--interface=/dev/eth0 --address=127.1.2.3 --netmask=255.255.255.0 --address6=[fe80::123:23ff:fe45:6789]/64 --address6=[fec0::123:23ff:fe45:6789]/64'), ''

    def get_bin_path(*args, **kwargs):
        return 'fsysopts'

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    module.run_command

# Generated at 2022-06-23 00:03:13.313230
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.interfaces import Interfaces
    from ansible.module_utils.facts.network.linux_default import LinuxDefault

    interfaces = Interfaces()
    interfaces.parse()
    linux_default = LinuxDefault()
    linux_default.parse()

    network = HurdPfinetNetwork(interfaces, linux_default)
    network.populate()

    assert network.interfaces

# Generated at 2022-06-23 00:03:25.241555
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # FIXME: convert this using real unit test class, if possible
    def my_run_command(args):
        ifargs = '--interface=foo --address=0.0.0.0 --netmask=255.255.255.0 --address6=2002::1/64 --address6=2001::2/64'.split()
        iargs = '--interface=lo'.split()
        if args == ['fsysopts', '-L', '/path/to/inet']:
            return (0, ' '.join(ifargs) + ' ' + ' '.join(iargs), '')
        raise NotImplementedError("invalid test case")

    class Module:
        def __init__(self):
            self.run_command = my_run_command
            self.params = {}


# Generated at 2022-06-23 00:03:36.309442
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    m = HurdPfinetNetwork(None)
    m._socket_dir = 'tests/unit/module_utils/facts/network/gnu/'
    x = m.populate()
    assert x['interfaces'][0] == 'eth0'
    assert x['eth0']['device'] == 'eth0'
    assert x['eth0']['active']
    assert x['eth0']['ipv4']['address'] == '10.56.15.65'
    assert x['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-23 00:03:40.087409
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    network_facts = {
        'interfaces': []
    }
    network_facts = HurdPfinetNetwork.assign_network_facts(HurdPfinetNetwork, network_facts, '/bin/fsysopts', '/test/socket')
    assert 'eth0' in network_facts['interfaces']

# Generated at 2022-06-23 00:03:43.006534
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork
    assert isinstance(HurdNetworkCollector()._fact_class(),
                      HurdPfinetNetwork)


# Generated at 2022-06-23 00:03:47.460303
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import module_utils.facts.network.gnu
    pfinet = module_utils.facts.network.gnu.HurdPfinetNetwork(None)

    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    out = """
--interface=/dev/eth0
--address=10.0.0.1
--netmask=255.255.255.0
--address6=fe80::2cc2:47ff:fe37:b8e7/10
--address6=2001::1/10
--address6=2001::1:1/10
"""
    network_facts = pfinet.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-23 00:03:50.679168
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-23 00:03:53.560464
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    assert network.module == module
    assert network.platform == 'GNU'

# Generated at 2022-06-23 00:03:54.573423
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork({})

# Generated at 2022-06-23 00:03:59.421681
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    # check the platform
    assert c.platform() == 'GNU'
    # check the fact class assigned
    assert c._fact_class == HurdPfinetNetwork
    # check the base fact class assigned
    assert c.get_fact_class() == Network

# Generated at 2022-06-23 00:04:02.628603
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''
    Constructor for class HurdPfinetNetwork
    '''
    obj = HurdPfinetNetwork({})
    assert obj
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:04:07.564231
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-23 00:04:08.553185
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass


# Generated at 2022-06-23 00:04:12.900544
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():

    c = HurdNetworkCollector()
    assert c.platform == 'GNU'
    assert c._platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork
    assert c._fact_class.platform == 'GNU'
    assert isinstance(c._fact_class(), Network)

# Generated at 2022-06-23 00:04:16.724190
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Unit test of HurdNetworkCollector constructor
    """
    ctor = HurdNetworkCollector()
    assert ctor.platform == 'GNU'
    assert ctor.fact_class == HurdPfinetNetwork

# Generated at 2022-06-23 00:04:28.015552
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import os
    from ansible.module_utils.facts.network.gnu.hurd.pfinet_network import HurdPfinetNetwork

    class FakeModule(object):
        def run_command(self, args):
            out = '--interface=foo --address=127.0.0.1 --netmask=255.255.255.255 --address6=::1/128'
            return 0, out, ''

        def get_bin_path(self, cmd):
            return '/path/to/fsysopts'

    facts = {'hardware': {'network': {}}}
    module = FakeModule()
    network_collection = HurdPfinetNetwork(module)
    network_collection.populate(facts)

# Generated at 2022-06-23 00:04:29.897924
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    o = HurdPfinetNetwork(dict(module=dict()))
    assert o.platform == 'GNU'


# Generated at 2022-06-23 00:04:35.188167
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    network = HurdPfinetNetwork({})

    network._socket_dir = 'tests/unit/modules/network/hurd/'
    network._fsysopts = 'tests/unit/modules/network/hurd/fsysopts'

    network_facts = network.populate()

    assert network_facts == json.load(open('tests/unit/modules/network/hurd/network_facts.json'))

# Generated at 2022-06-23 00:04:46.675903
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return (0, '--address=1.2.3.4 --netmask=255.0.0.0 --address6=1:2:3::5/8', '')

        def get_bin_path(self, cmd):
            return cmd

    class MockFs:
        def __init__(self, socket_path):
            self.socket_path = socket_path
            return

        def exists(self, path):
            if path.startswith('/servers/socket/'):
                return True
            return False

    module = MockModule()
    fs = MockFs(socket_path='/servers/socket/inet')


# Generated at 2022-06-23 00:04:57.855934
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "--interface=/dev/eth0 --address=10.0.2.15\n--interface=/dev/eth1 --address=192.168.1.70", ''))
    network_facts = {}
    instance = HurdPfinetNetwork(module)
    result = instance.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')

# Generated at 2022-06-23 00:04:59.214548
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'

# Generated at 2022-06-23 00:05:07.143413
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()
    mcp = HurdPfinetNetwork()
    mcp.module = module
    module.run_command = FakeRunner()
    collected_facts = {}

    network_facts = mcp.populate(collected_facts)
    assert network_facts == {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {'address': '10.0.2.15', 'netmask': '255.255.255.0'},
            'ipv6': [{'address': 'fe80::a00:27ff:fe7e:8b2c', 'prefix': '64'}]
        }
    }



# Generated at 2022-06-23 00:05:14.256263
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mod = AnsibleModule(argument_spec={})
    facts = HurdPfinetNetwork(mod).populate()
    assert 'interfaces' in facts
    assert isinstance(facts['interfaces'], list)
    assert facts['lo'] is not None
    assert isinstance(facts['lo'], dict)
    assert 'ipv4' in facts['lo']
    assert 'ipv6' in facts['lo']
    assert 'lo' in facts['interfaces']

# Generated at 2022-06-23 00:05:23.189810
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hostname = "mock_host"
    module = mock.Mock()
    module.params = {}
    module.get_bin_path.return_value = "/fsysopts"
    module.run_command.return_value = 0, "out", "err"
    pfinet = HurdPfinetNetwork(module, hostname)
    assert pfinet.platform == "GNU"
    assert pfinet._socket_dir == "/servers/socket/"
    assert pfinet.hostname == "mock_host"
    assert pfinet.module == module



# Generated at 2022-06-23 00:05:34.859136
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command
    network_facts = {}
    platform = HurdPfinetNetwork(module)
    fsysopts_path = '/hurd/fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = platform.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-23 00:05:37.664708
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    net = HurdNetworkCollector()
    assert net._platform == 'GNU'
    assert net._fact_class == HurdPfinetNetwork


# Generated at 2022-06-23 00:05:48.751053
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    sockets_dir = '/servers/socket/'
    fsysopts_path = '/bin/fsysopts'

    module = MockModule()
    module.run_command = Mock(return_value=(0, '--interface=eth0 --address=1.1.1.1 --netmask=255.255.255.0', ''))
    module.get_bin_path = Mock(return_value=fsysopts_path)

    facts = {}
    network = HurdPfinetNetwork()
    network._socket_dir = sockets_dir
    network.module = module

    network_facts = network.assign_network_facts(facts, fsysopts_path, os.path.join(sockets_dir, 'inet'))

# Generated at 2022-06-23 00:05:57.973686
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import ansible.module_utils.facts.network.hurd_pfinet.HurdPfinetNetwork as gnu_pfinet
    from ansible.module_utils._text import to_bytes

    gnu = gnu_pfinet.HurdPfinetNetwork()

    out = to_bytes(u"""--interface=/dev/eth0
--address=192.168.1.106
--netmask=255.255.255.0
""")


# Generated at 2022-06-23 00:06:04.061993
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    HurdPfinetNetwork - assign_network_facts test
    """
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)

    # FIXME: for now, just test it returns something
    ret = network.assign_network_facts(dict(), 'fsysopts', 'foo')
    assert isinstance(ret, dict)
