

# Generated at 2022-06-22 23:56:03.204789
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(None)
    assert h is not None

# Generated at 2022-06-22 23:56:04.152259
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'

# Generated at 2022-06-22 23:56:07.729757
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = NetworkCollector()
    hurd_pfinet_network_obj = HurdPfinetNetwork(module)
    assert hurd_pfinet_network_obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-22 23:56:10.462619
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.fact_class == HurdPfinetNetwork
    assert HurdNetworkCollector._platform == 'GNU'

# Generated at 2022-06-22 23:56:20.110841
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.run_command.return_value = (0, '--interface=/dev/eth0 --address=1.2.3.4 --netmask=255.255.255.0', None)
    facts = HurdPfinetNetwork(module)
    assert facts.populate() == {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '1.2.3.4',
                'netmask': '255.255.255.0',
            },
            'ipv6': [],
        }
    }


# Generated at 2022-06-22 23:56:31.730961
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    # assign_network_facts(self, network_facts, fsysopts_path, socket_path)
    network = HurdPfinetNetwork(module)
    network_facts = {'interfaces': ['eth0', 'eth1', 'eth2']}
    fsysopts_path = "fsysopts"
    socket_path = "/servers/socket/inet"
    out = "%s" % (
        "--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.0.0 --address6=fe80::1ff:fe23:4567:89ab/64"
    )
    module.run_command.return_value = (0, out, '')

# Generated at 2022-06-22 23:56:36.998755
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import mock
    import ansible.module_utils.facts.network.hurd as hurd
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    module = mock.MagicMock()
    module.run_command.return_value = (0, '--interface=eth0 --address=10.0.0.1 --netmask=254', None)

    fsysopts_path = '/fsysopts_path'
    socket_path = '/socket_path'

    h = HurdPfinetNetwork(module)
    h.assign_network_facts = mock.MagicMock(return_value={})

    network_facts = h.populate()

    h.assign_network_facts.assert_called_once_with({}, fsysopts_path, socket_path)


# Generated at 2022-06-22 23:56:40.496071
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of class HurdPfinetNetwork
    """
    module = HurdPfinetNetwork.module
    pfinet_network = HurdPfinetNetwork(module)
    assert pfinet_network.module is module

# Generated at 2022-06-22 23:56:47.007107
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    module, fsysopts_path, socket_path = get_mocked_objects()
    # Initialize the object
    obj = HurdPfinetNetwork(module=module)
    # Assign the network facts
    network_facts = obj.assign_network_facts(network_facts, fsysopts_path, socket_path)
    # Assert that the correct network facts for interface pfinet has been assigned
    assert_network_facts(network_facts)


# Generated at 2022-06-22 23:56:58.214815
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile
    import os
    import shutil
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    tmp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(tmp_dir, 'servers/socket'))
    os.symlink('/servers/socket', os.path.join(tmp_dir, 'servers/socket/inet'))
    os.symlink('/servers/socket', os.path.join(tmp_dir, 'servers/socket/inet6'))


# Generated at 2022-06-22 23:56:59.184412
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork(False)
    assert m.platform == 'GNU'
    assert m._socket_dir == '/servers/socket/'

# Generated at 2022-06-22 23:57:10.293755
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-22 23:57:17.135490
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    m.run_command = MagicMock(return_value=[0, "", ""])
    m.get_bin_path = Mock(return_value="/bin/fsysopts")

    n = HurdPfinetNetwork(m)
    n.populate()

    m.get_bin_path.assert_called_with('fsysopts', False)


# Generated at 2022-06-22 23:57:18.714679
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''Return a dictionary with network related facts.'''
    network = HurdPfinetNetwork()
    network.populate()

# Generated at 2022-06-22 23:57:20.269148
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork()
    assert network_facts.platform == "GNU"


# Generated at 2022-06-22 23:57:24.189881
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor must set the _platform attribute value to GNU and
    _fact_class to an instance of HurdPfinetNetwork
    """

    collector = HurdNetworkCollector(None)

    assert 'GNU' == collector._platform
    assert isinstance(collector._fact_class, HurdPfinetNetwork)

# Generated at 2022-06-22 23:57:28.461115
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facts = {'ansible_sysname': 'GNU'}
    obj = HurdPfinetNetwork(None, facts, None)
    assert obj._platform == 'GNU'
    assert obj.platform == 'GNU'

# Generated at 2022-06-22 23:57:30.201589
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = None
    htpc = HurdNetworkCollector(module)
    assert htpc.platform == 'GNU'
    assert htpc.fact_class == HurdPfinetNetwork

# Generated at 2022-06-22 23:57:33.047755
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Unit tests for methods of class HurdPfinetNetwork

# Generated at 2022-06-22 23:57:38.781564
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hostname = 'localhost'
    port = 80
    use_ssl = False
    validate_certs = False
    instance = HurdPfinetNetwork(hostname, port, use_ssl, validate_certs)
    assert instance.hostname == hostname
    assert instance.port == port
    assert instance.use_ssl == use_ssl
    assert instance.validate_certs == validate_certs
    assert instance.platform == 'GNU'

# Generated at 2022-06-22 23:57:43.109232
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu_hurd import HurdPfinetNetwork
    assert HurdPfinetNetwork().__module__ == 'ansible.module_utils.facts.network.gnu_hurd'

# Generated at 2022-06-22 23:57:44.812641
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    parsed = HurdPfinetNetwork({}, {})
    assert parsed.platform == "GNU"


# Generated at 2022-06-22 23:57:57.611885
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import tempfile
    from ansible.module_util.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector

    # we need a temporary directory to store fake fsysopts output
    tmpdir = tempfile.mkdtemp()
    old_tmpdir = os.environ.get('TMPDIR')

# Generated at 2022-06-22 23:58:07.866285
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.six import PY2
    import ansible.module_utils.facts.network.gnu.pfinet
    test = ansible.module_utils.facts.network.gnu.pfinet.HurdPfinetNetwork(None, 'eth0', None, None)
    assert test._platform == 'GNU'
    assert test._interfaces == None
    assert test._device == 'eth0'
    assert test._module == None
    assert isinstance(test.get_interfaces(), list) == True
    assert test.get_device() == 'eth0'
    assert isinstance(test.get_network_facts(), dict) == True

# Generated at 2022-06-22 23:58:18.839291
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import json

    # test on out1 (with ipv6)
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    out1 = '--address=10.0.0.1 --broadcast=10.0.0.255 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe6b:29f4/64 --address6=fe80::5054:ff:fe6b:29f4%enp0s25/64 --address6=2001:db8:0:1::2/64 --address6=2001:db8:0:1::2%enp0s25/64 --interface=/dev/eth0'
    network_facts = {}
    network_facts['interfaces'] = []
    network_

# Generated at 2022-06-22 23:58:22.323238
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = Network.init_module_mock(params=dict(gather_subset=['!all', 'network']))
    if module.exit_json.called:
        module.exit_json.assert_called_once_with(ansible_facts=dict(network=dict()))

# Generated at 2022-06-22 23:58:24.766772
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''
    Test init of class
    :return:
    '''

    obj = HurdNetworkCollector()

    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-22 23:58:35.263567
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module(object):
        def __init__(self):
            self._loaded_plugins = []
        def get_bin_path(self, arg):
            return 'fsysopts'
        def run_command(self, args):
            return 0, '--interface=/dev/eth0 --address=192.168.1.10 --netmask=255.255.255.0 --interface=/dev/eth1 --address=10.0.0.2 --netmask=255.255.255.0 --address6=2001:0db8:0:f101::1/64 --address6=2001:0db8:0:f101::2/64', ''

    class Collected_facts(object):
        pass

    collected_facts = Collected_facts()

    class Network(object):
        pass

    network = Network()
   

# Generated at 2022-06-22 23:58:36.378328
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector().collect()

# Generated at 2022-06-22 23:58:48.309248
# Unit test for method populate of class HurdPfinetNetwork

# Generated at 2022-06-22 23:58:52.497951
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeModule()
    network = HurdPfinetNetwork(module=module)
    network.assign_network_facts({}, 'fsysopts', 'socket')

    module.run_command.assert_called_with(['fsysopts', '-L', 'socket'])
    assert module.run_command.called



# Generated at 2022-06-22 23:58:59.666115
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    class AnsibleModuleFake(object):
        def run_command(self, command):
            return (0, "--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0", "")

    class HurdPfinetNetworkFake(HurdPfinetNetwork):
        module = AnsibleModuleFake()

        def __init__(self):
            self.facts = {}

    collected_facts = {}
    test_object = HurdPfinetNetworkFake()
    result = test_object.assign_network_facts(collected_facts, "fsysopts", "socket")
    assert result['interfaces'] == ['eth0']

# Generated at 2022-06-22 23:59:04.564739
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net_facts = HurdPfinetNetwork()
    assert type(net_facts) == HurdPfinetNetwork
    assert net_facts.platform == 'GNU'
    assert net_facts._socket_dir == '/servers/socket/'


# Generated at 2022-06-22 23:59:06.359557
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj is not None


# Generated at 2022-06-22 23:59:15.318775
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_facts = HurdPfinetNetwork().populate()
    assert network_facts == {
        'interfaces': [ 'eth0' ],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '192.0.2.20',
                'netmask': '255.255.255.0',
            },
            'ipv6': [
                {
                    'address': '2001:db8::1',
                    'prefix': '64',
                },
                {
                    'address': '2001:db8::2',
                    'prefix': '64',
                },
            ],
        },
    }

# Generated at 2022-06-22 23:59:24.883946
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    fake_module = Facts(
        {},
        ansible_facts={'virtualization_role': ''},
    )
    fake_module.run_command = lambda x: (0, '', '')
    fake_module.get_bin_path = lambda x: '/' + x

    HurdPfinetNetwork.assign_network_facts = lambda x, y, z: {
        'interfaces': ['fake0'],
        'fake0': {
            'active': True,
            'device': 'fake0',
            'ipv4': {},
            'ipv6': [],
        },
    }


# Generated at 2022-06-22 23:59:27.406096
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork({})
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'

# Generated at 2022-06-22 23:59:31.001678
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork(None)
    assert(net.platform == 'GNU')
    assert(net._socket_dir == '/servers/socket/')
    assert(net.assign_network_facts(None, 'fsysopts', 'inet') is None)

# Generated at 2022-06-22 23:59:32.711572
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork()
    assert network_facts._socket_dir == '/servers/socket/'

# Generated at 2022-06-22 23:59:42.810566
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = type('', (), {'run_command': mock_run_command})
    obj = HurdPfinetNetwork(module)
    obj.module.get_bin_path = mock_get_bin_path
    assert obj.module.get_bin_path('fsysopts') == '/bin/fsysopts'

    network_facts = obj.populate()

# Generated at 2022-06-22 23:59:52.333255
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.ansible.community.plugins.module_utils.facts import FactCollector
    # initialize a FactCollector
    fact_collector = FactCollector(None)

    # initialize HurdPfinetNetwork
    hurd_pfinet_network = HurdPfinetNetwork(None)

    # set the module instance attribute
    hurd_pfinet_network.module = fact_collector.module

    # init the expected result

# Generated at 2022-06-23 00:00:03.732986
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test with empty fsysopts output
    test_module = {
        "run_command": lambda x: (0, '', ''),
    }
    test_network_facts = {}
    test_fsysopts_path = 'fsysopts'
    test_socket_path = '/servers/socket/inet'
    test_obj = HurdPfinetNetwork(test_module, collected_facts=None)
    assert test_obj.assign_network_facts(test_network_facts, test_fsysopts_path, test_socket_path) == \
         {'interfaces': []}
    # test with real fsysopts output

# Generated at 2022-06-23 00:00:08.356490
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """This function is used to test that the constructor of class HurdNetworkCollector works correctly."""
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork



# Generated at 2022-06-23 00:00:13.906720
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    def module_mock(command):
        return 0, '', ''

    network_collector = HurdNetworkCollector(module_mock)
    assert network_collector != None
    assert type(network_collector) is HurdNetworkCollector
    assert network_collector.module == module_mock


# Generated at 2022-06-23 00:00:17.691956
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = type('module', (), {'run_command': lambda x: [0, "--address=192.168.1.1 --netmask=255.255.255.0", ""]})
    fact_net = HurdPfinetNetwork(module)
    facts = {}
    fact_net.populate()

# Generated at 2022-06-23 00:00:29.680390
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from io import StringIO
    from ansible.module_utils._text import to_bytes

    module = FakeModule({})
    m = HurdPfinetNetwork(module)
    fsysopts_path = '/fsysopts_path'
    socket_path = '/socket_path'
    module.run_command.return_value = 0, '''--interface=/dev/eth0 --address=1.2.3.4 --netmask=255.255.255.0 --address6=fe80::100:f5ff:fe7c:b5d9/64 --address6=2001:db8::1/32''', 'stderr'
    module.get_bin_path.return_value = fsysopts_path
    ret = m.populate()

# Generated at 2022-06-23 00:00:31.203450
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """ test constructor of class HurdPfinetNetwork"""
    HurdPfinetNetwork(None)


# Generated at 2022-06-23 00:00:40.668723
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()
    network = HurdPfinetNetwork(module)
    module.run_command.return_value = (0, '--disable-arp-announce', '--disable-arp-filter',
        '--interface=/dev/eth0', '--disable-arp-accept', '--address=127.0.0.1',
        '--netmask=255.0.0.0')
    network.populate()
    assert set(network.facts['interfaces']) == set(['eth0'])
    assert network.facts['eth0']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-23 00:00:43.487752
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork(None)
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:00:44.034060
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-23 00:00:56.821160
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network = HurdPfinetNetwork({'module_setup': True})
    network.module = FakeAnsibleModule()
    network.module.run_command = FakeRunCommand()

    # Populate
    network.populate()

    assert network.facts['interfaces'] == ['eth0', 'eth1', 'eth2']
    assert network.facts['eth0'] == {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '192.168.0.1',
            'netmask': '255.255.255.0',
        },
        'ipv6': [
            {
                'address': 'fe80::a00:27ff:fe8a:6a7f',
                'prefix': '64',
            }
        ]
    }


# Generated at 2022-06-23 00:01:03.030595
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils import basic
    import json
    import sys

    # for unit test
    module = ModuleFacts()
    module.argument_spec = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default='!all', type='list'),
            gather_network_resources=dict(default=None, type='list'),
        )
    ).argument_spec
    module.check_mode = False
    module.exit_json = lambda x: True
    network_collector = HurdNetworkCollector
    network = network_collector.collect(module)
    network_facts = network.populate()


# Generated at 2022-06-23 00:01:06.257764
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict())
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:01:14.244974
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    facts = Facts(get_module=lambda: None)
    fact_collector = FactCollector(facts=facts,
                                   get_module=lambda: None,
                                   rescue_facts=lambda: None)
    network = HurdPfinetNetwork(get_module=lambda: None,
                                fact_collector=fact_collector)

    # HurdPfinetNetwork.__init__()
    assert network.collector is fact_collector
    assert network._network_facts is None
    assert network.module is None



# Generated at 2022-06-23 00:01:15.657668
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    x = HurdPfinetNetwork()
    assert isinstance(x, HurdPfinetNetwork)

# Generated at 2022-06-23 00:01:17.671156
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(None, None)
    assert h.platform == 'GNU'
    assert h.interfaces == []

# Generated at 2022-06-23 00:01:28.551612
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-23 00:01:30.141475
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    global network_module
    network_module = HurdPfinetNetwork()


# Generated at 2022-06-23 00:01:34.621930
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.get_fact_class() == HurdPfinetNetwork
    assert collector._platform == HurdPfinetNetwork.platform

# Generated at 2022-06-23 00:01:37.353494
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModuleMock()
    fc = HurdPfinetNetwork(module)
    assert None == fc.populate()


# Generated at 2022-06-23 00:01:47.802020
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.network import HurdPfinetNetwork

    module_args = dict(
        ansible_facts=dict(
            ansible_net_all_ipv4_addresses=['127.0.0.1'],
            ansible_net_all_ipv6_addresses=['::1'],
            ansible_net_interfaces=['eth0', 'eth1', 'lo'],
        )
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, **module_args)

    class MockGNUNetworkModule(object):
        def __init__(self, module):
            self.module = module

        def _executable_exists(self, executable):
            return True


# Generated at 2022-06-23 00:01:56.835629
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = MockModule()
    n = HurdPfinetNetwork(m)
    network_facts = n.populate()
    print(network_facts)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.10'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'] == [{'address': 'fe80::5efe:192.168.1.10',
                                             'prefix': '64'}]


# Generated at 2022-06-23 00:02:07.942739
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    lines = '--hostname=host-01\n--interface=eth0\n--address=192.168.1.1\n--netmask=255.255.255.0\n--broadcast=192.168.1.255\n--address6=2001:0db8::0/64\n'

# Generated at 2022-06-23 00:02:17.060121
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()
    network = HurdPfinetNetwork(module)
    collected_facts = {}
    network.populate(collected_facts)
    assert collected_facts['interfaces'] == ['eth0']
    assert collected_facts['eth0'] == {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '192.168.1.42',
            'netmask': '255.255.255.0',
        },
        'ipv6': [
            {
                'address': 'fe80::21a:a0ff:fedf:8c2',
                'prefix': '64',
            },
            {
                'address': 'fec0::1',
                'prefix': '64',
            },
        ]
    }


# Generated at 2022-06-23 00:02:20.561655
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpn = HurdPfinetNetwork(None)
    assert hpn is not None
    assert hpn.platform == 'GNU'
    assert hpn.interfaces == []

# Generated at 2022-06-23 00:02:22.237705
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(dict(), dict())
    h.populate()

# Generated at 2022-06-23 00:02:32.902105
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    '''
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    module = basic.AnsibleModule(argument_spec=dict())
    network_facts = {}
    test_object = HurdPfinetNetwork(module)
    test_object.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    # assign_network_facts should be idempotent
    test_object.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    # FIXME: Check if the network_facts['interfaces'] is valid.
    # In GNU/Hurd there will be only one

# Generated at 2022-06-23 00:02:43.967775
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    my_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    my_module.run_command = lambda x, check_rc=True: (0, to_bytes('--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0'), '')

    my_obj = HurdPfinetNetwork(my_module)
    my_obj.module.get_bin_path = lambda x: '/bin/' + x
    my_facts = my_obj.populate()
    assert 'interfaces' in my_facts
    assert len(my_facts['interfaces']) == 1

# Generated at 2022-06-23 00:02:47.400724
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc
    assert hnc._platform == 'GNU'
    assert hnc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-23 00:02:58.412184
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    mock_module = unittest.mock.Mock()
    mock_module.run_command.return_value = (0, (
        '--interface=loopback\n'
        '--address=127.0.0.1\n'
        '--netmask=255.0.0.0\n'
        '--interface=eth0\n'
        '--address=192.168.0.17\n'
        '--netmask=255.255.255.0\n'
    ), '')
    subject = HurdPfinetNetwork(mock_module)


# Generated at 2022-06-23 00:03:00.614228
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = NetworkCollector(None, None)
    obj = HurdPfinetNetwork(module)
    assert 'GNU' == obj.platform

# Generated at 2022-06-23 00:03:02.575387
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = FakeModule()
    facts = HurdPfinetNetwork(module)
    assert facts.platform == 'GNU'


# Generated at 2022-06-23 00:03:09.740927
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import _is_gnu
    from ansible.module_utils.facts.network.gnu import _collect_network_facts
    from ansible.module_utils.facts.network.gnu import Network, NetworkCollector
    from ansible.module_utils.facts.network.base import Network as BaseNetwork

    # check if a GNU system
    assert _is_gnu() is True

    # check if HurdNetworkCollector is a subclass of NetworkCollector
    assert issubclass(HurdNetworkCollector, NetworkCollector) is True

    # check if HurdPfinetNetwork is a subclass of Network and BaseNetwork


# Generated at 2022-06-23 00:03:21.914042
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils._text import to_bytes

    module = FactCollector()
    facts_dir = os.path.dirname(os.path.dirname(__file__))
    module.add_directory(facts_dir)
    fact_names = module.detect_collectors()
    module.exit_json = lambda: sys.exit(1)

    def test_populate():
        collector = NetworkCollector(module=module)

# Generated at 2022-06-23 00:03:26.783318
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Create a test HurdPfinetNetwork instance
    hpn = HurdPfinetNetwork()
    # Test that assign_network_facts() returns a dictionary
    assert isinstance(hpn.assign_network_facts({}, None, None), dict)

    # Test that populate() returns a dictionary
    assert isinstance(hpn.populate(), dict)



# Generated at 2022-06-23 00:03:37.855047
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Assume that fsysopts command is present
    m = module_mock(paths={'fsysopts': '/bin/fsysopts'})
    # Create mock for system facts os_family='GNU'.
    facts = Facts(dict(os_family='GNU'))
    network = HurdPfinetNetwork(m, facts)

    # Create file to mock the /dev/eth0 device
    with open('/dev/eth0', 'w') as f:
        f.write('/dev/eth0')

    # Create file to mock the /servers/socket/inet existance
    os.makedirs(network._socket_dir)

# Generated at 2022-06-23 00:03:38.559683
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None

# Generated at 2022-06-23 00:03:40.102530
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector().__class__ == NetworkCollector


# Generated at 2022-06-23 00:03:49.998045
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = None
    network_facts = {}
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    # Valid test
    out = """
stack=pflocal
--transport=inet/dgram/udp
--address=192.168.1.7
--netmask=255.255.255.0
--broadcast=0
--interface=eth0
--mtu=1500
--hwaddress=00:16:3e:01:a2:c2
--address6=fd00:20:2a::7d8d:14a4/96
"""
    obj = HurdPfinetNetwork(module)

# Generated at 2022-06-23 00:03:52.874193
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-23 00:03:56.169657
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Construct a NetworkCollector object
    collector = HurdNetworkCollector()
    # Test if the object is an instance of HurdNetworkCollector
    assert isinstance(collector, HurdNetworkCollector)


# Generated at 2022-06-23 00:04:05.003284
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class TestModule:
        def run_command(self, cmd):
            out = '--interface=/dev/eth0 --address=192.168.0.3 --netmask=255.255.255.0 '
            out += '--address6=fe80::8e01:27ff:fe71:3140 --address6=fe80::a00:27ff:fe6a:7c9d/64 '
            out += '--broadcast=192.168.0.255 --broadcast6=ff02::1 --dstaddr=-- --dstaddr6='
            return (0, out, '')

        def get_bin_path(self, cmd):
            return 'fsysopts'

    test_module = TestModule()
    test_network = HurdPfinetNetwork(test_module)

# Generated at 2022-06-23 00:04:09.448475
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class.__name__ == 'HurdPfinetNetwork'

# Unit tests for sub class HurdPfinetNetwork

# Generated at 2022-06-23 00:04:10.815999
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork({}).platform == 'GNU'

# Generated at 2022-06-23 00:04:22.421669
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from collections import namedtuple
    from ansible.module_utils.facts.collector import Facts

    class Module:
        def __init__(self):
            self.params = {}
            self.run_command_result = namedtuple('run_command', ('rc', 'out', 'err'))(0, '--device=eth0 --interface=/dev/pfinet0 --address=192.168.4.4 --netmask=255.255.255.0 --address6=2a02:e00:ffff::/48', '')

        def run_command(self, args):
            return self.run_command_result

        def get_bin_path(self, name):
            return '/bin/' + name

    class Iface:
        None

    class NetworkFacts:
        None

    module = Module()
   

# Generated at 2022-06-23 00:04:24.469529
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'

# Generated at 2022-06-23 00:04:25.146358
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None)


# Generated at 2022-06-23 00:04:26.076121
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-23 00:04:34.427791
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(
            foo=dict(required=False, type='str'),
        ),
        supports_check_mode=True,
    )
    module.get_bin_path = lambda x: None
    module.run_command = lambda x: (0, "--interface=eth0 --address=10.0.0.1 --netmask=255.255.255.0 --interface=eth1 --address6=fe80::a00:27ff:fe6d:5e5e/64 --address6=fec0::ffff:ffff:ffff:ffff/64", None)
    module.exit_json = lambda x: x
    network = HurdPfinetNetwork(module)
    facts = network.assign_network_facts

# Generated at 2022-06-23 00:04:36.583586
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network.module == module
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:04:40.205169
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector_data = HurdNetworkCollector()
    assert collector_data._platform == 'GNU'
    assert collector_data._fact_class.platform == 'GNU'
    assert collector_data._fallback_facts is False


# Generated at 2022-06-23 00:04:51.423448
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import itertools
    import random

    # generate random interface name, ipv4 and ipv6 address and
    # generate fsysopts output
    ifaces = ['IF' + str(x) for x in itertools.cycle(range(1, 11))]
    ipv4_list = ['172.0.0.' + str(x) for x in range(1, 255)]
    ipv6_list = [':'.join(x) for x in itertools.zip_longest(
            *[random.sample('0123456789ABCDEF', 8) for _ in range(8)],
            fillvalue='')]
    out = []
    for i in range(random.randint(1, len(ifaces))):
        name = ifaces[i]

# Generated at 2022-06-23 00:05:02.200197
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    HurdPfinetNetwork = __import__('ansible.module_utils.facts.network.gnu.hurd.pfinet.HurdPfinetNetwork', fromlist=['HurdPfinetNetwork']).HurdPfinetNetwork

    class MockModule(object):
        def get_bin_path(self, x):
            return '/usr/bin/fsysopts'

        def run_command(self, x):
            return 0, '--interface=eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=2001:db8::/64', ''

    fact_network = HurdPfinetNetwork(MockModule())
    fact_network.populate()

    assert fact_network.facts['interfaces'] == ['eth0']

# Generated at 2022-06-23 00:05:04.122612
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-23 00:05:10.414724
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    net = HurdPfinetNetwork({})
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    out = """network-interface=eth0
network-script=yes
network-address=192.168.0.10
network-netmask=255.255.255.0
network-prefix=24
network-address6=fe80::5054:ff:fe56:a5fb/64
network-address6=fc00::/7
network-prefix6=64
network-mtu=1500
network-interfaces=
network-zones=public,internal
network-no-ipv6=false
"""

# Generated at 2022-06-23 00:05:12.496769
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == 'GNU'

# Generated at 2022-06-23 00:05:14.827118
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    HurdPfinetNetwork.module = module
    HurdPfinetNetwork.populate()


# Generated at 2022-06-23 00:05:17.403523
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec = dict()
    )

    network = HurdPfinetNetwork(module)
    assert network

# Generated at 2022-06-23 00:05:20.140793
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert isinstance(network._socket_dir, unicode)

# Generated at 2022-06-23 00:05:24.938871
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    instance = HurdPfinetNetwork()
    assert isinstance(instance, Network)
    assert instance._platform == 'GNU'
    assert instance._fact_class == HurdPfinetNetwork
    assert instance._socket_dir == '/servers/socket/'


# Generated at 2022-06-23 00:05:36.907354
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import pytest

    module = sys.modules['ansible.module_utils.facts.network.gnu.pfinet']
    pfinet_network = module.HurdPfinetNetwork({})

    network_facts = {'interfaces': []}
    fsysopts_path = 'fsysopts'
    socket_path = 'socket_path'
    out = '''--interface=/dev/eth0
--address=10.0.2.15
--netmask=255.255.255.0
--address6=fe80::a00:27ff:fef3:7091/64'''
    pfinet_network.module.run_command = lambda args: (0, out, '')

# Generated at 2022-06-23 00:05:39.921369
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc.platform == 'GNU'
    assert isinstance(hnc.get_facts(), HurdPfinetNetwork)

# Generated at 2022-06-23 00:05:43.171735
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({})
    assert h.platform == 'GNU'
    assert h._socket_dir == '/servers/socket/'



# Generated at 2022-06-23 00:05:45.978084
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)


# Generated at 2022-06-23 00:05:48.250901
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():

    collector = HurdNetworkCollector()
    assert collector is not None
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-23 00:05:57.037962
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    # test method of class HurdPfinetNetwork
    network = HurdPfinetNetwork(None)

    # test for 1 interface
    out = '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.255.255.0 --address6=fc00::1/8'
    network_facts = {'interfaces': []}
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-23 00:05:59.741259
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()

    net = HurdPfinetNetwork(module)
    results = net.populate()

    assert 'interfaces' in results
    assert len(results['interfaces']) > 0
    assert 'ipv4' in results['lo']



# Generated at 2022-06-23 00:06:10.696497
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    HurdPfinetNetwork.fsysopts_path = fsysopts_path
    HurdPfinetNetwork.socket_path = socket_path
    HurdPfinetNetwork.rc = 0
    HurdPfinetNetwork.out = '--interface=eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:DB8:0:0:0:0:2:1/64'
    HurdPfinetNetwork.err = ''
    HurdPfinetNetwork.collected_facts = None
