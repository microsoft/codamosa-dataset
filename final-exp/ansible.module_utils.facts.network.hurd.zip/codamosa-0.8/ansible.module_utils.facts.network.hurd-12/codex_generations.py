

# Generated at 2022-06-11 03:25:20.476345
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector class
    """
    collector_object = HurdNetworkCollector()
    assert collector_object.network

# Generated at 2022-06-11 03:25:23.494925
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """This is a unit test for the constructor of class HurdNetworkCollector"""
    net_obj = HurdNetworkCollector()
    assert net_obj.fact_class == HurdPfinetNetwork



# Generated at 2022-06-11 03:25:34.869020
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    hn = HurdPfinetNetwork(None)

# Generated at 2022-06-11 03:25:35.861520
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()

# Generated at 2022-06-11 03:25:36.895133
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork(None)

# Generated at 2022-06-11 03:25:46.270253
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    obj = HurdNetworkCollector()
    assert type(obj) is HurdNetworkCollector
    assert BaseFactCollector in HurdNetworkCollector.__bases__
    assert obj.__class__.__bases__[0].__name__ == 'BaseFactCollector'
    assert type(obj._platform) is str
    assert obj._platform == 'GNU'
    assert type(obj._fact_class) is type
    assert obj._fact_class.__name__ == 'HurdPfinetNetwork'

# Generated at 2022-06-11 03:25:47.707373
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(dict())


# Generated at 2022-06-11 03:25:54.542888
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.packaging import NetworkPackageManager
    pkg = NetworkPackageManager
    pkg.collect = lambda x, y: []

    module = FakeModule('/sbin/fsysopts', '--interface=eth1 --interface=eth2 --address=10.0.0.1 --netmask=255.255.255.0 --address6=1:2:3:4:5:6:7:8/64 --address6=1:2:3:4:5:6:7:9/128')
    hn = HurdPfinetNetwork(module)
    network_facts = hn.populate()


# Generated at 2022-06-11 03:25:59.306923
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec={},
    )
    m.get_bin_path = lambda x: x
    np = HurdPfinetNetwork(m)
    assert np is not None

# Generated at 2022-06-11 03:26:09.260646
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a fake module
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda x: '/hurd/fsysopts'
    })

    # Create a fake subprocess with a fake run_command() method
    class AnsibleModule(object):
        def run_command(self, args):
            return 0, '--interface=eth0 --address=192.168.1.1 --netmask=255.255.255.0', ''

    module.run_command = AnsibleModule.run_command

    class AnsibleModule(object):
        def run_command(self, args):
            return 0, 'fe80::223:3dff:fe85:2740/64', ''

    module.run_command = AnsibleModule.run_command

    # Create a fake class with a

# Generated at 2022-06-11 03:26:21.911700
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = DummyModule()
    obj = HurdPfinetNetwork(module)
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    # assign_network_facts returns same argument
    facts = {}
    assert obj.assign_network_facts(facts, fsysopts_path, socket_path) == facts
    # if fsysopts_path is not set, return empty dict
    assert obj.populate() == {}



# Generated at 2022-06-11 03:26:23.922689
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    networkCollector = HurdNetworkCollector()
    assert networkCollector.fact_class == networkCollector._fact_class

# Generated at 2022-06-11 03:26:26.621194
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector(None)
    assert hnc._platform == 'GNU'
    assert hnc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:26:28.350065
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork(None)
    assert hn is not None

# Generated at 2022-06-11 03:26:37.251297
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    This test is for method assign_network_facts of class HurdPfinetNetwork
    Test case 1: No option is given in fsysopts -L
    Test case 2: --interface option is given, but ip options are not given
    Test case 3: ip address, netmask and ipv6 address are given
    """
    class TestModule:
        def __init__(self):
            self.run_command = self._run_command
        def _run_command(self, args, check_rc=True):
            if args[2] == '-L':
                if args[3] == 'interface1':
                    out = 'interface'
                elif args[3] == 'interface2':
                    out = '--interface=interface2'

# Generated at 2022-06-11 03:26:38.600945
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():

    assert HurdNetworkCollector is not None


# Generated at 2022-06-11 03:26:41.454628
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # pylint: disable=W0212
    network_collector = HurdNetworkCollector()
    facts_class = network_collector._get_fact_class(None)
    assert facts_class._platform == 'GNU'


# Generated at 2022-06-11 03:26:44.743354
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """This function can serve as a unit test for the class HurdNetworkCollector
    """
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:26:48.760481
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector.fact_class == HurdPfinetNetwork
    assert hurd_network_collector.platform == 'GNU'


# Generated at 2022-06-11 03:26:50.151270
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'

# Generated at 2022-06-11 03:26:58.665034
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
  assert HurdNetworkCollector._platform == 'GNU'
  assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:00.930691
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None

if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-11 03:27:03.410157
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:27:05.997325
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    my_network_obj = HurdPfinetNetwork()
    print(my_network_obj)


if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-11 03:27:12.077005
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock()
    network = HurdPfinetNetwork(module)
    fsysopts_path = '/path/to/fsysopts'
    socket_path = '/path/to/socket'
    network_facts = {}
    out = """
--interface=/dev/eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=fe80::1/64
"""
    err = ''
    rc = 0
    module.run_command.return_value = rc, out, err
    # call assign_network_facts method
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:27:22.975340
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    network_collector = HurdNetworkCollector(module)
    facts = network_collector.collect()

    for key, value in facts.iteritems():
        assert isinstance(key, str), 'key %s is not a string: %s' % (key, type(key))
        assert isinstance(value, dict), 'value %s is not a dict: %s' % (key, type(value))
        assert value, 'value for %s is empty' % key
        for k, v in value.iteritems():
            assert isinstance(k, str), 'key %s is not a str: %s' % (k, type(k))

# Generated at 2022-06-11 03:27:24.590646
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    b = HurdNetworkCollector()
    assert(b.platform == 'GNU')

# Generated at 2022-06-11 03:27:28.534200
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Test the constructor for this class and the fact_class.
    """
    obj = HurdPfinetNetwork(None)
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:34.492253
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            cache_facts=dict(default=True, type='bool')
        )
    )

    facts = HurdPfinetNetwork(module=module)
    facts_result = facts.populate()

    assert facts_result is not None
    assert len(facts_result) == 1
    assert 'interfaces' in facts_result
    for iface in facts_result['interfaces']:
        assert 'ipv4' in facts_result[iface]
        assert 'ipv6' in facts_result[iface]


# Generated at 2022-06-11 03:27:46.265237
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        add_file_common_args=True,
    )

    # Mock a complete set of facts

# Generated at 2022-06-11 03:28:07.452225
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    network_facts = HurdPfinetNetwork(dict(module=HurdPfinetNetworkMockModule))
    network_facts.populate(collected_facts=None)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0'] == {
        'active': True,
        'device': 'eth0',
        'ipv4': {
            'address': '10.0.2.15',
            'netmask': '255.255.255.0',
        },
        'ipv6': [{
            'address': 'fe80::a00:27ff:feca:f6c8',
            'prefix': '64',
        }],
    }


# Generated at 2022-06-11 03:28:15.870325
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule([])
    network = HurdPfinetNetwork(module)
    fsysopts_path = '/boot/bootstrap/sbin/fsysopts'
    socket_path = '/servers/socket/inet'
    module.run_command = FakeRunCommand(
        rc=0,
        out='--interface=/dev/eth0 --address=10.0.1.1 --netmask=255.255.255.0 --address6=fddd:e9f5:5eaa:d99:10:1:1:1/128',
        err='',
    )
    network_facts = network.assign_network_facts({}, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-11 03:28:18.616345
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:28:29.277390
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = DummyAnsibleModule()
    module.get_bin_path = Mock(return_value='/hurd/fsysopts')
    module.run_command = Mock(return_value=(0, '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.255.255.0 --address6=::1/128', ''))
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

# Generated at 2022-06-11 03:28:37.298674
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import io

    class FakeModule():
        def __init__(self):
            self.run_command = fake_module_run_command
        def get_bin_path(self, cmd):
            return os.path.join(os.path.dirname(__file__), 'fixtures', cmd)

    tmp_module = FakeModule()

    # Success
    fsysopts = io.open(os.path.join(os.path.dirname(__file__),
                                    'fixtures',
                                    'fsysopts_success'))

# Generated at 2022-06-11 03:28:46.204995
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class FakeModule:
        def __init__(self):
            self.params = {'gather_subset': '!all,!min'}
            self.run_command = lambda x: (0, None, None)

    class FakeNetwork(HurdPfinetNetwork):
        def __init__(self):
            self.module = FakeModule()
            self._socket_dir = '/servers/socket/'

    fake_network = FakeNetwork()
    fake_network.assign_network_facts(network_facts={}, fsysopts_path='/hurd/pfinet/fsysopts',
                                      socket_path='/servers/socket/default')

# Generated at 2022-06-11 03:28:47.745654
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({})
    assert h.platform == 'GNU'

# Generated at 2022-06-11 03:28:57.446906
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.hurdpfinet import HurdPfinetNetwork

    # There is no suitable class for the unit test.
    # So a mock class is used.
    class MockModule:
        def __init__(self):
            self.params = {'gather_subset': ['all']}
            self.config = {'module_name': 'mock_module'}
            self.fail_json = False
            self.run_command_value = 0

        def get_bin_path(self, name, required=False):
            return name


# Generated at 2022-06-11 03:29:03.588021
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()

    class Fake(object):

        def __init__(self):
            self.module = module

    network = HurdPfinetNetwork(Fake())
    network.module.run_command = test_run_command

    network.module.get_bin_path = lambda x: '/servers/socket/inet'
    facts = network.populate()
    assert facts == {'interfaces': ['lo'],
                     'lo': {'active': True,
                            'device': 'lo',
                            'ipv4': {'address': '127.0.0.1', 'netmask': '255.0.0.0'},
                            'ipv6': [{'address': '::1', 'prefix': '128'}]}}



# Generated at 2022-06-11 03:29:14.559243
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    network_facts = {
        'interfaces': [],
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
        'default_ipv4': {},
        'default_ipv6': {},
    }

    p = HurdPfinetNetwork(module=module)
    network_facts = p.assign_network_facts(network_facts, '/fsysopts', '/socket')

    assert len(network_facts['interfaces']) == 1
    assert len(network_facts['all_ipv4_addresses']) == 1
    assert len(network_facts['all_ipv6_addresses']) == 1

    assert network_facts['interfaces'][0] == 'eth0'

# Generated at 2022-06-11 03:29:46.092407
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    # test if binary exists
    fsysopts_path = '/usr/bin/fsysopts'
    if os.path.exists(fsysopts_path):
        network_facts = {}
        network = HurdPfinetNetwork(module, network_facts)
        network_facts = network.assign_network_facts(network_facts, fsysopts_path, '/servers/socket/inet')
    # test facts
    assert 'enp0s3' in network_facts
    assert network_facts['enp0s3']['active']
    assert network_facts['enp0s3']['device'] == 'enp0s3'

# Generated at 2022-06-11 03:29:56.568173
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={'path': {'type': 'str', 'required': False}})
    path = '/path/pfinet'
    output = '--interface=/dev/eth0 --address=192.168.0.42 --netmask=255.255.255.0 --address6=2a00:1450:4001:c05::56/64 --address6=2a00:1450:4001:c05::70/64 --address6=fe80::c0a8:28c/64 --address6=fe80::c0a8:28e/64'
    network_facts = []
    result = HurdPfinetNetwork(module).assign_network_facts(network_facts, path, '/socket/inet')

# Generated at 2022-06-11 03:30:06.995589
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.cpu.base import CPU
    from ansible.module_utils.facts.system.base import System
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import Distribution
    module_mock = Mock(name="module_mock")
    module_mock.run_command = Mock(name="run_command")

# Generated at 2022-06-11 03:30:15.107804
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    module.run_command.return_value = (0, 'foo', '')
    module.get_bin_path.return_value = '/fsysopts'
    network_facts = {}

    network = HurdPfinetNetwork(module)
    network.get_bin_path = module.get_bin_path
    network.run_command = module.run_command

    network_facts = {}
    assert network.populate() == network_facts

    module.get_bin_path.return_value = None
    assert network.populate() == network_facts

    module.get_bin_path.return_value = '/fsysopts'
    network_facts = network.assign_network_facts(network_facts, '/fsysopts', '/servers/socket/inet')
    assert network

# Generated at 2022-06-11 03:30:24.084987
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import pytest
    from ansible.module_utils.facts.network.base import Network

    net = Network()
    network_facts = {}
    network_facts['interfaces'] = ['eth0']

    # Test with a valid output
    fsysopts_path = 'fsysopts'
    socket_path = 'socket_path'
    net.run_command = lambda arg, **_: (0, '--interface=/dev/eth0 --address=127.0.1.1 --netmask=255.255.255.0 --broadcast=127.0.0.0 --address6=::1/128 --address6=2000::1/64', '')


# Generated at 2022-06-11 03:30:32.082546
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Prepare mock
    module_mock = AnsibleModuleMock()
    module_mock.run_command["fsysopts"] = ["fsysopts", "--interface=eth0", "--address=192.168.0.1", "--netmask=255.255.255.0", "--address6=1716::1/64",]
    module_mock.is_lxc = False

    # Populate network fact
    network = HurdPfinetNetwork(module_mock)
    network_facts = network.populate()
    # Check result
    assert 'interfaces' not in network_facts


# Generated at 2022-06-11 03:30:40.869249
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_result = 0, (u"--address=10.0.0.1\n"
                                          "--netmask=255.255.255.0\n"
                                          "--address6=2001:db8:aaaa:bbbb::1/64"), ''

        def run_command(self, cmd):
            return self.run_command_result

    test_module = ModuleMock()
    test_class = HurdPfinetNetwork(test_module)

    network_facts = {}
    fsysopts_path = 'test_path'
    socket_path = 'test_path'
    result = test_class.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-11 03:30:42.957276
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = None
    network = HurdPfinetNetwork(module=module)
    facts = network.populate()
    assert isinstance(facts, dict) is True

# Generated at 2022-06-11 03:30:44.587325
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-11 03:30:46.936948
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    result = HurdPfinetNetwork()
    assert result._socket_dir == '/servers/socket/'
    assert result.platform == 'GNU'


# Generated at 2022-06-11 03:31:46.093021
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, {}, {})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:31:52.089129
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fsysopts_path = 'fsysopts_path'
    socket_path = 'socket_path'
    network_facts = {}
    class_object = HurdPfinetNetwork()
    # Defined a sample output
    out = "--interface='/dev/eth0' --address='10.17.1.2' --netmask='255.255.0.0' --address6='fe80::216:3eff:fe22:f36c/64'"
    class_object.run_command = lambda x,y,z:('0', out, '')
    result = class_object.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:31:58.966392
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True
    )

    pc = HurdPfinetNetwork(m)

    # Set expected result
    expected_result = {
        "interfaces": ['eth0'],
        "eth0": {
            "device": "eth0",
            "ipv4": {
                "address": "192.168.56.101",
                "netmask": "255.255.255.0",
            },
            "ipv6": [{
                "address": "fe80::a00:27ff:fe61:3822",
                "prefix": "64",
            }],
            "active": True,
        },
    }



# Generated at 2022-06-11 03:32:00.101961
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector can be called.
    """
    HurdNetworkCollector(None)

# Generated at 2022-06-11 03:32:05.222196
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = HurdPfinetNetwork.assign_network_facts(None, None, '../tests/unit/module_utils/facts/files/fsysopts-eth0')
    assert facts['interfaces'][0] == 'eth0'
    assert facts['eth0']['ipv4']['address'] == '192.168.1.42'
    assert facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:32:12.842837
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''Test for method populate of HurdPfinetNetwork'''
    if os.path.exists('/servers/socket/inet'):
        _socket_dir = '/servers/socket/'
    else:
        return None
    fsysopts_path = 'fsysopts'
    socket_path = 'inet'
    link = os.path.join(_socket_dir, socket_path)
    network_facts = {}
    hnet = HurdPfinetNetwork(module=None, socket_dir=_socket_dir)

# Generated at 2022-06-11 03:32:19.698767
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    module = MockModule()
    network_facts = dict()
    network_facts['interfaces'] = []
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet6'
    network = HurdPfinetNetwork(module)
    result = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert result == {'interfaces': ['lo'], 'lo': {'active': True, 'device': 'lo', 'ipv4': {}, 'ipv6': [{'address': '::1', 'prefix': '128'}]}}


# Generated at 2022-06-11 03:32:20.624396
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork(None)
    assert n is not None

# vim: set expandtab: tabstop=4: shiftwidth=4:

# Generated at 2022-06-11 03:32:21.665688
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == "GNU"

# Generated at 2022-06-11 03:32:22.795422
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None)


# Generated at 2022-06-11 03:34:29.221445
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    Network.platform = 'GNU'
    assert HurdNetworkCollector(None)._platform == 'GNU'


# Generated at 2022-06-11 03:34:36.396562
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu.pfinet.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.pfinet.pfinet import HurdPfinetCollector
    from ansible.module_utils.facts import module_facts
    from ansible.module_utils.facts.network.common import NetworkCommonCollector
    from ansible.module_utils.facts.network.base import Network

    # Create collect object and add module object to it
    facts_collector = HurdPfinetCollector()
    module = module_facts()
    facts_collector.set_module(module)
    # Get the collection object of Network class and add the collect object to it
    collect_obj = NetworkCommonCollector()

# Generated at 2022-06-11 03:34:37.184386
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()

# Generated at 2022-06-11 03:34:39.614663
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurdNetworkCollector = HurdNetworkCollector()
    assert hurdNetworkCollector._platform == 'GNU'
    assert hurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:34:46.578400
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = './fsysopts'
    socket_path = './socket'
    data = {
        'rc': 0,
        'out': """
--interface=/dev/eth0
--address=10.0.0.1
--netmask=255.255.255.0
--address6=fe80::5cb5:5cb5:5cb5:5cb5/64
--interface=/dev/eth1
--address=10.0.0.2
--netmask=255.255.255.0
--address6=fe80::5cb5:5cb5:5cb5:5cb5/64
""".lstrip(),
        'err': '',
    }

# Generated at 2022-06-11 03:34:52.671605
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network import HurdNetworkCollector
    import json

    # We will test with the following output of fsysopts
    fsysopts_output = '''--interface=/dev/eth0
--address=192.168.10.10
--netmask=255.255.255.0
--address6=fe80::222:19ff:fe33:4455/64
'''

    class FakeModule(object):
        def __init__(self):
            # Set up basic parameters for the module
            self.params = {}
            self.sysconfig_path = ''


# Generated at 2022-06-11 03:34:59.790508
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = MagicMock(return_value=(0, '--interface=eth0 --address=10.0.0.1 --netmask=255.255.0.0 --address6=fe80::c305:6eff:feea:21e3/64 --address6=fe80::c305:6eff:feea:21e0/64', ''))

    network = HurdPfinetNetwork(module)
    collected_facts = network.populate()

    assert collected_facts['interfaces'] == ['eth0']
    assert collected_facts['eth0']['device'] == 'eth0'
    assert collected_facts['eth0']['active'] is True

# Generated at 2022-06-11 03:35:02.364230
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    assert issubclass(HurdNetworkCollector, NetworkCollector)

# Generated at 2022-06-11 03:35:10.807516
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collected_facts = {}
    networks = HurdNetworkCollector(collected_facts=collected_facts).collect()
    assert networks['interfaces'] == ['eth0', 'eth1']
    assert networks['eth0']['active']
    assert networks['eth0']['device'] == 'eth0'
    assert networks['eth0']['ipv4']['address'] == '192.168.1.6'
    assert networks['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert networks['eth0']['ipv6'] == [{'address': '2001:db8:0:a::1', 'prefix': '64'}]
    assert networks['eth1']['active']