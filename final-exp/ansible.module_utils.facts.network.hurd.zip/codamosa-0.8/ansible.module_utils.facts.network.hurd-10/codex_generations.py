

# Generated at 2022-06-11 03:25:21.277672
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_collector = HurdNetworkCollector()
    iface_facts = network_collector.get_network_facts()
    assert iface_facts['interfaces']

# Generated at 2022-06-11 03:25:23.082666
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert isinstance(c, HurdNetworkCollector)


# Generated at 2022-06-11 03:25:30.121177
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # pylint: disable=R0903
    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, args, check_rc=False):
            return 0, '', ''

    class MockFact(object):
        module = MockModule()

    fact_obj = MockFact()
    network_obj = HurdPfinetNetwork(fact_obj)
    network_facts = network_obj.populate()
    assert 'interfaces' in network_facts
    interfaces = network_facts['interfaces']
    assert interfaces[0] == 'eth0'
    assert 'eth0' in network_facts
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.100'
    assert network

# Generated at 2022-06-11 03:25:31.228451
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()

# Generated at 2022-06-11 03:25:41.929678
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts import collector

    collector.collector.populate(['network'], None, False)

    assert collector.collector.collected_facts['network']['interfaces'] == ['eth0', 'eth1']
    assert collector.collector.collected_facts['network']['eth0']['ipv4'] == {
        u'address': u'192.168.178.47',
        u'netmask': u'255.255.255.0'
    }

# Generated at 2022-06-11 03:25:51.522352
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    answer = {
            'interfaces': ['eth0'],
            'eth0': {
                'active': True,
                'device': 'eth0',
                'ipv4': {
                    'address': '192.168.1.2',
                    'netmask': '255.255.255.0',
                },
                'ipv6': [
                    {'address': 'fe80::a00:27ff:fe8f:c9a9', 'prefix': '64'},
                    {'address': '2001:abcd:fedc:1234:a00:27ff:fe8f:c9a9', 'prefix': '64'}
                ],
            }
        }

    module = dict()
    module['run_command'] = stub_run_command
    module['get_bin_path'] = stub

# Generated at 2022-06-11 03:25:56.714996
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """ Constructor of class HurdPfinetNetwork should set attribute '_fact_class' and '_platform' in appropriate
    way.
    """
    network = HurdPfinetNetwork(None, None)
    assert network._fact_class == HurdPfinetNetwork
    assert network._platform == 'GNU'



# Generated at 2022-06-11 03:26:07.271485
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.facts.network.gnu
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    module = ansible.module_utils.facts.network.gnu.AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all','!min'], type='list'),
            gather_network_resources=dict(type='list'),
        ),
        supports_check_mode=False,
    )


# Generated at 2022-06-11 03:26:08.226114
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector

# Generated at 2022-06-11 03:26:09.889801
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc is not None
    assert hnc.__doc__ is not None

# Generated at 2022-06-11 03:26:26.030189
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import sys
    import unittest

    class AnsibleModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = """server: /servers/socket/inet
--interface=eth0
--address=10.0.0.1
--netmask=255.255.255.0
--address6=2001:db8:1::1/64"""
            self.run_command_err = ''

        def run_command(self, args):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

        def get_bin_path(self, binary):
            return 'fake/path'


# Generated at 2022-06-11 03:26:35.106289
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # mock module
    import sys
    module = sys.modules['__main__']
    module.get_bin_path = lambda _x: '/bin/fsysopts'
    module.run_command = lambda _x: (0, '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0', '')

    # data
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    # assign network facts
    network = HurdPfinetNetwork(module)
    network._socket_dir = '/servers/socket/'
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

    # results

# Generated at 2022-06-11 03:26:36.679867
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurdpfinet = HurdNetworkCollector()
    assert hurdpfinet.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:26:43.813248
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Prepare fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda args, check_rc=False: (0, 'interface=0.0.0.0 address=127.0.0.1 netmask=255.255.255.0', '')

    # Initiate the HurdPfinetNetwork instance
    network = HurdPfinetNetwork(module)

    # Call to the method with a fake socket_path
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, '/bin/fsysopts', '/dev/null')

    assert network_facts['interfaces'] == ['0.0.0.0']

# Generated at 2022-06-11 03:26:48.760605
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test HurdNetworkCollector constructor
    """
    hurd_network_collector = HurdNetworkCollector()
    assert isinstance(hurd_network_collector, HurdNetworkCollector)
    assert isinstance(hurd_network_collector._fact_class, HurdPfinetNetwork)


# Generated at 2022-06-11 03:26:52.637299
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = DummyModule()
    network_facts = HurdPfinetNetwork(module)
    assert(network_facts.platform == 'GNU')
    assert(network_facts._socket_dir == '/servers/socket/')


# Generated at 2022-06-11 03:27:03.153684
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import re
    import tempfile

    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    captured_stdout = tempfile.TemporaryFile()
    m = HurdPfinetNetwork({'ansible_facts': {}, 'module': {'run_command': run_mock_command, 'no_log': False}, 'changed': False})
    network_facts = m.assign_network_facts({}, '/bin/fsysopts', '/servers/socket/inet')
    assert len(network_facts['interfaces']) == 2
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['ipv4']['address'] == '10.1.1.1'

# Generated at 2022-06-11 03:27:10.530610
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=[0, "--interface=pfinet --interface=eth0 --interface6=pfinet6 --interface6=eth0 --address=10.12.15.1 --netmask=255.255.255.0 --address6=::1/128 --address6=fe80::1428:edff:fe9a:9c32/64 --address6=2001:0690:1428:edff:fe9a:9c32/64", ""])
    HurdPfinetNetwork(module).populate()

if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 03:27:11.975984
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    x = HurdNetworkCollector()
    assert x.platform == 'GNU'

# Generated at 2022-06-11 03:27:21.460104
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # For testing purpose
    facts = {}
    network_facts = {}
    module.run_command = ansible_run_command
    fsysopts_path = '/hurd/pfinet'
    socket_path = '/servers/socket/inet6'

    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    module.exit_json(ansible_facts=network_facts)

# Unit test to make the doc works

# Generated at 2022-06-11 03:27:35.584753
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'



# Generated at 2022-06-11 03:27:47.509415
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network import NetworkCollector
    import ansible.module_utils.basic
    import copy
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    def dummy_get_bin_path(arg):
        return '/bin/fsysopts'

# Generated at 2022-06-11 03:27:57.173213
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import pytest

    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector

    collector = HurdNetworkCollector()
    network_facts = collector.collect()

    assert len(network_facts) == 1
    assert 'interfaces' in network_facts
    assert len(network_facts['interfaces']) == 1

    assert 'lo' in network_facts['interfaces']
    assert network_facts['lo']['device'] == 'lo'
    assert network_facts['lo']['active']

    assert network_facts['lo']['ipv4']['address'] == '127.0.0.1'
    assert network_facts['lo']['ipv4']['netmask'] == '255.0.0.0'

# Generated at 2022-06-11 03:28:02.188431
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():

    module = None
    facts = HurdPfinetNetwork(module)

    assert facts.platform == 'GNU'
    assert '_socket_dir' in facts.__dict__
    #assert '_device_name_exceptions' in facts.__dict__  # ?
    #assert '_command_search_paths' in facts.__dict__  # ?

# Generated at 2022-06-11 03:28:04.292882
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict())
    assert network.__class__.__name__ == 'HurdPfinetNetwork'

# Generated at 2022-06-11 03:28:13.887499
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeModule()
    module.run_command = fake_run_command

    hnp = HurdPfinetNetwork()
    hnp.module = module
    hnp.interface = 'eth0'

    network_facts = {}
    socket_path = '/servers/socket/inet'

    network_facts = hnp.assign_network_facts(network_facts, "fsysopts", socket_path)

    assert network_facts['interfaces'][0] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:28:24.462377
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import os
    import os.path
    import tempfile

    ansible_module_path = os.path.join(os.path.dirname(__file__), '../../../../test/ansible_module.py')

    pfinet_socket_dir = os.path.join(tempfile.gettempdir(), 'pfinet-socket')
    os.mkdir(pfinet_socket_dir)
    pfinet_socket_path = os.path.join(pfinet_socket_dir, 'inet')
    os.symlink('/dev/eth0', pfinet_socket_path)

    fd, fsysopts_path = tempfile.mkstemp()

# Generated at 2022-06-11 03:28:25.809724
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)


# Generated at 2022-06-11 03:28:28.983965
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Create an instance of class HurdPfinetNetwork
    pfinet_facts = HurdPfinetNetwork({})
    assert pfinet_facts.platform == 'GNU'


# Generated at 2022-06-11 03:28:37.124648
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Mock module
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import Network, NetworkCollector
    from ansible.module_utils.facts import collector

    class MockModule:
        def get_bin_path(self, name):
            return name

        def run_command(self, args):
            if args[0] == 'fsysopts':
                return 0, 'ifname\n', ''
            if args[0] == 'fsysopts-L':
                if args[1] == '/servers/socket/inet':
                    return 0, '--ifname=eth0\n', ''

# Generated at 2022-06-11 03:29:07.899017
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = DummyAnsibleModule()
    fsysopts_path = HurdPfinetNetwork(module).module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet'
    network_facts = HurdPfinetNetwork(module).assign_network_facts({}, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:29:13.494606
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.collector import NetworkCollector
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    f = HurdPfinetNetwork()
    assert isinstance(f, NetworkCollector)
    assert isinstance(f, HurdPfinetNetwork)

# Generated at 2022-06-11 03:29:17.423093
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor for HurdNetworkCollector should already be tested as part of
    generic NetworkCollector, but we have an extra attribute _platform.
    """
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'


# Generated at 2022-06-11 03:29:25.640849
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    output = """--family=pfinet
--num=1
--interface=/dev/eth0
--address=192.168.122.10
--netmask=255.255.255.0
--broadcast=192.168.122.255
--address6=fe80::5054:ff:fe98:7ed0/64
"""

# Generated at 2022-06-11 03:29:30.125295
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule({})
    mod_path = module.get_bin_path('fsysopts')
    assert mod_path is not None
    net_module = HurdPfinetNetwork(module)
    assert net_module is not None


# Generated at 2022-06-11 03:29:41.130981
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
        This unit test will test the method populate of the class HurdPfinetNetwork
    """

    class AnsibleModuleMock:
        def __init__(self):
            self.run_command = self.run_command_func
            self.get_bin_path = self.get_bin_path_func

        def run_command_func(self, args):
            return 0, '--interface=pfinet0 --address=10.2.2.2 --netmask=255.255.255.0 --address6=fd00:dead:beef::0/64', None

        def get_bin_path_func(self, prog):
            return 'fsysopts'

    module = AnsibleModuleMock()
    hurd = HurdPfinetNetwork(module)
    assert 'interfaces' in hurd.populate

# Generated at 2022-06-11 03:29:47.994919
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import NetworkCollector

    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    socket_dir = os.path.join(test_dir, 'servers/socket')
    test_socket = os.path.join(socket_dir, 'inet')

    os.makedirs(socket_dir)

    orig_run_command = NetworkCollector.run_command
    def fake_run_command(self, args, check_rc=True):
        if args[0] == 'fsysopts' and args[1] == '-e':
            test_file = open(test_socket, 'w')

# Generated at 2022-06-11 03:29:51.603183
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork(dict(module=dict()))
    assert hn.platform == 'GNU'
    assert hn._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:30:02.152616
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import StringIO
    network_facts = {}
    network = HurdPfinetNetwork({}, StringIO(), StringIO(), '', '', '')
    out = (b'--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0 '
           b'--address6=::1/128\n')
    network_facts = network.assign_network_facts(network_facts,
                                                 '/usr/bin/fsysopts',
                                                 '/servers/socket/inet')

# Generated at 2022-06-11 03:30:11.350857
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    fsysopts_path = module.get_bin_path('fsysopts')
    link = os.path.join('/servers/socket/', 'inet')
    if os.path.exists(link):
        socket_path = link
    network_facts = {}

    obj = HurdPfinetNetwork(module)
    res = obj.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:30:54.625246
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c.platform == 'GNU'


# Generated at 2022-06-11 03:31:01.782425
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Simulation of the module argument_spec
    argument_spec = {
        'run_command': {
            'mock': 'ansible.module_utils.basic.AnsibleModule.run_command'
        },
    }

    # Creation of a mock for the class Network
    mock_module = type('MockModule', (object,), argument_spec)

    # Creation of a mock for the method run_command
    def run_command_mock(self, cmd, check_rc=True, close_fds=True):
        """
        :param cmd: The command to run
        :param check_rc: Whether to check the return code or not
        :param close_fds: Whether to close the file descriptors or not
        :return: return code, stdout and stderr
        """

# Generated at 2022-06-11 03:31:10.994853
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleExec:
        def __init__(self):
            self.res = True
            self.output = """--address=192.168.0.42
--netmask=255.255.255.0
--address6=fe80::5266:e5ff:fe5a:64b8/64
--address6=2001:db8:0:1::1/64
"""
        def run_command(self, cmd, tmpfile):
            self.cmd = cmd
            self.tmpfile = tmpfile
            return (self.res, self.output, '')

    module = ModuleExec()
    network_facts = HurdPfinetNetwork(module).assign_network_facts({}, '/foo/bar', '/socket/inet')
    assert network_facts is not None
    assert 'interfaces' in network_facts
   

# Generated at 2022-06-11 03:31:18.333770
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')

    socket_path = os.path.join(HurdPfinetNetwork._socket_dir, 'inet')
    network_facts = {}
    network_facts = HurdPfinetNetwork.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces']

    socket_path = os.path.join(HurdPfinetNetwork._socket_dir, 'inet6')
    network_facts = {}
    network_facts = HurdPfinetNetwork.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces']

# Generated at 2022-06-11 03:31:19.647710
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Unit test for constructor of class HurdPfinetNetwork"""
    obj = HurdPfinetNetwork({}, None)

# Generated at 2022-06-11 03:31:23.769868
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Unit test for constructor of class HurdNetworkCollector
    """
    obj = HurdNetworkCollector()
    assert obj.__class__.__name__ == 'HurdNetworkCollector'
    assert obj._platform == 'GNU'
    assert obj._fact_class.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-11 03:31:33.426396
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec=dict())

    class dummy_module:
        def __init__(self, args):
            self.run_command = lambda cmd: (0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:DB8::1/64', '')

    hnetwork = HurdPfinetNetwork(dummy_module(module))

    network_facts = {}

    hnetwork.assign_network_facts(network_facts, '/usr/bin/fsysopts', '/servers/socket/inet')

    # FIXME: update expected output with new collect_network_facts

# Generated at 2022-06-11 03:31:34.520757
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert isinstance(c, NetworkCollector)

# Generated at 2022-06-11 03:31:36.261063
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:31:37.031543
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork()



# Generated at 2022-06-11 03:33:43.410605
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork({})

if __name__ == '__main__':
    test_HurdPfinetNetwork()

# Generated at 2022-06-11 03:33:51.885698
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command
    fsysopts_path = '/fsysopts_path'
    socket_path = '/test'

    network_facts = {}
    network_mock = HurdPfinetNetwork(module, fsysopts_path, socket_path)
    network_facts = network_mock.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['lo', 'eth0']
    assert network_facts['lo']['active'] is True
    assert network_facts['lo']['device'] == 'lo'
    assert network_facts['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:33:54.431133
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork



# Generated at 2022-06-11 03:34:02.823371
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})

    class HurdPfinetNetwork_Mock(Network):
        platform = 'GNU'
        __socket_dir = 'tests/Unittests/mocks/'

    module = AnsibleModule(argument_spec={})
    class HurdPfinetNetwork_Mock(HurdPfinetNetwork):
        def assign_network_facts(self, network_facts, fsysopts_path, socket_path):
            rc, out, err = self.module.run_command([
                'cat',
                'tests/Unittests/mocks/network/fsysopts_pfinet_inet.out',
            ])
            # FIXME: build up a interfaces datastructure, then assign into network_facts
            network_facts['interfaces'] = []

# Generated at 2022-06-11 03:34:04.559954
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork(dict(module=None), 'test_interface')
    assert m.interface == 'test_interface'


# Generated at 2022-06-11 03:34:13.274661
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    fact_class = HurdPfinetNetwork(module)

    # Set some attributes of fact_class to make the test meaningful
    fact_class.module = module
    fake_fsysopts_path = '/path/to/fsysopts'
    fact_class._fsysopts_path = fake_fsysopts_path
    fake_socket_path = '/path/to/socket'
    fact_class._socket_path = fake_socket_path
    # Open file for reading as alternative to subprocess.Popen
    fake_output_file = open('tests/unit/module_utils/facts/network/HurdPfinetNetwork.txt', 'r')


# Generated at 2022-06-11 03:34:15.283943
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert(HurdNetworkCollector._platform == 'GNU')
    assert(HurdNetworkCollector._fact_class == HurdPfinetNetwork)


# Generated at 2022-06-11 03:34:16.473883
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork()
    assert n.platform == 'GNU'

# Generated at 2022-06-11 03:34:23.223791
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """Assign network facts for GNU Hurd with pfinet"""

    input_data = """--interface=/dev/eth0 --address=192.168.0.12 --netmask=255.255.255.0 --address6=2a00:1450:4009:81c::200e/64"""

    network_facts = {}

    network_facts['interfaces'] = []
    current_if = 'eth0'
    network_facts['interfaces'].append(current_if)
    network_facts[current_if] = {
        'active': True,
        'device': current_if,
        'ipv4': {},
        'ipv6': [],
    }

    network = HurdPfinetNetwork(dict())


# Generated at 2022-06-11 03:34:30.929947
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/servers/socket/'
    socket_path = '/servers/socket/inet'
    out = '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe81:ee27/64'

    m = Mock()
    m.run_command.return_value = (0, out, '')
    n = HurdPfinetNetwork(m)
    network_facts = n.assign_network_facts(network_facts, fsysopts_path, socket_path)