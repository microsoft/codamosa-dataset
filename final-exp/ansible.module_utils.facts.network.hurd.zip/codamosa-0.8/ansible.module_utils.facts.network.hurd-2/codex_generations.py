

# Generated at 2022-06-11 03:25:27.128569
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils import basic
    network_facts = {}
    pfinet_network = HurdPfinetNetwork(basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    ))
    network_facts = pfinet_network.assign_network_facts(
        network_facts,
        '/usr/bin/fsysopts',
        '/servers/socket/inet6'
    )
    assert network_facts['eth0']['ipv4'] == {
        'address': '10.0.2.15',
        'netmask': '255.255.255.0'
    }

# Generated at 2022-06-11 03:25:35.549448
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import tempfile
    import os
    import shutil
    sockdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(sockdir, './servers/socket/'))
    os.mknod(os.path.join(sockdir, './servers/socket/inet'))
    network_module = HurdPfinetNetwork({'ANSIBLE_NET_SOCKET_DIR': sockdir})
    network_module.populate()
    shutil.rmtree(sockdir)


# Generated at 2022-06-11 03:25:37.035159
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'

# Generated at 2022-06-11 03:25:47.994064
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    fsysopts_output = '--interface=eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::6c40:8ff:fe00:0/64'

    network_facts = {}

    network_facts = HurdPfinetNetwork.assign_network_facts(
        HurdPfinetNetwork,
        network_facts,
        fsysopts_output)

    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-11 03:25:57.914480
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path

    # Create a test module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create a HurdPfinetNetwork object
    fact_class = HurdPfinetNetwork(module)

    # Set the fsysopts bin path
    fsysopts_path = get_bin_path('fsysopts')

    # Try to get the socket file path
    socket_path = None
    for l in ('inet', 'inet6'):
        link = os.path.join(fact_class._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break


# Generated at 2022-06-11 03:25:58.989312
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:26:03.160566
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    r = HurdPfinetNetwork({}, "module_utils.facts.network", False)
    assert(r.module == "module_utils.facts.network")
    assert(r.socket_path is None)
    assert(r.fsysopts_path is None)
    assert(r._test_mode == False)

# Generated at 2022-06-11 03:26:11.451940
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import MagicMock
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(0, '', ''))
    mock_module.get_bin_path = MagicMock(return_value='/usr/bin/fsysopts')
    mock_module.fail_json = MagicMock()

    hpn = HurdPfinetNetwork(mock_module)
    hpn.populate()

# Generated at 2022-06-11 03:26:14.573510
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork
    assert isinstance(obj.fact_class, type)


# Generated at 2022-06-11 03:26:19.544884
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, opt_dirs=[]):
            if path == 'fsysopts':
                return True

    module = MockModule(
        dict(
            socket_dir='/servers/socket/'
        )
    )

    class MockHurdPfinetNetwork(HurdPfinetNetwork):
        def __init__(self, module):
            self._fsysopts_path = self.module.get_bin_path(
                'fsysopts', []
            )


# Generated at 2022-06-11 03:26:34.193396
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    Module = type('Module', (object,), {})
    Network.set_module(Module)
    module = Module()

    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'


# Generated at 2022-06-11 03:26:41.437593
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import os
    from unittest.mock import patch
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes

    class ModuleStub:
        def __init__(self):
            self.run_command_called = False
            self.run_command_call_count = 0
            self.run_command_args = None

        def get_bin_path(self, arg):
            # Calling get_bin_path will return a path to the mocked fsysopts if it's provided by the test.
            if 'fsysopts' in arg:
                return os.path.join('tmp', 'fsysopts')
            else:
                return None


# Generated at 2022-06-11 03:26:52.093091
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, ' --interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::4670:bfff:feab:966b/64', ''))
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    # FIXME: compare datastructure
    assert len(network_facts) == 2
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:27:02.622953
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module, fsysopts_path, socket_path = get_mock_module()

    try:
        hurd_pfinet_network = HurdPfinetNetwork(module=module)
    except:
        assert False
    network_facts = {}

# Generated at 2022-06-11 03:27:04.934329
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector(load_on_init=False)
    assert hnc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:07.780474
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_class = HurdPfinetNetwork({})
    assert test_class
    assert test_class._fsysopts_path == '/hurd/pfinet'
    assert test_class._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:27:11.464259
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    if 'Hurd' not in os.uname():
        return
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:16.005174
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    network_facts = HurdPfinetNetwork(module)
    network_facts.collect()
    expected = dict(
        interfaces=[],
    )
    assert network_facts.get_facts() == expected

# Generated at 2022-06-11 03:27:18.146597
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:28.615724
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = Network().populate()
    assert 'enp3s0' in facts['interfaces']
    assert 'enp3s0' in facts
    assert 'lo' in facts['interfaces']
    assert 'lo' in facts
    assert 'enp3s0' in facts['interfaces']
    assert 'enp3s0' in facts
    assert 'ipv4' in facts['enp3s0']
    assert 'ipv6' in facts['enp3s0']
    assert 'address' in facts['enp3s0']['ipv4']
    assert 'netmask' in facts['enp3s0']['ipv4']
    assert isinstance(facts['enp3s0']['ipv4']['address'], str)

# Generated at 2022-06-11 03:27:40.259439
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:27:51.482610
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.ansible_facts = {}
    m = HurdPfinetNetwork(module=module, socket_dir='/servers/socket/')

    m.fsysopts_path = '/bin/fsysopts'
    m.add_if = True
    m.add_ipaddr = True
    m.add_netmask = True
    m.add_ipaddr6 = True

    network = {}

    network['interfaces'] = ['lo', 'eth0', 'eth1']

# Generated at 2022-06-11 03:27:59.457904
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    # create a directory in a temp place to mock server/socket
    import shutil
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    tmp_socket_dir = os.path.join(tmp_dir, 'servers', 'socket')
    os.makedirs(tmp_socket_dir)
    # create the link to pfinet in our mocked socket dir
    os.symlink('/servers/pfinet', os.path.join(tmp_socket_dir, 'inet'))
    # instantiate a ModuleRunner
    from ansible.module_utils.basic import ModuleRunner
    import json
    module_runner = ModuleRunner(module, json.dumps({}), tmp_dir)

# Generated at 2022-06-11 03:28:10.592211
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # Create a dummy base class that has a dummy methods to have a
    # valid instance of HurdPfinetNetwork
    class DummyBase:
        def __init__(self):
            self.module = module
        def get_bin_path(self, path):
            if path == 'fsysopts':
                return '/path_to_fsysopts'
            elif path == 'netstat':
                return '/path_to_netstat'

    base = DummyBase()
    hurd_network = HurdPfinetNetwork(base)

    # Create a fake module to test module.run_command
    class AnsibleModule:
        def __init__(self, argument_spec):
            self.params = {}


# Generated at 2022-06-11 03:28:13.019040
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:28:23.043825
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda _: '/bin/fsysopts'

    pfinet = HurdPfinetNetwork(module=module)
    pfinet.get_bin_path = lambda _: '/bin/fsysopts'

    os.listdir = lambda d: ['inet', 'inet6']
    os.path.exists = lambda p: True

    if_list = pfinet.populate()['interfaces']
    assert len(if_list) == 3
    assert 'lo' in if_list
    assert 'eth0' in if_list
    assert 'sit0' in if_list

    assert pfinet['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:28:26.619508
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector
    """
    collector = HurdNetworkCollector
    assert collector._platform == 'GNU'
    assert collector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-11 03:28:28.433334
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert issubclass(HurdPfinetNetwork, Network)


# Generated at 2022-06-11 03:28:36.701316
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import cache
    from ansible.module_utils.facts.facts import Facts
    # We are using a test runner to execute the method populate

    # We create a fake module object
    module = type('FakeModule', (object,), {
        'run_command': lambda self, arg: arg,
        'get_bin_path': lambda self, arg: arg
    })()

    # We need to create a cache before calling our method populate
    # The cache will be used to simulate the presence of a gce.yml or
    # ec2.yml in the cache directory
    cache_dir = '/tmp'
    cache_file = os.path.join(cache_dir, 'gce.yml')
    cache.write_cache(cache_file, {})

    # We create a fake Facts object to

# Generated at 2022-06-11 03:28:47.219339
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    mod = HurdPfinetNetwork(module=module)

    def run_command_faux(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return None, "--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0 \
--address6=dead:beef::1/64 --address6=dead:beef::2/64 --address6=dead:beef::3/64", None

    def get_bin_path_faux(self, name):
        return '/bin/fsysopts'

    # we expect get_bin_path to return a path
    module.get_bin_path = get_bin_path

# Generated at 2022-06-11 03:29:18.661460
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
    )

    class PatchedModule(object):
        def run_command(self, cmd):
            if cmd == ['fsysopts', '-L', '/servers/socket/inet']:
                return (None, '--interface=/dev/eth0 --address=192.168.1.7 --netmask=255.255.255.0 --address6=fd00::2/64', None)
            # in case /servers/socket/inet doesn't exist
            elif cmd == ['fsysopts', '-L', '/servers/socket/inet6']:
                return (None, '--interface=/dev/eth0 --address=192.168.1.7 --netmask=255.255.255.0 --address6=fd00::2/64', None)

# Generated at 2022-06-11 03:29:27.608710
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock(return_value=(0, '--interface=eth0 --address=10.20.30.40 --netmask=255.255.0.0 --address6=fe80::a00:27ff:fe4a:a8b4/64', ''))
    network = HurdPfinetNetwork(module)
    network.module.get_bin_path = mock.Mock(return_value='/usr/bin/fsysopts')
    network.collect_platform_facts = mock.Mock(return_value=None)
    actual = network.populate()
    assert actual['interfaces'] == ['eth0']
    assert actual['eth0']['ipv4']['address'] == '10.20.30.40'

# Generated at 2022-06-11 03:29:32.905409
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd_pfinet import HurdPfinetNetwork
    network_facts = HurdPfinetNetwork().assign_network_facts({}, 'fsysopts', 'socket_path')
    assert type(network_facts) is dict
    assert 'interfaces' in network_facts

# Generated at 2022-06-11 03:29:42.969841
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    test_obj = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    out = '''--interface=/dev/eth0 --address=192.168.0.3 --netmask=255.255.255.0
    --broadcast=192.168.0.255 --address6=fe80::1/64'''
    module.run_command.return_value = (0, out, None)

    res = test_obj.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:29:45.174175
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()

    assert c.platform == 'GNU'
    assert c.fact_class == HurdNetworkCollector._fact_class

# Generated at 2022-06-11 03:29:55.987151
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.base import NetworkEnvironmentError
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.basic import AnsibleModule

    # Avoid network environment errors

# Generated at 2022-06-11 03:30:06.298623
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-11 03:30:14.550829
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.run_command.return_value = (0, "--interface=/dev/eth0 --address=192.168.1.102 --netmask=255.255.255.0 --address6=fddc:a67a:e9a1::1/64", "")
    pfinet = HurdPfinetNetwork(module)
    pfinet.populate()
    assert module.exit_json.called
    for call in module.exit_json.call_args_list:
        if call[0][0].get('ansible_facts', {}).get('ansible_interfaces'):
            assert call[0][0]['ansible_facts']['ansible_interfaces'] == ['eth0']

# Generated at 2022-06-11 03:30:16.618548
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    nm = HurdPfinetNetwork()
    assert nm.platform == 'GNU'
    assert nm._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:30:19.218753
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(None)
    assert h.platform == 'GNU'
    assert h._fact_class == HurdPfinetNetwork



# Generated at 2022-06-11 03:31:06.282061
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(dict(module=None), 'foo')
    assert h._platform == 'GNU'
    assert h._fact_class == HurdPfinetNetwork
    assert h._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:31:10.660247
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU', "test_HurdNetworkCollector() has failed"
    assert collector._fact_class == HurdPfinetNetwork, "test_HurdNetworkCollector() has failed"
    assert collector._collectors == [], "test_HurdNetworkCollector() has failed"


# Generated at 2022-06-11 03:31:13.966521
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network_collector = HurdNetworkCollector(module)
    network_collector.collect()

    assert network_collector.platform == 'GNU'
    assert network_collector.facts_class.platform == 'GNU'

# Generated at 2022-06-11 03:31:17.056142
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts import Facts
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    network_collector = HurdPfinetNetwork(Facts({}))
    assert network_collector._socket_dir == '/servers/socket/'
    assert network_collector.platform == 'GNU'

# Generated at 2022-06-11 03:31:25.260189
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu.hurd.network import HurdPfinetNetwork as test_net
    tn = test_net(None)
    tn.module.run_command = fake_run_command
    tn.module.get_bin_path = fake_get_bin_path

# Generated at 2022-06-11 03:31:34.993848
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network import Network
    test_network_facts = {}

    # Test with fsysopts & lo
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    test_network_facts = HurdPfinetNetwork.assign_network_facts(
        Network(), test_network_facts, fsysopts_path, socket_path)
    assert test_network_facts['lo']['ipv4']['address'] == '127.0.0.1'
    assert test_network_facts['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert len(test_network_facts['lo']['ipv6']) == 1
    assert test_network

# Generated at 2022-06-11 03:31:37.425507
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = AnsibleModuleMock()
    obj = HurdNetworkCollector(module)
    assert obj._get_fact_class() == HurdPfinetNetwork
    assert obj._get_fact_class().platform == 'GNU'

# Generated at 2022-06-11 03:31:44.130351
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    hnet = HurdPfinetNetwork(module)

    hnet.module.get_bin_path.return_value = '/fsysopts'

    hnet.module.run_command.return_value = (0, '1, 2, 3', '')
    network_facts = hnet.populate()
    hnet.module.run_command.assert_called_with(['/fsysopts', '-L', '/servers/socket/inet'])
    assert network_facts.keys() == set(['interfaces'])
    for k, v in network_facts.items():
        assert v == [], k


# Generated at 2022-06-11 03:31:45.422337
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpn = HurdPfinetNetwork()
    assert hpn.platform == 'GNU'



# Generated at 2022-06-11 03:31:50.412545
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork

    fsysopts_path = '/usr/bin/fsysopts'
    socket_path   = '/servers/socket/inet'

    module = AnsibleModuleMock()
    facts = Facts(module)
    net_mock = HurdPfinetNetwork(module, facts)
    facts = net_mock.assign_network_facts({}, fsysopts_path, socket_path)

    # FIXME: check the network_facts dict



# Generated at 2022-06-11 03:33:58.479851
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    raise NotImplementedError

# Generated at 2022-06-11 03:34:00.458730
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """ test HurdNetworkCollector constructor """
    collector = HurdNetworkCollector()
    assert collector.fact_class.platform == 'GNU'


# Generated at 2022-06-11 03:34:02.858740
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
        """ Constructor test of HurdPfinetNetwork"""
        hurd_pfinet_network = HurdPfinetNetwork(None)
        assert hurd_pfinet_network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:34:11.283546
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec=dict())

    fsysopts_path = 'fsysopts_path'
    module.get_bin_path = MagicMock(side_effect=[fsysopts_path, None])

    socket_path = 'socket_path'
    os.path.exists = MagicMock(return_value=True)

    command_output = 'command output'
    rc = 0
    err = ''

    module.run_command = MagicMock(return_value=(rc, command_output, err))

    network = HurdPfinetNetwork(module)
    network.assign_network_facts = MagicMock(return_value="returned value")

    assert network.populate() == "returned value"

# Generated at 2022-06-11 03:34:19.412760
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    m_module = patch.multiple(HurdPfinetNetwork, module=DEFAULT)
    m_module['module'].run_command.return_value = (0, ' interface=2 --address=10.0.2.15 --netmask=10.0.2.15 ', '')

    n = HurdPfinetNetwork(m_module['module'])
    n.collector = {'default': 'pfinet'}
    facts = n.assign_network_facts({}, '/fsysopts', '/socket')
    assert 'interfaces' in facts
    assert facts['interfaces'] == ['2']
    assert '2' in facts
    assert 'device' in facts['2']

# Generated at 2022-06-11 03:34:20.884051
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    assert HurdPfinetNetwork({}).assign_network_facts({}, '/bin/true', '/bin/true') == {}

# Generated at 2022-06-11 03:34:22.242305
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector.platform == 'GNU'
    assert HurdNetworkCollector.fact_class == HurdPfinetNetwork



# Generated at 2022-06-11 03:34:23.766198
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    a = HurdPfinetNetwork()
    assert a._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:34:25.550954
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork()
    assert net.platform == 'GNU'
    assert net._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:34:26.318741
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    #TODO
    pass
