

# Generated at 2022-06-11 03:25:25.308192
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda *args, **kwargs: (0, '', '')
            self.fail_json = lambda *args, **kwargs: None
            self.get_bin_path = lambda *args, **kwargs: None

    class FakeHurdPfinetNetwork(HurdPfinetNetwork):
        def __init__(self):
            self.module = FakeModule()

    obj = FakeHurdPfinetNetwork()
    assert obj.populate()[0] == {
        'interfaces': []
    }

# Generated at 2022-06-11 03:25:36.455631
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    network_facts = {}
    fact_instance = HurdPfinetNetwork(module)
    fake_fsysopts_path = '/bin/fsysopts'
    fake_socket_path = '/foo/bar'
    # Avoid to spawn a command
    module._run_command = lambda *args, **kwargs: (0, '', '')
    fact_instance.assign_network_facts(network_facts, fake_fsysopts_path, fake_socket_path)
    assert network_facts['interfaces'] == ['lo', 'eth0']
    assert network_facts['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:25:39.433955
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():

    from ansible.module_utils.facts import FactCollector

    fact_collector = FactCollector()
    fact_collector.collect(['network'])


# Generated at 2022-06-11 03:25:49.756196
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    this_module = 'ansible.module_utils.facts.network.hurd'
    m = MockModule(_platform='GNU')
    n = HurdPfinetNetwork(module=m)

    # test without fsysopts and socket directory
    assert n.populate() == {}

    m2 = MockModule(_platform='GNU')
    m2.run_command = Mock(side_effect=lambda x, check_rc=True: ('', '--interface=/dev/eth0 --address=10.1.1.1 --netmask=255.255.255.0', ''))
    n2 = HurdPfinetNetwork(module=m2)
    n2.module.get_bin_path = Mock(return_value='/bin/fsysopts')
    # test on inet
    assert n2.populate

# Generated at 2022-06-11 03:25:51.453220
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_obj = HurdPfinetNetwork(None)
    assert network_obj._socket_dir == '/servers/socket/'



# Generated at 2022-06-11 03:25:57.642233
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # create a instance of module
    module = AnsibleModule(argument_spec={})

    # create a HurdPfinetNetwork object
    hurd_network = HurdPfinetNetwork(module)

    # create a facts dict
    collected_facts = {}

    # run populate method
    result = hurd_network.populate(collected_facts)

    # check the result
    assert collected_facts == result

# Generated at 2022-06-11 03:26:03.206320
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../../..'))
    from ansible.module_utils.facts.network.hurd import HurdNetworkCollector
    collector = HurdNetworkCollector
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:26:12.857148
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of HurdPfinetNetwork object.
    """
    try:
        import ansible
    except ImportError:
        # unit tests should be executed from path of ansible package, if not, try
        # to load ansible package from parent directory.
        ansible_pkg_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ansible_parent_pkg_dir = os.path.dirname(ansible_pkg_dir)
        sys.path.insert(0, ansible_parent_pkg_dir)
        import ansible

    # initialize an empty AnsibleModule object
    module = None
    facts = {'ansible_python_interpreter': '/usr/bin/python'}

    # call constructor of class HurdPfinetNetwork

# Generated at 2022-06-11 03:26:14.070194
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

# Generated at 2022-06-11 03:26:17.761570
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()

    #HurdPfinetNetwork.assign_network_facts() returns an empty list when pfinet
    #is not installed

    assert h.assign_network_facts({}, 'fsysopts', '/servers/socket/inet') == {}


# Generated at 2022-06-11 03:26:26.755512
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    assert network_facts is not None

# Test we get the correct class when called via NetworkCollector

# Generated at 2022-06-11 03:26:35.837621
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network_collector = HurdNetworkCollector(module)
    network_facts = network_collector.populate()
    assert 'interfaces' in network_facts
    assert 'lo' in network_facts['interfaces']
    assert 'eth0' in network_facts['interfaces']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.10'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == 'fe80::d93f:85ff:fe45:3a0d'

# Generated at 2022-06-11 03:26:43.775592
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fact_module = FakeAnsibleModule()

    test_datastructure = {
        'netmask': '255.255.0.0',
        'ipv4': {
            'netmask': '255.255.0.0',
            'address': u'10.1.0.2'
        },
        'interfaces': ['enp0s4'],
        'device': u'enp0s4',
        'ipv6': [
            {
                'prefix': '64',
                'address': u'fe80::a00:27ff:fe58:dbb8'
            },
            {
                'prefix': '64',
                'address': u'fc00:10::2'
            }
        ],
        'active': True,
    }

    network_collector = HurdNetwork

# Generated at 2022-06-11 03:26:54.772742
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import module_utils.facts.network.gnu_hurd.pfinet as pfinet
    fsysopts_path = '/path/to/fsysopts'
    socket_path = '/path/to/socket'
    network_facts = {
        'ansible_fsysopts_path': '/path/to/fsysopts',
        'ansible_fsysopts_socket': '/path/to/socket',
    }
    pfinet.HurdPfinetNetwork._socket_dir = ''

    pfinet_net = pfinet.HurdPfinetNetwork(None)


# Generated at 2022-06-11 03:27:04.978304
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    result = {}
    module.run_command = Mock(return_value=(0, '--address=192.168.1.100 --netmask=255.255.255.0 --address6=2001:470:1f00:1a6::8/64 --address6=2001:470:1f00:1a6::9/64 --interface=/dev/eth0', ''))
    h_network = HurdPfinetNetwork(module)
    result = h_network.populate()

# Generated at 2022-06-11 03:27:07.917804
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    module = fake_ansible_module()
    network_api = HurdPfinetNetwork(module=module)

    network_facts = network_api.populate()

    assert network_facts == {}



# Generated at 2022-06-11 03:27:16.605328
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/fsysopts")

    class MockFacterNetwork(HurdPfinetNetwork):
        def __init__(self, module):
            self.module = module

    network_facts_obj = MockFacterNetwork(module)
    network_facts_obj.populate()

    assert network_facts_obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:27:22.707181
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    ''' Test the constructor of HurdNetworkCollector'''
    is_correct_platform = HurdNetworkCollector._platform == 'GNU'
    if not is_correct_platform:
        print('Incorrect platform')
    is_correct_fact_class = HurdNetworkCollector._fact_class == HurdPfinetNetwork
    if not is_correct_fact_class:
        print('Incorrect _fact_class')
    assert is_correct_fact_class and is_correct_platform

# Generated at 2022-06-11 03:27:24.676166
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert type(collector) == HurdNetworkCollector


# Generated at 2022-06-11 03:27:28.615483
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Test with ifconfig_path undefined
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector
    assert hurd_network_collector.platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:39.228292
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    pass

# Generated at 2022-06-11 03:27:50.289885
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from units.compat import unittest
    from units.compat.mock import patch
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    class TestHurdPfinetNetwork(unittest.TestCase):

        def setUp(self):
            self.test_obj = HurdPfinetNetwork()
            self.test_obj.module = unittest.mock.MagicMock()

# Generated at 2022-06-11 03:27:55.060793
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fsysopts_path = None
    socket_path = None
    network_facts = None
    network_facts = HurdPfinetNetwork(None, fsysopts_path, socket_path).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == []
    return network_facts

# Generated at 2022-06-11 03:28:01.031531
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.gnu.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test_ans
    from ansible.module_utils.facts import AnsibleFacts
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 03:28:03.009552
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()

    assert network
    assert network.platform == 'GNU'

# Generated at 2022-06-11 03:28:13.027311
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    # Redirect to /dev/null stdout and stderr
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')
    network = HurdPfinetNetwork(module)
    ansible = {}
    ansible['ansible_eth0'] = {}
    ansible['ansible_eth0']['ipv4'] = {}
    ansible['ansible_eth0']['ipv4']['address'] = '10.0.2.15'
    ansible['ansible_eth0']['ipv4']['netmask'] = '255.255.255.0'

# Generated at 2022-06-11 03:28:23.470931
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MockModule(object):

        def __init__(self):
            self.rc = 0
            self.out = "--interface=eth0 --address=127.0.0.1 --netmask=255.0.0.0"
            self.err = ""

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    class MockNetwork(HurdPfinetNetwork):

        def __init__(self):
            self.module = MockModule()

    network = MockNetwork()

# Generated at 2022-06-11 03:28:24.952522
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # TODO: Test me
    pass


# Generated at 2022-06-11 03:28:26.898823
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)
    network.populate(None)



# Generated at 2022-06-11 03:28:29.764221
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpf = HurdPfinetNetwork({})
    assert hpf.__class__.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-11 03:28:58.855519
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    module.run_command = lambda args: (0, "--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8::42/128\n" +
                                       "--interface=/dev/eth1 --address=192.168.2.1 --netmask=255.255.255.0 --address6=2001:db8::43/128\n", "")

    network_facts = {}
    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, None, None)

    assert len(network_facts['interfaces']) == 2
    assert network_facts['interfaces'] == ['eth0', 'eth1']

# Generated at 2022-06-11 03:29:02.385721
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = MockModule()
    # test the constructor
    pf = HurdPfinetNetwork(module)
    assert pf is not None
    assert pf._module == module
    assert pf._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:29:05.244462
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert isinstance(network_collector, HurdNetworkCollector) and \
        isinstance(network_collector, NetworkCollector)



# Generated at 2022-06-11 03:29:08.825841
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpn = HurdPfinetNetwork(None)
    assert hpn.platform == 'GNU'
    assert hpn._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:29:10.472502
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an object HurdNetworkCollector
    """
    HurdNetworkCollector()

# Generated at 2022-06-11 03:29:12.641060
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None)._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:29:16.214327
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector._platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:29:20.179203
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = DummyAnsibleModule()
    obj = HurdPfinetNetwork(module)
    obj.populate()
    module.exit_json.assert_called_once_with(ansible_facts={'network': {'interfaces': [], 'devices': []}})


# Dummy AnsibleModule class

# Generated at 2022-06-11 03:29:21.637211
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert HurdPfinetNetwork(dict(module=MockModule())).populate() is not None

# Generated at 2022-06-11 03:29:32.089744
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    This is a test function to test the function populate of the class
    HurdPfinetNetwork. It will create a fake module and test if the output
    of the populate method is the same as the expected output.
    """
    def get_bin_path(self, arg):
        return '/bin/fsysopts'

    class TestModule(object):
        def __init__(self):
            self.run_command = lambda arg: (0,
                '--interface=/dev/eth0 --address=192.168.10.10 --netmask=255.255.255.0 --address6=fe80::1/64\n--interface=/dev/eth1 --address=192.168.10.10 --netmask=255.255.255.0 --address6=fe80::2/64',
                '')

# Generated at 2022-06-11 03:30:14.785155
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:30:23.782834
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    """
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/path/to/socket'
    module = MagicMock()
    run_command = MagicMock()
    run_command.return_value = (0, '--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.255.0.0 --interface6=/dev/eth0 --address6=fe80::223:6cff:fe8d:c5d5/64', '')
    module.run_command.return_value = run_command
    network = HurdPfinetNetwork(module)

# Generated at 2022-06-11 03:30:26.279138
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    r = HurdNetworkCollector()
    assert r
    assert r.platform == 'GNU'
    assert r.fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:30:28.603676
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector(None)
    assert collector._platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:30:30.791793
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    h=HurdNetworkCollector()
    assert h.platform == 'GNU'
    assert h.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:30:32.042390
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork()._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:30:40.869823
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fact_network = HurdPfinetNetwork()

    os.environ['PATH'] = '/bin:/sbin'
    res = fact_network._populate()
    assert 'lo' in res['interfaces']
    assert 'lo' in res
    assert res['lo']['device'] == 'lo'
    assert res['lo']['active'] == True

    assert 'eth0' in res['interfaces']
    assert 'eth0' in res
    assert res['eth0']['device'] == 'eth0'
    assert res['eth0']['active'] == True


if __name__ == '__main__':
    import sys
    import os.path
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    test_HurdPfin

# Generated at 2022-06-11 03:30:43.826595
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = {}

    # Create object for class HurdPfinetNetwork
    test_class = HurdPfinetNetwork(network_facts, '/dev/null', '/dev/null', '/bin/true')

    assert(network_facts['interfaces'] == [])

# Generated at 2022-06-11 03:30:45.716781
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork
    assert obj.platforms == ('GNU',)


# Generated at 2022-06-11 03:30:53.835453
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # test for method 'assign_network_facts'

    # create a instance
    network = HurdPfinetNetwork(None)

    # Create dict for 'network_facts' and 'out'
    network_facts = {}

    out = '--interface=eth0 --address 10.0.0.2 --netmask 255.255.255.0'
    out += ' --mtu=1500 --address6=fe80::a00:27ff:fe97:762e/64'

    # test for ipv4
    network_facts = network.assign_network_facts(network_facts, '/bin/fsysopts', 'socket-path')
    assert network_facts['interfaces'] == ['eth0']

# Generated at 2022-06-11 03:33:00.545424
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    result = dict(
        network_facts={},
        fsysopts_path='/hurd/pfinet',
        socket_path='/servers/socket/inet',
    )

    rc = 0

# Generated at 2022-06-11 03:33:01.355266
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # TODO: implement
    assert True

# Generated at 2022-06-11 03:33:09.510631
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils.facts import __get_module_cache
    module_cache = __get_module_cache()

    # Set the module cache.
    module_cache['ansible_facts.network.GNU'] = None

    # Set the collector class.
    ansible_collector._fact_classes['ansible_facts.network.GNU'] = HurdNetworkCollector

    # Test with fsysopts
    HurdPfinetNetwork._socket_dir = '../../../../../mocks/fsysopts/servers/socket'

    # Test with inet.
    module_cache['ansible_facts.network.GNU']['ansible_network_resources'] = HurdPfinetNetwork().populate()


# Generated at 2022-06-11 03:33:10.534159
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'

# Generated at 2022-06-11 03:33:19.641004
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import os
    import re
    sys.modules['ansible.module_utils.facts.collector'] = __import__('ansible.module_utils.facts.collector')
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.gnu.pfinet.pfinet_pkg import HurdPfinetNetwork


# Generated at 2022-06-11 03:33:20.716616
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # test for existence of the class
    assert HurdPfinetNetwork

# Generated at 2022-06-11 03:33:29.055985
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()

    network_facts = {}

    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    expected_network_facts = {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '192.168.1.1',
                'netmask': '255.255.255.0'
            },
            'ipv6': [
                {'address': '2001:db8::1',
                 'prefix': '64'}
            ]
        }
    }

    pf = HurdPfinetNetwork(module)
    result_network_facts = pf.assign_network_

# Generated at 2022-06-11 03:33:37.051414
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Initialize class
    hp = HurdPfinetNetwork({})

    # Sample data returned by method fsysopts -L
    out = b"""--interface=/dev/eth0 --address=192.168.100.30 --netmask=255.255.255.0 --address6=2001:db8::42/128 --mtu=1500 --broadcast=192.168.100.255 --address6=2001:db8:aaaa:bbbb:cccc:dddd:eeee:ffff/64"""

    # Run test
    network_facts = hp.assign_network_facts({}, '', '')

    # Assert results
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True

# Generated at 2022-06-11 03:33:45.313013
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    module = sys.modules[__name__]
    module.run_command = lambda x: (0,
                                    '--interface=/dev/eth0 --address=192.168.1.100 --netmask=255.255.255.0 --address6=2001::1/64',
                                    '')
    network = HurdPfinetNetwork(module)
    network_facts = {}
    fsysopts_path = '/path/to/fsysopts'
    socket_path = '/path/to/socket'
    result = network.assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:33:53.574010
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork({})
    iface = m.interfaces[0]
    assert m.interfaces[0] == m.ipv4[iface][0]['interface']
    assert m.interface_has_ip(iface, '80.80.80.80')
    assert not m.interface_has_ip(iface, '80.80.80.81')
    assert not m.interface_has_ip(iface, '2001:0db8:85a3:0000:0000:8a2e:0370:7334')
    assert m.interface_has_ip(iface, '2001:db8:85a3:0:0:8a2e:370:7334')
