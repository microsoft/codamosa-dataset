

# Generated at 2022-06-11 03:25:22.713557
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Run with:
    python -m unitest -v ansible.module_utils.facts.network.hurd.hurd_network_collector
    """
    from ansible.module_utils.facts.network.parsers.pfinet import PfinetNetwork
    from ansible.module_utils.facts.network.hurd.hurd_network_collector import HurdNetworkCollector

    instance = HurdNetworkCollector()
    assert isinstance(instance._fact_class, PfinetNetwork)

# Generated at 2022-06-11 03:25:24.724941
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert isinstance(network, Network)

# Generated at 2022-06-11 03:25:36.173737
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, TEST_OUTPUT, ''))
    platform = 'GNU'

    facts_collector = HurdPfinetNetwork(module)
    facts = facts_collector.populate()

    assert facts['interfaces'] == ['eth0']
    assert facts['eth0']['device'] == 'eth0'
    assert facts['eth0']['active'] == True
    assert facts['eth0']['ipv4']['address'] == '169.254.144.9'
    assert facts['eth0']['ipv4']['netmask'] == '255.255.0.0'

# Generated at 2022-06-11 03:25:47.252102
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    net = HurdPfinetNetwork(None)
    conf = net.assign_network_facts({}, 'fsysopts', 'socket')
    assert conf['interfaces'] == ['eth0']
    assert conf['eth0']['device'] == 'eth0'
    assert conf['eth0']['active'] == True
    assert conf['eth0']['ipv4']['address'] == '127.0.1.1'
    assert conf['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert conf['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert conf['eth0']['ipv6'][0]['prefix'] == '64'

# Generated at 2022-06-11 03:25:51.621814
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from fnmatch import fnmatch
    obj = HurdNetworkCollector()
    assert fnmatch(obj._platform, '*Hurd*'), 'Obj platform %s is not GNU' % (obj._platform)
    assert obj._fact_class is not None, 'Obj fact class is none'
    assert obj._fact_class.platform == 'GNU', 'Obj fact class is not HurdPfinetNetwork'



# Generated at 2022-06-11 03:25:54.568694
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:25:56.500760
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert isinstance(HurdPfinetNetwork(), Network)


# Generated at 2022-06-11 03:26:02.242091
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    class_name = 'ansible.module_utils.facts.network.hurd.HurdNetworkCollector'
    class_obj = HurdNetworkCollector
    # class_type = type(class_obj)
    class_name1 = '%s.%s' % (class_obj.__module__, class_obj.__name__)
    assert class_name == class_name1



# Generated at 2022-06-11 03:26:04.694043
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert(HurdPfinetNetwork.platform == 'GNU')
    assert(HurdPfinetNetwork._socket_dir == '/servers/socket/')



# Generated at 2022-06-11 03:26:07.799773
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork(None)

    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'



# Generated at 2022-06-11 03:26:14.928885
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_fact_instance = HurdPfinetNetwork()
    assert network_fact_instance.platform == 'GNU'
    assert network_fact_instance.interfaces == []


# Generated at 2022-06-11 03:26:25.819012
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeModule()
    network_facts = {}

    result = HurdPfinetNetwork(module).assign_network_facts(network_facts,
        fsysopts_path='fsysopts', socket_path='socket')


# Generated at 2022-06-11 03:26:26.712831
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:26:29.091118
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    gnu_network = HurdPfinetNetwork({})
    assert gnu_network.platform == 'GNU'


# Generated at 2022-06-11 03:26:37.621300
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    run_command = MockFunction()

    class Module:
        def __init__(self):
            self.run_command = run_command

    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    # trivial test with no interfaces
    network_facts = {}
    HurdPfinetNetwork(Module()).assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == []

    # test for 2 interfaces

# Generated at 2022-06-11 03:26:39.949429
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc._platform == 'GNU'
    assert hnc._fact_class == HurdPfinetNetwork
# Test for method collect of HurdNetworkCollector

# Generated at 2022-06-11 03:26:47.064775
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork

    network_facts = {
        'interfaces': []
    }
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    current_if = None
    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False,
        )

# Generated at 2022-06-11 03:26:48.011622
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    pass


# Generated at 2022-06-11 03:26:50.100713
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hurd_network_collector = HurdNetworkCollector()
    assert type(hurd_network_collector) == HurdNetworkCollector

# Generated at 2022-06-11 03:27:01.211173
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MagicMock()
    fsysopts = '/foo/fsysopts'
    network_facts = {
        'foo': 'bar',
    }
    module.get_bin_path.return_value = fsysopts
    hpn = HurdPfinetNetwork(module)
    with patch('os.path.exists') as ope:
        ope.return_value = False
        assert hpn.populate(network_facts) == network_facts
        ope.assert_called_with('/servers/socket/inet')
    with patch('os.path.exists') as ope:
        ope.return_value = True

# Generated at 2022-06-11 03:27:22.289986
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module:
        def __init__(self):
            self.run_command = run_command

        def get_bin_path(self, name, opts=None, required=False):
            return '/bin/' + name

    def run_command(command, check_rc=True, close_fds=True, executable=None, data=None):
        print('args:', command)
        if command[1] == '-L' and command[2] == '/servers/socket/inet':
            return 0, '--address=X.X.X.X --netmask=X.X.X.X --interface=/dev/eth0 --address6=Y.Y.Y.Y/32', None

# Generated at 2022-06-11 03:27:24.633519
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module_mock = MockModule()
    assert HurdPfinetNetwork(module_mock).platform == 'GNU'


# Generated at 2022-06-11 03:27:26.414969
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_facts = HurdPfinetNetwork()
    assert 'GNU' == network_facts.platform

# Generated at 2022-06-11 03:27:34.308039
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import pytest

    fsysopts_path = pytest.helpers.fsysopts_path

    facts = {
        'interfaces': [],
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

    # simulate GNU Hurd machine with no network
    path = '/servers/socket'
    network = HurdPfinetNetwork(None, facts, path)
    network.module.run_command = pytest.helpers.run_command

    network_facts = network.populate()
    assert {'interfaces': []} == network_facts

    # simulate GNU Hurd machine with 2 ethernet
    path = '/servers/socket/inet'
    network = HurdPfinetNetwork(None, facts, path)
    network.module.run

# Generated at 2022-06-11 03:27:46.097865
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()

# Generated at 2022-06-11 03:27:56.488072
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import tempfile

    temp_fd, temp_path = tempfile.mkstemp()
    os.write(temp_fd, b"""
--interface=/dev/eth0
--enabled
--address=192.168.1.1
--netmask=255.255.255.0
--address6=fe80::f816:3eff:fece:9f1a/64
--enabled6
--interface=/dev/eth1
--enabled
--address=192.168.1.2
--netmask=255.255.255.0
--address6=fe80::f816:3eff:fece:9f1b/64
--enabled6
""")
    os.close(temp_fd)


# Generated at 2022-06-11 03:27:57.989373
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pfinet = HurdPfinetNetwork()
    assert pfinet._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:27:59.465572
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector is not None


# Generated at 2022-06-11 03:28:10.593351
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.get_bin_path = FakeGetBinPath()
    module.run_command.side_effect = [
        (0, "interface=foo\n", ''),
        (0, "--address=127.0.0.1\n", ''),
        (0, "--netmask=255.255.255.0\n", ''),
        (0, "--address6=::1/128\n", ''),
    ]
    module.get_bin_path.side_effect = ['fsysopts']
    h = HurdPfinetNetwork(module)


# Generated at 2022-06-11 03:28:19.510190
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Set up class and module
    module = AnsibleModule(argument_spec={})
    module.check_mode = True
    HurdPfinetNetwork.module = module
    HurdPfinetNetwork.socket_dir = '/servers/socket/'
    # The expected output from fsysopts
    out = (
        '--interface=/dev/eth0 --address=192.168.1.2 '
        '--netmask=255.255.255.0 --broadcast=192.168.1.255 '
        '--address6=fe80::a00:27ff:fe34:f9cd/64\n'
    )
    err = ''
    rc = 0

    # Set up the mock run_command

# Generated at 2022-06-11 03:28:42.598923
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c._platform == "GNU"
    assert c._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:28:53.343199
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    test HurdPfinetNetwork.assign_network_facts()
    """
    module = MockAnsibleModule()
    # Case where just one interface is configured
    fsysopts_path = '/bin/fsysopts'
    pf = HurdPfinetNetwork(module)
    link = 'inet'
    socket_path = os.path.join(pf._socket_dir, link)
    network_facts = {}
    rc = 0
    out = '--interface=/dev/eth0 --mode=manual --address=192.168.0.100 --netmask=255.255.255.0'
    err = ''
    module.run_command.return_value = rc, out, err

# Generated at 2022-06-11 03:29:01.382763
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockAnsibleModule()
    module.run_command = Mock(return_value=(0, '--interface=eth0 --address=1.2.3.4 --netmask=255.255.255.0 \
--address6=2::1/64', ''))
    network = HurdPfinetNetwork()
    network.module = module
    network.populate()
    assert module.exit_json.call_count == 1
    assert module.exit_json.call_args[0][0]['ansible_facts']['interfaces'][0] == 'eth0'
    assert module.exit_json.call_args[0][0]['ansible_facts']['eth0']['ipv4']['address'] == '1.2.3.4'
    assert module.exit_json.call

# Generated at 2022-06-11 03:29:12.595883
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # This function requires python3
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    m = HurdPfinetNetwork({})
    m.module = type("Foo", (), {})()
    m.module.run_command = lambda x: (0,
"""--interface=eth0
--address=192.168.1.100
--netmask=255.255.255.0
--address6=fe80::2e0:4cff:fe08:4b4/10
--interface=lo0
--address=127.0.0.1
--netmask=255.0.0.0
--address6=::1/128""", '')
    network_facts = {}

# Generated at 2022-06-11 03:29:14.770338
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact_class = HurdNetworkCollector(None)._fact_class
    assert fact_class is HurdPfinetNetwork, 'Not the expected class.'

# Generated at 2022-06-11 03:29:17.928967
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    print("constructor of HurdPfinetNetwork:")
    net = HurdPfinetNetwork()
    print("print network:", net)
    assert net.platform == 'GNU'


# Generated at 2022-06-11 03:29:20.690791
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollectorObj = HurdNetworkCollector()
    assert HurdNetworkCollectorObj._fact_class is HurdPfinetNetwork
    assert HurdNetworkCollectorObj._platform is 'GNU'

# Generated at 2022-06-11 03:29:22.025025
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector is not None


# Generated at 2022-06-11 03:29:23.709171
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()
    assert network.platform == 'GNU'
    assert network._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:29:34.476511
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    fsysopts_path = '/path/fsysopts'
    socket_path = '/path/socket/'
    output = '''
--interface=eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=2001:db8:1::1/128
--interface=lo
--address=127.0.0.1
--netmask=255.0.0.0
--address6=::1/128
'''
    network_facts = {}

# Generated at 2022-06-11 03:30:16.071087
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()
    assert network.__class__.__name__ == 'HurdNetworkCollector'

# Generated at 2022-06-11 03:30:16.588611
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    pass

# Generated at 2022-06-11 03:30:20.806512
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor of class HurdPfinetNetwork
    """
    network_facts = HurdPfinetNetwork(None)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'

# Unit tests for populate method of class HurdPfinetNetwork

# Generated at 2022-06-11 03:30:21.960755
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)

# Generated at 2022-06-11 03:30:24.680820
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({}, {}, {})
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:30:29.253379
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'  # pylint: disable=protected-access


# Generated at 2022-06-11 03:30:38.434363
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = 0, """
--interface=eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe5c:b7d6/64
""", None
    obj = HurdPfinetNetwork(module)

    network_facts = {}

    network_facts = obj.assign_network_facts(network_facts, '/bin/fsysopts', '/servers/socket/inet')


# Generated at 2022-06-11 03:30:46.745658
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    fact_class = HurdPfinetNetwork(module)
    if fact_class.fsysopts_path is None:
        pytest.skip("GNU Hurd not found")
    facts = fact_class.populate()
    assert isinstance(facts['interfaces'], list)
    assert len(facts['interfaces']) > 0
    assert 'lo' in facts['interfaces']
    assert isinstance(facts['enp0s3'], dict)
    assert facts['enp0s3']['device'] == 'enp0s3'
    assert isinstance(facts['enp0s3']['ipv4'], dict)

# Generated at 2022-06-11 03:30:54.583417
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import json
    from ansible.module_utils._text import to_bytes
    # create a module and populate facts
    class ModuleStub():
        def __init__(self):
            self.params = {}
        def run_command(self, command):
            if command == ['fsysopts', '-L', '/servers/socket/inet']:
                return 0, to_bytes(
                    '''--address=172.28.128.59 --broadcast=172.28.255.255 --interface=/dev/eth0 --netmask=255.255.0.0'''
                ), None

# Generated at 2022-06-11 03:30:55.834415
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.__class__ == HurdNetworkCollector


# Generated at 2022-06-11 03:32:59.436590
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import tempfile
    directory = tempfile.mkdtemp()

# Generated at 2022-06-11 03:33:00.901987
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    data = HurdPfinetNetwork(None)
    assert isinstance(data, object)


# Generated at 2022-06-11 03:33:03.392688
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    collector = HurdNetworkCollector()
    result = collector.parse()
    assert result.pop('default_ipv4')
    assert result.pop('default_ipv6')
    assert 'interfaces' in result

# Generated at 2022-06-11 03:33:05.097041
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert hasattr(HurdPfinetNetwork, 'platform')
    network = HurdPfinetNetwork()


# Generated at 2022-06-11 03:33:12.913572
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a fake module with args and facts
    module = type('module', (object,), dict(
        params=dict(),
        run_command=lambda *a, **kw: dict(rc=0, out='', err=''),
        get_bin_path=lambda *a: '/bin/fsysopts',
        facts=dict(network={}),
    ))()

    # Register this fact class with the fact class registry
    NetworkCollector.register_fact_class(HurdNetworkCollector)

    # Create an instance of HurdPfinetNetwork
    fact_class_inst = HurdPfinetNetwork(module)

    # Populate the fact_class_inst
    fact_class_inst.populate()

    # Check the collected facts
    assert isinstance(module.facts['network'], dict)

# Generated at 2022-06-11 03:33:14.448210
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector is not None
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:33:23.773589
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    def mock_run_command(self, args=None, check_rc=True):
        out = ''
        if args[0] == '/sbin/fsysopts':
            if args[-1] == '/servers/socket/inet':
                out = '--interface=/dev/eth0 --address=10.0.1.10 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe48:f1d0/64'
            elif args[-1] == '/servers/socket/inet6':
                out = '--interface=/dev/eth1 --address=10.0.0.10 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe48:f1d0/64'


# Generated at 2022-06-11 03:33:26.021369
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fake_module = FakeModule()
    network = HurdPfinetNetwork(fake_module)
    network.populate()


# Generated at 2022-06-11 03:33:32.086502
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={'module_name': {'type': 'str', 'required': True},
                                          'module_args': {'type': 'dict', 'required': False, 'default': {}}})
    # This is a little hacky, but will work for now
    module.run_command = lambda x: (0, 'not found', '')
    module.get_bin_path = lambda x: None
    network = HurdPfinetNetwork(module)
    global network_facts
    network_facts = network.populate()
    assert network_facts == {}


# Generated at 2022-06-11 03:33:40.287402
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MockModule:
        def run_command(self, args):
            if args == ['/bin/fsysopts', '-L', '/servers/socket/inet']:
                return 0, "--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::250:56ff:fe88:5bc6/64", ""
            else:
                return -1, "", ""
    m = MockModule()
    n = HurdPfinetNetwork(m)
    network_facts = {}
    n.assign_network_facts(network_facts, '/bin/fsysopts', '/servers/socket/inet')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active']