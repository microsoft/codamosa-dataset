

# Generated at 2022-06-11 03:25:19.192508
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert(obj)
    assert(obj._fact_class)
    assert(obj.collect() == {})

# Generated at 2022-06-11 03:25:21.177487
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'

# Generated at 2022-06-11 03:25:25.402060
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.network import NetworkCollector

    obj = NetworkCollector()
    assert obj._platform == 'Generic'
    assert obj._fact_class == Network

    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork



# Generated at 2022-06-11 03:25:27.157530
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Create a instance of HurdPfinetNetwork.
    """
    network = HurdPfinetNetwork({})
    assert network is not None

# Generated at 2022-06-11 03:25:32.114900
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    '''
    Constructor of class HurdPfinetNetwork
    '''
    module = object
    hurddevice = HurdPfinetNetwork(module)
    assert hurddevice.platform == 'GNU'


# Generated at 2022-06-11 03:25:35.409777
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    os.environ['LANG'] = 'C'
    network = HurdNetworkCollector()
    assert network._fact_class.__class__.__name__ == 'HurdPfinetNetwork'
    del os.environ['LANG']

# Generated at 2022-06-11 03:25:46.417301
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    with open('/proc/sys/kernel/ostype') as f:
        ostype = f.readline()
    with open('/proc/sys/kernel/osrelease') as f:
        osrelease = f.readline()
    if osrelease.startswith('GNU') and ostype.startswith('GNU'):
        network = HurdPfinetNetwork({})
        network.module.run_command = lambda x: (0, '--interface=/dev/eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::a00:27ff:fe33:17a9/64 --address6=fdc6:a7e8:616a:b7a:a00:27ff:fe33:17a9/64', '')

# Generated at 2022-06-11 03:25:53.949286
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys
    import json
    # On GNU/Hurd the PFINET network is the only network interface
    # the others network interfaces are not supported yet.
    # So, test only the pfinet network.

    # mock module
    class MockModule():
        def __init__(self):
            self.params = None
            self.run_command_calls = 0
            self.run_command_success = False
            self.run_command_output = None
            self.run_command_output2 = None
            self.run_command_output3 = None
            self.run_command_output4 = None
            self.run_command_output5 = None
            self.run_command_output6 = None
            self.get_bin_path_calls = 0
            self.get_bin_path = None


# Generated at 2022-06-11 03:26:04.963560
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys
    import unittest

    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    class MockModule(object):
        def run_command(self, args):
            stdout = '--interface=lo0 --address=127.0.0.1 --netmask=255.0.0.0'
            stderr = ''
            return 0, stdout, stderr

    # set up program to return test values
    mod = MockModule()
    hpn = HurdPfinetNetwork(mod)

    network_facts = {}

    hpn.assign_network_facts(network_facts, '', '')

    # assert the expected value

# Generated at 2022-06-11 03:26:14.276592
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.network.base import Network

    # Set up Facts class
    facts = Facts()
    facts.get_facts()

    # Set up Network class
    network = Network(facts.get_ansible_module())

    # Set up HurdPfinetNetwork class, then run assign_network_facts
    hurd_pfinet = HurdPfinetNetwork(network._module)

    test_fsysopts = 'this_is_a_test_fsysopts'
    test_socket = 'this_is_a_test_socket'

# Generated at 2022-06-11 03:26:20.907865
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

# Generated at 2022-06-11 03:26:31.001864
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    testmodule = AnsibleModule(argument_spec={})
    testmodule.run_command = lambda command: (0, test_data['fsysopts_output'], '')
    test_data['fsysopts_output'] = """--interface=eth0
--address=10.0.2.15
--netmask=255.255.255.0
--server=10.0.2.2"""
    testclass = HurdPfinetNetwork(module=testmodule)

# Generated at 2022-06-11 03:26:33.434523
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec=dict())
    fc = HurdPfinetNetwork()
    fc.assign_network_facts({}, '/bin/fsysopts', '/servers/socket/inet')

# Generated at 2022-06-11 03:26:36.206078
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network_module = HurdPfinetNetwork('GNU', 'host')
    assert network_module.platform == 'GNU'
    assert network_module._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:26:40.738972
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
        ),
        supports_check_mode=True,
    )
    network_facts = HurdPfinetNetwork(module).populate()
    assert isinstance(network_facts.get('default_ipv4'), dict)
    assert isinstance(network_facts.get('lo'), dict)
    assert isinstance(network_facts.get('all_ipv4_addresses'), list)

# Generated at 2022-06-11 03:26:50.239714
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import collector

    # Initialize a HurdPfinetNetwork object
    hpf = HurdPfinetNetwork(collector)

    # Default input for assign_network_facts
    fsysopts_path = '/fsysopts'
    socket_path = '/socket_path'
    network_facts = {}

    # Assign values to network_facts
    network_facts = hpf.assign_network_facts(network_facts, fsysopts_path, socket_path)

    # Get the interfaces
    interfaces = network_facts.get('interfaces')

    # Check if the value of interfaces is correct
    assert interfaces[0] == 'lo'

    # Get the interface lo
    lo = network_facts.get('lo')

    # Check the value of device
    assert lo.get

# Generated at 2022-06-11 03:26:52.189174
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    # assert isinstance(collector, dict)

# Generated at 2022-06-11 03:26:54.443600
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:04.682383
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys

    if sys.platform != 'gnu0':
        print("Skipping test_HurdPfinetNetwork_populate on non GNU platform")
        assert True
        return

    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    def get_module(args=None):
        from ansible.module_utils.facts.system.distribution import DistributionFactModule
        distribution_collector = DistributionFactCollector(module=DistributionFactModule(), collected_facts=None)

# Generated at 2022-06-11 03:27:05.817283
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:27:18.379817
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()

    assert collector._platform == 'GNU'
    assert collector._fact_class is HurdPfinetNetwork

# Generated at 2022-06-11 03:27:20.212404
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None


# Generated at 2022-06-11 03:27:30.058629
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeModule()
    network = HurdPfinetNetwork(module)
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet6'
    network_facts = {}
    network_facts['interfaces'] = []
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    # check assigned network facts
    assert network_facts['interfaces'] == ['lo0', 'eth0']

# Generated at 2022-06-11 03:27:39.966650
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    obj = HurdPfinetNetwork()
    obj.module = MockModule()
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = obj.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert len(network_facts['interfaces']) == 1
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'

# Generated at 2022-06-11 03:27:44.312949
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, '', ''))
    network_facts = network.HurdPfinetNetwork().populate(None)
    assert network_facts == {
        'interfaces': []
    }


# Generated at 2022-06-11 03:27:55.066456
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes, to_native

    # create a module for the unit test
    module = basic.AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # create a dummy os.path
    path = 'ansible.module_utils.facts.network.gnu.hurd.os.path'
    path_mock = collector._mock_module(path)
    module.params['gather_subset'] = ['network']
    module.exit_json = lambda x: x


# Generated at 2022-06-11 03:27:57.975453
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert HurdPfinetNetwork().populate() == {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '10.0.1.101',
                'netmask': '255.255.255.0'
            },
            'ipv6': [{
                'address': '2001:db8:a:b:0:0:0:0',
                'prefix': '64'
            }]
        }
    }


# Generated at 2022-06-11 03:28:01.862759
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert isinstance(network_collector, HurdNetworkCollector)
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-11 03:28:03.732848
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c.collect() == dict(), 'Empty dict'


# Generated at 2022-06-11 03:28:05.915370
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(object(), None)
    assert network.platform == 'GNU'

# Generated at 2022-06-11 03:28:35.336603
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockAnsibleModule()

    fsysopts_path = None
    socket_path = '/servers/socket/inet'

    network_facts = {}
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['lo'] == {
        'active': True,
        'device': 'lo',
        'ipv4': {'address': '127.0.0.1', 'netmask': '255.0.0.0'},
        'ipv6': [{'address': '::1', 'prefix': '128'}]
    }

# Generated at 2022-06-11 03:28:36.206836
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None).platform == 'GNU'


# Generated at 2022-06-11 03:28:46.682207
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Test with no fsysopts
    test_module = MockAnsibleModule()
    facter_instance = HurdPfinetNetwork(test_module)
    network_facts = facter_instance.assign_network_facts(None, None, None)
    assert network_facts == {}

    # Test with fsysopts, but no output
    test_module = MockAnsibleModule(commands={'fsysopts': {'rc': 0, 'out': '', 'err': ''}})
    facter_instance = HurdPfinetNetwork(test_module)
    network_facts = facter_instance.assign_network_facts(None, '/fake/fsysopts', '/fake/socket')
    assert network_facts == {}

    # Test with fsysopts, and some output
    test_module

# Generated at 2022-06-11 03:28:50.816288
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    facts_network = HurdPfinetNetwork()
    if isinstance(facts_network, HurdPfinetNetwork):
        print("Success: test_HurdPfinetNetwork")
    else:
        print("Failure: test_HurdPfinetNetwork")


# Generated at 2022-06-11 03:28:52.129952
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)


# Generated at 2022-06-11 03:28:56.401043
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    This function tests if the assign_network_facts function give the right output
    :return
    """
    import ansible.module_utils.facts.network.gnu.pfinet.HurdPfinetNetwork as HurdPfinetNetwork
    dut = HurdPfinetNetwork()
    dut.module = None
    self._socket_dir = "./testdata/pfinet"
    network_facts = {}
    fsysopts_path = "./testdata/fsysopts"

    for socket_path in ["./testdata/pfinet/inet", "./testdata/pfinet/inet6"]:
        network_facts = dut.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-11 03:28:58.257238
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({}, None)
    assert h
    assert h.platform == 'GNU'

# Generated at 2022-06-11 03:29:08.349804
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule()
    fact = HurdPfinetNetwork(module)

    socket_path = os.path.join(fact._socket_dir, 'inet')
    fsysopts_path = '/bin/fsysopts'

    network_facts = {}

    network_facts = fact.assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.0'

# Generated at 2022-06-11 03:29:12.735028
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    # Construct object
    obj = HurdNetworkCollector()
    # Check obj.platform is 'GNU'
    assert obj._platform is 'GNU'
    # Check obj._fact_class is HurdPfinetNetwork
    assert obj._fact_class is HurdPfinetNetwork


# Generated at 2022-06-11 03:29:22.247609
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.community.general.plugins.module_utils.facts.facts import Facts
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({}, {}, supports_check_mode=True)
    module.run_command = lambda args, check_rc=False: (0, 'v4=--interface=eth0 --address=127.0.0.1 --netmask=255.0.0.0 v6=--address6=::1', '')

    pfinet_module_path = os.path.join(unfrackpath(Facts), 'network', 'pfinet.yaml')
    os.makedirs(os.path.dirname(pfinet_module_path))

# Generated at 2022-06-11 03:30:05.897840
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({}, {}, {})
    assert isinstance(obj, HurdPfinetNetwork)

# Generated at 2022-06-11 03:30:14.272707
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from collections import defaultdict
    from ansible.module_utils._text import to_bytes

    network_facts = defaultdict(lambda: defaultdict(dict))
    # FIXME: When possible, use unittest.mock for this

# Generated at 2022-06-11 03:30:16.619117
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc.__class__.__name__ == 'HurdNetworkCollector'
    assert hnc.platform == HurdPfinetNetwork.platform

# Generated at 2022-06-11 03:30:18.009933
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc.platform == 'GNU'

# Generated at 2022-06-11 03:30:19.733626
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork(
        '/servers/socket/inet6'
    )


# Generated at 2022-06-11 03:30:22.454431
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd = HurdPfinetNetwork({}, {'run_command':run_command}, [])
    assert(hurd.platform == 'GNU')
    assert(hurd._socket_dir == '/servers/socket/')


# Generated at 2022-06-11 03:30:32.368884
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a dummy module with a dummy HurdPfinetNetwork instance
    class DummyModule:
        def get_bin_path(self, command):
            return '/usr/bin/fsysopts'

        def run_command(self, command):
            if '/usr/bin/fsysopts' in command:
                if ' --interface=eth0' in command:
                    # FIXME: test IPv6
                    return 0, '''--interface=eth0
--address=192.168.1.1
--netmask=255.255.255.0
--address6=2001:db8:1234::1/64
--address6=2001:db8:1234::2/64''', ''

# Generated at 2022-06-11 03:30:41.152918
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule({})
    result = dict(changed=False, ansible_facts=dict(network=dict()))
    result['ansible_facts'] = dict(network=dict(interfaces=[]))
    result['ansible_facts']['network']['interfaces'].append('eth0')
    result['ansible_facts']['network']['eth0'] = dict()
    result['ansible_facts']['network']['eth0']['ipv4'] = dict()
    result['ansible_facts']['network']['eth0']['ipv4']['address'] = '10.0.2.15'

# Generated at 2022-06-11 03:30:42.034559
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({'use_ipv6': True}, [], [])
    assert network

# Generated at 2022-06-11 03:30:43.754883
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    m = HurdPfinetNetwork({"ansible_facts": {}})
    assert m.platform == 'GNU'


# Generated at 2022-06-11 03:32:45.961348
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    # Check if not None
    assert collector is not None
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:32:47.464469
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:32:49.321464
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:32:50.858651
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # testing the constructor
    pfinet_net_obj = HurdPfinetNetwork()
    assert pfinet_net_obj


# Generated at 2022-06-11 03:32:54.647228
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector is tested
    """
    import ansible.module_utils.facts.network.hurd
    obj = ansible.module_utils.facts.network.hurd.HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:33:02.825975
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-11 03:33:04.649946
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor of HurdNetworkCollector class
    """
    collector = HurdNetworkCollector()
    assert collector.fact_class == HurdPfinetNetwork, \
        "Constructor of HurdPfinetNetwork class to assign fact class"
    assert collector.platform == 'GNU', "Constructor of HurdPfinetNetwork to assign platform"

# Generated at 2022-06-11 03:33:09.038220
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import json
    import sys
    fsysopts_path = sys.argv[1]
    socket_path = sys.argv[2]
    n = HurdPfinetNetwork({})
    sys.stdout.write(json.dumps(n.assign_network_facts({
        'interfaces': [],
    }, fsysopts_path, socket_path)))


# Generated at 2022-06-11 03:33:10.044906
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert isinstance(HurdNetworkCollector(), NetworkCollector)

# Generated at 2022-06-11 03:33:19.119684
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModuleMock(
        dict(
            ansible_facts=dict(
                network_interface_facts=dict(),
                ansible_all_ipv4_addresses=[],
                ansible_all_ipv6_addresses=[],
            ),
            run_command=run_command_mock(),
        )
    )

    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    # example fsysopts output
    out = '--interface=/dev/eth0 --address=192.168.0.5 --netmask=255.255.255.0 ' \
          '--address6=1234:5678:90AB:CDEF:1234:5678:90AB:CDEF/64'
    module.run_command