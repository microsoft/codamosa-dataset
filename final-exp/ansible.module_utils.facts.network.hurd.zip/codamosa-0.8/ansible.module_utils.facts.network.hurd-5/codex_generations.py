

# Generated at 2022-06-11 03:25:20.646602
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj


# Generated at 2022-06-11 03:25:28.898022
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module_class = 'ansible.module_utils.facts.network.gnu.hurd_pfinet.HurdPfinetNetwork'
    field_name = 'assign_network_facts'

    # should return a dictionary with the two interfaces
    arg_string = """/fsysopts --interface=/dev/eth0 --address=192.168.1.240 --netmask=255.255.255.0 --address6=/2001:db8::c001:240/64 --interface=/dev/eth1 --address=10.1.1.1 --address6=/2001:db8::d001:240/64"""

# Generated at 2022-06-11 03:25:40.429541
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''
    Test of method populate of class HurdPfinetNetwork
    '''
    class MockedModule():
        def run_command(self, args):
            return 0, '''--interface=/dev/eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::a00:27ff:febd:2f8c%eth0/64 --address6=1026::f816:3eff:fef4:f5d5%eth0/64''', ''
    class MockedNetworkCollector():
        def __init__(self):
            self._platform = 'GNU'
    mocked_module = MockedModule()
    mocked_network = HurdPfinetNetwork(mocked_module, MockedNetworkCollector())
    network_facts = {}

# Generated at 2022-06-11 03:25:50.517018
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = object
    module.run_command = lambda x: ('', '--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=2001:db8::10/64', '')
    module.get_bin_path = lambda x: '/bin/fsysopts'
    hurd1 = HurdPfinetNetwork(module)
    assert hurd1.get_device() == 'eth0'
    assert hurd1.get_ipv4_address() == '192.168.1.2'
    assert hurd1.get_ipv4_netmask() == '255.255.255.0'
    assert hurd1.get_ipv6_address() == '2001:db8::10'

# Generated at 2022-06-11 03:25:52.012135
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Nothing to check
    pass

# Generated at 2022-06-11 03:25:53.692202
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Constructor test for class HurdPfinetNetwork
    """
    assert HurdPfinetNetwork(dict())

# Generated at 2022-06-11 03:26:04.785077
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork

    test_obj = HurdPfinetNetwork(Facts())

    test_param = {
        'network_facts': '',
        'fsysopts_path': 'None',
        'socket_path': 'None',
    }
    test_result = test_obj.assign_network_facts(**test_param)
    assert test_result == {}

    test_param = {
        'network_facts': {},
        'fsysopts_path': '',
        'socket_path': '',
    }
    test_result = test_obj.assign_network_facts(**test_param)
    assert test_result == {}

# Generated at 2022-06-11 03:26:14.201987
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    socket_path = '/servers/socket/inet'
    fsysopts_path = '/fsysopts'
    fsysopts_output = '''
--interface=/dev/eth0 --address=127.0.0.1 --netmask=255.0.0.0 --broadcast=127.255.255.255 --address6=fe80::2%eth0/64 --address6=::1/128 --address6=fe80::1%lo0/64 --address6=::1/128
'''
    module.run_command = MagicMock()
    module.run_command.return_value = (0, fsysopts_output, '')
    network = HurdPfinetNetwork(module)

# Generated at 2022-06-11 03:26:18.867667
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import snmpfacts
    NetworkCollector.register(HurdNetworkCollector)
    snmpfacts.NetworkCollector.register(HurdNetworkCollector)
    networkCollector = NetworkCollector.for_platform('GNU')
    assert isinstance(networkCollector, HurdNetworkCollector)
    assert isinstance(networkCollector.get_network_facts(), HurdPfinetNetwork)

# Generated at 2022-06-11 03:26:25.270558
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''
    Class HurdNetworkCollector is used for GNU Hurd system.

    It must have a _platform attribute set to 'GNU' and a
    _fact_class attribute set to HurdPfinetNetwork.
    '''
    hnc = HurdNetworkCollector()
    assert hnc._platform == 'GNU'
    assert hnc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:26:34.242137
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Initialize module's class
    module = HurdPfinetNetwork({})
    # Make sure we got the right class
    assert isinstance(HurdPfinetNetwork({}), HurdPfinetNetwork)
    # Make sure populate return a dict
    assert isinstance(HurdPfinetNetwork({}).populate(), dict)
    # Make sure we got the right class
    assert isinstance(HurdNetworkCollector({}), HurdNetworkCollector)

# Generated at 2022-06-11 03:26:41.458580
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mock_module = MockAnsibleModule()
    m = HurdPfinetNetwork(mock_module)

    # Test the function in both cases, one when the command is present, one
    # when it's not
    for command_present in (True, False):
        # Set up the command
        for pfinet_cmd in ('fsysopts', 'pfinet'):
            mock_module.run_command.mock_reset()
            if command_present:
                mock_module.get_bin_path.return_value = '/bin/%s' % (pfinet_cmd)
            else:
                mock_module.get_bin_path.return_value = None

            # Set up the return value of read_file

# Generated at 2022-06-11 03:26:42.861611
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    o = HurdPfinetNetwork()


# Generated at 2022-06-11 03:26:45.521509
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    pfinet = HurdPfinetNetwork()
    assert pfinet.platform == 'GNU'


# Generated at 2022-06-11 03:26:57.072686
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class FakeModule(object):
        def run_command(self, args):
            return 0, """--interface=/dev/eth0 --netmask=255.255.255.0 --address=192.168.1.100 --address6=fe80::223:6cff:fe8a:2e70/64 --address6=2001:db8::223:6cff:fe8a:2e70/64""", ""
    network = HurdPfinetNetwork(FakeModule())
    network_facts = {}
    network_facts = network.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')

    assert network_facts['interfaces'] == ["eth0"]

# Generated at 2022-06-11 03:27:06.591878
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import os
    import tempfile
    import shutil
    import sys
    import contextlib
    import io

    # Hack to avoid pytest to print stdout
    # "Module already imported so cannot be rewritten"
    @contextlib.contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = io.BytesIO()
        yield
        sys.stdout = save_stdout

    # Fake a GNU Hurd system
    temp_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(temp_dir, 'servers/socket'))
    os.symlink('/servers/socket/inet', os.path.join(temp_dir, 'servers/socket/pfinet'))

# Generated at 2022-06-11 03:27:12.347856
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Fake AnsibleModule
    class MockModule:
        def __init__(self, name):
            self.params = {'path': '/bin'}
            self.name = name

        def get_bin_path(self, name):
            return 'lib/' + name

        def run_command(self, args):
            return 0, '', ''

    # Fake AnsibleModule object
    module = MockModule('test')
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.0.3'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:27:23.183445
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Unit test class to test method assign_network_facts of class HurdPfinetNetwork
    """
    class Module:
        """
        Mock class for ansible module
        """
        def __init__(self, params=None):
            self.params = params

        def run_command(self, command):
            """
            Run the given command
            """
            # return code (0 for success, 1 for failure)
            # output from the command
            # error from the command
            return 0, "--interface=/dev/eth0\n--address=10.0.0.1\n--netmask=255.255.255.0\n--address6=::1/64\n", ""

    class Facts:
        """
        Mock class for facts
        """
        def __init__(self):
            self.ans

# Generated at 2022-06-11 03:27:32.578351
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''
    Test the method HurdPfinetNetwork.populate.
    '''
    class MockModule(object):
        @staticmethod
        def get_bin_path(binary, required=False):
            if binary == 'fsysopts':
                return '/hurd/fsysopts'
            return None

        @staticmethod
        def run_command(command):
            if command == ['/hurd/fsysopts', '-L', '/servers/socket/inet']:
                # fsysopts -L output
                return 0, (
                    '--interface=eth0 --address=127.0.0.1 --netmask=255.0.0.0 '
                    '--address6=::1/128'
                    ), None
            return None, None, None


# Generated at 2022-06-11 03:27:45.183059
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-11 03:27:57.835715
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    o = HurdNetworkCollector()
    assert o is not None, 'Failed to instantiate a HurdNetworkCollector object'

# Generated at 2022-06-11 03:28:08.430688
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Create a module
    module = MockModule()
    # Create a HurdPfinetNetwork and set module attribute
    network = HurdPfinetNetwork()
    network.module = module
    # Create a network_facts dict
    network_facts = {}
    # Create a fsysopts_path
    fsysopts_path = 'fsysopts_path'
    # Create a socket_path
    socket_path = 'socket_path'
    # Create a return code
    rc = 0
    # Create an out

# Generated at 2022-06-11 03:28:10.066369
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network


# Generated at 2022-06-11 03:28:11.641549
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    hnc = HurdNetworkCollector()
    assert hnc.platform == 'GNU'


# Generated at 2022-06-11 03:28:14.519031
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Unit test for constructor of class HurdNetworkCollector"""
    hurd_network_collector = HurdNetworkCollector()
    assert hurd_network_collector._platform == 'GNU'
    assert hurd_network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:28:24.922978
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    import platform
    import os
    import tempfile
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils._text import to_bytes

    # This test only run on GNU platform
    if platform.system() != 'GNU' or os.uname()[0] != 'GNU':
        return


# Generated at 2022-06-11 03:28:34.200420
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import pytest
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    network_facts = {
        'interfaces': [
            'eth0',
        ],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '172.16.1.1',
                'netmask': '255.255.255.0',
            },
            'ipv6': [
                {
                    'address': 'fe80::1',
                    'prefix': '64',
                },
                {
                    'address': 'fe80::2',
                    'prefix': '64',
                }
            ],
        }
    }
    fsysopts_path = 'fsysopts'
   

# Generated at 2022-06-11 03:28:42.372457
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    import os.path
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmpdir, 'servers'))
    os.mkdir(os.path.join(tmpdir, 'servers', 'socket'))
    os.symlink('/servers/pfinet/inet', os.path.join(tmpdir, 'servers', 'socket', 'inet'))

    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'

    network_facts = {}

    # create a module stub for this test

# Generated at 2022-06-11 03:28:45.169670
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    result = HurdNetworkCollector()
    assert result._platform == 'GNU'
    assert result._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:28:46.411840
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:29:16.515903
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Test the constructor of the class HurdPfinetNetwork,
    the only method that doesn't need to be tested is collect,
    because is equal to the GNU one
    """
    of_system = HurdPfinetNetwork(dict())
    assert of_system.platform == 'GNU'
    # Test the method get_interface_data
    assert 'interfaces' in of_system.get_interface_data()
    # Test the method get_route_data
    assert 'default_gateway' in of_system.get_route_data()
    assert 'gateway4' not in of_system.get_route_data()
    assert 'routes4' not in of_system.get_route_data()

# Generated at 2022-06-11 03:29:18.235396
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'

# Generated at 2022-06-11 03:29:26.661557
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    fsysopts_path = '/hurd/ext2fs/fsysopts'
    socket_path = '/servers/socket/inet'

# Generated at 2022-06-11 03:29:31.950574
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._socket_dir == '/servers/socket/'
    assert collector._fact_class.platform == 'GNU'
    assert collector._fact_class._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:29:42.229144
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # setup a pseudo environment
    class Module:
        def run_command(self, cmd):
            if cmd[0] == '/path/to/fsysopts':
                return (0,
                        '--interface=/dev/eth0 --address=192.168.1.2 --netmask=255.255.255.0 --address6=::1/128',
                        '')
            else:
                raise NotImplementedError('unknown command: %s' % cmd[0])

        def get_bin_path(self, executable):
            if executable == 'fsysopts':
                return '/path/to/fsysopts'
            else:
                raise NotImplementedError('unknown executable: %s' % executable)

    class Facts:
        network = None
        network_ipv4 = None
        network_ipv6

# Generated at 2022-06-11 03:29:48.689340
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fsysopts_path = None
    socket_path = None
    collected_facts = None
    g = HurdPfinetNetwork(fsysopts_path, socket_path, collected_facts)

# Generated at 2022-06-11 03:29:52.849560
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurdPfinetNetwork = HurdPfinetNetwork(1)
    assert hurdPfinetNetwork.platform == "GNU"
    assert hurdPfinetNetwork._socket_dir == "/servers/socket/"


# Generated at 2022-06-11 03:29:54.828806
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    net = HurdPfinetNetwork()
    # test empty case
    assert {} == net.populate()

# Generated at 2022-06-11 03:30:04.623349
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """This test case is using a HurdPfinetNetwork object to build a network facts
    structure based on the output of:
        fsysopts -l /servers/socket/inet
    then check if the structure is the expected one.
    """
    # Build a HurdPfinetNetwork object using a module as interface to the OS
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args):
            return (self.rc, self.out, self.err)

    class MockedModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-11 03:30:13.623158
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class ModuleMock(object):
        def run_command(self, args):
            return 1, '''--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe43:0ab/64 --interface=/dev/eth1 --address=10.0.0.2 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe43:0aa/64''', ''

    module_mock = ModuleMock()
    network_facts = {}
    fsysopts_path = '/hurd/pfinet'
    socket_path = '/servers/socket/inet'

    network = HurdPfinetNetwork(module_mock)
    result = network.assign_network_

# Generated at 2022-06-11 03:30:59.497396
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    network = HurdPfinetNetwork(module)
    network.populate()

    # FIXME: check output
    #assert dict(network.facts) == dict(network_facts)


# Generated at 2022-06-11 03:31:08.879723
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import unittest.mock as mock
    module = mock.MagicMock()

    network_facts = {
        'interfaces': []
    }
    sample_output = """
    --interface=/dev/eth0 --address=192.168.1.1
    --interface=/dev/eth1 --address=2001:db8::100 --netmask=64
    --interface=/dev/eth2 --address6=2001:db8::2/64
    """
    fake_fsysopts_path = '/bin/fsysopts'
    fake_socket_path = '/servers/socket/inet'
    network_facts = HurdPfinetNetwork(module).assign_network_facts(network_facts, fake_fsysopts_path, fake_socket_path)
    module.run_command.assert_called_with

# Generated at 2022-06-11 03:31:09.711034
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    NetworkCollector(None)

# Generated at 2022-06-11 03:31:17.338417
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = {}
    networkCollector = HurdNetworkCollector(module)
    network = networkCollector._fact_class(module)
    socket_path = '/servers/socket/inet'
    fsysopts_path = '/servers/socket/fsysopts'
    network_facts = {}
    output = "--interface=/dev/eth0 --address=192.168.0.6 --netmask=255.255.255.0 --address6=2001:db8::6/64\n"
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert 'eth0' in network_facts
    assert network_facts['eth0']['active'] == True
    assert network_facts

# Generated at 2022-06-11 03:31:18.938223
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:31:27.330716
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = HurdPfinetNetwork(dict(module=dict()))
    module.module.run_command = MagicMock()
    module.module.run_command.side_effect = [
        # fsysopts -L /servers/socket/inet
        (0, ('--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0', ''), ''),
    ]
    network_facts = module.populate()
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '10.0.0.1'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:31:28.162276
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork() is not None

# Generated at 2022-06-11 03:31:37.583964
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '--interface=/dev/eth0 --netmask=255.255.0.0 --address=10.10.0.1 --address6=fe80::5054:ff:fe35:f61e/64 --address6=ff02::1/128 --address6=ff02::1:ff35:f61e/128', '')

    test_obj = HurdPfinetNetwork(mock_module)

    network_facts = {}


# Generated at 2022-06-11 03:31:38.796190
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork({}, {}).platform == 'GNU'
    # TODO: more tests

# Generated at 2022-06-11 03:31:39.473764
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    assert False, 'Not implemented'

# Generated at 2022-06-11 03:33:49.409466
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network_collector = HurdPfinetNetwork(module)
    network_collector.populate()

# Generated at 2022-06-11 03:33:51.401524
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    res = HurdNetworkCollector()

    # It's an instance of NetworkCollector
    assert isinstance(res, NetworkCollector)


# Generated at 2022-06-11 03:34:00.348045
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # test with multiple interfaces
    module = MockAnsibleModule()
    fsysopts_path = '/bin/fsysopts'
    network_facts = {}
    socket_path = '/servers/socket/inet'

# Generated at 2022-06-11 03:34:04.260400
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.collector import BaseFactCollector
    c = HurdNetworkCollector()
    assert isinstance(c, BaseFactCollector)
    assert c.__class__.__name__== 'HurdNetworkCollector'
    assert c.platform == 'GNU'
    assert c.fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:34:08.036485
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    '''Test constructor of class HurdNetworkCollector'''
    # Construct a HurdNetworkCollector object
    network_collector = HurdNetworkCollector()
    # Check _platform property
    assert network_collector._platform == 'GNU'
    # Check _fact_class property
    assert network_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:34:16.553355
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return {'changed': False, 'failed': True, 'msg': 'fsysopts not found on the system'}
    network_facts = {
        'interfaces': []
    }
    socket_path = '/servers/socket/inet'
    h = HurdPfinetNetwork(module)
    h.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] is True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network

# Generated at 2022-06-11 03:34:18.249084
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:34:24.301361
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.network import HurdPfinetNetwork

    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/tmp/socket'

    ft = FactCollector()
    nc = HurdNetworkCollector(ft, ft.collection_module)

    socket_path = os.path.join(nc.fact_class._socket_dir, 'inet')
    out = '--interface=/dev/eth1 --address=192.168.0.1 --netmask=255.255.255.0 --address6=fe80::6c:ff:fe39:6b3e/64'


# Generated at 2022-06-11 03:34:26.023453
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:34:33.468816
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    network_facts = {}
    network = HurdPfinetNetwork({'module_name': 'test'})
    network_facts = network.assign_network_facts(network_facts, '/bin/fsysopts', '/servers/socket/inet')
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.21'
    assert network_facts['eth0']['ipv4']['netmask'] == '255.255.255.0'
    assert network_facts['eth0']['ipv6'][0]['address'] == '2001:db8:1234::1'