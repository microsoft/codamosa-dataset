

# Generated at 2022-06-11 03:25:27.382571
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts import stubs
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.utils import get_file_content

    contents = get_file_content(os.path.join(os.path.dirname(__file__), 'fsysopts_sample.txt'))

    module = stubs.StubModule()

    obj = HurdPfinetNetwork(module)

    fact_subset = obj.assign_network_facts({}, 'fsysopts', 'a_path')

# Generated at 2022-06-11 03:25:30.874311
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Testing constructor of HurdPfinetNetwork
    hn = HurdPfinetNetwork(None)
    assert hn is not None

# Generated at 2022-06-11 03:25:41.736003
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Unit test for method populate of class HurdPfinetNetwork
    """
    def _run_command(cmd, module):
        """
        Stubs function module.run_command
        """
        if cmd[0] == 'fsysopts':
            return 0, _TEST_INPUT, ''
        else:
            return 0, '', ''
    module = _MockedModule(run_command=_run_command)
    obj = HurdPfinetNetwork(module)
    network_facts = obj.populate()
    assert network_facts
    # We should have one interface
    assert len(network_facts) == 1
    # We should have only one interface
    assert len(network_facts['interfaces']) == 1
    eth0 = network_facts['interfaces'][0]

# Generated at 2022-06-11 03:25:47.157726
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    network_collector = HurdNetworkCollector(module)
    network_collector.populate()
    network_facts = network_collector.get_facts()
    assert "active" in network_facts['eth0']['ipv4']

# Generated at 2022-06-11 03:25:54.290323
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    inet_path = '/servers/socket/inet'
    os.makedirs(inet_path)
    module = MockModule()
    module.run_command = Mock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:0db8:85a3:0000:0000:8a2e:0370:7334/64', ''))
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    print(network_facts)
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'], True
    assert network_facts['eth0']['device'], 'eth0'
    assert network_facts

# Generated at 2022-06-11 03:26:05.604072
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={})
    fsysopts_path = module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        module.fail_json(msg='fsysopts not found')

    network_facts = {}

    path = '/servers/socket/inet'
    hurd = HurdPfinetNetwork(module)
    network_facts = hurd.assign_network_facts(network_facts, fsysopts_path, path)

    assert 'interfaces' in network_facts, 'interfaces not in network_facts'
    assert 'lo0' in network_facts['interfaces'], 'lo0 not in network_facts'
    assert 'lo0' in network_facts, 'device lo0 not in network_facts'
    assert 'ipv4'

# Generated at 2022-06-11 03:26:06.903989
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hn = HurdPfinetNetwork({})
    assert hn is not None

# Generated at 2022-06-11 03:26:15.613753
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.utils import AnsibleModule

    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'
    fsysopts_output = b"""--interface=eth0 \
--address=10.0.0.7
--netmask=255.0.0.0
--address6=fe80::20c:29ff:fe63:dea7/64
"""
    module = AnsibleModule(argument_spec={})
    network_facts = {}
    HurdPfinetNetwork(module).assign_network_facts(network_facts, fsysopts_path, socket_path)

# Generated at 2022-06-11 03:26:18.500767
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor test of HurdNetworkCollector
    """
    obj = HurdNetworkCollector()
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:26:29.459208
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    test_HurdPfinetNetwork_assign_network_facts
    """
    module = AnsibleModuleMock()


# Generated at 2022-06-11 03:26:40.069593
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts.network.gnu.hurd import HurdNetworkCollector
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.gnu.hurd import HurdPfinetNetwork
    network = HurdNetworkCollector()
    assert isinstance(network, Network)
    assert isinstance(network, HurdNetworkCollector)
    assert isinstance(network._fact, HurdPfinetNetwork)


# Generated at 2022-06-11 03:26:42.418552
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """Test constructor of HurdNetworkCollector."""

    hurddevice = HurdNetworkCollector()
    assert hurddevice.platform == 'GNU'

# Generated at 2022-06-11 03:26:44.316914
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == 'GNU'
    assert h._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:26:55.486195
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    """
    Unit test for method assign_network_facts of class HurdPfinetNetwork
    """
    network_facts = {}
    network_facts = HurdPfinetNetwork(None).assign_network_facts(
        network_facts,
        '/usr/bin/fsysopts',
        '/servers/socket/inet6'
    )

    assert ('interfaces' in network_facts)
    assert ('eth0' in network_facts['interfaces'])
    assert (network_facts['eth0']['active'] is True)
    assert (network_facts['eth0']['device'] == 'eth0')
    assert (network_facts['eth0']['ipv4']['address'] == 'fe80::400:27ff:fe02:fb80')

# Generated at 2022-06-11 03:27:05.557083
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    import sys
    # sys.path.insert(0, '')
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    module = AnsibleFakeModule(json.dumps({'ANSIBLE_NET_FSYSOPTS': '/bin/fsysopts'}))
    module.run_command = lambda x: (0, '--address=192.168.1.10 --address6=2001:1::1 --interface=/dev/eth0 --netmask=255.255.255.0 --address6=2001:1::2 --netmask6=64 --interface=/dev/eth1 --address=192.168.2.10 --netmask=255.255.255.0\n', '')
    network = HurdPfinetNetwork(module)

    ifaces = network.pop

# Generated at 2022-06-11 03:27:06.791117
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'


# Generated at 2022-06-11 03:27:07.625630
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector


# Generated at 2022-06-11 03:27:10.947883
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import ModuleCollector
    module = ModuleCollector()
    test_obj = HurdPfinetNetwork(module)
    assert test_obj.module == module
    assert test_obj.platform == 'GNU'

# Generated at 2022-06-11 03:27:21.955259
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    result = HurdPfinetNetwork().populate()
    for i in result['interfaces']:
        assert isinstance(result[i], dict)
        assert 'ipv4' in result[i] and 'ipv6' in result[i]
        assert 'active' in result[i] and 'device' in result[i]
        assert result[i]['active'] == True
        assert result[i]['device'] == i
        assert isinstance(result[i]['ipv4'], dict)
        assert isinstance(result[i]['ipv6'], list)
        if 'address' in result[i]['ipv4']:
            assert 'netmask' in result[i]['ipv4']

# Generated at 2022-06-11 03:27:31.655052
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)

    # test with existing inet socket
    module._mock_os_path_exists = lambda x: True
    module._mock_os_path_realpath = lambda x: '/servers/socket/inet'
    module._mock_run_command = lambda x: (0, '', '')
    network.populate()

    # test with existing inet6 socket
    module._mock_os_path_exists = lambda x: True
    module._mock_os_path_realpath = lambda x: '/servers/socket/inet6'
    module._mock_run_command = lambda x: (0, '', '')
    network.populate()

    # test with empty socket
    module._mock_os

# Generated at 2022-06-11 03:27:40.701344
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork()
    assert net['interfaces'] == None
    assert net['ipv4'] == None


# Generated at 2022-06-11 03:27:51.858624
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = MockModule()
    network = HurdPfinetNetwork(module)
    network_facts = network.populate({})
    assert 'enp0s3' in network_facts['interfaces']
    assert 'enp0s8' in network_facts['interfaces']
    assert network_facts['enp0s3']['active']
    assert network_facts['enp0s8']['active']
    assert network_facts['enp0s3']['ipv4']['address'] == '192.168.1.3'
    assert network_facts['enp0s3']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-11 03:27:53.195059
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector()
    assert network._platform == 'GNU'

# Generated at 2022-06-11 03:27:55.469751
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:58.767535
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact = HurdNetworkCollector()
    assert isinstance(fact, HurdNetworkCollector)
    assert fact.platform == 'GNU'
    assert fact._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:28:00.018352
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == 'GNU'

# Generated at 2022-06-11 03:28:11.060895
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = AnsibleModuleMock(
        dict(
            ANSIBLE_MODULE_ARGS=dict(gather_subset='all')
        )
    )
    f = HurdPfinetNetwork(m)
    f.populate()

# Generated at 2022-06-11 03:28:17.745025
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class MockModule(object):
        def __init__(self, arch, cmd_rc, cmd_out, cmd_err):
            self.arch = arch
            self.cmd_rc = cmd_rc
            self.cmd_out = cmd_out
            self.cmd_err = cmd_err

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return (self.cmd_rc, self.cmd_out, self.cmd_err)

    def run_tests(tests):
        for test in tests:
            m = MockModule(test['arch'], test['cmd_rc'], test['cmd_out'],
                           test['cmd_err'])
            n = HurdPfinetNetwork(m)
            f = n.populate()

# Generated at 2022-06-11 03:28:24.581215
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    mod = FakeAnsibleModule()
    obj = HurdPfinetNetwork(mod)
    obj.module.get_bin_path = lambda x: '/usr/bin/fsysopts'
    obj.path_exists = lambda x: True
    facts = obj.populate()
    assert facts['interfaces'] == ['eth0']
    assert facts['eth0']['active']
    assert facts['eth0']['device'] == 'eth0'


# Generated at 2022-06-11 03:28:26.232499
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert str(HurdNetworkCollector()) == '<HurdNetworkCollector(GNU)>'

# Generated at 2022-06-11 03:28:48.981168
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module:
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err
        def run_command(self, cmd):
            return self.rc, self.out, self.err

    fsysopts_path = '/foo/fsysopts'
    socket_path = '/foo/socket'
    out = '--interface=/dev/eth0 --address=10.10.10.1 --netmask=255.255.255.0 --address6=2001:db8::1/64'

    module = Module(0, out, '')
    network = HurdPfinetNetwork(module, '/foo')
    network_facts = {}

# Generated at 2022-06-11 03:28:58.414371
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command
    fact = HurdPfinetNetwork(module)


# Generated at 2022-06-11 03:29:08.663128
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock(params={})
    network_facts = {}
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/bin/socket'
    network_facts['interfaces'] = []
    network_facts['lo'] = {
        'active': True,
        'device': 'lo',
        'ipv4': {},
        'ipv6': [],
    }

    module.run_command = Mock(return_value=(0,
                                            '--interface=eth0 --address=10.0.0.1 --netmask=255.255.255.0 --address6=fe80::c0a8:3c01/64',
                                            ''))

    network_obj = HurdPfinetNetwork(module)
    network_obj.assign_

# Generated at 2022-06-11 03:29:10.310842
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert isinstance(collector, HurdNetworkCollector)

# Generated at 2022-06-11 03:29:12.917818
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork()
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:29:17.242654
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    HurdPfinetNetwork methods unit test.
    """
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    obj = HurdPfinetNetwork()
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:29:23.935137
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    x = HurdPfinetNetwork({}, {'fsysopts_path': '/hurd/pfinet/fsysopts', 'socket_path': '/hurd/pfinet/socket'}, [])

    x.module.run_command = lambda args, check_rc=False: (0, '--interface=eth0', '--netmask=255.255.255.0')
    assert x.populate() == {'interfaces': ['eth0'], 'eth0': {'active': True, 'device': 'eth0', 'ipv4': {'netmask': '255.255.255.0'}, 'ipv6': []}}

# Generated at 2022-06-11 03:29:28.406110
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Constructor HurdNetworkCollector doesn't take parameters
    """
    network_collector = HurdNetworkCollector()
    assert network_collector._platform == 'GNU'
    assert network_collector._fact_class.__name__ == 'HurdPfinetNetwork'


# Generated at 2022-06-11 03:29:30.354961
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    fact = NetworkCollector.get_network_collector(None, HurdNetworkCollector)
    assert fact is not None

# Generated at 2022-06-11 03:29:36.463568
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/bin/fsysopts'
    obj = HurdPfinetNetwork(module)
    assert obj.platform == 'GNU'
    assert obj.module == module
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:30:02.844328
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork()

    # Assert various class variables
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:30:12.028110
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.command = Mock(return_value=(0, '--interface=dev/eth0 --address=10.0.0.1 --netmask=255.0.0.0 --address6=2001:638:902:100::1/64', ''))
    test_module.get_bin_path = Mock(return_value='/bin/fsysopts')
    test_network_collector = HurdNetworkCollector(test_module)
    test_network = HurdPfinetNetwork(test_module)
    result = test_network.assign_network_facts({}, 'fsysopts', '/servers/socket/inet')

# Generated at 2022-06-11 03:30:16.619471
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # TODO: write better tests
    from ansible_collections.ansible.community.plugins.module_utils.facts import ansible_collector
    from ansible.module_utils.facts.network import Network
    network_facts = NetworkCollector.populate_network_facts(ansible_collector, Network)
    assert network_facts is not None
    assert 'interfaces' in network_facts
    # assert 'lo' in network_facts['interfaces']


# Generated at 2022-06-11 03:30:19.218954
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({}, '/usr/bin/fsysopts')
    assert network.fsysopts_path == '/usr/bin/fsysopts'

# Generated at 2022-06-11 03:30:28.604025
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    # Create an object HurdPfinetNetwork
    HurdPfinetNetwork_object = HurdPfinetNetwork(module)
    # Create a fake interface eth0
    inet_file = open(HurdPfinetNetwork_object._socket_dir + 'inet', 'w')
    inet_file.write('--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0 --address6=2001:db8:0:1::1/64')
    network_facts = {'interfaces': []}
    HurdPfinetNetwork_object.assign_network_facts(network_facts, '/fsysopts', '/servers/socket/inet')


# Generated at 2022-06-11 03:30:30.786756
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == "GNU"
    assert HurdPfinetNetwork()._socket_dir == "/servers/socket/"

# Generated at 2022-06-11 03:30:39.509108
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, '--interface=/dev/eth0 --address=192.168.1.1 --netmask=255.255.255.0', None))
    network_facts = {}
    out_network_facts = {
        'interfaces': [
            'eth0',
        ],
        'eth0': {
            'ipv4': {
                'address': '192.168.1.1',
                'netmask': '255.255.255.0',
            },
            'device': 'eth0',
            'ipv6': [],
            'active': True,
        },
    }
    fsysopts_path = '/bin/fsysopts'
    socket_path = '/servers/socket/inet'


# Generated at 2022-06-11 03:30:47.766727
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # We can't import ansible.module_utils.facts.network.gnu.hurd.pfinet
    # because it will import ansible.module_utils.facts.network.gnu.hurd.base
    # that does not exist, so we add this ugly hack to avoid failures when
    # running unitest
    import ansible.module_utils.facts.network.gnu.hurd  # noqa
    from ansible.module_utils.facts.network.gnu.hurd.base import HurdNetworkCollector  # noqa

    # We need a class to test populate. We build a class Test
    class Test:
        def get_bin_path(self, arg):
            return "fsysopts"


# Generated at 2022-06-11 03:30:49.487882
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.__class__.__name__ == 'HurdNetworkCollector'



# Generated at 2022-06-11 03:30:56.620090
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    fsysopts_path = 'fsysopts'
    socket_path = 'socket'

    # Set module return values
    module.run_command.return_value = (0, ("--interface=/dev/eth0 --address=192.168.0.2 --netmask=255.255.255.0 --broadcast=192.168.0.255 --address6=fe80::400:27ff:fe44:ffab/64",), "")

    network_facts = {}

    network = HurdPfinetNetwork(module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-11 03:32:01.264543
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # TODO
    pass

# Generated at 2022-06-11 03:32:01.792839
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    pass

# Generated at 2022-06-11 03:32:09.750978
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils.facts.network import Network, NetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxPfinetNetwork
    from ansible.module_utils.facts import ModuleFacts
    import os.path
    import unittest

    class FakeModule(object):
        def get_bin_path(self, path):
            return '/bin/fsysopts'


# Generated at 2022-06-11 03:32:16.768022
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network import Network

    # Get an native instance of HurdPfinetNetwork for testing
    network_col = HurdNetworkCollector(None)
    network = network_col.get_network_instance(None)

    # Make fsysopts available to avoid None from module.get_bin_path
    network.module.run_command = lambda x: (0, x[0], '')

    # Make _socket_dir available to avoid None from os.path.join
    network._socket_dir = '/tmp'

    # Mock os.path.exists
    class ExistsMock:
        def __init__(self):
            self.call_count = 0

        def __call__(self, path):
            self.call_count += 1
            return path == '/tmp/inet'

   

# Generated at 2022-06-11 03:32:19.232401
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU', 'failed initializing platform'
    assert collector._fact_class == HurdPfinetNetwork, 'failed initializing fact_class'


# Generated at 2022-06-11 03:32:26.785546
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd.pfinet import test_HurdPfinetNetwork_assign_network_facts as test
    from ansible.module_utils.facts.network.base import Network
    os.environ = {'PATH': '/bin:/usr/bin'}
    p = HurdPfinetNetwork()
    p.assign_network_facts = test
    p.fsysopts_path = '/bin/fsysopts'
    p.socket_path = '/servers/socket/inet'
    p.populate()
    assert p.fsysopts_path == '/bin/fsysopts'

# Generated at 2022-06-11 03:32:29.416145
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert obj._platform == 'GNU'
    assert obj._fact_class == HurdPfinetNetwork
    assert obj._cache_expiration_time == 6

# Generated at 2022-06-11 03:32:31.639277
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule()
    network_module = HurdPfinetNetwork()
    network_module.module = module
    network_module.populate(None)

# Generated at 2022-06-11 03:32:38.270780
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class MockModule(object):
        def __init__(self):
            self.run_command = MockModule.run_command
            self.get_bin_path = MockModule.get_bin_path

        def run_command(self, command):
            if command[0] == '/bin/fsysopts':
                return 0, "--interface=/dev/eth0 --address=192.168.1.10 --netmask=255.255.255.0 ", ""

        def get_bin_path(self, command):
            return '/bin/' + command

    testmodule = MockModule()
    testmodule.run_command.return_code = 0
    testmodule.run_command.stdout = "--interface=/dev/eth0 --address=192.168.1.10 --netmask=255.255.255.0 "

   

# Generated at 2022-06-11 03:32:39.754876
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:34:54.074135
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_data = []
    # FIXME: Complete with tests for all options
    test_data.append("""--interface=/dev/eth0
--address=1.2.3.4
--port=0
--netmask=255.255.255.0
--address6=fe80::5e:65ff:fe82:23d1/64
--interface=/dev/eth1
--address=2.3.4.5
--port=0
--netmask=255.255.255.0
--address6=fe80::5e:65ff:fe82:23d2/64""")


# Generated at 2022-06-11 03:34:55.621947
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network = HurdNetworkCollector()
    assert(network.facts == 'interfaces')



# Generated at 2022-06-11 03:34:57.015001
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Create an instance of HurdNetworkCollector.
    """
    HurdNetworkCollector(None)

# Generated at 2022-06-11 03:34:58.026981
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h is not None

# Generated at 2022-06-11 03:34:59.502758
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork.platform == 'GNU'
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:35:00.794948
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork({})
    assert isinstance(obj, HurdPfinetNetwork)

# Generated at 2022-06-11 03:35:02.289984
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork(None, {})
    assert h.platform == 'GNU'

# Generated at 2022-06-11 03:35:03.795743
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    obj = HurdPfinetNetwork(None)
    assert obj.platform == 'GNU'


# Generated at 2022-06-11 03:35:04.956651
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'

# Generated at 2022-06-11 03:35:09.146816
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    fsysopts_path = '/usr/bin/fsysopts'
    socket_path = '/servers/socket/inet'

    hn = HurdPfinetNetwork()
    hn.module.run_command = run_command
    hn.assign_network_facts(dict(), fsysopts_path, socket_path)

