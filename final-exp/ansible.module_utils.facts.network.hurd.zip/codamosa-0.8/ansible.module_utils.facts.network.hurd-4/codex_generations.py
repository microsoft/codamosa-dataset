

# Generated at 2022-06-11 03:25:27.656529
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    mod = AnsibleModule(argument_spec={})
    fsysopts_path = 'fsysopts'
    socket_path = 'servers/socket/inet'
    hh = HurdPfinetNetwork(mod)
    network_facts = {}

# Generated at 2022-06-11 03:25:31.961867
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork({})
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'



# Generated at 2022-06-11 03:25:34.481260
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    o = HurdPfinetNetwork('dummy')
    assert o.platform == 'GNU'
    assert o._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:25:36.266848
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    net = HurdPfinetNetwork(dict(), dict())
    assert net.get_default_interfaces() == []

# Generated at 2022-06-11 03:25:47.345961
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd.pfinet import HurdPfinetNetwork
    module = None
    fsysopts_path = os.path.join(os.path.dirname(__file__), 'fsysopts.py')
    socket_path = os.path.join(os.path.dirname(__file__), 'socket')
    network_facts = {}
    network = HurdPfinetNetwork(network_facts, module)
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)
    assert network_facts['interfaces'] == ['eth0', 'eth1', 'eth2']

# Generated at 2022-06-11 03:25:49.279627
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.__class__.__name__ == 'HurdNetworkCollector'

# Generated at 2022-06-11 03:26:00.305346
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    from ansible.module_utils._text import to_text

    module = Mock()
    # run_command() is called twice, return different values
    module.run_command.side_effect = [
        (0, to_text('--interface=/dev/en0 --address=1.2.3.4 --netmask=0.0.0.0'), None),
        (0, to_text('--interface=/dev/en0 --address6=10::1/64'), None)
    ]

    network_facts = {}
    fsysopts_path = '/usr/sbin/fsysopts'
    socket_path = '/servers/socket/inet'

    g = HurdPfinetNetwork(module)
    g.ass

# Generated at 2022-06-11 03:26:02.845211
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:26:12.512856
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class args:
        socket_dir = '/servers/socket/'
        module = None

    class module:
        def get_bin_path(self, interface):
            return '/bin/fsysopts'

        def run_command(self, interface):
            return (0, '--interface=eth0 --address=10.1.1.1 --netmask=255.0.0.0 --address6=fe00::/64', None)

    args.module = module()
    network = HurdPfinetNetwork(args)
    res = network.populate()
    assert 'interfaces' in res
    assert 'eth0' in res
    assert 'active' in res['eth0']
    assert 'ipv4' in res['eth0']
    assert 'address' in res['eth0']['ipv4']

# Generated at 2022-06-11 03:26:20.636772
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.hurd.pfinet.os_facts import HurdPfinetNetwork
    from ansible.module_utils.facts.network.hurd.pfinet.os_facts import HurdNetworkCollector
    from ansible.module_utils.facts.network.generic import Network
    network_facts = dict()
    network = HurdNetworkCollector()
    network._fact_class = HurdPfinetNetwork
    network.get_facts()
    fsysopts = network_facts['ansible_facts']['ansible_fsysopts']
    socket_path = network_facts['ansible_facts']['ansible_socket']
    network.get_facts()

# Generated at 2022-06-11 03:26:32.972985
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    n = HurdPfinetNetwork('', '', '')
    assert n.platform == 'GNU'
    assert n._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:26:40.738805
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network import NetworkCollector
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    from ansible.module_utils.facts.network.ios import IosNetwork
    from ansible.module_utils.facts.network.generic import GenericNetwork
    import pytest

    class ModuleDummy:
        def run_command(self, *args, **kwargs):
            return (0, '', '')

        def get_bin_path(self, *args, **kwargs):
            return ''

    class FakeCollect(NetworkCollector):
        def __init__(self):
            self.platform = 'GNU'
            self.module = ModuleDummy()


# Generated at 2022-06-11 03:26:50.193002
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module(object):
        def run_command(self, args, **kwargs):
            if args[0] == 'fsysopts' and args[1] == '-L' and args[2] == socket_path:
                return (0, out, '')
            return (1, '', '')

        def get_bin_path(self, path):
            if path == 'fsysopts':
                return '/bin/fsysopts'
            return None

    module = Module()
    socket_path = '/servers/socket/inet'
    network_facts = {}

    # test 1
    # pfinet

# Generated at 2022-06-11 03:26:53.436550
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork()
    assert h.platform == "GNU"
    assert h._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:27:00.361963
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.network.gnu import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    c = HurdNetworkCollector()
    assert isinstance(c, Collector)
    assert isinstance(c, HurdNetworkCollector)
    assert c.platform == 'GNU'
    assert c._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:03.537171
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    This function verifies the constructor of the class HurdNetworkCollector
    """
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:05.799794
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    net_collector = HurdNetworkCollector()

    assert net_collector.platform == 'GNU'
    assert net_collector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:11.458181
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert hasattr(HurdPfinetNetwork, 'platform')
    assert HurdPfinetNetwork.platform == 'GNU'
    assert hasattr(HurdPfinetNetwork, '_socket_dir')
    assert HurdPfinetNetwork._socket_dir == '/servers/socket/'

    # Create a instance of HurdPfinetNetwork
    obj = HurdPfinetNetwork()

    assert hasattr(obj, 'platform')
    assert obj.platform == 'GNU'

    assert hasattr(obj, 'module')
    assert obj.module is None

    assert hasattr(obj, '_socket_dir')
    assert obj._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:27:14.357596
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert 'GNU' == HurdNetworkCollector._platform
    assert HurdPfinetNetwork == HurdNetworkCollector._fact_class

# Generated at 2022-06-11 03:27:16.747118
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.platform == 'GNU'
    assert collector.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:27:29.334049
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network=HurdPfinetNetwork(None)
    assert 'GNU' == network.platform

# Generated at 2022-06-11 03:27:31.431661
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    testobj = HurdNetworkCollector()
    assert testobj.platform == 'GNU'
    assert testobj._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:27:43.204340
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # We need to mock module_utils to be able to run unit test on this class
    # Method run_command will mock the module to return a tuple with
    # the returncode, stdout, and stderr.
    MockedModule = type('MockedModule', (object,),
                        {'run_command': lambda self, args, check_rc=True: (0, (
                            '--interfacenum=0 --interface=eth0 --link=up --speed=-1 --hw=a:b:c:d:e:f --address=10.0.2.15 --netmask=255.255.255.0 --address6=fe80::5054:ff:fe96:7baf/64'
                         ), '')})
    module = MockedModule()
    network = HurdPfinetNetwork(module)
    expected_

# Generated at 2022-06-11 03:27:53.974000
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Unit test for method populate of class HurdPfinetNetwork
    """
    from ansible.module_utils.facts import ModuleFacts

    module = AnsibleModuleMockup(dict(
        run_command=run_command_mockup
    ))

    module.params = dict(
        path='/servers/socket/inet',
        key='value',
    )

    network_plugin = HurdPfinetNetwork()
    network_plugin.set_module(module)
    facts = dict()


# Generated at 2022-06-11 03:27:56.339730
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """
    Test instantiation of HurdPfinetNetwork
    """
    module = None
    network = HurdPfinetNetwork(module)
    assert network.platform == 'GNU'

# Generated at 2022-06-11 03:28:06.787155
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    net_mod = HurdPfinetNetwork(module)

    # Test for two interfaces with ipv4 and ipv6
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'
    network_facts = net_mod.assign_network_facts(network_facts, fsysopts_path, socket_path)

    assert len(network_facts['interfaces']) == 2
    assert 'lo' in network_facts['interfaces']
    assert sorted(network_facts['lo']['ipv4']) == ['address', 'netmask']
    assert network_facts['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:28:09.137344
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector._platform == 'GNU'
    assert collector._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:28:16.528794
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)
    network.module.get_bin_path = lambda x: '/sbin/' + x
    network.module.run_command = lambda x: (0, '', '')
    network.assign_network_facts = lambda x, y, z: x
    network_facts = network.populate()
    assert network_facts['interfaces'] == ['lo']
    assert network_facts['lo']['device'] == 'lo'
    assert network_facts['lo']['active']
    assert network_facts['lo']['ipv4'] == {}
    assert network_facts['lo']['ipv6'] == []


# Generated at 2022-06-11 03:28:27.059160
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import sys
    import ansible
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork, HurdNetworkCollector
    from ansible.module_utils.six import PY3

    collector = HurdNetworkCollector()
    network = HurdPfinetNetwork(collector)

    network.module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # FIXME: test the functionality
    if PY3:
        assert (network.populate()) == {}

# Generated at 2022-06-11 03:28:36.031137
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    if module.check_mode:
        return

    hpn = HurdPfinetNetwork(module)
    collected_facts = {'ansible_architecture': 'i386'}
    hpn.populate(collected_facts)

    assert 'ansible_architecture' in collected_facts
    assert 'ansible_interfaces' in collected_facts
    assert 'ansible_all_ipv4_addresses' in collected_facts
    assert 'ansible_all_ipv6_addresses' in collected_facts
    assert 'ansible_default_ipv4' in collected_facts
    assert 'ansible_default_ipv6' in collected_facts


# Generated at 2022-06-11 03:28:58.373827
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert issubclass(HurdPfinetNetwork, Network)

# Generated at 2022-06-11 03:29:08.555936
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Create a module and populate it with
    # parameters needed by module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # Create a instance of HurdPfinetNetwork
    network_facts = HurdPfinetNetwork(module=module)

    fake_fsysopts_path = '/bin/fsysopts'
    fake_socket_path = '/servers/socket/inet'
    socket_path = None

    for l in ('inet', 'inet6'):
        link = os.path.join(network_facts._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break

    if socket_path is None:
        return None

    # FIXME: add mocks
    #module.get_

# Generated at 2022-06-11 03:29:11.238794
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    nc = HurdNetworkCollector()
    assert nc._platform == 'GNU'
    assert nc._fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:29:21.226173
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    obj = HurdPfinetNetwork(module)
    network_facts = {'interfaces': []}
    fsysopts_path = module.get_bin_path('fsysopts')
    socket_path = '/servers/socket/inet'
    expected = {
        'interfaces': ['eth0'],
        'eth0': {
            'active': True,
            'device': 'eth0',
            'ipv4': {
                'address': '1.2.3.4',
                'netmask': '255.255.255.0'
            },
            'ipv6': [
                {'address': 'fe80::1',
                 'prefix': '64'}
            ]
        }
    }
    collected_facts = obj.assign_

# Generated at 2022-06-11 03:29:31.528321
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import json
    # to run test_HurdPfinetNetwork_assign_network_facts() you must be on GNU Hurd,
    # then run:
    # module_utils/facts/network/gnuhurd/hurd_pfinet_network.py
    # and you'll get json object.
    # that object is the result of test_HurdPfinetNetwork_assign_network_facts()
    # to use it in test_HurdPfinetNetwork_assign_network_facts() uncomment this line:
    # output_json = open('output_json').read()
    # to regenerate the output_json, you must comment this line:

# Generated at 2022-06-11 03:29:41.890418
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    fact = NetworkCollector().collect('')
    fact_main = fact.get('ansible_net_interfaces')
    assert 'lo' in fact_main
    assert fact_main['lo']['device'] == 'lo'
    assert fact_main['lo']['active'] is True
    assert fact_main['lo']['ipv4'] == {'address': '127.0.0.1', 'netmask': '255.0.0.0'}
    assert fact_main['lo']['ipv6'] == [{'prefix': '8', 'address': '::1'}]
    assert fact_main['eth0']['device'] == 'eth0'
    assert fact_main['eth0']['active'] is True

# Generated at 2022-06-11 03:29:48.478340
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Test no fsysopts
    module = FakeAnsibleModule()
    module.get_bin_path.return_value = None
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    expected_result = {}
    assert network_facts == expected_result

    # Test no socket
    module = FakeAnsibleModule()
    module.get_bin_path.return_value = '/fsysopts'
    network = HurdPfinetNetwork(module)
    network_facts = network.populate()
    expected_result = {}
    assert network_facts == expected_result

    # Test one interface
    module = FakeAnsibleModule()
    module.get_bin_path.return_value = '/fsysopts'
    # fake a call to fsysopts with

# Generated at 2022-06-11 03:29:55.452549
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.__class__.__name__ == 'HurdNetworkCollector'
    assert network_collector._fact_class_name == 'HurdPfinetNetwork'
    assert network_collector._fact_class.__name__ == 'HurdPfinetNetwork'
    assert network_collector.platform == 'GNU'
    assert network_collector._fact_class.platform == 'GNU'


# Generated at 2022-06-11 03:30:05.684867
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    test_base_dir = '/etc/'
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, u'', u''))
    module.get_bin_path = MagicMock(return_value=u'/bin/false')
    module.params = {}
    fact_network = HurdPfinetNetwork(module)
    fact_network.populate()
    assert isinstance(fact_network._socket_dir, str)
    assert fact_network._socket_dir == test_base_dir
    assert isinstance(fact_network.module, AnsibleModule)
    assert isinstance(fact_network.platform, str)
    assert fact_network.platform == u'GNU'

# Generated at 2022-06-11 03:30:14.138617
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    Test HurdPfinetNetwork_populate method: when pfinet is not
    configure
    """
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork
    module = FakeAnsibleModule()
    network = HurdPfinetNetwork(module)
    fsysopts_path = network.module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return
    socket_path = None
    for l in ('inet', 'inet6'):
        link = os.path.join(network._socket_dir, l)
        if os.path.exists(link):
            socket_path = link
            break
    if socket_path is None:
        return

    network.module.run_command = Fake_run_command

# Generated at 2022-06-11 03:30:59.265028
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:31:08.627839
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():

    from ansible.module_utils.facts.network.gnuhurd import HurdPfinetNetwork

    _ansible_module = mock.MagicMock()

    network_facts = {}

    fsysopts_path = '/bin/fsysopts'
    socket_path = 'servers/socket/inet'

    # fsysopts output

# Generated at 2022-06-11 03:31:11.348273
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeAnsibleModule()
    module.params = {}
    instance = HurdPfinetNetwork(module, {})

    # check that the return value of populate is correct
    assert instance.populate() == {}


# Generated at 2022-06-11 03:31:18.537758
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = {}
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    instance = HurdPfinetNetwork(module)
    network_facts = instance.assign_network_facts(
        {},
        '/bin/fsysopts',
        '/servers/socket/inet'
    )
    assert network_facts['interfaces'] == ['eth0']
    assert network_facts['eth0']['active'] == True
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '192.168.1.2'
    assert network

# Generated at 2022-06-11 03:31:23.804414
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = AnsibleModuleMock()
    network_facts = {}
    obj = HurdPfinetNetwork(module)
    obj.assign_network_facts(network_facts, '/usr/sbin/fsysopts', '/servers/socket/inet')
    assert sorted(network_facts) == [
        'default_ipv4',
        'device_id',
        'device_index',
        'interfaces',
        'lo',
    ]


# Generated at 2022-06-11 03:31:30.288301
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Make sure we don't overwrite what is already there
    network_facts = {'test': 1}
    # Call HurdPfinetNetwork constructor
    obj = HurdPfinetNetwork({}, network_facts)
    assert isinstance(obj.module, dict)
    assert isinstance(obj.facts, dict)
    # Make sure nothing got added to the facts
    assert len(obj.facts) == 1
    assert obj.facts['test'] == 1
    # Make sure we got the correct platform
    assert obj.platform == 'GNU'


# Generated at 2022-06-11 03:31:36.001225
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures import FakeHurdPfinetNetworkModule
    from ansible_collections.ansible.community.tests.unit.modules.utils.fixtures import FakeHurdPfinetNetworkOutput
    module = FakeHurdPfinetNetworkModule()
    o = FakeHurdPfinetNetworkOutput()
    h = HurdPfinetNetwork(module)
    # FIXME: write me
    assert h.populate() == o

# Generated at 2022-06-11 03:31:36.848741
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork({})
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:31:37.831279
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert 'GNU' == HurdPfinetNetwork.platform


# Generated at 2022-06-11 03:31:44.639845
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import json
    from ansible.module_utils._text import to_text

    # get reference values from actual system
    # module_utils.basic.AnsibleModule has no constructor with params
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    fsysopts_path = module.get_bin_path('fsysopts')
    if fsysopts_path is None:
        return network_facts

    socket_path = None

    for l in ('inet', 'inet6'):
        link = os.path.join('/servers/socket/', l)
        if os.path.exists(link):
            socket_path = link
            break

    if socket_path is None:
        return network_facts


# Generated at 2022-06-11 03:33:54.655572
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    HurdNetworkCollector()

# Generated at 2022-06-11 03:33:57.784308
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collectors = [
        {
            '_platform': 'GNU',
            '_fact_class': HurdPfinetNetwork,
        }
    ]

    nc = HurdNetworkCollector()
    assert nc.collectors == collectors

# Generated at 2022-06-11 03:34:05.711196
# Unit test for method assign_network_facts of class HurdPfinetNetwork

# Generated at 2022-06-11 03:34:10.401083
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = FakeAnsibleModule()
    obj = HurdPfinetNetwork(module)
    assert obj.module == module
    assert obj.platform == 'GNU'
    assert obj._socket_dir == '/servers/socket/'

# Constructor of the class HurdPfinetNetwork need a FakeAnsibleModule for
# testing constructor, but when run unit test for other functions, we don't
# need.

# Generated at 2022-06-11 03:34:13.348301
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # create the object
    obj = HurdPfinetNetwork(None)
    # check object attributes are correctly set
    assert(obj.platform == 'GNU')
    assert(obj._socket_dir == '/servers/socket/')


# Generated at 2022-06-11 03:34:16.624997
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a fake module and a dummy facts object
    network_facts = dict()
    network = HurdPfinetNetwork(module)

    assert network.populate(network_facts) == dict()

# Generated at 2022-06-11 03:34:20.081779
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    module = FakeModule()
    pfinet = HurdPfinetNetwork(module)

    assert pfinet._socket_dir == '/servers/socket/'
    assert pfinet.platform == 'GNU'


# Generated at 2022-06-11 03:34:21.113657
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    h = HurdPfinetNetwork({})
    assert h.platform == 'GNU'

# Generated at 2022-06-11 03:34:21.979528
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert issubclass(HurdPfinetNetwork, Network) == True

# Generated at 2022-06-11 03:34:29.831924
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import sys

    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestModule(object):
        def __init__(self, run_command_args, fail_json_args, debug_args):
            self.run_command_args = run_command_args
            self.fail_json_args = fail_json_args
            self.debug_args = debug_args

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'fsysopts':
                return '/bin/fsysopts'
            else:
                return None

        def run_command(self, args):
            if args == self.run_command_args:
                rc = 0