

# Generated at 2022-06-11 03:25:21.546316
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    mod = type('AnsibleModule', (object,), {'params': {}})
    net = HurdPfinetNetwork(mod)
    assert net.platform == 'GNU'
    assert net._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:25:28.950747
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module(object):
        def run_command(self, cmd):
            return (0, '"--nettype=pfinet --interface=/dev/eth1 --address=192.168.1.101"', '')

    class Network_mod(HurdPfinetNetwork):
        def __init__(self):
            self.module = Module()

    try:
        fact_network = Network_mod()
    except Exception as err:
        # We expect this to fail on non GNU platforms.
        assert False, err

    network_facts = {}
    network_facts = fact_network.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert 'eth1' in network_facts['interfaces']

# Generated at 2022-06-11 03:25:32.260899
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class is HurdPfinetNetwork


# Generated at 2022-06-11 03:25:34.002367
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    p = HurdPfinetNetwork(dict())
    assert p._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:25:44.969527
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # Patch to retrieve the same data on all platforms
    import platform
    old_system = platform.system
    platform.system = lambda: 'GNU'

    # Prepare the module and the class
    class Module:
        def __init__(self):
            self.run_command = lambda x: ('', '', '')
            self.get_bin_path = lambda x: '/bin/fsysopts'
    mod = Module()

    cur = HurdPfinetNetwork()
    cur.module = mod

    # Run the method
    res = cur.populate()

    # Verify the result

# Generated at 2022-06-11 03:25:47.575488
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork is not None
    if HurdPfinetNetwork is not None:
        assert HurdPfinetNetwork.platform == 'GNU'

# Generated at 2022-06-11 03:25:56.816534
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    import json
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.run_command_exit = 0
            self.run_command_cmds = []
            self.run_command_results = []
            self.get_bin_path_count = 0
            self.get_bin_path_cmds = []
            self.get_bin_path_paths = []

        def get_bin_path(self, cmd, opt_dirs=[]):
            self.get_bin_path_count += 1
            self.get_bin_path_cmds.append(cmd)
            self.get_bin_path_paths.append(opt_dirs)
            return self.get_bin_path_cmds[-1]


# Generated at 2022-06-11 03:25:59.361943
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert c.platform == 'GNU'
    assert c.fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:26:02.286259
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # input data
    net_data = {}
    # instance of constructor
    test = HurdPfinetNetwork(None)
    # assert
    assert isinstance(test, HurdPfinetNetwork)


# Generated at 2022-06-11 03:26:03.642754
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(dict(module=None))

# Generated at 2022-06-11 03:26:16.831235
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MockModule()
    n = HurdPfinetNetwork()
    n.module = module
    assert n.assign_network_facts({}, '/bin/fsysopts', '/servers/socket/inet') == {'interfaces': ['eth0'],
                                                                                   'eth0': {'device': 'eth0',
                                                                                            'active': True,
                                                                                            'ipv4': {'address': '10.0.0.7',
                                                                                                     'netmask': '255.255.255.0'},
                                                                                            'ipv6': [{'prefix': '64',
                                                                                                      'address': 'fe80::21d:9ff:fe11:b8bf'}]}}


# Mock module to be able to

# Generated at 2022-06-11 03:26:27.394426
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeModule()
    network_facts = {}

    network = HurdPfinetNetwork(module)

    fsysopts_path = None
    socket_path = None
    rc, out, err = module.run_command([fsysopts_path, '-L', socket_path])
    out = '''\
--interface=eth0
--address=192.168.1.2
--netmask=255.255.255.0
--address6=2a00:1450:400a:800::1007/64
'''
    network_facts = network.assign_network_facts(network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-11 03:26:29.294721
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collect = HurdNetworkCollector()
    assert collect.__class__.__name__ == 'HurdNetworkCollector'

# Generated at 2022-06-11 03:26:35.541504
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = FakeModule(
        dict(
            params=dict(
                gather_subset=['!all', '!min'],
                gather_timeout=10,
            )
        )
    )
    m = HurdPfinetNetwork(module)
    m.populate()
    assert module.run_command.call_count == 1
    cargs, ckwargs = module.run_command.call_args
    expected = ('fsysopts', '-L', '/servers/socket/inet')
    assert cargs == expected
    assert ckwargs == {}

# Generated at 2022-06-11 03:26:43.430358
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class MockModule:
        def run_command(self, args):
            if args[0] == 'fsysopts' and args[1] == '-L' and args[2] == '/servers/socket/inet':
                return (0, (
                    "--interface=/dev/eth0 "
                    "--address=192.168.1.1 "
                    "--netmask=255.255.255.0 "), "")
            else:
                raise Exception("run command error")


# Generated at 2022-06-11 03:26:54.352424
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = {
        'interfaces': [],
    }
    network = HurdPfinetNetwork()
    # pfinet only
    network_facts = network.assign_network_facts(facts, '/dev/null', '/servers/socket/inet')
    assert len(network_facts['interfaces']) == 1
    assert 'eth0' in network_facts['interfaces']

    assert 'eth0' in network_facts
    assert 'eth1' not in network_facts

    assert network_facts['eth0']['active']
    assert network_facts['eth0']['device'] == 'eth0'
    assert network_facts['eth0']['ipv4']['address'] == '10.0.0.1'

# Generated at 2022-06-11 03:26:57.415249
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    network = HurdPfinetNetwork(None)
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:27:06.827182
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    facts = HurdPfinetNetwork(None)
    # test the empty case
    network_facts = {}
    out = ''
    network_facts = facts.assign_network_facts(network_facts, None, None)
    assert network_facts == {'interfaces': []}
    # test a LAN
    network_facts = {'interfaces': []}
    out='--interface=/dev/eth0 --address=10.5.5.5 --netmask=255.255.255.0 --address6=2001:db8::ff00:42:8329/64 --address6=2001:db8::ff00:42:8328/64'
    network_facts = facts.assign_network_facts(network_facts, None, None)

# Generated at 2022-06-11 03:27:17.286898
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.interfaces import Interfaces
    from ansible.module_utils.facts.network.distributed import DistributedNetwork
    from ansible.module_utils.facts.network.generic import GenericNetwork
    import pytest

    @pytest.fixture(scope="module")
    def module(self):
        import ansible.module_utils.facts.network.gnu
        import ansible.module_utils.facts.network.interfaces
        import ansible.module_utils.facts.network.distributed
        import ansible.module_utils.facts.network.generic
        import ansible.module_utils.facts.network.base
        import tempfile
        import os
        import sys

        # Make a copy of the ansible.

# Generated at 2022-06-11 03:27:27.506267
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """Check that the method populate of class HurdPfinetNetwork returns a dictionary."""
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand(output_inet='--interface=/dev/eth0 --address=192.168.0.2 --netmask=255.255.255.0 --address6=2a02:2788:0:3::1/64',
                                        output_inet6='--interface=/dev/eth0 --address=192.168.0.2 --netmask=255.255.255.0 --address6=2a02:2788:0:3::1/64')
    obj = HurdPfinetNetwork(module)
    facts = obj.populate()
    assert isinstance(facts, dict)
    assert facts['interfaces'][0] == 'eth0'

# Generated at 2022-06-11 03:27:49.612660
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import collector

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    def remove_file_in_dir(root_dir, target_file):
        for root, dirs, files in os.walk(root_dir):
            if target_file in files:
                full_path = os.path.join(root, target_file)
                os.remove(full_path)

    # Remove facts if they are already in the cache

# Generated at 2022-06-11 03:27:58.454902
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    '''Return a network fact for GNU hurd platform'''
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand()
    module.run_command.add_data([0, '--interface=lo', '--interface=eth0'])
    module.run_command.add_data([0, '--interface=lo', '--address=127.0.0.1', '--netmask=255.0.0.0', '--interface=eth0', '--address=10.10.0.5', '--netmask=255.255.255.0', '--address6=fe80::4d40:8ff:fe00:2/64', '--address6=2a02:a448:ddb0:0:216:3eff:fe00:2/64'])

    collector = Hurd

# Generated at 2022-06-11 03:28:09.096675
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    class Module:
        def run_command(self, args):
            return 0, "--interface=/dev/eth0 --address=10.0.0.1 --netmask=255.255.255.0 --interface=/dev/wlan0 --address=10.0.0.2 --address6=fe80::10:0:0:1/64 --netmask=255.255.255.0 --address6=fe80::10:0:0:2/64", ""
    class Facts:
        pass
    module = Module()
    facts = Facts()
    net = HurdPfinetNetwork(module, facts)
    network_facts = {}
    fsysopts_path = 'fsysopts'
    socket_path = '/servers/socket/inet'

# Generated at 2022-06-11 03:28:16.924907
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    class ModuleStub(object):
        def get_bin_path(self, name, opt_dirs=None, required=False):
            return '/bin/fsysopts'

        def run_command(self, cmd):
            return (0,
                    '--interface=/dev/eth0 --address=255.255.255.255 --netmask=255.255.255.255 --address6=::1/64',
                    None)

    class FactsStub(object):
        pass

    class NetworkStub(HurdPfinetNetwork):
        def __init__(self, module, collected_facts):
            self.module = module

    network = NetworkStub(ModuleStub(), FactsStub())
    network_facts = network.populate()

# Generated at 2022-06-11 03:28:20.156048
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    c = HurdNetworkCollector()
    assert isinstance(c, NetworkCollector)
    assert c._fact_class == HurdPfinetNetwork
    assert c._platform == 'GNU'


# Generated at 2022-06-11 03:28:24.035968
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hpn = HurdPfinetNetwork(None)
    assert hpn._socket_dir == '/servers/socket/'

    hpn._socket_dir = '/tmp'
    assert hpn._socket_dir == '/tmp'


# Generated at 2022-06-11 03:28:33.427818
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts.network.hurd_pfinet import HurdPfinetNetwork
    network_facts = {}
    network_facts['interfaces'] = []
    fsysopts_path = '/home/epatc00/fsysopts'
    socket_path = '/servers/socket/inet'
    out = '--vendor=Wistron --model=CM9 --revision=0000 --serial=00:11:22:33:44:55 --interface=/dev/eth0 --address=10.0.2.15 --netmask=255.255.255.0 --address6=10.0.2.15/24'

# Generated at 2022-06-11 03:28:39.659639
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # We are using a file as fsysopts because fsysopts is not present on
    # Debian system.

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts import fallback_network_defs
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.gnu.pfinet import HurdNetworkCollector
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork

    class MockModule(object):
        """
        Provide a mock module.
        """
        def __init__(self):
            self.params = dict()

# Generated at 2022-06-11 03:28:47.485747
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    from ansible.module_utils.facts import ansible_facts

    module = ansible_facts.AnsibleFactsModule
    # TODO: set module.params
    # module.params = {}

    # Create a test instance of HurdPfinetNetwork
    test_instance = HurdPfinetNetwork(module)

    # test that the class was initialized properly
    assert test_instance.module == module
    assert test_instance.platform == 'GNU'
    assert test_instance._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:28:57.289363
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    # Create a fake module
    module = FakeModule()
    # Create a fake Network object
    obj = HurdPfinetNetwork(module)
    # Create a dict that represent the collected_facts
    collected_facts = dict()

    # Assign the text output of fsysopts
    fsysopts_output = (
        '--interface=/dev/eth0\n'
        '--address=192.168.1.1\n'
        '--netmask=255.255.255.255\n'
        '--address6=fe80::20c:29ff:feaa:1199/64\n'
        '--address6=2a01:e34:eea6:10:20c:29ff:feaa:1199/64\n'
        )

    # Assign the path to the fake f

# Generated at 2022-06-11 03:29:18.877453
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None, None).platform == 'GNU'

# Generated at 2022-06-11 03:29:21.741874
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec={})
    network = HurdPfinetNetwork(module)

    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'


# Generated at 2022-06-11 03:29:32.137187
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """HurdPfinetNetwork - populate, return network information"""
    network = HurdPfinetNetwork()
    network._socket_dir = ''

    if not hasattr(network, "_get_bin_path"):
        def _get_bin_path(path):
            return path

        setattr(network, "_get_bin_path", _get_bin_path)


# Generated at 2022-06-11 03:29:37.344694
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    module = AnsibleModule(argument_spec=dict())
    network_facts = HurdPfinetNetwork(module)
    assert isinstance(network_facts, Network)
    assert isinstance(network_facts, HurdPfinetNetwork)
    assert network_facts.platform == 'GNU'
    assert network_facts._socket_dir == '/servers/socket/'



# Generated at 2022-06-11 03:29:45.875899
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    from ansible.module_utils.facts.network.gnu import HurdPfinetNetwork

    network_facts = {}

    fsysopts_path = ''
    socket_path = ''

    res = HurdPfinetNetwork.assign_network_facts(
        {'fsysopts_path': fsysopts_path,
         'socket_path': socket_path},
        network_facts, fsysopts_path, socket_path)


# Generated at 2022-06-11 03:29:48.257317
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    # Test with no options
    network = HurdPfinetNetwork()
    assert network.platform == 'GNU'
    assert network._socket_dir == '/servers/socket/'

# Generated at 2022-06-11 03:29:59.461313
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    # We create a Mock module since we don't want to hit the filesystem
    module = MockModule()
    module.run_command = Mock(return_value=(0, '--interface=/dev/eth0 --port=0 --address=192.168.0.2 --address6=2001:470:1f05:778::2/64 --netmask=255.255.255.0 --broadcast=192.168.0.255', ''))
    module.get_bin_path = Mock(return_value='/bin/fsysopts')

    # We instantiate the class we want to test
    facts = HurdPfinetNetwork(module)
    ret = facts.populate()

    assert 'interfaces' in ret
    assert 'lo' not in ret
    assert 'eth0' in ret

# Generated at 2022-06-11 03:30:00.773543
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork().platform == 'GNU'

# Generated at 2022-06-11 03:30:10.305098
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = FakeAnsibleModule()
    m = HurdPfinetNetwork(module)
    network_facts = {
        'interfaces': [],
    }

    # --interface=eth0 --address=192.0.2.1 --address6=2001:db8::1 --netmask=255.255.255.0
    network_facts = m.assign_network_facts(network_facts, 'fsysopts', '/servers/socket/inet')
    assert len(network_facts['interfaces']) == 1
    assert 'eth0' in network_facts
    assert 'ipv4' in network_facts['eth0']
    assert 'ipv6' in network_facts['eth0']
    assert 'address' in network_facts['eth0']['ipv4']
    assert 'netmask' in network

# Generated at 2022-06-11 03:30:17.195304
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """
    HurdPfinetNetwork - Unit test for method populate
    """
    from ansible.module_utils.facts.network.gnu.pfinet import HurdPfinetNetwork
    from ansible.module_utils.facts.network.base import Network
    from ansible.module_utils.facts import collectors

    collectors.add_collector('NetworkCollector')
    network = HurdPfinetNetwork()
    ansible_module = MockAnsibleModule()
    ansible_module.run_command = Mock(return_value=(0, "", ""))

    # result of one interface

# Generated at 2022-06-11 03:31:06.904601
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    import os
    import ansible.module_utils
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork
    import ansible.module_utils.facts.network.base
    from ansible.module_utils.facts.network.base import Network

    # class HurdPfinetNetwork is a subclass of Network and it has the method assign_network_facts
    assert(issubclass(HurdPfinetNetwork, Network) and HurdPfinetNetwork.assign_network_facts != Network.assign_network_facts)


# Generated at 2022-06-11 03:31:09.674484
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    Test HurdNetworkCollector
    """
    assert HurdNetworkCollector._platform == 'GNU'
    assert HurdNetworkCollector._fact_class == HurdPfinetNetwork

# Generated at 2022-06-11 03:31:12.678524
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network_collector = HurdNetworkCollector()
    assert network_collector.platform == 'GNU'
    assert network_collector._fact_class == HurdPfinetNetwork
    assert isinstance(network_collector._fact_class(), HurdPfinetNetwork)

# Generated at 2022-06-11 03:31:15.305547
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    """Unit test for constructor of class HurdPfinetNetwork."""
    # Get HurdPfinetNetwork object
    obj = HurdPfinetNetwork()

    # Check object's properties
    assert obj.platform == 'GNU'

# Generated at 2022-06-11 03:31:16.859969
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    network = HurdNetworkCollector('module')
    assert network.platform == 'GNU'
    assert network.fact_class.platform == 'GNU'

# Generated at 2022-06-11 03:31:18.310682
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    hurd_pfinet = HurdPfinetNetwork(None)
    assert isinstance(hurd_pfinet, HurdPfinetNetwork)

# Generated at 2022-06-11 03:31:25.668433
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '--interface=lo', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/fsysopts')
    module.exit_json = MagicMock()
    network_facts = HurdPfinetNetwork(module).populate()
    assert network_facts['interfaces'] == ['lo']
    assert network_facts['lo']['ipv4'] == {'address': None,
                                           'netmask': None}
    assert network_facts['lo']['ipv6'] == []

# Generated at 2022-06-11 03:31:28.397711
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    collector = HurdNetworkCollector()
    assert collector.fact_class == HurdPfinetNetwork, "Unexpected fact_class attribute value"
    assert collector.platform == 'GNU', "Unexpected platform attribute value"


# Generated at 2022-06-11 03:31:30.897297
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    return HurdPfinetNetwork(None, None)


# Generated at 2022-06-11 03:31:38.706730
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    m = FakeAnsibleModule({
        'fsysopts': '/usr/bin/fsysopts',
        'pfinet_socket': '/servers/socket/inet',
        'fsysopts_output': """--interface=/dev/eth0
--address=10.0.2.15
--netmask=255.255.255.0
--address6=fe80::a00:27ff:fe34:7a01/64
""",
    })
    facts_network = HurdPfinetNetwork(m)

    res = facts_network.populate()
    assert 'interfaces' in res
    assert res['interfaces'] == ['eth0']

# Generated at 2022-06-11 03:33:47.181613
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    test of constructor of class HurdNetworkCollector
    """
    ansible_module_mock = MockAnsibleModule()
    hurd_network_collector_obj = HurdNetworkCollector(ansible_module_mock)
    assert hurd_network_collector_obj is not None


# Generated at 2022-06-11 03:33:56.593666
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    test_ansible_module = AnsibleModuleMock()
    test_ansible_module.run_command = AnsibleRunCommandMock(out='''
--interface=eth0
--address=192.168.1.10
--broadcast=192.168.1.255
--netmask=255.255.255.0
--address6=fe80::a00:27ff:fe2c:d9a9/64
--interface=lo
--address=127.0.0.1
--address6=::1/128
''')
    test_fsysopts_path = '/usr/bin/fsysopts'
    test_socket_path = '/servers/socket/inet'
    test_network_facts = {}

    test_collector = HurdPfinetNetwork(test_ansible_module)


# Generated at 2022-06-11 03:34:04.631056
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    """Test HurdPfinetNetwork.populate."""

    class Options(object):
        def __init__(self, values=None):
            self.values = values or {}
            self.get_option = self.values.get

    class ModuleStub(object):
        def __init__(self, options=None):
            self.options = options or Options()
            self.fsysopts_path = './test/ansible/module_utils/facts/network/fsysopts'
            self.run_command_calls = 0

# Generated at 2022-06-11 03:34:07.111160
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    obj = HurdNetworkCollector()
    assert isinstance(obj, NetworkCollector)
    assert obj.platform == 'GNU'
    assert obj.fact_class == HurdPfinetNetwork


# Generated at 2022-06-11 03:34:10.438251
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    n = HurdPfinetNetwork(dict())
    res = n.populate()
    assert 'interfaces' in res
    assert res['interfaces']
    assert 'lo' in res['interfaces']
    assert 'lo' not in res['interfaces']

# Generated at 2022-06-11 03:34:11.241380
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    HurdPfinetNetwork(dict(), dict())

# Generated at 2022-06-11 03:34:13.870846
# Unit test for constructor of class HurdNetworkCollector
def test_HurdNetworkCollector():
    """
    HurdNetworkCollector is-a NetworkCollector.
    """
    network_collector = HurdNetworkCollector()
    assert isinstance(network_collector, NetworkCollector)


# Generated at 2022-06-11 03:34:21.424322
# Unit test for method populate of class HurdPfinetNetwork
def test_HurdPfinetNetwork_populate():
    '''Unit test for method HurdPfinetNetwork.populate'''
    import os
    import tempfile
    from ansible.module_utils.facts.network.hurd import HurdPfinetNetwork

    network_info = HurdPfinetNetwork(None, None, None)
    if not os.path.exists(network_info._socket_dir):
        os.mkdir(network_info._socket_dir, 0o755)
    with tempfile.NamedTemporaryFile('wb', delete=False) as f:
        pass
    network_info.module.run_command = lambda x, check_rc=True: (0, '--address=192.168.1.1 --netmask=255.255.255.0', '')

# Generated at 2022-06-11 03:34:29.122211
# Unit test for method assign_network_facts of class HurdPfinetNetwork
def test_HurdPfinetNetwork_assign_network_facts():
    module = MagicMock()
    # unsuccessful fsysopts run
    rc = 1
    out = ''
    err = 'command not found'
    module.run_command.return_value = rc, out, err
    network_facts = {}

    obj = HurdPfinetNetwork()
    obj.module = module
    obj.assign_network_facts(network_facts, 'fsysopts', 'socket_path')
    assert not network_facts

    module.run_command.return_value = 0, '', ''

# Generated at 2022-06-11 03:34:29.901889
# Unit test for constructor of class HurdPfinetNetwork
def test_HurdPfinetNetwork():
    assert HurdPfinetNetwork(None) is not None