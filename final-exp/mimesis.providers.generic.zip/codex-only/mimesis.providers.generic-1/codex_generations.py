

# Generated at 2022-06-23 21:19:48.127453
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    obj = Generic()
    obj.add_providers(Person, Address)
    assert 'person' in obj.__dict__
    assert 'address' in obj.__dict__
    assert not obj.__dict__['person']
    assert not obj.__dict__['address']
    obj.add_providers()
    assert 'person' in obj.__dict__
    assert 'address' in obj.__dict__
    assert not obj.__dict__['person']
    assert not obj.__dict__['address']


# Generated at 2022-06-23 21:19:52.273031
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Address)
    assert 'address' in dir(generic)
    generic.add_providers(Address, Business)
    assert 'address' in dir(generic)
    assert 'business' in dir(generic)

# Generated at 2022-06-23 21:19:58.793491
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person.__class__ == Person
    assert gen.address.__class__ == Address
    assert gen.datetime.__class__ == Datetime
    assert gen.business.__class__ == Business
    assert gen.text.__class__ == Text
    assert gen.food.__class__ == Food
    assert gen.science.__class__ == Science

# Generated at 2022-06-23 21:20:06.039541
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create a custom provider
    class SomeProvider(BaseProvider):
        def some_method(self):
            return 'some_method'

    # Add custom providers to Generic() object
    foo = Generic()
    foo.add_providers(SomeProvider)

    # Check if providers were added
    assert 'some_provider' in foo.__dict__.keys()

    # Check if methods were correctly added to Generic object
    assert hasattr(foo, 'some_provider')
    assert hasattr(foo.some_provider, 'some_method')


# Generated at 2022-06-23 21:20:09.095729
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g.__dir__(), list)
    assert g.__dir__()

# Generated at 2022-06-23 21:20:18.008699
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def method(self):
            return 'something'

    g = Generic()
    assert hasattr(g, 'custom_provider') is False

    g.add_provider(CustomProvider)

    assert hasattr(g, 'custom_provider')
    assert hasattr(g.custom_provider, 'method')

    # Testing meta data
    assert g.custom_provider.Meta.name == 'custom_provider'
    assert g.custom_provider.method() == 'something'

    # Testing incorrect providers
    class IncorrectProvider:
        pass

    try:
        g.add_provider(IncorrectProvider)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 21:20:22.545103
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert not hasattr(Generic(), 'example')
    example_provider = BaseProvider(seed=0)
    Generic().add_provider(example_provider)
    assert hasattr(Generic(), 'example')


# Generated at 2022-06-23 21:20:29.178449
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.custom import Custom
    from mimesis.providers.extra import Extra
    gender = {
        'male': ['male_1', 'male_2', 'male_3', 'male_4'],
        'female': ['female_1', 'female_2', 'female_3', 'female_4'],
    }
    provider = Custom(gender=gender)
    all_in_one = Generic()
    all_in_one.add_provider(provider)
    assert hasattr(all_in_one, 'custom')
    assert hasattr(all_in_one.custom, 'gender')
    assert isinstance(all_in_one.custom.gender, str)
    assert all_in_one.custom.gender in gender

    provider = Extra()

# Generated at 2022-06-23 21:20:41.323552
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    # g.person() - is Deprecated since version 1.2.2!
    g.address = Address(seed=42)
    assert isinstance(g.address, Address)
    assert g.address.city() == 'North Alma'

    assert isinstance(g.business, Business)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.development, Development)
    assert isinstance(g.internet, Internet)
    assert isinstance

# Generated at 2022-06-23 21:20:45.686778
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):

        class Meta:
            name = 'custom_provider'

        def custom_method(self):
            return 'Hello, world!'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.custom_method() == 'Hello, world!'

# Generated at 2022-06-23 21:20:48.310653
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.text import Text as CustomProvider

    Generic().add_provider(CustomProvider)

# Generated at 2022-06-23 21:20:55.517784
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    expected = [
        'add_provider',
        'add_providers',
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'person',
        'payment',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]
    assert generic.__dir__() == expected



# Generated at 2022-06-23 21:21:00.076899
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.process import Process
    from mimesis.providers.os import OS
    from mimesis.providers.programming import Programming

    b = Generic()
    b.add_providers(Process, OS, Programming)
    assert hasattr(b, 'process')
    assert hasattr(b, 'os')
    assert hasattr(b, 'programming')


# Generated at 2022-06-23 21:21:01.607355
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic class."""
    obj = Generic('en')
    assert set(obj.__dir__()) == set(Generic.__dict__)

# Generated at 2022-06-23 21:21:07.872981
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create test data
    class DummyProvider(BaseProvider):
        class Meta:
            name = 'dummy'

    class AnotherDummyProvider(BaseProvider):
        class Meta:
            name = 'another_dummy'

    # Create Generic object
    generic = Generic()
    providers = [DummyProvider, AnotherDummyProvider]

    # Try to add providers
    generic.add_providers(*providers)
    assert hasattr(generic, "dummy")
    assert hasattr(generic, "another_dummy")
    assert type(generic.dummy) == DummyProvider
    assert type(generic.another_dummy) == AnotherDummyProvider

# Generated at 2022-06-23 21:21:16.319688
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    def test_provider():
        class TestProvider(BaseProvider):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.exp = [
                    'skjdhfkjsdhfs',
                    'skjdhfkjsdhfs',
                    'skjdhfkjsdhfs',
                    'skjdhfkjsdhfs',
                    'skjdhfkjsdhfs',
                ]
                self.i = 0

            def test_method(self):
                return self.exp[self.i]

            def __iter__(self):
                return self

            def __next__(self):
                self.i += 1
                if self.i > len(self.exp):
                    raise StopIteration
                return self.test_method

# Generated at 2022-06-23 21:21:24.025682
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__()."""
    g = Generic()

# Generated at 2022-06-23 21:21:28.926105
# Unit test for constructor of class Generic
def test_Generic():
    all_providers = Generic().__dir__()
    all_providers.append('add_provider')
    all_providers.append('add_providers')
    assert len(all_providers) == len(set(all_providers))

# Generated at 2022-06-23 21:21:35.898839
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Base provider
    base = BaseProvider
    generic = Generic()

    # Test incorrect type
    try:
        generic.add_provider(base)
        got_error = False
    except TypeError as e:
        assert str(e) == 'The provider must be a subclass of BaseProvider'
        got_error = True
    assert got_error

    # Test correct type
    generic.add_provider(Person)
    assert hasattr(generic, 'person')



# Generated at 2022-06-23 21:21:45.234604
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    g.transport
    g.code
    g.unit_system
    g.file
    g.numbers
    g.development
    g.hardware
    g.clothing
    g.internet
    g.path
    g.payment
    g.cryptographic
    g.structure
    g.choice
    
    g.person
    g.address
    g.datetime
    g.business
    g.text
    g.food
    g.science
    
test_Generic()

# Generated at 2022-06-23 21:21:47.066590
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('en')
    gen._person = Person
    assert gen.person.full_name == 'Elena Jones'


# Generated at 2022-06-23 21:21:51.054240
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Unit test for method add_providers of class Generic
    g = Generic()
    g.add_providers(Person, Address)
    assert g.person.full_name()
    assert g.address.city()

# Generated at 2022-06-23 21:21:53.945024
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic_obj = Generic()
    generic_obj.add_custom_providers([1,2])
    assert len(generic_obj.__dir__()) == 47

# Generated at 2022-06-23 21:21:59.976985
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.file import File
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person
    from mimesis.providers.structure import Structure

    g = Generic()
    g.add_providers(File, Payment, Person, Structure)

    assert g.file is not None
    assert g.payment is not None
    assert g.person is not None
    assert g.structure is not None

# Generated at 2022-06-23 21:22:04.598850
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert g.__getattr__('person') is g.person

# Generated at 2022-06-23 21:22:15.693153
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    # print start
    print("\nStart test_Generic___getattr__ ...\n")
    # print end
    generic.person
    generic.address
    generic.datetime
    generic.business
    generic.text
    generic.food
    generic.science
    generic.transport
    generic.code
    generic.unit_system
    generic.file
    generic.numbers
    generic.development
    generic.hardware
    generic.clothing
    generic.internet
    generic.path
    generic.payment
    generic.cryptographic
    generic.structure
    generic.choice
    # print start
    print("End test_Generic___getattr__ ...\n")
    # print end


# Generated at 2022-06-23 21:22:22.950876
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    assert g.person.full_name() == 'Kathleen Hubbard'
    assert g.address.city() == 'Hostonshire'
    assert g.datetime.date() == '13.12.1997'
    assert g.business.company() == 'K Clark & Sons'
    assert g.text.sentence() == 'Nam accusamus nihil cupiditate.'
    assert g.food.fruit() == 'strawberry'
    assert g.science.element() == 'bromine'
    assert g.transport.ship().startswith('Gorch Fock')
    assert g.code.isbn() == '9740259402347'
    assert g.unit_system.weight() == 'kilograms'
    assert g.file.extension() == 'c'

# Generated at 2022-06-23 21:22:32.009926
# Unit test for constructor of class Generic
def test_Generic():
	generic = Generic('en')
	assert isinstance(generic, Generic)
	assert isinstance(generic.person, Person)
	assert isinstance(generic.address, Address)
	assert isinstance(generic.datetime, Datetime)
	assert isinstance(generic.business, Business)
	assert isinstance(generic.text, Text)
	assert isinstance(generic.food, Food)
	assert isinstance(generic.science, Science)
	assert isinstance(generic.transport, Transport)
	assert isinstance(generic.code, Code)
	assert isinstance(generic.unit_system, UnitSystem)
	assert isinstance(generic.file, File)
	assert isinstance(generic.numbers, Numbers)
	assert isinstance(generic.development, Development)
	assert isinstance(generic.hardware, Hardware)

# Generated at 2022-06-23 21:22:41.409598
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic().__dict__
    assert g['_person'] == Person(locale=None, seed=None)
    assert g['_address'] == Address(locale=None, seed=None)
    assert g['_datetime'] == Datetime(locale=None, seed=None)
    assert g['_business'] == Business(locale=None, seed=None)
    assert g['_text'] == Text(locale=None, seed=None)
    assert g['_food'] == Food(locale=None, seed=None)
    assert g['_science'] == Science(locale=None, seed=None)


# Generated at 2022-06-23 21:22:44.581749
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Get attribute from object."""
    gen = Generic('ko-KR')
    gen.person.full_name()
    gen.business.company()

# Generated at 2022-06-23 21:22:49.906879
# Unit test for constructor of class Generic
def test_Generic():
    local = Generic('en')

    assert local.choice
    assert local.person
    assert local.address
    assert local.datetime
    assert local.business
    assert local.text
    assert local.food
    assert local.science
    assert local.code
    assert local.unit_system
    assert local.file
    assert local.numbers
    assert local.development
    assert local.hardware
    assert local.clothing
    assert local.internet
    assert local.path
    assert local.payment
    assert local.cryptographic
    assert local.structure
    # assert local.choice  # TODO: Fix this
    assert local.transport

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:22:57.233803
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    subjects = Generic().__dir__()
    assert subjects == [
        'address',
        'business',
        'choice',
        'code',
        'person',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'clothing',
        'internet',
        'numbers',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'science',
        'transport',
        'text',
        'unit_system'
    ]


# Generated at 2022-06-23 21:22:58.244792
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()


# Generated at 2022-06-23 21:23:01.653594
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    for field in Generic.Meta.fields:
        print(field)
    g = Generic()
    for field in g.__dir__():
        print(field)


# Generated at 2022-06-23 21:23:03.573594
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert sorted(generic.__dir__()) == sorted(__all__)


# Generated at 2022-06-23 21:23:09.436417
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """
    Tets class __dir__
    """
    obj = Generic('ru')
    res = ['address', 'business', 'choice', 'code', 'clothing', 'cryptographic', 'datetime', 'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'path', 'payment', 'person', 'science', 'structure', 'text', 'transport', 'unit_system']
    assert obj.__dir__() == res

# Generated at 2022-06-23 21:23:11.581367
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """assert that __dir__(self) actually retrieve all the attributes of a
        given provider object
    """
    generic = Generic()
    attribute_list = generic.__dir__()

    assert len(attribute_list) == len(generic.__dict__) - 1

# Generated at 2022-06-23 21:23:15.573186
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic"""
    generic = Generic()
    current_year = generic.datetime.formatted('YYYY')
    assert current_year in ['2019', '2018']

# Generated at 2022-06-23 21:23:19.948594
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers function."""
    providers = Generic()
    providers.add_providers(Person, Address)
    assert hasattr(providers, 'person')
    assert hasattr(providers, 'address')
    assert not hasattr(providers, '_person')
    assert not hasattr(providers, '_address')



# Generated at 2022-06-23 21:23:20.974352
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.person is not None


# Generated at 2022-06-23 21:23:22.234607
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('ru')
    assert generic.business.company_name() == 'Азбука'

# Generated at 2022-06-23 21:23:26.110523
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    g = Generic()
    assert 'generic' in g.__dir__()

# Generated at 2022-06-23 21:23:26.771947
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-23 21:23:29.653437
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Science)
    assert hasattr(generic, 'science')


# Generated at 2022-06-23 21:23:32.452023
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, BaseDataProvider)
    assert isinstance(g.provider, Person)


# Generated at 2022-06-23 21:23:37.967830
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestGeneric(BaseProvider):
        pass

    class TestGeneric2(BaseProvider):
        class Meta:
            name = 'test_generic_2'

    gen = Generic()
    gen.add_provider(TestGeneric)
    gen.add_provider(TestGeneric2)
    assert isinstance(gen.TestGeneric(), BaseProvider)
    assert isinstance(gen.test_generic_2(), TestGeneric2)


# Generated at 2022-06-23 21:23:40.766462
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    provider = Generic()
    exclude = BaseDataProvider().__dict__.keys()
    lst = [x for x in provider.__dir__() if x not in exclude]
    assert len(lst) == 25



# Generated at 2022-06-23 21:23:47.411504
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a class inheritant of class BaseProvider
    class MyProvider(BaseProvider):
        def foo(self):
            return 'foo'

    assert not hasattr(Generic(), 'myprovider'), 'Attribute must not be setted'
    generic_obj = Generic()
    generic_obj.add_provider(MyProvider)
    assert hasattr(Generic(), 'myprovider'), 'Attribute must be setted'
    assert Generic().myprovider.foo() == 'foo', 'Method foo must return "foo"'
    generic_obj.add_provider(Generic)
    assert not hasattr(Generic(), 'generic'), 'Attribute must not be setted'


# Generated at 2022-06-23 21:23:57.789831
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    provider = Generic()
    assert provider.address.get_address()
    assert provider.business.get_company_name()
    assert provider.datetime.get_datetime()
    assert provider.food.get_dish()
    assert provider.person.get_full_name()
    assert provider.transport.get_car_brand()
    assert provider.code.get_password()
    assert provider.unit_system.get_weight(system='imperial')
    assert provider.file.get_extension()
    assert provider.numbers.get_integer()
    assert provider.development.get_language()
    assert provider.hardware.get_screen_resolution()
    assert provider.clothing.get_material()

# Generated at 2022-06-23 21:24:01.235596
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.person import Person

    person = Person(seed=123)
    assert person.name() == 'Светлана Сикорский'

    person = Person(seed=123)
    assert person.full_name() == 'Светлана Сикорский'


# Generated at 2022-06-23 21:24:08.511766
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    person = Generic().person
    assert person.full_name() == "Robert Walker"
    assert person.full_name(gender='female') == "Elizabeth Wilson"

    address = Generic().address
    assert address.station_code() == "9437"
    assert address.country_code() == "AF"

    datetime = Generic().datetime
    assert datetime.date() == "2019-06-17"

    text = Generic().text
    assert text.text()[:10] == "Et laborum "

    business = Generic().business
    assert business.swift_bic() == "BKTRUS33"
    assert business.company_number() == "99943731"

    food = Generic().food
    assert food.food() == "British Indian Ocean Territory"

# Generated at 2022-06-23 21:24:13.201834
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider_names = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
    ]
    g = Generic('th-TH')
    for name in provider_names:
        assert hasattr(g, name)
        assert isinstance(getattr(g, name), BaseProvider)

# Generated at 2022-06-23 21:24:24.784132
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def test(self):
            return 'test_method'

    custom_provider = CustomProvider
    gen = Generic()

    # Check good case
    gen.add_provider(custom_provider)
    assert gen.custom.test() == 'test_method'

    # Check wrong cases
    try:
        gen.add_provider('wrong_type_argument')
    except TypeError:
        pass
    else:
        raise AssertionError('ValueError should be raised when the argument is not a class')


# Generated at 2022-06-23 21:24:29.077668
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.misc import Misc
    from mimesis.providers.misc import Name

    generic = Generic()
    assert not hasattr(generic, 'misc')

    generic.add_provider(Misc)
    assert hasattr(generic, 'misc')

    generic.add_provider(Name)
    assert hasattr(generic, 'name')


# Generated at 2022-06-23 21:24:34.008777
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    generic = Generic('en')
    cls = Generic
    generic.add_provider(cls)
    assert getattr(generic, 'generic')
    assert isinstance(generic.generic, Generic)
    assert generic.generic.__class__ == cls


# Generated at 2022-06-23 21:24:38.419094
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Person, Address)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, '_person')
    assert hasattr(generic, '_address')

# Generated at 2022-06-23 21:24:41.154204
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.custom_providers import Animal

    gen = Generic()
    gen.add_provider(Animal)
    assert gen.animal is not None
    assert gen.animal.cat() == 'cat'

# Generated at 2022-06-23 21:24:50.715998
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.generic import Generic
    from mimesis.providers.structure import Structure
    from mimesis.providers.payment import Payment

    class Payment2(Payment):
        @Payment.postcode.variant('Hello')
        def postcode(self) -> str:
            return 'hello'

    g = Generic()
    g.add_providers(Structure, Payment2)
    assert hasattr(g, 'structure')
    assert hasattr(g, 'payment')
    assert hasattr(g.payment, 'postcode')
    assert g.payment.postcode() == 'hello'

# Generated at 2022-06-23 21:24:52.158352
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    print(dir(Generic()))

# Generated at 2022-06-23 21:24:54.275982
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.formation import Formation
    gen = Generic()
    gen.add_provider(Formation)
    assert 'formation' in dir(gen)


# Generated at 2022-06-23 21:24:59.936200
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    p = Generic()
    old_dir = dir(p)
    p.add_provider(Person)
    assert 'person' not in old_dir
    assert 'person' in dir(p)
    old_dir.append('person')

    delattr(p, 'person')

    p.add_provider(Address)
    assert 'address' not in old_dir
    assert 'address' in dir(p)
    old_dir.append('address')

    delattr(p, 'address')


# Generated at 2022-06-23 21:25:08.444367
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()

    # This condition is correct, now.
    assert g.__dir__() == [
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

# Generated at 2022-06-23 21:25:17.151745
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    expected_attribute = ['person', 'address', 'datetime',
                          'business', 'text', 'food', 'science',
                          'transport', 'code', 'unit_system', 'file',
                          'numbers', 'development', 'hardware',
                          'clothing', 'internet', 'path', 'payment',
                          'cryptographic', 'structure', 'choice']
    
    assert generic.add_provider(BaseProvider) is None
    assert generic.add_providers(BaseProvider) is None
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'science')
    assert generic.person not in ['person']
    assert generic.science not in ['science']
    assert generic.person.gender not in ['gender']

# Generated at 2022-06-23 21:25:27.438168
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Initilize a Generic object
    gen = Generic()
    # Set name attribute of Meta class automatically for custom provider
    class CustomClass():
        class Meta:
            pass
    custom_cls = CustomClass()
    # Add a custom provider
    gen.add_provider(custom_cls)
    # Assert the provider is added successfully
    assert hasattr(gen, 'custom_class')

    # Set name attribute of Meta class automatically with personalized name
    class CustomClass():
        class Meta:
            name = 'custom_cls'
    custom_cls = CustomClass()
    # Add a custom provider
    gen.add_provider(custom_cls)
    # Assert the provider is added successfully
    assert hasattr(gen, 'custom_cls')



# Generated at 2022-06-23 21:25:33.372185
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Arrange
    
    # Act
    generic = Generic('en')
    generic.add_providers(Address, Datetime, Person)
    print(dir(generic))

    # Assert
    assert generic.address is not None
    assert generic.datetime is not None
    assert generic.person is not None

# Generated at 2022-06-23 21:25:44.135068
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create custom providers
    class Provider(BaseProvider):
        pass
    class Provider1(BaseProvider):
        pass
    class Provider2(BaseProvider):
        pass
    # Initialize object of class Generic
    g = Generic()
    # Add custom providers to object
    g.add_providers(Provider, Provider1, Provider2)
    # Check names of providers
    assert Provider.Meta.name == 'provider'
    assert Provider1.Meta.name == 'provider1'
    assert Provider2.Meta.name == 'provider2'
    # Check if providers is present in attributes of object
    assert hasattr(g, Provider.Meta.name)
    assert hasattr(g, Provider1.Meta.name)
    assert hasattr(g, Provider2.Meta.name)

# Generated at 2022-06-23 21:25:49.657680
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Creating a Generic object
    g = Generic(seed=42)

    # Getting attribute `person`
    person = g.person

    # Creating a `Person` object
    p = Person('ru')

    # Comparing `person` with `p`
    assert person.full_name() == p.full_name()


# Generated at 2022-06-23 21:25:52.772619
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [BaseProvider]
    g = Generic()
    g.add_providers(*providers)
    assert 'base_provider' in g.__dict__



# Generated at 2022-06-23 21:25:54.323241
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert isinstance(Generic.__dir__(Generic()), list)



# Generated at 2022-06-23 21:25:57.522375
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    objectGeneric = Generic(seed=11)
    print(dir(objectGeneric))

    objectGeneric.add_provider(Path)
    print(dir(objectGeneric))

if __name__ == "__main__":
    test_Generic___dir__()

# Generated at 2022-06-23 21:26:03.357037
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person
    assert gen.address
    assert gen.datetime
    assert gen.business
    assert gen.text
    assert gen.food
    assert gen.science
    assert gen.transport
    assert gen.code
    assert gen.unit_system
    assert gen.file
    assert gen.numbers
    assert gen.development
    assert gen.hardware
    assert gen.clothing
    assert gen.internet
    assert gen.path
    assert gen.payment
    assert gen.cryptographic
    assert gen.structure
    assert gen.choice


# Generated at 2022-06-23 21:26:10.581376
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert (Generic().__getattr__('_person') is not None)
    assert (Generic().__getattr__('_address') is not None)
    assert (Generic().__getattr__('_datetime') is not None)
    assert (Generic().__getattr__('_business') is not None)
    assert (Generic().__getattr__('_text') is not None)
    assert (Generic().__getattr__('_food') is not None)
    assert (Generic().__getattr__('_science') is not None)


# Generated at 2022-06-23 21:26:17.247079
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    class Test:
        """Class for testing."""

    class TestSubclass(BaseProvider):
        """Class for testing."""

    generic = Generic('ru')
    generic.add_provider(Test)
    try:
        generic.add_provider(TestSubclass)
    except:
        assert False
    assert True


# Generated at 2022-06-23 21:26:18.560931
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    for provider in g.__dir__():
        getattr(g, provider).__class__


# Generated at 2022-06-23 21:26:23.135847
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = g.__dir__()
    assert result is not None
    assert len(result) > 1
    assert all(isinstance(item, str) for item in result)
    assert all(len(item) > 0 for item in result)
    assert all(not item.startswith('_') for item in result)


# Generated at 2022-06-23 21:26:26.454294
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    a = Generic()
    a.add_providers(X, Y, Z)
    assert hasattr(a, 'x')
    assert hasattr(a, 'y')
    assert hasattr(a, 'z')


# Generated at 2022-06-23 21:26:37.620307
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    gen = Generic()
    assert callable(getattr(gen, 'person'))
    assert callable(getattr(gen, 'address'))
    assert callable(getattr(gen, 'datetime'))
    assert callable(getattr(gen, 'business'))
    assert callable(getattr(gen, 'text'))
    assert callable(getattr(gen, 'food'))
    assert callable(getattr(gen, 'science'))
    assert callable(getattr(gen, 'transport'))
    assert callable(getattr(gen, 'code'))
    assert callable(getattr(gen, 'unit_system'))
    assert callable(getattr(gen, 'file'))
    assert callable(getattr(gen, 'numbers'))

# Generated at 2022-06-23 21:26:45.853907
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    # The following name errors should occur
    g = Generic()
    g.test_name_error()
    g.test_name_error1
    g.test_name_error2
    g.test_name_error3
    g.test_name_error4()
    g.test_name_error5()()
    g.test_name_error6()()()
    g.test_name_error7()()()()()()()()

# Generated at 2022-06-23 21:26:48.412812
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    print(gen.__dir__())

# Generated at 2022-06-23 21:26:53.744628
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            return self.random.choice(['foo', 'bar'])

    gen = Generic()
    gen.add_provider(CustomProvider)
    assert gen.custom_provider.foo() in ['foo', 'bar']
    assert gen.CustomProvider.foo() in ['foo', 'bar']



# Generated at 2022-06-23 21:27:02.293753
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test adding a provider to Generic() object."""
    from mimesis.providers.generic import Generic
    from mimesis.providers.base import BaseProvider

    class Custom(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Method to test."""
            return 'bar'

    g = Generic()
    g.add_provider(Custom)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-23 21:27:03.889024
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('ru')
    assert generic
    assert isinstance(generic, Generic)


# Generated at 2022-06-23 21:27:06.955208
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print('Test __getattr__() of class Generic')
    g = Generic()
    g.person.full_name()
    assert 'person' in g.__dict__
    assert callable(g.person)
    g.food.fruit()



# Generated at 2022-06-23 21:27:15.775879
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # setup
    g = Generic()

    # test_providers
    providers = {
        'food',
        'person',
        'science',
        'address',
        'datetime',
        'business',
        'text',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    }
    assert set(g.__dir__()) == providers


# Generated at 2022-06-23 21:27:17.242035
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    pass


# Generated at 2022-06-23 21:27:23.944153
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
  gen = Generic('en')
  gen.add_provider(BaseProvider)
  actual_data = list(gen.__dir__())
  expected_data = ['Meta', '_datetime', '_address', 'datetime', 'person', 'choice', 'address', 'text', 'business', 'code', 'science', 'numbers', 'unit_system', 'food', 'transport', 'hardware', 'path', 'internet', 'cryptographic', 'payment', 'development', 'clothing', 'file', 'structure', 'seed', 'locale', 'random']
  assert actual_data == expected_data


# Generated at 2022-06-23 21:27:32.659466
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """
    Test __dir__ method of class Generic.

    Set of unit tests that check field of class Generic.
    """
    assert hasattr(Generic, '__dir__')

    result_string = dir(Generic())
    test_result_string = [
        'add_provider', 'add_providers', 'address',
        'business', 'choice', 'code', 'clothing',
        'cryptographic', 'datetime', 'development',
        'file', 'food', 'hardware', 'internet',
        'numbers', 'person', 'path', 'payment',
        'science', 'seed', 'structure', 'text',
        'transport', 'unit_system'
    ]
    for element in test_result_string:
        assert element in result_string

# Generated at 2022-06-23 21:27:33.533730
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    ob = Generic.add_providers()
    assert ob == None


# Generated at 2022-06-23 21:27:39.084343
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        pass

    class GenericStub(Generic):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    person = GenericStub()
    person.add_provider(CustomProvider)
    assert hasattr(person, 'custom_provider')


# Generated at 2022-06-23 21:27:45.315422
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'myprovider'

        def method(self):
            return self.random.randint(0, 9999)

    class MyProvider2(BaseProvider):
        class Meta:
            name = 'myprovider2'

        def method(self):
            return self.random.randint(0, 9999)

    g = Generic()
    g.add_providers(MyProvider, MyProvider2)
    assert isinstance(g.myprovider, MyProvider)
    assert isinstance(g.myprovider2, MyProvider2)
    assert callable(g.myprovider.method)
    assert callable(g.myprovider2.method)
    assert isinstance(g.myprovider.method(), int)

# Generated at 2022-06-23 21:27:47.510523
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Create a Generic() instance
    generic = Generic()

    assert generic.food is not None
    assert generic.food.get_fruit() is not None


# Generated at 2022-06-23 21:27:49.999056
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    func = getattr(generic, 'person')
    assert generic.person == func



# Generated at 2022-06-23 21:28:00.890072
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    # check that all attributes are availables
    from mimesis.enums import DataField, Field, Language
    for field in DataField:
        for field_name in field.value:
            attr = getattr(g, field_name)
            assert isinstance(attr, BaseDataProvider)
            for subfield in Field:
                assert hasattr(attr, subfield.value)
    # check if Ru and En are the same
    locales = {Language.RU, Language.EN}
    for lang in locales:
        g.add_locale(lang)
        for field in DataField:
            for field_name in field.value:
                attr = getattr(g, field_name)
                assert isinstance(attr, BaseDataProvider)

# Generated at 2022-06-23 21:28:02.001362
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person



# Generated at 2022-06-23 21:28:07.669314
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        @property
        def foo(self):
            return 'foo'

    generic = Generic()
    generic.add_provider(Provider)
    assert generic.provider.foo == 'foo'


# Generated at 2022-06-23 21:28:09.600713
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Tests get attribute without underscore."""
    g = Generic()
    g.__getattr__('address')
    assert g.__dict__['address']



# Generated at 2022-06-23 21:28:11.160508
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    string = generic.text.text()
    print(string)

# Generated at 2022-06-23 21:28:13.423550
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # GIVEN
    generic = Generic()
    providers = []
    # WHEN
    # THEN
    generic.add_providers(*providers)

# Generated at 2022-06-23 21:28:19.062576
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Check method __dir__ of class Generic.

    :return: None.
    """
    generic = Generic('en')
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')

    assert generic.__dir__() == [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]

# Generated at 2022-06-23 21:28:22.695059
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person.full_name()
    assert '_person' in dir(g)
    assert g.person.full_name() == g._person.full_name()


# Generated at 2022-06-23 21:28:30.491020
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert a.gen_byte(length=2) == b'\xc3\x89'
    assert a.gen_uuid4() == '4bf19eae-9b2d-4e6c-b7e0-a77002e7d144'
    assert a.gen_uuid5() == 'd1b6c0b7-a8f8-5408-aac2-ee2bb4680f9a'
    assert a.gen_uuid1() == '51d2b49e-b0f3-11e9-9c3d-3c970e4a9cbf'
    assert a.gen_email() == 'enriquemccoy@yahoo.com'
    assert a.gen_username() == 'jeffreyward'
    assert a

# Generated at 2022-06-23 21:28:32.761024
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic(seed=123)
    assert len(dir(a)) == len(dir(Generic))
    assert len(dir(a)) == len(a._data)


# Generated at 2022-06-23 21:28:35.246415
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """."""
    gen = Generic('en')
    gen.add_providers(Numbers)
    assert hasattr(gen, 'numbers')
    assert callable(gen.numbers)

# Generated at 2022-06-23 21:28:42.157364
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # TODO: The test don't work
    # Provides a lang with is not in list of supported one
    x = Generic('xx')
    result = x.__dir__()
    assert ('person', 'address', 'datetime', 'business', 'food',
            'science', 'transport', 'code', 'choice', 'unit_system',
            'file', 'numbers', 'development', 'hardware', 'clothing',
            'internet', 'path', 'payment', 'cryptographic', 'structure'
            ) in result


# Test adding a custom provider.

# Generated at 2022-06-23 21:28:45.341874
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_obj = Generic('en')
    print(test_obj.unit_system)
    print(test_obj.payment)
    print(test_obj.structure)

# Generated at 2022-06-23 21:28:46.917950
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic_t = Generic(None)
    generic_t.__dir__()

# Generated at 2022-06-23 21:28:52.615972
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    d = Generic()
    assert 'stuff' not in dir(d)

    class Stuff(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.hello = 'hello'

    d.add_providers(Stuff)
    assert 'stuff' in dir(d)
    assert d.stuff.hello == 'hello'

# Generated at 2022-06-23 21:28:55.931062
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    instances = Generic()
    instances.add_provider(Datetime)
    instances.add_provider(Person)
    assert 'person' in instances.__dir__()
    assert 'datetime' in instances.__dir__()
    assert 'person' in instances.__dir__()

# Generated at 2022-06-23 21:29:04.253917
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(token_length=10)
    assert generic is not None
    assert generic.choice is not None
    assert generic.food is not None
    assert generic.cryptographic is not None
    assert generic.numbers is not None
    assert generic.business is not None
    assert generic.internet is not None
    assert generic.development is not None
    assert generic.transport is not None
    assert generic.path is not None
    assert generic.unit_system is not None
    assert generic.person is not None
    assert generic.file is not None
    assert generic.datetime is not None
    assert generic.hardware is not None
    assert generic.science is not None
    assert generic.clothing is not None
    assert generic.text is not None
    assert generic.structure is not None
    assert generic.payment is not None


# Generated at 2022-06-23 21:29:16.460260
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert not hasattr(generic, 'ru_person')
    assert not hasattr(generic, 'ru_address')

    class RuPerson(Person):
        """Represents data provider for Russian locale."""

        class Meta:
            """Class for metadata."""

            name = 'ru_person'

    class RuAddress(Address):
        """Represents data provider for Russian locale."""

        class Meta:
            """Class for metadata."""

            name = 'ru_address'

    generic.add_provider(RuPerson)
    assert hasattr(generic, 'ru_person')
    assert not hasattr(generic, 'ru_address')

    generic.add_provider(RuAddress)
    assert hasattr(generic, 'ru_address')
    assert hasattr(generic, 'ru_person')

    generic.add

# Generated at 2022-06-23 21:29:28.262880
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers method of class Generic.

    :return: None
    """
    def foo_bar_provider():
        """Provider for foo_bar."""
        class FooBar(BaseProvider):
            """Main class."""

            def foo_bar(self) -> str:
                """Foo bar method."""
                return self.choice(['foo', 'bar'])

        return FooBar

    class TestProvider(BaseProvider):
        """Test provider."""

        def test(self) -> Any:
            """Test method."""
            return self.choice(['test'])

    class FooProvider(BaseProvider):
        """Foo provider."""

        def foo(self) -> str:
            """Foo method."""
            return self.choice(['foo', 'bar'])

    gen = Generic()
    gen

# Generated at 2022-06-23 21:29:31.034638
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.__getattr__('person')
    assert 'person' in generic.__dict__


# Generated at 2022-06-23 21:29:33.397415
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__() of class Generic."""
    generic = Generic()
    assert generic.choice in generic.__dir__()

# Generated at 2022-06-23 21:29:36.724458
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
  generic = Generic('en')
  assert isinstance(generic.__dir__(), list)
  assert len(generic.__dir__()) > 0



# Generated at 2022-06-23 21:29:41.395970
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.robot import Robot
    from mimesis.providers.mail import Email
    generic = Generic('en')
    generic.add_providers(Robot, Email)
    assert hasattr(generic, 'robot')
    assert hasattr(generic, 'email')