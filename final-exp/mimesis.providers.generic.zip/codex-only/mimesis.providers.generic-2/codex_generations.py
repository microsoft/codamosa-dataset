

# Generated at 2022-06-23 21:19:46.105326
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert all([
        attr in generic.__dir__()
        for attr in list(generic.__dict__)
        if not attr.startswith('_')
    ])

# Generated at 2022-06-23 21:19:49.833005
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Business, Text)
    assert 'business' in generic.__dict__.keys()
    assert 'text' in generic.__dict__.keys()


# Generated at 2022-06-23 21:19:54.380213
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    Test add provider to class Generic()
    """
    # Note: This condition is skipped to avoid error
    #       when running tests under py37
    if __name__ != '__main__':
        cls = Generic
        obj = cls()
        obj.add_providers(Code, Cryptographic)

# Generated at 2022-06-23 21:20:01.680570
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    expected = [
        'person', 'address', 'datetime', 'business', 'text',
        'food', 'science', 'transport', 'code', 'unit_system',
        'file', 'numbers', 'development', 'hardware', 'clothing',
        'internet', 'path',
        'payment', 'cryptographic', 'structure', 'choice'
    ]
    result = g.__dir__()
    assert sorted(result) == sorted(expected)

# Generated at 2022-06-23 21:20:04.079303
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic(seed=123)
    g.add_providers(Structure, Payment)
    assert 'structure' in dir(g)
    assert 'payment' in dir(g)

# Generated at 2022-06-23 21:20:06.614362
# Unit test for constructor of class Generic
def test_Generic():
    ''' Unit test for constructor of class Generic
        Added by Yitesh '''
    obj = Generic()
    assert obj.unit_system.name == 'generic:unit_system'


# Generated at 2022-06-23 21:20:17.101386
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.internet import Internet as I
    from mimesis.providers.person import Person as P
    from mimesis.providers.file import File as F
    G = Generic()
    # one custom provider
    G.add_provider(I)
    assert hasattr(G, 'internet')
    assert G.internet.__class__.__name__ == I.__name__
    assert G.internet.locale == G.locale
    assert G.internet.seed == G.seed
    # two custom providers
    G.add_provider(P)
    assert hasattr(G, 'person')
    assert G.person.__class__.__name__ == P.__name__
    assert G.person.locale == G.locale
    assert G.person.seed == G.seed


# Generated at 2022-06-23 21:20:20.825066
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.data import Data

    generic = Generic('en')
    data = Data('en')
    generic.add_provider(Data)
    assert generic.data == data


# Generated at 2022-06-23 21:20:30.873606
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    x = generic.person_full_name
    assert x == 'Mrs. Courtney Shaffer'
    x = generic.address_city
    assert x == 'Hudson'
    x = generic.datetime_rfc1123
    assert x == 'Mon, 16 Dec 2019 17:34:58 GMT'
    x = generic.business_company_name
    assert x == 'Knapp-Abernathy'
    x = generic.text_sentence
    assert x == 'Consectetur soluta quas.'
    x = generic.food_beverage
    assert x == 'Coke'
    x = generic.science_element
    assert x == 'Hydrogen'
    x = generic.transport_vehicle
    assert x == 'Sedan'
    x = generic.code_isbn

# Generated at 2022-06-23 21:20:42.197258
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test ``Generic.__getattr__()`` method."""
    a = Generic()
    assert a.person()
    assert a.address()
    assert a.datetime()
    assert a.business()
    assert a.text()
    assert a.food()
    assert a.science()
    assert a.transport()
    assert a.code()
    assert a.unit_system()
    assert a.file()
    assert a.numbers()
    assert a.development()
    assert a.hardware()
    assert a.clothing()
    assert a.internet()
    assert a.path()
    assert a.payment()
    assert a.cryptographic()
    assert a.structure()
    assert a.choice()

# Generated at 2022-06-23 21:20:51.291699
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=42)
    # making sure that the attribute person is not in __dict__
    assert 'person' not in generic.__dict__
    # calling person property
    assert generic.person.__class__.__name__ == 'Person'
    # making sure person attribute is in __dict__
    assert 'person' in generic.__dict__
    # making sure person property is stored in Generic's __dict__
    assert generic.__dict__['person'].__class__.__name__ == 'Person'
    # making sure that the attribute business is not in __dict__
    assert 'business' not in generic.__dict__
    # calling business property
    assert generic.business.__class__.__name__ == 'Business'
    # making sure business attribute is in __dict__
    assert 'business' in generic.__dict__

# Generated at 2022-06-23 21:20:58.032679
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # 1. Сreate functional object
    class SomeProvider(BaseProvider):
        """Just for testing."""

        class Meta:
            """Class for metadata."""

            name = 'some_provider'

        def my_method(self) -> str:
            """."""
            return 'test'

    test_object = Generic()
    test_object.add_provider(SomeProvider)
    assert test_object.some_provider.my_method() == 'test'
    assert test_object.some_provider.seed == test_object.seed
    assert test_object.some_provider.locale == test_object.locale


# Generated at 2022-06-23 21:21:07.620016
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person.full_name()
    g.address.address()
    g.datetime.datetime()
    g.business.company()
    g.text.text()
    g.science.chemical_element()
    g.transport.vehicle()
    g.code.isbn()
    g.unit_system.angle()
    g.file.filename()
    g.numbers.geometric_mean()
    g.development.technology()
    g.hardware.cpu()
    g.clothing.clothing()
    g.internet.domain_name()
    g.path.directory()
    g.payment.card_number()
    g.cryptographic.md5()
    g.structure.uuid()
    g.choice.element()

# Generated at 2022-06-23 21:21:09.585442
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert getattr(generic, 'movies') == None

    import mimesis.providers.movies
    generic.add_provider(mimesis.providers.movies.Movies)
    assert getattr(generic, 'movies') != None

# Generated at 2022-06-23 21:21:18.174610
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for generating instance of a custom provider

    :return: None
    """
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def method(self) -> str:
            """Get a pre-defined string.

            :return: A pre-defined string.
            """
            return 'custom_provider'

    gen = Generic()
    gen.add_provider(CustomProvider)
    gen_custom = gen.custom
    assert gen_custom.method() == 'custom_provider'



# Generated at 2022-06-23 21:21:22.380672
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    assert not hasattr(g, '_provider')
    assert not hasattr(g, 'provider')

    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

    g.add_provider(Provider)
    assert hasattr(g, 'provider')
    assert issubclass(g.provider, BaseProvider)



# Generated at 2022-06-23 21:21:24.533953
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic()
    provider = data.person
    assert isinstance(provider, Person)



# Generated at 2022-06-23 21:21:26.469798
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert g.person.__class__.__name__ == 'Person'


# Generated at 2022-06-23 21:21:32.731784
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    seed=1
    obj=Generic(seed=seed)
    print(obj.text.word(), obj.text.word())
    print(obj.person.full_name())
    print(obj.text.word())
    print(obj.business.company())
    print(obj.person.full_name())
    print(obj.transport.car())


# Generated at 2022-06-23 21:21:38.644568
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.development import Development
    from mimesis.providers.food import Food
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.base import BaseDataProvider

# Generated at 2022-06-23 21:21:49.117858
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.basic import Basic
    from mimesis.providers.currency import Currency
    from mimesis.providers.custom import CustomText
    from mimesis.providers.person import Person

    g = Generic()
    g.add_provider(Basic)
    g.add_provider(Currency)
    g.add_provider(CustomText)
    g.add_provider(Person)
    g.add_providers(Currency, Person, Basic)

    assert isinstance(g.basic, Basic)
    assert isinstance(g.currency, Currency)
    assert isinstance(g.custom_text, CustomText)
    assert isinstance(g.person, Person)
    assert isinstance(g.currency, Currency)
    assert isinstance(g.person, Person)

# Generated at 2022-06-23 21:21:59.852942
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import random
    random.seed(1)
    gen = Generic(1)
    assert gen.mac_address == '74:8C:A2:18:D1:2E'
    assert gen.street_name() == 'South street'
    assert gen.business.credit_card_number() == '4028 4794 7349 4585'
    assert gen.business.company() == 'Wells, Baker and Barber'
    assert gen.business.bank_iban() == 'GB20 BARC 2065 2533 6134 71'
    assert gen.address.country() == 'Germany'
    assert gen.address.region() == 'Bavaria'
    assert gen.address.city() == 'Rosenheim'
    assert gen.choice.weighted(1, 2, 3)
    assert gen.numbers.between(1, 1)

# Generated at 2022-06-23 21:22:05.764883
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
	class BasicTest(BaseProvider):
		class Meta:
			name = 'test'
		def func():
			return 'test'
	g = Generic()
	g.add_provider(BasicTest)
	assert g.test.func() == 'test'
	del g



# Generated at 2022-06-23 21:22:08.076482
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=43)
    assert g
    assert g.provider_name is Generic.Meta.name

# Generated at 2022-06-23 21:22:11.979606
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    pre_len = len(dir(gen))
    gen.add_provider(TestProvider)
    post_len = len(dir(gen))
    assert pre_len != post_len

# Generated at 2022-06-23 21:22:21.062984
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.choice is not None
    assert g.clothing is not None
    assert g.code is not None
    assert g.cryptographic is not None
    assert g.datetime is not None
    assert g.development is not None
    assert g.file is not None
    assert g.hardware is not None
    assert g.internet is not None
    assert g.numbers is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.science is not None
    assert g.structure is not None
    assert g.transport is not None
    assert g.unit_system is not None
    assert g.food is not None
    assert g.person is not None
    assert g.text is not None
    assert g.address is not None

# Generated at 2022-06-23 21:22:23.221799
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(g.person)



# Generated at 2022-06-23 21:22:32.103561
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    from mimesis.providers.file import File
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.person import Person
    from mimesis.providers.person import Provider as PersonProvider
    from mimesis.providers.text import Text
    from mimesis.providers.text import Provider as TextProvider
    from mimesis.providers.address import Address

# Generated at 2022-06-23 21:22:37.005298
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Generic)
    assert 'generic' in generic.__dict__
    assert 'generic' in generic.__dir__()
    assert generic.generic is not None

# Generated at 2022-06-23 21:22:44.902777
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test class Generic."""
    generic = Generic()
    # assert 'locale' in generic.__dict__
    # assert 'seed' in generic.__dict__
    # assert 'person' in generic.__dict__
    # assert 'address' in generic.__dict__
    # assert 'datetime' in generic.__dict__
    # assert 'business' in generic.__dict__
    # assert 'text' in generic.__dict__
    # assert 'food' in generic.__dict__
    # assert 'science' in generic.__dict__
    assert 'transport' in generic.__dict__
    assert 'code' in generic.__dict__
    assert 'unit_system' in generic.__dict__
    assert 'file' in generic.__dict__
    assert 'numbers' in generic.__dict__

# Generated at 2022-06-23 21:22:49.484047
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    assert len(gen.__dir__()) == 21

    class SimpleProvider(BaseProvider):
        class Meta:
            name = 'simple'

    gen.add_providers(SimpleProvider)
    assert len(gen.__dir__()) == 22

# Generated at 2022-06-23 21:22:51.003802
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(struct.StructuredAddress)
    assert hasattr(g, 'structured_address')

# Generated at 2022-06-23 21:22:53.679635
# Unit test for constructor of class Generic
def test_Generic():
    p = Generic('zh')
    print(p.food.vegetable())
    print(p.food.fruit())
    print(p.science.element())

# Generated at 2022-06-23 21:22:54.868772
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)



# Generated at 2022-06-23 21:22:59.287132
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Generative test for method add_providers of class Generic."""
    generic = Generic('en')
    providers = [
        BaseProvider,
        Provider,
    ]
    generic.add_providers(*providers)
    providers_names = [
        'BaseProvider',
        'Provider',
    ]
    for name, provider in zip(providers_names, providers):
        assert getattr(generic, name) == provider(seed=generic.seed)

# Generated at 2022-06-23 21:23:08.339046
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    custom_provider = CustomProvider()
    g = Generic()
    g.add_providers(custom_provider)
    assert g.custom_provider.__class__.__name__ == "CustomProvider"
    # Because of the BaseProvider __init__, the seeds of the custom_provider and g
    # are the same, provided by the parent BaseDataProvider class
    assert g.custom_provider.seed == g.seed

# Generated at 2022-06-23 21:23:10.373065
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Datetime)
    assert isinstance(generic.datetime, Datetime)




# Generated at 2022-06-23 21:23:12.402678
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    all_providers = Generic().__dir__()
    for provider in all_providers:
        Generic().__getattr__(provider)

# Generated at 2022-06-23 21:23:17.488181
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic("en", "ru")
    assert generic.person == generic.__getattr__("person")
    assert generic.address == generic.__getattr__("address")
    assert generic.datetime == generic.__getattr__("datetime")
    assert generic.business == generic.__getattr__("business")
    assert generic.text == generic.__getattr__("text")
    assert generic.food == generic.__getattr__("food")
    assert generic.science == generic.__getattr__("science")

# Generated at 2022-06-23 21:23:26.076867
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print ('\n=========Unit test for method __getattr__ of class Generic=========')
    g = Generic()
    print(g.datetime.formatted_datetime())
    print(g.transport.airport())
    print(g.code.product_code())
    print(g.unit_system.weight())
    print(g.file.mime_type())
    print(g.numbers.positive_decimal())
    print(g.development.programming_language())
    print(g.hardware.cpu())
    print(g.clothing.coat())
    print(g.internet.email())
    print(g.path.unix_path())
    print(g.payment.bank_identification_number())
    print(g.cryptographic.sha1())

# Generated at 2022-06-23 21:23:32.794038
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Tests for Generic.__dir__()."""
    g = Generic()
    assert 'person' in dir(g)
    assert 'address' in dir(g)
    assert 'business' in dir(g)
    assert 'datetime' in dir(g)
    assert 'text' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)
    assert 'transport' in dir(g)
    assert 'code' in dir(g)
    assert 'unit_system' in dir(g)
    assert 'file' in dir(g)
    assert 'numbers' in dir(g)
    assert 'development' in dir(g)
    assert 'hardware' in dir(g)
    assert 'clothing' in dir(g)
    assert 'internet' in dir

# Generated at 2022-06-23 21:23:41.294147
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    person = obj.person
    assert person.full_name() == 'James Murray'
    assert person.full_name() == 'Cecilia Maxwell'
    assert person.full_name() == 'Diana Walsh'
    address = obj.address
    assert address.city() == 'Laurel'
    assert address.city() == 'Westbury'
    assert address.city() == 'Casper'
    business = obj.business
    assert business.company() == 'Blaze, Waters and Schmitt'
    assert business.company() == 'Bailey and Sons'
    assert business.company() == 'Miller Group'
    datetime = obj.datetime
    assert datetime.datetime() == '2018-08-26T07:04:50'

# Generated at 2022-06-23 21:23:44.981481
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.payment import Payment

    a = Generic()
    assert a.payment.__class__.__name__ == \
           Payment.__name__
    a.add_provider(Payment)
    assert type(a.payment) == Payment
test_Generic_add_provider()

# Generated at 2022-06-23 21:23:53.654440
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    providers = [
        'person', 'clothing', 'business', 'choice',
        'science', 'transport', 'development', 'cryptographic',
        'address', 'file', 'food', 'hardware', 'internet',
        'numbers', 'path', 'payment', 'structure', 'datetime',
        'code', 'text', 'unit_system'
    ]

    generic = Generic('en')
    result = generic.__dir__()
    assert isinstance(result, list)
    assert len(result) > 0

    assert set(result).issubset(providers)

# Generated at 2022-06-23 21:23:54.334651
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-23 21:24:04.466172
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    from mimesis.providers.science import Science
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.path import Path
    from mimesis.providers.crypto import Cryptographic
    from mimesis.providers.structure import Structure
    from mimesis.providers.choice import Choice
    datetime = Datetime(seed=10)
    address = Address(seed=10)
   

# Generated at 2022-06-23 21:24:13.537025
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__() == [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'structure',
        'choice',
        'cryptographic'
    ]


# Generated at 2022-06-23 21:24:15.646655
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert g.person



# Generated at 2022-06-23 21:24:26.502799
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert hasattr(Generic(), '__dir__')
    assert callable(getattr(Generic(), '__dir__'))

    g = Generic()
    dir_generic = dir(g)
    assert 'address' in dir_generic
    assert 'business' in dir_generic
    assert 'choice' in dir_generic
    assert 'clothing' in dir_generic
    assert 'code' in dir_generic
    assert 'cryptographic' in dir_generic
    assert 'datetime' in dir_generic
    assert 'development' in dir_generic
    assert 'file' in dir_generic
    assert 'food' in dir_generic
    assert 'hardware' in dir_generic
    assert 'internet' in dir_generic
    assert 'numbers' in dir_generic
    assert 'path' in dir_generic
    assert 'person' in dir_

# Generated at 2022-06-23 21:24:30.214862
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():

    def test(method, args, expected):
        method(*args)==expected

    from mimesis.providers.geography import Territory

    generic = Generic()
    territory = Territory(seed=generic.seed)

    test(generic.add_providers, [territory], None)

# Generated at 2022-06-23 21:24:31.666339
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)



# Generated at 2022-06-23 21:24:35.849738
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__
    of class Generic()."""
    g = Generic()
    assert g.person.full_name() == 'Liam Peterson'
    assert g.address.full_address() == '5, South Regina Ave., '\
        'Kelowna, BC, V5, , Canada'

# Generated at 2022-06-23 21:24:41.254975
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person == g._person(g.locale, g.seed)
    g.datetime == g._datetime(g.locale, g.seed)
    g.business == g._business(g.locale, g.seed)
    g.text == g._text(g.locale, g.seed)
    g.food == g._food(g.locale, g.seed)
    g.science == g._science(g.locale, g.seed)


# Generated at 2022-06-23 21:24:43.709842
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for the method __getattr__ of class Generic."""
    g = Generic()
    assert g.person



# Generated at 2022-06-23 21:24:49.876998
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.vehicle import Vehicle
    from mimesis.providers.personal import Personal

    g = Generic()
    assert not hasattr(g, 'vehicle')
    assert not hasattr(g, 'personal')

    g.add_providers(Vehicle, Personal)
    assert hasattr(g, 'vehicle')
    assert hasattr(g, 'personal')

# Generated at 2022-06-23 21:24:53.012274
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert Generic(seed=123)
    assert a.__class__.__name__ == 'Generic'
    assert hasattr(a, 'address')
    assert hasattr(a, 'choice')

# Generated at 2022-06-23 21:24:56.514101
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic("nl")
    
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

    generic.add_provider(TestProvider)
    assert generic.test
    
    

# Generated at 2022-06-23 21:25:01.505543
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'myprovider'

        def foo(self):
            return self.random.randint(0,10)

    provider = Generic()
    provider.add_providers(MyProvider)
    result = provider.myprovider.foo()
    assert result >= 0


# Generated at 2022-06-23 21:25:05.938522
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """
    Unit test for method __getattr__ of class Generic.
    """
    # Arrange
    generic = Generic()
    # Act
    result = generic.person
    # Assert
    assert isinstance(result, Person)
    assert result == generic.person
    assert result is generic._person



# Generated at 2022-06-23 21:25:06.588320
# Unit test for constructor of class Generic
def test_Generic():
    pass

# Generated at 2022-06-23 21:25:10.864388
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class Provider(BaseProvider):
        def get_numbers(self):
            return 'get_numbers'

    providers = [Provider, Provider]
    generic = Generic()
    generic.add_providers(*providers)

    assert 'get_numbers' in generic.__dir__()

# Generated at 2022-06-23 21:25:19.895894
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=0)
    assert g.person.full_name() == 'Богдан Лыков'
    assert g.address.city() == 'Подпорожье'
    assert g.datetime.date(start=2018, end=2028) == '06.06.2021'
    assert g.person.username() == 'kpugachev'
    assert g.text.word() == 'погань'
    assert g.food.vegetable() == 'баклажан'
    assert g.transport.car() == 'Москвич-2141'
    assert g.code.imei() == '018127969477277'
    assert g.business.iban()

# Generated at 2022-06-23 21:25:22.963362
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    _ = Generic()
    try:
        _.add_providers()
    except TypeError:
        _.add_providers(BaseProvider)
    except Exception:
        pass

# Generated at 2022-06-23 21:25:30.709649
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic"""
    # Create object
    provider = Generic()
    # Add custom provider
    provider.add_provider(Person)
    # Test method
    assert hasattr(provider, 'person')
    assert not hasattr(provider, '_person')
    assert hasattr(provider, 'address')
    assert hasattr(provider, 'datetime')
    # Test method with param is not a class
    provider.add_provider(Person.full_name)
    # Test method
    assert hasattr(provider, 'person')
    assert not hasattr(provider, '_person')
    assert hasattr(provider, 'address')
    assert hasattr(provider, 'datetime')


# Generated at 2022-06-23 21:25:34.523738
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('ru')
    assert generic._person is Person
    assert generic._address is Address
    assert generic._datetime is Datetime
    assert generic._business is Business
    assert generic._text is Text
    assert generic._food is Food
    assert generic._science is Science

# Generated at 2022-06-23 21:25:45.174590
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Test for: Add a lot of custom providers to Generic() object.
    from mimesis.providers.base import BaseProvider, Meta
    from mimesis.providers.person import Person as P
    from mimesis.enums import Gender
    from mimesis.data import Person as D
    from mimesis.builtins import datetime

    class Echo:
        """Echo custom_provider."""
        class Meta(Meta):
            """Class for meta."""
            name = 'echo'
            provider_name = 'echo'

        def __init__(self, seed=None):
            """Initialize attributes."""
            self._data = D
            self._seed = seed
            self.__locale = None
            self.__dt = datetime
            self.__gender = Gender


# Generated at 2022-06-23 21:25:49.382156
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    parser = Generic(seed=12356)
    parser.add_providers(Clothing)
    assert parser.Clothing.fabric() == "linen"
    assert parser.Clothing.bathing_suit_style() == "pirate"

# Generated at 2022-06-23 21:25:50.010677
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic


# Generated at 2022-06-23 21:25:57.995612
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):

        def foo(self):
            return 'foo'

        class Meta:
            name = 'custom'
    generic = Generic()
    assert 'custom' not in dir(generic)
    generic.add_provider(Custom)
    assert 'custom' in dir(generic)
    assert generic.custom.foo() == 'foo'
    assert Generic().add_provider(Custom) is None
    assert Generic().add_provider(Custom) == Generic().add_provider(Custom())
    assert Generic().add_provider(Custom) == Generic().add_provider('hello')

# Generated at 2022-06-23 21:26:03.007600
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test adding the custom provider to Generic.

    :return: None
    """
    from mimesis.providers.cryptographic import Cryptographic

    g = Generic()
    assert 'cryptographic' not in g.__dict__.keys()
    g.add_provider(Cryptographic)
    assert 'cryptographic' in g.__dict__.keys()
    try:
        g.add_provider(Cryptographic)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-23 21:26:12.453188
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        """Custom class."""

        class Meta:
            """Meta class."""

            name = 'custom_provider'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize custom class attributes.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self.__seed = None

        @property
        def seed(self) -> Any:
            """Getter for seed.

            :return: Seed.
            """
            return self.__seed

        @seed.setter
        def seed(self, value: Any) -> None:
            """Setter for seed.

            :param value: Seed.
            """
            self.__seed = value



# Generated at 2022-06-23 21:26:19.342535
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ method."""
    data = Generic()
    assert isinstance(data, Generic)
    assert isinstance(data.person, Person)
    assert isinstance(data.address, Address)
    assert isinstance(data.datetime, Datetime)
    assert isinstance(data.business, Business)
    assert isinstance(data.text, Text)
    assert isinstance(data.food, Food)
    assert isinstance(data.science, Science)



# Generated at 2022-06-23 21:26:24.584074
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.name == 'Generic'
    assert generic.address == '359 Graaskamp Trail'
    assert generic.datetime == '2019-01-17 22:24:35.936377'
    assert generic.business == '18. számú cégbíróság'
    assert generic.choice.gen_element([1, 2, 3]) == 2
    assert generic.text.sentence() == 'Nihil laborum et qui doloremque.'

# Generated at 2022-06-23 21:26:27.875183
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method `Generic().__getattr__()`."""
    gen = Generic('en')
    name = gen.person.full_name()
    assert name == 'Brandon Nguyen'



# Generated at 2022-06-23 21:26:38.614526
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    for i in range(10):
        generic = Generic(seed=i)
        result = generic.__dir__()
        assert isinstance(result, list)
        assert '__class__' not in result
        assert '__init__' not in result
        assert '__module__' not in result
        assert 'Meta' not in result
        assert generic._person.Meta.name in result
        assert generic._address.Meta.name in result
        assert generic._datetime.Meta.name in result
        assert generic._business.Meta.name in result
        assert generic._text.Meta.name in result
        assert generic._food.Meta.name in result
        assert generic._science.Meta.name in result
        assert 'transport' in result
        assert 'code' in result

# Generated at 2022-06-23 21:26:45.083173
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

    class CustomProvider2(BaseProvider):
        class Meta:
            name = 'custom2'

    # Test
    gen = Generic()
    gen.add_providers(CustomProvider, CustomProvider2)
    assert hasattr(gen, 'custom_provider')
    assert hasattr(gen, 'custom2_provider')

# Generated at 2022-06-23 21:26:48.058210
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider(BaseProvider):
        def met(self):
            return 'test'

    gp = Generic()
    gp.add_providers(TestProvider(), TestProvider, TestProvider)

# Generated at 2022-06-23 21:26:54.552588
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Base(BaseProvider):
        class Meta:
            name = "base"

    class Foo(BaseProvider):
        class Meta:
            name = "foo"

    class Bar(BaseProvider):
        class Meta:
            name = "bar"

    generic = Generic()
    generic.add_providers(Base, Foo, Bar)
    assert isinstance(generic.base, Base) and \
        isinstance(generic.foo, Foo) and \
        isinstance(generic.bar, Bar)

# Generated at 2022-06-23 21:26:57.152894
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    p = g.person
    assert p.first_name() == 'Joe'
    assert p.last_name() == 'Bennett'

# Generated at 2022-06-23 21:27:06.989134
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import mock
    from mimesis.providers.language import Language
    from mimesis.providers.person import Person
    from mimesis.providers.person import Person as Person2
    gen = Generic()
    assert not hasattr(gen, 'language')
    assert not hasattr(gen, 'person')
    assert not hasattr(gen, 'person2')
    with mock.patch('mimesis.providers.Generic.add_provider',
                    wraps=gen.add_provider) as mock_add:
        gen.add_providers(Language, Person, Person2)
        mock_add.assert_has_calls([
            mock.call(Language),
            mock.call(Person),
            mock.call(Person2),
        ])
    assert hasattr(gen, 'language')

# Generated at 2022-06-23 21:27:12.583964
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert ['address', 'business', 'choice', 'clothing', 'code',
            'cryptographic', 'datetime', 'development', 'file',
            'food', 'hardware', 'internet', 'numbers', 'path',
            'payment', 'person', 'science', 'structure',
            'text', 'transport', 'unit_system'] == Generic().__dir__()


# Generated at 2022-06-23 21:27:16.029751
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    gen = Generic()
    gen.add_provider(Code)
    assert isinstance(gen.code, Code)
    assert not isinstance(gen.code, Datetime)



# Generated at 2022-06-23 21:27:20.720363
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit tests for testing the method add_provider of class Generic."""
    gen = Generic()
    assert True not in [hasattr(gen, 'custom_provider')]
    gen.add_provider(Business)
    assert True in [hasattr(gen, 'business')]
    assert False in [hasattr(gen, 'custom_provider')]


# Generated at 2022-06-23 21:27:22.535360
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of class Generic."""
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert isinstance(generic.custom, CustomProvider)



# Generated at 2022-06-23 21:27:25.108692
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__(attrname: str) -> Any."""
    gen = Generic()
    assert gen.person is not None
    assert gen.address is not None
    assert gen.datetime is not None
    assert gen.business is not None
    assert gen.text is not None
    assert gen.choice is not None


# Generated at 2022-06-23 21:27:28.694229
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__."""
    tests = [
        ('person', Person),
        ('address', Address),
        ('datetime', Datetime),
        ('business', Business),
        ('text', Text),
        ('food', Food),
        ('science', Science)
    ]
    for attrname, provider in tests:
        g = Generic(seed=42)
        attr = getattr(g, attrname)
        assert isinstance(attr, provider)

# Generated at 2022-06-23 21:27:29.258917
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-23 21:27:38.391892
# Unit test for constructor of class Generic
def test_Generic():
    """Test for Generic.

    :return: None
    """
    data = Generic()
    assert data.person
    assert data.address
    assert data.datetime
    assert data.business
    assert data.text
    assert data.food
    assert data.science
    assert data.transport
    assert data.code
    assert data.unit_system
    assert data.file
    assert data.numbers
    assert data.development
    assert data.hardware
    assert data.clothing
    assert data.internet
    assert data.path
    assert data.payment
    assert data.cryptographic
    assert data.structure
    assert data.choice

# Generated at 2022-06-23 21:27:38.998334
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic()

# Generated at 2022-06-23 21:27:42.084296
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert isinstance(gen.__dir__(), list) # noqa: S101
    assert 'person' in gen.__dir__()
    assert 'business' in gen.__dir__()


# Generated at 2022-06-23 21:27:43.961587
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.custom.numbers import CustomNumbers
    gen = Generic()
    assert gen.add_providers(CustomNumbers) is None

# Generated at 2022-06-23 21:27:49.777739
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.misc import Misc
    from mimesis.enums import Gender
    from mimesis.providers.other import Other
    generic_test = Generic('uk')
    misc_test = Misc('uk')
    other_test = Other('uk')
    generic_test.add_providers(Person, Misc, Other)
    assert generic_test.person.full_name() == 'Григорій Пантеличів'
    assert generic_test.misc.gender(Gender.MALE) == 'male'
    assert generic_test.other.color() == 'pink'
    assert misc_test.gender(Gender.FEMALE) == 'female'
    assert other_test.color() == 'grey'

# Generated at 2022-06-23 21:27:56.190637
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    import mimesis.builtins.providers.address
    generic = Generic()
    generic.add_providers(mimesis.builtins.providers.address.Address)
    assert hasattr(generic, 'address')
    assert isinstance(generic.address, Generic.address)
    assert not hasattr(generic, '_address')



# Generated at 2022-06-23 21:28:04.201405
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    obj.add_provider(Person)
    person = obj.person
    address = obj.address
    address_ = obj.address_
    datetime = obj.datetime
    business = obj.business
    text = obj.text
    food = obj.food
    science = obj.science
    transport = obj.transport
    code = obj.code
    unit_system = obj.unit_system
    file = obj.file
    numbers = obj.numbers
    development = obj.development
    hardware = obj.hardware
    clothing = obj.clothing
    internet = obj.internet
    path = obj.path
    payment = obj.payment
    cryptographic = obj.cryptographic
    structure = obj.structure
    print(person)
    print(address)
    print(address_)
    print

# Generated at 2022-06-23 21:28:06.353053
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)

# Generated at 2022-06-23 21:28:13.334120
# Unit test for constructor of class Generic
def test_Generic():
    """Enter a class."""
    g = Generic()
    # print(g.__dict__)
    print(g.__dir__())
    print(dir(g))
    print(isinstance(g.numbers, Numbers))
    g.add_providers(Clothing, Science)
    print(dir(g))
    g.add_provider(Development)
    print(dir(g))
    g.add_providers(Development, Payment, Clothing)
    print(dir(g))

# test_Generic()

# Generated at 2022-06-23 21:28:14.909638
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic.person.full_name() == 'David Bradley'

# Generated at 2022-06-23 21:28:20.325238
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert '__init__' not in dir(g)
    assert 'transport' in dir(g)
    assert 'code' in dir(g)
    assert 'unit_system' in dir(g)
    assert 'file' in dir(g)
    assert 'numbers' in dir(g)
    assert 'development' in dir(g)
    assert 'hardware' in dir(g)
    assert 'clothing' in dir(g)
    assert 'internet' in dir(g)
    assert 'path' in dir(g)
    assert 'payment' in dir(g)
    assert 'cryptographic' in dir(g)
    assert 'structure' in dir(g)
    assert 'choice' in dir(g)

# Generated at 2022-06-23 21:28:30.578960
# Unit test for constructor of class Generic
def test_Generic():
    test = Generic()
    print(test.datetime.date(localized=True, format_='%d/%m/%Y'))
    print(test.datetime.time(localized=True, format_='%H:%M:%S'))
    print(test.datetime.datetime(localized=True, format_='%H:%M:%S %d/%m/%Y'))
    print(test.datetime.year(min_=1950, max_=2050))
    print(test.datetime.timestamp())

    print(test.business.company_name())
    print(test.business.credit_card_number())

    print(test.choice.boolean())
    print(test.choice.element())
    print(test.choice.elements())

# Generated at 2022-06-23 21:28:36.229629
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestDataProvider(BaseProvider):

        class Meta:
            name = __name__

        def test(self):
            return self.seed

    class TestDataProvider2(BaseProvider):

        class Meta:
            name = __name__ + '2'

        def test(self):
            return self.seed

    g = Generic()
    g.add_providers(TestDataProvider, TestDataProvider2)
    assert getattr(g._test, 'test')() == getattr(g._test2, 'test')()

# Generated at 2022-06-23 21:28:44.638590
# Unit test for constructor of class Generic
def test_Generic():
    print('========== test Generic start =========')
    gen = Generic()
    for cls in gen.__dir__():
        print( cls)
    print('========== test Generic end =========')


if __name__ == '__main__':
    '''Generate fake data using class Generic.
    For every provider method is used to generate data.

    '''
    # test_Generic()
    gen = Generic()
    person = gen.person
    address = gen.address
    fullname = person.full_name()
    address_data = address.address()
    print(fullname)
    print(address_data)

    text = gen.text
    food = gen.food
    science = gen.science

    print(text.title())
    print(text.text())
    print(food.beverage())


# Generated at 2022-06-23 21:28:54.985152
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('ja')
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'transport')
    assert hasattr(generic, 'code')
    assert hasattr(generic, 'unit_system')
    assert hasattr(generic, 'file')
    assert hasattr(generic, 'numbers')
    assert hasattr(generic, 'development')
    assert hasattr(generic, 'hardware')
    assert hasattr(generic, 'clothing')
    assert hasattr(generic, 'internet')
    assert hasattr(generic, 'path')
    assert hasattr(generic, 'payment')
    assert hasattr(generic, 'cryptographic')
    assert hasattr(generic, 'structure')

# Generated at 2022-06-23 21:29:03.549737
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider of class Generic."""
    from mimesis.providers.random import Random
    from pytest import raises

    gen = Generic()
    assert not hasattr(gen, 'random')

    gen.add_provider(Random)

    assert hasattr(gen, 'random')
    assert isinstance(gen.random, Random)

    with raises(TypeError) as exc:
        gen.add_provider(1)
    assert str(exc.value) == 'The provider must be a class'

    with raises(TypeError) as exc:
        gen.add_provider(Random(seed=1))
    assert str(exc.value) == 'The provider must be a class'

# Generated at 2022-06-23 21:29:07.489433
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of generic provider."""
    g = Generic('zh')
    g.add_provider(Generic)
    assert g.generic is not None
    assert g.generic is not g


# Generated at 2022-06-23 21:29:19.044586
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    for i in gen.__dir__():
        if i not in ['random', 'add_provider', 'add_providers']:
            assert callable(getattr(gen, i))
    assert gen.choice.random.choice(('a', 'b')) in ('a', 'b')
    assert gen.text.random.random_string(length=100)
    assert gen.datetime.random.datetime(start=-100, stop=-14)
    assert gen.code.random.hash_id(alphabet=gen.numbers.random.integers())
    assert gen.person.random.occupation()
    assert gen.food.random.measure_system()
    assert gen.clothing.random.color()
    assert gen.file.random.extension()

# Generated at 2022-06-23 21:29:27.669627
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    def attributes_for_test():
        attributes = []
        exclude = Generic.Meta.__dict__.keys()
        for a in Generic.__dict__:
            if a not in exclude:
                if a.startswith('_'):
                    attribute = a.replace('_', '', 1)
                    attributes.append(attribute)
                else:
                    attributes.append(a)
        return attributes

    generic = Generic(seed=1)
    attributes = attributes_for_test()
    for attribute in attributes:
        assert isinstance(getattr(generic, attribute), BaseProvider)



# Generated at 2022-06-23 21:29:29.519230
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert len(Generic().__dir__()) == 22


# Generated at 2022-06-23 21:29:32.418386
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen
    assert isinstance(gen, Generic)
    assert isinstance(gen, BaseDataProvider)
    assert isinstance(gen, BaseProvider)

# Generated at 2022-06-23 21:29:41.732853
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.providers.person import Person

    person = Person(seed=123)
    generic = Generic(seed=123)
    generic.add_provider(Person)
    assert person.full_name() == generic.person.full_name()
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing

    business = Business(seed=123)
    clothing = Clothing(seed=123)
    generic.add_providers(Business, Clothing)
    assert business.company() == generic.business.company()
    assert clothing.material() == generic.clothing.material()


# Generated at 2022-06-23 21:29:47.660860
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    assert g.person.full_name() == 'Mr. Dominique Gibson'
    assert g.address.country() == 'Maldives'
    assert g.food.fruit() == 'banana'
    assert g.science.element() == 'Fluorine'
    assert g.clothing.jacket() == 'anorak'
    assert g.numbers.between(1, 3) == 2
    assert g.unit_system.unit() == 'Pascal'
    assert g.transport.train() == 'Commuter train'
    assert g.payment.visa_number() == '4539557903586129'
    assert g.path.directory() == '/Users/dgibson'