

# Generated at 2022-06-23 21:19:44.332270
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.file import File
    generic = Generic()
    assert len(generic.__dir__()) == 15
    generic.add_provider(BaseProvider)
    assert len(generic.__dir__()) == 16
    generic.add_provider(File)
    assert len(generic.__dir__()) == 17


# Generated at 2022-06-23 21:19:55.544528
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider method of class Generic."""
    from mimesis.providers.science import Science

    from mimesis.providers.science import Science as Sci
    from mimesis.providers.structure import Structure as Str

    gen = Generic()
    gen.add_provider(Science)
    gen.add_provider(Structure)
    assert 'science' in gen.__dir__()
    assert 'structure' in gen.__dir__()
    assert len(gen.__dir__()) == 34
    sci = Sci()
    assert sci.choice_of(gen.science.biomes()) in gen.science.biomes()
    str_ = Str()
    assert str_.choice_of(gen.structure.data_types()) in gen.structure.data_types()



# Generated at 2022-06-23 21:20:03.947206
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    expected = [
        'address',
        'add_provider',
        'add_providers',
        'business',
        'choice',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'transport',
        'unit_system',
        'text',
    ]
    actual = obj.__dir__()
    assert sorted(expected) == sorted(actual)

# Generated at 2022-06-23 21:20:15.130887
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=1)

    print('g.seed:%s' % str(g.seed))
    print('g.person.full_name():%s' % str(g.person.full_name()))
    print('g.person.first_name():%s' % str(g.person.first_name()))
    print('g.person.last_name():%s' % str(g.person.last_name()))
    print('g.last_name():%s' % str(g.last_name()))
    print('g.address.full_address():%s' % str(g.address.full_address()))
    print('g.address.full_country():%s' % str(g.address.full_country()))

# Generated at 2022-06-23 21:20:17.939127
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Test)
    assert isinstance(gen.test, Test)


# Generated at 2022-06-23 21:20:21.696119
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    a = Generic().add_providers(Business, Address)
    assert 'business' in dir(a) and 'address' in dir(a)


# Generated at 2022-06-23 21:20:23.158975
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    m = Generic()
    assert isinstance(m.food, Food)

# Generated at 2022-06-23 21:20:28.878502
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    l = Generic().__dir__()
    expected = ['address', 'business', 'code', 'choice', 'clothing',
                'cryptographic', 'data', 'datetime', 'development',
                'file', 'food', 'hardware', 'internet', 'numbers',
                'path', 'payment', 'person', 'science', 'structure',
                'text', 'transport', 'unit_system']
    assert l == expected

# Generated at 2022-06-23 21:20:32.015697
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()
    assert isinstance(result, list)
    assert 'science' in result

# Generated at 2022-06-23 21:20:33.662497
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person(), Person)

# Generated at 2022-06-23 21:20:38.435324
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import mimesis.providers.development.software as software
    import mimesis.providers.development.databases as database

    g = Generic()
    assert g.python is None
    g.add_providers(software.Python, database.MySQL)
    assert not g.python is None

# Generated at 2022-06-23 21:20:44.177654
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert isinstance(generic.person(), Person) is True
    assert isinstance(generic.address(), Address) is True
    assert isinstance(generic.datetime(), Datetime) is True
    assert isinstance(generic.business(), Business) is True
    assert isinstance(generic.food(), Food) is True
    assert isinstance(generic.science(), Science) is True



# Generated at 2022-06-23 21:20:48.784367
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    def test_provider(BaseProvider):
        class TestProvider(BaseProvider):
            class Meta:
                name = "test_provider"
        return TestProvider

    generic = Generic("en")
    generic.add_provider(test_provider)
    assert hasattr(generic, "test_provider")


# Generated at 2022-06-23 21:20:52.064033
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
        def content(self): pass

    generic = Generic()
    generic.add_provider(TestProvider)
    assert generic.test_provider.content() is None


# Generated at 2022-06-23 21:21:00.591784
# Unit test for constructor of class Generic
def test_Generic():
    d = Generic()
    assert isinstance(d, Generic)
    assert isinstance(d.person, Person)
    assert isinstance(d.address, Address)
    assert isinstance(d.datetime, Datetime)
    assert isinstance(d.business, Business)
    assert isinstance(d.text, Text)
    assert isinstance(d.food, Food)
    assert isinstance(d.science, Science)
    assert isinstance(d.transport, Transport)
    assert isinstance(d.code, Code)
    assert isinstance(d.unit_system, UnitSystem)
    assert isinstance(d.file, File)
    assert isinstance(d.numbers, Numbers)
    assert isinstance(d.development, Development)
    assert isinstance(d.hardware, Hardware)

# Generated at 2022-06-23 21:21:03.108926
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic("en")
    prov = gen.add_provider(Text)
    assert prov.text.__class__.__name__ == "Text"

# Generated at 2022-06-23 21:21:10.613220
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def method(self):
            return "Called method of MyProvider() class"

    generic = Generic()
    generic.add_provider(MyProvider)
    assert generic.myprovider.method() == "Called method of MyProvider() class"


# Generated at 2022-06-23 21:21:20.825503
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    dir_generic = dir(Generic())
    assert ('__class__' in dir_generic)
    assert ('__doc__' in dir_generic)
    assert ('__init__' in dir_generic)
    assert ('__module__' in dir_generic)
    assert ('__dict__' in dir_generic)
    assert ('__weakref__' in dir_generic)
    assert ('add_provider' in dir_generic)
    assert ('add_providers' in dir_generic)
    assert ('choice' in dir_generic)
    assert ('code' in dir_generic)
    assert ('clothing' in dir_generic)
    assert ('cryptographic' in dir_generic)
    assert ('development' in dir_generic)
    assert ('file' in dir_generic)
    assert ('hardware' in dir_generic)

# Generated at 2022-06-23 21:21:26.823363
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    generic = Generic()
    class Test(BaseProvider):
        def __init__(self, language_code: str = None):
            super().__init__(language_code)

        def foo(self, *args):
            return 'bar'

    generic.add_provider(Test)
    assert generic.test.foo() == 'bar'



# Generated at 2022-06-23 21:21:33.404216
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.Faker import Faker  # pylint: disable=E0611

    gen = Generic('ru')
    assert not hasattr(gen, 'faker')
    gen.add_provider(Faker)
    assert hasattr(gen, 'faker')
    assert isinstance(gen.faker, Faker)
    assert gen.faker.locale == 'ru'

# Generated at 2022-06-23 21:21:35.040626
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Text)

# Generated at 2022-06-23 21:21:38.202847
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    for k in obj.__dir__():
        if k.startswith('_'):
            k = k.replace('_', '', 1)
        try:
            getattr(obj, k)
        except AttributeError as error:
            print(f'Attribute {k} not found ({error})')
    print(obj.__dict__)


# Generated at 2022-06-23 21:21:40.049201
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address



# Generated at 2022-06-23 21:21:48.696054
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():   # noqa: WPS600
    """Unit test for method Generic.__dir__."""
    assert Generic().__dir__() == [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

# Generated at 2022-06-23 21:21:51.603744
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider() of class Generic."""
    provider = Generic()
    provider.add_provider(Person)



# Generated at 2022-06-23 21:21:57.357651
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test Generic add provider by adding only one."""
    gen = Generic()
    class MyProvider(BaseProvider):
        class Meta:
            name = 'first_new'

        def __call__(self):
            return 'hello'

    gen.add_provider(MyProvider)
    assert hasattr(gen, 'first_new')
    assert gen.first_new() == 'hello'



# Generated at 2022-06-23 21:22:05.220056
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    foo = Generic()
    assert len(foo.__dir__()) == 37
    assert '__name__' not in foo.__dir__()
    assert '__doc__' not in foo.__dir__()
    assert '__class__' not in foo.__dir__()
    assert '__module__' not in foo.__dir__()
    assert '__dict__' not in foo.__dir__()



# Generated at 2022-06-23 21:22:17.157587
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    obj.__getattr__('person')
    assert isinstance(obj.person, Person)
    obj.__getattr__('address')
    assert isinstance(obj.address, Address)
    obj.__getattr__('datetime')
    assert isinstance(obj.datetime, Datetime)
    obj.__getattr__('business')
    assert isinstance(obj.business, Business)
    obj.__getattr__('text')
    assert isinstance(obj.text, Text)
    obj.__getattr__('food')
    assert isinstance(obj.food, Food)
    obj.__getattr__('science')
    assert isinstance(obj.science, Science)
    assert isinstance(obj.transport, Transport)
    assert isinstance(obj.code, Code)
    assert isinstance

# Generated at 2022-06-23 21:22:22.066063
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(repr(generic), str)
    assert isinstance(str(generic), str)
    assert len(generic.seed) == 16
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)

# Generated at 2022-06-23 21:22:24.867519
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    try:
        gen.add_providers(Person, Address)
        assert True
    except:
        assert False

# Generated at 2022-06-23 21:22:30.989217
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.financial import Financial
    from mimesis.providers.geography import Geography
    from mimesis.providers.process import Process

    generic = Generic('pl')
    generic.add_provider(Financial)
    generic.add_provider(Geography)
    generic.add_provider(Process)

    assert isinstance(generic.financial, Financial)
    assert isinstance(generic.geography, Geography)
    assert isinstance(generic.process, Process)

# Generated at 2022-06-23 21:22:37.192225
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.business()
    assert g.address()
    assert g.person()
    assert g.food()
    assert g.science()
    assert g.development()
    assert g.clothing()
    assert g.numbers()
    assert g.path()
    assert g.unit_system()
    assert g.internet()
    assert g.file()
    assert g.cryptographic()

# Generated at 2022-06-23 21:22:45.020861
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.person.__class__.__name__ == 'Person'
    assert g.address.__class__.__name__ == 'Address'
    assert g.business.__class__.__name__ == 'Business'
    assert g.choice.__class__.__name__ == 'Choice'
    assert g.clothing.__class__.__name__ == 'Clothing'
    assert g.code.__class__.__name__ == 'Code'
    assert g.cryptographic.__class__.__name__ == 'Cryptographic'
    assert g.datetime.__class__.__name__ == 'Datetime'
    assert g.development.__class__.__name__ == 'Development'
    assert g.file.__class__.__name__ == 'File'
    assert g.food.__

# Generated at 2022-06-23 21:22:45.622381
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:22:47.290609
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person
    assert gen.address
    assert gen.datetime



# Generated at 2022-06-23 21:22:52.692603
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [Person, Address]
    obj = Generic()
    obj.add_providers(*providers)
    assert obj.person.name() == 'Erik'
    assert obj.address.address() == '4372 Spring St., Newburgh, PA 17105'

if __name__ == '__main__':
    pass

# Generated at 2022-06-23 21:22:55.573248
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = dir(g)
    assert len(result) == 44
    assert result[0] == 'person'
    assert 'male' in result
    assert result[-1] == 'units'

# Generated at 2022-06-23 21:22:56.750195
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)


# Generated at 2022-06-23 21:23:07.778573
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.development import Testing
    from mimesis.providers.hardware import Phone

    class CustomInt(BaseProvider):
        """Custom int provider."""

        class Meta:
            """Class for metadata."""

            name = 'customint'

        def custom_int(self) -> int:
            """Create a custom int.

            :return: Custom int.
            """
            return self.random.randint(0, 1000)

    g = Generic('en')
    g.add_providers(CustomInt, Testing, Phone)
    assert hasattr(g, 'customint')
    assert hasattr(g, 'testing')
    assert hasattr(g, 'phone')
    assert g.customint.custom_int() == g.custom_int()

# Generated at 2022-06-23 21:23:09.403019
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Custom)
    assert hasattr(generic, 'custom')
    assert isinstance(generic.custom, Custom)



# Generated at 2022-06-23 21:23:10.688309
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic('ru')
    assert obj.seed == 'ru'

# Generated at 2022-06-23 21:23:14.909024
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Generic(__dir__)."""
    g = Generic()
    assert 'address' in dir(g)
    assert 'business' in dir(g)
    assert 'text' in dir(g)
    assert 'person' in dir(g)
    assert 'datetime' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)

# Generated at 2022-06-23 21:23:16.345123
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    foo = Generic()
    bar = foo.person
    assert(isinstance(bar, Person))


# Generated at 2022-06-23 21:23:16.971146
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.full_name()



# Generated at 2022-06-23 21:23:23.434720
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():

    obj = Generic()
    obj.add_provider(Generic)

    assert 'generic' in dir(obj)
    assert 'name' in dir(obj)
    assert '__file__' not in dir(obj)

    # test that providers added with add_provider can be found in dir()
    class TestProvider(BaseProvider):
        """Test provider."""

        class Meta:
            """Class for metadata."""

            name = 'testprovider'

    obj.add_provider(TestProvider)
    assert 'testprovider' in dir(obj)

# Generated at 2022-06-23 21:23:30.225368
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Original = Generic()
    # Case without set language
    Original._person = 'Foo'
    person = Original.person
    assert person == 'Foo'
    # Case with set language
    Original = Generic(locale='ru')
    Original._person = ['Foo', 'Bar']
    person = Original.person
    assert person in Original._person

# Generated at 2022-06-23 21:23:32.880977
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g is not None
    assert isinstance(g, Generic)

# Unit tests for constructor of class Generic

# Generated at 2022-06-23 21:23:34.914537
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.seed == 123
    assert g.locale == 'en'

# Generated at 2022-06-23 21:23:40.729587
# Unit test for constructor of class Generic
def test_Generic():
    """Test constructor of class Generic"""
    generic = Generic(seed=313)
    providers = [generic.person, generic.address, generic.datetime, generic.business, generic.text, generic.food, generic.science, generic.transport, generic.code, generic.unit_system, generic.file, generic.numbers, generic.development, generic.hardware, generic.clothing, generic.internet, generic.path, generic.payment, generic.cryptographic, generic.structure, generic.choice]
    for p in providers:
        assert isinstance(p, BaseProvider)

test_Generic()

# Generated at 2022-06-23 21:23:43.086830
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic(seed=42)
    assert gen.provider == 'generic'
    assert gen.locale == 'en'
    assert gen.seed == 42

# Generated at 2022-06-23 21:23:47.285577
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from generic import Generic
    from mimesis.providers.geography import World
    from mimesis.providers.person import Avatar

    g = Generic()
    assert "World" not in dir(g)
    assert "Avatar" not in dir(g)

    g.add_providers(World, Avatar)
    assert "World" in dir(g)
    assert "Avatar" in dir(g)

# Generated at 2022-06-23 21:23:52.517384
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.units import UnitSystem
    gen = Generic()
    gen.add_providers(Numbers, UnitSystem)

    assert isinstance(gen.numbers, Numbers)
    assert isinstance(gen.unit_system, UnitSystem)

# Generated at 2022-06-23 21:24:03.099705
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import unittest
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.path import Path

# Generated at 2022-06-23 21:24:13.994216
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    expected = [
        'unit_system', 
        'numbers', 
        'person', 
        'science', 
        'address', 
        'choice', 
        'text', 
        'development', 
        'file', 
        'datetime', 
        'business', 
        'food', 
        'transport', 
        'code', 
        'hardware', 
        'clothing', 
        'internet', 
        'path', 
        'payment', 
        'cryptographic', 
        'structure'
    ]
    assert expected == Generic().__dir__()

# Generated at 2022-06-23 21:24:15.603837
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)



# Generated at 2022-06-23 21:24:21.988028
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseDataProvider):

        class Meta:
            name = 'custom_provider'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert 'custom_provider' in generic.__dir__()

    class CustomProviderWithoutMeta(BaseProvider):
        pass

    generic.add_provider(CustomProviderWithoutMeta)
    assert 'custom_provider_without_meta' in generic.__dir__()

# Generated at 2022-06-23 21:24:30.693662
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.structure import Structure
    from mimesis.providers.transport import Transport
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    from mimesis.providers.choice import Choice
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.file import File

# Generated at 2022-06-23 21:24:33.738706
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Generate a custom provider
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def foo(self) -> str:
            return 'bar'

    gen = Generic()
    # add_provider() custom provider
    gen.add_provider(CustomProvider)
    assert gen.test_provider.foo() == 'bar'



# Generated at 2022-06-23 21:24:36.624369
# Unit test for constructor of class Generic
def test_Generic():
    # Asserting the type of object
    assert isinstance(Generic(), Generic)

    # Asserting the value of seed attr
    assert Generic().seed == 1234

    # Asserting the functionality of seed attr
    assert Generic(seed=42).seed == 42

    # Asserting the functionality of use_cache attr
    assert Generic().use_cache == True

# Generated at 2022-06-23 21:24:44.094059
# Unit test for constructor of class Generic
def test_Generic():
    GEN = Generic('en')
    assert GEN._seed == 'en'
    assert GEN._locale == 'en'
    assert GEN._provider == 'en'
    assert GEN._person == Person
    assert GEN._text == Text
    assert GEN._food == Food
    assert GEN._science == Science
    assert GEN.transport.__class__ == Transport
    assert GEN.code.__class__ == Code
    assert GEN.unit_system.__class__ == UnitSystem
    assert GEN.file.__class__ == File
    assert GEN.numbers.__class__ == Numbers
    assert GEN.development.__class__ == Development
    assert GEN.hardware.__class__ == Hardware
    assert GEN.clothing.__class__ == Clothing
    assert GEN.internet.__class__ == Internet
    assert GEN.path.__class__ == Path


# Generated at 2022-06-23 21:24:47.866189
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    custom = Generic()
    custom.add_providers(Person, Address)
    assert custom.person
    assert custom.address
    custom.add_provider(Datetime)
    assert custom.datetime

# Generated at 2022-06-23 21:24:53.403128
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic.

    :return: None
    """
    gen = Generic()
    assert gen.__dir__() == ['choice', 'code', 'clothing', 'cryptographic', 'datetime', 'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'path', 'payment', 'person', 'science', 'transport', 'unit_system', 'add_provider', 'add_providers']

# Generated at 2022-06-23 21:24:58.785981
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add providers of class Generic()."""
    import mimesis.providers.currency
    obj = Generic()
    obj.add_providers(mimesis.providers.currency.Currency)
    assert obj.currency.code() == 'SOS'
    assert obj.currency.name() == 'Somali Shilling'
    assert obj.currency.symbol() == 'S'

# Generated at 2022-06-23 21:25:03.734393
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.address import Address

    attr = 'address'
    obj = Generic(locale='en')
    res = obj.__getattr__(attr)
    assert res is not None
    # assert isinstance(res, Address)



# Generated at 2022-06-23 21:25:10.674957
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.person
    generic.address
    generic.datetime
    generic.business
    generic.text
    generic.food
    generic.science
    generic.transport
    generic.code
    generic.unit_system
    generic.file
    generic.numbers
    generic.development
    generic.hardware
    generic.clothing
    generic.internet
    generic.path
    generic.payment
    generic.cryptographic
    generic.structure
    generic.choice
    assert len(generic.__dict__) == 27



# Generated at 2022-06-23 21:25:11.957223
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic( 'en')
    assert hasattr(g, 'person')

# Generated at 2022-06-23 21:25:17.373778
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    person = generic.person
    address = generic.address
    datetime = generic.datetime
    business = generic.business
    text = generic.text
    food = generic.food
    science = generic.science
    test = {
        person.full_name(): text.text(),
        address.city(): food.dish(),
        datetime.datetime(start=1, end=100): science.element(),
    }

    for k, v in test.items():
        assert k != v



# Generated at 2022-06-23 21:25:23.275852
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    class CustomProvider(BaseProvider):
        @classmethod
        def __name__(cls):
            return 'custom_provider'
        def method(self):
            return 'method'

    gen.add_providers(CustomProvider)
    assert hasattr(gen, 'custom_provider')
    assert gen.custom_provider.method() == 'method'

# Generated at 2022-06-23 21:25:29.789669
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        """Example custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'myprovider'

        def foo(self, a: str) -> str:
            """Example method.

            :param a: Some argument.
            :return: Argument.
            """
            return a

    gen = Generic()
    gen.add_provider(MyProvider)
    assert hasattr(gen, 'myprovider')
    assert hasattr(gen.myprovider, 'foo')
    assert gen.myprovider.foo('bar') == 'bar'



# Generated at 2022-06-23 21:25:32.649336
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert hasattr(generic, 'person')
    assert not hasattr(generic, '_person')


# Generated at 2022-06-23 21:25:37.293740
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Dummy(BaseProvider):
        class Meta:
            name = 'dummy'

    g = Generic()
    g.add_provider(Dummy)
    assert hasattr(g, 'dummy')



# Generated at 2022-06-23 21:25:44.863779
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # if we want to test add_provider method,
    # we need to create a class that subclasses BaseProvider,
    # and pass it to the add_provider method.
    class Test(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed)

        def test(self):
            return 'test'

    generic = Generic()
    # invoked the add_provider method, pass the above class.
    generic.add_provider(Test)

    # invoke the test method and print the results
    print(generic.test.test())
test_Generic_add_provider()



# Generated at 2022-06-23 21:25:52.312460
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=123456789)
    address_1 = g.address.address()
    address_2 = g.address.address()
    assert address_1 != address_2
    g._address = None
    g = Generic(seed=123456789)
    address_1 = g.address.address()
    g = Generic(seed=123456789)
    address_2 = g.address.address()
    assert address_1 == address_2

# Generated at 2022-06-23 21:25:54.279041
# Unit test for constructor of class Generic
def test_Generic():
    mechanics = Mechanics()
    assert mechanics.provider == 'generic'
    print('Test success!')



# Generated at 2022-06-23 21:25:56.095167
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    attribute = Generic()._person
    assert callable(attribute)
    assert attribute is Generic().person

# Generated at 2022-06-23 21:26:01.066611
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    module_path = 'mimesis.enums'
    class_name = 'Lorem'
    cls = getattr(__import__(module_path, fromlist=[class_name]), class_name)
    generic = Generic('en')
    generic.add_provider(cls)
    assert generic.lorem() == 'Lorem ipsum dolor sit amet'
    assert generic.lorem.words() == 'Lorem ipsum dolor sit amet consectetur'



# Generated at 2022-06-23 21:26:05.252936
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    assert len(dir(gen)) > 0
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'
    gen.add_providers(TestProvider)
    assert 'test' in dir(gen)

# Generated at 2022-06-23 21:26:08.500840
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [Person, Business]
    generic = Generic()
    generic.add_providers(*providers)

    assert generic.person
    assert generic.business


# Generated at 2022-06-23 21:26:11.147008
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g is not None , "Generic Object is not constructed"
    assert g.__dict__ is not None, "Generic dict is not constructed"
    assert len(g.__dict__)==0

# Generated at 2022-06-23 21:26:13.862726
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.name() == g.__getattr__('person').name()



# Generated at 2022-06-23 21:26:20.342201
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=1234)
    assert g.person
    assert g.datetime
    g2 = Generic(seed=1234)
    assert g2.person != g.person
    assert g.person.full_name() == "Kristopher Davis"
    assert g.datetime.range(start='01.01.2014', stop='01.01.2015') == '2014-05-01'

# Generated at 2022-06-23 21:26:25.616236
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    print(g.datetime.datetime(start=2015, end=2020))
    print(g.person.full_name())
    g.add_providers(Person, Address)
    print(g.datetime.datetime(start=2015, end=2020))
    print(g.person.full_name())
    print(g.address.city())


# Generated at 2022-06-23 21:26:32.545523
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # adding a custom provider to Generic
    class MyProvider(BaseProvider):
        class Meta:
            name = "myprovider"
        def myprovider(self):
            return "myprovider"

    g = Generic()
    g.add_provider(MyProvider)
    assert isinstance(g.myprovider, MyProvider)
    assert g.myprovider.myprovider() == "myprovider"


# Generated at 2022-06-23 21:26:33.940681
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert isinstance(gen, Generic)


# Generated at 2022-06-23 21:26:35.448080
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    pass

# Generated at 2022-06-23 21:26:40.972203
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()

    g.add_provider(Person)
    g.add_provider(Address)
    g.add_provider(Datetime)
    g.add_provider(Business)
    g.add_provider(Text)
    g.add_provider(Food)
    g.add_provider(Science)
    g.add_provider(Transport)
    g.add_provider(Code)
    g.add_provider(UnitSystem)
    g.add_provider(File)
    g.add_provider(Numbers)
    g.add_provider(Development)
    g.add_provider(Hardware)
    g.add_provider(Clothing)
    g.add_provider(Internet)
    g.add_provider(Path)
    g

# Generated at 2022-06-23 21:26:44.980935
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unittest for method __dir__.

    :return: None.
    """
    import inspect
    generic = Generic()
    for a in generic.__dir__():
        assert inspect.ismethod(getattr(generic, a))

# Generated at 2022-06-23 21:26:52.717748
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.person.full_name() in gen.name.full_name()
    assert gen.address.street_name() in gen.address.address()
    assert gen.business.company() in gen.business.company_name()
    assert gen.text.syllable() in gen.text.word()
    assert gen.food.spice() in gen.food.course()
    assert gen.transport.fuel() in gen.transport.vehicle()
    assert gen.unit_system.currency() in gen.unit_system.currency_code()
    assert gen.file.mime_type() in gen.file.extension()
    assert gen.code.cvv() in gen.code.isbn()
    assert gen.development.html_tag() in gen.development.programming_language()

# Generated at 2022-06-23 21:27:01.673197
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from random import random
    from mimesis.providers.base import BaseProvider

    class Extra(BaseProvider):

        class Meta:
            name = 'extra'

        def foo(self):
            return 'foo'

    class Extra2(BaseProvider):

        class Meta:
            name = 'extra2'

        def bar(self):
            return 'bar'

    generator = Generic(random())

    generator.add_provider(Extra)

    assert callable(generator.extra.foo)
    assert generator.extra.foo() == 'foo'

    assert callable(generator.extra2)
    generator.add_provider(Extra2)
    assert callable(generator.extra2.bar)
    assert generator.extra2.bar() == 'bar'

    with pytest.raises(TypeError):
        generator

# Generated at 2022-06-23 21:27:07.114703
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test attributes without underscores of Generic() class"""
    generic = Generic()
    attribute_list = [
        'person', 'address', 'datetime', 'business', 'text', 'food', 'science',
        'transport', 'code', 'unit_system', 'file', 'numbers', 'development',
        'hardware', 'clothing', 'internet', 'path', 'payment', 'cryptographic',
        'structure', 'choice'
    ]

    for attribute in attribute_list:
        assert hasattr(generic, attribute)

# Generated at 2022-06-23 21:27:17.875260
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')

    generic.food  # noqa
    assert generic.food is not None

    generic.person  # noqa
    assert isinstance(generic.person, Person)
    assert generic.person.__class__.__name__ == 'Person'

    generic.datetime  # noqa
    assert generic.datetime is not None

    generic.business  # noqa
    assert generic.business is not None

    generic.text  # noqa
    assert generic.text is not None

    generic.science  # noqa
    assert generic.science is not None

    generic.transport  # noqa
    assert generic.transport is not None

    generic.code  # noqa
    assert generic.code is not None

    generic.unit_system  # noqa
    assert generic.unit_system is not None



# Generated at 2022-06-23 21:27:23.579564
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    g = Generic()
    class NewProvider(BaseProvider):
        """Custom provider."""
        class Meta:
            """Class for metadata."""
            name = 'new_provider'
        def new_method(self):
            return 42
    g.add_provider(NewProvider)
    assert hasattr(g, 'new_provider')
    assert g.new_provider.new_method() == 42


# Generated at 2022-06-23 21:27:25.121934
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for __dir__ method."""
    g = Generic()
    assert isinstance(g.__dir__(), list)



# Generated at 2022-06-23 21:27:34.232261
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__.

    :return: result
    :rtype: bool
    """
    g = Generic()
    s = set(dir(g))

    expected_set = {'address',
                    'add_provider',
                    'add_providers',
                    'business',
                    'code',
                    'clothing',
                    'cryptographic',
                    'datetime',
                    'development',
                    'file',
                    'food',
                    'hardware',
                    'internet',
                    'numbers',
                    'path',
                    'person',
                    'payment',
                    'science',
                    'structure',
                    'text',
                    'transport',
                    'unit_system'}

    return s == expected_set

# Generated at 2022-06-23 21:27:36.790152
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Person, UnitSystem)
    assert isinstance(g.person, Person)
    assert isinstance(g.unit_system, UnitSystem)

# Generated at 2022-06-23 21:27:45.742725
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.file import File
    g = Generic()
    assert type(g.file) == File
    assert g.file.file_extension() == 'json'
    assert type(g.address) == Address
    assert g.address.street_name() == 'Ленина'
    assert type(g.datetime) == Datetime
    assert g.datetime.timestamp() == 1575004600
    assert type(g.business) == Business
    assert g.business.company_name() == 'Коперник'
    assert type(g.text) == Text
    assert g.text.word() == 'сложены'
    assert type(g.food) == Food

# Generated at 2022-06-23 21:27:47.594949
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=12345)
    assert g.person('en')
    assert g.address('en', 12345)

# Generated at 2022-06-23 21:27:59.862451
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__."""
    g = Generic()
    assert g.person.full_name() == 'Adana Marjorie'
    assert g.address.country() == 'Canada'
    assert g.datetime.date() == '16.06.1988'
    assert g.business.company() == 'Diaz, Rodriguez and Rodriguez'
    assert g.text.transliterate() == 'Pkvdyu wnq izfqnq'
    assert g.food.main_dish() == 'Buffalo wings'
    assert g.science.chemical_element() == 'Selen'
    assert g.transport.car() == 'Mitsubishi'
    assert g.code.imei() == '354719259679350'
    assert g.unit_system.weight() == '55.0 kg'

# Generated at 2022-06-23 21:28:02.840106
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test Generic.__getattr__(attrname)."""
    g = Generic()
    g.__getattr__('datetime')
    assert g.datetime is not None
    assert g.datetime._seed == g._seed

# Generated at 2022-06-23 21:28:14.259723
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.topology import Topology

    class MyNewProvider(BaseProvider):
        class Meta:
            name = 'my_new_provider'

        def new_provider(self) -> str:
            """Make a new provider to mimesis test.

            :return: str
            """
            return 'It works!'

    generic = Generic()
    generic.add_provider(MyNewProvider)
    assert generic.my_new_provider.new_provider() == 'It works!'
    assert generic.my_new_provider.new_provider() == 'It works!'
    generic.add_provider(Topology)
    assert generic.topology.ip_address() is not None
    generic.add_provider(Topology)



# Generated at 2022-06-23 21:28:21.451747
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic('ru')
    assert provider.person.full_name()
    assert provider.ru.business.company()
    assert provider.random.choice(['1', '2'])
    assert provider.datetime
    assert provider.datetime_date
    assert provider.datetime_time
    assert provider.datetime_datetime
    assert provider.address
    assert provider.business
    assert provider.text
    assert provider.food
    assert provider.science
    assert provider.transport
    assert provider.code
    assert provider.unit_system
    assert provider.file
    assert provider.numbers
    assert provider.development
    assert provider.hardware
    assert provider.clothing
    assert provider.internet
    assert provider.path
    assert provider.payment
    assert provider.cryptographic
    assert provider.structure

# Generated at 2022-06-23 21:28:31.226637
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('zh')
    assert gen.numbers.__class__.__name__ == 'Numbers'
    assert gen.code.__class__.__name__ == 'Code'
    assert gen.unit_system.__class__.__name__ == 'UnitSystem'
    assert gen.file.__class__.__name__ == 'File'
    assert gen.development.__class__.__name__ == 'Development'
    assert gen.hardware.__class__.__name__ == 'Hardware'
    assert gen.clothing.__class__.__name__ == 'Clothing'
    assert gen.internet.__class__.__name__ == 'Internet'
    assert gen.path.__class__.__name__ == 'Path'
    assert gen.payment.__class__.__name__ == 'Payment'
    assert gen

# Generated at 2022-06-23 21:28:40.464146
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_provider and add_providers of class Generic."""
    data = Generic()

    class Foo(BaseProvider):
        """Dummy class."""

        def foo(self):
            """Dummy method."""
            return 'foo'

    class Bar(BaseProvider):
        """Dummy class."""

        def bar(self):
            """Dummy method."""
            return 'bar'

    class Baz(BaseProvider):
        """Dummy class."""

        def baz(self):
            """Dummy method."""
            return 'baz'

    data.add_provider(Foo)
    data.add_provider(Bar)
    data.add_provider(Baz)
    assert data.foo.foo() == 'foo'
    assert data.bar.bar() == 'bar'
   

# Generated at 2022-06-23 21:28:51.520733
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    from mimesis.enums import Gender, PersonTitle

    class CustomProvider(BaseProvider):
        """Custom provider."""

        def custom_method(self) -> str:
            """Custom method."""
            return 'Success!'

    generic = Generic()
    generic.add_provider(CustomProvider)

    assert generic.custom_provider.custom_method() == 'Success!'

    generic.add_provider(Person)
    assert generic.person.full_name() == 'Tomas G. Ross'
    assert generic.person.full_name(gender=Gender.FEMALE) == 'Rebecca C. Ford'
    assert generic.person.full_name(title=PersonTitle.MADAM) == 'Madam Julia M. Burch'



# Generated at 2022-06-23 21:28:55.920033
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.language import Language

    dt = Datetime('ru')
    g = Generic('ru')
    g.add_provider(Datetime)
    g.add_provider(Language)

    assert g.datetime.timestamp() == dt.timestamp()
    assert g.language.word() == 'язык'



# Generated at 2022-06-23 21:29:04.214920
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert not hasattr(Generic, '_person')
    assert not hasattr(Generic, '_address')
    assert not hasattr(Generic, '_datetime')
    assert not hasattr(Generic, '_business')
    assert not hasattr(Generic, '_text')
    assert not hasattr(Generic, '_food')
    assert not hasattr(Generic, '_science')
    assert not hasattr(Generic, 'transport')
    assert not hasattr(Generic, 'code')
    assert not hasattr(Generic, 'unit_system')
    assert not hasattr(Generic, 'file')
    assert not hasattr(Generic, 'numbers')
    assert not hasattr(Generic, 'development')
    assert not hasattr(Generic, 'hardware')
    assert not hasattr(Generic, 'clothing')
    assert not hasattr

# Generated at 2022-06-23 21:29:06.077455
# Unit test for constructor of class Generic
def test_Generic():
    from generic import Generic
    print(Generic())
    assert Generic


# Generated at 2022-06-23 21:29:07.592785
# Unit test for constructor of class Generic
def test_Generic():
    mimesis = Generic('zh')
    assert mimesis


# Generated at 2022-06-23 21:29:12.205547
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert hasattr(g, 'business')
    assert hasattr(g, 'person')
    assert hasattr(g, 'food')
    assert hasattr(g, 'numbers')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'text')



# Generated at 2022-06-23 21:29:15.822555
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic.

    Should return a list of available providers.
    """
    gen = Generic()
    assert isinstance(gen.__dir__(), list)

# Generated at 2022-06-23 21:29:21.040268
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """
        Test for method self.add_providers of class Generic
    """

    from mimesis.providers.custom import CustomProvider
    from mimesis.providers.geo import Geo
    from mimesis.providers.test import TestData

    data = Generic()
    data.add_providers(CustomProvider, Geo, TestData)

    assert data.get_providers() == ['custom', 'geo', 'testdata']

# Generated at 2022-06-23 21:29:28.701813
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    for x in range(1000):
        g = Generic('ru')
        assert type(g.person.name()) == str
        assert type(g.business.company()) == str
        assert type(g.address.address()) == str
        assert type(g.datetime.date()) == str
        assert type(g.text.title()) == str
        assert type(g.food.protein()) == str
        assert type(g.transport.vehicle()) == str
        assert type(g.code.issn()) == str
        assert type(g.unit_system.mass()) == str

# Generated at 2022-06-23 21:29:31.623288
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic("ja")
    generic.business.company()
    generic.person.occupation()
    generic.internet.ip_address()
    generic.development.framework()

# Generated at 2022-06-23 21:29:40.816434
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.datetime.hijri import Hijri
    from mimesis.providers.datetime.julian import Julian
    from mimesis.providers.datetime.maya import Maya
    from mimesis.providers.datetime.timestamp import Timestamp
    from mimesis.providers.internet import Internet
    
    unit = Generic()
    unit.add_providers(Hijri, Julian, Maya, Timestamp, Internet)

    unit.julian.date()
    unit.hijri.date()
    unit.maya.date()
    unit.timestamp.timestamp()
    unit.internet.url()