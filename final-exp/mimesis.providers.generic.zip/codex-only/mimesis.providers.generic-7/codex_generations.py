

# Generated at 2022-06-23 21:19:51.676487
# Unit test for constructor of class Generic
def test_Generic():
    mimesis = Generic('en')
    assert isinstance(mimesis.internet, Internet)
    assert isinstance(mimesis.address, Address)
    assert isinstance(mimesis.datetime, Datetime)
    assert isinstance(mimesis.business, Business)
    assert isinstance(mimesis.person, Person)
    assert isinstance(mimesis.text, Text)
    assert isinstance(mimesis.food, Food)
    assert isinstance(mimesis.science, Science)
    assert isinstance(mimesis.transport, Transport)
    assert isinstance(mimesis.code, Code)
    assert isinstance(mimesis.unit_system, UnitSystem)
    assert isinstance(mimesis.file, File)
    assert isinstance(mimesis.numbers, Numbers)


# Generated at 2022-06-23 21:19:54.142724
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person.full_name() in g.person._data['en']['full_name']



# Generated at 2022-06-23 21:19:58.277689
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=123)
    assert generic._address.address() == '9041 New Castle Pass'



# Generated at 2022-06-23 21:20:07.776562
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.science import Science
    from mimesis.providers import Science, Internet as web

    class Hello(Person):
        class Meta:
            pass
    hello = Hello('en')
    print(hello.full_name())

    class Internet(Internet):
        class Meta:
            pass

    internet = Internet('en')
    print(internet.ipv4())

    class Science(Science):
        class Meta:
            pass

    science = Science('en')
    print(science.chemical_element())

    provider = Generic()

    provider.add_providers(Hello, Internet, Science)
    print(provider.hello.full_name())
   

# Generated at 2022-06-23 21:20:11.101799
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    print("test Generic_add_providers")
    gen = Generic()
    if len(gen.__dict__) != 0:
        raise Exception("Error test_Generic_add_providers")

# Generated at 2022-06-23 21:20:12.703937
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert Generic().__dir__() is not None


# Generated at 2022-06-23 21:20:13.504977
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    print(dir(Generic()))

# Generated at 2022-06-23 21:20:18.622688
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test class Generic."""
    mock_provider = Generic(seed=10)
    p = mock_provider.person
    a = mock_provider.address
    d = mock_provider.datetime
    b = mock_provider.business
    t = mock_provider.text
    f = mock_provider.food
    s = mock_provider.science
    assert p.full_name() == 'Samantha Brown'
    assert p.age() == 60
    assert p.date_of_birth() == '1956-07-11'
    assert a.full_address() == '9172 Stone Creek Square, North ' \
                               'Myraham, NM 05633'
    assert a.zip_code() == '5633'
    assert a.city() == 'North Myraham'
    assert a

# Generated at 2022-06-23 21:20:25.201135
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Person, Address)
    assert g.person.name() != None
    assert g.address.city() != None
    assert g.person.name() == Person(seed=g.seed).name()
    assert g.address.city() == Address(seed=g.seed).city()
    assert g.person._seed == g.address._seed


# Generated at 2022-06-23 21:20:27.442011
# Unit test for constructor of class Generic
def test_Generic():
    """Testing the constructor of class Generic"""
    assert Generic().seed == 'I\'m so random'

# Generated at 2022-06-23 21:20:29.979309
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # we haven't going to test this method,
    # but we will test it
    class CustomProvider(BaseProvider):
        pass

    custom_provider = CustomProvider()

    generic = Generic()
    generic.add_provider(CustomProvider)
    custom_provider_object = getattr(generic, 'custom_provider')
    assert isinstance(custom_provider_object, CustomProvider)

# Generated at 2022-06-23 21:20:37.351783
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert sorted(dir(generic)) == ['address', 'add_provider', 'add_providers',
        'business', 'choice', 'code', 'clothing', 'cryptographic', 'datetime',
        'development', 'file', 'food', 'hardware', 'internet', 'numbers',
        'path', 'payment', 'person', 'science', 'structure', 'text', 'transport',
        'unit_system']

# Generated at 2022-06-23 21:20:43.001101
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    class Provider_A(BaseProvider):
        class Meta:
            name = 'provider_a'
    class Provider_B(BaseProvider):
        class Meta:
            name = 'provider_b'
    gen.add_providers(Provider_A, Provider_B)
    assert hasattr(gen, 'provider_a')
    assert hasattr(gen, 'provider_b')

# Generated at 2022-06-23 21:20:50.637620
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    print("\nMethod __dir__ of class Generic")

    list_providers = ['unit_system', 'code', 'file', 'numbers', 'development',
                      'hardware', 'clothing', 'internet', 'path', 'payment',
                      'cryptographic', 'structure', 'choice', 'address',
                      'datetime', 'person', 'business', 'text', 'food',
                      'science', 'transport']

    g = Generic()
    # print(dir(g))
    assert len(dir(g)) == len(list_providers)
    assert [i for i in dir(g) if i in list_providers] == list_providers


# Generated at 2022-06-23 21:20:51.933243
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=1)
    assert generic != None


# Generated at 2022-06-23 21:21:00.591676
# Unit test for constructor of class Generic
def test_Generic():

    def check_type(cls: Type[BaseProvider], instance: BaseDataProvider) -> None:
        """Check type.

        :param cls: Class object.
        :param instance: Instance of cls.
        :return: None
        """
        assert isinstance(instance, cls)

    generic = Generic()
    check_type(Person, generic.person)
    check_type(Datetime, generic.datetime)
    check_type(Address, generic.address)
    check_type(Business, generic.business)
    check_type(Text, generic.text)
    check_type(Food, generic.food)
    check_type(Science, generic.science)
    check_type(Transport, generic.transport)
    check_type(Code, generic.code)

# Generated at 2022-06-23 21:21:06.547721
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.transport import Transport
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.text import Text

    g = Generic()
    g.add_providers(Numbers, Transport, Clothing, Text)
    assert 'numbers' in dir(g) and 'transport' in dir(g)\
        and 'clothing' in dir(g) and 'text' in dir(g)

# Generated at 2022-06-23 21:21:09.395818
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    test_obj = Generic()
    assert test_obj.__dir__() == [
        'person', 'address', 'datetime', 'business', 'text', 'food', 'science',
        'transport', 'code', 'unit_system', 'file', 'numbers',
        'development', 'hardware', 'clothing', 'internet', 'path', 'payment',
        'cryptographic', 'structure', 'choice'
    ]

# Generated at 2022-06-23 21:21:11.241422
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic"""
    provider = Generic()
    assert provider.__dir__()

# Generated at 2022-06-23 21:21:14.039807
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Person, Address)
    assert g.person is not None
    assert g.address is not None



# Generated at 2022-06-23 21:21:17.138644
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print(">>> start test_Generic___getattr__ function.")
    g = Generic()
    print(g.person())
    print(g.business())
    print(">>> end test_Generic___getattr__ function.")


# Generated at 2022-06-23 21:21:18.061611
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.providers == None

# Generated at 2022-06-23 21:21:28.895139
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Method to test __getattr__ method of class Generic.

    Сhecks that the methods are called lazily.
    """
    g = Generic()

    assert '_person' not in g.__dict__.keys()
    p = g.person
    assert '_person' in g.__dict__.keys()
    assert g.__dict__['_person'] is p

    assert '_address' not in g.__dict__.keys()
    addr = g.address
    assert '_address' in g.__dict__.keys()
    assert g.__dict__['_address'] is addr

    assert '_datetime' not in g.__dict__.keys()
    dt = g.datetime
    assert '_datetime' in g.__dict__.keys()

# Generated at 2022-06-23 21:21:38.560127
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('zh')
    # print(generic.datetime.date())
    # print(generic.datetime.time())
    # print(generic.datetime.weekday())
    # print(generic.datetime.month())
    # print(generic.datetime.year())
    # print(generic.datetime.datetime())
    # print(generic.datetime.file_timestamp())
    # print(generic.datetime.timestamp())
    # print(generic.datetime.timezone())
    # print(generic.datetime.iso8601())
    # print(generic.datetime.precise_date())
    # print(generic.datetime.precise_date_time())
    # print(generic.datetime.precise_time())
    # print(generic.datetime.past_datetime())


# Generated at 2022-06-23 21:21:40.868427
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.food
    assert g.person
    assert g.address
    assert g.unit_system
    assert g.numbers
    assert g.file
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice

# Generated at 2022-06-23 21:21:48.868136
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Here we define a some custom classes
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def test_method(self) -> str:
            return 'test_method'

    class CustomProviderTwo(BaseProvider):
        class Meta:
            name = 'custom_provider_two'

    class CustomProviderThree(BaseProvider):
        def test_method(self) -> str:
            return 'test_method'

    class CustomProviderFour(BaseProvider):
        class Meta:
            name = 'custom_provider_four'

        def test_method(self) -> str:
            return 'test_method'

    class CustomProviderFive(BaseProvider):
        class Meta:
            name = 'custom_provider_five'

    # Here we create a instance of class Generic

# Generated at 2022-06-23 21:21:51.660627
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__ of class Generic()."""
    g = Generic()
    assert isinstance(g.__dir__(), list)


# Generated at 2022-06-23 21:22:00.267893
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider."""

    g = Generic()

    class A(BaseProvider):

        def foo(self):
            return 'foo'

        class Meta:
            name = 'a'

    class B(BaseProvider):

        def bar(self):
            return 'bar'

        class Meta:
            name = 'b'

    g.add_provider(A)
    g.add_provider(B)

    assert g.a.foo() == 'foo'
    assert g.a.foo() == 'foo'

    assert g.b.bar() == 'bar'
    assert g.b.bar() == 'bar'


# Generated at 2022-06-23 21:22:04.187379
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.__class__ == Generic


# Generated at 2022-06-23 21:22:16.437446
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    print("\n")
    print(Generic().add_provider.__doc__)
    print(Generic().add_provider(Science))
    print(Generic().add_provider(Business))
    #Exception
    print(Generic().add_provider(Datetime))
    print(Generic().add_provider(Numbers))
    print(Generic().add_provider(Internet))
    print(Generic().add_provider(Text))
    print(Generic().add_provider(Path))
    #Exception
    print(Generic().add_provider(UnitSystem))
    print(Generic().add_provider(Clothing))
    #Exception
    print(Generic().add_provider(File))
    print(Generic().add_provider(Hardware))
    print(Generic().add_provider(Code))

# Generated at 2022-06-23 21:22:19.428907
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic('ru').person.full_name()
    assert isinstance(a, str)


# Generated at 2022-06-23 21:22:30.642828
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    g.add_provider(Generic)
    assert inspect.isclass(g)
    assert issubclass(g, BaseDataProvider)
    assert 'add_provider' in dir(g)
    assert 'add_providers' in dir(g)
    assert 'choice' in dir(g)
    assert 'internet' in dir(g)
    assert 'payment' in dir(g)
    assert 'choice' in dir(g)
    assert g.choice().rand.get_seed() == 1
    assert g.internet().rand.get_seed() == 1
    assert g.payment().rand.get_seed() == 1
    assert g.choice().rand.get_seed() == 1
    g = Generic(seed=2, __type=True)
    assert inspect.isclass(g)

# Generated at 2022-06-23 21:22:32.825972
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic.

    Unit test for method __dir__ of class Generic
    """
    g = Generic()
    assert g.__dir__() != []

# Generated at 2022-06-23 21:22:42.916922
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    def test_set_of_attrs():
        c = Generic()

# Generated at 2022-06-23 21:22:51.365693
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_providers(CustomProvider, CustomProvider)
    assert hasattr(generic, 'custom_provider')
    assert generic.custom_provider.foo() == 'bar'

# Generated at 2022-06-23 21:22:59.759174
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'business')
    assert hasattr(g, 'text')
    assert hasattr(g, 'food')
    assert hasattr(g, 'science')
    assert hasattr(g, 'transport')
    assert hasattr(g, 'code')
    assert hasattr(g, 'unit_system')
    assert hasattr(g, 'file')
    assert hasattr(g, 'numbers')
    assert hasattr(g, 'development')
    assert hasattr(g, 'hardware')
    assert hasattr(g, 'clothing')
    assert hasattr(g, 'internet')
    assert hasattr(g, 'path')

# Generated at 2022-06-23 21:23:05.996118
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    for x in g.__dict__.values():
        assert isinstance(x, BaseProvider)
    # attrs = g.__dict__.keys()
    # for a in attrs:
    #     if a.startswith('_'):
    #         assert isinstance(
    #             g.__getattribute__(a[1:]), BaseProvider)



# Generated at 2022-06-23 21:23:12.319015
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # arrange
    properties = ['person', 'address', 'datetime', 'business', 'text', 'food', 'science', 'transport', 'code',
                  'unit_system', 'file', 'numbers', 'development', 'hardware', 'clothing', 'internet', 'path',
                  'payment', 'cryptographic', 'structure', 'choice']
    generic = Generic('en')

    # act
    data_providers = generic.__dir__()

    # assert
    assert data_providers == properties


# Generated at 2022-06-23 21:23:19.569979
# Unit test for constructor of class Generic
def test_Generic():
    # Seed None
    g = Generic()
    assert g.seed is None
    # Seed value
    g = Generic(seed=123)
    assert g.seed == 123
    # Set seed value
    g.seed = 'abc'
    assert g.seed == 'abc'
    # Providers
    assert isinstance(g.locales, list)
    assert isinstance(g.locale, str)
    assert isinstance(g.ip_address, str)
    assert isinstance(g.ip_network, str)
    # Properties
    assert isinstance(g.gender, str)
    assert isinstance(g.male, str)
    assert isinstance(g.female, str)
    assert isinstance(g.other, str)
    assert isinstance(g.gender_abbreviation, str)



# Generated at 2022-06-23 21:23:23.587099
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    p1 = type('P1', (BaseProvider, ), {
        'Meta': {'name': 'p1'},
        '__init__': lambda self: None
    })
    p2 = type('P2', (BaseProvider, ), {
        'Meta': {'name': 'p2'},
        '__init__': lambda self: None
    })
    Generic().add_providers(p1, p2)
    assert isinstance(Generic().p1, BaseProvider)
    assert isinstance(Generic().p2, BaseProvider)

# Generated at 2022-06-23 21:23:31.366739
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert {'person', 'address', 'datetime', 'business', 'text', 'food', 'science', 'transport', 'code', 'unit_system', 'file', 'numbers', 'development', 'hardware', 'clothing', 'internet', 'path', 'payment', 'cryptographic', 'structure', 'choice'} == set(dir(Generic()))
    assert {'name'} == set(dir(Generic.Meta))


# Generated at 2022-06-23 21:23:33.388167
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen is not None


if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:23:41.655494
# Unit test for constructor of class Generic
def test_Generic():
    assert(Generic().__class__.__name__)=='Generic'
    assert(Generic().person)
    assert(Generic().datetime)
    assert(Generic().business)
    assert(Generic().text)
    assert(Generic().food)
    assert(Generic().science)
    assert(Generic().transport)
    assert(Generic().code)
    assert(Generic().unit_system)
    assert(Generic().file)
    assert(Generic().numbers)
    assert(Generic().development)
    assert(Generic().hardware)
    assert(Generic().clothing)
    assert(Generic().internet)
    assert(Generic().path)
    assert(Generic().payment)
    assert(Generic().cryptographic)
    assert(Generic().structure)
    assert(Generic().choice)


# Generated at 2022-06-23 21:23:49.120491
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.custom_provider import CustomProvider
    from mimesis.providers.fake import Fake
    from mimesis.providers.sql import SQL

    g = Generic()
    default_providers = g.__dict__.keys()
    g.add_provider(CustomProvider)
    assert 'custom' in g.__dict__.keys()

    g.add_provider(Fake)
    assert 'fake' in g.__dict__.keys()

    g.add_provider(SQL)
    assert 'sql' in g.__dict__.keys()

    # Clean up: delete custom providers
    for provider in ['custom', 'fake', 'sql']:
        delattr(g, provider)

    # Check if default providers remain unchanged
    assert g.__dict__.keys() == default_prov

# Generated at 2022-06-23 21:23:52.737312
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic('en')

    class Provider(BaseProvider):
        pass

    g.add_provider(Provider)
    assert all(hasattr(g, attr) for attr in dir(g))

# Generated at 2022-06-23 21:23:53.719922
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert 'add_provider' in dir(Generic())

# Generated at 2022-06-23 21:24:04.003622
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert 'person' in g.__dir__()
    assert 'address' in g.__dir__()
    assert 'datetime' in g.__dir__()
    assert 'business' in g.__dir__()
    assert 'text' in g.__dir__()
    assert 'food' in g.__dir__()
    assert 'science' in g.__dir__()
    assert 'transport' in g.__dir__()
    assert 'code' in g.__dir__()
    assert 'unit_system' in g.__dir__()
    assert 'file' in g.__dir__()
    assert 'numbers' in g.__dir__()
    assert 'development' in g.__dir__()
    assert 'hardware' in g.__dir__()

# Generated at 2022-06-23 21:24:09.570166
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class CustomProvider(BaseProvider):
        pass

    custom_provider = CustomProvider()
    gen = Generic()
    gen.add_provider(CustomProvider)
    assert hasattr(gen, custom_provider.name)

# Generated at 2022-06-23 21:24:10.923169
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Person, Address)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)

# Generated at 2022-06-23 21:24:19.407428
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.providers.address import Address
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.name import Name
    from mimesis.providers.person import Person
    from mimesis.providers.transport import Transport

    g = Generic()
    address = g.address.__dir__()
    person = g.person.__dir__()
    name = g.name.__dir__()
    hardware = g.hardware.__dir__()
    development = g.development.__dir__()
    transport = g.transport.__dir__()
    assert g.__dir__() == (address +
                           person +
                           name +
                           development +
                           hardware +
                           transport)



# Generated at 2022-06-23 21:24:20.569662
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Clothing)
    assert generic.clothing.__class__.__name__ == 'Clothing'

# Generated at 2022-06-23 21:24:22.354519
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """  """
    test_provider = Generic()
    list_providers = []
    list_providers.append(BaseProvider)
    try:
        test_provider.add_providers(*list_providers)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:24:23.649639
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # TODO
    pass

# Generated at 2022-06-23 21:24:29.872503
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    data1 = g.personal.full_name()
    data2 = g.personal.full_name()
    assert data1 == data2
    assert not hasattr(g, 'personal')
    g.personal.full_name()
    new_data = g.person(seed=42).full_name()
    assert new_data == 'Сергей Петров'
    assert g.personal.full_name() == 'Сергей Петров'


# Generated at 2022-06-23 21:24:39.416660
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    assert g.person.full_name() == 'Алексей Чернышев'
    assert g.address.address() == 'Тюленевская улица, 18, а/я 01'
    assert g.person.full_name() == 'Анастасия Кропанина'
    assert g.person.full_name() == 'Розалия Ларина'
    assert g.person.full_name() == 'Софья Логунова'

# Generated at 2022-06-23 21:24:40.129496
# Unit test for constructor of class Generic
def test_Generic():
    x = Generic()
    assert x

# Generated at 2022-06-23 21:24:42.126978
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert(isinstance(g, Generic))

# Generated at 2022-06-23 21:24:53.209367
# Unit test for constructor of class Generic
def test_Generic():
    """Testing constructor of class Generic."""
    provider = Generic("en")
    assert provider._person.locale == "en"
    assert provider._address.locale == "en"
    assert provider._business.locale == "en"
    assert provider._text.locale == "en"
    assert provider._food.locale == "en"
    assert provider._science.locale == "en"
    assert provider.transport.locale == "en"
    assert provider.code.locale == "en"
    assert provider.unit_system.locale == "en"
    assert provider.file.locale == "en"
    assert provider.numbers.locale == "en"
    assert provider.development.locale == "en"
    assert provider.hardware.locale == "en"

# Generated at 2022-06-23 21:25:02.692739
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=42)
    assert g.food._seed == 42
    assert g.science._seed == 42
    assert g.transport._seed == 42
    assert g.code._seed == 42
    assert g.unit_system._seed == 42
    assert g.file._seed == 42
    assert g.numbers._seed == 42
    assert g.development._seed == 42
    assert g.hardware._seed == 42
    assert g.clothing._seed == 42
    assert g.internet._seed == 42
    assert g.path._seed == 42
    assert g.payment._seed == 42
    assert g.cryptographic._seed == 42
    assert g.structure._seed == 42
    assert g.choice._seed == 42

    # test __getattr__
    assert g.business._seed == 42
    assert g

# Generated at 2022-06-23 21:25:05.735527
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person as P
    new_provider = P('ro')
    generic_obj = Generic('ro')
    generic_obj.add_provider(new_provider)
    assert generic_obj.person._locale == 'ro'



# Generated at 2022-06-23 21:25:15.431143
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    '''This method is a unit test for class: Generic function: add_provider'''
    test_provider = Generic()

    # test exception for non-class object
    try:
        test_provider.add_provider("test")
    except TypeError:
        pass
    else:
        assert False

    # test exception for non-BaseProvider object
    try:
        test_provider.add_provider(Generic)
    except TypeError:
        pass
    else:
        assert False

    # test exception for non-BaseProvider object (can't import)
    try:
        test_provider.add_provider(object)
    except TypeError:
        pass
    else:
        assert False

    # test random method
    test_provider.add_provider(Person)
    assert test_provider

# Generated at 2022-06-23 21:25:19.084223
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert getattr(gen, 'science', None)
    assert not getattr(gen, 'test', None)
    try:
        gen.add_provider(BaseProvider)
        raise AssertionError
    except TypeError:
        pass
    gen.add_provider(Science)


# Generated at 2022-06-23 21:25:25.013304
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic(seed=123)

    #  Test for Person provider
    assert generic.person.full_name() == 'Alberto Wells'
    assert generic.person.username() == 'albertowellss'
    assert generic.person.email() == 'jacob_mcglynn@hotmail.com'
    assert generic.person.password() == 'bcyo7mHz'
    assert generic.person.birthday() == '25.01.0019'
    assert generic.person.birthday(century='XX') == '25.01.1999'
    assert generic.person.sex() == 'male'
    assert generic.person.sex(abbr=True) == 'm'
    assert generic.person.occupation() == 'software engineer'

# Generated at 2022-06-23 21:25:31.323610
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert callable(Generic().person)
    assert callable(Generic().address)
    assert callable(Generic().datetime)
    assert callable(Generic().business)
    assert callable(Generic().text)
    assert callable(Generic().food)
    assert callable(Generic().science)
    assert callable(Generic().transport)
    assert callable(Generic().code)
    assert callable(Generic().unit_system)
    assert callable(Generic().file)
    assert callable(Generic().numbers)
    assert callable(Generic().development)
    assert callable(Generic().hardware)
    assert callable(Generic().clothing)
    assert callable(Generic().internet)
    assert callable(Generic().path)
    assert callable(Generic().payment)
    assert callable(Generic().cryptographic)
   

# Generated at 2022-06-23 21:25:39.463046
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.name() == 'Rafael'
    assert g.person.full_name() == 'Rafael Molina'
    assert g.address.city() == 'Valdosta'
    assert g.address.street_address() == '1704 Marne Locks'
    assert g.datetime.datetime(year_start=2000)


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-23 21:25:43.666344
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.person.full_name() == "Анастасия Егоровна Иванова"
    assert gen.address.address() == "Ахтубинская, 7аб, 5"

# Generated at 2022-06-23 21:25:45.521201
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    data = Generic(seed=42)
    attrs = data.__dir__()
    assert len(attrs) == 32

# Generated at 2022-06-23 21:25:50.578979
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('ru')
    assert g.person.full_name() == 'Наталья Позднякова'
    assert g.choice.choose() == 'l'
    assert g.choice.choose(amount=2) == ['l', 'z']

# Generated at 2022-06-23 21:25:52.010478
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic is not None


# Generated at 2022-06-23 21:25:58.379938
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class ProviderA(BaseProvider):
        class Meta:
            name = 'provider_a'

    class ProviderB(BaseProvider):
        class Meta:
            name = 'provider_b'

    generic = Generic()
    generic.add_providers(ProviderA, ProviderB)

    assert len(generic.__dir__()) == 24
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.provider_a, ProviderA)
    assert isinstance(generic.provider_b, ProviderB)

# Generated at 2022-06-23 21:26:01.188661
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()

    person = gen.person
    address = gen.address
    datetime = gen.datetime
    business = gen.business
    text = gen.text
    food = gen.food
    science = gen.science

# Generated at 2022-06-23 21:26:11.878487
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'datetime' in dir(generic)
    assert 'business' in dir(generic)
    assert 'text' in dir(generic)
    assert 'food' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)
    assert 'clothing' in dir(generic)
    assert 'internet' in dir(generic)
    assert 'path' in dir(generic)

# Generated at 2022-06-23 21:26:22.917020
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    #
    g = Generic()
    g.add_provider(Business)
    g.add_provider(Address)
    g.business
    assert g.business
    assert g.address
    assert g.datetime
    assert g.text
    assert g.file
    assert g.payment
    assert g.person
    assert g.unit_system
    assert g.numbers
    assert g.path
    assert g.internet
    assert g.structure
    assert g.hardware
    assert g.choice
    assert g.science
    assert g.transport
    assert g.clothing
    assert g.development
    assert g.code
    assert g.cryptographic
    assert g.food
    assert g.__getattr__
    assert g.__getattr__
    assert g.__getattr__
   

# Generated at 2022-06-23 21:26:33.896547
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.internet, Internet)

# Generated at 2022-06-23 21:26:35.447925
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g is not None


# Generated at 2022-06-23 21:26:40.992668
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import random
    import math
    import string
    import datetime

    class MyProvider(BaseProvider):
        class Meta:
            name = 'my'

        @classmethod
        def my_method(cls):
            return random.randint(0, math.inf)

    class MySecondProvider(BaseProvider):
        class Meta:
            name = 'second'

        @classmethod
        def my_second_method(cls):
            return random.choice(string.ascii_letters)

    class MyThirdProvider(BaseProvider):
        class Meta:
            name = 'third'

        def my_third_method(self):
            return datetime.datetime.now()

    provider = Generic()
    provider.add_provider(MyProvider)
    provider.add_provider(MySecondProvider)

# Generated at 2022-06-23 21:26:50.862816
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic()
    assert isinstance(provider.person, Person)
    assert isinstance(provider.address, Address)
    assert isinstance(provider.business, Business)
    assert isinstance(provider.datetime, Datetime)
    assert isinstance(provider.text, Text)
    assert isinstance(provider.food, Food)
    assert isinstance(provider.science, Science)
    assert isinstance(provider.transport, Transport)
    assert isinstance(provider.code, Code)
    assert isinstance(provider.unit_system, UnitSystem)
    assert isinstance(provider.file, File)
    assert isinstance(provider.numbers, Numbers)
    assert isinstance(provider.development, Development)
    assert isinstance(provider.hardware, Hardware)

# Generated at 2022-06-23 21:27:00.216880
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=31337)
    assert g.seed == 31337
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.business, Business)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)

# Generated at 2022-06-23 21:27:01.414309
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:27:05.976508
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert set(Generic().__dir__()) == set([
        'numbers',
        'internet',
        'cryptographic',
        'development',
        'custom_provider',
        'datetime',
        'science',
        'file',
        'choice',
        'text',
        'code',
        'structure',
        'food',
        'address',
        'transport',
        'clothing',
        'business',
        'hardware',
        'payment',
        'unit_system',
        'path',
        'person',
    ])

# Generated at 2022-06-23 21:27:09.760629
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class P(BaseDataProvider):
        class Meta:
            name = 'test'

    generic = Generic(seed=123456789)
    generic.add_provider(P)
    result = generic.__dir__()
    assert 'test' in result

# Generated at 2022-06-23 21:27:15.015478
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert isinstance(g.person, Person)
    assert g.address
    assert isinstance(g.address, Address)
    assert g.datetime
    assert isinstance(g.datetime, Datetime)
    assert g.business
    assert isinstance(g.business, Business)
    assert g.text
    assert isinstance(g.text, Text)
    assert g.food
    assert isinstance(g.food, Food)
    assert g.science
    assert isinstance(g.science, Science)


# Generated at 2022-06-23 21:27:24.089343
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Use default locale and seed
    seed = 42
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.structure import Structure
    class ExtendedPerson(Person):
        """Class which extends Person."""

        class Meta:
            """Class for metadata."""

            name = 'extended_person'

        def get_password(self, *args) -> str:
            """Get a random password.

            :param args: Argumnents.
            :return: Password.
            """
            return 'mimesis'

    class ExtendedScience(Science):
        """Class which extends Science."""

        class Meta:
            """Class for metadata."""



# Generated at 2022-06-23 21:27:29.836157
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    p = Generic('ru')
    assert p.business.get_tin()
    assert isinstance(p.person, Person)
    assert isinstance(p.address, Address)
    assert isinstance(p.datetime, Datetime)
    assert isinstance(p.business, Business)
    assert isinstance(p.text, Text)
    assert isinstance(p.food, Food)
    assert isinstance(p.science, Science)
    assert isinstance(p.transport, Transport)
    assert isinstance(p.code, Code)
    assert isinstance(p.unit_system, UnitSystem)
    assert isinstance(p.file, File)
    assert isinstance(p.numbers, Numbers)
    assert isinstance(p.development, Development)
    assert isinstance(p.hardware, Hardware)
    assert isinstance

# Generated at 2022-06-23 21:27:35.350403
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def test(self):
            return 'hello world'

    obj = Generic()
    obj.add_provider(Test)

    assert isinstance(obj.test, Test)
    assert obj.test.test() == 'hello world'


# Generated at 2022-06-23 21:27:42.904963
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers."""
    g = Generic()
    g.add_providers(
        Person,
        Address,
        Datetime,
        Business,
        Text,
        Food,
        Science,
    )

    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)

# Generated at 2022-06-23 21:27:50.580152
# Unit test for constructor of class Generic
def test_Generic():
    # Given
    g = Generic()
    g.person
    g.address
    g.datetime
    g.business
    g.text
    g.food
    g.science
    g.transport
    g.code
    g.unit_system
    g.file
    g.numbers
    g.development
    g.hardware
    g.clothing
    g.internet
    g.path
    g.payment
    g.cryptographic
    g.structure
    g.choice
    # When
    # Then
    assert g
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system

# Generated at 2022-06-23 21:27:52.406365
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) > 20



# Generated at 2022-06-23 21:27:58.796275
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic(seed=0)
    set(g.__dir__()) == {
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'transport',
        'unit_system',
        'text',
    }

# Generated at 2022-06-23 21:28:03.521724
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import ProgramLanguage
    from mimesis.providers.schema import Schema
    generic = Generic('en')
    assert not hasattr(generic, 'program_language')
    assert not hasattr(generic, 'schema')
    generic.add_provider(ProgramLanguage)
    generic.add_provider(Schema)
    assert hasattr(generic, 'program_language')
    assert hasattr(generic, 'schema')


# Generated at 2022-06-23 21:28:07.148728
# Unit test for constructor of class Generic
def test_Generic():

    g = Generic()
    assert g

if __name__ == '__main__':
    g = Generic()
    print(g.choice())

# Generated at 2022-06-23 21:28:09.644225
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.misc import Misc

    generic = Generic()
    generic.add_provider(Misc)
    assert hasattr(generic, 'misc')



# Generated at 2022-06-23 21:28:18.576252
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic.
    """
    test_gen = Generic()

    # Add multiple providers
    test_gen.add_providers(Code)
    test_gen.add_providers(Code, UnitSystem)
    test_gen.add_providers(Code, UnitSystem, File)

    # Python string representation for object.
    assert isinstance(str(test_gen), str)

    # Values from added providers.
    assert hasattr(test_gen, 'code')
    assert hasattr(test_gen, 'unit_system')
    assert hasattr(test_gen, 'file')
    assert isinstance(test_gen.code, Code)
    assert isinstance(test_gen.unit_system, UnitSystem)
    assert isinstance(test_gen.file, File)
    # d

# Generated at 2022-06-23 21:28:20.675560
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # prepare
    pass
    # act
    generic = Generic()
    person = generic.person
    # assert
    assert isinstance(person, Person)
    assert person.get_gender()



# Generated at 2022-06-23 21:28:24.402587
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    custom_providers = [Person, Address, Datetime]
    g = Generic()
    g.add_providers(*custom_providers)
    assert len(dir(g)) == 7
    assert g.datetime is not None



# Generated at 2022-06-23 21:28:32.880522
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        pass
    from mimesis.builtins import UnitSystem
    from mimesis.builtins import Text
    from mimesis.builtins import Datetime
    from mimesis.builtins import Person
    from mimesis.builtins import Address
    from mimesis.builtins import Choice
    from mimesis.builtins import Food
    from mimesis.builtins import Structure
    from mimesis.builtins import Cryptographic
    from mimesis.builtins import Payment
    from mimesis.builtins import Path
    from mimesis.builtins import Internet
    from mimesis.builtins import Clothing
    from mimesis.builtins import Hardware
    from mimesis.builtins import Development
    from mimesis.builtins import Numbers

# Generated at 2022-06-23 21:28:38.865380
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    func_list = [
        'person', 'address', 'datetime',
        'business', 'text', 'food', 'science']
    for func_name in func_list:
        func = getattr(generic, func_name)
        assert isinstance(func, BaseDataProvider)
    try:
        getattr(generic, 'money')
    except AttributeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 21:28:45.827163
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # test return Generic object. This is first test
    # where it's not necessary to use assertEqual()
    generic = Generic('fr')
    assert isinstance(generic, Generic)
    # test return the attribute by name
    assert isinstance(generic.address, Address)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)

# Generated at 2022-06-23 21:28:49.546003
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.phone import Phone
    g = Generic()
    g.add_provider(Phone)
    assert g.phone.mask('+7 (9xx) xxx-xx-xx')


# Generated at 2022-06-23 21:28:58.360585
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Create a Generic instance
    g = Generic()
    # Test the result
    assert hasattr(g,'code')
    assert hasattr(g,'unit_system')
    assert hasattr(g,'file')
    assert hasattr(g,'numbers')
    assert hasattr(g,'development')
    assert hasattr(g,'hardware')
    assert hasattr(g,'clothing')
    assert hasattr(g,'internet')
    assert hasattr(g,'path')
    assert hasattr(g,'payment')
    assert hasattr(g,'cryptographic')
    assert hasattr(g,'structure')
    assert hasattr(g,'choice')
    assert hasattr(g,'transport')
    assert hasattr(g,'person')
    assert hasattr(g,'address')
    assert hasattr(g,'datetime')
   

# Generated at 2022-06-23 21:29:05.958759
# Unit test for constructor of class Generic
def test_Generic():
    print(Generic().person.full_name())
    print(Generic().datetime.date(start=2018, end=2019))
    print(Generic().text.capitalize('python 3'))
    print(Generic().food.fruit())
    print(Generic().numbers.between(10, 20))
    print(Generic().development.dependency())
    print(Generic().hardware.cpu())
    print(Generic().clothing.random_color())
    print(Generic().internet.url())
    print(Generic().path.file_name(ext='pdf'))
    print(Generic().payment.credit_card_number(card_type='visa'))
    print(Generic().cryptographic.hash_id())
    print(Generic().structure.dictionary())
    print(Generic().choice.boolean())


# Generated at 2022-06-23 21:29:17.977697
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business

    class CustomPerson(Person):
        """Custom provider for Person."""
        class Meta:
            """Class for metadata."""
            name = 'person_custom'

    class CustomAddress(Address):
        """Custom provider for Address."""
        class Meta:
            """Class for metadata."""
            name = 'address_custom'

    class CustomBusiness(Business):
        """Custom provider for Business."""
        class Meta:
            """Class for metadata."""
            name = 'business_custom'

    generic = Generic()
    generic.add_providers(CustomPerson, CustomAddress, CustomBusiness)
    assert hasattr(generic, 'person_custom')

# Generated at 2022-06-23 21:29:20.542906
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(g.__dir__())
    pass

# Generated at 2022-06-23 21:29:24.913568
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    _gen = Generic()
    _gen.add_provider(Person)
    assert isinstance(_gen.person, Person)

    _gen = Generic()
    _gen.add_provider(BaseProvider)
    assert _gen.base_provider is None



# Generated at 2022-06-23 21:29:34.595699
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Test get attribute without underscore
    generic = Generic('uk')
    assert generic.person.full_name() == "Александр Романов"
    assert generic.text.text() == "Не выходи из него на свет."
    assert generic.address.address() == "Лихачева Смирнова Петра 43 A, 63"
    assert generic.business.company() == 'Интервенция'
    assert generic.science.element() == 'йод'
    assert generic.science.element_symbol() == 'I'

# Generated at 2022-06-23 21:29:36.984635
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic"""
    gen = Generic('en')
    assert gen.choice.boolean(probability=0.5)

# Generated at 2022-06-23 21:29:46.866342
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print("%s\n" % g)
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None