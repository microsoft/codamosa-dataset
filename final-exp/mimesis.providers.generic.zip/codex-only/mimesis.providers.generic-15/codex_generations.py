

# Generated at 2022-06-23 21:19:40.401506
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    provider = Generic()
    data_provider = provider.__dir__()
    for _ in ['provider', 'internet']:
        assert _ in data_provider

# Generated at 2022-06-23 21:19:43.377675
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    # unit test for get list generate() calls of providers
    assert isinstance(generic.__dir__(), list)


# Generated at 2022-06-23 21:19:54.930585
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.person.full_name() == 'Marco Jones'
    assert isinstance(gen.person.height(), float)
    assert isinstance(gen.person.weight(), int)
    assert gen.address.postal_code() == '71593'
    assert gen.address.country() == 'United States'
    assert gen.address.country_code() == 'US'
    assert gen.address.city() == 'Jacksonville'
    assert gen.address.region() == 'Florida'
    assert gen.address.time_zone() == 'America/Detroit'
    assert gen.address.street_name() == 'Monroe Street'
    assert gen.address.street_suffix() == 'Street'
    assert gen.address.street_address() == '531 Monroe Street'

# Generated at 2022-06-23 21:20:01.003907
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Arrange
    gen = Generic()
    # Act
    gen.person
    gen.address
    gen.datetime
    gen.business
    gen.text
    gen.food
    gen.science
    gen.transport
    gen.code
    gen.unit_system
    gen.file
    gen.numbers
    gen.development
    gen.hardware
    gen.clothing
    gen.internet
    gen.path
    gen.payment
    gen.cryptographic
    gen.structure
    gen.choice
    # Assert
    assert gen.person is not None
    assert gen.address is not None
    assert gen.datetime is not None
    assert gen.business is not None
    assert gen.text is not None
    assert gen.food is not None
    assert gen.science is not None
   

# Generated at 2022-06-23 21:20:05.198827
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Payment)
    assert generic.payment.card_number() == generic.payment.card_number()
    try:
        generic.add_provider(Generic)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:20:06.692653
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.random is not None

#Unit test for method __getattr__

# Generated at 2022-06-23 21:20:09.092959
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert isinstance(Generic().__dir__(), list)


# Generated at 2022-06-23 21:20:15.645247
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
  from mimesis.providers.internet import Internet as i
  from mimesis.providers.address import Address as a
  from mimesis.generic import Generic
  i = i(seed=123)
  a = a(seed=123)
  g = Generic(seed=123)
  assert g.internet != i
  assert g.address != a
  g.add_provider(i)
  g.add_provider(a)
  assert g.internet == i
  assert g.address == a

# Generated at 2022-06-23 21:20:27.665255
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.person import Person
    g = Generic()
    assert g.person is not None
    assert isinstance(g.person, Person)

    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None

    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None

# Generated at 2022-06-23 21:20:32.815692
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test Generic.__getattr__.

    Without underscore
    """
    gen = Generic()
    assert gen.person
    assert gen.address
    assert gen.datetime
    assert gen.business
    assert gen.text
    assert gen.food
    assert gen.science
    assert gen.transport
    assert gen.code
    assert gen.unit_system
    assert gen.file
    assert gen.numbers
    assert gen.development
    assert gen.hardware
    assert gen.clothing
    assert gen.internet
    assert gen.path
    assert gen.payment
    assert gen.cryptographic
    assert gen.structure
    assert gen.choice

# Generated at 2022-06-23 21:20:43.938635
# Unit test for constructor of class Generic
def test_Generic():
    # Test for all providers
    g = Generic()

    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.science, Science)
    assert isinstance(g.file, File)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.internet, Internet)
    assert isinstance(g.path, Path)
    assert isinstance(g.payment, Payment)
    assert isinstance(g.cryptographic, Cryptographic)
    assert isinstance(g.structure, Structure)
    assert isinstance(g.choice, Choice)

    # Test for randomness
    g = Generic

# Generated at 2022-06-23 21:20:46.018904
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science


# Generated at 2022-06-23 21:20:49.255847
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        pass
    generic = Generic()
    generic.add_provider(Provider)
    assert isinstance(generic.provider, Provider)


# Generated at 2022-06-23 21:20:57.489549
# Unit test for constructor of class Generic
def test_Generic():
    # Seed = 42
    # Locale = 'en'
    gen = Generic(seed=42, locale='en')

    # Person()
    assert gen.person.full_name() == 'Dr. Wendy Little'
    assert gen.person.username() == 'carly'

    # Address()
    assert gen.address.city_name() == 'Manning'
    assert gen.address.country_code() == 'SE'
    assert gen.address.country_name() == 'Mozambique'

    # Datetime()
    assert gen.datetime.date(min_year=2010, max_year=2019) == '2016-06-08'
    assert gen.datetime.date(min_date='2019-05-01', max_date='2019-05-31') == '2019-05-17'
    assert gen.dat

# Generated at 2022-06-23 21:21:07.337044
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=12345)
    
    # Test Generic.person
    assert isinstance(g.person, Person)
    assert g.person.full_name() == 'Andrew Castillo'
    assert g.person.full_name('en') == 'Beyonce Holcomb'
    assert g.person.full_name('ru') == 'Юлия Дроздова'
    assert g.person.full_name('fr') == 'Michael Roach'
    
    # Test Generic.address
    assert isinstance(g.address, Address)
    assert g.address.state() == 'Maryland'
    assert g.address.state('en') == 'Kentucky'

# Generated at 2022-06-23 21:21:16.083386
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__."""
    def check_provider_name(g: Generic, provider: str) -> bool:
        """Check provider name.

        :param g: An instance of Generic.
        :param provider: Provider name.
        :return: True if provider's name is in dir
            of Generic object.
        """
        return provider in dir(g)

    g = Generic()
    assert check_provider_name(g, 'person')
    assert check_provider_name(g, 'address')
    assert check_provider_name(g, 'datetime')
    assert check_provider_name(g, 'business')
    assert check_provider_name(g, 'text')
    assert check_provider_name(g, 'food')

# Generated at 2022-06-23 21:21:21.453214
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.work import Work
    generic = Generic()
    assert type(generic.work) == str

    generic.add_provider(Work)
    assert type(generic.work) == Work

    generic.add_provider(Work)
    assert type(generic.work) == Work

    generic.add_provider(Generic)
    assert type(generic.generic) == Generic

    generic.add_provider(Generic)
    assert type(generic.generic) == Generic



# Generated at 2022-06-23 21:21:27.459926
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.date import SimpleDateTime
    from mimesis.providers.payment import Cryptocurrency

    gen = Generic()

    assert 'SimpleDatetime' not in dir(gen)
    assert 'cryptocurrency' not in dir(gen)

    gen.add_provider(SimpleDateTime)
    gen.add_provider(Cryptocurrency)

    assert 'SimpleDatetime' in dir(gen)
    assert 'cryptocurrency' in dir(gen)

# Generated at 2022-06-23 21:21:37.931902
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    fake = Generic()

    assert isinstance(fake.person, Person)
    assert isinstance(fake.address, Address)
    assert isinstance(fake.datetime, Datetime)
    assert isinstance(fake.business, Business)
    assert isinstance(fake.text, Text)
    assert isinstance(fake.food, Food)
    assert isinstance(fake.science, Science)
    assert isinstance(fake.transport, Transport)
    assert isinstance(fake.code, Code)
    assert isinstance(fake.unit_system, UnitSystem)
    assert isinstance(fake.file, File)
    assert isinstance(fake.numbers, Numbers)
    assert isinstance(fake.development, Development)
    assert isinstance(fake.hardware, Hardware)

# Generated at 2022-06-23 21:21:42.377034
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic,Generic)
    assert isinstance(generic.provider(),Generic)
    assert generic.seed == generic.seed
    assert generic.locale == 'en'

# Generated at 2022-06-23 21:21:49.758534
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    test = Generic()
    assert isinstance(test.choice, Choice)
    assert isinstance(test.numbers, Numbers)
    assert isinstance(test.unit_system, UnitSystem)
    assert isinstance(test.hardware, Hardware)
    assert isinstance(test.clothing, Clothing)
    assert isinstance(test.internet, Internet)
    assert isinstance(test.path, Path)
    assert isinstance(test.payment, Payment)
    assert isinstance(test.cryptographic, Cryptographic)
    assert isinstance(test.structure, Structure)


# Generated at 2022-06-23 21:21:58.867601
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import inspect
    import mimesis.builtins.geo
    import mimesis.builtins.statistics
    g = Generic('en')
    providers = [mimesis.builtins.geo.Geo,
                 mimesis.builtins.statistics.Statistics]
    g.add_providers(*providers)
    for provider in providers:
        name = provider.Meta.name
        assert hasattr(g, name) == True
        assert inspect.ismethod(getattr(g, name)) == True
    names = ['geo', 'statistics']
    for name in names:
        assert isinstance(getattr(g, name).__self__, provider)

# Generated at 2022-06-23 21:22:02.479895
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    dummy_class = type('DummyProvider', (BaseProvider,), {'Meta': {'name': 'Dummy'}})
    dummy_class = dummy_class(seed=123)
    dummy_class2 = type('DummyProvider2', (BaseProvider,), {'Meta': {'name': 'Dummy2'}})
    dummy_class2 = dummy_class2(seed=123)
    generic = Generic(seed = 123)
    generic.add_providers(dummy_class, dummy_class2)
    assert generic.dummy == dummy_class
    assert generic.dummy2 == dummy_class2


# Generated at 2022-06-23 21:22:06.326406
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):

        class Meta:
            name = 'custom'

        def __init__(self, seed: Any = None) -> None:
            super().__init__(seed=seed)
            self.seed = seed

        def get_provider(self) -> None:
            pass


    gen = Generic()
    gen.add_provider(CustomProvider)

    assert 'custom' in dir(gen)

# Generated at 2022-06-23 21:22:17.700329
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def foo(self):
            return 'Hello, world!'

    p = Generic()
    p.add_provider(Provider)
    assert p.provider.foo() == 'Hello, world!'

    class Bar(BaseProvider):
        class Meta:
            name = 'bar'

        def __init__(self, seed=None):
            super().__init__(seed=seed)

        def foo_bar(self):
            return 'Hello, world!'

    p.add_provider(Bar)
    assert p.bar.foo_bar() == 'Hello, world!'



# Generated at 2022-06-23 21:22:21.128150
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.datetime.datetime()
    gen.add_provider(SampleProvider)
    assert gen.sampleprovider.data()
    gen.add_providers(SampleProvider, SampleProvider)

# Generated at 2022-06-23 21:22:31.466548
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.localization import Localization
    from mimesis.providers.base import BaseProvider

    class FirstProvider(BaseProvider):
        """First custom provider."""
        pass

    class SecondProvider(BaseProvider):
        """Second custom provider."""
        class Meta(BaseProvider.Meta):
            """Meta class."""
            name = 'my_provider'

    generic = Generic('en')

    # Must be a subclass of BaseProvider
    try:
        generic.add_provider(Generic)
    except TypeError:
        pass

    # Must be a class
    try:
        generic.add_provider(FirstProvider())
    except TypeError:
        pass

    # Attribute with name of provider must be created
    generic.add_provider(FirstProvider)

# Generated at 2022-06-23 21:22:32.783625
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert isinstance(gen, Generic)


# Generated at 2022-06-23 21:22:39.452300
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Class Generic__dir__ test."""
    assert Generic().__dir__() == ['food', 'science', 'transport', 'code',
                                   'unit_system', 'file', 'numbers',
                                   'development', 'hardware', 'clothing',
                                   'internet', 'path', 'payment',
                                   'cryptographic', 'structure', 'choice',
                                   'provider']



# Generated at 2022-06-23 21:22:46.050456
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    m = Generic()
    assert isinstance(m.person, Person)
    assert isinstance(m.address, Address)
    assert isinstance(m.datetime, Datetime)
    assert isinstance(m.business, Business)
    assert isinstance(m.text, Text)
    assert isinstance(m.food, Food)
    assert isinstance(m.science, Science)
    assert isinstance(m.transport, Transport)
    assert isinstance(m.code, Code)
    assert isinstance(m.unit_system, UnitSystem)
    assert isinstance(m.file, File)
    assert isinstance(m.numbers, Numbers)
    assert isinstance(m.development, Development)
    assert isinstance(m.hardware, Hardware)
    assert isinstance(m.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:22:51.753917
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from tests.common import CustomProvider, CustomProvider2
    generic = Generic()
    generic.add_providers(CustomProvider, CustomProvider2)
    assert getattr(generic.custom_provider, 'name', None) == 'custom_provider'
    assert getattr(generic.custom_provider2, 'name', None) == 'custom_provider2'

# Generated at 2022-06-23 21:22:59.968464
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic().__dir__()

    assert len(gen) == 63
    assert 'person' in gen
    assert 'address' in gen
    assert 'datetime' in gen
    assert 'business' in gen
    assert 'text' in gen
    assert 'food' in gen
    assert 'science' in gen
    assert 'transport' in gen
    assert 'code' in gen
    assert 'unit_system' in gen
    assert 'file' in gen
    assert 'numbers' in gen
    assert 'development' in gen
    assert 'hardware' in gen
    assert 'clothing' in gen
    assert 'internet' in gen
    assert 'path' in gen
    assert 'payment' in gen
    assert 'cryptographic' in gen
    assert 'structure' in gen
    assert 'choice' in gen

# Generated at 2022-06-23 21:23:04.988664
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers of class Generic."""
    generic = Generic()
    generic.add_providers(Person, Address, Datetime)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)

# Generated at 2022-06-23 21:23:14.378308
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic.
    """
    class Custom(BaseProvider):
        """Custom class."""

        class Meta:
            """Meta info."""

            name = 'custom'

        def func(self) -> str:
            """Get something."""
            return 'Custom function'

    class OtherCustom(BaseProvider):
        """Custom class."""

        class Meta:
            """Meta info."""

            name = 'other_custom'

        def func(self) -> str:
            """Get something."""
            return 'Other custom function'

    test_generic = Generic('en')
    test_generic.add_provider(Custom)
    test_generic.add_provider(OtherCustom)
    test_generic.add_providers(Custom, OtherCustom)

# Generated at 2022-06-23 21:23:16.303214
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Tests generic __getattr__ method."""
    generic = Generic()
    assert generic._person is not None
    assert generic.person is not None

# Generated at 2022-06-23 21:23:18.530541
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic('en')
    gen.add_provider(Person)
    assert hasattr(gen, 'person')



# Generated at 2022-06-23 21:23:23.350331
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert not hasattr(g, 'person')
    assert hasattr(g, '_person')
    assert hasattr(g, '__getattr__')
    g.person
    assert hasattr(g, 'person')
    assert callable(g.person)
    # But the attribute with underscore is still exists
    assert hasattr(g, '_person')



# Generated at 2022-06-23 21:23:25.589013
# Unit test for constructor of class Generic
def test_Generic():
    mimesis = Generic(seed=4321)
    print(mimesis.code.imei())
    print(mimesis.text.password())

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:23:27.807795
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == len(set(g.__dir__()))

# Generated at 2022-06-23 21:23:32.199687
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.text import Text as CustomText
    custom_provider = Generic()
    custom_provider.add_provider(CustomText)
    assert len([x for x in custom_provider.__dict__ if x.startswith('_')]) == 5
    assert custom_provider.custom_text


# Generated at 2022-06-23 21:23:32.884866
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert dir(Generic())

# Generated at 2022-06-23 21:23:38.620688
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    attrs = [
        "person", "address", "datetime", "business", "text", "food",
        "science", "transport", "code", "unit_system", "file", "numbers",
        "development", "hardware", "clothing", "internet", "path", "payment",
        "cryptographic", "structure", "choice",
    ]
    for a in attrs:
        assert a in dir(g)

# Generated at 2022-06-23 21:23:43.558378
# Unit test for constructor of class Generic
def test_Generic():
    # 1. Constructor of Generic.
    # 1.1. With default arguments
    g1 = Generic()
    g2 = Generic('ru')
    assert isinstance(g1, Generic) and isinstance(g2, Generic)

    # 1.2. with arguments
    g3 = Generic(locale='en', seed=4)
    assert isinstance(g3, Generic)



# Generated at 2022-06-23 21:23:55.657039
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'customprovider'

        def custom_func(self) -> str:
            return self.random.choice(Gender.ALL)

    # Generic() object will have an attribute
    # called 'customprovider'
    generic = Generic()
    assert not hasattr(generic, 'customprovider')

    # Add provider
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'customprovider')

    # Add a new method to Generic() object
    custom_method = getattr(generic, 'customprovider')
    assert hasattr(custom_method, 'custom_func')
    custom_func = getattr(custom_method, 'custom_func')
    assert callable(custom_func)
   

# Generated at 2022-06-23 21:23:57.738829
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test that method add_provider of class Generic add new provider."""
    g = Generic()
    assert not hasattr(g, 'mobile')
    g.add_provider(Mobile)
    assert hasattr(g, 'mobile')



# Generated at 2022-06-23 21:24:02.639380
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):

        def __init__(self, seed: Any = None):
            super().__init__(seed)

        def __str__(self):
            return 'test'

    g = Generic()
    g.add_provider(CustomProvider)
    assert hasattr(g, 'custom_provider')
    assert str(g.custom_provider) == 'test'



# Generated at 2022-06-23 21:24:05.907535
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.example import Example
    from mimesis.providers.generic import Generic
    gen = Generic()
    gen.add_providers(Example, Example)
    assert hasattr(gen, 'example')
    assert hasattr(gen, 'example_2')



# Generated at 2022-06-23 21:24:13.703317
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers."""
    class ProviderA(BaseProvider):
        def foo(self):
            return None

    class ProviderB(BaseProvider):
        def bar(self):
            return None

    class ProviderC(BaseProvider):
        def baz(self):
            return None

    gen = Generic()
    gen.add_providers(
        ProviderA,
        ProviderB,
        ProviderC
    )
    assert hasattr(gen, 'ProviderA')
    assert hasattr(gen, 'ProviderB')
    assert hasattr(gen, 'ProviderC')

# Generated at 2022-06-23 21:24:14.252659
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:24:17.362974
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.science import Science
    gen = Generic('en')
    assert 'science' in dir(gen)
    assert 'science' not in dir(gen.add_providers(Science))

# Generated at 2022-06-23 21:24:28.083694
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.__class__.__name__ == 'Generic'
    assert hasattr(gen, '_address')
    assert hasattr(gen, '_business')
    assert hasattr(gen, '_datetime')
    assert hasattr(gen, '_food')
    assert hasattr(gen, '_person')
    assert hasattr(gen, '_science')
    assert hasattr(gen, '_text')
    assert hasattr(gen, 'numbers')
    assert hasattr(gen, 'file')
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'hardware')
    assert hasattr(gen, 'clothing')
    assert hasattr(gen, 'internet')
    assert hasattr(gen, 'path')
    assert hasattr(gen, 'payment')
   

# Generated at 2022-06-23 21:24:32.026141
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.provider
    g.person
    g.address
    g.business
    g.datetime
    g.food
    g.internet
    # g.computer
    # g.science

# Unit tests for method __dir__ of class Generic

# Generated at 2022-06-23 21:24:34.381250
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert obj.add_provider(Generic()) == None
    assert obj.add_providers(Generic()) == None

# Generated at 2022-06-23 21:24:35.672074
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert isinstance(gen, Generic)

# Generated at 2022-06-23 21:24:41.192654
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=1234)
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None
    assert g.structure is not None
    assert g.choice is not None


# Generated at 2022-06-23 21:24:43.941130
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

        def foo(self):
            return 'foo'

    generic = Generic()

    generic.add_provider(Provider)
    assert generic.provider.foo() == 'foo'

    delattr(generic, 'provider')

# Generated at 2022-06-23 21:24:51.426104
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from .address import Address
    from .business import Business
    from .clothing import Clothing
    from .code import Code
    from .cryptographic import Cryptographic
    from .date import Datetime
    from .development import Development
    from .food import Food
    from .hardware import Hardware
    from .internet import Internet
    from .numbers import Numbers
    from .payment import Payment
    from .person import Person
    from .science import Science
    from .structure import Structure
    from .text import Text
    from .transport import Transport
    from .units import UnitSystem
    from .file import File
    from .choice import Choice

    g = Generic()

    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)

# Generated at 2022-06-23 21:24:56.716922
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic()
    t1 = data.datetime
    t2 = data._datetime
    assert t1.__class__ == t2.__class__
    assert data.datetime.seed == data.seed
    assert data.datetime.seed == data._datetime.seed
    assert data.datetime.locale == t2.locale


# Generated at 2022-06-23 21:24:58.368038
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=12345)
    assert g.seed == 12345
    assert g.locale == 'en'

# Generated at 2022-06-23 21:25:02.174984
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    assert len(dir(g)) == 51

    # Add two providers to Generic() object
    from mimesis.providers.security import Security
    from mimesis.providers.vehicle import Vehicle
    g.add_providers(Security, Vehicle)
    assert len(dir(g)) == 53

# Generated at 2022-06-23 21:25:03.354874
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g is not None



# Generated at 2022-06-23 21:25:07.240539
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method."""
    g = Generic()

    class Provider(BaseProvider):
        """Class for provider."""

        class Meta:
            """Class for metadata."""

            name = 'example'

    g.add_provider(Provider)
    assert isinstance(g.example, Provider)

# Generated at 2022-06-23 21:25:12.774557
# Unit test for constructor of class Generic
def test_Generic():
    """Unit testing for the constructor of class Generic."""
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)

# Generated at 2022-06-23 21:25:18.278831
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.liub import Liub
    g = Generic()
    g.add_providers(Liub)
    assert 'liub' in dir(g)
    liub = getattr(g, 'liub')
    assert callable(liub.get_attitude)
    assert callable(liub.get_one_of_them)
    assert callable(liub.get_one_of_those)
    assert callable(liub.get_self)
    assert callable(liub.get_hongyun_status)


# Generated at 2022-06-23 21:25:19.968854
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == 27

# Generated at 2022-06-23 21:25:24.214746
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic.__getattr__."""
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person

    gen = Generic()
    assert isinstance(gen.text, Text)
    assert isinstance(gen.person, Person)

# Generated at 2022-06-23 21:25:30.628718
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Business)
    assert generic.business.company_name()
    assert generic.business.company_suffix()
    assert generic.business.brand()
    assert generic.company_name()
    assert generic.company_suffix()
    assert generic.brand()
    generic.add_providers(Business, Person)
    assert generic.business.company_name()
    assert generic.business.company_suffix()
    assert generic.business.brand()
    assert generic.company_name()
    assert generic.company_suffix()
    assert generic.brand()
    assert generic.birthday()
    assert generic.gender()
    assert generic.birthdate()
    assert generic.full_name()
    assert generic.name()
    assert generic.surname()
    assert generic.pat

# Generated at 2022-06-23 21:25:34.028437
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def custom_method(self):
            return self.random.randint(10, 100)

    gen = Generic(locale='ru')
    p1 = CustomProvider()
    gen.add_provider(CustomProvider)
    assert hasattr(gen, 'customprovider')
    assert gen.customprovider is not p1
    assert isinstance(gen.customprovider, CustomProvider)
    assert gen.customprovider.custom_method() == p1.custom_method()


# Generated at 2022-06-23 21:25:36.772079
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()

    assert generic is not None


# Generated at 2022-06-23 21:25:45.747800
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # test for an instance of class Generic

    g = Generic()
    assert set(g.__dir__()) == set(g.__class__.__dict__)

    # test for custom providers

    class ProviderOne(BaseProvider):
        class Meta:
            name = 'part_one'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def method_one(self): pass

    class ProviderTwo(BaseProvider):
        class Meta:
            name = 'part_two'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def method_two(self): pass


# Generated at 2022-06-23 21:25:52.364238
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.business, Business)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)


# Generated at 2022-06-23 21:26:01.505007
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic()
    assert repr(x.person) == repr(Person())
    assert repr(x.address) == repr(Address())
    assert repr(x.datetime) == repr(Datetime())
    assert repr(x.business) == repr(Business())
    assert repr(x.text) == repr(Text())
    assert repr(x.food) == repr(Food())
    assert repr(x.science) == repr(Science())
    assert repr(x.transport) == repr(Transport())
    assert repr(x.code) == repr(Code())
    assert repr(x.unit_system) == repr(UnitSystem())
    assert repr(x.file) == repr(File())
    assert repr(x.numbers) == repr(Numbers())
    assert repr(x.development) == repr(Development())
    assert repr

# Generated at 2022-06-23 21:26:11.110377
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def some_data(self) -> str:
            return 'some_data'

        class Meta:
            name = 'custom'

    g = Generic()

    try:
        # Assert raises error, because CustomProvider
        # is not a subclass of BaseProvider.
        g.add_provider(CustomProvider)
        assert False
    except TypeError:
        assert True

    class CustomProvider_2(BaseProvider):
        def some_data(self) -> str:
            return 'some_data'

    try:
        g.add_provider(CustomProvider_2)
        assert True
    except TypeError:
        assert False


test_Generic_add_provider()

# Generated at 2022-06-23 21:26:13.861699
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.__getattribute__('food')
    g.__getattribute__('__getattribute__')


# Generated at 2022-06-23 21:26:19.342131
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    generic = Generic()
    generic.add_provider(Provider)
    assert hasattr(generic, 'provider') is True


# Generated at 2022-06-23 21:26:24.783544
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()

    # if it's a class
    assert isinstance(g, Generic)
    # if the method __dir__ is implemented
    assert "__dir__" in dir(g)
    # if the method __dir__ is callable
    assert callable(getattr(g, "__dir__"))
    # return value is a list
    assert isinstance(g._Generic__dir__(), list)
    # check returned list
    for item in g._Generic__dir__():
        assert getattr(g, item, None) is not None

# Generated at 2022-06-23 21:26:26.051279
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    pass


# Generated at 2022-06-23 21:26:37.266680
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for __dir__ method of class Generic."""
    assert '__dir__' in dir(Generic)
    assert '__eq__' in dir(Generic)
    assert '__ge__' in dir(Generic)
    assert '__gt__' in dir(Generic)
    assert '__le__' in dir(Generic)
    assert '__lt__' in dir(Generic)
    assert '__ne__' in dir(Generic)
    assert '__new__' in dir(Generic)
    assert '__reduce__' in dir(Generic)
    assert '__reduce_ex__' in dir(Generic)
    assert '__repr__' in dir(Generic)
    assert '__setattr__' in dir(Generic)
    assert '__sizeof__' in dir(Generic)
    assert '__str__' in dir

# Generated at 2022-06-23 21:26:44.680216
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic()

    class TestProvider(BaseProvider):
        def __init__(self, seed: None = None):
            super().__init__(seed=seed)

        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'TEST METHOD'

    provider.add_provider(TestProvider)
    assert provider.test_provider.test_method() == 'TEST METHOD'


# Generated at 2022-06-23 21:26:52.579612
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for __dir__ of Generic() class."""
    dir_ = Generic().__dir__()

    person = Person().__dir__()
    address = Address().__dir__()
    datetime = Datetime().__dir__()
    business = Business().__dir__()
    text = Text().__dir__()
    food = Food().__dir__()
    science = Science().__dir__()
    transport = Transport().__dir__()
    code = Code().__dir__()
    unit_system = UnitSystem().__dir__()
    file = File().__dir__()
    numbers = Numbers().__dir__()
    development = Development().__dir__()
    hardware = Hardware().__dir__()
    clothing = Clothing().__dir__()
    internet = Internet().__dir__()
    path = Path().__dir__

# Generated at 2022-06-23 21:27:01.791293
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import inspect
    import re
    import mimesis
    Generic = mimesis.Generic()
    pattern = re.compile(r'^test_\w*')
    attributes = []
    inspect_ = inspect.getmembers(Generic)
    for attribute, _ in inspect_:
        if pattern.match(attribute):
            attributes.append(attribute)
    assert len(attributes) == 0
    class Test1(mimesis.BaseProvider):
        def _foo(self):
            pass
    class Test2(mimesis.BaseProvider):
        def _bar(self):
            pass
    Generic.add_providers(Test1, Test2)
    inspect_ = inspect.getmembers(Generic)
    for attribute, _ in inspect_:
        if pattern.match(attribute):
            attributes.append(attribute)

   

# Generated at 2022-06-23 21:27:09.395914
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert 'choice' in generic.__dir__()
    assert 'code' in generic.__dir__()
    assert 'datetime' in generic.__dir__()
    assert 'unit_system' in generic.__dir__()
    assert 'transport' in generic.__dir__()
    assert 'file' in generic.__dir__()
    assert 'numbers' in generic.__dir__()
    assert 'development' in generic.__dir__()
    assert 'hardware' in generic.__dir__()
    assert 'clothing' in generic.__dir__()
    assert 'internet' in generic.__dir__()
    assert 'path' in generic.__dir__()
    assert 'payment' in generic.__dir__()
    assert 'cryptographic' in generic.__dir__()

# Generated at 2022-06-23 21:27:19.776182
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen, 'Объект "Generic" не создан'
    assert gen.person, 'Не создан объект person'
    assert gen.transport, 'Не создан объект transport'
    assert gen.unit_system, 'Не создан объект unit_system'
    assert gen.file, 'Не создан объект file'
    assert gen.code, 'Не создан объект code'

# Generated at 2022-06-23 21:27:29.510706
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=0)
    file_mimesis = generic.file.file_name()  # type: str
    assert file_mimesis == 'config.xml'

    food_mimesis = generic.food.meat_product()  # type: str
    assert food_mimesis == 'Beef'

    path_mimesis = generic.path.unix_path()  # type: str
    assert path_mimesis == '/var/www/site/data/.file'

    structure_mimesis = generic.structure.composite_material()  # type: str
    assert structure_mimesis == 'Foam'

    choice_mimesis = generic.choice.element()  # type: str
    assert choice_mimesis == 'Hydrogen'

    text_mimesis = generic

# Generated at 2022-06-23 21:27:36.114731
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.test_method = lambda self: 'test'
    g = Generic(seed=1)
    g.add_provider(TestProvider)
    assert 'test_provider' in dir(g)


# Generated at 2022-06-23 21:27:40.884335
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.builtins import BrazilSpecProvider

    gen = Generic()
    assert gen.add_provider(BrazilSpecProvider) is None
    gen.add_providers(BrazilSpecProvider, BrazilSpecProvider)
    assert isinstance(gen.brazil, BrazilSpecProvider)
    assert isinstance(gen.brazil_spec, BrazilSpecProvider)

# Generated at 2022-06-23 21:27:42.362549
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    print(a.transport.vehicle())
    print(a.choice.make_choice([1,2,3]))

# Generated at 2022-06-23 21:27:44.710507
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    '''
    
    :return: 
    '''
    assert True


# Generated at 2022-06-23 21:27:47.790975
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person as CustomProvider
    g = Generic()
    g.add_provider(CustomProvider)
    g.add_provider(CustomProvider)
    result = isinstance(g.person, CustomProvider)
    assert result is True

# Generated at 2022-06-23 21:27:59.967000
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert hasattr(gen, 'person')
    assert gen.person.username() == 'michelle_26'
    assert gen.person.username(gender=gen.person.GENDER.FEMALE) == 'debra_cole'
    gen.seed(1000)
    assert gen.person.username() == 'lkpcv4'
    assert gen.person.username(gender=gen.person.GENDER.FEMALE) == 'opyr'
    gen.seed(10000)
    assert gen.person.username() == 'njwck8o'
    assert gen.person.username(gender=gen.person.GENDER.FEMALE) == 'nyf'
    gen.seed(100000)
    assert gen.person.username() == '7eig'

# Generated at 2022-06-23 21:28:02.792620
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for '__dir__' method."""
    gen_inst = Generic()
    assert 'name' not in gen_inst.__dir__()
    assert 'file' in gen_inst.__dir__()

# Generated at 2022-06-23 21:28:14.572665
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.__getattr__('person')

# Generated at 2022-06-23 21:28:19.288736
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Tests for method __getattr__ of class Generic."""
    g = Generic('en', seed=42)
    assert isinstance(g.business, Business)
    assert isinstance(g.address, Address)
    assert isinstance(g.person, Person)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)


# Generated at 2022-06-23 21:28:22.745243
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import pytest
    g = Generic()
    g.add_providers(Generic)
    assert Generic in dir(g)
    pytest.raises(TypeError, g.add_providers, Generic)

# Generated at 2022-06-23 21:28:25.642824
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person.name() == 'Сергей Сергеев'


# Generated at 2022-06-23 21:28:26.418892
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Generic()
    pass


# Generated at 2022-06-23 21:28:28.125979
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.address.__class__.__name__ == 'Address'



# Generated at 2022-06-23 21:28:31.493790
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class test_provider(BaseProvider):
        class Meta:
            name = 'test_provider'

    provider = Generic()
    provider.add_provider(test_provider)
    assert hasattr(provider, 'test_provider')


# Generated at 2022-06-23 21:28:35.701191
# Unit test for constructor of class Generic
def test_Generic():
    global _
    gen = Generic()
    _ = gen
    assert _.__dir__() == ['address', 'business', 'choice', 'code', 'clothing', 'cryptographic', 'datetime', 'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'path', 'payment', 'person', 'science', 'text', 'transport', 'unit_system']

# Generated at 2022-06-23 21:28:37.374336
# Unit test for constructor of class Generic
def test_Generic():

    generic_object = Generic()
    assert generic_object


# Generated at 2022-06-23 21:28:45.138653
# Unit test for method __dir__ of class Generic

# Generated at 2022-06-23 21:28:55.388835
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__."""
    g = Generic()
    assert '__init__' not in dir(g)
    assert 'meta' not in dir(g)
    assert 'add_provider' not in dir(g)
    assert 'add_providers' not in dir(g)
    assert 'generic' in dir(g)
    assert 'person' in dir(g)
    assert 'address' in dir(g)
    assert 'datetime' in dir(g)
    assert 'business' in dir(g)
    assert 'text' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)
    assert 'transport' in dir(g)
    assert 'code' in dir(g)
    assert 'unit_system' in dir(g)

# Generated at 2022-06-23 21:29:00.531170
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test adding a provider to a Generic object.
    """

    class MyProvider(BaseProvider):
        """A provider class."""

        class Meta:
            name = "myprovider"

        def my_method(self) -> Any:
            """Return my method."""
            return 1

    g = Generic()
    g.add_provider(MyProvider)

    assert g.myprovider.my_method() == 1


# Generated at 2022-06-23 21:29:04.215352
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    g = Generic()
    g.add_provider(Science)
    g.add_provider(Text)
    assert 'science' in g.__dir__()
    assert 'text' in g.__dir__()
    assert 'person' in g.__dir__()

# Generated at 2022-06-23 21:29:14.709394
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Generic and add_provider method in action."""
    provider = Generic()

    # add custom provider
    class NewProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'new'

        def new(self, *args, **kwargs) -> str:
            """Generate new data.

            :param args: List of custom arguments.
            :param kwargs: Dictionary of custom arguments.
            :return: New data.
            """
            return 'new'

    provider.add_provider(NewProvider)

    # access provider
    assert provider.new.new() == 'new'



# Generated at 2022-06-23 21:29:23.650026
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    cls = Generic()
    assert 'person' in dir(cls)
    assert 'address' in dir(cls)
    assert 'datetime' in dir(cls)
    assert 'business' in dir(cls)
    assert 'text' in dir(cls)
    assert 'food' in dir(cls)
    assert 'science' in dir(cls)
    assert 'transport' in dir(cls)
    assert 'code' in dir(cls)
    assert 'unit_system' in dir(cls)
    assert 'file' in dir(cls)
    assert 'numbers' in dir(cls)
    assert 'development' in dir(cls)
    assert 'hardware' in dir(cls)
    assert 'clothing' in dir(cls)
    assert 'internet'

# Generated at 2022-06-23 21:29:26.751037
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""

    assert isinstance(Generic().__dir__(), list)
    assert len(Generic().__dir__()) > 0


# Generated at 2022-06-23 21:29:31.086714
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers which add a lot of providers."""
    g = Generic()
    g.add_providers(Person, Address)
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)


# Generated at 2022-06-23 21:29:34.066218
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    generic = Generic()
    assert isinstance(generic.__dir__(), list)

# Generated at 2022-06-23 21:29:35.391218
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)


# Generated at 2022-06-23 21:29:36.792928
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen

# Generated at 2022-06-23 21:29:42.152799
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

    class Custom1(BaseProvider):  # noqa: W0105
        class Meta:
            name = 'custom1'

    generic = Generic()
    generic.add_providers(Custom, Custom1)
    assert hasattr(generic, 'custom')
    assert hasattr(generic, 'custom1')