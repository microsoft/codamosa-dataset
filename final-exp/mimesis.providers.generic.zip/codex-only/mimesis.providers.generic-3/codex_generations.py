

# Generated at 2022-06-23 21:19:50.341777
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    GENERIC = Generic()

    dir_list = GENERIC.__dir__()
    assert isinstance(dir_list, list)
    assert len(dir_list) > 0
    assert 'person' in dir_list
    assert 'address' in dir_list
    assert 'datetime' in dir_list
    assert 'business' in dir_list
    assert 'text' in dir_list
    assert 'food' in dir_list
    assert 'science' in dir_list
    assert 'transport' in dir_list
    assert 'code' in dir_list
    assert 'unit_system' in dir_list
    assert 'file' in dir_list
    assert 'numbers' in dir_list
    assert 'development' in dir_list
    assert 'hardware' in dir_list
    assert 'clothing' in dir

# Generated at 2022-06-23 21:19:56.415243
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """
    Test for method __getattr__ of class Generic.
    """
    from mimesis.enums import Gender
    g = Generic()
    # FIXME: This test may fail because of random
    assert g._food is None
    assert g.food is not None

    assert g._person is None
    assert g.person is not None
    assert g.person._gender is Gender.MALE
    assert g.person.gender() is Gender.MALE



# Generated at 2022-06-23 21:20:06.051236
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    attrname = 'data_provider'
    # The following line will fails, because it contains double
    # underscores:
    # attrname = '__data_provider'
    gen = obj.__getattr__(attrname)
    gen.__dict__['foo'] = 'bar'
    assert gen.__dict__['foo'] == 'bar'
    assert isinstance(gen, BaseProvider)
    assert isinstance(gen, Generic)
    assert gen.foo == 'bar'
    assert gen.__name__ == 'DataProvider'
    assert gen.__qualname__ == 'DataProvider'
    assert gen.__getattribute__('__name__') == 'DataProvider'
    assert gen.__getattribute__('__qualname__') == 'DataProvider'

# Generated at 2022-06-23 21:20:15.494061
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science as NewScience
    from mimesis.providers.science import Science as OldScience
    class NewProvider(BaseProvider):
        """New provider"""
        class Meta:
            """Metaclass"""
            name = 'new_provider'

        def __init__(self):
            super().__init__()

        def __getattr__(self, attrname):
            return self.true()

    g = Generic()
    ns = NewScience()
    g.add_provider(NewProvider)
    assert g.new_provider
    assert g.new_provider != ns


# Generated at 2022-06-23 21:20:27.617005
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    assert 'address' in obj.__dir__()
    assert 'business' in obj.__dir__()
    assert 'food' in obj.__dir__()
    assert 'science' in obj.__dir__()
    assert 'choice' in obj.__dir__()
    assert 'unit_system' in obj.__dir__()
    assert 'structure' in obj.__dir__()
    assert 'datetime' in obj.__dir__()
    assert 'hardware' in obj.__dir__()
    assert 'clothing' in obj.__dir__()
    assert 'payment' in obj.__dir__()
    assert 'path' in obj.__dir__()
    assert 'text' in obj.__dir__()
    assert 'transport' in obj.__dir__()

# Generated at 2022-06-23 21:20:28.596037
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert Generic

# Generated at 2022-06-23 21:20:32.015457
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    data_provider = Generic()
    data_provider.add_provider(CustomProvider)
    assert hasattr(data_provider, 'customprovider')


# Generated at 2022-06-23 21:20:33.409397
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_obj = Generic()
    test_obj.add_provider(ProviderTest)
    result = test_obj.test()
    assert result == 'test'


# Generated at 2022-06-23 21:20:39.420666
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic('en')
    assert generic.text().word(quantity=1)
    assert not generic.dummy()

    class Dummy(BaseProvider):
        class Meta:
            name = 'dummy'

        def dummy_method(self):
            return 'dummy'

    generic.add_providers(Dummy)
    assert generic.dummy().dummy_method() == 'dummy'

# Generated at 2022-06-23 21:20:45.414825
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def do(self):
            return 'It works!'

    from mimesis.providers import Datetime
    g = Generic('en')
    g.add_provider(CustomProvider)
    g.add_provider(Datetime)

    assert g.datetime.datetime()
    assert g.custom_provider.do() == 'It works!'

# Generated at 2022-06-23 21:20:54.918527
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    This simulator to test add_provider of class Generic
    """
    def create_a_custom_provider():
        """
        This function to create a custom provider
        """
        class CustomProvider(BaseProvider):
            """
            This is a custom provider
            """
            class Meta:
                """
                Name is gettext_lazy
                """
                name = 'custom_provider'
            def custom_method(self, param1: str, param2: str) -> str:
                """
                This is a method in custom provider
                """
                return param1 + param2
        return CustomProvider
    test = Generic()
    test.add_provider(create_a_custom_provider())
    test = Generic()
    test.add_providers(create_a_custom_provider())

# Generated at 2022-06-23 21:20:59.136691
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    exclude = BaseDataProvider().__dict__.keys()

    for a in g.__dict__:
        if a not in exclude:
            if a.startswith('_'):
                attribute = a.replace('_', '', 1)
            else:
                attribute = a
            assert callable(getattr(g, attribute))

# Generated at 2022-06-23 21:21:06.440380
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'
    
    class BadCustomProvider(object):
        name = 'bad_custom'
    
    g = Generic()
    g.add_provider(CustomProvider)
    try:
        g.add_provider(BadCustomProvider)
    except TypeError as e:
        assert str(e) == 'The provider must be a subclass of BaseProvider'
    assert hasattr(g, 'custom')
    assert g.custom.__class__.__name__ == 'CustomProvider'


# Generated at 2022-06-23 21:21:10.093624
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider1(BaseProvider):

        class Meta:
            name = 'provider1'

    class Provider2(BaseProvider):

        class Meta:
            name = 'provider2'

    class Provider3(BaseProvider):
        pass

    generic = Generic()
    generic.add_providers(Provider1, Provider2)
    assert hasattr(generic, 'provider1')
    assert hasattr(generic, 'provider2')
    assert not hasattr(generic, 'provider3')
    generic.add_provider(Provider3)
    assert hasattr(generic, 'provider3')

# Generated at 2022-06-23 21:21:15.871013
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(
        Datetime,
        # Just for checking.
        Science,
    )

    assert hasattr(g, 'datetime')
    assert not hasattr(g, '_datetime')

    assert hasattr(g, 'science')
    assert hasattr(g, '_science')

# Generated at 2022-06-23 21:21:17.178384
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)

# Generated at 2022-06-23 21:21:19.090472
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(g.person)
    assert id(g.person) is id(g.person)



# Generated at 2022-06-23 21:21:22.135526
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
  from mimesis.providers.random import Random

  generic = Generic()
  assert generic.random is None
  generic.add_providers(Random)
  assert generic.random is not None

# Generated at 2022-06-23 21:21:25.075900
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.__class__.__name__ == 'Generic'

if __name__ == "__main__":
    test_Generic()

# Generated at 2022-06-23 21:21:34.534413
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    gen = Generic()
    assert 'first_name' not in gen.__dict__

    class FirstName(BaseProvider):
        """Custom provider for first name."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        @property
        def first_name(self):
            return 'John'

    gen.add_provider(FirstName)
    assert 'first_name' in gen.__dict__


# Generated at 2022-06-23 21:21:39.742399
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    seed = 10
    o = Generic(seed=seed)
    assert o.person.full_name() == 'Boris Becker'
    assert o.address.building_number() == 'Cuatro'
    assert o.datetime.date(formats=['%d.%m.%Y']) == '31.12.1947'
    assert o.business.company() == 'Ocore Software'
    assert o.text.words() == 'Berkeley Aperture'
    assert o.food.meat() == 'churos'
    assert o.science.chemical_element() == 'Cromo'



# Generated at 2022-06-23 21:21:46.656240
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.phone import Phone
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'phone'

        def phone_number(self):
            raise NotImplementedError

    g = Generic()
    g.add_provider(Phone)
    assert hasattr(g, 'phone')
    g.add_provider(CustomProvider)
    try:
        assert g.phone._phone_mask()
    except:
        assert False

# Generated at 2022-06-23 21:21:48.039196
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic().__getattr__"""
    pass



# Generated at 2022-06-23 21:21:58.060464
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.generic import Generic
    from mimesis.providers.base import BaseProvider

    class TestProvider1(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self) -> str:
            return 'TestProvider1'

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self) -> str:
            return 'TestProvider2'

    gen = Generic()

    assert 'test' not in dir(gen)

    gen.add_providers(TestProvider1, TestProvider2)
    assert 'test' in dir(gen)
    assert gen.test.foo() == 'TestProvider2'

# Generated at 2022-06-23 21:22:06.284995
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic().__dir__().

    :return: None
    """
    generic = Generic()
    assert set(generic.__dir__()).issuperset(
        {'person', 'address', 'datetime', 'business',
         'text', 'food', 'science', 'transport', 'code',
         'unit_system', 'file', 'numbers', 'development',
         'hardware', 'clothing', 'internet', 'path',
         'payment', 'cryptographic', 'structure', 'choice'}
    )


# Generated at 2022-06-23 21:22:08.608327
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('ru')
    assert(generic.code.special_smiley() == '😜')

# Generated at 2022-06-23 21:22:12.091320
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert Generic().__dir__() is not None
    assert isinstance(Generic().__dir__(), list)
    assert len(Generic().__dir__()) > 0


# Generated at 2022-06-23 21:22:20.616165
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert hasattr(generic, "choice") is True
    assert hasattr(generic, "code") is True
    assert hasattr(generic, "clothing") is True
    assert hasattr(generic, "development") is True
    assert hasattr(generic, "file") is True
    assert hasattr(generic, "hardware") is True
    assert hasattr(generic, "internet") is True
    assert hasattr(generic, "numbers") is True
    assert hasattr(generic, "path") is True
    assert hasattr(generic, "payment") is True
    assert hasattr(generic, "cryptographic") is True
    assert hasattr(generic, "structure") is True
    assert hasattr(generic, "transport") is True

# Generated at 2022-06-23 21:22:27.954047
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self) -> None:
            self._data = ['foo', 'bar', 'baz']
        def custom(self) -> str:
            return self.random.choice(self._data)
    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.custom() in g.custom._data
    g.add_provider(Generic)
    assert g.generic is None


# Generated at 2022-06-23 21:22:39.744330
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic(seed=3)
    print (gen.address.address())
    print (gen.name.name())
    print (gen.date_time.time())
    print (gen.science.chemical_element())
    print (gen.transport.plane())
    print (gen.code.isbn())
    print (gen.unit_system.volume())
    print (gen.file.file_name(ext='mp3'))
    print (gen.numbers.decimal(min=0, max=100))
    print (gen.development.framework())
    print (gen.hardware.cpu())
    print (gen.clothing.clothing())
    print (gen.internet.url())
    print (gen.path.relative_path())
    print (gen.payment.credit_card_number())

# Generated at 2022-06-23 21:22:41.450245
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()

    # print('===test_Generic___dir__===')
    assert isinstance(gen.__dir__(), list)


# Generated at 2022-06-23 21:22:43.496789
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    value = 'ZH-CN'
    g = Generic(value)
    print('\ng.__getattr__(attrname)')
    print(g.address)
    print(g.business)

# Generated at 2022-06-23 21:22:55.316899
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic.__dir__.

    Test if in result of __dir__() method is a name of providers.
    """
    g = Generic()
    result = g.__dir__()
    assert 'person' in result
    assert 'address' in result
    assert 'datetime' in result
    assert 'business' in result
    assert 'text' in result
    assert 'food' in result
    assert 'science' in result
    assert 'transport' in result
    assert 'code' in result
    assert 'unit_system' in result
    assert 'file' in result
    assert 'numbers' in result
    assert 'development' in result
    assert 'hardware' in result
    assert 'clothing' in result
    assert 'internet' in result
    assert 'path' in result
    assert 'payment' in result


# Generated at 2022-06-23 21:23:05.996563
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')

    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'datetime' in dir(generic)
    assert 'business' in dir(generic)
    assert 'text' in dir(generic)
    assert 'food' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)
    assert 'clothing' in dir(generic)
    assert 'internet' in dir(generic)

# Generated at 2022-06-23 21:23:11.333785
# Unit test for constructor of class Generic
def test_Generic():
    """Test for the generic class."""
    a = Generic()
    print(a.science.chemical_element())
    print(a.food.dish())
    print(a.text.greeting())
    print(a.business.company())
    print(a.datetime.datetime().isoformat())
    print(a.person.full_name())
    print(a.address.address())
    print(a.transport.airport())
    print(a.code.ascii_letters())
    print(a.unit_system.mass())
    print(a.file.mime_type())
    print(a.numbers.between())
    print(a.development.library())
    print(a.hardware.gpu())
    print(a.clothing.brand_name())

# Generated at 2022-06-23 21:23:22.063214
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    x = Generic()
    x_dir = x.__dir__()
    # x_dir: ['add_provider', 'add_providers', 'address', 'business',
    # 'choice', 'clothing', 'code', 'cryptographic', 'development',
    # 'file', 'food', 'hardware', 'internet', 'numbers', 'payment',
    # 'path', 'person', 'science', 'structure', 'text',
    # 'transport', 'unit_system']
    # it's not ordered, so if you want to check this unit test
    # copy and paste the output of the function to the list above
    # and delete the rest

# Generated at 2022-06-23 21:23:33.445943
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    import pytest

    class MyProvider(BaseProvider):
        def foo(self):
            return 'foo'
        def bar(self):
            return 'bar'
            
    g = Generic()
    g.add_provider(MyProvider)
    
    # basic test
    assert callable(g.foo)
    assert g.foo() == 'foo'
    assert g.bar() == 'bar'

    # check that seed is passed
    g = Generic(seed=42)
    g.add_provider(MyProvider)
    assert g.foo() == 'foo'
    assert g.bar() == 'bar'
    g = Generic(seed=43)
    g.add_provider(MyProvider)
    assert g.foo() != 'foo'
    assert g.bar() != 'bar'

    # check that

# Generated at 2022-06-23 21:23:34.452625
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic.choice

# Generated at 2022-06-23 21:23:35.164550
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()


# Generated at 2022-06-23 21:23:39.618954
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        """Custom provider class."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Sample method."""
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)

    assert hasattr(generic, 'custom')
    assert isinstance(generic.custom, CustomProvider)



# Generated at 2022-06-23 21:23:44.697714
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers of class Generic."""
    from mimesis.providers.geography import Geography
    class TestProvider(BaseProvider):
        """Test provider class."""

        class Meta:
            """Name of class."""

            name = 'geography'
    generic = Generic()
    generic.add_providers(TestProvider, Geography)
    assert hasattr(generic, 'geography')


# Generated at 2022-06-23 21:23:52.955918
# Unit test for constructor of class Generic
def test_Generic():
    # Test constructor with explicit setting seed value
    gen = Generic('en', 'foo')

    assert gen._random.seed == 'foo'
    assert gen.locale == 'en'

    # Test constructor with not explicit setting seed value
    gen = Generic('en')

    assert gen._random.seed is not None
    assert gen.locale == 'en'

    # Test constructor with default locale
    gen = Generic()

    assert gen._random.seed is not None
    assert gen.locale == 'en'

# Generated at 2022-06-23 21:24:03.341059
# Unit test for constructor of class Generic
def test_Generic():
    t = Generic()
    assert isinstance(t.choice, Choice)
    assert isinstance(t.person, Person)
    assert isinstance(t.business, Business)
    assert isinstance(t.address, Address)
    assert isinstance(t.datetime, Datetime)
    assert isinstance(t.text, Text)
    assert isinstance(t.food, Food)
    assert isinstance(t.science, Science)
    assert isinstance(t.transport, Transport)
    assert isinstance(t.code, Code)
    assert isinstance(t.unit_system, UnitSystem)
    assert isinstance(t.file, File)
    assert isinstance(t.numbers, Numbers)
    assert isinstance(t.development, Development)
    assert isinstance(t.hardware, Hardware)

# Generated at 2022-06-23 21:24:06.601349
# Unit test for constructor of class Generic
def test_Generic():
    pass


# Generated at 2022-06-23 21:24:07.780071
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic()
    assert provider.first_name() == provider.first_name



# Generated at 2022-06-23 21:24:12.428285
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""


    class CustomProvider1(BaseProvider):
        """Custom provider 1."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider_1'

    class CustomProvider2(BaseProvider):
        """Custom provider 2."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider_2'

    custom_provider_1 = Generic().custom_provider_1
    custom_provider_2 = Generic().custom_provider_2

    assert isinstance(custom_provider_1, type(CustomProvider1))
    assert issubclass(custom_provider_1, CustomProvider1)
    assert isinstance(custom_provider_2, type(CustomProvider2))

# Generated at 2022-06-23 21:24:16.261685
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    assert len(generic.__dir__()) == 23
    generic.add_providers(Person, Address, Datetime)
    assert len(generic.__dir__()) == 26

# Generated at 2022-06-23 21:24:24.164607
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.exporters import DictExporter
    from mimesis.providers.datetime import Datetime

    class Custom(Datetime):
        class Meta:
            name = 'Custom'

        def foo(self) -> str:
            return 'bar'
        #add_provider()
    test = Generic(DictExporter)
    test.add_provider(Custom)
    assert test.custom.foo() == 'bar' 
    print("\ntest_Generic_add_provider() passed!")


# Generated at 2022-06-23 21:24:31.790901
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.data import ALL_LOCALES
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science

# Generated at 2022-06-23 21:24:32.880593
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert obj is not None

# Generated at 2022-06-23 21:24:36.348892
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    data = Generic().__dir__()
    assert data == [
        'address', 'business', 'code', 'choice', 'clothing', 'cryptographic',
        'datetime', 'development', 'file', 'food', 'hardware', 'internet',
        'numbers', 'payment', 'person', 'path', 'science', 'structure',
        'transport', 'unit_system', 'text',
    ]


# Generated at 2022-06-23 21:24:43.851613
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class A(BaseProvider):
        class Meta:
            name = 'a'

    class B(BaseProvider):
        class Meta:
            name = 'b'

    class C(BaseProvider):
        class Meta:
            name = 'c'

    g = Generic()
    g.add_provider(A)
    assert isinstance(g.a, A)

    g.add_provider(B)
    assert isinstance(g.b, B)

    g.add_provider(C)
    assert isinstance(g.c, C)

    # raise TypeError
    try:
        g.add_provider(1)
    except TypeError:
        assert True
    else:
        assert False

    try:
        g.add_provider('str')
    except TypeError:
        assert True


# Generated at 2022-06-23 21:24:50.305134
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.account import Account

    ac = Account(seed=1)
    class MyAccount(BaseProvider):
        class Meta:
            name = "account"
        def account(self) -> str:
            return ac.account()

    g = Generic(seed=1)
    g.add_providers(MyAccount)
    assert g.account.account() == ac.account()


# Generated at 2022-06-23 21:24:51.601491
# Unit test for constructor of class Generic
def test_Generic():
    print('test_Generic')
    g = Generic('en')
    print(g)

# Generated at 2022-06-23 21:24:55.976600
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    data = Generic()

    assert data.person()
    assert data.address()
    assert data.datetime()
    assert data.business()
    assert data.text()
    assert data.food()
    assert data.science()
    assert data.transport()
    assert data.code()
    assert data.unit_system()
    assert data.file()
    assert data.numbers()
    assert data.development()
    assert data.hardware()
    assert data.clothing()
    assert data.internet()
    assert data.path()
    assert data.payment()
    assert data.cryptographic()
    assert data.structure()
    assert data.choice()

# Generated at 2022-06-23 21:25:03.588657
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    G = Generic()
    G.add_provider(Person)
    assert G.choice.item(['Person'])=='Person'
    assert G.person.name()=='Lonnie D. Farrow'
    class MyCustomProvider(BaseProvider):
        def __init__(self, locale, seed=None):
            super().__init__(locale=locale, seed=seed)
        def say_hello(self):
            return 'hello'
    G.add_provider(MyCustomProvider)
    assert G.choice.item(['MyCustomProvider'])=='MyCustomProvider'
    assert G.MyCustomProvider.say_hello()=='hello'

# Generated at 2022-06-23 21:25:08.170439
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider of class Generic."""
    a = Generic(locale='ru')

    class NewProvider(BaseProvider):
        """Class for test."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            super().__init__(*args, **kwargs)

    a.add_provider(NewProvider)

    assert a.newprovider.__class__.__name__ == 'NewProvider'
    assert a.newprovider.locale == 'ru'



# Generated at 2022-06-23 21:25:11.230825
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic()
    assert hasattr(generic, 'person') is False
    generic.person
    assert hasattr(generic, 'person') is True


# Generated at 2022-06-23 21:25:12.819748
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    data = generic.person.full_name()
    assert data is not None

# Generated at 2022-06-23 21:25:15.700670
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    assert hasattr(g, 'numbers')
    g.add_providers(Players, Weapons)
    assert hasattr(g, 'players')
    assert hasattr(g, 'weapons')

# Generated at 2022-06-23 21:25:16.540021
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic


# Generated at 2022-06-23 21:25:26.554024
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    assert Generic().person
    assert Generic().address
    assert Generic().datetime
    assert Generic().business
    assert Generic().text
    assert Generic().food
    assert Generic().science
    assert Generic().transport
    assert Generic().code
    assert Generic().unit_system
    assert Generic().file
    assert Generic().numbers
    assert Generic().development
    assert Generic().hardware
    assert Generic().clothing
    assert Generic().internet
    assert Generic().path
    assert Generic().payment
    assert Generic().cryptographic
    assert Generic().structure
    assert Generic().choice
    print("All tests for method \"__getattr__\" of class Generic were passed!")


# Generated at 2022-06-23 21:25:28.157622
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person is not None
    assert g.food is not None
    assert g.science is not None

# Generated at 2022-06-23 21:25:38.951921
# Unit test for constructor of class Generic
def test_Generic():
    f = Generic()
    assert str(f) == '<Generic>'
    assert f.code is not None
    assert f.unit_system is not None
    assert f.file is not None
    assert f.numbers is not None
    assert f.development is not None
    assert f.hardware is not None
    assert f.clothing is not None
    assert f.internet is not None
    assert f.path is not None
    assert f.payment is not None
    assert f.cryptographic is not None
    assert f.structure is not None
    assert f.choice is not None
    assert f.transport is not None



# Generated at 2022-06-23 21:25:44.485657
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    def test_provider(BaseProvider):
        """Class which mimic custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'test_provider'

        def test_func(self):
            """This function is just for test."""
            pass

    generic = Generic()
    generic.add_providers(test_provider)
    assert 'test_provider' in dir(generic)

# Generated at 2022-06-23 21:25:47.102567
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en')
    print(g.__dir__())

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:25:51.282076
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    a = Generic()
    assert isinstance(a.__dir__(), list)
    assert 'person' in a.__dir__()
    assert 'patronymic' in a.__dir__()

# Generated at 2022-06-23 21:25:52.823706
# Unit test for constructor of class Generic
def test_Generic():
    expected_type = type(Generic())
    assert Generic().__class__ == expected_type

# Generated at 2022-06-23 21:26:01.816433
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()
    assert 'person' in result
    assert 'address' in result
    assert 'datetime' in result
    assert 'business' in result
    assert 'text' in result
    assert 'food' in result
    assert 'science' in result
    assert 'transport' in result
    assert 'code' in result
    assert 'unit_system' in result
    assert 'file' in result
    assert 'numbers' in result
    assert 'development' in result
    assert 'hardware' in result
    assert 'clothing' in result
    assert 'internet' in result
    assert 'path' in result
    assert 'payment' in result
    assert 'cryptographic' in result
    assert 'structure' in result
    assert 'choice' in result


# Generated at 2022-06-23 21:26:06.364675
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    attributes = generic.__dir__()
    expected_result = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]
    assert attributes == expected_result


# Generated at 2022-06-23 21:26:14.219595
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method __add_providers__."""
    from mimesis.providers.locales import Ukrainian
    custom_provider_a = CustomProviderA(locale='ru')
    custom_provider_b = CustomProviderB(locale='ru')
    custom_provider_c = CustomProviderC(locale='ru')
    generic = Generic(locale='ru')
    generic.add_providers(custom_provider_a, custom_provider_b, custom_provider_c)
    assert isinstance(generic.provider_a, CustomProviderA)
    assert isinstance(generic.provider_b, CustomProviderB)
    assert isinstance(generic.provider_c, CustomProviderC)
    assert generic.provider_a.locale == Ukrainian
    assert generic.provider_b.locale

# Generated at 2022-06-23 21:26:24.205373
# Unit test for constructor of class Generic
def test_Generic():
    result = Generic()
    assert 'person' in dir(result)
    assert 'address' in dir(result)
    assert 'datetime' in dir(result)
    assert 'business' in dir(result)
    assert 'text' in dir(result)
    assert 'food' in dir(result)
    assert 'science' in dir(result)
    assert 'transport' in dir(result)
    assert 'code' in dir(result)
    assert 'unit_system' in dir(result)
    assert 'file' in dir(result)
    assert 'numbers' in dir(result)
    assert 'development' in dir(result)
    assert 'hardware' in dir(result)
    assert 'clothing' in dir(result)
    assert 'internet' in dir(result)
    assert 'path' in dir(result)

# Generated at 2022-06-23 21:26:27.541373
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert not all(['_' + g.person.__class__.__name__ == g.person.__class__.__name__ for g in [g]])


# Generated at 2022-06-23 21:26:31.471280
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic(seed=123)

    print(obj.text)
    print(obj.datetime)


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-23 21:26:32.931948
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert isinstance(obj, Generic)

# Generated at 2022-06-23 21:26:34.426337
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers.
    """
    gen = Generic()
    gen.add_providers()
    gen.add_providers(Person, Address)
    gen.add_providers(BaseProvider)

# Generated at 2022-06-23 21:26:41.024272
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test adding custom providers to Generic() object.

    :return: None
    """
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider'

        def fruit(self) -> str:
            """Get fruit.

            :return: Fruit.
            """
            return self.data['fruits'].get_one()

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.fruit() in CustomProvider().data['fruits']



# Generated at 2022-06-23 21:26:44.980708
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    result = obj.__dir__()
    assert isinstance(result, list)
    assert len(result) > 0
    for i in result:
        assert isinstance(i, str)


# Generated at 2022-06-23 21:26:52.718165
# Unit test for constructor of class Generic
def test_Generic():
    # test for constructor of class Generic
    # with default arguments
    gen = Generic()
    assert isinstance(gen, Generic)

    # with arguments
    gen = Generic('en', 123)
    assert isinstance(gen, Generic)

    # with keyword arguments
    gen = Generic(locale='en', seed=123)
    assert isinstance(gen, Generic)

    # test for lazy initialization of attributes
    # with underscore
    person = gen._person
    assert issubclass(person, Person)

    # without underscore
    person = gen.person
    assert isinstance(person, Person)

    # test to add custom provider
    class CustomProvider(BaseProvider):
        """Custom dummy provider."""

        class Meta:
            """Metadata."""

            name = 'custom_provider'

    # via method add_provider
    gen

# Generated at 2022-06-23 21:26:56.114811
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    print(gen.person.full_name(gender='male'))
    print(gen.food.fruit())
    print(gen.address.address())

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:27:03.932460
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__ of class Generic."""
    g = Generic('en')
    result = g.__dir__()
    assert isinstance(result, list)
    assert 'person' in result # pylint: disable=W0106
    assert 'address' in result # pylint: disable=W0106
    assert 'datetime' in result # pylint: disable=W0106
    assert 'business' in result # pylint: disable=W0106
    assert 'text' in result # pylint: disable=W0106
    assert 'food' in result # pylint: disable=W0106
    assert 'science' in result # pylint: disable=W0106
    assert 'transport' in result # pylint: disable=W0106
    assert 'code' in result # pylint:

# Generated at 2022-06-23 21:27:09.368419
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic().__dir__()
    """
    generic = Generic()
    dir_g = dir(generic)
    print(dir_g)
    assert  isinstance(dir_g, list)
    assert  'key' in dir_g
    assert  'person' in dir_g
    assert  '_address' in dir_g
    assert  '_datetime' in dir_g
    assert  '_business' in dir_g
    assert  '_text' in dir_g
    assert  '_food' in dir_g
    assert  '_science' in dir_g


# Generated at 2022-06-23 21:27:10.819344
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic('en')
    generic.add_providers(Person, Address, Business)

# Generated at 2022-06-23 21:27:20.423225
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    expected = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
        'add_provider',
        'add_providers',
        'add_custom_provider',
        'add_custom_providers',
    ]
    generic = Generic()
    result = sorted(generic._Generic__dir__())

    assert result == expected


# Generated at 2022-06-23 21:27:23.949059
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        def method(self):
            return 'custom'

    g = Generic()
    assert not hasattr(g, 'custom')

    g.add_providers(CustomProvider)
    assert hasattr(g, 'custom')
    assert g.custom.method() == 'custom'

    g.add_providers(CustomProvider, CustomProvider)
    assert len(g.__dir__()) == len(Generic().__dict__.keys()) + 3

# Generated at 2022-06-23 21:27:31.917944
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.complex import Complex
    from mimesis.providers.geography import Geography
    # Define custom providers
    class CustomProvider(BaseProvider):
        def foo(self):
            return 'bar'
    # Add many providers
    g = Generic()
    g.add_providers(Complex, Geography, CustomProvider)
    # Check if they were added
    assert isinstance(g.complex, Complex)
    assert isinstance(g.geography, Geography)
    assert isinstance(g.custom_provider, CustomProvider)
    assert g.custom_provider.foo() == 'bar'

# Generated at 2022-06-23 21:27:35.535811
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """
    Test method add_providers of class Generic.
    """
    generic = Generic()
    generic.add_providers(Person, Address)
    assert generic.person and generic.address

# Generated at 2022-06-23 21:27:38.443504
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Name
    generic = Generic()
    generic.add_providers(Name)
    assert hasattr(generic, 'name')

# Generated at 2022-06-23 21:27:42.617262
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

        def test_data(self):
            return {'test': 'hello, world!'}

    provider = Generic()
    provider.add_provider(Custom)

    assert provider.custom.test_data() == Custom().test_data()


# Generated at 2022-06-23 21:27:47.655945
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    def func(locale: str, seed: Any) -> BaseProvider:
        return BaseProvider(locale, seed)

    x = Generic()
    y = x._address
    assert y == x.address
    x._address = func
    del y
    y = x.address
    assert y == x._address(x.locale, x.seed)
    assert y == func(x.locale, x.seed)

# Generated at 2022-06-23 21:27:53.066653
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Test(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

    gen = Generic()
    gen.add_providers(Test)

    # if custom provider was added, then we can get it
    assert hasattr(gen, 'test')

# Generated at 2022-06-23 21:28:00.964202
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person
    assert generic.address
    assert generic.business
    assert generic.text
    assert generic.food
    assert generic.science
    assert generic.choice
    assert generic.transport
    assert generic.unit_system
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic
    assert generic.structure

# Test for the method __dir__ of the class Generic

# Generated at 2022-06-23 21:28:05.388563
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    obj = Generic()
    assert len(obj.__dir__()) >= 25
    assert obj.__dir__() == dir(obj)



# Generated at 2022-06-23 21:28:07.999803
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Business, Text, Person, BaseProvider)
    assert len(generic.__dict__) == 4

# Generated at 2022-06-23 21:28:09.412213
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.business.company_name() != ''



# Generated at 2022-06-23 21:28:12.646920
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    g = Generic()
    g.add_provider(TestProvider)
    assert hasattr(g, 'testprovider')


# Generated at 2022-06-23 21:28:15.918890
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider"""
    g = Generic()
    class Foo(BaseProvider):
        def foo(self):
            return "foo"
    g.add_provider(Foo)
    assert g.foo() == g.foo.foo()


# Generated at 2022-06-23 21:28:18.502076
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers of class Generic"""
    gen = Generic()
    gen.add_providers(Person, Address, Datetime)
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)

# Generated at 2022-06-23 21:28:22.228244
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    try:
        assert Generic().phone_number  # noqa: WPS511
    except Exception:
        assert False, 'Error in Generic.__getattr__'



# Generated at 2022-06-23 21:28:27.468666
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # define the instance of class Generic
    generic = Generic()
    # add custom provider
    generic.add_provider(Test)
    # check that custom provider has been added
    assert generic.test
    return True


# Generated at 2022-06-23 21:28:35.905666
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    class MyProvider(BaseProvider):
        """Class for unit test of Generic().add_providers."""

        class Meta:
            """Class for metadata."""

            name = 'myprovider'

        def func(self) -> str:
            """Dummy method.

            :return: str
            """
            return 'hello'

    class MyProvider2(BaseProvider):
        """Class for unit test of Generic().add_providers."""

        class Meta:
            """Class for metadata."""

            name = 'myprovider2'

        def func(self) -> str:
            """Dummy method.

            :return: str.
            """
            return 'hello'

    gen = Generic()
    gen.add_providers(MyProvider, MyProvider2)


# Generated at 2022-06-23 21:28:43.757204
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    all_providers: List[Type[BaseProvider]] = [
        Person, Address, Datetime, Text, Food, Science, Development,
        Hardware, Clothing, Internet, Path, Payment, Cryptographic,
        Structure, Choice,
    ]
    all_providers.remove(Business)
    all_providers.remove(Transport)
    all_providers.remove(Code)
    all_providers.remove(UnitSystem)
    all_providers.remove(File)
    all_providers.remove(Numbers)

    for provider_cls in all_providers:
        provider_name = provider_cls.Meta.name
        assert getattr(Generic(), provider_name).VERSION



# Generated at 2022-06-23 21:28:45.548644
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('en')
    assert gen.text.words(5)

# Generated at 2022-06-23 21:28:49.661449
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import X_Provider
    from mimesis.providers.person import Gender
    g = Generic()
    assert not hasattr(g, 'person')
    g.add_provider(X_Provider)
    assert g.person.gender == Gender.FEMALE

# Generated at 2022-06-23 21:28:58.424414
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic()
    assert x.person.__class__.__name__ == 'Person'
    assert x.address.__class__.__name__ == 'Address'
    assert x.datetime.__class__.__name__ == 'Datetime'
    assert x.business.__class__.__name__ == 'Business'
    assert x.text.__class__.__name__ == 'Text'
    assert x.food.__class__.__name__ == 'Food'
    assert x.science.__class__.__name__ == 'Science'
    assert x.transport.__class__.__name__ == 'Transport'
    assert x.code.__class__.__name__ == 'Code'
    assert x.unit_system.__class__.__name__ == 'UnitSystem'

# Generated at 2022-06-23 21:29:04.108238
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic.__dir__()"""
    generic = Generic()
    actual = generic.__dir__()
    expected = [
        'address',
        'add_provider',
        'add_providers',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]
    assert sorted(expected) == sorted(actual)



# Generated at 2022-06-23 21:29:09.263941
# Unit test for constructor of class Generic
def test_Generic():
    init_args = {}
    init_args['seed'] = 'mimesis'
    init_args['locale'] = 'en'
    g = Generic(**init_args)

    assert g.seed == 'mimesis'
    assert g.locale == 'en'



# Generated at 2022-06-23 21:29:16.913855
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen1 = Generic('en')
    print(gen1.person.full_name())
    print(gen1.person.full_name())
    print(gen1.person.full_name())
    print(gen1.person.full_name())
    gen2 = Generic('en')
    print(gen2.person.full_name())
    print(gen2.person.full_name())
    print(gen2.person.full_name())
    print(gen2.person.full_name())


# Generated at 2022-06-23 21:29:28.702150
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geography.address import Address as Address_local
    from mimesis.providers.geography.address import Address as Address_global

    address = Address_local(seed=42)
    address_global = Address_global(seed=42)

    assert address._city() == 'Хабаровск' # same locale
    assert address_global._city() != 'Хабаровск' # different locale

    class Foo():
        pass

    gener = Generic(locale='ru', seed=42)
    gener.add_provider(Foo)
    gener.add_provider(Address_local)

    assert not gener.generic  # Added Foo
    assert gener.address._city() == 'Хабаровск' # same

# Generated at 2022-06-23 21:29:40.022369
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    Generic.add_provider()
    Generic.add_provider("")
    Generic.add_provider(None, ())
    Generic.add_provider(())
    Generic.add_provider("")
    Generic.add_provider(None, [])
    Generic.add_provider([])
    Generic.add_provider("")
    Generic.add_provider(None, {})
    Generic.add_provider({})
    Generic.add_provider("")
    Generic.add_provider(None, set())
    Generic.add_provider(set())
    Generic.add_provider("")
    Generic.add_provider(None, int())
    Generic.add_provider(int())
    Generic.add_provider("")
    Generic.add_provider(None, float())
   