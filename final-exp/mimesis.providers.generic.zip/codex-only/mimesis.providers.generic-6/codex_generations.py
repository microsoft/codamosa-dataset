

# Generated at 2022-06-23 21:19:50.909392
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic(seed=42)
    attributes = dir(g)
    assert len(attributes) == 58
    assert 'address' in attributes
    assert 'business' in attributes
    assert 'person' in attributes
    assert 'datetime' in attributes
    assert 'text' in attributes
    assert 'food' in attributes
    assert 'science' in attributes
    assert 'transport' in attributes
    assert 'code' in attributes
    assert 'unit_system' in attributes
    assert 'file' in attributes
    assert 'numbers' in attributes
    assert 'development' in attributes
    assert 'hardware' in attributes
    assert 'clothing' in attributes
    assert 'internet' in attributes
    assert 'path' in attributes
    assert 'payment' in attributes
    assert 'cryptographic' in attributes
    assert 'structure' in attributes

# Generated at 2022-06-23 21:19:53.718078
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic()

    person = generic.person

    assert person is not None


# Generated at 2022-06-23 21:19:59.025445
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.builtins import RussiaSpecProvider

    g = Generic()
    assert 'russia' not in dir(g)

    g.add_provider(RussiaSpecProvider)
    assert 'russia' in dir(g)



# Generated at 2022-06-23 21:20:00.812670
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    aa = g.person()
    assert aa.name() == "孙节"

# Generated at 2022-06-23 21:20:06.899123
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Generic.__getattr__ test."""
    g = Generic()

    # Testing __getattr__ with attrname 'food'
    a = g.food
    b = g.food
    assert a == b
    c = g.choice
    d = g.choice
    assert c == d

    # Testing __getattr__ with not existent attrname
    try:
        f = g.helloworld
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-23 21:20:08.399856
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert gen.__dir__()

# Generated at 2022-06-23 21:20:17.814421
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic('en')
    # Test for providers:
    #
    # from mimesis.providers.address import Address (1 methods)
    # from mimesis.providers.base import BaseDataProvider (1 methods)
    # from mimesis.providers.business import Business (3 methods)
    # from mimesis.providers.choice import Choice (2 methods)
    # from mimesis.providers.clothing import Clothing (28 methods)
    # from mimesis.providers.code import Code (9 methods)
    # from mimesis.providers.cryptographic import Cryptographic (2 methods)
    # from mimesis.providers.date import Datetime (more than 20 methods)
    # from mimesis.providers.development import Development (6 methods)
    # from mimesis.providers.file

# Generated at 2022-06-23 21:20:20.291075
# Unit test for constructor of class Generic
def test_Generic():
    t = Generic()
    assert t.__getattr__('person') is not None



# Generated at 2022-06-23 21:20:30.616062
# Unit test for constructor of class Generic

# Generated at 2022-06-23 21:20:34.094348
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.base import BaseProvider
    class CUSTOM(BaseProvider):
        class Meta:
            name = 'custom'
    class CUSTOM2(BaseProvider):
        class Meta:
            name = 'custom2'

    g = Generic()
    g.add_providers(CUSTOM, CUSTOM2)

    assert isinstance(g.custom, CUSTOM)
    assert isinstance(g.custom2, CUSTOM2)

# Generated at 2022-06-23 21:20:42.515628
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""
    gen = Generic('en')
    gen.add_provider(Person)
    gen.add_provider(Code)
    gen.add_provider(UnitSystem)
    providers = ['person', 'datetime', 'business', 'text', 'food', 'science',
                 'code', 'unit_system', 'transport', 'file', 'numbers',
                 'development', 'hardware', 'clothing', 'internet', 'path',
                 'payment', 'cryptographic', 'structure', 'choice']

    assert sorted(gen.__dir__()) == sorted(providers)

# Generated at 2022-06-23 21:20:46.801921
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en')
    assert g.business.company_name(upper=True) == "NETTRIUM"
    assert g.address.city() == "Burlington"
    assert g.food.fruit() == "avocado"
    assert g.person.last_name() == "Espinel"
    assert g.file.filename() == 'user.js'


# Generated at 2022-06-23 21:20:48.072811
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass



# Generated at 2022-06-23 21:20:51.584875
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Create generic object
    generic = Generic()
    # Create a fake attribute
    # to test __getattr__ method
    attribute = generic._person()

    # Check that attribute is realy created
    assert attribute

    # Check that attribute is instance of BaseProvider
    assert isinstance(attribute, BaseProvider)



# Generated at 2022-06-23 21:20:59.127172
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    x = Generic()
    x.add_provider(Address)
    x.add_provider(Business)
    x.add_provider(Choice)
    x.add_provider(Clothing)
    x.add_provider(Code)
    x.add_provider(Cryptographic)
    x.add_provider(Datetime)
    x.add_provider(Development)
    x.add_provider(File)
    x.add_provider(Food)
    x.add_provider(Hardware)
    x.add_provider(Internet)
    x.add_provider(Numbers)
    x.add_provider(Path)
    x.add_provider(Payment)
    x.add_provider(Person)
    x.add_provider(Science)
    x

# Generated at 2022-06-23 21:21:07.241597
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        def foo(self):
            return 'bar'

    generic = Generic('en')
    
    # add_provider method is working
    generic.add_provider(TestProvider)
    assert callable(generic.testprovider.foo)
    assert generic.testprovider.foo() == 'bar'

    # add_provider raises exception if provider is not a class
    import pytest
    with pytest.raises(TypeError):
        generic.add_provider('foo')
    # add_provider raises exception if provider is not a subclass of BaseProvider
    with pytest.raises(TypeError):
        generic.add_provider(Generic)

# Generated at 2022-06-23 21:21:16.031886
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic('en')
    dir_result = dir(g)
    assert isinstance(dir_result, list)
    assert dir_result[0] == 'address'
    assert dir_result[1] == 'business'
    assert dir_result[2] == 'choice'
    assert dir_result[3] == 'code'
    assert dir_result[4] == 'clothing'
    assert dir_result[5] == 'cryptographic'
    assert dir_result[6] == 'datetime'
    assert dir_result[7] == 'development'
    assert dir_result[8] == 'file'
    assert dir_result[9] == 'food'
    assert dir_result[10] == 'hardware'
    assert dir_result[11] == 'internet'

# Generated at 2022-06-23 21:21:17.138810
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic is not None

# Generated at 2022-06-23 21:21:18.654121
# Unit test for constructor of class Generic
def test_Generic():
    """Tests for class constructor."""
    g = Generic()
    assert g is not None

# Generated at 2022-06-23 21:21:29.127777
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    testers = [
        g.file,
        g.unit_system,
        g.numbers,
        g.development,
        g.hardware,
        g.clothing,
        g.internet,
        g.payment,
        g.cryptographic,
        g.structure,
        g.choice,
        g.person
    ]
    assert testers[0].__class__.__name__ == 'File'
    assert testers[1].__class__.__name__ == 'UnitSystem'
    assert testers[2].__class__.__name__ == 'Numbers'
    assert testers[3].__class__.__name__ == 'Development'
    assert testers[4].__class__.__name__ == 'Hardware'

# Generated at 2022-06-23 21:21:34.990294
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
	# create instance of Generic
	generic = Generic()
	person = generic.person()

	# add provider to generic
	class MyPersonProvider(BaseProvider):
		def name(self):
			return 'user'

	generic.add_provider(MyPersonProvider)
	my_person = generic.my_person()

# Generated at 2022-06-23 21:21:36.471974
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    lst = g.__dir__()
    assert len(lst) == 30


# Generated at 2022-06-23 21:21:41.226383
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    a = Generic()
    a.add_providers(Person)
    a.add_providers(Address, Business)
    assert hasattr(a, 'person')
    assert hasattr(a, 'address')
    assert hasattr(a, 'business')

# Generated at 2022-06-23 21:21:46.095450
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic
    for attr in dir(g):
        print(attr)
    print(g.internet)
    print(g.internet.url())
    print(g.internet.ipv4())
    print(g.internet.ipv6())

# test
if __name__ == '__main__':
    test_Generic___dir__()

# Generated at 2022-06-23 21:21:50.774493
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    # Add providers
    generic.add_providers(Person, Address, Datetime)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)

# Generated at 2022-06-23 21:21:55.442632
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic('ru')
    assert len(dir(provider)) == 32
    assert 'ru_ru_address' in dir(provider)
    assert 'ru_ru_person' in dir(provider)
    assert 'ru_ru_business' in dir(provider)



# Generated at 2022-06-23 21:21:57.639285
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert(len(Generic().__dir__()) == 20)
    assert(len(Generic().__dir__()) == len(Generic().__dict__))

# Generated at 2022-06-23 21:22:01.629890
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = "test"
        @staticmethod
        def something(cls):
            return cls.seed.randint(1, 5)
    data = Generic()
    data.add_provider(Provider)
    assert hasattr(data, "test")
    assert data.test.something() < 6

# Generated at 2022-06-23 21:22:04.925454
# Unit test for constructor of class Generic
def test_Generic():
    try:
        g = Generic('en')
        address = g.address
    except AttributeError:
        address = False
    assert address

# Generated at 2022-06-23 21:22:09.309829
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_provider method."""
    g = Generic()
    g.add_providers(Code, UnitSystem, File)
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None


# Generated at 2022-06-23 21:22:13.784365
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    local_gen = Generic()
    local_gen.add_provider(File)
    assert 'file' in dir(local_gen)
    assert 'choice' in dir(local_gen)
    assert 'add_provider' in dir(local_gen)

# Generated at 2022-06-23 21:22:22.187815
# Unit test for constructor of class Generic
def test_Generic():
    gener = Generic()
    assert gener.person
    assert gener.address
    assert gener.business
    assert gener.text
    assert gener.food
    assert gener.science
    assert gener.transport
    assert gener.code
    assert gener.unit_system
    assert gener.file
    assert gener.numbers
    assert gener.development
    assert gener.hardware
    assert gener.clothing
    assert gener.internet
    assert gener.path
    assert gener.payment
    assert gener.cryptographic
    assert gener.structure
    assert gener.choice


# Generated at 2022-06-23 21:22:23.546979
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g is not None

# Generated at 2022-06-23 21:22:28.527449
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # test add_providers to Generic() object
    provider = Generic()

    def test_provider(BaseProvider):
        class Meta:
            name = 'test'

        return BaseProvider

    provider.add_providers(test_provider)
    assert isinstance(provider.test, type(provider))
    delattr(provider, 'test')


# Generated at 2022-06-23 21:22:32.299703
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    generic = Generic('en')
    generic.add_provider(Address)
    assert hasattr(generic, 'address')



# Generated at 2022-06-23 21:22:37.300687
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """
    Generic.__getattr__() should return attributes of class Generic().
    """
    try:
        gen = Generic()
        getattr(gen, 'person')
    except AttributeError:
        assert False
    else:
        assert True

# Generated at 2022-06-23 21:22:44.036851
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.science import Science
    from mimesis.providers.person import Person
    from mimesis.enums import Gender

    gen = Generic()
    gen.add_providers(Science, Person)
    assert gen.science.get_element() in Science.Meta.elements
    assert gen.person.gender() == Gender.FEMALE.value or Gender.MALE.value
    assert gen.person.sex == Gender.FEMALE.value or Gender.MALE.value
    assert gen.person.full_name() == '{} {}'.format(Person.Meta.first_name,
                                                    Person.Meta.last_name)


# Generated at 2022-06-23 21:22:49.122091
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():

    class CustomProvider(BaseProvider):
        def foo(self):
            return 'foo'

    gen = Generic()
    gen.add_providers(CustomProvider)

    assert hasattr(gen, 'customprovider')
    actual = gen.customprovider.foo()
    expected = 'foo'

    assert actual == expected

# Generated at 2022-06-23 21:22:50.918355
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    assert len(dir(obj)) > 1

# Generated at 2022-06-23 21:22:58.591852
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.payment import CreditCard
    from mimesis.providers.person import Person

    g = Generic()
    g.add_providers(CreditCard, Person)
    c = g.credit_card

    # https://stackoverflow.com/questions/586546/
    # how-do-i-check-if-im-running-in-pythons-interpreter
    # https://www.python.org/dev/peps/pep-0521/
    if '__main__' in globals():
        print('Hello, ', c.card_number(), c.issuer_name())
        print(g.person.full_name())

# Generated at 2022-06-23 21:23:05.254441
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import copy
    from mimesis.providers.base import BaseProvider

    class TestProvider(BaseProvider):
        class Meta:
            name = 'testprovider'

        def __init__(self, seed: int = None, **kwargs):
            super().__init__(seed, **kwargs)

        def test_func(self):
            return 'test'

    data_provider = Generic()

    data_provider.add_provider(TestProvider)
    test_provider = data_provider.testprovider
    assert test_provider.test_func() == 'test'

    data_provider_copy = copy.deepcopy(data_provider)

    data_provider_copy.add_provider(TestProvider)
    test_provider_copy = data_provider_copy.testprovider


# Generated at 2022-06-23 21:23:11.215320
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic('zh-CN')
    assert provider.locale == 'zh-CN'
    person = provider.person()
    person.full_name()
    person.username()
    provider.address().address()
    provider.datetime().timezone()
    provider.text().text()
    provider.food().ingredient()
    provider.science().element()
    provider.transport().vehicle()
    provider.code().isbn()
    provider.unit_system().mass()
    provider.file().medium()
    provider.numbers().latin_number()
    provider.development().email()
    provider.hardware().mac_address()
    provider.clothing().shoe_size()
    provider.internet().ipv4()
    provider.path().posix_file_path()
    provider.payment().iban()

# Generated at 2022-06-23 21:23:13.509931
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    class MockGeneric():
        def __init__(self):
            self.__dict__['_person'] = None
    g = MockGeneric()
    assert g.person == None

# Generated at 2022-06-23 21:23:17.050126
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class A(BaseProvider):
        class Meta:
            name = 'a'

        def provide(self):
            return 'a'

    g = Generic()
    g.add_provider(A)

    assert hasattr(g, 'a')
    assert g.a.provide() == 'a'


# Generated at 2022-06-23 21:23:25.792511
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.data import LANGUAGES

    gen = Generic()
    assert len(gen.__dir__()) == 35

    gen.add_providers(Transport, Code, UnitSystem, File, Numbers)
    assert len(gen.__dir__()) == 40

    assert gen.transport.__dict__['_seed'] == gen.seed
    assert gen.code.__dict__['_seed'] == gen.seed
    assert gen.unit_system.__dict__['_seed'] == gen.seed
    assert gen.file.__dict__['_seed'] == gen.seed
    assert gen.numbers.__dict__['_seed'] == gen.seed

    gen.transport.set_seed(23)
    assert gen.transport.__dict__['_seed'] == 23
    assert gen.transport.__dict

# Generated at 2022-06-23 21:23:28.019281
# Unit test for constructor of class Generic
def test_Generic():
    print(Generic())

if '__main__' == __name__:
    test_Generic()

# Generated at 2022-06-23 21:23:30.053025
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic('en')
    assert 'choice' in gen.__dir__()



# Generated at 2022-06-23 21:23:39.842153
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert isinstance(g.address, Address)
    assert isinstance(g.person, Person)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.internet, Internet)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.path, Path)

# Generated at 2022-06-23 21:23:47.937682
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert gen.Meta.name == 'generic'
    assert hasattr(gen, 'person')
    assert hasattr(gen, 'address')
    assert hasattr(gen, 'business')
    assert hasattr(gen, 'datetime')
    assert hasattr(gen, 'text')
    assert hasattr(gen, 'food')
    assert hasattr(gen, 'science')
    assert hasattr(gen, 'transport')
    assert hasattr(gen, 'code')
    assert hasattr(gen, 'unit_system')
    assert hasattr(gen, 'file')
    assert hasattr(gen, 'numbers')
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'hardware')
    assert hasattr(gen, 'clothing')

# Generated at 2022-06-23 21:23:54.082023
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    import pytest
    providers = Generic()
    providers.add_provider(Payment)
    assert providers.payment != None
    with pytest.raises(TypeError):
        providers.add_provider(Person)


# Generated at 2022-06-23 21:24:01.037985
# Unit test for constructor of class Generic
def test_Generic():
    x = Generic()
    assert x._person
    assert x._address 
    assert x._datetime
    assert x._business
    assert x._text
    assert x._food
    assert x._science
    assert x.transport
    assert x.code
    assert x.unit_system
    assert x.file
    assert x.numbers
    assert x.development
    assert x.hardware
    assert x.clothing
    assert x.internet
    assert x.path
    assert x.payment
    assert x.cryptographic
    assert x.structure
    assert x.choice


# Generated at 2022-06-23 21:24:07.615216
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import os
    import sys

    a = Generic()
    assert a.__dir__() == [
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
        'add_provider',
        'add_providers'
    ]


# Generated at 2022-06-23 21:24:12.286930
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.providers.generic import Generic
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.date import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science

    PROVIDERS = [
        Person,
        Address,
        Datetime,
        Business,
        Text,
        Food,
        Science,
    ]

# Generated at 2022-06-23 21:24:19.376301
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.finance import Finance

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        @classmethod
        def some_method(cls):
            return cls.__name__.lower()

    generic = Generic()
    generic.add_providers(Finance, TestProvider)

    assert hasattr(generic, 'finance')
    assert hasattr(generic, 'test_provider')

    assert hasattr(generic.finance, 'currency_code')
    assert hasattr(generic.test_provider, 'some_method')

# Unit tests for method __getattr__ of class Generic

# Generated at 2022-06-23 21:24:24.469910
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.datetime import DayOfWeek, Time

    class CustomTime(Time):
        class Meta:
            name = 'time'

    generic = Generic()
    try:
        generic.add_providers(DayOfWeek, CustomTime)
    except TypeError:
        print("Test passed")

# Generated at 2022-06-23 21:24:29.902921
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g.__dir__(), list)
    providers = [
        'person', 'address', 'datetime', 'business', 'text', 'food',
        'science', 'transport', 'code', 'unit_system', 'file', 'numbers',
        'development', 'hardware', 'clothing', 'internet', 'path', 'payment',
        'cryptographic', 'structure', 'choice'
    ]
    for provider in g.__dir__():
        assert provider in providers

# Generated at 2022-06-23 21:24:39.458377
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    dir_list = g.__dir__()
    assert isinstance(dir_list, list)
    assert 'person' in dir_list
    assert 'address' in dir_list
    assert 'datetime' in dir_list
    assert 'business' in dir_list
    assert 'text' in dir_list
    assert 'food' in dir_list
    assert 'science' in dir_list
    assert 'transport' in dir_list
    assert 'code' in dir_list
    assert 'unit_system' in dir_list
    assert 'file' in dir_list
    assert 'numbers' in dir_list
    assert 'development' in dir_list
    assert 'hardware' in dir_list
    assert 'clothing' in dir_list
    assert 'internet' in dir_list

# Generated at 2022-06-23 21:24:51.085485
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.data import PROVIDERS
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.path import Path
    from mimesis.providers.payment import Payment
    from mimesis.providers.person import Person


# Generated at 2022-06-23 21:24:52.356077
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic
test_Generic()

# Generated at 2022-06-23 21:24:53.314726
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(dir(g))

# Generated at 2022-06-23 21:24:59.400135
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    meta = getattr(Generic, 'Meta')
    meta_name = getattr(meta, 'name')
    assert meta_name in dir(generic)
    assert 'BaseProvider' not in dir(generic)
    assert 'AbstractField' not in dir(generic)
    assert 'BaseDataProvider' not in dir(generic)
    assert 'Generic' not in dir(generic)
    assert generic.__class__.__name__ not in dir(generic)


# Generated at 2022-06-23 21:25:07.084720
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:25:10.955756
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('ru')
    assert g.person.full_name() != g.person.full_name()
    g1 = Generic('en')
    assert g1.person.full_name() != g.person.full_name()

# Generated at 2022-06-23 21:25:19.925853
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider of class Generic."""
    g = Generic('ru')
    assert hasattr(g, 'business') == True
    assert hasattr(g, 'payment') == True
    assert hasattr(g, 'transport') == True
    assert hasattr(g, 'development') == True
    assert hasattr(g, 'hardware') == True
    assert hasattr(g, 'clothing') == True
    assert hasattr(g, 'internet') == True
    assert hasattr(g, 'path') == True
    assert hasattr(g, 'numbers') == True
    assert hasattr(g, 'code') == True
    assert hasattr(g, 'unit_system') == True
    assert hasattr(g, 'file') == True
    assert hasattr(g, 'cryptographic') == True

# Generated at 2022-06-23 21:25:29.454513
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.unit_system is not None
    assert g.code is not None
    assert g.file is not None
    assert g.food is not None
    assert g.hardware is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.clothing is not None
    assert g.cryptographic is not None
    assert g.science is not None
    assert g.structure is not None
    assert g.transport is not None
    assert g.development is not None
    assert g.numbers is not None
    assert g.choice is not None
    assert g.person is not None
    assert g.address is not None
    assert g.business is not None
    assert g.datetime is not None

# Generated at 2022-06-23 21:25:31.908687
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    defProvider = Generic()
    defProvider.person.random
    defProvider.datetime.datetime()

# Generated at 2022-06-23 21:25:43.319310
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)
    assert isinstance(g, BaseDataProvider)
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)

# Generated at 2022-06-23 21:25:47.894143
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic(seed=42)
    g.add_providers(Person, Address, Business)
    assert hasattr(g, 'generic')
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')
    assert hasattr(g, 'business')


# Generated at 2022-06-23 21:25:52.517997
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def foo(self, _provider: Any) -> str:
            return 'bar'

    generic = Generic()
    generic.add_provider(Provider)
    assert generic.provider.foo(generic) == 'bar'



# Generated at 2022-06-23 21:25:57.782905
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)


# Generated at 2022-06-23 21:26:04.825027
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic(seed=1)
    assert obj.person.full_name() == 'Georgina Duran'
    assert obj.datetime.datetime() == '1999-12-03T03:29:34'
    assert obj.datetime.datetime() == '1999-12-03T03:29:34'
    assert obj.address.address() == '83723 Sanders Forge\nEast Evelyn, NL 21194-0990'
    assert obj.address.address() == '83723 Sanders Forge\nEast Evelyn, NL 21194-0990'
    assert obj.business.company() == 'Wolff-Zemlak'
    assert obj.business.company() == 'Wolff-Zemlak'
    assert obj.text.title() == 'Ad aperiam qui nemo accusamus.'

# Generated at 2022-06-23 21:26:07.717218
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic.__dir__()."""
    g = Generic()
    assert isinstance(g.__dir__(), list)



# Generated at 2022-06-23 21:26:09.479142
# Unit test for constructor of class Generic
def test_Generic():
    """Test constructor Generic."""
    g = Generic()
    assert isinstance(g, Generic)


# Generated at 2022-06-23 21:26:20.623941
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    dir_ = g.__dir__()
    assert len(dir_) >= 23
    assert 'address' in dir_
    assert 'person' in dir_
    assert 'unit_system' in dir_
    assert 'food' in dir_
    assert 'transport' in dir_
    assert 'file' in dir_
    assert 'science' in dir_
    assert 'internet' in dir_
    assert 'datetime' in dir_
    assert 'path' in dir_
    assert 'structure' in dir_
    assert 'development' in dir_
    assert 'hardware' in dir_
    assert 'numbers' in dir_
    assert 'payment' in dir_
    assert 'text' in dir_
    assert 'business' in dir_
    assert 'clothing' in dir_

# Generated at 2022-06-23 21:26:23.183541
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for __getattr__ method of class Generic."""
    g = Generic(seed=10)
    result = g.person.username()
    assert result == 'vkdlj12'

# Generated at 2022-06-23 21:26:24.457945
# Unit test for constructor of class Generic
def test_Generic():

    gen = Generic()
    assert isinstance(gen, Generic)

# Generated at 2022-06-23 21:26:35.991772
# Unit test for method __dir__ of class Generic

# Generated at 2022-06-23 21:26:40.699586
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test to check if all providers are in __dir__ of Generic."""
    test_providers = [
        Generic().person, Generic().address, Generic().datetime,
        Generic().business, Generic().text, Generic().food,
        Generic().science, Generic().transport, Generic().code,
        Generic().unit_system, Generic().file, Generic().numbers,
        Generic().development, Generic().hardware, Generic().clothing,
        Generic().internet, Generic().path, Generic().payment,
        Generic().cryptographic, Generic().structure, Generic().choice,
    ]
    for provider in test_providers:
        assert 'person' in Generic().__dir__()



# Generated at 2022-06-23 21:26:43.773628
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert 'person' in generic.__dir__()
    assert 'address' in generic.__dir__()



# Generated at 2022-06-23 21:26:45.225973
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person.full_name()

# Generated at 2022-06-23 21:26:46.942352
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic) is True

# Generated at 2022-06-23 21:26:50.971662
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """
    The method add_providers of class Generic is currently not tested
    """
    pass


# Generated at 2022-06-23 21:27:00.251328
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert isinstance(generic, Generic)
    assert isinstance(generic, BaseDataProvider)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)

# Generated at 2022-06-23 21:27:02.067886
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    gen = Generic()
    assert gen is not None

# Generated at 2022-06-23 21:27:06.021654
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyOwnProvider(BaseProvider):
        class Meta:
            name = 'my_own_provider'

        def hello(self):
            return 'Hello'

    g = Generic()
    g.add_provider(MyOwnProvider)
    assert g.my_own_provider.hello() == 'Hello'



# Generated at 2022-06-23 21:27:10.621477
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    person = generic.person
    person_name = generic.person.name
    assert isinstance(person, Person)
    assert isinstance(person_name, str)
    generic = Generic('ru')
    person = generic.person
    person_name = generic.person.name

# Generated at 2022-06-23 21:27:13.647384
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(Test)
    assert hasattr(g, 'test')
    assert g.test.foo() == 'bar'


# Generated at 2022-06-23 21:27:19.247915
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic('en')
    class ProviderA(BaseProvider):
        class Meta:
            name = 'provider_a'

    class ProviderB(BaseProvider):
        class Meta:
            name = 'provider_b'

    g.add_providers(ProviderA, ProviderB)
    assert isinstance(g.provider_a, ProviderA) and isinstance(g.provider_b, ProviderB)


# Generated at 2022-06-23 21:27:24.592182
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.numbers
    assert g.clothing
    assert g.code
    assert g.development
    assert g.file
    assert g.hardware
    assert g.internet
    assert g.path
    assert g.payment
    assert g.transport
    assert g.unit_system
    assert g.science
    assert g.person
    assert g.business
    assert g.choice
    assert g.address
    assert g.food
    assert g.text

# Generated at 2022-06-23 21:27:28.145687
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider() method."""
    from mimesis.providers.sport import Sport
    g = Generic()
    g.add_provider(Sport)
    assert callable(g.sport)



# Generated at 2022-06-23 21:27:32.629195
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    # print(g.internet)
    assert isinstance(g.internet, Internet)
    g.add_provider(Business)
    assert isinstance(g.business, Business)
    g = Generic(locale='en')
    assert g.locale == 'en'
    g = Generic(seed=0)
    assert g.seed == 0


if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:27:43.504788
# Unit test for method __dir__ of class Generic

# Generated at 2022-06-23 21:27:50.718626
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Country(BaseProvider):
        """Representation of Country."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.prefixes = ['A', 'B', 'C']

        def color(self):
            return self.random.choice(self.prefixes)

    class Color(BaseProvider):
        """Representation of Color."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.colors = ['Red', 'Blue', 'Black']

        def color(self):
            return self.random.choice(self.colors)

    g = Generic()

# Generated at 2022-06-23 21:27:52.896466
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=10)
    assert generic._address  # Initialization test.
    assert generic.address  # Lazy initialization test.

# Generated at 2022-06-23 21:28:01.543678
# Unit test for constructor of class Generic
def test_Generic():
    p = Generic('en')
    assert p.address.address() is not None
    assert p.person.full_name() is not None
    assert p.person.name() is not None
    assert p.business.credit_card_number() is not None
    assert p.code.iban() is not None
    assert p.clothing.clothing() is not None
    assert p.clothing.size() is not None

    assert p.choice.coin() is not None
    assert p.choice.dice() is not None
    assert p.choice.number() is not None

    assert p.datetime.datetime() is not None
    assert p.datetime.datetime(end=2020) is not None
    assert p.datetime.timestamp() is not None

# Generated at 2022-06-23 21:28:06.192906
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Person)
    assert gen.person.__class__.__name__ == 'Person'


# Generated at 2022-06-23 21:28:07.663628
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert 'Generic' == g.__class__.__name__

# Generated at 2022-06-23 21:28:13.905266
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    providers = ['person', 'person', 'datetime',
                 'datetime', 'business', 'business',
                 'text', 'text', 'food', 'food',
                 'science', 'science', 'transport', 'transport',
                 'code', 'code', 'unit_system', 'unit_system',
                 'file', 'file', 'numbers', 'numbers',
                 'development', 'development',
                 'hardware', 'hardware', 'clothing', 'clothing',
                 'internet', 'internet', 'path', 'path',
                 'payment', 'payment', 'cryptographic', 'cryptographic',
                 'structure', 'structure', 'choice', 'choice']

    g = Generic()
    lst = g.__dir__()
    assert lst == providers

# Generated at 2022-06-23 21:28:19.907142
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method Generic.__dir__()."""
    data = Generic()

    assert isinstance(data.__dir__(), list)
    assert '__dir__' in dir(data)
    assert len(dir(data)) > 0
    assert 'internet' in dir(data)
    assert 'payment' in dir(data)
    assert 'numbers' in dir(data)
    assert 'development' in dir(data)
    assert 'hardware' in dir(data)
    assert 'clothing' in dir(data)
    assert 'file' in dir(data)
    assert 'unit_system' in dir(data)
    assert 'code' in dir(data)
    assert 'transport' in dir(data)
    assert 'choice' in dir(data)
    assert 'path' in dir(data)

# Generated at 2022-06-23 21:28:27.155029
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from .test_providers.test_personal import CustomProvider1
    from .test_providers.test_personal import CustomProvider2

    gen = Generic()
    gen.add_providers(CustomProvider1, CustomProvider2)

    assert hasattr(gen, 'custom_provider1')
    assert hasattr(gen, 'custom_provider2')

    assert isinstance(gen.custom_provider1, CustomProvider1)
    assert isinstance(gen.custom_provider2, CustomProvider2)

# Generated at 2022-06-23 21:28:28.846514
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    result = gen.__dir__()
    assert isinstance(result, list) and result

# Generated at 2022-06-23 21:28:36.828984
# Unit test for constructor of class Generic
def test_Generic():
    """Test to check if constructor of the class Generic works correctly."""
    generic = Generic()
    assert generic.person.name.__class__.__name__ == "Person"
    assert generic.address.address.__class__.__name__ == "Address"
    assert generic.datetime.datetime.__class__.__name__ == "Datetime"
    assert generic.developement.programming_language.__class__.__name__ == "Development"
    assert generic.business.company.__class__.__name__ == "Business"
    assert generic.text.text.__class__.__name__ == "Text"
    assert generic.food.comida.__class__.__name__ == "Food"
    assert generic.science.chemical_element.__class__.__name__ == "Science"
    assert generic.unit.system

# Generated at 2022-06-23 21:28:43.926260
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    person = Person()
    class ProviderOne(BaseProvider):
        class Meta:
            name = 'provider_one'

        def foo(self) -> str:
            return "foo"

    class ProviderTwo(BaseProvider):
        class Meta:
            name = 'provider_two'

        def bar(self) -> str:
            return "bar"

    generic = Generic()
    generic.add_providers(ProviderOne, ProviderTwo)

    assert person.random.choice.from_dict(generic.provider_one.foo) == 'foo'
    assert person.random.choice.from_dict(generic.provider_two.bar) == 'bar'

# Generated at 2022-06-23 21:28:47.344525
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.movie import Movie

    gen = Generic()
    gen.provider = 'ru'
    assert not gen.movie
    gen.add_providers(Movie)
    assert gen.movie

# Generated at 2022-06-23 21:28:56.983624
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person.full_name()
    assert generic.address.postal_code()
    assert generic.datetime.date(minimum='Jan 1 2019', maximum='Jun 1 2019')
    assert generic.business.company()
    assert generic.text.title()
    assert generic.food.ingredient()
    assert generic.science.chemical_element()
    assert generic.transport.car()
    assert generic.code.isbn(partition=True)
    assert generic.unit_system.weight()
    assert generic.file.extension(system=True)
    assert generic.numbers.pow(base=5, power=3)
    assert generic.development.function_name(
        prefixes=['def'],
        postfixes=['()']
    )
    assert generic.hardware.gpu

# Generated at 2022-06-23 21:29:01.594566
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'
        def my_method(self):
            return 'test'

    class MyProvider2(BaseProvider):
        def my_method(self):
            return 'test2'

    gen = Generic()
    gen.add_provider(MyProvider)
    gen.add_provider(MyProvider2)

    assert gen.my_provider.my_method() == 'test'
    assert gen.my_provider2.my_method() == 'test2'

# Generated at 2022-06-23 21:29:09.371191
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic(seed=123)
    generic.add_provider(MockProvider)

    assert generic.__dir__() == [ 'person', 'address', 'datetime', 'business', 'text', 'food', 'science', 'transport',
                                 'code', 'unit_system', 'file', 'numbers', 'development', 'hardware', 'clothing',
                                 'internet', 'path', 'payment', 'cryptographic', 'structure', 'choice', 'mock_provider' ]



# Generated at 2022-06-23 21:29:16.512969
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.address != None
    assert gen.datetime != None
    assert gen.person != None
    assert gen.business != None
    assert gen.text != None
    assert gen.food != None
    assert gen.science != None
    assert gen.transport != None
    assert gen.code != None
    assert gen.unit_system != None
    assert gen.file != None
    assert gen.numbers != None
    assert gen.development != None
    assert gen.hardware != None
    assert gen.clothing != None
    assert gen.internet != None
    assert gen.path != None
    assert gen.payment != None
    assert gen.cryptographic != None
    assert gen.structure != None
    assert gen.choice != None

    # Unit test for method __dir__ of class Generic

# Generated at 2022-06-23 21:29:24.131398
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Payment)
    assert isinstance(generic.payment, Payment)
    generic.add_provider(Path)
    assert isinstance(generic.path, Path)
    generic.add_provider(UnitSystem)
    assert isinstance(generic.unit_system, UnitSystem)
    generic.add_provider(Science)
    assert isinstance(generic.science, Science)
    generic.add_provider(Cryptographic)
    assert isinstance(generic.cryptographic, Cryptographic)
    generic.add_provider(Development)
    assert isinstance(generic.development, Development)

    try:
        generic.add_provider(str)
    except TypeError:
        assert True


# Generated at 2022-06-23 21:29:27.297495
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for Generic.__dir__."""
    g = Generic()
    assert 'numbers' in dir(g)
    assert 'random_int' in dir(g)
    assert 'science' in dir(g)

# Generated at 2022-06-23 21:29:30.327107
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generator = Generic()
    generator.person.full_name()
    generator.address.address()


# Generated at 2022-06-23 21:29:40.850468
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of Generic class."""
    generic = Generic()
    try:
        generic.add_provider(int)
    except TypeError as e:
        assert str(e) == 'The provider must be a class'
    else:
        assert False

    try:
        generic.add_provider(BaseDataProvider)
    except TypeError as e:
        assert str(e) == 'The provider must be a subclass of BaseProvider'
    else:
        assert False

    class AProvider(BaseProvider):
        """A provider."""

        class Meta:
            """Class for metadata."""

            name = 'a_provider'

    generic.add_provider(AProvider)
    assert hasattr(generic, 'a_provider')
