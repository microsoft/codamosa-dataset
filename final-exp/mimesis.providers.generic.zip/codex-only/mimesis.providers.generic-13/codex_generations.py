

# Generated at 2022-06-23 21:19:45.185009
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    providers = dir(generic)
    assert len(providers) > 0
    for provider in providers:
        assert provider in generic.__dict__
    providers.sort()
    assert providers == sorted(list(generic.__dict__.keys()))

# Generated at 2022-06-23 21:19:56.160660
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.numbers import RandomDecimal
    from mimesis.providers.numbers import RandomHexadecimal
    from mimesis.providers.numbers import RandomInteger
    from mimesis.providers.numbers import RandomRomanNumeral

    one = Generic(seed=123456789)
    one.add_providers(Numbers, RandomDecimal, 
                      RandomHexadecimal, RandomInteger, 
                      RandomRomanNumeral)
    one.numbers.number(10, 15) == one.random_integer(10, 15)
    one.random_decimal(10.001, 15.02) == one.random_integer(10.001, 15.02)

# Generated at 2022-06-23 21:20:05.797143
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic('ru')

    assert 'Георгий' == generic.person.full_name()
    assert 'Краснодар' == generic.address.city()
    assert '10:58:05' == generic.datetime.time()
    assert '14:58:05' == generic.datetime.time(formatted=False)
    assert 'Московский проспект, 119, строение 1, квартира 28' == \
        generic.address.address(country_code='RU')

# Generated at 2022-06-23 21:20:09.416321
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic._data
    assert generic.clothing
    assert generic.numbers
    return generic


# Generated at 2022-06-23 21:20:11.052409
# Unit test for constructor of class Generic
def test_Generic():
    t = Generic()
    assert isinstance(t, Generic)

# Generated at 2022-06-23 21:20:16.864326
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    seed = 123456
    g = Generic(seed)
    try:
        class MyProvider(BaseProvider):
            def foo(self):
                return self.seed

        g.add_provider(MyProvider)
    except TypeError:
        pass
    else:
        raise AssertionError('The provider must be a '
                             'subclass of BaseProvider')

    class MyProvider(BaseProvider):
        def foo(self):
            return self.seed

    g.add_provider(MyProvider)
    assert g.myprovider.foo() == seed

    assert 'myprovider' in dir(g)


# Generated at 2022-06-23 21:20:19.468004
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    generic = Generic()
    assert isinstance(generic.person, Person)



# Generated at 2022-06-23 21:20:30.258554
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)

# Generated at 2022-06-23 21:20:37.615312
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    providers = []
    exclude = BaseDataProvider().__dict__.keys()
    for a in gen.__dict__:
        if a not in exclude:
            if a.startswith('_'):
                providers.append(a.replace('_', '', 1))
            else:
                providers.append(a)
    assert set(providers) == set(gen.__dir__())


# Generated at 2022-06-23 21:20:43.256591
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    members = {'address', 'business', 'choice', 'code', 'clothing', 'cryptographic', 'datetime', 'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'payment', 'person', 'path', 'science', 'structure', 'text', 'transport', 'unit_system'}
    result = set(dir(g))
    assert result == members

# Generated at 2022-06-23 21:20:51.409755
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    expected_list = [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'transport',
        'unit_system',
    ]

    obtained_list = g.__dir__()
    assert len(obtained_list) == len(expected_list)

    for item in obtained_list:
        assert item in expected_list


# Generated at 2022-06-23 21:20:58.093188
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers of class Generic."""
    import unittest.mock as mock
    from mimesis.providers.base import BaseProvider

    class MyProvider(BaseProvider):
        def foo(self):
            return 'bar'

    class MyProvider2(BaseProvider):
        def foo2(self):
            return 'bar'

    g = Generic()
    g.add_providers(MyProvider, MyProvider2)
    assert isinstance(g.myprovider, MyProvider)
    assert isinstance(g.myprovider2, MyProvider2)
    assert g.myprovider.foo() == g.myprovider2.foo2()



# Generated at 2022-06-23 21:21:07.642274
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime

    g = Generic('ru')
    assert g.locale == 'ru'
    assert g.seed is not None

    assert g.choice is not None
    assert g.structure is not None
    assert g.cryptographic is not None
    assert g.payment is not None
    assert g.path is not None
    assert g.internet is not None
    assert g.clothing is not None
    assert g.hardware is not None
    assert g.development is not None
    assert g.numbers is not None
    assert g.file is not None
    assert g.unit_system is not None

# Generated at 2022-06-23 21:21:16.203688
# Unit test for constructor of class Generic
def test_Generic():
    test=Generic()
    assert test._person.__class__.__module__=='mimesis.providers.person'
    assert test._address.__class__.__module__=='mimesis.providers.address'
    assert test._datetime.__class__.__module__=='mimesis.providers.date'
    assert test._business.__class__.__module__=='mimesis.providers.business'
    assert test._text.__class__.__module__=='mimesis.providers.text'
    assert test._food.__class__.__module__=='mimesis.providers.food'
    assert test._science.__class__.__module__=='mimesis.providers.science'

# Generated at 2022-06-23 21:21:23.969734
# Unit test for constructor of class Generic
def test_Generic():
    # initialize object
    g = Generic()

    # test attributes
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None

# Generated at 2022-06-23 21:21:33.062006
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # This function should not return an error
    a = Generic('en')
    a.person
    a.address
    a.datetime
    a.business
    a.text
    a.food
    a.science
    a.transport
    a.code
    a.unit_system
    a.file
    a.numbers
    a.development
    a.hardware
    a.clothing
    a.internet
    a.path
    a.payment
    a.cryptographic
    a.structure
    a.choice
    
    

# Generated at 2022-06-23 21:21:38.715802
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    generic = Generic(seed=12345)
    assert 'custom' not in dir(generic)
    generic.add_provider(CustomProvider)
    assert 'custom' in dir(generic)
    assert generic.custom.foo() == 'bar'


# Generated at 2022-06-23 21:21:46.257203
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.providers.manga import Manga
    from mimesis.providers.pokemon import Pokemon
    from mimesis.providers.video_game import VideoGame

    g = Generic()
    g.add_providers(Manga, Pokemon, VideoGame)

    assert 'manga' in dir(g)
    assert 'pokemon' in dir(g)
    assert 'video_game' in dir(g)

# Generated at 2022-06-23 21:21:47.799722
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert type(generic) is Generic


# Generated at 2022-06-23 21:21:56.270723
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.development import Development
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.system import System
   
    gen = Generic()
    custom_providers = (Development, Internet, Person, System)
    gen.add_providers(*custom_providers)
    assert isinstance(gen.system, System)
    assert isinstance(gen.development, Development)
    assert isinstance(gen.internet, Internet)
    assert isinstance(gen.person, Person)


# Generated at 2022-06-23 21:22:04.058156
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import os
    import sys
    sys.path.append(os.path.join(os.path.abspath(os.path.dirname(__file__)), '../'))

    from mimesis.providers.nature import Nature
    nature = Nature()
    import json
    d = json.loads(nature.serialize())
    assert set(['nature']) == set(d.keys())


# Generated at 2022-06-23 21:22:16.436863
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('ru')
    assert len(generic.__dir__()) == 49
    assert 'person' in generic.__dir__()
    assert 'address' in generic.__dir__()
    assert 'datetime' in generic.__dir__()
    assert 'business' in generic.__dir__()
    assert 'text' in generic.__dir__()
    assert 'food' in generic.__dir__()
    assert 'science' in generic.__dir__()
    assert 'transport' in generic.__dir__()
    assert 'code' in generic.__dir__()
    assert 'unit_system' in generic.__dir__()
    assert 'file' in generic.__dir__()
    assert 'numbers' in generic.__dir__()
    assert 'development' in generic.__dir__()

# Generated at 2022-06-23 21:22:18.016917
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic(random_data_provider=True)
    assert sorted(dir(a)) == sorted(__all__)

# Generated at 2022-06-23 21:22:29.315406
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'my_provider'

        def __init__(self, seed: Any = None, **kwargs: Any) -> None:
            super().__init__(seed=seed, **kwargs)
            self._words = self.data['words']

        def word(self) -> str:
            """Return random word."""
            return self.random.choice(self._words)

        def sentence(self, min_word: int = 1, max_word: int = 10) -> str:
            """Generate a random sentence.

            :param min_word: Min number of words in the sentence.
            :param max_word: Max number of words in the sentence.
            :return: Random sentence.
            """

# Generated at 2022-06-23 21:22:30.855472
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass



# Generated at 2022-06-23 21:22:38.769107
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'Test'

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test_provider2'

        def test_method(self):
            return 'Test'

    g = Generic()
    g.add_providers(TestProvider, TestProvider2)
    assert g.test_provider.test_method() == 'Test'
    assert g.test_provider2.test_method() == 'Test'

# Generated at 2022-06-23 21:22:42.710997
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MockProvider(BaseProvider):
        class Meta:
            name = 'mock'

        def __init__(self, seed):
            super().__init__(seed)
        def foo(self):
            return 42

    g = Generic()
    g.add_provider(MockProvider)

    assert g.mock.foo() == 42

# Generated at 2022-06-23 21:22:44.579473
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:22:46.411180
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.generic import Generic
    from mimesis.providers.text import Text
    generic = Generic()
    generic.add_providers(Text)
    assert 'text' in dir(generic)

# Generated at 2022-06-23 21:22:51.708930
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('en')
    try:
        generic.add_provider(int)
    except TypeError:
        assert True
    else:
        assert False
    try:
        generic.add_provider(Generic)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:22:55.445406
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen._person is not None
    assert gen._address is not None
    assert gen._datetime is not None
    assert gen._business is not None
    assert gen._text is not None
    assert gen._food is not None
    assert gen._science is not None

# Generated at 2022-06-23 21:23:00.155093
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')
    assert hasattr(g, 'business')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'text')
    assert hasattr(g, 'food')
    assert hasattr(g, 'science')



# Generated at 2022-06-23 21:23:03.205977
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def test(self):
            return "this is my provider"

    g = Generic()
    g.add_providers(MyProvider)

    assert hasattr(g, 'my_provider')
    assert g.my_provider

# Generated at 2022-06-23 21:23:07.570985
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.person import Person

    g = Generic()
    g.add_providers(Identifier, Person)

    assert g.identifier is not None
    assert g.person is not None


# Generated at 2022-06-23 21:23:16.306416
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    gen = Generic()
    gen.add_provider(Person)
    assert inspect.isclass(gen.person)
    gen.add_provider(Transport)
    assert inspect.isclass(gen.transport)
    gen.add_provider(Code)
    assert inspect.isclass(gen.code)
    gen.add_provider(UnitSystem)
    assert inspect.isclass(gen.unit_system)
    gen.add_provider(File)
    assert inspect.isclass(gen.file)
    gen.add_provider(Numbers)
    assert inspect.isclass(gen.numbers)
    gen.add_provider(Development)
    assert inspect.isclass(gen.development)
    gen.add_provider(Hardware)
   

# Generated at 2022-06-23 21:23:18.578108
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Generic.Meta)
    assert 'Meta' in generic


# Generated at 2022-06-23 21:23:19.485477
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == 35

# Generated at 2022-06-23 21:23:25.420404
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)

# Generated at 2022-06-23 21:23:30.311197
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geography import Geography
    from mimesis.providers.structure import Structure

    g = Generic()
    try:
        g.add_provider(Geography)
        g.add_provider(Structure)
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 21:23:32.999532
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    # Cache persons
    g.person
    assert hasattr(g, 'person')
    # No cache persons
    setattr(g, 'person', None)
    assert not hasattr(g, 'person')



# Generated at 2022-06-23 21:23:36.107208
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    from mimesis.providers.address import Address
    g = Generic()
    g.add_provider(Address)



# Generated at 2022-06-23 21:23:42.285624
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    assert obj.__dir__() == [
        'internet',
        'person',
        'datetime',
        'address',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]


# Generated at 2022-06-23 21:23:47.714490
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()

    assert gen.__dir__() == [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]

# Generated at 2022-06-23 21:23:55.517914
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)


# Generated at 2022-06-23 21:23:59.883141
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic()
    print(generic.generic.__dict__)
    print(generic.person.__dict__)
    print(generic.address)
    print(generic.datetime)


# Generated at 2022-06-23 21:24:00.399995
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:24:05.029900
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

        def car(self):
            return 'car'

    mimesis.add_provider(Provider)
    assert isinstance(mimesis.custom_provider, Provider)
    assert mimesis.custom_provider.car() == 'car'



# Generated at 2022-06-23 21:24:11.478515
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'text')
    assert hasattr(generic, 'food')
    assert hasattr(generic, 'science')


# Generated at 2022-06-23 21:24:15.602272
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers of class Generic."""
    generic = Generic('en')
    providers = [Person, Address, Datetime]
    generic.add_providers(*providers)
    assert 'person' in generic.__dict__ and \
           'address' in generic.__dict__ and \
           'datetime' in generic.__dict__


# Generated at 2022-06-23 21:24:21.603791
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider of Generic class."""
    provider = Generic()
    assert not hasattr(provider, 'test_attribute')
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_attribute'
    provider.add_provider(TestProvider)
    assert provider.test_attribute
    assert provider.test_attribute == provider.test_attribute


# Generated at 2022-06-23 21:24:28.655495
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

    class CustomProvider2(BaseProvider):
        class Meta:
            name = 'custom_provider2'

    provider = Generic()
    provider.add_provider(CustomProvider)

    assert isinstance(provider.custom_provider, CustomProvider) is True

    provider.add_providers(CustomProvider, CustomProvider2)

    assert isinstance(provider.custom_provider, CustomProvider) is True
    assert isinstance(provider.custom_provider2, CustomProvider2) is True

# Generated at 2022-06-23 21:24:31.060531
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    str_ = "Generic()"
    assert str(generic) == str_ or repr(generic) == str_


# Generated at 2022-06-23 21:24:32.982822
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic.person.full_name() == 'Ms. Hannah Smith'

# Generated at 2022-06-23 21:24:40.516869
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class A(BaseProvider):

        class Meta:
            name = 'a'

        def __str__(self):
            return self.meta.name

    class B(BaseProvider):

        class Meta:
            name = 'b'

        def __str__(self):
            return self.meta.name

    class C(BaseProvider):

        class Meta:
            name = 'c'

        def __str__(self):
            return self.meta.name

    gen = Generic()
    gen.add_providers(A, B, C)

    assert gen.a == 'a'
    assert gen.b == 'b'
    assert gen.c == 'c'

# Generated at 2022-06-23 21:24:42.171114
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic().__dict__.keys() == dir(Generic())



# Generated at 2022-06-23 21:24:45.465713
# Unit test for constructor of class Generic
def test_Generic():
    # Check class Generic
    assert isinstance(Generic(), Generic)
    assert isinstance(Generic('en'), Generic)
    assert isinstance(Generic('en', 42), Generic)


# Generated at 2022-06-23 21:24:52.089497
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    gen = Generic()
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.business, Business)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)



# Generated at 2022-06-23 21:24:53.217422
# Unit test for constructor of class Generic
def test_Generic():
    try:
        generic = Generic('en')
        print(generic)
    except Exception as e:
        print(e)

# Generated at 2022-06-23 21:25:02.731742
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    class TestProvider(BaseProvider):
        """Class for test provider."""

        class Meta:
            """Class for metadata."""

            name = 'test'

        def get_name(self) -> str:
            """Get name.

            :return: Name.
            """
            return self.random.get_item(['Name1', 'Name2'])

    test_provider = TestProvider()
    generic = Generic()
    generic.add_provider(test_provider)

    assert generic.test.get_name() == 'Name1' or \
        generic.test.get_name() == 'Name2'

    try:
        generic.add_provider('str')
    except TypeError:
        pass



# Generated at 2022-06-23 21:25:05.305803
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers method of class Generic."""
    gen = Generic().add_providers(Person)
    assert 'person' in gen.__dir__()



# Generated at 2022-06-23 21:25:12.731375
# Unit test for constructor of class Generic
def test_Generic():
   d = Generic(seed=42)
   assert d.unit_system is not None
   assert d.file is not None
   assert d.numbers is not None
   assert d.development is not None
   assert d.hardware is not None
   assert d.clothing is not None
   assert d.internet is not None
   assert d.path is not None
   assert d.payment is not None
   assert d.cryptographic is not None
   assert d.structure is not None
   assert d.choice is not None



# Generated at 2022-06-23 21:25:19.742113
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create a new instance of class Generic
    gen = Generic()
    # Create a custom provider
    class Provider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            """Class for metadata."""
            name = 'provider'

        def method(self):
            return 'method'
    # Add a custom provider
    gen.add_provider(Provider)
    # Assert it
    assert gen.provider.method() == 'method'
    # Create a custom provider
    class AnotherProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            """Class for metadata."""

# Generated at 2022-06-23 21:25:29.318838
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Unit test for method __getattr__ of class Generic
    g = Generic('ru')
    assert hasattr(g, '_person') is True
    assert hasattr(g, '_address') is True
    assert hasattr(g, '_datetime') is True
    assert hasattr(g, '_business') is True
    assert hasattr(g, '_text') is True
    assert hasattr(g, '_food') is True
    assert hasattr(g, '_science') is True

    assert hasattr(g, 'person') is True
    assert hasattr(g, 'address') is True
    assert hasattr(g, 'datetime') is True
    assert hasattr(g, 'business') is True
    assert hasattr(g, 'text') is True
    assert hasattr(g, 'food') is True

# Generated at 2022-06-23 21:25:41.281689
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test all attributes of Generic class."""
    generic = Generic('en')
    attributes = [method for method in dir(generic) if
                  callable(getattr(generic, method))]
    expected = [
        'add_provider',
        'add_providers',
        'address',
        'business',
        'code',
        'clothing',
        'choice',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'text',
        'transport',
        'unit_system',
    ]

    assert attributes == expected

# Generated at 2022-06-23 21:25:43.199346
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__(self, attrname: str) -> Any."""
    assert Generic().address.province() == 'CA'

# Generated at 2022-06-23 21:25:50.068205
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person

    class CustomProvider(BaseProvider):
        pass

    obj = Generic()
    before = dir(obj)
    obj.add_provider(CustomProvider)
    after = dir(obj)
    assert len(after) == len(before) + 1
    assert 'custom_provider' in after
    obj.add_providers(Person)
    after = dir(obj)
    assert 'person' in after



# Generated at 2022-06-23 21:26:00.099134
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic
    """

    generic_provider = Generic()
    assert generic_provider.__class__.__name__ == 'Generic'
    assert generic_provider.seed is not None
    assert generic_provider.person is not None
    assert generic_provider.address is not None
    assert generic_provider.datetime is not None
    assert generic_provider.business is not None
    assert generic_provider.text is not None
    assert generic_provider.food is not None
    assert generic_provider.science is not None
    assert generic_provider.transport is not None
    assert generic_provider.code is not None
    assert generic_provider.unit_system is not None
    assert generic_provider.file is not None

# Generated at 2022-06-23 21:26:03.125210
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.address import Address
    generic = Generic('en')
    assert isinstance(generic.address, Address)


# Generated at 2022-06-23 21:26:11.268749
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.misc import Misc
    from mimesis.providers.misc import _Misc
    from mimesis.providers.numbers import _Numbers

    misc = Misc(seed=1)
    g = Generic(seed=1)
    g.add_providers(misc.__class__)

    attrs = dir(g)
    assert 'misc' in attrs
    assert isinstance(getattr(g, 'misc'), _Misc)
    assert not isinstance(getattr(g, 'misc'), _Numbers)
    assert isinstance(getattr(g, 'numbers'), _Numbers)


# Generated at 2022-06-23 21:26:14.649595
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.cryptographic import Cryptographic
    g = Generic(seed=42)
    g.add_providers(Cryptographic)
    assert g.cryptographic


# Generated at 2022-06-23 21:26:20.756599
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.unit import Unit

    u = Generic()
    assert not hasattr(u, 'unit')
    u.add_provider(Unit)
    assert hasattr(u, 'unit')
    assert(u.unit.distance() != u.unit.distance())


# Generated at 2022-06-23 21:26:23.589517
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    actual = Generic()
    expected = list(set(dir(actual)).difference(dir(object)))
    actual_dir = actual.__dir__()

    for e in expected:
        assert e in actual_dir

# Generated at 2022-06-23 21:26:27.226279
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for __dir__ of Generic class."""
    gen = Generic()
    g_d = gen.__dir__()
    d_p = gen.data_providers
    assert sorted(g_d) == sorted(d_p)

# Generated at 2022-06-23 21:26:31.004840
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    for attr in dir(provider):
        value = getattr(provider, attr)
        if attr != "Meta":
            assert isinstance(value, BaseDataProvider)

# Generated at 2022-06-23 21:26:35.838902
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    providers = [
         Person,
         Address,
         Datetime,
         Business,
         Text,
         Food,
         Science
    ]
    g = Generic()

    for p in providers:
        if p.Meta.name:
            assert hasattr(g, p.Meta.name)

# Generated at 2022-06-23 21:26:42.854283
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert 'datetime' in dir(generic)
    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'business' in dir(generic)
    assert 'food' in dir(generic)
    assert 'text' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)
    assert 'clothing' in dir(generic)
    assert 'internet' in dir(generic)
    assert 'path' in dir(generic)

# Generated at 2022-06-23 21:26:44.479504
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person)



# Generated at 2022-06-23 21:26:52.058722
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()

    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def my_method(self) -> int:
            return 1

    class MySecondProvider(BaseProvider):
        class Meta:
            name = 'my_second_provider'

        def my_second_method(self) -> str:
            return 'Hello'

    providers = (MyProvider, MySecondProvider)

    gen.add_providers(*providers)

    assert callable(gen.my_provider)
    assert callable(gen.my_second_provider)

    assert gen.my_provider.my_method() == 1
    assert gen.my_second_provider.my_second_method() == 'Hello'

# Generated at 2022-06-23 21:26:55.075076
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [Person, Address]
    generic = Generic()
    generic.add_providers(*providers)
    for provider in providers:
        assert provider.__name__.lower() in dir(generic)

# Generated at 2022-06-23 21:26:56.899806
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert generic.person().full_name()
    generic.full_name()

# Generated at 2022-06-23 21:27:04.326395
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic(seed=123)
    class NewProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def method_1(self):
            return 'BlaBlaBla'

        class Meta:
            name = 'new_provider'
    g.add_provider(NewProvider)
    assert g.new_provider.method_1() == 'BlaBlaBla'


# Integration test for method add_provider of class Generic

# Generated at 2022-06-23 21:27:06.176250
# Unit test for constructor of class Generic
def test_Generic():
    obj_01 = Generic()
    _obj_01 = obj_01.person
    assert isinstance(_obj_01, Person)

# Generated at 2022-06-23 21:27:14.600552
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    class Meta:
        name = 'person'

    class Location(Address):
        class Meta:
            name = 'location'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    generic = Generic('en')
    generic.add_providers(Location, Person)

    assert hasattr(generic, 'person')
    assert hasattr(generic, 'location')
    assert generic.location.city() != generic.person.city()



# Generated at 2022-06-23 21:27:23.764995
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=42)
    assert generic.business.business_identifier() == '494703267'
    assert generic.business.isbn() == '49-598-2811-7'
    assert generic.business.credit_card_number() == '8434-1330-3240-5931'
    assert generic.person.username() == 'marcus.schneider'
    assert generic.structure.guid() == '8a4a4b4f-3569-4a52-9ea2-7a1a2e16cf0d'
    assert generic.person.social_security_number() == '597-47-0243'
    assert generic.datetime.datetime() == '1985-08-24 07:37:19'

# Generated at 2022-06-23 21:27:29.767557
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic(seed=42)
    custom_provider = type('CustomProvider', (BaseProvider,), {'Meta': type('Meta',(),{'name':'custom_provider'})})
    generic.add_provider(custom_provider)
    assert 'custom_provider' in generic.__dict__
    #assert 'custom_provider' in generic.__dir__() not working correctly in Python3.6


# Generated at 2022-06-23 21:27:40.847937
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'tp'

        def method_a(self):
            return 'a'

        def method_b(self):
            return 'b'

        def method_c(self):
            return 'c'

    class TestProvider1(BaseProvider):
        def method_d(self):
            return 'd'

        def method_e(self):
            return 'e'

    gen = Generic()

    gen.add_providers(TestProvider1)
    assert callable(getattr(gen, 'testprovider1'))
    assert callable(getattr(gen, 'testprovider1').method_d)
    assert callable(getattr(gen, 'testprovider1').method_e)

    gen = Generic()

# Generated at 2022-06-23 21:27:44.671463
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class NewProvider(BaseProvider):
        def function(self):
            return 'Test'
    generic = Generic()
    generic.add_provider(NewProvider)
    assert hasattr(generic, 'new_provider')

# Generated at 2022-06-23 21:27:47.209105
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.user import User
    g = Generic('en')
    g.add_provider(User)
    assert callable(g.user.__getattribute__('username'))


# Generated at 2022-06-23 21:27:48.748913
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    x = Generic()
    print(dir(x))

# Generated at 2022-06-23 21:27:54.909569
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    custom = Generic()
    custom.add_providers(Person, Address)
    custom_providers = dir(custom)
    print(custom_providers)

    assert 'address' in custom_providers
    assert 'person' in custom_providers
    assert 'address' not in dir(generic)
    assert 'person' not in dir(generic)

# Generated at 2022-06-23 21:28:03.007534
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """testing Generic add_providers method"""
    # Get the globals
    global Business
    global Text

    ## Creating a unique subclass of BaseProvider with a custom provider
    # This provider will generate random german names
    class GermanNamesProvider(BaseProvider):
        """Creates german names"""
        class Meta:
            """Abstract class for metadata"""
            name = 'german_names'
        def german_names():
            """Generate a german name"""
            return "Max Mustermann"
    ##

    class TestGeneric(Generic):
        """class used for testing"""
        pass

    test_generic = TestGeneric()
    # Testing business provider
    assert test_generic.business.__class__ == Business
    # Testing text provider
    assert test_generic.text.__class__ == Text
    # Trying to get a provider that

# Generated at 2022-06-23 21:28:08.562691
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers import color
    from mimesis.providers import name

    g = Generic()
    g.add_providers(color.Color, name.Name)

    assert hasattr(g, 'name')
    assert hasattr(g, 'color')

# Generated at 2022-06-23 21:28:11.559732
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert generic.address
    assert generic.datetime
    assert generic.business
    assert generic.text
    assert generic.food
    assert generic.science


# Generated at 2022-06-23 21:28:14.095043
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(g.choice.choices)
    print(g.development.programming_language())
if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:28:15.998194
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    data = Generic('nl-NL')
    data.add_provider(Code)
    assert 'code' in data.__dir__()
    assert isinstance(getattr(data, 'code'), Code)

# Generated at 2022-06-23 21:28:26.535693
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Base test
    p1 = Generic()
    p1.add_provider(Person)
    assert hasattr(p1, 'person')
    assert not hasattr(p1, '_person')
    # Base test
    p2 = Generic()
    p2.add_provider(Person)
    p2.add_provider(Address)
    assert hasattr(p2, 'person')
    assert not hasattr(p2, '_person')
    assert hasattr(p2, 'address')
    assert not hasattr(p2, '_address')
    # Exception test
    p3 = Generic()
    try:
        p3.add_provider('Person')
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 21:28:28.207408
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    for provider in g.__dir__():
        _ = getattr(g, provider)

# Generated at 2022-06-23 21:28:34.215627
# Unit test for constructor of class Generic
def test_Generic():
    """Test constructor of class Generic."""
    generic = Generic()
    assert generic.business is not None
    assert generic.person is not None
    assert generic.science is not None
    assert generic.file is not None
    assert generic.development is not None
    assert generic.choice is not None
    assert generic.hardware is not None
    assert generic.clothing is not None
    assert generic.internet is not None
    assert generic.path is not None
    assert generic.payment is not None
    assert generic.cryptographic is not None
    assert generic.structure is not None

# Generated at 2022-06-23 21:28:35.024045
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic


# Generated at 2022-06-23 21:28:37.952973
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    mimesis_generic = Generic('en')
    mimesis_generic.add_provider(MyProvider)
    assert mimesis_generic.myprovider.a() == 0


# Generated at 2022-06-23 21:28:39.136092
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    provider = Generic()
    provider.add_providers(Person, Address)
    assert provider.person is not None
    assert provider.address is not None

# Generated at 2022-06-23 21:28:41.432265
# Unit test for constructor of class Generic
def test_Generic():
    # TODO: Write unit tests for:
    # 1. Add one provider to Generic() object
    # 2. Add more than one provider to Generic() object
    pass

# Generated at 2022-06-23 21:28:45.290463
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test __dir__ of class Generic."""
    generic = Generic()
    assert 'Generic' == generic.__class__.__name__
    assert 'generic' == generic.Meta.name
    assert 'person' in dir(generic)

# Generated at 2022-06-23 21:28:53.118147
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test: Generic()
        Method: __dir__
    """
    g = Generic(seed=42)
    assert sorted(g.__dir__()) == sorted(['choice', 'address', 'file',
                                          'person', 'path', 'numbers',
                                          'payment', 'internet', 'code',
                                          'clothing', 'datetime', 'business',
                                          'transport', 'text', 'unit_system',
                                          'cryptographic', 'food', 'hardware',
                                          'science', 'development', 'structure'])

# Generated at 2022-06-23 21:28:54.824311
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert hasattr(g, 'person') == True
    assert hasattr(g, 'address') == True
    assert hasattr(g, 'food') == True

# Generated at 2022-06-23 21:28:56.189485
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)

# Generated at 2022-06-23 21:28:59.399806
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Check method __getattr__ of class Generic."""
    generic = Generic('en')
    assert generic.person.full_name() == generic.person().full_name()
    assert generic.person.full_name() == generic.person().full_name()



# Generated at 2022-06-23 21:29:03.640590
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        def foo(self):
            return "foo"

    generic = Generic()
    generic.add_provider(TestProvider)
    assert generic.testprovider.foo() == "foo"

#Unit test for method add_providers of class Generic

# Generated at 2022-06-23 21:29:04.505017
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    gen = Generic()
    print(gen.person)

# Generated at 2022-06-23 21:29:13.706406
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic.datetime
    assert generic.address
    assert generic.business
    assert generic.text
    assert generic.food
    assert generic.science
    assert generic.transport
    assert generic.code
    assert generic.unit_system
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic
    assert generic.structure
    assert generic.choice



# Generated at 2022-06-23 21:29:16.925726
# Unit test for constructor of class Generic
def test_Generic():
    """Test constructor of class Generic."""
    from mimesis.enums import Gender
    data = Generic('ru')
    assert data

    data = Generic(Gender.FEMALE)
    assert data


# Generated at 2022-06-23 21:29:19.405677
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.business.siren() != None


# Generated at 2022-06-23 21:29:26.118163
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider method of class Generic."""
    from mimesis.builtins import Person as CustomPerson

    obj = Generic('en')
    assert not hasattr(obj, 'person')
    assert not hasattr(obj, 'another')
    obj.add_provider(CustomPerson)
    assert hasattr(obj, 'person')
    assert not hasattr(obj, 'another')
    assert not hasattr(obj, 'another')

# Generated at 2022-06-23 21:29:36.499515
# Unit test for constructor of class Generic
def test_Generic():

    from mimesis.enums import Gender
    
    g = Generic()
    data = g.person.full_name('en') # example for Provider of Generic
    data = g.person.full_name('en', gender=Gender.FEMALE) # example for Provider.method() of Generic

    g.add_provider(CustomProvider)

    data = g.customprovider.some_method() # example for Provider of CustomProvider

    g.add_providers(CustomProvider1, CustomProvider2)

    data = g.customprovider1.some_method() # example for Provider of CustomProvider1
    data = g.customprovider2.some_method() # example for Provider of CustomProvider2

# Generated at 2022-06-23 21:29:38.493197
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    assert g.numbers is not None
    assert g.path is not None
    assert g.internet is not None


# Generated at 2022-06-23 21:29:42.187319
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Foo:
        pass

    g = Generic()
    g.add_provider(Foo)

    assert g._foo is None
    assert g.foo.__class__.__name__ == 'Foo'

