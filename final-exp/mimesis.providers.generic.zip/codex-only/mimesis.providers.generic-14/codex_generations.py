

# Generated at 2022-06-23 21:19:53.668967
# Unit test for constructor of class Generic
def test_Generic():
    # Create an instance of class Generic
    generic = Generic(seed=0)
    # Check the attribute locale
    locale = generic.locale
    assert locale == 'en'
    # Check the attribute seed
    seed = generic.seed
    assert seed == 0
    # Check the attribute __provider__
    provider = generic.provider
    assert provider == 'generic'
    # Check that the attribute _person is loaded
    person = generic._person
    assert person is not None
    assert isinstance(person, Person)
    # Check that the attribute _address is loaded
    address = generic._address
    assert address is not None
    assert isinstance(address, Address)
    # Check that the attribute _datetime is loaded
    datetime = generic._datetime
    assert datetime is not None
    assert isinstance(datetime, Datetime)


# Generated at 2022-06-23 21:20:00.162720
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.my_provider import MyCustomProvider

    provider = Generic()
    assert not hasattr(provider, 'my_custom_provider')

    provider.add_providers(MyCustomProvider)
    assert provider.my_custom_provider.__class__.__name__ == 'MyCustomProvider'

# Generated at 2022-06-23 21:20:02.985091
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    dir_ = generic.__dir__()
    assert dir_

    for a in dir_:
        assert not inspect.ismodule(getattr(generic, a))

# Generated at 2022-06-23 21:20:07.130685
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.test import TestData
    from mimesis.providers.test_two import TestDataTwo
    generic = Generic()
    assert generic.test is None
    assert generic.test_two is None
    generic.add_providers(TestData, TestDataTwo)
    assert generic.test is not None
    assert generic.test_two is not None

# Generated at 2022-06-23 21:20:10.352283
# Unit test for constructor of class Generic
def test_Generic():
    print("constructor of class Generic")
    gen = Generic()
    print(gen)
    print('\n')


# Generated at 2022-06-23 21:20:14.327894
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def method(self):
            return "string"

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.method() == "string"

# Generated at 2022-06-23 21:20:16.258242
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert generic.person is not None


# Generated at 2022-06-23 21:20:21.964617
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    class CustomProvider(BaseProvider):
        pass

    class CustomProvider1(BaseProvider):
        pass

    g = Generic()
    g.add_providers(CustomProvider, CustomProvider1)
    assert g.customprovider
    assert g.customprovider1

# Generated at 2022-06-23 21:20:31.268647
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    person = generic.person
    address = generic.address
    datetime = generic.datetime
    business = generic.business
    text = generic.text
    food = generic.food
    science = generic.science
    transport = generic.transport
    code = generic.code
    file = generic.file
    numbers = generic.numbers
    development = generic.development
    hardware = generic.hardware
    clothing = generic.clothing
    internet = generic.internet
    path = generic.path
    payment = generic.payment
    cryptographic = generic.cryptographic
    structure = generic.structure
    choice = generic.choice
    assert isinstance(person, Person)
    assert isinstance(address, Address)
    assert isinstance(datetime, Datetime)
    assert isinstance(business, Business)

# Generated at 2022-06-23 21:20:33.381417
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()

    assert generic is not None
    assert hasattr(generic, 'person')

# Generated at 2022-06-23 21:20:39.780447
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        def do_something(self):
            return 'Hello'

    class AnotherProvider(BaseProvider):
        def do_something_else(self):
            return 'World'

    gen = Generic()
    gen.add_providers(MyProvider, AnotherProvider)

    assert gen.my_provider.do_something() == 'Hello'
    assert gen.another_provider.do_something_else() == 'World'

# Generated at 2022-06-23 21:20:46.124739
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    @dataclass
    class CustomProvider(BaseProvider):
        @classmethod
        def custom_method(cls) -> str:
            return 'custom method'

    sp = Generic().add_provider(CustomProvider)
    c = sp.custom_method()
    assert c == 'custom method'

    sp = Generic()
    assert sp.custom_method() == 'custom method'
    assert hasattr(sp, 'custom_provider') is True



# Generated at 2022-06-23 21:20:47.676647
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en')
    assert g.__class__.__name__ == 'Generic'

# Generated at 2022-06-23 21:20:55.214439
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    a = Generic()
    providers = [
        Generic,
        Generic,
        Generic,
    ]
    a.add_providers(*providers)
    assert set(dir(a)) == {
        'add_provider',
        'add_providers',
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'person',
        'payment',
        'science',
        'structure',
        'transport',
        'unit_system',
        'text',
    }
    assert 'generic' in set(dir(a))


# Generated at 2022-06-23 21:20:57.246671
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person = g.person()
    assert isinstance(g.person, Person)

# Generated at 2022-06-23 21:21:02.461216
# Unit test for constructor of class Generic
def test_Generic():
    # Input parameters
    # Expected results
    # The result we got
    # Is it correct?

    # pylint: disable=no-member,unused-argument
    gen = Generic()
    assert hasattr(gen, 'business')
    assert hasattr(gen, 'code')
    assert hasattr(gen, 'clothing')
    assert hasattr(gen, 'cryptographic')
    assert hasattr(gen, 'datetime')
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'food')
    assert hasattr(gen, 'hardware')
    assert hasattr(gen, 'internet')
    assert hasattr(gen, 'numbers')
    assert hasattr(gen, 'path')
    assert hasattr(gen, 'person')
    assert hasattr(gen, 'payment')
    assert has

# Generated at 2022-06-23 21:21:11.265345
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider

    class Test(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(Test)
    assert hasattr(generic, 'test')

    class Test(BaseProvider):
        class Meta:
            name = 'test_provider'

    generic = Generic()
    generic.add_provider(Test)
    assert hasattr(generic, 'test_provider')

    try:
        generic.add_provider(list)
    except TypeError:
        pass


# Generated at 2022-06-23 21:21:16.285594
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.base import BaseProvider
    
    class ExtendedProvider(BaseProvider):
        def __init__(self):
            super().__init__()
        
        def say(self, obj: Field = None, value: str = None) -> str:
            return "Hello World"
    
    g = Generic()
    g.add_provider(ExtendedProvider)
    assert g.say() == "Hello World"

# Generated at 2022-06-23 21:21:17.223985
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:21:21.056035
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert generic.business is not None
    assert generic.address is not None
    assert generic.datetime is not None
    assert generic.text is not None
    assert generic.food is not None
    assert generic.science is not None

# Generated at 2022-06-23 21:21:27.813511
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    example_provider = Generic()
    assert 'person' in dir(example_provider)
    assert 'address' in dir(example_provider)
    assert 'datetime' in dir(example_provider)
    assert 'business' in dir(example_provider)
    example_provider.add_provider(Payment)
    assert 'payment' in dir(example_provider)
    example_provider.add_provider(Cryptographic)
    assert 'cryptographic' in dir(example_provider)


# Generated at 2022-06-23 21:21:29.748370
# Unit test for constructor of class Generic
def test_Generic():
    # Test without params
    gen = Generic()  # pylint: disable=no-member
    assert gen.seed == gen.__initial_seed__

# Generated at 2022-06-23 21:21:37.100755
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def foo(self) -> str:
            return "foo"

        def bar(self) -> str:
            return "bar"

    gen = Generic()
    gen.add_provider(CustomProvider)

    assert hasattr(gen, 'custom_provider')
    assert hasattr(gen, 'custom_provider')

    gen = Generic()
    assert not hasattr(gen, 'custom_provider')


# Generated at 2022-06-23 21:21:48.360862
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__."""
    g = Generic()
    dir_list = list(g.__dir__())
    assert dir_list != []
    assert '__dict__' in dir_list
    assert '__weakref__' in dir_list
    assert 'Meta' in dir_list
    assert 'Meta' in dir_list
    assert '__getattribute__' in dir_list
    assert '__setattr__' in dir_list
    assert '__delattr__' in dir_list
    assert '__format__' in dir_list
    assert '__ge__' in dir_list
    assert '__gt__' in dir_list
    assert '__hash__' in dir_list
    assert '__le__' in dir_list
    assert '__lt__' in dir_list

# Generated at 2022-06-23 21:21:52.143299
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    a = gen.person.full_name()
    b = gen.Person().full_name()
    assert a == b, "Error in __getattr__ method of class Generic"


# Generated at 2022-06-23 21:21:55.794659
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseDataProvider):
        class Meta:
            name = 'customprovider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class CustomProvider2(BaseDataProvider):
        class Meta:
            name = 'customprovider2'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    generic = Generi

# Generated at 2022-06-23 21:22:04.074547
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    dp1 = Generic()
    dp1.add_providers(Person, Address, Datetime)
    dp2 = Generic()
    dp2.add_providers(Datetime, ABBA)
    assert dp1.person.full_name() != None
    assert dp1.address.address() != None
    assert dp1.datetime.date() != None
    assert dp2.datetime.date() != None
    assert hasattr(dp2, 'abba') == True
    assert getattr(dp2, 'abba').__class__.__name__ == 'ABBA'
    try:
        dp2.add_providers(ABBA())
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 21:22:16.437181
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from typing import Type
    from mimesis.providers.lorem import Lorem
    gen = Generic()
    # Check if add_provider raise TypeError if provder isn't class.
    try:  # type: ignore
        gen.add_provider(1)
    except TypeError as e:
        assert str(e) == 'The provider must be a class'
    except Exception:
        assert False
    try:  # type: ignore
        gen.add_provider('string')
    except TypeError as e:
        assert str(e) == 'The provider must be a class'
    except Exception:
        assert False
    # Check if add_provider raise TypeError if provder isn't a subclass of
    # BaseProvider

# Generated at 2022-06-23 21:22:24.320207
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    gen = Generic()
    gen.add_providers(Person, Address, Business)
    assert hasattr(gen, 'person') is True
    assert hasattr(gen, 'address') is True
    assert hasattr(gen, 'business') is True

# Generated at 2022-06-23 21:22:28.453390
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.lorem import Lorem
    gen = Generic()
    assert hasattr(gen, 'lorem') is False
    gen.add_provider(Lorem)
    assert hasattr(gen, 'lorem') is True
    gen.add_provider(Generic)



# Generated at 2022-06-23 21:22:40.209776
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit-test for method add_provider of class Generic

    :return: None
    """
    from mimesis.validators import Pattern
    from mimesis.providers.personal import Personal

    class CustomProvider(BaseProvider):
        """Custom provider class."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider'

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            # pylint: disable=W0231
            super().__init__(*args, **kwargs)
            self.__datafile = 'custom_data.json'
            self.pattern = Pattern(seed=self.seed)

        def get_detail(self):
            """Get detail.

            :return: str
            """
            return 'Custom provider'

# Generated at 2022-06-23 21:22:42.754296
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """ """
    g = Generic(seed=1)
    print(g.__dir__())
    print(g.__getattr__('datetime').__dir__())


if __name__ == '__main__':
    test_Generic___dir__()

# Generated at 2022-06-23 21:22:55.274312
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    
    from mimesis.providers.science import Science
    from mimesis.providers.structure import Structure
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.date import Datetime
    from mimesis.enums import Gender, Weekday
    from mimesis.builtins import range_
    
    
    
    
    
    
    
    
    
        
    food = Food(seed=0)
    food_1 = Food(seed=0)
    assert food._generator.random == food_1._generator.random
    assert food.ve

# Generated at 2022-06-23 21:23:05.997143
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.internet import Internet
    from mimesis.providers.base import BaseProvider

    class MyInternet(Internet):
        class Meta:
            name = 'my_internet'

    class MyBase(BaseProvider):
        class Meta:
            name = 'my_base'

        def get_nothing(self) -> None:
            pass

    # Class is not subclass of BaseProvider
    try:
        Generic().add_provider(MyBase)
    except TypeError:
        pass
    else:
        assert False

    # Object is not class
    try:
        Generic().add_provider(MyInternet)
    except TypeError:
        pass
    else:
        assert False

    # Adding or deleting class from default providers

# Generated at 2022-06-23 21:23:09.984629
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def __call__(self, *args, **kwargs):
            return 'Custom'

    providers = (CustomProvider, CustomProvider)

    g = Generic()
    g.add_providers(*providers)

    assert hasattr(g, 'custom')
    assert hasattr(g, 'custom_1')

    assert g.custom() == 'Custom'
    assert g.custom_1() == 'Custom'

# Generated at 2022-06-23 21:23:18.033492
# Unit test for constructor of class Generic
def test_Generic():
    """Test class Generic.
    """
    generic = Generic()
    assert hasattr(
        generic, 'person')
    assert hasattr(
        generic, 'address')
    assert hasattr(
        generic, 'datetime')
    assert hasattr(
        generic, 'business')
    assert hasattr(
        generic, 'text')
    assert hasattr(
        generic, 'food')
    assert hasattr(
        generic, 'science')
    assert hasattr(
        generic, 'transport')
    assert hasattr(
        generic, 'code')
    assert hasattr(
        generic, 'unit_system')
    assert hasattr(
        generic, 'file')
    assert hasattr(
        generic, 'numbers')
    assert hasattr(
        generic, 'development')

# Generated at 2022-06-23 21:23:19.711135
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test the method __getattr__."""
    gen = Generic('ru')

    gender = getattr(gen, 'gender')()
    name = getattr(gen, 'name')()

    assert gender in ['Male', 'Female', None]
    assert type(name) == str



# Generated at 2022-06-23 21:23:20.901805
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    test = Generic()
    assert isinstance(test.__dir__(),list)
    assert isinstance(test.__dir__(),list)

# Generated at 2022-06-23 21:23:25.919955
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('ru')
    assert 'development' in dir(generic)
    assert isinstance(generic.development, Development)
    assert generic.development.seed == generic.seed
    assert generic.development.locale == generic.locale

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)

        def method(self) -> None:
            pass

    generic.add_provider(CustomProvider)
    assert 'custom' in dir(generic)
    assert isinstance(generic.custom, CustomProvider)
    assert generic.custom.seed == generic.seed
    assert generic.custom.locale == generic.locale

# Generated at 2022-06-23 21:23:34.716810
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g

    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.internet, Internet)
    assert isinstance(g.path, Path)
    assert isinstance(g.payment, Payment)
    assert isinstance(g.cryptographic, Cryptographic)
    assert isinstance(g.structure, Structure)
    assert isinstance(g.choice, Choice)

# Generated at 2022-06-23 21:23:38.166670
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    def add_test_providers(custom_provider: Type[BaseProvider]) -> None:
        generic.add_provider(custom_provider)

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

    generic = Generic()
    add_test_providers(CustomProvider)

    assert generic.custom_provider

# Generated at 2022-06-23 21:23:46.818914
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    c = Generic()
    assert 'person' in c.__dir__()
    assert 'address' in c.__dir__()
    assert 'datetime' in c.__dir__()
    assert 'business' in c.__dir__()
    assert 'text' in c.__dir__()
    assert 'food' in c.__dir__()
    assert 'science' in c.__dir__()
    assert 'transport' in c.__dir__()
    assert 'code' in c.__dir__()
    assert 'unit_system' in c.__dir__()
    assert 'file' in c.__dir__()
    assert 'numbers' in c.__dir__()
    assert 'development' in c.__dir__()
    assert 'hardware' in c.__dir__()

# Generated at 2022-06-23 21:23:55.722930
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self, *args, **kwargs):
            return True

    class AnotherTest(BaseProvider):
        class Meta:
            name = 'another_test'

        def bar(self, *args, **kwargs):
            return True

    data = Generic('en')
    # result of adding provider Test
    data.add_provider(Test)
    # result of adding provider AnotherTest
    data.add_provider(AnotherTest)

    assert data.test.foo() is True
    assert data.another_test.bar() is True

# Generated at 2022-06-23 21:24:01.902674
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers of class Generic."""
    from mimesis.data import PROVIDERS_PACKAGE
    from mimesis.providers.finance import Finance
    from mimesis.providers.place import Place
    from mimesis.providers.system import System

    generic = Generic('en')

    providers = [
        Finance,
        Place,
        System
    ]

    generic.add_providers(*providers)

    assert hasattr(generic, 'finance')
    assert hasattr(generic, 'place')
    assert hasattr(generic, 'system')

    # Create all providers

# Generated at 2022-06-23 21:24:08.306667
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        """ Custom provider class. """

        class Meta:
            """ Class for metadata. """

            name = 'custom_provider'

        def get_custom_attribute(self) -> str:
            """ Generate custom attribute. """
            return self.random.choice(['foo', 'bar'])

    providers = (
        CustomProvider,
        CustomProvider,
        CustomProvider,
    )
    generic = Generic()
    generic.add_providers(*providers)

    assert len(generic.__dict__) == len(providers) + 1
    assert hasattr(generic, 'custom_provider')

    for provider in providers:
        assert isinstance(getattr(generic, provider.Meta.name), provider)


# Generated at 2022-06-23 21:24:10.410795
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Business())
    assert 'business' in g.__dict__

# Generated at 2022-06-23 21:24:16.828121
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert (
        Generic.__dir__(Generic(seed=42)) == [
            'address',
            'add_provider',
            'add_providers',
            'business',
            'choice',
            'clothing',
            'code',
            'cryptographic',
            'datetime',
            'development',
            'file',
            'food',
            'hardware',
            'internet',
            'numbers',
            'path',
            'payment',
            'person',
            'science',
            'structure',
            'transport',
            'unit_system',
            'text',
        ]
    )

# Generated at 2022-06-23 21:24:21.737248
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print("in test def")
    test_obj = Generic()
    test_obj.add_provider(Generic)
    print("test object add provider")
    # print(test_obj.person.full_name())
    # print(test_obj.person.full_name())


# Generated at 2022-06-23 21:24:28.162905
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.builtins import UnitTest

    providers = []
    for _ in range(5):
        gen = UnitTest()
        provider = gen.simple('provider')
        providers.append(provider)
    parent = Generic(seed=1)
    parent.add_providers(*providers)
    for p in providers:
        assert hasattr(parent, p)


__all__.extend(Generic.__all__)

# Generated at 2022-06-23 21:24:35.980682
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test to get attribute without underscore."""
    g = Generic()

    assert g.food
    assert g.code
    assert g.code.words
    assert g.code.variables
    assert g.code.classes
    assert g.code.python
    assert g.code.java
    assert g.code.cpp
    assert g.code.csharp
    assert g.code.cpp.classes
    assert g.code.cpp.functions
    assert g.code.cpp.namespaces
    assert g.code.cpp.structures
    assert g.code.cpp.variables


# Generated at 2022-06-23 21:24:43.138608
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text
    from mimesis.providers.science import Science
    from mimesis.providers.clothing import Clothing

    class RandomClass(BaseProvider):
        class Meta:
            name = 'test'

        def random_method(self):
            return 'test'

    # Add a valid custom provider
    generic = Generic('en')
    generic.add_provider(RandomClass)
    assert generic.test.random_method() == 'test'

    # Add a not valid custom provider
    try:
        generic.add_provider('non_valid')
    except TypeError:
        pass
    else:
        raise TypeError


# Generated at 2022-06-23 21:24:52.733029
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    data = Generic()
    data.add_providers(
        Person,
        Address,
        Payment,
        File,
        Numbers
    )
    assert data.__dict__['person']
    assert data.__dict__['address']
    assert data.__dict__['payment']
    assert data.__dict__['file']
    assert data.__dict__['numbers']


# Generated at 2022-06-23 21:24:54.471220
# Unit test for constructor of class Generic
def test_Generic():
    obj1 = Generic()
    assert isinstance(obj1, Generic)

# Generated at 2022-06-23 21:24:58.742673
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Test with empty method
    expected = ['choice', 'code', 'clothing', 'cryptographic',
                'development', 'file', 'food', 'hardware',
                'internet', 'numbers', 'path', 'payment',
                'science', 'structure', 'transport', 'unit_system']
    assert Generic().__dir__() == expected

# Generated at 2022-06-23 21:25:01.083901
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test which add a custom provider."""
    generic = Generic()
    generic.add_provider(BaseDataProvider)
    assert hasattr(generic, 'base_data_provider')

# Generated at 2022-06-23 21:25:05.984486
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic._person, Person)
    assert isinstance(generic._address, Address)
    assert isinstance(generic._datetime, Datetime)
    assert isinstance(generic._business, Business)
    assert isinstance(generic._science, Science)
    assert generic.__dict__['_person'].__dict__['formatter']
    assert not generic.__dict__['_address'].__dict__['formatter']


# Generated at 2022-06-23 21:25:08.920542
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    attrs = gen.__dir__()
    assert isinstance(attrs, list)
    assert len(attrs) == 35



# Generated at 2022-06-23 21:25:17.468986
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=1)
    assert g._person.__class__.__name__ == 'Person'
    assert g._person.__class__.__name__ == 'Person'
    assert g.person.__class__.__name__ == 'Person'
    g.person.__class__.__name__ == 'Person'
    assert g.__dict__['_person'].__class__.__name__ == 'Person'
    assert g.__dict__['person'].__class__.__name__ == 'Person'
    assert g.__dict__['_address'].__class__.__name__ == 'Address'
    assert g.__dict__['address'].__class__.__name__ == 'Address'

# Generated at 2022-06-23 21:25:26.298506
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    attrs = [
        'add_provider',
        'add_providers',
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'payment',
        'person',
        'path',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]
    assert obj.__dir__() == attrs

# Generated at 2022-06-23 21:25:28.176381
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for the method __getattr__ of class Generic"""
    generic = Generic()
    generic._person()
    generic.person


# Generated at 2022-06-23 21:25:30.573027
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.numbers import Numbers as Number
    g = Generic()
    g.add_provider(Number)
    assert isinstance(g.numbers, Number)



# Generated at 2022-06-23 21:25:35.883516
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)

    g = Generic()
    assert isinstance(g.address, Address)

    g = Generic()
    assert isinstance(g.datetime, Datetime)

    g = Generic()
    assert isinstance(g.business, Business)

    g = Generic()
    assert isinstance(g.text, Text)

    g = Generic()
    assert isinstance(g.food, Food)

    g = Generic()
    assert isinstance(g.science, Science)

    g = Generic()
    assert isinstance(g.transport, Transport)

    g = Generic()
    assert isinstance(g.code, Code)

    g = Generic()
    assert isinstance(g.unit_system, UnitSystem)

    g = Generic()

# Generated at 2022-06-23 21:25:45.495524
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    g = Generic()
    assert hasattr(g, 'add_provider')
    assert hasattr(g, 'add_providers')
    assert hasattr(g, 'choice')
    assert hasattr(g, 'clothing')
    assert hasattr(g, 'code')
    assert hasattr(g, 'cryptographic')
    assert hasattr(g, 'development')
    assert hasattr(g, 'file')
    assert hasattr(g, 'hardware')
    assert hasattr(g, 'internet')
    assert hasattr(g, 'numbers')
    assert hasattr(g, 'path')
    assert hasattr(g, 'payment')
    assert hasattr(g, 'structure')
    assert hasattr(g, 'transport')
   

# Generated at 2022-06-23 21:25:56.914213
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = g.__dir__()
    assert result is not None
    assert 'person' in result
    assert 'address' in result
    assert 'datetime' in result
    assert 'business' in result
    assert 'text' in result
    assert 'food' in result
    assert 'science' in result
    assert 'transport' in result
    assert 'code' in result
    assert 'unit_system' in result
    assert 'file' in result
    assert 'numbers' in result
    assert 'development' in result
    assert 'hardware' in result
    assert 'clothing' in result
    assert 'internet' in result
    assert 'path' in result
    assert 'payment' in result
    assert 'cryptographic' in result
    assert 'structure' in result
    assert 'choice' in result

# Generated at 2022-06-23 21:25:59.643986
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class FakeProvider(BaseProvider):
        class Meta:
            name = 'fake_provider'

    generic = Generic()
    # Will raise an exception
    try:
        generic.add_provider(1)
    except TypeError:
        assert True
    # Will add new provider
    generic.add_provider(FakeProvider)
    assert hasattr(generic, 'fake_provider')


# Generated at 2022-06-23 21:26:10.620971
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    print('Dir: '+str(dir(gen)))
    print('Gen (1): '+str(gen.person.username()))
    print('Gen (2): '+str(gen.person.full_name()))
    print('Gen (3): '+str(gen.person.title()))
    gen.add_providers(Address)
    print('Dir: '+str(dir(gen)))
    print('Gen (1): '+str(gen.person.username()))
    print('Gen (2): '+str(gen.person.full_name()))
    print('Gen (3): '+str(gen.person.title()))
    print('Gen (4): '+str(gen.address.country()))

# Generated at 2022-06-23 21:26:13.463931
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    g.person.full_name()
    g.address.address()
    g.datetime.date()

# Generated at 2022-06-23 21:26:20.667449
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.providers.development import Development
    from mimesis.providers.clothing import Clothing
    generic = Generic('ru')
    assert not hasattr(generic, 'development')
    assert not hasattr(generic, 'clothing')
    generic.add_providers(Development, Clothing)
    assert hasattr(generic, 'development')
    assert hasattr(generic, 'clothing')

# Generated at 2022-06-23 21:26:21.611519
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:26:32.598465
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g
    g.person
    assert g.person._namespace
    g.address
    assert g.address._namespace
    g.business
    assert g.business._namespace
    g.datetime
    assert g.datetime._namespace
    g.text
    assert g.text._namespace
    g.food
    assert g.food._namespace
    g.science
    assert g.science._namespace
    g.transport
    assert g.transport._namespace
    g.code
    assert g.code._namespace
    g.unit_system
    assert g.unit_system._namespace
    g.file
    assert g.file._namespace
    g.numbers
    assert g.numbers._namespace
    g.development
    assert g.development._

# Generated at 2022-06-23 21:26:36.224341
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [
        Person,
        Address,
        Datetime,
        Business,
        Text,
        Food,
        Science,
        ]

    generic = Generic()

    generic.add_providers(*providers)

    assert hasattr(generic, 'person')
    assert hasattr(generic, 'text')
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'food')
    assert hasattr(generic, 'science')



# Generated at 2022-06-23 21:26:38.500128
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .custom import CustomProvider
    _ = Generic()
    assert not hasattr(_, 'custom')
    _.add_provider(CustomProvider)
    assert hasattr(_, 'custom')

# Generated at 2022-06-23 21:26:49.667453
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    from mimesis.enums import Gender
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider'

        def custom_method(self, gender: Gender = None) -> None:
            """Return a custom method.

            :param gender: Gender.
            :return: str.
            """
            if gender == Gender.MALE:
                return 'Male'

            if gender == Gender.FEMALE:
                return 'Female'

            return self.random.choice([
                'Male',
                'Female',
            ])

    g = Generic('en')
    g.add_provider(CustomProvider)
    assert hasattr(g, 'custom_provider')


# Generated at 2022-06-23 21:26:51.270364
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert generic.person()



# Generated at 2022-06-23 21:26:52.540623
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()


# Generated at 2022-06-23 21:27:01.573444
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Avery Dunn'
    assert g.text.sentence() == 'Doloremque et dolorem.'
    assert g.science.formula() == 'Ki = (1/2)mv^2'
    assert g.science.element() == 'Zn'
    assert g.address.city() == 'San Francisco'
    assert g.business.company() == 'Schuster LLC'
    assert g.food.dish() == 'Goulash'
    assert g.payment.credit_card_number() == '6821542656255948'
    assert g.transport.vehicle_model() == 'F150'
    assert g.transport.license_plate() == 'CA GV732'
    assert g.unit_system.get_

# Generated at 2022-06-23 21:27:09.227671
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider method for class Generic."""
    from mimesis.providers.development import Development
    from mimesis.providers.file import File
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.payment import Payment
    from mimesis.providers.numbers import Numbers, Seed

    e = Generic(seed=Seed())
    e.add_provider(Development)
    e.add_provider(File)
    e

# Generated at 2022-06-23 21:27:10.479009
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    data = Generic()
    data.add_providers(Address, Datetime, Person)
    assert True

# Generated at 2022-06-23 21:27:13.740681
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
        def foo(self):
            return 'foo'
    prov = Generic()
    prov.add_provider(TestProvider)
    assert prov.test_provider.foo() == 'foo'


# Generated at 2022-06-23 21:27:16.698020
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider(BaseProvider):
        class Meta:
            name = 'name'
    a=Generic()
    a.add_providers(Provider)
    assert 'name' in dir(a)


# Generated at 2022-06-23 21:27:22.184717
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person

    class AnotherPerson(Person):
        """Provider for generating test data.

        To use locally::

            from mimesis.enums import Gender
            from mimesis.providers.person import Person

            class Person(Person):
                class Meta:
                    name = 'person'

                def _another_person(self):
                    male = self.person(Gender.MALE)
                    female = self.person(Gender.FEMALE)
                    return f'{male} <=> {female}'

            g = Generic()
            g.add_providers(Person)
            g.person.another_person()

            # Will return a string, like 'John Smith <=> Jane Smith'

        """


# Generated at 2022-06-23 21:27:24.522962
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert len(gen.__dir__()) == 100


# Generated at 2022-06-23 21:27:32.422568
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.add_provider(File)
    g.file
    assert g.__getattr__('file')
    assert g.file
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice

# Generated at 2022-06-23 21:27:43.388118
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    generic.person.full_name()
    generic.person
    generic.address.province()
    generic.datetime.datetime()
    generic.business.company()
    generic.text.word()
    generic.food.fruit()
    generic.science.moon_phase()
    generic.transport.airport_code()
    generic.code.isbn()
    generic.unit_system.weight()
    generic.file.extension()
    generic.numbers.decimal()
    generic.development.language()
    generic.hardware.cpu_clock_speed()
    generic.clothing.color()
    generic.internet.ipv4()
    generic.path.path()
    generic.payment.credit_card_number()
    generic.cryptographic.checksum()

# Generated at 2022-06-23 21:27:45.602346
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    provider = Generic()
    provider.add_providers(Person, Address, Business)
    assert provider.__dir__() == ['business', 'address', 'person']

# Generated at 2022-06-23 21:27:50.730462
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None
    assert g.structure is not None

# Generated at 2022-06-23 21:27:52.933339
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()

    assert isinstance(generic.business.company(), str)
    assert isinstance(generic.person.full_name(), str)



# Generated at 2022-06-23 21:27:55.974640
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic('en')
    gen.add_provider(Development)
    gen.add_provider(UnitSystem)
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'unit_system')


# Generated at 2022-06-23 21:27:58.295588
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic"""
    generic = Generic()
    assert generic.__getattr__('person') == 'First Name'


# Generated at 2022-06-23 21:28:00.257174
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(UnitSystem)
    assert isinstance(g.unit_system, UnitSystem)


# Generated at 2022-06-23 21:28:07.071233
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    result = gen.__dir__()
    assert 'person' in result
    assert 'address' in result
    assert 'datetime' in result
    assert 'business' in result
    assert 'text' in result
    assert 'food' in result
    assert 'science' in result
    assert 'transport' in result
    assert 'code' in result
    assert 'unit_system' in result
    assert 'file' in result
    assert 'numbers' in result
    assert 'development' in result
    assert 'hardware' in result
    assert 'clothing' in result
    assert 'internet' in result
    assert 'path' in result
    assert 'payment' in result
    assert 'cryptographic' in result
    assert 'structure' in result
    assert 'choice' in result

# Generated at 2022-06-23 21:28:15.347133
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    my_providers = [Person, Address]
    a = Generic()
    a.add_providers(*my_providers)
    assert isinstance(a.person, Person)
    assert isinstance(a.address, Address)
    # Test with providers that are not classes
    my_providers = [1, 2, "3"]
    with pytest.raises(TypeError):
        a.add_providers(*my_providers)
    # Test with providers that are classes but not provider classes
    my_providers = [Locale, Datetime]
    with pytest.raises(TypeError):
        a.add_providers(*my_providers)

# Generated at 2022-06-23 21:28:24.068025
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic('en')
    result = gen.__dir__()
    expected = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
        ]
    assert sorted(result) == sorted(expected)
# def test_Generic___dir__

# Generated at 2022-06-23 21:28:27.979541
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    # test for not repeated elements
    assert len(obj.__dir__()) == len(set(obj.__dir__()))
    # test for correct length
    assert len(obj.__dir__()) == len([i for i in dir(Generic())])

# Generated at 2022-06-23 21:28:29.458343
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Foo)


# Generated at 2022-06-23 21:28:37.077252
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Set English locale and seed 0
    a = Generic(locale='en', seed=0)

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def get_data(self):
            return 'test_provider_data'

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test_provider_2'

        def get_data(self):
            return 'test_provider_2_data'

    # Add two custom providers
    a.add_providers(TestProvider,TestProvider2)

    assert a.test_provider.get_data() == 'test_provider_data'
    assert a.test_provider_2.get_data() == 'test_provider_2_data'

# Generated at 2022-06-23 21:28:42.610203
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic(seed=11)
    res = obj.__dir__()
    exp = ['person', 'address', 'datetime', 'business', 'text',
           'food', 'science', 'transport', 'unit_system',
           'file', 'numbers', 'development', 'hardware',
           'clothing', 'internet', 'path', 'code',
           'payment', 'cryptographic', 'structure',
           'choice']
    assert res == exp


# Generated at 2022-06-23 21:28:45.600428
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic('en')
    gen.add_providers(Address, Code)
    assert gen.address is not None and gen.code is not None
    

# Generated at 2022-06-23 21:28:47.132194
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()

    assert isinstance(g.numbers, Numbers)

# Generated at 2022-06-23 21:28:55.270235
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.automotive import Automotive
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.person import Person

    auto = Automotive(seed=1)
    lorem = Lorem(seed=1)
    person = Person(seed=1)

    generic = Generic()
    generic.add_providers(auto, lorem, person)

    assert auto.make_model() == 'Dodge Nitro'
    assert lorem.words(quantity=5) == 'qui'
    assert person.full_name(gender='male') == 'Franklyn Bird'



# Generated at 2022-06-23 21:28:58.468754
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # arrange
    g = Generic()
    expected_value = g.science.scientist(seed=g.seed.random())

    # act
    actual_value = g.science.scientist(seed=g.seed.random())

    # assert
    assert expected_value == actual_value

# Generated at 2022-06-23 21:29:00.971444
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for Generic.add_provider."""
    generic = Generic()
    provider = Generic.Meta
    generic.add_provider(provider)
    assert generic.meta.name == provider.name

# Generated at 2022-06-23 21:29:03.053347
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic("ru")
    print(generic.person.full_name())
    print(generic.choice.choose(["a", "b", "c"]))

# Generated at 2022-06-23 21:29:11.458995
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    gen_providers = []
    for provider in gen.__dir__():
        gen_providers.append(provider)
    gen_providers.sort()
    assert gen_providers == [
        'address', 'business', 'choice', 'code', 'clothing',
        'cryptographic', 'datetime', 'development', 'file',
        'food', 'hardware', 'internet', 'numbers', 'path',
        'payment', 'person', 'science', 'structure',
        'text', 'transport', 'unit_system'
    ]

# Generated at 2022-06-23 21:29:19.743021
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    assert Generic().__dir__() == [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

# Generated at 2022-06-23 21:29:20.435355
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:29:26.085281
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self):
            return 'test'

    class TestProviderTwo(BaseProvider):
        class Meta:
            name = 'test2'

        def bar(self):
            return 'test2'

    g = Generic()
    g.add_providers(TestProvider)
    new_provider = g.test
    assert new_provider.foo() == 'test'
    assert new_provider.bar() is None
    g.add_providers(TestProviderTwo)
    new_provider_two = g.test2
    assert new_provider_two.foo() is None
    assert new_provider_two.bar() == 'test2'



# Generated at 2022-06-23 21:29:35.510966
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    from mimesis.enums import Gender
    from mimesis.providers.base import Person as BasePerson # type: ignore
    from mimesis.providers.person import Person as CustomPerson # type: ignore

    class CustomPerson(BasePerson):
        def foo(self):
            return 'bar'

    generic = Generic('en')
    assert generic.person.full_name(Gender.FEMALE) == 'Carol Lane'
    assert generic.person.full_name(Gender.FEMALE) == 'Carol Lane'
    assert generic.address.city() == 'South Edwin'
    assert generic.address.city() == 'South Edwin'
    assert isinstance(generic.person, BasePerson)
    assert isinstance(generic.address, BasePerson)

    generic.add_provider(CustomPerson)

# Generated at 2022-06-23 21:29:37.546093
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    g = Generic()
    assert callable(g.person)

# Generated at 2022-06-23 21:29:45.168457
# Unit test for constructor of class Generic
def test_Generic():
    test = Generic()
    assert test._person
    assert test._address
    assert test._datetime
    assert test._business
    assert test._text
    assert test._food
    assert test._science
    assert test.transport
    assert test.code
    assert test.unit_system
    assert test.file
    assert test.numbers
    assert test.development
    assert test.hardware
    assert test.clothing
    assert test.internet
    assert test.path
    assert test.payment
    assert test.cryptographic
    assert test.structure
    assert test.choice
