

# Generated at 2022-06-23 21:19:47.968347
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.geography import Geography
    from mimesis.providers.culture import Culture

    g = Generic()
    g.add_providers(Geography, Culture)
    assert isinstance(g.geography, Geography)
    assert isinstance(g.culture, Culture)



# Generated at 2022-06-23 21:19:49.842192
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    generic.person.full_name()



# Generated at 2022-06-23 21:19:57.418020
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    '''
    :return: None
    '''
    import pytest
    from mimesis.typing import ProviderT
    from mimesis.providers.photo import Photo
    
    with pytest.raises(TypeError):
        Photo(seed='test')
    
    assert not hasattr(Generic(), 'Photo')
    assert not hasattr(Generic(), 'photo')

    generic = Generic()
    generic.add_provider(ProviderT(Photo))
    assert hasattr(generic, 'Photo') and hasattr(generic, 'photo')

    generic.Photo.user_name() == generic.photo.user_name()


# Generated at 2022-06-23 21:19:58.793115
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)

# Generated at 2022-06-23 21:20:06.350918
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic.

    :return: None
    """
    expected = ['address', 'business', 'choice', 'code', 'food', 'file',
                'internet', 'hardware', 'person', 'clothing', 'numbers',
                'path', 'payment', 'cryptographic', 'datetime', 'science',
                'text', 'transport', 'development', 'structure', 'unit_system',
                'add_provider', 'add_providers', 'file', 'file']

    instance = Generic()
    result = dir(instance)

    assert result == expected

# Generated at 2022-06-23 21:20:10.494991
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    g = Generic()

    assert g.person
    assert g.business
    assert g.address
    assert g.file
    assert g.transport



# Generated at 2022-06-23 21:20:11.887318
# Unit test for constructor of class Generic
def test_Generic():
    p = Generic()

# Generated at 2022-06-23 21:20:16.141437
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    print(g.person.name())
    print(g.address.address())
    print(g.datetime.date())
    print(g.business.company())
    print(g.text.text())
    print(g.food.dish())
    print(g.science.chemical_element())
    print(g.transport.license_plate())
    print(g.code.imei())
    print(g.unit_system.mass())


# Generated at 2022-06-23 21:20:27.940830
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic"""
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    from mimesis.providers.transport import Transport
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.generic import Generic
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    """Test provider add_provider of class Generic"""
    test_gen = Generic()

# Generated at 2022-06-23 21:20:29.837717
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g.__dir__(), list)
    assert isinstance(g.__dir__()[0], str)

# Generated at 2022-06-23 21:20:41.683853
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person

    class CustomProvider(BaseProvider):
        """Example of custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        @staticmethod
        def foo() -> str:
            return 'foo'

    # create instance of class Generic
    generic = Generic()

    # add a custom provider
    generic.add_provider(CustomProvider)

    # add provider by name
    generic.add_provider(Person)

    class OtherProvider(BaseProvider):
        """Example of Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'other'

    class AnotherProvider(BaseProvider):
        """Example of Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'another'

    #

# Generated at 2022-06-23 21:20:50.912747
# Unit test for constructor of class Generic
def test_Generic():
    x = Generic()
    assert (x.address is not None)
    assert (x.address.address() is not None)
    assert (x.address.street_name is not None)
    assert (x.address.street_name().isalpha() is True)
    assert (x.address.building_number() > 0)
    assert (x.address.apartment_number() > 0)
    assert (x.address.city() is not None)
    assert (x.address.city().isalpha() is True)
    assert (x.address.country() is not None)
    assert (x.address.country().isalpha() is True)
    assert (x.address.region() is not None)
    assert (x.address.region().isalpha() is True)
    assert (x.address.latitude() is not None)

# Generated at 2022-06-23 21:20:58.720076
# Unit test for constructor of class Generic
def test_Generic():

    foo = Generic()
    # Check person
    assert foo.person.full_name() != foo.person.full_name()
    # Check address
    assert foo.address.city() != foo.address.city()
    # Check datetime
    assert foo.datetime.date() != foo.datetime.date()
    # Check business
    assert foo.business.company() != foo.business.company()
    # Check text
    assert foo.text.title() != foo.text.title()
    # Check food
    assert foo.food.meat() != foo.food.meat()
    # Check science
    assert foo.science.element() != foo.science.element()
    # Check transport
    assert foo.transport.vehicle() != foo.transport.vehicle()
    # Check code
    assert foo.code.isbn()

# Generated at 2022-06-23 21:21:01.170535
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert hasattr(gen, '__dir__')



# Generated at 2022-06-23 21:21:02.826814
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(
        BaseProvider,
    )
    assert hasattr(g, 'base')



# Generated at 2022-06-23 21:21:07.857487
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    '''Test method add_provider of class Generic'''
    from .test_providers import CustomProvider
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.customprovider



# Generated at 2022-06-23 21:21:10.482978
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert dir(Generic(seed=42)) == Generic(seed=42).__dir__()
    assert dir(Generic(seed=42)) == Generic.__dir__(Generic(seed=42))

# Generated at 2022-06-23 21:21:17.486220
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.address
    assert g.person
    assert g.business
    assert g.datetime
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.choice



# Generated at 2022-06-23 21:21:21.954549
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic in ``providers.py`` module."""

    instance = Generic()
    instance.add_providers(Person, Datetime)
    assert type(instance.person) == Person
    assert type(instance.datetime) == Datetime

# Generated at 2022-06-23 21:21:23.718350
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert 'business' in dir(Generic())
    assert 'address' in dir(Generic())
    assert 'person' in dir(Generic())
    assert 'file' in dir(Generic())

# Generated at 2022-06-23 21:21:27.285202
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(CustomProvider)
    assert 'customprovider' in g.__dict__
    assert hasattr(g, 'customprovider')



# Generated at 2022-06-23 21:21:33.990752
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    assert g._person.full_name() == 'Рудольфов Кирилл Алексеевич'
    assert g.person.full_name() == 'Рудольфов Кирилл Алексеевич'



# Generated at 2022-06-23 21:21:36.920631
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert gen.business.is_company_name() == 'Open'
    gen.add_provider(Business)
    assert gen.business.is_company_name() == 'Open'


# Generated at 2022-06-23 21:21:48.359862
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == 19
    assert 'person' in g.__dir__()
    assert 'address' in g.__dir__()
    assert 'datetime' in g.__dir__()
    assert 'business' in g.__dir__()
    assert 'text' in g.__dir__()
    assert 'food' in g.__dir__()
    assert 'science' in g.__dir__()
    assert 'transport' in g.__dir__()
    assert 'code' in g.__dir__()
    assert 'unit_system' in g.__dir__()
    assert 'file' in g.__dir__()
    assert 'numbers' in g.__dir__()
    assert 'development' in g.__dir__()
    assert 'hardware'

# Generated at 2022-06-23 21:21:59.477242
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    f = Generic()
    assert 'person' in f.__dir__()
    assert 'address' in f.__dir__()
    assert 'datetime' in f.__dir__()
    assert 'business' in f.__dir__()
    assert 'text' in f.__dir__()
    assert 'food' in f.__dir__()
    assert 'science' in f.__dir__()
    assert 'transport' in f.__dir__()
    assert 'code' in f.__dir__()
    assert 'unit_system' in f.__dir__()
    assert 'file' in f.__dir__()
    assert 'numbers' in f.__dir__()
    assert 'development' in f.__dir__()
    assert 'hardware' in f.__dir__()

# Generated at 2022-06-23 21:22:06.764393
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis_tests.providers.test_base import TestBase
    TestBase(
        cls=Generic,
        method='__dir__',
        attrs=['__init__', '_address', '_business',
               '_datetime', '_person', '_text', '_food',
               '_science', 'address', 'business',
               'datetime', 'food', 'person', 'science',
               'text'],
        args=None,
        include_inherited=True,
    )

# Generated at 2022-06-23 21:22:12.765783
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    universe = Generic()
    universe.add_providers(Clothing)
    universe.add_providers(Business, Payment, Text)
    # assert isinstance(universe.clothing, Clothing)
    assert isinstance(universe.business, Business)
    assert isinstance(universe.payment, Payment)
    assert isinstance(universe.text, Text)

# Generated at 2022-06-23 21:22:15.125078
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic()
    assert Generic(seed=1)
    assert Generic(locale='ru')
    assert Generic(seed=1, locale='ru')

# Generated at 2022-06-23 21:22:16.052355
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = []
    generic = Generic()
    generic.add_providers(*providers)

# Generated at 2022-06-23 21:22:28.748348
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert isinstance(gen, Generic)
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.business, Business)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)
    assert isinstance(gen.transport, Transport)
    assert isinstance(gen.code, Code)
    assert isinstance(gen.unit_system, UnitSystem)
    assert isinstance(gen.file, File)
    assert isinstance(gen.numbers, Numbers)
    assert isinstance(gen.development, Development)
    assert isinstance(gen.hardware, Hardware)

# Generated at 2022-06-23 21:22:36.368292
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.net import Net
    from mimesis.providers.test import Test
    generic = Generic()
    net = Net(seed=generic.seed)
    test = Test(seed=generic.seed)
    generic.add_providers(Net, Test)
    assert generic.net.mac_address() == net.mac_address()
    assert generic.test.bool() == test.bool()

# Generated at 2022-06-23 21:22:41.626266
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test case for add_provider method of class Generic."""
    GEN = Generic('ru')
    assert not hasattr(GEN, 'not_provider')
    GEN.add_provider(BaseProvider)
    assert not hasattr(GEN, 'base_provider')
    assert not hasattr(GEN, 'not_provider')
    GEN.add_provider(NotProvider)
    assert not hasattr(GEN, 'not_provider')



# Generated at 2022-06-23 21:22:42.099692
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:22:43.325802
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    print(a)
    print(a.file.file_name())

# Generated at 2022-06-23 21:22:44.518744
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    for name in Generic.Meta.__dict__.keys():
        assert isinstance(getattr(Generic(), name), BaseProvider)

# Generated at 2022-06-23 21:22:46.161478
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('ru')
    print(gen.code.uuid())

# Generated at 2022-06-23 21:22:50.252929
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import USASpecProvider

    g = Generic()
    g.add_providers(BrazilSpecProvider, USASpecProvider)

# Generated at 2022-06-23 21:22:51.709494
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)


# Generated at 2022-06-23 21:22:59.946511
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import random
    from mimesis.enums import DataProvider
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-23 21:23:06.473349
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider() of class Generic."""
    locale = 'en'
    seed = '444'
    gen = Generic(seed=seed)
    assert gen.seed == seed
    gen.add_provider(Person)
    assert isinstance(gen.person, Person)
    assert gen.person.seed == seed
    assert gen.person.locale == locale
    assert gen.person._data == gen.person.data



# Generated at 2022-06-23 21:23:09.118046
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """ Unit test for method __getattr__ of class Generic.
    """
    obj = Generic()
    assert isinstance(obj.person(),BaseProvider)


# Generated at 2022-06-23 21:23:11.887576
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import mimesis.providers.currency
    generic = Generic()
    generic.add_providers(mimesis.providers.currency.Currency)
    assert 'currency' in dir(generic)

# Generated at 2022-06-23 21:23:15.268254
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.logging import Logging

    gen = Generic()
    gen.add_provider(Logging)
    gen.logging.trace()



# Generated at 2022-06-23 21:23:16.383435
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person, Person) == True

# Generated at 2022-06-23 21:23:24.471413
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    c = Generic()
    assert c.address != None
    assert c.business != None
    assert c.datetime != None
    assert c.food != None
    assert c.internet != None
    assert c.numbers != None
    assert c.person != None
    assert c.development != None
    assert c.text != None
    assert c.transport != None
    assert c.unit_system != None
    assert c.hardware != None
    assert c.clothing != None
    assert c.path != None
    assert c.payment != None
    assert c.cryptographic != None
    assert c.structure != None
    assert c.choice != None

test_Generic___getattr__()

# Generated at 2022-06-23 21:23:33.777610
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person

    class NewProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def new(self, *args, **kwargs):
            self.__new__(*args, **kwargs)

        class Meta:
            name = 'new_provider'

    generic = Generic(Universal, 'ru')
    new_provider = NewProvider(seed=generic.seed)
    generic.add_providers(new_provider)
    assert isinstance(generic.new_provider, NewProvider)



# Generated at 2022-06-23 21:23:38.120638
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')
    # the number of attributes from dict __dict__
    number_of_attrs = 0
    for a in generic.__dict__:
        if a[0] != '_':
            number_of_attrs = number_of_attrs + 1
    assert number_of_attrs == len(generic.__dir__())

# Generated at 2022-06-23 21:23:39.864381
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic(seed=12345)
    assert len(obj.__dict__) == 21


# Generated at 2022-06-23 21:23:42.870940
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers of class Generic()."""
    from mimesis import Person, Address
    gen = Generic('en')
    gen.add_providers(Person, Address)
    assert hasattr(gen, 'person')

# Generated at 2022-06-23 21:23:43.523178
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('en')


# Generated at 2022-06-23 21:23:55.591882
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'datetime' in dir(generic)
    assert 'business' in dir(generic)
    assert 'text' in dir(generic)
    assert 'food' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)
    assert 'clothing' in dir(generic)
    assert 'internet' in dir(generic)
    assert 'path' in dir(generic)

# Generated at 2022-06-23 21:23:56.782993
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()

    assert isinstance(result, list)


# Generated at 2022-06-23 21:23:59.180846
# Unit test for constructor of class Generic
def test_Generic():
    #assert generic is not None
    assert Generic().structure is not None
    print(Generic().structure)
    assert Generic().internet is not None
    print(Generic().internet)

# Generated at 2022-06-23 21:24:07.210971
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """test_Generic_add_provider."""
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.base import BaseProvider

    # This is a standard situation when everything is fine
    # and we add a custom provider, PersonProvider
    try:
        generic = Generic()
        generic.add_provider(PersonProvider)

        assert(
            generic.person.__name__ == 'PersonProvider'
        )
    finally:
        del (generic)

    # The situation where we have an error,
    # we try to add a non-class object
    # and an object that is not a subclass of BaseProvider

# Generated at 2022-06-23 21:24:16.459667
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    print(generic.person().full_name())
    print(generic.address().full_address())
    print(generic.datetime().date(start=2020, end=2021))
    print(generic.business().license_plate())
    print(generic.text().sentence())
    print(generic.food().dish())
    print(generic.science().chemical_symbol())
    print(generic.transport().car())
    print(generic.code().isbn10())
    print(generic.unit_system().get_base_units())
    print(generic.file.extension())
    print(generic.numbers.numbers(quantity=10, start=1, stop=10))
    print(generic.development().programming_language())
    print(generic.hardware().cpu())

# Generated at 2022-06-23 21:24:26.588921
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Test with BaseProvider subclass
    class TestProvider(BaseProvider):
        class Meta:
            name = 'TEST'
        def func(self):
            pass
    generic = Generic()
    generic.add_providers(TestProvider)
    assert 'test' in dir(generic)
    assert generic.test is not None
    assert 'func' in dir(generic.test)
    # Test with BaseProvider subclass
    class AnotherTestProvider(BaseProvider):
        class Meta:
            pass
        def func(self):
            pass
    generic.add_providers(AnotherTestProvider)
    assert 'anothertestprovider' in dir(generic)
    assert generic.anothertestprovider is not None
    assert 'func' in dir(generic.anothertestprovider)

# Generated at 2022-06-23 21:24:31.871553
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert hasattr(g, 'person')
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'business')
    assert hasattr(g, 'text')
    assert hasattr(g, 'food')
    assert hasattr(g, 'science')


# Generated at 2022-06-23 21:24:36.372388
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.person.full_name() is not None
    assert gen.address.city() is not None
    assert gen.datetime.datetime() is not None
    assert gen.business.company() is not None
    assert gen.food.food() is not None
    assert gen.science.planet() is not None



# Generated at 2022-06-23 21:24:41.192461
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic.

    """
    g = Generic()
    try:
        g.business()
        g.business
        assert True, 'generic_providers_test_test_Generic___getattr__: ' \
                     'pass'
    except Exception as e:
        print('generic_providers_test_test_Generic___getattr__: '
              'fail')
        raise e


# Generated at 2022-06-23 21:24:42.805188
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic is not None


# Generated at 2022-06-23 21:24:45.972492
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    actual_provider = Generic()
    actual_provider.person == Person(actual_provider.locale, actual_provider.seed)

# Generated at 2022-06-23 21:24:55.357735
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from unittest.mock import Mock, patch
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.development import Development

    def test_add_provider():
        provider = Generic()
        provider.add_provider(Clothing)
        provider.add_provider(Development)

        assert provider.clothing is not None
        assert provider.development is not None

    def test_add_custom_provider():
        class Foo:
            pass

        provider = Generic()
        provider.add_provider(Foo)

    def test_add_custom_provider_without_seed():
        class Foo(BaseProvider):
            pass

        provider = Generic()
        provider.add_provider(Foo)

    def test_add_class():
        provider = Generic()

# Generated at 2022-06-23 21:24:57.646842
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    gen.add_providers(Datetime, Person)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.person, Person)

# Generated at 2022-06-23 21:25:05.183349
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic  """
    class MyProvider(BaseProvider):
        """Custom class."""

        class Meta:
            """Class for metadata."""

            name = 'myprovider'

        def foo(self) -> str:
            """Foo method."""
            return 'foo'

    gen = Generic()
    gen.add_provider(MyProvider)
    assert gen.myprovider
    assert 'foo' == gen.myprovider.foo()

    try:
        gen.add_provider(UnitSystem)
    except TypeError:
        assert True

    try:
        gen.add_provider(BaseProvider)
    except TypeError:
        assert True

# Generated at 2022-06-23 21:25:15.196870
# Unit test for constructor of class Generic
def test_Generic():
    # When I create an instance of Generic
    gen = Generic()
    # Then the result should be instance of Generic
    assert isinstance(gen, Generic)

    # When I create an instance of Generic with locale
    gen_with_locale = Generic('ru')
    # Then the result should be instance of Generic
    assert isinstance(gen_with_locale, Generic)
    # And locale should be 'ru'
    assert gen_with_locale.locale == 'ru'

    # When I create an instance of Generic with some seed
    gen_with_seed = Generic('ru', seed=12345)
    # Then the result should be instance of Generic
    assert isinstance(gen_with_seed, Generic)
    # And locale should be 'ru'
    assert gen_with_seed.locale == 'ru'
    # And seed should

# Generated at 2022-06-23 21:25:18.604148
# Unit test for constructor of class Generic
def test_Generic():
    # Instance of class Generic
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic._person, Person)
    assert isinstance(generic.person._data, Text)
    assert generic._person.person_name() in generic.person._data.full_name()

# Generated at 2022-06-23 21:25:19.919307
# Unit test for constructor of class Generic
def test_Generic():
    global generic
    generic = Generic()
    assert generic

# Generated at 2022-06-23 21:25:24.528674
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic()
    print("Test __getattr__ with method 'person.full_name'")
    print("Result: ", data.person.full_name())
    print("\nTest __getattr__ with method 'address.city'")
    print("Result: ", data.address.city())



# Generated at 2022-06-23 21:25:25.221756
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:25:29.490867
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def method(self):
            return "A method"
    assert getattr(Generic().add_provider(MyProvider), 'method', None) is not None


# Generated at 2022-06-23 21:25:31.959280
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic.add_provider
    assert generic.add_providers

# Generated at 2022-06-23 21:25:39.311022
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    def my_provider(BaseProvider):
        class Meta:
            name = 'my_provider'
        def foo(self):
            return 'bar'

    gen = Generic('en')
    gen.add_providers(my_provider)
    assert hasattr(gen, 'my_provider')
    assert isinstance(gen.my_provider, BaseProvider)
    assert gen.my_provider.foo() == 'bar'

# Generated at 2022-06-23 21:25:43.239855
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    class NewProvider(BaseProvider):
        class Meta:
            name = 'foo'
        def bar(self):
            return 'bar'
    g.add_providers(NewProvider)
    assert hasattr(g, 'foo')
    assert g.foo.bar() == 'bar'

# Generated at 2022-06-23 21:25:46.442157
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(MyProvider)
    assert 'myprovider' in generic.__dir__()

# Generated at 2022-06-23 21:25:49.655744
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    expected_result = 'en-US'

    result = generic.address.get_full_address()

    assert expected_result in result



# Generated at 2022-06-23 21:25:59.773243
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    '''
    测试 Generic 类的 add_providers 方法
    '''
    gen = Generic( 'zh' )
    assert hasattr( gen, '_person' ), 'expect Generic object has person prop'
    assert hasattr( gen, 'person' ), 'expect Generic object has person method'

    gen.add_providers( Person )
    assert hasattr( gen, 'person1' ), 'expect Generic object has person1 method'
    assert hasattr( gen, 'person2' ), 'expect Generic object has person2 method'

    gen.add_provider( Person )
    assert hasattr( gen, 'person3' ), 'expect Generic object has person3 method'

    gen.add_provider( BaseDataProvider )

# Generated at 2022-06-23 21:26:01.749410
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test Generic.__getattr__() method."""
    generic = Generic()
    name = generic.person()
    assert name == generic.person().full_name()



# Generated at 2022-06-23 21:26:06.816342
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class x:
        pass

    class y:
        pass

    # instance of class Generic
    a = Generic()
    # add just one custom provider
    a.add_providers(x)
    # add a lot of custom providers
    a.add_providers(x, y)


# Generated at 2022-06-23 21:26:14.309190
# Unit test for constructor of class Generic
def test_Generic():
    it = Generic()
    it.unit_system.__class__.__name__ == 'UnitSystem'
    it.code.__class__.__name__ == 'Code'
    it.choice.__class__.__name__ == 'Choice'
    it.transport.__class__.__name__ == 'Transport'
    it.file.__class__.__name__ == 'File'
    it.numbers.__class__.__name__ == 'Numbers'
    it.development.__class__.__name__ == 'Development'
    it.hardware.__class__.__name__ == 'Hardware'
    it.clothing.__class__.__name__ == 'Clothing'
    it.internet.__class__.__name__ == 'Internet'

# Generated at 2022-06-23 21:26:19.392509
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider(BaseProvider):
        def foo(self):
            return self.random.randint(0, 100)

    g = Generic()
    g.add_providers(Provider)
    assert hasattr(g, 'provider')
    assert hasattr(g.provider, 'foo')



# Generated at 2022-06-23 21:26:21.957705
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic('ru')
    g.add_provider(UnitSystem)
    assert g.unit_system.__class__.__name__ == 'UnitSystem'



# Generated at 2022-06-23 21:26:32.698207
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    myclass = Generic('en')
    dir_list = myclass.__dir__()
    assert 'person' in dir_list
    assert 'address' in dir_list
    assert 'datetime' in dir_list
    assert 'business' in dir_list
    assert 'text' in dir_list
    assert 'food' in dir_list
    assert 'science' in dir_list
    assert 'transport' in dir_list
    assert 'code' in dir_list
    assert 'unit_system' in dir_list
    assert 'file' in dir_list
    assert 'numbers' in dir_list
    assert 'development' in dir_list
    assert 'hardware' in dir_list
    assert 'clothing' in dir_list
    assert 'internet' in dir_list
    assert 'path' in dir_list


# Generated at 2022-06-23 21:26:35.338230
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic('en')
    assert gen.development
    gen.add_providers(Person, Address)
    assert gen.person
    assert gen.address


# Generated at 2022-06-23 21:26:40.877588
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Bitcoin
    class MyProvider(BaseProvider):
        class Meta:
            name = 'myprovider'

        def my_method(self):
            return 'my method'

    g = Generic()
    assert 'myprovider' not in dir(g)

    g.add_provider(MyProvider)
    assert 'myprovider' in dir(g)
    assert g.myprovider.my_method() == 'my method'

    g = Generic()  # Clear prev. added providers
    assert 'bitcoin' not in dir(g)

    g.add_provider(Bitcoin)
    assert 'bitcoin' in dir(g)

# Generated at 2022-06-23 21:26:50.832742
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for __getattr__."""
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)

# Generated at 2022-06-23 21:26:53.652994
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test that the attributes are available."""
    generic = Generic()
    for i in dir(generic):
        assert isinstance(getattr(generic, i), BaseProvider)



# Generated at 2022-06-23 21:27:02.280401
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""
    assert 'person' in Generic().__dir__()
    assert 'address' in Generic().__dir__()
    assert 'datetime' in Generic().__dir__()
    assert 'business' in Generic().__dir__()
    assert 'text' in Generic().__dir__()
    assert 'food' in Generic().__dir__()
    assert 'science' in Generic().__dir__()
    assert 'transport' in Generic().__dir__()
    assert 'unit_system' in Generic().__dir__()
    assert 'code' in Generic().__dir__()
    assert 'file' in Generic().__dir__()
    assert 'numbers' in Generic().__dir__()
    assert 'development' in Generic().__dir__()
    assert 'hardware' in Generic().__dir__()


# Generated at 2022-06-23 21:27:09.542561
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None
    assert g.structure is not None
    assert g.choice is not None



# Generated at 2022-06-23 21:27:13.581939
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.enums import Gender
    g = Generic()
    assert g.person.full_name('en') == 'Suzanne Lynch'
    assert g.person.full_name(gender=Gender.FEMALE) == 'Lorene E. Vazquez'



# Generated at 2022-06-23 21:27:19.557436
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    data = Generic()
    expected = [
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]

    for e in expected:
        assert hasattr(data, e)


# Generated at 2022-06-23 21:27:21.028880
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(g.person)
    assert g.person is not None


# Generated at 2022-06-23 21:27:24.113659
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    # Test data
    test_1 = Generic(seed=42)
    test_2 = Generic(seed=42)
    # Result
    _res = test_1.person.full_name(gender='female')

    # Expected
    _exp = test_2.full_name(gender='female')

    assert _res == _exp


# Generated at 2022-06-23 21:27:28.305139
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    provider = Generic(seed=12345)
    result = provider.__dir__()

    expected = [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

    assert sorted(result) == sorted(expected)

# Generated at 2022-06-23 21:27:36.204066
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('ru', 0)
    print(g.code.code())
    print(g.datetime.datetime())
    print(g.datetime.timestamp())
    print(g.unit_system.length())
    print(g.unit_system.measure())
    print(g.unit_system.mass())
    print(g.unit_system.area())
    print(g.unit_system.volume())
    print(g.unit_system.temperature())
    print(g.unit_system.pressure())



# Generated at 2022-06-23 21:27:43.961339
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert str(a.__class__) == "<class 'mimesis.providers.all_at_once.Generic'>"
    assert str(a.choice.__class__) == "<class 'mimesis.providers.choice.Choice'>"
    assert str(a.code.__class__) == "<class 'mimesis.providers.code.Code'>"
    assert str(a.person.__class__) == "<class 'mimesis.providers.person.Person'>"
    assert str(a.datetime.__class__) == "<class 'mimesis.providers.date.Datetime'>"

# Generated at 2022-06-23 21:27:45.521490
# Unit test for constructor of class Generic
def test_Generic():
    clazz = Generic()
    assert clazz.locale == 'en'
    assert clazz.seed == 42

# Generated at 2022-06-23 21:27:49.805696
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.file
    assert g.transport
    assert g.internet
    assert g.path
    assert g.structure
    assert g.choice

    assert g.person
    assert g.address
    assert g.food
    assert g.science
    assert g.code
    assert g.unit_system
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing


# Generated at 2022-06-23 21:27:52.995964
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Address)
    g.add_providers(Address)
    assert g.address.__name__ == 'Address'

# Generated at 2022-06-23 21:27:54.846518
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.person().full_name() == "白崇禧"

# Generated at 2022-06-23 21:28:01.868029
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print("\n" + __name__ +"."+ test_Generic___getattr__.__name__)
    generic = Generic()
    assert generic.person
    assert generic.food
    assert generic.business
    assert generic.text
    assert generic.science
    assert generic.transport
    assert generic.code
    assert generic.unit_system
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic
    assert generic.structure
    assert generic.choice


# Generated at 2022-06-23 21:28:06.601666
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    g = Generic(seed = 10)
    g = Generic(locale = "en")
    g = Generic(locale = 'en', seed = 10)

# Generated at 2022-06-23 21:28:07.664045
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method."""
    pass

# Generated at 2022-06-23 21:28:17.049628
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # 从官方测试代码可知,这个方法的目的就是对对象的属性进行重命名
    # 这里为了测试把所有属性都改造成"_+属性名"形式
    # 如果是函数则把函数拼接到属性上并执行调用
    # 测试调用text属性并调用其中的 get_sentence()
    a = Generic

# Generated at 2022-06-23 21:28:22.643810
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        ...

    class CustomProvider_2(BaseProvider):
        ...

    gen = Generic()
    gen.add_providers(CustomProvider, CustomProvider_2)
    assert hasattr(gen, 'customprovider')
    assert hasattr(gen, 'customprovider_2')

# Generated at 2022-06-23 21:28:24.169520
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')

    assert generic is not None


# Generated at 2022-06-23 21:28:29.194170
# Unit test for constructor of class Generic
def test_Generic():
    # Create an instance of class Generic without a parameter
    s = Generic()
    print(s)
    print(s.__dict__)

    # Create an instance of class Generic with a parameter
    s1 = Generic(seed=345)
    print(s1)
    print(s1.__dict__)

if __name__ == "__main__":
    test_Generic()

# Generated at 2022-06-23 21:28:37.109497
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text

    g = Generic()
    assert not hasattr(g, 'person')
    assert not hasattr(g, 'datetime')
    assert not hasattr(g, 'text')

    g.add_provider(Person)
    assert hasattr(g, 'person')
    assert not hasattr(g, 'datetime')
    assert not hasattr(g, 'text')

    g.add_provider(Datetime)
    assert hasattr(g, 'person')
    assert hasattr(g, 'datetime')
    assert not hasattr(g, 'text')

    g.add_provider(Text)
    assert hasattr(g, 'person')

# Generated at 2022-06-23 21:28:41.393390
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add provider to Generic singleton.

    :return: None.
    """
    from mimesis.providers.person import Person as CustomPerson
    provider = Generic()
    provider.add_provider(CustomPerson)
    person = provider.person
    assert person.full_name() == 'Francesco Stanghellini'



# Generated at 2022-06-23 21:28:52.522186
# Unit test for constructor of class Generic
def test_Generic():
    """Test for Generic class constructor."""
    data = Generic('en')
    assert isinstance(data, Generic)
    assert isinstance(data.person, Person)
    assert isinstance(data.address, Address)
    assert isinstance(data.datetime, Datetime)
    assert isinstance(data.business, Business)
    assert isinstance(data.text, Text)
    assert isinstance(data.food, Food)
    assert isinstance(data.science, Science)
    assert isinstance(data.transport, Transport)
    assert isinstance(data.code, Code)
    assert isinstance(data.unit_system, UnitSystem)
    assert isinstance(data.file, File)
    assert isinstance(data.numbers, Numbers)
    assert isinstance(data.development, Development)

# Generated at 2022-06-23 21:29:00.255600
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()
    assert isinstance(result, List)
    assert 'address' in result
    assert 'business' in result
    assert 'choice' in result
    assert 'communication' in result
    assert 'code' in result
    assert 'cryptographic' in result
    assert 'datetime' in result
    assert 'development' in result
    assert 'file' in result
    assert 'food' in result
    assert 'hardware' in result
    assert 'internet' in result
    assert 'numbers' in result
    assert 'path' in result
    assert 'payment' in result
    assert 'person' in result
    assert 'science' in result
    assert 'structure' in result
    assert 'transport' in result
    assert 'unit_system' in result


# Generated at 2022-06-23 21:29:06.180380
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for add_providers of class Generic."""
    from mimesis.providers.person import Person

    g = Generic()
    g.add_providers(Person, Person)
    assert isinstance(g.person, Person)
    assert isinstance(g.person_, Person)
    assert g.person != g.person_


# Generated at 2022-06-23 21:29:12.483438
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    expected = [
        'choice', 'code', 'file', 'numbers', 'address',
        'datetime', 'development', 'hardware', 'clothing',
        'internet', 'path', 'payment', 'cryptographic',
        'structure', 'business', 'person', 'transport',
        'text', 'food', 'science', 'unit_system',
    ]
    assert gen.__dir__() == expected

# Generated at 2022-06-23 21:29:14.113445
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    obj = Generic('en')
    for provider in (Person, Address):
        obj.add_provider(provider)
    assert obj.person._seed == obj.seed
    assert obj.address._seed == obj.seed

# Generated at 2022-06-23 21:29:16.863196
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    data = Generic()
    data.add_providers(Address, Datetime)
    assert hasattr(data, 'datetime')
    assert hasattr(data, 'address')

# Generated at 2022-06-23 21:29:24.690821
# Unit test for constructor of class Generic
def test_Generic():
    test = Generic()
    assert test._person is not None
    assert test._address is not None
    assert test._datetime is not None
    assert test._business is not None
    assert test._text is not None
    assert test._food is not None
    assert test._science is not None
    assert test.transport is not None
    assert test.code is not None
    assert test.unit_system is not None
    assert test.file is not None
    assert test.numbers is not None
    assert test.development is not None
    assert test.hardware is not None
    assert test.clothing is not None
    assert test.internet is not None
    assert test.path is not None
    assert test.payment is not None
    assert test.cryptographic is not None
    assert test.structure is not None

# Generated at 2022-06-23 21:29:28.029977
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__ of class Generic."""
    g = Generic()
    g.add_provider(Text)
    g.add_provider(Development)
    assert g.__dir__() == ['text', 'development']


# Generated at 2022-06-23 21:29:32.582024
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis import Generic
    from mimesis.providers.science import Science

    g = Generic()
    g.add_providers(Science)

    assert hasattr(g, 'science')
    assert g.science.get_chemical_element() == 'Lithium'

# Generated at 2022-06-23 21:29:34.508092
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    for item in list(generic.__dir__()):
        print(item)


# Generated at 2022-06-23 21:29:37.624965
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Test(BaseProvider):
        class Meta:
            name = 'test'
    
    test = Generic()
    test.add_providers(Test)
    assert isinstance(test.test.seed, int)

# Generated at 2022-06-23 21:29:47.290119
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create a Generic object and add providers to it
    g = Generic()
    g.add_providers(Structure, Payment)
    # Get list of all provider's methods
    structures = [s[0] for s in inspect.getmembers(Structure) if s[0].startswith('_')]
    payments = [s[0] for s in inspect.getmembers(Payment) if s[0].startswith('_')]
    # Check if method was created and does not start with underscore
    for s in structures:
        method = g.structure.__getattribute__(s)
        assert (s[0] != '_' and callable(method)) == True
    for s in payments:
        method = g.payment.__getattribute__(s)