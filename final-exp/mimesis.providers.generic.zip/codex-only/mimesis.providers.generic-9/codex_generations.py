

# Generated at 2022-06-23 21:19:43.377994
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic(seed=42)
    assert gen.seed == 42


# Generated at 2022-06-23 21:19:49.467094
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    g = Generic()
    assert isinstance(g.__dir__(), list)
    assert isinstance(g.__dir__(), list)
    assert isinstance(g.__dir__(), list)
    assert isinstance(g.__dir__(), list)
    assert isinstance(g.__dir__(), list)

# Generated at 2022-06-23 21:19:52.417056
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person  # is not None
    assert g.address  # is not None
    assert g.datetime  # is not None



# Generated at 2022-06-23 21:20:02.958436
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    # get data of provider `generic`
    data = g.choice.choices('provider')
    # get data of provider `person`
    data = g.choice.choices('person')
    # get data of provider `address`
    data = g.choice.choices('address')
    # get data of provider `datetime`
    data = g.choice.choices('datetime')
    # get data of provider `business`
    data = g.choice.choices('business')
    # get data of provider `text`
    data = g.choice.choices('text')
    # get data of provider `food`
    data = g.choice.choices('food')
    # get data of provider `science`
    data = g.choice.choices('science')
    # get data of provider

# Generated at 2022-06-23 21:20:07.528725
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'
        def custom_method(self):
            return self.random.randint(1, 100)

    generic = Generic()

    generic.add_provider(CustomProvider)
    assert isinstance(generic.custom, CustomProvider)
    assert generic.custom.custom_method() <= 100

    generic = Generic()
    try:
        generic.add_provider(BaseProvider)
    except TypeError:
        pass

    try:
        generic.add_provider('foo')
    except TypeError:
        pass

# Generated at 2022-06-23 21:20:17.465794
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment

    class Custom(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'foo'

    class Person(Person):
        class Meta:
            name = 'custom_person'

        def custom_method(self):
            return 'custom_method'

        def custom_method_2(self):
            pass

    class Payment(Payment):
        class Meta:
            name = 'custom_payment'

        def custom_method(self):
            return 'custom_method'

    g = Generic()
    g.add_provider(Custom)

# Generated at 2022-06-23 21:20:29.155812
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.base import BaseSpecProvider
    
    address_provider = Address(seed = 123)
    base_provider = BaseProvider(seed = 123)
    base_data_provider = BaseDataProvider(seed = 123)
    base_spec_provider = BaseSpecProvider(seed = 123)
    
    generic = Generic()
    
    assert generic.add_provider(Address) == None, "test_Generic_add_provider_Address: The provider must be a subclass of BaseProvider"
    

# Generated at 2022-06-23 21:20:30.796238
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()


# Generated at 2022-06-23 21:20:40.983666
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class Animal(BaseProvider):
        def cow(self):
            return 'cow'

    class Pet(BaseProvider):
        def dog(self):
            return 'dog'

    class Sound(BaseProvider):
        def sound(self):
            return 'sound'

    gen = Generic()

    gen.add_provider(Animal)
    gen.add_provider(Pet)

    assert gen.animal.cow() == 'cow'
    assert gen.pet.dog() == 'dog'

    gen.add_providers(Animal, Pet, Sound)

    assert gen.animal.cow() == 'cow'
    assert gen.pet.dog() == 'dog'
    assert gen.sound.sound() == 'sound'

# Generated at 2022-06-23 21:20:50.355498
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert 'datetime' in dir(gen)
    assert 'person' in dir(gen)
    assert 'address' in dir(gen)
    assert 'choice' in dir(gen)
    assert 'structure' in dir(gen)
    assert 'numbers' in dir(gen)
    assert 'text' in dir(gen)
    assert 'science' in dir(gen)
    assert 'business' in dir(gen)
    assert 'food' in dir(gen)
    assert 'transport' in dir(gen)
    assert 'code' in dir(gen)
    assert 'unit_system' in dir(gen)
    assert 'file' in dir(gen)
    assert 'development' in dir(gen)
    assert 'hardware' in dir(gen)

# Generated at 2022-06-23 21:20:58.366204
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    gen = Generic()
    assert (gen.person.name())
    assert (gen.address.country())
    assert (gen.datetime.datetime())
    assert (gen.business.company())
    assert (gen.text.title())
    assert (gen.food.dish())
    assert (gen.science.chemistry.chemical_element())
    assert (gen.transport.airplane())
    assert (gen.code.c())
    assert (gen.unit_system.imperial.acceleration())
    assert (gen.file.name())
    assert (gen.numbers.decimal())
    assert (gen.development.electron.name())
    assert (gen.hardware.mac_address())

# Generated at 2022-06-23 21:21:03.759702
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.internet import Internet

    class InternetWrapper(Internet):
        class Meta:
            name = "internet_wrapper"

    g = Generic()
    g.add_providers(InternetWrapper)
    assert hasattr(g, "internet_wrapper")
    assert isinstance(g.internet_wrapper, InternetWrapper)

# Generated at 2022-06-23 21:21:09.194000
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers of class Generic."""
    g = Generic()
    g.add_provider(Person)
    g.add_provider(Address)
    assert g.person != None
    assert g.address != None

# Generated at 2022-06-23 21:21:10.905230
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    assert getattr(generic, 'person') == generic.person


# Generated at 2022-06-23 21:21:12.623056
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert isinstance(generic, Generic)


# Generated at 2022-06-23 21:21:15.962684
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science
    g = Generic()
    g.add_provider(Science)
    assert g.science


# Generated at 2022-06-23 21:21:24.760380
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method Generic.add_providers()"""

    class BaseTestProvider(BaseProvider):
        """Test provider."""
        class Meta:
            """Class for metadata."""

            name = 'base_test_provider'

    class TestProvider(BaseProvider):
        """Test provider."""
        class Meta:
            """Class for metadata."""

            name = 'test_provider'

    generic = Generic()
    generic.add_providers(BaseTestProvider, TestProvider)

    assert isinstance(generic.base_test_provider, BaseTestProvider)
    assert isinstance(generic.test_provider, TestProvider)

# Generated at 2022-06-23 21:21:33.402382
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic('en')
    b = Generic('en', '123')
    c = Generic('en', 123)
    d = Generic('en', 123.123)
    assert a.locale == 'en'
    assert a.seed == 123
    assert b.locale == 'en'
    assert b.seed == '123'
    assert c.locale == 'en'
    assert c.seed == 123
    assert d.locale == 'en'
    assert d.seed == 123.123



# Generated at 2022-06-23 21:21:40.332430
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.address.address() != None
    assert g.address.address() == g.address.address()
    assert g.business.company() != None
    assert g.business.company() == g.business.company()
    assert g.person.full_name() != None
    assert g.person.full_name() == g.person.full_name()
    assert g.person.username() != None
    assert g.person.username() == g.person.username()
    assert g.datetime.date() != None
    assert g.datetime.date() == g.datetime.date()
    assert g.datetime.timestamp() != None
    assert g.datetime.timestamp() == g.datetime.timestamp()

# Generated at 2022-06-23 21:21:45.152767
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.linux import Linux

    g = Generic(seed=42)
    g.add_provider(Linux)
    actual = g.linux.pkg_name()
    expected = 'firefox'
    assert actual == expected



# Generated at 2022-06-23 21:21:56.171882
# Unit test for constructor of class Generic
def test_Generic():
    all_providers=[
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
        ]
    
    attribute_names = dir(Generic(seed=123))
    
    assert len(all_providers)==len(attribute_names)
    assert sorted(all_providers)==sorted(attribute_names)

# Generated at 2022-06-23 21:21:58.331241
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)
    
    g = Generic(seed=10)
    assert isinstance(g, Generic)

# Generated at 2022-06-23 21:22:04.502908
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    from mimesis.providers.base import BaseProvider
    from mimesis.exceptions import ProviderLoadError

    class CustomProvider(BaseProvider):

        class Meta:
            """Class for metadata"""
            name = 'custom'

        def method(self):
            pass

    gp = Generic()
    gp.add_provider(CustomProvider)
    assert CustomProvider in gp.__class__.__dict__.values()

    try:
        gp.add_provider(1)
    except ProviderLoadError:
        pass
    else:
        raise AssertionError('Unit test is failed.')


# Generated at 2022-06-23 21:22:05.143523
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-23 21:22:09.527772
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    providers = [Person, Numbers, Hardware]
    g.add_providers(*providers)
    assert 'person' in g.__dict__
    assert 'numbers' in g.__dict__
    assert 'hardware' in g.__dict__

# Generated at 2022-06-23 21:22:13.995511
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    for item in generic.__dir__():
        if not isinstance(item, str):
            raise AssertionError('A value was "not" str')
    assert item in generic.__dir__()


# Generated at 2022-06-23 21:22:22.465455
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic(seed=13)
    generic_dir = generic.__dir__()
    assert generic_dir == [
        'address',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

# Generated at 2022-06-23 21:22:25.514692
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    print(gen.person.full_name())


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-23 21:22:28.245488
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.address import Address

    g = Generic()
    assert not hasattr(g, 'address')
    assert isinstance(g.person, Person)

    g.add_provider(Address)
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)



# Generated at 2022-06-23 21:22:40.040751
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    dp_name = []
    for attr in generic.__dict__.keys():
        if not attr.startswith('_'):
            dp_name.append(attr)

    class DummyProvider(BaseProvider):
        class Meta:
            name = 'dummy'

        def __str__(self):
            return 'Dummy.'

    class DummyProviderTwo(BaseProvider):
        class Meta:
            name = 'dummy2'

        def __str__(self):
            return 'Dummy.'

    generic.add_provider(DummyProvider)
    generic.add_provider(DummyProviderTwo)
    assert 'dummy' in generic.__dir__()
    assert 'dummy2' in generic.__dir__()


# Generated at 2022-06-23 21:22:46.484839
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    # assert generic is not None
    # assert generic.__getattr__('address') is not None
    assert generic.address is not None
    # assert generic._address is not None
    # assert generic.__getattr__('datetime') is not None
    assert generic.datetime is not None
    # assert generic._datetime is not None
    # assert generic.__getattr__('business') is not None
    assert generic.business is not None
    # assert generic._business is not None
    # assert generic.__getattr__('text') is not None
    assert generic.text is not None
    # assert generic._text is not None
    # assert generic.__getattr__('food') is not None
    assert generic.food is not None
    # assert generic._food is not None
    # assert generic.__get

# Generated at 2022-06-23 21:22:57.549686
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test __dir__."""
    g = Generic()
    dir(g)
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)

# Generated at 2022-06-23 21:22:59.195018
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    print(g.__dir__())

# Generated at 2022-06-23 21:23:10.060123
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    attributes = g.__dir__()
    assert g.locale == g.internet.locale == g.numbers.locale
    assert g.seed == g.internet.seed == g.numbers.seed
    assert isinstance(g.internet.get_ipv4(), str)
    assert isinstance(g.internet.get_ipv6(), str)
    assert isinstance(g.numbers.get_float(), float)
    assert isinstance(g.numbers.get_integer(), int)
    assert attributes
    assert 'internet' in attributes
    assert 'locale' in attributes
    assert 'seed' in attributes
    assert 'numbers' in attributes
    assert 'internet' in g.__dir__()
    assert 'numbers' in g.__dir__()

# Generated at 2022-06-23 21:23:13.786766
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.linux import Linux
    from mimesis.providers.geography import Geography

    g = Generic()
    providers = [Linux, Geography]
    g.add_providers(*providers)
    assert 'linux' in dir(g) and 'geography' in dir(g)

# Generated at 2022-06-23 21:23:18.952976
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers of class Generic."""
    class TestProvider(BaseDataProvider):
        pass
    generic = Generic(iterable=[1, 2, 3, 4, 5, 6, 7, 8, 9, 0])
    generic.add_providers(generic.__class__, TestProvider)
    assert hasattr(generic, 'generic')
    assert hasattr(generic, 'testprovider')

# Generated at 2022-06-23 21:23:26.809807
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    assert not hasattr(gen, 'test_provider_1')
    assert not hasattr(gen, 'test_provider_2')

    class TestProvider1(BaseProvider):
        __slots__ = 'test_field_1', 'test_field_2'

    class TestProvider2(BaseProvider):
        __slots__ = 'test_field_3', 'test_field_4'

    gen.add_providers(TestProvider1, TestProvider2)
    assert hasattr(gen, 'test_provider_1')
    assert hasattr(gen, 'test_provider_2')

    gen.add_providers(TestProvider1, TestProvider2)
    gen.add_providers(TestProvider1, TestProvider2,
                      TestProvider1, TestProvider2)

# Generated at 2022-06-23 21:23:30.051728
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic.__dir__."""
    assert isinstance(Generic().__dir__(), list)
    assert 'all' in Generic().__dir__()


# Generated at 2022-06-23 21:23:33.206180
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    obj = Generic()
    obj.add_provider(Person)
    assert obj.person

    obj.add_provider(Address)
    assert obj.address



# Generated at 2022-06-23 21:23:35.969669
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers."""
    from mimesis.providers.custom import Custom
    g = Generic()
    g.add_providers(Custom)

# Generated at 2022-06-23 21:23:42.464577
# Unit test for constructor of class Generic
def test_Generic():
    data = Generic()
    assert data.address
    assert data.business
    assert data.choice
    assert data.code
    assert data.clothing
    assert data.cryptographic
    assert data.datetime
    assert data.development
    assert data.file
    assert data.food
    assert data.hardware
    assert data.internet
    assert data.numbers
    assert data.person
    assert data.payment
    assert data.path
    assert data.science
    assert data.structure
    assert data.text
    assert data.transport
    assert data.unit_system


# Generated at 2022-06-23 21:23:48.253500
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('en')
    assert gen.choice
    assert gen.text.word()
    assert gen.person.full_name()
    assert gen.address.street_address()
    assert gen.business.company()
    assert gen.food.recipe_name()
    assert gen.science.cell()
    assert gen.transport.car()
    assert gen.code.isbn()
    assert gen.unit_system.length()
    assert gen.numbers.between()
    assert gen.development.framework()
    assert gen.hardware.hardware()
    assert gen.path.path()

# Generated at 2022-06-23 21:23:58.329765
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    generic = Generic(seed=10)
    assert generic.person.name() == 'Gabriel'
    assert generic.address.city() == 'Melbourne'
    assert generic.datetime.time(pattern='long') == '23:26:46.738'
    assert generic.business.company() == 'Hall LLC'
    assert generic.text.title() == 'Могли бы носить уже'
    assert generic.food.dish() == 'тефтели'
    assert generic.science.scientific_name() == 'Sabal etonia'
    assert generic.transport.license_plate_number() == 'I04PY'
    assert generic.code.binary() == '11010110110101011011011101101110'
    assert generic

# Generated at 2022-06-23 21:24:04.730025
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    assert obj.person
    assert obj.address
    assert obj.datetime
    assert obj.science
    assert obj.business
    assert obj.choice
    assert obj.text
    assert obj.food
    assert obj.code
    assert obj.unit_system
    assert obj.file
    assert obj.numbers
    assert obj.development
    assert obj.hardware
    assert obj.clothing
    assert obj.internet
    assert obj.payment
    assert obj.path
    assert obj.cryptographic
    assert obj.structure
    assert obj.transport

# Generated at 2022-06-23 21:24:10.467841
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=1)
    assert generic.datetime.datetime(1900) == 'Mon Apr 26 20:43:09'
    assert generic.datetime.timestamp(1423759081) == 'Mon Jan 26 18:51:21 2015'
    assert generic.datetime.date() == 'Sat Sep 15 2018'
    assert generic.datetime.time() == '01:22:01'
    assert generic.datetime.day_of_week() == 'Friday'
    assert generic.datetime.month_name() == 'February'
    assert generic.datetime.year() == '2079'
    assert generic.datetime.date('DD.MM.YYYY', start=2020, end=2021) == '26.04.2021'

# Generated at 2022-06-23 21:24:13.538427
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('ru')
    assert g.person()
    assert g.address()
    assert g.datetime()
    assert g.business()
    assert g.text()
    assert g.food()
    assert g.science()



# Generated at 2022-06-23 21:24:24.833353
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=123)
    assert generic.seed == 123
    assert generic.locale == 'en'
    # Stands for:
    # data = {
    #     'en': {
    #         'generic': {
    #             'hello': 'Hello!',
    #             'hello_name': 'Hello, {name}!',
    #         }
    #     }
    # }
    data = {'en': {'generic': {'hello': 'Hello!', 'hello_name': 'Hello, {name}!'}}}
    generic.add_provider(GenericDataProvider)
    assert generic.hello() == 'Hello!'
    assert generic.hello_name('John') == 'Hello, John!'

    # Stands for:
    # data = {
    #     'en': {
    #         '

# Generated at 2022-06-23 21:24:34.562477
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    person = generic.person
    mimesis_person = Person('en')
    assert person.username() == mimesis_person.username()
    assert person.username(gender='male') == mimesis_person.username(gender='male')
    assert person.full_name(gender='female') == mimesis_person.full_name(gender='female')
    assert person.surname() == mimesis_person.surname()
    assert person.name(gender='male') == mimesis_person.name(gender='male')
    assert person.full_name() == mimesis_person.full_name()
    assert person.occupation() == mimesis_person.occupation()
    assert person.blood_group() == mimesis_person.blood_group()

# Generated at 2022-06-23 21:24:42.713990
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic()
    assert a.datetime.date() == '2016-08-23'
    assert a.business.company() == 'Hinton Ltd.'
    assert a.person.full_name() == 'Gage Whitaker'
    assert a.text.text() == 'Starting to create a new one.\n'
    assert a.food.fruit() == 'Plum'
    assert a.science.element() == 'protons'
    assert a.transport.vehicle() == 'Honda'
    assert a.code.isbn() == '978-597-912-030-4'
    assert a.unit_system.temperature() == 'kelvin'
    assert a.file.filename_extension() == 'jpg'
    assert a.numbers.integral() > -10

# Generated at 2022-06-23 21:24:47.967765
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for adding providers by method."""
    import mimesis.providers.os

    g = Generic()
    g.add_providers(mimesis.providers.os.OS, Text)
    assert hasattr(g, 'os')
    assert hasattr(g, 'text')

# Generated at 2022-06-23 21:24:51.343866
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        def foo(self):
            return 'bar'

    provider = Generic()
    provider.add_providers(MyProvider)

    assert provider.my_provider.foo() == 'bar'

# Generated at 2022-06-23 21:24:55.218864
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person()
    assert g.address()
    assert g.datetime()
    assert g.business()
    assert g.text()
    assert g.food()
    assert g.science()


# Generated at 2022-06-23 21:25:03.148959
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.code
    assert gen.unit_system
    assert gen.file
    assert gen.numbers
    assert gen.development
    assert gen.hardware
    assert gen.clothing
    assert gen.internet
    assert gen.path
    assert gen.payment
    assert gen.cryptographic
    assert gen.structure
    assert gen.choice
    assert gen.person
    assert gen.datetime
    assert gen.business
    assert gen.text
    assert gen.food
    assert gen.science


# Generated at 2022-06-23 21:25:04.451108
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert generic.__dir__() != []

# Generated at 2022-06-23 21:25:08.482697
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test Generic().add_providers()"""
    class MyProvider(BaseProvider):
        """Class provider"""
        class Meta:
            """Meta class."""
            name = "my_provider"
    g = Generic()
    g.add_providers(MyProvider)
    assert g.my_provider is not None

# Generated at 2022-06-23 21:25:17.182665
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert 'datetime' in g.__dir__()
    assert 'address' in g.__dir__()
    assert 'text' in g.__dir__()
    assert 'food' in g.__dir__()
    assert 'science' in g.__dir__()
    assert 'transport' in g.__dir__()
    assert 'code' in g.__dir__()
    assert 'unit_system' in g.__dir__()
    assert 'file' in g.__dir__()
    assert 'numbers' in g.__dir__()
    assert 'development' in g.__dir__()
    assert 'hardware' in g.__dir__()
    assert 'clothing' in g.__dir__()
    assert 'internet' in g.__dir__()

# Generated at 2022-06-23 21:25:20.328428
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    gen = Generic()

    assert any([method in gen.__dir__() for method in gen.Meta.methods])

# Generated at 2022-06-23 21:25:22.460733
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_instance = Generic()
    attribute = generic_instance.person
    assert callable(attribute)

# Generated at 2022-06-23 21:25:23.122879
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:25:30.348621
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # GIVEN a class, and classes
    class Custom1(BaseProvider):
        class Meta:
            name = 'custom1'
    class Custom2(BaseProvider):
        class Meta:
            name = 'custom2'
    class Custom3(BaseProvider):
        class Meta:
            name = 'custom3'
    # WHEN instantiate a Generic and call
    # add_providers method
    g = Generic()
    g.add_providers(Custom1, Custom2, Custom3)
    # THEN assert a newly attributes
    assert hasattr(g, 'custom1')
    assert hasattr(g, 'custom2')
    assert hasattr(g, 'custom3')



# Generated at 2022-06-23 21:25:37.348645
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    
    g = Generic()
    g.add_providers(Person, Address, Datetime)

    assert g.person.seed is g.seed
    assert g.address.seed is g.seed
    assert g.datetime.seed is g.seed

# Generated at 2022-06-23 21:25:41.812731
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Tests for method add_provider of class Generic."""

    from mimesis.providers.other import Other
    from mimesis.enums import Gender

    g = Generic()
    g.add_provider(Other)
    assert g.other.gender == Gender.MALE


# Generated at 2022-06-23 21:25:52.977679
# Unit test for constructor of class Generic
def test_Generic():

    from mimesis import Generic
    from mimesis.providers.development import Development
    from mimesis.providers.payment import Payment

    gen = Generic()
    gen.add_provider(Development)
    gen.add_providers(Payment)

    print("*"*10+" Attributes of Generic " + "*"*10)
    # Here we can see that attributes of class Generic appear at once
    # as if they were added successively line by line
    print("gen.data_providers = ", gen.data_providers)
    print("gen.address = ", gen.address)
    print("gen.person = ", gen.person)
    print("gen.business = ", gen.business)
    print("gen.text = ", gen.text)
    print("gen.food = ", gen.food)

# Generated at 2022-06-23 21:25:57.132718
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    v = Generic()
    v.person.full_name()
    assert isinstance(v.person, Person)
    v.datetime.datetime()
    assert isinstance(v.datetime, Datetime)
    v.business.company()
    assert isinstance(v.business, Business)

# Generated at 2022-06-23 21:26:00.461022
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    attrs = gen.__dir__()
    assert isinstance(attrs, list)
    assert len(attrs) == 42
    assert attrs[0] == 'address'
    assert attrs[-1] == 'structure'


# Generated at 2022-06-23 21:26:03.926667
# Unit test for constructor of class Generic
def test_Generic():
    # Unit test for __init__ method
    gen = Generic('en')
    assert gen.datetime.now().datetime() is not None
    

# Generated at 2022-06-23 21:26:13.044365
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic(seed=1)

    assert gen.business.company_name() == 'Mishka, Inc.'
    assert gen.person.full_name() == 'Елена Степанова'
    assert gen.address.street_name() == 'Коммунарская'
    assert gen.datetime.date() == '2012-10-15'

# Generated at 2022-06-23 21:26:15.123774
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    providers = gen.__dir__()
    assert isinstance(providers, list)
    assert len(providers) > 0

# Generated at 2022-06-23 21:26:18.992852
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def abc(self):
            return 'abc'

    g = Generic()
    g.add_provider(MyProvider)
    assert g.abc() == 'abc'

# Generated at 2022-06-23 21:26:25.755755
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()

    assert type(generic.person) == Person
    assert type(generic.address) == Address
    assert type(generic.datetime) == Datetime
    assert type(generic.business) == Business
    assert type(generic.text) == Text
    assert type(generic.food) == Food
    assert type(generic.development) == Development
    assert type(generic.hardware) == Hardware
    assert type(generic.clothing) == Clothing
    assert type(generic.internet) == Internet
    assert type(generic.payment) == Payment
    assert type(generic.path) == Path
    assert type(generic.cryptographic) == Cryptographic
    assert type(generic.structure) == Structure
    assert type(generic.choice) == Choice



# Generated at 2022-06-23 21:26:37.050679
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    # True
    g = Generic()
    # pprint.pprint(dir(g))
    # ['Meta', '_address', '_business', '_choice', '_clothing',
    #  '_code', '_cryptographic', '_datetime', '_development',
    #  '_file', '_food', '_hardware', '_internet', '_numbers',
    #  '_path', '_payment', '_person', '_science', '_structure',
    #  '_text', '_transport', '_unit_system', 'choice', 'code',
    #  'cryptographic', 'datetime', 'development', 'file', 'food',
    #  'hardware', 'internet', 'numbers', 'path', '

# Generated at 2022-06-23 21:26:40.279718
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Print list of providers.

    It's used to check __all__ in mimesis/__init__.py
    """
    generate = Generic()
    print(generate.__dir__())

# Generated at 2022-06-23 21:26:42.040160
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    attribute = Generic()
    assert attribute.person is not None


# Generated at 2022-06-23 21:26:47.200286
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    person = generic.person
    assert person.full_name() == 'Donald Randall'
    assert person.full_name(gender='male') == 'Ramon Lamb'
    assert person.username() == 'daniellarose'
    assert person.username(prefix='x') == 'xjeanniemccray'

# Generated at 2022-06-23 21:26:53.201342
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return "bar"

    generic = Generic()
    generic.add_provider(Provider)
    assert getattr(generic, 'provider').foo() == "bar"


# Generated at 2022-06-23 21:26:58.504376
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person) is True
    assert isinstance(g.address, Address) is True
    assert isinstance(g.datetime, Datetime) is True
    assert isinstance(g.business, Business) is True
    assert isinstance(g.text, Text) is True
    assert isinstance(g.food, Food) is True
    assert isinstance(g.science, Science) is True

# Generated at 2022-06-23 21:27:02.995450
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.network import Network
    from mimesis.providers.file import Hash
    gen = Generic()
    gen.add_providers(Network, Hash)

    assert hasattr(gen, 'network') and hasattr(gen, 'hash')

# Generated at 2022-06-23 21:27:09.662758
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ method of the Generic class."""
    generic = Generic('en')
    assert generic.person is not None
    assert isinstance(generic.person, Person)
    assert generic.datetime is not None
    assert isinstance(generic.datetime, Datetime)
    assert generic.address is not None
    assert isinstance(generic.address, Address)
    assert generic.business is not None
    assert isinstance(generic.business, Business)


# Generated at 2022-06-23 21:27:18.118629
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    #test
    gen = Generic('ru')

    #get first name
    result = gen.person.name()
    assert isinstance(result, str)

    #get last name
    result = gen.person.surname()
    assert isinstance(result, str)

    #get address
    result = gen.address.address()
    assert isinstance(result, str)

    #get payment
    result = gen.payment.iban()
    assert isinstance(result, str)

    #get structure
    result = gen.structure.company_name()
    assert isinstance(result, str)

    pass


# Generated at 2022-06-23 21:27:20.806396
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    r = Generic().__getattr__('person')
    assert isinstance(r, Person)


# Generated at 2022-06-23 21:27:21.954549
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Generic()._person
    Generic()._address
    Generic()._text
    Generic()._food
    Generic()._science

# Generated at 2022-06-23 21:27:24.123883
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    provider = Generic()
    result = provider.__dir__()
    assert type(result) == list
    assert len(result) == 33
    assert 'person' in result

# Generated at 2022-06-23 21:27:32.871865
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender

    class MyProvider(BaseProvider):
        class Meta:
            name = "myprovider"

        def get_gender(self) -> str:
            return Gender.FEMALE.value

    class MyProvider2(BaseProvider):
        class Meta:
            name = "myprovider2"

        def get_gender(self) -> str:
            return Gender.FEMALE.value

    generic = Generic("en")
    generic.add_providers(MyProvider, MyProvider2)

    assert getattr(generic, 'myprovider')
    assert getattr(generic, 'myprovider2')
    assert generic.myprovider.get_gender() == Gender.FEMALE.value
    assert generic.myprovider2.get_gender() == Gender.FEMALE.value

#

# Generated at 2022-06-23 21:27:38.150461
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    person = gen.person
    address = gen.address
    datetime = gen.datetime
    business = gen.business
    text = gen.text
    food = gen.food
    science = gen.science
    transport = gen.transport
    code = gen.code
    unit_system = gen.unit_system
    file = gen.file
    numbers = gen.numbers
    development = gen.development
    hardware = gen.hardware
    clothing = gen.clothing
    internet = gen.internet
    path = gen.path
    payment = gen.payment
    cryptographic = gen.cryptographic
    structure = gen.structure
    choice = gen.choice

# Generated at 2022-06-23 21:27:41.311601
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test whether the addition of a custom provider class is successful."""
    gen = Generic('es')
    gen.add_provider(Type[BaseProvider])
    assert hasattr(gen, 'test') == True


# Generated at 2022-06-23 21:27:46.508255
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic.choice
    assert generic.business
    assert generic.unit_system
    assert generic.structure
    assert generic.category
    assert generic.person
    assert generic.address
    assert generic.datetime
    assert generic.text
    assert generic.food
    assert generic.science
    assert generic.transport
    assert generic.code
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic

# Generated at 2022-06-23 21:27:49.764528
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    setattr(generic, 'test_name', generic.choice)
    assert hasattr(generic, 'test_name')

# Generated at 2022-06-23 21:27:59.173889
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    class CustomProvider(BaseProvider):
        """Custom provider."""
        class Meta:
            """Class for metadata."""
            name = 'custom'

        def method(self) -> str:
            """Return string."""
            return 'test'

    def test_add_provider():
        """Test add_provider method."""
        generic = Generic()
        generic.add_provider(CustomProvider)
        assert 'custom' in dir(generic)
        assert generic.custom.method() == 'test'

    test_add_provider()

# Generated at 2022-06-23 21:28:00.101972
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__()

# Generated at 2022-06-23 21:28:05.437272
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self) -> str:
            return self.__class__.__name__

    gen = Generic()
    gen.add_providers(Custom)
    assert gen.custom.foo() == 'Custom'


# Generated at 2022-06-23 21:28:13.208475
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert Generic().__dir__() == []
    asserts = ['person', 'address', 'datetime', 'business', 'text',
               'food', 'science', 'transport', 'code', 'unit_system',
               'file', 'numbers', 'development', 'hardware', 'clothing',
               'internet', 'path', 'payment', 'cryptographic',
               'structure', 'choice']
    provider = Generic()
    assert len(asserts) == len(provider.__dir__())
    for assert_ in asserts:
        assert assert_ in provider.__dir__()

# Generated at 2022-06-23 21:28:20.810269
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.business, Business)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.text, Text)
    assert isinstance(g.science, Science)
    assert isinstance(g.food, Food)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:28:28.302321
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    generic = Generic('en-EN')
    keys = generic.__dir__()
    # provider = Generic('en-EN')
    # print('-' * 16)
    # print(provider.__dict__)
    # print('-' * 16)
    # print(provider.__dir__())
    # print('-' * 16)
    # print(provider.__getattr__('address'))
    # print('-' * 16)
    assert keys

# Generated at 2022-06-23 21:28:36.611267
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Given
    from mimesis.providers.transport import Vehicle
    brand_name = 'Volkswagen'
    color = 'black'
    fuel = 'petrol'
    number_of_doors = 3
    number_of_seats = 8

    # When
    class CustomVehicle(Vehicle):
        def brand(self) -> str:
            return brand_name

        def color(self) -> str:
            return color

        def fuel(self) -> str:
            return fuel

        def number_of_doors(self) -> int:
            return number_of_doors

        def number_of_seats(self) -> int:
            return number_of_seats

    generic = Generic()
    generic.add_provider(CustomVehicle)

    # Then

# Generated at 2022-06-23 21:28:44.838707
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic('en')
    assert a.address.get_state() == 'South Carolina'
    assert isinstance(a.address, Address)
    assert isinstance(a.datetime, Datetime)
    assert isinstance(a.business, Business)
    assert isinstance(a.text, Text)
    assert isinstance(a.food, Food)
    assert isinstance(a.science, Science)
    assert isinstance(a.transport, Transport)
    assert isinstance(a.code, Code)
    assert isinstance(a.unit_system, UnitSystem)
    assert isinstance(a.file, File)
    assert isinstance(a.numbers, Numbers)
    assert isinstance(a.development, Development)
    assert isinstance(a.hardware, Hardware)

# Generated at 2022-06-23 21:28:47.240997
# Unit test for constructor of class Generic
def test_Generic():
    """The unit-test for module Generic"""
    assert Generic().internet.email() == "emil.barcenas@yahoo.com"

# Generated at 2022-06-23 21:28:53.990691
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers import Crypto
    assert issubclass(Generic().cryptographic.__class__, Crypto)
    from mimesis.providers import Text
    assert issubclass(Generic().text.__class__, Text)
    from mimesis.providers import Address
    assert issubclass(Generic().address.__class__, Address)
    from mimesis.providers import UnitSystem
    assert issubclass(Generic().unit_system.__class__, UnitSystem)


# Generated at 2022-06-23 21:28:55.935837
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.generators.generic import Generic
    g = Generic()
    n = g.numbers
    n.gen_digit()

# Generated at 2022-06-23 21:28:57.658310
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Note, Note)
    assert Note.Meta.name in dir(g)



# Generated at 2022-06-23 21:29:01.439051
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test if providers are added to list of available methods."""
    # Create a new instance of Generic.
    g = Generic()
    providers = dir(g)
    assert 'business' in providers
    assert 'development' in providers
    assert 'code' in providers
    assert 'internet' in providers
    assert 'unit_system' in providers


# Generated at 2022-06-23 21:29:13.656623
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert 'address' in dir(gen)
    assert 'business' in dir(gen)
    assert 'clothing' in dir(gen)
    assert 'code' in dir(gen)
    assert 'choice' in dir(gen)
    assert 'cryptographic' in dir(gen)
    assert 'datetime' in dir(gen)
    assert 'development' in dir(gen)
    assert 'file' in dir(gen)
    assert 'food' in dir(gen)
    assert 'hardware' in dir(gen)
    assert 'internet' in dir(gen)
    assert 'numbers' in dir(gen)
    assert 'payment' in dir(gen)
    assert 'path' in dir(gen)
    assert 'person' in dir(gen)
    assert 'science' in dir(gen)
   

# Generated at 2022-06-23 21:29:16.913677
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic()
    # Check for list of all providers
    assert isinstance(a.__dir__(), list)
    assert all(isinstance(x, str) for x in a.__dir__())

# Generated at 2022-06-23 21:29:27.425139
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    generic = Generic()
    expected_result = [
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'person',
        'payment',
        'science',
        'structure',
        'transport',
        'unit_system',
    ]
    assert structurally_equal(
        sorted(generic.__dir__()),
        expected_result,
    )

# Generated at 2022-06-23 21:29:38.896880
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=42)
    assert isinstance(g.person, Person)
    assert g.person.name() == 'Пётр'
    assert isinstance(g.datetime, Datetime)
    assert g.datetime.timestamp() == 1170279426
    assert isinstance(g.address, Address)
    assert g.address.full_address() == 'Харьковская область, город Дружковка, Данилов улица, 15'
    assert isinstance(g.text, Text)