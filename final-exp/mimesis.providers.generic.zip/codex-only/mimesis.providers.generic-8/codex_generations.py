

# Generated at 2022-06-23 21:19:44.120905
# Unit test for constructor of class Generic
def test_Generic():
    data = Generic()

    assert data is not None


# Generated at 2022-06-23 21:19:52.674345
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test generic.Generic()

    Ensures that the following methods are available:
        - person
        - address
        - datetime
        - business
        - text
        - food
        - science
        - transport
        - code
        - unit_system
        - file
        - numbers
        - development
        - hardware
        - clothing
        - internet
        - path
        - payment
        - cryptographic
        - structure
        - choice
    """
    gen = Generic()

if __name__ == '__main__':
    test_Generic___dir__()

# Generated at 2022-06-23 21:19:57.822137
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    for provider in dir(g):
        name = '_' + provider
        assert getattr(g, name) is None
        assert isinstance(
            getattr(g, provider), BaseProvider)



# Generated at 2022-06-23 21:19:59.658321
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic
    """
    generic = Generic()
    assert generic is not None


# Generated at 2022-06-23 21:20:00.306435
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-23 21:20:05.199614
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test class Generic."""
    gen = Generic(seed=123)
    actual = gen.datetime.datetime()
    expected = '2003-11-15 13:23:42'
    assert expected == actual
    assert isinstance(gen.datetime, Datetime)


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-23 21:20:10.207182
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    geo = Generic(seed=777)
    geo.add_providers(Text, Business)
    assert geo.choice.choices('Python') == 'Python'
    assert geo.text.all() == 'zhong guo'


# Generated at 2022-06-23 21:20:13.177104
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    #This test fails as ported to Python, because the __dir__ method is not called at all.
    A = Generic()
    assert len(A.__dir__()) == 1



# Generated at 2022-06-23 21:20:15.976259
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic("en")
    result = generic.__dir__()
    assert isinstance(result, list)
    assert len(result) > 0
    generic.add_provider(Code)
    result = generic.__dir__()
    assert isinstance(result, list)
    assert len(result) > 0

# Generated at 2022-06-23 21:20:27.709243
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super(CustomProvider, self).__init__(*args, **kwargs)
            self.c = 'c'

        class Meta:
            name = 'foo'

        def foo(self):
            return 'foo'

    class CustomProvider2(BaseProvider):
        def __init__(self, *args, **kwargs):
            super(CustomProvider2, self).__init__(*args, **kwargs)
            self.d = 'd'

        class Meta:
            name = 'bar'

        def bar(self):
            return 'bar'

    gen = Generic()
    assert len(gen.__dict__) == 26
    gen.add_providers(CustomProvider, CustomProvider2)

# Generated at 2022-06-23 21:20:31.886452
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for __dir__ method."""
    expected = ['person', 'address', 'datetime',
                'business', 'text', 'food',
                'science', 'transport', 'code',
                'unit_system', 'file', 'numbers',
                'development', 'hardware', 'clothing',
                'internet', 'path', 'payment',
                'cryptographic', 'structure', 'choice']
    assert sorted(dir(Generic())) == sorted(expected)

# Generated at 2022-06-23 21:20:35.863127
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        foo = 'bar'
    generic = Generic()
    assert not hasattr(generic, 'foo')
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'foo')

# Generated at 2022-06-23 21:20:38.846464
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()

    for attr in dir(gen):
        if '__' in attr:
            continue
        assert hasattr(gen, attr)


# Generated at 2022-06-23 21:20:40.351362
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    assert provider is not None


# Generated at 2022-06-23 21:20:44.044087
# Unit test for constructor of class Generic
def test_Generic():
    if __name__ == '__main__':
        print(Generic().random)
    else:
       assert Generic().random == '415cbf40-aa5e-58b7-bdb9-ec5ee1677b36'


# Generated at 2022-06-23 21:20:52.526597
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """."""
    generic = Generic()
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'text')
    assert hasattr(generic, 'food')
    assert hasattr(generic, 'science')
    assert hasattr(generic, 'transport')
    assert hasattr(generic, 'code')
    assert hasattr(generic, 'unit_system')
    assert hasattr(generic, 'file')
    assert hasattr(generic, 'numbers')
    assert hasattr(generic, 'development')
    assert hasattr(generic, 'hardware')
    assert hasattr(generic, 'clothing')
    assert hasattr(generic, 'internet')

# Generated at 2022-06-23 21:20:57.422139
# Unit test for constructor of class Generic
def test_Generic():
    # Test for __getattr__
    print(Generic())

    # Test for __dir__
    g = Generic()
    generic_attributes = g.__dir__()
    assert generic_attributes is not None

    # Test for add_provider
    g.add_provider(Path)
    assert g.path

    # Test for add_providers
    g.add_providers(Path, Cryptographic)
    assert g.path
    assert g.cryptographic

# Generated at 2022-06-23 21:21:00.872178
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Person, Address)
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')

# Generated at 2022-06-23 21:21:04.664808
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert type(g.__dir__()) is list
    assert len(g.__dir__()) >= 32
    assert 'person' in g.__dir__()
    assert 'table' not in g.__dir__()



# Generated at 2022-06-23 21:21:10.307815
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    providers = (Address, Person)
    g.add_providers(*providers)
    assert isinstance(g.address, Address)
    assert isinstance(g.person, Person)



# Generated at 2022-06-23 21:21:16.139342
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of class Generic"""
    from mimesis.providers.auxiliary import Auxiliary
    generic = Generic('en')
    assert not hasattr(generic, 'Auxiliary')
    generic.add_provider(Auxiliary)
    assert hasattr(generic, 'auxiliary')



# Generated at 2022-06-23 21:21:20.257619
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'
        
        def foo(self):
            """Custom method."""
            return "Foo"

    generic = Generic()
    generic.add_provider(CustomProvider)

    assert 'custom_provider' in generic.__dir__()
    assert 'foo' in generic.__dir__()

# Generated at 2022-06-23 21:21:24.937604
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Country(BaseProvider):
        def country(self):
            return 'Australia'

    assert hasattr(Generic(), 'country')  # False

    gen = Generic()
    gen.add_provider(Country)

    assert gen.country.country() == 'Australia'
    
    

# Generated at 2022-06-23 21:21:34.492791
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test custom provider."""
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Return 'foo'."""
            return 'foo'

    generator = Generic()
    try:
        generator.add_provider(CustomProvider)
    except TypeError:
        return False
    else:
        if hasattr(generator, 'custom') and generator.custom.foo() == 'foo':
            return True



# Generated at 2022-06-23 21:21:38.280185
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text
    generic = Generic()
    custom_providers = [Datetime, Text]
    generic.add_providers(*custom_providers)

    assert type(generic.datetime) is type(custom_providers[0](seed=generic.seed))



# Generated at 2022-06-23 21:21:40.159948
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic is not None


# Generated at 2022-06-23 21:21:43.005338
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic._person is None
    assert generic.person



# Generated at 2022-06-23 21:21:46.456971
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import system

    generic = Generic()
    assert generic.system is None

    generic.add_provider(system.System)
    assert isinstance(generic.system, system.System)
    assert generic.system is not None



# Generated at 2022-06-23 21:21:51.713379
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.text  # call __getattr__
    g.person  # call __getattr__
    g.address  # call __getattr__
    assert 'text' in g.__dict__
    assert 'person' in g.__dict__
    assert 'address' in g.__dict__



# Generated at 2022-06-23 21:21:53.351173
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(getattr(g, 'person'))

# Generated at 2022-06-23 21:21:54.173562
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    c = Generic()
    print(c.__dir__())

# Generated at 2022-06-23 21:21:59.297190
# Unit test for constructor of class Generic
def test_Generic():
    import mimesis
    data = mimesis.Generic()
    # assert isinstance(data,mimesis.Generic)
    assert hasattr(data, 'choice')
    assert hasattr(data, 'clothing')
    assert hasattr(data, 'code')
    assert hasattr(data, 'cryptographic')
    assert hasattr(data, 'development')
    assert hasattr(data, 'file')
    assert hasattr(data, 'food')
    assert hasattr(data, 'hardware')
    assert hasattr(data, 'internet')
    assert hasattr(data, 'numbers')
    assert hasattr(data, 'path')
    assert hasattr(data, 'payment')
    assert hasattr(data, 'person')
    assert hasattr(data, 'science')
    assert hasattr(data, 'text')

# Generated at 2022-06-23 21:22:04.213341
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = 'custom'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def do_something(self):
            return 'Hello, world!'

    g = Generic()
    g.add_provider(Provider)
    assert hasattr(g, 'custom')
    assert g.custom.do_something() == 'Hello, world!'


# Generated at 2022-06-23 21:22:09.191981
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    dir_generic = dir(generic)
    assert len(dir_generic) == 37
    assert 'business' in dir_generic
    assert 'datetime' in dir_generic
    assert 'text' in dir_generic
    assert 'numbers' in dir_generic
    assert 'science' in dir_generic

# Generated at 2022-06-23 21:22:16.278303
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__() of class Generic."""
    assert Generic().__dir__() == [
        'person', 'address', 'datetime', 'business',
        'text', 'food', 'science', 'transport', 'code',
        'unit_system', 'file', 'numbers', 'development',
        'hardware', 'clothing', 'internet', 'path',
        'payment', 'cryptographic', 'structure', 'choice'
    ]

# Generated at 2022-06-23 21:22:21.329934
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    # try to get attribute "full_name" of person
    assert g.person.full_name is not None
    assert g.locale == 'en'

# Generated at 2022-06-23 21:22:31.545460
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic(seed=5)
    name = hex(id(obj))
    assert obj is not None, "Object is None"
    assert len(obj.__dict__) > 0, "Length of object is zero"
    assert 'seed' in obj.__dict__, "seed not found in object"
    assert '_datetime' in obj.__dict__, "_datetime not found in object"
    assert '_business' in obj.__dict__, "_business not found in object"
    assert '_text' in obj.__dict__, "_text not found in object"
    assert '_food' in obj.__dict__, "_food not found in object"
    assert '_science' in obj.__dict__, "_science not found in object"

# Generated at 2022-06-23 21:22:39.489896
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Create a lot of custom providers instance"""
    providers = [Person, Address, Datetime]
    generic = Generic(locale="ru")
    generic.add_providers(Person, Address, Datetime)
    for provider in providers:
        assert provider(locale="ru") in generic.__dict__.values()
    for cls in providers:
        if 'Meta' in cls.__dict__:
            assert cls.Meta.name in generic.__dict__
        else:
            assert cls.__name__.lower() in generic.__dict__

# Generated at 2022-06-23 21:22:41.450640
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.embedded import Embedded
    custom = Generic()
    custom.add_providers(Embedded)
    assert len(custom.__dir__()) == 31

# Generated at 2022-06-23 21:22:46.295023
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    '''
    Unit test for method add_provider of class Generic
    '''
    Generic().add_provider(Provider)
    print(Generic().__dict__)
    assert Generic().__dict__['provider'].__class__ == Provider


# Generated at 2022-06-23 21:22:52.453858
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit testing for add_provider of Generic."""
    generic = Generic()
    generic.add_provider(DateTime)
    assert 'datetime' in generic.__dict__.keys()
    # Raising TypeError
    try:
        generic.add_provider(str)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-23 21:22:56.345342
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person is not None
    assert gen.address is not None
    assert gen.datetime is not None
    assert gen.business is not None
    assert gen.text is not None
    assert gen.food is not None
    assert gen.science is not None

# Generated at 2022-06-23 21:23:07.312876
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    def custom_provider():
        class MyProvider(BaseDataProvider):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)

            class Meta:
                name = 'my_provider'

            def custom_method(self):
                return 'a'

        return MyProvider

    class CustomProvider(BaseDataProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

        def custom_method(self):
            return 'b'


    data = Generic(locale='en')
    data.add_provider(custom_provider())
    data.add_providers(CustomProvider)
    
    assert data.my_

# Generated at 2022-06-23 21:23:12.924341
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers."""
    from mimesis.providers import BaseProvider
    class User(BaseProvider):
        """Test class."""

        class Meta:
            """Test Meta."""

            name = 'user'

        def user(self):
            """Test user."""
            return self.datetime.timestamp()

    from mimesis.providers import Address, Person
    _providers = [Address, Person]
    gen = Generic()
    assert not hasattr(gen, 'address')
    assert not hasattr(gen, 'person')
    assert not hasattr(gen, 'user')
    gen.add_providers(*_providers)
    assert hasattr(gen, 'address')
    assert hasattr(gen, 'person')
    assert not hasattr(gen, 'user')
    gen.add_

# Generated at 2022-06-23 21:23:21.810101
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'
    
        def method(self):
            return 'Custom method'
    
    class CustomProvider2(BaseProvider):
        class Meta:
            name = 'custom2'
    
        def method(self):
            return 'Custom2 method'
    
    gen = Generic()
    gen.add_provider(CustomProvider)
    assert gen.custom.method() == 'Custom method'
    gen.add_providers(CustomProvider, CustomProvider2)
    assert gen.custom.method() == 'Custom method'
    assert gen.custom2.method() == 'Custom2 method'


if __name__ == '__main__':
    test_Generic_add_provider()

# Generated at 2022-06-23 21:23:33.109324
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__ of class Generic."""
    gen = Generic()
    d = dir(gen)
    assert isinstance(d, list)
    assert len(d) != 0
    assert 'Meta' in d
    assert 'choice' in d
    assert 'person' in d
    assert 'address' in d
    assert 'datetime' in d
    assert 'business' in d
    assert 'text' in d
    assert 'food' in d
    assert 'science' in d
    assert 'transport' in d
    assert 'code' in d
    assert 'unit_system' in d
    assert 'file' in d
    assert 'numbers' in d
    assert 'development' in d
    assert 'hardware' in d
    assert 'clothing' in d
    assert 'internet' in d

# Generated at 2022-06-23 21:23:36.240039
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic()._person
    assert Generic().address
    assert Generic().datetime
    assert Generic().business
    assert Generic().text
    assert Generic().food
    assert Generic().science


# Generated at 2022-06-23 21:23:36.899119
# Unit test for method add_providers of class Generic

# Generated at 2022-06-23 21:23:44.941076
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Expected result
    expected_result = [
        'address',
        'add_provider',
        'add_providers',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'payment',
        'path',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]
    # Get result
    result = sorted(list(Generic().__dir__()))
    # Check
    assert result == expected_result

# Generated at 2022-06-23 21:23:51.087595
# Unit test for constructor of class Generic
def test_Generic():
    global generic_provider
    generic_provider = Generic()
#Unit test for add_providers of class Generic
    generic_provider.add_providers()
#Unit test for __dir__ of class Generic
generic_provider.__dir__()
#Unit test for __getattr__ of class Generic
generic_provider.__getattr__("_address")

# Generated at 2022-06-23 21:23:53.851867
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Person, Address, Datetime)
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None

# Generated at 2022-06-23 21:23:55.631487
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    Generic().__dir__()

# Generated at 2022-06-23 21:23:58.434780
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    instance = Generic()
    assert isinstance(instance, Generic)



# Generated at 2022-06-23 21:23:59.053531
# Unit test for constructor of class Generic
def test_Generic():
    pass

# Generated at 2022-06-23 21:24:01.029965
# Unit test for constructor of class Generic
def test_Generic():
    t = Generic()
    assert hasattr(t, 'person')
    assert hasattr(t, 'food')
    assert hasattr(t, 'text')

# Generated at 2022-06-23 21:24:02.474274
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic.address() != None
    assert generic.choice() != None
    assert generic.business() != None

# Generated at 2022-06-23 21:24:07.476947
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science
    from mimesis.providers.person import Person

    class Custom(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def get_something(self):
            return 'get_something'

    g = Generic()
    g.add_provider(Person)
    g.add_provider(Science)
    g.add_provider(Custom)
    assert isinstance(g.person, Person)
    assert isinstance(g.science, Science)
    assert g.custom.get_something() == 'get_something'

# Generated at 2022-06-23 21:24:08.263106
# Unit test for method add_providers of class Generic

# Generated at 2022-06-23 21:24:16.662094
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic
    assert g.Meta
    assert g.Meta.name == 'generic'
    assert g.__getattr__('person')
    assert g.__getattr__('address')
    assert g.__getattr__('datetime')
    assert g.__getattr__('business')
    assert g.__getattr__('text')
    assert g.__getattr__('food')
    assert g.__getattr__('science')
    assert g.__getattr__('transport')
    assert g.__getattr__('code')
    assert g.__getattr__('unit_system')
    assert g.__getattr__('file')
    assert g.__getattr__('numbers')
    assert g.__getattr__('development')
    assert g.__getattr__('hardware')

# Generated at 2022-06-23 21:24:18.940404
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
   obj = Generic('zh') 
   assert not hasattr(obj, 'person')
   assert isinstance(obj.person, Person)

# Generated at 2022-06-23 21:24:29.178448
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic()
    person = data.person
    address = data.address
    datetime = data.datetime
    business = data.business
    text = data.text
    food = data.food
    science = data.science

    assert 'person' in dir(data)
    assert 'address' in dir(data)
    assert 'datetime' in dir(data)
    assert 'business' in dir(data)
    assert 'text' in dir(data)
    assert 'food' in dir(data)
    assert 'science' in dir(data)

    assert person.full_name() is not None
    assert address.address() is not None
    assert datetime.weekday() is not None
    assert business.company() is not None
    assert text.text() is not None

# Generated at 2022-06-23 21:24:34.146177
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.identity import Identity
    from mimesis.providers.numbers import Cardinal

    identity = Identity().__class__
    cardinal = Cardinal().__class__
    generic = Generic()
    generic.add_providers(identity, cardinal)
    assert generic.person
    assert generic.identity
    assert generic.cardinal

# Generated at 2022-06-23 21:24:39.661210
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.science import Science
    from mimesis.providers.food import Food
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.science, Science)

# Generated at 2022-06-23 21:24:41.787232
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.user_agent == g._user_agent(g.locale, g.seed)

# Generated at 2022-06-23 21:24:44.324601
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = g.__dir__()
    
    assert type(result) == list
    assert len(result) == 2

# Generated at 2022-06-23 21:24:54.648476
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

        def provide(self):
            return self.random.randint(1, 10)

        def provide_float(self):
            return self.random.randint(1, 10) / 10

    class Provider2(BaseProvider):
        class Meta:
            name = 'provider2'

        def provide(self):
            return self.random.randint(1, 10)

    g = Generic()
    g.add_providers(Provider, Provider2)
    assert 'provider' in g.__dir__()
    assert 'provider2' in g.__dir__()
    assert isinstance(g.provider.provide(), int)
    assert isinstance(g.provider2.provide(), int)


# Generated at 2022-06-23 21:24:58.915521
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('de')
    person = gen.person
    assert person.full_name() == 'Vanessa König'
    person = gen.person
    assert person.full_name() == 'Vanessa König'
    person = gen.person
    assert person.full_name() == 'Vanessa König'



# Generated at 2022-06-23 21:25:06.711518
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Testing method add_providers of class Generic."""
    from mimesis.enums import Gender

    class GenderProvider(BaseProvider):
        """Custom provider for testing add_providers
        method of class Generic.
        """

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def gender(self):
            return Gender.MALE.value

    class CategoryProvider(BaseProvider):
        """Custom provider for testing add_providers method of
        class Generic.
        """

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def category(self):
            return 'category'

    generic = Generic()
    generic.add_providers(GenderProvider, CategoryProvider)

# Generated at 2022-06-23 21:25:11.998808
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom_provider')


# Generated at 2022-06-23 21:25:20.552148
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    # TODO: make a better test
    dir_result = g.__dir__()
    assert 'person' in dir_result
    assert 'address' in dir_result
    assert 'datetime' in dir_result
    assert 'business' in dir_result
    assert 'text' in dir_result
    assert 'food' in dir_result
    assert 'science' in dir_result
    assert 'transport' in dir_result
    assert 'code' in dir_result
    assert 'unit_system' in dir_result
    assert 'file' in dir_result
    assert 'numbers' in dir_result
    assert 'development' in dir_result
    assert 'hardware' in dir_result
    assert 'clothing' in dir_result
    assert 'internet' in dir_result

# Generated at 2022-06-23 21:25:23.534360
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().person().full_name() == 'Павел Иванов'
    assert Generic().business().company().name


# Generated at 2022-06-23 21:25:25.255386
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert 'food' in gen.__dir__()



# Generated at 2022-06-23 21:25:29.062508
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Foo(BaseProvider):
        class Meta:
            name = 'test'

        def get_string(self):
            return 'I am a test'

    class Bar(BaseProvider):
        def get_string(self):
            return 'I am a provider'


    gen = Generic()
    gen.add_provider(Foo)
    gen.add_provider(Bar)
    assert gen.test.string() == 'I am a test'
    assert gen.bar.string() == 'I am a provider'



# Generated at 2022-06-23 21:25:40.754795
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    generic = Generic()

    actual = dir(generic)
    expected = [
        'add_provider',
        'add_providers',
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'payment',
        'person',
        'path',
        'science',
        'seed',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

    assert actual == expected


# Generated at 2022-06-23 21:25:42.818168
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert 'french' not in dir(generic)
    import mimesis.providers.address
    generic.add_provider(mimesis.providers.address.Address)
    assert 'address' in dir(generic)


# Generated at 2022-06-23 21:25:48.778721
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert hasattr(Generic(seed=1), 'person')
    assert hasattr(Generic(seed=1), 'datetime')
    assert hasattr(Generic(seed=1), 'address')
    assert hasattr(Generic(seed=1), 'business')
    assert hasattr(Generic(seed=1), 'text')
    assert hasattr(Generic(seed=1), 'food')
    assert hasattr(Generic(seed=1), 'science')



# Generated at 2022-06-23 21:25:50.224403
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic() is not None

# Generated at 2022-06-23 21:25:54.183156
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.cards import Cards

    generic = Generic()
    generic.add_provider(Cards)
    assert generic.cards.__class__.__name__ == 'Cards'


# Testing for Generic

# Generated at 2022-06-23 21:26:02.609410
# Unit test for constructor of class Generic
def test_Generic():
    # Test for constructor of class Generic
    g = Generic()
    # Test for initial value of locale
    locale = getattr(g, 'locale', 'en')
    assert locale == 'en'
    # Test for initial seed
    seed = getattr(g, 'seed', 'mimesis')
    assert seed == 'mimesis'
    # Test for exception raise
    try:
        Generic('a', 'b', 'c')
    except TypeError:
        pass
    # Test for exception raise
    try:
        Generic(False, 'c', 'c')
    except ValueError:
        pass
    # Test for exception raise
    try:
        Generic('a', 'b', False)
    except ValueError:
        pass
    # Test for constructor

# Generated at 2022-06-23 21:26:09.081372
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # test when the provider is not a class
    g1 = Generic('en')
    assert g1.add_provider(g1) == None
    # test when the provider is a class
    g2 = Generic('en')
    assert g2.add_provider(Business) == None
    # test when the provider is not a subclass of BaseProvider
    g3 = Generic('en')
    assert g3.add_provider(Generic) == TypeError

# Generated at 2022-06-23 21:26:13.878629
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    custom_providers = (
        'tests.providers.AddressProvider',
        'tests.providers.PersonProvider',
    )
    g = Generic(seed=12345)
    g.add_providers(*custom_providers)
    assert hasattr(g, 'address')
    assert hasattr(g, 'person')
    assert isinstance(g.address, BaseProvider)
    assert isinstance(g.person, BaseProvider)
    assert g.address.seed == 12345
    assert g.person.seed == 12345



# Generated at 2022-06-23 21:26:20.392037
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of class Generic.

        Note:
            Add custom provider to the object. 

        Args:
            None

        Returns:
            bool: True if test success else False.
    """

    from mimesis.providers.utils import Address

    generic = Generic()
    generic.add_provider(Address)
    assert generic.address()
    return True


# Generated at 2022-06-23 21:26:31.573789
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Testing correct input
    gen = Generic('en')
    assert not hasattr(gen, 'foobar')
    assert not hasattr(gen, 'cool_provider')

    class CoolProvider:
        pass

    class CoolProviderSubclass(BaseProvider):
        pass

    gen.add_provider(CoolProviderSubclass)
    assert hasattr(gen, 'cool_provider_subclass')

    class CoolProviderSubclassWithMeta(BaseProvider):
        class Meta:
            name = 'cool_provider_meta'

    gen.add_provider(CoolProviderSubclassWithMeta)
    assert hasattr(gen, 'cool_provider_meta')

    # Testing incorrect input
    with pytest.raises(TypeError):
        gen.add_provider(None)

# Generated at 2022-06-23 21:26:33.237819
# Unit test for constructor of class Generic
def test_Generic():
    source = Generic(seed=42)
    test = source.choice.random_element(['a', 'b', 'c'])
    assert test == 'c', 'choice should select c'


# Generated at 2022-06-23 21:26:34.226490
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass



# Generated at 2022-06-23 21:26:36.304137
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [BaseProvider]
    g = Generic()
    g.add_providers(*providers)
    assert g

# Generated at 2022-06-23 21:26:39.331763
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            pass
    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo is not None


# Generated at 2022-06-23 21:26:49.771919
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import sys
    import os
    import unittest
    file_file = os.path.abspath(__file__)
    sys.path.insert(0, os.path.dirname(os.path.dirname(file_file)))
    from mimesis.providers.additional import Additional
    from mimesis.providers.media import Media

    class TestGeneric(unittest.TestCase):

        def setUp(self):
            self.generic = Generic()

        def test_add_providers(self):
            self.generic.add_providers(Additional, Media)
            self.assertTrue(hasattr(self.generic, 'additional'))
            self.assertTrue(hasattr(self.generic, 'media'))

    unittest.main()

# Generated at 2022-06-23 21:26:54.332765
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

    g = Generic()
    g.add_provider(CustomProvider)
    assert hasattr(g, 'custom')
    assert isinstance(g.custom, CustomProvider)

# Generated at 2022-06-23 21:26:55.271690
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:27:03.403723
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import os
    import re
    import string
    import sys
    import unittest
    # Create a file with all available providers' names
    all_providers = ''
    for attribute in dir(Generic()):
        if re.match(r'^\w+$', attribute) and attribute not in ['file']:
            all_providers += '{0}\n'.format(attribute)

    # Create a file with imported providers' names
    imported_providers = ''
    for name, obj in globals().items():
        if inspect.isclass(obj) and issubclass(obj, BaseProvider):
            imported_providers += '{0}\n'.format(name)

    # Compare content of files

# Generated at 2022-06-23 21:27:05.434815
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=1)
    assert generic is not None

# Generated at 2022-06-23 21:27:15.928868
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for add_provider of class Generic."""
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    
    class NewProvider(BaseDataProvider):
        pass
    
    class NewProviderException(BaseDataProvider):
        pass
    
    generic = Generic()
    generic.add_provider(NewProvider)
    assert generic.newprovider.__class__ == NewProvider
    assert generic.newprovider.__class__.Meta.name == 'newprovider'
    assert generic.newprovider.__class__.Meta.localizable == False
    
    class NewLocalizableProvider(BaseDataProvider):
        class Meta:
            localizable = True
    

# Generated at 2022-06-23 21:27:19.257435
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic().add_provider('a') == None
    assert Generic().add_provider(1) == None
    assert Generic().add_providers('a',2) == None
    assert Generic().add_providers(1) == None

# Generated at 2022-06-23 21:27:21.492864
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # There is no return values for method __dir__
    # It should be test manually
    g = Generic()
    print('Attributes of Generic class:')
    print(dir(g))

# Generated at 2022-06-23 21:27:29.075829
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    p = Generic()
    assert p.person
    assert p.address
    assert p.datetime
    assert p.business
    assert p.food
    assert p.science
    assert p.transport
    assert p.code
    assert p.unit_system
    assert p.file
    assert p.numbers
    assert p.development
    assert p.hardware
    assert p.clothing
    assert p.internet
    assert p.path
    assert p.payment
    assert p.cryptographic
    assert p.structure
    assert p.choice


# Generated at 2022-06-23 21:27:39.720150
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance(generic.internet, Internet)
    assert isinstance(generic.path, Path)
    assert isinstance(generic.payment, Payment)
    assert isinstance(generic.cryptographic, Cryptographic)
    assert isinstance(generic.structure, Structure)
    assert isinstance(generic.choice, Choice)



# Generated at 2022-06-23 21:27:42.074680
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Generic().__getattr__('person')
    # Generic().person
    assert Generic().person.full_name(gender='female') == 'Lucy Barnes'


# Generated at 2022-06-23 21:27:46.848632
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')
    assert generic.__dir__() == [
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'payment',
        'path',
        'person',
        'science',
        'structure',
        'transport',
        'unit_system'
    ]

# Generated at 2022-06-23 21:27:49.458287
# Unit test for constructor of class Generic
def test_Generic():
    # That's how we get an instance of our provider
    gen = Generic()
    assert gen is not None

# Generated at 2022-06-23 21:28:00.589623
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

        def method(self):
            return 'method'

    class Provider1(BaseProvider):
        class Meta:
            name = 'provider1'

        def method1(self):
            return 'method1'

    gen = Generic()

    gen.add_providers(Provider, Provider1)

    assert hasattr(gen, 'provider')
    assert hasattr(gen, 'provider1')

    assert callable(getattr(gen, 'provider'))
    assert callable(getattr(gen, 'provider1'))

    assert callable(getattr(gen.provider, 'method'))
    assert callable(getattr(gen.provider1, 'method1'))



# Generated at 2022-06-23 21:28:04.960430
# Unit test for constructor of class Generic
def test_Generic():
    _ = Generic()
    assert _._seed == 42
    assert _._data == {}
    assert _._locale == 'en'
    assert _._person == Person
    assert _._address == Address
    assert _._datetime == Datetime
    assert _._business == Business
    assert _._text == Text
    assert _._food == Food
    assert _._science == Science
    assert isinstance(_.transport, Transport)
    assert isinstance(_.code, Code)
    assert isinstance(_.unit_system, UnitSystem)
    assert isinstance(_.file, File)
    assert isinstance(_.numbers, Numbers)
    assert isinstance(_.development, Development)
    assert isinstance(_.hardware, Hardware)
    assert isinstance(_.clothing, Clothing)
    assert isinstance(_.internet, Internet)

# Generated at 2022-06-23 21:28:14.178382
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.development import Development
    from mimesis.providers.random import Random
    gen = Generic()
    crypto = Cryptographic(seed=gen.seed)
    development = Development(seed=gen.seed)
    random = Random(seed=gen.seed)
    gen.add_providers(crypto, development)

    assert hasattr(gen, 'cryptographic')
    assert hasattr(gen, 'development')
    assert not hasattr(gen, 'random')
    assert gen.cryptographic.uuid4() == crypto.uuid4()
    assert gen.development.version() == development.version()



# Generated at 2022-06-23 21:28:16.426849
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic.

    :return:
    """
    data = Generic('en')
    assert data
    # print(data.datetime)

# Generated at 2022-06-23 21:28:23.613428
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    '''
    This test will check if __getattr__() method can return an attribute correctly
    '''
    gen = Generic('en')
    # private provider
    assert hasattr(gen,'_person') == True
    person = gen.person
    assert person is not None and isinstance(person, Person)
    # public provider
    assert hasattr(gen, 'file') == True
    path = gen.file
    assert path is not None and isinstance(path, File)

# Generated at 2022-06-23 21:28:27.600313
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    gen = Generic()
    from mimesis.enums import Gender
    assert Gender.MALE in gen.person.__dir__()
    assert Gender.FEMALE in gen.person.__dir__()

# Generated at 2022-06-23 21:28:29.376820
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic(seed=1)
    assert a.__dir__().__contains__('address')


# Generated at 2022-06-23 21:28:30.844994
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.__getattr__('person')
    assert generic.person



# Generated at 2022-06-23 21:28:34.282826
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider

    class CustomProvider(BaseProvider):
        def foo(self):
            return 'Custom provider'
    gp = Generic()
    gp.add_provider(CustomProvider)
    assert gp.custom_provider.foo() == 'Custom provider'



# Generated at 2022-06-23 21:28:35.098146
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:28:41.394801
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Localization
    # Create new provider
    Provider = type('Provider', (BaseProvider,), {
        '__init__': lambda self: BaseProvider.__init__(self),
        'Meta': type('Meta', (), {'name': 'provider'}),
        'flag': lambda self: 'flag',
    })
    gen = Generic(Localization())
    gen.add_provider(Provider)
    print(gen.provider.flag())



# Generated at 2022-06-23 21:28:44.891451
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Create a Generic object
    g = Generic()

    # Get attribute
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None



# Generated at 2022-06-23 21:28:55.187697
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()

    assert isinstance(generic, Generic)
    assert isinstance(generic.choice, Choice)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)

# Generated at 2022-06-23 21:29:00.612062
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """testing special method __add_provider__ of class Generic()."""
    generic = Generic()
    assert hasattr(generic, 'address')

    def custom_provider(BaseProvider):
        """Custom provider."""

        class CustomProvider(BaseProvider):
            """Custom provider."""

            class Meta:
                """Class for metadata."""

                name = 'custom'

        return CustomProvider

    generic.add_provider(custom_provider)
    assert hasattr(generic, 'custom')



# Generated at 2022-06-23 21:29:03.979003
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=100)
    assert (generic.seed) == 100
    print("unit test Generic: PASS")

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:29:09.978158
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.address is not None
    assert gen.business is not None
    assert gen.datetime is not None
    assert gen.person is not None
    assert gen.text is not None
    assert gen.food is not None
    assert gen.science is not None

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:29:13.328918
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # define a custom provider class
    class MyCustomProvider(BaseProvider):
        class Meta:
            name = 'custom'
        def custom(self):
            return 'custom'
    # initialize a instance of class Generic
    g = Generic()
    # add custom provider to Generic() object
    g.add_providers(MyCustomProvider)
    # test if method add_providers works correctly
    assert g.custom().custom() == 'custom'

# Generated at 2022-06-23 21:29:22.708862
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    class A(BaseProvider):
        """Class A."""
        class Meta:
            """Class A Meta."""
            name = 'a'
    g.add_provider(A)

# Generated at 2022-06-23 21:29:25.162524
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Should return an attribute."""
    gen = Generic()
    assert gen.person.full_name() == 'Alexander Guerin'



# Generated at 2022-06-23 21:29:28.701721
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('ru')
    print(g)
    print(g.person.full_name())
    print(g.datetime.datetime())
    print(g.text.text())

if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:29:40.021716
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.business, Business)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:29:42.843611
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test Genereic.add_providers()"""
    _ = Generic().add_providers(Person, Address)
    assert ('person' in dir(Generic())) and ('address' in dir(Generic()))