

# Generated at 2022-06-23 21:19:45.825411
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic(seed=42)
    g.add_provider(numbers.Numbers)
    result = g.numbers.numerify('')
    expected = '1234567890'
    assert result == expected

# Generated at 2022-06-23 21:19:54.613667
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.business import Business as BusinessProvider
    g = Generic('ru')
    assert 'russia_spec' in dir(g)
    assert 'person' in dir(g)
    assert 'business' in dir(g)
    g.add_providers(RussiaSpecProvider, PersonProvider, BusinessProvider)
    assert 'russia_spec' in dir(g)
    assert 'person' in dir(g)
    assert 'business' in dir(g)

# Generated at 2022-06-23 21:19:58.793445
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """The function tests the method `add_providers` of class `Generic`."""
    gen = Generic()
    assert hasattr(gen,'add_providers')



# Generated at 2022-06-23 21:20:06.039831
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    g = Generic('en')
    d = g.__dir__()
    assert d
    assert sorted(d) == sorted(['person', 'address', 'datetime',
                                'business', 'text', 'food',
                                'science', 'transport', 'code',
                                'unit_system', 'file', 'numbers',
                                'development', 'hardware', 'clothing',
                                'internet', 'path', 'payment',
                                'cryptographic', 'structure', 'choice'])


# Generated at 2022-06-23 21:20:12.661027
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    locale = "en"
    generic = Generic(locale)
    providers_list = [Person, Address]
    generic.add_providers(*providers_list)
    assert generic.person._data["address"]["city"]["suffix"] == "Crescent"
    assert generic.address._data["city"]["suffix"] == "Crescent"


# Generated at 2022-06-23 21:20:16.459410
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person
    g.address
    g.business
    g.text
    g.food
    g.science
    g.transport
    g.code
    g.unit_system
    g.file
    g.numbers
    g.development
    g.hardware
    g.clothing
    g.internet
    g.path
    g.payment
    g.cryptographic
    g.structure
    g.choice



# Generated at 2022-06-23 21:20:20.927551
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.identification import Identification
    from mimesis.special import FileProvider

    gen = Generic()
    gen.add_providers(Identification, FileProvider)
    assert gen.identification is not None
    assert gen.file is not None

# Generated at 2022-06-23 21:20:23.740400
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()

    assert 'choice' in dir(g)
    assert 'person' in dir(g)
    assert 'address' in dir(g)

# Generated at 2022-06-23 21:20:26.156281
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.network import Network
    g = Generic()
    g.add_providers(Network)
    assert isinstance(g.network, Network)


# Generated at 2022-06-23 21:20:28.959592
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Code, UnitSystem)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)

# Generated at 2022-06-23 21:20:38.957236
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Method to test if __getattr__() works as expected.

    :return: None
    """
    print('[+] Testing method Generic.__getattr__()... ', end='')

    g = Generic()
    assert g.person.name() == g.person.name()
    assert g.address.building_number() == g.address.building_number()
    assert g.datetime.datetime() == g.datetime.datetime()
    assert g.food.fruit() == g.food.fruit()
    assert g.science.chemical_element() == g.science.chemical_element()

    print('done')



# Generated at 2022-06-23 21:20:40.459931
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g,"Generic")


# Generated at 2022-06-23 21:20:45.641830
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    actual = dir(Generic())
    expected = ['address', 'business', 'choice', 'code', 'cryptographic',
                'datetime', 'development', 'file', 'food', 'hardware',
                'internet', 'numbers', 'person', 'path', 'payment', 'science',
                'structure', 'text', 'transport', 'unit_system']
    assert actual == expected

# Generated at 2022-06-23 21:20:47.593451
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert g.__dict__['person'].__class__ == Person


# Generated at 2022-06-23 21:20:51.026295
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('ru')
    assert g.__getattr__('address') is not None
    assert g.__getattr__('text') is not None
    assert g.__getattr__('science') is not None
    assert g.__getattr__('file') is not None


# Generated at 2022-06-23 21:20:54.271624
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import mimesis.providers.phone
    import mimesis.providers.finance
    generic = Generic()
    generic.add_providers(mimesis.providers.phone.Phone,
                          mimesis.providers.finance.Finance)

# Generated at 2022-06-23 21:20:56.350447
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    print(provider._address)
    print(type(provider._address))
    provider.add_providers()
    print(provider.get_choices())

# Generated at 2022-06-23 21:21:07.241890
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert('person' in dir(g))
    assert('address' in dir(g))
    assert('transport' in dir(g))
    assert('file' in dir(g))
    assert('code' in dir(g))
    assert('numbers' in dir(g))
    assert('datetime' in dir(g))
    assert('unit_system' in dir(g))
    assert('business' in dir(g))
    assert('food' in dir(g))
    assert('science' in dir(g))
    assert('text' in dir(g))
    assert('development' in dir(g))
    assert('hardware' in dir(g))
    assert('clothing' in dir(g))
    assert('internet' in dir(g))
    assert('path' in dir(g))

# Generated at 2022-06-23 21:21:09.236110
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    u"""Test for method __getattr__ of class Generic."""

    from mimesis.builtins import RussiaSpecProvider

    gen = Generic(RussiaSpecProvider)
    assert gen.person() is not None
    assert gen.address() is not None



# Generated at 2022-06-23 21:21:15.118118
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Car(BaseProvider):
        class Meta:
            name = 'car'

        def car_type(self):
            return 'sedan'

    class Pokemon(BaseProvider):
        class Meta:
            name = 'pokemon'

        def pokemon(self):
            return 'pikachu'

    g = Generic()
    g.add_providers(Car, Pokemon)
    assert g.car.car_type() == 'sedan'
    assert g.pokemon.pokemon() == 'pikachu'

# Generated at 2022-06-23 21:21:25.758964
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test of method __dir__ of class Generic."""
    g = Generic(seed=17)
    d = g.__dir__()
    assert isinstance(d, list)
    assert 'address' in d
    assert 'person' in d
    assert 'datetime' in d
    assert 'business' in d
    assert 'text' in d
    assert 'science' in d
    assert 'food' in d
    assert 'unit_system' in d
    assert 'numbers' in d
    assert 'code' in d
    assert 'file' in d
    assert 'internet' in d
    assert 'hardware' in d
    assert 'clothing' in d
    assert 'path' in d
    assert 'payment' in d
    assert 'cryptographic' in d
    assert 'development' in d

# Generated at 2022-06-23 21:21:29.734334
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic(seed=1)
    assert a.unit_system.get_si_prefix() == 'p'
    b = Generic(seed=a.seed)
    assert b.unit_system.get_si_prefix() == 'p'

# Generated at 2022-06-23 21:21:33.085110
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    all_at_one = Generic(seed=123)

    assert all_at_one is not None
    assert all_at_one.seed is not None
    assert all_at_one.seed == 123
    assert all_at_one.locale is not None
    assert all_at_one.locale == 'en'

# Generated at 2022-06-23 21:21:37.362143
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # 1. init `Generic` object
    generic = Generic()
    # 2. get attributes
    #    and check if it is a subclass of `BaseProvider`
    for attribute in generic.__dir__():
        attr = getattr(generic, attribute)
        assert issubclass(attr.__class__, BaseProvider)


# Generated at 2022-06-23 21:21:48.481496
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed = 0)
    assert g._person == Person
    assert g._address == Address
    assert g._datetime == Datetime
    assert g._business == Business
    assert g._text == Text
    assert g._food == Food
    assert g._science == Science
    assert g.transport == Transport(seed = 0)
    assert g.code == Code(seed = 0)
    assert g.unit_system == UnitSystem(seed = 0)
    assert g.file == File(seed = 0)
    assert g.numbers == Numbers(seed = 0)
    assert g.development == Development(seed = 0)
    assert g.hardware == Hardware(seed = 0)
    assert g.clothing == Clothing(seed = 0)
    assert g.internet == Internet(seed = 0)
    assert g.path == Path

# Generated at 2022-06-23 21:21:56.220520
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person

    class CustomProvider(BaseProvider):
        """Custom provider."""
        class Meta:
            """Class for metadata."""
            name = 'custom_provider'

        def foo(self) -> str:
            """Get a foo string."""
            return 'bar'

    instance = Generic()
    instance.add_providers(CustomProvider, Person)
    assert hasattr(instance, 'custom_provider')
    assert hasattr(instance, 'person')

# Generated at 2022-06-23 21:21:58.170634
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    provider = Generic()
    providers = [Text, Business, Transportation]
    provider.add_providers(*providers)
    assert hasattr(provider, 'text')
    assert hasattr(provider, 'business')
    assert hasattr(provider, 'transportation')



# Generated at 2022-06-23 21:22:07.539193
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Tests the __dir__ method of the Generic class."""
    actual = Generic().__dir__()
    _expected = ['Meta', '_person', 'person', '_address', 'address',
                 '_datetime', 'datetime', '_business', 'business',
                 '_text', 'text', '_food', 'food', '_science', 'science',
                 'transport', 'code', 'unit_system', 'file', 'numbers',
                 'development', 'hardware', 'clothing', 'internet',
                 'path', 'payment', 'cryptographic', 'structure',
                 'choice', 'add_provider', 'add_providers',
                 '__getattr__', '__dir__', '__init__']
    assert sorted(_expected) == sorted(actual)

# Generated at 2022-06-23 21:22:09.297909
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    address = generic.address
    assert address

# Generated at 2022-06-23 21:22:19.819772
# Unit test for constructor of class Generic
def test_Generic():
    data = Generic()
    print(data.person.full_name())
    print(data.address.address())
    print(data.datetime.date(minimum_year=2000,
                             maximum_year=2010))
    print(data.business.company())
    print(data.text.title(), data.text.sentence())
    print(data.food.ingredient())
    print(data.science.element_symbol())
    print(data.transport.car())
    print(data.code.isbn())
    print(data.unit_system.imperial.mass())
    print(data.file.filename())
    print(data.numbers.between(5, 100))
    print(data.development.language())
    print(data.hardware.mac_address())

# Generated at 2022-06-23 21:22:22.880467
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    address = Generic().address.street_name()
    assert address is not None
    assert isinstance(address, str)

# Generated at 2022-06-23 21:22:25.019719
# Unit test for constructor of class Generic
def test_Generic():
    seed = 12364
    gen = Generic(seed=seed)
    assert gen.seed == seed

# Generated at 2022-06-23 21:22:32.799952
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider."""
    class CustomProvider(BaseProvider):
        """Custom class which inherit from BaseProvider."""

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        class Meta:
            """Meta class."""

            name = 'custom_provider'

        def method(self) -> str:
            """Method of CustomProvider class."""
            return 'ok'

    generic = Generic()
    assert not hasattr(generic, 'custom_provider')
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom_provider')
    assert generic.custom_provider.method() == 'ok'

if __name__ == '__main__':
    test

# Generated at 2022-06-23 21:22:42.916735
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    gen = Generic()
    assert hasattr(gen, 'address')
    assert hasattr(gen, 'person')
    assert hasattr(gen, 'datetime')
    assert hasattr(gen, 'text')
    assert hasattr(gen, 'food')
    assert hasattr(gen, 'science')
    assert hasattr(gen, 'code')
    assert hasattr(gen, 'unit_system')
    assert hasattr(gen, 'file')
    assert hasattr(gen, 'numbers')
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'hardware')
    assert hasattr(gen, 'clothing')
    assert hasattr(gen, 'internet')
    assert hasattr(gen, 'business')

# Generated at 2022-06-23 21:22:44.460329
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:22:55.824107
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.unit_system import UnitSystem
    from mimesis.providers.path import Path
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.payment import Payment

# Generated at 2022-06-23 21:23:02.909739
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create a list of custom providers
    providers = [
        Generic, Generic, Generic, Generic
    ]
    generic_obj = Generic()
    # Add custom providers to Generic object
    generic_obj.add_providers(
        *providers
    )
    assert callable(generic_obj.generic)
    assert callable(generic_obj.generic_1)
    assert callable(generic_obj.generic_2)
    assert callable(generic_obj.generic_3)



# Generated at 2022-06-23 21:23:07.668506
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
        def func(self):
            return 'test'

    g = Generic()
    assert 'test_provider' not in dir(g)
    g.add_providers(TestProvider)
    assert hasattr(g, 'test_provider')

# Generated at 2022-06-23 21:23:09.435826
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.builtins import Generic
    generic = Generic()
    assert generic


# Generated at 2022-06-23 21:23:10.700134
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    assert Generic.__dir__(Generic) == Generic().__dir__()

# Generated at 2022-06-23 21:23:12.150365
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        pass

    obj = Generic()
    obj.add_provider(CustomProvider)
    assert isinstance(obj.custom_provider, CustomProvider)

# Generated at 2022-06-23 21:23:22.314917
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    providers = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]
    # CHECK
    assert len(providers) == len(list(set(providers)))
    # CREATE
    g = Generic()
    # CHECK
    assert len(g.__dict__) == len(providers)
    # EXEC

# Generated at 2022-06-23 21:23:25.906500
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generator = Generic()
    generator.person.full_name()
    assert isinstance(generator.person, Person)

# Generated at 2022-06-23 21:23:34.977331
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    ''' Test method __getattr__ of class Generic.
    '''
    g = Generic()

    # test method get_shuffled_sequence
    print('g.get_shuffled_sequence(): %s' % g.get_shuffled_sequence())

    # test method get_shuffled_sequence
    print('g.get_shuffled_sequence(1): %s' % g.get_shuffled_sequence(1))
    
    # test method get_shuffled_sequence_range
    print('g.get_shuffled_sequence_range(1,4): %s' % g.get_shuffled_sequence_range(1,4))

    # test method get_random_sequence
    print('g.get_random_sequence(): %s' % g.get_random_sequence())
    

# Generated at 2022-06-23 21:23:42.449370
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    obj.address.country_code()
    obj.business.company()
    obj.clothing.hat()
    obj.code.barcode()
    obj.code.license_plate()
    obj.code.simple_vat()
    obj.code.isin()
    obj.code.iban()
    obj.code.is_bn()
    obj.code.is_gtin()
    obj.code.uid()
    obj.code.uuid4()
    obj.code.uuid1()
    obj.code.uuid3()
    obj.code.uuid5()
    obj.cryptographic.md5()
    obj.cryptographic.sha224()
    obj.cryptographic.sha256()
    obj.cryptographic.sha384()
    obj.cryptographic.sha512()


# Generated at 2022-06-23 21:23:53.497279
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.text  # type: ignore
    assert gen.address  # type: ignore
    assert gen.person  # type: ignore
    assert gen.science  # type: ignore
    assert gen.food  # type: ignore
    assert gen.datetime  # type: ignore
    assert gen.business  # type: ignore
    assert gen.transport  # type: ignore
    assert gen.code  # type: ignore
    assert gen.unit_system  # type: ignore
    assert gen.file  # type: ignore
    assert gen.numbers  # type: ignore
    assert gen.development  # type: ignore
    assert gen.hardware  # type: ignore
    assert gen.clothing  # type: ignore
    assert gen.internet  # type: ignore
    assert gen.path  # type: ignore

# Generated at 2022-06-23 21:23:58.211372
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from providers import EyeColor
    generic = Generic('en')
    assert not hasattr(generic, 'eye_color')
    generic.add_provider(EyeColor)
    assert hasattr(generic, 'eye_color')
    assert hasattr(generic, 'EyeColor')


# Generated at 2022-06-23 21:23:58.879766
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert 'generate' in dir(Generic())

# Generated at 2022-06-23 21:24:01.332614
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == 20
    g.add_provider(Science)
    assert len(g.__dir__()) == 21

# Generated at 2022-06-23 21:24:02.315143
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.provider.name


# Generated at 2022-06-23 21:24:09.116461
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.web import Web
    from mimesis.providers.person import Person
    from mimesis.providers.auto import Auto
    from mimesis.providers.geography import Geography
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.file import File
    from mimesis.providers.path import Path
    from mimesis.providers.payment import Payment
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing

# Generated at 2022-06-23 21:24:13.911770
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic('en')
    add_providers = generic.add_providers
    add_providers(Person)
    add_providers(Address, Datetime)
    assert generic.person.__class__.__name__ == 'Person'
    assert generic.address.__class__.__name__ == 'Address'
    assert generic.datetime.__class__.__name__ == 'Datetime'

# Generated at 2022-06-23 21:24:22.417958
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    actual = Generic().__dir__()
    expected = [
        'address',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'meta',
        'numbers',
        'path',
        'person',
        'payment',
        'science',
        'structure',
        'transport',
        'unit_system',
        'text',
    ]
    assert sorted(actual) == sorted(expected)

# Generated at 2022-06-23 21:24:26.370884
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers import Foo
    from mimesis.providers import Bar

    class Foo(BaseProvider):
        pass

    class Bar(BaseProvider):
        pass

    foo = Foo()
    bar = Bar()
    provider = Generic()
    provider.add_providers(foo, bar)
    assert hasattr(provider, 'foo')
    assert hasattr(provider, 'bar')

# Generated at 2022-06-23 21:24:32.026985
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Arrange
    class MyProvider(BaseProvider):
        def foo(self) -> str:
            return self.random.choice(['bar', 'baz'])

    # Act
    g = Generic()
    g.add_provider(MyProvider)

    # Assert
    assert hasattr(g, 'my_provider')
    assert g.my_provider.foo() in ['bar', 'baz']


# Generated at 2022-06-23 21:24:38.834462
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.locale import Locale
    from mimesis.types import Localization
    from mimesis.enums import Gender
    from random import seed

    g = Generic(Gender.MALE, 2018)
    assert isinstance(g, BaseProvider)
    assert isinstance(g._person, Person)
    assert isinstance(g._address, Address)
    assert isinstance(g._datetime, Datetime)
    assert isinstance(g._business, Business)
    assert isinstance(g._text, Text)
    assert isinstance(g._food, Food)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance

# Generated at 2022-06-23 21:24:45.670126
# Unit test for constructor of class Generic
def test_Generic():
    # Запускается конструктор класса Generic()
    generic = Generic()
    # Проверяется что ни одно поле не было предварительно инициализировано
    assert len(generic.__dict__) == 0

    # Запускается конструктор класса Generic() с передачей параметра locale

# Generated at 2022-06-23 21:24:47.165954
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        test_provider = Generic().add_provider('Not a provider')
    except TypeError:
        test_provider = True
    assert test_provider is True

# Generated at 2022-06-23 21:24:51.572180
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class CustomProvider(BaseProvider):
        def foo(self) -> str:
            return 'bar'
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'



# Generated at 2022-06-23 21:24:56.056840
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    foo = Generic()
    bar = Generic()
    foo.data = 'a'
    foo.add_provider(Person)
    foo.add_providers(Person, Address)
    assert foo.data == 'a'
    assert foo.person._seed == foo.seed
    assert foo.address._seed == foo.seed
    assert foo.person is not bar.person
    assert foo.address is not bar.address

# Generated at 2022-06-23 21:25:01.387124
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.other import DatasetProvider

    data = [
        ('dataset', DatasetProvider),
    ]

    gen = Generic()
    for provider in data:
        gen.add_provider(provider[1])

        assert hasattr(gen, provider[0])
        assert getattr(gen, provider[0])



# Generated at 2022-06-23 21:25:06.925503
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class A(BaseProvider):
        class Meta:
            name = 'example_a'

    class B(BaseProvider):
        class Meta:
            name = 'example_b'

    g = Generic()
    g.add_providers(A)
    assert g.example_a

    g.add_providers(A, B)
    assert g.example_a
    assert g.example_b

# Generated at 2022-06-23 21:25:16.270777
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Set default locale and seed
    g = Generic(seed = 0)
    # Create providers
    class MyProvider1(BaseProvider):
        def method(self):
            return "MyProvider1"
    class MyProvider2(BaseProvider):
        def method(self):
            return "MyProvider2"
    class MyProvider3(BaseProvider):
        def method(self):
            return "MyProvider3"
    # Add custom providers to Generic object
    g.add_providers(MyProvider1, MyProvider2, MyProvider3)
    # Set correct result to compare with test result
    correct_result = ["myprovider1", "myprovider2", "myprovider3"]
    # Get all methods of MyProviders
    namelist = dir(g)
    #  Get the list of names of methods of MyProviders without the

# Generated at 2022-06-23 21:25:20.884402
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic(seed=42)
    generic.add_providers(Provider1, Provider2)
    assert 'provider1' in dir(generic)
    assert 'provider2' in dir(generic)



# Generated at 2022-06-23 21:25:25.299580
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class A(BaseProvider):
        class Meta:
            name = 'a'

        def get_test(self):
            return 'test'

    test = Generic()
    test.add_provider(A)
    assert hasattr(test, 'a')
    assert test.a.get_test() == 'test'

# Generated at 2022-06-23 21:25:30.614859
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # get attributes of class Generic
    attributes = dir(Generic())
    except_attributes = BaseDataProvider().__dict__.keys()

    assert "Meta" in attributes
    assert "__getattr__" in attributes
    assert "__dir__" in attributes
    assert "__init__" in attributes
    assert "add_provider" in attributes
    assert "add_providers" in attributes
    assert "address" in attributes
    assert "business" in attributes
    assert "choice" in attributes
    assert "clothing" in attributes
    assert "code" in attributes
    assert "cryptographic" in attributes
    assert "datetime" in attributes
    assert "development" in attributes
    assert "file" in attributes
    assert "food" in attributes
    assert "hardware" in attributes
    assert "internet" in attributes

# Generated at 2022-06-23 21:25:31.887190
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic()
    provider.add_provider(File)
    assert hasattr(provider, 'file')


# Generated at 2022-06-23 21:25:40.039541
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender

    class CustomProvider(BaseProvider):
        pass

    class CustomData(Generic):

        class Meta:
            name = 'custom_data'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.add_providers(CustomProvider)
            self.custom_data = CustomProvider()

    cd = CustomData('en')
    assert cd.custom_data.choice(Gender) in Gender.__members__

# Generated at 2022-06-23 21:25:47.294862
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers."""
    from mimesis.providers.containers import Containers
    from mimesis.providers.redundancy import Redundancy
    from mimesis.providers.storage import Storage
    from mimesis.providers.tree import Tree
    from mimesis.providers.system import System
    from mimesis.providers.network import Network

    g = Generic()
    assert Containers not in g.__dir__()
    assert Redundancy not in g.__dir__()
    assert Storage not in g.__dir__()
    assert Tree not in g.__dir__()
    assert System not in g.__dir__()
    assert Network not in g.__dir__()

    g.add_providers(Containers, Redundancy, Storage, Tree, System, Network)

# Generated at 2022-06-23 21:25:49.964486
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert hasattr(g, 'date')
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')

# Generated at 2022-06-23 21:26:00.017846
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Here is test for method add_provider of class Generic """
    provider = Generic()
    provider.add_provider(UnitSystem)
    provider.add_provider(File)
    print(provider.unit_system.__dict__.keys())
    print(provider.unit_system.__dict__['_data'].keys())
    print(provider.unit_system.__dict__['_data']['units'].keys())
    print(provider.unit_system.__dict__['_data']['units']['weight'].keys())
    print(provider.unit_system.__dict__['_data']['units']['weight']['pound'].keys())

# Generated at 2022-06-23 21:26:11.040509
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(Generic().datetime.datetime())
    print(Generic().address.address())
    print(Generic().transport.train())
    print(Generic().text.word())
    print(Generic().business.small_company())
    print(Generic().person.full_name())
    print(Generic().science.constant())
    print(Generic().science.law())
    print(Generic().science.theory())
    print(Generic().science.hypothesis())
    print(Generic().science.formula())
    print(Generic().clothing.shoe())
    print(Generic().clothing.jacket())
    print(Generic().clothing.coat())
    print(Generic().clothing.cap())
    print(Generic().clothing.trouser())
    print(Generic().clothing.hat())
   

# Generated at 2022-06-23 21:26:13.551028
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert isinstance(generic.person, Person)

# Generated at 2022-06-23 21:26:23.245675
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.calendar import Calendar
    from mimesis.providers.date import Date
    from mimesis.providers.time import Time
    from mimesis.providers.localization import Localization
    g = Generic()
    assert not hasattr(g, 'calendar')
    assert not hasattr(g, 'date')
    assert not hasattr(g, 'time')
    assert not hasattr(g, 'localization')
    g.add_providers(Calendar, Date, Time, Localization)
    assert hasattr(g, 'calendar')
    assert hasattr(g, 'date')
    assert hasattr(g, 'time')
    assert hasattr(g, 'localization')

# Generated at 2022-06-23 21:26:29.905534
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.build import Build
    from mimesis.providers.geography import Geography
    from mimesis.providers.telecoms import Telecoms

    generic = Generic()

    generic.add_providers(Build, Telecoms, Geography)

    assert 'build' in generic.__dict__
    assert 'telecoms' in generic.__dict__
    assert 'geography' in generic.__dict__

# Generated at 2022-06-23 21:26:31.471743
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    assert isinstance(provider, Generic)

# Generated at 2022-06-23 21:26:31.833497
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass

# Generated at 2022-06-23 21:26:38.261162
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta(BaseProvider.Meta):
            name = 'my_provider'

        def mymethod(self):
            return "SUCCESS"

    a1 = Generic()
    a1.add_provider(MyProvider)
    assert a1.my_provider.mymethod() == "SUCCESS"

    a2 = Generic()
    a2.add_providers(MyProvider)
    assert a2.my_provider.mymethod() == "SUCCESS"

# Generated at 2022-06-23 21:26:46.815881
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""

    # Expected result
    class MyProvider(BaseProvider):
        """Custom provider."""

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def say_hello(self):
            """Say Hello."""
            return 'Hello!'


    gen = Generic()
    gen.add_provider(MyProvider)
    assert hasattr(gen, 'my_provider')



# Generated at 2022-06-23 21:26:57.965645
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for ``Generic.__getattr__()``."""
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)


# Generated at 2022-06-23 21:27:02.294152
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = g.__dir__()
    assert isinstance(result, list)
    assert len(result) > 1
    for i in result:
        assert isinstance(i, str)


# Generated at 2022-06-23 21:27:07.332845
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'my_provider'

        def foo(self):
            return 'foo'

    gen = Generic()
    gen.add_provider(MyProvider)
    assert hasattr(gen, 'my_provider')

#  Unit test for method add_providers of class Generic

# Generated at 2022-06-23 21:27:11.710934
# Unit test for constructor of class Generic
def test_Generic():
    a=Generic()
    print(a.business.company_name())
    b=Generic()
    print(b.business.company_name())
    print(a.business.company_name())
    c=Generic(seed=12)
    print(c.business.company_name())

# Generated at 2022-06-23 21:27:12.425108
# Unit test for constructor of class Generic
def test_Generic():
  Generic('en')

# Generated at 2022-06-23 21:27:19.644899
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic class."""
    g = Generic()
    assert g.choice is None

    class Choice(BaseProvider):
        """Class for unit test for method add_provider of class Generic."""

        class Meta:
            """Class for unit test for method add_provider of class Generic."""

            name = 'ch'

    g.add_provider(Choice)
    assert g.ch.choice() is not None

    try:
        g.add_provider(int)
    except TypeError:
        assert True



# Generated at 2022-06-23 21:27:22.890027
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Generic() should contains all methods."""
    g = Generic()
    exclude = BaseDataProvider().__dict__.keys()
    assert len(g.__dir__()) == len(g.__dict__.keys()) - len(exclude)



# Generated at 2022-06-23 21:27:24.565911
# Unit test for constructor of class Generic
def test_Generic():
  generic = Generic()
  assert(generic is not None)

# Generated at 2022-06-23 21:27:33.095876
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic(locale='en')
    assert a.datetime.date() !=''
    assert a.datetime.time() != ''
    assert a.datetime.datetime() != ''
    assert a.datetime.timestamp() != ''
    assert a.datetime.year() != ''
    assert a.datetime.month() != ''
    assert a.datetime.day() != ''
    assert a.datetime.hour() != ''
    assert a.datetime.minute() != ''
    assert a.datetime.second() != ''
    assert a.datetime.tz() != ''
    assert a.datetime.md5(32) != ''
    assert a.datetime.sha1(40) != ''
    assert a.datetime.sha256(64) != ''
    assert a.datetime.uuid

# Generated at 2022-06-23 21:27:39.722287
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    def test_add_provider_provider_is_class(provider):
        generic = Generic()
        generic.add_provider(provider)

    def test_add_provider_provider_is_not_class(provider):
        generic = Generic()
        try:
            generic.add_provider(provider)
        except TypeError as e:
            assert str(e) == 'The provider must be a class'

    class Provider(BaseProvider):
        class Meta:
            name = ''

    class NotProvider:
        pass

    class BaseProviderProvider(BaseProvider):
        class Meta:
            name = ''

    test_add_provider_provider_is_class(Generic)
    test_add_provider_provider_is_class(BaseProviderProvider)
    test_add_provider_

# Generated at 2022-06-23 21:27:43.704655
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test if Generic.__getattr__ works properly
    # when attribute is already exists in object.
    result = Generic()._person(locale='ru')
    assert result is not None
    assert result.__class__ == Person
    # Test if Generic.__getattr__ works properly
    # when attribute starts with underscore.
    result = Generic().person(locale='ru')
    assert result is not None
    assert result.__class__ == Person



# Generated at 2022-06-23 21:27:50.870583
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:27:55.974816
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Address, Person, Datetime, Business)

    assert g.address.__class__.__name__ == 'Address'
    assert g.person.__class__.__name__ == 'Person'
    assert g.datetime.__class__.__name__ == 'Datetime'
    assert g.business.__class__.__name__ == 'Business'



# Generated at 2022-06-23 21:27:58.294082
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=42)
    assert generic._address is not None
    assert generic._datetime is not None

# Test for add_provider method

# Generated at 2022-06-23 21:28:02.047451
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""

# Generated at 2022-06-23 21:28:14.220395
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    dir_g = g.__dir__()
    assert 'person' in dir_g
    assert 'address' in dir_g
    assert 'datetime' in dir_g
    assert 'business' in dir_g
    assert 'text' in dir_g
    assert 'food' in dir_g
    assert 'science' in dir_g
    assert 'transport' in dir_g
    assert 'code' in dir_g
    assert 'unit_system' in dir_g
    assert 'file' in dir_g
    assert 'numbers' in dir_g
    assert 'development' in dir_g
    assert 'hardware' in dir_g
    assert 'clothing' in dir_g
    assert 'internet' in dir_g
    assert 'path' in dir_g

# Generated at 2022-06-23 21:28:16.789902
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""
    gen = Generic()
    dir_ = gen.__dir__()
    assert 'address' in dir_
    assert 'unit_system' in dir_



# Generated at 2022-06-23 21:28:28.021798
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__.

    :return: None
    """
    # Initialize class
    generic = Generic('en')

    expected = [
        'address',
        'business',
        'code',
        'choice',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'food',
        'file',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

    for i, e in enumerate(expected):
        generic_dir = generic.__dir__()
        assert e == generic_dir[i]

# Generated at 2022-06-23 21:28:36.371066
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic('ru')
    assert 'person' in dir(provider)
    assert 'mail' in dir(provider)
    assert 'transport' in dir(provider)
    assert 'code' in dir(provider)
    assert 'unit_system' in dir(provider)
    assert 'file' in dir(provider)
    assert 'numbers' in dir(provider)
    assert 'development' in dir(provider)
    assert 'hardware' in dir(provider)
    assert 'clothing' in dir(provider)
    assert 'internet' in dir(provider)
    assert 'path' in dir(provider)
    assert 'payment' in dir(provider)
    assert 'cryptographic' in dir(provider)
    assert 'structure' in dir(provider)

# Generated at 2022-06-23 21:28:43.866325
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test Generic class."""

    # Initialize generic object
    generic = Generic()

    # Person's attributes
    person = generic.person
    assert person.title() in generic.list_titles()

    # Address's attributes
    address = generic.address
    assert address.country_name() in generic.list_country_names()

    # Datetime's attributes
    datetime = generic.datetime
    assert datetime.date() in generic.list_dates()

    # Business's attributes
    business = generic.business
    assert business.company() in generic.list_companies()

    # Text's attributes
    text = generic.text
    assert text.word() in generic.list_words()

# Generated at 2022-06-23 21:28:52.003078
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.transport import Transport
    from mimesis.providers.payment import Payment
    import random

    @add_providers(Numbers, Transport, Payment)
    class CustomGeneric(Generic):
        """Custom class."""
        pass

    cg = CustomGeneric('ru')
    assert isinstance(cg.numbers, Numbers)
    assert isinstance(cg.transport, Transport)
    assert isinstance(cg.payment, Payment)
    assert isinstance(cg.random, random.Random)

# Generated at 2022-06-23 21:28:59.613553
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.providers.file import File
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet
    from mimesis.providers.path import Path
    from mimesis.providers.payment import Payment
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.structure import Structure

# Generated at 2022-06-23 21:29:02.061768
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers of class Generic."""
    # TODO: create test for method add_providers of class Generic
    pass

# Generated at 2022-06-23 21:29:06.461846
# Unit test for constructor of class Generic
def test_Generic():
    # create new entity
    generic = Generic()

    # test add_provider()
    provider = Person
    generic.add_provider(provider)

    # test add_providers()
    providers = [Person, Address]
    generic.add_providers(*providers)

# Generated at 2022-06-23 21:29:11.191544
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    def test_provider():
        class TestProvider(BaseProvider):
            def test_method(self):
                return "example"
        return TestProvider

    g = Generic()
    g.add_provider(test_provider())
    assert "example" == g.test_provider().test_method()

# Generated at 2022-06-23 21:29:13.398895
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    assert Generic().add_providers(Person, Person) is None

# Generated at 2022-06-23 21:29:18.208311
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    del generic


# Generated at 2022-06-23 21:29:28.224155
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class A(BaseProvider):
        class Meta:
            name = 'a'
    
    class B(BaseProvider):
        class Meta:
            name = 'b'
    
    g = Generic()
    g.add_providers(
        A,
        B
    )
    assert dir(g) == ['a', 'b', 'address', 'business', 'choice', 'code',
        'clothing', 'cryptographic', 'datetime', 'development', 'file',
        'food', 'hardware', 'internet', 'numbers', 'path', 'payment',
        'person', 'science', 'structure', 'text', 'transport', 'unit_system']

# Generated at 2022-06-23 21:29:39.830854
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.payment import Payment
    from mimesis.providers.units import UnitSystem

    g = Generic()

    assert(isinstance(g.person, Person))
    assert(isinstance(g.address, Address))
    assert(isinstance(g.datetime, Datetime))

# Generated at 2022-06-23 21:29:46.988709
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic('en')
    assert provider.person
    assert provider.address
    assert provider.datetime
    assert provider.business
    assert provider.text
    assert provider.food
    assert provider.science
    assert provider.transport
    assert provider.code
    assert provider.unit_system
    assert provider.file
    assert provider.numbers
    assert provider.development
    assert provider.hardware
    assert provider.clothing
    assert provider.internet
    assert provider.path
    assert provider.payment
    assert provider.cryptographic
    assert provider.structure
    assert provider.choice
    provider.add_provider(Internet)
    provider.add_providers(Internet, Transport)
    assert provider.internet
    assert provider.transport
    assert provider.internet.domain()
    assert provider.transport.plate_number