

# Generated at 2022-06-23 21:19:45.403277
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Tests the add_providers method of Generic class."""
    from mimesis.providers.word import Word
    from mimesis.enums import Locale
    
    g = Generic(locale=Locale.EN)
    g.add_providers(Word)
    assert isinstance(g.word, Word)

# Generated at 2022-06-23 21:19:56.307410
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

# class CustomPerson(Person):
#     """Custom person class."""

#     class Meta:
#         """Class for metadata."""

#         name = 'custom'

#     def custom(self):
#         """Custom method for testing."""
#         return self.random.choice(['x', 'y', 'z'])

# class_methods = [i[0] for i in inspect.getmembers(CustomPerson, predicate=inspect.isroutine)
#                  if not i[0].startswith('__')]

# person = CustomPerson()
# person.seed(0)
# person.random.choice(['a', 'b', 'c'])
# person.custom()
# person.birth

# Generated at 2022-06-23 21:20:04.205609
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for function add_providers."""
    # Test if add_providers function works fine
    gen = Generic('en')
    class CustomProvider(BaseProvider):
        def foo(self):
            return self.random.randint(100)
    gen.add_providers(CustomProvider)
    assert gen.custom_provider.foo() < 100
    # Test if arg is not class
    try:
        gen.add_providers(1)
    except TypeError:
        pass
    # Test if arg is subclass of BaseProvider
    try:
        gen.add_providers(CustomProvider)
    except TypeError:
        pass

# Generated at 2022-06-23 21:20:10.748162
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    class_provider = type(
        'CustomProvider',
        (BaseProvider,),
        {
            'Meta': type('Meta', (), {'name': 'custom'}),
            '__init__': lambda self: super().__init__()
        }
    )

    gen.add_provider(class_provider)
    assert hasattr(gen, 'custom') is True
    assert hasattr(gen, '_custom') is True
    assert '_custom' in gen.__dict__

    gen.add_provider(class_provider)
    assert hasattr(gen, 'custom') is True
    assert hasattr(gen, '_custom') is True
    assert '_custom' in gen.__dict__


# Generated at 2022-06-23 21:20:17.570630
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    
    meta = Generic.Meta()
    
    assert meta.name == 'generic'
    
    assert Generic.__name__ == 'Generic'
    assert Generic.__module__ == 'mimesis.providers.generic'
    
    assert Generic.__annotations__  == {}
    
    assert Generic.__init__.__name__ == '__init__'
    assert Generic.__init__.__module__ == 'mimesis.providers.generic'
    assert Generic.__init__.__annotations__ == {'args': Any, 'kwargs': Any, 'return': None}
    
    assert Generic.__getattr__.__name__ == '__getattr__'
    assert Generic.__getattr__.__module__ == 'mimesis.providers.generic'
    assert Generic.__getattr__.__

# Generated at 2022-06-23 21:20:18.361961
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass

# Generated at 2022-06-23 21:20:29.663955
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic("en")
    assert(obj.code)
    assert(obj.unit_system)
    assert(obj.file)
    assert(obj.numbers)
    assert(obj.development)
    assert(obj.hardware)
    assert(obj.clothing)
    assert(obj.internet)
    assert(obj.path)
    assert(obj.payment)
    assert(obj.cryptographic)
    assert(obj.structure)
    assert(obj.choice)
    assert(obj.transport)
    assert(obj.person)
    assert(obj.address)
    assert(obj.datetime)
    assert(obj.business)
    assert(obj.text)
    assert(obj.food)
    assert(obj.science)

    assert(obj.person.name())

# Generated at 2022-06-23 21:20:39.419937
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit testing method add_provider of class Generic."""
    class TestProvider(BaseProvider):
        """Class TestProvider."""

        class Meta:  # noqa: D106
            name = 'test_provider'

        def get_test(self) -> str:
            """Get a test string."""
            return self.random.choice(['test-1', 'test-2'])

    generic = Generic()
    generic.add_provider(TestProvider)
    assert hasattr(generic, 'test_provider')
    assert generic.test_provider.get_test() in ['test-1', 'test-2']



# Generated at 2022-06-23 21:20:46.169447
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic(seed=2)

    local_attr_set = {'address', 'business', 'choice', 'code', 'clothing', 'cryptographic', 'datetime',
                      'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'path', 'payment',
                      'person', 'science', 'structure', 'text', 'transport', 'unit_system'}

    assert(set(g.__dir__()) == local_attr_set)



# Generated at 2022-06-23 21:20:47.387131
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.__class__ == Generic

# Generated at 2022-06-23 21:20:49.883342
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__ of class Generic."""
    g = Generic(seed=42)
    assert isinstance(g.__dir__(), list)
    assert 'person' in g.__dir__()


# Generated at 2022-06-23 21:20:57.969251
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g.__dir__(), list)
    assert g.__dir__() != []
    assert g.__dir__() is not None
    assert g.__dir__() is not []
    assert g.__dir__() is not {}
    assert g.__dir__() is not ()
    assert g.__dir__()[0] == 'choice'
    assert g.__dir__()[1] == 'clothing'
    assert g.__dir__()[2] == 'code'
    assert g.__dir__()[3] == 'cryptographic'
    assert g.__dir__()[4] == 'development'
    assert g.__dir__()[5] == 'file'
    assert g.__dir__()[6] == 'hardware'
    assert g.__

# Generated at 2022-06-23 21:21:00.925231
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    test_list = generic.__dir__()
    assert isinstance(test_list, list)


# Generated at 2022-06-23 21:21:08.117015
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Class Generic has all providers as attributes."""
    gen = Generic()
    actual = dir(gen)
    expected = [
        'add_provider',
        'add_providers',
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'payment',
        'person',
        'path',
        'science',
        'structure',
        'transport',
        'unit_system',
    ]
    assert sorted(actual) == sorted(expected)

# Generated at 2022-06-23 21:21:16.428918
# Unit test for constructor of class Generic
def test_Generic():
    #Test Constructor
    g = Generic()
    #Test create person
    name = g.person.full_name()
    assert(name!='')
    #Test create address
    address = g.address.address()
    assert(address!='')
    #Test create datetime
    date = g.datetime.date(minimum=1990, maximum=2020)
    assert(date!='')
    #Test create business
    email = g.business.email()
    assert(email!='')
    #Test create text
    word = g.text.word()
    assert(word!='')
    #Test create food
    food = g.food.fruit()
    assert(food!='')
    #Test create science
    science = g.science.element()
    assert(science!='')


# Generated at 2022-06-23 21:21:18.743028
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.science

    # __getattr__() should add an attribute to Generic().__dict__
    assert 'science' in generic.__dict__.keys()



# Generated at 2022-06-23 21:21:24.669245
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) > 0
    d = g.__dir__()
    assert 'person' in d
    assert 'address' in d
    assert 'datetime' in d
    assert 'business' in d
    assert 'food' in d
    assert 'science' in d
    assert 'text' in d

# Generated at 2022-06-23 21:21:26.264309
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    assert 'business' in dir(Generic())

# Generated at 2022-06-23 21:21:37.314471
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    obj = Generic('en', seed=1)
    result = obj.__dir__()

# Generated at 2022-06-23 21:21:40.809995
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    s = Generic()
    assert not hasattr(s, 'test')
    class Test(BaseProvider):
        class Meta: pass
    s.add_providers(Test)
    assert hasattr(s, 'test')

# Generated at 2022-06-23 21:21:43.541463
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    for a in dir(g):
        getattr(g, a)

# Generated at 2022-06-23 21:21:48.690735
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic=Generic()
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    #print(generic.__dict__.keys())
    generic.add_providers(Numbers,Text)
    #print(generic.__dict__.keys())
    assert 'numbers' in generic.__dict__ and 'text' in generic.__dict__

test_Generic_add_providers()

# Generated at 2022-06-23 21:21:59.686819
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic.

    :return: None
    """
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)

# Generated at 2022-06-23 21:22:08.163625
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('ru')
    assert isinstance(generic._person, Person)
    assert isinstance(generic._address, Address)
    assert isinstance(generic._datetime, Datetime)
    assert isinstance(generic._business, Business)
    assert isinstance(generic._text, Text)
    assert isinstance(generic._food, Food)
    assert isinstance(generic._science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)

# Generated at 2022-06-23 21:22:19.081104
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # test for invalid input class BaseDataProvidier
    from mimesis.providers import BaseDataProvider
    from mimesis.providers.base import BaseProvider
    g = Generic()
    try:
        g.add_provider(BaseDataProvider)
        assert False, 'Test should not be passed'
    except TypeError:
        assert True, 'Test passed'
    # test for invalid input with class not subclass of BaseProvider
    class A:
        pass
    try:
        g.add_provider(A)
        assert False, 'Test should not be passed'
    except TypeError:
        assert True, 'Test passed'
    # test for valid input
    class B(BaseProvider):
        class Meta:
            name = 'b'
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-23 21:22:22.926407
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    mimesis = Generic()
    assert mimesis.person != mimesis._person
    assert mimesis.address != mimesis._address
    assert mimesis.datetime != mimesis._datetime
    assert mimesis.business != mimesis._business
    assert mimesis.text != mimesis._text
    assert mimesis.food != mimesis._food
    assert mimesis.science != mimesis._science


# Generated at 2022-06-23 21:22:31.594845
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test dir of Generic.

    :return:
    """
    providers = [
        Generic().datetime,
        Generic().address,
        Generic().business,
        Generic().food,
        Generic().internet,
        Generic().numbers,
        Generic().unit_system,
        Generic().clothing,
        Generic().cryptographic,
        Generic().development,
        Generic().file,
        Generic().hardware,
        Generic().payment,
        Generic().person,
        Generic().path,
        Generic().science,
        Generic().structure,
        Generic().text,
        Generic().transport,
    ]
    assert 'person' in dir(Generic())
    assert len(providers) == len(dir(Generic()))



# Generated at 2022-06-23 21:22:35.191710
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert 'person' in dir(generic)


# Generated at 2022-06-23 21:22:40.176599
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    print('testing add_provider() method')
    gen = Generic('en')
    gen.add_provider(Clothing)
    print(Clothing)
    print(gen.Clothing)

# Generated at 2022-06-23 21:22:42.140387
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)
    assert isinstance(g, BaseDataProvider)
    assert g.locale == "en"
    assert g.seed == 1

# Generated at 2022-06-23 21:22:44.160313
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.dummy import Dummy
    generic = Generic()
    generic.add_providers(Dummy)

    assert generic.dummy.__provider__ == 'Dummy'

# Generated at 2022-06-23 21:22:45.489002
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    pass


# Generated at 2022-06-23 21:22:54.705418
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.geography import Geography
    from mimesis.providers.media import Media

    class CustomGeography(Geography):
        class Meta:
            name = 'CustomGeography'

    class CustomMedia(Media):
        class Meta:
            name = 'CustomMedia'

    g = Generic()
    g.add_provider(CustomGeography)
    g.add_provider(CustomMedia)

    assert isinstance(g.CustomGeography, CustomGeography)
    assert isinstance(g.CustomMedia, CustomMedia)


# Generated at 2022-06-23 21:23:01.866525
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('en')
    assert not hasattr(generic, 'custom_provider')
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def foo(self):
            return self.random.randint(1, 100)
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom_provider')
    assert hasattr(generic.custom_provider, 'foo')



# Generated at 2022-06-23 21:23:11.887934
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    g = Generic()
    assert g.person
    assert g.address
    assert not g.foo


#   def __getattr__(self, attrname: str) -> Any:
#         """Get attribute without underscore.
#
#         :param attrname: Attribute name.
#         :return: An attribute.
#         """
#         attribute = object.__getattribute__(self, '_' + attrname)
#         if attribute and callable(attribute):
#             self.__dict__[attrname] = attribute(self.locale,
#                                                 self.seed)
#             return self.__dict__[attrname]
#
#     def __dir__(self) -> List[str]:
#         """Available data providers.
#


# Generated at 2022-06-23 21:23:16.991508
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    g = Generic()
    g.add_providers(ProviderA, ProviderB)
    assert g.provider_a.__class__.__name__ == 'ProviderA'
    assert g.provider_b.__class__.__name__ == 'ProviderB'



# Generated at 2022-06-23 21:23:23.474393
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'myprovider'

        def my_method(self):
            return self.random.randint(0, 100)

    g = Generic('en')

    assert 'myprovider' not in dir(g)

    g.add_providers(MyProvider)
    assert 'myprovider' in dir(g)
    assert hasattr(g.myprovider, 'my_method')
    assert isinstance(g.myprovider.my_method(), int)

# Generated at 2022-06-23 21:23:34.379434
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from collections import defaultdict
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def get_value(self) -> str:
            return 'my_value'

    class MyProvider2(BaseProvider):
        class Meta:
            name = 'my_provider2'

        def get_value(self) -> str:
            return 'my_value2'

    gen = Generic()
    gen.add_providers(MyProvider, MyProvider2)
    assert 'my_provider' in gen.__dict__
    assert gen.my_provider.get_value() == 'my_value'
    assert 'my_provider2' in gen.__dict__
    assert gen.my_provider2.get_value() == 'my_value2'

    gen.add_prov

# Generated at 2022-06-23 21:23:35.887513
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    monkey = Generic()
    assert monkey.person.__class__.__name__ == 'Person'
    assert monkey.__class__.__name__ == 'Generic'


# Generated at 2022-06-23 21:23:38.695861
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'cp'
    g = Generic()
    try:
        g.add_provider(CustomProvider)
        assert hasattr(g, 'cp')
    except TypeError:
        assert True

# Generated at 2022-06-23 21:23:46.179113
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.text import TextWrapper

    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._text = TextWrapper('en')

        def some_method(self):
            return self.text.sentence()

    class Meta:
        name = 'custom'

    CustomProvider.Meta = Meta
    g = Generic()
    g.add_provider(CustomProvider)

    assert isinstance(g.custom, CustomProvider)
    assert g.custom.some_method() == 'Aenean et lectus.'



# Generated at 2022-06-23 21:23:51.035784
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic.__dir__."""
    g = Generic()
    assert isinstance(g, object)
    assert isinstance(g, BaseDataProvider)
    assert isinstance(g, Generic)
    assert dir(g)
    assert dir(g) == g.__dir__()

# Generated at 2022-06-23 21:23:58.466292
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic.__dir__()."""
    g = Generic()
    meta = g.Meta
    name = getattr(meta, 'name')
    assert inspect.isclass(g)
    assert name == 'generic'
    assert 'Meta' not in dir(g)
    assert 'Generic' not in dir(g)
    assert 'test_Generic___dir__' not in dir(g)
    assert 'add_provider' in dir(g)
    assert 'add_providers' in dir(g)
    assert 'load_words' in dir(g)
    assert 'load_data' in dir(g)
    assert '__class__' in dir(g)

# Generated at 2022-06-23 21:23:59.893179
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic().seed == Generic().seed

# Generated at 2022-06-23 21:24:07.700700
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('nl')
    assert generic._person is not None
    assert generic._address is not None
    assert generic._datetime is not None
    assert generic._business is not None
    assert generic._text is not None
    assert generic._food is not None
    assert generic._science is not None

    assert generic.transport is not None
    assert generic.code is not None
    assert generic.unit_system is not None
    assert generic.file is not None
    assert generic.numbers is not None
    assert generic.development is not None
    assert generic.hardware is not None
    assert generic.clothing is not None
    assert generic.internet is not None
    assert generic.path is not None
    assert generic.payment is not None
    assert generic.cryptographic is not None
    assert generic.structure is not None

# Generated at 2022-06-23 21:24:10.340098
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.food import Product
    g = Generic()
    assert not hasattr(g, 'product')
    g.add_provider(Product)
    assert hasattr(g, 'product')
    g.add_provider(Generic)
    assert not hasattr(g, 'generic')
    g.add_provider(1)
    assert not hasattr(g, '1')

# Generated at 2022-06-23 21:24:16.103628
# Unit test for constructor of class Generic
def test_Generic():
    # Just test constructors
    n = Generic()
    n.address
    n.business
    n.datetime
    n.development
    n.food
    n.science
    n.text
    n.person
    n.unit_system
    n.transport
    n.code
    n.file
    n.numbers
    n.hardware
    n.clothing
    n.internet
    n.path
    n.payment
    n.cryptographic
    n.structure
    n.choice
    n.seed

# Generated at 2022-06-23 21:24:21.790809
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        """Class for testing."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def custom(self):
            """Custom method."""
            return 'custom'
    g = Generic()
    g.add_providers(CustomProvider)
    assert g.custom.custom() == 'custom'


# Generated at 2022-06-23 21:24:28.799494
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""
    generic = Generic()
    assert set(generic.__dir__()) == set(['address', 'business',
                                          'code', 'choice',
                                          'clothing', 'cryptographic',
                                          'datetime', 'development',
                                          'file', 'food',
                                          'hardware', 'internet',
                                          'numbers', 'path', 'person',
                                          'payment', 'science',
                                          'structure', 'transport',
                                          'unit_system'])


# Generated at 2022-06-23 21:24:33.411556
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender
    class CustomProvider(BaseProvider):
        def sex(self) -> str:
            return self.random.choice(Gender)
    p = Generic()
    p.add_provider(CustomProvider)
    assert hasattr(p, 'custom_provider')

# Generated at 2022-06-23 21:24:35.097369
# Unit test for constructor of class Generic
def test_Generic():
    
    try:
        Generic()
    except Exception as e:
        raise e
    else:
        print("Test Generic Constructor completed")
        

# Generated at 2022-06-23 21:24:42.738384
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.path import Path

# Generated at 2022-06-23 21:24:53.639758
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.person.__dir__() == Person().__dir__() + ['gender', 'get_gender']
    assert g.address.__dir__() == Address().__dir__()
    assert g.datetime.__dir__() == Datetime().__dir__()
    assert g.business.__dir__() == Business().__dir__()
    assert g.text.__dir__() == Text().__dir__()
    assert g.food.__dir__() == Food().__dir__()
    assert g.science.__dir__() == Science().__dir__()
    assert g.transport.__dir__() == Transport().__dir__()
    assert g.code.__dir__() == Code().__dir__()
    assert g.unit_system.__dir__() == UnitSystem().__dir__

# Generated at 2022-06-23 21:24:57.177694
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """
    Get Generic.person, Generic.address and Generic.datetime
    """
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None


# Generated at 2022-06-23 21:25:03.060280
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic().__getattr__()."""
    assert Generic()._person is not None
    assert Generic()._address is not None
    assert Generic()._datetime is not None
    assert Generic()._business is not None
    assert Generic()._text is not None
    assert Generic()._food is not None
    assert Generic()._science is not None


# Generated at 2022-06-23 21:25:09.248732
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic(seed=1)
    # Testing with a standard provider
    person_attr = obj.person
    assert isinstance(person_attr, Person)
    # Testing _transport attribute,
    # because the first letter of the name of the provider is the same
    assert obj.transport is None
    # Testing with a custom provider
    from .test_provider import CustomProvider

    obj.add_provider(CustomProvider)
    assert obj.custom_provider is None



# Generated at 2022-06-23 21:25:15.915602
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider()."""
    class CustomProvider(BaseProvider):
        """Test custom provider."""

        class Meta:
            """Test meta class."""
            name = 'custom'

        def method(self):
            """Test method."""
            return 'Hello World'

    provider = Generic()
    provider.add_provider(CustomProvider)

    assert 'custom' in dir(provider)

    # Check function call
    assert provider.custom.method() == 'Hello World'


# Generated at 2022-06-23 21:25:21.954406
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider

    class Foo(BaseProvider):
        pass

    obj = Generic()
    obj.add_provider(Foo)

    assert 'foo' in dir(obj)
    assert isinstance(obj.foo, Foo)
    assert obj.foo.seed == obj.seed


# Generated at 2022-06-23 21:25:29.548456
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import mimesis.providers.identification as identification
    generic = Generic()
    generic.add_provider(identification.Passport)
    generic.add_provider(identification.IDCard)
    assert 'passport' in generic.__dir__()
    assert 'idcard' in generic.__dir__()
    assert 'passport' in generic.__dict__.keys()
    assert 'idcard' in generic.__dict__.keys()
    assert generic.passport.series().isdigit()
    assert len(generic.passport.number()) == 6
    assert generic.idcard.number().isdigit()
    assert len(generic.idcard.name()) > 0

# Generated at 2022-06-23 21:25:41.945715
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person in ('John', 'Joseph', 'Jack', 'Jay', 'Joshua',
                        'James', 'Jacob', 'Justin', 'Jake', 'Jeremy')
    assert g.address in ('2', '3', '4', '5', '6', '7', '8', '9', '10')
    assert g.datetime in ('1', '2', '3', '4', '5', '6', '7', '8', '9',
                          '0', '11', '12', '13', '14', '15', '16', '17',
                          '18', '19', '20', '21', '22', '23', '24', '25',
                          '26', '27', '28', '29', '30', '31')

# Generated at 2022-06-23 21:25:48.301310
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method of class Generic."""
    gen = Generic()
    class MyProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Meta attributes."""
            name = 'my_provider'

        def one(self) -> str:
            """Return one."""
            return 'one'

    gen.add_provider(MyProvider)
    assert hasattr(gen, 'my_provider')
    assert gen.my_provider.one() == 'one'

# Generated at 2022-06-23 21:25:50.120125
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # TODO: add test
    pass


# Generated at 2022-06-23 21:25:55.291484
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test adding the custom providers."""
    from mimesis.providers.development import DebugMeta
    from mimesis.providers.science import Science

    gen = Generic()
    gen.add_providers(DebugMeta, Science)
    assert isinstance(gen.debug, DebugMeta)
    assert isinstance(gen.science, Science)

# Generated at 2022-06-23 21:26:03.272872
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from provider import Person
    from generic import Generic

    custom_provider = Person(seed=42)
    container = Generic(seed=42)

    # Test for adding custom provider
    container.add_provider(Person)
    assert container.person.name(gender=Gender.FEMALE) == \
        custom_provider.name(gender=Gender.FEMALE)

    # Test for error if provider is not a class
    # Test for error if provider is not a subclass of BaseProvider
    wrong_providers = [
        'Person',
        42,
        None,
        [],
        {},
        ()
    ]
    for provider in wrong_providers:
        try:
            container.add_provider(provider)
        except TypeError:
            pass
       

# Generated at 2022-06-23 21:26:08.715757
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Init a generic object."""
    generic = Generic()

    # Testing with 1 provider
    generic.add_providers(Person)
    assert hasattr(generic, 'person')

    # Testing with more providers
    generic.add_providers(Address, Datetime)
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'datetime')

# Generated at 2022-06-23 21:26:09.779242
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert isinstance(Generic.__dir__(), list)

# Generated at 2022-06-23 21:26:12.709705
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    attrs = ['person', 'address', 'datetime', 'business']
    assert all(hasattr(generic, a) for a in attrs)



# Generated at 2022-06-23 21:26:14.790289
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic.__dir__() method."""
    data = Generic()
    assert len(data.__dir__()) == 21

# Generated at 2022-06-23 21:26:24.083443
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    def test_provider(method):
        def helper():
            return method()

        helper.__name__ = method.__name__
        return helper

    gener = Generic()  # noqa: S106
    gener.add_providers(
        test_provider,
    )

    assert hasattr(gener, 'test_provider')
    assert callable(getattr(gener, 'test_provider'))

    gener.add_providers(
        test_provider,
        test_provider,
        test_provider,
    )

    assert hasattr(gener, 'test_provider')
    assert callable(getattr(gener, 'test_provider'))

# Generated at 2022-06-23 21:26:32.647875
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class NewProvider(BaseProvider):
        def foo(self):
            return 'foo'

    generic = Generic()
    generic.add_provider(NewProvider)
    assert hasattr(generic, 'newprovider')
    assert generic.newprovider.foo() == 'foo'

    # Test the exception
    class NewProvider2:
        def foo(self):
            return 'foo'

    try:
         generic.add_provider(NewProvider2)
    except TypeError as exception:
        assert str(exception) == 'The provider must be a class'

# Generated at 2022-06-23 21:26:36.748647
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

    a = Generic()
    assert a.custom_provider is None
    a.add_provider(CustomProvider)
    assert isinstance(a.custom_provider, CustomProvider)

# Generated at 2022-06-23 21:26:38.017032
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Generic = Generic(seed=42)
    assert isinstance(Generic.person, Person)

# Generated at 2022-06-23 21:26:41.950464
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for Generic.add_provider."""
    from mimesis.providers.generic import Generic
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.internet import Internet

    g = Generic()
    g.add_provider(Lorem)
    g.add_provider(Internet)


if __name__ == '__main__':
    test_Generic_add_provider()

# Generated at 2022-06-23 21:26:46.438102
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    res = dir(gen)
    assert len(res) == len(gen.__dict__) - 1
    assert 'transport' in res and 'code' in res and 'unit_system' in res and 'file' in res and 'numbers' in res


# Generated at 2022-06-23 21:26:57.771502
# Unit test for constructor of class Generic
def test_Generic():
    # test initialization of Generic
    gen = Generic()

    assert gen.seed == 0

    # test that all the providers inside Generic work
    assert gen.person.full_name() is not None
    assert gen.address.address() is not None
    assert gen.business.nip() is not None
    assert gen.text.text() is not None
    assert gen.food.fruit() is not None
    assert gen.science.planet() is not None
    assert gen.transport.vehicle() is not None
    assert gen.code.ean() is not None
    assert gen.unit_system.unit() is not None
    assert gen.file.filename() is not None
    assert gen.numbers.integer() is not None
    assert gen.development.file_extension() is not None

# Generated at 2022-06-23 21:27:01.684590
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test if add_provider(cls) works."""
    from mimesis.providers.development import Development

    generic = Generic()
    generic.add_provider(Development)
    assert generic.development is not None

# Generated at 2022-06-23 21:27:07.438844
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert (isinstance(a, Generic))
    assert (isinstance(a.person, Person))
    assert (isinstance(a.address, Address))
    assert (isinstance(a.datetime, Datetime))
    assert (isinstance(a.business, Business))
    assert (isinstance(a.text, Text))
    assert (isinstance(a.food, Food))
    assert (isinstance(a.science, Science))
    assert (isinstance(a.transport, Transport))
    assert (isinstance(a.code, Code))
    assert (isinstance(a.unit_system, UnitSystem))
    assert (isinstance(a.file, File))
    assert (isinstance(a.numbers, Numbers))
    assert (isinstance(a.development, Development))

# Generated at 2022-06-23 21:27:18.293621
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.choice.choices is not None
    assert g.business.company_name() is not None
    assert g.person.full_name() is not None
    assert g.address.city() is not None
    assert g.datetime.current_datetime is not None
    assert g.person.name() is not None
    assert g.clothing.type_of_clothing() is not None
    assert g.file.extension() is not None
    assert g.food.recipe() is not None
    assert g.science.science() is not None
    assert g.transport.vehicle() is not None
    assert g.code.isbn() is not None
    assert g.unit_system.mass(prefix='Mega') is not None

# Generated at 2022-06-23 21:27:28.930408
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('fr')
    assert callable(generic.person)
    assert callable(generic.address)
    assert callable(generic.datetime)
    assert callable(generic.business)
    assert callable(generic.text)
    assert callable(generic.food)
    assert callable(generic.science)
    assert callable(generic.transport)
    assert callable(generic.code)
    assert callable(generic.unit_system)
    assert callable(generic.file)
    assert callable(generic.numbers)
    assert callable(generic.development)
    assert callable(generic.hardware)
    assert callable(generic.clothing)
    assert callable(generic.internet)
    assert callable(generic.path)
    assert callable(generic.payment)
    assert callable

# Generated at 2022-06-23 21:27:31.776129
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.business.company_name()
    assert hasattr(g, 'business') == True
    assert hasattr(g, 'datetime') == True

test_Generic___getattr__()

# Generated at 2022-06-23 21:27:39.540215
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = "test"
        def test_provider(self):
            return "pass"
    generic = Generic()
    generic.add_provider(Test)
    assert generic.test.test_provider() == "pass"
    try:
        generic.add_provider(Datetime)
    except TypeError:
        assert True
    test = Test(seed=generic.seed)
    assert test.test_provider() == "pass"

# Generated at 2022-06-23 21:27:42.284219
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class FooProvider(BaseProvider):
        pass

    g = Generic()
    g.add_provider(FooProvider)
    assert isinstance(g.foo, FooProvider)


# Generated at 2022-06-23 21:27:44.955772
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    t = Generic("en_US")
    t.person()
    assert t.person() == t._person(locale="en_US", seed=None)
    assert t.person == t._person(locale="en_US", seed=None)

# Generated at 2022-06-23 21:27:46.823408
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    obj = Generic()
    obj.add_providers(Numbers)
    assert isinstance(obj.numbers, Numbers)



# Generated at 2022-06-23 21:27:54.621888
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class NewProvider(BaseProvider):
        """New class."""
        class Meta:
            """Metaclass."""
            name = 'new'

        def __init__(self, seed: Any = None) -> None:
            """Initialize attributes.

            :param seed: Seed.
            """
            super().__init__(seed=None)

        def foo(self) -> str:
            """Generate foo."""
            return 'foo'

    g = Generic()
    g.add_provider(NewProvider)
    assert 'new' in g.__dict__
    assert 'new' in g.__dir__()
    assert callable(getattr(g, 'new'))
    assert callable(getattr(g, 'new').foo)
    assert g.new.foo() == 'foo'

# Generated at 2022-06-23 21:28:00.914403
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.code import Code
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.file import File

    g = Generic()
    g.add_providers(Code, Datetime, File, File, File)
    assert hasattr(g, 'code')
    assert hasattr(g, 'datetime')
    assert hasattr(g.datetime.datetime, 'timestamp')
    assert hasattr(g.file, 'extension')

# Generated at 2022-06-23 21:28:03.181676
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    method = '__dir__'
    generic = Generic()
    result = list(sorted(generic.__dir__()))
    assert method in result

# Generated at 2022-06-23 21:28:14.700437
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g.random, float)
    assert isinstance(g.random.int(0,10), int)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)

# Generated at 2022-06-23 21:28:16.936046
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(Test)
    assert g.test.foo() == 'bar'

# Generated at 2022-06-23 21:28:27.512776
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = g.__dir__()
    expected = [
        'add_provider',
        'add_providers',
        'person',
        'address',
        'business',
        'datetime',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]
    assert sorted(result) == sorted(expected)

# Generated at 2022-06-23 21:28:34.450297
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test Generic.__dir__()."""
    generic = Generic(seed=42)
    expected_result = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
        ]
    assert generic.__dir__() == expected_result

# Generated at 2022-06-23 21:28:35.904453
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    g.add_provider(Address)
    g.address.address()

# Generated at 2022-06-23 21:28:39.686986
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert isinstance(a.numbers, Numbers)
    assert isinstance(a.unit_system, UnitSystem)
    assert isinstance(a.transport, Transport)
    assert isinstance(a.file, File)


# Generated at 2022-06-23 21:28:42.320928
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    print(dir(g))
    assert hasattr(g, 'person')
    g.add_provider(Person)
    assert hasattr(g, 'person')

# Generated at 2022-06-23 21:28:50.845082
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    a = Generic()
    # Custom provider without seed
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

    class MyProvider2(BaseProvider):
        class Meta:
            name = 'my_provider2'

    a.add_providers(MyProvider, MyProvider2)

    assert hasattr(a, 'my_provider')
    assert hasattr(a, 'my_provider2')

    assert isinstance(a.my_provider, MyProvider)
    assert isinstance(a.my_provider2, MyProvider2)

# Generated at 2022-06-23 21:28:55.108594
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('en')
    providers = ['Address', 'Datetime', 'Business', 'Text', 'Food', 'Science']

# Generated at 2022-06-23 21:28:59.287366
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic(seed=0)
    assert len(dir(generic)) == 5
    class Provider(BaseProvider):
        class Meta:
            name = 'test'

        def test(self):
            return 'test'
    generic.add_providers(Provider, Provider)
    assert len(dir(generic)) == 7
    assert generic.test.test() == 'test'

# Generated at 2022-06-23 21:29:06.526987
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    # Check the required attributes.
    assert generic.choice is not None
    assert generic.code is not None
    assert generic.cryptographic is not None
    assert generic.datetime is not None
    assert generic.development is not None
    assert generic.file is not None
    assert generic.hardware is not None
    assert generic.internet is not None
    assert generic.numbers is not None
    assert generic.payment is not None
    assert generic.path is not None
    assert generic.structure is not None
    assert generic.transport is not None
    assert generic.unit_system is not None
    assert generic.business is not None
    assert generic.food is not None
    assert generic.clothing is not None
    assert generic.science is not None
    assert generic.person is not None
    assert generic.text

# Generated at 2022-06-23 21:29:18.254794
# Unit test for constructor of class Generic
def test_Generic():
    # Create the object
    generic = Generic(seed=42)
    # Create the object and add custom providers
    custom_providers = [Generic]
    generic2 = Generic(providers=custom_providers, seed=42)
    # Check that the object has attribute
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'text')
    assert hasattr(generic, 'food')
    assert hasattr(generic, 'science')
    assert hasattr(generic, 'transport')
    assert hasattr(generic, 'code')
    assert hasattr(generic, 'unit_system')
    assert hasattr(generic, 'file')

# Generated at 2022-06-23 21:29:21.389888
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('ru')
    g._choice.set_choices('a', 'b', 'c', 'd')
    result = set()
    for _ in range(10):
        result.add(g.choice.choice())
    assert len(result) == 4


# Generated at 2022-06-23 21:29:28.374864
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    i = Generic()
    # doctest: +ELLIPSIS
    assert i.__dir__() == ['address', 'choice', 'clothing', 'code', 'cryptographic', 'datetime', 'development', 'file',
                           'food', 'hardware', 'internet', 'numbers', 'payment', 'path', 'person', 'science', 'structure',
                           'text', 'transport', 'unit_system']
    # doctest: +ELLIPSIS
    assert type(i.__dir__()) is list

# Generated at 2022-06-23 21:29:39.980642
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    t = Generic()
    assert isinstance(t, Generic)
    assert 'business' in dir(t)
    assert 'text' in dir(t)
    assert 'person' in dir(t)
    assert 'address' in dir(t)
    assert 'datetime' in dir(t)
    assert 'clothing' in dir(t)
    assert 'code' in dir(t)
    assert 'unit_system' in dir(t)
    assert 'file' in dir(t)
    assert 'numbers' in dir(t)
    assert 'development' in dir(t)
    assert 'hardware' in dir(t)
    assert 'internet' in dir(t)
    assert 'path' in dir(t)