

# Generated at 2022-06-23 21:19:43.378306
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person, Person)

# Generated at 2022-06-23 21:19:47.872907
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Expected Result
    desired_result = "Lloyd"
    # Actual Result
    test = Generic(seed=1)
    actual_result = test.person.full_name()
    # Check for equality
    assert actual_result == desired_result


# Generated at 2022-06-23 21:19:57.701100
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.enums import Gender
    from mimesis.providers.mixins import AddressProvider
    from mimesis.providers.person import Person
    from mimesis.providers.transport import Transport
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.text import Text

    type_test = type(Generic())
    assert isinstance(type_test.person, Person)

    assert isinstance(type_test.person.full_name(), str)
    assert type_test.person.gender() == Gender.MALE
    assert isinstance(type_test.person.occupation(), str)
    assert isinstance(type_test.person.password(), str)

# Generated at 2022-06-23 21:20:06.615272
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():

    class Custom(BaseProvider):
        def __init__(self, seed: Any = None, **kwargs: Any) -> None:
            super().__init__(seed=seed, **kwargs)
            
        def test(self):
            return 'test'
    
    class Custom2(BaseProvider):
        def __init__(self, seed: Any = None, **kwargs: Any) -> None:
            super().__init__(seed=seed, **kwargs)
            
        def test2(self):
            return 'test2'

    gen = Generic()

    gen.add_providers(Custom, Custom2)

    assert gen.custom.test() == 'test'
    assert gen.custom2.test2() == 'test2'

# Generated at 2022-06-23 21:20:11.586379
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic(seed=12)
    gen.gender  # Created Person object with seed=12

    assert gen.__getattribute__('_person') == gen.person
    assert gen.person.seed == 12
    assert isinstance(gen.person, Person)



# Generated at 2022-06-23 21:20:14.097940
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    not_found_property = 'not_found_property'
    try:
        Generic().not_found_property
    except AttributeError:
        assert True
    else:
        assert False, 'Expected AttributeError'



# Generated at 2022-06-23 21:20:25.506481
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider1(BaseProvider):
        class Meta:
            name = 'provider_1'

    class Provider2(BaseProvider):
        class Meta:
            name = 'provider_2'

    class Provider3(BaseProvider):
        class Meta:
            name = 'provider_3'

    class Provider4(BaseProvider):
        class Meta:
            name = 'provider_4'

    g = Generic()
    g.add_providers(Provider1, Provider2, Provider3, Provider4)

    assert getattr(g, 'provider_1') is not None
    assert getattr(g, 'provider_2') is not None
    assert getattr(g, 'provider_3') is not None
    assert getattr(g, 'provider_4') is not None



# Generated at 2022-06-23 21:20:28.082603
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    dir_test_resul = Generic().__dir__()
    assert isinstance(dir_test_resul[0], str)



# Generated at 2022-06-23 21:20:39.629512
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider_with_meta = type('provider',
                              (BaseProvider,),
                              {'Meta': type('Meta', (object,), {'name': 'name'})})
    provider_without_meta = type('provider', (BaseProvider,), {})
    generic = Generic()
    assert not hasattr(generic, 'name')
    assert not hasattr(generic, 'provider')

# Generated at 2022-06-23 21:20:41.528468
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g._address = 'Ivanov'
    assert g.address == 'Ivanov'

# Generated at 2022-06-23 21:20:50.835582
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic(seed=1)
    assert ('address' in dir(a)) is True
    assert ('datetime' in dir(a)) is True
    assert ('person' in dir(a)) is True
    assert ('business' in dir(a)) is True
    assert ('text' in dir(a)) is True
    assert ('food' in dir(a)) is True
    assert ('transport' in dir(a)) is True
    assert ('code' in dir(a)) is True
    assert ('unit_system' in dir(a)) is True
    assert ('file' in dir(a)) is True
    assert ('numbers' in dir(a)) is True
    assert ('development' in dir(a)) is True
    assert ('hardware' in dir(a)) is True
    assert ('clothing' in dir(a)) is True


# Generated at 2022-06-23 21:20:56.046280
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class CustomPerson(Person):
        class Meta:
            name = 'custom_person'

        def name(self, gender: Gender = None) -> str:
            return 'John Doe'

    g = Generic()
    g.add_provider(CustomPerson)

    assert hasattr(g, 'custom_person')
    assert g.custom_person.name() == 'John Doe'

# Generated at 2022-06-23 21:21:04.306194
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geography import Geography
    from mimesis.providers.misc import Misc
    from mimesis.providers.person import Person
    generic = Generic('ru')
    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    generic.add_provider(Misc)
    generic.add_provider(Geography)
    assert hasattr(generic, 'misc')
    assert hasattr(generic, 'geography')

# Generated at 2022-06-23 21:21:11.304563
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert 'person' in dir(g)
    assert 'address' in dir(g)
    assert 'datetime' in dir(g)
    assert 'business' in dir(g)
    assert 'text' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)


# Generated at 2022-06-23 21:21:13.423869
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic(seed=1)
    custom_provider = gen.choice
    gen.add_provider(custom_provider)

    assert hasattr(gen, 'choice')


# Generated at 2022-06-23 21:21:16.878266
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # create instance of class Generic
    generic = Generic()

    # add providers to instance of class Generic
    generic.add_providers(Generic, Generic)

    # test: if dict of instance of class Generic contains name of class Generic
    assert 'generic' in generic.__dict__.keys()

    # test: if dict of instance of class Generic contains name of class Generic 2 times
    assert list(generic.__dict__.keys()).count('generic') == 2



# Generated at 2022-06-23 21:21:18.144241
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    print(generic._person.full_name())


# Generated at 2022-06-23 21:21:25.230890
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science

    g = Generic()
    assert (type(g.person) == Person)
    assert (type(g.address) == Address)
    assert (type(g.datetime) == Datetime)
    assert (type(g.business) == Business)
    assert (type(g.text) == Text)
    assert (type(g.food) == Food)
    assert (type(g.science) == Science)



# Generated at 2022-06-23 21:21:29.251925
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    from mimesis.providers.payment import CreditCard

    generic = Generic('en')
    assert generic.seed == 'en'

    assert generic.scien

# Generated at 2022-06-23 21:21:36.103356
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .test_provider import CustomProvider
    from .test_provider import CustomProvider2

    generic = Generic()
    generic.add_provider(CustomProvider)
    generic.add_provider(CustomProvider2)
    assert hasattr(generic, 'custom_provider')
    assert hasattr(generic, 'custom_provider2')
    assert isinstance(generic.custom_provider, CustomProvider)
    assert isinstance(generic.custom_provider2, CustomProvider2)

# Generated at 2022-06-23 21:21:39.496844
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    keys = [k for k in g.__dir__()]
    print(keys[0])


# Generated at 2022-06-23 21:21:44.789114
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()

# Generated at 2022-06-23 21:21:52.143303
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    obj = Generic()
    assert 'test' not in dir(obj)
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def test(self) -> int:
            return self.random.randint(1, 10)

    obj.add_provider(TestProvider)
    assert 'test' in dir(obj)
    assert isinstance(obj.test, TestProvider)
    assert 1 <= obj.test.test() <= 10


# Generated at 2022-06-23 21:21:56.491941
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    print(gen.person.full_name())
    print(gen.address.address())
    print(gen.business.company())
    print(gen.datetime.date(minimum=0, maximum=300000000))
    print(gen.food.ingredient())
    print(gen.science.element())
    print(gen.transport.model())
    print(gen.code.serial_number())
    print(gen.unit_system.unit_name())
    print(gen.file.extension())
    print(gen.numbers.between(0,255))
    print(gen.development.language())
    print(gen.hardware.cpu_name())
    print(gen.clothing.brand())
    print(gen.internet.domain_name())
    print(gen.path.url())


# Generated at 2022-06-23 21:22:00.954176
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        """This is a test provider."""
        pass

    test_provider = TestProvider()
    name = test_provider.__class__.__name__.lower()
    generic = Generic()
    assert not hasattr(generic, name)
    generic.add_provider(TestProvider)
    assert hasattr(generic, name)


# Generated at 2022-06-23 21:22:04.315206
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person, Person)


# Generated at 2022-06-23 21:22:16.482250
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert(hasattr(gen, 'person'))
    assert(hasattr(gen, 'address'))
    assert(hasattr(gen, 'datetime'))
    assert(hasattr(gen, 'business'))
    assert(hasattr(gen, 'text'))
    assert(hasattr(gen, 'food'))
    assert(hasattr(gen, 'science'))
    assert(hasattr(gen, 'transport'))
    assert(hasattr(gen, 'code'))
    assert(hasattr(gen, 'unit_system'))
    assert(hasattr(gen, 'file'))
    assert(hasattr(gen, 'numbers'))
    assert(hasattr(gen, 'development'))
    assert(hasattr(gen, 'hardware'))

# Generated at 2022-06-23 21:22:20.086664
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Foo(BaseProvider):
        def bar(self):
            return 'bar'

        class Meta:
            name = 'foo'

    g = Generic()
    g.add_provider(Foo)
    assert hasattr(g, 'foo')
    assert g.foo.bar() == 'bar'



# Generated at 2022-06-23 21:22:21.062891
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic()
    assert a.name


# Generated at 2022-06-23 21:22:30.433887
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()

    assert generic._address == Address
    assert generic.address == Address(seed=generic.seed)
    assert generic.address != Address(seed=generic.seed)

    assert generic._person == Person
    assert generic.person == Person(seed=generic.seed)
    assert generic.person != Person(seed=generic.seed)

    assert generic._datetime == Datetime
    assert generic.datetime == Datetime(seed=generic.seed)
    assert generic.datetime != Datetime(seed=generic.seed)

    assert generic._business == Business
    assert generic.business == Business(seed=generic.seed)
    assert generic.business != Business(seed=generic.seed)



# Generated at 2022-06-23 21:22:41.247045
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('en')
    assert isinstance(gen.person(), Person)
    assert isinstance(gen.address(), Address)
    assert isinstance(gen.datetime(), Datetime)
    assert isinstance(gen.business(), Business)
    assert isinstance(gen.text(), Text)
    assert isinstance(gen.food(), Food)
    assert isinstance(gen.science(), Science)
    assert isinstance(gen.transport(), Transport)
    assert isinstance(gen.code(), Code)
    assert isinstance(gen.unit_system(), UnitSystem)
    assert isinstance(gen.file(), File)
    assert isinstance(gen.numbers(), Numbers)
    assert isinstance(gen.development(), Development)
    assert isinstance(gen.hardware(), Hardware)
    assert isinstance(gen.clothing(), Clothing)

# Generated at 2022-06-23 21:22:46.935586
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    custom_clazz = []
    generic = Generic()
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime

    class test_provider(Person):
        class Meta:
            name = 'test'

    class test_address_provider(Address):
        class Meta:
            name = 'test_address'

    custom_clazz.append(test_address_provider)
    custom_clazz.append(test_provider)
    generic.add_providers(*custom_clazz)
    assert generic.test_address.country == "China"
    assert generic.test.name(gender="female") == "Chen Huang"

# Generated at 2022-06-23 21:22:50.252033
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    prov = Generic()
    assert 'file' in dir(prov)
    assert 'choice' in dir(prov)
    assert 'code' in dir(prov)

# Generated at 2022-06-23 21:22:50.750305
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()

# Generated at 2022-06-23 21:22:55.659394
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class ExtendedProvider(BaseProvider):
        class Meta:
            name = 'extended_provider'

        @classmethod
        def method(cls):
            pass

    g = Generic()
    g.add_provider(ExtendedProvider)
    assert isinstance(g.extended_provider, ExtendedProvider)
    assert hasattr(g.extended_provider, 'method')

# Generated at 2022-06-23 21:22:57.228149
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    print(Generic().__dir__())
    assert isinstance(Generic().__dir__(), list)

# Generated at 2022-06-23 21:23:02.657918
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .mimesis_test import add_provider_test
    print('Test for method add_provider of class Generic')
    generic = Generic('en')
    generic.add_provider(add_provider_test)
    assert(hasattr(generic, 'addprovidertest'))
    print('Test is passed')


# Generated at 2022-06-23 21:23:09.342857
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Testing for adding providers to Generic() object."""
    class NewProvider(BaseProvider):
        """New provider."""
        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        class Meta:
            """Metaclass."""
            name = 'new_provider'

    g = Generic()
    g.add_providers(NewProvider)
    assert hasattr(g, 'new_provider')



# Generated at 2022-06-23 21:23:10.277952
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-23 21:23:18.236045
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic("zh")
    assert isinstance(generic, Generic)
    assert generic.developer() != ""
    assert isinstance(generic.create_token(), str)
    assert isinstance(generic.dns_label(), str)
    assert isinstance(generic.latitude(), float)
    assert isinstance(generic.longitude(), float)
    assert isinstance(generic.coordinate(), str)
    assert isinstance(generic.phone_number(), str)
    assert isinstance(generic.telephone(), str)
    assert isinstance(generic.city_name(), str)
    assert isinstance(generic.street_name(), str)
    assert isinstance(generic.street_address(), str)
    assert isinstance(generic.street(), str)
    assert isinstance(generic.building_number(), str)

# Generated at 2022-06-23 21:23:20.128364
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import Development

    g = Generic()
    g.add_provider(Development)
    assert 'development' in g.__dir__()



# Generated at 2022-06-23 21:23:26.109815
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for generic.Generic().__dir__()."""
    g = Generic()
    assert hasattr(g, 'person')

    assert 'person' in dir(g)
    assert 'address' in dir(g)
    assert 'datetime' in dir(g)
    assert 'business' in dir(g)
    assert 'text' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)
    assert 'transport' in dir(g)
    assert 'code' in dir(g)
    assert 'unit_system' in dir(g)
    assert 'file' in dir(g)
    assert 'numbers' in dir(g)
    assert 'development' in dir(g)
    assert 'hardware' in dir(g)

# Generated at 2022-06-23 21:23:29.832424
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.cryptographic import Base64
    g = Generic()
    g.add_provider(Base64)
    assert isinstance(g.base64, Base64)



# Generated at 2022-06-23 21:23:36.937201
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.providers.instagram import Instagram
    from mimesis.providers.person import Person

    insta = Instagram(seed=42)
    pers = Person(seed=42)
    g = Generic(seed=42)
    g.add_providers(insta.__class__, pers.__class__)
    assert isinstance(g.instagram, Instagram)
    assert isinstance(g.person, Person)

# Generated at 2022-06-23 21:23:37.445521
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass

# Generated at 2022-06-23 21:23:46.143233
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method .add_provider() of class Generic.

    :return: None
    """
    from mimesis.providers.education import Education
    gen = Generic()
    gen.add_provider(Education)
    assert gen.education.faculty() == 'Факультет Техники и технологии пищевых продуктов'
    gen.add_provider(Transport)
    assert gen.transport.boat() == 'Страйкер'
    assert gen.transport.manufacturer() == 'ИЖМАШ'
    gen.add_providers(Education, Transport)
    assert gen.trans

# Generated at 2022-06-23 21:23:51.871795
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert not hasattr(gen, 'test')
    gen.add_provider(Person)
    assert hasattr(gen, 'person')
    gen.add_provider(Address)
    assert hasattr(gen, 'address')
    gen.add_provider(Datetime)
    assert hasattr(gen, 'datetime')

# Generated at 2022-06-23 21:23:54.791233
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    c = Generic()
    assert hasattr(c, '_person')
    assert not hasattr(c, 'person')
    person = c.person
    assert person is not None


# Generated at 2022-06-23 21:24:00.534381
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Foo(BaseProvider):
        pass

    class Bar(BaseProvider):
        pass

    obj = Generic()
    obj.add_providers(Foo, Bar)
    assert hasattr(obj, 'foo')
    assert isinstance(obj.foo, Foo)
    assert hasattr(obj, 'bar')
    assert isinstance(obj.bar, Bar)

# Generated at 2022-06-23 21:24:05.280202
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    dir_generic = dir(generic)
    expected = ['person', 'address', 'datetime', 'business',
          'text', 'food', 'science', 'transport',
          'code', 'unit_system', 'file', 'numbers',
          'development', 'hardware', 'clothing',
          'internet', 'path', 'payment', 'cryptographic',
          'structure', 'choice']
    assert dir_generic == expected

# Generated at 2022-06-23 21:24:07.479495
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.provider == 'generic'


# Generated at 2022-06-23 21:24:08.849559
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.music import Music
    m = Generic().add_provider(Music)
    assert isinstance(m, Generic)



# Generated at 2022-06-23 21:24:16.989538
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    gen = Generic()
    assert gen.name == 'generic'
    assert gen.age == 27
    assert gen.address.address() == 'Marekovskiy 14'
    gen.add_providers(UnitSystem, Datetime)
    assert gen.unit_system.name == 'unit_system'
    assert gen.datetime.name == 'datetime'
    assert gen.unit_system.mass_unit() == 'g'
    assert gen.datetime.year() == '2011'
    gen.add_providers(Person, Address)
    assert gen.person.name == 'person'
    assert gen.address.name == 'address'
    assert gen.person.full_name() == 'Max Murphy'

# Generated at 2022-06-23 21:24:27.888893
# Unit test for constructor of class Generic
def test_Generic():

    g=Generic()
    print(dir(g))
    print(g.person.full_name())
    print(g.business.company_name())
    print(g.address.address())
    print(g.food.ingredient())
    print(g.text.sentence(quantity=10))
    print(g.unit_system.mass())
    print(g.file.extension())
    print(g.numbers.calc_factorial(n=3))
    print(g.development.package())
    print(g.hardware.gpu())
    print(g.clothing.clothing())
    print(g.internet.url())
    print(g.path.linux_root_directory())
    print(g.payment.bank_card_number())

# Generated at 2022-06-23 21:24:29.861037
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic('en')
    gen.add_providers(cls)
    gen.cls.foo()

# Generated at 2022-06-23 21:24:39.416074
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class NewProvider(BaseProvider):
        """This is a new provider."""

        class Meta:
            """Class for metadata."""

            name = 'new_provider'
        # Unit test for method add_providers of class Generic
        def test_Generic_add_providers():
            class NewProvider(BaseProvider):
                """This is a new provider."""
        
                class Meta:
                    """Class for metadata."""
        
                    name = 'new_provider'

                def provide(self) -> str:
                    """Provide data.

                    :return: New data.
                    """
                    return self.random.choice(['a', 'b', 'c'])

            g = Generic('en')
            g.add_providers(NewProvider)

# Generated at 2022-06-23 21:24:50.999409
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Foo(BaseProvider):
        class Meta:
            name = "foo"

        def bar(self):
            return self.random.randint(0, 100000)

    class Bar(BaseDataProvider):
        class Meta:
            name = "bar"

    class FooBar(BaseDataProvider):
        class Meta:
            name = "foobar"

    generiс = Generic()
    generiс.add_providers(Foo, Bar, FooBar)
    assert isinstance(generiс.foo, Foo)
    assert isinstance(generiс.bar, Bar)
    assert isinstance(generiс.foobar, FooBar)

    generiс = Generic()
    generiс.add_providers(Foo, Bar, FooBar)
    assert isinstance(generiс.foo, Foo)
   

# Generated at 2022-06-23 21:24:54.867683
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Tests for __getattr__() of Generic."""
    # Initialize `Generic` object
    generic = Generic()

    # Initialize `Person` data provider
    person = Person()

    # Call `_person` from `Generic` object
    _person = generic._person

    # Compare results
    assert _person == person


# Generated at 2022-06-23 21:24:57.863663
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """To test method __getattr__ of class Generic."""
    generic = Generic()
    person = generic.person
    assert person.__class__.__name__ == Person.__name__
    assert person._region == 'en'



# Generated at 2022-06-23 21:24:59.354533
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    Generic.add_provider(BaseProvider)



# Generated at 2022-06-23 21:25:04.168533
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    def my_provider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def my_method(self):
            return 'Success!'

    providers = Generic().add_providers(my_provider)
    assert hasattr(providers, 'my_provider')
    assert callable(getattr(providers, 'my_provider'))
    assert providers.my_provider().my_method() == 'Success!'

# Generated at 2022-06-23 21:25:14.455573
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()
    assert isinstance(result, list)
    assert result != []
    assert ('person' in result)
    assert ('address' in result)
    assert ('datetime' in result)
    assert ('business' in result)
    assert ('text' in result)
    assert ('food' in result)
    assert ('science' in result)
    assert ('transport' in result)
    assert ('code' in result)
    assert ('unit_system' in result)
    assert ('file' in result)
    assert ('numbers' in result)
    assert ('development' in result)
    assert ('hardware' in result)
    assert ('clothing' in result)
    assert ('internet' in result)
    assert ('path' in result)

# Generated at 2022-06-23 21:25:18.203993
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    locale = 'en'
    seed = None
    generic = Generic(locale, seed)
    assert generic.datetime
    assert generic.person


# Generated at 2022-06-23 21:25:28.398271
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import timeit

    generic = Generic('en')
    start = timeit.default_timer()
    assert generic.person.full_name() == 'George Maddox'
    assert generic.address.postal_code() == '63847'
    assert generic.datetime.date() == '1993-12-01'
    assert generic.business.company() == 'Albright-Lang'
    assert generic.text.sentence() == 'Dolores voluptatum eos atque magni.'
    assert generic.food.fruit() == 'avocado'
    assert generic.science.chemical_element() == 'Tungsten'
    assert generic.transport.aircraft() == '747'

# Generated at 2022-06-23 21:25:33.906140
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test case 1 : The attribute is exists
    generic = Generic()
    assert generic.person
    assert generic.address
    assert generic.datetime

    # Test case 2 : The attribute is not exist
    generic._person = None
    generic._address = None
    generic._datetime = None

    msg = 'object has no attribute \'_person\''
    with pytest.raises(AttributeError, message=msg):
        generic.person

    msg = 'object has no attribute \'_address\''
    with pytest.raises(AttributeError, message=msg):
        generic.address

    msg = 'object has no attribute \'_datetime\''
    with pytest.raises(AttributeError, message=msg):
        generic.datetime



# Generated at 2022-06-23 21:25:40.551324
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender

    class CustomPerson(Person):
        class Meta:
            name = 'custom_person'
            gender = Gender.FEMALE

    s = Generic('en')
    s.add_provider(CustomPerson)
    assert 'custom_person' in s.__dict__
    assert s.custom_person.gender == Gender.FEMALE

# Generated at 2022-06-23 21:25:47.519818
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.text import Text
    from mimesis.providers.person import Person

    class A(BaseProvider):
        def get_str(self):
            return 'test'

    class B(BaseProvider):
        def get_str(self):
            return 'text'

    test_obj = Generic()
    test_obj.add_provider(Cryptographic)
    test_obj.add_provider(Numbers)
    test_obj.add_provider(Text)
    test_obj.add_provider(Person)
    test_obj.add_provider(A)
    test_obj.add_provider(B)

    test_str = test_obj.cryptographic

# Generated at 2022-06-23 21:25:49.341456
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    result = Generic().__getattr__('person')
    assert result


# Generated at 2022-06-23 21:25:50.818291
# Unit test for constructor of class Generic
def test_Generic():    
    generic = Generic()
    assert isinstance(generic.person.full_name(), str)

# Generated at 2022-06-23 21:25:59.646423
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print("test getattribute")
    gen = Generic()
    assert gen.person() == gen._person(gen.locale,gen.seed)
    assert gen.business() == gen._business(gen.locale, gen.seed)
    assert gen.datetime() == gen._datetime(gen.locale, gen.seed)
    assert gen.address() == gen._address(gen.locale, gen.seed)
    assert gen.food() == gen._food(gen.locale, gen.seed)
    assert gen.text() == gen._text(gen.locale, gen.seed)
    assert gen.science() == gen._science(gen.locale, gen.seed)



# Generated at 2022-06-23 21:26:10.660296
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic"""

    def test_positive():
        """Positive test cases."""
        gen = Generic()
        gen.add_provider(Person)
        assert gen.person

        gen.add_provider(Address)
        assert gen.address

    def test_negative():
        """Negative test cases."""
        gen = Generic()
        # arg must be a class
        try:
            gen.add_provider(Person())
        except TypeError:
            assert True
        except:
            assert False

        # arg must be a subclass of BaseProvider
        try:
            gen.add_provider(Exception)
        except TypeError:
            assert True
        except:
            assert False

    test_positive()
    test_negative()



# Generated at 2022-06-23 21:26:16.094083
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    provider = Generic(seed=42)

    # pylint: disable=pointless-statement
    provider.person
    provider.address
    provider.datetime
    provider.business
    provider.text
    provider.food
    provider.science

# Generated at 2022-06-23 21:26:18.889890
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic is not None
    assert isinstance(generic, Generic)
    assert isinstance(generic, BaseDataProvider)



# Generated at 2022-06-23 21:26:21.259007
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(locale='en')
    result = g.person.full_name()
    assert isinstance(result, str)



# Generated at 2022-06-23 21:26:22.163932
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:26:27.726005
# Unit test for constructor of class Generic
def test_Generic():
    test = Generic(locale='ru')
    assert test.person.full_name() == 'Елена Исакова'
    assert test.code.uuid() == '6476f95e-69a6-3140-b0c6-2af1f8d1b9da'
    assert test.unit_system.volume() == 0.075
    assert test.numbers.integer_number() == 18

# Generated at 2022-06-23 21:26:31.675377
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test __dir__ of Generic class."""
    GENERIC = Generic('en')
    assert len(dir(GENERIC)) > 0
    assert len(GENERIC.__dir__()) > 0

# Generated at 2022-06-23 21:26:40.785387
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=123)
    assert g.transport.car() == 'Peugeot 307'
    assert g.transport.vehicle() == 'Porsche 900z'
    assert g.code.iban() == 'BY42ALFA301111222333000005130'
    assert g.numbers.integer_number() == -781901312
    assert g.internet.user_agent() == 'ConveraCrawler/0.1 ( http://www.authoritativeweb.com/crawl)'
    assert g.hardware.cpu().startswith('AMD')
    assert g.address.region(country=None).startswith('Q')
    assert g.business.company().startswith('Q')
    assert g.person.occupation().startswith('Q')

# Generated at 2022-06-23 21:26:42.265120
# Unit test for constructor of class Generic
def test_Generic():
    print(Generic().address.address())

# Generated at 2022-06-23 21:26:51.410763
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    gener = Generic('ru')
    gener.add_provider(Person)
    gener.add_provider(Address)
    gener.add_provider(Datetime)
    gener.add_provider(Business)
    gener.add_provider(Text)
    gener.add_provider(Food)
    gener.add_provider(Science)
    gener.add_provider(Transport)
    gener.add_provider(Code)
    gener.add_provider(UnitSystem)
    gener.add_provider(File)
    gener.add_provider(Numbers)
    gener.add_provider(Development)
    gener.add_provider(Hardware)
    gener.add_provider(Clothing)
    gener.add_provider(Internet)


# Generated at 2022-06-23 21:26:53.046939
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    values = Generic().__dir__()
    assert isinstance(values, list)

# Generated at 2022-06-23 21:26:56.027201
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.database import Database
    g = Generic(seed=10)
    providers = [Database]
    g.add_providers(*providers)
    assert isinstance(g.database, Database)

# Generated at 2022-06-23 21:27:01.379223
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Text, Person)
    assert isinstance(g.text, Text)
    assert isinstance(g.person, Person)
    assert g.person._data is g.text._data

if __name__ == '__main__':
    test_Generic_add_providers()

# Generated at 2022-06-23 21:27:08.181982
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    '''
    if it's possible to add a custom provider to Generic() object,
    return True
    '''
    try:
        class CustomProvider(BaseProvider):
            def __init__(self, seed=None, **kwargs):
                super().__init__(seed, **kwargs)

            class Meta:
                name = 'custom_provider'

        custom_provider = CustomProvider(seed='test')
        g = Generic()
        g.add_provider(custom_provider)
        assert hasattr(g, 'custom_provider')
        del g
    except:
        return False
    else:
        return True


# Generated at 2022-06-23 21:27:15.338574
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    # Base test
    provider = Generic()
    provider.add_provider(TestProvider1)
    assert hasattr(provider, 'test_provider1')
    assert isinstance(getattr(provider, 'test_provider1'), TestProvider1)

    # Exception test
    try:
        provider.add_provider(list)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 21:27:24.328517
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test the correctness of method add_providers of class Generic."""
    generic = Generic()

    class CustomProvider(BaseProvider):
        """Test class for Generic.add_providers."""

        class Meta:
            """Providers metadata."""

            name = 'custom_provider'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize parameters.

            :param args: Positional arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self.PROVIDERS = ['take']

        def take(self) -> str:
            """Return 'take'.

            :return: String "take".
            """
            return 'take'


# Generated at 2022-06-23 21:27:25.996006
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    if Generic().__getattr__('person'):
        pass

# Generated at 2022-06-23 21:27:33.563083
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:27:34.690986
# Unit test for constructor of class Generic
def test_Generic():
    _ = Generic(seed=12345678)
    assert _.unit_system.variant() == 'metric'

# Generated at 2022-06-23 21:27:37.942206
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic"""
    g = Generic()
    assert isinstance(g.person, Person), 'Unit test for method __getattr__ of class Generic is failed.'


# Generated at 2022-06-23 21:27:42.117291
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    test_ = Generic()
    # test no exception
    test_.add_providers(Person, Address)
    # test AttributeError
    class s:
        pass
    m = Generic()
    m.add_providers(s())
    # test TypeError
    m.add_providers(Address)


# Generated at 2022-06-23 21:27:47.111433
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Sample(BaseProvider):
        def __init__(
                self,
                seed: int = None,
                locales: str = None,
                **kwargs: Any) -> None:
            super().__init__(seed, locales)

        class Meta:
            """Class for metadata."""

            name = 'sample'

        def foo(self) -> str:
            return 'foo'

    g = Generic()
    g.add_provider(Sample)
    assert g.sample.foo() == 'foo'


# Generated at 2022-06-23 21:27:59.503661
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.business, Business)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)

# Generated at 2022-06-23 21:28:01.449225
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.process import Process
    generic = Generic()
    generic.add_provider(Process)
    assert hasattr(generic, 'process')

# Generated at 2022-06-23 21:28:11.296853
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test Generic().add_providers() method."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Metadata for custom provider."""

            name = 'custom'

        def foo(self) -> str:
            """Return string."""
            return 'bar'

    g = Generic()
    g.add_providers(CustomProvider, Address)

    assert g.custom.foo() == 'bar'
    assert g.address.get_city_name()

# Generated at 2022-06-23 21:28:17.729837
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__(): # type: ignore
    g = Generic()

    assert isinstance(g.person, Person)
    assert isinstance(g.business, Business)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.address, Address)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.internet, Internet)
    assert isinstance(g.transport, Transport)



# Generated at 2022-06-23 21:28:19.996640
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert dir(Generic) == Generic().__dir__()

# Generated at 2022-06-23 21:28:22.541577
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    generic = Generic()

    assert isinstance(generic.__dir__(), list)

# Generated at 2022-06-23 21:28:29.237644
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    expected_result = ['clothing', 'science', 'datetime', 'person', 'file', 'numbers', 'path', 'address', 'transport', 'cryptographic', 'business', 'development', 'hardware', 'internet', 'choice', 'text', 'payment', 'code', 'food', 'unit_system', 'structure']
    expected_result.sort()
    gen = Generic()
    dir_res = dir(gen)
    dir_res.sort()
    assert expected_result == dir_res


# Generated at 2022-06-23 21:28:37.141647
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    print(generic.person.full_name())
    print(generic.address.country())
    print(generic.datetime.date())
    print(generic.business.email())
    print(generic.text.word())
    print(generic.food.dish())
    print(generic.science.gene())
    print(generic.transport.vehicle())
    print(generic.code.iban())
    print(generic.unit_system.weight())
    print(generic.file.mimetype())
    print(generic.numbers.gauss(0,0.2))
    print(generic.development.dummy())
    print(generic.hardware.cpu())
    print(generic.clothing.color())
    print(generic.internet.ipv4())

# Generated at 2022-06-23 21:28:39.018461
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic('en')
    assert isinstance(gen, Generic)
    assert len(gen.__dir__()) == 27

# Generated at 2022-06-23 21:28:43.435602
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.person import Person as Person_provider
    from mimesis.providers.address import Address as Address_provider
    g = Generic()
    g.add_providers(Person_provider, Address_provider)

    assert isinstance(g.person, Person_provider)
    assert isinstance(g.address, Address_provider)



# Generated at 2022-06-23 21:28:47.766502
# Unit test for constructor of class Generic
def test_Generic():
    # Arrange
    # Act
    generic = Generic()

    # Assert
    assert isinstance(generic, BaseDataProvider)
    assert isinstance(generic, Generic)
    assert generic.locale == 'en'
    assert generic.seed is None


# Generated at 2022-06-23 21:28:51.905841
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers()
    assert len(generic.__dir__()) == len(__all__)
    generic.add_providers(Person)
    assert len(generic.__dir__()) == len(__all__) + 1



# Generated at 2022-06-23 21:28:52.525344
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass

# Generated at 2022-06-23 21:28:54.942439
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business

    g = Generic('en')
    g.add_providers(Address, Business)

    assert hasattr(g, 'address')
    assert hasattr(g, 'business')

# Generated at 2022-06-23 21:28:58.134761
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Occupation
    from mimesis.providers.address import StreetAddress
    generic = Generic('en')
    generic.add_provider(Occupation)
    generic.add_provider(StreetAddress)
    assert generic.occupation is not None



# Generated at 2022-06-23 21:29:03.833388
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    providers = [Address, Business, Datetime, Food, Numbers, Payment,
                 Person, Science, Structure, Text, Transport, UnitSystem,
                 Choice]
    g.add_providers(*providers)

    assert g.address is not None
    assert g.business is not None
    assert g.datetime is not None
    assert g.food is not None
    assert g.numbers is not None
    assert g.payment is not None
    assert g.person is not None
    assert g.science is not None
    assert g.structure is not None
    assert g.text is not None
    assert g.transport is not None
    assert g.units is not None
    assert g.choice is not None


# Generated at 2022-06-23 21:29:06.887880
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    person = g.person
    address = g.address
    gen = Generic('en')
    person = gen.person
    address = gen.address



# Generated at 2022-06-23 21:29:07.597957
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:29:09.306770
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=42)

    for attr, value in generic.__dict__.items():
        print(attr, "=", value)

# Generated at 2022-06-23 21:29:13.602229
# Unit test for constructor of class Generic
def test_Generic():
    gen=Generic()
    gen.add_provider(Transport)
    print(gen.transport)
    assert gen.transport == 'Genaric'
if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-23 21:29:22.828750
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en')
    assert hasattr(g, 'address')
    assert hasattr(g, 'business')
    assert hasattr(g, 'choice')
    assert hasattr(g, 'clothing')
    assert hasattr(g, 'code')
    assert hasattr(g, 'cryptographic')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'development')
    assert hasattr(g, 'food')
    assert hasattr(g, 'file')
    assert hasattr(g, 'hardware')
    assert hasattr(g, 'internet')
    assert hasattr(g, 'numbers')
    assert hasattr(g, 'person')
    assert hasattr(g, 'payment')
    assert hasattr(g, 'path')
    assert hasattr(g, 'science')

# Generated at 2022-06-23 21:29:32.595636
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import random
    import mimesis.providers.generic as generic
    data = dict()
    data.update({'choices': '(1, 2, 3, 4, 5, 6)',
                 'providers': '()',
                 'provider_name': 'Generic',
                 'value': '4'})
    choice_provider = generic.Choice(seed = data['seed'])
    choice_provider.choices = eval(data['choices'])
    choice_provider.choice = eval(data['value'])
    providers = [(choice_provider, choice_provider.choice)]
    provider_name = data['provider_name']
    generic_provider = generic.Generic(locale='ru-RU', seed = data['seed'])

# Generated at 2022-06-23 21:29:41.585935
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    prov = Generic(seed=0)
    assert prov.__dir__() == ['address',
                              'business',
                              'choice',
                              'code',
                              'clothing',
                              'cryptographic',
                              'datetime',
                              'development',
                              'file',
                              'food',
                              'hardware',
                              'internet',
                              'numbers',
                              'person',
                              'path',
                              'payment',
                              'science',
                              'structure',
                              'text',
                              'transport',
                              'unit_system']

# Generated at 2022-06-23 21:29:43.815071
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__."""
    l = Generic().__dir__()
    assert isinstance(l, list)
    assert 'code' in l
    assert 'unit_system' in l
    assert 'file' in l
    assert 'numbers' in l
    assert 'development' in l
    assert 'hardware' in l
    assert 'clothing' in l
    assert 'internet' in l