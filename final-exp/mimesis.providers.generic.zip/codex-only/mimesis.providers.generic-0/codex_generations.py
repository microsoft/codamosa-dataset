

# Generated at 2022-06-23 21:19:43.356695
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic()

    assert data.address
    assert data.datetime
    assert data.business
    assert data.text
    assert data.person
    assert data.science
    assert data.transport
    assert data.code
    assert data.unit_system
    assert data.file
    assert data.numbers
    assert data.development
    assert data.hardware
    assert data.clothing
    assert data.internet
    assert data.path
    assert data.payment
    assert data.cryptographic
    assert data.structure
    assert data.choice



# Generated at 2022-06-23 21:19:51.576776
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(locale='en')
    g.person
    g.address
    g.datetime
    g.business
    g.text
    g.food
    g.science
    g.transport
    g.code
    g.unit_system
    g.file
    g.numbers
    g.development
    g.hardware
    g.clothing
    g.internet
    g.path
    g.payment
    g.cryptographic
    g.structure
    g.choice


# Generated at 2022-06-23 21:19:55.852493
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic('en')
    assert hasattr(g, 'core'
                   ) is False
    from tests.providers import Core
    g.add_provider(Core)
    assert hasattr(g, 'core') is True
    assert isinstance(g.core, Core) is True


# Generated at 2022-06-23 21:20:05.422696
# Unit test for constructor of class Generic

# Generated at 2022-06-23 21:20:16.742222
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test method __dir__"""
    test_instance = Generic()
    test_instance.add_provider(Generic) # it must be not type Generic
    attributes = test_instance.__dir__()

# Generated at 2022-06-23 21:20:28.514175
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    print(type(generic.person))


if __name__ == '__main__':
    generic = Generic()
    # print(generic.text.paragraph(quantity=2))
    # print(generic.person.occupation())
    # print(generic.text.phonetic_alphabet())
    # print(generic.business.business_idea())
    # print(generic.address.address())
    # print(generic.text.title())
    # print(generic.text.sentences(quantity=2))
    # print(generic.text.words(quantity=2))
    # print(generic.food.dish_name())
    # print(generic.food.ingredient())
    # print(generic.food.item())
    # print(generic.food.cuisine())


# Generated at 2022-06-23 21:20:30.338508
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().__getattr__('address') == Generic()._address(None, None)


# Generated at 2022-06-23 21:20:33.081754
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.food
    g.science
    g.payment
    g.business
    g.text
    g.numbers
    g.development
    g.hardware
    g.clothing
    g.internet
    g.path
    g.cryptographic
    g.structure


# Generated at 2022-06-23 21:20:43.785059
# Unit test for constructor of class Generic
def test_Generic():
    obj=Generic()
    assert obj._person == Person
    assert obj._address == Address
    assert obj._datetime == Datetime
    assert obj._business == Business
    assert obj._text == Text
    assert obj._food == Food
    assert obj._science == Science
    assert obj.transport == Transport
    assert obj.code == Code
    assert obj.unit_system == UnitSystem
    assert obj.file == File
    assert obj.numbers == Numbers
    assert obj.development == Development
    assert obj.hardware == Hardware
    assert obj.clothing == Clothing
    assert obj.internet == Internet
    assert obj.path == Path
    assert obj.payment == Payment
    assert obj.cryptographic == Cryptographic
    assert obj.structure == Structure
    assert obj.choice == Choice



# Generated at 2022-06-23 21:20:52.341165
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic()
    x.person.full_name()       # __getattr__ is run
    x.address.street_name()    # __getattr__ is run
    x.datetime.timestamp()     # __getattr__ is run
    x.business.company()       # __getattr__ is run
    x.text.text()              # __getattr__ is run
    x.science.technology()     # __getattr__ is run
    x.food.meat()              # __getattr__ is run
    x.transport.vehicle()      # __getattr__ is run
    x.code.barcode()           # __getattr__ is run
    x.unit_system.unit()       # __getattr__ is run
    x.file.extension()         # __getattr__ is run
    x.n

# Generated at 2022-06-23 21:20:59.594932
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test function get_person of class Generic
    seed = 1234567890
    gen = Generic(seed=seed)
    assert gen.person.name(gender=None) == 'Jhosette'
    assert gen.person.name(gender='female') == 'Caroline'
    assert gen.person.full_name() == 'Damian Toni Simons'
    assert gen.person.full_name(gender=None) == 'Bryana Hane Livingston'
    assert gen.person.full_name(gender='female') == 'Caroline Ines Rodriguez'
    assert gen.person.occupation() == 'Administrator'
    assert gen.person.email() == 'melendez.melissa@yahoo.com'
    assert gen.person.telephone() == '039-937-3790'
    assert gen.person.username()

# Generated at 2022-06-23 21:21:08.259890
# Unit test for constructor of class Generic
def test_Generic():
    temp1 = Generic(seed=12345)
    temp2 = Generic(seed=12345)
    assert temp1.code == temp2.code
    assert temp1.unit_system == temp2.unit_system
    assert temp1.file == temp2.file
    assert temp1.numbers == temp2.numbers
    assert temp1.development == temp2.development
    assert temp1.hardware == temp2.hardware
    assert temp1.clothing == temp2.clothing
    assert temp1.internet == temp2.internet
    assert temp1.path == temp2.path
    assert temp1.payment == temp2.payment
    assert temp1.cryptographic == temp2.cryptographic
    assert temp1.structure == temp2.structure
    assert temp1.transport == temp2.transport
    assert temp

# Generated at 2022-06-23 21:21:16.490743
# Unit test for constructor of class Generic
def test_Generic():
    x = Generic()
    # testing if correct values are returned for different functions
    assert x.person.full_name()!=x.person.full_name()
    assert x.person.full_name()!=x.person.full_name()
    assert x.business.company()!=x.business.company()
    assert x.numbers.integer(min_value=1, max_value=100)!=x.numbers.integer(min_value=1, max_value=100)

# Generated at 2022-06-23 21:21:22.914511
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__."""
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice

# Generated at 2022-06-23 21:21:28.332613
# Unit test for constructor of class Generic
def test_Generic():
    data = Generic()
    assert isinstance(data.address, Address)
    assert isinstance(data.person, Person)
    assert isinstance(data.datetime, Datetime)
    assert isinstance(data.business, Business)
    assert isinstance(data.text, Text)
    assert isinstance(data.food, Food)
    assert isinstance(data.science, Science)
    assert isinstance(data.transport, Transport)
    assert isinstance(data.code, Code)
    assert isinstance(data.unit_system, UnitSystem)
    assert isinstance(data.file, File)
    assert isinstance(data.numbers, Numbers)
    assert isinstance(data.development, Development)
    assert isinstance(data.hardware, Hardware)
    assert isinstance(data.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-23 21:21:31.465105
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    for attr in generic.__dir__():
        assert attr in generic.__dict__, "The directory does not contain {} attr".format(attr)

# Generated at 2022-06-23 21:21:39.646754
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(
        Code,
        Internet,
        Path,
        Payment,
        Cryptographic,
        Structure,
        UnitSystem,
        Choice,
        File,
        Numbers,
        Development,
        Hardware,
        Clothing,
    )
    assert g.transport is not None
    assert g.unit_system is not None
    assert g.code is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None
    assert g.structure is not None

# Generated at 2022-06-23 21:21:48.690936
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic(seed=True)
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice



# Generated at 2022-06-23 21:21:56.375060
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.food import Food
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    cls = Generic(seed=12345)
    cls.add_providers(Food, Person, Text)

    assert len(cls.__dict__.keys()) == 11
    assert cls.text.__class__ is Text
    assert cls.person.__class__ is Person
    assert cls.food.__class__ is Food


# Generated at 2022-06-23 21:22:00.066404
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def test(self):
            return 'test'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.customprovider.test() == 'test', 'Providers are not equals'


# Generated at 2022-06-23 21:22:06.505509
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic"""

    from mimesis.providers.automotive import Automotive
    from mimesis.providers.bicycle import Bicycle

    g = Generic()
    g.add_providers(Automotive, Bicycle)

    assert hasattr(g, 'automotive') == True
    assert hasattr(g, 'bicycle') == True


# Generated at 2022-06-23 21:22:13.890525
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g, Generic)
    assert 'food' in dir(g)
    assert 'numbers' in dir(g)
    assert '_numbers' not in dir(g)
    assert '_food' not in dir(g)

    g._food = None
    g._numbers = None
    assert 'food' not in dir(g)
    assert 'numbers' not in dir(g)



# Generated at 2022-06-23 21:22:22.065684
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert hasattr(g, 'generic')
    assert hasattr(g, 'address')
    assert hasattr(g, 'person')
    assert hasattr(g, 'datetime')
    assert hasattr(g, 'business')
    assert hasattr(g, 'text')
    assert hasattr(g, 'food')
    assert hasattr(g, 'science')
    assert hasattr(g, 'transport')
    assert hasattr(g, 'code')
    assert hasattr(g, 'unit_system')
    assert hasattr(g, 'file')
    assert hasattr(g, 'numbers')
    assert hasattr(g, 'development')
    assert hasattr(g, 'hardware')
    assert hasattr(g, 'clothing')
    assert hasattr(g, 'internet')

# Generated at 2022-06-23 21:22:23.049993
# Unit test for constructor of class Generic
def test_Generic():
    Generic()

# Generated at 2022-06-23 21:22:24.737552
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    assert isinstance(provider,Generic)


# Generated at 2022-06-23 21:22:29.199090
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider method."""
    import mimesis.providers.automotive
    from mimesis.providers.automotive import Automotive, Car

    def _check_provider(a: BaseProvider) -> None:
        _ = Automotive.Meta
        _ = Car.Meta
        assert hasattr(a, Automotive.Meta.name)
        assert hasattr(a, Car.Meta.name)
        assert isinstance(a.automotive, Automotive)
        assert isinstance(a.car, Car)

    _check_provider(Generic())



# Generated at 2022-06-23 21:22:31.235705
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic('en')
    assert obj._person is not None
    assert obj._address is not None
    assert obj._datetime is not None
    assert obj._business is not None
    assert obj._text is not None
    assert obj._food is not None
    assert obj._science is not None



# Generated at 2022-06-23 21:22:38.023533
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class StaticProvider(BaseProvider):
        class Meta:
            name = 'static'

        def hello_world(self) -> str:
            return 'Hello world!'

    generic = Generic()
    generic.add_provider(StaticProvider)
    assert hasattr(generic, 'hello_world')



# Generated at 2022-06-23 21:22:44.882592
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers in class Generic."""
    # Case 1
    generic = Generic()
    generic.add_providers(Code, UnitSystem)
    assert 'code' in generic
    assert 'unit_system' in generic

    # Case 2
    generic = Generic()
    cls = type('TestProvider', (BaseProvider, ), {})
    generic.add_providers(Code, UnitSystem, cls)
    assert 'code' in generic
    assert 'unit_system' in generic
    assert 'test_provider' in generic

    # Case 3
    generic = Generic()
    generic.add_providers()
    assert 'code' not in generic
    assert 'unit_system' not in generic


# Generated at 2022-06-23 21:22:51.035704
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test Generic.__getattr__ method.

    Test a bunch of all providers.
    """
    locale = 'en'
    seed = 123
    g = Generic(locale=locale, seed=seed)

    assert g.person.full_name() == 'William Mitchell'
    assert g.datetime.date(start=2000) == '2000-01-10'
    assert g.science.element() == 'iodine'
    assert g.code.uuid4() == '6c5d6ab2-9fd5-4922-8c06-3047f5c637cb'
    assert g.file.file_extension() == 'gz'
    assert g.numbers.between(start=0, stop=10,
                             formatter='{0:,}') == '4,351'
    assert g

# Generated at 2022-06-23 21:22:56.188919
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    g = Generic()
    result = str(g.__dir__())

    assert '_person' in result
    assert '_address' in result
    assert '_datetime' in result
    assert '_business' in result
    assert '_text' in result
    assert '_food' in result
    assert '_science' in result


# Generated at 2022-06-23 21:22:57.837569
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__().__len__() == 0


# Generated at 2022-06-23 21:23:08.938177
# Unit test for constructor of class Generic
def test_Generic():
    # Create a Generic() object
    generic = Generic('en')
    # Get another Generic() object
    another_generic = Generic()
    # Create a Person() object
    person = generic.person
    # Get a Person() object
    another_person = generic.person
    # Create an Address() object
    address = generic.address
    # Get a Business() object
    business = generic.business
    # Get a cryptographical object
    cryptographic = generic.cryptographic
    # Get a structure object
    structure = generic.structure
    # Get a internet object
    internet = generic.internet
    # Get a path object
    path = generic.path
    # Get a payment object
    payment = generic.payment
    # Get a choice object
    choice = generic.choice
    # The length of the list of attributes should be equal 8

# Generated at 2022-06-23 21:23:10.595614
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic.provider == 'generic'
    assert generic.person.name()

# Generated at 2022-06-23 21:23:18.451594
# Unit test for constructor of class Generic
def test_Generic():
    # Test without any params
    a = Generic()
    assert (a.__class__.__name__ ) == "Generic"
    assert (a.address.__class__.__name__) == "Address"
    assert (a.file.__class__.__name__) == "File"
    assert (a.internet.__class__.__name__) == "Internet"
    assert (a.food.__class__.__name__) == "Food"

    # Test with seed
    b = Generic(seed=338)
    assert (b.__class__.__name__) == "Generic"
    assert (b.address.__class__.__name__) == "Address"
    assert (b.file.__class__.__name__) == "File"

# Generated at 2022-06-23 21:23:22.936329
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic()._structure is Generic().structure
    assert Generic()._person is Generic().person
    assert Generic()._address is Generic().address
    assert Generic()._datetime is Generic().datetime
    assert Generic()._text is Generic().text
    assert Generic()._food is Generic().food
    assert Generic()._science is Generic().science
    assert Generic()._business is Generic().business

# Generated at 2022-06-23 21:23:27.122432
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # 1. Create a Generic object
    generic = Generic('en')

    # 2. Add providers
    class Provider1(BaseProvider):
        def method_1(self):
            return 1
    class Provider2(BaseProvider):
        def method_2(self):
            return 2

    generic.add_providers(Provider1, Provider2)

    # 3. Check
    assert generic.provider1.method_1() == 1
    assert generic.provider2.method_2() == 2

# Generated at 2022-06-23 21:23:29.832742
# Unit test for constructor of class Generic
def test_Generic():
    print(Generic().__dict__)
    # Generic().add_provider(Numbers())
    # Generic().add_providers(Numbers())


# Generated at 2022-06-23 21:23:33.726148
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

    g = Generic()
    g.add_providers(CustomProvider)
    assert hasattr(g, 'custom_provider')



# Generated at 2022-06-23 21:23:39.299773
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic(seed=42)
    assert g.seed == 42
    assert g.code.seed == 42
    assert g.datetime.seed == 42
    assert g.file.seed == 42
    assert g.hardware.seed == 42
    assert g.internet.seed == 42
    assert g.numbers.seed == 42
    assert g.path.seed == 42
    assert g.transport.seed == 42
    assert g.unit_system.seed == 42

# Generated at 2022-06-23 21:23:47.564328
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class CustomPerson(Person):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def title(self, gender: Gender = None) -> str:
            return "Dr"

    class CustomCode(Code):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def isbn(self) -> str:
            return 'isbn'

    generic = Generic()
    generic.add_providers(CustomPerson, CustomCode)
    assert generic.person.title() == "Dr"
    assert generic.code.isbn() == 'isbn'


# Generated at 2022-06-23 21:23:57.871250
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.payment import Payment
    from mimesis.providers.file import File
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.development import Development
    g = Generic('en')
    g.add_provider(Person)
    g.add_provider(Science)
    g.add_provider(Payment)
    g.add_provider(File)
    g.add_provider(Hardware)
    g.add_provider(Development)
    assert g.person.full_name() == 'Kaitlyn Brown'
    assert g.science.scientific_name() == 'Ceratopsidae'
    assert g.payment.credit_

# Generated at 2022-06-23 21:24:02.422025
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    result = generic.__dir__()
    assert isinstance(result, list)
    assert 'address' in result
    assert 'business' in result
    assert 'person' in result
    assert 'code' in result
    assert 'text' in result
    assert 'food' in result
    assert 'unit_system' in result
    assert 'choice' in result

# Generated at 2022-06-23 21:24:08.054764
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(g.food.fruits())
    print(g.food.beverages())
    print(g.person.full_name())
    print(g.person.occupation())
    print(g.text.text())
    print(g.address.city())
    print(g.address.street_name())
    print(g.address.building_number())
    print(g.address.zip_code())
    print(g.business.company())
    print(g.business.brand())
    print(g.business.buzzword())
    print(g.business.bs())
    print(g.business.suffix())
    print(g.business.dun_number())
    print(g.business.email())
    print(g.business.job_title())

# Generated at 2022-06-23 21:24:16.633545
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        """Class for unit testing of Generic's add_provider method."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            super().__init__(*args, **kwargs)
            self.num = 1

    generic = Generic()

    assert generic
    # Check if property of Test class is in object of Generic class
    assert Test.__name__.lower() not in generic.__dir__()

    # AttributeError
    try:
        generic.add_provider(Test())
    except AttributeError:
        assert True

    # TypeError
    try:
        generic.add_provider(123)
    except TypeError:
        assert True

    # Check if property of Test class is in object of Generic class
    generic.add_prov

# Generated at 2022-06-23 21:24:27.493466
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for Generic class."""
    # Test add_provider method
    # Create a custom provider
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'test_method'

    # Create instance of Generic class
    generic = Generic()
    # Add provider to Generic object
    generic.add_provider(TestProvider)
    assert generic.test_provider.test_method() == 'test_method'
    # Add a lot of custom providers
    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test_provider2'

        def test_method2(self):
            return 'test_method2'

    class TestProvider3(BaseProvider):
        class Meta:
            name = 'test_provider3'

# Generated at 2022-06-23 21:24:30.617144
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Address)
    assert 'address' in dir(generic)



# Generated at 2022-06-23 21:24:40.001995
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic(seed=0)
    assert gen.person.full_name() == 'Dr. Johnnie Kihn'
    assert gen.address.street_name() == 'Hickle Viaduct'
    assert gen.datetime.date() == '11-21-1980'
    assert gen.business.company() == 'Batz, Torphy and Ullrich'
    assert gen.person.full_name() == 'Piper Schmitt'
    assert gen.food.dish() == 'Cheese Cake'
    assert gen.science.element() == 'Bromine'
    assert gen.transport.vehicle() == 'motorcycle'
    assert gen.code.barcode() == '2/5 Interleaved'
    assert gen.unit_system.temperature() == 'fahrenheit'

# Generated at 2022-06-23 21:24:51.963315
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """TODO: Docstring for test_Generic_add_provider.
    :returns: TODO

    """
    import random
    class Generic(BaseDataProvider):
        """Class which contain all providers at one."""
        class Meta:
            """Class for metadata."""
            name = 'generic'

    class CustomProvider(BaseProvider):
        """Docstring for CustomProvider. """
        class Meta:
            """Class for metadata."""
            name = 'custom'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes lazily.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self._special = 'custom test'


# Generated at 2022-06-23 21:25:01.775214
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic('uk')
    assert generic.person.last_name()
    assert generic.address.zip_code()
    assert generic.datetime.date(minimum=1895)
    assert generic.business.code(code_type='random_lowercase')
    assert generic.text.sentence(length=3)
    assert generic.food.vegetable()
    assert generic.science.element_symbol()
    assert generic.transport.vehicle()
    assert generic.code.isbn13()
    assert generic.unit_system.temperature_fahrenheit(t=10)
    assert generic.file.mime_type()
    assert generic.numbers.real(end=10)
    assert generic.development.password()
    assert generic.hardware.cpu_socket()
    assert generic.clothing.sleeve()

# Generated at 2022-06-23 21:25:08.677038
# Unit test for method __getattr__ of class Generic

# Generated at 2022-06-23 21:25:10.219537
# Unit test for constructor of class Generic
def test_Generic():
    test_generic = Generic()
    assert hasattr(test_generic, "person")

# Generated at 2022-06-23 21:25:15.157157
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [Person, Address, Datetime]
    generic = Generic()
    generic.add_providers(*providers)

    assert 'person' in generic.__dir__()
    assert 'datetime' in generic.__dir__()
    assert 'address' in generic.__dir__()

    try:
        generic.add_providers('not a class', 'not a class again')
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-23 21:25:17.649054
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def foo(self):
            return 'foo'
    
    generic = Generic('ru')
    generic.add_provider(Provider)
    assert generic.provider.foo() == 'foo'

# Generated at 2022-06-23 21:25:24.213991
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():

    g = Generic()
    expected = ['person', 'address', 'datetime', 'business',
                'text', 'food', 'science', 'transport',
                'code', 'unit_system', 'file', 'numbers',
                'development', 'hardware', 'clothing',
                'internet', 'path', 'payment', 'cryptographic',
                'structure', 'choice']
    result = dir(g)
    assert result == expected


# Generated at 2022-06-23 21:25:25.558302
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()

    assert isinstance(gen.person, Person)


# Generated at 2022-06-23 21:25:32.171212
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import inspect
    import sys
    import unittest

    class GenericTestCase(unittest.TestCase):
        def setUp(self):
            self.generic = Generic()

        def test_dir(self):
            attrs = ['person',
                     'address',
                     'datetime',
                     'business',
                     'text',
                     'food',
                     'science',
                     'transport',
                     'code',
                     'unit_system',
                     'file',
                     'numbers',
                     'development',
                     'hardware',
                     'clothing',
                     'internet',
                     'path',
                     'payment',
                     'cryptographic',
                     'structure',
                     'choice']
            self.assertCountEqual(dir(self.generic), attrs)

    suite = unittest.TestLoader().load

# Generated at 2022-06-23 21:25:33.939479
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    gen = Generic()
    assert isinstance(gen, Generic)

# Generated at 2022-06-23 21:25:38.433212
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    a = Generic()
    assert hasattr(a, 'generic')
    a = Generic()
    a.add_provider(Payment)
    assert hasattr(a, 'payment')


# Generated at 2022-06-23 21:25:46.568506
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert gen.person  # type: ignore
    assert gen.address  # type: ignore
    assert gen.datetime  # type: ignore
    assert gen.business  # type: ignore
    assert gen.text  # type: ignore
    assert gen.food  # type: ignore
    assert gen.science  # type: ignore
    assert gen.transport  # type: ignore
    assert gen.code  # type: ignore
    assert gen.unit_system  # type: ignore
    assert gen.file  # type: ignore
    assert gen.numbers  # type: ignore
    assert gen.development  # type: ignore
    assert gen.hardware  # type: ignore
    assert gen.clothing  # type: ignore
    assert gen.internet  # type: ignore
    assert gen.path  # type: ignore

# Generated at 2022-06-23 21:25:55.779079
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    custom_provider1 = type('CustomProvider1', (BaseProvider,),
                            {'Meta': type('Meta', (), {'name': 'x'})})
    custom_provider2 = type('CustomProvider1', (BaseProvider,),
                            {'Meta': type('Meta', (), {'name': 'y'})})
    mimesis = Generic()
    mimesis.add_providers(custom_provider1, custom_provider2)
    assert hasattr(mimesis, 'x')
    assert hasattr(mimesis, 'y')

# Generated at 2022-06-23 21:25:58.758949
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add provider method."""
    generic = Generic()
    custom_class = Generic
    name = 'generic'
    generic.add_provider(custom_class)
    assert hasattr(generic, name)


# Generated at 2022-06-23 21:26:10.109014
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis import Generic
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    all_providers = Generic()

    class CustomAddress(Address):
        class Meta:
            name = 'custom_address'

    class CustomPerson(Person):
        class Meta:
            name = 'custom_person'

    all_providers.add_providers(CustomAddress, CustomPerson)

    assert hasattr(all_providers, 'custom_address')
    assert hasattr(all_providers.custom_address, 'address')
    assert hasattr(all_providers, 'custom_person')
    assert hasattr(all_providers.custom_person, 'full_name')
# End of unit test

# Generated at 2022-06-23 21:26:13.146227
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic.

    :return: None
    """
    generic = Generic(seed=123)
    print(generic.__dir__())

# Generated at 2022-06-23 21:26:14.080965
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass



# Generated at 2022-06-23 21:26:16.622143
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic('en')
    assert isinstance(g.__dir__(), list)


# Generated at 2022-06-23 21:26:21.769932
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None



# Generated at 2022-06-23 21:26:27.408679
# Unit test for constructor of class Generic
def test_Generic():
    a1 = Generic()
    print(a1.address.city())
    print(a1.address.country())
    print(a1.business.company())
    print(a1.datetime.datetime())
    print(a1.file.extension())
    print(a1.food.fruit())
    print(a1.food.vegetable())
    print(a1.hardware.cores())
    print(a1.hardware.processor())
    print(a1.internet.email())
    print(a1.numbers.float_number())
    print(a1.person.username())
    print(a1.science.subject())
    print(a1.transport.vehicle_type())


if __name__ == "__main__":
    test_Generic()

# Generated at 2022-06-23 21:26:34.411205
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic

    class Provider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata"""
            name = 'provider'

        def data(self):
            """Analog of method data."""
            return 'Custom provider'

    generic = Generic()
    generic.add_provider(Provider)
    assert hasattr(generic, 'provider')
    assert generic.provider.data() == 'Custom provider'

# Generated at 2022-06-23 21:26:41.899032
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    def test_getattr__(provider: BaseProvider):
        # test for getting an attribute of provider
        print('---', provider)
        print(provider.__class__.__name__)
        print(provider.randomize())
        print(provider.random_choice())

    gen = Generic('es')
    ## test custom unit system
    gen.add_provider(UnitSystem)

    ## test getting a provider
    test_getattr__(gen.person)

    test_getattr__(gen.unit_system)

    ## test getting a provider with a custom locale
    test_getattr__(gen.unit_system(locale='en'))


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-23 21:26:51.209247
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('ru')
    assert 'ru' == g.locale
    assert g.code.language_code
    assert g.provider.language_code
    assert g.integer_number(max_value=10)
    assert g.person().name()
    assert g.internet.domain_name()
    assert g.internet.ipv4()
    assert g.internet.ipv6()
    assert g.internet.mac_address()
    assert g.internet.url()
    assert g.internet.user_agent()
    assert g.internet.username()
    assert g.file.file_name()
    assert g.file.file_extension()
    assert g.file.mime_type()
    assert g.datetime.date()
    assert g.datetime.time()

# Generated at 2022-06-23 21:26:55.453557
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    class MyProvider(BaseProvider):
        def foo(self):
            return 'foo'

    g = Generic()
    g.add_provider(MyProvider)
    assert g.my_provider.foo() == 'foo'



# Generated at 2022-06-23 21:27:00.657147
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert generic.datetime is not None
    assert generic.business is not None
    assert generic.food is not None
    assert generic.science is not None
    assert generic.transport is not None
    assert generic.numbers is not None


# Generated at 2022-06-23 21:27:03.847595
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.datetime is not None
    assert g.datetime.date is not None
    assert g.datetime.timestamp() is not None
    assert g.datetime.datetime_object() is not None


# Generated at 2022-06-23 21:27:09.779932
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    cls = Generic()
    class MyProvider(BaseProvider):
        class Meta:
            name = "my_provider"
        def provide_my_provider(self):
            return "provider 1, provider 2"
    class SecondProvider(BaseProvider):
        class Meta:
            name = "second_provider"
        def provide_second_provider(self):
            return "provider 2"
    cls.add_providers(MyProvider, SecondProvider)
    assert cls.my_provider.provide_my_provider() == "provider 1, provider 2"
    assert cls.second_provider.provide_second_provider() == "provider 2"

# Generated at 2022-06-23 21:27:13.266464
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

    gen = Generic('en')
    gen.add_providers(Development, Hardware)
    assert gen.development.hardware is gen.hardware.hardware
    
test_Generic_add_providers()


# Generated at 2022-06-23 21:27:15.730781
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    gen.add_providers(Internet)
    assert hasattr(gen.internet, '__class__')

# Generated at 2022-06-23 21:27:21.259623
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert type(obj.person) == Person
    assert type(obj.address) == Address
    assert type(obj.datetime) == Datetime
    assert type(obj.business) == Business
    assert type(obj.text) == Text
    assert type(obj.food) == Food
    assert type(obj.science) == Science
    assert type(obj.transport) == Transport
    assert type(obj.code) == Code
    assert type(obj.unit_system) == UnitSystem
    assert type(obj.file) == File
    assert type(obj.numbers) == Numbers
    assert type(obj.development) == Development
    assert type(obj.hardware) == Hardware
    assert type(obj.clothing) == Clothing
    assert type(obj.internet) == Internet
    assert type(obj.path)

# Generated at 2022-06-23 21:27:31.034708
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en', 'test')

    assert g._person.__class__.__name__ == 'Person'
    assert g._person.locale == 'en'
    assert g.person.locale == 'en'
    assert g.person.full_name() == 'Mr. William James'
    assert isinstance(g.person.full_name(), str)

    assert g._address.__class__.__name__ == 'Address'
    assert g._address.locale == 'en'
    assert g.address.locale == 'en'
    assert g.address.city() == 'Michigan'
    assert isinstance(g.address.city(), str)

    assert g._datetime.__class__.__name__ == 'Datetime'
    assert g._datetime.locale == 'en'
    assert g.dat

# Generated at 2022-06-23 21:27:38.903217
# Unit test for constructor of class Generic
def test_Generic():
	generic = Generic()
	generic.person
	generic.address
	generic.datetime
	generic.business
	generic.text
	generic.food
	generic.science
	generic.transport
	generic.code
	generic.unit_system
	generic.file
	generic.numbers
	generic.development
	generic.hardware
	generic.clothing
	generic.internet
	generic.path
	generic.payment
	generic.cryptographic
	generic.structure
	generic.choice

# Generated at 2022-06-23 21:27:43.348101
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

        def one(self):
            return 'one'

    generic = Generic()
    assert not hasattr(generic, 'custom')
    generic.add_provider(Custom)
    assert hasattr(generic, 'custom')
    assert hasattr(generic.custom, 'one')


# Generated at 2022-06-23 21:27:46.864160
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test adding a custom provider to Generic() object."""
    from mimesis.providers.generic import Generic
    print(Generic().__dict__)
    Generic().add_provider(fake_provider)
    print(Generic().__dict__)
    assert 'fake_provider' in Generic().__dict__



# Generated at 2022-06-23 21:27:54.585498
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    g.person
    g.address
    g.datetime
    g.business
    g.food
    assert g.__dict__.get('person')
    assert g.__dict__.get('address')
    assert g.__dict__.get('datetime')
    assert g.__dict__.get('business')
    assert g.__dict__.get('food')



# Generated at 2022-06-23 21:27:56.633653
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic('en')
    assert hasattr(provider, 'choice')
    assert not hasattr(provider, 'test')


# Generated at 2022-06-23 21:28:02.335090
# Unit test for constructor of class Generic
def test_Generic():
    g=Generic()
    print(type(g._address))
    print(g._address)
    print(g._food)
    print(g.file)
    print(g.numbers)
    print(g.development)
    print(g.unit_system)
    print(g.hardware)
    print(g.internet)
    print(g.code)
    print(g.path)
    print(g.clothing)
    print(g.payment)
    print(g.cryptographic)
    print(g.structure)
    print(g.choice)


# Generated at 2022-06-23 21:28:14.298190
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')
    assert 'en' in dir(generic)
    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'datetime' in dir(generic)
    assert 'business' in dir(generic)
    assert 'text' in dir(generic)
    assert 'food' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)
    assert 'clothing' in dir(generic)

# Generated at 2022-06-23 21:28:18.539219
# Unit test for constructor of class Generic
def test_Generic():
    defaults = Generic()
    assert all(hasattr(defaults, attr) for attr in ["person", "address", "datetime", "business", "text", "food", "science", "transport", "code", "unit_system", "file", "numbers", "development", "hardware", "clothing", "internet", "path", "payment", "cryptographic", "structure", "choice"])


# Generated at 2022-06-23 21:28:20.385726
# Unit test for constructor of class Generic
def test_Generic():
    # test_Generic.py
    print("Testing Generic class constructor")

    generic = Generic()

    assert generic.provider == "generic"
    assert generic.__class__.__name__ == "Generic"
    print("Test passed")


# Generated at 2022-06-23 21:28:27.512547
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()
    assert provider.name == 'generic'
    assert provider.seed is None
    assert provider.locale == 'en-US'
    assert provider.person is not None
    assert provider.address is not None
    assert provider.food is not None
    assert provider.business is not None
    assert provider.transport is not None
    assert provider.science is not None
    assert provider.text is not None
    assert provider.datetime is not None
    assert provider.choice is not None



# Generated at 2022-06-23 21:28:35.942236
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.food import Food
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person

# Generated at 2022-06-23 21:28:41.127185
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    providers = dir(g)
    assert len(providers) == 34
    assert 'person' in providers
    assert 'address' in providers
    assert 'datetime' in providers
    assert 'business' in providers
    assert 'text' in providers
    assert 'food' in providers
    assert 'science' in providers
    assert 'transport' in providers
    assert 'code' in providers
    assert 'unit_system' in providers
    assert 'file' in providers
    assert 'numbers' in providers
    assert 'development' in providers
    assert 'hardware' in providers
    assert 'clothing' in providers
    assert 'internet' in providers
    assert 'path' in providers
    assert 'payment' in providers
    assert 'cryptographic' in providers
    assert 'structure' in providers

# Generated at 2022-06-23 21:28:48.853074
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    assert not hasattr(generic, 'test_provider')
    assert not hasattr(generic, 'test_provider2')

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test_provider2'

    generic.add_providers(TestProvider, TestProvider2)
    assert hasattr(generic, 'test_provider')
    assert hasattr(generic, 'test_provider2')

# Generated at 2022-06-23 21:28:50.918422
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test = Generic('en')
    test.__getattr__('person')
    test.__getattr__('address')
    test.__getattr__('datetime')
    test.__getattr__('business')
    test.__getattr__('text')
    test.__getattr__('food')
    test.__getattr__('science')


# Generated at 2022-06-23 21:28:54.768332
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Case simple
    class Test(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed)
            self.words = ['a', 'b', 'c']

        def test(self):
            return self.words[0]

    generic = Generic()
    generic.add_providers(Test)
    assert generic.test() == 'a'

# Generated at 2022-06-23 21:29:01.755429
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    c = Generic()
    assert c.person.__class__.__name__ == 'Person'
    assert c.address.__class__.__name__ == 'Address'
    assert c.datetime.__class__.__name__ == 'Datetime'
    assert c.business.__class__.__name__ == 'Business'
    assert c.text.__class__.__name__ == 'Text'
    assert c.food.__class__.__name__ == 'Food'
    assert c.science.__class__.__name__ == 'Science'


# Generated at 2022-06-23 21:29:07.119823
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    test = Generic('en')
    test.add_provider(Person)
    assert hasattr(test, 'person')
    test.add_provider(Address)
    assert hasattr(test, 'address')
    test.add_provider(Datetime)
    assert hasattr(test, 'datetime')
    test.add_provider(Business)
    assert hasattr(test, 'business')
    test.add_provider(Text)
    assert hasattr(test, 'text')
    test.add_provider(Food)
    assert hasattr(test, 'food')
    test.add_provider(Science)
    assert hasattr(test, 'science')
    test.add_provider(Transport)
    assert hasattr(test, 'transport')
    test.add_provider(Code)


# Generated at 2022-06-23 21:29:08.072261
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic(None)
    result = obj.__dir__()
    print(result)

# Generated at 2022-06-23 21:29:09.543991
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person.full_name().startswith('Mrs.')

# Generated at 2022-06-23 21:29:14.678643
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    class Provider(BaseProvider):
        class Meta:
            name = 'test'

    providers = [Person, Address, Datetime, Business, Text, Food, Science,
                 Transport, Code, UnitSystem, File, Numbers, Development,
                 Hardware, Clothing, Internet, Path, Payment, Cryptographic,
                 Structure, Choice]

    g = Generic()
    result = g.__dir__()
    providers.extend(['person', 'address', 'datetime', 'business', 'text',
                      'food', 'science', 'transport', 'code', 'unit_system',
                      'file', 'numbers', 'development', 'hardware',
                      'clothing', 'internet', 'path', 'payment',
                      'cryptographic', 'structure', 'choice'])
    assert (type(result) == list)

# Generated at 2022-06-23 21:29:23.005981
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic()._person == Person
    assert Generic()._address == Address
    assert Generic()._datetime == Datetime
    assert Generic()._business == Business
    assert Generic()._text == Text
    assert Generic()._science == Science
    assert Generic().transport == Transport
    assert Generic().code == Code
    assert Generic().unit_system == UnitSystem
    assert Generic().file == File
    assert Generic().numbers == Numbers
    assert Generic().development == Development
    assert Generic().hardware == Hardware
    assert Generic().clothing == Clothing
    assert Generic().internet == Internet
    assert Generic().path == Path
    assert Generic().payment == Payment
    assert Generic().cryptographic == Cryptographic
    assert Generic().structure == Structure
    assert Generic().choice == Choice

# Generated at 2022-06-23 21:29:27.991095
# Unit test for constructor of class Generic
def test_Generic():
    """Test for class constructor."""
    _gen = Generic('en')
    assert isinstance(_gen, Generic)
    assert isinstance(_gen.datetime, Datetime)
    assert isinstance(_gen.numbers, Numbers)
    assert isinstance(_gen.science, Science)
    assert isinstance(_gen.cryptographic, Cryptographic)

# Generated at 2022-06-23 21:29:39.702411
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    generic = Generic(seed=42)
    assert (generic.person.full_name() == 'Ryan Blanch')
    assert (generic.datetime.datetime() == '1985/08/20 09:49:00')
    assert (generic.address.region() == 'Приморский край')
    assert (generic.business.vat() == '7727896188')
    assert (generic.text.quote() == 'When you are courting a nice girl '
                                    'an hour seems like a second. '
                                    'When you sit on a red-hot cinder '
                                    'a second seems like an hour. '
                                    'That\'s relativity.')

# Generated at 2022-06-23 21:29:41.544912
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic()._person == Generic().person