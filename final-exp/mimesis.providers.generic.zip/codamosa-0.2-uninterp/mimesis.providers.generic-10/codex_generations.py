

# Generated at 2022-06-17 22:29:31.604053
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def foo(self):
            return 'bar'
    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:29:41.744416
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Петрова'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-02-28'
    assert g.business.company() == 'ООО "СтройСпецТехника"'
    assert g.text.sentence() == 'Он пришел в кабинет и сел за стол.'
    assert g.food.fruit() == 'груша'


# Generated at 2022-06-17 22:29:51.361041
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Сергеевич Сергеев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-01-01'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.text() == 'Всем привет!'
    assert g.food.fruit() == 'Апельсин'
    assert g.science.element() == 'Серебро'

# Generated at 2022-06-17 22:29:59.137059
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:30:10.415195
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:30:14.615304
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            return 'foo'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'foo'

# Generated at 2022-06-17 22:30:22.181746
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Кондратьев'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '2018-12-30'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.title() == 'Совершенно секретно'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:30:32.275714
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Пушкин'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-05-13'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Серебро'

# Generated at 2022-06-17 22:30:44.161155
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:54.228202
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-11-06'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Все это было в прошлом.'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'бериллий'