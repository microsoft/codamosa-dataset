

# Generated at 2022-06-17 22:29:39.491263
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:29:50.099278
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:29:52.802839
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:30:06.325124
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:30:13.979334
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'ООО "Стройкомплект"'
    assert g.text.sentence() == 'Не принимайте во внимание.'
    assert g.food.fruit() == 'груша'
    assert g.science.chemical_element() == 'бериллий'

# Generated at 2022-06-17 22:30:22.112525
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Евгений Савин'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2019-07-10'
    assert g.business.company() == 'ООО "Агротехника"'
    assert g.text.word() == 'пример'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'
    assert g.transport.vehicle() == 'ВАЗ-2106'

# Generated at 2022-06-17 22:30:32.220804
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-05-22'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Все просто и понятно.'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'бериллий'
    assert g.transport

# Generated at 2022-06-17 22:30:37.131245
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:30:42.834724
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:30:46.015251
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def test(self):
            return 'test'

    g = Generic()
    g.add_provider(TestProvider)
    assert g.test.test() == 'test'