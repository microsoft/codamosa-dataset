

# Generated at 2022-06-17 22:29:34.891071
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Кузнецов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'ООО "Альфа"'
    assert g.text.sentence() == 'Не принимайте все так близко к сердцу.'
    assert g.food.fruit() == 'банан'
    assert g.science.element

# Generated at 2022-06-17 22:29:46.611247
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person as CustomPerson
    from mimesis.providers.address import Address as CustomAddress
    from mimesis.providers.datetime import Datetime as CustomDatetime
    from mimesis.providers.business import Business as CustomBusiness
    from mimesis.providers.text import Text as CustomText
    from mimesis.providers.food import Food as CustomFood
    from mimesis.providers.science import Science as CustomScience
    from mimesis.providers.transport import Transport as CustomTransport
    from mimesis.providers.code import Code as CustomCode
    from mimesis.providers.units import UnitSystem as CustomUnitSystem
    from mimesis.providers.file import File as CustomFile
    from mimesis.providers.numbers import Numbers as CustomNumbers

# Generated at 2022-06-17 22:29:55.392580
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic('en')
    assert g.person.full_name() == 'Mr. Johnathan S. Smith'
    assert g.address.address() == '967-9077 Euismod St.'
    assert g.datetime.date() == '19-01-19'
    assert g.business.company() == 'Smith-Sanchez'

# Generated at 2022-06-17 22:30:07.918789
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Samantha'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'Github'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.dish() == 'Pizza'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.unit() == 'Kilogram'

# Generated at 2022-06-17 22:30:18.322954
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Мария Мариянова'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '2020-05-20'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'бериллий'
    assert g.transport.vehicle()

# Generated at 2022-06-17 22:30:29.702498
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.person.full_name(gender='female') == 'Анна Сидорова'
    assert g.person.full_name(gender='male') == 'Александр Петров'
    assert g.person.full_name(gender='female', middle_name=True) == 'Анна Ивановна Сидорова'

# Generated at 2022-06-17 22:30:34.290034
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice


# Generated at 2022-06-17 22:30:45.099958
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Mrs. Annette M. Hahn'
    assert g.address.city() == 'Hillsborough'
    assert g.datetime.date() == '1962-04-18'
    assert g.business.company() == 'Hahn-Hermann'
    assert g.text.title() == 'Amet et quisquam.'
    assert g.food.fruit() == 'peach'
    assert g.science.element() == 'Neon'
    assert g.transport.vehicle() == 'Chevrolet'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'kilogram'
    assert g.file.extension() == 'jpg'
   

# Generated at 2022-06-17 22:30:54.858401
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:00.146315
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'txt'

# Generated at 2022-06-17 22:31:28.835757
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:34.744515
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Казакова'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '2018-08-30'
    assert g.business.company() == 'ООО "Континент"'
    assert g.text.title() == 'Приветствие'
    assert g.food.fruit() == 'груша'
    assert g.science.chemical_element() == 'бериллий'
    assert g.transport.veh

# Generated at 2022-06-17 22:31:39.266396
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:31:48.781894
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:57.615748
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:32:06.145806
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.unit_system import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing

# Generated at 2022-06-17 22:32:10.895367
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:32:14.660160
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:32:23.284177
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Иван Иванов'
    assert g.address.city() == 'Санкт-Петербург'
    assert g.datetime.date() == '02.11.2016'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.text() == 'Привет, мир!'
    assert g.food.fruit() == 'банан'
    assert g.science.chemical_element() == 'Серебро'
    assert g.transport.vehicle() == 'Волга'

# Generated at 2022-06-17 22:32:32.541435
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Марина Борисовна Кузнецова'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '25.05.2018'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.word() == 'причина'
    assert g.food.fruit() == 'персик'
    assert g.science.chemical_element() == 'Серебро'

# Generated at 2022-06-17 22:33:00.767617
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(MyProvider)
    assert generic.my_provider.foo() == 'bar'


# Generated at 2022-06-17 22:33:11.410203
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:33:17.941117
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Кузнецова'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-09-17'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.title() == 'Пример заголовка'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Калий'
    assert g

# Generated at 2022-06-17 22:33:27.758773
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.date import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:33:36.364680
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware