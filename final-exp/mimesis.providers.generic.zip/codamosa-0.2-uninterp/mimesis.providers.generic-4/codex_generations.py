

# Generated at 2022-06-17 22:29:41.566499
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Return foo."""
            return 'foo'

    class CustomProvider2(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom2'

        def bar(self) -> str:
            """Return bar."""
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    g.add_prov

# Generated at 2022-06-17 22:29:51.222383
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Кузнецов'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '2019-04-17'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Последний человек на Земле.'

# Generated at 2022-06-17 22:30:05.463049
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:13.477120
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:22.096111
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '19.01.2019'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Серебро'
    assert g.transport.vehicle() == 'Автомобиль'

# Generated at 2022-06-17 22:30:32.221556
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:30:44.161150
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:54.228881
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:59.774992
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Mrs. Lillian Johnson'
    assert g.address.city() == 'Sylvan Shores'
    assert g.datetime.date() == '1962-08-04'
    assert g.business.company() == 'Johnson-Baker'
    assert g.text.sentence() == 'Qui sint quisquam.'
    assert g.food.dish() == 'Cake'
    assert g.science.element() == 'Boron'
    assert g.transport.vehicle() == 'Ford'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'Kilogram'


# Generated at 2022-06-17 22:31:10.664635
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Иванов'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '03.03.2018'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'В прошлом году было много приключений.'
    assert g.food.dish() == 'Пицца'