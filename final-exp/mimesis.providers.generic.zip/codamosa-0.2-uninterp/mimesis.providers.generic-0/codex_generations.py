

# Generated at 2022-06-17 22:29:35.771714
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Mrs. Maryann Stokes'
    assert g.person.full_name(gender='male') == 'Mr. Johnathan Hodge'
    assert g.person.full_name(gender='female') == 'Mrs. Maryann Stokes'
    assert g.person.full_name(gender='male', middle_name=True) == 'Mr. Johnathan A. Hodge'
    assert g.person.full_name(gender='female', middle_name=True) == 'Mrs. Maryann A. Stokes'
    assert g.person.full_name(gender='male', middle_name=True, initials=True) == 'Mr. J. A. Hodge'

# Generated at 2022-06-17 22:29:42.856185
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    class CustomProvider(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed=seed)
        class Meta:
            name = 'custom'
        def foo(self):
            return 'bar'
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'


# Generated at 2022-06-17 22:29:52.103813
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:05.956017
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.country() == 'Россия'
    assert g.datetime.date() == '2019-03-04'
    assert g.business.company() == 'ООО "Промстрой"'
    assert g.text.sentence() == 'Все произошло в один прекрасный момент.'
    assert g.food.fruit() == 'банан'

# Generated at 2022-06-17 22:30:13.777506
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:22.093461
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes lazily.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)

        def foo(self) -> str:
            """Return foo."""
            return 'foo'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'foo'


# Generated at 2022-06-17 22:30:32.482066
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-04-11'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Приветствую вас на нашем сайте.'
    assert g.food.fruit() == 'груша'

# Generated at 2022-06-17 22:30:37.406993
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:30:47.181015
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Иванов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-12-04'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Калий'
    assert g.transport.vehicle() == 'Лада Гранта'
    assert g

# Generated at 2022-06-17 22:30:56.112405
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development