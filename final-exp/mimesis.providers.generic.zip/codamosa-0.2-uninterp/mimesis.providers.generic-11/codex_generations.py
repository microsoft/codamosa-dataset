

# Generated at 2022-06-17 22:29:35.782653
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Mrs. Tanya R. Smith'
    assert g.address.city() == 'Newport'
    assert g.datetime.date() == '2018-07-10'
    assert g.business.company() == 'Klein, Schmitt and Schmitt'
    assert g.text.sentence() == 'Qui et quia.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Boron'
    assert g.transport.vehicle() == 'Chevrolet'
    assert g.code.isbn() == '978-1-56619-909-4'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'mp3'
   

# Generated at 2022-06-17 22:29:41.973458
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Doe'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'Apple'
    assert g.text.word() == 'lorem'
    assert g.food.vegetable() == 'carrot'
    assert g.science.element() == 'hydrogen'
    assert g.transport.vehicle() == 'car'
    assert g.code.isbn() == '978-0-306-40615-7'
    assert g.unit_system.mass() == 'kilogram'
    assert g.file.extension() == 'txt'
    assert g.numbers.between(1, 10) == 1

# Generated at 2022-06-17 22:29:47.192398
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'

# Generated at 2022-06-17 22:29:53.915042
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Казаков'
    assert g.address.city() == 'Казань'
    assert g.datetime.date() == '2018-12-03'
    assert g.business.company() == 'ООО "Деловой мир"'
    assert g.text.title() == 'Пример заголовка'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'
    assert g.transport.vehicle() == 'ВАЗ-2106'

# Generated at 2022-06-17 22:30:04.482927
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'Google'
    assert g.text.word() == 'lorem'
    assert g.food.fruit() == 'apple'
    assert g.science.element() == 'carbon'
    assert g.transport.vehicle() == 'car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'kilogram'
    assert g.file.extension() == 'txt'
    assert g.numbers.integer() == '1'

# Generated at 2022-06-17 22:30:11.421359
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Семенов'
    assert g.address.country() == 'Россия'
    assert g.datetime.date() == '2019-06-06'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'В стране все было хорошо.'
    assert g.food.dish() == 'Салат из свеклы'
    assert g.science.element() == 'Серебро'


# Generated at 2022-06-17 22:30:21.072678
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:31.741386
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Кузнецов'
    assert g.person.full_name(gender='male') == 'Александр Кузнецов'
    assert g.person.full_name(gender='female') == 'Анна Кузнецова'
    assert g.person.full_name(gender='female', middle_name=True) == 'Анна Александровна Кузнецова'

# Generated at 2022-06-17 22:30:43.530973
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Калинин'
    assert g.address.city() == 'Санкт-Петербург'
    assert g.datetime.date() == '10.11.1961'
    assert g.business.company() == 'ООО "Прометей"'
    assert g.text.sentence() == 'Совершенно верно.'
    assert g.food.dish() == 'Картофельное пюре'

# Generated at 2022-06-17 22:30:54.160516
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)

# Generated at 2022-06-17 22:31:11.529130
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'test'

        def test(self):
            return 'test'

    gen = Generic()
    gen.add_provider(TestProvider)
    assert gen.test.test() == 'test'



# Generated at 2022-06-17 22:31:17.030688
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:27.165181
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:29.974030
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:31:40.434109
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person as CustomPerson
    from mimesis.providers.address import Address as CustomAddress
    from mimesis.providers.datetime import Datetime as CustomDatetime
    from mimesis.providers.business import Business as CustomBusiness
    from mimesis.providers.text import Text as CustomText
    from mimesis.providers.food import Food as CustomFood
    from mimesis.providers.science import Science as CustomScience
    from mimesis.providers.transport import Transport as CustomTransport
    from mimesis.providers.code import Code as CustomCode
    from mimesis.providers.units import UnitSystem as CustomUnitSystem
    from mimesis.providers.file import File as CustomFile
    from mimesis.providers.numbers import Numbers as CustomNumbers

# Generated at 2022-06-17 22:31:44.939207
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:31:48.961952
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:31:57.757941
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:06.189198
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:17.155703
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-06-14'
    assert g.business.company() == 'ООО "Альфа-Банк"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.chemical_element() == 'Калий'

# Generated at 2022-06-17 22:32:37.308104
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:42.363420
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:32:47.957801
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:32:52.129119
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:33:04.482345
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Сергей Константинов'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2019-08-06'
    assert g.business.company() == 'ООО "Стройкомплект"'
    assert g.text.word() == 'программирование'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:33:09.020670
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:33:13.468480
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def foo(self):
            return 'bar'
    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:33:18.948025
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Кузнецова'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2018-01-22'
    assert g.business.company() == 'ООО "Промстрой"'
    assert g.text.text() == 'Привет, мир!'
    assert g.food.fruit() == 'груша'
    assert g.science.chemical_element() == 'Серебро'

# Generated at 2022-06-17 22:33:28.513038
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:33:37.446389
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geography import Geography
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem

    g = Generic()
    g.add_provider(Geography)
    g.add_provider(Person)
    g.add_provider(Payment)
    g.add_provider(Science)
    g.add_provider(Text)
    g.add_provider(Transport)
    g.add_provider(UnitSystem)

    assert hasattr(g, 'geography')

# Generated at 2022-06-17 22:33:52.549921
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:34:03.383865
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:34:10.860047
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:34:16.435686
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Person)
    assert 'person' in generic.__dir__()
    assert isinstance(generic.person, Person)
    generic.add_provider(Address)
    assert 'address' in generic.__dir__()
    assert isinstance(generic.address, Address)
    generic.add_provider(Datetime)
    assert 'datetime' in generic.__dir__()
    assert isinstance(generic.datetime, Datetime)
    generic.add_provider(Business)
    assert 'business' in generic.__dir__()
    assert isinstance(generic.business, Business)
    generic.add_provider(Text)
    assert 'text' in generic.__dir__()

# Generated at 2022-06-17 22:34:25.760350
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:34:33.663876
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person')

    generic.add_provider(Address)
    assert hasattr(generic, 'address')

    generic.add_provider(Datetime)
    assert hasattr(generic, 'datetime')

    generic.add_provider(Business)
    assert hasattr(generic, 'business')

    generic.add_provider(Text)
    assert hasattr(generic, 'text')

    generic.add_provider(Food)
    assert hasattr(generic, 'food')

    generic.add_provider(Science)
    assert hasattr(generic, 'science')

    generic.add_provider(Transport)

# Generated at 2022-06-17 22:34:38.300451
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    assert isinstance(generic.person, Person)
    generic.add_provider(Address)
    assert hasattr(generic, 'address')
    assert isinstance(generic.address, Address)
    generic.add_provider(Datetime)
    assert hasattr(generic, 'datetime')
    assert isinstance(generic.datetime, Datetime)
    generic.add_provider(Business)
    assert hasattr(generic, 'business')
    assert isinstance(generic.business, Business)
    generic.add_provider(Text)
    assert hasattr(generic, 'text')
    assert isinstance(generic.text, Text)
    generic.add

# Generated at 2022-06-17 22:34:44.117025
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person.full_name() == 'Данила Калинин'
    assert generic.address.city() == 'Калининград'
    assert generic.datetime.date() == '2018-04-24'
    assert generic.business.company() == 'ООО "Агро-Сервис"'
    assert generic.text.sentence() == 'Привет, мир!'
    assert generic.food.fruit() == 'груша'
    assert generic.science.element() == 'бериллий'
    assert generic.transport.vehicle() == 'ВАЗ-2106'

# Generated at 2022-06-17 22:34:52.306813
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:35:04.267871
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:35:36.896018
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:35:43.749515
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:35:50.148125
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person.full_name() == 'Александр Петров'
    assert gen.address.city() == 'Калининград'
    assert gen.datetime.date() == '2018-12-30'
    assert gen.business.company() == 'ООО "Рога и копыта"'
    assert gen.text.title() == 'Привет мир'
    assert gen.food.fruit() == 'груша'
    assert gen.science.element() == 'бериллий'
    assert gen.transport.vehicle() == 'ВАЗ-2109'

# Generated at 2022-06-17 22:35:56.714588
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:36:05.480778
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:36:10.007358
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'



# Generated at 2022-06-17 22:36:18.200569
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:36:23.345320
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Сергеевна Попова'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-01-08'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Когда все просто, то все просто.'
    assert g.food.fruit() == 'груша'

# Generated at 2022-06-17 22:36:32.133659
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:36:36.990178
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def custom_method(self) -> str:
            """Custom method."""
            return 'custom'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom')
    assert isinstance(generic.custom, CustomProvider)
    assert generic.custom.custom_method() == 'custom'

    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    assert isinstance(generic.person, Person)
    assert generic.person

# Generated at 2022-06-17 22:37:26.208015
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:37:29.481095
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:37:34.397196
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person

    class CustomProvider(BaseProvider):
        """Custom provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        def foo(self):
            """Foo."""
            return 'bar'

    class CustomProvider2(BaseProvider):
        """Custom provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        def foo(self):
            """Foo."""
            return 'bar'

    g = Generic()
    g