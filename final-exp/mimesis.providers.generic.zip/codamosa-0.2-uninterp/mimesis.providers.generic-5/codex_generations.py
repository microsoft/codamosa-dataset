

# Generated at 2022-06-17 22:29:35.449222
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    gen = Generic()
    assert gen.person.full_name() == 'Александр Кузнецов'
    assert gen.address.city() == 'Калининград'
    assert gen.datetime.date() == '01.01.2000'
    assert gen.business.company() == 'ООО "Рога и копыта"'
    assert gen.text.word() == 'пример'
    assert gen.food.fruit() == 'груша'
    assert gen.science.element() == 'бериллий'

# Generated at 2022-06-17 22:29:47.021883
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Королев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-03-12'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Все просто и понятно.'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'бериллий'

# Generated at 2022-06-17 22:29:49.913184
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(Provider)
    assert generic.provider.foo() == 'bar'


# Generated at 2022-06-17 22:29:58.824969
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Иванов'
    assert g.address.country() == 'Россия'
    assert g.datetime.date(start=2000, end=2010) == '2005-11-30'
    assert g.business.company() == 'ООО "Стройкомплект"'
    assert g.text.text() == 'Стройкомплект приветствует вас!'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'гелий'
   

# Generated at 2022-06-17 22:30:02.761810
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:08.159350
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed=seed)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'



# Generated at 2022-06-17 22:30:18.606976
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Бурмистров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-07-04'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Все произошло в один прекрасный день.'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'галлий'


# Generated at 2022-06-17 22:30:29.820834
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Сергей Кондратьев'
    assert g.address.city() == 'Кострома'
    assert g.datetime.date() == '2018-07-04'
    assert g.business.company() == 'ООО "Металлотехника"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:30:40.035023
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:48.682169
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware