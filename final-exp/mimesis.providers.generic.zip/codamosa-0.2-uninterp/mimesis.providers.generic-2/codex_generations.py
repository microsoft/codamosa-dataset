

# Generated at 2022-06-17 22:29:36.828263
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Кузнецов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-01-01'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Все прекрасно.'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Серебро'
    assert g.transport.vehicle() == 'Самолет'

# Generated at 2022-06-17 22:29:47.905025
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2019-02-01'
    assert g.business.company() == 'Microsoft'
    assert g.text.title() == 'The Lord of the Rings'
    assert g.food.dish() == 'Pizza'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'BMW'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'kg'
    assert g.file.extension() == 'mp3'

# Generated at 2022-06-17 22:29:54.167917
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-10-12'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.vegetable() == 'баклажан'

# Generated at 2022-06-17 22:30:06.904260
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Кузнецов'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '2019-04-15'
    assert g.business.company() == 'ООО "Компания"'
    assert g.text.sentence() == 'Как приятно проводить время в компании друзей.'
    assert g.food.fruit() == 'груша'

# Generated at 2022-06-17 22:30:14.238799
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:22.131059
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:30.448191
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Андрей Сергеевич Семенов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-12-04'
    assert g.business.company() == 'ООО "Агрострой"'
    assert g.text.sentence() == 'Старый принц пришел в новый дом.'
    assert g.food.fruit() == 'груша'
   

# Generated at 2022-06-17 22:30:41.639331
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:30:50.211132
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:31:03.869210
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-5-94878-484-7'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'txt'

# Generated at 2022-06-17 22:31:27.563751
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:31:29.672361
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)

    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:31:40.410944
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet