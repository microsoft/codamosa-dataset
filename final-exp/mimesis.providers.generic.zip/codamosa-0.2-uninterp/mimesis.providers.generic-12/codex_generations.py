

# Generated at 2022-06-17 22:29:39.165919
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Баранов'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '2019-03-20'
    assert g.business.company() == 'ООО "Агросельхоз" им. И.И. Селезнева'
    assert g.text.title() == 'Пример заголовка'
    assert g.food.fruit() == 'груша'

# Generated at 2022-06-17 22:29:49.875532
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Королев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-06-16'
    assert g.business.company() == 'ООО "Стройматериалы"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Кремний'
    assert g.transport.vehicle

# Generated at 2022-06-17 22:29:58.770551
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None
    assert g.structure is not None

# Generated at 2022-06-17 22:30:10.262317
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-17 22:30:20.263124
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-08-25'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:30:31.224208
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:42.924787
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Кондратьева'
    assert g.address.city() == 'Киров'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'ООО "Агросервис"'
    assert g.text.sentence() == 'Привет, как дела?'
    assert g.food.fruit() == 'банан'
    assert g.science.chemical_element() == 'бериллий'

# Generated at 2022-06-17 22:30:52.439323
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:58.467679
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'



# Generated at 2022-06-17 22:31:05.315119
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice
