

# Generated at 2022-06-17 22:29:31.731100
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert g.transport is not None
    assert g.code is not None
    assert g.unit_system is not None
    assert g.file is not None
    assert g.numbers is not None
    assert g.development is not None
    assert g.hardware is not None
    assert g.clothing is not None
    assert g.internet is not None
    assert g.path is not None
    assert g.payment is not None
    assert g.cryptographic is not None


# Generated at 2022-06-17 22:29:41.916064
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-17 22:29:51.480497
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name()
    assert g.address.city()
    assert g.datetime.date()
    assert g.business.company()
    assert g.text.word()
    assert g.food.fruit()
    assert g.science.element()
    assert g.transport.vehicle()
    assert g.code.isbn()
    assert g.unit_system.weight()
    assert g.file.extension()
    assert g.numbers.integer()
    assert g.development.language()
    assert g.hardware.cpu()
    assert g.clothing.clothing()
    assert g.internet.domain()
    assert g.path.path()
    assert g.payment.card_number()
   

# Generated at 2022-06-17 22:30:05.549226
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Петрова'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'ООО "Ромашка"'
    assert g.text.title() == 'Просто заголовок'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:30:13.527099
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:30:22.093189
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:29.660556
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    class CustomProvider(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed=seed)
        def __str__(self):
            return 'Custom provider'
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.__str__() == 'Custom provider'


# Generated at 2022-06-17 22:30:35.288812
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.text import Text
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.unit_system import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:41.402465
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def method(self):
            return 'method'

    g = Generic()
    g.add_provider(CustomProvider)
    assert hasattr(g, 'custom_provider')
    assert g.custom_provider.method() == 'method'


# Generated at 2022-06-17 22:30:50.007391
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Мария Петрова'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '04.08.2018'
    assert g.business.company() == 'ООО "Агропром"'
    assert g.text.sentence() == 'Приветствую вас, дорогие друзья!'
    assert g.food.dish() == 'Каша из гречки'

# Generated at 2022-06-17 22:31:08.310337
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:31:12.963367
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    class Provider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'provider'

        def foo(self) -> str:
            """Return 'bar'."""
            return 'bar'

    generic = Generic()
    generic.add_provider(Provider)
    assert generic.provider.foo() == 'bar'

# Generated at 2022-06-17 22:31:24.743585
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Doe'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'txt'

# Generated at 2022-06-17 22:31:32.677360
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing

# Generated at 2022-06-17 22:31:40.765964
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:31:50.257207
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:31:58.358835
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed=seed)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:32:06.342599
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:12.529959
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Return 'foo'."""
            return 'foo'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'foo'


# Generated at 2022-06-17 22:32:22.062408
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Максимов'
    assert g.address.country() == 'Россия'
    assert g.datetime.date() == '2018-04-01'
    assert g.business.company() == 'ООО "Сибирский лес"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'Серебро'
    assert g.transport.vehicle

# Generated at 2022-06-17 22:32:53.297961
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.identity import Identity
    from mimesis.providers.person import Person
    from mimesis.providers.payment import Payment
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.code import Code
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:33:04.847805
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Иван Иванов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-07-24'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.chemical_element() == 'Калий'
    assert g.transport.vehicle() == 'Волга'

# Generated at 2022-06-17 22:33:10.150822
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:33:17.453905
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Иванов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-12-23'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Калий'
    assert g.transport.car() == 'Лада Гранта'
    assert g.code

# Generated at 2022-06-17 22:33:27.150717
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:33:35.703026
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'txt'

# Generated at 2022-06-17 22:33:43.850418
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person.full_name() == 'Александр Кондратьев'
    assert generic.address.city() == 'Санкт-Петербург'
    assert generic.datetime.date() == '19.01.2018'
    assert generic.business.company() == 'ООО "Альфа-Банк"'
    assert generic.text.sentence() == 'Как дела?'
    assert generic.food.vegetable() == 'баклажан'
    assert generic.science.element() == 'Галлий'

# Generated at 2022-06-17 22:33:49.128482
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def foo(self):
            return 'bar'
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'

# Generated at 2022-06-17 22:34:01.589399
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Казань'
    assert g.datetime.date() == '12.01.2019'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.text() == 'Текст на русском языке'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.chemical_element() == 'Калий'

# Generated at 2022-06-17 22:34:10.659462
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def __str__(self):
            return 'CustomProvider'

    class CustomProvider2(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def __str__(self):
            return 'CustomProvider2'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert str(generic.customprovider) == 'CustomProvider'
    generic.add_provider(CustomProvider2)


# Generated at 2022-06-17 22:35:03.099869
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def test(self):
            return 'test'

    g = Generic()
    g.add_provider(TestProvider)
    assert g.test.test() == 'test'
