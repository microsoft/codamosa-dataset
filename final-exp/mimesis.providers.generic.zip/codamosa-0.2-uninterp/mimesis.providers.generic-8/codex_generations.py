

# Generated at 2022-06-17 22:29:36.277683
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:29:40.195483
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'


# Generated at 2022-06-17 22:29:50.609083
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Кузнецов'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '19.03.2019'
    assert g.business.company() == 'ООО "Агрострой"'
    assert g.text.text() == 'Строка для тестирования'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.chemical_element() == 'Калий'

# Generated at 2022-06-17 22:29:56.734760
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'



# Generated at 2022-06-17 22:30:02.104588
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    assert isinstance(generic.person, Person)



# Generated at 2022-06-17 22:30:11.705786
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    generic = Generic()
    generic.add_provider(Person)
    assert generic.person is not None
    assert generic.person.full_name() is not None
    assert generic.person.full_name() == 'Андрей Карпов'
    assert generic.person.full_name(gender='male') is not None
    assert generic.person.full_name(gender='male') == 'Андрей Карпов'
    assert generic.person.full_name(gender='female') is not None
    assert generic.person.full_name(gender='female') == 'Анна Карпова'

# Generated at 2022-06-17 22:30:21.208131
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Ковалева'
    assert g.address.city() == 'Архангельск'
    assert g.datetime.date() == '31.10.2018'
    assert g.business.company() == 'ООО "СпецТехника"'
    assert g.text.word() == 'пример'
    assert g.food.fruit() == 'груша'
    assert g.science.chemical_element() == 'бериллий'

# Generated at 2022-06-17 22:30:28.088288
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:30:30.897720
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert g.person.__class__.__name__ == 'Person'


# Generated at 2022-06-17 22:30:34.986987
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(TestProvider)
    assert generic.test.foo() == 'bar'


# Generated at 2022-06-17 22:30:55.663294
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:57.756408
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self) -> str:
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'