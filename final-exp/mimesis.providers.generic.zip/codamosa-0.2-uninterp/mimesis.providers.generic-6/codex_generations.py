

# Generated at 2022-06-17 22:29:39.407026
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Mr. John Doe'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-11-22'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    assert g.food.fruit() == 'apple'
    assert g.science.element() == 'hydrogen'
    assert g.transport.vehicle() == 'car'
    assert g.code.isbn() == '978-0-306-40615-7'
    assert g.unit_system.weight() == 'kilogram'
    assert g.file.extension() == 'png'

# Generated at 2022-06-17 22:29:50.062443
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анна Баранова'
    assert g.address.city() == 'Санкт-Петербург'
    assert g.datetime.date() == '2018-10-11'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Совершенно верно.'
    assert g.food.fruit() == 'банан'
    assert g.science.chemical_element() == 'Алюминий'
    assert g.transport.vehicle

# Generated at 2022-06-17 22:29:58.989289
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:10.339625
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2018-12-23'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'бериллий'
    assert g.transport.vehicle() == 'КамАЗ'

# Generated at 2022-06-17 22:30:20.298557
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Сергеевич Сергеев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-07-10'
    assert g.business.company() == 'ООО "Абракадабра"'
    assert g.text.text() == 'Строка текста'
    assert g.food.fruit() == 'груша'
    assert g.science.chemical_element() == 'бор'

# Generated at 2022-06-17 22:30:31.215968
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-07-28'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Все мы знаем, что все мы знаем.'
    assert g.food.fruit() == 'Апельсин'
    assert g.science.chemical_element() == 'Серебро'

# Generated at 2022-06-17 22:30:42.923103
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:50.930453
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Бабаева'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '2018-11-05'
    assert g.business.company() == 'ООО "Промтехнологии"'
    assert g.text.sentence() == 'Приветствую вас, мистер Андрей Макаров.'
    assert g.food.fruit() == 'груша'

# Generated at 2022-06-17 22:31:03.975527
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Кузнецова'
    assert g.address.city() == 'Санкт-Петербург'
    assert g.datetime.date() == '19.11.2018'
    assert g.business.company() == 'ООО "Альфа-Банк"'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.fruit() == 'банан'
    assert g.science.element() == 'галлий'

# Generated at 2022-06-17 22:31:13.534627
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:31:41.904621
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person as CustomPerson

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        def foo(self):
            """Return foo."""
            return 'foo'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'foo'

    g.add_provider(CustomPerson)

# Generated at 2022-06-17 22:31:50.844966
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Smith'
    assert g.address.city() == 'New York'
    assert g.datetime.date() == '2018-12-31'
    assert g.business.company() == 'Google'
    assert g.text.word() == 'qui'
    assert g.food.fruit() == 'apple'
    assert g.science.element() == 'carbon'
    assert g.transport.vehicle() == 'car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'kilogram'
    assert g.file.extension() == 'jpg'
    assert g.numbers.float_number() == '0.8'
    assert g.development

# Generated at 2022-06-17 22:32:03.678275
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.unit_system import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing

# Generated at 2022-06-17 22:32:09.005735
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Иванов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-10-01'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.dish() == 'Пицца'
    assert g.science.chemical_element() == 'Серебро'
    assert g.transport.vehicle() == 'Волга'
    assert g

# Generated at 2022-06-17 22:32:19.651227
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.unit_system import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:22.059116
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'

# Generated at 2022-06-17 22:32:26.333024
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Александрович Петров'
    assert g.address.country() == 'Россия'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.text() == 'Строка с произвольным текстом'
    assert g.food.fruit() == 'Яблоко'

# Generated at 2022-06-17 22:32:31.232409
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'



# Generated at 2022-06-17 22:32:40.400965
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Сергеевич Кузнецов'
    assert g.address.country() == 'Россия'
    assert g.datetime.date() == '2019-04-15'
    assert g.business.company() == 'ООО "Стройтехника"'
    assert g.text.sentence() == 'Стройтехника обеспечивает производство.'
    assert g.food.fruit() == 'банан'
    assert g

# Generated at 2022-06-17 22:32:50.084596
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware