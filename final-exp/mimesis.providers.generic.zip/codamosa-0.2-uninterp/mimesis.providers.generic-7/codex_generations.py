

# Generated at 2022-06-17 22:29:38.287607
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Сидоров'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '01.01.1970'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Все происходит в правильное время.'

# Generated at 2022-06-17 22:29:43.463912
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'



# Generated at 2022-06-17 22:29:52.493101
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:06.203717
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Анастасия Карпова'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '31.12.2018'
    assert g.business.company() == 'ООО "КОМПАНИЯ"'
    assert g.text.title() == 'ПРИМЕР ЗАГОЛОВКА'
    assert g.food.fruit() == 'Яблоко'

# Generated at 2022-06-17 22:30:11.396021
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'bar'


# Generated at 2022-06-17 22:30:21.072488
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:31.740542
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person.full_name() == 'Александр Кузнецов'
    assert generic.address.city() == 'Москва'
    assert generic.datetime.date() == '11.07.2018'
    assert generic.business.company() == 'ООО "Рога и копыта"'
    assert generic.text.text() == 'Всем привет!'
    assert generic.food.vegetable() == 'баклажан'
    assert generic.science.chemical_element() == 'Серебро'

# Generated at 2022-06-17 22:30:43.530770
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        def foo(self):
            """Return foo."""
            return 'foo'

    g = Generic()
    g.add_provider(CustomProvider)
    assert isinstance(g.custom, CustomProvider)

# Generated at 2022-06-17 22:30:54.160480
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анна Сидорова'
    assert g.address.city() == 'Краснодар'
    assert g.datetime.date() == '2018-09-16'
    assert g.business.company() == 'ООО "СтройТехСервис"'
    assert g.text.title() == 'Приветствие'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'Калий'
    assert g.transport.vehicle() == 'Ваз-2106'

# Generated at 2022-06-17 22:31:03.744197
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice
