

# Generated at 2022-06-17 22:29:34.627724
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice


# Generated at 2022-06-17 22:29:46.525505
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Алексей Константинович Константинов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-11-17'
    assert g.business.company() == 'ООО "Агрострой"'
    assert g.text.title() == 'Пример заголовка'
    assert g.food.fruit() == 'Апельсин'
    assert g.science.chemical_element() == 'Калий'
   

# Generated at 2022-06-17 22:29:53.699745
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Иванов'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'ООО Рога и копыта'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Водород'

# Generated at 2022-06-17 22:30:06.645482
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Анастасия Кузнецова'
    assert g.address.address() == 'г. Москва, ул. Красная, д. 1, кв. 2'
    assert g.datetime.date(minimum=2000, maximum=2010) == '2008-04-01'
    assert g.business.company() == 'ООО "СтройСервис"'
    assert g.text.title() == 'Приветствие'
    assert g.food.fruit() == 'персик'

# Generated at 2022-06-17 22:30:13.003594
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice


# Generated at 2022-06-17 22:30:21.866265
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Васильев'
    assert g.address.city() == 'Калуга'
    assert g.datetime.date() == '06.09.1954'
    assert g.business.company() == 'ООО "Спецпроект"'
    assert g.text.sentence() == 'Страшное время наступило.'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'
    assert g.transport.vehicle

# Generated at 2022-06-17 22:30:32.077752
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Сергей Сергеевич Сергеев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-08-02'
    assert g.business.company() == 'ООО "Рога и копыта"'

# Generated at 2022-06-17 22:30:44.161149
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:48.182297
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'


# Generated at 2022-06-17 22:30:56.616822
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Александр Сергеевич Королев'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2019-03-19'
    assert g.business.company() == 'ООО "Синергия"'
    assert g.text.title() == 'Пример заголовка'
    assert g.food.fruit() == 'банан'