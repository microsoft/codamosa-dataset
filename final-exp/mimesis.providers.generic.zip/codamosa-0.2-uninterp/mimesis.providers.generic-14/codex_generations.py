

# Generated at 2022-06-17 22:29:31.257441
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person.full_name() == 'Василий Петров'
    assert g.address.city() == 'Калининград'
    assert g.datetime.date() == '2018-07-20'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.title() == 'Привет, мир!'
    assert g.food.fruit() == 'груша'
    assert g.science.element() == 'галлий'
    assert g.transport.veh

# Generated at 2022-06-17 22:29:41.568021
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:29:45.886251
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'bar'


# Generated at 2022-06-17 22:29:53.308534
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.person.full_name() == 'Александр Константинов'
    assert generic.address.city() == 'Москва'
    assert generic.datetime.date() == '2019-08-28'
    assert generic.business.company() == 'ООО "СпецСтрой"'
    assert generic.text.text() == 'Общество представляет собой общество в целом.'
    assert generic.food.fruit() == 'персик'

# Generated at 2022-06-17 22:30:04.088680
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet

# Generated at 2022-06-17 22:30:10.809232
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:30:20.666934
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science

    class CustomProvider(BaseProvider):
        """Custom provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self._data = {'foo': 'bar'}


# Generated at 2022-06-17 22:30:31.529154
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-17 22:30:37.472843
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
        def test_method(self):
            return 'test'
    generic = Generic()
    generic.add_provider(TestProvider)
    assert generic.test_provider.test_method() == 'test'

# Generated at 2022-06-17 22:30:47.216557
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Андрей Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '2018-09-23'
    assert g.business.company() == 'ООО "Рога и копыта"'
    assert g.text.sentence() == 'Привет, мир!'
    assert g.food.fruit() == 'Яблоко'
    assert g.science.element() == 'Серебро'
    assert g.transport.vehicle() == 'Самолет'

# Generated at 2022-06-17 22:31:10.403046
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'Александр Петров'
    assert g.address.city() == 'Москва'
    assert g.datetime.date() == '21.02.1962'
    assert g.business.company() == 'ООО "Рога и копыта"'

# Generated at 2022-06-17 22:31:13.655774
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'test'

    generic = Generic()
    generic.add_provider(TestProvider)
    assert generic.test_provider.test_method() == 'test'


# Generated at 2022-06-17 22:31:20.202075
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom_provider.foo() == 'bar'



# Generated at 2022-06-17 22:31:29.323375
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.text import Text

    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom.foo() == 'bar'
    assert g.custom.__class__.__name__ == 'CustomProvider'

    g.add_provider(Person)
    assert g.person.__class

# Generated at 2022-06-17 22:31:36.027321
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'test_method'

    g = Generic()
    g.add_provider(TestProvider)
    assert g.test_provider.test_method() == 'test_method'

# Generated at 2022-06-17 22:31:41.997872
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:31:46.176384
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def custom_method(self):
            return 'custom_method'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom_provider')
    assert generic.custom_provider.custom_method() == 'custom_method'


# Generated at 2022-06-17 22:31:54.795072
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:05.280886
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-17 22:32:10.299373
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:32:32.292408
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice
