

# Generated at 2022-06-17 22:29:52.331719
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-17 22:30:06.091337
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Doe'
    assert g.address.country() == 'United States'
    assert g.datetime.date() == '2019-01-01'
    assert g.business.company() == 'Google'
    assert g.text.word() == 'lorem'
    assert g.food.fruit() == 'apple'
    assert g.science.element() == 'hydrogen'
    assert g.transport.vehicle() == 'car'
    assert g.code.isbn() == '978-3-16-148410-0'
    assert g.unit_system.weight() == 'kg'
    assert g.file.extension() == 'jpg'
    assert g.numbers.between(1, 10) == 3
    assert g.development.language

# Generated at 2022-06-17 22:30:13.856413
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person.full_name() == 'John Doe'
    assert g.address.country() == 'United States'
    assert g.datetime.date() == '2019-11-08'
    assert g.business.company() == 'Google'
    assert g.text.sentence() == 'Lorem ipsum dolor sit amet.'
    assert g.food.fruit() == 'Apple'
    assert g.science.element() == 'Hydrogen'
    assert g.transport.vehicle() == 'Car'
    assert g.code.isbn() == '978-1-56619-909-4'
    assert g.unit_system.weight() == 'Kilogram'
    assert g.file.extension() == 'jpg'

# Generated at 2022-06-17 22:30:19.545783
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def method(self):
            return 'Hello, world!'

    g = Generic()
    g.add_provider(CustomProvider)
    assert g.custom_provider.method() == 'Hello, world!'
