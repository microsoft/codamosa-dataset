

# Generated at 2022-06-25 20:42:55.557577
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    str_0 = 'fPR-m\tG'
    str_1 = '\x14\x1e\x1a]X-R\x18i\x05\x14\x19\x12\x17\x07\x1f\x1a\x05\r\r'
    generic_0 = Generic()
    generic_0.add_provider('field_0')
    generic_0.add_provider(str_0)
    generic_0.add_provider(str_1)
    generic_0 = Generic()
    generic_0.add_provider('field_0')
    generic_0.add_provider(str_0)
    generic_0.add_provider(str_1)
    generic_0 = Generic()

# Generated at 2022-06-25 20:42:58.474800
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    str_0 = 'lh\t+|;%n\x0c'
    generic_0 = Generic()
    any_0 = generic_0.__getattr__(str_0)


# Generated at 2022-06-25 20:43:00.783383
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    str_0 = '|'
    any_0 = generic_0.__getattr__(str_0)


# Generated at 2022-06-25 20:43:03.863749
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    str_0 = 'v1tQ}Wq\x7fu$'
    any_0 = generic_0.__getattr__(str_0)


# Generated at 2022-06-25 20:43:07.718336
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = test_case_0()
    try:
        generic_0.add_provider(generic_provider_0)
    except TypeError:
        generic_0.add_provider(generic_provider_1)
    assert generic_0.__getattr__(str_0)


# Generated at 2022-06-25 20:43:11.436496
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    print('test method add_provider')
    generic_0 = Generic()
    print(generic_0)
    print(type(generic_0))
    print(dir(generic_0))
    assert hasattr(generic_0, 'github')
    assert hasattr(generic_0, 'github_username')


# Generated at 2022-06-25 20:43:15.845995
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('person')


# Generated at 2022-06-25 20:43:20.528192
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from datetime import datetime
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def get_value(self) -> datetime:
            return datetime.now()

    generic_0 = Generic()
    generic_0.add_provider(MyProvider)
    str_0 = generic_0.my_provider.get_value()


# Generated at 2022-06-25 20:43:21.898169
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert not hasattr(Generic, 'add_provider'), 'Generic has attribute add_provider'


# Generated at 2022-06-25 20:43:22.937491
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_case_0()