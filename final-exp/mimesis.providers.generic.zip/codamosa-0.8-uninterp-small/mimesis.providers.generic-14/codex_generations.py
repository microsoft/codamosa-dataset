

# Generated at 2022-06-25 20:42:39.472378
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Generic)
    assert generic.generic == Generic(seed=generic._seed)


# Generated at 2022-06-25 20:42:42.029994
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider_0 = Generic().provider
    assert isinstance(provider_0, Generic)


# Generated at 2022-06-25 20:42:45.015259
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.person
    name = generic.person.full_name()
    assert name == 'Anders Mclaughlin'

test_case_0()
test_Generic___getattr__()

# Generated at 2022-06-25 20:42:47.534980
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from ..providers import InternetProviderExample
    generic = Generic()
    generic.add_provider(InternetProviderExample)
    assert hasattr(generic, 'internetproviderexample')
    assert isinstance(generic.internetproviderexample,
                      InternetProviderExample)


# Generated at 2022-06-25 20:42:52.428938
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import Development
    generic_1 = Generic()
    development_1 = Development(seed=generic_1.seed)
    generic_1.add_provider(Development)
    assert development_1.__dict__ == generic_1.development.__dict__



# Generated at 2022-06-25 20:42:59.755654
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomClass(BaseProvider):
        class Meta:
            name = 'custom_class'

        def get_something(self):
            return 'something'

    custom_class = CustomClass(seed=123)

    generic_0 = Generic(seed=123)
    generic_0.add_provider(CustomClass)

    assert hasattr(generic_0, 'custom_class')
    assert isinstance(generic_0.custom_class, CustomClass)
    assert generic_0.custom_class.get_something() == custom_class.get_something()


# Generated at 2022-06-25 20:43:09.293114
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic(seed=0)
    assert generic_0.address().building_number() == '40'
    assert generic_0.address().postal_code() == '91215-4235'
    assert generic_0.address().street_name() == 'Sigmond Plains'
    assert generic_0.address().street_address() == '054 Ebert Manor'
    assert generic_0.address().street_address_with_postal_code() == \
        '054 Ebert Manor, 1162 Carroll Summit'
    assert generic_0.address().street_address_with_postal_code(
        postal_code=False) == '0939 Boyle Village, 0528 Sanford Knoll'
    assert generic_0.address().city_name() == 'Jaskolskihaven'

# Generated at 2022-06-25 20:43:11.274422
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from custom_providers import CustomProvider
    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    assert(generic_0.custom_provider)


# Generated at 2022-06-25 20:43:15.845510
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert not hasattr(generic, 'custom')

    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

    generic.add_provider(Custom)
    assert hasattr(generic, 'custom')



# Generated at 2022-06-25 20:43:17.495229
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Provider0)
    assert generic_0.provider0.get_result() == ('name', 'age', 'gender')


# Generated at 2022-06-25 20:43:37.167726
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class A(BaseProvider):
        class Meta:
            name = "a"
        def a(self):
            return 1
    generic_0.add_provider(A)
    assert generic_0.a.a() == 1


# Generated at 2022-06-25 20:43:38.955833
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.add_provider(cls=Person)
    # Put your code here.


# Generated at 2022-06-25 20:43:39.919206
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    Generic.add_provider(Generic,"Internet")


# Generated at 2022-06-25 20:43:45.392779
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider

    class Provider(BaseProvider):
        def foo(self):
            return self.random.randint(1, 100)
    generic = Generic()
    generic.add_provider(Provider)


# Generated at 2022-06-25 20:43:49.996028
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class TestProvider(BaseProvider):
        def __repr__(self) -> str:
            return 'TestProvider'

    generic.add_provider(TestProvider)
    assert generic.__dir__()[-1] == 'testprovider'
    generic.add_provider(Generic)



# Generated at 2022-06-25 20:43:54.547440
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    cls_0 = generic_0.person
    generic_0.add_provider(cls_0)
    assert generic_0.person is not None
    generic_1 = Generic()
    cls_1 = generic_1.business.company
    generic_1.add_provider(cls_1)
    assert generic_1.business is not None



# Generated at 2022-06-25 20:43:59.043459
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class Custom(BaseProvider):
        class Meta:
            name = "test_case"
        @classmethod
        def data(cls) -> dict:
            return {}
    generic_0.add_provider(Custom)
    assert generic_0.test_case.data() == {}

if __name__ == '__main__':
    test_case_0()
    test_Generic_add_provider()

# Generated at 2022-06-25 20:44:01.971191
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert hasattr(Generic(), 'person')


# Generated at 2022-06-25 20:44:10.647893
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestCls(BaseProvider):
        class Meta:
            name = 'test_provider'

        def some_method(self) -> str:
            return 'some_value'

    generic_0 = Generic()
    generic_0.add_provider(TestCls)
    assert hasattr(generic_0, 'test_provider')
    assert hasattr(generic_0.test_provider, 'some_method')
    assert generic_0.test_provider.some_method() == 'some_value'
    generic_1 = Generic(test_provider=TestCls)
    assert generic_1.test_provider.some_method() == 'some_value'
    try:
        generic_0.add_provider('test')
    except TypeError:
        pass
    generic_0.add_prov

# Generated at 2022-06-25 20:44:13.785888
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert generic_1.person.name()


# Generated at 2022-06-25 20:44:35.609003
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self, *args, **kwargs):
            pass

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    assert hasattr(generic_0, 'custom_provider')
    assert hasattr(generic_0.custom_provider, 'foo')
    assert generic_0.custom_provider.foo == generic_0.custom_provider.foo


# Generated at 2022-06-25 20:44:37.445218
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class_0 = Person
    generic_0.add_provider(class_0)
    assert (generic_0.person != None)


# Generated at 2022-06-25 20:44:40.073690
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Generic)
    generic_0.generic

# Generated at 2022-06-25 20:44:50.965697
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.internet.ipv4(), str)
    assert isinstance(generic_0.internet.ipv6(), str)
    assert isinstance(generic_0.internet.mac_address(), str)
    assert isinstance(generic_0.internet.provider(), str)
    assert isinstance(generic_0.internet.email(), str)
    assert isinstance(generic_0.internet.domain_zone(), str)
    assert isinstance(generic_0.internet.uri(), str)
    assert isinstance(generic_0.internet.ip_address(), str)
    assert isinstance(generic_0.internet.user_agent(), str)
    assert isinstance(generic_0.internet.url(), str)
    assert isinstance(generic_0.internet.domain(), str)

# Generated at 2022-06-25 20:44:55.936176
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class myCustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    generic = Generic()
    generic.add_provider(myCustomProvider)


# Generated at 2022-06-25 20:45:05.910357
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()

    # case 0
    assert generic_1.__getattr__('person') == generic_1._person(None, None)
    assert generic_1.__getattr__('business') == generic_1._business(None, None)
    assert generic_1.__getattr__('text') == generic_1._text(None, None)
    assert generic_1.__getattr__('food') == generic_1._food(None, None)

# Generated at 2022-06-25 20:45:09.009963
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Code)
    generic.add_provider(Payment)



# Generated at 2022-06-25 20:45:13.539498
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('clothing')
    generic_0.__getattr__('business')
    generic_0.__getattr__('hardware')



# Generated at 2022-06-25 20:45:20.456308
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(cls=Person)
    assert isinstance(generic_0.person, Person), 'Fail'
    generic_0.add_provider(cls=Address)
    assert isinstance(generic_0.address, Address), 'Fail'
    generic_0.add_provider(cls=Datetime)
    assert isinstance(generic_0.datetime, Datetime), 'Fail'
    generic_0.add_provider(cls=Business)
    assert isinstance(generic_0.business, Business), 'Fail'
    generic_0.add_provider(cls=Text)
    assert isinstance(generic_0.text, Text), 'Fail'
    generic_0.add_provider(cls=Food)

# Generated at 2022-06-25 20:45:27.517641
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    assert generic_0.custom_provider.foo() == 'bar'


# Generated at 2022-06-25 20:45:58.467194
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class customProvider(BaseProvider):
        def custom(self):
            return 'test'
    generic_1 = Generic()
    generic_1.add_provider(customProvider)
    assert generic_1.custom.custom() == 'test'


# Generated at 2022-06-25 20:45:59.445431
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    assert generic_0.locale == 'en'


# Generated at 2022-06-25 20:46:00.475995
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    for attr in dir(generic):
        generic.__getattr__(attr)



# Generated at 2022-06-25 20:46:05.925400
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def get_test_something(self) -> str:
            return 'Test'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'test_provider')
    assert generic.test_provider.get_test_something() == 'Test'

