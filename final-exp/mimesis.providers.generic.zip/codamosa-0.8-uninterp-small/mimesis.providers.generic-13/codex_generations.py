

# Generated at 2022-06-25 20:42:55.562472
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    # Testing of type hinting
    def test(generic_cls: Generic, new_provider: BaseProvider):
        """Test.

        :param generic_cls: Generic class instance.
        :param new_provider: New provider.
        """
        generic_cls.add_provider(new_provider)

    generic_2 = Generic()
    provider = Generic.Meta

    # Testing of incorrect class type
    try:
        provider = 12
        generic_2.add_provider(provider)
    except TypeError as e:
        assert str(e) == 'The provider must be a class'

    # Testing of incorrect type

# Generated at 2022-06-25 20:42:57.818051
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    # add_provider(cls)
    generic.add_provider(Person)


# Generated at 2022-06-25 20:42:59.476626
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__("")
    generic_0.__getattr__("dummy")
    generic_0.__getattr__("spam")
    generic_0.__getattr__("eggs")


# Generated at 2022-06-25 20:43:08.382644
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.person
    generic_0.address
    generic_0.datetime
    generic_0.business
    generic_0.text
    generic_0.food
    generic_0.science
    generic_0.transport
    generic_0.code
    generic_0.unit_system
    generic_0.file
    generic_0.numbers
    generic_0.development
    generic_0.hardware
    generic_0.clothing
    generic_0.internet
    generic_0.path
    generic_0.payment
    generic_0.cryptographic
    generic_0.structure
    generic_0.choice
    generic_0.generic_provider


# Generated at 2022-06-25 20:43:11.907403
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.internet.ip_address()
    generic.internet.http_method()
    generic.internet.dns()
    generic.internet.url()

    generic.food.ingredient()
    generic.food.dish()
    generic.food.condiment()
    generic.food.vegetable()
    generic.food.spice()
    generic.food.fruit()



# Generated at 2022-06-25 20:43:17.978821
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):

        class Meta:
            name = 'test_provider'

        def __init__(self):
            super().__init__(
                'en',
                '0',
            )

        def test_method(self):
            return 'test_method'

    test_provider = TestProvider

    generic = Generic()
    generic.add_provider(test_provider)
    assert hasattr(generic, 'test_provider')
    assert hasattr(generic.test_provider, 'test_method')
    assert generic.test_provider.test_method() == 'test_method'



# Generated at 2022-06-25 20:43:27.954307
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    globals()["generic_0"] = Generic()
    generic_0 = globals()["generic_0"]
    generic_0.person
    assert generic_0.__dict__["person"].__class__.__name__ == "Person"
    generic_0.address
    assert generic_0.__dict__["address"].__class__.__name__ == "Address"
    generic_0.datetime
    assert generic_0.__dict__["datetime"].__class__.__name__ == "Datetime"
    generic_0.business
    assert generic_0.__dict__["business"].__class__.__name__ == "Business"
    generic_0.text
    assert generic_0.__dict__["text"].__class__.__name__ == "Text"
    generic_0.food

# Generated at 2022-06-25 20:43:35.648302
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert hasattr(generic, "person")
    assert hasattr(generic, "address")
    assert hasattr(generic, "datetime")
    assert hasattr(generic, "business")
    assert hasattr(generic, "text")
    assert hasattr(generic, "food")
    assert hasattr(generic, "science")
    assert hasattr(generic, "transport")
    assert hasattr(generic, "code")
    assert hasattr(generic, "unit_system")
    assert hasattr(generic, "file")
    assert hasattr(generic, "numbers")
    assert hasattr(generic, "development")
    assert hasattr(generic, "hardware")
    assert hasattr(generic, "clothing")
    assert hasattr(generic, "internet")
    assert hasattr(generic, "path")

# Generated at 2022-06-25 20:43:37.398309
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.numbers.__getattr__('__getattr__')
    generic_0.__getattr__('numbers')


# Generated at 2022-06-25 20:43:43.545192
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    person_0 = generic_1._person
    address_0 = generic_1._address
    datetime_0 = generic_1._datetime
    business_0 = generic_1._business
    text_0 = generic_1._text
    food_0 = generic_1._food
    science_0 = generic_1._science
    assert person_0
    assert address_0
    assert datetime_0
    assert business_0
    assert text_0
    assert food_0
    assert science_0
    #  __getattr__ method
    person_1 = generic_1.person
    address_1 = generic_1.address
    datetime_1 = generic_1.datetime
    business_1 = generic_1.business
    text_1 = generic_1.text
    food_

# Generated at 2022-06-25 20:44:01.813342
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Testing that new provider is added to Generic() object
    try:
        from .test_provider import DummyProvider
        g = Generic()
        g.add_provider(DummyProvider)
        assert 'dummyprovider' in dir(g)
    except:
        assert False


# Generated at 2022-06-25 20:44:07.869502
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(ProviderE)
    assert generic.provider_e
    try:
        generic.add_provider(UnitSystem)
        assert False
    except TypeError:
        assert True
    try:
        generic.add_provider(object)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 20:44:10.155796
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    print(generic_0.address)


# Generated at 2022-06-25 20:44:17.566886
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class myProvider(BaseProvider):
        class Meta:
            name = 'provider'

    generic_1 = Generic()
    try:
        generic_1.add_provider(myProvider)
        assert hasattr(generic_1, 'provider')
    except TypeError:
        pass
    class myBadProvider():
        pass
    try:
        generic_1.add_provider(myBadProvider)
    except TypeError:
        pass


# Generated at 2022-06-25 20:44:18.905330
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()


# Generated at 2022-06-25 20:44:26.875092
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print(Generic.__dict__)
    gen = Generic()
    print(gen.person.name())
    for i in gen.__dict__.keys():
        if i.startswith('_'):
            print(i, gen.__dict__[i])
    # first_name = getattr(gen, 'first_name', None)
    # print(first_name)
    # assert first_name is not None
    # assert isinstance(first_name, str)



# Generated at 2022-06-25 20:44:29.801814
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Address)



# Generated at 2022-06-25 20:44:35.024885
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    cls = Person
    provider = Generic(seed=123)
    provider.add_provider(cls)
    assert isinstance(provider.person, cls)
    assert provider.person.name() == "Валентина"


# Generated at 2022-06-25 20:44:39.531792
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.file import File
    from mimesis.providers.choice import Choice

    generic_0 = Generic()
    generic_0.add_provider(Person)
    generic_0.add_provider(Cryptographic)
    generic_0.add_provider(File)
    generic_0.add_provider(Choice)


# Generated at 2022-06-25 20:44:42.487751
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic()
    provider.add_provider(Choice)
    assert 'choice' in provider.__dict__


# Generated at 2022-06-25 20:44:56.151580
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    # generic.add_provider(Provider)


# Generated at 2022-06-25 20:45:02.706626
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Generic_0 = Generic()
    Generic_1 = Generic()
    Generic_2 = Generic()

    Generic_1.add_provider(Payment)
    Generic_2.add_provider(Hardware)

    test_case_1(Generic_1, Generic_2)

# Test cases for method add_provider of class Generic

# Generated at 2022-06-25 20:45:10.019668
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    def test_case_0():
        import mimesis.providers.generic
        generic_0 = mimesis.providers.generic.Generic()
        assert generic_0.add_provider(None) is None
    def test_case_1():
        import mimesis.providers.generic
        import mimesis.providers.developer
        generic_0 = mimesis.providers.generic.Generic()
        assert generic_0.add_provider(mimesis.providers.developer.Developer) is None
    def test_case_2():
        import mimesis.providers.generic
        import mimesis.providers.developer
        generic_0 = mimesis.providers.generic.Generic()

# Generated at 2022-06-25 20:45:13.270916
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    for provider in get_providers():
        generic_0.add_provider(provider)


# Generated at 2022-06-25 20:45:20.328824
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class ProviderA(BaseProvider):
        class Meta:
            name = 'provider_a'

    class ProviderB(BaseProvider):
        class Meta:
            name = 'provider_b'

    class ProviderC(BaseProvider):
        class Meta:
            name = 'provider_c'

    class ProviderD(BaseProvider):
        class Meta:
            name = 'provider_d'

    class ProviderE(BaseProvider):
        class Meta:
            name = 'provider_e'

    class Provider_X(BaseProvider):
        class Meta:
            name = 'provider_x'

    class Provider_Y(BaseProvider):
        class Meta:
            name = 'provider_y'

    class Provider_Z(BaseProvider):
        class Meta:
            name = 'provider_z'

    # all custom

# Generated at 2022-06-25 20:45:23.584855
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Address)


# Generated at 2022-06-25 20:45:30.827636
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.choice, Choice)
    assert isinstance(generic_0.code, Code)
    assert isinstance(generic_0.cryptographic, Cryptographic)
    assert isinstance(generic_0.politics, Politics)
    assert isinstance(generic_0.structure, Structure)
    assert isinstance(generic_0.payment, Payment)
    assert isinstance(generic_0.business, Business)
    assert isinstance(generic_0.food, Food)
    assert isinstance(generic_0.science, Science)
    assert isinstance(generic_0.transport, Transport)
    assert isinstance(generic_0.clothing, Clothing)
    assert isinstance(generic_0.hardware, Hardware)
    assert isinstance(generic_0.unit_system, UnitSystem)


# Generated at 2022-06-25 20:45:36.650726
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    expected_attribute_0 = generic_0.person.full_name()
    assert str.lower(expected_attribute_0) == 'aaron harper'
    expected_attribute_1 = generic_0.datetime.datetime()
    assert expected_attribute_1 == '2015-11-16 20:35:14'


# Generated at 2022-06-25 20:45:46.120231
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        test_case_0()
        test_case_add_provider_0()
        test_case_add_provider_1()
    except Exception as e:
        print("\033[31;1mError:\033[0m {}".format(e))
    else:
        print("\033[32;1mPass:\033[0m test case for Generic's add_provider() succeed.")
# test_Generic_add_provider()

# Test case for Generic.add_provider()

# Generated at 2022-06-25 20:45:58.595904
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    cls_0 = generic_0.add_provider(Code)
    cls_1 = generic_0.add_provider(UnitSystem)
    cls_2 = generic_0.add_provider(File)
    cls_3 = generic_0.add_provider(Numbers)
    cls_4 = generic_0.add_provider(Hardware)
    cls_5 = generic_0.add_provider(Development)
    cls_6 = generic_0.add_provider(Clothing)
    cls_7 = generic_0.add_provider(Internet)
    cls_8 = generic_0.add_provider(Path)
    cls_9 = generic_0.add_provider(Payment)
    cls_10 = generic_

# Generated at 2022-06-25 20:46:18.133612
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    generic_1 = Generic()
    generic_1.add_provider(Person)
    generic_1.add_provider(Address)
    generic_1.person
    generic_1.address
    generic_1.add_provider(Numbers)
    generic_1.numbers


# Generated at 2022-06-25 20:46:18.791696
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-25 20:46:30.804147
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    generic_0.add_provider(Address)
    generic_0.add_provider(Path)
    generic_0.add_provider(Datetime)
    generic_0.add_provider(Business)
    generic_0.add_provider(Text)
    generic_0.add_provider(Food)
    generic_0.add_provider(Science)
    generic_0.add_provider(Transport)
    generic_0.add_provider(Code)
    generic_0.add_provider(UnitSystem)
    generic_0.add_provider(File)
    generic_0.add_provider(Numbers)
    generic_0.add_provider(Development)
    generic_0.add

# Generated at 2022-06-25 20:46:32.611489
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    custom_provider = Person
    generic.add_provider(custom_provider)
    assert (
        'person' in dir(generic)
    )


# Generated at 2022-06-25 20:46:34.387336
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Code)
    generic_1_new = generic_1.code
    

# Generated at 2022-06-25 20:46:41.739188
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'
        def foo(self):
            return 'bar'

    test_case_0 = TestProvider()
    assert test_case_0.foo() == 'bar'

    test_case_1 = Generic()
    test_case_1.add_provider(TestProvider)
    assert test_case_1.test.foo() == 'bar'


# Generated at 2022-06-25 20:46:43.118859
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Generic.__getattr__(Generic())

# Generated at 2022-06-25 20:46:52.549714
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    generic.add_provider(Address)
    generic.add_provider(Datetime)
    generic.add_provider(Business)
    generic.add_provider(Text)
    generic.add_provider(Food)
    generic.add_provider(Science)
    generic.add_provider(Transport)
    generic.add_provider(Code)
    generic.add_provider(UnitSystem)
    generic.add_provider(File)
    generic.add_provider(Numbers)
    generic.add_provider(Development)
    generic.add_provider(Hardware)
    generic.add_provider(Clothing)
    generic.add_provider(Internet)
    generic.add_provider(Path)
    generic

# Generated at 2022-06-25 20:46:55.313700
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)


# Generated at 2022-06-25 20:46:59.170020
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """ Unit test for method add_provider of class Generic """
    generic_0 = Generic()
    generic_0.add_provider(Person)
    generic_0.add_provider(Address)


# Generated at 2022-06-25 20:47:17.326625
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)
    generic_1.add_provider(Address)
    generic_1.add_provider(Datetime)
    generic_1.add_provider(Business)
    generic_1.add_provider(Text)
    generic_1.add_provider(Food)
    generic_1.add_provider(Science)
    generic_1.add_provider(Transport)
    generic_1.add_provider(Code)
    generic_1.add_provider(UnitSystem)
    generic_1.add_provider(File)
    generic_1.add_provider(Numbers)
    generic_1.add_provider(Development)
    generic_1.add_provider(Hardware)
    generic_1.add

# Generated at 2022-06-25 20:47:20.312691
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Payment)



# Generated at 2022-06-25 20:47:22.891850
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    assert generic_1.add_provider(cls=Person) == None

# Use of method add_provider of class Generic

# Generated at 2022-06-25 20:47:29.312011
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic"""
    # Example: Set up some test values
    generic_0 = Generic()

    # Example: Use the method
    generic_0.__getattr__("person")

    # Example: Assert the result to be valid
    generic_0.__getattr__("person")

# Generated at 2022-06-25 20:47:32.540675
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.names import Names
    # add a custom namespace
    generic = Generic()
    generic.add_provider(Names)
    assert generic.names.name(gender='male') == 'Anderson'


# Generated at 2022-06-25 20:47:43.747188
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import mimesis.providers.custom.my_provider as custom

    class MyProvider(BaseProvider):
        class Meta:
            name = 'MyProvider'

        def custom_method(self):
            return 'This is custom method'

    class MyProvider2(BaseProvider):
        class Meta:
            name = 'MyProvider'

        def custom_method(self):
            return 'This is custom method'

    generic = Generic()
    generic.add_provider(MyProvider)
    assert callable(generic.MyProvider().custom_method)

    class MyProvider3(BaseProvider):
        class Meta:
            name = 'MyProvider'

        def custom_method(self):
            return 'This is custom method'

    generic.add_providers(MyProvider2, MyProvider3)

# Generated at 2022-06-25 20:47:44.353936
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert(True)

# Generated at 2022-06-25 20:47:48.855423
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.custom.custom_provider import CustomProvider
    name = "test_provider"
    class TestProvider(BaseProvider):
        def __init__(self):
            super().__init__()
        def __str__(self):
            return name
    generic = Generic()
    generic.add_provider(TestProvider)
    provider = getattr(generic, name)
    assert(str(provider) == name)


# Generated at 2022-06-25 20:47:55.293283
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Person(BaseProvider):
        """Custom provider"""
        class Meta:
            name = 'person'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.name = self.__class__.__name__

        def __call__(self, *args, **kwargs):
            return self.name

    generic = Generic()
    generic.add_provider(Person)
    assert(hasattr(generic, Person.Meta.name))
    assert(generic.person() == 'Person')


# Generated at 2022-06-25 20:47:59.409012
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test case for method add_provider of class Generic"""
    # Test with provider class of type BaseProvider
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert generic_1.person

    # Test with provider class of type not BaseProvider
    generic_2 = Generic()
    generic_2.add_provider(Datetime)

    # Test with a non class object
    generic_3 = Generic()
    generic_3.add_provider(3.14)


# Generated at 2022-06-25 20:48:33.216091
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0__person_0 = generic_0.person
    generic_0__address_0 = generic_0.address
    generic_0__datetime_0 = generic_0.datetime
    generic_0__business_0 = generic_0.business
    generic_0__text_0 = generic_0.text
    generic_0__food_0 = generic_0.food
    generic_0__science_0 = generic_0.science
    generic_0_transport_0 = generic_0.transport
    generic_0_code_0 = generic_0.code
    generic_0_unit_system_0 = generic_0.unit_system
    generic_0_file_0 = generic_0.file
    generic_0_numbers_0 = generic_0.numbers
   

# Generated at 2022-06-25 20:48:40.743186
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.person = Person()
    generic.address = Address()
    generic.datetime = Datetime()
    generic.business = Business()
    generic.text = Text()
    generic.food = Food()
    generic.science = Science()
    generic.transport = Transport()
    generic.code = Code()
    generic.unit_system = UnitSystem()
    generic.file = File()
    generic.numbers = Numbers()
    generic.development = Development()
    generic.hardware = Hardware()
    generic.clothing = Clothing()
    generic.internet = Internet()
    generic.path = Path()
    generic.payment = Payment()
    generic.cryptographic = Cryptographic()
    generic.structure = Structure()
    generic.choice = Choice()


# Generated at 2022-06-25 20:48:43.250160
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__(attrname='address')
    generic_0.__getattr__(attrname='datetime')


# Generated at 2022-06-25 20:48:51.275290
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science

    # 1. test to add a provider as a class
    generic_0 = Generic()
    generic_0.add_provider(Science)
    assert "science" in generic_0.__dict__
    assert isinstance(generic_0.__dict__["science"], Science)

    # 2. test to add a provider as a subclass of BaseProvider
    generic_0 = Generic()

    class CustomProvider(BaseProvider):

        class Meta:
            name = 'custom_provider'

        def custom_method(self):
            return self.random.choice(['a', 'b', 'c'])

    generic_0.add_provider(CustomProvider)

    # 2.1 check "custom_provider" in attributes of generic

# Generated at 2022-06-25 20:48:54.446277
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.custom import Custom
    generic = Generic()
    assert not hasattr(generic, 'custom')
    generic.add_provider(Custom)


# Generated at 2022-06-25 20:48:59.767600
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert (generic_0.__getattribute__('_person') == Person), \
        'generic_0.__getattribute__(' + "'_person'" + ') is not a ' \
        + 'Person'
    assert (generic_0.__getattribute__('_address') == Address), \
        'generic_0.__getattribute__(' + "'_address'" + ') is not a ' \
        + 'Address'
    assert (generic_0.__getattribute__('_datetime') == Datetime), \
        'generic_0.__getattribute__(' + "'_datetime'" + ') is not a ' \
        + 'Datetime'

# Generated at 2022-06-25 20:49:00.531844
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()



# Generated at 2022-06-25 20:49:04.234856
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.business import Business
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.user_agent import UserAgent

    assert issubclass(Business, BaseProvider)
    assert not issubclass(UserAgent, BaseProvider)

    generic = Generic()
    generic.add_provider(Business)
    generic.add_provider(UserAgent)

    assert 'business' in dir(generic)


# Generated at 2022-06-25 20:49:07.296521
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .custom_providers.country import Country
    generic_0 = Generic()

    generic_0.add_provider(Country)
    assert getattr(generic_0, "country").__class__.__name__ == Country.__name__
    assert generic_0.country.get_country_code() == "AF"
    generic_0.add_provider(Country)


# Generated at 2022-06-25 20:49:13.333698
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        class Meta:
            name = 'provider'
    generic = Generic()
    generic.add_provider(Provider)
    
    # the provider should be added to the list of all providers
    assert 'provider' in dir(generic)
    
    # the provider should not be added to the list of all providers
    assert 'provider' not in dir(generic)


# Generated at 2022-06-25 20:50:03.895122
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a mockup class for adding it to generic
    class DummyClass(BaseProvider):
        class Meta:
            name = 'dummy_class'

    generic_0 = Generic()
    generic_0.add_provider(DummyClass)

    # Check by assertion that dummy class is added to generic
    assert(generic_0.dummy_class is not None)



# Generated at 2022-06-25 20:50:10.356612
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    generic_0.add_provider(Address)
    generic_0.add_provider(Datetime)
    generic_0.add_provider(Business)
    generic_0.add_provider(Text)
    generic_0.add_provider(Food)
    generic_0.add_provider(Science)
    generic_0.add_provider(Transport)
    generic_0.add_provider(Code)
    generic_0.add_provider(UnitSystem)
    generic_0.add_provider(File)
    generic_0.add_provider(Numbers)
    generic_0.add_provider(Development)
    generic_0.add_provider(Hardware)
    generic_0.add

# Generated at 2022-06-25 20:50:16.097322
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    from mimesis.providers.development import Development
    from mimesis.providers.transport import Transport
    generic = Generic()
    generic.add_provider(Person)
    generic.add_provider(Address)
    generic.add_provider(Internet)
    generic.add_provider(Development)
    generic.add_provider(Transport)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.internet, Internet)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.transport, Transport)



# Generated at 2022-06-25 20:50:24.293238
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test case 0
    # Create object generic_0
    generic_0 = Generic()
    # Create object cls_0
    cls_0 = generic_0.person
    # Create object cls_1
    cls_1 = generic_0.address
    # Create object cls_2
    cls_2 = generic_0.datetime
    # Create object cls_3
    cls_3 = generic_0.business
    # Create object cls_4
    cls_4 = generic_0.text
    # Create object cls_5
    cls_5 = generic_0.food
    # Create object cls_6
    cls_6 = generic_0.science
    # Create object cls_7
    cls_7 = generic_0.transport
    # Create object cls_

# Generated at 2022-06-25 20:50:28.551128
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert generic_1.person.full_name()  # > success



# Generated at 2022-06-25 20:50:30.622546
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_7 = Generic()
    generic_7.add_provider(Generic)
    generic_7.add_provider(BaseProvider)
    generic_7.add_provider(BaseDataProvider)


# Generated at 2022-06-25 20:50:36.434109
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    Test case for method add_provider of class Generic
    """
    generic_1 = Generic()
    generic_1.add_provider(UnitSystem)
    assert isinstance(generic_1.unit_system, UnitSystem)
    generic_1.add_provider(Numbers)
    assert isinstance(generic_1.numbers, Numbers)
    generic_1.add_provider(Structure)
    assert isinstance(generic_1.structure, Structure)
    generic_1.add_provider(Cryptographic)
    assert isinstance(generic_1.cryptographic, Cryptographic)
    generic_1.add_provider(Choice)
    assert isinstance(generic_1.choice, Choice)
    generic_1.add_provider(Payment)
    assert isinstance(generic_1.payment, Payment)

# Generated at 2022-06-25 20:50:39.032785
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Payment)
    generic.payment.address.address()
    if hasattr(generic, 'payment'):
        assert True
    else:
        assert False


    # Unit test for method add_providers of class Generic

# Generated at 2022-06-25 20:50:44.176507
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseDataProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)
        def __str__(self):
            return "This is MyProvider"

    # Use case 1: add a provider which has a subclass definition
    generic = Generic()
    generic.add_provider(MyProvider)
    print(generic.myprovider)
    assert str(generic.myprovider) == "This is MyProvider"

    # Use case 2: try add a provider without subclass definition
    class NoProvider:
        def __init__(self):
            print("NoProvider is created")

    try:
        generic.add_provider(NoProvider)
    except TypeError as e:
        print(e)
    else:
        print("Use case 2: No exception is thrown")


# Generated at 2022-06-25 20:50:45.063881
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Transport)
