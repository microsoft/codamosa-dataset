

# Generated at 2022-06-25 20:42:41.289399
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    
    class OneProvider(BaseProvider):
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.meta = self.Meta

        class Meta:
            name = 'one_provider'

        def __call__(self):
            return 'One Provider'

    generic_0 = Generic()
    print(generic_0.add_provider(OneProvider))

    print(generic_0.one_provider())


# Generated at 2022-06-25 20:42:48.339163
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    a0 = generic_0.business.company()
    a1 = generic_0.business.company_name()
    a2 = generic_0.business.company_suffix()
    a3 = generic_0.business.credit_card_expire()
    a4 = generic_0.business.credit_card_full()
    a5 = generic_0.business.credit_card_number()
    a6 = generic_0.business.credit_card_provider()
    a7 = generic_0.business.credit_card_security_code()
    a8 = generic_0.business.credit_card_type()
    a9 = generic_0.business.job_title()
    a10 = generic_0.business.job_titles()

# Generated at 2022-06-25 20:42:54.818365
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Person)
    gen.add_provider(Datetime)
    print(dir(gen))
    gen_0 = Generic(seed=1)
    gen_1 = Generic(seed=1)
    assert gen_0 == gen_1
    generic = Generic()
    generic.add_providers(Person, Datetime, Code, Payment)
    assert 'Person' in dir(generic)



# Generated at 2022-06-25 20:42:58.112000
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    '''
    >>> generic_1 = Generic()
    >>> person_1 = generic_1.person
    >>> person_2 = generic_1.person
    >>> person_1 != person_2
    True
    '''


# Generated at 2022-06-25 20:43:01.604747
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test case 0
    # Create an instance of Generic

    generic_0 = Generic()
    # Create an attribute datetime
    generic_0.datetime
    # Create an attribute person
    generic_0.person



# Generated at 2022-06-25 20:43:03.864339
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0._person is None
    assert generic_0.person is not None



# Generated at 2022-06-25 20:43:05.563015
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('_person')



# Generated at 2022-06-25 20:43:07.230638
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.person is not None


# Generated at 2022-06-25 20:43:07.849554
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Datetime)



# Generated at 2022-06-25 20:43:10.005463
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Arrange
    class Type(BaseProvider):
        pass

    generic_obj = Generic()
    # Act
    generic_obj.add_provider(Type)

    # Assert
    assert hasattr(generic_obj, "type")


# Generated at 2022-06-25 20:43:34.394701
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic("en")
    class Provider1(BaseProvider):
        class Meta:
            name = "provider1"
    class Provider2(BaseProvider):
        class Meta:
            name = "provider2"
        def __init__(self, seed):
            self.seed = seed
    try:
        generic.add_provider(Provider1)
        generic.add_provider(Provider2)
    except Exception as e:
        assert True == False, 'Got unexpected exception: %s' % e
    else:
        assert True == True


# Generated at 2022-06-25 20:43:36.859703
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Business)
    generic.add_provider(Address)
    generic.add_provider(Person)



# Generated at 2022-06-25 20:43:38.030198
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)


# Generated at 2022-06-25 20:43:42.853530
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class Foo(BaseProvider):
        pass
    generic_0.add_provider(Foo)
    assert isinstance(generic_0.foo, Foo)
    class Bar(BaseProvider):
        class Meta:
            name = 'bar'
    generic_0.add_provider(Bar)
    assert isinstance(generic_0.bar, Bar)


# Generated at 2022-06-25 20:43:52.066923
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class MyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        class Meta:
            name = 'myprovider'
        def my_method(self):
            return 'mymethod'
    generic_add_provider_0 = Generic()
    generic_add_provider_0_result = generic_add_provider_0.add_provider(MyProvider)
    assert generic_add_provider_0_result is None
    assert generic_add_provider_0.myprovider.my_method() == 'mymethod'


# Generated at 2022-06-25 20:43:56.041489
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__("")
    generic_0.__getattr__("")
    generic_0.__getattr__("")


# Generated at 2022-06-25 20:43:57.982584
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert "person" in dir(generic)
    assert isinstance(generic.person, Person)


# Generated at 2022-06-25 20:44:09.846941
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.product import Product
    from mimesis.providers.file import File
    # Providing the object of two different classes,
    # and checking for their availability in the object
    generic_1 = Generic()
    generic_1.add_provider(Product)
    generic_1.add_provider(File)

    assert hasattr(generic_1, "product")
    assert hasattr(generic_1, "file")

    # Testing with an invalid provider,ie, a class which is not a
    # subclass of BaseProvider
    from mimesis.providers.science import Science

    class InvalidProvider(Science):
        pass

    generic_2 = Generic()
    try:
        generic_2.add_provider(InvalidProvider)
    except TypeError as e:
        pass

# Generated at 2022-06-25 20:44:13.426667
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Generic)


if __name__ == '__main__':
    test_Generic_add_provider()

# Generated at 2022-06-25 20:44:17.532566
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Add a custom provider to Generic() object."""
    from mimesis.providers import Person

    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    assert generic.person is not None
