

# Generated at 2022-06-25 20:42:42.305833
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

    generic_0 = Generic()
    generic_0.add_provider(cls=MyProvider)
    assert generic_0.my_provider.__class__.__name__ == 'MyProvider'


# Generated at 2022-06-25 20:42:45.015105
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person') == True



# Generated at 2022-06-25 20:42:53.981954
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        """MyProvider."""

        class Meta:
            """Class for metadata."""

            name = 'my_provider'

        def __init__(self, seed: str = None,
                     datetime: Datetime = None,
                     locales: List[str] = None) -> None:
            super().__init__(
                seed=seed,
                datetime=datetime,
                locales=locales,
            )

    class WrongProvider(int):
        """WrongProvider."""

    generic = Generic()
    generic.add_provider(MyProvider)
    #generic.add_provider(WrongProvider)


# Generated at 2022-06-25 20:42:56.053259
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import pytest
    with pytest.raises(KeyError):
        Generic().__getattr__('_person')


# Generated at 2022-06-25 20:42:59.574010
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_1 = Generic()
    assert(generic_0.text.string() == "XZvFsGBt")
    assert(generic_1.text.string() == "mzMvlrsm")


# Generated at 2022-06-25 20:43:09.143073
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    # Test with a custom class
    class MyProvider(BaseProvider):
        class Meta(BaseProvider.Meta):
            """Class for metadata."""

            name = 'myprovider'
    generic_0.add_provider(MyProvider)
    assert isinstance(generic_0.myprovider, MyProvider)
    # Test with a type
    generic_0.add_provider(type(MyProvider))
    assert isinstance(generic_0.myprovider, MyProvider)
    # Test with an instance
    generic_0.add_provider(MyProvider())
    assert isinstance(generic_0.myprovider, MyProvider)
    # Test with an error
    try:
        generic_0.add_provider('MyProvider')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-25 20:43:16.474648
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()

    assert callable(getattr(generic_0, 'person'))
    assert callable(getattr(generic_0, 'address'))
    assert callable(getattr(generic_0, 'business'))
    assert callable(getattr(generic_0, 'cryptographic'))
    assert callable(getattr(generic_0, 'file'))
    assert callable(getattr(generic_0, 'hardware'))
    assert callable(getattr(generic_0, 'internet'))
    assert callable(getattr(generic_0, 'numbers'))
    assert callable(getattr(generic_0, 'path'))
    assert callable(getattr(generic_0, 'payment'))
    assert callable(getattr(generic_0, 'science'))
   

# Generated at 2022-06-25 20:43:25.832647
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'address')
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'text')
    assert hasattr(generic, 'food')
    assert hasattr(generic, 'science')
    assert hasattr(generic, 'transport')
    assert hasattr(generic, 'code')
    assert hasattr(generic, 'unit_system')
    assert hasattr(generic, 'file')
    assert hasattr(generic, 'numbers')
    assert hasattr(generic, 'development')
    assert hasattr(generic, 'hardware')
    assert hasattr(generic, 'clothing')
    assert hasattr(generic, 'internet')
    assert hasattr(generic, 'path')

# Generated at 2022-06-25 20:43:27.971366
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert generic_1.person


# Generated at 2022-06-25 20:43:29.494639
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    test_provider_0 = Person
    generic_0 = Generic()
    generic_0.add_provider(cls=test_provider_0)


# Generated at 2022-06-25 20:43:56.065919
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Initialization
    generic_1 = Generic()

    # Test method
    generic_1.person
    generic_1.address
    generic_1.datetime
    generic_1.business
    generic_1.text
    generic_1.food
    generic_1.science
    generic_1.transport
    generic_1.code
    generic_1.unit_system
    generic_1.file
    generic_1.numbers
    generic_1.development
    generic_1.hardware
    generic_1.clothing
    generic_1.internet
    generic_1.path
    generic_1.payment
    generic_1.cryptographic
    generic_1.structure
    generic_1.choice

    # Check the results
    res_0 = generic_1.person

# Generated at 2022-06-25 20:44:03.057120
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super().__init__(seed, **kwargs)

        class Meta:
            name = 'provider'

        def method_0(self):
            return 0

    class Provider1(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super().__init__(seed, **kwargs)

        class Meta:
            name = 'provider1'

        def method_1(self):
            return 1

    class Provider2(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super().__init__(seed, **kwargs)

        class Meta:
            name = 'provider2'

        def method_2(self):
            return 2



# Generated at 2022-06-25 20:44:10.091375
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class PersonDummy(Person):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.dummy = Dummy(seed=self.seed)

        class Meta:
            name = 'dummy'

        def name(self, gender: Gender = None) -> str:
            return self.dummy.word()

    generic = Generic()
    generic.add_provider(PersonDummy)

    assert_true(isinstance(generic.dummy, PersonDummy))



# Generated at 2022-06-25 20:44:15.999965
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    print(generic.Meta.name)
    assert generic.Meta.name == 'generic'
    generic.add_provider(Person)
    print(generic.Meta.name)
    assert generic.Meta.name == 'generic'
    assert generic.person.Meta.name == 'person'

# Generated at 2022-06-25 20:44:17.667287
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Clothing)
    generic_0.clothing.cloth()


# Generated at 2022-06-25 20:44:23.823206
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # In this test we're going to check if Generic has a member
    # 'person' and that it has type Person
    from mimesis.providers.person import Person
    generic_0 = Generic()
    assert hasattr(generic_0, 'person')
    assert type(generic_0.person) is Person


# Generated at 2022-06-25 20:44:30.179348
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)

# Generated at 2022-06-25 20:44:36.255238
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def custom_method(self) -> str:
            return 'custom_method'

    generic_1.add_provider(CustomProvider)
    generic_1.custom_provider.custom_method()


# Generated at 2022-06-25 20:44:41.170648
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    if generic.choice:
        print(generic.choice.__class__)
        generic.add_provider(Choice)
        generic.add_provider(Generic)
        generic.add_provider(Choice())


# Generated at 2022-06-25 20:44:44.358548
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Barcode
    generic_0 = Generic()
    generic_0.add_provider(Barcode)


# Generated at 2022-06-25 20:45:15.445152
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic(random_state=43)
    g.add_provider(Person)
    assert type(g.person) == Person



# Generated at 2022-06-25 20:45:21.190952
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'
    generic_1.add_provider(Custom)
    assert isinstance(generic_1.custom, Custom)


# Generated at 2022-06-25 20:45:28.080357
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    def test_provider():
        class TestProvider(BaseProvider):
            """Test provider."""

            class Meta:
                """Class for metadata."""

                name = 'test'

            def foo(self) -> str:
                """Test method.

                :return: Test.
                """
                return 'test'

    generic.add_provider(test_provider)
    assert generic.test.foo() == 'test'



# Generated at 2022-06-25 20:45:33.112754
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class TestProvider(BaseProvider):
        pass
    generic_1.add_provider(TestProvider)
    assert "testprovider" in dir(generic_1)


# Generated at 2022-06-25 20:45:39.862299
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    # adding provider for which class is not a subclass of BaseProvider
    def test_case_1():
        generic_1 = Generic()
        generic_1.add_provider(Generic)

    test_case_1()

    # adding non class object
    def test_case_2():
        generic_2 = Generic()
        generic_2.add_provider("")

    test_case_2()

    # adding a custom provider which class is a subclass of BaseDataProvider
    def test_case_3():
        generic_3 = Generic()
        class MyProvider(BaseDataProvider):
            pass
        generic_3.add_provider(MyProvider)
        assert generic_3.myprovider

    test_case_3()

    # adding custom provider which class is a subclass of BaseProvider but not a subclass of BaseDataProvider

# Generated at 2022-06-25 20:45:45.484720
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import Datetime as DatetimeProvider
    generic = Generic()
    generic.add_provider(DatetimeProvider)
    assert hasattr(generic, 'datetime')
    assert isinstance(generic.datetime, DatetimeProvider)


# Generated at 2022-06-25 20:45:48.953658
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Device(BaseProvider):
        class Meta:
            name = 'device'
        def cpu(self) -> str:
            return 'Intel core 2 duo.'
    generic_0 = Generic()
    assert hasattr(generic_0, 'device') is False
    generic_0.add_provider(Device)
    assert hasattr(generic_0, 'device') is True
    assert generic_0.device.cpu() == 'Intel core 2 duo.'


# Generated at 2022-06-25 20:45:59.849362
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.add_provider(generic_0.person)
    generic_0.add_provider(generic_0.datetime)
    generic_0.add_provider(generic_0.business)
    generic_0.add_provider(generic_0.text)
    generic_0.add_provider(generic_0.food)
    generic_0.add_provider(generic_0.science)
    generic_0.add_provider(generic_0.transport)
    generic_0.add_provider(generic_0.code)
    generic_0.add_provider(generic_0.unit_system)
    generic_0.add_provider(generic_0.file)
    generic_0.add_provider(generic_0.numbers)

# Generated at 2022-06-25 20:46:03.504341
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert(hasattr(g, 'person'))
    assert(isinstance(g.person, Person))


# Generated at 2022-06-25 20:46:07.063382
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):

        class Meta:
            name = 'sample'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def sample_method(self):
            return self.random.randint(100, 1000)

    generic = Generic()
    generic.add_provider(Provider)

    assert generic.sample.sample_method() == Provider().sample_method()



# Generated at 2022-06-25 20:46:40.327379
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Generic.address)


# Generated at 2022-06-25 20:46:51.965490
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    head = []
    for method_name in dir(Generic()):
        if not method_name.startswith('__') and method_name != 'add_provider':
            head.append(method_name)

    # test normal case
    g = Generic()
    assert set(dir(g)) == set(head)
    g.add_provider(Text)
    assert 'text' in dir(g)
    assert set(dir(g)) == set(head + ['text'])
    g.add_provider(Person)
    assert 'person' in dir(g)
    assert set(dir(g)) == set(head + ['text', 'person'])

    # test modified case
    g_ = Generic()
    g_.add_provider(Text)
    assert 'text' in dir(g_)

# Generated at 2022-06-25 20:46:56.906384
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_testcase = Generic()
    generic_testcase.add_provider(Science)
    assert getattr(generic_testcase, 'science') != None


# Generated at 2022-06-25 20:47:03.092145
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class test_provider(BaseProvider):
        class Meta:
            name = "provider"
        def method(self, a: int):
            return a
    generic_1.add_provider(test_provider)
    assert generic_1.provider.method(10) == 10
    generic_1.add_provider(test_provider)


# Generated at 2022-06-25 20:47:10.888606
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class TestProvider(BaseProvider):
        class Meta:
            # Name of the provider
            name = 'test'

    generic_0.add_provider(TestProvider)
    test_provider = getattr(generic_0, 'test')
    assert isinstance(test_provider, TestProvider)


# Generated at 2022-06-25 20:47:15.413626
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    attrname = 'person'
    res0 = generic_0.__getattr__(attrname)
    assert res0 is not None


# Generated at 2022-06-25 20:47:25.315979
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test case for __getattr__()."""
    generic = Generic()

    # Firstly, the method should return Person().
    result0 = generic.person
    assert result0.full_name() == 'Noel Durgan'

    # Secondly, the method should return Address().
    result1 = generic.address
    assert result1.postal_code() == '6921EQ'

    # Thirdly, the method should return Datetime().
    result2 = generic.datetime
    assert result2.datetime(mask='%d.%m.%Y') == '24.07.1994'

    # Fourthly, the method should return Business().
    result3 = generic.business
    assert result3.company_email() == 'he.vandervort@sauer.com'

    # Fifthly, the method should return Text().
   

# Generated at 2022-06-25 20:47:33.114946
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Address)
    assert hasattr(generic, 'address')
    generic.add_provider(Datetime)
    assert hasattr(generic, 'datetime')
    generic.add_provider(Business)
    assert hasattr(generic, 'business')
    generic.add_provider(Text)
    assert hasattr(generic, 'text')
    generic.add_provider(Food)
    assert hasattr(generic, 'food')
    generic.add_provider(Science)
    assert hasattr(generic, 'science')


# Generated at 2022-06-25 20:47:38.893487
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.dummy import DummyDictionary

    generic = Generic()
    generic.add_provider(DummyDictionary)
    assert hasattr(generic, 'dummy_dictionary')


# Generated at 2022-06-25 20:47:43.543766
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()

    assert isinstance(generic_0.__getattr__('person'), Person)



# Generated at 2022-06-25 20:48:20.042396
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(BaseProvider)
    assert generic_1.baseprovider
    assert type(generic_1.baseprovider) == BaseProvider


# Generated at 2022-06-25 20:48:24.009867
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.payment import Payment
    generic_0 = Generic()
    generic_0.add_provider(Hardware)
    assert generic_0.hardware.hdd() == 'Intel SSDSC2KK120H7'
    generic_0.add_provider(Payment)
    assert generic_0.payment.bitcoin() == '12h7bdfnAKt3qmVu8x3sJ1HjK9XBg'
    generic_0.add_provider(None)



# Generated at 2022-06-25 20:48:26.883763
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert 'person' in dir(generic)


# Generated at 2022-06-25 20:48:30.098780
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def __init__(self, *args, **kwargs):
            self.test = 'test'

    generic = Generic()
    assert not hasattr(generic, 'test')
    generic.add_provider(TestProvider)
    assert generic.test is not None


# Generated at 2022-06-25 20:48:34.560751
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class Provider_0(BaseProvider):
        class Meta:
            name = 'provider_0'

    generic_0.add_provider(Provider_0)
    assert(dir(generic_0).count('provider_0') == 1)


# Generated at 2022-06-25 20:48:39.808239
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    generic_1 = Generic()
    # The provider must be a class
    try:
        generic_1.add_provider('')
        raise AssertionError
    except TypeError:
        pass
    # The provider must be a subclass of BaseProvider
    try:
        generic_1.add_provider(Address)
        raise AssertionError
    except TypeError:
        pass



# Generated at 2022-06-25 20:48:44.802182
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    assert callable(generic_1.person)
    assert callable(generic_1.address)
    assert callable(generic_1.datetime)
    assert callable(generic_1.business)
    assert callable(generic_1.text)
    assert callable(generic_1.food)
    assert callable(generic_1.science)


# Generated at 2022-06-25 20:48:48.740225
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic(seed=123)
    generic.add_provider(CustomProvider1)
    generic.add_provider(CustomProvider2)
    assert generic.custom_provider_1.method_1() == 'method_1'
    assert generic.custom_provider_2.method_1() == 'method_1_2'


# Generated at 2022-06-25 20:48:50.281507
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    try:
        generic_0.add_provider(None)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-25 20:48:52.001529
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    test_class = Generic()
    test_class.add_provider(UnitSystem)
    assert hasattr(test_class, 'unit_system')


# Generated at 2022-06-25 20:49:32.332850
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-25 20:49:37.695133
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import sys
    import inspect

    class MyProvider(BaseProvider):
        def my_method(self):
            return 'my_data'

    try:
        generic = Generic()
        generic.add_provider(MyProvider)
        assert hasattr(generic, 'myprovider')
        assert callable(generic.myprovider.my_method)
    except:
        generic.raise_error()



# Generated at 2022-06-25 20:49:41.566196
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'
        def get_custom(self) -> None:
            pass
    generic_0.add_provider(Custom)
    assert hasattr(generic_0, 'custom')
    assert generic_0.custom.get_custom() == None


# Generated at 2022-06-25 20:49:42.673622
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.business
    generic_0.internet


# Generated at 2022-06-25 20:49:43.351779
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()



# Generated at 2022-06-25 20:49:46.030905
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'
        def some_method(self):
            return 'It works!'
    generic_0 = Generic()
    generic_0.add_provider(MyProvider)
    assert generic_0.my_provider.some_method() == 'It works!'


# Generated at 2022-06-25 20:49:51.440019
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    assert True == generic_0.add_provider(Address), 'Add provider Address'
    x = generic_0.address
    assert True == x.full_address(country='en')
    assert True == generic_0.add_provider(Choice), 'Add provider Choice'
    assert True == generic_0.choice.boolean()
    assert True == generic_0.add_provider(File), 'Add provider File'
    assert True == generic_0.file.mime_type()
    assert True == generic_0.add_provider(Payment), 'Add provider Payment'
    assert True == generic_0.payment.iban()
    assert True == generic_0.add_provider(Person), 'Add provider Person'
    assert True == generic_0.person.full_name()
    assert True

# Generated at 2022-06-25 20:49:58.571372
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.getattr('datetime')
    generic_0.getattr('person')
    generic_0.getattr('business')
    generic_0.getattr('unit_system')
    generic_0.getattr('file')
    generic_0.getattr('internet')
    generic_0.getattr('address')
    generic_0.getattr('numbers')
    generic_0.getattr('text')
    generic_0.getattr('science')
    generic_0.getattr('path')
    generic_0.getattr('development')
    generic_0.getattr('cryptographic')
    generic_0.getattr('hardware')
    generic_0.getattr('payment')
    generic_0.getattr('clothing')

# Generated at 2022-06-25 20:50:04.018417
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # create instance of class Generic
    generic = Generic()
    # add instance of class FooBarProvider to Generic
    generic.add_provider(FooBarProvider)
    # get attribute 'foobar' from instance of class Generic
    foobar_generic = generic.foobar
    # get attribute 'foobar' from instance of class FooBarProvider
    foobar_provider = FooBarProvider()
    # Check that attribute 'foobar' of instance generic
    # is instance of class FooBarProvider
    assert type(foobar_generic) == type(foobar_provider)
# create class FooBarProvider

# Generated at 2022-06-25 20:50:08.818906
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test Generic.add_provider."""
    test_class = Generic()
    test_class.add_provider(Person)
    test_class.add_provider(Address)
    test_class.add_provider(Datetime)
    test_class.add_provider(Business)
    test_class.add_provider(Text)
    test_class.add_provider(Food)
    test_class.add_provider(Science)

# Write a unit test for method add_providers of class Generic

# Generated at 2022-06-25 20:50:43.060954
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Datetime)
    assert isinstance(g.datetime, Datetime)


# Generated at 2022-06-25 20:50:47.939946
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.business import Business
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.development import Development
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.internet import Internet
    from mimesis.providers.path import Path
    from mimesis.providers.payment import Payment

    generic_1 = Generic()

    generic

# Generated at 2022-06-25 20:50:53.001002
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create Generic object
    g = Generic()
    # Create class
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'
        def foo(self):
            return 'bar'
    # Add provider
    g.add_provider(TestProvider)
    # Check if Provider is really added
    test_0 = g.test
    assert(test_0.foo() == 'bar')
    assert(test_0.bar() == 'bar')
    # Check if other providers are still OK
    assert(g.person.full_name() != '')
    assert(g.text.title() != '')
    # Check if methods didn't change
    assert(g.person.__dir__() == Person.__dir__())
    assert(g.text.__dir__() == Text.__dir__())


# Generated at 2022-06-25 20:50:54.802366
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
        test_generic = Generic()
        test_generic.add_provider(Developer)
        assert test_generic.developer.program() == 'Python'


# Generated at 2022-06-25 20:50:57.983612
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.temperature import Temperature
    generic_1 = Generic()
    generic_1.add_provider(Temperature)
    assert hasattr(generic_1, 'temperature')
    assert isinstance(generic_1.temperature, Temperature)


# Generated at 2022-06-25 20:51:01.638296
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider of Generic"""
    import mimesis.providers.automotive
    gen = Generic()
    gen.add_provider(mimesis.providers.automotive.Automotive)
    assert hasattr(gen, 'automotive')
    assert isinstance(gen.automotive, mimesis.providers.automotive.Automotive)


# Generated at 2022-06-25 20:51:03.813281
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(Custom)
    assert 'custom' in generic.__dir__()



# Generated at 2022-06-25 20:51:10.529511
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class MyProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

        class Meta:
            name = "myprovider"

        def the_answer(self):
            return 42

    generic_1.add_provider(MyProvider)

    assert len(generic_1.__dict__) == 22
    assert hasattr(generic_1, 'myprovider')

    instance_of_myprovider = generic_1.myprovider
    assert instance_of_myprovider.the_answer() == 42


# Generated at 2022-06-25 20:51:13.700866
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    meta_0 = type('Meta', (), {})
    meta_0.name = 'coin'
    class Coin(BaseProvider):
        class Meta:
            name = 'coin'
    coin_0 = Coin(seed=generic_0.seed)
    generic_0.add_provider(coin_0.__class__)



# Generated at 2022-06-25 20:51:16.984358
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.payment import Payment
    from mimesis.providers.code import Code
    from mimesis.providers.numbers import Numbers
    generic_0 = Generic()
    generic_0.add_provider(Payment)
    generic_0.add_provider(Code)
    generic_0.add_provider(Numbers)


# Generated at 2022-06-25 20:51:56.280256
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()

    Generic.__getattr__(generic_0, '_person')
    Generic.__getattr__(generic_0, '_address')
    Generic.__getattr__(generic_0, '_datetime')
    Generic.__getattr__(generic_0, '_business')
    Generic.__getattr__(generic_0, '_text')
    Generic.__getattr__(generic_0, '_food')
    Generic.__getattr__(generic_0, '_science')
    Generic.__getattr__(generic_0, 'transport')
    Generic.__getattr__(generic_0, 'code')
    Generic.__getattr__(generic_0, 'unit_system')
    Generic.__getattr__(generic_0, 'file')
    Generic.__

# Generated at 2022-06-25 20:51:56.902357
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-25 20:52:00.972560
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    try:
        result___getattr__ = generic_0.__getattr__(
            'person')
    except Exception as e:
        print('Exception: {}'.format(e))
    else:
        print('Success, the result is: {}'.format(
            result___getattr__))


# Generated at 2022-06-25 20:52:03.705067
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    attribute = generic_0.internet
    assert isinstance(attribute, BaseProvider)

# Generated at 2022-06-25 20:52:05.653629
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    Generic_0 = Generic()
    Generic_0.add_provider(numbers)
    Generic_0.add_provider((UnitSystem))
    Generic_0.add_provider(numbers)


# Generated at 2022-06-25 20:52:08.637176
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def __init__(self, seed=None):
            super().__init__(seed)

    custom = CustomProvider()
    generic_0 = Generic()

    generic_0.add_provider(custom)

    assert isinstance(generic_0.custom, CustomProvider)



# Generated at 2022-06-25 20:52:11.297093
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        def foo(self):
            return 'foo'

    generic_0 = Generic()
    assert not hasattr(generic_0, 'custom')
    generic_0.add_provider(Custom)
    assert hasattr(generic_0, 'custom')
    foo = generic_0.custom.foo()
    assert foo == 'foo'



# Generated at 2022-06-25 20:52:13.702757
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    custom_provider = type(str('CustomProvider'), (BaseProvider,), {})
    generic_1.add_provider(custom_provider)
    assert isinstance(generic_1, Generic)
    assert isinstance(generic_1.customprovider, custom_provider)



# Generated at 2022-06-25 20:52:19.923592
# Unit test for method __getattr__ of class Generic