

# Generated at 2022-06-25 20:42:44.183765
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_cases = [((), {}, AttributeError)]
    for test_case in test_cases:
        assert_test(test_Generic___getattr__, *test_case[0],
                    **test_case[1])()


# Generated at 2022-06-25 20:42:47.336020
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'
    generic_0.add_provider(Custom)
    assert hasattr(generic_0, 'custom')


# Generated at 2022-06-25 20:42:50.799414
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    # Check if custom_provider is correct
    generic.add_provider(CustomProvider)
    # Check if provider exists
    print(generic.custom_provider)


# Generated at 2022-06-25 20:42:53.126799
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_ = Generic()
    generic_.add_provider(Clothing)
    generic_.add_provider(Internet)


# Generated at 2022-06-25 20:42:56.686847
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            return 'Bar'

    generic_1 = Generic()
    generic_1.add_provider(CustomProvider)
    assert generic_1.custom_provider.foo() == 'Bar'


# Generated at 2022-06-25 20:43:06.704965
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    # Check method __getattr__ from class Generic
    assert generic_0.person is not None
    assert generic_0.address is not None
    assert generic_0.datetime is not None
    assert generic_0.business is not None
    assert generic_0.text is not None
    assert generic_0.food is not None
    assert generic_0.science is not None
    assert generic_0.transport is not None
    assert generic_0.code is not None
    assert generic_0.unit_system is not None
    assert generic_0.file is not None
    assert generic_0.numbers is not None
    assert generic_0.development is not None
    assert generic_0.hardware is not None
    assert generic_0.clothing is not None
    assert generic_0.internet

# Generated at 2022-06-25 20:43:09.648024
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test case with all fields
    gen = Generic(seed=1, locale=None)
    assert all(
        getattr(gen, name) for name in dir(Generic) if '_' not in name)



# Generated at 2022-06-25 20:43:11.129781
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.address.address() == 'Bungalow, Rainforest, Zone D'

# Generated at 2022-06-25 20:43:15.846321
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class _Test0(BaseProvider):
        def foo(self):
            return self.random.random()

    generic.add_provider(_Test0)
    assert generic.test0.foo() != None


# Generated at 2022-06-25 20:43:23.978732
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider0(BaseProvider):
        class Meta:
            name = 'custom_provider_0'

        def method_0(self):
            return 'result_0'
    class CustomProvider1(BaseProvider):
        class Meta:
            name = 'custom_provider_1'

        def method_1(self):
            return 'result_1'

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider0)
    generic_0.add_provider(CustomProvider1)
    assert generic_0.custom_provider_0.method_0() == 'result_0'
    assert generic_0.custom_provider_1.method_1() == 'result_1'
