

# Generated at 2022-06-25 20:42:43.610343
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)



# Generated at 2022-06-25 20:42:47.646494
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Check adding custom provider to Generic() object."""
    class Custom(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def method(self):
            return 'lol'

    g = Generic()
    g.add_provider(Custom)
    assert g.custom.method() == 'lol'



# Generated at 2022-06-25 20:42:50.428256
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Business)
    assert hasattr(generic_1, 'business') is True


# Generated at 2022-06-25 20:42:52.381474
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().__getattr__("address") == Generic()._address(
        Generic().seed
    )


# Generated at 2022-06-25 20:42:55.703294
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('choice')
    str_0 = generic_0.choice.random()

    # Test attribute '_choice'
    assert str_0 == 'H'


# Generated at 2022-06-25 20:42:57.132310
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)



# Generated at 2022-06-25 20:43:00.555168
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    try:
        generic_0.__getattr__('_person')
    except AttributeError:
        assert True
    else:
        assert False



# Generated at 2022-06-25 20:43:09.964863
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic(seed=1)
    if generic_0.address:
        generic_0.address
    if generic_0.business:
        generic_0.business
    if generic_0.code:
        generic_0.code
    if generic_0.clothing:
        generic_0.clothing
    if generic_0.cryptographic:
        generic_0.cryptographic
    if generic_0.datetime:
        generic_0.datetime
    if generic_0.development:
        generic_0.development
    if generic_0.file:
        generic_0.file
    if generic_0.food:
        generic_0.food
    if generic_0.hardware:
        generic_0.hardware
    if generic_0.internet:
        generic_0.internet

# Generated at 2022-06-25 20:43:16.004740
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    # Test for raise TypeError:
    try:
        generic_0.add_provider(None)
    except TypeError:
        pass
    # Test for raise TypeError:
    try:
        generic_0.add_provider(BaseProvider)
    except TypeError:
        pass
    # Test for set attribute 'Custom' and create instance of Custom:
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'

    generic_0.add_provider(Custom)
    assert hasattr(generic_0, 'custom')
    assert isinstance(generic_0.custom, Custom)

# Generated at 2022-06-25 20:43:18.266528
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """TestCase for testing __getattr__"""
    # generic_1 = Generic()
    # assert(generic_1.__getattr__('person') == Person(locale='en'))