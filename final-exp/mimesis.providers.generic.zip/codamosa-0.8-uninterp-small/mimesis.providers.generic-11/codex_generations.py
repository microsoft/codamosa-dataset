

# Generated at 2022-06-25 20:42:49.998037
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    cls = Generic()
    assert cls.person
    assert cls.datetime
    assert cls.address
    assert cls.business
    assert cls.text
    assert cls.food
    assert cls.science
    assert cls.transport
    assert cls.code
    assert cls.unit_system
    assert cls.file
    assert cls.numbers
    assert cls.development
    assert cls.hardware
    assert cls.clothing
    assert cls.internet
    assert cls.path
    assert cls.payment
    assert cls.cryptographic
    assert cls.structure
    assert cls.choice


# Generated at 2022-06-25 20:42:59.431653
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """
    Test __getattr__
    """
    generic_0 = Generic()
    generic_0_address_0 = generic_0.address
    assert generic_0.address == generic_0_address_0
    generic_0_address_1 = generic_0.address
    assert generic_0.address == generic_0_address_1
    generic_0_address_2 = generic_0.address
    assert generic_0.address == generic_0_address_2
    generic_0_address_3 = generic_0.address
    assert generic_0.address == generic_0_address_3
    generic_0_address_4 = generic_0.address
    assert generic_0.address == generic_0_address_4


# Generated at 2022-06-25 20:43:03.658651
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class MyProvider(BaseProvider):
        class Meta:
            name = 'test'
        def foo(self):
            return 'foo'
    generic_0.add_provider(MyProvider)
    assert generic_0.test.foo() == 'foo'


# Generated at 2022-06-25 20:43:12.828712
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # test for generic_0
    generic_0 = Generic()
    generic_0_return = generic_0.address
    assert generic_0_return != 'None'
    generic_0_return = generic_0.business
    assert generic_0_return != 'None'
    generic_0_return = generic_0.clothing
    assert generic_0_return != 'None'
    generic_0_return = generic_0.code
    assert generic_0_return != 'None'
    generic_0_return = generic_0.cryptographic
    assert generic_0_return != 'None'
    generic_0_return = generic_0.datetime
    assert generic_0_return != 'None'
    generic_0_return = generic_0.development
    assert generic_0_return != 'None'
    generic_0_

# Generated at 2022-06-25 20:43:18.086081
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        generic = Generic()
        generic.add_provider(BaseProvider)
    except TypeError as e:
        assert str(e) == 'The provider must be a subclass of BaseProvider'



# Generated at 2022-06-25 20:43:27.954108
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person())
    generic_0.add_provider(Address())
    generic_0.add_provider(Datetime())
    generic_0.add_provider(Business())
    generic_0.add_provider(Text())
    generic_0.add_provider(Food())
    generic_0.add_provider(Science())
    generic_0.add_provider(Transport())
    generic_0.add_provider(Code())
    generic_0.add_provider(UnitSystem())
    generic_0.add_provider(File())
    generic_0.add_provider(Numbers())
    generic_0.add_provider(Development())
    generic_0.add_provider(Hardware())
    generic_0.add

# Generated at 2022-06-25 20:43:32.062955
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):

        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'Hello, World!'

    generic = Generic()
    generic.add_provider(CustomProvider)
    result = generic.custom_provider.foo()
    assert result is not None


# Generated at 2022-06-25 20:43:33.193392
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert(generic_0.person)


# Generated at 2022-06-25 20:43:35.282594
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.payment import Payment
    generic_0 = Generic()
    generic_0.add_provider(Payment)
    assert 'payment' in dir(generic_0)

# Generated at 2022-06-25 20:43:36.992335
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    assert generic_0.person.__class__ == Person


# Generated at 2022-06-25 20:44:07.023305
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class TestProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed)
            self.test_field = 'tested'

    generic_1.add_provider(TestProvider)
    assert generic_1.test_provider.test_field == 'tested'


# Generated at 2022-06-25 20:44:13.884423
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class User():
        class Meta():
            name = 'user'
    user = User()
    if not isinstance(generic_1,Generic):
        assert False
    if not isinstance(user,User):
        assert False
    if isinstance(generic_1.user,User):
        assert False
    generic_1.add_provider(User)
    if isinstance(generic_1.user,User):
        assert True
    else:
        assert False
    if not isinstance(User,BaseProvider):
        assert False
    class Wrong():
        class Meta():
            name = 'wrong'
    wrong = Wrong()
    if isinstance(generic_1.wrong,Wrong):
        assert False

# Generated at 2022-06-25 20:44:22.187216
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyTestProvider(BaseProvider):
        class Meta:
            name = 'mytestprovider'

        def foo(self, input: str) -> str:

            return f"MyTestProvider is working with {input}"

    class MyTestProvider2(BaseProvider):
        class Meta:
            name = 'mytestprovider2'

        def bar(self, input: str) -> str:

            return f"MyTestProvider2 is working with {input}"

    generic_1 = Generic()
    generic_1.add_provider(MyTestProvider)
    assert (generic_1.mytestprovider.foo('foo')) == "MyTestProvider is working with foo"

    generic_2 = Generic()
    generic_2.add_provider(MyTestProvider2)

# Generated at 2022-06-25 20:44:25.817029
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(MyProvider)
    assert 'myprovider' in dir(generic)



# Generated at 2022-06-25 20:44:35.286467
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    def test_provider(BaseProvider):
        class CustomProvider(BaseProvider):
            class Meta:
                name = 'my_provider'

            @staticmethod
            def my_method():
                return 'Foo'

        return CustomProvider

    g.add_provider(test_provider(BaseProvider))

    assert g.my_provider.my_method() == 'Foo'



# Generated at 2022-06-25 20:44:38.832260
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class CustomProvider(BaseProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)
    generic.add_provider(CustomProvider)
    assert hasattr(generic, "customprovider")
    assert isinstance(getattr(generic, "customprovider"), CustomProvider)
    assert generic.customprovider.seed == generic.seed


# Generated at 2022-06-25 20:44:50.535038
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    var_0 = generic_0.person.full_name()
    var_1 = generic_0.food.fruit()
    var_2 = generic_0.business.company()
    var_3 = generic_0.address.address()
    var_4 = generic_0.datetime.date()
    var_5 = generic_0.datetime.datetime()
    var_6 = generic_0.datetime.datetime_string()
    var_7 = generic_0.datetime.date_string()
    var_8 = generic_0.datetime.time()
    var_9 = generic_0.datetime.time_string()
    var_10 = generic_0.person.title_male()
    var_11 = generic_0.person.name_male()
    var_

# Generated at 2022-06-25 20:44:53.186000
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)


# Generated at 2022-06-25 20:44:56.390222
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    assert isinstance(generic_0, Generic)
    generic_0.add_provider(Person)
    assert isinstance(generic_0.person, Person)

# Generated at 2022-06-25 20:45:00.368836
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    try:
        generic_1.add_provider(BaseProvider)
    except TypeError:
        pass


# Generated at 2022-06-25 20:45:26.720246
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.person, Person)
    assert isinstance(generic_0.address, Address)
    assert isinstance(generic_0.datetime, Datetime)
    assert isinstance(generic_0.business, Business)
    assert isinstance(generic_0.text, Text)
    assert isinstance(generic_0.food, Food)
    assert isinstance(generic_0.science, Science)

# Generated at 2022-06-25 20:45:34.241969
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()

    class MyProvider(BaseProvider):
        class Meta:
            name = "myprovider"

        def foo(self):
            return "bar"
    generic_0.add_provider(MyProvider)
    assert generic_0.myprovider.foo() == "bar"



# Generated at 2022-06-25 20:45:40.181940
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    generic_0 = Generic()
    assert generic_0.person.full_name() == 'Nina Mendez'
    assert generic_0.address.address() == '2074 W. South Street'
    assert generic_0.datetime.datetime() == '2018-04-18T03:28:41'
    assert generic_0.business.company() == 'Tailored, Jones'
    assert generic_0.text.slug() == 'qui-fugit-a'
    assert generic_0.food.ingredient() == 'quae'
    assert generic_0.science.element_symbol() == '12'
    assert generic_0.transport.vehicle() == 'express'
    assert generic_0.code.isbn() == '8293350-2'
    assert generic_0.unit_

# Generated at 2022-06-25 20:45:43.263912
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for adding a custom provider to Generic() object."""
    generic = Generic()
    generic.add_provider(Person)



# Generated at 2022-06-25 20:45:46.907233
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.address import Address

    a = Generic()
    c = Generic()
    a.add_provider(Address)
    assert hasattr(a, 'address')
    assert id(a) != id(c)


# Generated at 2022-06-25 20:45:57.544319
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Testing method add_provider of class Generic."""
    # Test with normal input
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert generic_1.person is not None
    # Test with class not subclass of BaseProvider
    generic_2 = Generic()
    try:
        generic_2.add_provider(Generic)
    except TypeError:
        assert True
    # Test with not a class input
    generic_3 = Generic()
    try:
        generic_3.add_provider('Person')
    except TypeError:
        assert True


# Generated at 2022-06-25 20:45:59.497488
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    info = Generic()
    info.add_provider(Code)
    x = Code(seed=info.seed)
    assert info.code.__dir__() == x.__dir__()



# Generated at 2022-06-25 20:46:01.805564
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    address = Address(seed=0)
    generic_add_provider_obj = Generic(seed=0)
    generic_add_provider_obj.add_provider(address.__class__)
    assert generic_add_provider_obj.address.__class__ == address.__class__



# Generated at 2022-06-25 20:46:05.425326
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    assert(hasattr(generic_0, "person"))
    assert(not hasattr(generic_0, "any_provider"))
    generic_0.add_provider(Payment)
    assert(hasattr(generic_0, "any_provider"))


# Generated at 2022-06-25 20:46:08.944710
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'
    assert 'test_provider' not in dir(generic_1)
    generic_1.add_provider(TestProvider)
    assert 'test_provider' in dir(generic_1)


# Generated at 2022-06-25 20:46:30.971553
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Chinese(BaseProvider):
        class Meta:
            name = 'Chinese'
        def china_name(self):
            return '中文名'
    generic = Generic()
    generic.add_provider(Chinese)
    chinese = generic.chinese
    assert chinese.china_name() == '中文名'


# Generated at 2022-06-25 20:46:32.611795
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(BaseProvider)
    assert(generic_0.baseprovider is not None)


# Generated at 2022-06-25 20:46:38.444636
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person(), Person)
    assert isinstance(generic.datetime(), Datetime)
    assert isinstance(generic.business(), Business)
    assert isinstance(generic.text(), Text)
    assert isinstance(generic.food(), Food)
    assert isinstance(generic.science(), Science)
    assert isinstance(generic.transport(), Transport)
    assert isinstance(generic.code(), Code)
    assert isinstance(generic.unit_system(), UnitSystem)
    assert isinstance(generic.file(), File)
    assert isinstance(generic.numbers(), Numbers)
    assert isinstance(generic.development(), Development)
    assert isinstance(generic.hardware(), Hardware)
    assert isinstance(generic.clothing(), Clothing)
    assert isinstance(generic.internet(), Internet)
    assert isinstance