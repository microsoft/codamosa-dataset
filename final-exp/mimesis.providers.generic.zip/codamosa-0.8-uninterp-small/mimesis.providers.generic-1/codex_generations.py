

# Generated at 2022-06-25 20:42:38.493627
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_1 = Generic()
    provider_0 = generic_1.choice
    assert isinstance(provider_0, Choice)


# Generated at 2022-06-25 20:42:39.953492
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.person
    generic_0.person.full_name


# Generated at 2022-06-25 20:42:46.375585
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # testing with an attribute that doesn't exist
    generic_0 = Generic()
    try:
        generic_0.__getattr__("doesnotexist")
    except Exception as inst:
        if type(inst) is AttributeError:
            pass
        else:
            assert False
    # testing with an attribute that exists and is not a callable
    try:
        generic_0.__getattr__("clothing")
    except Exception as inst:
        if type(inst) is AttributeError:
            pass
        else:
            assert False


# Generated at 2022-06-25 20:42:48.275365
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Address)
    assert generic_0.address_line


# Generated at 2022-06-25 20:42:50.695808
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('person')


# Generated at 2022-06-25 20:42:53.879313
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.person.__doc__ == Person.__doc__
    assert generic_0.internet.__doc__ == Internet().__doc__


# Generated at 2022-06-25 20:42:55.968374
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    try:
        generic_0.person
    except AttributeError:
        pass



# Generated at 2022-06-25 20:43:00.988450
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    class MyPerson(Person):
        @staticmethod
        def gender() -> Gender:
            return Gender.MALE

    generic_0 = Generic()
    generic_0.add_provider(MyPerson)
    assert generic_0.person.gender() == Gender.MALE



# Generated at 2022-06-25 20:43:04.799517
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(MethodProvider)
    generic_method = MethodProvider(seed=generic.seed)
    getattr(MethodProvider, 'method_1')
    assert generic.method_1 == generic_method.method_1


# Generated at 2022-06-25 20:43:06.469011
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime

