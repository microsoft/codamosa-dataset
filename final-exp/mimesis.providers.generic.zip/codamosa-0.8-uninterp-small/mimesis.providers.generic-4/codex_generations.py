

# Generated at 2022-06-25 20:42:46.173442
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create Generic object
    generic_0 = Generic()
    # Execute method add_provider with argument PersonalData
    generic_0.add_provider(Person)
    assert hasattr(generic_0, 'person')
    # Execute method add_provider with argument BaseProvider
    generic_0.add_provider(BaseProvider)
    assert hasattr(generic_0, 'base')
    # Execute method add_provider with argument BaseDataProvider
    generic_0.add_provider(BaseDataProvider)
    assert hasattr(generic_0, 'basedata')


# Generated at 2022-06-25 20:42:56.507794
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    generic_0 = Generic()

    # Init test values
    expect_0 = "Peggy"
    actual_0 = generic_0.person.full_name()
    # Check assert
    assert expect_0 == actual_0, "{0} != {1}".format(expect_0, actual_0)

    # Init test values
    expect_0 = "Oliver"
    actual_0 = generic_0.person.name()
    # Check assert
    assert expect_0 == actual_0, "{0} != {1}".format(expect_0, actual_0)

    # Init test values
    expect_0 = "Sofia"
    actual_0 = generic_0.person.surname()
    # Check assert

# Generated at 2022-06-25 20:43:06.558493
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Case 0. Test for correct work of method.
    generic_0 = Generic()
    assert generic_0.name()
    assert generic_0.surname()
    assert generic_0.patronymic()
    assert generic_0.sex()
    assert generic_0.email()
    assert generic_0.username()
    assert generic_0.telephone()
    assert generic_0.building_number()
    assert generic_0.street_suffix()
    assert generic_0.city()
    assert generic_0.region()
    assert generic_0.country()
    assert generic_0.postal_code()
    assert generic_0.latitude()
    assert generic_0.longitude()
    assert generic_0.timezone()
    assert generic_0.year()
    assert generic_0.date()

# Generated at 2022-06-25 20:43:15.846424
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        """Test provider."""

        class Meta:
            """Metadata."""

            name = "test"

        def __str__(self) -> str:
            """Convert Test to string."""
            return self.text.word()

    class OtherTest(BaseProvider):
        """Other test provider."""

        class Meta:
            """Metadata."""

            name = "other_test"

        def __str__(self) -> str:
            """Convert OtherTest to string."""
            return self.text.word()

    gen = Generic()
    gen.add_provider(Test)
    assert isinstance(gen.test, Test)

    gen.add_provider(OtherTest)
    assert isinstance(gen.test, Test)

# Generated at 2022-06-25 20:43:17.213307
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # TODO: rewrite test
    generic = Generic()
    generic.__getattr__('name')

# Generated at 2022-06-25 20:43:18.301785
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().__getattr__("_person")


# Generated at 2022-06-25 20:43:23.160844
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert_str(generic_0.bit_int)
    assert_str(generic_0.captcha)
    assert_str(generic_0.hex_color)
    assert_str(generic_0.ipv6)
    assert_str(generic_0.key)
    assert_str(generic_0.mac_address)



# Generated at 2022-06-25 20:43:26.086673
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Text)
    assert generic_0.text.__class__.__name__ == 'Text'


# Generated at 2022-06-25 20:43:34.332827
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print('test_Generic___getattr__')
    generic_0 = Generic()

    # test data provider address
    generic_0.__getattr__('address').__getattribute__('city')
    generic_0.__getattr__('address').__getattribute__('country')
    generic_0.__getattr__('address').__getattribute__('region')
    generic_0.__getattr__('address').__getattribute__('latitude')
    generic_0.__getattr__('address').__getattribute__('longitude')
    generic_0.__getattr__('address').__getattribute__('district')
    generic_0.__getattr__('address').__getattribute__('postal_code')
    generic_0.__getattr__('address').__getattribute__('street_name')
    generic_0

# Generated at 2022-06-25 20:43:35.682494
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.person, Person)


# Generated at 2022-06-25 20:43:59.460849
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'my_provider'

        def foo(self):
            return 'bar'

    generic_0 = Generic()
    # test the method
    generic_0.add_provider(MyProvider)
    assert hasattr(generic_0, 'my_provider')
    assert hasattr(generic_0.my_provider, 'foo')
    assert generic_0.my_provider.foo() == 'bar'



# Generated at 2022-06-25 20:44:01.658322
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class ProviderTest(BaseProvider):
        class Meta:
            name = 'provider_test'

    generic.add_provider(ProviderTest)
    assert 'provider_test' in dir(generic)


# Generated at 2022-06-25 20:44:08.045044
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyClass:
        class Meta:
            name = 'my_class'

        def __init__(self, seed: int = None, use_cache: bool = False):
            super().__init__(seed, use_cache)

        def get_data(self, *args, **kwargs):
            pass

    generic_0 = Generic()
    generic_0.add_provider(MyClass)


# Generated at 2022-06-25 20:44:11.784623
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        generic = Generic()
        generic.add_provider(Text)
        assert generic.text
    except Exception as e:
        raise e



# Generated at 2022-06-25 20:44:16.199454
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    obj = Generic()
    import mimesis.providers.company
    obj.add_provider(mimesis.providers.company.Company)
    assert "Company" in dir(generic)


# Generated at 2022-06-25 20:44:22.864750
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a new instance of Generic class
    generic = Generic()
    # Create a custom class
    class Foo(BaseProvider):
        def bar(self):
            return 'This is bar method'
    # Add custom provider
    generic.add_provider(Foo)
    # Create instance of custom class
    foo = Foo()
    # Check that custom class is added
    assert foo.bar() == generic.foo.bar()
    # Check that method add_provider doesn't add not BaseProvider subclass
    class NotBase(object):
        pass
    with pytest.raises(TypeError):
        generic.add_provider(NotBase)
    class NotBaseProvider(BaseProvider):
        pass
    with pytest.raises(TypeError):
        generic.add_provider(NotBaseProvider)


# Generated at 2022-06-25 20:44:26.559155
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()

    class CustomProvider(BaseProvider):
        def foo(self):
            return 'bar'

    generic.add_provider(CustomProvider)

    assert generic.custom_provider.foo() == 'bar'


# Generated at 2022-06-25 20:44:31.968269
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Mock(BaseProvider):
        class Meta:
            name = 'mock'

    generic = Generic()
    generic.add_provider(Mock)
    assert generic.__dict__['mock'] != None 


# Generated at 2022-06-25 20:44:35.090318
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import Development
    generic_0 = Generic()
    generic_0.add_provider(Development)


# Generated at 2022-06-25 20:44:38.543339
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert 'locale' in dir(gen)
    assert 'seed' in dir(gen)
    assert 'address' in dir(gen)
    assert 'person' in dir(gen)
    assert 'business' in dir(gen)
    assert 'text' in dir(gen)
    assert 'datetime' in dir(gen)



# Generated at 2022-06-25 20:44:52.262561
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a Generic object
    generic_0 = Generic()

    # Add a custom provider to Generic() object
    generic_0.add_provider(Generic)


# Generated at 2022-06-25 20:44:56.962256
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # initialization
    generic_1 = Generic()
    # operation
    generic_1.person.name()
    # verification
    assert generic_1.person

    # initialization
    generic_2 = Generic()
    # operation
    generic_2.address.street_name()
    # verification
    assert generic_2.address


# Generated at 2022-06-25 20:45:05.418911
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.seed = '1'
    class TestProvider(BaseProvider):
        def __init__(self):
            super().__init__()

        def foo(self):
            return 'bar'

    generic.add_provider(TestProvider)
    assert generic.test.foo() == 'bar'
    generic.seed = '2'
    assert generic.test.foo() == 'bar'


# Generated at 2022-06-25 20:45:09.193852
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.business import Business
    from mimesis.providers.transport import Transport
    from mimesis.providers.date import Datetime
    from mimesis.providers.payment import Payment

    generic = Generic()

    for provider in (Person, Internet, Business, Transport, Datetime, Payment):
        generic.add_provider(provider)



# Generated at 2022-06-25 20:45:18.737446
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()

    assert isinstance(generic_0, Generic)
    assert isinstance(generic_0.person, Person)
    assert isinstance(generic_0.address, Address)
    assert isinstance(generic_0.datetime, Datetime)
    assert isinstance(generic_0.business, Business)
    assert isinstance(generic_0.text, Text)
    assert isinstance(generic_0.food, Food)
    assert isinstance(generic_0.science, Science)
    assert isinstance(generic_0.transport, Transport)
    assert isinstance(generic_0.code, Code)
    assert isinstance(generic_0.unit_system, UnitSystem)
    assert isinstance(generic_0.file, File)
    assert isinstance(generic_0.numbers, Numbers)
    assert isinstance

# Generated at 2022-06-25 20:45:23.849527
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)
    assert hasattr(generic_1, 'person')
    assert isinstance(generic_1.person, Person)


# Generated at 2022-06-25 20:45:30.919108
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class MyProvider(BaseProvider):
        class Meta:
            name = 'MyProvider'
        def foo(self):
            return 'bar'

    generic_1.add_provider(MyProvider)
    assert generic_1.MyProvider().foo() == 'bar'
    generic_1 = Generic()

    class Provider1(BaseProvider):
        class Meta:
            name = 'Provider 1'
        def bar(self):
            return 'foo'

    class Provider2(BaseProvider):
        class Meta:
            name = 'Provider 2'
        def foo(self):
            return 'bar'

    generic_1.add_providers(Provider1, Provider2)
    assert generic_1.Provider1().bar() == 'foo'
    assert generic_1.Provider2().foo() == 'bar'

# Generated at 2022-06-25 20:45:35.506491
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    result = generic_0.get_provider_name()
    assert result == 'generic', \
        'Expected: {}, but got: {}'.format('generic', result)


# Generated at 2022-06-25 20:45:36.832426
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert callable(Generic.__getattr__)
    assert not hasattr(Generic, 'Meta')


# Generated at 2022-06-25 20:45:41.328444
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    my_provider = Generic()
    my_provider.add_provider(CustomProvider)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 20:45:58.809271
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Generic
    from mimesis.providers.base import BaseProvider

    class C(BaseProvider): pass
    class D(BaseProvider): pass
    g = Generic()
    g.add_provider(C)
    g.add_provider(D)
    assert hasattr(g, 'c')
    assert hasattr(g, 'd')


# Generated at 2022-06-25 20:46:04.005248
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    from mimesis.providers.color import Color

    class Pink(Color):
        """A subclass of Color which contains the pink color only."""

        def __init__(self, seed: int = None) -> None:
            """Initialize a provider.

            :param seed: Seed.
            """
            super().__init__(seed=seed)

            self.__pink = [
                '#FFECB3',
                '#FFC0CB',
                '#D72638',
                '#FFC0CB',
            ]

        @property
        def pink(self) -> str:
            """Get a random pink color.

            :return: Pink color as string.
            """
            return self._random.choice(self.__pink)


# Generated at 2022-06-25 20:46:05.788675
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    res = g.person.full_name()
    assert isinstance(res, str)
    assert g.person.full_name() == res


# Generated at 2022-06-25 20:46:13.653899
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.person is not None
    assert gen.address is not None
    assert gen.datetime is not None
    assert gen.business is not None
    assert gen.text is not None
    assert gen.food is not None
    assert gen.science is not None
    assert gen.transport is not None
    assert gen.code is not None
    assert gen.unit_system is not None
    assert gen.file is not None
    assert gen.numbers is not None
    assert gen.development is not None
    assert gen.hardware is not None
    assert gen.clothing is not None
    assert gen.internet is not None
    assert gen.path is not None
    assert gen.payment is not None
    assert gen.cryptographic is not None
    assert gen.structure is not None

# Generated at 2022-06-25 20:46:17.717556
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    car_provider: Type[BaseProvider] = Transport

    generic_0 = Generic()
    generic_0.add_provider(car_provider)

    car: Transport = generic_0.transport

    assert car is not None


# Generated at 2022-06-25 20:46:18.878922
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Code)
    assert generic.code is not None


# Generated at 2022-06-25 20:46:26.752890
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Setup
    custom_cls = Person(locale="en")
    generic = Generic()

    # Act
    generic.add_provider(custom_cls)

    # Verify
    assert isinstance(generic.person, Person)
    assert generic.person.__dict__ == custom_cls.__dict__


# Generated at 2022-06-25 20:46:28.569740
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    from mimesis.providers.python import Python
    generic_0.add_provider(Python)
    assert generic_0.python.random_int(0, 6) == generic_0.choice.random_int(0, 6)


# Generated at 2022-06-25 20:46:32.618821
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    # Unit test case 0
    # Test when provider is a class
    class Provider0(BaseProvider):
        class Meta:
            name = 'provider0'

        def foo(self):
            return 'bar'

    generic_0 = Generic()
    generic_0.add_provider(Provider0)
    assert generic_0.provider0.foo() == 'bar'

    # Unit test case 1
    # Test when provider is not a class
    generator_1 = Generic()
    try:
        generator_1.add_provider('not-a-class')
    except TypeError:
        assert True
        return
    assert False


# Generated at 2022-06-25 20:46:33.558951
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()


# Generated at 2022-06-25 20:46:50.778605
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'
        def __init__(self):
            super().__init__()
    generic.add_provider(TestProvider)
    assert hasattr(generic, 'test')


# Generated at 2022-06-25 20:46:56.906397
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    custom_provider = Generic()
    custom_provider.add_provider(CustomProvider)
    assert hasattr(custom_provider, 'custom_provider')
    assert not hasattr(custom_provider, 'customprovider')


# Generated at 2022-06-25 20:47:01.196181
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'test_method'

    test_generic = Generic()
    test_generic.add_provider(TestProvider)
    assert test_generic.test_provider.test_method() == 'test_method'

# Generated at 2022-06-25 20:47:05.998519
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    assert isinstance(generic_0.__dict__['Person'], BaseProvider)


# Generated at 2022-06-25 20:47:10.862774
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

    generic = Generic()
    generic.add_provider(TestProvider)
    assert 'test_provider' in generic.__dir__()



# Generated at 2022-06-25 20:47:19.524025
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    @BaseProvider.register('test')
    class TestClass(BaseProvider):
        """Test provider."""

        class Meta:
            """The name of provider."""

            name = 'test'

        def name(self) -> str:
            return 'Test'

    generic = Generic()
    generic.add_provider(TestClass)
    assert generic.test.name() == 'Test'



# Generated at 2022-06-25 20:47:21.868737
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Provider)

if __name__ == '__main__':
    test_Generic_add_provider()

# Generated at 2022-06-25 20:47:32.907247
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'my_provider'

        def my_method(self):
            return 'my_method'

    generator_0 = Generic()

    generator_0.add_provider(MyProvider)

    assert isinstance(generator_0.my_provider, MyProvider)

    assert isinstance(generator_0.my_provider.my_method(), str)

    assert generator_0.my_provider.my_method() == 'my_method'


# Generated at 2022-06-25 20:47:37.751492
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.fake import Fake

    generic = Generic()
    generic.add_provider(Fake)
    assert hasattr(generic, 'fake')


# Generated at 2022-06-25 20:47:44.110763
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Constructor of class Generic
    generic = Generic()
    # Case 0: add_provider(cls: Type[BaseProvider])
    generic.add_provider(Generic)
    assert generic.generic is not None


# Generated at 2022-06-25 20:48:10.035930
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    class CustomProvider(BaseProvider):
        def method_foo(self):
            return 1
            
        def method_bar(self):
            return 1.1
    generic_0.add_provider(CustomProvider)
    generic_0.custom_provider.method_foo()
    generic_0.custom_provider.method_bar()
    generic_0.custom_provider.method_foo()


# Generated at 2022-06-25 20:48:11.912754
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Person)


# Generated at 2022-06-25 20:48:18.997886
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'

        def an_instance_method(self):
            return 'This is an instance method'

        @classmethod
        def a_class_method(cls):
            return 'This is a class method'

    generic_1.add_provider(Provider)

    assert generic_1.provider.an_instance_method() == 'This is an instance method'
    assert generic_1.provider.a_class_method() == 'This is a class method'


# Generated at 2022-06-25 20:48:20.131195
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_1 = Generic()
    generic_0.person == generic_1.person

# Generated at 2022-06-25 20:48:21.878485
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

    generic_1 = Generic()
    generic_1.add_provider(CustomProvider)
    assert generic_1.custom

# Generated at 2022-06-25 20:48:27.740349
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert 'business' not in dir(generic)

    class BusinessProvider(BaseProvider):
        pass

    generic.add_provider(BusinessProvider)
    assert 'business' in dir(generic)


# Generated at 2022-06-25 20:48:29.042423
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert "person" in dir(generic)
    assert generic.person



# Generated at 2022-06-25 20:48:34.154666
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create class CustomProvider
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def example_method(self) -> str:
            return 'example method'

    # Create Generic object
    generic = Generic()

    # Add custom provider to Generic
    generic.add_provider(CustomProvider)

    # Check if provider exists
    assert hasattr(generic, 'custom')

    # Check method of custom provider
    assert generic.custom.example_method() == 'example method'



# Generated at 2022-06-25 20:48:40.920755
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    This function is for testing the method add_provider of class Generic
    with different input and check if it works properly

    """
    from mimesis.providers.network import Network as nw
    nw.Meta.class_name = 'Network'
    nw.Meta.name = 'network'
    generic_1 = Generic()
    assert hasattr(generic_1,'network') == False

    generic_1.add_provider(nw)
    assert hasattr(generic_1,'network') == True
    assert type(generic_1.network.ipv6_address()) == str
    assert type(generic_1.network.ipv6_network()) == str



# Generated at 2022-06-25 20:48:48.813215
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # test when attrname is person.
    generic_0 = Generic()
    generic_0.person

    # test when attrname is address.
    generic_1 = Generic()
    generic_1.address

    # test when attrname is datetime.
    generic_2 = Generic()
    generic_2.datetime

    # test when attrname is business.
    generic_3 = Generic()
    generic_3.business

    # test when attrname is text.
    generic_4 = Generic()
    generic_4.text

    # test when attrname is food.
    generic_5 = Generic()
    generic_5.food

    # test when attrname is science.
    generic_6 = Generic()
    generic_6.science



# Generated at 2022-06-25 20:49:40.144685
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Add a custom provider to Generic() object."""
    # Create a generic object
    generic_0 = Generic()
    # Create a custom provider
    Generic.add_provider(generic_0,
                         CustomProvider)
    # Create a generic object
    generic_1 = Generic()
    # Create a custom provider
    generic_1.add_provider(
        CustomProvider)
    # Assertion
    assert "customprovider" in generic_0.__dict__.keys()
    assert "customprovider" in generic_1.__dict__.keys()


# Generated at 2022-06-25 20:49:44.136571
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_ = Generic()
    # Creating class with structure Meta
    class New_Class(BaseProvider):
        class Meta:
            name = 'new_class'
        def __init__(self, seed=None):
            super().__init__(seed=seed)
        def method(self):
            return 'return_value'
    # Check that attributes of 'new_class' are created
    assert generic_.new_class.method() == 'return_value'


# Generated at 2022-06-25 20:49:46.824983
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    generic_1.person.full_name() == 'David Brown'
    generic_1.address.country() == 'Chile'
    generic_1.datetime.timestamp() == '1298983764'
    generic_1.business.iban() == 'US992555917108'


# Generated at 2022-06-25 20:49:51.688125
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Path)

# Generated at 2022-06-25 20:49:57.035639
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    def custom_provider(cls: Type[Generic], cls2: Type[BaseProvider]) -> bool:
        """Functions that check if a custom provider was added to Generic()
        when the method add_provider was executed

        :param cls: Generic class
        :param cls2: Custom provider
        :return: bool
        """
        cls.add_provider(cls2)
        return hasattr(cls, 'custom')

    assert custom_provider(Generic(), BaseProvider) == True


# Generated at 2022-06-25 20:49:58.758796
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    geolocation = generic.internet.geolocation()
    generic.add_provider(Internet)
    assert generic.internet.geolocation() == geolocation


# Generated at 2022-06-25 20:49:59.569758
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Clothing)


# Generated at 2022-06-25 20:50:05.019196
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class CustomProvider(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super(CustomProvider, self).__init__(seed=seed, **kwargs)
            self.class_name = 'TestCustomProvider'

        class Meta:
            name = 'custom'

        def method_test(self):
            return self.class_name

    generic_1.add_provider(CustomProvider)
    res = generic_1.custom.method_test()
    assert res == 'TestCustomProvider'


# Generated at 2022-06-25 20:50:06.209914
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)



# Generated at 2022-06-25 20:50:09.586079
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person import Person

    generic = Generic()
    generic.add_provider(Person)
    assert generic.person.name() == generic.person.name()

    generic.add_provider(Datetime)
    assert generic.datetime.date() == generic.datetime.date()
