

# Generated at 2022-06-25 20:42:41.416147
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.name = 'custom'

        def foo(self):
            return 'bar'

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    assert generic_0.custom.foo() == 'bar'


# Generated at 2022-06-25 20:42:45.826318
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0 = Generic()
    var_0 = generic_0._person()
    var_1 = generic_0._text()
    var_2 = generic_0._business()
    var_3 = generic_0._address()
    var_4 = generic_0._datetime()
    var_5 = generic_0._food()
    var_6 = generic_0._science()


# Generated at 2022-06-25 20:42:47.668186
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    attrname = 'person'
    assert generic_0.__getattr__(attrname)



# Generated at 2022-06-25 20:42:50.077167
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert (generic_0.__getattr__('person') != None)


# Generated at 2022-06-25 20:42:58.158372
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Unit test for method add_provider of class Generic
    from mimesis.providers.person import Person as PersonProvider
    from mimesis.providers.date import Datetime as DateProvider
    from mimesis.exceptions import NonExistentProviderError

    g = Generic()
    g.add_provider(PersonProvider)
    g.add_provider(DateProvider)
    g.add_provider(PersonProvider)
    try:
        # Should throw an error, because this provider is already added.
        g.add_provider(PersonProvider)
    except NonExistentProviderError:
        pass


# Generated at 2022-06-25 20:42:59.336321
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass


# Generated at 2022-06-25 20:43:08.930148
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class FirstProvider(BaseProvider):
        class Meta:
            name = 'first_provider'
        def get_something(self):
            return 'something'
    class SecondProvider(BaseProvider):
        class Meta:
            name = 'second_provider'
        def get_something(self):
            return 'something'
    # generic_0 must have attribute first_provider
    generic_0 = Generic()
    generic_0.add_provider(FirstProvider)
    generic_0.add_provider(SecondProvider)
    # generic_1 mustn't have attribute first_provider
    generic_1 = Generic()
    generic_1.add_providers(FirstProvider, SecondProvider)
    # generic_2 mustn't have attribute first_provider and must be equal to generic_1
    generic_2 = Generic()
   

# Generated at 2022-06-25 20:43:16.187955
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.person, Person)
    assert isinstance(generic_0.address, Address)
    assert isinstance(generic_0.datetime, Datetime)
    assert isinstance(generic_0.business, Business)
    assert isinstance(generic_0.text, Text)
    assert isinstance(generic_0.food, Food)
    assert isinstance(generic_0.science, Science)
    assert isinstance(generic_0.transport, Transport)
    assert isinstance(generic_0.code, Code)
    assert isinstance(generic_0.unit_system, UnitSystem)
    assert isinstance(generic_0.file, File)
    assert isinstance(generic_0.numbers, Numbers)
    assert isinstance(generic_0.development, Development)

# Generated at 2022-06-25 20:43:17.576232
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert isinstance(generic_0.person, Person) == True


# Generated at 2022-06-25 20:43:21.649233
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # See tests/providers/tests.py for more cases
    generic_0 = Generic()
    generic_0.add_provider(Address)
    generic_1 = Generic()
    generic_1.add_provider(Transport)
    generic_2 = Generic()
    generic_2.add_provider(Path)
