

# Generated at 2022-06-25 20:42:47.162125
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class CustomProvider(BaseProvider):

        class Meta:
            name = 'custom'

        def method1(self) -> str:
            return self.generator.pystr(5)

        def method2(self) -> int:
            return self.generator.pyint()

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert generic.custom.method1() != ''
    assert isinstance(generic.custom.method2(), int)



# Generated at 2022-06-25 20:42:57.818783
# Unit test for method __getattr__ of class Generic

# Generated at 2022-06-25 20:43:07.364651
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.person
    assert generic_0.address
    assert generic_0.datetime
    assert generic_0.business
    assert generic_0.text
    assert generic_0.food
    assert generic_0.science
    assert generic_0.transport
    assert generic_0.code
    assert generic_0.unit_system
    assert generic_0.file
    assert generic_0.numbers
    assert generic_0.development
    assert generic_0.hardware
    assert generic_0.clothing
    assert generic_0.internet
    assert generic_0.path
    assert generic_0.payment
    assert generic_0.cryptographic
    assert generic_0.structure
    assert generic_0.choice


# Generated at 2022-06-25 20:43:08.224702
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.__getattr__('person')


# Generated at 2022-06-25 20:43:10.975897
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science
    generic_2 = Generic()
    generic_2.add_provider(Science)
    assert hasattr(generic_2, 'science')

#Unit test for method add_providers of class Generic

# Generated at 2022-06-25 20:43:11.864279
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-25 20:43:20.038922
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-25 20:43:22.310776
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0.__getattr__(attrname='person') is None
    assert generic_0.__getattr__(attrname='file') is None


# Generated at 2022-06-25 20:43:29.440250
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic class and method __getattr__()."""
    generic = Generic()
    generic.person
    generic.address
    generic.datetime
    generic.business
    generic.text
    generic.food
    generic.science
    generic.transport
    generic.code
    generic.unit_system
    generic.file
    generic.numbers
    generic.development
    generic.hardware
    generic.clothing
    generic.internet
    generic.path
    generic.payment
    generic.cryptographic
    generic.structure
    generic.choice




# Generated at 2022-06-25 20:43:30.544396
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert generic.datetime is not None


# Generated at 2022-06-25 20:43:52.593973
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert 'person' in dir(generic)
    assert generic.person.__class__.__name__ == 'Person'
    # Raise TypeError if cls is not a class
    with pytest.raises(TypeError):
        generic.add_provider(123)
    # Raise TypeError if cls is not a subclass of BaseProvider
    with pytest.raises(TypeError):
        generic.add_provider(int)


# Generated at 2022-06-25 20:43:54.348134
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert g.person


# Generated at 2022-06-25 20:44:01.659566
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert generic_0._person is not None
    assert generic_0._address is not None
    assert generic_0._datetime is not None
    assert generic_0._business is not None
    assert generic_0._text is not None
    assert generic_0._food is not None
    assert generic_0._science is not None
    assert generic_0.transport is not None
    assert generic_0.code is not None
    assert generic_0.unit_system is not None
    assert generic_0.file is not None
    assert generic_0.numbers is not None
    assert generic_0.development is not None
    assert generic_0.hardware is not None
    assert generic_0.clothing is not None
    assert generic_0.internet is not None

# Generated at 2022-06-25 20:44:05.310149
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person
    from mimesis.providers.clothing import Clothing
    generic_0 = Generic()
    generic_0.add_provider(Person)
    generic_0.add_provider(Clothing)
    assert generic_0.person != None
    assert generic_0.clothing != None



# Generated at 2022-06-25 20:44:07.901463
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Generic)
    assert hasattr(generic_0, 'generic') is True


# Generated at 2022-06-25 20:44:11.722864
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class Custom(BaseProvider):
        pass
    generic.add_provider(Custom)
    assert type(generic.custom) == Custom


# Generated at 2022-06-25 20:44:21.473241
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic(seed=1, seed_obj=seed_0)
    attr_name = 'address'
    assert generic_0.__getattr__(attr_name) == generic_0._address(locale='en', seed=1)
    attr_name = 'business'
    assert generic_0.__getattr__(attr_name) == generic_0._business(locale='en', seed=1)
    attr_name = 'person'
    assert generic_0.__getattr__(attr_name) == generic_0._person(locale='en', seed=1)
    attr_name = 'text'
    assert generic_0.__getattr__(attr_name) == generic_0._text(locale='en', seed=1)
    attr_name = 'datetime'


# Generated at 2022-06-25 20:44:26.230658
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert isinstance(generic.person, Person)
    assert generic.person.seed == generic.seed
    try:
        generic.add_provider(Generic)
    except TypeError:
        assert True


# Generated at 2022-06-25 20:44:35.804714
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    try :
        # If a provider doesn't inherit from the class BaseProvider, a error is expected
        generic.add_provider(Business)
    except TypeError as err0:
        assert type(err0) == TypeError

    # If a provider is a subclass of BaseProvider, nothing happend
    generic.add_provider(Path)
    assert hasattr(generic, "path")
    assert callable(getattr(generic, "path"))



# Generated at 2022-06-25 20:44:39.774611
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Demo provider
    class DemoProvider(BaseProvider):
        class Meta:
            name = 'demo'

        def __init__(self, seed: Any = None) -> None:
            super().__init__(seed=seed)

        def __getattr__(self, item: str) -> Any:
            return item

    generic = Generic()
    generic.add_provider(DemoProvider)
    assert hasattr(generic, 'demo')
    assert hasattr(generic.demo, 'demo')


# Generated at 2022-06-25 20:44:56.446062
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'my_provider'

        def method(self):
            return 'test'

    generic = Generic()
    generic.add_provider(MyProvider)
    assert generic.my_provider.method() == 'test'


# Generated at 2022-06-25 20:45:00.367392
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Clothing)

    assert 'clothing' in generic_1.__dir__()


# Generated at 2022-06-25 20:45:09.139786
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.base import BaseProvider

    class NewProvider(BaseProvider):
        """Class of new provider."""

        class Meta:
            """Class for metadata."""

            name = 'new'

    new_provider = NewProvider()
    assert hasattr(new_provider, 'new')
    assert hasattr(new_provider, 'new')
    assert hasattr(new_provider, 'new')

    class FakeProvider:
        pass

    generic_0 = Generic()
    try:
        generic_0.add_provider(cls=FakeProvider)
    except TypeError as error:
        assert str(error) == 'The provider must be a ' \
                             'subclass of BaseProvider'

    generic_0.add_provider(cls=NewProvider)
    generic_0.add_provider

# Generated at 2022-06-25 20:45:13.131817
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    expected = isinstance(generic.person, Person)
    assert expected, 'Should return `True`'


# Generated at 2022-06-25 20:45:15.854952
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Add a custom provider
    def CustomProvider(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(CustomProvider)



# Generated at 2022-06-25 20:45:19.810667
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Clothing)
    assert 'Clothing' in dir(generic)


# Generated at 2022-06-25 20:45:29.719807
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.file import File
    from mimesis.providers.payment import Payment

    generic = Generic()
    generic.add_provider(Person)
    generic.add_provider(Address)
    generic.add_provider(File)
    generic.add_provider(Payment)
    assert generic.person
    assert generic.person.__class__.__name__ == 'Person'
    assert generic.address
    assert generic.address.__class__.__name__ == 'Address'
    assert generic.file
    assert generic.file.__class__.__name__ == 'File'
    assert generic.payment
    assert generic.payment.__class__.__name__ == 'Payment'

# Generated at 2022-06-25 20:45:31.223282
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    test_case_0()

# Generated at 2022-06-25 20:45:32.529519
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass


# Generated at 2022-06-25 20:45:36.487671
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .example_provider import BaseExampleProvider

    generic = Generic()
    generic.add_provider(BaseExampleProvider)
    generic.baseexampleprovider.foo()

    generic.add_provider(Generic)
    generic.generic



# Generated at 2022-06-25 20:46:03.971817
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Business)
    assert 'Business' in dir(generic_0)
    assert generic_0.business



# Generated at 2022-06-25 20:46:06.798641
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):

        class Meta:
            name = 'test_provider'

        def foo(self):
            return True

    generic = Generic()
    generic.add_provider(TestProvider)
    assert hasattr(generic, 'test_provider')
    assert generic.test_provider.foo()


# Generated at 2022-06-25 20:46:10.337424
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    #given:
    class TestClass(object):

        def __init__(self):
            self.name = "John Doe"

    #when:
    generic = Generic()
    generic.add_provider(TestClass)
    #then:
    assert generic.testclass.name == "John Doe"



# Generated at 2022-06-25 20:46:18.288763
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.business import Business
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.address import Address
    
    my_provider1 = Person(seed = 1)
    my_provider2 = Business(seed = 2)
    my_provider3 = Address(seed = 3)

    gr = Generic()

    gr.add_provider(my_provider1)
    gr.add_provider(my_provider2)
    gr.add_provider(my_provider3)



# Generated at 2022-06-25 20:46:21.033919
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    Generic.add_provider(Generic, BaseProvider)
    Generic.add_provider(Generic, BaseDataProvider)
    Generic.add_provider(Generic, Business)
    Generic.add_provider(Generic, Address)
    Generic.add_provider(Generic, Datetime)
    Generic.add_provider(Generic, Transport)
    generic = Generic()



# Generated at 2022-06-25 20:46:31.109992
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    # global generic_1_type
    # generic_1_type=type(generic_1)
    # global generic_1_dict
    # generic_1_dict=generic_1.__dict__

    # assert generic_1.person().__dict__['data']==generic_1.person().data
    # # assert generic_1_type is type(generic_1)
    # # assert generic_1_dict is generic_1.__dict__

    global custom_cls
    class custom_cls(BaseProvider):
        class Meta:
            name="custom_cls"

        def __init__(self,locale='en',seed=None):
            super().__init__(locale=locale,seed=seed)


# Generated at 2022-06-25 20:46:34.115172
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        @property
        def test(self):
            return 1

    generic = Generic()

    try:
        generic.add_provider(TestProvider)
    except TypeError:
        assert False

    assert generic.test == 1


# Generated at 2022-06-25 20:46:35.294687
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Provider)


# Generated at 2022-06-25 20:46:44.229305
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(cls=Address)
    assert hasattr(generic_1, 'address')

    generic_2 = Generic()
    generic_2.add_provider(cls=Person)
    assert hasattr(generic_2, 'person')

    generic_3 = Generic()
    generic_3.add_provider(cls=Datetime)
    assert hasattr(generic_3, 'datetime')

    generic_4 = Generic()
    generic_4.add_provider(cls=Business)
    assert hasattr(generic_4, 'business')

    generic_5 = Generic()
    generic_5.add_provider(cls=Text)
    assert hasattr(generic_5, 'text')

    generic_6 = Generic()
    generic_6

# Generated at 2022-06-25 20:46:52.948491
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        __qualname__ = 'test_Generic_add_provider.<locals>.CustomProvider'

        class Meta:
            __qualname__ = 'test_Generic_add_provider.<locals>.CustomProvider.Meta'
            name = 'custom_provider'

        def __init__(self, seed: int=None) -> None:
            super().__init__(seed)

        def get_provider_name(self) -> str:
            """Get the name of the provider.

            :return: The name of the provider.
            """
            return 'CustomProvider'

        def foo(self) -> str:
            return 'bar'

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)