

# Generated at 2022-06-25 20:42:46.453052
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    provider_name_list = [
        'person', 'address', 'datetime', 'business', 'text',
        'food', 'science', 'transport', 'code', 'unit_system',
        'file', 'numbers', 'development', 'hardware', 'clothing',
        'internet', 'path', 'payment', 'cryptographic', 'structure',
        'choice']
    for provider_name in provider_name_list:
        assert generic_1.__getattr__(provider_name) != None


# Generated at 2022-06-25 20:42:50.194796
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    assert isinstance(generic_0.person, Person)
    assert generic_0.person.seed == generic_0.seed


# Generated at 2022-06-25 20:42:57.911562
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create custom provider
    class CustomProvider(BaseProvider):
        pass

    # Instance generic object
    generic = Generic()

    # Add custom provider to generic object
    generic.add_provider(CustomProvider)

    # Check if provider is exist in generic object
    assert len(generic.__dict__) == 2

    # Create second custom provider
    class CustomProvider2(BaseProvider):
        pass

    # Add second custom provider to generic object
    generic.add_provider(CustomProvider2)

    # Check if second provider is exist in generic object
    assert len(generic.__dict__) == 3


# Generated at 2022-06-25 20:43:04.177919
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    if generic_1.person.__class__.__name__ != 'Person':
        raise TypeError('Generic.person must be Person')
    if generic_1.address.__class__.__name__ != 'Address':
        raise TypeError('Generic.address must be Address')
    if generic_1.food.__class__.__name__ != 'Food':
        raise TypeError('Generic.food must be Food')


# Generated at 2022-06-25 20:43:10.315412
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import unittest

    class test_Generic___getattr__(unittest.TestCase):
        def test_Generic___getattr__(self):
            """Test that a provider will be created only if it's called."""
            address_name = 'address'
            generic = Generic()
            self.assertIsNone(generic.__dict__.get(address_name))
            provider = getattr(generic, address_name)
            self.assertIsNotNone(provider)

    return test_Generic___getattr__



# Generated at 2022-06-25 20:43:17.871222
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-25 20:43:27.954307
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Generic.__getattr__(generic_0, 'person') # Check that attribute person is a Provider Person
    type(generic_0.person) is Person
    Generic.__getattr__(generic_0, 'address') # Check that attribute address is a Provider Address
    type(generic_0.address) is Address
    Generic.__getattr__(generic_0, 'datetime') # Check that attribute datetime is a Provider Datetime
    type(generic_0.datetime) is Datetime
    Generic.__getattr__(generic_0, 'business') # Check that attribute business is a Provider Business
    type(generic_0.business) is Business
    Generic.__getattr__(generic_0, 'text') # Check that attribute text is a Provider Text
    type(generic_0.text) is Text

# Generated at 2022-06-25 20:43:29.047720
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # creation of object
    generic_0 = Generic()
    assert isinstance(generic_0, Generic)


# Generated at 2022-06-25 20:43:31.018283
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    g.add_provider(Business)
    print(g.__dict__)


# Generated at 2022-06-25 20:43:32.598376
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.__getattr__('address')


# Generated at 2022-06-25 20:43:58.121118
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    g.add_provider(Address)
    g.add_provider(Datetime)
    g.add_provider(Business)
    g.add_provider(Text)
    g.add_provider(Food)
    g.add_provider(Science)
    g.add_provider(Transport)
    g.add_provider(Code)
    g.add_provider(UnitSystem)
    g.add_provider(File)
    g.add_provider(Numbers)
    g.add_provider(Development)
    g.add_provider(Hardware)
    g.add_provider(Clothing)
    g.add_provider(Internet)
    g.add_provider(Path)
    g

# Generated at 2022-06-25 20:44:02.240408
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Generic)


# Generated at 2022-06-25 20:44:04.770720
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Business)



# Generated at 2022-06-25 20:44:06.749530
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Text)


# Generated at 2022-06-25 20:44:10.244176
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    generic_1.add_provider(Text)
    assert 'text' in dir(generic_1)


# Generated at 2022-06-25 20:44:12.509810
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider('CustomProvider')


# Generated at 2022-06-25 20:44:21.778935
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    events = []

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def get_data(self):
            events.append('test_provider_get_data')

        def foo(self):
            events.append('test_provider_foo')

    generic = Generic()

    generic.add_provider(TestProvider)

    # method get_data is called when Generic method is called
    generic.test_provider.get_data()
    assert events == ['test_provider_get_data']

    # method without get_data is not called
    generic.test_provider.foo()
    assert events == ['test_provider_get_data',
                      'test_provider_foo']

    # method get_data is called each time

# Generated at 2022-06-25 20:44:25.098144
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Address)
    assert generic_0
    

# Generated at 2022-06-25 20:44:27.356217
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_add_p = Generic()
    class C(BaseProvider):
        pass
    generic_add_p.add_provider(C)
    assert hasattr(generic_add_p, 'c')


# Generated at 2022-06-25 20:44:35.025094
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create instance of the class
    generic = Generic()
    # There is no provider 'test' now
    assert 'test' not in dir(generic)
    # Create a new provider
    from mimesis.providers import Test
    # Add provider to instance of class
    generic.add_provider(Test)
    # Check that
    assert hasattr(generic, 'test')



# Generated at 2022-06-25 20:44:48.775101
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().__getattr__('person') is not None


# Generated at 2022-06-25 20:44:58.432744
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    assert generic_0.person.full_name() == "Mackenzie Cerda"
    generic_0.add_provider(Address)
    assert generic_0.address.city() == "Roxbury"
    generic_0.add_provider(Datetime)
    assert generic_0.datetime.datetime(maximum="2005-12-31", minimum="1900-01-01") == "1915-01-05T15:44:06"
    generic_0.add_provider(Business)
    assert generic_0.business.company() == "Fritsch and Sons"
    generic_0.add_provider(Text)
    assert generic_0.text.sentence() == "Qui est perferendis voluptates."

# Generated at 2022-06-25 20:45:01.639131
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic().add_provider(Address)
    assert(generic_0.address.__class__ == Address)


# Generated at 2022-06-25 20:45:04.654726
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    assert (generic_0.person()) == 'Dominique Johnson'


# Generated at 2022-06-25 20:45:07.363029
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    assert generic.person is not None
    assert generic.hardware is not None
    assert generic.path is not None
    assert generic.payment is not None
    assert generic.cryptographic is not None
    assert generic.structure is not None
    assert generic.choice is not None


# Generated at 2022-06-25 20:45:08.610893
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()


# Generated at 2022-06-25 20:45:11.333099
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    assert generic_0.add_provider(Person) is None


# Generated at 2022-06-25 20:45:19.068393
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    :return:
    """
    def __init__(self, seed: int = None):
        super().__init__(seed)
        self.seed = seed

    class Foo(BaseProvider):
        class Meta:
            name = 'foo'

    class Bar(BaseProvider):
        class Meta:
            name = 'bar'

    generic_0 = Generic()
    generic_0.add_provider(Foo)
    assert 'foo' in generic_0._providers
    generic_0.add_provider(Bar)
    assert 'bar' in generic_0._providers

    try:
        generic_0.add_provider(BaseProvider)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 20:45:25.704562
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.payment import CreditCard as CreditCard
    generic = Generic()
    generic.add_provider(CreditCard)
    # There is a bug: there is no exception if the provider is not subclass of BaseProvider


# Generated at 2022-06-25 20:45:31.442583
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    reg = '[a-z0-9]{8}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{4}-[a-z0-9]{12}'
    generic.add_provider(Person)
    assert generic.person.uuid() == True
    generic.add_provider(Address)
    assert generic.address.coordinates() == True
    generic.add_provider(Datetime)
    assert generic.datetime.datetime() == True
    generic.add_provider(Business)
    assert generic.business.company_name() == True
    generic.add_provider(Text)
    assert generic.text.timestamp() == True
    generic.add_provider(Food)

# Generated at 2022-06-25 20:45:59.879912
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.address import Region
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.date import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    
    with pytest.raises(TypeError):
        Generic().add_provider(1)

    generic = Generic()
    generic.add_provider(Region)
    assert isinstance(generic.region, Region)
    assert issubclass(generic.region.__class__, BaseProvider)

    generic.add_provider(Datetime)
    assert isinstance(generic.datetime, Datetime)
    assert issubclass(generic.datetime.__class__, BaseProvider)

    generic

# Generated at 2022-06-25 20:46:02.668022
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generic_0.add_provider(Payment)


# Generated at 2022-06-25 20:46:04.375732
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Business)
    assert hasattr(gen, 'business')


# Generated at 2022-06-25 20:46:05.396342
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)


# Generated at 2022-06-25 20:46:06.793303
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .custom import CustomProvider

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    assert generic_0.custom is not None



# Generated at 2022-06-25 20:46:16.611968
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.add_provider(Person)
    # True
    print('\nThe following test should return `True`')
    print(generic_0.person() is not None)
    generic_0.add_provider(Address)
    # True
    print('\nThe following test should return `True`')
    print(generic_0.address() is not None)
    generic_0.add_provider(Datetime)
    # True
    print('\nThe following test should return `True`')
    print(generic_0.datetime() is not None)
    generic_0.add_provider(Business)
    # True
    print('\nThe following test should return `True`')
    print(generic_0.business() is not None)

# Generated at 2022-06-25 20:46:18.944621
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.identifier import Identifier
    generic_0 = Generic()
    generic_0.add_provider(Identifier)
    print(generic_0.identifier.uuid4())



# Generated at 2022-06-25 20:46:30.678354
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit Tests for Generic.__getattr__()"""

    generic_0 = Generic(locale='ja')
    generic_1 = Generic(locale='en')
    generic_2 = Generic(locale='ru')
    generic_3 = Generic(locale='zh')

    attrname = "person"

    assert generic_0.person.full_name() != None
    assert generic_0.person.full_name() != generic_1.person.full_name()
    assert generic_1.person.full_name() != generic_2.person.full_name()
    assert generic_2.person.full_name() != generic_3.person.full_name()
    assert generic_0.person.full_name() != generic_3.person.full_name()


# Generated at 2022-06-25 20:46:31.496472
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    print('\n', generic_1)

# Generated at 2022-06-25 20:46:36.151701
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        """Docstring."""

        class Meta:
            """Metaclass."""

            name = 'custom'

        def foo(self) -> None:
            pass

    generic_0 = Generic()
    generic_0.add_provider(CustomProvider)
    generic_1 = Generic()
    generic_1.add_provider(CustomProvider)
    generic_2 = Generic()
    generic_2.add_provider(CustomProvider)
    generic_3 = Generic()
    generic_3.add_provider(CustomProvider)


# Generated at 2022-06-25 20:47:19.393339
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()


# Generated at 2022-06-25 20:47:26.584546
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'Test value'

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'test_provider_2'

        def test_method_2(self):
            return 'Test value 2'

    generic = Generic()
    assert 'test_provider' not in dir(generic)
    assert 'test_provider_2' not in dir(generic)
    generic.add_provider(TestProvider)
    assert 'test_provider' in dir(generic)
    assert 'test_provider_2' not in dir(generic)
    generic.add_provider(TestProvider2)
    assert 'test_provider' in dir(generic)

# Generated at 2022-06-25 20:47:33.343755
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import mimesis.extra as extra
    def ClassCustom():
        from mimesis.custom.custom_provider import GenericCustom
        class Custom(GenericCustom):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.test0 = 'test0'
        return Custom
    generic_0 = Generic()
    generic_0.add_provider(ClassCustom())
    assert isinstance(ClassCustom(), ClassCustom().__class__)
    assert generic_0.test0 == 'test0'


# Generated at 2022-06-25 20:47:34.810929
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_case_0()


# Generated at 2022-06-25 20:47:44.439802
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_1 = Generic()
    # Provider Person
    result_1 = generic_1.person.full_name()
    # Provider Address
    result_2 = generic_1.address.city()
    # Provider Datetime
    result_3 = generic_1.datetime.datetime(datetime_format='%Y-%m-%d %H:%M:%S')
    # Provider Business
    result_4 = generic_1.business.company()
    # Provider Text
    result_5 = generic_1.text.title(quantity=1)
    # Provider Food
    result_6 = generic_1.food.fruit()
    # Provider Science
    result_7 = generic_1.science.element_name()
    # Provider Transport
    result_8 = generic_1.transport.category()
    # Provider Code

# Generated at 2022-06-25 20:47:47.357839
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.software import Software
    from mimesis.providers.development import Development
    generic = Generic()
    for provider in [Development, Software]:
        generic.add_provider(provider)

# Generated at 2022-06-25 20:47:49.812149
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):

        def foo(self) -> str: return 'bar'

    generic_1 = Generic()
    generic_1.add_provider(Provider)
    assert hasattr(generic_1, 'provider')
    assert generic_1.provider.foo() == 'bar'


# Generated at 2022-06-25 20:47:54.454512
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def foo(self):
            return 'bar'
    g = Generic()
    g.add_provider(CustomProvider)
    assert getattr(g, 'customprovider') is not None
    assert g.customprovider.foo() == 'bar'


# Generated at 2022-06-25 20:48:00.593458
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Case 0: test add_provider method
    generic_0 = Generic()
    generic_0.add_provider(Num)
    assert hasattr(generic_0, 'num')
    generic_0.add_provider(Date)
    assert hasattr(generic_0, 'date')

    with pytest.raises(TypeError):
        generic_0.add_provider(1)
    # Case 1: test add_provider method
    generic_1 = Generic()
    generic_1.add_provider(Num)
    assert hasattr(generic_1, 'num')
    generic_1.add_provider(Date)
    assert hasattr(generic_1, 'date')

    with pytest.raises(TypeError):
        generic_1.add_provider(1)
    # Case 2:

# Generated at 2022-06-25 20:48:06.277436
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Case 0: add a subclass of BaseProvider
    generic = Generic()
    class Boolean(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get_boolean(self):
            return True

    generic.add_provider(Boolean)
    assert generic.boolean.get_boolean()
    assert 'boolean' in dir(generic)

    # Case 1: add a class that is not subclass of BaseProvider
    class NotSubclassOfBaseProvider:
        pass
    try:
        generic.add_provider(NotSubclassOfBaseProvider)
    except TypeError:
        pass
    else:
        raise RuntimeError('Test for Case 1 fails.')

    # Case 2: add a not class object