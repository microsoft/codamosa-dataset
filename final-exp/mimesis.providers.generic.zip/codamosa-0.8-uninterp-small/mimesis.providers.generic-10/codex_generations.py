

# Generated at 2022-06-25 20:42:45.015710
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_1 = Generic()
    class TestProvider(BaseProvider):
        def method_test(self):
            return 12
    generic_1.add_provider(TestProvider)
    assert generic_1.test_provider.method_test() == 12


# Generated at 2022-06-25 20:42:46.436165
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    #TODO: need test cases


# Generated at 2022-06-25 20:42:48.319593
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic_0 = Generic()
    generi_0_1=generic_0.add_provider('cls')


# Generated at 2022-06-25 20:42:59.210584
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # test for TypeError
    try:
        generic_1 = Generic()
        generic_1.add_provider(Generic)
        assert False
    except TypeError:
        assert True
    # test for TypeError
    try:
        generic_2 = Generic()
        generic_2.add_provider(BaseDataProvider)
        assert False
    except TypeError:
        assert True
    # test for normal
    try:
        generic_3 = Generic()
        generic_3.add_provider(BaseProvider)
        assert True
    except TypeError:
        assert False
    # test for normal
    try:
        generic_4 = Generic()
        generic_4.add_provider(BaseProvider())
        assert False
    except TypeError:
        assert True

# test for method add_providers of class Generic


# Generated at 2022-06-25 20:43:05.246518
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    def dummy_provider(self):
        print("adding dummy_provider")

    class MyDummyProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            dummy_provider(self)

    generic_0 = Generic()
    try:
        generic_0.add_provider(MyDummyProvider)
    except TypeError:
        print("Expected TypeError")


# Generated at 2022-06-25 20:43:06.197606
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass


# Generated at 2022-06-25 20:43:11.087436
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'test'
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def test(self):
            return 'test'
    gen = Generic()
    gen.add_provider(CustomProvider)
    assert hasattr(gen, 'test')
    assert gen.test.test() == 'test'


# Generated at 2022-06-25 20:43:14.458547
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic_0 = Generic()
    generic_0.unit_system = UnitSystem()
    generic_0.__getattr__()


# Generated at 2022-06-25 20:43:24.956376
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # define custom class
    class Custom(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def custom(self):
            return 1

    # define custom class of class BaseProvider
    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def custom(self):
            return 1

    # define class without Meta class
    class CustomProviderWithoutMeta(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def custom(self):
            return 1

    generic = Generic()

    # Add the provider Custom() to the Generic() object
    generic.add_

# Generated at 2022-06-25 20:43:33.456447
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.base import BaseDataProvider

    class custom_provider(BaseProvider):
        def foo(self):
            return "bar"

    class custom_provider_nodata(BaseDataProvider):
        def foo(self):
            return "bar"

    generic_0 = Generic()
    # add a custom provider
    generic_0.add_provider(cls=custom_provider)
    # add a custom provider class not a subclass of BaseProvider
    generic_0.add_provider(cls=custom_provider_nodata)
    # add a custom provider.
    generic_0.add_provider(custom_provider)
    # add a custom provider class not a subclass of BaseProvider
    generic_0.add_prov