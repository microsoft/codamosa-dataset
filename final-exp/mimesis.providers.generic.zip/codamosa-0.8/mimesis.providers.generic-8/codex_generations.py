

# Generated at 2022-06-12 01:51:53.643444
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import mimesis
    print('\n')
    data = Generic()
    
    # Method __getattr__, part 1
    data.__getattr__('locale') == 'en'
    
    # Method __getattr__, part 2
    data.__getattr__('seed') == '9'
    
    # Method __getattr__, part 3
    data.__getattr__('address') == data.address


# Generated at 2022-06-12 01:52:01.136805
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.numbers import Numbers, NumberParts
    from mimesis.exceptions import NonEnumerableError, FieldValidationError
    from mimesis.enums import Gender

    # Test for first case of exception
    class A(BaseProvider):
        class Meta:
            name = 'a'
        def __init__(self, *args, **kwargs):
            raise NonEnumerableError

    # Test for second case of exception
    class B(BaseProvider):
        class Meta:
            name = 'b'
        def __init__(self, *args, **kwargs):
            self.a = None

    # Test for third case of exception
    class C(BaseProvider):
        class Meta:
            name = 'c'

# Generated at 2022-06-12 01:52:09.086392
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    Generic().__getattr__('person')
    Generic().__getattr__('address')
    Generic().__getattr__('datetime')
    Generic().__getattr__('business')
    Generic().__getattr__('text')
    Generic().__getattr__('science')
    Generic().__getattr__('food')
    Generic().__getattr__('payment')
    Generic().__getattr__('transport')
    Generic().__getattr__('code')
    Generic().__getattr__('unit_system')
    Generic().__getattr__('file')
    Generic().__getattr__('numbers')
    Generic().__getattr__('development')
    Generic().__getattr__('hardware')
    Generic().__getattr__('internet')
    Generic().__getattr__('structure')
    Generic().__get

# Generated at 2022-06-12 01:52:12.240425
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.name # will create something like g.name = Person().name(...)
    assert g.__dict__.get('name') is not None


# Generated at 2022-06-12 01:52:15.526188
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .test_providers import NewProvider
    person = Person()
    provider = Generic()
    provider.add_provider(NewProvider)
    assert provider.newprovider.providers == person.providers

# Generated at 2022-06-12 01:52:25.212170
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.base import BaseProvider
    from mimesis.enums import Language
    from mimesis.providers.base import BaseDataProvider
    from mimesis import Generic as Generic_

    gen = Generic_()
    assert not isinstance(gen.numbers, Numbers)

    # Test for TypeError
    try:
        gen.add_provider(BaseProvider)
    except TypeError:
        assert True
    else:
        assert False

    gen.add_provider(Numbers)
    assert isinstance(gen.numbers, Numbers)

    # Test for TypeError
    try:
        gen.add_provider(BaseDataProvider)
    except TypeError:
        assert True
    else:
        assert False

    # Add the same provider

# Generated at 2022-06-12 01:52:28.619035
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'provider'

        def foo(self):
            return 'bar'

    gen = Generic()
    gen.add_provider(MyProvider)
    assert gen.provider.foo() == 'bar'

# Generated at 2022-06-12 01:52:38.759441
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed=12345)
    assert generic.person != None
    assert generic.person != generic._person(None, 12345)
    assert generic.person == generic._person(None, 12345)
    assert generic.datetime != None
    assert generic.datetime != generic._datetime(None, 12345)
    assert generic.datetime == generic._datetime(None, 12345)
    assert generic.address != None
    assert generic.address != generic._address(None, 12345)
    assert generic.address == generic._address(None, 12345)
    assert generic.business != None
    assert generic.business != generic._business(None, 12345)
    assert generic.business == generic._business(None, 12345)
    assert generic.text != None
    assert generic.text != generic._text(None, 12345)

# Generated at 2022-06-12 01:52:42.282084
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.music import Music

    g = Generic('en')
    g.add_provider(Music)
    
    assert hasattr(g, 'music')

# Generated at 2022-06-12 01:52:47.250348
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    g = Generic()
    g.__getattr__('person')

    for attr in dir(g):
        if attr.startswith('_') and attr.endswith('_'):
            continue
        getattr(g, attr)