

# Generated at 2022-06-12 01:51:39.904591
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    print(generic.person())

# Generated at 2022-06-12 01:51:47.370093
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Unit: test_Generic___getattr__
    # When: Call __getattr__ with the parameter attrname = "person"
    # Then: Return the object Person


    # Unit: test_Generic___getattr__
    # When: Call __getattr__
    # Then: Raise error AttributeError

    # Unit: test_Generic___getattr__
    # When: Call __getattr__ with the parameter attrname = "_person"
    # Then: Raise error AttributeError

    # Unit: test_Generic___getattr__
    # When: Call __getattr__ with the parameter attrname = "GENERIC"
    # Then: Raise error AttributeError
    pass


# Generated at 2022-06-12 01:51:53.047771
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider:
        def __init__(self, seed=None):
            self.seed = seed

        class Meta:
            name = 'custom_provider'
    g = Generic(seed=42)
    g.add_provider(CustomProvider)

    assert hasattr(g, 'custom_provider')


# Generated at 2022-06-12 01:51:54.950248
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    assert isinstance(g.person, Person)

# Generated at 2022-06-12 01:51:58.760913
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for __getattr__ method of Generic class."""
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address.en import AddressProvider
    generic = Generic('ru')
    assert isinstance(generic.person, RussiaSpecProvider)
    assert isinstance(generic.address, AddressProvider)


# Generated at 2022-06-12 01:52:02.710704
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        def foo(self):
            return 'bar'
    test = Generic()
    test.add_provider(Test)
    result = test.test.foo()
    assert result == 'bar'

# Generated at 2022-06-12 01:52:06.414250
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('en')
    assert gen.person is not None
    assert gen.address is not None
    assert gen.datetime is not None
    assert gen.business is not None
    assert gen.text is not None
    assert gen.food is not None
    assert gen.science is not None



# Generated at 2022-06-12 01:52:09.959225
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test function."""
    obj = Generic()
    def b():
        obj.add_provider(object)
    def c():
        obj.add_provider(BaseProvider)

    assert b() == None
    assert c() == None

# Generated at 2022-06-12 01:52:14.990208
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class FruitProvider(BaseProvider):
        class Meta:
            name = 'fruits'
        def apple(self):
            return 'Apple'
    generic = Generic()
    generic.add_provider(FruitProvider)
    assert generic.fruits.apple() == 'Apple'


# Generated at 2022-06-12 01:52:21.585739
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import pytest
    class Custom():
        pass
    with pytest.raises(TypeError):
        Generic.add_provider(Custom)
    class Custom(BaseProvider):
        class Meta:
            name = 'custom'
        def foo(self):
            return None
    g = Generic()
    g.add_provider(Custom)
    assert getattr(g, 'custom')
    assert callable(getattr(g, 'foo'))
