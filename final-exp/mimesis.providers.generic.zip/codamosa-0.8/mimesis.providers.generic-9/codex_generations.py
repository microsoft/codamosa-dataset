

# Generated at 2022-06-12 01:51:46.780516
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.misc import Misc

    g = Generic()
    g.add_provider(Misc)

    assert hasattr(g, 'misc')

    try:
        g.add_provider('test')
    except TypeError:
        pass

# Generated at 2022-06-12 01:51:50.540000
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.example import Example
    g = Generic()
    g.add_provider(Example)
    assert callable(g.example.example)

# Generated at 2022-06-12 01:51:55.536618
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    def test_Generic___getattr__func():
        pass
    test_Generic___getattr__func()

    g = Generic()
    print(g.person.full_name())
    print(g.address.address())
    print(g.datetime.date())

    g.add_provider(Choice)
    print(g.choice.boolean())

# Generated at 2022-06-12 01:51:58.259208
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self):
            return 'foo'

    g = Generic()
    g.add_provider(Test)
    assert g.test.foo() == 'foo'

# Generated at 2022-06-12 01:52:07.878640
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method ``__getattr__`` of class :class:`Generic`."""
    generic = Generic()
    # If we call ``__getattr__`` in ``Generic`` object
    result = generic.__getattr__('person')
    # then ``result`` must be an object of class ``Person``
    assert isinstance(result, Person)

    # Or we call ``__getattr__`` in ``Generic`` object
    result = generic.__getattr__('address')
    # then ``result`` must be an object of class ``Address``
    assert isinstance(result, Address)

    # Or we call ``__getattr__`` in ``Generic`` object
    result = generic.__getattr__('datetime')
    # then ``result`` must be an object of class ``Datetime``
    assert isinstance(result, Datetime)

# Generated at 2022-06-12 01:52:19.028197
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider1(BaseProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # this test whether add_provider works properly with \
    # subclass of BaseProvider
    assert Provider1

    class Provider2(BaseProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    # this test whether add_provider works properly with \
    # subclass of BaseProvider
    assert Provider2

    class Provider3:
        pass

    # this test whether add_provider will raise TypeError when a class\
    # that is not subclass of BaseProvider is passed to it
    try:
        Generic().add_provider(Provider3)
    except TypeError:
        assert True

    generic

# Generated at 2022-06-12 01:52:27.252073
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.asset import Asset
    from mimesis.providers.bitcoin import Bitcoin
    from mimesis.providers.blockchain import Blockchain
    from mimesis.providers.character import Character
    from mimesis.providers.color import Color
    from mimesis.providers.currency import Currency
    from mimesis.providers.email import Email
    from mimesis.providers.finance import Finance
    from mimesis.providers.http import HTTP
    from mimesis.providers.language import Language
    from mimesis.providers.localization import Localization
    from mimesis.providers.misc import Miscellaneous
    from mimesis.providers.network import Network
    from mimesis.providers.password import Password
    from mimesis.providers.process import Process

# Generated at 2022-06-12 01:52:37.398147
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider1(BaseProvider):
        class Meta:
            name = 'provider_one'

    class Provider2(BaseProvider):
        class Meta:
            name = 'provider_two'

    g = Generic()
    g.add_provider(Provider1)
    assert hasattr(g, 'provider_one')
    g.add_providers(Provider2)
    assert hasattr(g, 'provider_two')
    assert hasattr(g, 'provider_one')
    assert hasattr(g, 'provider_two')

    try:
        g.add_provider('some_string_value')
        assert False
    except TypeError:
        pass


# Generated at 2022-06-12 01:52:43.878820
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    class A(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class B(BaseProvider):
        class Meta:
            name = 'b'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    g.add_provider(A)
    assert "a" in g.__dir__()
    g.add_provider(B)
    assert "b" in g.__dir__()

# Generated at 2022-06-12 01:52:51.128256
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class SomeProvider(BaseProvider):

        class Meta:
            name = 'some'

        @classmethod
        def some_method(cls):
            return '...'

    generic = Generic()
    generic.add_provider(SomeProvider)
    assert generic.__dir__()[-1] == 'some'
    assert generic.some.some_method() == '...'