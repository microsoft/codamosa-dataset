

# Generated at 2022-06-12 01:51:52.578016
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.custom import CustomProvider
    generic = Generic()
    assert not hasattr(generic, 'custom')
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom')



# Generated at 2022-06-12 01:52:00.640098
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.numbers import Numbers as NumbersProvider
    from mimesis.seed import Seed
    from mimesis.seed.base import Base64Seed

    seed = Seed.random_base64(seed_class=Base64Seed)
    x = Generic(seed=seed)
    x.add_provider(NumbersProvider)
    assert isinstance(x.numbers, NumbersProvider)
    print(x.numbers.random_int(min_value=10, max_value=100))

    # Static seed
    seed = 'RX9QQYaVWA=='
    x = Generic(seed=seed)
    x.add_provider(NumbersProvider)
    assert isinstance(x.numbers, NumbersProvider)

# Generated at 2022-06-12 01:52:04.686231
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        pass

    assert Custom not in Generic().__dict__.keys()
    generic = Generic(seed=42)
    generic.add_provider(Custom)
    assert 'custom' in generic.__dict__.keys()


# Generated at 2022-06-12 01:52:16.299036
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.generic import Generic
    from mimesis.providers.bank import Bank
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.python import Python
    gen = Generic('en')
    # Class Bank() is a subclass of BaseProvider so this
    # must work
    gen.add_provider(Bank)
    assert isinstance(gen.bank, Bank)
    # Class Python() is not a subclass of BaseProvider so
    # this must raise TypeError
    try:
        gen.add_provider(Python)
    except TypeError:
        pass
    else:
        assert False, "Should have raised an TypeError"
    # Function must raise TypeError if argument is not class

# Generated at 2022-06-12 01:52:23.577451
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.generators.address import AddressGenerator
    from mimesis.providers import Generic
    from mimesis.providers.address import Address
    from pytest import raises
    gen = Generic()
    assert 'address' not in dir(gen)
    gen.add_provider(AddressGenerator)
    assert isinstance(gen.address, AddressGenerator)
    assert hasattr(AddressGenerator, 'Meta')
    gen.add_provider(Address)
    with raises(TypeError):
        gen.add_provider('foo')

# Generated at 2022-06-12 01:52:29.114948
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    # The following code will raise an AttributeError
    # generic = Generic()
    # generic.add_provider(None)

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self) -> str:
            """Get string."""
            return 'foo'

    # The following code will raise an AttributeError
    # generic = Generic()
    # generic.add_provider(CustomProvider)
    generic = Generic('en')
    generic.add_provider(CustomProvider)
    assert generic.custom.foo() == 'foo'
    assert hasattr(generic.custom, 'foo') is True



# Generated at 2022-06-12 01:52:32.898737
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    class TestMe(BaseDataProvider):
        def __init__(self):
            pass

        def foo(self):
            return 'bar'

    assert TestMe().foo() == 'bar'

# Generated at 2022-06-12 01:52:36.178811
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    # Provider 'food' is not implemented so this line will
    # invoke method __getattr__
    gen.food.cookie()
    assert isinstance(gen.food, Food)


# Generated at 2022-06-12 01:52:38.320218
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    person = g.person
    assert person.name() == 'Jason'
    assert person.full_name() == 'Aurora Rivers'



# Generated at 2022-06-12 01:52:45.108365
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider."""
    fake = Generic('ru')
    assert not hasattr(fake, 'TestProvider')

    class TestProvider(BaseProvider):
        """Test provider."""

        class Meta:
            """Test class."""
            name = 'test_provider'

        def __str__(self):
            """Test string repr."""
            return 'TestProvider'

    fake.add_provider(TestProvider)
    assert hasattr(fake, 'test_provider')
    assert isinstance(fake.test_provider, TestProvider)
    assert str(fake.test_provider) == 'TestProvider'

