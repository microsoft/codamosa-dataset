

# Generated at 2022-06-12 01:51:58.225621
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.science import Science as science

    class TestProvider(BaseProvider):
        """Test provider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)

        class Meta:
            """Class for metadata."""

            name = 'test_provider'

        def get_test_provider(self):
            """Test method."""
            return 42

        def __str__(self):
            """Return string representation."""
            return self.__class__.__name__

    g = Generic()
    g.add_provider(TestProvider)

    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food


# Generated at 2022-06-12 01:52:07.881282
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.process import Process
    from mimesis.providers.software import Software
    from mimesis.providers.terminal import Terminal
    from mimesis.providers.web import Web
    from mimesis.providers.other import Other
    from mimesis.providers.misc import Misc

    g = Generic()
    g.add_provider(Process)
    g.add_provider(Software)
    g.add_provider(Terminal)
    g.add_provider(Web)
    g.add_provider(Other)
    g.add_provider(Misc)

    assert hasattr(g, 'software')
    # Test that they are instances of their classes
    assert isinstance(g.software, Software)
    assert isinstance(g.process, Process)


# Generated at 2022-06-12 01:52:13.944260
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def test(self):
            pass

    genesis = Generic()
    genesis.add_provider(TestProvider)
    genesis.test_provider.test()

# Generated at 2022-06-12 01:52:23.952527
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic()
    # check that the attribute exists
    assert hasattr(provider, 'person')
    # the attribute should implement __call__
    assert callable(provider.person)
    # the attribute should initialize with locale and seed
    assert isinstance(provider.person, Person)
    assert provider.person.locale == 'en'
    assert provider.person._seed == provider.seed
    # test a custom provider
    assert isinstance(provider.clothing, Clothing)
    assert provider.clothing.locale == 'en'
    assert provider.clothing._seed == provider.seed
    # test a custom provider added to generic object
    provider.add_provider(Choice)
    assert hasattr(provider, 'choice')
    assert callable(provider.choice)

# Generated at 2022-06-12 01:52:28.284892
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    res = g.person
    assert isinstance(res, Person)
    res = g.business
    assert isinstance(res, Business)
    res = g.science
    assert isinstance(res, Science)
    res = g.datetime
    assert isinstance(res, Datetime)
    res = g.choice
    assert isinstance(res, Choice)


# Generated at 2022-06-12 01:52:38.431667
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    generic = Generic()

    # When I call the method add_provider with the argument that is not a
    # class, Then I see the TypeError
    with pytest.raises(TypeError):
        generic.add_provider('not_a_class')

    # When I call the method add_provider with the argument that is a class,
    # but it's not a subclass of BaseProvider, Then I see the TypeError
    class NotASubclass: # pylint: disable=R0903
        """Not a subclass of BaseProvider class."""
        pass

    with pytest.raises(TypeError):
        generic.add_provider(NotASubclass)

    # When I call the method add_provider with the argument that is a class
    # and

# Generated at 2022-06-12 01:52:45.864205
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.science import Science
    def test_is_class(cls):
        assert inspect.isclass(cls)

    def test_is_subclass(cls):
        assert issubclass(cls, BaseProvider)

    def test_error_class():
        try:
            Generic().add_provider('string')
        except TypeError:
            pass

    def test_error_subclass():
        class Provider(object):
            def __init__(self):
                pass
        try:
            Generic().add_provider(Provider)
        except TypeError:
            pass

    test_is_class(Science)
    test_is_subclass(Science)
    test_error_class()
    test_error_subclass()
    Generic().add_provider(Science)

# Generated at 2022-06-12 01:52:53.201217
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('zh')
    assert g.person.first_name() == '齐艳'
    assert g.address.street_name() == '太和路'
    assert g.datetime.date() == '1991-03-03'
    assert g.business.corporation() == '英联邦煤业'
    assert g.text.text(10) == '计算后台营销项和分析统计顶网页'
    assert g.food.vegetable() == '水萝卜'
    assert g.science.chemical_element() == '法国水'
    assert g.transport

# Generated at 2022-06-12 01:52:56.340936
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for add_provider of class Generic"""
    from mimesis.providers import Game
    generator = Generic()
    generator.add_provider(Game)
    assert generator.game.__class__.__name__ == "Game"

# Generated at 2022-06-12 01:52:58.080226
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(TestProvider)
    assert hasattr(generic, 'testprovider')
