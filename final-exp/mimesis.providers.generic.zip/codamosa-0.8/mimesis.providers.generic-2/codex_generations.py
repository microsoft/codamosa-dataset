

# Generated at 2022-06-12 01:51:47.676185
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    g = Generic()
    g.add_provider(Person)
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')

    g.add_provider(Address)
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')

    try:
        g.add_provider(Bytes)
        pytest.fail('Generic.add_provider(Bytes) should raise TypeError')
    except TypeError:
        assert True


# Generated at 2022-06-12 01:51:58.225195
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    seed = 0
    g = Generic(seed=seed)
    assert g.address.country() == 'город Большеварьков', "error in method address.country()"
    assert g.datetime.time() == '4:10:40', "error in method datetime.time()"
    assert g.food.fruit() == 'банан', "error in method food.fruit()"
    assert g.food.vegetable() == 'огурец', "error in method food.vegetable()"
    assert g.food.dish() == 'холодец', "error in method food.dish()"

# Generated at 2022-06-12 01:52:05.367347
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider."""
    gen = Generic()
    assert 'villager' not in dir(gen)
    assert not hasattr(gen, 'villager')
    gen.add_provider(Villager)
    assert 'villager' in dir(gen)
    assert hasattr(gen, 'villager')
    assert 'test_provider' not in dir(gen)
    gen.add_provider(TestProvider)
    assert 'test_provider' in dir(gen)


# Generated at 2022-06-12 01:52:11.171746
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def hello_world(self) -> str:
            return 'Hello world'

    g = Generic()
    g.add_provider(Test)

    assert hasattr(g, 'test')
    assert callable(g.test.hello_world)


# Generated at 2022-06-12 01:52:16.194951
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.structure import Structure
    from mimesis import Generic
    g = Generic()
    assert isinstance(g.structure, Structure)
    assert isinstance(g.development, Development)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.payment, Payment)
    assert isinstance(g.cryptographic, Cryptographic)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.internet, Internet)
    assert isinstance(g.path, Path)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.code, Code)
    assert isinstance(g.transport, Transport)

# Generated at 2022-06-12 01:52:20.640579
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestingStructure(Structure):
        class Meta:
            name = 'testing'

    gen = Generic()
    gen.add_provider(TestingStructure)
    assert 'testing' in dir(gen)
    assert callable(getattr(gen, 'testing'))



# Generated at 2022-06-12 01:52:27.631017
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test for normal work of __getattr__
    tools = Generic('ru')
    tools.person
    tools.address
    tools.food
    tools.internet
    tools.cryptographic
    tools.choice
    tools.unit_system
    tools.hardware
    tools.development
    tools.clothing
    tools.development
    tools.numbers
    tools.path
    tools.file
    tools.transport
    tools.code
    tools.payment
    tools.structure
    tools.business
    tools.science
    tools.text
    tools.datetime
    # Test the way to get an inexistent class
    if hasattr(tools, 'wrong_name'):
        assert False  # pragma: no cover



# Generated at 2022-06-12 01:52:30.542943
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Person
    p = Generic()
    p.add_provider(Person)
    assert 'person' in dir(p)
    assert p.person.name() != ''


# Generated at 2022-06-12 01:52:41.244341
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic()
    assert obj.person is not None
    assert obj.address is not None
    assert obj.datetime is not None
    assert obj.business is not None
    assert obj.text is not None
    assert obj.food is not None
    assert obj.science is not None
    assert obj.transport is not None
    assert obj.code is not None
    assert obj.unit_system is not None
    assert obj.file is not None
    assert obj.numbers is not None
    assert obj.development is not None
    assert obj.hardware is not None
    assert obj.clothing is not None
    assert obj.internet is not None
    assert obj.path is not None
    assert obj.payment is not None
    assert obj.cryptographic is not None
    assert obj.structure is not None

# Generated at 2022-06-12 01:52:51.870551
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ method of Generic class."""
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None
    assert getattr(g, 'transport', None) is not None
    assert getattr(g, 'code', None) is not None
    assert getattr(g, 'unit_system', None) is not None
    assert getattr(g, 'file', None) is not None
    assert getattr(g, 'numbers', None) is not None
    assert getattr(g, 'development', None) is not None

# Generated at 2022-06-12 01:53:15.452175
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geo import Geo
    
    assert hasattr(Generic(), 'geo') is False
    assert issubclass(Geo, BaseProvider) is True
    Generic().add_provider(Geo)
    assert hasattr(Generic(), 'geo') is True



# Generated at 2022-06-12 01:53:17.076328
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.address import Address

    addr = Generic()._address
    assert isinstance(addr, Address)



# Generated at 2022-06-12 01:53:18.680680
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    gen.add_provider(Person)
    assert isinstance(gen.person, Person) is True

# Generated at 2022-06-12 01:53:23.613069
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj1 = Generic()
    print(obj1.person.full_name())
    print(obj1.address.address())
    print(obj1.datetime.date())
    print(obj1.business.company())
    print(obj1.text.text())
    print(obj1.food.ingredient())
    print(obj1.science.isotope())
    print(obj1.transport.vehicle())
    print(obj1.code.isbn10())

    obj2 = Generic(seed=42)
    print(obj2.person.full_name())
    print(obj2.address.address())
    print(obj2.datetime.date())
    print(obj2.business.company())
    print(obj2.text.text())
    print(obj2.food.ingredient())


# Generated at 2022-06-12 01:53:25.184658
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Food)
    assert hasattr(g, 'food')

# Generated at 2022-06-12 01:53:27.476923
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(locale='en')
    for item in dir(generic):
        if not isinstance(getattr(generic, item), BaseProvider):
            raise AssertionError('Attribute {item} must be a subtype of '
                                 'BaseProvider.')

# Generated at 2022-06-12 01:53:28.741511
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person.full_name() == 'Ms. Sharon M. Anderson'


# Generated at 2022-06-12 01:53:35.076499
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    class PersonProvider(Person):
        def full_name(self, gender: Gender = None) -> str:
            return 'Full name'

    gen = Generic()
    gen.add_provider(PersonProvider)
    assert gen.full_name() == 'Full name'