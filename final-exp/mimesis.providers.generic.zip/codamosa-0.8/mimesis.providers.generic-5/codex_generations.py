

# Generated at 2022-06-12 01:51:45.745980
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    gen = Generic()
    assert not hasattr(gen, 'custom')
    from mimesis.providers.generic import Custom
    gen.add_provider(Custom)
    assert hasattr(gen, 'custom')


# Generated at 2022-06-12 01:51:57.026883
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)
    assert isinstance(gen.transport, Transport)
    assert isinstance(gen.code, Code)
    assert isinstance(gen.unit_system, UnitSystem)
    assert isinstance(gen.file, File)
    assert isinstance(gen.numbers, Numbers)
    assert isinstance(gen.development, Development)
    assert isinstance(gen.hardware, Hardware)
    assert isinstance(gen.clothing, Clothing)
    assert isinstance(gen.internet, Internet)
    assert isinstance

# Generated at 2022-06-12 01:52:07.413495
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.cryptographic import Cryptographic
    generic = Generic()
    class TestProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        class Meta:
            name = 'test_provider'
        def test(self):
            return 'test'
    t = TestProvider()
    generic.add_provider(TestProvider)
    generic.add_provider(Cryptographic)
    assert generic.test_provider.test() == 'test'
    assert generic.cryptographic.token_hex()
    g1 = Generic()
    g2 = Generic()
    assert g1.cryptographic.token_hex() != g2.cryptographic.token_hex()


# Generated at 2022-06-12 01:52:14.764176
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test the add_provider method of class Generic
    to add a custom provider.
    """
    class Provider(BaseProvider):
        """Test class."""

        class Meta:
            """Class for metadata."""

            name = 'test'

        def test(self, a, b):
            """This is a test function."""
            return a + b

    generic = Generic()

    generic.add_provider(Provider)
    assert hasattr(generic, 'test')


# Generated at 2022-06-12 01:52:21.358543
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class A(BaseProvider):
        pass

    class B(BaseProvider):
        pass

    class C(BaseProvider):
        pass

    generic = Generic()
    generic.add_provider(A)
    generic.add_provider(B)
    generic.add_provider(C)
    assert isinstance(generic.a, A)
    assert isinstance(generic.b, B)
    assert isinstance(generic.c, C)


# Generated at 2022-06-12 01:52:24.475747
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.builtins import RussiaSpecProvider

    generic = Generic('ru')
    generic.add_provider(RussiaSpecProvider)
    assert hasattr(generic, 'russia_spec')
    assert isinstance(generic.russia_spec, BaseProvider)


# Generated at 2022-06-12 01:52:25.206774
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    getattr(Generic(), 'person')

# Generated at 2022-06-12 01:52:26.585439
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    d = Generic()
    d.person.name()


# Generated at 2022-06-12 01:52:27.778642
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert None != Generic().add_provider()


# Generated at 2022-06-12 01:52:37.912489
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('es')
    assert g.person.last_name() == 'Álvarez'
    assert g.person.full_name() == 'Teresa Ruiz Álvarez'
    assert g.address.postal_code() == '03594'
    assert g.business.company().startswith('Hotel')
    assert g.text.sentence() == 'Quod.'
    assert g.food.meat() == 'Chuletas de cerdo'
    assert g.science.particle() == 'bosón Z'
    assert g.transport.airplane_model() == 'Boeing 767-300'
    assert g.code.imei() == '785769172318305'
    assert g.unit_system.pressure() == 'kPa'
    assert g.file.extension().startsw