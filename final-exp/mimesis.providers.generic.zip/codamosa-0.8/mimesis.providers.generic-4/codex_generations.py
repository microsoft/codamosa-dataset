

# Generated at 2022-06-12 01:51:42.797919
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Case 1
    generic = Generic()
    expected = ['person', 'address', 'datetime', 'business', 'text', 'food', 'science', 'transport', 'code', 'unit_system', 'file', 'numbers', 'development', 'hardware', 'clothing', 'internet', 'path', 'payment', 'cryptographic', 'structure', 'choice']
    assert set(dir(generic)) == set(expected)
    generic.__getattr__('person')
    assert 'person' in generic.__dict__

    # Case 2
    generic = Generic()
    generic.__getattr__('person')
    assert 'person' in generic.__dict__

# Generated at 2022-06-12 01:51:46.733310
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Person_test(Person):
        class Meta:
            name = 'person'
    generic = Generic()
    original_len = len(generic.__dir__())
    generic.add_provider(Person_test)
    new_len = len(generic.__dir__())
    assert original_len == new_len - 1
    assert generic.__dir__().__contains__('person')


# Generated at 2022-06-12 01:51:48.357784
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    pass

# Generated at 2022-06-12 01:51:58.699871
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    providers = [BaseProvider, Person, Datetime]
    custom_provider = type("CustomProvider", (BaseProvider,), {
        "Meta": type("Meta", (), {
            "name": "custom_provider"
        })
    })

    class Provider0(BaseProvider):
        """Provider class."""
        class Meta:
            """Metaclass."""
            name = "provider0"

    class Provider1(BaseProvider):
        """Provider class."""
        class Meta:
            """Metaclass."""
            name = "provider1"

    class Provider2(BaseProvider):
        """Provider class."""
        class Meta:
            """Metaclass."""
            name = "provider2"

    class Provider3(BaseProvider):
        """Provider class."""

# Generated at 2022-06-12 01:52:00.855114
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    person = Generic().person.full_name()
    assert isinstance(person, str)



# Generated at 2022-06-12 01:52:02.592494
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def foo(self):
            return 'bar'

    generic = Generic()
    generic.add_provider(MyProvider)

    assert generic
    assert generic.foo() == 'bar'


# Generated at 2022-06-12 01:52:08.389575
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('en')
    assert gen.person.__class__.__name__ == 'Person'
    assert gen.address.__class__.__name__ == 'Address'
    assert gen.datetime.__class__.__name__ == 'Datetime'
    assert gen.business.__class__.__name__ == 'Business'
    assert gen.text.__class__.__name__ == 'Text'
    assert gen.food.__class__.__name__ == 'Food'
    assert gen.science.__class__.__name__ == 'Science'


# Generated at 2022-06-12 01:52:19.270504
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Init
    generic = Generic()
    # Run
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)

# Generated at 2022-06-12 01:52:24.476359
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Create a custom provider and add it to the Generic() object."""
    from mimesis.providers.base import BaseProvider

    class Provider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Meta class."""

            name = 'provider'

    generic = Generic()
    generic.add_provider(Provider)
    assert isinstance(generic.provider, Provider)



# Generated at 2022-06-12 01:52:31.485032
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure


# Generated at 2022-06-12 01:52:52.056163
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from .custom import Custom
    from .custom import TestClass

    custom = Custom()
    generic = Generic()
    generic.add_provider(custom.TestClass)

    assert hasattr(generic, 'test_class')
    assert isinstance(generic.test_class, TestClass)


# Generated at 2022-06-12 01:53:01.565417
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()

    # Test method Person
    assert g.person.full_name() == 'Nathan Webb'

    # Test method address
    assert g.address.city() == 'Bulwell'

    # Test method datetime
    assert g.datetime.month_name() == 'March'

    # Test method business
    assert g.business.company() == 'Taylor, Stokes and Lynch'

    # Test method text
    assert g.text.word() == 'similique'

    # Test method food
    assert g.food.fruit() == 'Banana'

    # Test method science
    assert g.science.planet() == 'Mercury'

    # Test method transport
    assert g.transport.route() == '1'

    # Test method code

# Generated at 2022-06-12 01:53:02.384910
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass



# Generated at 2022-06-12 01:53:06.327721
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(g.address)
    assert callable(g.person)
    assert callable(g.datetime)
    # assert isinstance(g.address, Address)
    # assert g.address().__class__.__name__ in g.__dir__()


# Generated at 2022-06-12 01:53:08.508666
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .custom_provider import Custom
    generic = Generic()
    Generic.add_provider(generic, Custom)
    assert hasattr(generic, 'custom')


# Generated at 2022-06-12 01:53:12.912059
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider method."""
    gen = Generic()
    assert len(gen.__dir__()) == 36
    gen.add_provider(Business)
    assert len(gen.__dir__()) == 37
    gen.add_provider(Business)
    assert len(gen.__dir__()) == 37

# Generated at 2022-06-12 01:53:16.266113
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic('en')
    assert callable(provider._person)
    assert isinstance(provider.person, Person)
    assert isinstance(provider.person.full_name(), str)
    assert issubclass(provider.person.__class__, BaseDataProvider)

# Generated at 2022-06-12 01:53:21.334869
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # we call a method without underscore
    generic = Generic('en')
    assert generic.text
    assert isinstance(generic.text, Text) == True
    assert generic.text.sentence()
    assert generic.person
    assert isinstance(generic.person, Person) == True
    assert generic.person.fema

# Generated at 2022-06-12 01:53:29.049577
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    # Test if method returns instance of the Person class
    person = Generic().person
    assert isinstance(person, Person)

    # Test if method returns instance of the Address class
    address = Generic().address
    assert isinstance(address, Address)

    # Test if method returns instance of the Datetime class
    datetime = Generic().datetime
    assert isinstance(datetime, Datetime)

    # Test if method returns instance of the Business class
    business = Generic().business
    assert isinstance(business, Business)

    # Test if method returns instance of the Text class
    text = Generic().text
    assert isinstance(text, Text)

    # Test if method returns instance of the Food class
    food = Generic().food
    assert isinstance(food, Food)

    # Test if

# Generated at 2022-06-12 01:53:35.196121
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    class Provider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'new'
    generic.add_provider(Provider)
    assert hasattr(generic, 'new')
