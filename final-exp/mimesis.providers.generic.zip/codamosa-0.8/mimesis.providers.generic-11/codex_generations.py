

# Generated at 2022-06-12 01:51:48.087180
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.media import Media
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.providers.utils import gen_choice
    g = Generic()
    g.add_provider(Media)
    g.add_provider(Person)
    print(g.media.music_album())
    print(g.media.movie())
    print(g.media.tv_show())
    g.person.config['gender'] = gen_choice(Gender.FEMALE)
    print(g.person.full_name())
    print(g.person.occupation())



# Generated at 2022-06-12 01:51:53.791903
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('nl')
    generic.add_provider(Person)
    generic.add_provider(Address)

    assert hasattr(generic, 'person') is True
    assert hasattr(generic, 'address') is True
    assert isinstance(generic.person, Person) is True
    assert isinstance(generic.address, Address) is True



# Generated at 2022-06-12 01:52:01.217543
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    gr = Generic()
    gr.add_provider(Business)
    assert hasattr(gr, 'business')
    gr.add_provider(Food)
    assert hasattr(gr, 'food')
    gr.add_provider(Code)
    assert hasattr(gr, 'code')
    gr.add_provider(UnitSystem)
    assert hasattr(gr, 'unit_system')
    gr.add_provider(File)
    assert hasattr(gr, 'file')
    gr.add_provider(Development)
    assert hasattr(gr, 'development')
    gr.add_provider(Hardware)
    assert hasattr(gr, 'hardware')
    gr.add_provider(Transport)

# Generated at 2022-06-12 01:52:09.145088
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import os
    import unittest
    class TestProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'test_provider'

        def __getattr__(self, attrname):
            return attrname
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.seed = os.getenv('MIMESIS_SEED')
        def test_add_provider_success(self):
            self.generic = Generic(seed=self.seed)
            self.generic.add_provider(TestProvider)

# Generated at 2022-06-12 01:52:20.053889
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic(seeder=1)
    assert 'address' in g.__dir__()
    assert 'file' in g.__dir__()
    assert g.__dir__() == ['address', 'choice', 'clothing', 'code', 'cryptographic',
                           'data_provider', 'datetime', 'development', 'file', 'food', 'generic', 'hardware',
                           'internet', 'numbers', 'path', 'payment', 'person', 'science', 'text', 'transport',
                           'unit_system']
    g.add_provider(Text)
    assert 'text' in g.__dir__()

# Generated at 2022-06-12 01:52:23.577406
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person

    obj = Generic()
    obj.add_provider(Person)
    assert obj.person.full_name() != None



# Generated at 2022-06-12 01:52:26.267448
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class New(BaseDataProvider):
        class Meta:
            name = 'new'
        def method(self):
            return "NEW DATA PROVIDER"
    g = Generic()
    g.add_provider(New)
    assert g.new.method() == "NEW DATA PROVIDER"

# Generated at 2022-06-12 01:52:28.190789
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    get_attr = Generic()
    get_attr.person.name()
    assert getattr(get_attr, 'person')

# Generated at 2022-06-12 01:52:35.208729
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    class TestProvider(BaseProvider):
        """Test provider."""

        class Meta:
            """Class for metadata."""

            name = 'test_provider'

        def foobar(self):
            return 'foobar'

    g = Generic()
    g.add_provider(TestProvider)
    assert hasattr(g, 'test_provider')
    assert type(g.test_provider) == TestProvider
    assert g.test_provider.foobar() == 'foobar'



# Generated at 2022-06-12 01:52:38.911088
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomBaseProvider(BaseProvider):
        class Meta:
            name = 'Custom'

        def foo(self):
            return 'foo'

    expected = 'foo'
    g = Generic()
    g.add_provider(CustomBaseProvider)
    assert g.custom.foo() == expected
