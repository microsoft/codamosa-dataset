

# Generated at 2022-06-12 01:51:42.060031
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    obj = Generic(seed=4)
    assert obj.datetime.de() == 'Mittwoch, April 2, 2008, 21:35:54'
    assert obj.person.name() == 'Pete'
    assert len(obj.person.full_name()) == 13
    assert obj.person.phone_number() == '32-401-1036'
    assert len(obj.person.name()) == 4


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-12 01:51:43.706380
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic()
    assert provider.person().full_name() == provider.person().full_name()

# Generated at 2022-06-12 01:51:45.956237
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    for i in generic.__dir__():
        assert generic.__getattr__(i) == getattr(generic, i)

# Generated at 2022-06-12 01:51:53.285482
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'
        def test(self, *args, **kwargs): pass

    foo = Generic()
    foo.add_provider(TestProvider)
    assert hasattr(foo, 'test')
    assert callable(getattr(foo, 'test'))
    assert hasattr(foo, 'test_test')
    assert callable(getattr(foo, 'test_test'))



# Generated at 2022-06-12 01:52:00.985525
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-12 01:52:09.041810
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import DateTime
    import datetime

    test_datetime = DateTime()
    gen = Generic(seed=100)

    gen.add_provider(DateTime)
    assert gen.datetime.now().isoformat() == '2009-12-27T02:17:54'
    assert gen.datetime.date(start='2019-12-27',
                             end='2019-12-27').isoformat() == '2019-12-27'
    assert gen.datetime.time(start='11:16:54',
                             end='11:16:54').isoformat() == '11:16:54'

# Generated at 2022-06-12 01:52:14.127789
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():

    import mimesis.builtins

    g = Generic('ru')
    g.add_provider(mimesis.builtins.Gender)

    assert g.gender.male() == 'мужской'
    assert isinstance(g.choice, Choice) is True



# Generated at 2022-06-12 01:52:15.406449
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic()
    a.person
    a.address



# Generated at 2022-06-12 01:52:15.944297
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass

# Generated at 2022-06-12 01:52:17.715850
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""



# Generated at 2022-06-12 01:52:37.624848
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic()
    assert x.datetime is not None
    assert x.datetime.time == '09:38:57'
    assert x.choice.boolean() is True
    assert x.choice.from_dict(
        {'a': 1, 'b': 2, 'c': 3}
    ) in ('a', 'b', 'c')
    assert x.choice.from_set(
        {'a', 'b', 'c'}
    ) in ('a', 'b', 'c')



# Generated at 2022-06-12 01:52:40.827669
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g._person
    g.person
    assert callable(g.person.full_name)



# Generated at 2022-06-12 01:52:51.815460
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    instance = Generic(seed=1)

    assert instance.person.__class__.__name__ == 'Person'
    assert instance.address.__class__.__name__ == 'Address'
    assert instance.datetime.__class__.__name__ == 'Datetime'
    assert instance.business.__class__.__name__ == 'Business'
    assert instance.text.__class__.__name__ == 'Text'
    assert instance.food.__class__.__name__ == 'Food'
    assert instance.science.__class__.__name__ == 'Science'
    assert instance.transport.__class__.__name__ == 'Transport'
    assert instance.code.__class__.__name__ == 'Code'
    assert instance.unit_system.__class__.__name__ == 'UnitSystem'

# Generated at 2022-06-12 01:53:01.360639
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Foo(BaseProvider):
        def bar(self):
            return self.datetime.datetime()


    class Foo2(BaseProvider):
        def bar(self):
            return self.datetime.date()


    generic = Generic()
    try:
        generic.add_provider(Foo().__class__)
        assert True
    except TypeError:
        assert False

    try:
        generic.add_provider(int)
        assert False
    except TypeError:
        assert True

    try:
        generic.add_providers(Foo().__class__, Foo2().__class__)
        assert True
    except TypeError:
        assert False


# Generated at 2022-06-12 01:53:06.442967
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def test(self):
            return 'test'
    cls = Generic()
    cls()
    cls.add_provider(TestProvider)

    assert hasattr(cls, 'test')


# Generated at 2022-06-12 01:53:08.627350
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person
    g.address
    g.datetime
    g.business
    g.text
    g.food
    g.science



# Generated at 2022-06-12 01:53:11.336516
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    g = Generic()

    with pytest.raises(AttributeError):
        g.person

    assert isinstance(g._person(), Person)

# Generated at 2022-06-12 01:53:14.495206
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test to get attribute without underscore."""
    # When attrname not in self.__dict__
    gen = Generic()
    assert gen.person
    # When attrname in self.__dict__
    gen = Generic()
    assert gen.person
    assert gen.person


# Generated at 2022-06-12 01:53:18.876158
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    def test1():
        g = Generic()
        assert g.person
        assert not g._person
        assert g.person

    def test2():
        g = Generic()
        g._person = Person(locale = 'en', seed = 1)
        assert g.person
        assert g._person
        assert g.person

    test1()
    test2()


# Generated at 2022-06-12 01:53:28.283032
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class Foo(BaseProvider):
        def __init__(self, *args, **kwargs):
            BaseProvider.__init__(self, *args, **kwargs)

        class Meta(BaseProvider.Meta):
            name = 'foo'


    class Bar(BaseProvider):
        def __init__(self, *args, **kwargs):
            BaseProvider.__init__(self, *args, **kwargs)

        class Meta(BaseProvider.Meta):
            name = 'bar'

    gen = Generic()
    gen.add_provider(Foo)
    gen.add_provider(Bar)
    assert isinstance(gen.foo, Foo)
    assert isinstance(gen.bar, Bar)
