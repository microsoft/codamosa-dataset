

# Generated at 2022-06-12 01:52:00.824844
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        def method(self):
            return self.datetime.datetime(0, tzinfo=None)

    class Test(BaseProvider):
        class Meta:
            name = 'test'

    class Test2(BaseProvider):
        class Meta:
            name = 'test2'

        def method(self):
            return self.pseudo_random.random()

    obj = Generic()
    obj.add_provider(Provider)
    assert isinstance(obj.provider, Provider)
    assert obj.provider.method() == obj.provider.method()

    obj.add_providers(Test, Test2)
    assert obj.test2.method() == obj.test2.method()
    assert obj.test.method() != obj.test.method()

# Generated at 2022-06-12 01:52:08.993297
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic.
    """
    # This example is not a real provider, it is only for
    # the test, because I don't want to write a real provider.
    class Color(BaseProvider):
        """Example class.
        """

# Generated at 2022-06-12 01:52:14.479629
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    assert not hasattr(g, 'test')
    g.add_provider(TestProvider)
    assert hasattr(g, 'test')
    g.add_provider(TestProvider)
    g.add_provider(TestProvider)
    assert len(g.__dir__()) == 3



# Generated at 2022-06-12 01:52:18.015920
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Check when attrname is 'person'
    generic = Generic()
    assert generic.person is not None

    # Check when attrname is not 'person'
    generic = Generic()
    assert generic.address is not None


# Generated at 2022-06-12 01:52:20.052447
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.food.__class__ == gen._food
    assert gen.food.__class__ == Food
    


# Generated at 2022-06-12 01:52:23.578025
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
	gen = Generic()
	gen.add_provider(Povider)
	assert 'povider' in gen.__dir__()
	assert type(gen.povider) == Povider

# Generated at 2022-06-12 01:52:27.310627
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Custom(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def method(self):
            return "method"

    g = Generic()
    g.add_provider(Custom)
    assert hasattr(g, 'custom_provider')
    assert g.custom_provider.method() == "method"
