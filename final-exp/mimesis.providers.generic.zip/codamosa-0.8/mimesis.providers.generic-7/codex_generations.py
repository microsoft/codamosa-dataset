

# Generated at 2022-06-12 01:52:01.117759
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    for i in range(4):
        assert g.person.name(i)
        assert g.address.city(i)
        assert g.datetime.month(i)
        assert g.business

# Generated at 2022-06-12 01:52:04.543043
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person.name() == 'Brent Barton'
    assert g.person.full_name() == 'Brent Barton'
    assert g.person.occupation() == 'Civil Engineer'


# Generated at 2022-06-12 01:52:09.203098
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    import pytest
    test_obj = Generic()
    test_obj.__getattr__("person")
    assert "person" in test_obj
    with pytest.raises(AttributeError):
        test_obj.__getattr__("wrong_attr")


# Generated at 2022-06-12 01:52:13.512451
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('ru')
    assert generic.person.full_name() == 'Павел Гришин'
    person = Person('ru')
    assert generic.person == person
