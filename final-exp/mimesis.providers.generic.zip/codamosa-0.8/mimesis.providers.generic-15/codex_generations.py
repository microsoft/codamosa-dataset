

# Generated at 2022-06-12 01:51:44.281247
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test to get attribute without underscore."""
    g = Generic()
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
    assert g.business is not None
    assert g.text is not None
    assert g.food is not None
    assert g.science is not None


# Generated at 2022-06-12 01:51:50.099529
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    dp = Generic()
    class Test(BaseProvider):
        """Test."""
        class Meta:
            """Test."""
            name = 'test'

    assert hasattr(dp, 'test') is False
    dp.add_provider(Test)
    assert hasattr(dp, 'test') is True



# Generated at 2022-06-12 01:51:53.647091
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('ru')
    # attrname = 'datetime'
    # __getattr__(self, attrname: str) -> Any
    # getattr(g, attrname)
    # returns Datetime object



# Generated at 2022-06-12 01:51:59.789633
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    p = g.person()
    assert '_person' in dir(g)
    assert '_person' in g.__dir__()
    assert 'person' in g.__dir__()
    assert g.person is not None
    assert 'person' not in g.__dict__
    assert '_person' in g.__dict__
    assert isinstance(g.person, Person)
    assert isinstance(g.person, BaseProvider)
    assert isinstance(p, Person)
    assert isinstance(p, BaseProvider)

# Generated at 2022-06-12 01:52:01.947254
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    # TODO
    pass

# Generated at 2022-06-12 01:52:06.450120
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Tests for method add_provider."""
    context = Generic()
    class TestProvider(BaseProvider):
        pass
    context.add_provider(TestProvider)
    assert context.testprovider
    assert isinstance(context.testprovider, TestProvider)

if __name__ == '__main__':
    test_Generic_add_provider()

# Generated at 2022-06-12 01:52:17.715049
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    test_obj = Generic()
    test_obj.__getattr__('address')
    test_obj.__getattr__('business')
    test_obj.__getattr__('clothing')
    test_obj.__getattr__('code')
    test_obj.__getattr__('cryptographic')
    test_obj.__getattr__('datetime')
    test_obj.__getattr__('development')
    test_obj.__getattr__('file')
    test_obj.__getattr__('food')
    test_obj.__getattr__('hardware')
    test_obj.__getattr__('internet')
    test_obj.__getattr__('numbers')
    test_obj.__getattr__('payment')
    test_obj.__getattr__('person')
    test_obj

# Generated at 2022-06-12 01:52:26.408122
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, BaseProvider)
    assert isinstance(generic.address, BaseProvider)
    assert isinstance(generic.datetime, BaseProvider)
    assert isinstance(generic.business, BaseProvider)
    assert isinstance(generic.text, BaseProvider)
    assert isinstance(generic.food, BaseProvider)
    assert isinstance(generic.science, BaseProvider)
    assert isinstance(generic.transport, BaseProvider)
    assert isinstance(generic.code, BaseProvider)
    assert isinstance(generic.unit_system, BaseProvider)
    assert isinstance(generic.file, BaseProvider)
    assert isinstance(generic.numbers, BaseProvider)
    assert isinstance(generic.development, BaseProvider)
    assert isinstance(generic.hardware, BaseProvider)

# Generated at 2022-06-12 01:52:29.720002
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')
    attributes = generic.__dir__()
    for attr in attributes:
        attr = getattr(generic, attr)
    assert generic.business
    assert generic.food
    assert generic.person
    assert generic.text


# Generated at 2022-06-12 01:52:33.468900
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test that the function add_provider is working correctly."""
    from mimesis.providers import Provider
    generic = Generic()
    generic.add_provider(Provider)
    assert 'provider' in generic.__dir__()

