

# Generated at 2022-06-12 01:51:42.569769
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person

    generic = Generic()
    generic.add_provider(Person)
    assert generic.person is not None



# Generated at 2022-06-12 01:51:43.881976
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic()._address == Address
    assert Generic().__getattr__('address') == Address

# Generated at 2022-06-12 01:51:55.537758
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.datetime  # noqa: F841
    generic.person  # noqa: F841
    generic.business  # noqa: F841
    generic.text  # noqa: F841
    generic.food  # noqa: F841
    generic.science  # noqa: F841
    assert generic.transport  # noqa: F841
    assert generic.code  # noqa: F841
    assert generic.unit_system  # noqa: F841
    assert generic.file  # noqa: F841
    assert generic.numbers  # noqa: F841
    assert generic.development  # noqa: F841
    assert generic.hardware  # noqa: F841
    assert generic.internet  # noqa: F

# Generated at 2022-06-12 01:51:57.065759
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.food
    assert hasattr(g, 'food')



# Generated at 2022-06-12 01:52:06.052027
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person == g._person(g.locale, g.seed)
    assert g.address == g._address(g.locale, g.seed)
    assert g.datetime == g._datetime(g.locale, g.seed)
    assert g.business == g._business(g.locale, g.seed)
    assert g.text == g._text(g.locale, g.seed)
    assert g.food == g._food(g.locale, g.seed)
    assert g.science == g._science(g.locale, g.seed)


# Generated at 2022-06-12 01:52:17.620913
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Create instance of class Generic
    generic = Generic()
    print("[+] Success: Create instance of class Generic")
    # Test method text of class Generic
    print("[+] Success: Test method text of class Generic")
    print("[+] Success: Test method word of class Generic")
    print("[+] Success: Test method sentence of class Generic")
    print("[+] Success: Test method paragraph of class Generic")
    print("[+] Success: Test method title of class Generic")
    print("[+] Success: Test method text of class Generic")
    # Test method person of class Generic
    print("[+] Success: Test method person of class Generic")
    print("[+] Success: Test method full_name of class Generic")
    print("[+] Success: Test method name of class Generic")

# Generated at 2022-06-12 01:52:26.349203
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert callable(Generic.Meta)
    assert callable(Generic.__getattr__)
    assert callable(Generic.__dir__)
    assert callable(Generic.add_provider)
    assert callable(Generic.add_providers)
    assert callable(Generic.__init__)
    assert Generic.Meta.name == 'generic'
    assert Generic().internet
    assert Generic().internet.username()
    assert Generic().internet.ipv4_address()
    assert Generic().internet.ipv6_address()
    assert Generic().internet.domain_name()
    assert Generic().internet.uri()
    assert Generic().internet.uri_extension()
    assert Generic().internet.url()
    assert Generic().internet.tld()
    assert Generic().internet.sld()
    assert Generic().internet.mac_address()
   

# Generated at 2022-06-12 01:52:30.955726
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic(seed=12345)
    assert x.person.name() == 'Lorenzo Sample'
    assert x.business.uuid() == '37cb79f0-8123-5e1a-b7a2-9e8986512ca0'
    assert x.person.birthday() == '2002-06-06'

# Generated at 2022-06-12 01:52:38.358496
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice


# Generated at 2022-06-12 01:52:45.495786
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender

    class SomeProvider(BaseProvider):
        class Meta:
            name = 'some_provider'

        def foo(self) -> str:
            return 'foo'

    class CustomPerson(Person):
        @Person.name.variant(gender=Gender.FEMALE)
        def female_name(cls) -> str:
            return 'Barbie'

    g = Generic()
    g.add_provider(SomeProvider)
    g.add_providers(
        CustomPerson,
    )

    assert hasattr(g, 'some_provider')
    assert hasattr(g, 'foo')
    assert hasattr(g, 'custom_person')
    assert hasattr(g, 'female_name')

# Generated at 2022-06-12 01:53:08.169572
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import Datetime as CustomDatetime

    g = Generic()
    g.add_provider(CustomDatetime)

# Generated at 2022-06-12 01:53:11.184914
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person

    g = Generic()
    g.add_provider(Person)
    assert hasattr(g, 'person')

# Generated at 2022-06-12 01:53:18.225147
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyCustomProvider(BaseProvider):

        class Meta:
            name = 'my_custom_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.__version__ = '0.0.1'

        def my_custom_method(self):
            return 'outout_of_my_custom_method'

    my_gen = Generic()
    my_gen.add_provider(MyCustomProvider)
    assert hasattr(my_gen, 'my_custom_provider')
    assert hasattr(my_gen.my_custom_provider, 'my_custom_method')
    assert my_gen.my_custom_provider.my_custom_method() == 'outout_of_my_custom_method'


# Unit

# Generated at 2022-06-12 01:53:22.239396
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('en')

    assert generic.person
    assert generic.address
    assert generic.datetime
    assert generic.business
    assert generic.text
    assert generic.food
    assert generic.science
    assert generic.transport
    assert generic.code
    assert generic.unit_system
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic
    assert generic.structure
    assert generic.choice


# Generated at 2022-06-12 01:53:27.886930
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, seed: Any = None):
            super().__init__(seed)

        class Meta:
            name = 'custom_provider'

        def method(self):
            return 'foo'

    gen = Generic()

    assert not hasattr(gen, 'custom_provider')
    gen.add_provider(CustomProvider)
    assert hasattr(gen, 'custom_provider')
    assert gen.custom_provider.method() == 'foo'



# Generated at 2022-06-12 01:53:37.884664
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    print('Testing method add_provider of class Generic')
    generic = Generic()
    generic.add_provider(Person)
    assert dict.__len__(generic.__dict__) == 25
    generic.add_provider(Address)
    assert dict.__len__(generic.__dict__) == 26
    generic.add_provider(Datetime)
    assert dict.__len__(generic.__dict__) == 27
    generic.add_provider(Business)
    assert dict.__len__(generic.__dict__) == 28
    generic.add_provider(Text)
    assert dict.__len__(generic.__dict__) == 29
    generic.add_provider(Food)
    assert dict.__len__(generic.__dict__) == 30
    generic.add_provider(Science)

# Generated at 2022-06-12 01:53:40.659764
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person
    g = Generic()
    g.add_provider(Person)
    assert (hasattr(g, 'person'))


# Generated at 2022-06-12 01:53:44.453997
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Test lowercase
    g = Generic()
    g.food
    assert g.food.__class__.__name__ == 'Food'
    assert g.food.locale == g.locale
    assert g.food.seed == g.seed
    # Test uppercase
    g = Generic()
    g.Food
    assert g.Food.__class__.__name__ == 'Food'
    assert g.Food.locale == g.locale
    assert g.Food.seed == g.seed

# Generated at 2022-06-12 01:53:45.977524
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass


# Generated at 2022-06-12 01:53:51.410324
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        class Meta:
            name = 'provider'

        def my_method(self, *args, **kwargs):
            return 'I am in new Provider!'

    provider = MyProvider()
    generic = Generic()
    generic.add_provider(MyProvider)
    assert provider.my_method() == generic.provider.my_method()