

# Generated at 2022-06-12 01:51:43.133316
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Initialize class
    G = Generic('ru')

    # Check getting of exist attribute
    assert (G.person)

    # Check getting of unexist attribute
    assert (G.custom)



# Generated at 2022-06-12 01:51:49.138404
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    generic = Generic('en')
    assert generic.person() is not None
    assert generic.address() is not None
    assert generic.datetime() is not None
    assert generic.business() is not None
    assert generic.text() is not None
    assert generic.food() is not None
    assert generic.transport() is not None
    assert generic.code() is not None
    assert generic.unit_system() is not None
    assert generic.file() is not None
    assert generic.numbers() is not None
    assert generic.development() is not None
    assert generic.hardware() is not None
    assert generic.clothing() is not None
    assert generic.internet() is not None
    assert generic.path() is not None
    assert generic.payment() is not None


# Generated at 2022-06-12 01:51:58.039359
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    from mimesis.providers.network import Network
    from mimesis.providers.software import Software

    custom_provider1 = Network(seed=1000)
    custom_provider2 = Software(seed=1000)
    provider = Generic(seed=1000)

    provider.add_provider(Network)
    provider.add_provider(Software)
    assert hasattr(provider, 'network')
    assert hasattr(provider, 'software')
    assert provider.network.mac_address() == custom_provider1.mac_address()
    assert provider.software.application_name() == custom_provider2.application_name()


# Generated at 2022-06-12 01:52:07.880081
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person) is True
    assert isinstance(g.address, Address) is True
    assert isinstance(g.datetime, Datetime) is True
    assert isinstance(g.business, Business) is True
    assert isinstance(g.text, Text) is True
    assert isinstance(g.food, Food) is True
    assert isinstance(g.science, Science) is True
    assert isinstance(g.transport, Transport) is True
    assert isinstance(g.code, Code) is True
    assert isinstance(g.unit_system, UnitSystem) is True
    assert isinstance(g.file, File) is True
    assert isinstance(g.numbers, Numbers) is True
    assert isinstance(g.development, Development) is True
    assert isinstance

# Generated at 2022-06-12 01:52:10.288440
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.generic import Generic

    _generic = Generic()
    assert _generic.address



# Generated at 2022-06-12 01:52:21.630071
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import pytest
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider, BaseDataProvider

    class CustomProvider(BaseProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    class FooProvider(BaseProvider):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def foo(self):
            return 'bar'

    class Meta:
        name = 'foo'

    FooProvider.Meta = Meta  # type: ignore

    gen = Generic()

    gen.add_provider(CustomProvider)
    gen.add_provider(FooProvider)

    assert gen

# Generated at 2022-06-12 01:52:27.556860
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    foo = Generic()
    foo.add_provider(Person)
    assert 'person' in dir(foo)
    foo.add_provider(Address)
    assert 'address' in dir(foo)
    foo.add_provider(Datetime)
    assert 'datetime' in dir(foo)
    foo.add_provider(Business)
    assert 'business' in dir(foo)
    foo.add_provider(Text)
    assert 'text' in dir(foo)
    foo.add_provider(Food)
    assert 'food' in dir(foo)
    foo.add_provider(Science)
    assert 'science' in dir(foo)


# Generated at 2022-06-12 01:52:37.704816
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic()
    assert type(a.person.identifier) == str
    assert type(a.business.nip) == str
    assert type(a.address.address) == str
    assert type(a.clothing.tshirt()) == str
    assert type(a.unit_system.mass()) == str
    assert type(a.datetime.datetime()) == str
    assert type(a.datetime.date()) == str
    assert type(a.datetime.time()) == str
    assert type(a.datetime.date(start=2010, end=2017)) == str
    assert type(a.datetime.datetime(start=2010, end=2017)) == str
    assert type(a.datetime.date(formatted=False)) == list

# Generated at 2022-06-12 01:52:41.623852
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def foo(self):
            return 'bar'

    g = Generic()
    g.add_provider(Test)
    assert g.test.foo() == 'bar'

# Generated at 2022-06-12 01:52:52.044424
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    print(g.person.age())
    print(g.person.date_of_birth())
    print(g.address.address())
    print(g.address.city())
    print(g.datetime.time())
    print(g.datetime.date())
    print(g.datetime.datetime())
    print(g.datetime.datetime_object())
    print(g.datetime.month())
    print(g.datetime.year())
    print(g.business.company())
    print(g.text.text())
    print(g.food.fruit())
    print(g.food.vegetables())
    print(g.science.chemical_element())
    print(g.science.chemical_compound())
    print(g.transport.cars())

# Generated at 2022-06-12 01:53:16.906845
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    provider = Generic()
    assert not hasattr(provider, 'test')
    provider.add_provider(BaseProvider)
    assert hasattr(provider, 'test')

# Generated at 2022-06-12 01:53:24.886599
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

    class CustomProvider2(BaseProvider):
        class Meta:
            name = 'custom2'

    g = Generic(seed=1)
    assert 'custom' not in dir(g)
    assert 'custom2' not in dir(g)
    g.add_provider(CustomProvider)
    assert 'custom' in dir(g)
    g.add_providers(CustomProvider2)
    assert 'custom2' in dir(g)
    g.__dict__.clear()

# Generated at 2022-06-12 01:53:26.545721
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for method __getattr__ of class Generic."""
    # TODO
    assert True

# Generated at 2022-06-12 01:53:33.172360
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert hasattr(Generic(), 'person')
    assert hasattr(Generic(), 'datetime')
    assert hasattr(Generic(), 'business')
    assert hasattr(Generic(), 'text')
    assert hasattr(Generic(), 'food')
    assert hasattr(Generic(), 'science')

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

    g = Generic()
    g.add_provider(TestProvider)
    assert hasattr(g, 'test')
    assert 'test' in g.__dir__()

# Generated at 2022-06-12 01:53:41.872911
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert hasattr(Generic(), "address")
    assert hasattr(Generic(), "business")
    assert hasattr(Generic(), "clothing")
    assert hasattr(Generic(), "code")
    assert hasattr(Generic(), "cryptographic")
    assert hasattr(Generic(), "datetime")
    assert hasattr(Generic(), "development")
    assert hasattr(Generic(), "file")
    assert hasattr(Generic(), "food")
    assert hasattr(Generic(), "hardware")
    assert hasattr(Generic(), "internet")
    assert hasattr(Generic(), "numbers")
    assert hasattr(Generic(), "payment")
    assert hasattr(Generic(), "path")
    assert hasattr(Generic(), "person")
    assert hasattr(Generic(), "science")
    assert hasattr(Generic(), "structure")

# Generated at 2022-06-12 01:53:50.234033
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method."""
    from mimesis.providers.base import BaseProvider
    generic = Generic()
    assert 'address' in generic.__dict__
    assert 'person' in generic.__dict__

    class CustomProvider(BaseProvider):
        """A custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def foo(self):
            """A foo method."""
            return 'foo'

    generic.add_provider(CustomProvider)
    assert 'custom' in generic.__dict__
    assert generic.custom.foo() == 'foo'



# Generated at 2022-06-12 01:53:55.621933
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test  of method add_provider of class Generic"""
    # Test adding custom provider
    g1 = Generic('ru')
    g1.add_provider(TestProvider)
    assert g1.test_provider.__class__ == TestProvider
    assert g1.test_provider.seed == g1.seed

    # Test adding class which not is a subclass of BaseProvider
    try:
        g1.add_provider(object)
        assert False
    except TypeError:
        assert True

    # Test adding non-class
    try:
        g1.add_provider(TestProvider())
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-12 01:53:59.288164
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    class CustomPerson(Person):
        class Meta:
            """Class for metadata."""
            name = 'fullname'
        def custom_provider(self, gender: Gender = None) -> str:
            return 'a Full name'
    generic = Generic()
    generic.add_provider(CustomPerson)
    assert isinstance(generic.fullname, CustomPerson)
    assert generic.fullname.custom_provider() == 'a Full name'

# Generated at 2022-06-12 01:54:04.021428
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('uk')
    #get Person provider
    assert isinstance(generic.person, Person)
    #get Person provider again
    assert isinstance(generic.person, Person)
    #get Address provider
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)

# Generated at 2022-06-12 01:54:13.427010
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Check if the method `add_provider` is working."""
    from mimesis.providers.numbers import Numbers
    class Custom(BaseProvider):
        """Docstring for Custom."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self._codes = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            self._numbers = Numbers(locale='en', seed=self.seed)

    generic = Generic()
    generic.add_provider(Custom)
    assert generic.custom