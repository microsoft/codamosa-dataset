

# Generated at 2022-06-12 01:51:40.053873
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-12 01:51:43.794315
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    test_attr = '_test'
    setattr(g, test_attr, g._address)
    assert g.test

# Generated at 2022-06-12 01:51:51.032105
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        def __init__(self, locale: str, seed: int):
            super().__init__(locale, seed)
        def foo(self):
            return 'foo'

    g = Generic()
    g.add_provider(CustomProvider)
    assert hasattr(g, 'customprovider')
    assert g.customprovider.foo() == 'foo'
    assert g.customprovider.locale == 'en'


# Generated at 2022-06-12 01:51:59.982090
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Test for a custom class
    class TestProvider(BaseProvider):
        class Meta:
            name = 'Test'
        def build(self):
            return 'Hello world!'

    provider = Generic('en')
    provider.add_provider(TestProvider)
    assert provider.Test.build() == 'Hello world!'
    provider.Test.seed(0)
    assert provider.Test.build() == 'Hello world!'

    # Test for a subclass of BaseProvider
    class TestProvider(BaseProvider):
        class Meta:
            name = 'Test'
        def build(self):
            return 'Hello world!'

    provider = Generic('en')
    provider.add_provider(TestSubclass)
    assert provider.Test.build() == 'Hello world!'
    provider.Test.seed(0)
    assert provider.Test.build()

# Generated at 2022-06-12 01:52:08.690952
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic."""
    from . import vehicle
    from .base import Provider
    gen = Generic()
    gen.add_provider(vehicle.Vehicle)
    provider = gen.vehicle
    assert provider.__class__.__name__ == "Vehicle"
    assert isinstance(gen.vehicle, vehicle.Vehicle)

    class Vehicle(Provider):
        """Vehicle Provider."""

        class Meta:
            """The name of the provider."""

            name = 'test'

        def make(self):
            """Make a test."""
            return 'test'

    gen.add_provider(Vehicle)
    assert gen.test.make() == 'test'
    assert isinstance(gen.test, Vehicle)
    assert Provider.__name__ == 'Provider'
   

# Generated at 2022-06-12 01:52:19.605281
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):

        class Meta:
            name = 'test'

        def test(self):
            pass

    provider = Generic()
    provider.add_provider(TestProvider)
    assert hasattr(provider, 'test')
    assert hasattr(provider, 'test_test')
    assert hasattr(provider.test, 'test')

    try:
        provider.add_provider(Generic)
    except TypeError:
        assert True
    else:
        assert False

    try:
        provider.add_provider(1)
    except TypeError:
        assert True
    else:
        assert False

    try:
        provider.add_provider(str)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 01:52:22.505413
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    test_instance = Generic()
    test_instance.add_provider(BaseProvider)
    assert hasattr(test_instance, 'BaseProvider')


# Generated at 2022-06-12 01:52:28.746846
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        """Create a fake provider."""

        class Meta:
            """Metadata."""

            name = 'my_provider'

        def __str__(self):
            """Representation of instance.

            :return: Instance representation.
            """
            cls = self.__class__.__name__
            return '<{}(locale={},  seed={})>'.format(
                cls,
                self._locale,
                self._seed,
            )

        def foo(self):
            """An example of a static method."""
            return self.random.choice(['bar', 'qux'])

    MyProviderSubclass = type('MyProviderSubclass', (MyProvider,), {})

    class MyDefaultProvider(BaseProvider):
        """Create a fake provider."""



# Generated at 2022-06-12 01:52:38.874442
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import Datetime as Date
    g = Generic()
    g.add_provider(Date)
    from mimesis.providers.datetime import Datetime as Date2
    g.add_provider(Date2)
    from mimesis.providers.datetime import Datetime as Date3
    g.add_provider(Date3)
    from mimesis.providers.datetime import Datetime as Date4
    g.add_provider(Date4)
    from mimesis.providers.datetime import Datetime as Date5
    g.add_provider(Date5)
    from mimesis.providers.datetime import Datetime as Date6
    g.add_provider(Date6)

# Generated at 2022-06-12 01:52:46.096889
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    from mimesis.enums import Gender

    class GenderProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'gender'

        def __init__(self, gender: str = '', seed: int = None, **kwargs) -> None:
            """Initialize attributes.

            :param gender: Gender.
            :param seed: Seed.
            """
            super().__init__(seed=seed, **kwargs)
            if gender not in Gender:
                raise ValueError('Unsupported gender')
            self._data = {
                'male': Gender.MALE,
                'female': Gender.FEMALE,
                'not_specified': Gender.NOT_SPECIFIED,
            }


# Generated at 2022-06-12 01:53:14.729014
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

    # def test__getattr__(self):
    #     """Test for get attribute without underscore."""
    #     attrs = ['person', 'address', 'datetime', 'business']
    #     for attr in attrs:
    #         self.assertTrue(attr in self.obj.__dir__())
    #         self.assertTrue(callable(getattr(self.obj, attr)))

    # def test__dir__(self):
    #     """Test for available data providers."""
    #     dir_obj = self.obj.__dir__()
    #     self.assertGreater(len(dir_obj), 0)

    # def test_add_provider(self):
    #     """Test add_provider."""
    #     class NewProvider(BaseProvider):
    #         """NewProvider

# Generated at 2022-06-12 01:53:25.567103
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.name.title() == 'Mr. Carl Smith'
    assert gen.address.street_name() == 'Heather Court'
    assert gen.city() == 'London'
    assert gen.country() == 'Cyprus'
    assert gen.region() == 'Lincolnshire'
    assert gen.building_number() == '112'
    assert gen.postal_code() == '3N3'
    assert gen.scientific_name() == 'Rhododendron'
    assert gen.brand() == 'Fujitsu'
    assert gen.product_name() == 'Leather Jacket'
    assert gen.payment_card_number() == '5403347085702575'
    assert gen.ascii_text() == 'Ylkc hzrctp rstrcg.'

# Generated at 2022-06-12 01:53:28.660114
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()

    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    g.add_provider(TestProvider)

    assert 'test_provider' in dir(g)



# Generated at 2022-06-12 01:53:33.511782
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)


# Generated at 2022-06-12 01:53:36.318628
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'


# Generated at 2022-06-12 01:53:37.533663
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)


# Generated at 2022-06-12 01:53:39.954494
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    foo = Generic()
    foo.add_provider(Person)
    assert foo.person.__class__.__name__ == 'Person'


# Generated at 2022-06-12 01:53:42.833479
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import ProgrammingLanguage
    g = Generic('en')
    g.add_provider(ProgrammingLanguage)
    lang = g.programming_language.get_language()
    assert (lang.lower() in g.programming_language._data['languages'])



# Generated at 2022-06-12 01:53:47.495121
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.payment import CardProvider
    from mimesis.providers.file import FileExtensionProvider
    mp = Generic()
    mp.add_provider(CardProvider)
    mp.add_provider(FileExtensionProvider)
    assert mp.card.card_type()
    assert mp.file.extension()

# Generated at 2022-06-12 01:53:55.661794
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ method."""
    g = Generic()
    # g.__getattr__('person')
    assert callable(g.person) is True
    assert callable(g.person) is True
    assert isinstance(g.person, Person) is True
    assert callable(g.get_current_locale) is True
    assert callable(g.__getattr__) is True
    assert callable(g.numbers) is True
    assert callable(g.development) is True
    assert callable(g.internet) is True
    assert callable(g.clothing) is True
    assert callable(g.structure) is True
    assert callable(g.choice) is True
    assert callable(g.path) is True
    assert callable(g.transport) is True
