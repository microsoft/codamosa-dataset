

# Generated at 2022-06-21 16:09:54.746054
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # test for positive
    generic = Generic('ru')
    cls = Person
    generic.add_provider(cls)


# Generated at 2022-06-21 16:10:06.629769
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    f = Generic()
    assert(f.person.first_name() != None)
    assert(f.address.city() != None)
    assert(f.datetime.date() != None)
    assert(f.business.company() != None)
    assert(f.text.word() != None)
    assert(f.food.ingredient() != None)
    assert(f.science.chemical_element() != None)
    assert(f.transport.fuel() != None)
    assert(f.code.codepoint() != None)
    assert(f.unit_system.unit() != None)
    assert(f.file.name() != None)
    assert(f.numbers.number() != None)
    assert(f.development.language() != None)

# Generated at 2022-06-21 16:10:07.715211
# Unit test for constructor of class Generic
def test_Generic():
    u1 = Generic()
    print(u1.address)

# Generated at 2022-06-21 16:10:09.807077
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic(seed=42)
    generic.add_providers()

# Generated at 2022-06-21 16:10:13.894759
# Unit test for constructor of class Generic
def test_Generic():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        @property
        def _provider(self) -> str:
            return 'CustomProvider'

        def my_method(self):
            return 'my_method'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom')
    assert generic.custom.my_method() == 'my_method'

# Generated at 2022-06-21 16:10:22.475656
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()

    assert generic.person
    assert generic.address
    assert generic.datetime
    assert generic.business
    assert generic.choice
    assert generic.text
    assert generic.food
    assert generic.science
    assert generic.transport
    assert generic.code
    assert generic.unit_system
    assert generic.file
    assert generic.numbers
    assert generic.development
    assert generic.hardware
    assert generic.clothing
    assert generic.internet
    assert generic.path
    assert generic.payment
    assert generic.cryptographic
    assert generic.structure


# Generated at 2022-06-21 16:10:24.104274
# Unit test for constructor of class Generic
def test_Generic():
    gr = Generic()
    assert gr.Meta.name == 'generic'

# Generated at 2022-06-21 16:10:34.714596
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic is not None
    assert isinstance(generic, Generic)
    assert isinstance(generic._address, Address)
    assert isinstance(generic._business, Business)
    assert isinstance(generic._datetime, Datetime)
    assert isinstance(generic._food, Food)
    assert isinstance(generic._person, Person)
    assert isinstance(generic._science, Science)
    assert isinstance(generic._text, Text)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_sys, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)

# Generated at 2022-06-21 16:10:40.804160
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.builtins import InternetProvider
    generic = Generic()
    generic.add_providers(RussiaSpecProvider, USASpecProvider, InternetProvider)
    assert callable(generic.russia)
    assert callable(generic.usa)
    assert callable(generic.internet)

# Generated at 2022-06-21 16:10:48.276361
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    r = Generic()
    r.address
    r.person
    r.business
    r.datetime
    r.text
    r.food
    r.science
    r.transport
    r.code
    r.unit_system
    r.file
    r.numbers
    r.development
    r.hardware
    r.clothing
    r.internet
    r.path
    r.payment
    r.cryptographic
    r.structure
    r.choice


# Generated at 2022-06-21 16:11:10.219126
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test Generic_add_providers."""
    # pylint: disable=protected-access
    # pylint: disable=no-member
    generic = Generic()
    generic.add_provider(Datetime)
    generic.add_provider(Datetime)
    assert 'datetime' in dir(generic)
    assert 'datetime' in generic._Generic__dict__
    generic.add_providers(Datetime, Datetime, Datetime)
    assert 'datetime' in dir(generic)
    assert 'datetime' in generic._Generic__dict__

# Generated at 2022-06-21 16:11:16.791710
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    g.person
    g.datetime
    g.address
    g.business
    g.text
    g.food
    g.science
    g.transport
    g.code
    g.unit_system
    g.file
    g.development
    g.hardware
    g.clothing
    g.internet
    g.numbers
    g.path
    g.cryptographic
    g.structure
    g.choice
    assert g.choice.__class__.__name__ == 'Choice'

# Generated at 2022-06-21 16:11:22.975092
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert obj is not None
    assert obj.__dict__
    assert obj.__class__
    assert obj.__dir__()
    assert obj.__doc__
    assert obj.__getattr__
    assert obj.__init__
    assert obj.__repr__
    assert obj.__module__
    assert obj.add_provider
    assert obj.add_providers
    assert obj.choice
    assert obj.code
    assert obj.cryptographic
    assert obj.development
    assert obj.file
    assert obj.hardware
    assert obj.internet
    assert obj.numbers
    assert obj.path
    assert obj.payment
    assert obj.structure
    assert obj.transport
    assert obj.unit_system

# Generated at 2022-06-21 16:11:31.683957
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test case for method add_providers of class Generic."""
    generic = Generic('en')
    # Instance of class Generic
    assert isinstance(generic, Generic)
    # generic.business attribute contains provider with name 'business'
    # But after execution of method add_providers it is no longer
    assert 'business' not in generic.__dict__.keys()
    # But after execution of method add_providers it is no longer
    assert 'business' in generic.__dir__()
    # Adding one more provider to Generic
    generic.add_provider(Business)
    # Now it is in dictionary
    assert 'business' in generic.__dict__.keys()
    # Class Business is a Provider
    assert isinstance(generic.business, Business)
    # After using method add_providers() 'business' attribute is no longer
   

# Generated at 2022-06-21 16:11:36.019099
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider of class Generic."""
    g = Generic('en')
    assert isinstance(Generic, type)
    assert issubclass(Generic, BaseDataProvider)
    assert hasattr(g, '_add_provider') and callable(g._add_provider)


# Generated at 2022-06-21 16:11:38.900181
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic('ru')
    assert len(g.__dir__()) == 38
    g.add_provider(UnitSystem)
    assert len(g.__dir__()) == 39

# Generated at 2022-06-21 16:11:41.050806
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person != None
    assert g.address != None


# Generated at 2022-06-21 16:11:44.115987
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis import Person as P, Address as A
    from mimesis import Person as P, Address as A
    g = Generic()
    assert g.person == P(g.locale, g.seed)
    assert g.address == A(g.locale, g.seed)

# Generated at 2022-06-21 16:11:48.390403
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # https://github.com/lk-geimfari/mimesis/issues/93
    data = Generic()
    data.add_providers(Address)
    assert 'address' in dir(data)



# Generated at 2022-06-21 16:11:52.746141
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Testing __getattr__ of class Generic().
    :return: None
    """
    from mimesis.providers.person import Person

    expected_result = 'Male'

    g = Generic('en')
    person = g.person
    assert person.gen_gender() == expected_result
    assert isinstance(person, Person)

# Generated at 2022-06-21 16:12:09.684642
# Unit test for constructor of class Generic
def test_Generic():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'provider'

        def foo(self):
            return 'foo'

        def bar(self):
            return 'bar'

    g = Generic()
    try:
        g.add_provider(TestProvider)
    except TypeError:
        assert False, 'The provider must be a subclass of BaseProvider'

    g.add_provider(TestProvider)
    assert g.provider.foo() == 'foo'
    assert g.provider.bar() == 'bar'

    try:
        g.add_provider('some_provider')
    except TypeError:
        assert True, 'The provider must be a class'

# Generated at 2022-06-21 16:12:12.340381
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    gen = Generic()
    assert "datetime" in dir(gen)
    assert "address" in dir(gen)
    assert "person" in dir(gen)
    assert "business" in dir(gen)
    assert "food" in dir(gen)
    assert "transport" in dir(gen)


# Generated at 2022-06-21 16:12:18.410939
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Tests for Generic().add_providers() method."""
    g = Generic()
    g.add_providers()
    assert g.__dir__() == [
        'add_provider', 'add_providers', 'address', 'business',
        'choice', 'clothing', 'code', 'cryptographic',
        'datetime', 'development', 'file', 'food',
        'hardware', 'internet', 'numbers', 'payment',
        'person', 'path', 'science', 'structure',
        'text', 'transport', 'unit_system',
    ]

    class ProviderA(BaseProvider):
        class Meta:
            name = 'a'

    class ProviderB(BaseProvider):
        class Meta:
            name = 'b'

    g = Generic()

# Generated at 2022-06-21 16:12:29.591215
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    # BaseProvider of Class Generic
    assert g.seed == 32
    assert g.locale == 'en-US'
    g1 = Generic('ja', 64)
    assert g1.locale == 'ja'
    assert g1.seed == 64

    # All providers available in Generic()
    assert g.person.full_name() == 'Jacqueline Sanchez'
    assert g.datetime.datetime() == '2006-05-31 12:38:12'
    assert g.address.address() == '4567 Watkins Flat\nNew Deidre, NM' \
                                  ' 03326-9591'
    assert g.person.full_name(gender='male') == 'George White'
    assert g.person.full_name(gender='female') == 'Mae Johnston'

# Generated at 2022-06-21 16:12:36.592635
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create custom providers
    class Custom1(BaseProvider):
        class Meta:
            name = 'custom1'

        def dummy(self):
            return "Dummy1"

    class Custom2(BaseProvider):
        class Meta:
            name = 'custom2'

        def dummy(self):
            return "Dummy2"

    gen = Generic()
    gen.add_providers(Custom1, Custom2)
    assert gen.custom1 is not None
    assert gen.custom2 is not None
    assert gen.custom1.dummy() == "Dummy1"
    assert gen.custom2.dummy() == "Dummy2"


# Generated at 2022-06-21 16:12:38.183276
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test method __getattr__ of class Generic."""
    generic = Generic(locale='en')
    assert generic.address.city() == 'Fort Wayne'

# Generated at 2022-06-21 16:12:39.176454
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    assert len(generic._providers) > 1


# Generated at 2022-06-21 16:12:45.500894
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic."""
    # Test with good constructor
    gen = Generic()

    assert (gen._seed == 1)
    assert (gen._language == 'en')
    assert (gen._locale == 'en_US')
    assert (gen._localization == 'en')
    assert (gen._region == 'US')
    assert (gen._data == None)

    # Test with bad language
    gen = Generic(language="A")

    assert (gen._seed == 1)
    assert (gen._language == 'en')
    assert (gen._locale == 'en_US')
    assert (gen._localization == 'en')
    assert (gen._region == 'US')
    assert (gen._data == None)

    # Test with bad region
    gen = Generic(region="A")


# Generated at 2022-06-21 16:12:51.473667
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():  
  from mimesis.providers.calendar import Calendar
  from mimesis.providers.education import Education
  from mimesis.providers.finance import Finance
  g = Generic() 
  providers = [Calendar, Education, Finance]
  g.add_providers(*providers)
  assert g.calendar != None
  assert g.education != None
  assert g.finance != None


# Generated at 2022-06-21 16:12:55.538083
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    prov = Generic()
    generic_attrs = "generic_attrs"
    setattr(prov, generic_attrs, Generic())
    assert generic_attrs in dir(prov)
    assert "Meta" in dir(prov)

# Generated at 2022-06-21 16:13:29.189694
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class A(BaseProvider):
        """A provider."""
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    class B(BaseProvider):
        """B provider."""
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    class C(BaseProvider):
        """C provider."""
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    # We don't have A, B, C providers
    gen = Generic()
    assert 'A' not in dir(gen)
    assert 'B' not in dir(gen)
    assert 'C' not in dir(gen)

    # Add providers
    gen.add_providers(A, B, C)

# Generated at 2022-06-21 16:13:31.797953
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():

    c = Generic()
    assert isinstance(c.__dir__(), list)
    assert isinstance(c.__dir__(), list)

    for name in c.__dir__():
        if name in c.__dict__.keys():
            assert isinstance(c.__dict__[name], BaseProvider)

# Generated at 2022-06-21 16:13:35.703541
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Generic
    class Foo(BaseProvider):
        """Class Foo."""
        class Meta:
            """Class Meta."""
            name = 'foo'
    class Bar(BaseProvider):
        """Class Bar."""
        class Meta:
            """Class Meta."""
            name = 'bar'
    g = Generic()
    g.add_providers(Foo, Bar)
    g.foo.foo()
    g.bar.bar()

# Generated at 2022-06-21 16:13:40.215862
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.test.test_provider import TestProvider
    g = Generic(seed=10)

    def check():
        assert isinstance(g.test, TestProvider)

    check()
    g.add_provider(TestProvider)
    check()



# Generated at 2022-06-21 16:13:43.039587
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """ """
    generic = Generic()
    # g = Generic()
    print(dir(generic))
    print(dir(Generic))
    print(dir(Generic.Meta()))
    print(dir(BaseDataProvider))


# Generated at 2022-06-21 16:13:45.299620
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.custom_providers.my_provider import MyProvider
    generic = Generic()
    generic.add_provider(MyProvider)
    assert generic.my_provider



# Generated at 2022-06-21 16:13:47.182698
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    g.add_provider(Person)
    print(g.person)


# Generated at 2022-06-21 16:13:58.140616
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Known result
    result = {
        'provider1': 'provider1',
        'provider2': 'provider2',
        'provider3': 'provider3',
        'provider4': 'provider4',
    }
    # Test
    g = Generic()
    providers = [GenericProvider1, GenericProvider2, GenericProvider3, GenericProvider4]
    g.add_providers(*providers)
    for key, value in result.items():
        assert key in g.__dict__, "Provider does not exist"
        assert isinstance(g.__dict__[value], GenericProvider), "Class '{}' is not a valid provider".format(key)


# class GenericProvider1(BaseDataProvider):

# Generated at 2022-06-21 16:14:07.709641
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=1)
    print("{}\n".format(generic))
    print("{}\n".format(generic.general()))
    print("{}\n".format(generic.person()))
    print("{}\n".format(generic.address()))
    print("{}\n".format(generic.datetime()))
    print("{}\n".format(generic.business()))
    print("{}\n".format(generic.text()))
    print("{}\n".format(generic.food()))
    print("{}\n".format(generic.science()))
    print("{}\n".format(generic.transport()))
    print("{}\n".format(generic.code()))
    print("{}\n".format(generic.unit_system()))

# Generated at 2022-06-21 16:14:11.479935
# Unit test for constructor of class Generic
def test_Generic():
    """Call method for test"""
    generic = Generic()
    assert generic.datetime.datetime()
    assert generic.address.coordinate()
    assert generic.person.full_name()
    assert generic.text.text()
    assert generic.numbers.decimal()
    assert generic.business.company()
    assert generic.food.fruit()
    assert generic.science.element()

# Generated at 2022-06-21 16:15:07.596568
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TestProvider1(BaseProvider):
        class Meta:
            name = 'testprovider1'
        def get_dummy(self):
            return 1

    class TestProvider2(BaseProvider):
        class Meta:
            name = 'testprovider2'
        def get_dummy(self):
            return 2

    g = Generic()
    g.add_providers(TestProvider1, TestProvider2)
    assert isinstance(g.testprovider1, TestProvider1)
    assert isinstance(g.testprovider2, TestProvider2)
    assert g.testprovider1.get_dummy() == 1
    assert g.testprovider2.get_dummy() == 2

# Generated at 2022-06-21 16:15:08.626406
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert len(g.__dir__()) == 45

# Generated at 2022-06-21 16:15:14.634299
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = 'test'
        def __init__(self, seed: int = None):
            super().__init__(seed)
        def test(self) -> str:
            return 'test'

    class Other:
        def foo(self) -> int:
            return 100500

    generic = Generic()
    generic.add_provider(Test)
    assert generic.test.test() == 'test'
    try:
        generic.add_provider(Other)
    except:
        pass


# Generated at 2022-06-21 16:15:16.726621
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert isinstance(a, Generic)
    assert isinstance(a.person, Person)
    assert isinstance(a.person, BaseProvider)

# Generated at 2022-06-21 16:15:19.439114
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of class Generic."""
    gen = Generic()
    gen.add_provider(MyProvider)
    assert hasattr(gen, 'myprovider')
    assert isinstance(gen.myprovider, MyProvider)



# Generated at 2022-06-21 16:15:25.242728
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__."""
    g = Generic()
    assert g.person.full_name() == 'Данило Алексеев'
    assert g.person.full_name(gender='female') == 'Альона Иларионова'
    assert g.address.address() == 'ул. Создание, 97, Киев, Тернопольская обл, Украина'

# Generated at 2022-06-21 16:15:34.882221
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    seed = 12
    generic = Generic(seed=seed)
    assert hasattr(generic, 'provider')
    assert hasattr(generic, 'code')
    assert hasattr(generic, 'unit_system')
    assert hasattr(generic, 'file')
    assert hasattr(generic, 'numbers')
    assert hasattr(generic, 'development')
    assert hasattr(generic, 'hardware')
    assert hasattr(generic, 'clothing')
    assert hasattr(generic, 'internet')
    assert hasattr(generic, 'path')
    assert hasattr(generic, 'payment')
    assert hasattr(generic, 'cryptographic')
    assert hasattr(generic, 'structure')
    assert hasattr(generic, 'choice')

# Generated at 2022-06-21 16:15:35.211101
# Unit test for constructor of class Generic
def test_Generic():


    assert Generic()

# Generated at 2022-06-21 16:15:36.170203
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    sample = Generic()
    sample.add_providers(Person, Address)
    sample.person
    sample.address

# Generated at 2022-06-21 16:15:37.629384
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    generic = Generic(None)

    attributes = generic.__dir__()
    assert len(attributes) == 37