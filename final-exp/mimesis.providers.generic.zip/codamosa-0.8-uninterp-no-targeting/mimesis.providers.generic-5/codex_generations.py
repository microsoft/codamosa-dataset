

# Generated at 2022-06-21 16:10:03.609849
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(g.address)
    print(g.person)
    print(g.text)
    print('Generic.__dict__ = ', g.__dict__)
    assert isinstance(g, Generic)
    assert isinstance(g.address, Address)
    assert isinstance(g.person, Person)
    assert isinstance(g.text, Text)


if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-21 16:10:11.033881
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    g = Generic('en')
    assert 'address' in dir(g)
    assert 'person' in dir(g)
    assert 'business' in dir(g)
    assert 'datetime' in dir(g)
    assert 'text' in dir(g)
    assert 'food' in dir(g)
    assert 'science' in dir(g)
    assert 'transport' in dir(g)
    assert 'code' in dir(g)
    assert 'unit_system' in dir(g)
    assert 'file' in dir(g)
    assert 'numbers' in dir(g)
    assert 'development' in dir(g)
    assert 'hardware' in dir(g)
    assert 'clothing' in dir(g)

# Generated at 2022-06-21 16:10:12.946372
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    for name in ['name', 'add_provider', 'add_providers']:
        assert hasattr(Generic, name)

    assert Generic().__dir__()



# Generated at 2022-06-21 16:10:15.953010
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g
    assert g.person
test_Generic()


# Generated at 2022-06-21 16:10:26.714750
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.providers.food import Food
    from mimesis.providers.person import Person
    from mimesis.providers.science import Science
    from mimesis.providers.text import Text
    from mimesis.providers.transport import Transport
    from mimesis.providers.units import UnitSystem
    g = Generic()
    assert not isinstance(g, Generic)
    assert isinstance(g, BaseDataProvider)
    assert isinstance(g, Food)
    assert isinstance(g, Person)
    assert isinstance(g, Science)
    assert isinstance(g, Text)
    assert isinstance(g, Transport)
    assert isinstance(g, UnitSystem)
    assert g.person is not None
    assert g.address is not None
    assert g.datetime is not None
   

# Generated at 2022-06-21 16:10:33.089696
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():

    d = Generic(seed=1)
    assert d.__dir__() == ['address', 'business', 'choice',
                           'code', 'clothing', 'cryptographic',
                           'datetime', 'development', 'food',
                           'hardware', 'internet', 'numbers',
                           'path', 'payment', 'person',
                           'science', 'structure', 'text',
                           'transport', 'unit_system']

# Generated at 2022-06-21 16:10:35.320812
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic(seed=12345)
    assert a.choice.get_coin() == 'Heads'
    assert a.choice.get_coin() == 'Heads'

# Generated at 2022-06-21 16:10:37.966997
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert Generic().__getattr__('person')
    assert Generic().__getattr__('address')
    assert Generic().__getattr__('numbers')
    assert Generic().__getattr__('food')
    assert Generic().__getattr__('transport')


# Generated at 2022-06-21 16:10:44.894852
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Test(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super().__init__(seed)
        def test(self):
            return 1
    g = Generic()
    assert not hasattr(g, 'tests')
    g.add_providers(Test)
    assert hasattr(g, 'tests')
    assert g.tests.test() == 1

# Generated at 2022-06-21 16:10:48.161807
# Unit test for constructor of class Generic
def test_Generic():
    "Test initializer of class Generic"

    generic = Generic()
    assert isinstance(generic, Generic)
    assert generic.seed == "2d128cde8a6a846fcfb06ea39126a6c1"
