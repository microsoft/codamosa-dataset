

# Generated at 2022-06-21 16:10:00.703160
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        gen = Generic()
        gen.add_provider(Generic)
        gen.add_provider(BaseProvider)
        gen.add_provider(Code)
        gen.add_provider(Payment)
        gen.add_provider(Text)
        gen.add_provider(DataProvider)
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 16:10:09.472464
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-21 16:10:11.424206
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.code import Code

    g = Generic()
    assert g.code.__class__ == Code
    assert g.code.seed == g.seed


# Generated at 2022-06-21 16:10:12.385289
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    result = dir(Generic())
    assert result == sorted(result)

# Generated at 2022-06-21 16:10:23.318207
# Unit test for constructor of class Generic
def test_Generic():
    obj = Generic()
    assert obj.address != None
    assert obj.person != None
    assert obj.choice != None
    assert obj.clothing != None
    assert obj.code != None
    assert obj.cryptographic != None
    assert obj.datetime != None
    assert obj.development != None
    assert obj.file != None
    assert obj.food != None
    assert obj.hardware != None
    assert obj.internet != None
    assert obj.numbers != None
    assert obj.path != None
    assert obj.payment != None
    assert obj.science != None
    assert obj.structure != None
    assert obj.text != None
    assert obj.transport != None
    assert obj.unit_system != None

# Generated at 2022-06-21 16:10:31.565390
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for add_provider of class Generic."""
    generic = Generic()
    assert isinstance(generic, Generic)
    assert 'bitcoin' not in dir(Generic)

    class Bitcoin(BaseProvider):
        """Bitcoin provider."""

        class Meta:
            """Class for metadata."""

            name = 'bitcoin'

        def hash(self) -> str:
            """Get bitcoin hash.

            :return: Hash.
            """
            return self.random.randstr(64)

    generic.add_provider(Bitcoin)
    assert 'bitcoin' in dir(Generic)

# Generated at 2022-06-21 16:10:36.403151
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        def __init__(self, seed: int = None):
            super().__init__(seed=seed)

        class Meta:
            name = 'custom'

        @property
        def a(self):
            return 'a'

    g = Generic()
    g.add_providers(CustomProvider)
    assert hasattr(g, 'custom')
    assert g.custom.a == 'a'

# Generated at 2022-06-21 16:10:37.662478
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    providers = Generic().__dir__()

    if providers:
        assert Generic().numbers
    else:
        assert providers

# Generated at 2022-06-21 16:10:48.925671
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    gen = Generic()
    assert gen.person.full_name() == 'Maximillian McFarland'
    assert gen.address.city() == 'Windsor'
    assert gen.datetime.date() == '2019-09-29'
    assert gen.business.company() == 'Doyle and Sons'
    assert gen.text.title() == 'Aut non quia.'
    assert gen.food.ingredient() == 'Asparagus'
    assert gen.science.chemical_element() == 'Silver'
    assert gen.transport.road_vehicle() == 'Van'
    assert gen.code.cvv() == '033'
    assert gen.unit_system.length() == 'Kilometre'

# Generated at 2022-06-21 16:10:55.366891
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Generic
    from mimesis.providers.internet import Internet

    g = Generic(seed=11)

    g.add_provider(Internet)

    assert g.internet.mac_address() == 'CD:CB:68:F6:D9:B1'

    g.add_provider(Internet)

    assert g.internet.mac_address() == 'CD:CB:68:F6:D9:B1'