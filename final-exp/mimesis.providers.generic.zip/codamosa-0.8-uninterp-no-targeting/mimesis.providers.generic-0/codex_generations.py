

# Generated at 2022-06-21 16:10:07.579553
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic(randomize=False, seed=12345)
    assert a.person.full_name() == 'Alexander Smith'
    assert a.address
    assert a.datetime
    assert a.business
    assert a.text
    assert a.food
    assert a.science
    assert a.transport
    assert a.code
    assert a.unit_system
    assert a.file
    assert a.numbers
    assert a.development
    assert a.hardware
    assert a.clothing
    assert a.internet
    assert a.path
    assert a.payment
    assert a.cryptographic
    assert a.structure
    assert a.choice



# Generated at 2022-06-21 16:10:11.815073
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    generic = Generic()
    generic.add_providers(Payment, Science, Person, Datetime)
    assert hasattr(generic, 'payment')
    assert hasattr(generic, 'science')
    assert hasattr(generic, 'person')
    assert hasattr(generic, 'datetime')

# Generated at 2022-06-21 16:10:14.934323
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():

    obj = Generic()
    obj.datetime
    obj.structure
    obj.transport
    

# Generated at 2022-06-21 16:10:25.790129
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import Address
    from mimesis.providers import Datetime
    from mimesis.providers import Business
    from mimesis.providers import Text
    from mimesis.providers import Food
    from mimesis.providers import Science
    from mimesis.providers import Transport
    from mimesis.providers import Code
    from mimesis.providers import UnitSystem
    from mimesis.providers import File
    from mimesis.providers import Numbers
    from mimesis.providers import Development
    from mimesis.providers import Hardware
    from mimesis.providers import Clothing
    from mimesis.providers import Internet
    from mimesis.providers import Path
    from mimesis.providers import Payment
    from mimesis.providers import Crypt

# Generated at 2022-06-21 16:10:36.087454
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    print("Testing Generic")
    gen = Generic(seed=42)

    p = dir(gen)
    #  print(p)

    assert 'person' in p
    assert 'address' in p
    assert 'food' in p
    assert 'numbers' in p
    assert 'unit_system' in p
    assert 'development' in p
    assert 'hardware' in p
    assert 'clothing' in p
    assert 'internet' in p
    assert 'path' in p
    assert 'payment' in p
    assert 'cryptographic' in p
    assert 'structure' in p
    assert 'code' in p
    assert 'datetime' in p
    assert 'text' in p
    assert 'science' in p
    assert 'business' in p
    assert 'transport' in p
    assert 'file'

# Generated at 2022-06-21 16:10:45.300685
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.localization import Localization

    class CustomDatetime(Datetime):
        """Custom datetime provider."""
        pass

    class CustomLocalization(Localization):
        """Custom localization provider."""
        pass

    generic = Generic()
    generic.add_provider(CustomDatetime)
    generic.add_provider(CustomLocalization)
    assert hasattr(generic, 'datetime')
    assert hasattr(generic, 'localization')


# Generated at 2022-06-21 16:10:48.160425
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic('en')
    assert sorted(g.__dir__()) == sorted('choice business food text numbers datetime address person development transport code unit_system file hardware clothing internet path payment cryptographic structure'.split(' '))



# Generated at 2022-06-21 16:10:57.060052
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()

    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.business, Business)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)
    assert isinstance(gen.transport, Transport)
    assert isinstance(gen.code, Code)
    assert isinstance(gen.unit_system, UnitSystem)
    assert isinstance(gen.file, File)
    assert isinstance(gen.numbers, Numbers)
    assert isinstance(gen.development, Development)
    assert isinstance(gen.hardware, Hardware)
    assert isinstance(gen.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-21 16:10:58.299681
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    assert hasattr(Generic(), 'person')

# Generated at 2022-06-21 16:11:08.061627
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import random

    class Example(BaseProvider):
        """Example class."""
        class Meta:
            """Metadata class."""
            name = 'example'

        def __init__(self, seed: int = None, **kwargs: Any) -> None:
            """Initialize attributes."""
            super().__init__(seed, **kwargs)
            self.__choice = ['a', 'b', 'c']

        def example(self):
            """Example method."""
            return random.choice(self.__choice)

    m = Generic()
    m.add_provider(Example)
    assert m.example() in ['a', 'b', 'c']