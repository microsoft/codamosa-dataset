

# Generated at 2022-06-21 16:09:54.310017
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    assert hasattr(Generic(), 'person')
    assert hasattr(Generic(), 'datetime')
    assert hasattr(Generic(), 'address')
    assert hasattr(Generic(), 'business')
    assert hasattr(Generic(), 'text')



# Generated at 2022-06-21 16:10:06.173115
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    no_of_provider = len(dir(Generic()))
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def method(self):
            return 'Custom Provider'

    class OtherCustomProvider(BaseProvider):
        class Meta:
            name = 'other_custom'

        def method(self):
            return 'Other Custom Provider'

    generic = Generic()
    generic.add_providers(CustomProvider, OtherCustomProvider)
    assert len(dir(generic)) == no_of_provider + 2
    assert generic.custom.method() == 'Custom Provider'
    assert generic.other_custom.method() == 'Other Custom Provider'

    generic2 = Generic()
    generic2.add_providers([CustomProvider, OtherCustomProvider])
    assert len(dir(generic2)) == no_of_

# Generated at 2022-06-21 16:10:11.743065
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test'

        def test_method(self):
            return self.random.choice(['OK'])

    g = Generic()
    g.add_provider(TestProvider)
    assert hasattr(g, 'test')
    assert isinstance(g.test, TestProvider)
    assert g.test.test_method() == 'OK'



# Generated at 2022-06-21 16:10:17.064286
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('en')
    assert generic.person.username() == 'gabriel61'

    assert generic.internet.username() == 'BenjaminKam'
    generic = Generic('ru')
    assert generic.person.username() == 'Evrey_Vorobiev'

    generic.add_provider(Person)
    assert generic.person.username() == 'Evrey_Vorobiev'
    generic.add_provider(Internet)
    assert generic.internet.username() == 'Evrey_Vorobiev'

    generic = Generic('en')
    assert generic.person.username() == 'Ann-Marie_Adams'
    assert generic.internet.username() == 'SandySimmons'
    generic = Generic('ru')
    assert generic.person.username() == 'Evrey_Vorobiev'
    assert generic

# Generated at 2022-06-21 16:10:18.603613
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print("This is a test for method __getattr__ of class Generic")



# Generated at 2022-06-21 16:10:27.240732
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():

    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def foo(self):
            return 'bar'

    class AnotherCustomProvider(BaseProvider):
        class Meta:
            name = 'another_custom_provider'

        def foo(self):
            return 1

    generic = Generic()
    generic.add_providers(CustomProvider, AnotherCustomProvider)
    assert hasattr(generic, 'custom_provider')
    assert hasattr(generic, 'another_custom_provider')
    assert generic.custom_provider.foo() == 'bar'
    assert generic.another_custom_provider.foo() == 1

# Generated at 2022-06-21 16:10:32.050261
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    try:
        generic = Generic()
        generic.add_provider(Person)
        assert hasattr(generic, 'person')
        generic.add_provider(Address)
        assert hasattr(generic, 'address')
    except TypeError:
        print('Something went wrong')


# Generated at 2022-06-21 16:10:38.040202
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__() == [
        'address',
        'add_provider',
        'add_providers',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'development',
        'datetime',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'person',
        'path',
        'payment',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

# Generated at 2022-06-21 16:10:49.896010
# Unit test for constructor of class Generic
def test_Generic():
    """Test method for Generic."""
    provider = Generic()

    assert provider is not None
    assert provider.person is not None
    assert provider.address is not None
    assert provider.datetime is not None
    assert provider.business is not None
    assert provider.numbers is not None
    assert provider.text is not None
    assert provider.food is not None
    assert provider.science is not None
    assert provider.transport is not None
    assert provider.code is not None
    assert provider.file is not None
    assert provider.development is not None
    assert provider.hardware is not None
    assert provider.clothing is not None
    assert provider.internet is not None
    assert provider.path is not None
    assert provider.payment is not None
    assert provider.cryptographic is not None
    assert provider.structure is not None

# Generated at 2022-06-21 16:10:55.101613
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    assert len(g.__dir__())
    g.add_provider(Person)
    assert 'person' in g.__dir__()
    g.add_providers(Address, Payment)
    assert 'address' in g.__dir__()
    assert 'payment' in g.__dir__()

# Generated at 2022-06-21 16:11:20.823745
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    gen = Generic()
    dir_list = gen.__dir__()
    assert "Generic" in dir_list
    assert "address" in dir_list
    assert "business" in dir_list
    assert "code" in dir_list
    assert "clothing" in dir_list
    assert "cryptographic" in dir_list
    assert "datetime" in dir_list
    assert "development" in dir_list
    assert "food" in dir_list
    assert "hardware" in dir_list
    assert "internet" in dir_list
    assert "numbers" in dir_list
    assert "path" in dir_list
    assert "person" in dir_list
    assert "structure" in dir_list
    assert "text" in dir_list
   

# Generated at 2022-06-21 16:11:28.837307
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()

# Generated at 2022-06-21 16:11:32.879328
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.development import Development
    from mimesis.providers.internet import Internet

    generic = Generic()
    generic.add_provider(Development)
    generic.add_provider(Internet)



# Generated at 2022-06-21 16:11:34.618144
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic's method __getattr__."""

    provider = Generic()

    assert provider.person is not None



# Generated at 2022-06-21 16:11:41.504362
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import mimesis
    gen = mimesis.Generic()
    print(dir(gen))
    print(dir(gen.person))
    print(dir(gen.address))
    print(dir(gen.business))
    print(dir(gen.text))
    print(dir(gen.food))
    print(dir(gen.science))
    print(dir(gen.transport))
    print(dir(gen.code))
    print(dir(gen.unit_system))
    print(dir(gen.file))
    print(dir(gen.numbers))
    print(dir(gen.development))
    print(dir(gen.hardware))
    print(dir(gen.clothing))
    print(dir(gen.internet))
    print(dir(gen.path))
    print(dir(gen.payment))

# Generated at 2022-06-21 16:11:44.868953
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Test(BaseProvider):
        class Meta:
            name = "test"
        def testitem(self):
            return self.random.choice(["banana","oranges","apples","pears"])
    
    class Other(BaseProvider):
        class Meta:
            name = "other"
        
        def otheritem(self):
            return self.random.choice([4,5,6,7])
    
    gen = Generic()
    gen.add_provider(Test)
    gen.add_provider(Other)
    assert isinstance(gen.test, Test)
    assert isinstance(gen.other, Other)

# Generated at 2022-06-21 16:11:47.016055
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    generic.scientific_name()

# Generated at 2022-06-21 16:11:55.454422
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Arrange
    generic = Generic('en')

    # Act
    result = generic.__dir__()

    # Assert
    assert isinstance(result, list)
    assert 'person' in result
    assert 'address' in result
    assert 'datetime' in result
    assert 'business' in result
    assert 'text' in result
    assert 'food' in result
    assert 'science' in result
    assert 'transport' in result
    assert 'code' in result
    assert 'unit_system' in result
    assert 'file' in result
    assert 'numbers' in result
    assert 'development' in result
    assert 'hardware' in result
    assert 'clothing' in result
    assert 'internet' in result
    assert 'path' in result
    assert 'payment' in result
    assert 'cryptographic'

# Generated at 2022-06-21 16:11:56.375808
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    g.add_providers(Business)
    assert isinstance(g.business, Business)

# Generated at 2022-06-21 16:12:00.451982
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import sys
    import os
    sys.path.append(os.path.abspath(os.path.curdir))
    from mimesis.providers.example import Example

    g = Generic()
    g.add_provider(Example)
    assert hasattr(g, 'example')
    assert callable(g.example.example)
    g.add_provider(Example)
    assert hasattr(g, 'example_1')
    assert callable(g.example_1.example)

