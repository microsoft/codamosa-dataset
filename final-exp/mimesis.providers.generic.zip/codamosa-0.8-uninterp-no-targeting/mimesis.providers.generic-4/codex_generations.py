

# Generated at 2022-06-21 16:10:00.547166
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Expected result
    excepted = [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]

    g = Generic()
    assert sorted(g.__dir__()) == sorted(excepted)



# Generated at 2022-06-21 16:10:09.354006
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    gen = Generic()
    assert(gen.address.address() == "4335 Spikeston")
    assert(gen.business.company() == "Fisher Group")
    assert(gen.person.full_name() == "Richard Puckett")
    assert(gen.person.full_name(gender=Gender.MALE) == "William Graham")
    assert(gen.person.full_name(gender=Gender.FEMALE) == "Annie Briggs")
    assert(gen.choice.boolean() == True or gen.choice.boolean() == False)
    assert(gen.development.language() in ['Java', 'Python', 'PHP', 'JavaScript', 'C', 'C++'])

# Generated at 2022-06-21 16:10:15.093987
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.datetime is not None
    assert g.datetime.now() is not None
    assert g.person is not None
    assert g.person.full_name() is not None
    assert g.address is not None
    assert g.address.country() is not None
    assert g.business is not None
    assert g.business.company() is not None
    assert g.text is not None
    assert g.text.text() is not None
    assert g.food is not None
    assert g.food.fruit() is not None
    assert g.science is not None
    assert g.science.chemical_element() is not None



# Generated at 2022-06-21 16:10:17.705221
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    # Ensure that list of providers is correct
    providers = Generic().__dir__()
    assert providers == __all__


# Generated at 2022-06-21 16:10:21.216011
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic('en')
    class Provider(BaseProvider):
        class Meta:
            name = 'test'
    providers = (Provider, Provider)
    g.add_providers(*providers)
    assert g.test



# Generated at 2022-06-21 16:10:25.227474
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Test 1:
    # Test data: [provider.Provider]
    # Expected result: [None]
    provider = Generic()
    expected_result_1 = None

    assert provider.add_provider(Person) == expected_result_1


# Generated at 2022-06-21 16:10:28.547090
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert Generic().add_provider(Text).__dir__() == Generic().__dir__() + ['text']


# Generated at 2022-06-21 16:10:35.829149
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Foo(BaseProvider):
        """Provider for testing Generic.add_provider(Foo).

        All information about provider you can find here:
        http://mimesis.readthedocs.io/en/latest/api/providers.html
        """
        class Meta:
            """Class for metadata."""

            name = 'mimesis.providers.Foo'

        def foo(self) -> str:
            """Foo method.

            :return: Random string.
            """
            return 'foo'

    gen = Generic()
    gen.add_provider(Foo)
    assert gen.foo.foo() == 'foo'

# Generated at 2022-06-21 16:10:39.229081
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    gen = Generic()
    assert isinstance(gen.food, Food)



# Generated at 2022-06-21 16:10:47.099588
# Unit test for constructor of class Generic
def test_Generic():
    # Call the constructor of class Generic
    obj = Generic()

    # Check the data type of object
    assert isinstance(obj, Generic)

    # Check the object has own attribute
    assert hasattr(obj, 'datetime')

    # Check the data type of attribute
    assert isinstance(obj.datetime, Datetime)

    # Check the object has own attribute
    assert hasattr(obj, 'numbers')

    # Check the data type of attribute
    assert isinstance(obj.numbers, Numbers)

# Generated at 2022-06-21 16:11:13.506719
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    _g = Generic()
    result = _g.__dir__()
    assert 'business' in result
    assert 'person' in result
    assert 'clothing' in result
    assert 'science' in result
    assert 'development' in result
    assert 'address' in result
    assert 'unit_system' in result
    assert 'hardware' in result
    assert 'food' in result
    assert 'path' in result
    assert 'numbers' in result
    assert 'code' in result
    assert 'text' in result
    assert 'datetime' in result
    assert 'internet' in result
    assert 'file' in result
    assert 'transport' in result
    assert 'payment' in result
    assert 'cryptographic' in result
    assert 'structure'

# Generated at 2022-06-21 16:11:15.871669
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert isinstance(g.__dir__(), list)
    assert 'food' in g.__dir__()
    assert 'clothing' in g.__dir__()



# Generated at 2022-06-21 16:11:17.413382
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ method of class Generic."""
    generic = Generic()
    assert isinstance(generic.person, Person)

# Generated at 2022-06-21 16:11:19.547409
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class _Provider(BaseProvider):
        class Meta:
            name = 'foo'

    gen = Generic()
    gen.add_provider(_Provider)
    assert hasattr(gen, 'foo')



# Generated at 2022-06-21 16:11:20.823786
# Unit test for constructor of class Generic
def test_Generic():
    test_example = Generic()
    test_example.add_providers()
    assert test_example

# Generated at 2022-06-21 16:11:26.577235
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers of class Generic."""
    locale = 'en'
    seed = 10
    prov = Generic(locale=locale, seed=seed)
    providers = [Business, Text]
    prov.add_providers(*providers)
    assert prov.business.company_suffix() == 'Inc'
    assert prov.text.word() == 'quasi'
    prov = Generic(locale=locale, seed=seed)
    assert prov.business.company_suffix() == 'Inc'
    assert prov.text.word() == 'quasi'


# Generated at 2022-06-21 16:11:32.604502
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import (Person, Datetime, Choice, Text)

    providers = [Person, Datetime, Choice, Text]
    g = Generic()

    for provider in providers:
        g.add_provider(provider)

    for provider in providers:
        meta = getattr(provider, 'Meta')
        name = getattr(meta, 'name')
        assert isinstance(getattr(g, name), provider)

# Generated at 2022-06-21 16:11:33.676936
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
   assert isinstance(Generic().add_providers(), None)


# Generated at 2022-06-21 16:11:35.362293
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert isinstance(g, Generic)

# Generated at 2022-06-21 16:11:39.018478
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.numbers import Numbers
    gen = Generic()
    gen.add_provider(Numbers)
    number = gen.numbers.random_int(start=0, stop=200, places=2)
    assert isinstance(number, int)
    assert number >= 0 and number < 200
