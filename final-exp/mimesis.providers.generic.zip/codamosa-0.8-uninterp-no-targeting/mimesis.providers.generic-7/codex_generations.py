

# Generated at 2022-06-21 16:10:14.557246
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for method add_providers of class Generic."""
    from mimesis.providers.person import Person, Gender
    from mimesis.providers.address import Address
    from mimesis.providers.payment import Payment
    
    class CustomPerson(Person):
        """Custom person."""
        def __init__(self, *args, **kwargs):
            """Initialize attributes."""
            super().__init__(*args, **kwargs)
            self.data['first_name']['data'].append('Richard')
            self.data['last_name']['data'].append('Stallman')
            self.data['name']['data'].append('Richard Stallman')

# Generated at 2022-06-21 16:10:19.264902
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.cryptographic


# Generated at 2022-06-21 16:10:30.718062
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for method __dir__ of class Generic."""
    test = Generic()
    res = test.__dir__()

    assert 'address' in res
    assert 'business' in res
    assert 'choice' in res
    assert 'code' in res
    assert 'clothing' in res
    assert 'datetime' in res
    assert 'development' in res
    assert 'file' in res
    assert 'food' in res
    assert 'hardware' in res
    assert 'internet' in res
    assert 'numbers' in res
    assert 'path' in res
    assert 'payment' in res
    assert 'person' in res
    assert 'science' in res
    assert 'structure' in res
    assert 'text' in res
    assert 'transport' in res
    assert 'unit_system' in res
