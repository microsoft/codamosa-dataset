

# Generated at 2022-06-21 16:09:59.230473
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass



# Generated at 2022-06-21 16:10:09.378633
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)
    assert isinstance(generic, BaseDataProvider)
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)

# Generated at 2022-06-21 16:10:14.606348
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .providers import AbcProvider

    generic = Generic()
    abc = AbcProvider()
    generic.add_provider(AbcProvider)

    assert generic.abc is not None
    assert generic.abc.seed == generic.seed
    assert generic.abc.locale == generic.locale
    assert generic.abc.abc_provider is None
    assert generic.abc.abc_provider is None
    assert generic.abc.a(seed=123456789) == abc.a(seed=123456789)
    assert generic.abc.b(seed=123456789) == abc.b(seed=123456789)



# Generated at 2022-06-21 16:10:23.077998
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.business
    assert gen.address
    assert gen.code
    assert gen.clothing
    assert gen.cryptographic
    assert gen.unit_system
    assert gen.numbers
    assert gen.choice
    assert gen.datetime
    assert gen.development
    assert gen.file
    assert gen.food
    assert gen.hardware
    assert gen.internet
    assert gen.path
    assert gen.payment
    assert gen.person
    assert gen.science
    assert gen.structure
    assert gen.text
    assert gen.transport


# Generated at 2022-06-21 16:10:25.229561
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    provider = Generic('en')
    a = provider.person.full_name()
    
    assert provider.person._full_name() == a

# Generated at 2022-06-21 16:10:26.714229
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    pass

# Generated at 2022-06-21 16:10:31.694502
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers method of class Generic."""
    from mimesis.providers.commerce import Commerce
    from mimesis.providers.lorem import Lorem

    gen = Generic()
    gen.add_providers(Commerce, Lorem)
    assert gen.commerce
    assert gen.lorem

# Generated at 2022-06-21 16:10:34.682747
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers in class Generic."""
    g = Generic()
    assert hasattr(g, 'generic') is False
    g.add_providers(Generic)
    assert hasattr(g, 'generic')



# Generated at 2022-06-21 16:10:35.862247
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    obj = Generic()
    dir_obj = dir(obj)
    assert 'person' in dir_obj

# Generated at 2022-06-21 16:10:38.181428
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # TODO: implement.
    pass
