

# Generated at 2022-06-21 16:10:05.356920
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from .test_provider import Cat, Dog

    generic = Generic('en')
    generic.add_providers(Cat, Dog)

    cat = generic.cat.get_cat_name()
    dog = generic.dog.breed()

    assert isinstance(cat, str)
    assert isinstance(dog, str)

# Generated at 2022-06-21 16:10:11.387978
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Make Generic() object."""
    g = Generic()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()
    g.person.full_name()

# Generated at 2022-06-21 16:10:15.711472
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method Generic.__dir__."""
    g = Generic('ru')

    assert g.__dir__() == [
        'address',
        'business',
        'choice',
        'code',
        'clothing',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'transport',
        'unit_system',
        'text',
    ]

# Generated at 2022-06-21 16:10:17.325456
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert callable(g.person.full_name)

# Generated at 2022-06-21 16:10:24.983820
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # Корректный вызов __getattr__
    g = Generic()
    g.__getattr__('person')
    # Проверка на существование атрибута
    assert hasattr(g, 'person')
    # Проверка типа атрибута
    assert isinstance(g.person, Person)


# Generated at 2022-06-21 16:10:28.179769
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    gen = Generic()
    assert gen.person



# Generated at 2022-06-21 16:10:30.403997
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    assert hasattr(g, 'add_provider')
    assert callable(g.add_provider)


# Generated at 2022-06-21 16:10:35.121749
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import pytest
    from mimesis.exceptions import NonExistentProviderError

    from custom_providers.test_provider import TestClass

    g = Generic()

    g.add_provider(TestClass)
    assert hasattr(g, 'test_class')

    with pytest.raises(NonExistentProviderError):
        g.test_class.wrong_method()


# Generated at 2022-06-21 16:10:39.342432
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    class testProvider(BaseProvider):
        class Meta:
            name = 'test'
        def test_func(self):
            return 'test_result'
    p = testProvider()
    assert g.test_func  # Проверка функции с генератором несуществующего провайдера


# Generated at 2022-06-21 16:10:48.784590
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """
    Unit test for method add_provider of class Generic
    """
    class MyAwesomeProvider(BaseProvider):
        """
        Custom provider
        """
        def __init__(self, *args, **kwargs):
            """
            Initialize provider
            """
            super().__init__(*args, **kwargs)

        def sometext(self):
            """
            Generate text
            """
            return self.random.randint(100000, 999999)

    generic = Generic()
    generic.add_provider(MyAwesomeProvider)
    assert generic.myawesomeprovider.sometext() == generic.myawesomeprovider.sometext()