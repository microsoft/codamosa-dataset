

# Generated at 2022-06-21 16:09:59.107942
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert isinstance(generic.person, Person)
    assert not hasattr(generic, '_person')

    class MyProvider(BaseProvider):
        def foo(self) -> str:
            return 'bar'

    generic.add_provider(MyProvider)
    assert isinstance(generic.my_provider, MyProvider)
    assert generic.my_provider.foo() == 'bar'

# Generated at 2022-06-21 16:10:01.536564
# Unit test for constructor of class Generic
def test_Generic():
	#print("\nTest constructor of class Generic:\n")
	gen = Generic('en')
	print(gen)


# Generated at 2022-06-21 16:10:03.192118
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__() != []

# Generated at 2022-06-21 16:10:05.570896
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    GENERIC = Generic(seed=12345)
    assert GENERIC.person
    assert GENERIC.person.occupation() == 'Medical assistant'

# Generated at 2022-06-21 16:10:10.632911
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    class Custom1(BaseProvider):
        class Meta:
            name = 'custom1'
    class Custom2(BaseProvider):
        class Meta:
            name = 'custom2'
    g.add_providers(Custom1, Custom2)
    assert 'custom1' in dir(g)
    assert 'custom2' in dir(g)

# Generated at 2022-06-21 16:10:16.184607
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Tests of class Generic test add_provider"""
    seed = 'test_Generic_add_provider'
    g = Generic(seed=seed)
    providers = [Person, Address, Datetime, Business, Text, Food, Science]
    assert not g.food
    assert not g.science
    assert not g.address
    assert not g.datetime
    assert not g.person
    assert not g.business
    assert not g.text
    g.add_provider(Person)
    assert g.person
    assert g.person.seed == seed
    g.add_provider(Address)
    assert g.address.seed == seed
    g.add_provider(Datetime)
    assert g.datetime.seed == seed
    g.add_provider(Business)
    assert g.business.seed == seed

# Generated at 2022-06-21 16:10:27.051053
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class _Custom(BaseProvider):
        class Meta:
            name = 'custom'

        def f1(self):
            return 'this is f1'

        def f2(self):
            return 'this is f2'

    class _Custom2(BaseProvider):
        class Meta:
            name = 'custom2'

        def f1(self):
            return 'this is f1'

        def f2(self):
            return 'this is f2'

    custom = _Custom()
    custom.Meta.name = 'custom'
    generic = Generic()
    generic.add_providers(_Custom, _Custom2)

    assert generic.custom.f1() == 'this is f1'
    assert generic.custom.f2() == 'this is f2'

# Generated at 2022-06-21 16:10:30.890483
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from test_additional_provider import CustomProvider
    generic = Generic()
    generic.add_provider(CustomProvider)
    assert hasattr(generic, 'custom')
    assert generic.custom.test() == 'Test'

# Generated at 2022-06-21 16:10:38.602653
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    dp = Generic('en')
    name = dp.person.name(gender=Gender.FEMALE)
    street = dp.address.street_name()
    sed = dp.datetime.date(start=2018,end=2018)
    business = dp.business.company()
    text = dp.text.text(5)
    food = dp.food.fruit()
    science = dp.science.chemistry.element_symbol()
    transport = dp.transport.vehicle()
    code = dp.code.uuid()
    unit_system = dp.unit_system.bits()
    file = dp.file.mime_type()
    numbers = dp.numbers.integer_number(4)
    development = dp

# Generated at 2022-06-21 16:10:46.154426
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.misc import Misc
    from mimesis.providers.lorem import Lorem

    providers = [Misc, Lorem]
    g = Generic()
    g.add_providers(*providers)
    assert 'misc' in dir(g)
    assert 'lorem' in dir(g)
    assert not isinstance(g.misc, BaseProvider)
    assert not isinstance(g.lorem, BaseProvider)


# Generated at 2022-06-21 16:11:15.447200
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit test for method add_providers of class Generic."""
    class TestProvider(BaseProvider):
        """Class TestProvider."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            super().__init__(*args, **kwargs)

    class TestProvider1(BaseProvider):
        """Class TestProvider1."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            super().__init__(*args, **kwargs)

    class TestProvider2(BaseProvider):
        """Class TestProvider2."""

        def __init__(self, *args, **kwargs):
            """Initialize attributes lazily."""
            super().__init__(*args, **kwargs)


# Generated at 2022-06-21 16:11:22.249484
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic.person, Person)
    assert isinstance(generic.address, Address)
    assert isinstance(generic.datetime, Datetime)
    assert isinstance(generic.business, Business)
    assert isinstance(generic.text, Text)
    assert isinstance(generic.food, Food)
    assert isinstance(generic.science, Science)
    assert isinstance(generic.transport, Transport)
    assert isinstance(generic.code, Code)
    assert isinstance(generic.unit_system, UnitSystem)
    assert isinstance(generic.file, File)
    assert isinstance(generic.numbers, Numbers)
    assert isinstance(generic.development, Development)
    assert isinstance(generic.hardware, Hardware)
    assert isinstance(generic.clothing, Clothing)
    assert isinstance

# Generated at 2022-06-21 16:11:25.077352
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic('en')
    g.__getattribute__('person')
    assert g.__dict__['person'].locale == 'en'
    assert g.__dict__['person'].seed == g.seed


# Generated at 2022-06-21 16:11:34.323745
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    # It's work
    g._person = None
    g._address = None
    g._datetime = None
    g.food = g.__getattr__('food')
    assert g.food
    assert isinstance(g.food, Food)
    assert g.food.seed == g.seed
    assert g.food.locale == g.locale
    g.science = g.__getattr__('science')
    assert g.science
    assert isinstance(g.science, Science)
    assert g.science.seed == g.seed
    assert g.science.locale == g.locale
    g.text = g.__getattr__('text')
    assert g.text
    assert isinstance(g.text, Text)
    assert g.text.seed == g.seed

# Generated at 2022-06-21 16:11:36.019514
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    print(generic)

# Generated at 2022-06-21 16:11:39.223340
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic('en')
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)

if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-21 16:11:43.485127
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class TheTestProvider(BaseProvider):
        class Meta:
            name = 'custom'

        def foo(self):
            return 'bar'

    provider = Generic()
    provider.add_providers(TheTestProvider)
    assert provider.custom.foo() == 'bar'


# Generated at 2022-06-21 16:11:52.149625
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    providers = [
        Person,
        Address,
        Datetime,
        Business,
        Text,
        Food,
        Science,
        Transport,
        Code,
        UnitSystem,
        File,
        Numbers,
        Development,
        Hardware,
        Clothing,
        Internet,
        Path,
        Payment,
        Cryptographic,
        Structure,
        Choice,
    ]

    g = Generic()
    g.add_providers(*providers)
    provider_names = [provider.Meta.name for provider in providers]
    assert set(g.__dir__()) >= set(provider_names)

# Generated at 2022-06-21 16:11:59.522740
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data_provider = Generic()
    data_provider.address.address()
    data_provider.address.street_name()
    data_provider.address.city()
    data_provider.address.country()
    data_provider.address.building_number()
    assert data_provider.business.company()
    assert data_provider.business.company_type()
    assert data_provider.business.company_suffix()
    assert data_provider.business.industry()
    assert data_provider.business.experience()
    assert data_provider.business.vocation()
    assert data_provider.business.occupation()
    assert data_provider.business.activity()
    assert data_provider.business.profession()
    assert data_provider.business.position()
   

# Generated at 2022-06-21 16:12:02.489432
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    random_provider = Generic()
    res = random_provider.__dir__()
    return res