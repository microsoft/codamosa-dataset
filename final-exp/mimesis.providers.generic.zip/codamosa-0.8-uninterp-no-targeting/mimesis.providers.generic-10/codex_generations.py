

# Generated at 2022-06-21 16:09:59.718946
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
   generic = Generic('en', datetime.datetime(2000, 1, 1).timestamp())

   assert type(generic.__dir__()) == list
   assert len(generic.__dir__()) > 0

# Generated at 2022-06-21 16:10:08.886006
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for method __dir__ of class Generic."""
    t = Generic('en')
    output = t.__dir__()
    assert len(output) == 40
    assert 'address' in output
    assert 'person' in output
    assert 'datetime' in output
    assert 'business' in output
    assert 'text' in output
    assert 'food' in output
    assert 'science' in output
    assert 'transport' in output
    assert 'code' in output
    assert 'unit_system' in output
    assert 'file' in output
    assert 'numbers' in output
    assert 'development' in output
    assert 'hardware' in output
    assert 'clothing' in output
    assert 'internet' in output
    assert 'path' in output
    assert 'payment' in output

# Generated at 2022-06-21 16:10:12.102369
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic.

    :return: None
    """

    def test_provider(self, *args, **kwargs):
        return 'test_provider'

    provider = Generic()
    provider.add_provider(test_provider)
    assert provider.test_provider == 'test_provider'



# Generated at 2022-06-21 16:10:24.147802
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic('en')
    assert gen.person.name() == 'Daniel'
    assert gen.address.address() == '30973 Ralph Square' 
    assert gen.datetime.date() == '2016-12-14'
    assert gen.business.company() == 'Smith-Green'
    assert gen.text.text() == 'corrupti eveniet sint voluptates'
    assert gen.food.fruit() == 'apple'
    assert gen.science.periodic_element() == 'Uranium'
    assert gen.transport.airport() == 'Cape Verde International Airport'
    assert gen.code.npi() == '1801123317'
    assert gen.unit_system.imperial_length() == 'mile'
    assert gen.file.file_extension() == 'pdf'
    assert gen

# Generated at 2022-06-21 16:10:34.753526
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic"""
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development

# Generated at 2022-06-21 16:10:46.706131
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from .custom import FooBar
    from .providers import Custom

    c = Generic(locale='en')
    assert c.choice is not None
    c.add_provider(FooBar)
    assert c.foobar is not None
    assert c.foobar.seo_title is not None
    assert c.foobar.seo_title() == 'Api'
    c.add_provider(Custom)
    assert c.custom is not None
    assert c.custom.foo_bar is not None
    assert c.custom.foo_bar() == 'Foo Bar'

    c = Generic(locale='ru')
    assert c is not None
    assert c.choice is not None
    assert c.choice.person is not None

# Generated at 2022-06-21 16:10:50.370776
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    print(g.Person.full_name())
    print(g.Address.region())
    print(g.Text.title())


if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-21 16:10:56.486409
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProv(BaseProvider):
        def __init__(self, seed=None, **kwargs):
            super().__init__(seed)

        class Meta:
            name = 'myprov'

        def foo(self):
            return 'foo'

    g = Generic()
    g.add_provider(MyProv)

    assert g.myprov.foo() == 'foo'

    with raises(TypeError):
        g.add_provider(BaseProvider)

# Generated at 2022-06-21 16:11:04.493582
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        class Meta:
            name = 'test_provider'

        def test_method(self):
            return 'test_method'

    test_provider = Generic()
    test_provider.add_provider(TestProvider)
    assert test_provider.test_provider._seed == test_provider._seed
    assert test_provider.test_provider.test_method() == 'test_method'



# Generated at 2022-06-21 16:11:07.061750
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert len(a.__dict__) == 23
    assert len(a.__dir__()) == 30

# Generated at 2022-06-21 16:11:32.094464
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic('en')
    assert hasattr(generic, 'business')
    assert hasattr(generic, 'code')
    assert not hasattr(generic, 'sport')

    from mimesis.builtins.providers import Sport
    assert not hasattr(generic, 'sport')
    generic.add_provider(Sport)
    assert hasattr(generic, 'sport')



# Generated at 2022-06-21 16:11:35.181358
# Unit test for constructor of class Generic
def test_Generic():
    p = Generic()
    # print(p.person.full_name)
    # print(p.address.address)
    print(p.choice)


if __name__ == '__main__':
    test_Generic()

# Generated at 2022-06-21 16:11:41.587186
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Method should add a custom provider to Generic object.
    provider = Generic()
    from mimesis.providers.code import Code
    provider.add_provider(Code) # AttributeError
    assert 'code' in provider.__dir__()

    # Method should raise TypeError if cls is not class or is not a subclass
    # of BaseProvider.
    class A:
        pass

    provider = Generic()
    try:
        provider.add_provider(A)
    except TypeError:
        assert True

    class B(BaseProvider):
        pass

    provider = Generic()
    try:
        provider.add_provider(B)
    except TypeError:
        assert True

    class C(Generic):
        pass

    provider = Generic()

# Generated at 2022-06-21 16:11:45.580644
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.business import Business
    from mimesis.providers.date import Datetime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
   

# Generated at 2022-06-21 16:11:54.752334
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for add_provider of class Generic."""
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.numbers import Numbers

    class MyProvider(BaseDataProvider):
        """Custom provider to test Generic.add_provider()."""

        class Meta:
            """Class for metadata."""

            name = 'my_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def __getattr__(self, attrname: str) -> Any:
            """Get attribute without underscore.

            :param attrname: Attribute name.
            :return: An attribute.
            """

# Generated at 2022-06-21 16:11:58.431702
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from . import CustomProvider
    from .custom_provider import CustomProvider
    provider = Generic()
    provider.add_provider(CustomProvider)
    assert hasattr(provider, 'custom_provider') is True
    # Test for TypeError
    try:
        provider.add_provider('str')
    except TypeError:
        pass

# Generated at 2022-06-21 16:12:00.764919
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    x = Generic();
    assert x.my_attr == None, "BUG: Generic.__getattr__"


# Generated at 2022-06-21 16:12:03.654063
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class CustomProvider(BaseProvider):
        pass

    g = Generic()
    g.add_provider(CustomProvider)
    assert 'customprovider' in dir(g)

# Generated at 2022-06-21 16:12:07.114990
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    c1 = Generic()
    c1.add_providers(Numbers, Path)
    c2 = Generic()
    c2.add_providers(Numbers, Path, Payment)
    assert c1.numbers != c2.numbers
    assert c1.path != c2.path
    assert c2.payment



# Generated at 2022-06-21 16:12:14.043577
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    a = Generic()
    assert a.hash() is not None
    assert a.person.hash() is not None
    assert a.address.hash() is not None
    assert a.datetime.hash() is not None
    assert a.business.hash() is not None
    assert a.text.hash() is not None
    assert a.food.hash() is not None
    assert a.science.hash() is not None
    assert a.transport.hash() is not None
    assert a.code.hash() is not None
    assert a.unit_system.hash() is not None
    assert a.file.hash() is not None
    assert a.numbers.hash() is not None
    assert a.development.hash() is not None
    assert a.hardware.hash() is not None
    assert a.clothing.hash()

# Generated at 2022-06-21 16:12:38.497816
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.__str__() == 'Generic()'
    g = Generic('zh')
    assert g.__str__() == "Generic(locale='zh')"


# Generated at 2022-06-21 16:12:39.483877
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)



# Generated at 2022-06-21 16:12:41.458918
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test method add_providers."""
    g = Generic()
    g.add_providers(Person, Address)
    assert g.person is not None
    assert g.address is not None

# Generated at 2022-06-21 16:12:47.331934
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Unit test for method __getattr__ of class Generic."""
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.text, Text)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
   

# Generated at 2022-06-21 16:12:57.684905
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    p = Generic()
    p = Generic(seed=42)
    p = Generic('en')
    p = Generic('en', seed=42)
    p = Generic('en-GB')
    p = Generic('en-GB', seed=42)
    assert(p.person.full_name() == 'Mrs. Lisa Scott')
    assert(p.address.street_name() == 'Walnut Street')
    assert(p.datetime.date() == '1990-12-26')
    assert(p.business.company_name() == 'Wyman-Champlin')
    assert(p.text.word() == 'temporibus')
    assert(p.food.fruit() == 'Figs')
    assert(p.science.element_symbol() == 'Tl')

# Generated at 2022-06-21 16:13:00.378814
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    print(generic.person.full_name())
    generic = Generic(locale='ru')
    print(generic.person.full_name())


# Generated at 2022-06-21 16:13:05.710028
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    person = g.person                 # type: Person
    address = g.address               # type: Address
    datetime = g.datetime             # type: Datetime
    business = g.business             # type: Business
    text = g.text                     # type: Text
    food = g.food                     # type: Food
    science = g.science               # type: Science
    transport = g.transport           # type: Transport
    code = g.code                     # type: Code
    unit_system = g.unit_system       # type: UnitSystem
    file = g.file                     # type: File
    numbers = g.numbers               # type: Numbers
    development = g.development       # type: Development
    hardware = g.hardware             # type: Hardware
    clothing = g.clothing             # type: Clothing
   

# Generated at 2022-06-21 16:13:06.130675
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()

# Generated at 2022-06-21 16:13:07.043762
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert isinstance(generic, Generic)



# Generated at 2022-06-21 16:13:07.753720
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen is not None

# Generated at 2022-06-21 16:13:30.920414
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    result = [
        'address', 'business', 'choice', 'code', 'clothing',
        'cryptographic', 'datetime', 'development', 'file',
        'food', 'hardware', 'internet', 'numbers', 'path',
        'payment', 'person', 'science', 'structure', 'text',
        'transport', 'unit_system']

    result.sort()
    assert g.__dir__().sort() == result