

# Generated at 2022-06-21 16:10:06.843310
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Person(BaseProvider):
        class Meta:
            name = 'person'
        def first_name(self, gender=None):
            return 'James'
    class Address(BaseProvider):
        class Meta:
            name = 'address'
        def address(self):
            return 'My address'
    class Internet(BaseProvider):
        class Meta:
            name = 'internet'
        def email(self, domains=None):
            return 'a@a.com'
    d = Generic()
    d.add_providers(Person, Address, Internet)
    d.person.first_name()
    d.address.address()
    d.internet.email()
    d.seed = 0
    d.add_providers(Person, Address, Internet)
    assert d.person.first_name() == 'James'
   

# Generated at 2022-06-21 16:10:10.746011
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for add_providers."""
    g = Generic()
    g.add_providers(Person, Address, Business)
    assert hasattr(g, 'person')
    assert hasattr(g, 'address')
    assert hasattr(g, 'business')

# Generated at 2022-06-21 16:10:13.402707
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """test_Generic_add_provider method."""
    g = Generic()
    print(dir(g))
    assert 'science' in dir(g)

    from mimesis.providers.text import Lorem
    g.add_provider(Lorem)
    assert 'lorem' in dir(g)

# Generated at 2022-06-21 16:10:24.857556
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic('ru')
    assert generic
    assert 'person' in dir(generic)
    assert generic.person
    assert 'datetime' in dir(generic)
    assert generic.datetime
    assert 'address' in dir(generic)
    assert generic.address
    assert 'business' in dir(generic)
    assert generic.business
    assert 'text' in dir(generic)
    assert generic.text
    assert 'food' in dir(generic)
    assert generic.food
    assert 'science' in dir(generic)
    assert generic.science
    assert 'transport' in dir(generic)
    assert generic.transport
    assert 'code' in dir(generic)
    assert generic.code
    assert 'unit_system' in dir(generic)
    assert generic.unit_system

# Generated at 2022-06-21 16:10:32.017170
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.enums import Currencies

    def test_provider(BaseProvider):
        class Meta:
            name = 'test'
            locales = ['en']

        class Provider(BaseProvider):
            currency = Currencies.EURO

            def foo(self):
                return self.currency

    g = Generic()
    g.add_provider(test_provider)
    assert g.test.foo() == Currencies.EURO

# Generated at 2022-06-21 16:10:35.904766
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
        class Meta:
            name = 'provider'
    generic = Generic()
    generic.add_provider(Provider)
    assert len(list(filter(lambda x: x.startswith('_'), dir(generic))),) == len(list(filter(lambda x: x.startswith('_'), dir(generic))))

# Generated at 2022-06-21 16:10:48.275633
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    print("##### start test_Generic #####")
    assert isinstance(gen, Generic)
    assert isinstance(gen.choice, Choice)
    assert isinstance(gen.person, Person)
    assert isinstance(gen.address, Address)
    assert isinstance(gen.datetime, Datetime)
    assert isinstance(gen.business, Business)
    assert isinstance(gen.text, Text)
    assert isinstance(gen.food, Food)
    assert isinstance(gen.science, Science)
    assert isinstance(gen.transport, Transport)
    assert isinstance(gen.code, Code)
    assert isinstance(gen.unit_system, UnitSystem)
    assert isinstance(gen.file, File)
    assert isinstance(gen.numbers, Numbers)

# Generated at 2022-06-21 16:10:57.127735
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
	# The method __getattr__ is just a wrapper for the method __getattribute__
	# The method __getattribute__ is used to get attribute of an object
	obj = Generic()
	assert obj.person.name() == 'Полина'
	assert obj.address.town() == 'Азов'
	assert obj.datetime.now().year == 2020
	assert obj.business.company().upper() == 'ООО "ПРОМЫШЛЕННЫЕ СИСТЕМЫ"'
	assert obj.text.text().split('.')[0] == 'Не проходи мимо, пожалей'

# Generated at 2022-06-21 16:10:58.001676
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert str(g.locale) == str(type(g).locale)



# Generated at 2022-06-21 16:11:05.112341
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test for Generic.add_providers()"""
    gen = Generic()
    len_gen_dict = len(gen.__dict__)
    len_gen_dir = len(dir(gen))
    gen.add_providers(
        Address,
        Business,
        Datetime,
        Food,
        Text,
        Transport,
    )
    assert len_gen_dir < len(dir(gen))
    assert len_gen_dict < len(gen.__dict__)

# Generated at 2022-06-21 16:11:17.919712
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    cls = Generic()
    assert isinstance(cls.__dir__(), list)
    assert cls.__dir__() != []

# Generated at 2022-06-21 16:11:19.179081
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person().full_name() == g.__getattr__('person').full_name()

# Generated at 2022-06-21 16:11:23.012074
# Unit test for constructor of class Generic
def test_Generic():
    dp = Generic()
    assert dp.choice and dp.transport and dp.code and dp.unit_system and dp.file and dp.numbers and dp.development and dp.hardware and dp.clothing and dp.internet and dp.path and dp.payment and dp.cryptographic and dp.structure and dp.choice


# Generated at 2022-06-21 16:11:27.659240
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    import mimesis
    gen = mimesis.Generic()
    dir_list = gen.__dir__()
    assert sorted(dir_list) == sorted(['address', 'business', 'choice',
                        'clothing', 'code', 'cryptographic',
                        'datetime', 'development', 'file',
                        'food', 'hardware', 'internet',
                        'numbers', 'path', 'person',
                        'payment', 'science', 'structure',
                        'text', 'transport', 'unit_system'])

# Generated at 2022-06-21 16:11:31.005196
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    # generic = Generic()
    # assert isinstance(generic.person, Person)
    # assert isinstance(generic.address, Address)

    pass



# Generated at 2022-06-21 16:11:35.182022
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test Generic.add_providers."""
    g = Generic()
    g.add_providers(Person, Address, Datetime, Business)

    assert g._person
    assert g.person

    assert g._address
    assert g.address

    assert g._datetime
    assert g.datetime

    assert g._business
    assert g.business

# Generated at 2022-06-21 16:11:39.160335
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test for Generic.__getattr__(attrname) method."""
    generic = Generic()
    generic.__getattr__('person')
    assert generic.person is not None



# Generated at 2022-06-21 16:11:46.187272
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    import pytest
    from mimesis.providers.hardware import Hardware
    g = Generic()
    g.add_provider(Hardware)
    assert g.hardware
    class Provider(BaseProvider):
        def _foo(self):
            return 'bar'
    g.add_provider(Provider)
    assert g.provider.foo() == 'bar'
    with pytest.raises(AttributeError):
        g.provider.make_foo()

# Generated at 2022-06-21 16:11:54.813764
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test method add_provider of class Generic."""
    mimesis_provider = Generic()

    # add custom provider to mimesis.providers.Generic
    class CustomProvider(BaseProvider):
        """Custom provider for unit test."""

        class Meta:
            """Class for metadata."""

            name = 'custom'

        def __init__(self, *args, **kwargs) -> None:
            """Initialize attributes lazily.

            :param args: Arguments.
            :param kwargs: Keyword arguments.
            """
            super().__init__(*args, **kwargs)
            self._data = {
                'en': ['test_a', 'test_b', 'test_c']
            }

        def data(self) -> str:
            """Provide a random data."""

# Generated at 2022-06-21 16:11:56.259584
# Unit test for constructor of class Generic
def test_Generic():
    provider = Generic()



# Generated at 2022-06-21 16:12:09.344003
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic( 'en')
    assert isinstance(generic, Generic)
    assert 'person' in generic.__dir__()
    assert 'datetime' in generic.__dir__()
    assert 'address' in generic.__dir__()
    assert 100 < len(generic.__dir__()) < 150

# Generated at 2022-06-21 16:12:10.870043
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    f = Generic()
    s = f.science
    assert hasattr(s, 'elements')

# Generated at 2022-06-21 16:12:15.548485
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=1)
    assert generic.choice
    assert generic.internet
    assert generic.food
    assert generic.transport.car.make() == "Nissan"
    assert generic.unit_system.weight.pound() == "322.25 lb"
    assert generic.food.fruit()
    assert generic.unit_system.length.kilometer() == "2.58 km"
    assert generic.code.iban.iban() == "EE37770001200002224"
    assert generic.file.mime_type() == "audio"
    assert generic.choice.random_element()
    assert generic.business.bank.iban() == "DK646456000487035"
    assert generic.numbers.emoji.hex() == "1f30d"

# Generated at 2022-06-21 16:12:28.635218
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.business import Business
    from mimesis.providers.text import Text
    from mimesis.providers.food import Food
    from mimesis.providers.science import Science
    from mimesis.providers.transport import Transport
    from mimesis.providers.code import Code
    from mimesis.providers.units import UnitSystem
    from mimesis.providers.file import File
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.development import Development
    from mimesis.providers.hardware import Hardware

# Generated at 2022-06-21 16:12:31.551685
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    g = Generic()
    assert len(g.__dir__()) > 0
    providers = [Person]
    g.add_providers(*providers)
    assert len(g.__dir__()) > len(__all__)

# Generated at 2022-06-21 16:12:35.746189
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test add_provider method of class Generic."""
    from mimesis.providers.other import Other
    p = Generic()
    p.add_provider(Other)
    assert hasattr(p, 'other')
    assert isinstance(p.other, Other)
    assert p.other.provider == 'other'
    assert p.other.locale == 'en-GB'

# Generated at 2022-06-21 16:12:40.006106
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.text import Text
    from mimesis.providers.file import File
    from mimesis.providers.science import Science

    gen = Generic()
    gen.add_provider(Text)
    gen.add_provider(Science)
    gen.add_provider(File)

    assert hasattr(gen, 'text')
    assert hasattr(gen, 'file')
    assert hasattr(gen, 'science')


# Generated at 2022-06-21 16:12:44.273800
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic



# Generated at 2022-06-21 16:12:52.641033
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Create a custom provider
    class MyProvider(BaseProvider):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.__version__ = '0.0.0'

        def my_method(self):
            return 'My provider'

    # Create a list of providers
    providers = [MyProvider]
    # Create a Generic object
    generic = Generic()
    # Add providers in Generic instance
    generic.add_providers(*providers)
    # Test add provider
    my_provider = generic.myprovider
    assert my_provider.__version__ == '0.0.0'
    assert my_provider.my_method() == 'My provider'

# Generated at 2022-06-21 16:12:59.579749
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.identifier import Identifier
    from mimesis.providers.location import Location
    from mimesis.providers.misc import Misc
    assert hasattr(Generic, 'identifier') == False
    assert hasattr(Generic, 'location') == False
    assert hasattr(Generic, 'misc') == False
    Generic.add_provider(Identifier)
    Generic.add_provider(Location)
    Generic.add_provider(Misc)
    assert hasattr(Generic, 'identifier') == True
    assert hasattr(Generic, 'location') == True
    assert hasattr(Generic, 'misc') == True

# Generated at 2022-06-21 16:13:28.521192
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic('en')
    assert g.datetime.__class__.__name__ == 'Datetime'
    assert g.development.__class__.__name__ == 'Development'
    assert g.business.__class__.__name__ == 'Business'
    assert g.address.__class__.__name__ == 'Address'
    assert g.person.__class__.__name__ == 'Person'
    assert g.food.__class__.__name__ == 'Food'
    assert g.science.__class__.__name__ == 'Science'

# Generated at 2022-06-21 16:13:33.976114
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Unit tests for method add_provider of class Generic."""
    obj = Generic()
    assert all(name not in dir(obj) for name in ('foo', 'bar'))
    obj.add_providers(Foo, Bar)
    assert all(name in dir(obj) for name in ('foo', 'bar'))
    assert all(isinstance(getattr(obj, name), BaseProvider)
               for name in ('foo', 'bar'))
    assert obj.foo.locale == obj.locale
    assert obj.bar.locale == obj.locale
    assert obj.foo.seed == obj.seed
    assert obj.bar.seed == obj.seed



# Generated at 2022-06-21 16:13:44.348065
# Unit test for constructor of class Generic
def test_Generic():    
    gene = Generic()
    assert gene != None
    assert hasattr(gene, '__getattr__')
    assert callable(getattr(gene, '__getattr__', None))
    assert hasattr(gene, 'person')
    assert hasattr(gene, 'address')
    assert hasattr(gene, 'datetime')
    assert hasattr(gene, 'business')
    assert hasattr(gene, 'text')
    assert hasattr(gene, 'food')
    assert hasattr(gene, 'science')
    assert hasattr(gene, 'transport')
    assert hasattr(gene, 'code')
    assert hasattr(gene, 'unit_system')
    assert hasattr(gene, 'file')
    assert hasattr(gene, 'numbers')

# Generated at 2022-06-21 16:13:49.562198
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert '__dict__' in dir(g)
    assert '__weakref__' in dir(g)
    assert '__doc__' in dir(g)
    assert '__module__' in dir(g)
    assert '__init__' in dir(g)
    assert '__getattr__' in dir(g)
    assert '__dir__' in dir(g)
    assert 'add_provider' in dir(g)
    assert 'add_providers' in dir(g)
    assert 'person' not in dir(g)
    assert 'address' not in dir(g)
    assert 'datetime' not in dir(g)
    assert 'business' not in dir(g)
    assert 'text' not in dir(g)
    assert 'food' not in dir(g)

# Generated at 2022-06-21 16:14:00.385778
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a custom provider
    class CustomProvider(BaseProvider):
        class Meta:
            name = "custom"

        def __init__(self): # noqa: D107
            super().__init__()

        def custom_provider(self):  # noqa: D102
            return "foo"

    g = Generic() # noqa: F841
    # No 'custom' field should be present in Generic's instance
    assert not hasattr(g, 'custom')
    # Add custom class to Generic's instance
    g.add_provider(CustomProvider)
    # 'custom' field should be present in Generic's instance
    assert hasattr(g, 'custom')
    # 'custom.Meta.name' is 'custom'
    assert getattr(g.custom.Meta, 'name') == 'custom'
    # 'custom.

# Generated at 2022-06-21 16:14:02.192840
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    assert Generic().__class__.__name__ == 'Generic'
    pass


# Generated at 2022-06-21 16:14:06.435778
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=2)
    assert g.choice.true() == True
    assert g.choice.false() == False
    assert g.choice.boolean() == False


if __name__ == '__main__':
    test_Generic___getattr__()

# Generated at 2022-06-21 16:14:12.775029
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import unittest

    from mimesis.enums import Gender
    from mimesis.providers.base import BaseDataProvider

    class Custom(BaseDataProvider):
        class Meta:
            name = 'custom'

        def gender(self, gender: Gender = None) -> str:
            gender = self.random.choice(list(Gender))
            return gender.value

    class TestGeneric(unittest.TestCase):
        def test_add_providers(self):
            generic = Generic('en')
            generic.add_providers(Custom)
            self.assertEqual(generic.custom.gender(), 'MALE')
            self.assertTrue(isinstance(generic.custom, Custom))

    unittest.main()

# Generated at 2022-06-21 16:14:22.530237
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic(seed=1234)
    assert gen.datetime.datetime() == '1999-05-09T08:15:30+00:00'
    assert gen.datetime.timestamp() == 923847162.209165
    assert gen.datetime.epoch() == 923847162.209165

    assert gen.datetime.local_datetime() == '1999-05-09T03:15:30'
    assert gen.datetime.local_date() == '1999-05-09'
    assert gen.datetime.local_time() == '03:15:30'
    assert gen.datetime.year() == 1999
    assert gen.datetime.month() == 5
    assert gen.datetime.day() == 9
    assert gen.datetime.hour() == 3
    assert gen.datetime

# Generated at 2022-06-21 16:14:31.836790
# Unit test for constructor of class Generic
def test_Generic():

    #precondition
    assert Generic().person.name() is not None
    assert Generic().address.city() is not None
    assert Generic().business.company() is not None
    assert Generic().text.word() is not None
    assert Generic().food.dish() is not None
    assert Generic().science.latin_element() is not None
    assert Generic().transport.car() is not None
    assert Generic().code.imei() is not None
    assert Generic().unit_system.weight() is not None
    assert Generic().file.mime_type() is not None
    assert Generic().numbers.positive_float() is not None
    assert Generic().development.framework_version() is not None
    assert Generic().hardware.cpu() is not None
    assert Generic().clothing.brand() is not None

# Generated at 2022-06-21 16:15:18.208154
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import types

    class CustomProvider(BaseProvider):  # type: ignore
        class Meta:
            name = 'custom'

        def foo(self, *args, **kwargs):  # pragma: no cover
            pass

    class AnotherProvider(BaseProvider):  # type: ignore
        class Meta:
            name = 'another'

        def foo(self, *args, **kwargs):  # pragma: no cover
            pass

    class YetAnotherProvider(BaseProvider):  # type: ignore
        def bar(self, *args, **kwargs):  # pragma: no cover
            pass

    generic = Generic()
    generic.add_providers(CustomProvider, AnotherProvider, YetAnotherProvider)
    assert isinstance(generic.custom, CustomProvider)
    assert isinstance(generic.another, AnotherProvider)

# Generated at 2022-06-21 16:15:24.268540
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()

    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)
    assert isinstance(g.business, Business)
    assert isinstance(g.food, Food)
    assert isinstance(g.science, Science)
    assert isinstance(g.transport, Transport)
    assert isinstance(g.code, Code)
    assert isinstance(g.unit_system, UnitSystem)
    assert isinstance(g.file, File)
    assert isinstance(g.numbers, Numbers)
    assert isinstance(g.development, Development)
    assert isinstance(g.hardware, Hardware)
    assert isinstance(g.clothing, Clothing)
    assert isinstance(g.internet, Internet)
    assert isinstance

# Generated at 2022-06-21 16:15:25.219558
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic(seed = 'test')
    assert general.person.full_name() == 'test'

# Generated at 2022-06-21 16:15:36.062151
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=None)
    # Test for method __dir__
    print(dir(generic))
    # Test for method add_providers
    additional = [Code, Internet, Transport]
    generic.add_providers(*additional)
    # Test for method __getattr__
    print(generic.code.uuid())
    print(generic.person.full_name())
    print(generic.address.address())
    print(generic.transport.vehicle())
    print(generic.internet.ip_address())
    print(generic.business.iban())
    print(generic.food.ingredient())
    print(generic.science.scientific_name())
    print(generic.text.text())
    # Test for method add_provider
    generic.add_provider(Path)

# Generated at 2022-06-21 16:15:39.095661
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'
        def say(self):
            return 'Hi'
    class AnotherCustomProvider(BaseProvider):
        def say(self):
            return 'Hi,world'
    generic = Generic()
    generic.add_providers(CustomProvider,AnotherCustomProvider)
    assert generic.custom_provider.say() == 'Hi'
    assert generic.anothercustomprovider.say() == 'Hi,world'

# Generated at 2022-06-21 16:15:41.032135
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic('hi')
    assert generic.choice.true() is True

# Generated at 2022-06-21 16:15:48.710153
# Unit test for constructor of class Generic
def test_Generic():
    generics = Generic('en')
    assert generics.choice.bool() == True
    assert generics.choice.bool() == False
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice.bool()
    assert generics.choice

# Generated at 2022-06-21 16:15:50.840090
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    data = g.__dir__()
    assert isinstance(data, list)


# Generated at 2022-06-21 16:15:53.673802
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for Generic.__dir__()

    :return: True if test passed
    """
    gen = Generic()
    result = gen.__dir__()
    for a in result:
        assert hasattr(gen, a)
    return True

# Generated at 2022-06-21 16:15:56.810425
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    assert isinstance(g.person, Person)
    assert isinstance(g.address, Address)
    assert isinstance(g.datetime, Datetime)

# Generated at 2022-06-21 16:16:36.764814
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers method of class Generic."""
    generic = Generic()
    assert generic.numbers
    assert not generic.ip_v4_address

# Generated at 2022-06-21 16:16:40.617643
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    data_providers = ['address', 'choice', 'clothing', 'code', 'cryptographic',
                      'datetime', 'person', 'payment', 'path', 'science',
                      'structure', 'text', 'transport', 'unit_system']
    generic = Generic()
    assert sorted(generic.__dir__()) == sorted(data_providers)



# Generated at 2022-06-21 16:16:44.017510
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    # Initialize instance of Generic class
    gen = Generic()

    # Add providers
    providers = [Person, Address, Datetime, Transport]
    gen.add_providers(*providers)

    # Check if all providers were added
    assert all(attr in gen.__dir__() for attr in [p.Meta.name for p in providers])

# Generated at 2022-06-21 16:16:50.273676
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()
    assert gen.address()
    assert gen.business()
    assert gen.choice()
    assert gen.clothing()
    assert gen.code()
    assert gen.cryptographic()
    assert gen.datetime()
    assert gen.development()
    assert gen.file()
    assert gen.food()
    assert gen.hardware()
    assert gen.internet()
    assert gen.numbers()
    assert gen.path()
    assert gen.payment()
    assert gen.person()
    assert gen.science()
    assert gen.structure()
    assert gen.text()
    assert gen.transport()
    assert gen.unit_system()


# Generated at 2022-06-21 16:16:56.395193
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    assert 'phone' not in dir(g)

    class Phone(BaseProvider):
        class Meta:
            name = 'phone'

        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
            self.__fake = self._seed.randint(0, 10, 3)

        def phone_code(self, mask='###'):
            """Fake phone code."""
            return self.__fake

    g.add_provider(Phone)
    assert 'phone' in dir(g)
    assert g.phone.phone_code() == Phone(seed=g._seed).phone_code()

# Generated at 2022-06-21 16:17:04.129463
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic()
    g.person.name()
    g.address.city()
    g.datetime.day_of_week()
    g.business.company()
    g.text.word()
    g.food.ingredient()
    g.science.element()
    g.transport.license_plate()
    g.code.isbn()
    g.unit_system.mass()
    g.file.extension()
    g.numbers.number()
    g.development.framework()
    g.hardware.cpu()
    g.clothing.jacket()
    g.internet.email()
    g.path.home()
    g.payment.credit_card_number()
    g.cryptographic.hash()
    g.structure.list()
    g.choice.choice()



# Generated at 2022-06-21 16:17:07.525315
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Unit test for Generic.__dir__."""
    generic = Generic()
    assert len(generic.__dir__()), 23

# Generated at 2022-06-21 16:17:09.547240
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test __dir__ of class Generic."""
    gen = Generic()
    assert type(gen.__dir__()) is list



# Generated at 2022-06-21 16:17:18.814875
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Prov1(BaseProvider):
        class Meta:
            name = 'prov1'
            locales = ['en', 'ru']

    class Prov2(BaseProvider):
        class Meta:
            name = 'prov2'
            locales = ['ko', 'ja']

    class Prov3(BaseProvider):
        class Meta:
            name = 'prov3'
            locales = ['ko', 'ja']

    class Prov4(BaseProvider):
        class Meta:
            name = 'prov4'
            locales = ['ko', 'ja']

    generic = Generic('ko')
    generic.add_providers(Prov1, Prov2)
    assert hasattr(generic, Prov2.Meta.name)
    generic.add_providers(Prov3)
    assert hasattr(generic, Prov3.Meta.name)

# Generated at 2022-06-21 16:17:24.583407
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=123)
    assert g.person.username == 'Carlos_Freeman'
    assert g.address.country() == 'United Kingdom'
    assert g.datetime.date(start='2017-01-01', end='today') == '2017-08-30'
    assert g.business.job_title() == 'Research Chemist'
    assert g.text.sentence() == 'Inventore totam dolores laboriosam.'
    assert g.food.spice() == 'anise'
    assert g.science.element_symbol() == 'Rb'
    assert g.transport.flight_number() == 'BZ0982'
    assert g.code.issn() == '2858902'
    assert g.unit_system._convert(1, 'meter', 'foot') == 3

# Generated at 2022-06-21 16:18:41.660351
# Unit test for constructor of class Generic
def test_Generic():
    #pass
    print("test_Generic")
    g = Generic()
    print(g.science.periodic_element())
    print(g.science.periodic_table())


# Generated at 2022-06-21 16:18:48.386513
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Raise the AttributeError if no attrname attribute found."""
    gen = Generic()
    assert gen.person.full_name() == 'Mr. John Jack'
    assert gen.datetime.date(start=1990, end=2000) == '1990-08-31'
    assert gen.address.address() == '3232 Hamilton Reaches'
    assert gen.business.company() == 'Reichel-Hegmann'
    assert gen.food.beverage() == 'soda'
    assert gen.science.chemical_element() == 'Sodium'
    assert gen.transport.vehicle() == 'Koenigsegg One:1'
    assert gen.code.isbn() == 'ISBN-10: 3-16-148410-X'
    assert gen.unit_system.distance() == 'foot'

# Generated at 2022-06-21 16:18:56.910871
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    data = Generic('ru')
    assert data.person != None
    assert data.address != None
    assert data.datetime != None
    assert data.business != None
    assert data.text != None
    assert data.food != None
    assert data.science != None
    assert data.transport != None
    assert data.code != None
    assert data.unit_system != None
    assert data.file != None
    assert data.numbers != None
    assert data.development != None
    assert data.hardware != None
    assert data.clothing != None
    assert data.internet != None
    assert data.path != None
    assert data.payment != None
    assert data.cryptographic != None
    assert data.structure != None
    assert data.choice != None


# Generated at 2022-06-21 16:19:00.326257
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Check if method works with correct arguments
    class Test(BaseProvider):
        class Meta:
            name = 'test'

        def test(self):
            return 'test'

    generic = Generic()
    generic.add_provider(Test)
    assert generic.test.test() == 'test'



# Generated at 2022-06-21 16:19:03.338481
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.geography import Geography
    from mimesis.providers.software import Software
    provider = Generic()
    provider.add_providers(Geography, Software)
    assert hasattr(provider, 'geography')
    assert hasattr(provider, 'software')


# Generated at 2022-06-21 16:19:04.985467
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    dir = Generic().__dir__()
    assert isinstance(dir, list)
    assert len(dir) > 0
    assert 'person' in dir

# Generated at 2022-06-21 16:19:07.377442
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Unit test for method add_provider of class Generic"""
    from mimesis.providers.address import Address

    a = Generic('en')
    a.add_provider(Address)
    assert a.address.city() == 'Newport'



# Generated at 2022-06-21 16:19:11.022050
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    expected = ["address", "business", "choice", "code", "clothing",
                "cryptographic", "datetime", "development", "file",
                "hardware", "internet", "numbers", "path", "payment",
                "person", "science", "structure", "text", "transport",
                "unit_system", "food", "func_code", "func_default_code",
                "get_file", "get_number", "get_time", "seed", "stat_code"]
    gen = Generic()
    result = dir(gen)
    assert result == expected

# Generated at 2022-06-21 16:19:14.025747
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert gen.internet.uuid() == gen.uuid()
    assert gen.person.first_name() == gen.first_name()

    # Test with underscore
    assert gen._internet.uuid() == gen.uuid()
    assert gen._person.first_name() == gen.first_name()



# Generated at 2022-06-21 16:19:16.047488
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass