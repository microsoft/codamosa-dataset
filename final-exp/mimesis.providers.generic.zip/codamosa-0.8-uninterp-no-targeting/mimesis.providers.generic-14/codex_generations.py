

# Generated at 2022-06-21 16:10:03.291507
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic(seed=1234)
    assert g.person
    assert g.address
    assert g.datetime
    assert g.business
    assert g.text
    assert g.food
    assert g.science
    assert g.transport
    assert g.code
    assert g.unit_system
    assert g.file
    assert g.numbers
    assert g.development
    assert g.hardware
    assert g.clothing
    assert g.internet
    assert g.path
    assert g.payment
    assert g.cryptographic
    assert g.structure
    assert g.choice
    assert hasattr(g, 'transport')
    assert hasattr(g, 'code')
    assert hasattr(g, 'unit_system')
    assert hasattr(g, 'file')

# Generated at 2022-06-21 16:10:10.418142
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person


    class CustomProvider(BaseProvider):
        """CustomProvider class."""

        class Meta:
            """Class for metadata."""

            name = 'custom_provider'

        def build(self) -> str:
            return 'value'

    gen = Generic()
    gen.add_provider(CustomProvider)
    gen.add_provider(Person)

    assert isinstance(gen.custom_provider, CustomProvider)
    assert gen.custom_provider.build() == 'value'

    assert isinstance(gen.person, Person)
    assert gen.person.full_name() is not None



# Generated at 2022-06-21 16:10:11.340344
# Unit test for constructor of class Generic
def test_Generic():
    
    gen = Generic()
    assert isinstance(gen, Generic)

# Generated at 2022-06-21 16:10:12.675203
# Unit test for constructor of class Generic
def test_Generic():
    """Test for constructor of class Generic."""
    g = Generic('ru')
    g.add_providers()

# Generated at 2022-06-21 16:10:22.327910
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers import _base

    class CustomProvider(_base.BaseProvider):
        class Meta:
            name = 'custom_provider'

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._special_attrs = {'a': 'b'}

        def foo(self):
            return self._special_attrs['a']

    g = Generic(seed=12345678)
    g.add_provider(CustomProvider)
    assert g.custom_provider.foo() == 'b'



# Generated at 2022-06-21 16:10:23.971603
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    assert isinstance(
        dir(Generic()),
        list
    )

# Generated at 2022-06-21 16:10:26.131788
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic()
    gen.add_providers(Address, Business)
    gen.add_provider(Address)
    return gen

# Generated at 2022-06-21 16:10:29.810787
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    generic = Generic()
    generic.add_provider(Person)
    assert hasattr(generic, 'person')
    assert isinstance(generic.person, Person)

# Generated at 2022-06-21 16:10:31.158855
# Unit test for constructor of class Generic
def test_Generic():
    """Test of creating class Generic"""
    assert Generic() is not None


# Generated at 2022-06-21 16:10:33.134107
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    from mimesis.providers.misc import Misc
    generic = Generic()
    generic.add_provider(Misc)
    dir(generic)