

# Generated at 2022-06-21 16:09:58.990350
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
  gen = Generic()
  assert isinstance(gen.person, Person)
  assert isinstance(gen.datetime, Datetime)

# Generated at 2022-06-21 16:10:08.430240
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    m = Generic(seed=12345)
    assert isinstance(m.person, Person)
    assert isinstance(m.address, Address)
    assert isinstance(m.business, Business)
    assert isinstance(m.text, Text)
    assert isinstance(m.datetime, Datetime)
    assert isinstance(m.food, Food)
    assert isinstance(m.science, Science)
    assert isinstance(m.transport, Transport)
    assert isinstance(m.code, Code)
    assert isinstance(m.unit_system, UnitSystem)
    assert isinstance(m.file, File)
    assert isinstance(m.numbers, Numbers)
    assert isinstance(m.development, Development)
    assert isinstance(m.hardware, Hardware)
    assert isinstance(m.clothing, Clothing)

# Generated at 2022-06-21 16:10:14.657352
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Test for Generic.__dir__()."""
    g = Generic() # seed=None

    d = dir(g)

    assert('person' in d)
    assert('address' in d)
    assert('datetime' in d)
    assert('business' in d)
    assert('text' in d)
    assert('food' in d)
    assert('science' in d)
    assert('transport' in d)
    assert('code' in d)
    assert('unit_system' in d)
    assert('file' in d)
    assert('numbers' in d)
    assert('development' in d)
    assert('hardware' in d)
    assert('clothing' in d)
    assert('internet' in d)
    assert('path' in d)
    assert('payment' in d)

# Generated at 2022-06-21 16:10:25.550682
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    g = Generic()
    # Providers which have not BaseProvider as a parent class
    class TestProvider(object):
        pass
    # Providers which have BaseProvider as a parent class
    class TestProvider2(BaseProvider):
        pass
    # Providers which have BaseProvider as a parent class
    # and name in Meta class
    class TestProvider3(BaseProvider):
        class Meta:
            name = "test_provider"
    # Providers which have BaseProvider as a parent class
    # and name in Meta class
    class TestProvider4(BaseProvider):
        class Meta:
            name = "test_provider"
    g.add_provider(TestProvider2)
    g.add_provider(TestProvider3)
    g.add_provider(TestProvider4)
    # Test that a provider has been added to Generic

# Generated at 2022-06-21 16:10:29.313024
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    """Test __getattr__ of class Generic."""
    generic = Generic(seed=42)
    result = generic.person.full_name()
    assert result == "Randy Johnson"

# Generated at 2022-06-21 16:10:37.694319
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.abstract import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.typing import ProviderT

    def test_user_provider(BaseProvider):
        class User(BaseProvider):
            class Meta:
                name = 'user'

            def username(self) -> str:
                return 'Username: {}'.format(self.person.name())

        return User
    
    test_user_provider = test_user_provider(BaseProvider)
    generic_provider = Generic()

    class CustomGeneric(Generic):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.user = test_user_provider(seed=self.seed)

   

# Generated at 2022-06-21 16:10:48.090993
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    """Test for method add_provider() of class Generic."""
    from mimesis.providers.generic import Generic
    from mimesis.providers.social import SocialNetwork
    generic = Generic('en')


    class TestProvider(BaseProvider):
        def method(self):
            return self.datetime.datetime(datetime_format='%Y-%m-%d')

    custom_provider = TestProvider('en')
    generic.add_provider(custom_provider)
    assert generic.testprovider.method().startswith('2')

    generic.add_provider(SocialNetwork)
    assert generic.socialnetwork.user_name() is not None


# Generated at 2022-06-21 16:10:56.429930
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    expected = [
        'address',
        'add_provider',
        'add_providers',
        'business',
        'choice',
        'clothing',
        'code',
        'cryptographic',
        'datetime',
        'development',
        'file',
        'food',
        'hardware',
        'internet',
        'numbers',
        'path',
        'payment',
        'person',
        'science',
        'structure',
        'text',
        'transport',
        'unit_system',
    ]
    generic = Generic(seed=42)
    assert sorted(generic.__dir__()) == sorted(expected)


# Generated at 2022-06-21 16:10:59.398008
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')
    result = generic.__dir__()
    assert type(result) == list


# Generated at 2022-06-21 16:11:09.902535
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    providers = dir(Generic())
    assert 'person' in providers
    assert 'address' in providers
    assert 'datetime' in providers
    assert 'business' in providers
    assert 'text' in providers
    assert 'food' in providers
    assert 'science' in providers
    assert 'transport' in providers
    assert 'code' in providers
    assert 'unit_system' in providers
    assert 'file' in providers
    assert 'numbers' in providers
    assert 'development' in providers
    assert 'hardware' in providers
    assert 'clothing' in providers
    assert 'internet' in providers
    assert 'path' in providers
    assert 'payment' in providers
    assert 'cryptographic' in providers
    assert 'structure' in providers
    assert 'choice' in providers

# Generated at 2022-06-21 16:11:32.723202
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic()
    assert generic
    assert generic.choice
    assert generic.code
    assert generic.cryptographic
    assert generic.development
    assert generic.file
    assert generic.hardware
    assert generic.internet
    assert generic.numbers
    assert generic.path
    assert generic.payment
    assert generic.structure
    assert generic.transport
    assert generic.unit_system

