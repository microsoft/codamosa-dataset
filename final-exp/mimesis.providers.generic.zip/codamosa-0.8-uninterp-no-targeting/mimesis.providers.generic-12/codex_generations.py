

# Generated at 2022-06-21 16:10:05.613302
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.geo import Geo
    from mimesis.providers.network import Network

    class CustomProvider(BaseProvider):
        """Custom provider."""

        class Meta:
            """Class for metadata."""

            name = 'provider'

        def foo(self) -> str:
            return 'foo'

    g = Generic()
    g.add_provider(CustomProvider)
    g.add_providers(Geo, Network)
    assert hasattr(g, 'provider')
    assert hasattr(g, 'geo')
    assert hasattr(g, 'network')
    assert 'foo' == g.provider.foo()

# Generated at 2022-06-21 16:10:06.987835
# Unit test for constructor of class Generic
def test_Generic():
    assert Generic().person.full_name() == '卓颜沛'

# Generated at 2022-06-21 16:10:12.639427
# Unit test for constructor of class Generic
def test_Generic():
    a = Generic()
    assert (dir(a) == ['Meta', 'address', 'choice',
        'code', 'clothing', 'cryptographic', 'datetime',
        'development', 'file', 'food', 'hardware',
        'internet', 'numbers', 'path', 'payment',
        'person', 'science', 'structure', 'text',
        'transport', 'unit_system'])
    # assert (Generic().seed != Generic().seed)



# Generated at 2022-06-21 16:10:24.813091
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    assert isinstance(generic.person, Person) is True
    assert isinstance(generic.person, BaseProvider) is True
    assert generic.person.full_name() == 'Samuel Christensen'
    assert generic.person.full_name == generic.person.full_name()
    assert generic.person.full_name == generic.person.full_name
    assert isinstance(generic.address, Address) is True
    assert isinstance(generic.address, BaseProvider) is True
    assert generic.address.street_prefix() == 'Old'
    assert generic.address.street_prefix == generic.address.street_prefix()
    assert generic.address.street_prefix == generic.address.street_prefix
    assert isinstance(generic.datetime, Datetime) is True
    assert isinstance(generic.datetime, BaseProvider)

# Generated at 2022-06-21 16:10:35.367540
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    g = Generic('en')
    assert g.person.full_name() == 'Kevin A. Duran'
    assert g.person.name() == 'Kevin'
    assert g.person.last_name() == 'Duran'
    assert g.address.address() == '4930 56th Street'
    assert g.address.country() == 'United States'
    assert g.address.region() == 'District of Columbia'
    assert g.address.city() == 'Washington'
    assert g.address.postcode() == '1082'
    assert g.address.building_number() == '2595'
    assert g.address.street_suffix() == 'Avenue'
    assert g.address.street_prefix() == 'South'
    assert g.address.street_name() == 'Lafayette Street'
    assert g

# Generated at 2022-06-21 16:10:47.837199
# Unit test for constructor of class Generic
def test_Generic():
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.food import Food
    from mimesis.providers.file import File
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers
    from mimesis.providers.path import Path
    from mimesis.providers.payment import Payment

# Generated at 2022-06-21 16:10:56.915811
# Unit test for constructor of class Generic
def test_Generic():
    
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    import datetime
    # default
    gen = Generic()
    
    
    assert gen.seed == None
    assert gen.locale == 'en'
    assert isinstance(gen.person, Person)
    assert gen.person.gender == Gender.MALE
    assert gen.person.age() == 25
    assert gen.person.username() == 'deeptirai'
    assert isinstance(gen.address, Address)
    assert gen.address.postal_code() == '1748KW'
    assert isinstance(gen.datetime, Datetime)
    assert gen.datetime.timestamp() == 1588284319.906238
    assert gen.datetime.datetime() == datetime.datetime

# Generated at 2022-06-21 16:10:59.212163
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for constructor of class Generic"""

    gen = Generic()
    print(gen)


# Generated at 2022-06-21 16:11:09.961036
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class Provider1(BaseProvider):
        class Meta:
            name = 'provider1'
        def foo(self, *args, **kwargs):
            return 'x'

    class Provider2(BaseProvider):
        class Meta:
            name = 'provider2'
        def bar(self, *args, **kwargs):
            return 'y'

    g = Generic()
    g.add_providers(Provider1, Provider2)
    assert hasattr(g, 'provider1')
    assert hasattr(g, 'provider2')
    p1 = g.provider1
    p2 = g.provider2
    assert hasattr(p1, 'foo')
    assert hasattr(p2, 'bar')
    assert p1.foo() == 'x'

# Generated at 2022-06-21 16:11:14.381872
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert generic.__dir__() == ['address', 'business', 'clothing', 'code', 'choice', 'cryptographic', 'datetime', 'development', 'file', 'food', 'hardware', 'internet', 'numbers', 'path', 'payment', 'person', 'science', 'structure', 'text', 'transport', 'unit_system']

# Generated at 2022-06-21 16:11:39.202378
# Unit test for method __getattr__ of class Generic

# Generated at 2022-06-21 16:11:42.348931
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class TestProvider(BaseProvider):
        pass
    g = Generic()
    g.add_provider(TestProvider)
    assert hasattr(g, 'TestProvider')


# Generated at 2022-06-21 16:11:50.810274
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class MyProvider(BaseProvider):
        def __init__(self, seed: int = None, **kwargs) -> None:
            super().__init__(seed=seed, **kwargs)

        class Meta:
            name = 'myprovider'

        def foo(self) -> str:
            return 'foo'

        def bar(self) -> str:
            return 'bar'

    gen = Generic()
    gen.add_provider(MyProvider)
    assert gen.myprovider.foo() == 'foo'
    assert gen.myprovider.bar() == 'bar'
    assert gen.myprovider.foo() == 'foo'
    assert gen.myprovider.bar() == 'bar'

# Generated at 2022-06-21 16:11:56.916278
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    # Create a Custom Provider
    class CustomProvider(BaseProvider):
        def example_method(self):
            """Example method."""

        class Meta:
            """Class for metadata."""
            name = 'custom_provider'


    assert not hasattr(Generic, 'custom_provider')
    Generic.add_provider(CustomProvider)
    assert hasattr(Generic, 'custom_provider')
    assert hasattr(Generic.custom_provider, 'example_method')



# Generated at 2022-06-21 16:12:06.057432
# Unit test for constructor of class Generic
def test_Generic():
    gen = Generic()

    assert gen.person.full_name()
    assert gen.address.province()
    assert gen.food.vegetables()
    assert gen.science.element()
    assert gen.transport.car_full()
    assert gen.code.isbn()
    assert gen.file.file_name()
    assert gen.unit_system.unit()
    assert gen.numbers.binary()
    assert gen.development.language()
    assert gen.hardware.cpu_name()
    assert gen.clothing.socks()
    assert gen.internet.url()
    assert gen.path.posix()
    assert gen.payment.credit_card_number()
    assert gen.cryptographic.uuid4()
    assert gen.structure.list_()
    assert gen.choice.choice()

# Generated at 2022-06-21 16:12:07.152678
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    generic = Generic()
    person = generic.person
    assert person is not None


# Generated at 2022-06-21 16:12:08.755223
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    a = Generic()
    b = a.__dir__()
    assert isinstance(b, list)
    assert len(b) == 47

# Generated at 2022-06-21 16:12:13.725776
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Add a lot of custom providers to Generic() object."""
    from mimesis.providers.datetime import DateTime
    from mimesis.providers.geo import Geo

    g = Generic(locale='ru')
    if hasattr(g, 'datetime'):
        delattr(g, 'datetime')

    if hasattr(g, 'geo'):
        delattr(g, 'geo')

    g.add_providers(DateTime, Geo)
    assert g.datetime is not None
    assert g.geo is not None

# Generated at 2022-06-21 16:12:19.280283
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic()
    assert '__doc__' in dir(generic)

    # Result for providers with underscore
    assert 'person' in dir(generic)
    assert 'address' in dir(generic)
    assert 'datetime' in dir(generic)
    assert 'business' in dir(generic)
    assert 'clothing' in dir(generic)
    assert 'text' in dir(generic)
    assert 'food' in dir(generic)
    assert 'science' in dir(generic)
    assert 'transport' in dir(generic)
    assert 'code' in dir(generic)
    assert 'unit_system' in dir(generic)
    assert 'file' in dir(generic)
    assert 'numbers' in dir(generic)
    assert 'development' in dir(generic)
    assert 'hardware' in dir(generic)


# Generated at 2022-06-21 16:12:22.474459
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.person import Person as P
    g = Generic()
    g.add_provider(P)
    assert isinstance(g.person.provider, P)



# Generated at 2022-06-21 16:12:40.932808
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    expected = ('person', 'address', 'datetime', 'business', 'text',
                'food', 'science', 'transport', 'code', 'unit_system',
                'file', 'numbers', 'development', 'hardware', 'clothing',
                'internet', 'path', 'payment', 'cryptographic', 'structure',
                'choice')
    result = g.__dir__()
    assert isinstance(result, list)
    assert expected == tuple(result)

# Generated at 2022-06-21 16:12:46.942495
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.misc import (Misc, Misc as M)
    from mimesis.providers.person import Person as P
    class MyMisc(Misc):
        class Meta:
            name = 'other_name'

    generic = Generic('en')
    # class MyMisc(Misc)
    generic.add_provider(MyMisc)
    
    assert getattr(generic, 'other_name') is not None

    # class MyMisc(Misc)
    misc = MyMisc('en')
    generic.add_provider(misc)
    
    assert generic.other_name is not None

    # class MyMisc(Misc)
    generic.add_provider(MyMisc('en'))
    
    assert type(generic.other_name) == type(misc)


# Generated at 2022-06-21 16:12:48.608563
# Unit test for constructor of class Generic
def test_Generic():
    g = Generic()
    assert g.choice.element(['1', '2', '3']) == '1' or '2' or '3'

# Unit test of methods add_provider and add_providers of class Generic

# Generated at 2022-06-21 16:12:52.846421
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class NewDataProvider(BaseProvider):
        pass

    _generic = Generic()
    _generic.add_providers(NewDataProvider)
    result = hasattr(_generic, 'newdataprovider')
    assert result, 'Should be True'



# Generated at 2022-06-21 16:12:57.095815
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    from mimesis.providers.filesystem import Filesystem
    gen = Generic()
    assert gen.file == None
    assert gen.filesystem == None
    gen.add_providers(Filesystem)
    assert gen.file['Filesystem'] == None
    assert gen.filesystem != None

# Generated at 2022-06-21 16:13:03.516619
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    """Directory of class Generic should be list with all providers."""
    g = Generic()
    all_providers = [
        'person',
        'address',
        'datetime',
        'business',
        'text',
        'food',
        'science',
        'transport',
        'code',
        'unit_system',
        'file',
        'numbers',
        'development',
        'hardware',
        'clothing',
        'internet',
        'path',
        'payment',
        'cryptographic',
        'structure',
        'choice',
    ]
    assert isinstance(all_providers, list)
    assert not set(g.__dir__()) ^ set(all_providers)

# Generated at 2022-06-21 16:13:05.861558
# Unit test for constructor of class Generic
def test_Generic():
    p = Generic("lt_LT")
    assert p._person is not None
    assert p.locale == "lt_LT"



# Generated at 2022-06-21 16:13:07.011710
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    generic = Generic('en')
    assert len(generic.__dir__()) > 0


# Generated at 2022-06-21 16:13:07.955445
# Unit test for constructor of class Generic
def test_Generic():
    x = Generic()
    assert x is not None


# Generated at 2022-06-21 16:13:16.854177
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    class CustomProvider(BaseProvider):
        class Meta:
            name = 'custom_provider'

        def custom_provider_method(self):
            return True

    class AnotherCustomProvider(BaseProvider):
        class Meta:
            name = 'another_custom_provider'

        def another_custom_provider_method(self):
            return True

    provider = Generic()
    provider.add_providers(CustomProvider, AnotherCustomProvider)
    assert hasattr(provider, 'custom_provider')
    assert hasattr(provider, 'another_custom_provider')
    assert provider.custom_provider.custom_provider_method() is True
    assert provider.another_custom_provider.another_custom_provider_method() is True

# Generated at 2022-06-21 16:13:55.559788
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    gen = Generic("en")
    gen.add_providers(Internet, Payment)
    assert gen.internet is not None
    assert gen.payment is not None
    gen.add_provider(Internet)
    gen.add_provider(Payment)
    assert gen.internet is not None
    assert gen.payment is not None

# Generated at 2022-06-21 16:14:04.985619
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    seed = 1234
    locale = 'ru'
    g = Generic(seed=seed, locale=locale)
    class MyProvider(BaseProvider):
        @staticmethod
        def get_provider_name() -> str:
            return 'MyProvider'
        def __init__(self, *args, **kwargs) -> None:
            super().__init__(*args, **kwargs)
        def some_method(self) -> int:
            return 42
    g.add_provider(MyProvider)
    assert g.myprovider.seed == seed
    assert g.myprovider.locale == locale
    assert g.myprovider.some_method() == 42

if __name__ == '__main__':
    test_Generic_add_provider()
    print('Done')

# Generated at 2022-06-21 16:14:06.294562
# Unit test for method __dir__ of class Generic
def test_Generic___dir__():
    g = Generic()
    assert g.__dir__()

# Generated at 2022-06-21 16:14:13.245754
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    gen = Generic()
    assert hasattr(gen, 'file')
    assert hasattr(gen, 'person')
    assert hasattr(gen, 'address')
    assert hasattr(gen, 'datetime')
    assert hasattr(gen, 'business')
    assert hasattr(gen, 'text')
    assert hasattr(gen, 'food')
    assert hasattr(gen, 'science')
    assert hasattr(gen, 'transport')
    assert hasattr(gen, 'code')
    assert hasattr(gen, 'unit_system')
    assert hasattr(gen, 'numbers')
    assert hasattr(gen, 'development')
    assert hasattr(gen, 'hardware')
    assert hasattr(gen, 'clothing')
    assert hasattr(gen, 'internet')
    assert hasattr(gen, 'path')

# Generated at 2022-06-21 16:14:22.178659
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.computer import Computer

    class CustomProvider(BaseProvider):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        class Meta:
            name = 'custom'

        def method(self) -> str:
            return 'Method of CustomProvider'

    generic = Generic()
    generic.add_provider(CustomProvider)
    assert "custom" in Generic().__dir__() and hasattr(generic, 'custom') and \
        hasattr(generic.custom, 'method')
    generic.add_provider(Computer)
    assert "computer" in Generic().__dir__() and hasattr(generic, 'computer')

# Generated at 2022-06-21 16:14:31.401619
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
	test_generic_obj = Generic()
	test_generic_obj._person
	test_generic_obj._address
	test_generic_obj._datetime
	test_generic_obj._business
	test_generic_obj._text
	test_generic_obj._food
	test_generic_obj._science
	test_generic_obj.transport
	test_generic_obj.code
	test_generic_obj.unit_system
	test_generic_obj.file
	test_generic_obj.numbers
	test_generic_obj.development
	test_generic_obj.hardware
	test_generic_obj.clothing
	test_generic_obj.internet
	test_generic_obj.path
	test_generic_obj.payment
	test_generic_obj.cryptographic
	test_generic_obj.structure


# Generated at 2022-06-21 16:14:34.301280
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.custom_provider import CustomProvider
    custom_provider = CustomProvider()
    gen = Generic()
    gen.add_provider(custom_provider)
    assert isinstance(gen.custom_provider, CustomProvider)


# Generated at 2022-06-21 16:14:43.294052
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    getAll = Generic()
    assert getattr(getAll, 'person').__class__.__name__ == 'Person'
    assert getattr(getAll, 'address').__class__.__name__ == 'Address'
    assert getattr(getAll, 'datetime').__class__.__name__ == 'Datetime'
    assert getattr(getAll, 'business').__class__.__name__ == 'Business'
    assert getattr(getAll, 'text').__class__.__name__ == 'Text'
    assert getattr(getAll, 'food').__class__.__name__ == 'Food'
    assert getattr(getAll, 'science').__class__.__name__ == 'Science'
    assert getattr(getAll, 'transport').__class__.__name__ == 'Transport'
    assert getattr

# Generated at 2022-06-21 16:14:44.045872
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    pass


# Generated at 2022-06-21 16:14:45.037859
# Unit test for constructor of class Generic
def test_Generic():
    """Unit test for Generic class constructor."""
    assert Generic is not None