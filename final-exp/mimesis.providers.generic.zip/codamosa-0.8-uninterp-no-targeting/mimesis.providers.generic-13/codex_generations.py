

# Generated at 2022-06-21 16:10:09.039753
# Unit test for method __getattr__ of class Generic
def test_Generic___getattr__():
    print("\n[#] Test method __getattr__ of class Generic")
    generic = Generic(seed=666)
    x = generic.datetime.datetime(years=2, months=2, days=2)
    # datetime.datetime(2020, 2, 2, 2, 2, 2)

    print("\n[+] Method datetime.datetime:", x)
    print("[+] Method person.name:", generic.person.name())
    print("[+] Method address.building_number:", generic.address.building_number())
    print("[+] Method business.company:", generic.business.company_name())
    print("[+] Method text.text:", generic.text.text())
    print("[+] Method food.food_name:", generic.food.food_name())
   

# Generated at 2022-06-21 16:10:15.686645
# Unit test for constructor of class Generic
def test_Generic():
    generic = Generic(seed=12345)
    assert (generic._person is not None)
    assert (generic._address is not None)
    assert (generic._datetime is not None)
    assert (generic._business is not None)
    assert (generic._text is not None)
    assert (generic._food is not None)
    assert (generic._science is not None)

    assert (generic.transport is not None)
    assert (generic.code is not None)
    assert (generic.unit_system is not None)
    assert (generic.file is not None)
    assert (generic.numbers is not None)
    assert (generic.development is not None)
    assert (generic.hardware is not None)
    assert (generic.clothing is not None)
    assert (generic.internet is not None)

# Generated at 2022-06-21 16:10:16.352978
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    pass

# Generated at 2022-06-21 16:10:18.351697
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    assert hasattr(Generic(), 'test')

test_Generic_add_providers()


# Generated at 2022-06-21 16:10:19.031557
# Unit test for constructor of class Generic
def test_Generic():
    pass

# Generated at 2022-06-21 16:10:24.983714
# Unit test for constructor of class Generic
def test_Generic():
    # Test that all category providers are available
    # Test that all function providers are available
    # Test that all attributes are available
    generic = Generic()
    generic.add_provider(Business)
    print(generic.business)
    generic.add_providers(Datetime, Address)
    print(generic.datetime)
    print(generic.address)
    print(generic.datetime.date())


# test_Generic()


# Generated at 2022-06-21 16:10:35.484625
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    import json
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.providers.address import Address
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.business import Business
    from mimesis.providers.clothing import Clothing
    from mimesis.providers.code import Code
    from mimesis.providers.cryptographic import Cryptographic
    from mimesis.providers.date import Datetime
    from mimesis.providers.development import Development
    from mimesis.providers.file import File
    from mimesis.providers.food import Food
    from mimesis.providers.hardware import Hardware
    from mimesis.providers.internet import Internet
    from mimesis.providers.numbers import Numbers

# Generated at 2022-06-21 16:10:41.464174
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    from mimesis.providers.text import Text

    class MyText(Text):
        class Meta:
            name = 'my_text'

        def func(self):
            return 'Hello'

    g = Generic()
    g.add_provider(MyText)
    assert g.my_text.func() == 'Hello'

# Generated at 2022-06-21 16:10:49.896715
# Unit test for method add_provider of class Generic
def test_Generic_add_provider():
    class Provider(BaseProvider):
            class Meta:
                name = 'provider'

            def generator(self):
                return 'The provider'

    generic = Generic()
    # Test for add provider in generic object
    generic.add_provider(Provider)
    assert generic.provider.generator() == 'The provider'
    # Test for Error if provider is not class
    try:
        generic.add_provider(Provider.generator())
    except TypeError as e:
        assert 'The provider must be a class' == str(e)



# Generated at 2022-06-21 16:10:55.682993
# Unit test for method add_providers of class Generic
def test_Generic_add_providers():
    """Test add_providers of Generic."""
    g = Generic(randomizer=None)
    providers = [
        Person,
    ]
    g.add_providers(*providers)
    for provider in providers:
        meta = getattr(provider, 'Meta')
        name = getattr(meta, 'name')
        assert getattr(g, name)
    assert not getattr(g, 'test')