

# Generated at 2022-06-12 13:09:56.369815
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    from unittest import mock

    # success case
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 'result')
    assert future.result() == 'result'

    # cancelled case
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'result')
    assert future.cancelled()

# Generated at 2022-06-12 13:10:07.172307
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import inspect
    import time

    from tornado.ioloop import IOLoop, TimeoutError

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def timeout(self):
            raise TimeoutError()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2

# Generated at 2022-06-12 13:10:11.207827
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()
    future = Future()
    future_set_result_unless_cancelled(future, None)
    assert future.done()

# Generated at 2022-06-12 13:10:17.677667
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f_dummy = Future()
    f_asyncio = asyncio.Future()
    f_concurrent = futures.Future()

    def copy(future):
        # type: (Future) -> None
        assert future is f_asyncio
        f_concurrent.set_result(f_asyncio.result())

    f_asyncio.add_done_callback(copy)
    chain_future(f_dummy, f_asyncio)
    chain_future(f_dummy, f_concurrent)
    f_dummy.set_result(None)
    assert f_dummy.result() is None
    assert f_asyncio.result() is None
    assert f_concurrent.result() is None

# Generated at 2022-06-12 13:10:21.511719
# Unit test for function chain_future
def test_chain_future():
    f = futures.Future()
    g = futures.Future()
    chain_future(f, g)
    f.set_result(3)
    assert g.result() == 3

    g = Future()
    chain_future(f, g)
    assert g.result() == 3

# Generated at 2022-06-12 13:10:25.188414
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None



# Generated at 2022-06-12 13:10:34.929362
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()

    def handler(future):
        future_set_result_unless_cancelled(future3, future.result())

    for i in range(1, 4):
        setattr(sys.modules[__name__], "future" + str(i), locals()["future" + str(i)])

    chain_future(future1, future2)
    future_add_done_callback(future2, functools.partial(handler, future2))

    future1.set_result(10)
    assert future3.result() == 10

    future1 = Future()
    future2 = Future()
    future3 = Future()

    exc = RuntimeError()
    future_set_exception_unless_cancelled(future1, exc)
    chain

# Generated at 2022-06-12 13:10:38.334248
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def callback(future):
        assert not future.cancelled()

    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 1)
    future_add_done_callback(future, callback)
    assert future.done()
    assert future.result() == 1


# Generated at 2022-06-12 13:10:42.785515
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fn = lambda: 2
    future = dummy_executor.submit(fn)
    assert future.result() == 2

    fn = lambda: 1 / 0
    future = dummy_executor.submit(fn)
    try:
        future.result()
    except ZeroDivisionError:
        pass
    else:
        assert False



# Generated at 2022-06-12 13:10:50.995876
# Unit test for function chain_future
def test_chain_future():
    import inspect
    import tornado.testing
    import types

    def f(arg, sleep):
        tornado.ioloop.IOLoop.current().add_callback(lambda: setattr(f, "called", True))
        tornado.ioloop.IOLoop.current().add_timeout(
            tornado.ioloop.IOLoop.current().time() + 0.01, lambda: setattr(f, "timed_out", True)
        )
        return arg

    def target():
        tornado.ioloop.IOLoop.current().add_callback(
            lambda: tornado.testing.assertTrue(f.called)
        )

# Generated at 2022-06-12 13:10:57.678330
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()


# Generated at 2022-06-12 13:11:03.083380
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_result(1)
    try:
        raise ValueError("testing future_set_exception_unless_cancelled")
    except Exception as e:
        future_set_exception_unless_cancelled(f, e)
        assert f.exception() is e
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("test"))
    assert f.exception() is None

# Generated at 2022-06-12 13:11:11.106043
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # The test is commented out because it does not work correctly with Python 3.7
    # due to changes in the way the unittest framework captures exceptions.
    # For details see:
    #   https://bugs.python.org/issue29448
    #   https://bugs.python.org/issue31716
    # See also test_future.py in the same directory.
    return
    import unittest
    import mock

    class SomeError(Exception):
        pass

    def async_func():
        # type: () -> None
        raise SomeError()

    @gen.coroutine
    def sync_func():
        # type: () -> None
        yield gen.moment
        raise SomeError()


# Generated at 2022-06-12 13:11:18.936347
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor
            self._thread_pool = dummy_executor

        @run_on_executor
        def bar(self, x):
            return x + 1

        @run_on_executor(executor="_thread_pool")
        def baz(self, x):
            return x - 1

    loop = IOLoop()
    foo = Foo()

    future = foo.bar(21)
    assert isinstance(future, Future)
    future.add_done_callback(loop.add_callback)
    loop.add_future(future, loop.stop)
    loop.start()
    assert future.result() == 22


# Generated at 2022-06-12 13:11:25.873958
# Unit test for function chain_future
def test_chain_future():
    import threading

    io_loop = IOLoop()
    io_loop.make_current()
    io_loop_thread = threading.Thread(target=io_loop.start)
    io_loop_thread.start()

    t1 = threading.Thread(target=_test_chain_future_thread, args=(io_loop,))
    t1.start()
    t1.join()
    io_loop.stop()
    io_loop_thread.join()



# Generated at 2022-06-12 13:11:28.051717
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    def func():
        return 2
    # print(getattr(self, "executor"))

    assert dummy_executor.submit(func).result() == 2


# Generated at 2022-06-12 13:11:30.080287
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 100)
    assert future.cancelled()

# Generated at 2022-06-12 13:11:40.393531
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio as aio
    import concurrent.futures
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    import tornado.testing
    import unittest

    class RunOnExecutorTest(tornado.testing.AsyncTestCase, unittest.TestCase):
        def setUp(self) -> None:
            super().setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(2)

        def tearDown(self) -> None:
            self.executor.shutdown()

        @run_on_executor
        def foo(self, a: int, b: int = 1) -> int:
            return a + b


# Generated at 2022-06-12 13:11:44.788943
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    # f1 -> f2
    f1.set_result(42)
    assert f2.result() == 42
    # f2 -> f1
    f2.set_result(17)
    assert f1.result() == 42



# Generated at 2022-06-12 13:11:50.194577
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    with Future() as future:
        future_set_exception_unless_cancelled(future, ValueError())
        assert future.exception() is not None
        with Future() as future:
            future.cancel()
            future_set_exception_unless_cancelled(future, ValueError())
            assert future.exception() is None

# Generated at 2022-06-12 13:12:04.004116
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[str]
    f2 = Future()  # type: Future[str]
    chain_future(f1, f2)
    f1.set_result('foo')
    assert f2.result() == 'foo'

    f1 = Future()  # type: Future[str]
    f2 = Future()  # type: Future[str]
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result('foo')
    assert f2.cancelled()

    f1 = Future()  # type: Future[str]
    f2 = Future()  # type: Future[str]
    chain_future(f1, f2)

# Generated at 2022-06-12 13:12:12.573491
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado import gen

    def fail(future):
        future.set_exception(Exception("error"))

    @gen.coroutine
    def f():
        raise gen.Return(42)

    @gen.coroutine
    def g():
        raise gen.Return(24)

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop.current()
            f1 = Future()
            f2 = Future()
            f3 = Future()
            chain_future(f1, f3)
            chain_future(f2, f3)
            future_add_done_callback(f2, fail)
            loop.add_callback(f1.set_result, 42)

# Generated at 2022-06-12 13:12:14.632676
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = futures.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    f = futures.Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception(), ValueError

# Generated at 2022-06-12 13:12:17.666189
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, "test")
    assert future.exception() == "test"
    future_set_exception_unless_cancelled(future, "test2")
    assert future.exception() == "test"

# Generated at 2022-06-12 13:12:26.431301
# Unit test for function chain_future
def test_chain_future():
    from tornado.gen import TimeoutError

    # Testing Future
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f1.result() == 42
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    f2.cancel()
    assert f2.cancelled()
    assert f1.done()
    assert f1.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    f2.set_exception(ValueError())

# Generated at 2022-06-12 13:12:34.837923
# Unit test for function chain_future
def test_chain_future():
    def handle_future(future, callback):
        callback(future.result())

    def test_future_chain(a, b):
        a.add_done_callback(functools.partial(handle_future, callback=b.set_result))

    # Test with tornado futures:
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(123)
    assert g.result() == 123
    f = Future()
    g = Future()
    test_future_chain(f, g)
    f.set_result(123)
    assert g.result() == 123
    # Test with concurrent.futures.Future
    f = futures.Future()
    g = futures.Future()
    chain_future(f, g)
    f.set_result(456)

# Generated at 2022-06-12 13:12:43.156563
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.get_event_loop()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.result()

    with pytest.raises(asyncio.InvalidStateError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)

    loop.run_until_complete(f2)
    f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())

    with pytest.raises(RuntimeError):
        loop.run_until_complete(f2)


# Generated at 2022-06-12 13:12:47.626723
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    io_loop = IOLoop()
    io_loop.make_current()
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    io_loop.add_future(b, lambda f: io_loop.stop())
    io_loop.start()
    assert b.result() == 42



# Generated at 2022-06-12 13:12:53.706981
# Unit test for function run_on_executor
def test_run_on_executor():
    future = Future()
    exec_called = False

    @run_on_executor
    def acc(*args, **kwargs):
        exec_called = True
        return sum(args) + sum(kwargs.values())

    @gen.coroutine
    def test():
        ioloop.IOLoop.current().run_sync(lambda: future.set_result(5))
        result = yield acc(3, 4, a=5, b=6)
        self.assertEqual(result, 18)
        self.assertTrue(exec_called)

# Generated at 2022-06-12 13:13:02.755849
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class MyError(Exception):
        pass

    @gen_test
    def test_exception_in_concurrent_future(self: AsyncTestCase) -> None:
        def raise_exc():
            raise MyError()

        fut1 = dummy_executor.submit(raise_exc)
        fut2 = Future()

        chain_future(fut1, fut2)
        self.assertIsInstance(fut2.exception(), MyError)

    @gen_test
    def test_exception_in_chain_future(self: AsyncTestCase) -> None:
        def raise_exc():
            raise MyError()

        fut1 = Future()
        fut2 = Future()

        chain_future(fut1, fut2)
        fut1.set

# Generated at 2022-06-12 13:13:16.285301
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, "value")
    assert f.result() == "value"
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "value")
    assert f.cancelled() is True
    assert f.done() is True

# Generated at 2022-06-12 13:13:19.263138
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert not future.exception()

# Generated at 2022-06-12 13:13:26.174998
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future as CFuture
    from tornado.testing import gen_test

    class Future(object):
        def __init__(self):
            self.done_callbacks = []  # type: list

        def add_done_callback(self, callback):
            # type: (Callable) -> None
            self.done_callbacks.append(callback)

        def set_result(self, result):
            # type: (Any) -> None
            self.result = result
            while self.done_callbacks:
                self.done_callbacks.pop()(self)

        def result(self):
            # type: () -> Any
            return self.result


# Generated at 2022-06-12 13:13:36.390912
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import concurrent.futures

    class RunOnExecutorTest(tornado.testing.AsyncTestCase):
        def setUp(self) -> None:
            super(RunOnExecutorTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self) -> None:
            self.executor.shutdown()
            super(RunOnExecutorTest, self).tearDown()

        def test_future_return_value(self) -> None:
            # A Future that returns a Future
            @run_on_executor
            def f(self: Any, a: int, b: int) -> "Future":
                return tornado.concurrent.Future()


# Generated at 2022-06-12 13:13:40.941302
# Unit test for function run_on_executor
def test_run_on_executor():
    class A:
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            yield gen.sleep(0.01)
            return 42

    a = A()
    f = a.foo()
    assert isinstance(f, Future)
    assert f.done()
    assert f.result() == 42

# Generated at 2022-06-12 13:13:49.811428
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import unittest

    def add(x, y):
        return x + y

    def add_unavailable(x, y):
        raise RuntimeError("not available here")

    class TestFuture(unittest.TestCase):
        def test_run_on_executor(self):
            exec_result = [None]

            class Foo(object):
                def __init__(self, loop):
                    self.loop = loop
                    self.executor = futures.ThreadPoolExecutor(1)

                @run_on_executor
                def add(self, x, y):
                    return add(x, y)

                @run_on_executor(executor="executor")
                def add_with_executor(self, x, y):
                    return add(x, y)


# Generated at 2022-06-12 13:13:53.353088
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result('result')
    assert f2.done()
    assert f2.result() == 'result'



# Generated at 2022-06-12 13:13:57.171256
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fn = future_set_result_unless_cancelled
    f = asyncio.Future()
    fn(f, None)
    assert f.result() is None
    assert not f.cancelled()
    f = asyncio.Future()
    f.cancel()
    fn(f, None)
    assert f.cancelled()



# Generated at 2022-06-12 13:14:07.127622
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1, f2 = Future(), Future()
            result = object()
            chain_future(f1, f2)
            f1.set_result(result)
            self.assertEqual(f2.result(), result)

            # Cancelled f2 doesn't affect f1
            f1, f2 = Future(), Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(result)

            # Exceptions get passed through
            f1, f2 = Future(), Future()
            exception = ValueError()
            chain_future(f1, f2)
            f1.set_exception(exception)

# Generated at 2022-06-12 13:14:11.926120
# Unit test for function chain_future
def test_chain_future():  # pragma: nocover
    from tornado.ioloop import IOLoop

    t = []

    @gen.coroutine
    def f():
        yield gen.moment

    f1 = f()
    f2 = Future()

    def cb(f):
        t.append(f.result())

    chain_future(f1, f2)
    f2.add_done_callback(cb)
    IOLoop.instance().add_future(f1, lambda _: None)
    IOLoop.instance().start()
    assert t == [None]

    t = []

    @gen.coroutine
    def f():
        raise Exception()

    f1 = f()
    f2 = Future()
    chain_future(f1, f2)
    f2.add_done_callback(cb)


# Generated at 2022-06-12 13:14:37.813605
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test

    # Avoid warnings about 'coroutine' being deprecated in python 3.8
    # (copied from gen_test docs)
    import typing
    import unittest

    if sys.version_info >= (3, 8):
        def coroutine(func: typing.Callable[..., typing.Any]) -> typing.Callable:
            return typing.cast("typing.Callable", func)
    else:
        coroutine = gen_test
    asyncio.set_event_loop_policy(asyncio.DefaultEventLoopPolicy())
    io_loop_policy = asyncio.get_event_loop_policy()

# Generated at 2022-06-12 13:14:43.446711
# Unit test for function chain_future
def test_chain_future():
    import unittest.mock as mock
    from tornado.log import gen_log
    from concurrent.futures import Future as ConcFuture

    loop = mock.Mock()

    async_future = Future()
    conc_future = ConcFuture()

    # Test synchronous resolution of the source future
    chain_future(async_future, conc_future)

    # assert_false is missing in unittest on python 3.2.
    assert not conc_future.done()

    async_future.set_result(42)

    assert conc_future.done()
    assert conc_future.result() == 42

    # Test asynchronous resolution of the source future
    async_future = Future()
    conc_future = ConcFuture()
    chain_future(async_future, conc_future)

    assert not conc_future.done()

   

# Generated at 2022-06-12 13:14:52.329656
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import BaseAsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def func(self) -> int:
            return 42

        @run_on_executor(executor="executor2")
        def func2(self) -> int:
            return 42

    with AsyncIOMainLoop():
        io_loop = BaseAsyncIOLoop()
        io_loop.make_current()

        foo = Foo()
        foo.executor2 = foo.executor
        # Make sure the decorators applied properly
        assert foo.func().result() == 42
       

# Generated at 2022-06-12 13:14:58.718124
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import time
    import unittest
    import weakref

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
                def reference_implementation(a, b):
                    # type: (Future, Future) -> None
                    def copy(future):
                        # type: (Future) -> None
                        if b.done():
                            return
                        if a.exception() is not None:
                            b.set_exception(a.exception())
                        else:
                            b.set_result(a.result())

                    a.add_done_callback(copy)

                for impl_a in [Future, futures.Future]:
                    for impl_b in [Future, futures.Future]:
                        a = impl_a()

# Generated at 2022-06-12 13:15:07.499960
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test

    class ExampleClass(object):
        def __init__(self, result, executor):
            self.executor = executor
            self.result = result
            self.thread_id = None

        @run_on_executor
        def index(self):
            self.thread_id = threading.get_ident()
            return self.result

    @gen_test
    def test_run_on_executor():
        executor = futures.ThreadPoolExecutor(1)
        try:
            o = ExampleClass(42, executor)
            result = yield o.index()
            self.assertEqual(result, 42)
            self.assertNotEqual(o.thread_id, threading.get_ident())
        finally:
            executor.shut

# Generated at 2022-06-12 13:15:16.800489
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    from tornado.ioloop import IOLoop, TimeoutError

    def f():
        return 1

    def f2(arg):
        print(arg)
        return arg + 1

    def except_callback(f):
        # f is an exception object
        print('error on future', type(f), str(f))

    ioloop = IOLoop.instance()

    f1 = ioloop.run_in_executor(None, f)
    f2 = Future()

    chain_future(f1, f2)
    f2.add_done_callback(f2)


# Generated at 2022-06-12 13:15:24.683483
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    async def main():
        with dummy_executor:
            future = dummy_executor.submit(lambda x, y: x + y, 1, 2)
            assert len(dummy_executor._threads) == 0
            assert len(dummy_executor._work_queue) == 0
            assert future.done()
            assert future.result() == 3
        assert loop._stopped
        assert len(dummy_executor._threads) == 0
        assert len(dummy_executor._work_queue) == 0
        assert future.done()
        assert future.result() == 3

    future = Future()
    future_add_done_callback(future, lambda future: loop.stop())
    loop = IOLoop.current()
   

# Generated at 2022-06-12 13:15:31.181606
# Unit test for function chain_future
def test_chain_future():
    import tornado.ioloop
    import tornado.testing
    from tornado import gen

    @gen.coroutine
    def f():
        raise gen.Return(42)

    @gen.coroutine
    def g():
        yield gen.moment
        f2 = Future()
        chain_future(f(), f2)
        raise gen.Return(f2)

    @gen.coroutine
    def main():
        f1 = Future()
        ioloop = tornado.ioloop.IOLoop.current()
        ioloop.add_future(f(), lambda f: f1.set_result(f.result()))
        f3 = yield g()
        self.assertEqual(f1.result(), 42)
        self.assertEqual(f3.result(), 42)

    tornado.testing.gen_test(main)

# Generated at 2022-06-12 13:15:38.377929
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()
    f2 = None
    f1 = Future()
    f1.set_result(42)

    @gen.coroutine
    def f2_setter():
        nonlocal f2
        f2 = Future()
        f2.set_result(24)

    def cb(future):
        self.assertEqual(future.result(), 42)
        io_loop.add_future(f2_setter(), lambda f: chain_future(f2, future))

    f3 = Future()
    chain_future(f1, f3)
    future_add_done_callback(f3, cb)
    io_loop.run_sync(lambda: f3)
    self.assertEqual(f3.result(), 24)



# Generated at 2022-06-12 13:15:43.990326
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTestMixin(object):
        # mixin doesn't work with typing.overload, so we can't use it there.
        def test_chain(self):

            @self.gen_test
            def test_chain():
                future1 = self.get_future()
                future2 = self.get_future()
                chain_future(future1, future2)
                self.io_loop.add_timeout(time.time() + 0.01, lambda: future1.set_result(42))
                self.assertEqual((yield future2), 42)

            test_chain()

        def test_chain_when_done(self):

            @self.gen_test
            def test_chain_when_done():
                future1 = self.get_future()
                future

# Generated at 2022-06-12 13:16:23.284322
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    def raise_error(x):
        raise Exception(x)

    class TestFutures(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f = Future()
            f2 = Future()
            f.set_result(42)
            chain_future(f, f2)
            self.assertEqual(f.result(), 42)
            self.assertEqual((yield f2), 42)

            f = Future()
            f2 = Future()
            f.set_exception(RuntimeError())
            chain_future(f, f2)
            self.assertRaises(
                RuntimeError, lambda: f.result(timeout=0.1)
            )

# Generated at 2022-06-12 13:16:25.807551
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import pytest
    exec = DummyExecutor()
    future = exec.submit(lambda x, y: x + y, 1, 2)
    assert future.result() == 3


if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-12 13:16:33.662221
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    io_loop.add_callback(future1.set_result, "result")
    io_loop.add_callback(future1.set_exception, RuntimeError("error"))
    assert future2.exception() is not None
    assert future2.result() is None
    assert not future2.cancelled()
    assert future2.exception().__class__ is RuntimeError

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    io_loop.add_callback(future2.cancel)
    io_loop.add_callback(future1.set_result, "result")
    assert future2.cancelled

# Generated at 2022-06-12 13:16:36.021161
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor()
        def bar(self):
            yield gen.moment

    f = Foo()
    f.bar().result()

# Generated at 2022-06-12 13:16:43.383279
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import warnings

    future1 = Future()
    future2 = Future()
    future3 = Future()
    future4 = Future()

    def cb(f):
        future3.set_result(f.result() + 1)

    chain_future(future1, future2)
    future_add_done_callback(future2, cb)
    chain_future(future2, future4)
    chain_future(future3, future4)

    # Test that chaining fires callbacks
    future1.set_result(42)
    self.assertEqual(future1.result(), 42)
    self.assertEqual(future2.result(), 42)
    self.assertEqual(future3.result(), 43)
    self.assertEqual(future4.result(), 43)
    # Test that

# Generated at 2022-06-12 13:16:50.479564
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Unit tests for the "chain_future" function. The function is
    # tested in a few ways:
    #
    # - An asyncio.Future is chained to a concurrent.futures.Future,
    #   and vice versa
    # - A Future and a Future are chained together to each other.
    # - A Future and a Future are chained together, with the
    #   intermediate Future set_result() called before the first
    #   done callback is attached.
    #
    # In all cases, the done callback attached to the chained
    # Future should be invoked when the the first Future is marked
    # done. We test this by using a Future marked with a sentinel
    # result and asserting that the sentinel is present in the
    # chained Future.

    from tornado.ioloop import IOLoop

   

# Generated at 2022-06-12 13:16:54.734843
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    exc = Exception()
    future = Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.cancelled()

# Generated at 2022-06-12 13:17:03.947280
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from concurrent.futures import ThreadPoolExecutor

    AsyncIOMainLoop().install()

    class A:
        results = []  # type: typing.List[int]
        executor = ThreadPoolExecutor(max_workers=10)

        @run_on_executor
        def f(self, x: int) -> int:
            return x
        @run_on_executor
        def g(self, x):
            raise Exception(x)

        @run_on_executor
        def h(self, x, callback=None):
            self.results.append(x)
            if callback is not None:
                callback()


# Generated at 2022-06-12 13:17:07.909465
# Unit test for function chain_future
def test_chain_future():
    def f1(arg, callback):
        callback(arg)
    f2 = Future()
    chain_future(f1(1, f2.set_result), f2)
    assert f2.result() == 1

    f2 = Future()
    chain_future(f1(exc, f2.set_exception), f2)
    with pytest.raises(CustomException):
        f2.result()

# Generated at 2022-06-12 13:17:12.229713
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, True)
    assert future.cancelled() == False
    assert future.done() == True
    assert future.result() == True

    future = Future()
    future_set_result_unless_cancelled(future, True)
    assert future.cancelled() == False
    assert future.done() == True
    assert future.result() == True

# Generated at 2022-06-12 13:18:22.450724
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test_exc"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test_exc"))
    assert future.exception() is None

# Generated at 2022-06-12 13:18:28.781773
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """Test the chain_future method. The implementation of Future
    is fairly hard to test directly, so this test uses synchronous
    Condition objects to test its behavior.
    """
    from tornado import gen

    # Advanced warning: this function is a maze.

    finished = False

    class DoneCondition:
        def __init__(self) -> None:
            # type: () -> None
            self.done = False

        def done_task(self, future):
            # type: (Future) -> None
            self.done = True

    class SetCondition(DoneCondition):
        def __init__(self, value=None) -> None:
            # type: (Optional[Any]) -> None
            super().__init__()
            self.value = value


# Generated at 2022-06-12 13:18:36.960395
# Unit test for function chain_future
def test_chain_future():
    import time
    from tornado.testing import gen_test, AsyncTestCase

    class X(AsyncTestCase):
        def test(self):
            ioloop = self.io_loop
            f1 = Future()
            f2 = Future()

            def start():
                time.sleep(0.01)
                f1.set_result(None)
                f2.set_result(None)

            ioloop.add_callback(start)
            chain_future(f1, f2)
            ioloop.add_future(f2, lambda f: ioloop.stop())
            ioloop.start()

    test_chain_future.__test__ = False

# Generated at 2022-06-12 13:18:45.146835
# Unit test for function chain_future
def test_chain_future():
    @typing.no_type_check
    def copy(future):
        assert future is a
        if not b.done():
            if future.exc_info() is not None:
                b.set_exc_info(future.exc_info())
            elif future.exception() is not None:
                b.set_exception(future.exception())
            else:
                b.set_result(future.result())

    def run_and_raise(exc):
        raise exc

    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(None)
    assert b.done()
    assert b.result() is None
    for exc in (ZeroDivisionError, KeyError, RuntimeError):
        a = Future()
       

# Generated at 2022-06-12 13:18:53.882324
# Unit test for function run_on_executor
def test_run_on_executor():
    def function_that_takes_time():
        pass

    # Need to define class, to use as self, since run_on_executor
    # uses unbound methods.
    class MyClass:
        @run_on_executor
        def func(self):
            pass

    instance = MyClass()

    # Before setting executor
    # Note that no exceptions are raised, since they are all
    # caught and stored in the internal Future object
    assert instance.func() is not None
    assert instance.func().done() is False

    # this results in an exception
    # instance.func().result()

    instance.executor = dummy_executor
    assert instance.func().result() is None
    assert instance.func().done() is True

    assert instance.func() is not None
    assert instance.func().done() is False


# Generated at 2022-06-12 13:18:59.418511
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()  # type: Future[Any]
    b = Future()  # type: Future[Any]
    chain_future(a, b)
    a.set_result(42)
    try:
        a.set_result(17)
    except Exception:
        pass
    else:
        assert False, "second set_result should fail"
    assert b.result() == 42
    b.set_result(44)
    assert b.result() == 42

    a = asyncio.Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    try:
        a.set_result(17)
    except Exception:
        pass
    else:
        assert False, "second set_result should fail"

# Generated at 2022-06-12 13:19:01.854193
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    try:
        future_set_exception_unless_cancelled(f, RuntimeError())
    except RuntimeError:
        pass
    else:
        assert False, "did not raise"

# Generated at 2022-06-12 13:19:10.643199
# Unit test for function run_on_executor
def test_run_on_executor():
    # Test various combinations of arguments to run_on_executor.
    import unittest

    from tornado import gen
    from concurrent.futures import ThreadPoolExecutor

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown(wait=True)

        @gen.coroutine
        def _test_run(self, function_name, args, kwargs):
            yield getattr(self, function_name)(*args, **kwargs)

        @run_on_executor
        def _zero_args(self):
            pass


# Generated at 2022-06-12 13:19:12.808928
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()

    chain_future(future1, future2)
    future1.set_result('foo')
    assert future2.result() == 'foo'



# Generated at 2022-06-12 13:19:21.664194
# Unit test for function chain_future
def test_chain_future():
    ioloop = IOLoop()
    f1, f2 = Future(), Future()

    f1.set_result(1)
    chain_future(f1, f2)
    assert f2.result() == 1

    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    assert f2.done() is False
    f1.set_result(2)
    assert f2.result() == 2

    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("f1 failed"))
    try:
        f2.result()
        assert False, 'F2 should have raised exception'
    except Exception as e:
        assert str(e) == "f1 failed"