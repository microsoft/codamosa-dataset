

# Generated at 2022-06-12 13:09:56.679938
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    @to_tornado_future
    @to_asyncio_future
    def inner_to_asyncio_and_tornado():
        # type: () -> str
        return "success"

    def inner_both_tornado():
        # type: () -> str
        return "success"

    def inner_both_asyncio():
        # type: () -> str
        return "success"

    tornado_source = inner_both_tornado()
    asyncio_source = inner_both_asyncio()
    mixed_source = inner_to_asyncio_and_tornado()
    tornado_target = Future()  # type:

# Generated at 2022-06-12 13:10:07.368989
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # Tests that if a chained future is cancelled,
            # its source is also cancelled.
            ioloop = tornado.ioloop.IOLoop.current()
            source = Future()
            chained = Future()
            chain_future(source, chained)
            self.assertFalse(source.cancelled())
            self.assertFalse(chained.cancelled())
            # Cancel the chained future
            chained.cancel()
            self.io_loop.add_future(source, self.stop)
            self.wait()
            # If the source is not chained, it remains pending.
            # If the source is cancelled, it will raise
            # asyncio.CancelledError when run

# Generated at 2022-06-12 13:10:12.995900
# Unit test for function chain_future
def test_chain_future():
    future2 = Future()
    def assert_future_result(future1):
        assert future1.result() == 42
        assert not future2.done()
        future2.set_result(None)
    future1 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future_add_done_callback(future1, assert_future_result)
    future1.set_result(42)
    return future2

# Generated at 2022-06-12 13:10:20.928881
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert exc == future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert not future.cancelled()
    assert exc == future.exception()



# Generated at 2022-06-12 13:10:25.376910
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # pragma: no cover
    future = Future()
    future.set_exception(Exception("Error"))
    app_log.error("Exception after Future was cancelled", exc_info=future.exception())

    future = Future()
    future_set_exc_info(future, sys.exc_info())
    future_set_exception_unless_cancelled(future, Exception("error"))
    app_log.error("Exception after Future was cancelled", exc_info=future.exception())

# Generated at 2022-06-12 13:10:35.126713
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import unittest
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import CancelledError
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    with AsyncIOMainLoop():
        class CommonTests:
            @gen_test
            async def test_run_on_executor_success(self):
                pool = ThreadPoolExecutor(4)
                # This class makes sure that test_run_on_executor_success
                # is decorated with @run_on_executor.
                class ExampleClassWithRunDecorator(object):
                    executor = pool

                    @run_on_executor
                    def example_method(self):
                        return 42

                example_class = Example

# Generated at 2022-06-12 13:10:44.105808
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import io
    import threading
    import unittest
    import unittest.mock
    import weakref

    from tornado.platform.asyncio import (
        AnyThreadEventLoopPolicy,
        AsyncIOMainLoop,
        to_asyncio_future,
    )
    from tornado.testing import AsyncTestCase, bind_unused_port

    class MyClass(object):
        def __init__(self):
            self.executor = dummy_executor
            self._thread_pool = dummy_executor

        @run_on_executor
        def foo(self):
            return 42

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            return 24


# Generated at 2022-06-12 13:10:52.047805
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.httpclient import AsyncHTTPClient

    http_client = AsyncHTTPClient()

    def handle_response(response):
        if response.error:
            print("Error:", response.error)
        else:
            print(response.body)
        io_loop.stop()

    def get_google():
        return http_client.fetch("http://www.google.com")

    def get_stack_overflow():
        return http_client.fetch("http://stackoverflow.com")

    io_loop = IOLoop.current()
    f = Future()
    chain_future(get_google(), f)
    f.add_done_callback(lambda f: chain_future(get_stack_overflow(), f))

# Generated at 2022-06-12 13:11:00.758266
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

# Generated at 2022-06-12 13:11:08.218287
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    def callback(future):
        # type: (Future[_T]) -> None
        try:
            result = future.result()
        except Exception as e:
            future2.set_exception(e)
        else:
            future2.set_result(result)

    loop = asyncio.get_event_loop()
    future1 = asyncio.Future()  # type: Future[_T]
    future2 = asyncio.Future()  # type: Future[_T]

    chain_future(future1, future2)

    future1 = future2 = None  # type: ignore
    gc.collect()
    loop.run_until_complete(future2)

# Generated at 2022-06-12 13:11:17.333563
# Unit test for function chain_future
def test_chain_future():
    import functools
    import logging
    import threading

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, ExpectLog

    @gen.coroutine
    def f1():
        logging.info("f1")
        raise gen.Return(42)

    @gen.coroutine
    def f2():
        logging.info("f2")
        yield gen.sleep(0.01)
        raise gen.Return("hello")

    @gen.coroutine
    def test():
        fut = Future()
        chain_future(f1(), fut)
        raise gen.Return(fut)

    @gen.coroutine
    def test2():
        fut = Future()
        chain_future(f2(), fut)
        raise gen.Return(fut)

   

# Generated at 2022-06-12 13:11:27.696517
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    class Future(object):
        def __init__(self):
            self._done = False
            self._result = None
            self._exc_info = None
            self._callbacks = []

        def result(self):
            return self._result

        def exception(self):
            return self._exc_info[1] if self._exc_info else None

        def exc_info(self):
            return self._exc_info

        def set_result(self, result):
            self._result = result
            self._set_done()

        def set_exception(self, exception):
            self._exc_info = sys.exc_info()
            self._set_done()

        def cancel(self):
            self._set_done()

        def cancelled(self):
            return self._exc_

# Generated at 2022-06-12 13:11:31.298129
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    assert not future.done()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-12 13:11:41.669694
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class MyFuture(Future):
        pass
    try:
        Future.set_result
    except AttributeError:
        # Python 3.5 does not have this method (it was added in 3.6)
        Future.set_result = Future.__class__.set_result.__func__
    try:
        Future.set_exception
    except AttributeError:
        # Python 3.5 does not have this method (it was added in 3.6)
        Future.set_exception = Future.__class__.set_exception.__func__

    # concurrent.futures.Future object
    cf = futures.Future()
    chain_future(cf, Future())

    # Tornado Future object
    tf = Future()  # type: Future
    chain_future(tf, Future())

   

# Generated at 2022-06-12 13:11:51.924379
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent import futures
    import tornado.ioloop
    import tornado.platform.asyncio as asyncio
    import tornado.testing

    class TestCase(tornado.testing.AsyncTestCase):
        def test_run_on_executor(self):
            executor = futures.ThreadPoolExecutor(1)

            class Foo(object):
                executor = executor

                @run_on_executor
                def method(self):
                    return 42

                @run_on_executor(executor='executor2')
                def method2(self):
                    return 42

            @run_on_executor
            def function(self):
                return 42

            foo = Foo()
            foo.executor2 = foo.executor
            f = foo.method()

# Generated at 2022-06-12 13:11:58.676998
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    global counter
    counter = 0

    class FutureTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(FutureTest, self).setUp()
            self.io_loop.make_current()

        def tearDown(self):
            # Remove the IOLoop we created so it doesn't interfere with
            # other tests
            global _current_ioloop
            _current_ioloop = None
            super(FutureTest, self).tearDown()

        def test_chain_future(self):
            global counter

            f = Future()
            g = Future()
            chain_future(f, g)

            f.set_result(None)
            self.assertTrue(g.done())
            self.assertFalse(g.cancelled())
           

# Generated at 2022-06-12 13:12:02.730132
# Unit test for function chain_future
def test_chain_future():
    # https://github.com/tornadoweb/tornado/issues/2198
    f = Future()

    def cb(future):
        future.set_result(future.result() + 1)

    f.add_done_callback(cb)
    f.set_result(1)
    assert f.result() == 2



# Generated at 2022-06-12 13:12:10.216830
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def async_test(future):
        try:
            raise Exception("test_future_set_exception_unless_cancelled")
        except:
            future_set_exception_unless_cancelled(future, sys.exc_info()[1])
    f = Future()
    async_test(f)
    assert f.exception() is not None

    cancelled_future = Future()
    cancelled_future.cancel()
    try:
        raise Exception("test_future_set_exception_unless_cancelled")
    except:
        future_set_exception_unless_cancelled(cancelled_future, sys.exc_info()[1])

# Generated at 2022-06-12 13:12:15.373135
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = Future()
    assert not fut.done()
    assert not fut.cancelled()

    exc = ValueError("Test Value Error")
    future_set_exception_unless_cancelled(fut, exc)

    assert fut.done()
    assert not fut.cancelled()
    assert fut.exception() == exc

    fut2 = Future()
    fut2.cancel()
    assert fut2.cancelled()

    future_set_exception_unless_cancelled(fut2, exc)
    assert fut2.cancelled()


del Future, FUTURES

# Generated at 2022-06-12 13:12:23.881992
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase

    from tornado.ioloop import IOLoop

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    assert not f2.done()
    f1.set_result(42)
    IOLoop.current().run_sync(f2)
    assert f2.result() == 42

    f2 = Future()

    chain_future(f1, f2)

    assert f1.done() and not f2.done()
    f2.set_result(24)
    IOLoop.current().run_sync(f1)
    assert f1.result() == 42 and f2.result() == 24

    f1 = Future()
    f2 = Future()


# Generated at 2022-06-12 13:12:38.834569
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def fail(future):
        # type: (Future) -> None
        future.set_exception(Exception("yes"))

    def callback(future):
        # type: (Future) -> None
        future.set_result(None)

    io_loop = IOLoop()
    io_loop.make_current()
    f = Future()
    chain_future(f, f)
    future_add_done_callback(f, callback)
    f.set_result(42)
    io_loop.run_sync(lambda: None)

    f = Future()
    chain_future(f, f)
    future_add_done_callback(f, fail)
    f.set_result(42)
    with ExpectLog(app_log, "Exception after Future was cancelled"):
        io

# Generated at 2022-06-12 13:12:44.776867
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.ioloop
    import tornado.testing

    class MyClass:
        executor = dummy_executor

        @run_on_executor
        def foo(self, arg1, arg2, kwarg=None):
            return arg1, arg2, kwarg

    with tornado.testing.AsyncTestCase().get_ioloop() as io_loop:
        io_loop.spawn_callback(_test_run_on_executor, io_loop)
        io_loop.run_sync(io_loop.stop)



# Generated at 2022-06-12 13:12:53.546230
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    if not hasattr(asyncio, "as_completed"):
        raise Exception("asyncio.as_completed not defined")

    def cb(f):
        # type: (Future[int]) -> None
        assert f.result() == 1

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    f1.set_result(1)
    chain_future(f1, f2)
    f2.add_done_callback(cb)

    # Test that the order of attaching callbacks doesn't matter,
    # and that exceptions are raised immediately.
    f1 = Future()  # type: Future[int]
    f

# Generated at 2022-06-12 13:12:56.090626
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

# Generated at 2022-06-12 13:13:05.037710
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import BaseAsyncIOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self) -> None:
            self.io_loop = BaseAsyncIOLoop()
            self.set_up_future = Future()

        @gen_test
        def test_chain_future(self) -> None:
            conc_future = futures.Future()
            async_future = to_asyncio_future(conc_future)

            callback_args = [False, False]

            def callback_fn(conc_future):
                callback_args[0] = True

            def callback_coro(conc_future):
                callback_args[1]

# Generated at 2022-06-12 13:13:12.041543
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test success case
    future = Future()
    value = 'test value'
    future_set_result_unless_cancelled(future, value)

    # Test if `future` is already cancelled
    future = Future()
    cb = lambda: None
    future.add_done_callback(cb)
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, value)
    except Exception as e:
        assert e.__class__.__name__ == 'InvalidStateError'



# Generated at 2022-06-12 13:13:19.962749
# Unit test for function chain_future
def test_chain_future():
    if sys.version_info < (3, 5, 2):
        # async/await syntax is not available
        return

    import pytest

    async def main():
        # Test that type annotations are correct
        a: Future[str] = Future()
        b: Future[str] = Future()
        chain_future(a, b)

        with pytest.raises(asyncio.InvalidStateError):
            chain_future(Future(), Future())

        chain_future(a, b)
        a.set_result("foo")
        assert (await b) == "foo"
        chain_future(a, b)
        a.set_exception(ValueError())
        with pytest.raises(ValueError):
            await b
        chain_future(a, b)
        b.set_result("bar")


# Generated at 2022-06-12 13:13:23.831587
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ZeroDivisionError())
    assert f._loop.run_until_complete(f) is None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ZeroDivisionError())
    assert f._loop.run_until_complete(f) is None

# Generated at 2022-06-12 13:13:29.956203
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import concurrent.futures

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = asyncio.new_event_loop()
            self.executor = concurrent.futures.ThreadPoolExecutor(10)
            self.addCleanup(self.executor.shutdown)

        def test_run_on_executor(self):
            @run_on_executor
            def blocking_func():
                return 42

            result = []

            def callback(x):
                result.append(x)
                self.stop()

            blocking_func(callback=callback)
            self.wait()
            self.assertEqual(result, [42])


# Generated at 2022-06-12 13:13:32.136160
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ZeroDivisionError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ZeroDivisionError())

# Generated at 2022-06-12 13:13:47.982159
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("bar"))



# Generated at 2022-06-12 13:13:53.978504
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    @run_on_executor
    def blocking_function(result, time):
        time.sleep(0.1)
        return result

    @gen_test
    def test_chain_future():
        io_loop = IOLoop.current()
        result = {}
        future = blocking_function(result, time)
        res = yield future
        self.assertEqual(result, res)

    test_chain_future()

# Generated at 2022-06-12 13:13:56.717462
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "value")
    assert future.result() == "value"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "value")
    assert future.cancelled()

# Generated at 2022-06-12 13:14:06.475355
# Unit test for function run_on_executor
def test_run_on_executor():

    count = 0

    class FakeExecutor(object):
        def __init__(self):
            self.submit_return_value = None

        def submit(self, func, *args, **kwargs):
            self.submit_args = (func,) + args
            return self.submit_return_value

    class FakeFuture(object):
        def __init__(self):
            self.done_callbacks = []

        def add_done_callback(self, fn):
            self.done_callbacks.append(fn)

    class Foo(object):
        def __init__(self):
            self.executor = FakeExecutor()
            self.executor.submit_return_value = FakeFuture()
            self.call_count = 0

            self.executor_name = FakeExecutor()

# Generated at 2022-06-12 13:14:13.716335
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def test():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        assert not f2.done()
        f1.set_result(42)
        assert f2.done()
        assert f2.result() == 42

        f1 = Future()
        f2 = Future()
        f1.set_exception(ValueError())
        chain_future(f1, f2)
        assert f2.exception() is not None

    asyncio.get_event_loop().run_until_complete(test())

# Generated at 2022-06-12 13:14:14.880063
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42



# Generated at 2022-06-12 13:14:23.292092
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing
    import concurrent.futures
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future

    class _TestChainFuture(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
                # A concurrent.futures.Future that can be cancelled.
                class CancelFuture(concurrent.futures.Future):
                    def __init__(self, exc):
                        super().__init__()
                        self._exc = exc

                    def cancel(self):
                        self.set_exception(self._exc)

                # Create a "real" asyncio Future, which can be cancelled.

# Generated at 2022-06-12 13:14:33.853577
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    first_future = Future()
    second_future = Future()
    chain_future(first_future, second_future)

    assert not second_future.done()

    first_future.set_result(None)
    io_loop.run_sync(lambda: None)

    assert second_future.done()
    assert not second_future.cancelled()

    first_future = Future()
    second_future = Future()
    chain_future(first_future, second_future)

    assert not second_future.done()

    first_future.set_exception(RuntimeError())
    io_loop.run_sync(lambda: None)

    assert second_future.done()
    assert False == second_future.cancelled()

    first

# Generated at 2022-06-12 13:14:36.943587
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b, c):
        return a + b + c

    future = dummy_executor.submit(test_func, 1, 2, 3)
    assert future.result() == 6



# Generated at 2022-06-12 13:14:41.493136
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    @gen.coroutine
    def inner():
        raise Return((yield gen.moment))

    @gen.coroutine
    def outer():
        f = inner()
        f2 = Future()
        chain_future(f, f2)
        result = yield f2
        raise Return(result)

    result = outer()
    assert not is_future(result)
    result = io_loop.run_sync(result)
    assert result is None

# Generated at 2022-06-12 13:15:16.097105
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    def get_concurrent_future(io_loop: "IOLoop") -> "Future[None]":
        executor = concurrent.futures.ThreadPoolExecutor(1)
        future = concurrent.futures.Future()  # type: concurrent.futures.Future[None]

        def set_future():
            io_loop.add_callback(lambda: future.set_result(None))

        executor.submit(set_future)
        return future

    def _test_chain_future(io_loop_):
        # type: (IOLoop) -> None
        async_future = Future()  # type: Future[None]
        chain_future(get_concurrent_future(io_loop_), async_future)
        yield async_future

    io_loop = IOLoop

# Generated at 2022-06-12 13:15:21.135472
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class FutureTest(AsyncTestCase):
        @gen_test
        def test(self: "FutureTest") -> None:
            future1 = Future()  # type: Future
            future2 = Future()  # type: Future
            chain_future(future1, future2)
            future1.set_result(42)
            self.assertEqual(42, (yield future2))

    FutureTest().test()

# Generated at 2022-06-12 13:15:24.301745
# Unit test for function chain_future
def test_chain_future():
    first = Future()
    second = Future()
    chain_future(first, second)
    first.set_result("foo")
    assert second.result() == "foo"

# Generated at 2022-06-12 13:15:28.332533
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"



# Generated at 2022-06-12 13:15:34.249116
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()

# Generated at 2022-06-12 13:15:38.434186
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    exc = Exception()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None


if typing.TYPE_CHECKING:
    from asyncio import Future as asyncio_Future

# Generated at 2022-06-12 13:15:42.063718
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import asyncio
    future1 = asyncio.Future()
    future_set_result_unless_cancelled(future1, "result 1")
    assert future1.result() == "result 1"
    future2 = asyncio.Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, "result 2")
    assert future2.cancelled()
    assert future2.exception() is None


# Generated at 2022-06-12 13:15:46.850744
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    class ExceptionCallStack(Exception):
        def __init__(self):
            super().__init__()
            self.stack = []

        def __enter__(self):
            self.stack.append(sys._getframe())
            return self

        def __exit__(self, typ, value, traceback):
            assert self.stack[-1] == sys._getframe()
            self.stack.pop()

        def __str__(self):
            return repr(self)

        def __repr__(self):
            return "ExceptionCallStack(%s) at %s" % (
                self.stack,
                hex(id(self)),
            )

    exc = ExceptionCallStack()
    with exc:
        pass

    future = Future()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-12 13:15:55.038297
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.ioloop import IOLoop

    ioloop = IOLoop()
    ioloop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()

    @gen.coroutine
    def set_f1():
        f1.set_result(42)

    ioloop.add_callback(set_f1)
    ioloop.add_future(f2, lambda future: ioloop.stop())
    ioloop.start()

    assert f1.done()
    assert f2.done()
    assert f2.result() == 42


# Generated at 2022-06-12 13:15:58.739571
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert isinstance(future.exception(), Exception)

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.cancelled()

# Generated at 2022-06-12 13:16:55.780862
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase

    class Test(AsyncTestCase):
        def test_set_exception_unless_cancelled(self):
            future = Future()

            def test_set_exception_unless_cancelled_run():
                future_set_exc_info(future, sys.exc_info())
                future_set_exception_unless_cancelled(future, RuntimeError())

            self.io_loop.run_sync(test_set_exception_unless_cancelled_run)

# Generated at 2022-06-12 13:17:01.481965
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase

    io_loop = IOLoop()

    f1 = Future()
    f2 = Future()

    io_loop.add_callback(lambda: future_set_result(f1, 42))
    chain_future(f1, f2)
    io_loop.add_future(f2, lambda f: io_loop.stop())

    io_loop.start()
    assert f2.result() == 42



# Generated at 2022-06-12 13:17:06.116218
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "TEST")
    assert future.result() == "TEST"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "TEST")
    assert future.result() is None and future.cancelled() is True

# Generated at 2022-06-12 13:17:08.234696
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exc = Exception()

    f.set_exception(exc)
    f.set_exception(Exception())

    f.cancel()
    f.set_exception(Exception())

# Generated at 2022-06-12 13:17:10.923332
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 100)
    assert f.result() != 100
    f = Future()
    future_set_result_unless_cancelled(f, 100)
    assert f.result() == 100


# Generated at 2022-06-12 13:17:16.646450
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: no cover
    import unittest
    import time
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class Foo(object):
        executor = concurrent.futures.ThreadPoolExecutor(10)

        @run_on_executor
        def func(self):
            time.sleep(0.1)
            return 42

    class RunOnExecutorTest(unittest.TestCase):
        def test_run_on_executor(self):
            foo = Foo()
            ioloop = IOLoop.current()
            f = foo.func()
            self.assertFalse(f.done())
            ioloop.add_future(f, lambda f: self.stop(f.result()))
            ioloop.start()

# Generated at 2022-06-12 13:17:24.038440
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not (future1.done() or future2.done())
    future1.set_result(42)
    assert future2.done()
    assert future2.result() == 42
    future3 = Future()
    future4 = Future()
    chain_future(future3, future4)
    assert not (future3.done() or future4.done())
    future3.set_exception(ZeroDivisionError)
    assert future4.done()
    try:
        future4.result()
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError("ZeroDivisionError not raised")

# Generated at 2022-06-12 13:17:30.648904
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            conc_future = futures.Future()
            async_future = Future()
            chain_future(conc_future, async_future)
            self.assertFalse(async_future.done())
            conc_future.set_result(42)
            self.assertEqual((yield async_future), 42)

    test = TestChainFuture()
    test.test_chain_future()



# Generated at 2022-06-12 13:17:39.483326
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest

    from tornado.ioloop import IOLoop, TimeoutError

    class ChainFutureTest(unittest.TestCase):
        def setUp(self) -> None:
            self.io_loop = IOLoop()
            self.result = None
            self.exception = None

        def tearDown(self) -> None:
            self.io_loop.close(all_fds=True)

        def _run_until(self, condition: Callable[[], bool], timeout: float) -> None:
            end_time = time.time() + timeout
            while not condition():
                self.io_loop.run_sync(
                    lambda: self.io_loop.add_timeout(end_time, TimeoutError())
                )


# Generated at 2022-06-12 13:17:44.213066
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    from concurrent import futures

    class DummyExecutor_submit(unittest.TestCase):
        def test_add(self):
            de = DummyExecutor()
            future = de.submit(lambda a, b: a + b, 1, 2)
            self.assertEqual(future.result(), 3)

    unittest.main()


# Generated at 2022-06-12 13:18:40.578994
# Unit test for function chain_future
def test_chain_future():
    class MyException(Exception):
        def __init__(self, code):
            self.code = code

    def f():
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        return f2

    f3 = f()
    assert f3.result() == 42
    try:
        f4 = f()
        f4.set_exception(MyException(13))
        assert False, "should have raised"
    except MyException as e:
        assert e.code == 13



# Generated at 2022-06-12 13:18:43.615774
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    inst = DummyExecutor()
    assert isinstance(inst, DummyExecutor)
    assert isinstance(inst, futures.Executor)
    def square(x:int) -> float:
        return x**2
    assert inst.submit(square,2) == 4


# Generated at 2022-06-12 13:18:52.433933
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)
    c = Future()
    chain_future(b, c)
    a.set_result(42)
    assert c.result() == 42
    assert len(a._callbacks) == 1
    assert len(b._callbacks) == 1
    assert len(c._callbacks) == 0

    a2 = Future()
    b2 = Future()
    chain_future(a2, b2)
    c2 = Future()
    chain_future(b2, c2)
    b2.cancel()
    assert c2.cancelled()
    assert len(a2._callbacks) == 1
    assert len(b2._callbacks) == 1

# Generated at 2022-06-12 13:18:58.472856
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f2.set_result(43)
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 43
    assert f1.result() == 42

    f1 = Future()
    f2 = Future()
    f2.cancel()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.cancelled()
    assert f1.result() == 42

    # concurrent.futures.Future also supported

# Generated at 2022-06-12 13:19:07.019831
# Unit test for function chain_future
def test_chain_future():
    def handle_exception(typ, value, tb):
        pass
    # Check single exception
    try:
        fut1 = futures.Future()
        fut2 = Future()
        chain_future(fut1, fut2)
        fut1.set_exception(RuntimeError())
        fut2.result()
    except RuntimeError:
        pass
    else:
        assert False, "RuntimeError not raised"
    # Check double exception
    sysex = SystemExit()
    try:
        fut1 = futures.Future()
        fut2 = Future()
        chain_future(fut1, fut2)
        fut1.set_exception(RuntimeError())
        fut2.set_exception(sysex)
        fut2.result()
    except SystemExit as ex:
        assert ex is sysex

# Generated at 2022-06-12 13:19:15.200987
# Unit test for function chain_future
def test_chain_future():
    def make_future(result: Any) -> Future:
        future = Future()
        future.set_result(result)
        return future

    def make_future_exception(exc: Any) -> Future:
        future = Future()
        future.set_exception(exc)
        return future

    future_result = make_future(42)
    future_exception = make_future_exception(RuntimeError("the answer"))
    future2 = Future()
    chain_future(future_result, future2)
    chain_future(future_exception, future2)

    assert future2.result() == 42
    assert future2.exception() is None

    future_result = make_future(42)
    future_exception = make_future_exception(RuntimeError("the answer"))
    future2 = Future()
   

# Generated at 2022-06-12 13:19:23.401026
# Unit test for function chain_future
def test_chain_future():
    executor = futures.ThreadPoolExecutor(1)
    io_loop = asyncio.get_event_loop()

    @run_on_executor(executor='_thread_pool')
    def callback_dummy_async_call(future):
        return 1

    @run_on_executor(executor='_thread_pool')
    def callback_dummy_periodic_call():
        return 1

    # test for chain_future
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    assert isinstance(f, Future)
    assert isinstance(f2, Future)
    f2.set_result(True)
    io_loop.run_until_complete(f2)
    assert f2.done()
    assert f2.result() is True

   

# Generated at 2022-06-12 13:19:30.479118
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    @return_future
    def sleep_and_callback(io_loop, callback, n):
        io_loop.add_callback(callback, n)

    @run_on_executor
    def sleep_and_return(io_loop, n):
        return n

    @gen.coroutine
    def f():
        # test that a Future returned from an executor can be chained to
        # a Coroutine
        f1 = sleep_and_callback(n=1)
        n1 = yield f1
        self.assertEqual(1, n1)
        # test that a Future returned from an executor can be chained to
        # another Future
        f2 = sleep_and_callback(n=2)
        f3 = sleep_and_return(3)
        # chain f2 and

# Generated at 2022-06-12 13:19:36.357316
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test1():
        from tornado.httpclient import AsyncHTTPClient, HTTPRequest
        from tornado.platform.asyncio import AsyncIOMainLoop

        AsyncIOMainLoop().install()
        client = AsyncHTTPClient()
        future = client.fetch(HTTPRequest("http://www.facebook.com/"))

        def callback(f):
            response = f.result()
            assert response.code == 200
            assert b"Facebook" in response.body
            tornado.ioloop.IOLoop.current().stop()

        chain_future(future, asyncio.Future())
        future.add_done_callback(callback)


# Generated at 2022-06-12 13:19:44.513048
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.gen
    from tornado.testing import AsyncTestCase

    def bad_function():
        raise Exception("bad function exception")

    class MyTestCase(AsyncTestCase):

        def test_bad_function(self):
            f = tornado.gen.Future()
            future_set_exception_unless_cancelled(f, Exception("bad function exception"))
            f.add_done_callback(self.stop)
            self.wait()

        def test_bad_function_cancelled(self):
            f = tornado.gen.Future()
            f.set_result("some result")
            future_set_exception_unless_cancelled(f, Exception("bad function exception"))

        def test_bad_function_cancelled_immediate(self):
            f = tornado.gen.Future()
            f.c