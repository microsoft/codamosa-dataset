

# Generated at 2022-06-12 13:09:55.219702
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()

    try:
        raise ValueError("Test Argument")
    except ValueError as e:
        future_set_exception_unless_cancelled(future, e)

    # Make sure that the exception was not raised again by an uncaught exception
    assert True

# Generated at 2022-06-12 13:10:05.088647
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(5)
    assert b.result() == 5

    # Test that exceptions are propagated
    a = Future()
    b = Future()
    chain_future(a, b)
    e = Exception()
    a.set_exception(e)
    assert b.exception() is e

    # Test that b being cancelled suppresses exceptions
    a = Future()
    b = Future()
    chain_future(a, b)
    e = Exception()
    a.set_exception(e)
    b.cancel()
    assert b.cancelled()
    assert b.exception() is None

# Generated at 2022-06-12 13:10:12.686465
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test, AsyncTestCase

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.loop.make_current()

        @gen_test
        def test_submit(self):
            @gen.engine
            def f():
                raise gen.Return(42)

            res = yield dummy_executor.submit(f)
            self.assertEqual(42, res)

    test = TestCase()
    test.setUp()
    IOLoop.current().run_sync(test.test_submit)


# Generated at 2022-06-12 13:10:16.926387
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from concurrent.futures import Future
    from tornado.testing import AsyncTestCase, gen_test

    class TestFutureSetResultUnlessCancelled(AsyncTestCase):
        @gen_test
        def test_future_set_result_unless_cancelled(self):
            future = Future()
            future.cancel()
            future_set_result_unless_cancelled(future, "value")
            self.assertTrue(future.cancelled())
            self.assertFalse(future.done())

            future = Future()
            future_set_result_unless_cancelled(future, "value")
            self.assertFalse(future.cancelled())
            self.assertTrue(future.done())
            self.assertEqual(future.result(), "value")

            future = Future()
            future.cancel()


# Generated at 2022-06-12 13:10:25.034589
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    """Tests for future.future_set_result_unless_cancelled()."""
    import pytest
    from tornado.ioloop import IOLoop

    def f(future):
        # type: (Future) -> None
        future_set_result_unless_cancelled(future, 42)
        future_set_result_unless_cancelled(future, 43)

    class DummyFuture(Future):
        def cancel(self):
            # type: () -> bool
            self._cancelled = True
            return True

        def cancelled(self):
            # type: () -> bool
            return getattr(self, "_cancelled", False)

    async_future = DummyFuture()
    IOLoop.current().add_callback(f, async_future)
    assert async_future

# Generated at 2022-06-12 13:10:34.771955
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    io_loop = IOLoop.current()

    with pytest.raises(ValueError) as e:
        chain_future(Future(), Future())
    assert "not supported" in str(e)

    with pytest.raises(ValueError) as e:
        chain_future(futures.Future(), futures.Future())
    assert "not supported" in str(e)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    io_loop.run_sync(lambda: f1.set_result(None))
    assert f2.done()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()


# Generated at 2022-06-12 13:10:38.147541
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import pytest
    from tornado.ioloop import IOLoop

    future = Future()
    future_set_exc_info(future, sys.exc_info())

    def check():
        assert isinstance(future.exception(), ZeroDivisionError)

    IOLoop.current().add_callback(check)



# Generated at 2022-06-12 13:10:43.905229
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.stack_context

    class Foo(Exception):
        pass

    future = Future()
    try:
        raise Foo()
    except:
        exc_info = sys.exc_info()

    def check_exc():
        assert future.exception() is exc_info[1]

    tornado.stack_context.run_sync(lambda: future_set_exc_info(future, exc_info))
    future.add_done_callback(check_exc)



# Generated at 2022-06-12 13:10:51.376158
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    # Test with concurrent.futures.Future.
    f1 = futures.Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    io_loop.add_callback(lambda: f1.set_result(42))
    assert f2.result() == 42

    # Test with asyncio.Future.
    f3 = Future()
    f4 = Future()
    chain_future(f3, f4)
    io_loop.add_callback(lambda: future_set_result_unless_cancelled(f3, 43))
    assert f4.result() == 43

    io_loop.close()



# Generated at 2022-06-12 13:10:59.925101
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.locks
    import tornado.platform.asyncio

    class AsyncTestCase(unittest.TestCase):
        def setUp(self):
            super(AsyncTestCase, self).setUp()
            self.io_loop = tornado.testing.AsyncTestCase.get_new_ioloop(
                io_loop=tornado.platform.asyncio.AsyncIOLoop()
            )
            self.executor = dummy_executor
            self.call_counter = 0

        def f(self) -> None:
            self.call_counter += 1

        @run_on_executor
        def g(self) -> None:
            self.f()

        def h(self) -> int:
            self.f()
            return 42


# Generated at 2022-06-12 13:11:07.445235
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None



# Generated at 2022-06-12 13:11:14.831903
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    import unittest
    from tornado.testing import AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test1(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertEqual(a.done(), b.done())

            a.set_result(42)
            self.assertEqual(b.result(), 42)

            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(RuntimeError())
            self.assertFalse(b.done())
            b.set_result(100)
            self.assertEqual(b.exception(), RuntimeError())

            a = Future()
            b = Future()
            chain_future(a, b)
           

# Generated at 2022-06-12 13:11:25.596138
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def func(arg):
        return arg

    async def go():
        f1 = Future()
        f2 = Future()
        f3 = Future()
        f4 = Future()
        chain_future(f1, f2)
        f1.set_result(3)
        assert f2.result() == 3
        assert f3.exception()
        assert f4.result() == 4

        f1 = Future()
        f2 = Future()
        f3 = Future()
        f4 = Future()
        chain_future(f1, f2)
        f1.set_exception(KeyError)
        assert isinstance(f2.exception(), KeyError)
        assert f3.exception()
        assert f4.result() == 4

        f1 = Future()

# Generated at 2022-06-12 13:11:29.959679
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest.mock

    with unittest.mock.patch.object(
        dummy_executor, "submit", wraps=dummy_executor.submit
    ) as submit_mock:
        class Foo(object):
            executor = dummy_executor

            @run_on_executor
            def foo(self, a, b):
                return a + b

        f = Foo()
        assert isinstance(f.foo(1, 2), Future)
        assert submit_mock.called
        assert submit_mock.call_args[0][0].__self__ is f
        assert submit_mock.call_args[0][1:] == (1, 2)


# Generated at 2022-06-12 13:11:35.755897
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    from tornado.locks import Event

    @gen_test
    async def test_chain_future():
        done = Event()

        @gen_test
        async def foo():
            await asyncio.sleep(1)
            done.set()

        foo().add_done_callback(lambda _: done.set())
        await done.wait()



# Generated at 2022-06-12 13:11:45.712401
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop

    class TestClass:
        executor = dummy_executor

        def __init__(self, ioloop):
            self.ioloop = ioloop

        @run_on_executor
        def test_method_1(self, a, b, c=0):
            return a + b + c

        @run_on_executor(executor="_other_executor")
        def test_method_2(self, d, e, f=0):
            return d - e - f

        @run_on_executor(executor="_other_executor")
        def test_exc(self):
            raise Exception()

        @run_on_executor
        def test_exc2(self):
            raise Exception()


# Generated at 2022-06-12 13:11:54.665712
# Unit test for function chain_future
def test_chain_future():
    done = False

    @gen.coroutine
    def f():
        yield gen.moment
        raise gen.Return(3)

    def run_test():
        a = f()
        assert isinstance(a, Future)
        b = Future()
        chain_future(a, b)
        return b

    def check_result(f):
        assert f.result() == 3
        nonlocal done
        assert not done
        done = True

    t = run_test()
    IOLoop.current().add_future(t, check_result)
    # Also test the deprecated @return_future
    t = return_future(run_test)()
    IOLoop.current().add_future(t, check_result)


# Generated at 2022-06-12 13:12:04.116951
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    import unittest.mock

    class Foo(Exception):
        pass

    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, Foo)
    assert f.exception() == Foo

    with unittest.mock.patch.object(app_log, "error") as log:
        f = asyncio.Future()
        f.cancel()
        future_set_exception_unless_cancelled(f, Foo)
        assert f.exception() == None
        assert log.call_args[1]['exc_info'][0] == Foo

    with unittest.mock.patch.object(app_log, "error") as log:
        f = Future()
        f.cancel()
        future_set_exception_unless

# Generated at 2022-06-12 13:12:09.177303
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert not b.done()
    chain_future(a, b)
    assert not b.done()
    a.set_result("foo")
    assert b.result() == "foo"
    c = Future()
    chain_future(b, c)
    assert c.done()
    assert c.result() == "foo"



# Generated at 2022-06-12 13:12:15.842664
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing
    import unittest

    @tornado.testing.gen_test
    def test_gen(future1, future2):
        # type: (Future[_T], Future[_T]) -> None
        yield future_add_done_callback(future1, lambda future: future2.set_result(42))
        yield future1
        self.assertEqual(future2.result(), 42)
        yield future2

    @tornado.testing.gen_test
    def test_chaining(future1, future2):
        # type: (Future[_T], Future[_T]) -> None
        chain_future(future1, future2)
        future1.set_result(42)
        self.assertEqual(future2.result(), 42)


# Generated at 2022-06-12 13:12:29.526656
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    from unittest.mock import patch

    class _TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        @patch("tornado.gen.future_set_exception_unless_cancelled")
        def test_not_raised_cancelled(self, mock):
            future = Future()
            future.cancel()
            try:
                raise Exception
            except Exception as e:
                future_set_exception_unless_cancelled(future, e)
                mock.assert_not_called()

        @patch("tornado.gen.app_log.error")
        def test_log_exception(self, mock_log_error):
            future = Future()
            future.cancel()
            try:
                raise Exception
            except Exception as e:
                future_

# Generated at 2022-06-12 13:12:32.985780
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-12 13:12:35.023181
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("test value"))

# Generated at 2022-06-12 13:12:43.303278
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChaining(AsyncTestCase):
        def test_chaining(self):
            # type: () -> None
            a = Future()
            b = Future()
            c = Future()
            self.assertFalse(b.done())
            self.assertFalse(c.done())
            d = Future()
            chain_future(a, b)
            chain_future(b, c)
            a.set_result(42)
            self.assertTrue(b.done())
            self.assertTrue(c.done())
            self.assertEqual(c.result(), 42)
            a.set_result(37)
            self.assertEqual(c.result(), 42)
            b.set_result(37)
           

# Generated at 2022-06-12 13:12:51.914411
# Unit test for function chain_future
def test_chain_future():
    @functools.wraps(chain_future)
    def check_chain(a: Future, b: Future) -> None:
        chain_future(a, b)
        assert not a.done()
        assert not b.done()
        a.set_result(None)
        assert a.done()
        assert b.done()

    check_chain(Future(), Future())
    f1, f2 = Future(), Future()
    f1.set_result(None)
    check_chain(f1, f2)
    f1, f2 = Future(), Future()
    f2.set_result(None)
    check_chain(f1, f2)
    f1, f2 = Future(), Future()
    f2.set_exception(IndexError())
    check_chain(f1, f2)


# Generated at 2022-06-12 13:13:00.650513
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    @run_on_executor
    def f(self):
        # type: (Any) -> int
        return self.x + 1

    class A(object):
        def __init__(self):
            self.executor = dummy_executor
            self.x = 10

        function = f

    a = A()
    future = a.function()
    assert future.result() == 11
    assert isinstance(future, Future)
    assert not future.done()

    # Ensure that the decorator can be used without passing
    # self.
    @run_on_executor
    def f2(self):
        # type: (Any) -> int
        return self.x + 1

    class B(object):
        def __init__(self):
            self.x = 10

   

# Generated at 2022-06-12 13:13:04.850233
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    e = Exception()
    future_set_exception_unless_cancelled(future, e)
    assert future.done()
    assert e == future.exception()
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, e)

# Generated at 2022-06-12 13:13:07.938971
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f():
        return 1
    dummy = DummyExecutor()
    dummy.submit(f)


test_DummyExecutor_submit()



# Generated at 2022-06-12 13:13:13.104213
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError)
    assert not future.cancelled()
    assert future.exception() != None
    # Repeating with a cancelled future should log the exception;
    # we test that it doesn't throw
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError)



# Generated at 2022-06-12 13:13:18.116382
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    class TestException(Exception):
        pass

    f1 = Future()  # type: Future[int]
    future_set_exception_unless_cancelled(f1, TestException("error"))
    assert isinstance(f1.exception(), TestException)

    f2 = Future()  # type: Future[int]
    f2.cancel()
    future_set_exception_unless_cancelled(f2, TestException("error"))

# Generated at 2022-06-12 13:13:40.498381
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    results = []

    def make_future():
        # type: () -> Future
        return Future()

    def make_concurrent_future():
        # type: () -> futures.Future
        return futures.Future()

    for make_future_func in (make_future, make_concurrent_future):
        future1 = make_future_func()
        future2 = make_future_func()

        assert not future1.done()
        assert not future2.done()

        chain_future(future1, future2)

        assert not future1.done()
        assert not future2.done()

        future1.set_result('foo')

        assert future1.done()
        assert future2.done()
        assert future2.result() == 'foo'

        future1 = make_future_func

# Generated at 2022-06-12 13:13:42.740105
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f():
        return 1
    a = DummyExecutor()
    b = a.submit(f)
    assert b.result() == 1


# Generated at 2022-06-12 13:13:48.487058
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    #IOLoop.configure(AsyncIOMainLoop)
    loop = asyncio.get_event_loop()
    #IOLoop.current().start()

    def fn(a, b):
        return a + b

    f = dummy_executor.submit(fn, 1, 2)

    loop.run_until_complete(f)

    assert f.result() == 3

    loop.close()

# Generated at 2022-06-12 13:13:57.281760
# Unit test for function run_on_executor
def test_run_on_executor():
    import threading
    import tornado.testing

    @run_on_executor
    def f(x: int) -> int:
        return x + 1

    @run_on_executor(executor="_thread_pool")
    def g(x: int) -> int:
        return x + 1

    @run_on_executor(executor="_thread_pool")
    def h(x: int, y: int) -> int:
        return x + y

    class Dummy:
        executor = dummy_executor

    class ThreadPoolDummy:
        _thread_pool = dummy_executor

    dummy = Dummy()

    @run_on_executor
    def test_self():
        return threading.current_thread()


# Generated at 2022-06-12 13:14:03.704328
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    # f2 should be set
    assert f2.result() == 1
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() == f1.exception()


# Generated at 2022-06-12 13:14:06.684430
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-12 13:14:09.498212
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result("test")
    return f2



# Generated at 2022-06-12 13:14:17.879860
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock

    e = Exception()

    future = Future()
    # Unset exception isn't raised
    future_set_exception_unless_cancelled(future, e)
    future.result() # don't do this in real code

    # Explicitly cancelled future just logs the exception
    future = Future()
    future.cancel()
    with unittest.mock.patch('tornado.concurrent.futures.app_log') as mock_log:
        future_set_exception_unless_cancelled(future, e)
    mock_log.error.assert_called_once_with(
        'Exception after Future was cancelled',
        exc_info=e,
    )

    # Exception set with set_exception() is raised
    future = Future()
    future.set_exception

# Generated at 2022-06-12 13:14:22.665690
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    mfuture = Future()
    future_set_result_unless_cancelled(mfuture, "ok")
    assert mfuture.result() == "ok", "result is not ok"
    mfuture = Future()
    mfuture.cancel()
    future_set_result_unless_cancelled(mfuture, "not ok")
    assert mfuture.cancelled(), "future is not cancelled"

# Generated at 2022-06-12 13:14:33.175675
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestClass(object):
        @run_on_executor
        def function(self):
            return 42

    class TestClass2(AsyncTestCase):
        def setUp(self):
            super(TestClass2, self).setUp()
            self._loop = IOLoop.current()
            self.value = None

        @run_on_executor
        def function(self):
            return 42

        def callback(self, future):
            self.value = future.result()
            self._loop.stop()

        @gen_test
        def test(self):
            future = self.function()
            future_add_done_callback(future, self.callback)
            yield future
            self.assertEqual

# Generated at 2022-06-12 13:15:29.830371
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import unittest.mock

    class Thing(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            return "foo"

        def foo2(self):
            return "foo2"

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.thing = Thing()

        def test_run_on_executor(self):
            f = Thing().foo()
            self.assertEqual(f.result(), "foo")


# Generated at 2022-06-12 13:15:34.882593
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    async def async_main():
        # type: () -> None
        future1 = Future()
        future2 = Future()
        ioloop = IOLoop.current()
        ioloop.add_callback(lambda: future1.set_result(42))
        chain_future(future1, future2)
        assert 42 == await future2

    IOLoop.current().run_sync(async_main)

# Generated at 2022-06-12 13:15:39.119438
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f2.set_result(42)
    chain_future(f1, f2)
    f1.set_result(24)
    assert f2.result() == 42

# Generated at 2022-06-12 13:15:47.112987
# Unit test for function chain_future
def test_chain_future():
    def run_gen(
        g: generator,
        error: Optional[BaseException] = None,
        value: Optional[_T] = None,
    ) -> Future:
        future = Future()

        def callback() -> None:
            try:
                if error is None:
                    if value is not None:
                        fut = g.send(value)
                    else:
                        fut = g.send(None)
                    if future_set_result_unless_cancelled(future, fut.result()):
                        return
                else:
                    g.throw(error)
                    raise error
            except StopIteration as e:
                if future_set_result_unless_cancelled(future, e.value):
                    return
            except Exception as e:
                future_set_exc_info(future, sys.exc_info())
               

# Generated at 2022-06-12 13:15:52.837781
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    test_future = Future()

    def copy(f: Future) -> None:
        assert isinstance(f, Future)
        test_future.set_result(f.result())

    async_future = Future()
    chain_future(async_future, test_future)
    async_future.add_done_callback(copy)
    async_future.set_result(42)
    test_future.add_done_callback(
        lambda f: f.result() == 42 or raise_exc_info(f.exc_info())
    )

# Generated at 2022-06-12 13:15:55.728721
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-12 13:16:05.064838
# Unit test for function chain_future
def test_chain_future():
    from tornado import testing

    @testing.gen_test
    def test_chain():
        a, b = Future(), Future()
        chain_future(a, b)
        a.set_result(42)
        assert (yield b) == 42

        c, d, e = Future(), Future(), Future()
        chain_future(c, d)
        chain_future(c, e)
        c.set_result(84)
        assert (yield d) == 84
        assert (yield e) == 84

        f, g = Future(), Future()
        chain_future(f, g)
        g.set_result(None)
        f.set_result(None)  # should not raise unhandled exception

    test_chain()

# Generated at 2022-06-12 13:16:09.762007
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    b.add_done_callback(lambda f: f.result())

    a.set_result(42)

    # Check that b gets the right result no matter when it's examined
    b.add_done_callback(lambda f: (f.result(), f.result()))
    assert b.result() == 42



# Generated at 2022-06-12 13:16:16.126144
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    ex = RuntimeError()
    async_future = asyncio.Future()
    future_set_exception_unless_cancelled(async_future, ex)
    assert async_future.exception() == ex
    con_future = futures.Future()
    future_set_exception_unless_cancelled(con_future, ex)
    assert con_future.exception() == ex
    ex = RuntimeError()
    async_future = asyncio.Future()
    async_future.cancel()
    future_set_exception_unless_cancelled(async_future, ex)
    con_future = futures.Future()
    con_future.cancel()
    future_set_exception_unless_cancelled(con_future, ex)

# Generated at 2022-06-12 13:16:20.629973
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.result()

    f3 = futures.Future()
    f4 = Future()
    chain_future(f3, f4)
    f3.set_result(42)
    f4.result()

# Generated at 2022-06-12 13:17:55.128640
# Unit test for function chain_future
def test_chain_future():
    future = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    chain_future(future, future2)
    assert not future.done()
    assert not future2.done()

    future.set_result('result')
    assert future.done()
    assert future2.done()
    assert future2.exception() is None
    assert future2.result() == 'result'

    future = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    chain_future(future, future2)
    future.set_exception(ZeroDivisionError())
    assert future.done()
    assert future2.done()
    assert future2.exception() is not None

# Generated at 2022-06-12 13:18:00.280805
# Unit test for function chain_future
def test_chain_future():
    import tornado.ioloop

    io_loop = tornado.ioloop.IOLoop.current()
    io_loop.make_current()

    # We are testing for proper exception forwarding behavior, so
    # make sure we get the real stacktrace of any exceptions that
    # happen in our test.
    io_loop.set_exception_handler(lambda x, y: None)

    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.done()
    assert b.result() == 42

    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_exception(RuntimeError())
    assert b.done()

# Generated at 2022-06-12 13:18:03.372663
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert f.result() == 42
    assert g.result() == 42



# Generated at 2022-06-12 13:18:06.682678
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # test case stores the result of the method
    result = dummy_executor.submit(lambda x: x + 1, 3)
    print('The result of submit from DummyExecutor: %s' % result.result())

if __name__ == '__main__':
    test_DummyExecutor_submit()

# Generated at 2022-06-12 13:18:13.345653
# Unit test for function chain_future
def test_chain_future():
    import time

    async def async_foo(future: "Future[int]") -> None:
        await asyncio.sleep(0.1)
        future.set_result(42)

    def foo(future: "Future[int]") -> None:
        time.sleep(0.1)
        future.set_result(42)

    for f in (async_foo, foo):

        a = Future()
        b = Future()

        assert not a.done()
        assert not b.done()

        chain_future(a, b)

        assert not b.done()
        f(a)

        assert b.result() == 42



# Generated at 2022-06-12 13:18:17.874861
# Unit test for function run_on_executor
def test_run_on_executor():
    io_loop = IOLoop()

    class MyObj(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            return threading.current_thread().name

    obj = MyObj()
    future = io_loop.run_in_executor(None, obj.foo)
    io_loop.run_sync(future.result)

# Generated at 2022-06-12 13:18:21.253559
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    a = asyncio.Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    loop.run_until_complete(b)
    assert b.result() == 42



# Generated at 2022-06-12 13:18:29.863672
# Unit test for function chain_future
def test_chain_future():
    import unittest

    @run_on_executor
    def sleep_and_return(result: int, sleep: float) -> int:
        import time
        time.sleep(sleep)
        return result

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            from tornado.platform.asyncio import AsyncIOLoop
            import asyncio

            loop = AsyncIOLoop()
            loop.make_current()
            future_1 = Future()

            def callback(future: Future) -> None:
                self.assertFalse(future.exception())

# Generated at 2022-06-12 13:18:39.612687
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio

    if not AsyncIOMainLoop.initialized():
        AsyncIOMainLoop().install()

    event_loop = asyncio.get_event_loop()

    @gen.coroutine
    def func():
        yield gen.sleep(0.001)

    def f():
        return event_loop.run_sync(func, timeout=1)

    async_f = Future()
    fut = dummy_executor.submit(f)
    chain_future(fut, async_f)
    assert async_f.result() == None

    async_f = Future()
    fut = dummy_executor.submit(f)
    chain_future(async_f, fut)
    assert fut.result() == None


# Generated at 2022-06-12 13:18:47.721259
# Unit test for function chain_future
def test_chain_future():  # type: ignore
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        ioloop = asyncio.get_event_loop()
        from tornado.ioloop import IOLoop
        from tornado.concurrent import return_future, Future

        @return_future
        def add(a: int, b: int, callback: Callable[[int], Any]) -> None:
            ioloop.call_later(0, callback, a + b)

        def handle_add(f: Future[int]) -> None:
            assert f.result() == 5
            ioloop.stop()

        add(2, 3, handle_add)
        IOLoop.current().start()
    finally:
        loop.close()