

# Generated at 2022-06-12 13:09:51.847855
# Unit test for function run_on_executor
def test_run_on_executor():
    import mock

    @run_on_executor
    def f():
        pass

    instance = mock.MagicMock()
    f(instance)
    instance.executor.submit.assert_called_with(f, instance)

# Generated at 2022-06-12 13:10:01.526101
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.get_event_loop()

    def f(x):
        # type: (int) -> int
        return x + 1

    def a_done(fut):
        # type: (Future[int]) -> None
        loop.stop()
        assert fut.result() == 3

    def a_done_error(fut):
        # type: (Future[int]) -> None
        loop.stop()
        assert fut.exception() is not None

    a = asyncio.Future()
    b = asyncio.Future()

    if loop.is_running():
        raise Exception("loop is running")

    chain_future(a, b)

    b.add_done_callback(a_done)

    loop.run_until_complete(a)
    a.set_

# Generated at 2022-06-12 13:10:10.966204
# Unit test for function chain_future
def test_chain_future():
    """Tests for function chain_future."""

    def async_iter_return_result(result):
        fut = Future()
        future_set_result_unless_cancelled(fut, result)
        return fut

    def sync_return_result(result):
        return result

    # If the second future is not cancelled, the first future's result should
    # be returned and the second future's result should be the first future's
    # result.
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    # If the second future is cancelled, the first future's result should not
    # be returned.
    f2 = Future()
    f2.set_result(None)
    f1

# Generated at 2022-06-12 13:10:15.702779
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[str]
    f2 = Future()  # type: Future[str]
    chain_future(f1, f2)
    f1.set_result("result")
    assert f2.result() == "result"

    f1 = Future()
    f2 = Future()
    f1.set_result("result2")
    chain_future(f1, f2)
    assert f2.result() == "result2"

# Generated at 2022-06-12 13:10:20.628744
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()



# Generated at 2022-06-12 13:10:22.209886
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    f = executor.submit(lambda x: x, 10)
    assert f.result() == 10


# Generated at 2022-06-12 13:10:31.020793
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    loop.make_current()
    future1 = asyncio.Future()  # type: Future[int]
    future2 = asyncio.Future()  # type: Future[int]
    future3 = asyncio.Future()  # type: Future[int]
    chain_future(future1, future2)
    chain_future(future1, future3)
    assert not future1.done()
    assert not future2.done()
    assert not future3.done()

    assert future1.cancel()
    loop.run_sync(lambda: None)
    assert future1.cancelled()
    assert not future2.cancelled()
    assert not future3.cancelled()
    assert not future2.done()

# Generated at 2022-06-12 13:10:40.040882
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    # asyncio.Future
    async def test_asyncio_future():
        # create future
        future = Future()
        # test set_exception_unless_cancelled
        future_set_exception_unless_cancelled(future, Exception('foo'))
        # test future_set_result_unless_cancelled
        future_set_result_unless_cancelled(future, 1)
        # get result
        await future

    # concurrent.futures.Future
    def test_concurrent_future():
        # create future
        future = futures.Future()
        # test set_exception_unless_cancelled

# Generated at 2022-06-12 13:10:45.789973
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test_decorator")
    assert future.result() == "test_decorator"
    future_cancel(future)
    future_set_result_unless_cancelled(future, "test_decorator")
    assert future.cancelled() is True
    future_cancel(future)
    assert future.cancelled() is True



# Generated at 2022-06-12 13:10:48.885340
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future = Future()  # type: Future
    with futures.ThreadPoolExecutor() as e:
        conc_future = e.submit(lambda: 42)
        chain_future(conc_future, future)
        assert future.result() == 42

# Generated at 2022-06-12 13:10:57.177574
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado import gen

    class TestCase(unittest.TestCase):
        def setUp(self):
            # concurrent.futures.Future
            from concurrent.futures import Future
            self.conc_fut1 = Future()
            self.conc_fut2 = Future()
            # Tornado futures
            self.async_fut1 = gen.moment
            self.async_fut2 = gen.moment

        def test_chain_future_concurrent_to_tornado(self):
            """Concurrent `Future` to Tornado `Future`"""
            chain_future(self.conc_fut1, self.async_fut1)
            self.assertFalse(self.conc_fut1.done())

# Generated at 2022-06-12 13:11:05.816618
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import Future

    class FutureTest(AsyncTestCase):
        executor = dummy_executor

        @run_on_executor
        def function(self, x, y, z=1):
            # type: (int, int, int) -> int
            return x + y + z

        @run_on_executor
        def function_with_callback(self, x, y, callback, z=1):
            # type: (int, int, Callable[[int], int], int) -> None
            callback(x + y + z)

        @gen_test
        async def test_function(self):
            result = await self.function(1, 2)

# Generated at 2022-06-12 13:11:12.248564
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop
    from tornado import gen

    # Our run_on_executor decorator does not use the normal IOLoop
    # mechanisms for compatibility with objects that are not IO loops
    # (in particular, testing with unittest.TestCase).
    class DummyLoop(object):
        def add_future(self, future, callback):
            self.result = None
            self.exc_info = None

            def copy(f):
                if f.result() is not None:
                    self.result = f.result()
                if f.exception() is not None:
                    self.exc_info = f.exception()

            future_add_done_callback(future, copy)


# Generated at 2022-06-12 13:11:14.385541
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    assert not f2.done()
    f.set_result(None)
    assert f2.done()


_UNSET = object()



# Generated at 2022-06-12 13:11:25.017729
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    c = Future()
    b = Future()
    chain_future(b, c)
    b.set_result(1)
    assert c.result() == 1
    d = Future()
    chain_future(b, d)
    assert d.result() == 1
    b = Future()
    chain_future(b, c)
    b.set_exception(KeyError())
    try:
        c.result()
        raise AssertionError("did not get exception")
    except KeyError:
        pass
    d = Future()
    chain_future(b, d)
    try:
        d.result()
        raise AssertionError("did not get exception")
    except KeyError:
        pass
    e = Future()
    b = Future()

# Generated at 2022-06-12 13:11:29.428211
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1
    assert not future.done()



# Generated at 2022-06-12 13:11:39.677305
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import sys

    test_string = "test_string"
    test_future = Future()

    # Expected exception
    try:
        raise Exception(test_string)
    except Exception:
        expected_exc_info = sys.exc_info()

    try:
        future_set_exception_unless_cancelled(test_future, Exception(test_string))
    except Exception:
        actual_exc_info = sys.exc_info()

    assert actual_exc_info == expected_exc_info

    # Cancelled future
    test_future = Future()
    test_future.cancel()
    try:
        future_set_exception_unless_cancelled(test_future, Exception(test_string))
    except Exception:
        actual_exc_info = sys.exc_info()

   

# Generated at 2022-06-12 13:11:44.031545
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    import typing
    from typing import Callable, Any, Tuple
    from concurrent import futures

    de = DummyExecutor()
    f = de.submit(lambda: 42)

    # Test typing of method submit
    assert isinstance(f, futures.Future)
    assert f.result() == 42



# Generated at 2022-06-12 13:11:53.830305
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 123)
    assert future.result() is Future.CANCELLED, "Non-cancelled future result is incorrect"
    future.cancel()
    future.set_exception(Exception("test exception"))
    future_set_result_unless_cancelled(future, 123)
    assert future.result() is Future.CANCELLED, "Non-cancelled future result is incorrect"
    # Unit test for function future_set_exc_info
    future = Future()
    future.cancel()
    future_set_exc_info(future, (None, None, None))
    assert future.result() is Future.CANCELLED, "Non-cancelled future result is incorrect"
    future.cancel

# Generated at 2022-06-12 13:11:59.344257
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    # If a future is not done, don't set its result
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f3 = Future()
    # If a future is already done, don't set its result
    f3.set_result(44)
    chain_future(f1, f3)
    assert f3.result() == 44
    f4 = Future()
    # Ensure that the exception of a future is also copied
    f4.set_exception(ValueError())
    chain_future(f4, f2)
    assert f2.exception()



# Generated at 2022-06-12 13:12:08.830302
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    test_exc_info = (Exception, Exception("test exception"), None)
    future_set_exc_info(future, test_exc_info)
    assert future.exception() == test_exc_info[1]

    future = asyncio.Future()
    test_exc = Exception("test exception")
    future.cancel()
    future_set_exception_unless_cancelled(future, test_exc)
    assert not future.done()

# Generated at 2022-06-12 13:12:15.652889
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    fail_future = Future()
    fail_future.set_exception(RuntimeError)
    success_future = Future()
    success_future.set_result(None)

    class TestFuture(tornado.testing.AsyncTestCase):
        def test_chain_success_to_fail(self):
            # type: () -> None
            tornado.ioloop.IOLoop.current().run_sync(
                lambda: chain_future(success_future, fail_future)
            )
            self.assertFalse(success_future.exception())
            self.assertIsInstance(fail_future.exception(), RuntimeError)

        def test_chain_fail_to_success(self):
            # type: () -> None
            tornado.ioloop.IOLoop.current().run_

# Generated at 2022-06-12 13:12:22.248457
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test(**kwargs):
        try:
            import tornado.concurrent
            from tornado.concurrent import futures
            from tornado.ioloop import IOLoop
            from tornado.platform import asyncio
        except ImportError:
            return False

        # Setup
        future = futures.Future()
        dummy_executor.submit(lambda **kwargs: future.set_result(None), **kwargs)

        # Exercise
        IOLoop.current().run_sync(lambda: future)

        # Verify
        assert future.done()

        # Cleanup
        future.result()

    test(a=1)

# Generated at 2022-06-12 13:12:24.304989
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()
    fut.cancel()
    future_set_result_unless_cancelled(fut, 1)
    assert fut.done() and fut.cancelled()

# Generated at 2022-06-12 13:12:29.830454
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise ValueError('a')
    except ValueError as e:
        future_set_exception_unless_cancelled(future, e)
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, ValueError('b'))
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, ValueError('c'))
    assert future.exception() is not None

# Generated at 2022-06-12 13:12:38.343161
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    # These tests rely on IOLoop and IOStream, two modules that were not
    # public in Tornado 2.1
    try:
        # pylint: disable=unused-variable
        from tornado.iostream import IOStream
        from tornado import ioloop

        # DummyStream is defined in this file, below.
        from tornado.test.concurrent_test import DummyStream, dummy_executor
    except ImportError:
        raise unittest.SkipTest("these tests require iostream and ioloop")

    class Test(unittest.TestCase):
        # This class is intended for use with multiple threads and may have
        # thread-safety problems. (hence disable ThreadChecker)
        _NO_DAEMON_THREADS = True  # type: bool


# Generated at 2022-06-12 13:12:42.065659
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    with pytest.raises(asyncio.InvalidStateError):
        future_set_result_unless_cancelled(future, None)
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    assert future.cancelled()

# Generated at 2022-06-12 13:12:45.700752
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()



# Generated at 2022-06-12 13:12:54.490680
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception()

    future = Future()
    future.cancel()
    # If this message gets logged, the test was successful.
    future_set_exception_unless_cancelled(future, Exception())
    assert future.cancelled()


if asyncio.Future is Future:
    future_set_result_unless_cancelled = asyncio.Future.set_result
    future_set_exception_unless_cancelled = asyncio.Future.set_exception
    future_add_done_callback = asyncio.Future.add_done_callback


# Generated at 2022-06-12 13:13:00.843342
# Unit test for function chain_future
def test_chain_future():
    if sys.version_info < (3, 7):
        raise Exception('Test cannot run on Python <3.7')

    import asyncio
    import concurrent.futures

    with concurrent.futures.ThreadPoolExecutor() as executor:
        with asyncio.get_event_loop() as loop:
            async def main():
                a = executor.submit(lambda x: x + 1, 12)
                b = asyncio.Future()
                chain_future(a, b)
                assert (await b) == 13

            loop.run_until_complete(main())

# Generated at 2022-06-12 13:13:16.869393
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.testing.gen_test

    @tornado.testing.gen_test
    def test_chain_future_helper() -> None:
        # type: () -> None
        def make_future() -> Future:
            f = Future()
            f.set_result(None)
            return f

        class FutureHolder:
            def __init__(self) -> None:
                self.name = "holder"
                self.called = False

            def callback(self, f: Future) -> None:
                assert f is self.f2
                assert self.f2.done() and not self.f1.done()
                self.called = True

        f1 = make_future()
        f2 = make_future()
        fh = FutureHolder()
        fh.f1 = f

# Generated at 2022-06-12 13:13:23.905686
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # This test does not use the standard unittest.TestCase because the
    # call to future_set_exception_unless_cancelled is expected to raise
    # an exception
    # pylint: disable=too-few-public-methods
    class FutureTestException(Exception):
        pass

    class TestFuture:
        def __init__(self):
            self.cancelled = False
            self.exception_called = False
            self.future_set_exception_called = False

        def set_exception(self, e):  # noqa: A003
            self.exception_called = True
            if not self.cancelled:
                raise FutureTestException("future should not have been cancelled")

        def cancel(self):  # noqa: A003
            self.cancelled = True

    test

# Generated at 2022-06-12 13:13:30.007710
# Unit test for function chain_future
def test_chain_future():
    import functools

    f1 = Future()
    f2 = Future()

    @run_on_executor
    def callback(f2: Future, arg: int) -> None:
        assert f2 is f2
        f2.set_result(arg)

    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.result() == 42

    f1 = Future()
    f2 = Future()
    f2.set_result(None)
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() is None

    f1 = Future()
    f2 = Future()
    f2.set_exception(RuntimeError("error"))
    chain_future(f1, f2)
    f

# Generated at 2022-06-12 13:13:37.848507
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
        raise AssertionError("should get exception")
    except ZeroDivisionError:
        pass



# Generated at 2022-06-12 13:13:43.472524
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    throw_exception = False
    try:
        future_set_exception_unless_cancelled(future, Exception())
    except:
        throw_exception = True
    assert not throw_exception
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-12 13:13:45.663095
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError)
    assert f.cancelled()

# Generated at 2022-06-12 13:13:53.769931
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase
    from tornado import concurrent

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            @gen_test
            def test():  # type: ignore
                result = []
                f1 = concurrent.Future()  # type: Future[int]
                f2 = concurrent.Future()  # type: Future[int]
                f2.add_done_callback(lambda f: result.append(f.result()))
                chain_future(f1, f2)
                f1.set_result(42)
                yield f1
                self.assertEqual(result, [42])

            test()

# Generated at 2022-06-12 13:13:59.596809
# Unit test for function chain_future
def test_chain_future():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest  # type: ignore
    try:
        from unittest import mock  # type: ignore
    except ImportError:
        import mock  # type: ignore

    class FutureTestMixin(object):
        def make_future(self) -> "Future":
            return Future()

        def test_chain_future(self) -> None:
            a = self.make_future()
            b = self.make_future()
            chain_future(a, b)
            self.assertEqual(b.done(), False)
            a.set_result(5)
            self.assertEqual(b.done(), True)
            self.assertEqual(b.result(), 5)

            a = self.make_future()
           

# Generated at 2022-06-12 13:14:09.129167
# Unit test for function chain_future
def test_chain_future():
    async def async_main():
        loop = asyncio.get_event_loop()
        result = []

        async def wait_for_result(future):
            result.append(await future)

        future = Future()
        chain_future(dummy_executor.submit(lambda: 42), future)
        await wait_for_result(future)
        assert result == [42]

        future = loop.create_future()
        chain_future(dummy_executor.submit(lambda: 42), future)
        await wait_for_result(future)
        assert result == [42, 42]

        # Test that it works with multiple chained callbacks
        future = loop.create_future()
        callback = functools.partial(chain_future, dummy_executor.submit(lambda: 42))
        future.add_done_callback

# Generated at 2022-06-12 13:14:13.447873
# Unit test for function chain_future
def test_chain_future():
    async def test_async_function():
        future = asyncio.Future()
        return future

    @run_on_executor
    def yield_future(future):
        yield future

    @gen.coroutine
    def test_chain_future():
        future = test_async_function()
        yield_future(future)

    future = test_chain_future()

# Generated at 2022-06-12 13:14:37.666905
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_result(42)
    assert future2.result() == 42
    assert future3.result() == 42
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_exception(ValueError(123))
    assert isinstance(future2.exception(), ValueError)
    assert future2.exception().args == (123,)
    assert isinstance(future3.exception(), ValueError)
    assert future3.exception().args == (123,)

# Generated at 2022-06-12 13:14:43.373004
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f2, f1)
    f2.set_exception(ValueError())
    assert_raises(ValueError, f1.result)
    f1 = Future()
    f2 = Future()
    # This should no-op (probably) instead of causing an uncaught exception.
    f2.set_result(42)
    chain_future(f2, f1)
    assert f1.done()
    assert f1.result() is None
    f1 = Future()
    f2 = Future()
    # This should no-op (probably)

# Generated at 2022-06-12 13:14:52.294494
# Unit test for function run_on_executor
def test_run_on_executor():
    try:
        from tornado.platform.asyncio import AsyncIOMainLoop

        AsyncIOMainLoop().install()
        import asyncio
    except ImportError:
        asyncio = None

    if asyncio is not None:
        loop = asyncio.get_event_loop()
    else:
        from tornado.platform.asyncio import AsyncIOMainLoop
        import tornado.platform.asyncio

        loop = AsyncIOMainLoop()
        loop.make_current()
        tornado.platform.asyncio.AsyncIOMainLoop().install()

    class Example(object):
        # Use a thread pool with a small thread limit to test that
        # the thread pool is used at all.
        executor = futures.ThreadPoolExecutor(max_workers=1)


# Generated at 2022-06-12 13:14:55.576203
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(None)
    # f2 should now be complete even though we set its result after
    # its completion
    assert f2.done()



# Generated at 2022-06-12 13:14:56.653141
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(id, 'Hello') == type(asyncio.Future())

# Generated at 2022-06-12 13:15:04.737805
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import time
    import unittest

    loop = asyncio.get_event_loop()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()
    f2.set_result(2)
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 2

    f1 = Future()
    f2 = Future()
    f1.set_result(1)
    chain_future(f1, f2)
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()
    f

# Generated at 2022-06-12 13:15:13.968194
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.platform.asyncio

    asyncio.set_event_loop(tornado.platform.asyncio.AsyncIOMainLoop())

    class Foo:
        executor = dummy_executor
        _thread_pool = dummy_executor

        @run_on_executor
        def foo(self):
            pass

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            pass

    foo = Foo()

    with unittest.mock.patch.object(Foo.executor, "submit") as submit:
        foo.foo()

# Generated at 2022-06-12 13:15:22.317485
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import shutil
    import os
    import tempfile

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            fut = Future()
            fut2 = Future()

            chain_future(fut, fut2)

            fut.set_result(42)
            self.assertEqual(42, fut2.result())

            fut = Future()
            fut2 = Future()

            chain_future(fut, fut2)

            fut.set_exception(RuntimeError("test"))
            self.assertEqual(type(fut2.exception()), RuntimeError)
            self.assertEqual(fut2.exception().args[0], "test")

            # Check that second future is not completed if the first is already done.
            fut = Future()

# Generated at 2022-06-12 13:15:29.522769
# Unit test for function chain_future
def test_chain_future():
    import time

    # Test the Future
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42

    # Test the concurrent.futures.Future
    f3 = futures.Future()
    f4 = Future()
    chain_future(f3, f4)
    assert not f4.done()
    f3.set_result(42)
    # Previous versions allowed the IOLoop to be used as a callback,
    # so allow this test to pass in the old and new ways
    if isinstance(f4.result(), int):
        assert f4.result() == 42

# Generated at 2022-06-12 13:15:35.818669
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor()
    def f(x, y):
        return x * y

    async def main():
        a = f(4, 5)
        b = f(a, 6)
        c = f(a, a)
        assert (await a) == 20
        assert (await b) == 120
        assert (await c) == 400

    import tornado.platform.asyncio
    import asyncio
    io_loop = tornado.platform.asyncio.AsyncIOLoop()
    asyncio.set_event_loop(io_loop.asyncio_loop)
    io_loop.run_sync(main)

# Generated at 2022-06-12 13:16:12.475982
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():  # type: ignore
    future = Future()  # type: Future[int]
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10

    future1 = Future()  # type: Future[int]
    future1.cancel()
    future_set_result_unless_cancelled(future1, 110)
    assert not future1.result()

    @asyncio.coroutine
    def main() -> None:
        future = Future()  # type: Future[int]
        future_set_result_unless_cancelled(future, 10)
        ret = yield future
        assert ret == 10

        future1 = Future()  # type: Future[int]
        future1.cancel()
        future_set_result_unless_cancelled(future1, 110)

# Generated at 2022-06-12 13:16:16.156466
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    # The callback should have been run immediately
    assert b.done()
    assert b.result() is None
    a.set_result(42)
    assert b.result() == 42
    c = Future()
    chain_future(b, c)
    assert c.result() == 42
    a.set_result(24)
    assert c.result() == 42

# Generated at 2022-06-12 13:16:19.854616
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda *args, **kwargs: (args, kwargs), 1, 2, 3, a=1, b=2)
    assert future.result() == ((1, 2, 3), {'a': 1, 'b': 2})


# Generated at 2022-06-12 13:16:26.633087
# Unit test for function chain_future
def test_chain_future():
    import time

    @gen.coroutine
    def f():
        yield gen.moment
        raise gen.Return(42)

    def add(x, y):
        return x + y

    def error(x, y):
        raise Exception("error")

    def slow_add(x, y):
        time.sleep(0.01)
        return x + y

    @gen.coroutine
    def test_chain(f1, f2, combine, combine_exc, x, y):
        future1 = f1(x, y)
        future2 = f2(x, y)
        f1_result = yield future1
        f2_result = yield future2
        assert combine(x, y) == f1_result
        assert f1_result == f2_result


# Generated at 2022-06-12 13:16:31.120744
# Unit test for function chain_future
def test_chain_future():
    async def func(fn):
        await asyncio.sleep(1)
        assert fn(1, 2) == 3

    def fn(x, y):
        return x + y

    loop = asyncio.get_event_loop()
    future = loop.create_future()
    future2 = loop.create_future()
    chain_future(future, future2)
    loop.run_until_complete(func(fn))

# Generated at 2022-06-12 13:16:38.128428
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    class TestFuture(Future):
        def __init__(self) -> None:
            super(TestFuture, self).__init__()
            self.exception_set = False

        def set_exception(self, exception: BaseException) -> None:
            self.exception_set = True
            super(TestFuture, self).set_exception(exception)

    class TestException(Exception):
        pass

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        def setUp(self) -> None:
            self.future = TestFuture()

        def test_future_set_exception_unless_cancelled(self) -> None:
            self.future.cancel()
            try:
                1 / 0
            except Exception as e:
                future_set_exception

# Generated at 2022-06-12 13:16:41.854792
# Unit test for function chain_future
def test_chain_future():
    a, b = Future(), Future()

    chain_future(a, b)
    a.set_exception(RuntimeError())
    assert b.done()

    c, d = Future(), Future()
    chain_future(c, d)
    c.set_result(1)
    assert d.result() == 1



# Generated at 2022-06-12 13:16:48.612251
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def assert_is_cancelled(result):
        assert result.exception() is asyncio.CancelledError
        assert result.cancelled()

    future = asyncio.Future()
    future.set_result(42)
    future_set_exception_unless_cancelled(future, Exception())
    assert future.result() == 42
    assert not future.cancelled()
    assert not future.exception()

    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    future.add_done_callback(assert_is_cancelled)


# Generated at 2022-06-12 13:16:57.274344
# Unit test for function chain_future
def test_chain_future():
    @typing.no_type_check
    def assert_future_state(
        future: "Future", expected_exc_info: Optional[Tuple[Optional[type], BaseException, types.TracebackType]]
    ) -> None:
        if expected_exc_info is None:
            assert not future.exception()
            assert future.result() == 1
        else:
            if future.exception() is not None:
                assert future.exception() == expected_exc_info[1]
            else:
                assert False, "Expected %r, got %r" % (expected_exc_info[1], future.result())


# Generated at 2022-06-12 13:17:00.327202
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    def cancel():
        future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    future_set_exception_unless_cancelled(future, Exception())
    future_add_done_callback(future, cancel)

# Generated at 2022-06-12 13:18:06.194944
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.concurrent import Future

    impl = {}  # type: Dict[str, Any]
    a = Future()
    b = Future()
    chain_future(a, b)
    impl["result"] = None

    def copy(future):
        # type: (Future[str]) -> None
        impl["result"] = future.result()

    b.add_done_callback(copy)

    assert impl["result"] is None
    a.set_result("foo")
    assert impl["result"] == "foo"

    try:
        a.set_result("bar")
    except Exception:
        pass
    else:
        assert False, "second set_result should have raised an exception"

    assert impl["result"] == "foo"

# Generated at 2022-06-12 13:18:12.084329
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    assert asyncio.iscoroutinefunction(future_set_result_unless_cancelled)

    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.set_result(None)
    future_set_result_unless_cancelled(future, 42)
    assert future.result() is None

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() is None



# Generated at 2022-06-12 13:18:20.157749
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    assert not f2.cancelled()

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_exception(ValueError("spam"))
    try:
        f2.result()
    except ValueError as e:
        assert str(e) == "spam"
    else:
        assert False, "didn't get expected exception"

    f1 = Future()  # type: Future[

# Generated at 2022-06-12 13:18:28.371352
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    result = []  # type: typing.List[int]
    ioloop = IOLoop.current()

    def callback(future):
        # type: (Future[int]) -> None
        assert future is f
        assert future.result() == 42
        result.append(1)
        ioloop.stop()

    chain_future(f, Future())
    chain_future(f, Future())
    chain_future(f, Future())
    chain_future(f, f)
    chain_future(f, Future())
    chain_future(f, Future())
    ioloop.add_future(f, callback)
    f.set_result(42)
    ioloop.start()
    assert result == [1]



# Generated at 2022-06-12 13:18:29.716604
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)



# Generated at 2022-06-12 13:18:34.951238
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    from tornado import ioloop
    from tornado.testing import AsyncTestCase, gen_test

    class A(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self._executor = futures.ThreadPoolExecutor(max_workers=2)

        def tearDown(self):
            super().tearDown()
            self._executor.shutdown()

        @run_on_executor
        def async_future_test(self, num):
            return num

        @gen.coroutine
        def test_chain_future(self):
            f1 = self.async_future_test(1)
            f2 = self.async_future_test(2)
            f3 = self.async_future_test(3)

            f4 = Future()
           

# Generated at 2022-06-12 13:18:39.819472
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock
    # mock.Mock is not recommended for new code, but we just want
    # to check that it's called or not.
    future = unittest.mock.Mock()
    # Simulate cancelling the future.
    future.done.return_value = True
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-12 13:18:48.167320
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    def check_chain(future, callback):
        assert isinstance(future, Future)
        assert isinstance(callback, types.FunctionType)
        future_add_done_callback(future, callback)

    conc_future = futures.Future()
    async_future = Future()
    chain_future(conc_future, async_future)

    with unittest.mock.patch("tornado.concurrent.chain_future") as cf:
        cf.side_effect = check_chain

        class Foo:
            executor = dummy_executor

            @run_on_executor
            def foo(self, arg):
                assert arg == 3
                return arg

            @run_on_executor
            def bar(self, arg):
                assert arg == 3
                raise KeyError("foo")

# Generated at 2022-06-12 13:18:54.140110
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.test.util import unittest

    source = Future()
    target = Future()

    chain_future(source, target)

    @gen.coroutine
    def check(result):
        ret = yield target
        self.assertEqual(ret, result)

    IOLoop.current().add_callback(check, 42)
    IOLoop.current().add_callback(source.set_result, 42)
    IOLoop.current().add_callback(IOLoop.current().stop)
    IOLoop.current().start()

# Generated at 2022-06-12 13:18:58.570814
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado import testing

    async def f():
        await gen.sleep(0.01)
        return 42

    @gen.coroutine
    def test():
        cf1 = Future()
        cf2 = Future()
        chain_future(cf1, cf2)
        cf1.set_result(42)
        result = yield cf2
        raise gen.Return(result)
    testing.run_sync(test)
    result = Future()
    chain_future(f(), result)
    testing.run_sync(lambda: result)
    assert result.result() == 42

