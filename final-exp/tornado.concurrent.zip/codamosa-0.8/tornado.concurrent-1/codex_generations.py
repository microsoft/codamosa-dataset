

# Generated at 2022-06-12 13:09:55.912911
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = dummy_executor

        @run_on_executor(executor="executor")
        def blocking_io(self):
            pass

        @gen_test
        def test_chain_future(self):
            # Create a future that completes without a result
            fut1 = Future()
            fut1.set_result(None)
            # Create a blocking stub for an executor
            fut2 = yield gen.with_timeout(
                self.io_loop.time(), self.blocking_io(), timeout_value="foo"
            )

# Generated at 2022-06-12 13:09:57.199854
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-12 13:10:07.682182
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    async def async_func():
        # type: () -> None
        await asyncio.sleep(0.1)
        return "succeeded"

    def synchronous_func():
        # type: () -> None
        return "succeeded"

    def check_chain(future):
        # type: (Future) -> None
        tornado.testing.assert_equal(future.result(), "succeeded")

    def error_chain(future):
        # type: (Future) -> None
        tornado.testing.assert_equal(future.exception().args[0], "failed")

    f1 = Future()  # type: Future
    f2 = Future()  # type: Future
    f3 = Future()  # type: Future

# Generated at 2022-06-12 13:10:14.373968
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(ZeroDivisionError())
    assert isinstance(g.exception(), ZeroDivisionError)
    f = Future()
    g = Future()
    f.set_exception(ZeroDivisionError())
    chain_future(f, g)
    assert isinstance(g.exception(), ZeroDivisionError)

# Generated at 2022-06-12 13:10:22.090056
# Unit test for function chain_future
def test_chain_future():
    main = Future()
    aux = Future()
    chain_future(aux, main)
    assert not main.done()
    aux.set_result(3)
    assert main.done()
    assert main.result() == 3
    # Now reverse the order
    main = Future()
    aux = Future()
    chain_future(aux, main)
    assert not main.done()
    main.set_result(5)
    assert main.done()
    assert main.result() == 5



# Generated at 2022-06-12 13:10:30.973918
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class Foo:
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            pass

    foo = Foo()
    foo.foo()

    with unittest.mock.patch.object(foo.executor, "submit") as submit:
        foo.foo()
        submit.assert_called_once_with(foo.foo, foo)

    class Bar:
        _thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def foo(self):
            pass

    bar = Bar()
    with unittest.mock.patch.object(bar._thread_pool, "submit") as submit:
        bar.foo()

# Generated at 2022-06-12 13:10:40.001850
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class TestCase(object):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.executor = futures.ThreadPoolExecutor(2)
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close()

        def test_run_on_executor_decorator(self):
            @run_on_executor
            def f(self, x, y):
                self.io_loop.add_callback(self.stop)
                return x + y

            self.wait = self

# Generated at 2022-06-12 13:10:44.064239
# Unit test for function chain_future
def test_chain_future():
    from tornado import testing

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.set_result(42)
    f1.set_result(1729)
    f2.set_result(24)

    assert f2.result() == 42



# Generated at 2022-06-12 13:10:45.252159
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert run_on_executor()(lambda self: self)


# Generated at 2022-06-12 13:10:51.411103
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Test that chain_future works with both Tornado and asyncio futures
    executor = DummyExecutor()
    chain_future(futures.Future(), Future())
    chain_future(Future(), futures.Future())
    chain_future(Future(), Future())
    f = Future()
    chain_future(executor.submit(lambda: 1), f)
    assert f.result() == 1
    f = Future()
    chain_future(
        executor.submit(lambda: 1 / 0),
        f,
    )
    assert isinstance(f.exception(), ZeroDivisionError)

# Generated at 2022-06-12 13:11:03.411703
# Unit test for function chain_future
def test_chain_future():
    """
    Unit test for Tornado's chain_future

    References: #1704, #2144 and #2148
    """
    from concurrent.futures import Future as ConcurrentFuture
    import asyncio
    from tornado.log import gen_log
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.concurrent_future = ConcurrentFuture()
            self.async_future = Future()

        def tearDown(self):
            self.concurrent_future.cancel()
            self.async_future.cancel()
            super(TestChainFuture, self).tearDown()


# Generated at 2022-06-12 13:11:07.723613
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)  # should set b's result to 42
    assert b.result() == 42
    future_set_result_unless_cancelled(b, 24)
    # b is already done so the second call should not have any effect
    assert b.result() == 42



# Generated at 2022-06-12 13:11:15.007344
# Unit test for function run_on_executor
def test_run_on_executor():
    executor = futures.ThreadPoolExecutor(1)

    class FutureHolder:
        def __init__(self):
            self.future = None  # type: typing.Optional[futures.Future]
            self.exc_info = None  # type: typing.Optional[Tuple[None, None, None]]

        def set_result(self, _):
            assert self.future is not None
            assert self.exc_info is None
            self.future.set_result(None)

        def set_exc_info(self, exc_info: Tuple[None, None, None]):
            assert self.future is not None
            assert self.exc_info is None
            self.exc_info = exc_info
            self.future.set_result(None)

    class Foo:
        executor = executor

       

# Generated at 2022-06-12 13:11:22.027139
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # This test is in `tornado.test.concurrent_test` because it needs
    # to use the old QueueFuture class to test that it is compatible
    # with this function's argument type.
    from tornado.test.concurrent_test import QueueFuture

    f1 = QueueFuture()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.result()



# Generated at 2022-06-12 13:11:30.908747
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut1.set_result(3)
    assert fut2.result() == 3
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut2.set_result(4)
    fut1.set_result(3)
    assert fut2.result() == 4
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut1.set_exception(ZeroDivisionError)
    assert fut2.exception() is not None
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut2

# Generated at 2022-06-12 13:11:41.239555
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert f2.done() is False

    f1.set_result("foo")
    assert f2.result() == "foo"
    assert f2.exception() is None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    with pytest.raises(ZeroDivisionError):
        f2.result()

    # Test that a second callback to chain_future is no-op.
    f3 = Future()
    chain_future(f2, f3)
    assert f3.done() is True
    assert f3.ex

# Generated at 2022-06-12 13:11:48.072697
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_result(42)

    @io_loop.add_future
    def check_f2(fut):
        assert fut is f2
        assert fut.result() == 42
        io_loop.stop()

    io_loop.start()



# Generated at 2022-06-12 13:11:56.156361
# Unit test for function chain_future
def test_chain_future():
    import asyncio
    import tornado.testing

    @tornado.testing.gen_test
    async def f():
        f1, f2 = (Future(), Future())
        chain_future(f1, f2)
        f1.set_result(42)
        assert await f2 == 42
        f1, f2 = (Future(), Future())
        chain_future(f1, f2)
        f1.set_exception(ZeroDivisionError())
        with pytest.raises(ZeroDivisionError):
            await f2


# Generated at 2022-06-12 13:12:00.001957
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future1 = Future()
    future_set_exception_unless_cancelled(future1, KeyError())
    assert future1.exception() is not None

    future2 = Future()
    future2.cancel()
    future_set_exception_unless_cancelled(future2, KeyError())
    assert future2.exception() is None

# Generated at 2022-06-12 13:12:03.375679
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def make():
        f = Future()
        f.cancel()
        return f
    for f in make(), futures.Future():
        exc = RuntimeError("x")
        future_set_exception_unless_cancelled(f, exc)
        assert f.exception() is exc

# Generated at 2022-06-12 13:12:07.622329
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda x: x + 1, 3)

# Generated at 2022-06-12 13:12:14.806622
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent.futures import ThreadPoolExecutor
    import time

    class ReturnExecutor(object):
        def __init__(self):
            self.executor = ThreadPoolExecutor(1)

        @run_on_executor(executor="executor")
        def return_executor(self, arg1, arg2, kwarg=True):
            """
            Return the executor
            """
            return self.executor

        @run_on_executor()
        def return_args(self, arg1, arg2, kwarg=True):
            """
            Return the args
            """
            return arg1, arg2, kwarg

    class ReturnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.ex = ReturnExecutor()



# Generated at 2022-06-12 13:12:19.718197
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop

    loop = AsyncIOMainLoop()
    loop.make_current()

    async def main():
        future1 = Future()
        future2 = Future()
        future2.set_result(10)
        chain_future(future1, future2)
        await asyncio.sleep(0.01)
        future1.set_result(5)

    loop.run_sync(main)

# Generated at 2022-06-12 13:12:28.165800
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    import tornado.testing

    loop = IOLoop.current()
    async_future = Future()

    def on_future_done(f: "Future[_T]") -> None:
        assert f is conc_future
        assert conc_future.result() == 1
        async_future.set_result(conc_future.result())

    conc_future = futures.Future()

    chain_future(conc_future, async_future)
    future_add_done_callback(conc_future, on_future_done)
    conc_future.set_result(1)

    @tornado.gen.coroutine
    def test():
        assert (yield async_future) == 1

    loop.run_sync(test)



# Generated at 2022-06-12 13:12:32.426801
# Unit test for function chain_future
def test_chain_future():
    import time

    def run_test(future_class: "type[Future]") -> None:

        # Check a simple chain.
        a = future_class()
        b = future_class()
        chain_future(a, b)
        assert not a.done()
        assert not b.done()
        a.set_result(42)
        assert a.done()
        assert b.done()
        assert b.result() == 42

        # Check that cancelling the source future doesn't cancel the target.
        a = future_class()
        b = future_class()
        chain_future(a, b)
        assert not a.done()
        assert not b.done()
        a.cancel()
        assert a.cancelled()
        assert not b.done()
        a.set_result(42)


# Generated at 2022-06-12 13:12:38.343019
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        @gen_test
        def test(self):
            f = Future()
            f.cancel()
            try:
                f.set_exception(Exception())
            except asyncio.InvalidStateError:
                pass
            else:
                self.fail("Exception not raised")
            future_set_exception_unless_cancelled(f, Exception())
            try:
                yield f
            except Exception:
                pass
            else:
                self.fail("Exception not set")

# Generated at 2022-06-12 13:12:43.684187
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception("testing")
    future_set_exception_unless_cancelled(future, exc)
    assert (future.exception() == exc)
    future = Future()
    future_set_exception_unless_cancelled(future, None)
    assert (future.exception() is None)
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert (future.exception() is None)

# Generated at 2022-06-12 13:12:47.908507
# Unit test for function chain_future
def test_chain_future():
    import unittest

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result('test')
            b.add_done_callback(lambda f: self.assertEqual(f.result(), 'test'))

# Generated at 2022-06-12 13:12:55.265738
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_exception(Exception("Exception1"))
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("Exception2"))

__all__ = [
    "DummyExecutor",
    "Future",
    "ReturnValueIgnoredError",
    "dummy_executor",
    "is_future",
    "run_on_executor",
    "chain_future",
    "future_set_result_unless_cancelled",
    "future_set_exception_unless_cancelled",
    "future_set_exc_info",
    "future_add_done_callback",
]

# Generated at 2022-06-12 13:12:58.674586
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()
    f1.set_result(42)
    assert f1.result() == 42
    assert f2.result() == 42



# Generated at 2022-06-12 13:13:12.042401
# Unit test for function run_on_executor
def test_run_on_executor():
    test_wait = False
    test_threshold = 0.01
    counter = [0]
    lock = asyncio.Lock()

    class Loop:
        def __init__(self):
            self.io_loop = self

        def run_in_executor(
            self, executor, callback, *args, **kwargs
        ):  # type: ignore
            callback(*args, **kwargs)

    loop = Loop()

    class Obj:
        executor = dummy_executor

        @run_on_executor
        def meth(self, x):
            with lock:
                counter[0] += x
                return counter[0]

    obj = Obj()

    def incr():
        obj.meth(1)
        obj.meth(2)
        obj.meth(3)


# Generated at 2022-06-12 13:13:19.961221
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import pytest
    from tornado.log import access_log
    from tornado.testing import AsyncTestCase, gen_test

    class FutureSetExceptionUnlessCancelledTest(AsyncTestCase):
        def test_exception_unless_cancelled(self):
            with access_log.catch_logging():
                f = Future()
                f.cancel()
                future_set_exception_unless_cancelled(f, ValueError("foo"))
                self.assertTrue(f.cancelled())
                self.assertFalse(f.done())

        def test_exception_unless_cancelled_gen(self):
            with access_log.catch_logging():
                @gen_test
                def test_future_set_exception_unless_cancelled():
                    f = Future()
                    f.cancel()

# Generated at 2022-06-12 13:13:26.758603
# Unit test for function chain_future
def test_chain_future():
    def f(result):
        return result + 1

    # Test chaining from Future to Future
    a = Future()
    b = Future()
    assert not a.done()
    assert not b.done()
    chain_future(a, b)

    a.set_result(1)
    assert b.result() == 1

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(ValueError())
    exc_info = None
    try:
        b.result()
    except Exception:
        exc_info = sys.exc_info()
    assert exc_info[1].args[0] == 'ValueError()'

    # Test chaining from Future to concurrent.futures.Future
    a = Future()
    b = futures.Future()

# Generated at 2022-06-12 13:13:28.793312
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42

# Generated at 2022-06-12 13:13:40.054979
# Unit test for function chain_future

# Generated at 2022-06-12 13:13:48.982164
# Unit test for function chain_future
def test_chain_future():
    import unittest

    def f1(x, y):
        return x + y

    def f2(x, y):
        raise Exception("hello")

    class T(unittest.TestCase):
        def setUp(self):
            self.ioloop = asyncio.get_event_loop()

        def test_1(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_result(1)

        def test_2(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_exception(Exception("hello"))

        def test_3(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            i

# Generated at 2022-06-12 13:13:57.771624
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert isinstance(f.exception(), ValueError)

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.cancelled()

    # Ideally would use unittest.mock, but we still support py27
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class ExceptionLogger:
        def __init__(self):
            self.exception = None

        def error(self, msg, exc_info):
            self.exception = exc_info[1]

    logger = ExceptionLogger()
    old_logger = app_log.logger


# Generated at 2022-06-12 13:14:07.494090
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    test_exc = Exception("test_future_set_exception_unless_cancelled")

    # Set the future's exception
    future_set_exception_unless_cancelled(test_future, test_exc)

    # Check future's exception and ensure exception is the same as above
    assert test_future.exception() is not None
    assert test_future.exception() == test_exc

    # Cancel the future to test that the above exception is not logged
    test_future.cancel()

    # Set the future's exception again
    future_set_exception_unless_cancelled(test_future, test_exc)

    # Check that the exception was not logged
    assert test_future.exception() is None

# Generated at 2022-06-12 13:14:16.241154
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import sys
    import threading
    import functools
    import time

    class MyThreadPool(threading.ThreadPoolExecutor):
        def __init__(self, *args, **kwargs):
            self.sleep = kwargs.pop('sleep', 0)
            self.start_time = time.time()
            super(MyThreadPool, self).__init__(*args, **kwargs)

        def submit(self, fn, *args, **kwargs):
            @functools.wraps(fn)
            def wrapped_fn(*args, **kwargs):
                time.sleep(self.sleep)
                return fn(*args, **kwargs)
            return super(MyThreadPool, self).submit(
                wrapped_fn, *args, **kwargs)


# Generated at 2022-06-12 13:14:18.436170
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'value')
    assert future.result() == 'value'
    future = Future()
    future.cancel()
    futur

# Generated at 2022-06-12 13:14:30.534108
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    f = Future()
    future_set_result_unless_cancelled(f, 3)
    assert f.result() == 3

    f.cancel()
    future_set_result_unless_cancelled(f, 3)
    assert f.cancelled()



# Generated at 2022-06-12 13:14:33.094260
# Unit test for function chain_future
def test_chain_future():
    first = Future()
    second = Future()
    chain_future(first, second)
    first.set_result(None)
    assert second.done()



# Generated at 2022-06-12 13:14:40.926652
# Unit test for function chain_future
def test_chain_future():
    f1 = asyncio.Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.result() == 42
    f3 = Future()
    chain_future(f2, f3)
    assert f3.result() == 42
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    f4 = Future()
    chain_future(f3, f4)
    f1.set_exception(exc_info[1])
    assert f2.exception() is exc_info[1]
    assert f3.exception() is exc_info[1]
    assert f4.exception() is exc_info[1]

# Generated at 2022-06-12 13:14:50.345745
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class TestRunOnExecutor(unittest.TestCase):
        class Thing(typing.Generic[_T]):
            executor = dummy_executor

            def __init__(self, value: _T):
                self.value = value

            @run_on_executor
            def get_value(self) -> _T:
                return self.value

        def run_test(self, value: Any) -> None:
            for use_future in (True, False):
                thing = TestRunOnExecutor.Thing(value)
                if not use_future:
                    thing.get_value()  # type: ignore
                result = thing.get_value()
                if use_future:
                    result = result.result()
                self.assertEqual(result, value)


# Generated at 2022-06-12 13:14:57.083996
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = asyncio.Future()

    # In order to catch any logs, run in a separate context
    # that we can flush afterwards.
    with futures.ThreadPoolExecutor(1) as executor:
        executor.submit(future_set_exception_unless_cancelled, fut, Exception("err"))
        executor.submit(fut.cancel)
        executor.submit(future_set_exception_unless_cancelled, fut, Exception("err"))
        executor.submit(future_set_exception_unless_cancelled, fut, Exception("err"))

    # We expect to see two log entries with two different messages,
    # since .cancel() sets the future's exception to None.
    log_stream.seek(0)

# Generated at 2022-06-12 13:15:00.945963
# Unit test for function chain_future
def test_chain_future():
    async def async_test():
        f1 = Future() # type: Future
        f2 = Future() # type: Future
        chain_future(f1, f2)
        def cb(f2):
            # calling f2.done() directly doesn't work here because
            # f2.set_result() triggers the callback synchronously.
            if not f2.done():
                raise Exc

# Generated at 2022-06-12 13:15:09.514002
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from tornado.ioloop import IOLoop

    ioloop = IOLoop()
    ioloop.make_current()

    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def return_value(self):
            # type: () -> int
            return 42

        @run_on_executor
        def raise_error(self):
            # type: () -> None
            raise Exception("exception!")

        @run_on_executor(executor="_thread_pool")
        def return_value_alternate_executor(self):
            # type: () -> int
            return 42


# Generated at 2022-06-12 13:15:15.064219
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()
    f = asyncio.Future(loop=loop)
    result = object()
    future_set_result_unless_cancelled(f, result)
    assert f.result() is result

    f = asyncio.Future(loop=loop)
    f.cancel()
    future_set_result_unless_cancelled(f, result)
    assert f.cancelled()

# Generated at 2022-06-12 13:15:18.683338
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(x, y):
        return x + y

    future1 = dummy_executor.submit(f, 2, 3)
    assert future1.done()
    assert future1.result() == 5


if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-12 13:15:21.368869
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def func():
        pass

    task = asyncio.ensure_future(func())

    task.cancel()

    try:
        future_set_result_unless_cancelled(task, 1)
    except Exception:
        pass

# Generated at 2022-06-12 13:15:38.692103
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is not None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is None

# Generated at 2022-06-12 13:15:46.667727
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import time

    class MyTest(unittest.TestCase):
        def test_chain_future(self):
            try:
                from concurrent.futures import Future  # type: ignore
            except ImportError:
                self.assertTrue(str(sys.exc_info()[1]).find("Future") != -1)
                return

            # Check that result and exception are copied to the second
            # future in either order
            f1 = Future()
            f2 = Future()
            f1.set_result(42)
            chain_future(f1, f2)
            self.assertEqual(f2.result(), 42)
            f1 = Future()
            f2 = Future()
            f2.set_result(42)

# Generated at 2022-06-12 13:15:54.868788
# Unit test for function chain_future
def test_chain_future():
    outer = Future()
    inner = Future()
    chain_future(inner, outer)
    assert not outer.done()
    inner.set_result(42)
    assert outer.done()
    assert outer.result() == 42
    result = [None]
    outer2 = Future()
    chain_future(outer, outer2)
    outer2.add_done_callback(lambda f: result.append(f.result()))
    outer.set_result(24)
    assert result == [None, 24]
    result = [None]
    outer3 = Future()
    outer3.cancel()
    chain_future(outer, outer3)
    outer3.add_done_callback(lambda f: result.append(f.result()))
    outer.set_result(48)
    assert result == [None, None]

# Generated at 2022-06-12 13:16:04.527516
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.log import app_log

    class DummyLogHandler(object):
        def __init__(self):
            self.emitted_error = False

        def handle(self, record):
            if record.levelno >= app_log.ERROR:
                self.emitted_error = True

    loop = IOLoop()
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("foo"))
    assert future.exception()

    future = Future()
    future.cancel()
    log_handler = DummyLogHandler()
    app_log.addHandler(log_handler)
    future_set_exception_unless_cancelled(future, ValueError("foo"))
    assert not future.exception()

# Generated at 2022-06-12 13:16:10.251921
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = ValueError()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    exc = ValueError()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-12 13:16:12.819674
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("foo"))
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("bar"))

# Generated at 2022-06-12 13:16:20.257004
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(3)
    assert f2.result() == 3
    f2 = Future()
    chain_future(f1, f2)
    assert f2.result() == 3
    f1 = Future()
    f2 = Future()
    f1.set_result(5)
    chain_future(f1, f2)
    assert f2.result() == 5
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(KeyError())
    with tornado_assert_raises_regex(KeyError, ""):
        f2.result()

# Generated at 2022-06-12 13:16:27.023722
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import mock

    class FutureTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.result = None
            self.exc_info = None
            self.f1 = Future()  # type: Future[int]
            self.f2 = Future()  # type: Future[int]

        def callback(self, future):
            # type: (Future) -> None
            try:
                self.result = future.result()
            except:
                self.exc_info = sys.exc_info()

        def test_result(self):
            # type: () -> None
            self.f1.set_result(42)
            chain_future(self.f1, self.f2)
            self.f2

# Generated at 2022-06-12 13:16:32.788492
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    f = Future()
    future_set_result_unless_cancelled(f, 'a')
    assert f.result() == 'a'
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 'b')
    assert f.cancelled()
    f = Future()
    f.set_result('c')
    future_set_result_unless_cancelled(f, 'd')
    assert f.result() == 'c'

# Generated at 2022-06-12 13:16:40.254709
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from . import gen
    from .platform.asyncio import AsyncIOMainLoop

    if (isinstance(gen.coroutine, types.FunctionType)
            and sys.version_info >= (3, 5)):

        async def async_fn():
            return 42

        def sync_fn():
            return 42

        class A:
            executor = dummy_executor

            # Note: there is a mismatch between the executor's Future class
            # and the method's return value here that requires annotating
            # the Future explicitly.
            @run_on_executor
            def sync_future(self) -> Future:
                return 42

            @run_on_executor
            def sync_await(self):
                return sync_fn()


# Generated at 2022-06-12 13:17:17.683432
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    import tornado.testing
    import concurrent.futures

    class UsingRunOnExecutor(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, x, y, callback=None):
            return x + y

        def test_func(self, callback):
            future = self.func(1, 2, callback=callback)
            IOLoop.current().add_future(future, lambda f: callback(f.result()))

        @run_on_executor()
        def func2(self, x, y):
            return x + y


# Generated at 2022-06-12 13:17:21.572715
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'test value')
    assert future.done() == True
    result = future.result()
    assert result == 'test value'

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'test value')
    assert future.done() == False

# Generated at 2022-06-12 13:17:30.508728
# Unit test for function chain_future
def test_chain_future():
    import functools
    import unittest

    from tornado.ioloop import IOLoop

    class FutureChainTest(unittest.TestCase):
        def setUp(self):
            self.loop = IOLoop()
            self.on_done_called = False
            self.result = None
            self.exc_info = None

        def on_done(self, future):
            self.on_done_called = True
            try:
                self.result = future.result()
            except Exception:
                self.exc_info = sys.exc_info()

        def test_chain_future_asyncio_compat(self):
            future1 = Future()
            future2 = Future()
            chain_future(future1, future2)

            future1.set_result(42)


# Generated at 2022-06-12 13:17:38.937877
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.test.util

    import asyncio

    def result_callback(future: Future) -> None:
        tornado.test.util.stop()

    @asyncio.coroutine
    def run_test():
        a = Future()
        future_add_done_callback(a, result_callback)
        a.set_result(42)
        assert a.result() == 42
        tornado.testing.gen_test_wait(.1)
        b = Future()
        future_add_done_callback(b, result_callback)
        chain_future(a, b)
        assert b.result() == 42
        tornado.testing.gen_test_wait(.1)

    tornado.testing.gen_test(run_test)()



# Generated at 2022-06-12 13:17:48.677005
# Unit test for function chain_future
def test_chain_future():
    import unittest

    def make_future_with_callbacks():
        f = Future()
        cb = []

        def handle_callback(future):
            cb.append(future)

        f.add_done_callback(handle_callback)
        return f, cb

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1, cb1 = make_future_with_callbacks()
            f2, cb2 = make_future_with_callbacks()

            chain_future(f1, f2)
            self.assertEqual(0, len(cb1))
            self.assertEqual(0, len(cb2))

            f1.set_result(42)
            self.assertEqual(1, len(cb1))
            self

# Generated at 2022-06-12 13:17:51.355091
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    assert f.cancelled()
    future_set_exception_unless_cancelled(f, RuntimeError("test"))
    assert f.cancelled()

# Generated at 2022-06-12 13:17:57.155869
# Unit test for function chain_future
def test_chain_future():
    assert not hasattr(test_chain_future, "was_called")

    def future1_done_callback(future):
        assert future.result() == "result"
        assert hasattr(test_chain_future, "was_called")
        test_chain_future.was_called = True

    a = Future()
    b = Future()
    chain_future(a, b)
    assert not hasattr(test_chain_future, "was_called")
    a.set_result("result")
    assert hasattr(test_chain_future, "was_called")
    b.result()



# Generated at 2022-06-12 13:18:01.456115
# Unit test for function chain_future
def test_chain_future():
    def assert_raises(exc, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
            assert False, "did not get expected exception"
        except exc:
            pass

    # Callbacks added before the future is done are called.
    f1 = Future()
    results = []
    future_add_done_callback(f1, results.append)
    future_set_result_unless_cancelled(f1, 5)
    assert results == [f1], results

    # Callbacks added after the future is done are called immediately.
    results = []
    future_add_done_callback(f1, results.append)
    assert results == [f1], results

    # Callbacks added before the future is done are called even on error.
    f1 = Future()

# Generated at 2022-06-12 13:18:07.116387
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    async def async_func():
        future = Future()
        future_set_result_unless_cancelled(future, 'value')
        assert future.result() == 'value'
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 'value')
        assert future.cancelled()

    loop.run_until_complete(async_func())
    loop.close()

# Generated at 2022-06-12 13:18:15.455149
# Unit test for function chain_future
def test_chain_future():
    async def test_main():
        a = Future()
        b = Future()
        chain_future(a, b)

        a.set_result(42)
        assert b.result() == 42

        # When `b` is already cancelled, the result of `a` is not copied
        b = Future()
        b.cancel()
        chain_future(a, b)
        assert not b.cancelled()

        # Similarly, when `a` fails, the result is not copied if `b` is already
        # cancelled
        a = Future()
        b = Future()
        b.cancel()
        chain_future(a, b)
        a.set_exception(ZeroDivisionError)
        assert b.cancelled()

        b = Future()
        chain_future(a, b)

# Generated at 2022-06-12 13:19:28.090963
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future = Future()  # type: Future
    result = Future()  # type: Future
    chain_future(future, result)
    future.set_result(42)
    assert result.done()
    assert result.result() == 42
    future = Future()  # type: Future
    result = Future()  # type: Future
    chain_future(future, result)
    future.set_exception(RuntimeError('test'))
    assert result.done()
    assert isinstance(result.exception(), RuntimeError)
    future = Future()  # type: Future
    result = Future()  # type: Future
    result.cancel()
    chain_future(result, future)
    assert future.cancelled()

# Generated at 2022-06-12 13:19:31.565501
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    assert not f.done()

    future_set_result_unless_cancelled(f, 1)
    assert f.done()
    assert f.result() == 1

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()



# Generated at 2022-06-12 13:19:36.988668
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import pytest
    import tornado.ioloop
    import time

    future = asyncio.Future()
    exception = Exception()
    future_set_exception_unless_cancelled(future, exception)
    future.set_result(None)
    assert future.done()
    assert not future.cancelled()
    assert not future.exception()

    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, exception)
    future.cancel()

    with pytest.raises(tornado.ioloop.TimeoutError):
        with tornado.ioloop.IOLoop.current() as iol:
            iol.make_current()
            iol.run_sync(lambda: future)
    assert future.done()
    assert future.cancelled()
    future.set

# Generated at 2022-06-12 13:19:42.827254
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from unittest import mock
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop

    @run_on_executor
    def f(self):
        assert self is x

    class X(object):
        def __init__(self):
            self.executor = mock.NonCallableMock()

    x = X()
    x.f = f
    x.f()
    x.executor.submit.assert_called_with(f, x)



# Generated at 2022-06-12 13:19:49.091535
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """
    unit test function for future_set_result_unless_cancelled
    """
    future = asyncio.Future()
    test_value = "test123"
    # test case that the future is not cancelled
    future_set_result_unless_cancelled(future, test_value)
    assert future.result() == test_value
    future = asyncio.Future()
    # test case that the future is cancelled
    future.cancel()
    future_set_result_unless_cancelled(future, test_value)
    assert future.result() is None

test_future_set_result_unless_cancelled()