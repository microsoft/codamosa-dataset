

# Generated at 2022-06-12 13:09:59.302661
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    @gen.coroutine
    def f():
        # ensure these are run on separate stacks so we see
        # the result of f1.set_result in the callback.
        yield gen.moment
        f1.set_result(42)

    @gen.coroutine
    def b():
        yield f()
        assert f2.result() == 42

    io_loop.run_sync(b)
    io_loop.close()

# Generated at 2022-06-12 13:10:02.447520
# Unit test for function chain_future
def test_chain_future():
    def f():
        future = Future()
        chain_future(future, a)
        future.set_result(42)

    a = Future()
    f()
    assert a.result() == 42

# Generated at 2022-06-12 13:10:11.802871
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures
    import tornado.ioloop

    f1 = concurrent.futures.Future()
    f2 = Future()
    chain_future(f1, f2)

    def f():
        return "foo"

    def err():
        raise Exception("foo")

    tornado.ioloop.IOLoop.current().add_future(f1, lambda f: f.result())
    f1.set_result("bar")
    tornado.ioloop.IOLoop.current().add_future(f2, lambda f: f.result())

    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("bar"))
    tornado.ioloop.IOLoop.current().add_future(f2, lambda f: f.result())


# Generated at 2022-06-12 13:10:18.275275
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future as ConcFuture

    async def _async_chain_future(future: Union["Future[_T]", "futures.Future[_T]"]) -> None:
        try:
            result = await future
        except Exception:
            result = None
        return result

    def _conc_chain_future(future: Union["Future[_T]", "futures.Future[_T]"]) -> None:
        return future.result()

    for i in range(2):
        for j in range(2):
            a = Futures()[i]
            b = Futures()[j]
            future_set_result_unless_cancelled(a, 1492)
            if i == 0:
                result = _conc_chain_future(a)


# Generated at 2022-06-12 13:10:24.063686
# Unit test for function chain_future
def test_chain_future():
    sync_future = Future()
    async_future = Future()
    chain_future(sync_future, async_future)
    sync_future.set_result(None)
    assert async_future.done()
    sync_future = Future()
    async_future = Future()
    chain_future(sync_future, async_future)
    sync_future.set_exception(ValueError)
    assert async_future.done()
    try:
        async_future.result()
    except ValueError:
        pass



# Generated at 2022-06-12 13:10:33.675345
# Unit test for function chain_future
def test_chain_future():
    def make_future():
        return Future()  # type: Future[int]

    def make_concurrent_future():
        return futures.Future()  # type: futures.Future[int]

    for make_inner, make_outer in itertools.product(
        (make_future, make_concurrent_future), repeat=2
    ):
        # Future.result() -> Future.result()
        inner = make_inner()
        outer = make_outer()
        chain_future(inner, outer)
        inner.set_result(5)
        assert outer.done()
        assert outer.result() == 5

        # Future.result() -> Future.cancel()
        inner = make_inner()
        outer = make_outer()
        chain_future(inner, outer)
        inner.set_result(5)
        outer

# Generated at 2022-06-12 13:10:39.814068
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.simple_httpclient import SimpleAsyncHTTPClient
    from tornado.test.util import unittest, get_unused_port, AsyncHTTPTestCase

    def f():
        # type: () -> int
        raise Exception("oops")

    def g():
        # type: () -> int
        return 42

    class TestFuture(unittest.TestCase):
        io_loop = None  # type: IOLoop

        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop.current()
            super(TestFuture, self).setUp()

        def test_chain_future(self):
            # type: () -> None
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[

# Generated at 2022-06-12 13:10:46.536444
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()
    executor = concurrent.futures.ThreadPoolExecutor(1)

    class MyTestClass(object):
        def __init__(self):
            self.executor = executor

        @run_on_executor
        def func_blocking(self):
            time.sleep(0.01)
            return 42

    my_obj = MyTestClass()
    future = my_obj.func_blocking()
    assert future == 42

# Generated at 2022-06-12 13:10:53.681963
# Unit test for function chain_future
def test_chain_future():
    result = []  # type: typing.List[typing.Any]
    error = Exception()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    future_add_done_callback(f2, lambda f: result.append(f.result()))
    f1.set_result(42)
    assert result == [42]
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    future_add_done_callback(f2, lambda f: result.append(f.exception()))
    f1.set_exception(error)
    assert result == [42, error]
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set

# Generated at 2022-06-12 13:11:00.866587
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    import tornado.testing
    import tornado.ioloop

    a = Future()
    b = Future()
    chain_future(a, b)

    a.set_result(42)
    assert b.result() == 42

    c = Future()
    d = Future()
    chain_future(c, d)
    c.set_exception(ZeroDivisionError())

    def f(fut):
        assert fut.exception() == ZeroDivisionError
        tornado.ioloop.IOLoop.current().stop()

    d.add_done_callback(f)
    tornado.testing.run_sync(lambda: d)

# Generated at 2022-06-12 13:11:13.026673
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class FutureTest(AsyncTestCase):
        def setUp(self):
            super(FutureTest, self).setUp()
            self.futures = [Future(), Future()]

        @gen_test
        def test_chain(self):
            def cb(fut):
                self.futures.remove(fut)
                if not self.futures:
                    self.stop()
            chain_future(self.futures[0], self.futures[1])
            self.futures[1].add_done_callback(cb)
            self.futures[0].set_result(42)
            self.wait()
            self.assertFalse(self.futures[0].done())

# Generated at 2022-06-12 13:11:22.331814
# Unit test for function chain_future
def test_chain_future():  # pragma: nocover
    from asyncio import Event
    import tornado

    def _test_chain(input_future, output_future):
        def _check():
            assert not output_future.deadline
            assert output_future.done()
            output_future.result()
            assert output_future.result() == 42
            assert not output_future.deadline
        ioloop = tornado.ioloop.IOLoop.current()
        # check immediately, and in the future (in case we switch to lazy callbacks)
        _check()
        ioloop.add_callback(_check)
        input_future.set_result(42)
        assert not input_future.deadline
        assert input_future.done()
        assert input_future.result() == 42

    # Test the chain_future function with tornado.concurrent.

# Generated at 2022-06-12 13:11:25.227807
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(123)
    assert g.result() == 123

# Generated at 2022-06-12 13:11:32.099877
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[int]
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f2.set_result(24)
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 24  # f2 was already done, so 42 was ignored

# Generated at 2022-06-12 13:11:39.636051
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def real_test():
        # type: () -> None
        future = Future()
        future_set_exception_unless_cancelled(future, IndexError())
        assert future.exception() is not None
        assert future.cancelled() is False
        future = Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, IndexError())
        assert future.exception() is None
        assert future.cancelled() is True
    from tornado.ioloop import IOLoop
    IOLoop.current().run_sync(real_test)

# Generated at 2022-06-12 13:11:48.439048
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_exception(RuntimeError())
    chain_future(f1, f2)
    assert isinstance(f2.exception(), RuntimeError)

# Generated at 2022-06-12 13:11:56.397749
# Unit test for function chain_future
def test_chain_future():
    def test_asyncio_future_result(x):
        return asyncio.Future()

    def test_asyncio_future_exception(x):
        f = asyncio.Future()
        f.set_exception(Exception(x))
        return f

    def test_tornado_future_result(x):
        f = concurrent.futures.Future()
        f.set_result(x)
        return f

    def test_tornado_future_exception(x):
        f = concurrent.futures.Future()
        f.set_exception(Exception(x))
        return f

    def test_chain_result(x):
        f = Future()
        chain_future(test_asyncio_future_result(x), f)
        return f


# Generated at 2022-06-12 13:12:00.888862
# Unit test for function chain_future
def test_chain_future():

    def callback(future: Future) -> None:
        pass

    async_future = Future()
    conc_future = futures.Future()

    chain_future(async_future, conc_future)
    chain_future(conc_future, async_future)
    chain_future(async_future, async_future)  # should no-op

    future_add_done_callback(async_future, callback)

# Generated at 2022-06-12 13:12:08.678673
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.get_event_loop()

    def func(x, y):
        # type: (int, int) -> int
        return x + y

    f1 = loop.create_future()
    f2 = loop.create_future()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()

    f1.set_result(2)
    assert f1.done()
    assert f2.done()
    assert f2.result() == 2


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-12 13:12:15.529734
# Unit test for function chain_future
def test_chain_future():
    """Tests for chain_future."""
    import logging
    from concurrent.futures import Future as CFuture
    from unittest import TestCase

    class FirstFuture(CFuture):
        """A subclass of CFuture that can return the result without blocking."""

        def result(self):
            return CFuture.result(self)

    class SecondFuture(Future):
        """A subclass of Future that can return the result without blocking."""

        def result(self):
            return Future.result(self)

    class TestFutures(TestCase):
        def setUp(self):
            super(TestFutures, self).setUp()
            self.future1 = FirstFuture()
            self.future2 = SecondFuture()
            self.exception = ZeroDivisionError()


# Generated at 2022-06-12 13:12:27.397618
# Unit test for function chain_future
def test_chain_future():
    import unittest.mock

    d = unittest.mock.Mock()
    f = futures.Future()
    chain_future(f, d)
    f.set_result(None)
    d.assert_called_once_with(f)
    assert not d.return_value.called

    d = unittest.mock.Mock()
    f = Future()
    chain_future(f, d)
    f.set_result(None)
    d.assert_called_once_with(f)
    assert not d.return_value.called



# Generated at 2022-06-12 13:12:33.950065
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest.mock import create_autospec

    f1 = Future()
    func = create_autospec(future_set_exception_unless_cancelled)
    future_set_exception_unless_cancelled(f1, ValueError("test"))
    assert f1.exception() is not None
    func.assert_called_with(f1, ValueError("test"))

    f2 = Future()
    f2.cancel()
    future_set_exception_unless_cancelled(f2, ValueError("test"))
    assert f2.cancelled()



# Generated at 2022-06-12 13:12:42.142945
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, bind_unused_port, AsyncTestCase

    class Handler(AsyncTestCase):
        def setUp(self):  # noqa: F811
            super(Handler, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):  # noqa: F811
            # TODO(benh): "super(Handler, self).tearDown()"?
            self.executor.shutdown()

        @run_on_executor(executor="executor")
        def get(self, url):
            return url

        @gen_test
        def test_chain_future(self):
            f = Future()
            f2 = Future()
            chain_future(f2, f)

# Generated at 2022-06-12 13:12:50.769013
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    @asyncio.coroutine
    def chain_future_test():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(None)
        assert (yield From(f2)) is None

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_exception(ValueError())
        try:
            yield From(f2)
        except ValueError:
            pass
        else:
            raise Exception("did not propagate exception")

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f2.set_result(None)
        f1.set_result

# Generated at 2022-06-12 13:12:57.930774
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado import gen

    @gen.coroutine
    def f():
        # type: () -> None
        yield gen.sleep(0.01)
        raise gen.Return(42)

    @gen.coroutine
    def f2():
        # type: () -> None
        try:
            result = yield f()
        except Exception:
            result = "exception"
        assert result == 42

    @gen.coroutine
    def f3():
        # type: () -> None
        result = yield f2()
        assert result is None

    asyncio.get_event_loop().run_until_complete(f3())

# Generated at 2022-06-12 13:13:01.103126
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    assert future.cancelled()

    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-12 13:13:11.067558
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    result = None

    @gen_test
    async def f():
        f1 = Future()  # type: Future[str]
        f2 = Future()  # type: Future[str]
        chain_future(f1, f2)
        f1.set_result("foo")
        assert f2.done()
        assert (await f2) == "foo"

    loop.run_until_complete(f())

    @gen_test
    async def g():
        f1 = Future()  # type: Future[str]
        f2 = Future()  # type: Future[str]

# Generated at 2022-06-12 13:13:14.181967
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f_test(a: int, b: int) -> int:
        return a + b

    result = dummy_executor.submit(f_test, 3, 7)  # type: Future
    assert result.done()
    assert result.result() == 10


# Generated at 2022-06-12 13:13:19.094603
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future[Any]
    exc_info = (TypeError, TypeError("test"), None)
    future_set_exc_info(future, exc_info)
    assert future.exception() is exc_info[1]

    future = Future()
    future.cancel()
    exc_info = (TypeError, TypeError("test"), None)
    future_set_exc_info(future, exc_info)  # should not raise



# Generated at 2022-06-12 13:13:26.219306
# Unit test for function chain_future
def test_chain_future():
    import functools
    import logging
    import os
    import signal
    import sys

    from tornado.platform.auto import set_close_exec
    from tornado.testing import AsyncTestCase, gen_test

    from .httpclient_test import skipIfNonUnix, skipIfNoIPv6

    # Split into two tests with the same body to avoid the
    # max_concurrent_tests limit.
    # _test_chain_future is defined outside of the class so that
    # warnings from asyncio can be captured.
    def _test_chain_future(self):
        # Clear the handler for SIGCHLD so it doesn't fire during the test.
        old_handler = signal.signal(signal.SIGCHLD, signal.SIG_DFL)

# Generated at 2022-06-12 13:13:45.967514
# Unit test for function chain_future
def test_chain_future():
    import unittest.mock

    # Create a Future that doesn't do anything on set_result/set_exc_info
    class MyFuture(Future):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.callbacks = []  # type: typing.List[tuple]

        def add_done_callback(self, callback: Callable) -> None:
            self.callbacks.append(callback)
            while len(self.callbacks) == 1:
                pass

        def set_result(self, result: Any) -> None:
            if len(self.callbacks) == 1:
                callback = self.callbacks.pop(0)
                callback(self)


# Generated at 2022-06-12 13:13:53.394845
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            future1 = Future()
            future2 = Future()

            chain_future(future1, future2)

            self.assertFalse(future1.done())
            self.assertFalse(future2.done())

            future1.set_result(42)

            self.assertEqual(future2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-12 13:14:02.486643
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    future.set_exception(Exception("test"))

    # future has exception now
    assert not future.cancelled()
    assert future.exception() is not None

    future_set_exception_unless_cancelled(future, ValueError("test"))

    # no-op for set_exception_unless_cancelled
    assert not future.cancelled()
    assert future.exception() is not None

    # discard exception
    future = Future()

    future.cancel()

    # future is cancelled now
    assert future.cancelled()

    future_set_exception_unless_cancelled(future, ValueError("test"))

    # no-op for set_exception_unless_cancelled
    assert future.cancelled()
    assert future.exception() is None


# Generated at 2022-06-12 13:14:07.125053
# Unit test for function chain_future
def test_chain_future():
    def _test_chain(a, b):
        chain_future(a, b)
        with b:
            pass

    try:
        _test_chain(futures.Future(), futures.Future())
        _test_chain(Future(), Future())
    except TypeError:  # pragma: no cover
        # futures.Future is not compatible with asyncio.Future
        pass

# Generated at 2022-06-12 13:14:12.857196
# Unit test for function chain_future
def test_chain_future():
    import tornado.test.util  # import as a side effect

    @run_on_executor
    def get_result():
        return 42

    ioloop = tornado.test.util.new_ioloop()
    ioloop.make_current()  # for the get_future test
    async_future = get_result()
    assert async_future.done()
    assert async_future.result() == 42
    ioloop.close(all_fds=True)

# Generated at 2022-06-12 13:14:17.197022
# Unit test for function chain_future
def test_chain_future():

    async def test(make_future: Callable[..., "Future"]) -> None:
        future1 = make_future()
        future2 = make_future()
        chain_future(future1, future2)
        future1.set_result(42)
        assert future2.result() == 42

    asyncio.run(test(Future))
    asyncio.run(test(futures.Future))

# Generated at 2022-06-12 13:14:26.796448
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        assert not future.done()
        assert future.set_result(5)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.add_done_callback(callback)
    # f1 is completed by callback
    assert f2.result() == 5

    f1 = Future()
    f2 = Future()
    # f1 is already done
    f1.set_result(5)
    assert f1.done()
    chain_future(f1, f2)
    assert f2.result() == 5

    f1 = Future()
    f2 = Future()
    # f2 is already done
    f2.set_result(6)
    assert f2.done()
    chain_future(f1, f2)

# Generated at 2022-06-12 13:14:29.402805
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)

    assert b.result() == 42



# Generated at 2022-06-12 13:14:38.619599
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: no cover
    import time
    import unittest

    # Previously, run_on_executor would pass through any keyword arguments
    # it received. We can remove this once we remove the decorator's
    # support for keyword arguments.
    class TestCase(unittest.TestCase):
        def __init__(self, *args):
            super(TestCase, self).__init__(*args)
            self._executor_keywords = []

        @run_on_executor(executor="_executor")
        def foo(self, arg):
            return arg

        @run_on_executor(foo="bar")
        def executor_with_keywords(self, value):
            self._executor_keywords.append(value)
            return value


# Generated at 2022-06-12 13:14:41.372311
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    chain_future(g, g)

    f.set_result(42)
    # TODO: assertEquals(g.result(), 42)



# Generated at 2022-06-12 13:15:04.099380
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda x: x, 1).result() == 1


# Generated at 2022-06-12 13:15:12.970160
# Unit test for function chain_future
def test_chain_future():

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(Exception('the sky is falling'))
    assert b.exception() is not None

    a = Future()
    b = Future()
    chain_future(a, b)
    b.set_result(43)
    assert b.result() == 43

    a = Future()
    b = Future()
    chain_future(a, b)
    b.set_exception(Exception('panic'))
    assert b.exception() is not None

    a = Future()
    b = Future()

# Generated at 2022-06-12 13:15:16.295968
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("foo"))
    assert True  # no exception

# Generated at 2022-06-12 13:15:21.628123
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    done_future = Future()
    done_conc_future = futures.Future()
    done_conc_future.set_result(42)
    loop.call_soon(done_future.set_result, 42)
    assert done_future.result() == 42
    assert done_conc_future.result() == 42


# Test that concurrent.futures.Future can be used to get a result from a
# generator that uses yield

# Generated at 2022-06-12 13:15:28.829799
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            outer_future = Future()
            inner_future = Future()
            chain_future(inner_future, outer_future)

            @gen_test
            def finish():
                inner_future.set_result(42)
                self.assertEqual(outer_future.result(), 42)

                inner_future = Future()
                chain_future(inner_future, outer_future)
                inner_future.set_exception(ValueError("foo"))
                self.assertRaises(ValueError, outer_future.result)

            self.io_loop.add_future(outer_future, finish)

    test = Test()
    test.run_until_complete()

# Generated at 2022-06-12 13:15:36.274424
# Unit test for function chain_future
def test_chain_future():
    old_future = futures.Future()
    new_future = Future()
    chain_future(old_future, new_future)
    assert not new_future.done()
    old_future.set_result("result")
    assert new_future.done()
    assert new_future.result() == "result"

    old_future = futures.Future()
    new_future = Future()
    chain_future(old_future, new_future)
    assert not new_future.done()
    old_future.set_exception(Exception("exception"))
    assert new_future.done()
    assert new_future.exception().args == ("exception",)

    # Test that the old future doesn't affect the new
    old_future = futures.Future()
    new_future = Future()

# Generated at 2022-06-12 13:15:42.591727
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    g = Future()
    chain_future(f, g)
    assert not g.done()
    f.set_result(123)
    assert g.result() == 123

    err = Exception()
    f = Future()
    g = Future()
    chain_future(f, g)
    assert not g.done()
    f.set_exception(err)
    assert g.exception() is err

    f = Future()
    g = Future()
    h = Future()
    chain_future(f, g)
    assert not g.done()
    chain_future(f, h)
    assert not h.done()
    f.set_result(456)
    assert g.result() == 456
    assert h.result() == 456

   

# Generated at 2022-06-12 13:15:50.621401
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class FutureTestCase(AsyncTestCase):
        def test_chain_future(self):
            source = Future()
            source.set_result(42)
            destination = Future()
            self.assertFalse(destination.done())
            chain_future(source, destination)
            self.assertTrue(destination.done())
            self.assertEqual(destination.result(), 42)

    @gen_test
    def test_chain_future_to_concurrent_future():
        source = Future()
        source.set_result(42)
        destination = concurrent.futures.Future()
        chain_future(source, destination)

# Generated at 2022-06-12 13:15:54.867377
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert isinstance(future.exception(), ValueError)
    assert not future.cancelled()

    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    future.cancel()
    assert future.cancelled()

# Generated at 2022-06-12 13:16:04.528331
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            result = yield self.callback_result
            self.assertEqual(result, "something")

        @gen_test
        async def callback_result(
            self, executor, conc_future: futures.Future[str]
        ) -> Future[str]:
            async_future = Future()
            chain_future(conc_future, async_future)
            return await async_future


# Generated at 2022-06-12 13:16:50.262852
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception("foo"))
    assert f.exception() is not None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("foo"))
    assert f.exception() is None



# Generated at 2022-06-12 13:16:58.635101
# Unit test for function chain_future
def test_chain_future():

    class TestException(Exception):
        pass

    def f():
        raise TestException()

    future1 = asyncio.Future()
    future2 = asyncio.Future()
    chain_future(future1, future2)
    future1.set_exception(TestException)
    test_future = asyncio.Future()

    def f2(future):
        try:
            future.result()
        except TestException:
            test_future.set_result(1)
        except:
            test_future.set_exception(sys.exc_info())
        else:
            test_future.set_exception(Exception("future doesn't contain exception"))

    future_add_done_callback(future2, f2)
    return test_future

# Generated at 2022-06-12 13:17:07.005465
# Unit test for function chain_future
def test_chain_future():
    from tornado.test.util import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()

            self.assertFalse(f1.done())
            self.assertFalse(f2.done())

            chain_future(f1, f2)

            self.assertFalse(f1.done())
            self.assertFalse(f2.done())

            f1.set_result(3)
            self.assertTrue(f1.done())
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 3)

            f1 = Future()
            f2 = Future()

            f1.set_exception(ValueError())
            self.assertRaises

# Generated at 2022-06-12 13:17:09.226214
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.result() == 42
    assert f2.result() == 42
    assert f2.exception() is None



# Generated at 2022-06-12 13:17:17.448442
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

# Generated at 2022-06-12 13:17:23.237064
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert f.result() == 42
    assert g.result() == 42

    h = Future()
    chain_future(f, h)
    assert h.result() == 42
    f.set_result(1729)
    assert h.result() == 42

    i = Future()
    chain_future(f, i)
    assert i.result() == 1729



# Generated at 2022-06-12 13:17:29.288704
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    from tornado.ioloop import IOLoop

    IOLoop.current().add_callback(f1.set_result, 42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ValueError)

# Generated at 2022-06-12 13:17:38.111704
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover

    def callback(f):
        callback.called = True

    @gen.coroutine
    def f():
        yield gen.moment

    a = f()
    b = f()
    assert not a.done()
    assert not b.done()
    chain_future(a, b)
    assert not a.done()
    assert not b.done()
    a.set_result(None)
    assert a.done()
    assert b.done()
    a = f()
    b = f()
    callback.called = False
    chain_future(a, b)
    assert not a.done()
    assert not b.done()
    b.add_done_callback(callback)
    assert not b.done()
    assert not callback.called
    a.set_result(None)

# Generated at 2022-06-12 13:17:41.490964
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    from tornado.ioloop import IOLoop

    async def f():
        done = Future()
        future_set_exception_unless_cancelled(done, ValueError())
        return await done

    IOLoop.current().run_sync(f)

# Generated at 2022-06-12 13:17:44.129903
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(None)
    assert g.done()



# Generated at 2022-06-12 13:19:17.063768
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.log import enable_pretty_logging
    enable_pretty_logging()

    def f1():
        return 42

    def f2():
        1 / 0

    def f3():
        return 24

    f1 = dummy_executor.submit(f1)
    f2 = dummy_executor.submit(f2)
    f3 = dummy_executor.submit(f3)
    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(f1, c)
    chain_future(f2, a)
    chain_future(f3, a)
    IOLoop.current().run_sync(lambda: b)

# Generated at 2022-06-12 13:19:23.316167
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exc_info = (ZeroDivisionError, ZeroDivisionError("zero division"), None)

    assert not f.cancelled()
    future_set_exception_unless_cancelled(f, exc_info[1])
    assert f.exception() is exc_info[1]

    f2 = Future()
    f2.cancel()
    assert f2.cancelled()
    future_set_exception_unless_cancelled(f2, exc_info[1])
    assert f2.exception() is None

# Generated at 2022-06-12 13:19:28.285805
# Unit test for function chain_future
def test_chain_future():
    def f():
        raise RuntimeError("exception expected")

    io_loop = IOLoop()
    io_loop.make_current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(lambda: f1.set_result("result"))
    io_loop.add_callback(f)
    f2.add_done_callback(lambda f: io_loop.stop())
    io_loop.start()
    assert f2.exception()

# Generated at 2022-06-12 13:19:34.829448
# Unit test for function chain_future
def test_chain_future():
    try:
        import concurrent.futures  # type: ignore
        import asyncio
    except ImportError:
        raise unittest.SkipTest("concurrent.futures module not present")

    def executor(fn):
        def wrapper(*args):
            return futures.ThreadPoolExecutor(1).submit(fn, *args)
        return wrapper

    class MyFuture(asyncio.Future):
        def done(self):
            # asyncio.Future would normally crash here
            return False

    @executor
    def func():
        return 42

    @executor
    def func2(result):
        return result + 1

    @executor
    def func3(result):
        return result + 1

    f1 = func()
    f2 = MyFuture()
    f3 = MyFuture()
    chain_future

# Generated at 2022-06-12 13:19:42.896763
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop, PeriodicCallback

    async def test_async_future():
        async_future = Future()

        def do_test_task():
            print("test_task")
            future_set_result_unless_cancelled(async_future, 'test_result')

        executor_future = dummy_executor.submit(do_test_task)
        chain_future(executor_future, async_future)
        test_result = await async_future
        print('test_result:',test_result)

    def test_callback():
        print('test_callback')
        IOLoop.current().stop()

    IOLoop.current().add_future(test_async_future(), test_callback)