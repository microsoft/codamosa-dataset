

# Generated at 2022-06-12 13:09:57.725993
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """The future is chained to the executor and is done when the executor is done.
    """
    from tornado.platform.asyncio import to_asyncio_future

    # Test without exception
    executor = futures.ThreadPoolExecutor(1)
    try:
        f = Future()  # type: Future[int]
        chain_future(executor.submit(lambda a: a, 42), f)
        assert f.result() == 42
    finally:
        executor.shutdown(wait=True)

    # Test with exception
    executor = futures.ThreadPoolExecutor(1)

# Generated at 2022-06-12 13:10:03.449525
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.done()
    assert future.result() == 42

    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-12 13:10:11.169297
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain(self):
            @gen_test
            def test_chain():
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                IOLoop.current().call_later(0.1, f1.set_result, 42)

# Generated at 2022-06-12 13:10:17.867311
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future

    async def async_future_test():
        f = Future()
        f2 = to_asyncio_future(f)

        def callback(f: Future) -> None:
            stack_context.set_context(None)
            got_context[0] = stack_context.get_current()
            got_future[0] = f
            got_exc_info[0] = sys.exc_info()

        chain_future(f, f2)
        chain_future(f2, f)
        got_future = [None]
        got_exc_info = [None]
        got_context = [None]
        f.add_done_callback(callback)
        f

# Generated at 2022-06-12 13:10:20.744075
# Unit test for function chain_future
def test_chain_future():
    def f():
        raise Exception("eek")

    future = Future()  # type: Future[int]
    chained = Future()  # type: Future[int]
    chain_future(future, chained)

    future_set_exc_info(future, sys.exc_info())
    assert not future.result()

    assert chained.exception() is not None
    chained.result()



# Generated at 2022-06-12 13:10:25.082542
# Unit test for function chain_future
def test_chain_future():
    e = [None]

    def copy(future):
        assert future is a
        if not b.done():
            b.set_exception(Exception("chain_future"))
        e[0] = sys.exc_info()

    a = Future()
    b = Future()
    chain_future(a, b)
    a.add_done_callback(copy)
    a.set_exception(Exception("chain_future"))
    return b



# Generated at 2022-06-12 13:10:34.854245
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = Exception()

    # a future that is not cancelled shouldn't log anything
    future_set_exc_info(future, (None, exception))
    assert future.exception() is exception

    # a cancelled future should log an error
    future = Future()
    future.cancel()
    with LogTrap(app_log) as log:
        future_set_exc_info(future, (None, exception))
    assert log.has_error_for(exception)
    assert future.exception() is None

    # but it shouldn't log if the future is already done
    future = Future()
    future.set_result(None)
    with LogTrap(app_log) as log:
        future_set_exc_info(future, (None, exception))
    assert not log.has_error

# Generated at 2022-06-12 13:10:43.823765
# Unit test for function chain_future
def test_chain_future():
    ioloop = IOLoop.current()
    async_future = Future()
    conc_future = futures.Future()

    chain_future(conc_future, async_future)

    def cb():
        ioloop.stop()

    async_future.add_done_callback(cb)

    ioloop.add_callback(lambda: conc_future.set_result(42))
    ioloop.start()
    assert async_future.result() == 42

    async_future = Future()
    conc_future = futures.Future()
    chain_future(conc_future, async_future)

    def eb():
        ioloop.stop()

    async_future.add_done_callback(eb)


# Generated at 2022-06-12 13:10:47.977155
# Unit test for function chain_future
def test_chain_future():
    async def _test():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future1.set_result(42)
        assert future1.result() == 42
        assert future2.result() == 42

    asyncio.get_event_loop().run_until_complete(_test())



# Generated at 2022-06-12 13:10:52.794225
# Unit test for function chain_future
def test_chain_future():
    f = Future()  # type: Future
    g = Future()  # type: Future
    chain_future(f, g)
    f.set_result(42)
    f.set_exception(Exception("foo"))
    assert g.result() == 42
    f2 = Future()  # type: Future
    chain_future(f2, g)
    f2.set_exception(Exception("bar"))
    assert g.exception().args == ("bar",)



# Generated at 2022-06-12 13:11:10.393460
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result("foo")
    assert f2.result() == "foo"

    f1 = Future()
    f2 = Future()
    chain_future(f2, f1)
    f1.set_result("foo")
    assert f2.result() == "foo"

    f1 = Future()
    f2 = Future()
    f1.set_result("foo")
    chain_future(f1, f2)
    assert f2.result() == "foo"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f

# Generated at 2022-06-12 13:11:15.436588
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import asyncio
    async def test():
        future = asyncio.Task(asyncio.sleep(0))
        future.cancel()
        future_set_result_unless_cancelled(future, "hello")
        return future.cancelled()
    loop = asyncio.get_event_loop()
    if loop.run_until_complete(test()):
        print('test_future_set_result_unless_cancelled pass.')
    else:
        print('test_future_set_result_unless_cancelled fail.')


# Generated at 2022-06-12 13:11:20.791609
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'

    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, 'foo')
    assert future2.cancelled()



# Generated at 2022-06-12 13:11:30.256498
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import BaseAsyncIOLoop

    class Foo(object):
        executor = dummy_executor
        _thread_pool = dummy_executor

        @run_on_executor
        def func1(self):  # type: () -> int
            return 42

        @run_on_executor(executor="_thread_pool")
        def func2(self, x, y=1):  # type: (int, int) -> Tuple[int, int]
            return x, y

    foo = Foo()
    ioloop = BaseAsyncIOLoop()
    ioloop.make_current()

    f1 = foo.func1()
    assert isinstance(f1, Future)
    assert f1.result() == 42

    f2 = foo.func2(2)

# Generated at 2022-06-12 13:11:37.238526
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    @tornado.gen.coroutine
    def test_case():
        future = tornado.concurrent.Future()
        future_set_result_unless_cancelled(future, 123)
        result = yield future
        assert result == 123
        future = tornado.concurrent.Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 456)
        assert future.result() is None

    tornado.ioloop.IOLoop.current().run_sync(test_case)

# Generated at 2022-06-12 13:11:41.751979
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(None)
    future2.add_done_callback(lambda f: tornado.ioloop.IOLoop.current().stop())
    tornado.ioloop.IOLoop.current().start()



# Generated at 2022-06-12 13:11:48.617955
# Unit test for function chain_future
def test_chain_future():  # pragma: nocover
    a_future = Future()
    b_future = Future()
    def finish_a_future():
        future_set_result_unless_cancelled(a_future, 42)
    b_future.add_done_callback(lambda _: chain_future(a_future, b_future))
    b_future.add_done_callback(lambda _: finish_a_future())
    b_future.set_result(None)
    print("finished")

# Generated at 2022-06-12 13:11:53.684964
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f1 = Future()
    future_set_result_unless_cancelled(f1, 1)
    assert 1 == f1.result()
    f2 = Future()
    future_set_result_unless_cancelled(f2, 2)
    assert 2 == f2.result()
    f2.cancel()
    future_set_result_unless_cancelled(f2, 3)
    assert 2 == f2.result()

# Generated at 2022-06-12 13:11:56.219932
# Unit test for function chain_future
def test_chain_future():
    original = Future()
    duplicate = Future()
    chain_future(original, duplicate)
    assert not duplicate.done()
    original.set_result(42)
    assert duplicate.result() == 42
    assert duplicate.done()

# Generated at 2022-06-12 13:12:03.805539
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def additional_test(fut):
        # type: (Future) -> None
        fut.set_result(10)
    import tornado.gen
    #@tornado.gen.coroutine
    #def f1(x):
    #    return x+1
    #f2 = tornado.gen.coroutine(lambda x: x+2)
    io_loop = tornado.ioloop.IOLoop.current()
    f = Future()
    chain_future(f, f2(10))
    io_loop.add_future(f, additional_test)
    io_loop.start()
    assert f.result() == 10
    assert f2.result() == 12

# Generated at 2022-06-12 13:12:13.935459
# Unit test for function chain_future
def test_chain_future():
    sync_future = futures.Future()
    async_future = Future()
    chain_future(sync_future, async_future)
    sync_future.set_exception(Exception())
    assert async_future.exception() is not None



# Generated at 2022-06-12 13:12:22.546249
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    import tornado.testing

    from concurrent import futures

    executor = futures.ThreadPoolExecutor(1)

    io_loop = tornado.ioloop.IOLoop()

    f1 = Future()
    f2 = Future()

    def f1_done(future):
        assert f1.done()
        assert not f2.done()
        io_loop.add_callback(lambda: chain_future(f1, f2))

    def f2_done(future):
        assert f1.done()
        assert f2.done()

    chain_future(f1, f1)
    future_add_done_callback(f2, f2_done)
    future_add_done_callback(f1, f1_done)


# Generated at 2022-06-12 13:12:30.850918
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import concurrent.futures
    import typing
    from typing import Optional
    
    def start_loop(loop: Optional[asyncio.AbstractEventLoop]) -> None:
        if loop is not None:
            raise RuntimeError('This event loop is already running')
        loop = asyncio.get_event_loop()
        loop.stop()
        loop.run_forever()
    
    def stop_loop(loop: Optional[asyncio.AbstractEventLoop]) -> None:
        if loop is None:
            raise RuntimeError('There is no current event loop in thread %r' % threading.current_thread().name)
        loop.stop()
    

# Generated at 2022-06-12 13:12:39.381359
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    import tornado
    import tornado.log
    import logging

    def test_impl(future, exc):
        # type: (Future[None], BaseException) -> None
        try:
            future_set_exception_unless_cancelled(future, exc)
        except Exception:
            raise Exception("Future.set_exception raised exception")

    # run test with no logger
    future = Future()
    exc = ValueError()
    test_impl(future, exc)
    assert future.exception() == exc
    assert not future.cancelled()

    future = Future()
    future.cancel()
    exc = ValueError()
    test_impl(future, exc)
    assert not future.exception()
    assert future.cancelled()

    # run test with existing logger
    future

# Generated at 2022-06-12 13:12:47.797597
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test(self):
            futures = []
            for executor in [None, dummy_executor]:
                for base_future in [True, False]:
                    futures.append(self.run_future(executor, base_future))

            @gen.coroutine
            def finish_test():
                for future in futures:
                    yield future

            self.io_loop.run_sync(finish_test)

        @gen.coroutine
        def run_future(self, executor, base_future):
            f = Future() if base_future else futures.Future()
            f2 = Future() if base_future else futures.Future()
            chain_future(f, f2)


# Generated at 2022-06-12 13:12:51.801239
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert isinstance(future.exception(), Exception)

    future = Future()
    future_set_exception_unless_cancelled(future, None)
    assert isinstance(future.exception(), TypeError)


# Generated at 2022-06-12 13:13:00.503810
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    def _make_future(callback, *args, **kwargs):
        # type: (Callable, *Any, **Any) -> Future
        future = Future()
        callback(*args, **kwargs)
        return future

    def check_chain_future(make_future):
        # type: (Callable) -> None
        a = make_future(lambda: None)
        b = make_future(lambda: None)
        chain_future(a, b)
        tornado.testing.assert_true(b.done())
        a = make_future(lambda: None)
        b = make_future(lambda: None)
        a.set_result(1)
        chain_future(a, b)
        tornado.testing.assert_true(b.done())

# Generated at 2022-06-12 13:13:10.212664
# Unit test for function run_on_executor
def test_run_on_executor():
    from unittest import TestCase  # noqa

    class Test(TestCase):
        called = False
        executor = dummy_executor

        def setUp(self):
            self.called = False
            self.result = None
            self.exc = None

        @run_on_executor
        def func(self, arg):
            self.called = True
            return arg

        @run_on_executor
        def func_exc(self, arg):
            raise Exception("blah")

        def test_run_on_executor(self):
            future = self.func(1)
            self.assertFalse(self.called)
            future.result()
            self.assertTrue(self.called)


# Generated at 2022-06-12 13:13:16.501132
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    def cb(future):
        # type: (Future) -> None
        f2.set_result(future.result() + 1)

    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)

    io_loop = IOLoop.current()
    io_loop.add_future(f2, cb)
    io_loop.add_callback(f2.set_result, 13)

# Generated at 2022-06-12 13:13:19.198809
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))

# Generated at 2022-06-12 13:13:33.141756
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def main():
        future = Future()
        future_set_exception_unless_cancelled(future, RuntimeError())
        assert future.done()
        assert isinstance(future.exception(), RuntimeError)
        future = Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, RuntimeError())
        return future.result()

    asyncio.run(main())

# Generated at 2022-06-12 13:13:37.929799
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, "foo")
    assert f.result() == "foo"
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "bar")
    assert f.cancelled()



# Generated at 2022-06-12 13:13:47.336628
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    class DummyClass:
        def __init__(self):
            self.future = Future()

        def set_exception(self, exc):
            self.exc = exc

        def set_exception1(self, exc):
            self.exc1 = exc

        def exception(self):
            return self.exc

        def exception1(self):
            return self.exc1

    class TestFuture(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            dummy_class = DummyClass()
            future_add_done_callback(dummy_class.future, dummy_class.set_exception)
            exc = Exception("dummy exception")
            future_set_exc_info(dummy_class.future, sys.exc_info())

# Generated at 2022-06-12 13:13:53.978319
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        @gen_test
        def test_chain(self):
            def f(arg):
                yield gen.sleep(0.01)
                return arg + 1

            a = self.io_loop.run_in_executor(None, f, 41)
            b = Future()
            chain_future(a, b)

# Generated at 2022-06-12 13:13:59.619754
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.locks import Event

    future = Future()
    future.set_result(None)

    future_set_result_unless_cancelled(future, None)
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    assert future.result() is None

    future = Future()
    future.set_exception(ValueError())
    future = Future()
    future.set_exception(ValueError())
    future_set_result_unless_cancelled(future, None)
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    assert isinstance(future.exception(), ValueError)

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)

# Generated at 2022-06-12 13:14:04.759763
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    assert not future.done()
    assert not future.cancelled()
    future.cancel()
    assert future.done()
    assert future.cancelled()

    future_set_result_unless_cancelled(future, 100)

    # since the future was cancelled, the assignment of the result is ignored
    assert not future.done()
    assert future.cancelled()

# Generated at 2022-06-12 13:14:08.578812
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @gen.coroutine
    def test():
        future = Future()
        future_set_exception_unless_cancelled(future, ValueError())
        with pytest.raises(ValueError):
            yield future
    IOLoop.current().run_sync(test)



# Generated at 2022-06-12 13:14:14.766765
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f():
        yield gen.sleep(1)
        raise Exception("foo")

    @gen.coroutine
    def g():
        yield gen.sleep(1)

    future = f()
    chained = make_future()
    assert not future.done()
    assert not chained.done()

    chain_future(future, chained)

    assert not future.done()
    assert not chained.done()

    future.result()
    chained.result()

    chain_future(g(), make_future())

# Generated at 2022-06-12 13:14:23.214014
# Unit test for function chain_future
def test_chain_future():
    import time

    @gen.coroutine
    def f():
        raise Exception("oops")

    def f2():
        time.sleep(0.01)
        return 42

    ioloop = IOLoop.current()
    future1 = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future1, future2)
    future1.add_done_callback(lambda future: ioloop.stop())
    executor = futures.ThreadPoolExecutor(1)
    executor.submit(f2).add_done_callback(
        lambda future: future_set_result_unless_cancelled(future1, future.result())
    )
    ioloop.start()
    assert future2.result() == 42
    future1 = Future() 

# Generated at 2022-06-12 13:14:29.730581
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test

    class AsyncioFuture(Future):

        def cancel(self) -> None:
            raise TypeError("cannot cancel")

    @gen_test
    async def _test():
        future = AsyncioFuture()
        future_set_exc_info(future, (None, TypeError("foo"), None))
        with pytest.raises(TypeError, match=r"foo"):
            await future


# Generated at 2022-06-12 13:14:52.185727
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    g = Future()
    assert f is not g
    chain_future(f, g)
    f.set_result(123)
    assert_future_result(g, 123)

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(ValueError)
    assert_future_exception(g, ValueError)

    f = Future()
    g = Future()
    chain_future(f, g)
    f.cancel()
    assert g.cancelled()



# Generated at 2022-06-12 13:14:58.677919
# Unit test for function chain_future
def test_chain_future():
    def make_future():
        # type: () -> Future
        return Future()

    def make_completed_future(value=None):
        # type: (Any) -> Future
        future = make_future()
        future_set_result_unless_cancelled(future, value)
        return future

    def make_failed_future(exception=None):
        # type: (Any) -> Future
        future = make_future()
        future_set_exc_info(future, sys.exc_info() if exception is None else (None, exception, None))
        return future

    for make_preceding_future in [make_completed_future, make_failed_future]:
        for make_subsequent_future in [make_completed_future, make_failed_future]:
            preceding_future = make_preceding

# Generated at 2022-06-12 13:15:02.007441
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    try:
        future_set_exception_unless_cancelled(f, RuntimeError())
    except RuntimeError:
        assert False, "future_set_exception_unless_cancelled should log the exception"



# Generated at 2022-06-12 13:15:06.361997
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(
        lambda x, y: x + y, 2, 3
    )  # type: concurrent.futures.Future
    assert future.result() == 5
    assert not future.cancelled()
    assert not future.running()
    assert future.done()



# Generated at 2022-06-12 13:15:15.454535
# Unit test for function chain_future
def test_chain_future():
    f_start = Future()
    f_end = Future()
    chain_future(f_start, f_end)
    assert not f_end.done()
    f_start.set_result(42)
    assert f_end.done()
    f_start = Future()
    f_end = Future()
    chain_future(f_start, f_end)
    assert not f_end.done()
    f_start.set_exception(ZeroDivisionError())
    assert f_end.done()
    f_start = Future()
    f_end = Future()
    chain_future(f_start, f_end)
    assert not f_end.done()
    f_start.cancel()
    assert f_end.done()
    f_start = Future()
    f_end = Future()

# Generated at 2022-06-12 13:15:22.665003
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42

    c = Future()
    d = Future()
    e = Future()
    chain_future(c, d)
    chain_future(d, e)
    assert not c.done()
    assert not d.done()
    assert not e.done()
    c.set_result(42)
    assert d.done()
    assert e.done()
    assert e.result() == 42


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-12 13:15:25.899926
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = ValueError('hello')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future2 = Future()
    future2.cancel()
    future_set_exception_unless_cancelled(future2, exc)

# Generated at 2022-06-12 13:15:29.654953
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    class FutureTest(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            try:
                future_set_exception_unless_cancelled(Future(), ValueError("error"))
                self.fail("future_set_exception_unless_cancelled hasn't cancelled.")
            except ValueError:
                pass

    unittest.main()

# Generated at 2022-06-12 13:15:37.032584
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado.ioloop import IOLoop

    class MyClass(object):
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(2)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor2")
        def func2(self, a, b):
            return a + b

        def test_thread_pool_executor(self):
            f = self.func(1, 2)
            assert isinstance(f, Future)
            IOLoop.current().add_future(f, lambda f: f.result())
            assert f.result() == 3

            f = self.func2(1, 2)
            assert isinstance(f, Future)

# Generated at 2022-06-12 13:15:43.080543
# Unit test for function chain_future
def test_chain_future():

    class Future(object):
        def __init__(self):
            self.listeners = []

        def chain(self, other):
            chain_future(self, other)

        def set_result(self, result):
            assert not self.listeners
            self.result = result

        def set_exception(self, exception):
            assert not self.listeners
            self.exception = exception

        def add_done_callback(self, callback):
            if self.result is not _NO_RESULT:
                callback(self)
            else:
                self.listeners.append(callback)

        done = property(lambda self: self.result is not _NO_RESULT)

    a = Future()
    b = Future()
    a.chain(b)
    assert not a.done
    assert not b.done


# Generated at 2022-06-12 13:16:23.161446
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio

    @unittest.skipIf(
        tornado.concurrent.get_tornado_future_impl() is not tornado.concurrent.TracebackFuture,
        "This test only works with TracebackFuture",
    )
    class TestChainFuture(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            with tornado.platform.asyncio.AsyncIOMainLoop() as io_loop:
                io_loop.make_current()

                def func() -> tornado.concurrent.Future:
                    raise Exception("Hello")

                f = tornado.concurrent.TracebackFuture()  # type: tornado.concurrent.TracebackFuture

# Generated at 2022-06-12 13:16:25.164237
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor()
        def foo(self):
            return 42

    f = Foo()
    assert f.foo() == 42

# Generated at 2022-06-12 13:16:31.449384
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    f = Future()
    g = Future()

    chain_future(f, g)

    g.cancel()
    assert f.cancelled()

    f = Future()
    g = Future()

    chain_future(f, g)

    f.set_result(3)
    assert f.result() == 3
    assert g.result() == 3

    f = loop.run_in_executor(None, lambda: 42)
    g = Future()

    chain_future(f, g)

    assert g.result() == 42

# Generated at 2022-06-12 13:16:32.289608
# Unit test for function chain_future
def test_chain_future():
    raise NotImplementedError()



# Generated at 2022-06-12 13:16:35.490799
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception('test'))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception('test'))
    assert future.exception() is None



# Generated at 2022-06-12 13:16:38.789335
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)

    try:
        future.result()
        assert False
    except Exception as new_exc:
        assert new_exc is exc

    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-12 13:16:46.134697
# Unit test for function chain_future
def test_chain_future():

    # We use these as a way to record the order of operations.
    order = _TestOrder()

    # Build two asyncio.Futures, one to be chained to the other.
    a = Future()
    b = Future()

    # Method to call that will be chained.
    @functools.wraps(chain_future)
    def _chain():
        order.operation(2)
        a.set_result(5)
        order.operation(5)

    # Register the method with future b so that it will be called when b is
    # complete.
    future_add_done_callback(b, _chain)

    # Call the function chain_future, passing in the results from above.
    order.operation(1)
    chain_future(a, b)
    order.operation(3)

    # Complete the asynchronous

# Generated at 2022-06-12 13:16:54.203888
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Create a Future (a)
    a = Future()
    b = Future()
    # Chain a to b
    chain_future(a, b)
    # Set a to 1
    a.set_result(1)
    # Value of b should be 1
    assert b.result() == 1

    # Create a Future (b)
    b = Future()
    # Chain a to b
    chain_future(a, b)
    # Set b to 1
    b.set_result(1)
    # Value of b should be 1
    assert b.result() == 1

    # Create a Future (c)
    c = Future()
    # Chain a to c
    chain_future(a, c)
    # Set b to 1
    c.set_result(1)
    #

# Generated at 2022-06-12 13:16:57.506756
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-12 13:17:00.984759
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def fn(self, sleep_time):
        import time
        time.sleep(sleep_time)
        return sleep_time

    class Test(object):
        executor = dummy_executor

    f = Test().fn(1)
    assert isinstance(f, Future)
    f.result()

# Generated at 2022-06-12 13:18:13.008080
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():  # pragma: no cover
    import tornado.testing
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestFutureSetResultUnlessCancelled(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestFutureSetResultUnlessCancelled, self).setUp()
            AsyncIOMainLoop().install()
            self.loop = asyncio.get_event_loop()

        def test_AsyncIOMainLoop(self):
            future1 = Future()
            future_set_result_unless_cancelled(future1, True)
            self.assertTrue(self.loop.run_until_complete(future1))

            future2 = Future()
            future2.cancel()
            future_set_result_unless_cancelled(future2, True)
            future3

# Generated at 2022-06-12 13:18:20.188514
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            @gen_test
            def check_chain():
                f1 = Future()
                f2 = Future()

                chain_future(f1, f2)

                self.assertFalse(f1.done())
                self.assertFalse(f2.done())
                f1.set_result(42)
                yield f2
                self.assertEqual(f2.result(), 42)
                yield self.wait([f1, f2])

            check_chain()

    test = ChainFutureTest()
    test.test_chain_future()



# Generated at 2022-06-12 13:18:21.184307
# Unit test for function chain_future
def test_chain_future():
    import logging
    logging.basicConfig()


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-12 13:18:24.983422
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, type("exc", (Exception,), {}))
    assert not future.cancelled()
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, type("exc", (Exception,), {}))
    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-12 13:18:31.210598
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # implementation note: This test depends on a global variable to
    # store the result, since the test happens in a Task and exceptions
    # can't be returned via Future.result().
    global exception_raised
    exception_raised = False

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = Future()
    exc = ZeroDivisionError()
    @gen.coroutine
    def set_exception():
        future_set_exception_unless_cancelled(future, exc)
    loop.run_until_complete(set_exception())
    assert not future.cancelled()
    assert future.exception() is exc

    future = Future()
    exc = ZeroDivisionError()
    future.cancel()

# Generated at 2022-06-12 13:18:34.272820
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, Future())
    assert f.cancelled()
    assert not f.result().done()



# Generated at 2022-06-12 13:18:43.126016
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class ChainFutureTestCase(unittest.TestCase):
        def test_return_value(self):
            io_loop = IOLoop()

            def callback(result):
                self.assertEqual(result, 1)
                io_loop.stop()

            async_future = Future()
            conc_future = concurrent.futures.Future()
            chain_future(conc_future, async_future)
            io_loop.add_future(async_future, callback)
            conc_future.set_result(1)
            io_loop.start()

        def test_exception(self):
            io_loop = IOLoop()


# Generated at 2022-06-12 13:18:47.759611
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)

# Spurious "fail" if the function is not imported by tornado.gen
# (or is imported as something other than "tornado.util.concurrent.run_on_executor")
run_on_executor.__test_key__ = False  # type: ignore



# Generated at 2022-06-12 13:18:55.505341
# Unit test for function run_on_executor
def test_run_on_executor():
    import contextlib
    import gc
    import sys
    import unittest
    import weakref

    from tornado.concurrent import (
        return_future,
        run_on_executor,
        TracebackFuture,
    )
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOIOLoop
    from tornado.test.util import unittest_reporter

    # Test basic functionality of run_on_executor()
    if sys.version_info >= (3, 5):
        import asyncio
        from tornado.gen import coroutines

        # This is a test of run_on_executor() itself, not the asyncio
        # implementation of the IOLoop, so it's easiest to just disable
        # asyncio for this test.

# Generated at 2022-06-12 13:18:58.958183
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    loop = asyncio.get_event_loop()
    f = loop.create_future()
    f.set_result("OK")
    future_set_exception_unless_cancelled(f, RuntimeError("foo"))

    f = loop.create_future()
    f.set_result("OK")
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError("foo"))
    loop.close()