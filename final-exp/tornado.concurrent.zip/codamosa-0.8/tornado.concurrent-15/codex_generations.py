

# Generated at 2022-06-12 13:09:54.115182
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class EmptyFutures(object):
        def __init__(self):
            self.futures=[]

        def append(self, future):
            self.futures.append(future)

        def cancel(self):
            for f in self.futures:
                f.cancel()

        def clear(self):
            self.futures=[]

    # Initialize an FIFO of completed futures
    # and a FIFO of completed futures
    futures_set = EmptyFutures()
    completed_futures = EmptyFutures()

    # Initialize a Future to be used for testing with
    future = Future()

    # Initialize a result for the future
    result = 20

    futures_set.append(future)
    # set the result of the future before cancelling
    # and ensure that the

# Generated at 2022-06-12 13:10:05.046506
# Unit test for function chain_future
def test_chain_future():  # type: ignore
    # type: () -> None
    future1 = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_result(1)
    assert future2.result() == 1

    future1_err = Future()  # type: Future[int]
    future2_err = Future()  # type: Future[int]
    chain_future(future1_err, future2_err)
    assert not future2_err.done()
    future1_err.set_exception(RuntimeError("derp"))
    try:
        future2_err.result()
    except RuntimeError:
        pass

# Generated at 2022-06-12 13:10:13.805548
# Unit test for function run_on_executor
def test_run_on_executor():
    class DummyFuture(Future):
        # Dummy future class that can be instantiated without arguments
        def __init__(self):
            super(DummyFuture, self).__init__()
            self.set_result(None)
        # Silence a mypy warning (running Python 2)
        def result(self):
            return None

    def get_result(future):
        return future.result()

    class A(object):
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def f(self):
            return 42

        @run_on_executor()
        def g(self):
            return 42

    a = A()

    test1 = get_result(a.f())

# Generated at 2022-06-12 13:10:24.319545
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    loop = asyncio.new_event_loop()
    result = loop.run_until_complete(
        asyncio.gather(
            test_future_set_exception_unless_cancelled_helper(),
            test_future_set_exception_unless_cancelled_helper(),
            test_future_set_exception_unless_cancelled_helper(),
        )
    )
    assert isinstance(result[0], asyncio.InvalidStateError)
    assert isinstance(result[1], asyncio.InvalidStateError)
    assert isinstance(result[2], asyncio.InvalidStateError)


async def test_future_set_exception_unless_cancelled_helper() -> None:
    future = asyncio.Future()
    future.set_result(None)
    future.c

# Generated at 2022-06-12 13:10:29.629966
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError('foo')
    # normal case
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    # cancelled case
    future = Future()
    future.cancel()
    with app_log.capture_exceptions():
        future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-12 13:10:38.697752
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.platform.asyncio
    import unittest

    asyncio.set_event_loop_policy(tornado.platform.asyncio.AnyThreadEventLoopPolicy())
    loop = asyncio.get_event_loop()

    class Test(object):
        def __init__(self, executor):
            self.executor = executor

        def stop(self):
            self.executor.shutdown()

        @run_on_executor
        def test(self):
            pass

        @run_on_executor(executor="_executor")
        def test_custom_keyword(self):
            pass

    executor = concurrent.futures.ThreadPoolExecutor(1)
    test = Test(executor)
    fut = test.test()
    fut_custom = test.test_custom_

# Generated at 2022-06-12 13:10:42.826900
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
    future.cancel()
    future_set_result_unless_cancelled(future, 6)
    assert future.cancelled()



# Generated at 2022-06-12 13:10:45.008930
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(a,b):
        return a+b
    f1 = dummy_executor.submit(f,1,2)
    assert f1.result() == 3

# Generated at 2022-06-12 13:10:52.710768
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    f1.set_exception(ValueError())
    chain_future(f1, f2)
    try:
        f2.result()
        assert False
    except ValueError:
        pass
    f1 = Future()
    f2 = Future()
    f2.set_result(42)
    chain_future(f1, f2)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()

# Generated at 2022-06-12 13:11:01.477518
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import BaseAsyncIOLoop
    from tornado.testing import AsyncTestCase, gen_test

    async def async_foo(self: Any) -> None:
        pass

    class AsyncClass(object):
        executor = dummy_executor

    class SyncClass(object):
        executor = dummy_executor

    # AsyncClass methods are already run in an executor
    if not isinstance(IOLoop.current(), BaseAsyncIOLoop):
        AsyncClass.foo = run_on_executor(async_foo)

    SyncClass.foo = run_on_executor(async_foo)


# Generated at 2022-06-12 13:11:15.380736
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    # test for asyncio.Future
    async_future = Future()
    future = futures.Future()
    chain_future(future, async_future)

    future.set_result(3)
    assert async_future.result() == 3

    future = futures.Future()
    chain_future(future, async_future)

    future.set_exception(RuntimeError())
    with pytest.raises(RuntimeError):
        loop.run_until_complete(async_future)

    # test for concurrent.futures.Future
    async_future = Future()
    future = futures.Future()
    chain_future(async_future, future)

    async_future.set_result(3)
    assert loop.run_until_complete(future) == 3

   

# Generated at 2022-06-12 13:11:18.846908
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_future = dummy_executor.submit(lambda x: x, 1, _keywords={'test': 1})
    assert is_future(test_future)
    assert test_future.done()
    assert test_future.result() == 1

# Generated at 2022-06-12 13:11:27.054999
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_main(self):
            # type: () -> None
            from tornado import gen
            from tornado.ioloop import IOLoop

            @gen.coroutine
            def f():
                future = Future()
                chain_future(gen.sleep(0.1), future)
                self.assertFalse(future.done())
                yield future

            IOLoop.current().run_sync(f)

    test = ChainFutureTest()
    test.test_main()



# Generated at 2022-06-12 13:11:29.828951
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result('result')
    loop.run_until_complete(f2)

# Generated at 2022-06-12 13:11:36.503090
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def test_func():
        future = Future()  # type: Future[_T]
        future_set_exception_unless_cancelled(future, ValueError("testing"))
        assert future.exception() is not None
    test_func()

    future = Future()  # type: Future[_T]
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("testing"))
    assert future.exception() is None

# Generated at 2022-06-12 13:11:38.116969
# Unit test for function chain_future
def test_chain_future():
    def f():
        pass


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-12 13:11:44.511348
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, -1)
    assert future.result() == -1
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.cancelled()
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.cancelled()

# Generated at 2022-06-12 13:11:46.874753
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future[int]
    future_set_resul

# Generated at 2022-06-12 13:11:52.645445
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def f(i):
        return i

    ioloop = IOLoop.current()

    def cb(fut):
        cb.called = True
        assert fut.result() == 10

    cb.called = False
    fut = Future()
    chain_future(f(10), fut)

    @gen.coroutine
    def test_coro():
        yield fut
        assert cb.called

    ioloop.run_sync(test_coro)

# Generated at 2022-06-12 13:11:59.131525
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # noqa: F811
    from tornado.testing import gen_test, AsyncTestCase
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    class F(AsyncTestCase):
        def test_1(self):
            f = Future()
            future_set_exception_unless_cancelled(f, ValueError())
            self.assertTrue(repr(f.exception()))

        @gen_test
        def test_2(self):
            f = Future()
            future_set_exception_unless_cancelled(f, ValueError())
            self.assertTrue(repr(f.exception()))
            yield f
            self.assertTrue(repr(f.exception()))

        @gen_test
        def test_3(self):
            f = Future

# Generated at 2022-06-12 13:12:08.482702
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = asyncio.Future()
    future_set_result_unless_cancelled(test_future, "finished")
    assert test_future.done()
    assert test_future.result() == "finished"

    # check with an already cancelled future
    test_future = asyncio.Future()
    test_future.cancel()
    future_set_result_unless_cancelled(test_future, "finished")
    assert test_future.cancelled()

# Generated at 2022-06-12 13:12:14.997401
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # noqa: F811
    import pytest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    class TestException(Exception):
        pass

    class MyAsyncIOTestCase(AsyncTestCase):
        def test_exception_after_cancel(self):
            loop = AsyncIOMainLoop()
            loop.make_current()

            future = asyncio.Future()  # type: Future
            future.cancel()

            with pytest.raises(TestException):
                future_set_exception_unless_cancelled(future, TestException())

    # Run the test above
    MyAsyncIOTestCase().test_exception_after_cancel()

# Generated at 2022-06-12 13:12:23.423097
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.gen import Return
    from tornado.ioloop import IOLoop

    # Define a class that uses the decorator
    class RunOnExecutorTestClass(object):
        executor = dummy_executor

        @run_on_executor
        def method(self):
            return 42

    loop = AsyncIOMainLoop()
    asyncio.set_event_loop(None)
    IOLoop.configure(AsyncIOMainLoop)

    obj = RunOnExecutorTestClass()
    result = loop.run_sync(obj.method)
    assert result == 42

    # This class uses a non-standard attribute name
    class RunOnExecutorTestClass(object):
        _executor = dummy_executor


# Generated at 2022-06-12 13:12:27.740364
# Unit test for function chain_future
def test_chain_future():
    future1 = asyncio.Future()
    future2 = asyncio.Future()
    chain_future(future1, future2)
    future1.set_result(True)
    io_loop = asyncio.get_event_loop()
    io_loop.run_until_complete(future2)
    assert future2.result() is True



# Generated at 2022-06-12 13:12:30.996029
# Unit test for function chain_future
def test_chain_future():
    a = futures.Future()
    b = Future()

    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    b = Future()
    chain_future(a, b)
    assert b.result() == 42



# Generated at 2022-06-12 13:12:39.531246
# Unit test for function run_on_executor
def test_run_on_executor():
    import inspect
    import unittest.mock

    class Timer(object):
        def __init__(self):
            self.io_loop = asyncio.get_event_loop()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def foo(self):
            return 42

        @run_on_executor(executor='executor')
        def bar(self):
            return 24

        @run_on_executor
        def baz(self, arg1, kwarg1=None):
            return arg1, kwarg1

        @run_on_executor
        def qux(self, arg1, arg2=24, kwarg1=None):
            return arg1, arg2, kwarg1


# Generated at 2022-06-12 13:12:47.949826
# Unit test for function chain_future
def test_chain_future():
    def cb(f):
        pass

    io_loop = IOLoop.current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    assert not f1.done()
    assert not f2.done()
    f1.set_result(3)
    io_loop.run_sync(lambda: f2)
    assert f1.result() == f2.result()

    # Test that chain_future doesn't call set_result if f2 is already done
    f1 = Future()
    f2 = Future()
    f2.set_result(4)
    chain_future(f1, f2)
    assert not f1.done()
    assert f2.done()
    f1.set_result(5)
    io_loop.run_

# Generated at 2022-06-12 13:12:56.685276
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(12)
    assert b.done()
    assert 12 == b.result()
    # Check that it works with a future that's already done
    c = Future()
    c.set_result(24)
    d = Future()
    chain_future(c, d)
    assert 24 == d.result()
    # Check that it works with a future that's already got an exc
    e = Future()
    e.set_exception(ZeroDivisionError())
    f = Future()
    chain_future(e, f)
    assert isinstance(f.exception(), ZeroDivisionError)
    a = Future()
    b = Future()

# Generated at 2022-06-12 13:13:04.314079
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_result(42)
    assert future2.result() == 42

    future3 = Future()
    future3.set_exception(RuntimeError("foo"))
    chain_future(future3, future2)

    assert future2.exception().__class__ == RuntimeError
    assert future2.exception().args == ("foo",)

    future4 = Future()
    future4.cancel()
    chain_future(future4, future2)
    assert future2.cancelled()  # type: ignore

# Generated at 2022-06-12 13:13:08.682279
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42
    h = Future()
    chain_future(f, h)
    assert h.result() == 42



# Generated at 2022-06-12 13:13:22.711018
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import os
    import signal

    class TestIOLoop(asyncio.AbstractEventLoop):
        def __init__(self) -> None:
            self._callbacks = []  # type: typing.List[Tuple[int, Callable[..., None]]]
            self._time = 0
            super(TestIOLoop, self).__init__()

        def add_callback(self, callback: Callable[..., None], *args: Any) -> None:
            self._callbacks.append((self._time, callback))

        def add_timeout(self, deadline: float, callback: Callable[..., None]) -> None:
            raise NotImplementedError()

        def remove_timeout(self, timeout: Union[int, float]) -> None:
            raise NotImplementedError()


# Generated at 2022-06-12 13:13:27.989861
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test, main

    class Test(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            r, w = asyncio.subprocess.PIPE, asyncio.subprocess.PIPE
            proc = yield self.io_loop.subprocess_exec(
                lambda: None, "true", stdin=r, stdout=w
            )
            fut = proc.wait()
            fut2 = Future()
            chain_future(fut, fut2)
            yield fut2

    test_chain_future.__test__ = False
    main()

# Generated at 2022-06-12 13:13:37.177616
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future1 = Future()
    future_set_result_unless_cancelled(future1,123)
    assert future1.done() == True
    assert future1.result() == 123
    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2,123)
    assert future2.done() == True
    assert future2.cancelled() == True
    future3 = Future()
    future3.set_result(456)
    future_set_result_unless_cancelled(future3,123)
    assert future3.result() == 456

# Generated at 2022-06-12 13:13:40.336851
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class CustomException(Exception):
        pass
    future = Future()
    future_set_exception_unless_cancelled(future, CustomException(
        "Test future_set_exception_unless_cancelled"))

# Generated at 2022-06-12 13:13:49.226867
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):

        @gen_test
        def test_chain_future(self) -> None:
            # Simple case
            f1 = Future()
            f2 = Future()
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, f2.result())

            # Exception is propagated too
            f3 = Future()
            f4 = Future()
            chain_future(f3, f4)
            f3.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                f4.result()

            #

# Generated at 2022-06-12 13:13:51.911374
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def sum(a,b):
        return a+b
    executor = DummyExecutor()
    future = executor.submit(sum, 1, 2)
    return future.result()

# Generated at 2022-06-12 13:13:57.245804
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future[int]
    future_set_result_unless_cancelled(future, 42)
    assert future_set_result_unless_cancelled(future, -1) is None
    assert future.result() == 42
    future.cancel()
    # Test that the second set_result_unless_cancelled does not raise an exception
    assert future_set_result_unless_cancelled(future, -1) is None


# Generated at 2022-06-12 13:14:07.539685
# Unit test for function chain_future
def test_chain_future():
    def check_future(a: Future, b: Future) -> None:
        assert b.done()
        assert b.result() == a.result()
        assert b.exception() == a.exception()
        assert b.exc_info() == a.exc_info()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    check_future(f1, f2)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    check_future(f1, f2)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel

# Generated at 2022-06-12 13:14:16.313564
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop


    class Foo(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def f(self):
            return "hi"

        @run_on_executor(executor="_thread_pool")
        def f2(self):
            return "hi"

    @run_on_executor
    def f():
        return "hi"

    @run_on_executor(executor="_thread_pool")
    def f2():
        return "hi"

    loop = IOLoop.current()
    executor = futures.ThreadPoolExecutor(1)
    f = Foo(executor)
    f2 = Foo(executor)

# Generated at 2022-06-12 13:14:25.195177
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    ioloop = IOLoop.instance()

    def f(result):
        return result

    def g(result):
        return f(result)

    futures = [Future(), Future()]
    chain_future(futures[0], futures[1])

    futures[0].set_result(42)
    assert futures[1].result() == 42
    futures[1].add_done_callback(lambda f: ioloop.stop())
    ioloop.start()

    futures[0] = Future()
    futures[1] = Future()
    chain_future(futures[0], futures[1])

    futures[0].set_exception(ZeroDivisionError())
    assert isinstance(futures[1].exception(), ZeroDivisionError)

# Generated at 2022-06-12 13:14:43.432114
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exc_info(f, sys.exc_info())
    f = Future()
    future_set_exc_info(f, sys.exc_info())

# Generated at 2022-06-12 13:14:52.335306
# Unit test for function chain_future
def test_chain_future():
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)
    f.set_result('test')
    assert g.result() == 'test'

    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)
    g.set_result('test')
    assert f.done()
    assert g.result() == 'test'

    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)
    f.set_exception(ValueError('a'))
    assert g.exception().args == ('a',)

    f = Future()  #

# Generated at 2022-06-12 13:14:58.565177
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future
    f2 = Future()  # type: Future
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()  # type: Future
    f2 = Future()  # type: Future
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    exc_info = (ValueError, ValueError(), None)
    assert f2.exception() is exc_info[1]
    assert future_set_exc_info(f2, exc_info) is None
    assert f2.exception() is exc_info[1]



# Generated at 2022-06-12 13:15:07.000544
# Unit test for function chain_future
def test_chain_future():
    import threading

    f1 = Future()
    f2 = Future()

    def wake_f1() -> None:
        time.sleep(0.01)
        f1.set_result(8)

    threading.Thread(target=wake_f1).start()

    def f2_done(f: "Future[int]") -> None:
        test_case.assertFalse(f.cancelled())
        test_case.assertFalse(f.exception() is not None)
        test_case.assertTrue(f.done())
        test_case.assertEquals(f.result(), 8)
        test_case.stop()

    chain_future(f1, f2)
    f2.add_done_callback(f2_done)


# Generated at 2022-06-12 13:15:09.868634
# Unit test for function chain_future
def test_chain_future():
    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    assert not f2.cancelled()



# Generated at 2022-06-12 13:15:19.073564
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        assert future.result() == object()
        assert future.result() is not object()

    # check the chain_future
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    assert not fut2.done()
    fut1.set_result(object())
    assert fut2.result() == object()
    assert fut2.result() is not object()

    # check the callback when chain_future
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    assert not fut2.done()
    fut1.add_done_callback(callback)
    fut1.set_result(object())

    # check both done
    fut1 = Future()
    fut2 = Future()
    fut1

# Generated at 2022-06-12 13:15:26.716562
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import logging
    import concurrent.futures

    def _run(*args, **kwds):
        return kwds

    from tornado.testing import AsyncTestCase, gen_test

    class TestNoExecutor(AsyncTestCase):
        @gen_test
        def test_success(self):
            @run_on_executor
            def fn(self, *args, **kwds):
                return _run(*args, **kwds)

            response = yield fn(self, value=1)
            self.assertEqual(response, {"value": 1})

        @gen_test
        def test_failure(self):
            @run_on_executor
            def fn(self, *args, **kwds):
                raise ValueError("test_failure")


# Generated at 2022-06-12 13:15:34.811197
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    def f():
        return 1

    def g():
        return 2

    class Test(AsyncTestCase):

        @gen_test
        def test_future_chain(self):
            b = Future()
            a = dummy_executor.submit(f)
            chain_future(a, b)
            self.assertEqual(b.result(), 1)

        @gen_test
        def test_closing_future_chain_order(self):
            # This test is to make sure that when a is closing the second
            # future, the second future is already done.
            b = Future()
            a = dummy_executor.submit(g)
            chain_future(a, b)
            a.result()

# Generated at 2022-06-12 13:15:37.704987
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    try:
        f.set_result(True)
    except Exception:
        f.cancel()
    future_set_result_unless_cancelled(f, False)
    assert f.cancelled()


# Generated at 2022-06-12 13:15:45.412772
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError("foo"))
    exc = f2.exception()
    assert str(exc) == "foo"
    assert isinstance(exc, ValueError)

    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1, f2 = Future(), Future()
    chain_future(f1, f2)

# Generated at 2022-06-12 13:16:20.158747
# Unit test for function chain_future
def test_chain_future():
    io_loop = asyncio.get_event_loop()
    f1 = io_loop.create_future()
    f2 = io_loop.create_future()
    f1.set_result(3)
    assert f1.done()
    assert f2.done()
    assert f1.result() == 3
    assert f2.result() == 3

# Generated at 2022-06-12 13:16:21.232732
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda: 3) == 3



# Generated at 2022-06-12 13:16:28.059504
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future
    result = []
    future_set_exception_unless_cancelled(future, ValueError())
    # ValueError should be stored in future
    assert future.exception() is not None
    #  callback should be called after future is done
    future_add_done_callback(future, lambda future: result.append(future.exception()))
    assert result[0] is future.exception()
    # ValueError should be stored in future
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    # ValueError should not be stored in future, logging should be called.
    assert future.exception() is None


# Generated at 2022-06-12 13:16:34.914345
# Unit test for function chain_future
def test_chain_future():
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)

    fut1.set_result(42)
    assert fut2.result() == 42

    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)

    fut1.set_exception(RuntimeError())
    assert fut2.exception() is not None

    fut2.cancel()
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)

    fut1.set_result(42)
    assert fut2.result() == 42
    assert fut2.exception() is None



# Generated at 2022-06-12 13:16:42.402039
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    f1.set_exception(RuntimeError("foo"))
    chain_future(f1, f2)
    # Exception is copied to f2 if f2 is not already done.
    assert f2.exception().args[0] == "foo"
    f1 = Future()
    f2 = Future()
    f2.set_exception(RuntimeError("bar"))
    chain_future(f1, f2)
    # Exception is not copied to f2 if f2 is already done.

# Generated at 2022-06-12 13:16:44.672578
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(0)
    assert future2.result() == 0



# Generated at 2022-06-12 13:16:49.341313
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    @gen.coroutine
    def call_future_set_exception_unless_cancelled():
        future_set_exception_unless_cancelled(future, ValueError("exception"))

    call_future_set_exception_unless_cancelled()
    future.cancel()
    with ExpectLog(gen_log, "Exception after Future was cancelled"):
        IOLoop.current().run_sync(call_future_set_exception_unless_cancelled)

# Generated at 2022-06-12 13:16:58.252998
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def _test(self, a, b, a_result, b_result):
            a = futures.Future()
            b = Future()
            chain_future(a, b)
            a.set_result(a_result)
            self.assertEqual(b.result(), b_result)

        @gen_test
        def test_return(self):
            self._test(1, 2, 1, 2)

        @gen_test
        def test_exception(self):
            a = futures.Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(RuntimeError)
            with self.assertRaises(RuntimeError):
                b.result()

# Generated at 2022-06-12 13:17:04.274527
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import is_future
    loop = IOLoop.current()
    def test_fn(x: int, y: int) -> int:
        return x + y
    future = dummy_executor.submit(test_fn, 1, 2)
    assert is_future(future)
    loop.run_sync(lambda: future)
    assert future.result() == 3

if __name__ == '__main__':
    test_DummyExecutor_submit()

# Generated at 2022-06-12 13:17:06.159539
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-12 13:18:13.507846
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    if not f.cancelled():
        future_set_result_unless_cancelled(f, 123)
        assert f.result()==123
    else:
        assert f.cancelled()

    f2 = Future()
    f2.cancel()
    future_set_result_unless_cancelled(f2, 123)
    assert f2.cancelled()



# Generated at 2022-06-12 13:18:21.455911
# Unit test for function chain_future
def test_chain_future():
    from tornado.util import TimeoutError
    from tornado.testing import gen_test, AsyncTestCase
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    class TestException(Exception):
        pass

    @gen_test
    async def test(self):
        # test both Future objects
        a = Future()
        b1 = Future()
        chain_future(a, b1)
        b2 = Future()
        chain_future(a, b2)

        # test Future object and concurrent.futures.Future
        a = Future()
        b1 = futures.Future()
        chain_future(a, b1)
        b2 = futures.Future()
        chain_future(a, b2)

        # test both concurrent.futures.Future


# Generated at 2022-06-12 13:18:30.194335
# Unit test for function chain_future
def test_chain_future():
    import threading
    import time

    finished = threading.Event()

    def do_something():
        time.sleep(0.01)

    def callback(future):
        finished.set()

    f1 = Future()
    chain_future(f1, Future())
    chain_future(f1, Future())
    f1.set_result(None)
    assert finished.wait(0.1)

    for _ in range(5):
        finished.clear()
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f2.add_done_callback(callback)
        f1.set_result(None)
        assert finished.wait(0.1)

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-12 13:18:39.941854
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.platform.asyncio import to_asyncio_future

    class FutureChainTest(unittest.TestCase):
        def setUp(self):
            self.success_result = object()
            self.failure_exc_info = (
                type("exception"),
                Exception("exception"),
                object(),
            )

        @staticmethod
        def _success_future():
            f = Future()
            f.set_result(FutureChainTest.success_result)
            return f

        @staticmethod
        def _failure_future():
            f = Future()
            f.set_exception(FutureChainTest.failure_exc_info[1])
            return f


# Generated at 2022-06-12 13:18:48.275064
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import functools
    import types

    @functools.lru_cache(maxsize=None)  # type: ignore
    def blocking_fn(x):
        # type: (int) -> str
        return str(x)

    class MyRequestHandler:
        executor = dummy_executor

        @run_on_executor
        def blocking_io(self, x):
            # type: (int) -> str
            return blocking_fn(x)

        def sync_io(self, future, x):
            # type: (Future, int) -> None
            future.set_result(blocking_fn(x))

    handler = MyRequestHandler()
    assert handler.blocking_io(42) is handler.blocking_io(42)  # type: ignore

# Generated at 2022-06-12 13:18:55.888010
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent.futures import ThreadPoolExecutor
    from tornado.ioloop import IOLoop

    # type: ignore
    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            # type: ignore
            self.executor = ThreadPoolExecutor(1)

        def test_method_raised(self):
            @run_on_executor
            def f(self, a):
                raise ValueError(a)

            @run_on_executor(executor="_thread_pool")
            def g(self, a):
                raise ValueError(a)

            for f in (f, g):
                f = f(self, 1)
                self.io_loop.run_sync(lambda: f)
                self

# Generated at 2022-06-12 13:19:01.761459
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()  # type: Future
            f2 = Future()  # type: Future
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-12 13:19:06.446629
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    io_loop = asyncio.get_event_loop()

    @gen_test
    async def test():
        af = Future()
        cf = futures.Future()
        chain_future(af, cf)
        af.set_result(42)
        assert (await cf) == 42

    io_loop.run_sync(test)

# Generated at 2022-06-12 13:19:10.984822
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    @gen.coroutine
    def f():
        raise gen.Return(42)

    f2 = f()
    result = None

    def callback(future):
        nonlocal result
        result = future.result()

    chain_future(f2, asyncio.ensure_future(f2))
    f2.add_done_callback(callback)

    assert f2.result() == 42
    assert result == 42

# Generated at 2022-06-12 13:19:19.231158
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    executor = unittest.mock.Mock()

    class Foo:
        executor = executor
        _thread_pool = executor

    @run_on_executor
    def foo(self):
        return 42

    @run_on_executor(executor="_thread_pool")
    def bar(self):
        return 87

    future = foo(Foo())
    future2 = bar(Foo())
    executor.submit.assert_has_calls(
        [
            unittest.mock.call(foo, Foo()),
            unittest.mock.call(bar, Foo()),
        ],
        any_order=True,
    )
    assert future.result() == 42
    assert future2.result() == 87

# Unit test