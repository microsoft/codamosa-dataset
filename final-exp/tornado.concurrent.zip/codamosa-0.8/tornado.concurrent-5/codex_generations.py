

# Generated at 2022-06-12 13:09:56.623685
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    assert not f1.done()
    assert not f2.done()

    f1.set_result(None)
    assert f1.done()
    assert f2.done()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    assert not f1.done()
    assert not f2.done()

    f1.set_exception(ZeroDivisionError())
    assert f1.done()
    assert f2.done()

    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "should have raised ZeroDivisionError"



# Generated at 2022-06-12 13:10:02.281256
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = Exception("foo")
    future_set_exception_unless_cancelled(future, exception)
    assert future.result() == exception

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exception)
    assert not future.done()

# Generated at 2022-06-12 13:10:11.646996
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)
    assert not g.done()
    f.set_result(42)
    assert g.done()
    assert g.result() == 42

    g2 = Future()  # type: Future[int]
    chain_future(f, g2)
    assert g2.done()
    assert g2.result() == 42

    f2 = Future()  # type: Future[int]
    g3 = Future()  # type: Future[int]
    chain_future(f2, g3)
    f2.set_exception(ZeroDivisionError())
    assert g3.done()

# Generated at 2022-06-12 13:10:18.158761
# Unit test for function chain_future
def test_chain_future():
    error = Exception("error")
    traceback = None

    async def async_operation() -> "Future[int]":
        return 5

    async def async_future_operation() -> "Future[int]":
        return Future()

    async def async_error_operation() -> "Future[int]":
        return Future()

    def main():
        with futures.ThreadPoolExecutor(1) as executor:
            target_future = Future()

            # Test that set_result works
            future = async_operation()
            chain_future(future, target_future)
            assert target_future.result() == 5

            # Test that set_exc_info works
            future = async_error_operation()
            future_set_exc_info(future, (type(error), error, traceback))

# Generated at 2022-06-12 13:10:25.533309
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    # pylint: disable=protected-access
    class Foo(object):
        executor = dummy_executor
        was_set_result = None
        was_set_exception = None
        was_set_exc_info = None
        was_done = None

        @run_on_executor
        def func(self):
            # type: () -> str
            return "result"

        @run_on_executor
        def bad_func(self):
            # type: () -> None
            raise Exception("exception")

        @run_on_executor
        def err_func(self):
            # type: () -> None
            raise ValueError("error")


# Generated at 2022-06-12 13:10:30.346752
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    assert not f2.done()

    f.set_result(42)
    assert f2.done()
    assert f2.result() == 42

    # Calling multiple times has no additional effect
    chain_future(f, f2)
    assert f2.done()



# Generated at 2022-06-12 13:10:37.417337
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f_executor = futures.ThreadPoolExecutor(max_workers=1)
    f_loop = asyncio.get_event_loop()
    test_future = f_loop.run_in_executor(f_executor, lambda _: None)

    f_loop.run_until_complete(test_future)
    assert test_future.cancelled()
    # Set result
    f_loop.run_until_complete(test_future)
    future_set_result_unless_cancelled(test_future, "Test_result")

    assert test_future.result() is None


# Generated at 2022-06-12 13:10:42.101993
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError("should have raised ZeroDivisionError")

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError("foo"))
    try:
        f2.result()
    except ZeroDivisionError as e:
        assert e.args

# Generated at 2022-06-12 13:10:43.129664
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 100)
    assert (future.result() == 100)


# Generated at 2022-06-12 13:10:51.272774
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)

    f.set_result(42)
    assert g.result() == 42
    f = Future()
    g = Future()
    chain_future(g, f)
    f.set_result(42)
    assert g.result() == 42
    f = Future()
    g = Future()
    chain_future(g, f)
    g.set_result(42)
    assert f.result() == 42

    f = Future()
    g = Future()
    chain_future(f, g)

    f.set_exception(ZeroDivisionError)
    f = Future()
    with pytest.raises(ZeroDivisionError):
        f.result()

    f = Future()
    g = Future()
    chain

# Generated at 2022-06-12 13:11:02.744401
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    @gen_test
    def test_chain_future():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        assert not future2.done()
        future1.set_result(42)
        assert future2.done()
        assert future2.result() == 42
        return

    test_chain_future()

# Generated at 2022-06-12 13:11:04.439871
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())



# Generated at 2022-06-12 13:11:09.211219
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f.result() == f2.result() == 42
    f = Future()
    f2 = Future()
    f.set_exception(RuntimeError())
    chain_future(f, f2)
    assert f.exception() == f2.exception()

# Generated at 2022-06-12 13:11:16.067718
# Unit test for function chain_future
def test_chain_future():
    def run_test(a_class, b_class):

        class Callback:
            def __init__(self):
                self.called = False
                self.args = None
                self.kwargs = None

            def __call__(self, *args, **kwargs):
                self.called = True
                self.args = args
                self.kwargs = kwargs

        f1 = a_class()
        f2 = b_class()

        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

        # f2 shouldn't be called when f1 is already done
        callback = Callback()
        f1 = a_class()
        f2 = b_class()
        f1.set_result(42)

# Generated at 2022-06-12 13:11:18.936280
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():  # type: ignore
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-12 13:11:29.132417
# Unit test for function run_on_executor
def test_run_on_executor():
    from concurrent.futures import Future as CFuture, ThreadPoolExecutor

    class Future(CFuture):
        def add_done_callback(self, callback):
            pass

    def target(a, b):
        return a + b

    class TestObject(object):
        def __init__(self):
            self.executor = ThreadPoolExecutor(2)
            self.executor1 = ThreadPoolExecutor(2)

        @run_on_executor(executor='executor1')
        def target2(self, a, b):
            return a + b

        @run_on_executor
        def target1(self, a, b):
            return a + b

        def target3(self, a, b):
            return a + b


# Generated at 2022-06-12 13:11:34.071075
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.platform.asyncio import to_tornado_future

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()

        def test_chain_future(self):
            @asyncio.coroutine
            def foo():
                yield
                return "Hello"

            async_future = self.loop.create_future()
            foo_future = to_tornado_future(foo(), loop=self.loop)
            chain_future(foo_future, async_future)
            result = to_tornado_future(async_future, loop=self.loop).result()
            self.assertEqual(result, "Hello")

    unittest.main()

# Generated at 2022-06-12 13:11:43.385019
# Unit test for function chain_future
def test_chain_future():
    import unittest

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            main_future = Future()

            def set_result():
                main_future.set_result(True)

            chained_future = Future()
            chained_future.add_done_callback(lambda f: io_loop.add_callback(set_result))
            chain_future(main_future, chained_future)

            io_loop.add_timeout(time.time() + 0.1, lambda: set_result())

            main_future.add_done_callback(lambda f: io_loop.stop())
            io_loop.start()

            self.assertTrue(chained_future.result())

    unittest.main()



# Generated at 2022-06-12 13:11:48.116868
# Unit test for function chain_future
def test_chain_future():
    import tornado.platform.asyncio

    asyncio.set_event_loop_policy(tornado.platform.asyncio.AnyThreadEventLoopPolicy())

    _future_set_result_unless_cancelled_tests()
    _chain_future_tests()



# Generated at 2022-06-12 13:11:49.424337
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(pow, 2, 3)

# Generated at 2022-06-12 13:11:59.281906
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()

# Generated at 2022-06-12 13:12:01.323064
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())



# Generated at 2022-06-12 13:12:10.289978
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    asyncio.set_event_loop(asyncio.new_event_loop())
    a = Future()
    b = Future()
    futures.wait([a,b])
    assert a.cancelled()
    assert b.cancelled()
    future_set_result_unless_cancelled(a, "a")
    future_set_result_unless_cancelled(b, "b")
    assert a.cancelled()
    assert b.cancelled()
    # Test future_set_result_unless_cancelled() with concurrent.Future
    c = futures.Future()
    d = futures.Future()
    assert c.done()
    assert d.done()
    future_set_result_unless_cancelled(c, "c")

# Generated at 2022-06-12 13:12:16.531007
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing
    import tornado.web
    import tornado.websocket

    from tornado.escape import json_decode

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_result(42)
    assert future2.result() == 42

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_exception(RuntimeError("error"))
    try:
        future2.result()
    except RuntimeError:
        pass
    else:
        raise AssertionError("should have raised exception")

    @run_on_executor
    def blocking(self):
        # type: (Any) -> None
        future1 = Future()
        future

# Generated at 2022-06-12 13:12:22.473488
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    # Make sure we have a handler to absorb log messages
    app_log.name = __file__
    with app_log.catch_log() as cm:
        future_set_exception_unless_cancelled(f, RuntimeError)
        assert isinstance(cm, list)
        assert not cm
    # after this
    f = Future()
    future_set_exception_unless_cancelled(f, RuntimeError)
    assert f.exception() is not None



# Generated at 2022-06-12 13:12:30.736350
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    import unittest
    import logging

    logging.getLogger().setLevel(logging.DEBUG)

    def throw_exception():
        raise Exception("This is a test exception")

    def throw_and_set_result():
        future = Future()
        future.set_result(None)
        throw_exception()

    f = Future()
    future_set_exception_unless_cancelled(f, Exception("This is a test exception"))
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("This is a test exception"))

    f = Future()
    future_set_exception_unless_cancelled(f, Exception("This is a test exception"))
    future_set_result_unless_cancelled(f, None)



# Generated at 2022-06-12 13:12:37.696666
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    te = DummyExecutor()
    # expected type: (int, float) -> float
    def test(x, y):
        return float(x) + y
    f = te.submit(test, 3, 2.4)
    assert f.result() == 5.4
    assert f.done()
    assert f.result() == 5.4
    f = te.submit(test, 3, 2.4)
    assert f.result() == 5.4
    f = te.submit(test, 3, 2.4)
    assert f.result() == 5.4
test_DummyExecutor_submit()


# Generated at 2022-06-12 13:12:44.589298
# Unit test for function chain_future
def test_chain_future():
    from tornado import ioloop

    loop = ioloop.IOLoop()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    loop.add_future(f2, lambda x: loop.stop())
    loop.call_later(1, f1.set_result, None)
    loop.start()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    loop.add_future(f2, lambda x: loop.stop())
    loop.call_later(1, f1.set_exception, RuntimeError())
    loop.start()

# Generated at 2022-06-12 13:12:50.094499
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    @asyncio.coroutine
    def chain(a: Future, b: Future) -> None:
        result = yield a
        b.set_result(result)

    f1 = Future()
    f2 = Future()
    loop.run_until_complete(chain(f1, f2))

    f1.set_result(42)
    assert loop.run_until_complete(f2) == 42

# Generated at 2022-06-12 13:12:53.937597
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future1, future3)
    future1.set_result(123)

    assert future2.result() == 123
    assert future3.result() == 123


# Generated at 2022-06-12 13:13:11.214257
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """Test for `tornado.concurrent.future_set_exception_unless_cancelled`"""
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.set_result("result")
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.result() == "result"

# Generated at 2022-06-12 13:13:19.295582
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.gen import multi
    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            a = loop.create_future()
            b = loop.create_future()

            x = loop.create_future()
            y = loop.create_future()

            chain_future(x, y)

            rf, wf = loop.run_until_complete(multi(a, b))

            rf.set_result("done")

            self.assertEqual("done", wf.result())

            # Check that calling chain_future with

# Generated at 2022-06-12 13:13:22.164356
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise Exception("exception")
    except Exception as exc:
        future_set_exception_unless_cancelled(future, exc)
    assert future.done()
    assert not future.cancelled()
    assert future.exception()


# Generated at 2022-06-12 13:13:24.625910
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    try:
        dummy_executor.submit(lambda: 123)
    except futures.CancelledError:
        pass

    try:
        dummy_executor.submit(lambda: 1 / 0)
    except ZeroDivisionError:
        pass

# Generated at 2022-06-12 13:13:27.268321
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def return_value(x: str, y: str) -> str:
        return x + y
    executor = DummyExecutor()
    future = executor.submit(return_value, 'x', 'y')
    # concurrent.futures.Future
    assert future.result() == 'xy'

# Generated at 2022-06-12 13:13:32.721662
# Unit test for function chain_future
def test_chain_future():
    from tornado import testing

    class MyFuture(Future):
        def result(self):
            return 1

        def exception(self):
            return ValueError()

    if sys.version_info >= (3, 5):
        class MyConcurrentFuture(futures.Future):
            def result(self):
                return 1

            def exception(self):
                return ValueError()

    @testing.gen_test
    def test_future():
        a = MyFuture()
        b = Future()
        chain_future(a, b)
        self.assertFalse(b.done())
        a.set_result(3)
        self.assertEqual(b.result(), 3)


# Generated at 2022-06-12 13:13:37.091152
# Unit test for function chain_future
def test_chain_future():
    e = asyncio.Future()
    f = asyncio.Future()

    chain_future(e, f)
    assert not f.done()

    e.set_result(42)
    return f


# Unit tests for function future_set_result_unless_cancelled

# Generated at 2022-06-12 13:13:46.377468
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import concurrent.futures
    import time

    class Test(object):
        def __init__(self):
            self._thread_pool = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop.current()

            self.io_loop.call_later(0.1, self.stop)

        @run_on_executor(executor="_thread_pool")
        def test(self):
            time.sleep(0.1)
            return True

        def stop(self):
            self.io_loop.stop()

        def start(self):
            self.io_loop.start()

    test = Test()
    future = test.test()


# Generated at 2022-06-12 13:13:52.916109
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    from tornado.platform.asyncio import AsyncIOMainLoop

    @tornado.testing.gen_test
    def test_gen_test():

        io_loop = AsyncIOMainLoop()

        f1 = io_loop.run_sync(lambda: Future())
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.done()
        assert f2.result() == 42

    test_gen_test()

# Generated at 2022-06-12 13:13:59.186868
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import asyncio
    from concurrent.futures import Future
    from tornado.ioloop import IOLoop

    f1 = Future()
    f2 = Future()

    def cancel_f1_on_f2(future):
        # type: (Future) -> None
        if not f1.cancel():
            f1.set_result(None)
        f2.cancel()

    chain_future(f1, f2)
    future_add_done_callback(f2, cancel_f1_on_f2)
    ioloop = IOLoop.current()
    ioloop.add_future(f1, lambda _: ioloop.stop())
    ioloop.start()
    assert f1.cancelled()
    assert f2.cancelled()



# Generated at 2022-06-12 13:14:33.262509
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_chain(self):
            @run_on_executor
            def f(x):
                return x + 1

            futures = []

            for i in range(1):
                f1 = Future()
                f2 = f(i)
                chain_future(f1, f2)
                futures.append((f1, f2))

# Generated at 2022-06-12 13:14:36.294272
# Unit test for function run_on_executor
def test_run_on_executor():

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def method(self, a, b):
            return a + b

    foo = Foo()
    foo.method(5, 17)

# Generated at 2022-06-12 13:14:42.684485
# Unit test for function run_on_executor
def test_run_on_executor():
    # This test is only run once the decorator has been replaced
    # by an async version, so we can safely use async def here.
    # type: () -> None
    class Test:
        executor = dummy_executor

        @run_on_executor
        def foo(self, *args, **kwargs):
            return (args, kwargs)

        @run_on_executor(executor="_executor")
        def bar(self, *args, **kwargs):
            return (args, kwargs)

        @run_on_executor
        async def baz(self, *args, **kwargs):
            return (args, kwargs)

    t = Test()

    res = t.foo(1, 2, a=3, b=4)

# Generated at 2022-06-12 13:14:47.425346
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("This is an exception"))
    assert isinstance(future.exception(), Exception)
    future2 = Future()
    future2.cancel()
    future_set_exception_unless_cancelled(future2, Exception("This is an exception"))

# Generated at 2022-06-12 13:14:54.689550
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @staticmethod
        # TODO: Refactor this test to be a unittest.
        # According to https://gitlab.com/python/mypy/issues/6951,
        # assertRaises should be typed.
        @gen_test
        def gen_test_chain_future():
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            assert g.result() == 42
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(RuntimeError())
            with pytest.raises(RuntimeError):
                g.result()

    TestChainFuture.gen_test_

# Generated at 2022-06-12 13:15:01.663908
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future as ConcurrentFuture
    from tornado.gen import Future as TornadoFuture
    from unittest import TestCase

    class FutureChainTests(TestCase):
        def setUp(self):
            # type: () -> None
            self.concurrent_future = ConcurrentFuture()
            self.tornado_future1 = TornadoFuture()
            self.tornado_future2 = TornadoFuture()
            self.executor = dummy_executor

        def test_chain_to_concurrent_future(self):
            # type: () -> None
            chain_future(self.tornado_future1, self.concurrent_future)
            self.tornado_future1.set_result(True)
            self.assertTrue(self.concurrent_future.done())

# Generated at 2022-06-12 13:15:05.501660
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1

# Generated at 2022-06-12 13:15:14.782328
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop, TimeoutError

    f = Future()
    g = Future()  # type: Future[int]

    chain_future(f, g)

    def f_done(future: Future) -> None:
        assert not g.done()
        future_set_result_unless_cancelled(f, 42)

    def g_done(future: Future[int]) -> None:
        assert future.done()
        assert g.result() == 42
        assert f.result() == 42
        io_loop.stop()

    io_loop = IOLoop.current()
    io_loop.add_callback(f_done, f)
    io_loop.add_callback(g_done, g)


# Generated at 2022-06-12 13:15:17.713991
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn():
        return 1
    future = dummy_executor.submit(fn)
    assert future.result() == 1
    assert future.done() == True
    assert future.cancelled() == False
    assert future.running() == False

# Generated at 2022-06-12 13:15:25.551966
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    assert not f.done()
    assert not g.done()
    f.set_result("f")
    assert g.result() == "f"
    # if f has an exception, g should get the same:
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(RuntimeError("test"))
    with pytest.raises(RuntimeError):
        g.result()

    # Chain a normal Future to a Future with cancel()

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result("f")
    assert g.result() == "f"
    f = Future()
    g = Future()

# Generated at 2022-06-12 13:16:58.943044
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def test_cancelled():
        future = Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, Exception())
        await future

    loop = asyncio.new_event_loop()
    loop.run_until_complete(test_cancelled())
    loop.close()

# Generated at 2022-06-12 13:17:07.318024
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    def void() -> None:
        pass

    @gen.coroutine
    def test_chain_future() -> None:
        a = Future()
        b = Future()
        c = Future()
        chain_future(a, b)
        chain_future(b, c)
        a.set_result(42)
        c.set_result(24)
        assert 42 == (yield a)
        assert 42 == (yield b)
        assert 24 == (yield c)

        a = Future()
        b = Future()
        c = Future()
        chain_future(a, b)
        chain_future(b, c)
        chain_future(c, a)
        a.set_result(42)
        with pytest.raises(RuntimeError):
            yield a
       

# Generated at 2022-06-12 13:17:14.830059
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.testing
    import tornado.testing.gen_test

    # Using AsyncIOMainLoop in testing is not recommended, but in this
    # case it is necessary because the test needs to ensure that
    # future_set_exc_info is being called.

    class TestFutureSetExceptionUnlessCancelled(tornado.testing.AsyncTestCase):
        def get_new_ioloop(self) -> IOLoop:
            return AsyncIOMainLoop()

        @tornado.testing.gen_test
        async def test_future_set_exception_unless_cancelled(self):
            future = Future()
            future.set_result(None)
            self.assertTrue(future.done())
           

# Generated at 2022-06-12 13:17:18.296285
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception() is None

# Generated at 2022-06-12 13:17:26.854650
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import threading
    import time

    @run_on_executor  # type: ignore
    def f():
        # type: () -> int
        return 42

    @run_on_executor(executor="_thread_pool")  # type: ignore
    def g(n):
        # type: (int) -> None
        pass

    class C(object):
        def __init__(self):
            self.executor = dummy_executor
            self._thread_pool = dummy_executor

        @run_on_executor  # type: ignore
        def f(self):
            # type: () -> int
            return 42


# Generated at 2022-06-12 13:17:30.928269
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    with pytest.raises(asyncio.CancelledError):
        future.result()


# Generated at 2022-06-12 13:17:39.892263
# Unit test for function chain_future
def test_chain_future():
    def check_future(f, result, exception):
        if exception is not None:
            if not f.done():
                raise Exception('Future was not done')
            try:
                f.result()
            except Exception as e:
                assert type(e) is type(exception)
                if isinstance(e, str):
                    assert e == exception
                else:
                    assert e.args == exception.args
            else:
                raise Exception('Future should have been exception %r' % exception)
        else:
            assert f.done()
            assert f.result() == result

    # Chain before finished
    f1 = futures.Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    check_future(f2, 1, None)

    #

# Generated at 2022-06-12 13:17:49.484340
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()
    f1.set_result(42)
    assert f1.done()
    assert f2.done()
    assert f2.result() == 42
    exc = RuntimeError('test')
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(exc)
    assert f1.done()
    assert f2.done()
    assert f2.exception() is exc


if hasattr(asyncio, "isfuture"):
    is_future = asyncio.isfuture
    future_add_done_callback = asyncio.ensure_future

# Generated at 2022-06-12 13:17:57.297749
# Unit test for function run_on_executor
def test_run_on_executor():

    import unittest
    import tornado
    from tornado import testing

    class TestCase(testing.AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.executor = dummy_executor

        @run_on_executor
        def func(self, a, b, callback=None):
            # type: (int, int, Optional[Callable[[Any], None]]) -> int
            return a + b

        @tornado.gen.coroutine
        def test_run_on_executor(self):
            r = yield self.func(1, 2)
            self.assertEqual(r, 3)

            # Test that extra arguments after the callback are ok (compatibility
            # with @return_future).
            r = yield self.func(10, 20, None)


# Generated at 2022-06-12 13:18:00.074009
# Unit test for function chain_future
def test_chain_future():
    def f1(a, b):
        return a + b

    f2 = Future()
    f1(1, 2)
    chain_future(f1, f2)


__all__ = [
    "Future",
    "ReturnValueIgnoredError",
    "futures",
    "is_future",
    "chain_future",
    "run_on_executor",
]

# Generated at 2022-06-12 13:19:40.674605
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @functools.wraps(future_set_exception_unless_cancelled)
    def wrapped(future: Future[int], exc: BaseException) -> None:
        future_set_exception_unless_cancelled(future, exc)
    future = Future()
    wrapped(future, RuntimeError())
    assert future.exception() is not None
    assert future.exception().args == ("test",)
    future.cancel()
    wrapped(future, ValueError())
    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-12 13:19:48.403561
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)

    assert not b.done()
    a.set_result(42)
    assert b.done()
    assert b.result() == 42

    # chaining does not affect already-done futures
    c = Future()
    c.set_result(10)
    chain_future(a, c)
    assert c.result() == 10

    # exceptions pass through
    d = Future()
    e = Future()
    chain_future(d, e)
    d.set_exception(ValueError("the answer"))
    assert e.done()
    assert e.exception() is not None
    with pytest.raises(ValueError):
        e.result()


# For backwards-compatibility (aliases were removed in Tornado 4.0