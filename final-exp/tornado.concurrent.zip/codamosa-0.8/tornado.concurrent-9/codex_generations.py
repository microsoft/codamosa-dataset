

# Generated at 2022-06-12 13:09:57.848199
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.log import gen_log
    from tornado.testing import AsyncTestCase
    from tornado import gen
    from tornado.iostream import StreamClosedError
    from tornado.platform.asyncio import AsyncIOMainLoop

    def get_future():
        future = Future()
        assert not future.done()
        assert not future.cancelled()
        return future

    @gen.coroutine
    def cancel_future(future):
        yield gen.moment
        future.cancel()

    @gen.coroutine
    def raise_exception(future):
        yield gen.moment
        try:
            raise StreamClosedError()
        except Exception as e:
            future_set_exception_unless_cancelled(future, e)



# Generated at 2022-06-12 13:10:03.244124
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-12 13:10:08.787060
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42
    # Now check the other direction
    future3 = Future()
    future4 = Future()
    chain_future(future3, future4)
    future4.cancel()
    future3.set_result(42)
    assert future4.cancelled()

# Generated at 2022-06-12 13:10:13.109937
# Unit test for function chain_future
def test_chain_future():
    from concurrent import futures
    from tornado import gen
    from tornado.testing import AsyncTestCase

    future = futures.Future()  # type: futures.Future[int]
    chain_future(future, gen.convert_yielded(future))
    future.set_result(42)
    assert gen.convert_yielded(future).result() == 42

# Generated at 2022-06-12 13:10:24.292270
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class F:
        # some attribute used by run_on_executor()
        executor = "executor"

        # some attribute used by the decorator call
        symbol = 0

        def __init__(self) -> None:
            self.executor = unittest.mock.Mock()
            self.executor.submit.return_value = Future()
            self.executor.submit.return_value.set_result(None)
            self.args = None  # type: Optional[Tuple]
            self.kwargs = None  # type: Optional[dict]

        # some method called by the decorated method
        def foo(self, *args, **kwargs) -> None:
            self.args = args
            self.kwargs = kwargs

        # the method to be decorated

# Generated at 2022-06-12 13:10:28.729717
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    task = Future()
    task.add_done_callback(lambda f: f.exception())
    future_set_exception_unless_cancelled(task, RuntimeError("abc"))
    assert task.exception() is not None

    task = Future()
    task.cancel()
    future_set_exception_unless_cancelled(task, RuntimeError("abc"))

# Generated at 2022-06-12 13:10:37.999849
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # pylint: disable=unused-argument
    assert dummy_executor.submit(lambda x: x * 10, 2) == dummy_executor.submit(lambda x: x * 10, 2)
    assert dummy_executor.submit(lambda x: x * 10, 2) == dummy_executor.submit(lambda x: x * 10, 2)
    assert dummy_executor.submit(lambda x: x * 10, 2) == dummy_executor.submit(lambda x: x * 10, 2)
    assert dummy_executor.submit(lambda x: x * 10, 2) == dummy_executor.submit(lambda x: x * 10, 2)
    assert dummy_executor.submit(lambda x: x * 10, 2) == dummy_executor.submit(lambda x: x * 10, 2)
    assert dummy_executor

# Generated at 2022-06-12 13:10:42.488516
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exception = Exception("test")
    future_set_exception_unless_cancelled(f, exception)
    assert not f.done()
    assert f.exception() == exception
    f.cancel()
    future_set_exception_unless_cancelled(f, exception)
    assert f.done()

# Generated at 2022-06-12 13:10:50.752949
# Unit test for function chain_future
def test_chain_future():
    # two futures that were created before the asyncio backend
    # (without the result_type parameter)
    f1 = futures.Future()  # type: futures.Future[int]
    f2 = futures.Future()  # type: futures.Future[int]
    f1.set_result(1)
    assert not f2.done()
    chain_future(f1, f2)
    assert f2.result() == 1
    assert f2.exception() is None

    # two futures that were created after the asyncio backend
    # (with the result_type parameter)
    f3 = asyncio.Future()  # type: Future[int]
    f4 = asyncio.Future()  # type: Future[int]
    f3.set_result(2)
    assert not f4.done()
    chain_future

# Generated at 2022-06-12 13:10:52.292770
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception('test'))

# Generated at 2022-06-12 13:11:04.299612
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: nocover
    import time
    import unittest

    from tornado import gen
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

            self.executor = futures.ThreadPoolExecutor(1)

        @gen.coroutine
        def test_run_on_executor(self):
            @run_on_executor
            def a():
                return 42

            res = yield a()
            self.assertEqual(42, res)


# Generated at 2022-06-12 13:11:06.597535
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()


# Generated at 2022-06-12 13:11:14.094095
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    asyncio_future = Future()
    future = futures.Future()

    other = Future()
    future_set_result_unless_cancelled(other, None)
    assert other.done()

    other = Future()
    future_set_exception_unless_cancelled(other, Exception)
    assert other.done()

    try:
        1 / 0
    except:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    future_set_exc_info(asyncio_future, exc_info)

    assert future.done()
    assert asyncio_future.done()

    assert future.exception() == asyncio_future.exception()


# Generated at 2022-06-12 13:11:18.468401
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestClass:
        executor = dummy_executor

        @run_on_executor
        def func(self):
            return 5

        @run_on_executor(executor='_thread_pool')
        def func2(self):
            return 6
    test = TestClass()
    assert test.func().result() == 5
    assert test.func2().result() == 6

# Generated at 2022-06-12 13:11:28.742366
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest
    import concurrent
    import concurrent.futures
    from tornado import gen
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            # Check that chain_future copies the contents from one future to another
            f1 = Future()
            f2 = concurrent.futures.Future()

# Generated at 2022-06-12 13:11:32.879928
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    if sys.version_info < (3, 6):
        # future_set_result_unless_cancelled is only supported on 3.6+
        return

    from tornado.concurrent import Future

    future = Future()
    future_set_result_unless_cancelled(future, None)  # should not raise

    f2 = Future()
    f2.cancel()
    future_set_result_unless_cancelled(f2, None)  # should not raise


if __name__ == "__main__":
    test_future_set_result_unless_cancelled()

# Generated at 2022-06-12 13:11:37.784100
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado import gen

    @gen.coroutine
    def main():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    IOLoop.current().run_sync(main)



# Generated at 2022-06-12 13:11:43.384837
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    class FutureTestCase(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()
            future_set_exception_unless_cancelled(future, Exception("abc"))
            self.assertEqual(future.exception().args, ("abc",))

    unittest.main()

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-12 13:11:53.394041
# Unit test for function chain_future
def test_chain_future():
    def check_result(f):
        assert f.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f2, f3)
    f1.set_result(42)
    assert f2.result() == 42
    assert f3.result() == 42

    f1 = Future()
    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f2, f3)

# Generated at 2022-06-12 13:11:59.611486
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import concurrent.futures

    @run_on_executor
    def wait_and_callback(r, callback):
        callback((threading.current_thread(), r))

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @gen_test
        def test_run_on_executor(self):
            t = yield wait_and_callback(1, callback=self.stop)
            self.assertNotEqual(t[0], threading.current_thread())
            self.assertEqual(t[1], 1)
            self.future = wait_and_callback

# Generated at 2022-06-12 13:12:13.749745
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    @run_on_executor(executor='_thread_pool')
    def get_five(self):
        self.result = 5
        return 5

    @run_on_executor(executor='_thread_pool')
    def catch_error(self, f):
        # This will throw an exception if the first future is cancelled
        # before this future is added as a callback.
        return f.result()

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.f1 = Future()
            self.f2

# Generated at 2022-06-12 13:12:18.559335
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.done()
    assert isinstance(future.result(), ValueError)
    cancelled_future = Future()
    cancelled_future.cancel()
    assert cancelled_future.done()
    future_set_exception_unless_cancelled(cancelled_future, ValueError())

# Generated at 2022-06-12 13:12:27.323170
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.platform.asyncio import to_asyncio_future

    io_loop = IOLoop()
    io_loop.make_current()

    c = Future()
    d = Future()
    chain_future(c, d)
    f = Future()

    d.add_done_callback(lambda f: f.result())

    def set_result():
        c.set_result(42)

    io_loop.call_later(0.1, set_result)
    io_loop.call_later(0.15, io_loop.stop)


# Generated at 2022-06-12 13:12:30.929229
# Unit test for function chain_future
def test_chain_future():
    a = concurrent.futures.Future()
    b = Future()
    chain_future(a, b)
    a.set_result(True)
    assert b.result()
    assert b.done()
    c = Future()
    chain_future(b, c)
    assert c.result()
    assert c.done()

# Generated at 2022-06-12 13:12:37.925361
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado import testing
    from tornado.testing import gen_test

    class TestFutureSetExceptionUnlessCancelled(testing.AsyncTestCase):
        @gen_test
        async def test_set_exception_unless_cancelled(self):
            f = Future()
            f.cancel()
            try:
                f.set_exception(RuntimeError())
            except InvalidStateError:
                self.fail("Exception raised when it shouldn't be raised.")

            # Wait for the logging call to finish
            await asyncio.sleep(0.1, loop=self.io_loop)

    testing.run_test(TestFutureSetExceptionUnlessCancelled)

# Generated at 2022-06-12 13:12:43.611357
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-12 13:12:52.253405
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        @run_on_executor
        def blocking(self, a, b):
            return a + b

        @gen_test
        def test_executor1(self):
            self.executor = dummy_executor
            res = yield self.blocking(1, 2)
            self.assertEqual(res, 3)

        @gen_test
        def test_executor2(self):
            self._thread_pool = dummy_executor
            res = yield self.blocking(1, 2)
            self.assertEqual(res, 3)

        @gen_test
        def test_executor3(self):
            self.__threadpool = dummy_executor
            res = yield self.blocking

# Generated at 2022-06-12 13:13:01.051627
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # first, test that an exception in the first future is propagated to the second
    f1 = Future()  # type: Future[Any]
    f2 = Future()  # type: Future[Any]
    chain_future(f1, f2)
    f1.set_exception(Exception("test"))
    assert_future_exception(f2, Exception, "test")

    # then make sure that results are propagated
    f1 = Future()  # type: Future[Any]
    f2 = Future()  # type: Future[Any]
    chain_future(f1, f2)
    f1.set_result(42)
    assert_future_result(f2, 42)

    # now try the same tests but with concurrent.futures.Futures
    f1

# Generated at 2022-06-12 13:13:11.028106
# Unit test for function chain_future
def test_chain_future():
    from .testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self) -> None:
            super(ChainFutureTest, self).setUp()
            self.future = Future()
            self.callback_future = Future()

        @gen_test
        def tearDown(self) -> None:
            if not self.future.done():
                raise Exception("future not done")
            super(ChainFutureTest, self).tearDown()

        def callback(self, future: Future) -> None:
            if future.exception() is not None:
                raise future.exception()
            self.callback_future.set_result(future.result() * 2)


# Generated at 2022-06-12 13:13:19.134569
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from unittest.mock import Mock

    @asyncio.coroutine
    def f_coro():
        return 5

    @gen.coroutine
    def f_gen():
        return 6

    f1 = f_coro()
    f2 = f_gen()
    f3 = Future()
    f4 = Future()
    # Assert f1 and f2 are indeed before done
    assert not f1.done()
    assert not f2.done()

    # Chain two asyncio.Futures into f3
    chain_future(f1, f3)
    assert not f3.done()
    f1.set_result(5)
    assert f3.done()
    assert f3.result() == 5

    # Chain two gen.Futures into f4
   

# Generated at 2022-06-12 13:13:43.107726
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase
    from tornado import gen

    class ChainFutureTestCase(AsyncTestCase):
        def test_chain(self):
            a = Future()
            b = Future()

            chain_future(a, b)

            @gen.coroutine
            def test():
                a.set_result(42)
                self.assertEqual(42, (yield b))

            self.io_loop.run_sync(test)

        def test_chain_cancels(self):
            a = Future()
            b = Future()

            chain_future(a, b)
            a.cancel()
            @gen.coroutine
            def test():
                a.set_result(42)
                self.assertTrue(b.cancelled())


# Generated at 2022-06-12 13:13:52.373711
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures
    import traceback
    import unittest
    import warnings

    from tornado.ioloop import IOLoop
    import tornado.testing
    from tornado.util import _ObjDict

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)

        class MyTestCase(tornado.testing.AsyncTestCase):
            def setUp(self):
                super(MyTestCase, self).setUp()
                self.executor = concurrent.futures.ThreadPoolExecutor(1)

            def executor_method(self, arg1, arg2):
                return arg1 + arg2

            @run_on_executor
            def f(self, arg1, arg2=1):
                self.io_loop.add_callback(self.stop)
               

# Generated at 2022-06-12 13:14:00.589574
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    def f():
        return 1

    class Foo:
        executor = dummy_executor

        @run_on_executor()
        def foo(self):
            return f()

        @run_on_executor(executor="executor")
        def bar(self):
            return f()

    foo = Foo()
    f1 = foo.foo()
    f2 = foo.bar()
    assert f1.result() == f2.result() == 1
    io_loop.close()



# Generated at 2022-06-12 13:14:04.359968
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert not future.exception()

# Generated at 2022-06-12 13:14:13.680663
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    with app_log.capture_logs('tornado') as logs:
        future_set_exception_unless_cancelled(future, ValueError())
        future_set_exception_unless_cancelled(future, ValueError())
        future_set_exception_unless_cancelled(future, ValueError())
    assert len(logs) == 1

# Generated at 2022-06-12 13:14:18.507452
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise Exception("test exception")
    except Exception as e:
        future_set_exception_unless_cancelled(future, e)
    assert future.exception() is not None
    future = Future()
    future.cancel()
    try:
        raise Exception("test exception")
    except Exception as e:
        future_set_exception_unless_cancelled(future, e)
    assert future.exception() is None

# Generated at 2022-06-12 13:14:21.119420
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummyExecutor = DummyExecutor() # type: DummyExecutor
    future = dummyExecutor.submit(lambda: 3) # type: Future
    assert future.result() == 3


# Generated at 2022-06-12 13:14:31.938817
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    # Test that chain_future copies the results of one future to another.
    def check_future(src, dst, exc_info=None):
        if not exc_info:
            if hasattr(src, "exc_info") and src.exc_info() is not None:  # type: ignore
                exc_info = src.exc_info()  # type: ignore
            else:
                exc_info = (None, src.exception(), None)
        if exc_info[1] is None:
            assert dst.exception() is None
            dst.set_result(src.result())
        else:
            future_set_exc_info(dst, exc_info)


# Generated at 2022-06-12 13:14:39.349418
# Unit test for function run_on_executor
def test_run_on_executor():
    import time
    import unittest
    import concurrent.futures
    from tornado.testing import gen_test, AsyncTestCase

    def blocking_task():
        time.sleep(0.1)
        return 42

    class MyClass(object):
        executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking_call(self):
            return blocking_task()

    class TestCase(AsyncTestCase):
        @gen_test
        def test_run_on_executor(self):
            obj = MyClass()
            result = yield obj.blocking_call()
            self.assertEqual(result, 42)

    unittest.main()

# Generated at 2022-06-12 13:14:46.857635
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()

    a = Future()
    b = Future()
    chain_future(a, b)

    def on_complete_a(fut: Future) -> None:
        assert fut is a
        a.done()
        assert not b.done()

    def on_complete_b(fut: Future) -> None:
        assert fut is b
        io_loop.stop()

    future_add_done_callback(a, on_complete_a)
    future_add_done_callback(b, on_complete_b)

    io_loop.start()
    io_loop.close()



# Generated at 2022-06-12 13:15:22.138468
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    f3 = Future()

    chain_future(f, f2)
    f.set_result('hello')
    assert f2.result() == 'hello'
    f.set_result('world')
    assert f2.result() == 'hello'

    f = Future()
    f2 = Future()
    f3 = Future()

    chain_future(f2, f)
    f2.set_result('hello')
    assert f.result() == 'hello'
    f2.set_result('world')
    assert f.result() == 'hello'

    f = Future()
    f2 = Future()
    f3 = Future()

    chain_future(f2, f)
    f2.set_exception(ValueError())

# Generated at 2022-06-12 13:15:25.047708
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42



# Generated at 2022-06-12 13:15:30.467729
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            # Create a new `asyncio.Future` with no IOLoop attached,
            # to simulate a `concurrent.futures.Future`.
            self.future_instance = (
                futures.Future() if sys.version_info[0] < 3 else Future()
            )
            if isinstance(self.future_instance, Future):
                self.future_instance = to_tornado_future(self.future_instance)


# Generated at 2022-06-12 13:15:34.080811
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception("foo")
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future = Future()
    future_set_exception_unless_cancelled(future, None)
    assert future.exception() is None

# Generated at 2022-06-12 13:15:39.770503
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """
    >>> @gen.coroutine
    ... def f1():
    ...    yield gen.sleep(0.01)
    ...    raise Exception('test')
    >>> @gen.coroutine
    ... def f2():
    ...    yield gen.sleep(0)
    ...    raise Exception('test2')
    >>> f1 = f1()
    >>> f2 = f2()
    >>> chain_future(f1, f2)
    >>> f2.exception() # doctest: +ELLIPSIS
    Exception('test',)
    >>> f1.exception() is None
    True
    """



# Generated at 2022-06-12 13:15:42.120356
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()

# Generated at 2022-06-12 13:15:46.077376
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()

    chain_future(future1, future2)

    future1.set_result(42)
    # future2 must not be done yet

    assert not future2.done()

    future2.set_result(42)
    # future2 is done now

    assert future2.done()

# Generated at 2022-06-12 13:15:54.328287
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop
    import functools
    import unittest
    import warnings

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        def setUp(self):
            self.loop = IOLoop() # type: IOLoop
            self.loop.make_current()
            self.future = Future() # type: Future
            self.exception_raised = False
            warnings.simplefilter("error", DeprecationWarning)

        def tearDown(self):
            self.loop.clear_current()
            self.loop.close(all_fds=True)

        def on_future_done(self, future):
            try:
                future.result()
            except Exception as e:
                self.exception_raised = True


# Generated at 2022-06-12 13:16:03.996346
# Unit test for function chain_future
def test_chain_future():
    import time

    @gen.coroutine
    def f():
        yield gen.Task(IOLoop.current().add_timeout, time.time() + 0.01)
        raise Exception()

    a = f()
    b = Future()
    chain_future(a, b)
    # a is not done, so b has not been called
    assert not b.done()

    # run the rest of the IOLoop, which will cause the exception to
    # raise
    IOLoop.current().add_future(a, lambda a: None)
    IOLoop.current().start()
    # a is complete so b should be complete
    assert b.done()
    try:
        b.result()
    except Exception:
        pass
    else:
        assert False, "did not get expected exception"


# backwards compatibility (

# Generated at 2022-06-12 13:16:10.078074
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    @gen_test
    async def test_chain_future():
        # type: () -> typing.Any
        # Create a synthetic future and make sure it propagates
        # cancel to its child.
        parent = Future()
        child = Future()
        chain_future(parent, child)
        # Finish the parent
        parent.set_result(42)
        self.assertFalse(child.done())
        # Cancel the child
        child.set_result(44)
        self.assertEqual(44, await child)

# Generated at 2022-06-12 13:17:34.996527
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()

    async def async_foo(x):
        await asyncio.sleep(0.1)
        return x

    @run_on_executor
    def blocking_foo(x):
        time.sleep(0.1)
        return x

    @run_on_executor
    def raise_foo(x):
        time.sleep(0.1)
        if x == 1:
            raise Exception("foo")
        else:
            return x

    def assert_future(a, b, value, exception=None):
        if exception:
            assert_raises(exception, a.result)
        else:
            assert_equal(a.result(), value)
        if b.done():
            if exception:
                assert_raises(exception, b.result)
           

# Generated at 2022-06-12 13:17:38.341569
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = futures.Future()
    future_set_result_unless_cancelled(f, None)
    f.cancel()
    future_set_result_unless_cancelled(f, "value")
    assert f.cancelled()

# Generated at 2022-06-12 13:17:40.755940
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError('Error occured'))
    assert future.exception() is not None

# Generated at 2022-06-12 13:17:50.268684
# Unit test for function chain_future
def test_chain_future():  # pragma: nocover
    executor = futures.ThreadPoolExecutor(1)

    def a():
        return 42

    def b(x):
        return x * 2

    def c(x):
        return x > 0

    af = executor.submit(a)
    bf = Future()
    cf = Future()
    chain_future(af, bf)
    chain_future(bf, cf)

    assert not af.done()
    assert not bf.done()
    assert not cf.done()

    @cf.add_done_callback
    def done_cb(f):
        assert f.result() == True
        executor.shutdown()

    bf.add_done_callback(b)
    cf.add_done_callback(c)
    assert cf.result() == True
    execut

# Generated at 2022-06-12 13:17:54.534332
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import ioloop

    AsyncIOMainLoop().install()

    def hello():
        print('hello world')
    hello()
    loop = ioloop.IOLoop.instance()
    loop.run_sync(lambda : dummy_executor.submit(hello))


# Generated at 2022-06-12 13:17:56.649303
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(None)
    assert f2.done()



# Generated at 2022-06-12 13:17:58.475496
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    if not future.cancelled():
        future_set_result_unless_cancelled(future, "result")
        assert future.done()
        assert future.result() == "result"



# Generated at 2022-06-12 13:18:04.610498
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x, 1)
    assert future is not None
    assert not future.cancelled()
    assert future.running()
    assert not future.done()
    assert future.result() == 1
    assert future.exception() is None
    assert not future.cancelled()
    assert not future.running()
    assert future.done()


# Generated at 2022-06-12 13:18:11.719455
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    async def test_future():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        assert f1.done() is False
        assert f2.done() is False
        chain_future(f1, f2)
        assert f1.done() is False
        assert f2.done() is False
        loop.call_later(0.1, f1.set_result, 1)
        res = await f2
        assert res == 1
    loop.run_until_complete(test_future())
    loop.close()

# Generated at 2022-06-12 13:18:19.810616
# Unit test for function run_on_executor
def test_run_on_executor():
    call_args = []  # type: list
    results = []
    exception = None  # type: Optional[BaseException]
    result_future = None  # type: Future

    def executor_submit(fn, *args, **kwargs):
        call_args.append((fn, args, kwargs))
        return result_future

    class Foo(object):
        executor = executor_submit

        @run_on_executor
        def bar(self, arg, kwarg="default"):
            return arg, kwarg

        @run_on_executor(executor="executor")  # for testing multiple attributes
        def baz(self, arg, kwarg="default"):
            return arg, kwarg

    f = Foo()
    assert f.executor == executor_submit