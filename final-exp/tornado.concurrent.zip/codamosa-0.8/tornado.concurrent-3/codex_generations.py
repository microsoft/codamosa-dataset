

# Generated at 2022-06-12 13:09:56.838762
# Unit test for function chain_future
def test_chain_future():
    import time
    from tornado.ioloop import IOLoop, TimeoutError

    def wait_for_future(future):
        if not future.done():
            raise TimeoutError()
        return future.result()

    def cb(f):
        assert f.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_result(42)
    IOLoop.current().run_sync(functools.partial(wait_for_future, f2), timeout=0.1)
    assert f2.result() == 42
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f

# Generated at 2022-06-12 13:10:06.172403
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    def set_result_on_asyncio_future(future):
        # type: (asyncio.Future) -> None
        future.set_result(1)

    future = asyncio.Future()
    assert future.cancelled() == False
    future.set_result(2)
    assert future.cancelled() == False
    assert future.result() == 2

    future = asyncio.Future()
    future.cancel()
    assert future.cancelled() == True
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    assert future.cancelled() == False

# Generated at 2022-06-12 13:10:14.470705
# Unit test for function chain_future
def test_chain_future():
    import tornado.ioloop
    io_loop = tornado.ioloop.IOLoop.current()

    # Test with concurrent.futures.Future
    def callback(x):
        io_loop.stop()
        assert x == 42

    f1 = futures.Future()
    f2 = Future()
    chain_future(f1, f2)
    future_add_done_callback(f2, callback)
    f1.set_result(42)
    io_loop.start()

    # Test with asyncio.Future
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    future_add_done_callback(f2, callback)
    f1.set_result(42)
    io_loop.start()

# Generated at 2022-06-12 13:10:19.070727
# Unit test for function chain_future
def test_chain_future():
    f = Future()  # type: Future[None]
    g = Future()  # type: Future[None]
    chain_future(f, g)
    f.set_result(None)
    assert g.done()



# Generated at 2022-06-12 13:10:25.891868
# Unit test for function chain_future
def test_chain_future():
    import unittest

    asyncio.Future = Future

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            result = object()

            chain_future(f1, f2)

            f1.set_result(result)
            self.assertEqual(f2.result(), result)

            f1 = Future()
            f2 = Future()
            exception = RuntimeError()

            chain_future(f1, f2)

            f1.set_exception(exception)
            self.assertEqual(f2.exception(), exception)

            f1 = Future()
            f2 = Future()

            chain_future(f1, f2)
            f2.set_result(result)


# Generated at 2022-06-12 13:10:35.687812
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    assert not g.done()
    f.set_result(1)
    assert g.done()
    assert g.result() == 1

    f = Future()
    g = Future()
    chain_future(f, g)
    assert not g.done()
    f.set_exception(ZeroDivisionError())
    assert g.done()
    assert isinstance(g.exception(), ZeroDivisionError)

    f = Future()
    g = Future()
    chain_future(f, g)
    g.cancel()
    assert f.done()
    assert g.done()

    f = Future()
    g = Future()
    chain_future(f, g)
    f.cancel()

# Generated at 2022-06-12 13:10:41.713619
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyClass(object):
        def __init__(self):
            self.executor = dummy_executor
            self.result = None

        @run_on_executor
        def foo(self, a, b):
            return a + b

    async def test_myclass(loop):
        obj = MyClass()
        await obj.foo(1, 2)
        assert obj.result == 3

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_myclass(loop))



# Generated at 2022-06-12 13:10:44.925509
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-12 13:10:52.651541
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    future = Future()

    class Result:
        result = None

    result = Result()

    # Chaining self.io_loop.add_future to a Future is slightly
    # different from just calling add_done_callback, so we test it
    # separately.
    def set_result(future: Future) -> None:
        assert not future.done()
        result.result = 42
        assert not future.done()
        future.set_result(None)

    chain_future(future, asyncio.ensure_future(set_result(future)))
    assert not result.result
    future.set_result(None)
    tornado.testing.gen_test(lambda: future)()
    assert result.result == 42


# Generated at 2022-06-12 13:11:01.371444
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase, bind_unused_port, Future

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.io_loop.set_debug(True)
            self._result = None
            self._exception = None
            self._future = Future()

        @gen_test
        def test_chain_future(self):
            port = self.io_loop.run_sync(bind_unused_port)
            self._future_done_callback()

        def _future_done_callback(self):
            def _done(future):
                if future.exception() is not None:
                    self._exception = future.exception()
                else:
                    self._result = future.result()


# Generated at 2022-06-12 13:11:09.730325
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert not future.cancelled()
    assert future.done()



# Generated at 2022-06-12 13:11:11.431547
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("foo"))

# Generated at 2022-06-12 13:11:12.637371
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test = DummyExecutor().submit(lambda x: x + 1, 1)
    assert test.result() == 2

# Generated at 2022-06-12 13:11:21.747922
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    def copy(future):
        assert future is f1
        if f2.done():
            return
        if f1.exception() is not None:
            f2.set_exception(f1.exception())
        else:
            f2.set_result(f1.result())

    def nop():
        pass

    chain_future(f1, f2)

    assert not f1.done()
    assert not f2.done()
    f2.cancel()
    assert not f2.done()
    f1.cancel()
    assert f1.done()
    assert f2.done()

    f2 = Future()
    chain_future(f1, f2)
    assert f1.done()
    assert f2.done

# Generated at 2022-06-12 13:11:30.727343
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado import testing

    class Test1(testing.AsyncTestCase):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.executor = dummy_executor

        @run_on_executor
        def foo(self):
            return 1


# Generated at 2022-06-12 13:11:38.446744
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = futures.Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(6)
    assert future2.result() == 6

    # Test cancellation
    future3 = Future()
    future4 = Future()
    chain_future(future3, future4)
    future4.cancel()
    future3.set_result(10)
    assert future4.cancelled() is True


# Tests for function future_set_result_unless_cancelled

# Generated at 2022-06-12 13:11:41.627761
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    e = Exception()
    future_set_exception_unless_cancelled(future, e)
    assert future.exception() is e
    future.cancel()
    future.exception() # raise the exception

# Generated at 2022-06-12 13:11:51.887349
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()

    def f():
        return 1

    def callback(future):
        io_loop.stop()
        assert future.result() == 1

    # Test with asyncio.Future
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future_add_done_callback(future2, callback)
    future1.set_result(1)

    io_loop.start()

    # Test with concurrent.futures.Future
    future3 = futures.Future()
    future4 = futures.Future()
    chain_future(future3, future4)

    future_add_done_callback(future4, callback)
    future3.set_result(1)

    io_loop.start()

    # Test with exception in main Future


# Generated at 2022-06-12 13:11:56.218418
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def run_test(future: Future) -> None:
        future_set_result_unless_cancelled(future, 5)
        assert future.result() == 5

    loop = asyncio.get_event_loop()
    loop.run_until_complete(run_test(asyncio.Future()))
    loop.run_until_complete(run_test(asyncio.ensure_future(asyncio.Future())))



# Generated at 2022-06-12 13:12:01.241552
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import pytest
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    from tornado.concurrent import dummy_executor
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test, AsyncTestCase

    def function_dummy_executor_submit(a: int, b: int) -> int:
        return a + b

    class TestDummyExecutorSubmit(AsyncTestCase):
        @gen_test(timeout=10)
        async def test_dummy_executor_submit(self) -> None:
            ioloop = IOLoop.current()
            # test dummy_executor.submit
            ioloop.run_sync(self._test_dummy_executor_submit)


# Generated at 2022-06-12 13:12:14.666151
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import BaseEventLoop

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    if f2.done():
        raise Exception("f2 should not be done")
    f1.set_result("f1_result")
    if not f2.done():
        raise Exception("f2 should be done")
    if f2.exception() is not None:
        raise Exception("f2 should not have an exception")
    if f2.result() != "f1_result":
        raise Exception("f2 should have f1's result")
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    if f2.done():
        raise Exception("f2 should not be done")

# Generated at 2022-06-12 13:12:19.289694
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1, f2 = Future(), Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None



# Generated at 2022-06-12 13:12:26.474445
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()
    f1.set_result(42)
    assert f1.result() == f2.result() == 42
    # Make sure f2 is done even if f1 isn't (which would happen if
    # f1 was a Tornado Future)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(37)
    assert f1.result() == f2.result() == 37

# Generated at 2022-06-12 13:12:28.120299
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42



# Generated at 2022-06-12 13:12:36.564245
# Unit test for function chain_future
def test_chain_future():
    import unittest

    @unittest.skipIf(sys.version_info < (3, 5, 2), "python issue26169")
    class Test_chain_future(unittest.TestCase):
        def test_chain_future(self):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            f = Future()
            g = Future()
            chain_future(f, g)

            f.set_result(3)
            self.assertEqual(g.result(), 3)

            f = Future()
            g = Future()
            h = Future()
            chain_future(f, g)
            chain_future(f, h)

            f.set_exception(ZeroDivisionError())

# Generated at 2022-06-12 13:12:39.992535
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

# Generated at 2022-06-12 13:12:48.533393
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    f.set_result(42)
    chain_future(f, g)
    assert g.result() == 42
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    g.cancel()
    chain_future(f, g)
    f.set_result(42)
    assert g.cancelled()
    f = Future()  # type: Future[int]

# Generated at 2022-06-12 13:12:57.190971
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures

    executor = concurrent.futures.ThreadPoolExecutor(1)
    io_loop = None  # type: Optional[IOLoop]

    class A(object):
        executor = executor

        @run_on_executor
        def f(self, x, y):
            return x + y

        @run_on_executor
        def err(self):
            raise Exception("foo")

        @run_on_executor(executor='undefined_attr_name')
        def undefined(self):
            pass

    a = A()


# Generated at 2022-06-12 13:13:06.855961
# Unit test for function chain_future
def test_chain_future():
    executor = futures.ThreadPoolExecutor(1)

    @functools.wraps(chain_future)
    def chain(a: Future, b: Future) -> None:  # noqa: F821
        return chain_future(a, b)

    f1 = Future()
    f2 = Future()
    chain(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1, f2 = Future(), Future()
    chain(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1, f2 = Future(), Future()
    chain(f1, f2)
    f1.cancel()
    assert f2.cance

# Generated at 2022-06-12 13:13:15.981917
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        pass

    f1 = futures.Future()
    assert f1.done() == False
    assert f1.cancelled() == False
    assert f1.running() == False
    assert f1.exception() == None
    f2 = futures.Future()
    assert f2.done() == False
    assert f2.cancelled() == False
    assert f2.running() == False
    assert f2.exception() == None

    chain_future(f1, f2)
    assert f2.done() == False
    assert f2.cancelled() == False
    assert f2.running() == False
    assert f2.exception() == None

    f2.add_done_callback(callback)
    f1.set_result('test')
    # f1 changed f

# Generated at 2022-06-12 13:13:39.761739
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    def check_future(a: Future, b: Future) -> None:
        assert a.result() == b.result()
        assert a.exception() == b.exception()

    # a completes before b
    a = Future()
    b = Future()
    chain_future(a, b)
    check_future(a, b)
    a.set_result(42)
    loop.run_until_complete(a)
    loop.run_until_complete(b)
    check_future(a, b)

    # a may complete before or after b
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    check_future(a, b)
    loop.run_until_

# Generated at 2022-06-12 13:13:48.695887
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    from tornado.testing import gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    io_loop = asyncio.get_event_loop()

    async def async_test(future1: "Future[_T]", future2: "Future[_T]") -> None:
        try:
            await future1
        except Exception as e:
            future2.set_exception(e)
        else:
            future2.set_result(future1.result())

    future1 = Future()

    future2 = Future()

    io_loop.run_until_complete(async_test(future1, future2))

    chain_future(future1, future2)

    future1.set_result(0)

    assert io_loop

# Generated at 2022-06-12 13:13:54.219827
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test_func():
        future = Future()
        future_set_result_unless_cancelled(future, 1)
        assert future.result() == 1
        future1 = Future()
        future1.cancel()
        try:
            future_set_result_unless_cancelled(future1, 2)
            assert False
        except asyncio.InvalidStateError:
            assert True

    test_func()



# Generated at 2022-06-12 13:13:59.638414
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class MyFuture(Future):
        def __init__(self, value: Any) -> None:
            super(MyFuture, self).__init__()
            self.value = value

        def set_result(self, value: Any) -> None:
            super(MyFuture, self).set_result(value)
            assert value is self.value

    class UnitTestFuture(AsyncTestCase):
        @gen_test
        def test_chain_future_aio(self) -> None:
            f1 = MyFuture(1)
            f2 = MyFuture(f1.value)
            chain_future(f1, f2)
            f1.set_result(None)
            yield f2


# Generated at 2022-06-12 13:14:09.126918
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import threading
    import queue

    class QueueFuture(Future):
        def __init__(self, q):
            super().__init__()
            self.q = q

        def done(self):
            return not self.q.empty()

        def result(self):
            return self.q.get(block=False)

    def blocking_task(q):
        """This function blocks in a thread until a value is available."""
        q.put("I am done")

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            input_q = queue.Queue()
            output_q = queue.Queue()
            target_future = QueueFuture(input_q)
            chained_future = QueueFuture(output_q)
            chain_future

# Generated at 2022-06-12 13:14:13.805847
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()

    @gen.coroutine
    def wrapper():
        yield gen.moment
        f.set_result(42)
        assert f2.done()

    chain_future(f, f2)
    IOLoop.current().run_sync(wrapper)
    assert f2.result() == 42
    assert f.result() == 42



# Generated at 2022-06-12 13:14:17.781867
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    try:
        import unittest.mock
    except ImportError:
        import mock

    with unittest.mock.patch.object(MyTestCase, 'run_sync') as mock_object:
        mock_object.return_value = True
        MyTestCase().setUp()
        MyTestCase().test_chain_future()



# Generated at 2022-06-12 13:14:23.953400
# Unit test for function run_on_executor
def test_run_on_executor():

    class SomeClass:
        executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

        @run_on_executor(executor="_other_executor")
        def bar(self):
            return 1

        _other_executor = dummy_executor

    s = SomeClass()
    f = s.foo(1, 2)

    assert f.result() == 3

    f = s.bar()
    assert f.result() == 1

# Generated at 2022-06-12 13:14:34.616441
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent import futures
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase

    class MyFuture(Future):
        def __init__(self, io_loop: IOLoop) -> None:
            super(MyFuture, self).__init__()
            self.io_loop = io_loop

    class RunOnExecutorTest(AsyncTestCase):
        # The thread executor is a dummy, so we can't test
        # concurrent.futures.Future
        def setUp(self) -> None:
            super(RunOnExecutorTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)


# Generated at 2022-06-12 13:14:37.217025
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def test():
        future = Future()
        future_set_exception_unless_cancelled(future, ValueError("test cancel"))

    asyncio.get_event_loop().run_until_complete(test())

# Generated at 2022-06-12 13:15:11.652760
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyClass:
        executor = futures.ThreadPoolExecutor(1)

        def __init__(self, ioloop):
            self.ioloop = ioloop
            self.thread_results = []
            self.io_results = []

        @run_on_executor
        def thread_method(self, arg):
            self.thread_results.append(arg)

        @gen.coroutine
        def io_callback(self, future):
            self.io_results.append((yield future))

        @gen.coroutine
        def test(self):
            yield self.thread_method("hello")
            yield self.io_callback(self.thread_method("goodbye"))
            assert self.thread_results == ["hello", "goodbye"]
            assert self.io_results == ["goodbye"]
            self

# Generated at 2022-06-12 13:15:20.632168
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.testing import AsyncTestCase

    IOLoop = asyncio.get_event_loop()

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_exception(ValueError("foo"))
            self.assertEqual(f2.exception().args, ("foo",))
            self.assertTrue(type(f2.exception()) is ValueError)


# Generated at 2022-06-12 13:15:24.714510
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_exception_unless_cancelled(future, ValueError("foo"))
    assert future.exception()

    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_exception_unless_cancelled(future, ValueError("foo"))
    assert future.cancelled()

# Generated at 2022-06-12 13:15:31.816147
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    # exc_info will not be set if the exception is not raised
    exc_info = None # type: Optional[Tuple[Optional[type], Optional[BaseException], Optional[types.TracebackType]]]

    try:
        future_set_exception_unless_cancelled(future, RuntimeError("An error"))
    except RuntimeError as e:
        assert str(e) == "An error"
        exc_info = sys.exc_info()
    else:
        assert False, "Exception was not raised"

    assert exc_info is not None
    assert exc_info[0] is RuntimeError

    future = Future()
    future.cancel()

    # No exception should be raised when future is already cancelled

# Generated at 2022-06-12 13:15:38.770992
# Unit test for function chain_future
def test_chain_future():
    @types.coroutine
    def f(result, exc=None):
        if exc:
            raise exc
        else:
            return result

    @types.coroutine
    def g():
        yield

    @types.coroutine
    def h():
        raise Exception("h")

    from tornado.platform.asyncio import to_asyncio_future

    # A "real" use of chain_future is to bridge between Tornado futures
    # and other implementations, which is why we do these tests with
    # all the permutations of Future class.
    futures = [Future(), to_asyncio_future(Future()), f, g, h]
    for a in futures:
        for b in futures:
            chain_future(a, b)
            if a is f:
                assert not b.done()
                f.set_

# Generated at 2022-06-12 13:15:41.237217
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Setup
    def test():
        print("Hello")
    executor = DummyExecutor()

    # Exercise
    executor.submit(test)

    # Verify
    pass



# Generated at 2022-06-12 13:15:47.553379
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    def f():
        raise Exception("error")

    my_loop = IOLoop()  # type: IOLoop

    future1 = Future()
    future2 = Future()
    f1 = my_loop.run_in_executor(None, f)
    chain_future(f1, future1)
    f2 = my_loop.run_in_executor(None, f)
    chain_future(f2, future2)
    my_loop.run_sync(lambda: None)
    assert future1.exception() is not None
    assert future2.exception() is not None

# Generated at 2022-06-12 13:15:55.682524
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    result = [None, None]
    error = [None, None]
    fut1 = Future()
    fut2 = Future()

    def callback(fut):
        # type: (Future) -> None
        if not fut.cancelled():
            result[fut is fut1] = fut.result()
            error[fut is fut1] = fut.exception()
        else:
            result[fut is fut1] = None
            error[fut is fut1] = None

    fut1.add_done_callback(lambda fut: callback(fut))
    fut2.add_done_callback(lambda fut: callback(fut))
    chain_future(fut1, fut2)
    fut1.set_result(42)
    assert result[0] == 42
   

# Generated at 2022-06-12 13:16:05.819500
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    class ChainTests(AsyncTestCase):
        def setUp(self):
            self.f1_finished = False
            self.f2_finished = False
            self.f3_finished = False

            self.f1 = Future()
            self.f2 = Future()
            self.f3 = Future()
            self.f4 = Future()
            self.f5 = Future()
            self.f6 = Future()
            self.f7 = Future()
            self.f8 = Future()
            super().setUp()

        def tearDown(self):
            loop.close()
            super().tearDown()


# Generated at 2022-06-12 13:16:13.422936
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Old-style Future
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42
    c = futures.Future()
    a = futures.Future()
    chain_future(a, c)
    a.set_exception(ZeroDivisionError())
    assert c.exception() is not None
    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    b.cancel()
    a.set_result(42)
    assert b.cancelled()
    # Asyncio Future
    a = Future()
    b = Future()
    chain_future(a, b)

# Generated at 2022-06-12 13:17:11.704803
# Unit test for function chain_future
def test_chain_future():
    import tornado.gen as gen

    io_loop = IOLoop.current()

    # Test with asyncio.Future
    f = Future()

    def get_value():
        return 42

    new_f = gen.sleep(0).add_done_callback(
        lambda f: chain_future(f, f)
    )

    io_loop.add_future(new_f, lambda f: io_loop.stop())
    io_loop.start()

    assert not f.done()
    assert not new_f.done()

    f.set_result(get_value())
    assert new_f.done()
    assert new_f.result() == get_value()

    # Test with concurrent.futures.Future
    c_f = futures.Future()

    def get_value():
        return 42

    new

# Generated at 2022-06-12 13:17:15.720534
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-12 13:17:23.236979
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result(None)
    assert_future_result(b, None)
    # b.set_result() has been called, so chain_future should not set again.
    a.set_result(15)
    assert_future_result(b, None)

    # Test cancellation and exceptions
    c = futures.Future()
    chain_future(a, c)
    c.cancel()
    assert c.cancelled()
    a.set_exception(Exception("foo"))
    assert_future_result(b, None)
    assert not c.cancelled()



# Generated at 2022-06-12 13:17:27.976048
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc_info = sys.exc_info()
    try:
        raise RuntimeError("test")
    except RuntimeError:
        exc_info = sys.exc_info()

    assert future_set_exc_info(future, exc_info) == None
    assert future.exception() != None
    assert future.exception().args == ("test",)
    future.cancel()

# Generated at 2022-06-12 13:17:30.472341
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f():
        raise gen.Return(42)

    f2 = Future()
    chain_future(f(), f2)
    assert f2.result() == 42



# Generated at 2022-06-12 13:17:37.667523
# Unit test for function chain_future
def test_chain_future():
    # https://github.com/tornadoweb/tornado/issues/1776
    f = Future()
    p = Future()
    chain_future(f, p)
    f.set_exception(ZeroDivisionError())
    assert isinstance(p.exception(), ZeroDivisionError)
    q = Future()
    f = Future()
    chain_future(f, q)
    f.set_result(42)
    assert q.result() == 42
    p = Future()
    q = Future()
    p.set_result(None)
    chain_future(p, q)
    assert q.done()

# Generated at 2022-06-12 13:17:45.863265
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import unittest

    class FutureChainTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            io_loop = self.io_loop
            f1 = Future()
            f2 = Future()
            f3 = Future()
            io_loop.add_callback(f1.set_result, None)
            self.assertFalse(f2.done())
            chain_future(f1, f2)
            io_loop.add_future(f2, lambda f: f3.set_result((f, f.result())))
            self.assertEqual((f2, None), f3.result())

    unittest.main()


# Generated at 2022-06-12 13:17:52.843199
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock as mock

    class Test(object):
        executor = mock.NonCallableMock()

    t = Test()
    another_executor = mock.NonCallableMock()

    @run_on_executor()
    def f():
        pass

    f(t)
    t.executor.submit.assert_called_with(f, t)

    @run_on_executor(executor=another_executor)
    def f():
        pass

    f(t)
    another_executor.submit.assert_called_with(f, t)

# Generated at 2022-06-12 13:18:01.088121
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from concurrent.futures import ThreadPoolExecutor

    executor = ThreadPoolExecutor(2)

    class Dummy(object):
        executor = executor

    dummy = Dummy()

    @run_on_executor
    def f1(x):
        return x + 1

    @run_on_executor
    def f2(x):
        raise Exception("test exception")

    d1 = f1(10)
    d2 = f2(10)
    assert is_future(d1)
    assert is_future(d2)
    assert d1.result() == 11
    with pytest.raises(Exception) as exc:
        d2.result()
    assert str(exc.value) == "test exception"

    class Dummy2(object):
        _

# Generated at 2022-06-12 13:18:09.370905
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from unittest import mock

    class MyTestCase(unittest.TestCase):
        def test_future_chain(self):
            # In Python 2.7, we can't use unittest.mock.MagicMock as a
            # side_effect because MagicMock doesn't preserve the
            # __name__ attribute of its target when used with this
            # method. This means we can't assert on the call in
            # chain_future.
            class MockFuture(object):
                def __init__(self):
                    self.called = False

                def __call__(self):
                    self.called = True

                def set_exception(self, exception):
                    self.exception = exception

                def set_result(self, result):
                    self.result = result

            f = MockFuture()
