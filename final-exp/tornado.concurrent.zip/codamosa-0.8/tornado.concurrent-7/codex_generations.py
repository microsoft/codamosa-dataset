

# Generated at 2022-06-12 13:09:54.618204
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.platform.asyncio
    import asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    source = Future()
    source.set_result(42)
    target = asyncio.Future()
    chain_future(source, target)
    assert target.done()
    assert target.result() == 42

# Generated at 2022-06-12 13:10:05.369234
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from threading import Thread
    from time import time
    import concurrent.futures

    class TestChainFuture(unittest.TestCase):
        def test_chain(self):
            f1 = concurrent.futures.Future()
            f2 = concurrent.futures.Future()

            def get_test_result():
                return 1

            def set_result(future):
                future_set_result_unless_cancelled(future, get_test_result())

            def set_exception(future):
                future_set_exception_unless_cancelled(future, Exception())

            def cancel(future):
                future.cancel()

            def do_nothing(future):
                pass

            workers = [set_result, set_exception, do_nothing, cancel]

# Generated at 2022-06-12 13:10:14.076411
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestFuture(AsyncTestCase):
        def test_chain(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_with_exc_info(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            try:
                raise ValueError()
            except ValueError:
                exc_info = sys.exc_info()
            f1.set_exc_info(exc_info)
            with self.assertRaises(ValueError):
                f2.result()


# Generated at 2022-06-12 13:10:17.860309
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'test_result')



# Generated at 2022-06-12 13:10:23.036904
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    test_future = Future()
    test_future.cancel()
    future_set_result_unless_cancelled(test_future, "test_result")
    assert test_future.cancelled()

    test_future = Future()
    future_set_result_unless_cancelled(test_future, "test_result")
    assert test_future.result() == "test_result"

# Generated at 2022-06-12 13:10:32.138405
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing
    import tornado.gen
    import functools

    from tornado.platform.asyncio import AsyncIOMainLoop

    def f1(arg):
        # type: (Any) -> int
        return arg + 1

    def f2(arg):
        # type: (Any) -> int
        return arg + 2

    def f3(arg):
        # type: (Any) -> int
        return arg + 3

    def f4(arg):
        # type: (Any) -> int
        return arg + 4

    @tornado.testing.gen_test
    def test_chain_future_with_yield():
        # type: () -> None
        f = Future()
        f1_c = concurrent_future_to_asyncio_future(f)


# Generated at 2022-06-12 13:10:39.812118
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.result() is f2.result()
    assert not f2.cancelled()

    f1 = Future()
    f2 = Future()
    f2.set_result(42)
    chain_future(f1, f2)
    assert f2.done()
    f1.set_result(24)
    assert f1.result() == f2.result()
    f2.cancel()
    assert not f1.cancelled()



# Generated at 2022-06-12 13:10:48.808968
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time

    @run_on_executor
    def fn(self: Any, x: int, y: int) -> int:
        return x + y

    class Test(unittest.TestCase):

        def test_run_on_executor(self: "Test") -> None:
            # Set up a thread pool executor and save it as a test instance
            # attribute.
            self.thread_pool = futures.ThreadPoolExecutor(1)
            self.addCleanup(self.thread_pool.shutdown)

            # Make the test instance callable, so we can pass it to fn.
            self()

            # Make sure the function runs using the executor
            start = time.time()
            future = fn(self, 1, 2)
            result = future.result()

# Generated at 2022-06-12 13:10:55.089636
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            super(Test, self).__init__(*args, **kwargs)
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

        @run_on_executor(executor='executor')
        def func(self, arg1, arg2, kwarg1=None):
            time.sleep(0.1)
            return arg1 + arg2 + (kwarg1 or 0)

        @run_on_executor(executor='executor')
        def func_exc(self):
            raise Exception('exc')


# Generated at 2022-06-12 13:11:03.917792
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures
    import unittest
    import threading
    import time

    class ThreadPoolExecutorTest(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

        def tearDown(self):
            self.executor.shutdown(allow_some=True)

        def test_chain_future(self):
            self.done = threading.Event()

            def wrapper(a: "Future[_T]", b: "Future[_T]"):
                def copy(future):
                    self.done.set()
                    assert future is a

# Generated at 2022-06-12 13:11:14.803788
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.ioloop
    import concurrent.futures
    from tornado.platform.asyncio import BaseAsyncIOLoop
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):

        def make_future(self):
            # type: () -> Future
            return self.io_loop.run_sync(lambda: Future())

        def make_concurrent_future(self):
            # type: () -> futures.Future
            return futures.Future()

        @gen_test
        def test_concurrent_future_success(self):
            cfuture = self.make_concurrent_future()
            afuture = self.make_future()
            chain_future(cfuture, afuture)
            cfuture.set_result(42)

# Generated at 2022-06-12 13:11:25.597205
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import concurrent.futures

    class TestObject(object):
        def __init__(self) -> None:
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor()
        def foo(self, a: int) -> str:
            return "foo %d" % a

        @run_on_executor()
        def bar(self, a: int) -> str:
            return "bar %d" % a

    io_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(io_loop)
    test = TestObject()

# Generated at 2022-06-12 13:11:32.757101
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest 
    from types import FunctionType

    class DummyExecutorTestCase(unittest.TestCase):
        def test_submit(self) -> None:
            def sync_foo(arg1: Any, arg2: Any, kwarg1: Any = None) -> str:
                return "foo"

            future = dummy_executor.submit(sync_foo, "arg1", "arg2", kwarg1="kwarg1")
            self.assertIsInstance(future, futures.Future)
            self.assertEqual(future.result(), "foo")

            future = dummy_executor.submit(sync_foo, "arg1", arg2="arg2", kwarg1="kwarg1")
            self.assertIsInstance(future, futures.Future)

# Generated at 2022-06-12 13:11:42.340471
# Unit test for function chain_future
def test_chain_future():
    import threading
    import time
    import unittest

    from tornado.concurrent import Future, run_on_executor
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    class Test(unittest.TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            if self.io_loop:
                self.io_loop.clear_current()
            super(Test, self).tearDown()


# Generated at 2022-06-12 13:11:52.541456
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyFutureClass:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def my_method(self, arg1, arg2, kwarg1=None):
            return arg1 + arg2 + kwarg1

        @run_on_executor()
        def my_args_method(self, arg1, arg2, kwarg1=None):
            return arg1 + arg2 + kwarg1

        @run_on_executor(executor="_thread_pool")
        def my_thread_method(self, arg1, arg2, kwarg1=None):
            return arg1 + arg2 + kwarg1

    obj = MyFutureClass()

# Generated at 2022-06-12 13:11:59.083565
# Unit test for function chain_future
def test_chain_future():
    asyncio.set_event_loop(asyncio.new_event_loop())
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertTrue(b.done())
            self.assertEqual(b.result(), 42)

        def test_chain_future_already_completed_b(self):
            # b completes before a is chained to it.
            a = Future()
            b = Future()
            b.set_result(42)
            chain_future(a, b)
            self.assertTrue(b.done())
            self.assertEqual(b.result(), 42)


# Generated at 2022-06-12 13:12:08.320885
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 'Dummy')
    assert future.result() == 'Dummy'
    future_set_result_unless_cancelled(future, 'Dummy')
    assert future.result() == 'Dummy'
    future.set_result('Dummy2')
    assert future.result() == 'Dummy2'
    future.cancel()
    future_set_result_unless_cancelled(future, 'Dummy')
    assert future.result() == 'Dummy2'
    future.set_result('Dummy3')
    assert future.result() == 'Dummy2'
    loop.close()

# Generated at 2022-06-12 13:12:13.928690
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ValueError())
    assert f2.done()
    try:
        f2.result()
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-12 13:12:22.546188
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    io_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(io_loop)

    @asyncio.coroutine
    def f1():
        # type: () -> None
        yield gen.sleep(0.1)

    @asyncio.coroutine
    def f2():
        # type: () -> None
        yield gen.sleep(0.1)
        1 / 0

    f3 = asyncio.Future()
    f4 = Future()
    f5 = Future()

    chain_future(f1(), f3)
    chain_future(f2(), f4)
    chain_future(f3, f5)

    io_loop.run_until_complete(f5)
    print(f5.exception())
    assert f

# Generated at 2022-06-12 13:12:30.890074
# Unit test for function chain_future
def test_chain_future():
    io_loop = asyncio.get_event_loop()

    # Chain tornado futures
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    # Chain concurrent futures
    c = Future()
    d = futures.Future()
    chain_future(c, d)
    c.set_result(42)
    assert d.result() == 42

    # Chain future to concurrent future
    e = Future()
    f = futures.Future()
    chain_future(e, f)
    e.set_result(42)
    assert f.result() == 42

    # Chain concurrent future to future
    g = Future()
    h = futures.Future()
    chain_future(h, g)
    h.set_

# Generated at 2022-06-12 13:12:46.066709
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exc = RuntimeError()
    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is exc
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is exc

    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is exc
    future.cancel()
    # The exception should not be overwritten
    future_set_exception_unless_cancelled(future, exc)
    assert future.done() and future.exception() is exc

# Generated at 2022-06-12 13:12:51.485762
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    @gen.coroutine
    def f():
        # type: () -> None
        loop = IOLoop.current()
        f = Future()
        g = Future()
        loop.add_callback(chain_future, f, g)
        f.set_result(None)
        raise gen.Return(g)

    g = IOLoop.current().run_sync(f)
    assert g.done()



# Generated at 2022-06-12 13:12:54.409463
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.done()
    assert b.result() == 42

# Generated at 2022-06-12 13:13:03.398152
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import concurrent.futures
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(ChainFutureTest, self).tearDown()

        @gen_test
        def test_chain(self):
            f, g = Future(), Future()
            chain_future(f, g)
            self.assertFalse(g.done())
            f.set_result('ok')
            self.assertEqual(g.result(), 'ok')


# Generated at 2022-06-12 13:13:11.403226
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    import asyncio

    class TestSetResult(unittest.TestCase):
        def test_set_result(self):
            future = asyncio.Future()
            future_set_result_unless_cancelled(future, 1)
            self.assertEqual(1, future.result())

        def test_set_result_already_cancelled(self):
            future = asyncio.Future()
            future.cancel()
            with self.assertRaises(asyncio.InvalidStateError):
                future_set_result_unless_cancelled(future, 1)

    unittest.main()

# Generated at 2022-06-12 13:13:15.496288
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future() # type: Future
    future.cancel()

    assert future.done()
    assert future.cancelled()

    try:
        future_set_result_unless_cancelled(future, True)
    except Exception:
        pass
    else:
        assert False, "should raise error"



# Generated at 2022-06-12 13:13:22.570331
# Unit test for function chain_future
def test_chain_future():
    done_result = None
    done_exc_info = None

    def copy(future):
        nonlocal done_result, done_exc_info
        assert future is f1
        if f2.done():
            return
        if hasattr(f1, "exc_info") and f1.exc_info() is not None:
            exc_info = f1.exc_info()
            done_exc_info = exc_info
            future_set_exc_info(f2, exc_info)
        elif f1.exception() is not None:
            f2.set_exception(f1.exception())
        else:
            result = f1.result()
            done_result = result
            f2.set_result(result)

    f1 = futures.Future()
    f2 = futures.Future()

# Generated at 2022-06-12 13:13:24.461262
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None



# Generated at 2022-06-12 13:13:28.486813
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-12 13:13:36.395413
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future[None]
    assert not future.cancelled()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future.cancel()
    assert future.cancelled()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-12 13:14:12.061143
# Unit test for function chain_future
def test_chain_future(): # type: ignore
    # type: () -> None
    future1 = Future()
    future2 = Future()
    assert not future1.done()
    assert not future2.done()
    chain_future(future1, future2)
    assert not future1.done()
    assert not future2.done()
    future1.set_result("result")
    assert future1.result() == future2.result()
    assert future1.done()
    assert future2.done()
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_exception(RuntimeError("test error"))
    assert future1.exception() is not None
    assert future1.exception() == future2.exception()
    assert future1.done()
    assert future2.done

# Generated at 2022-06-12 13:14:14.091205
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError)
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError)
    assert future.exception() is None



# Generated at 2022-06-12 13:14:17.542536
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(3)
    assert g.result() == 3
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(ValueError())
    g.exception()



# Generated at 2022-06-12 13:14:23.728355
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    foo_exc = Exception("foo")
    f = Future()
    future_set_exception_unless_cancelled(f, foo_exc)
    assert f.exception() is foo_exc
    f.cancel()
    bar_exc = Exception("bar")
    future_set_exception_unless_cancelled(f, bar_exc)
    assert f.exception() is foo_exc
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, bar_exc)

# Generated at 2022-06-12 13:14:34.350613
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    import pytest
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()

    f = loop.create_future()
    assert not f.done()
    assert not f.cancelled()
    assert f.result() is None
    f.set_result(1)
    assert f.done()
    assert not f.cancelled()
    assert f.result() == 1

    # Canceled future
    f = loop.create_future()
    f.cancel()
    assert f.done()
    assert f.cancelled()
    with pytest.raises(asyncio.CancelledError):
        f.result()
    f.set_result(1)

# Generated at 2022-06-12 13:14:36.331521
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-12 13:14:39.769830
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    # Make sure the set_result is actually invoked.
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    # Make sure the set_result is not invoked.
    assert future.result() == 1

# Generated at 2022-06-12 13:14:44.847056
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result("foo")
    assert_future_result(b, "foo")

    # The chain should be unidirectional (a -> b but not b -> a)
    c = Future()
    chain_future(b, c)
    a.set_exception(RuntimeError("foo"))
    assert_future_exception(c, RuntimeError)



# Generated at 2022-06-12 13:14:53.281834
# Unit test for function chain_future
def test_chain_future():
    try:
        from tornado.concurrent import TracebackFuture
    except ImportError:
        TracebackFuture = None
    futures = [Future(), asyncio.Future(), futures.Future()]
    if TracebackFuture is not None:
        futures.append(TracebackFuture())
    for inner, outer in [(a, b) for a in futures for b in futures]:
        chain_future(inner, outer)
        assert not outer.done()
        inner.set_result(42)
        assert outer.done()
        assert inner.result() == outer.result()
        chain_future(inner, outer)
        assert not outer.done()
        inner.set_exception(RuntimeError("foo"))
        assert outer.done()
        try:
            inner.result()
        except RuntimeError:
            pass
        else:
            assert False

# Generated at 2022-06-12 13:14:59.263078
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    loop.set_debug(True)
    assert loop.get_debug()
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    loop.run_until_complete(b)
    assert b.result() == 42
    c = Future()
    chain_future(a, c)
    assert c.done()
    assert c.result() == 42
    d = Future()
    e = Future()
    chain_future(d, e)
    assert not e.done()
    d.set_exception(ZeroDivisionError())
    loop.run_until_complete(e)
    assert e.done()

# Generated at 2022-06-12 13:15:33.339371
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    def set_it(value):
        f1.set_result(value)
    io_loop = IOLoop()

    io_loop.add_callback(set_it, 5)
    chain_future(f1, f2)
    assert f2.result() == 5

# Generated at 2022-06-12 13:15:40.376960
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import io

    @functools.total_ordering
    class MyException(Exception):
        def __eq__(self, other):
            return type(self) == type(other)

        def __lt__(self, other):
            return type(self) < type(other)

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()
            self.loop.set_debug(True)
            asyncio.set_event_loop(None)

        def tearDown(self):
            self.loop.close()

        def test_success(self):
            # Simple success case
            source = Future()
            source.set_result(1)
            dest = Future()
            chain_future(source, dest)


# Generated at 2022-06-12 13:15:46.938433
# Unit test for function chain_future
def test_chain_future():
    # Test concurrent.futures.Future
    a = futures.Future()
    b = Future()
    chain_future(a, b)

    # Test Futures
    a = Future()
    b = Future()
    chain_future(a, b)

    # Test opposite
    a = Future()
    b = futures.Future()
    chain_future(a, b)

    # Test opposite
    a = futures.Future()
    b = Future()
    chain_future(a, b)

    # Test chaining a to b and b to a
    a = Future()
    b = Future()
    chain_future(a, b)
    chain_future(b, a)

# Generated at 2022-06-12 13:15:48.970363
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

# Generated at 2022-06-12 13:15:55.887745
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    f1 = Future()
    f2 = Future()

    @loop.gen.coroutine
    def g():
        yield f1
        yield f2

    chain_future(f1, f2)

    def finish():
        f2.set_exception(RuntimeError("testing"))

    loop.add_callback(finish)

    @loop.gen.coroutine
    def h():
        try:
            yield g()
        except RuntimeError:
            pass
        else:
            raise AssertionError("should never get here")

    loop.run_sync(h)

# Generated at 2022-06-12 13:16:06.030970
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(f, g)

    # Chaining works in both directions
    f.set_result(2)
    assert g.result() == 2
    f = Future()  # type: Future[int]
    g = Future()  # type: Future[int]
    chain_future(g, f)
    g.set_result(2)
    assert f.result() == 2

    # Callbacks run before chaining
    g = Future()  # type: Future[int]
    results = []

    def callback(future):
        # type: (Future[int]) -> None
        results.append(future.result())
        # Make sure that the other callback doesn't see

# Generated at 2022-06-12 13:16:13.358842
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42
    c = Future()
    d = Future()
    e = Future()
    chain_future(d, c)
    chain_future(e, c)
    assert not c.done()
    d.set_result(42)
    assert c.done()
    assert c.result() == 42
    f = Future()
    g = Future()
    chain_future(d, f)
    chain_future(e, f)
    assert not f.done()
    e.set_result(24)
    assert f.done()
    assert f.result() == 42



# Generated at 2022-06-12 13:16:20.893868
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    from tornado.platform.asyncio import to_asyncio_future
    from concurrent import futures

    class DummyFuture(concurrent.futures.Future):
        def __init__(self) -> None:
            super().__init__()
            self.thread_id = threading.get_ident()

        def set_result(self, value: Any) -> None:
            assert threading.get_ident() == self.thread_id
            super().set_result(value)

        def set_exception(self, exception: BaseException) -> None:
            assert threading.get_ident() == self.thread_id
            super().set_exception(exception)

    class SyncHandler:
        executor = dummy_executor


# Generated at 2022-06-12 13:16:27.655845
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading
    from tornado.ioloop import IOLoop

    fut1 = Future()
    fut2 = Future()

    # Test that chain_future works when the second future is already done
    chain_future(fut1, fut2)
    fut1.set_result(42)
    assert fut2.result() == 42

    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut2.set_result(24)
    assert fut1.done()

    # Test that chain_future works with concurrent.futures.Future
    l = threading.Lock()


# Generated at 2022-06-12 13:16:35.419628
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Foo(object):
        executor = dummy_executor
        result = None
        result_args = None
        result_kwargs = None

        @run_on_executor
        def func(self, x, y, z=1):
            self.result_args = (x, y)
            self.result_kwargs = dict(z=z)
            return x + y + z

        @run_on_executor(executor="_thread_pool")
        def func2(self):
            pass

        @run_on_executor(callback='_return_result')
        def func3(self):
            return 10

    f = Foo()
    f.func(1, y=2)
    assert f.result == 10
    assert f.result_args == (1,)

# Generated at 2022-06-12 13:17:41.332611
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError("test exception"))


if __name__ == "__main__":
    import logging
    import tornado.ioloop
    logging.basicConfig()
    test_future_set_exception_unless_cancelled()
    tornado.ioloop.IOLoop.current().start()

# Generated at 2022-06-12 13:17:46.663547
# Unit test for function chain_future
def test_chain_future():
    async def f():
        io_loop = IOLoop.current()

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        f2.add_done_callback(lambda f: io_loop.stop())
        await f2

    IOLoop.current().run_sync(f)



# Generated at 2022-06-12 13:17:55.363357
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    async def foo():
        return 42

# Generated at 2022-06-12 13:18:00.488496
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None

    class Object(object):
        def __init__(self):
            # type: () -> None
            self.io_loop = IOLoop.current()
            self.executor = DummyExecutor()

    o = Object()
    result = []
    result_append = result.append

    @run_on_executor
    def f(a, b):
        # type: (int, float) -> str
        result_append(("f", a, b))
        return "hello"

    # Note that we don't have to yield the result of f() --
    # the decorator will transparently do this for us
    f(1, 2.0)
    assert result == [("f", 1, 2.0)]
    result = []


# Generated at 2022-06-12 13:18:03.479506
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-12 13:18:11.493816
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    from concurrent.futures import Future as ConcFuture

    f1 = ConcFuture()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = ConcFuture()
    f

# Generated at 2022-06-12 13:18:16.955690
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exc = RuntimeError("oops")
    fu = Future()
    fu.cancel()
    future_set_exception_unless_cancelled(fu, exc)


# The remaining functions in this file are not used internally by
# Tornado itself, but are commonly used by applications that need
# the functionality they provide.
#
# This is a little ugly, but it allows us to avoid putting those
# functions in the "tornado.util" package, which is supposed to be
# reserved for non-essential utility functions.



# Generated at 2022-06-12 13:18:20.526479
# Unit test for function chain_future
def test_chain_future():

    def run_test(futures, exception):
        # type: (Tuple[futures._base.Future, futures._base.Future], Exception) -> None

        future1, future2 = futures
        if exception:
            future1.set_exception(exception)
        else:
            future1.set_result("result")
        if exception:
            assert future2.exception() is exception
        else:
            assert future2.result() == "result"

    run_test((futures.Future(), futures.Future()), Exception())
    run_test((Future(), Future()), Exception())

# Generated at 2022-06-12 13:18:27.042675
# Unit test for function chain_future
def test_chain_future():
    from tornado.log import gen_log

    async def main():
        f1 = Future()
        f2 = Future()

        chain_future(f1, f2)

        def f1_done(f: Future) -> None:
            assert f is f1
            gen_log.debug("f1 complete")
            assert not f2.done()
            f2_done.count += 1
            f1.set_result(1)

        f1_done.count = 0
        future_add_done_callback(f1, f1_done)

        def f2_done(f: Future) -> None:
            assert f is f2
            gen_log.debug("f2 complete")
            assert f1_done.count == 1
            f2_done.count += 1
            f1.set_result(2)

# Generated at 2022-06-12 13:18:29.633456
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()

    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    c = Future()
    chain_future(b, c)
    assert c.result() == 42