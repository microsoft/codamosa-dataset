

# Generated at 2022-06-12 13:09:54.221897
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_future = dummy_executor.submit(sum, [1, 2])
    assert dummy_future == 3

# Generated at 2022-06-12 13:09:56.507329
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42



# Generated at 2022-06-12 13:10:05.286602
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import gen_test, AsyncTestCase

    @run_on_executor(executor='_executor')
    def add(x, y):
        return x + y

    class RunOnExecutorTest(AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self._executor = dummy_executor

        @gen_test
        def test_run(self):
            ret = yield add(1, 2)
            self.assertEqual(ret, 3)

    unittest.main()

# Generated at 2022-06-12 13:10:09.372222
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut1 = Future()
    fut2 = Future()
    fut2.cancel()

    future_set_result_unless_cancelled(fut1, 'test')
    assert fut1.result() == 'test'

    future_set_result_unless_cancelled(fut2, 'test')
    assert fut2.cancelled()

# Generated at 2022-06-12 13:10:11.725022
# Unit test for function chain_future
def test_chain_future():
    """
    >>> f1 = Future()
    >>> f2 = Future()
    >>> chain_future(f1, f2)
    """
    pass



# Generated at 2022-06-12 13:10:16.477631
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    io_loop = tornado.ioloop.IOLoop.current()
    f1, f2 = futures.Future(), Future()
    chain_future(f1, f2)

    f1.set_result(42)
    test_case = tornado.testing.AsyncTestCase()

    @test_case.assert_future_result(42)
    def check_f2():
        # type: () -> None
        return f2

    io_loop.run_sync(check_f2)

# Generated at 2022-06-12 13:10:24.778837
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert isinstance(f2.exception(), ZeroDivisionError)

    # Test chaining already completed futures.
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-12 13:10:33.149273
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.log import gen_log
    from tornado.ioloop import IOLoop

    def test(future, exc_info):
        with gen_log.catch_logging():
            future_set_exc_info(future, exc_info)
            IOLoop.current().add_callback(IOLoop.current().stop)
        return future

    # A Future that is not cancelled, exc_info should be set as the exception.
    test(Future(), (Exception, Exception(), None))

    # A Future that is cancelled, we just log the exception.
    future = Future()
    future.cancel()
    test(future, (Exception, Exception(), None))

# Generated at 2022-06-12 13:10:35.009352
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-12 13:10:43.985275
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTests(AsyncTestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertFalse(a.done())
            self.assertFalse(b.done())
            a.set_result(42)
            self.assertTrue(a.done())
            self.assertTrue(b.done())
            self.assertEqual(b.result(), 42)
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertFalse(a.done())
            self.assertFalse(b.done())
            a.set_exception(RuntimeError())

# Generated at 2022-06-12 13:10:54.254697
# Unit test for function chain_future
def test_chain_future():
    import unittest

    def _on_foo_complete(result):
        on_foo_complete.result = result

    def _on_bar_complete(result):
        on_bar_complete.result = result

    class _TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            # create two future objects
            foo = Future()
            bar = Future()

            # attach callbacks to foo
            foo.add_done_callback(_on_foo_complete)

            # chain bar to foo
            chain_future(foo, bar)
            bar.add_done_callback(_on_bar_complete)

            # complete foo
            foo.set_result(42)
            future_result(foo)

            self.assertEqual(foo.result(), 42)

# Generated at 2022-06-12 13:11:03.230451
# Unit test for function chain_future
def test_chain_future():
    import threading
    import time
    import functools

    import tornado.testing
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest

    def foo(arg):
        return arg

    def slow_foo(arg):
        time.sleep(0.1)
        return arg

    def slow_async_foo(arg):
        t = threading.Thread(target=slow_foo, args=[arg])
        t.start()
        return t

    @unittest.skipIf(tornado.test.use_asyncio.is_asyncio_future_style(), "Asyncio")
    def test_concurrent_future(self):
        f = futures.Future()
        g = Future()

# Generated at 2022-06-12 13:11:07.012831
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1


# Generated at 2022-06-12 13:11:14.471035
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.log import gen_log
    from tornado.ioloop import IOLoop

    try:
        raise Exception("foo")
    except Exception:
        exc_info = sys.exc_info()

    future = Future()
    future_set_exception_unless_cancelled(future, Exception("bar"))
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, Exception("baz"))
    assert future.exception() is not None

    future = Future()
    future_set_exception_unless_cancelled(future, Exception("bar"))
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    future_set_exception_unless

# Generated at 2022-06-12 13:11:25.144021
# Unit test for function chain_future
def test_chain_future():  # noqa
    from tornado.ioloop import IOLoop

    async def async_future_test():
        fut1 = Future()
        fut2 = Future()

        chain_future(fut1, fut2)
        fut1.set_result(None)
        assert fut2.done()

        fut1 = Future()
        fut2 = Future()

        chain_future(fut1, fut2)
        fut1.set_exception(RuntimeError())
        assert fut2.done()
        assert fut2.exception()
        assert isinstance(fut2.exception(), RuntimeError)

    def callback_future_test():
        fut1 = Future()
        fut2 = Future()

        chain_future(fut1, fut2)
        fut1.set_result(None)
        assert fut2.done()



# Generated at 2022-06-12 13:11:32.533579
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from concurrent.futures import Future
    from tornado.testing import AsyncTestCase, gen_test

    class TestFutureSetExceptionUnlessCancelled(AsyncTestCase):
        @gen_test
        def test_set_exception_unless_cancelled(self):
            f = Future()
            future_set_exception_unless_cancelled(f, RuntimeError("Test error"))
            self.assertTrue(f.done())
            self.assertTrue(f.exception())
            try:
                yield f
            except RuntimeError:
                pass
            else:
                raise RuntimeError("Exception should not be consumed")

        @gen_test
        def test_set_exception_unless_cancelled_cancelled(self):
            f = Future()
            f.cancel()
            future_set_exception_

# Generated at 2022-06-12 13:11:42.216505
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.queues import Queue

    async def async_delay(delay: float) -> None:
        await asyncio.sleep(delay)

    q1 = Queue()
    q2 = Queue()

    @run_on_executor
    def func(delay: float) -> None:
        IOLoop.current().spawn_callback(async_delay, delay)

    f1 = func(0.1)
    f2 = func(0.2)
    f3 = func(0.3)
    chain_future(f1, q1.put(None))
    chain_future(f2, q2.put(None))
    chain_future(f3, q1.put(None))
    chain_future(f3, q2.put(None))


# Generated at 2022-06-12 13:11:52.430796
# Unit test for function chain_future
def test_chain_future():
    def test(input: Tuple[bool, bool]) -> str:
        if input[0]:
            raise Exception('input[0]')
        if input[1]:
            raise Exception('input[1]')
        return 'OK'

    input = (False, True)
    future_orig = Future()
    future_clone = Future()

    def set_error(_future: Future) -> None:
        _future.set_exception(Exception('OUTPUT'))

    chain_future(future_orig, future_clone)
    future_add_done_callback(future_clone, set_error)
    future_orig.set_result(input)

    try:
        future_clone.result()
    except Exception as e:
        assert str(e) == 'input[1]'



# Generated at 2022-06-12 13:11:57.353192
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_result(None)
    future2.set_result(None)
    assert not future3.done()
    future1.cancel()
    future3.add_done_callback(lambda f: f.result())
    # Verify that cancelling future1 doesn't cause future2 to be cancelled.
    assert not future2.cancelled()



# Generated at 2022-06-12 13:12:06.537408
# Unit test for function chain_future
def test_chain_future():
    future_test = Future()  # type: Future[int]
    async_test = Future()
    chain_future(future_test, async_test)
    # Test for normal result
    future_test.set_result(1)
    assert async_test.result() == 1

    # Test for exception
    future_test = Future()
    async_test = Future()
    chain_future(future_test, async_test)
    future_test.set_exception(ValueError())
    try:
        async_test.result()
        assert False, "should have raised"
    except ValueError:
        pass

    # Test for cancellation
    future_test = Future()
    async_test = Future()
    chain_future(future_test, async_test)
    future_test.cancel()

# Generated at 2022-06-12 13:12:20.009112
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    a = DummyExecutor()
    def b(a, x, y):
        return a + x + y

    c = a.submit(b, 1, 2, y = 3)

    assert c.result() == 6

# Generated at 2022-06-12 13:12:23.075396
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f():
        value = yield gen.moment  # type: ignore
        return value

    f2 = Future()
    chain_future(f(), f2)
    f2.set_result(True)

# Generated at 2022-06-12 13:12:31.826363
# Unit test for function chain_future
def test_chain_future():
    import time

    def callback(future):
        assert future.result() == 10

    tornado_future = Future()
    tornado_future.set_result(10)
    future = futures.Future()
    chain_future(tornado_future, future)
    future.add_done_callback(callback)
    assert future.result() == 10

    thread_future = futures.Future()
    tornado_future = Future()
    chain_future(thread_future, tornado_future)
    thread_future.set_result('test')
    assert tornado_future.result() == 'test'

    tornado_future = Future()
    thread_future = futures.Future()
    chain_future(tornado_future, thread_future)
    def callback(future):
        assert future.result() == 10


# Generated at 2022-06-12 13:12:39.918630
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def double(self, arg):
            return arg * 2

        @run_on_executor()
        def no_keyword(self, arg):
            return arg * 2

    foo = Foo()
    foo.executor = dummy_executor
    result = foo.double(41)
    assert result.result() == 82

    result = foo.no_keyword(41)
    assert result.result() == 82

    del foo.executor
    try:
        foo.double(41)
        raise Exception("Expected AttributeError")
    except AttributeError:
        pass


# Generated at 2022-06-12 13:12:44.628162
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        raise RuntimeError("error")
    except Exception as e:
        exc = e
    # future are not cancelled
    future = Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    # future are cancelled
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)

# Generated at 2022-06-12 13:12:46.521910
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))

# Generated at 2022-06-12 13:12:53.939428
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    fut1 = loop.run_sync(lambda: Future())
    fut2 = loop.run_sync(lambda: Future())

    def done_callback(fut: "Future[str]"):
        assert fut is fut2
        assert fut.done()
        assert not fut.exception()
        assert fut.result() == "result"
        loop.stop()

    chain_future(fut1, fut2)
    fut2.add_done_callback(done_callback)
    loop.add_callback(lambda: fut1.set_result("result"))
    loop.start()

# Generated at 2022-06-12 13:12:56.849960
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import gen

    @gen.coroutine
    def test():
        def increment(x):
            return x + 1

        x = yield dummy_executor.submit(increment, 5)
        assert x == 6

    test()

# Generated at 2022-06-12 13:13:06.465553
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class A:
        def __init__(self, val):
            self.val = val

    a_1 = A(1)
    a_2 = A(2)

    future_1 = Future()
    future_1.set_result(a_1)
    future_2 = Future()
    future_set_result_unless_cancelled(future_2, a_2)

    # case 1: future_1 is not cancelled and should set result properly
    assert future_1.result() == a_1

    # case 2: future_2 is not cancelled and should set result properly
    assert future_2.result() == a_2

    # case 3: future_3 cancel first then set result
    future_3 = Future()
    future_3.cancel()

# Generated at 2022-06-12 13:13:11.551550
# Unit test for function chain_future
def test_chain_future():
    @chain_future
    def f():
        # type: () -> Optional[int]
        return 42

    def g(future):
        # type: (Future[int]) -> None
        assert future.result() == 42

    future = Future()  # type: Future[int]
    IOLoop.current().add_callback(f, future)
    IOLoop.current().add_callback(g, future)



# Generated at 2022-06-12 13:13:20.188270
# Unit test for function chain_future
def test_chain_future():
    future1 = concurrent.futures.Future()
    future2 = concurrent.futures.Future()
    chain_future(future1, future2)
    future1.result = 10
    assert future2.result == 10

# Generated at 2022-06-12 13:13:24.072768
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future_set_result_unless_cancelled(future, 123)
    assert future.result() == 123
    future_set_result_unless_cancelled(future, 456)
    assert future.result() == 123

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 123)



# Generated at 2022-06-12 13:13:28.399157
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    @asyncio.coroutine
    def foo(x):
        # type: (int) -> int
        yield asyncio.From()
        return x + 42

    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    f = Future()  # type: Future[int]
    io_loop.run_sync(lambda: chain_future(foo(42), f))
    io_loop.close()
    assert f.result() == 42 + 42



# Generated at 2022-06-12 13:13:39.632848
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from concurrent.futures import Future as CFuture
    from tornado.concurrent import Future

    class FutureTest(unittest.TestCase):
        def test_future(self):
            future = Future()
            cfuture = CFuture()

            def set_result(future, result):
                future.set_result(result)

            # Test Tornado Future chaining
            future_add_done_callback(future, functools.partial(set_result, cfuture, 10))
            future.set_result(5)
            self.assertEqual(cfuture.result(), 10)

            # Test concurrent.futures Future chaining
            cfuture2 = CFuture()
            chain_future(cfuture, cfuture2)
            self.assertEqual(cfuture2.result(), 10)

    unittest

# Generated at 2022-06-12 13:13:46.376310
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    assert not future.done()
    future_set_result_unless_cancelled(future, 'result')
    assert future.done()
    assert future.result() == 'result'
    future = Future()
    future.cancel()
    assert future.cancelled()
    assert not future.done()
    future_set_result_unless_cancelled(future, 'result')
    assert not future.done()
    assert future.cancelled()
    future2 = Future()
    future2.set_result('result')



# Generated at 2022-06-12 13:13:50.054703
# Unit test for function chain_future
def test_chain_future():
    async def async_test():
        io_loop = asyncio.get_running_loop()

        a = Future()
        b = Future()
        chain_future(a, b)
        a.set_result(42)
        assert await b == 42

    asyncio.run(async_test())

# Generated at 2022-06-12 13:13:59.675181
# Unit test for function chain_future
def test_chain_future():
    from tornado.log import app_log
    from tornado.testing import AsyncTestCase, gen_test

    app_log.setLevel("ERROR")

    class TestChainFuture(AsyncTestCase):
        def test_main(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            safe_add_callback(f, self.stop)
            safe_add_callback(g, self.stop)
            f.set_result(1)
            self.wait()
            self.assertEqual(g.result(), 1)

            # Test that chaining works even if the destination is already done
            h = Future()
            h.set_result(2)
            chain_future(f, h)
            self.assertEqual(h.result(), 1)
            # Also make sure that it works

# Generated at 2022-06-12 13:14:09.175024
# Unit test for function chain_future
def test_chain_future():

    f1 = Future()
    f2 = Future()

    def callback2(f):
        assert f is f2
        assert f1.result() == 2
        assert f2.result() == 2
        assert f1.exception() is None
        assert f2.exception() is None
        assert f1.cancelled() is False
        assert f2.cancelled() is False

    chain_future(f1, f2)
    future_add_done_callback(f1, callback2)

    assert f1.result() is None
    assert f2.result() is None
    assert f1.exception() is None
    assert f2.exception() is None
    assert f1.cancelled() is False
    assert f2.cancelled() is False

    f1.set_result(2)

# Generated at 2022-06-12 13:14:13.049363
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @asyncio.coroutine
    def test_future():
        future = Future()
        future_set_exception_unless_cancelled(future, ValueError())
        try:
            yield from future
        except ValueError:
            pass
        else:
            raise RuntimeError('future_set_exception_unless_cancelled failed')
        future = Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, ValueError())

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test_future())

# Generated at 2022-06-12 13:14:15.276113
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(value: int) -> int:
        return value ** value

    future = dummy_executor.submit(foo, 4)
    assert future.result() == 256

# Generated at 2022-06-12 13:14:32.972833
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_1 = Future()
    future_2 = Future()
    future_3 = Future()
    future_4 = Future()
    future_5 = Future()

    for f in [future_1, future_2, future_3, future_4, future_5]:
        f.set_result(666)

    future_1.cancel()
    future_2.cancel()
    future_3.cancel()
    future_4.cancel()
    future_5.cancel()

    future_set_result_unless_cancelled(future_1, 666)
    future_set_result_unless_cancelled(future_2, 666)
    future_set_result_unless_cancelled(future_3, 666)

# Generated at 2022-06-12 13:14:35.807829
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    global b
    b = DummyExecutor()
    f = b.submit(print, "test_DummyExecutor_submit")
    f.done()
    print(f)



# Generated at 2022-06-12 13:14:42.375838
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    # Test that a future completed in a threadpool (which uses
    # concurrent.futures) propagates to the result of a future
    # chained to it.
    io_loop = tornado.testing.AsyncIOMainLoop()
    io_loop.make_current()
    executor = futures.ThreadPoolExecutor(1)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    def set_f1_result():
        f1.set_result(42)
        executor.shutdown()

    executor.submit(set_f1_result)
    io_loop.run_sync(lambda: f2)
    assert f2.result() == 42

    # test that a future chained to an already-completed future
    # gets the result

# Generated at 2022-06-12 13:14:51.569155
# Unit test for function chain_future
def test_chain_future():
    # Simple test for tornado.concurrent.chain_future
    # Use the fact that result() raises an exception if the future is not done.
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42

    # Test that chaining preserves exception state
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False


if __name__ == "__main__":
    import unittest
    from tornado.testing import AsyncTestCase, gen_test


# Generated at 2022-06-12 13:14:57.735516
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    exec1 = futures.ThreadPoolExecutor(max_workers=2)
    exec2 = futures.ThreadPoolExecutor(max_workers=2)

    class Obj:
        executor = exec1

        @run_on_executor
        def func(self, a, b):
            # type: (int, int) -> int
            return a + b

        @run_on_executor(executor="executor")
        def func_kwargs(self, a, b):
            # type: (int, int) -> int
            return a + b


# Generated at 2022-06-12 13:15:03.033755
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, z):
            # type: (int) -> int
            return z + 42

    foo = Foo()
    future = foo.bar(1)

    def callback(future):
        # type: (Future[int]) -> None
        future.result()

    future_add_done_callback(future, callback)

# Generated at 2022-06-12 13:15:10.134769
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f1 = Future()
    f2 = Future()
    future_set_result_unless_cancelled(f1, 'result')
    future_set_result_unless_cancelled(f2, 'result')
    assert f1.result() == 'result'
    assert f2.result() == 'result'
    f1.cancel()
    f2.cancel()
    future_set_result_unless_cancelled(f1, 'result')
    future_set_result_unless_cancelled(f2, 'result')
    assert f1.cancelled()
    assert f2.cancelled()


# Generated at 2022-06-12 13:15:15.732364
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop

    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    IOLoop.current().run_sync(future)
    assert future.exception() is None

# Generated at 2022-06-12 13:15:23.803718
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import functools
    import random

    @functools.total_ordering
    class MyException(Exception):
        def __lt__(self, other):
            return True

    def fail1():
        # type: () -> None
        raise MyException()

    def fail2():
        # type: () -> None
        raise Exception()

    def fail3():
        # type: () -> None
        1 / 0

    def fail4():
        # type: () -> None
        raise MyException()

    def fail5():
        # type: () -> None
        raise Exception()

    def fail6():
        # type: () -> None
        1 / 0

    def fail7():
        # type: () -> None
        raise MyException()


# Generated at 2022-06-12 13:15:30.552114
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()

    def finish_first():
        future1.set_result(42)

    def finish_second():
        future2.set_result(24)

    chain_future(future1, future2)

    assert not future2.done()
    future1.set_result(None)
    assert future2.done()
    assert future2.result() is None

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)

    future1.set_exception(RuntimeError())
    assert future2.exception() is not None
    assert isinstance(future2.exception(), RuntimeError)

    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future2.set_ex

# Generated at 2022-06-12 13:15:45.139765
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Various test cases for chain_future() without concurrency
    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    assert not b.done()  # b follows a

    a.set_result(42)
    assert b.done()
    assert b.result() == 42  # result is copied from a

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    assert not b.done()  # b follows a
    chain_future(b, c)
    assert not c.done()  # c follows b and therefore a

    # Exceptions are also copied from a to b
    e = ValueError()
    a.set_exception(e)
    assert b.done()

# Generated at 2022-06-12 13:15:50.911637
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is exc

    f = Future()
    f.set_exception(exc)
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is exc

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    assert not f.done()
    assert f.cancelled()

# Generated at 2022-06-12 13:15:59.690693
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def coroutine(r):
        raise asyncio.Return(r)


# Generated at 2022-06-12 13:16:04.984228
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = futures.Future()
    exc = Exception("The Answer")
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = futures.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-12 13:16:10.491540
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import gen
    from tornado.ioloop import IOLoop
    import json

    @gen.coroutine
    def print_json():
        print(json.dumps({'name': 'alex', 'age': '18'}))

    # 通过run_on_executor启动异步线程
    print_json = run_on_executor(print_json)
    IOLoop.current().run_sync(print_json)



# Generated at 2022-06-12 13:16:12.020800
# Unit test for function chain_future
def test_chain_future():
    import tests.util  # imports `unittest`

    async def f():
        pass
    tests.util.run_test(test_chain_future)

# Generated at 2022-06-12 13:16:16.474288
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    done_future = Future()
    done_future.set_result(42)
    cancelled_future = Future()
    cancelled_future.cancel()
    future_set_exception_unless_cancelled(done_future, RuntimeError("My Error"))
    assert done_future.result() == 42
    assert not cancelled_future._log_traceback
    future_set_exception_unless_cancelled(cancelled_future, RuntimeError("My Error"))
    assert cancelled_future._log_traceback[0] == "My Error"

# Generated at 2022-06-12 13:16:22.539199
# Unit test for function chain_future
def test_chain_future():

    global callback_was_called

    callback_was_called = 0

    @gen.coroutine
    def f():
        global callback_was_called
        callback_was_called = 0
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(None)
        callback_was_called = 1
        yield f2
        callback_was_called = 2

    ioloop = IOLoop.current()
    ioloop.run_sync(f)
    assert callback_was_called == 2, callback_was_called



# Generated at 2022-06-12 13:16:27.656103
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    f1.set_exception(RuntimeError())
    chain_future(f1, f2)
    assert isinstance(f2.exception(), RuntimeError)

# Generated at 2022-06-12 13:16:35.420222
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.done()

    # Exceptions are transferred
    c = Future()
    d = Future()
    chain_future(c, d)
    assert not d.done()
    c.set_exception(RuntimeError())
    assert d.done()
    assert_raises(RuntimeError, d.result)

    # But only the first one
    e = Future()
    f = Future()
    chain_future(e, f)
    assert not f.done()
    e.set_exception(RuntimeError())
    assert not f.done()
    e.set_exception(ValueError())

# Generated at 2022-06-12 13:16:53.842516
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exc_info(f, sys.exc_info())
    assert f.done()
    assert f.cancelled()
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.done()
    assert not f.cancelled()



# Generated at 2022-06-12 13:16:57.789888
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    # Close the loop again, even if f2 already has a result
    f2.set_result(None)



# Generated at 2022-06-12 13:17:06.226708
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            g1 = Future()
            g2 = Future()
            chain_future(g1, g2)

            e = Exception()
            g1.set_exception(e)
            self.assertIs(g2.exception(), e)

            h1 = Future()
            h2 = Future()
            chain_future(h1, h2)

            h1.cancel()
            self.assertTrue(h2.cancelled())

            i1 = Future()


# Generated at 2022-06-12 13:17:12.552505
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    def error_callback(f: "Future") -> None:
        raise Exception()

    @tornado.testing.gen_test
    async def test_chain_future_gen() -> None:
        a = Future()
        b = Future()
        chain_future(a, b)
        a.set_result(42)
        self.assertEqual(42, b.result())

        a = Future()
        b = Future()
        chain_future(a, b)
        a.set_exception(RuntimeError())
        self.assertTrue(b.exception())

        a = Future()
        b = Future()
        chain_future(a, b)
        a.set_result(42)
        b.set_result(24)
        self.assertEqual(42, b.result())

# Generated at 2022-06-12 13:17:18.782203
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    inner_future = Future()
    outer_future = Future()

    def verify_error_logged(future):
        assert future == outer_future
        outer_future.set_result(True)

    outer_future.add_done_callback(verify_error_logged)
    inner_future.set_exception(AssertionError("error message"))
    future_set_exception_unless_cancelled(outer_future, inner_future.exception())
    return outer_future

test_future_set_exception_unless_cancelled()

# Generated at 2022-06-12 13:17:23.915153
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.util import concurrent

    class FutureTest(AsyncTestCase):
        @gen_test
        def test_future_set_result_unless_cancelled(self):
            f = concurrent.Future()
            f.cancel()
            with self.assertRaises(concurrent.CancelledError):
                f.result()
            future_set_result_unless_cancelled(f, 123)
            self.assertFalse(f.done())

# Generated at 2022-06-12 13:17:32.695457
# Unit test for function chain_future

# Generated at 2022-06-12 13:17:38.301271
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase

    class TestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.future = Future()

        @gen_test
        async def test_future_set_exception_unless_cancelled(self):
            self.future.cancel()
            future_set_exception_unless_cancelled(self.future, RuntimeError())
            self.assertTrue(self.future.cancelled())

# Generated at 2022-06-12 13:17:42.620243
# Unit test for function chain_future
def test_chain_future():
    def cb(f):
        # type: (Future[int]) -> None
        assert f.done()
        assert not f.cancelled()
        assert f.result() == 5
    f = Future()
    chain_future(f, f)
    f.set_result(5)
    future_add_done_callback(f, cb)



# Generated at 2022-06-12 13:17:52.211159
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class FuturesTest(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            super(FuturesTest, self).__init__(*args, **kwargs)
            self.executor = futures.ThreadPoolExecutor(2)

        @run_on_executor(executor='executor')
        def add(self, a, b):
            return a + b

        @gen_test
        def test_run_on_executor(self):
            result = yield self.add(1, 2)
            self.assertEqual(3, result)

    from types import MethodType
    from unittest import mock

    mock_self = mock.MagicMock()
    mock_executor = mock.Magic

# Generated at 2022-06-12 13:18:25.287406
# Unit test for function chain_future
def test_chain_future():
    def f(x, y):
        return x + y

    @run_on_executor
    def run_f(x, y):
        return f(x, y)

    result1 = Future()
    result2 = Future()

    run_f(1, 2).add_done_callback(lambda future: future_set_result_unless_cancelled(
        result1, future.result()))
    run_f(3, 4).add_done_callback(lambda future: future_set_result_unless_cancelled(
        result2, future.result()))

    assert result1.result() == 3
    assert result2.result() == 7

# Generated at 2022-06-12 13:18:29.359809
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def func(x):
        return x

    io_loop = IOLoop()
    f1 = func("hello")
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    io_loop.add_future(f1, lambda f: io_loop.stop())
    io_loop.start()
    assert f2.done()
    assert f2.result() == "hello"

# Generated at 2022-06-12 13:18:34.659639
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def test_long_sleep():
        from tornado.platform.asyncio import to_asyncio_future
        from tornado.concurrent import Future
        import time
        import logging
        import asyncio
        logging.basicConfig(level=logging.DEBUG,
                        format='%(levelname)-8s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S')
        def long_sleep(seconds):
            logging.debug('long sleep starts')
            time.sleep(seconds)
            logging.debug('long sleep ends')
            return seconds
        coroutine = to_asyncio_future(dummy_executor.submit(long_sleep, 3))
        future = Future()
        coroutine.add_done_callback(lambda future: future.result())
        return

# Generated at 2022-06-12 13:18:38.585832
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

# Generated at 2022-06-12 13:18:47.026120
# Unit test for function chain_future
def test_chain_future():
    import time
    ioloop = IOLoop()
    ioloop.make_current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.done()
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        raise Exception("should have raised ZeroDivisionError")
    loop = asyncio.get_event_loop()
    loop.run_sync(lambda: time.sleep(0.1))
   

# Generated at 2022-06-12 13:18:54.985680
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    # f1 not done, f2 should not be done

    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42

    # Now try errback

    f3 = Future()
    chain_future(f3, f2)

    f3.set_exception(RuntimeError("please ignore"))
    assert f2.done()
    try:
        f2.result()
    except RuntimeError as e:
        assert e.args == ("please ignore",)

    # Now try callback with exception

    f4 = Future()
    chain_future(f4, f2)

    def callback(f):
        1 / 0


# Generated at 2022-06-12 13:18:58.247489
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(future, exc)
    assert_true(future.done())
    assert_true(future.exception() is exc)

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert_true(future.done())
    assert_true(future.cancelled())

# Generated at 2022-06-12 13:19:06.725294
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class A:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor()
        def func(self):
            return 42

    class B:
        def __init__(self):
            self.executor = dummy_executor

        # Explicitly specify the executor attribute
        @run_on_executor(executor="executor")
        def func(self):
            return 42

    class C:
        def __init__(self):
            self._thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self):
            return 42


# Generated at 2022-06-12 13:19:08.064191
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    dummy = DummyExecutor()
    import asyncio
    asyncio.run(dummy.submit)

# Generated at 2022-06-12 13:19:16.338610
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)