

# Generated at 2022-06-12 13:09:50.476410
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42

# Generated at 2022-06-12 13:09:57.275776
# Unit test for function chain_future
def test_chain_future():
    result = object()
    error = ValueError()
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future2.cancel()
    future1.set_result(result)
    assert not future2.done()
    future2 = Future()
    chain_future(future1, future2)
    assert future2.done()
    assert future2.result() is result
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future2.cancel()
    future1.set_exception(error)
    assert not future2.done()
    future2 = Future()
    chain_future(future1, future2)
    assert future

# Generated at 2022-06-12 13:10:07.764277
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42

    # Check that chaining a concurrent.futures.Future to a
    # concurrent.futures.Future works
    future3 = futures.Future()
    future4 = futures.Future()
    chain_future(future3, future4)
    future3.set_result(42)
    assert future4.result() == 42

    # Check that chaining a concurrent.futures.Future to a Future
    # works
    future5 = Future()
    future6 = futures.Future()
    chain_future(future5, future6)
    future5.set_result(42)
    assert future6.result() == 42

# Generated at 2022-06-12 13:10:15.852979
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import string
    import random
    import asyncio
    import time

    async def my_task(future1, future2):
        global _task_complete
        val = future1.result()
        val += future2.result()
        _task_complete.append(val)
        await asyncio.sleep(0.01)

    def genString(string_length=8):
        letters = string.ascii_lowercase
        return "".join(random.choice(letters) for i in range(string_length))

    async def main():
        global _task_complete
        global index
        futures = []
        for i in range(50):
            future1 = dummy_executor.submit(genString, 10)
            future2 = dummy_executor.submit(genString, 10)
            future3 = asyncio.ensure

# Generated at 2022-06-12 13:10:24.319982
# Unit test for function chain_future
def test_chain_future():
    class Future(object):
        def __init__(self, result):
            self.result = result
            self.callbacks = []

        def add_done_callback(self, callback):
            self.callbacks.append(callback)

        def done(self):
            return True

        def result(self):
            return self.result

    a = Future(1)
    b = Future(2)
    chain_future(a, b)
    assert b.result == 1
    assert b.callbacks == []
    c = Future(3)
    d = Future(4)
    chain_future(c, d)
    assert d.result == 3
    assert d.callbacks == []
    assert c.callbacks == [d.callbacks[0]]



# Generated at 2022-06-12 13:10:34.015259
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase

    class Test(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.future = Future()

        def tearDown(self):
            # When we don't use the dummy executor,
            # self.future.set_exception() will raise an exception, but
            # that's ok as it's just a test.
            self.future.cancel()
            super().tearDown()

        def test_future_set_exception_unless_cancelled(self):
            future_set_exception_unless_cancelled(self.future, Exception())
            self.assertFalse(self.future.done())
            self.future.set_result(None)
            IOLoop.current().add_future

# Generated at 2022-06-12 13:10:36.467884
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()  # type: Future[Any]
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("test"))

# Generated at 2022-06-12 13:10:45.457615
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    assert not future1.done()
    assert not future2.done()
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_result(42)
    assert future2.done()
    assert future2.result() == 42
    assert not future2.cancelled()

    future1, future2 = Future(), Future()
    future3, future4 = Future(), Future()
    chain_future(future1, future3)
    chain_future(future2, future4)
    future1.set_exception(RuntimeError("foo"))
    future2.set_exception(RuntimeError("bar"))
    assert future3.exception().args == future4.exception().args == ("foo",)

    future1, future

# Generated at 2022-06-12 13:10:52.326110
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func1(self):
            return 1

        @run_on_executor
        def func2(self, x):
            return x

        @run_on_executor(executor="thread_pool")
        def func3(self, x):
            return x

    foo = Foo()
    f1 = foo.func1()
    assert f1.result() == 1
    f2 = foo.func2(2)
    assert f2.result() == 2
    f3 = foo.func3(3)
    assert f3.result() == 3



# Generated at 2022-06-12 13:11:00.389141
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()

    assert not f2.done()
    chain_future(f1, f2)
    assert not f2.done()

    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_exception(RuntimeError)
    chain_future(f1, f2)
    assert f2.exception().__class__ == RuntimeError

    f1 = Future()
    f2 = Future()
    f1.cancel()
    chain_future(f1, f2)
    assert f2.exception().__class__ == futures.CancelledError

# Generated at 2022-06-12 13:11:12.749663
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures
    import functools
    import unittest
    import tornado.ioloop

    io_loop = tornado.ioloop.IOLoop.current()

    def f():
        return 42

    def ff(value: int, future: Future[int]) -> None:
        future.set_result(value)

    def g(value: int) -> int:
        return value + 1

    def gg(future: Future[int], value: int, callback: Callable[[int], None]) -> None:
        callback(value + 1)

    def callback(future: Future[int]) -> None:
        io_loop.stop()
        future.result()

    def callback2(future: Future[int]) -> None:
        io_loop.stop()
        assert future.result() == 43


# Generated at 2022-06-12 13:11:15.112485
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def dummy_return_1()-> int:
        return 1

    if isinstance(dummy_executor, futures.Executor):
        # type: ignore
        future = dummy_executor.submit(dummy_return_1)
        assert future.result() == 1



# Generated at 2022-06-12 13:11:25.953561
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception1 = RuntimeError("Error1")
    exception2 = RuntimeError("Error2")

    def test_set_exception_unless_cancelled(exception, cancelled_future, active_future):
        try:
            future_set_exception_unless_cancelled(cancelled_future, exception)
        except asyncio.InvalidStateError:
            pass
        else:
            raise Exception("set_exception_unless_cancelled should raise asyncio.InvalidStateError")

        future_set_exception_unless_cancelled(active_future, exception)
        assert active_future.exception() == exception

    test_set_exception_unless_cancelled(exception1, future.copy().cancel(), future.copy())
    test_set_exception_unless_cancelled

# Generated at 2022-06-12 13:11:32.582031
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future, future2)
    future.set_result(42)
    assert future2.result() == 42

    future = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future, future2)
    future.set_exception(ValueError())
    exc = None  # type: Optional[Exception]
    try:
        future2.result()
    except Exception as e:
        exc = e
    assert exc is not None
    assert isinstance(exc, ValueError)



# Generated at 2022-06-12 13:11:37.574444
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    assert not f1.done()
    assert not f2.done()
    f1.set_result(42)
    assert f1.done()
    assert f2.done()
    assert f2.result() == 42


# Generated at 2022-06-12 13:11:48.029548
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Use Future so we can call set_result and set_exception directly.
    first = Future()  # type: Future[str]
    second = Future()  # type: Future[str]
    chain_future(first, second)
    assert not second.done()
    first.set_result("value")
    assert second.result() == "value"
    assert not second.cancelled()

    third = Future()
    chain_future(first, third)
    assert third.done()
    assert third.result() == "value"

    first.cancel()
    assert first.cancelled()
    assert not second.done()

    first = Future()
    second = Future()
    chain_future(first, second)
    assert not second.done()
    first.set_exception

# Generated at 2022-06-12 13:11:56.121431
# Unit test for function chain_future
def test_chain_future():  # noqa: F811
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    a = Future()
    b = Future()

    def cb(f):
        assert f is b
        if not a.done():
            a.set_result(None)
        loop.stop()

    b.add_done_callback(cb)
    chain_future(a, b)
    # a->b
    a.set_result(None)
    loop.run_forever()

    c = Future()
    d = Future()

    def cb(f):
        assert f is d
        if not c.done():
            c.set_exception(Exception())
        loop.stop()

    d.add_done_callback(cb)

# Generated at 2022-06-12 13:12:05.486157
# Unit test for function chain_future
def test_chain_future():
    def combine_futures(future, other):
        assert future is a
        assert other is b
        received[0] = True

    def fail_first_future(future):
        assert False, "should not reach here"

    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    a = Future()
    b = Future()
    chain_future(a, b)

    received = [False]
    b.add_done_callback(combine_futures)

    # Check to make sure that the first future's result doesn't carry through
    # if the second future is already done.
    b.set_result(None)
    a.set_result(None)

# Generated at 2022-06-12 13:12:13.249665
# Unit test for function chain_future
def test_chain_future():
    def callbackA(arg):
        assert arg["key"] == "value"

    def callbackB(arg):
        assert arg["key"] == "value"

    a = Future()
    b = Future()
    chain_future(a, b)

    a.set_result({"key": "value"})
    b.add_done_callback(callbackB)

    # Check if the future is done, add_done_callback
    # should be called immediately.
    c = Future()
    c.set_result({"key": "value"})
    c.add_done_callback(callbackA)

    import logging
    import io
    import contextlib

    logger = logging.getLogger('tornado.application')
    log_output = io.BytesIO()

# Generated at 2022-06-12 13:12:22.327170
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Tests for tornado.concurrent.Future
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.done()
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.done()
    future = Future()
    future.set_result(5)
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
    future = Future()
    future.set_exception(Exception("Exception"))
    future_set_result_unless_cancelled(future, 5)
    assert isinstance(future.exception(), Exception)

    # Tests for concurrent.futures.Future
    future = futures.Future()
    future.cancel()

# Generated at 2022-06-12 13:12:30.587967
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(1234)
    assert not f2.done()
    f3 = Future()
    chain_future(f2, f3)
    assert f3.result() == 1234

    f = Future()
    chain_future(f, f)
    assert f.done()
    chain_future(f, f)
    assert f.done()

# Generated at 2022-06-12 13:12:39.153778
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_fail1(self):
            @gen_test
            def test_fail1():
                a = Future()
                b = Future()
                c = Future()
                chain_future(a, b)
                chain_future(b, c)
                a.set_exception(Exception("foo"))
                with self.assertRaises(Exception) as cm:
                    yield c
                self.assertEqual(str(cm.exception), "foo")

        def test_fail2(self):
            @gen_test
            def test_fail2():
                a = Future()
                b = Future()
                c = Future()
                chain_future(a, b)
                chain_future(b, c)


# Generated at 2022-06-12 13:12:47.544602
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.platform.asyncio.base
    import tornado.platform.asyncio.base_futures
    import tornado.platform.asyncio.constants
    import tornado.platform.asyncio.events
    import tornado.platform.asyncio.httpclient
    import tornado.platform.asyncio.locks
    import tornado.platform.asyncio.queues

    asyncio_future = asyncio.Future()
    # type: typing.Optional[Union[tornado.platform.asyncio.base.BaseFuture, tornado.platform.asyncio.base_futures.BaseTracebackFuture]]
    tornado_future = tornado.concurrent

# Generated at 2022-06-12 13:12:50.611421
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-12 13:12:59.010968
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.ioloop import IOLoop

    def finish_test(future: Future) -> None:
        IOLoop.current().stop()

    def test_one():
        f = Future()
        g = Future()
        chain_future(f, g)
        f.set_result(None)
        if f.done() and not g.done():
            raise Exception("f done, g not done")

    def test_two():
        f = Future()
        g = Future()
        chain_future(f, g)
        f.set_result(None)
        if f.done() and not g.done():
            raise Exception("f done, g not done")
        IOLoop.current().add_callback(test_one)

    def test_three():
        f = Future()
       

# Generated at 2022-06-12 13:13:08.971968
# Unit test for function chain_future
def test_chain_future():
    def make_future() -> Future:
        return Future()

    @functools.singledispatch
    def get_result(future: object) -> Any:
        raise NotImplementedError()

    @get_result.register
    def get_result1(future: Future) -> Any:
        return future.result()

    @get_result.register
    def get_result2(future: futures.Future) -> Any:
        return future.result()

    def set_result(future: object, value: Any) -> None:
        raise NotImplementedError()

    @set_result.register
    def set_result1(future: Future, value: Any) -> None:
        future.set_result(value)


# Generated at 2022-06-12 13:13:17.721765
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def callback(future):
        # type: (Future[_T]) -> None
        assert future.result() == 42

    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    a = Future()  # type: Future[_T]
    b = to_tornado_future(to_asyncio_future(a))
    chain_future(a, b)
    a.set_result(42)

    b.add_done_callback(lambda future: future.result())  # type: ignore

    # check that closing a future closes the result
    c = Future()  # type: Future[_T]
    d = Future()  # type: Future[_T]
    chain_future(c, d)
    c

# Generated at 2022-06-12 13:13:24.794532
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    ioloop = IOLoop()
    ioloop.make_current()

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = ioloop

        def tearDown(self):
            self.io_loop.close(all_fds=True)

        def test_chain_future_asyncio(self):
            future_a = Future()
            future_b = Future()
            chain_future(future_a, future_b)
            future_a.set_result(0)
            self.assertEqual(0, future_b.result())
            future_a = Future()
            future_b = Future()
            future_b.cancel()

# Generated at 2022-06-12 13:13:34.169913
# Unit test for function chain_future
def test_chain_future():
    from concurrent.futures import Future
    from tornado.ioloop import IOLoop

    def future_done_callback(future):
        IOLoop.current().stop()

    a = Future()
    b = Future()

    chain_future(a, b)

    future_add_done_callback(b, future_done_callback)

    IOLoop.current().add_callback(a.set_result, 1)
    IOLoop.current().start()

    assert b.result() == 1

    a = Future()
    b = Future()

    chain_future(a, b)

    @run_on_executor(executor='_thread_pool')
    def set_a():
        a.set_exception(ValueError("Test error"))

    IOLoop.current().add_callback(set_a)


# Generated at 2022-06-12 13:13:37.220613
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-12 13:13:44.479602
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    try:
        future.result()
    except Exception as err:
        assert err is exc

    future = Future()
    future.cancel()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-12 13:13:47.819217
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = futures.Future()
    future.set_exception(Exception("message"))
    future_set_exception_unless_cancelled(future, Exception("test"))
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))

# Generated at 2022-06-12 13:13:54.141194
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    my_future = Future()

    my_future.cancel()
    assert my_future.cancelled()

    future_set_exception_unless_cancelled(
        my_future, Exception('Test Future'))  # ignored

    my_future = Future()

    my_future.cancel()
    assert my_future.cancelled()

    future_set_exception_unless_cancelled(
        my_future, Exception('Test Future'), log_traceback=False)  # ignored

# Generated at 2022-06-12 13:13:56.536573
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()

    future.set_result(None)
    assert future.done()

    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1

# Generated at 2022-06-12 13:14:00.647091
# Unit test for function chain_future
def test_chain_future():
    try:
        from tornado.testing import AsyncTestCase, gen_test
    except ImportError:
        raise unittest.SkipTest("asyncio not present")

    class MyTestCase(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())

            f1.set_result(42)
            yield f2
            self.assertEqual(f2.result(), 42)

    test = MyTestCase()
    test.test_chain_future()

# Generated at 2022-06-12 13:14:10.177439
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock

    future = Future()
    exc = Exception("test exception")

    with unittest.mock.patch("tornado.concurrent.Future") as mock_future:
        future_set_exception_unless_cancelled(future, exc)

        mock_future.return_value.cancelled.assert_called_once_with()
        mock_future.return_value.set_exception.assert_called_once_with(exc)

    future.cancel()

    with unittest.mock.patch("tornado.concurrent.Future") as mock_future:
        with unittest.mock.patch("tornado.log.app_log") as mock_logging:
            future_set_exception_unless_cancelled(future, exc)


# Generated at 2022-06-12 13:14:15.490611
# Unit test for function chain_future
def test_chain_future():
    result = None

    def f1(x, y):
        return x + y

    def f2(future):
        global result
        result = future.result()

    f = Future()
    f.set_result(None)

    c1 = dummy_executor.submit(f1, 1, 2)
    chain_future(c1, f)

    assert not f.done()
    future_add_done_callback(f, f2)
    assert result == 3



# Generated at 2022-06-12 13:14:18.918925
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled() == False
    assert f.result() == 5
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled() == True

# Generated at 2022-06-12 13:14:23.291432
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    e = ValueError("hello")
    f = Future()
    future_set_exception_unless_cancelled(f, e)
    assert f.exception() == e
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, e)
    assert f.exception() is None

# Generated at 2022-06-12 13:14:33.852686
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import unittest

    try:
        import unittest.mock as mock  # type: ignore
    except ImportError:
        import mock

    # build mock future with a working add_done_callback as required by
    # future_set_exception_unless_cancelled
    future = mock.Mock()
    future.cancelled.return_value = False
    future.exception.side_effect = AttributeError()
    future.add_done_callback = mock.Mock()

    future_set_exception_unless_cancelled(future, Exception("foo"))
    # ensure the set_exception method of the future was called once
    future.set_exception.assert_called_once_with(Exception("foo"))
    # ensure the add_done_callback method was not called

# Generated at 2022-06-12 13:14:43.686175
# Unit test for function chain_future
def test_chain_future():
    # type: () -> Tuple[Future, Future]
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42
    return future1, future2



# Generated at 2022-06-12 13:14:52.520934
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    # pylint: disable=protected-access
    import unittest
    import mock

    # The Future class is used rather than the Future implementation
    # itself (asyncio.Future/_chain_future) to ensure that the
    # implementation detail doesn't change to break the test.
    class Future(object):
        def __init__(self):
            self.cancelled = False
            self.exception_was_called = False

        def cancelled(self):
            # type: () -> bool
            return self.cancelled

        def set_exception(self, exc):
            # type: (BaseException) -> None
            self.exception_was_called = True


# Generated at 2022-06-12 13:14:56.510104
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    loop = asyncio.new_event_loop()
    future = loop.create_future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.result() == None
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.result() == None
    loop.close()

# Generated at 2022-06-12 13:15:01.433511
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    canceled_future = Future()
    canceled_future.cancel()
    future_set_exception_unless_cancelled(canceled_future, ValueError())

    done_future = Future()
    done_future.set_exception(ValueError())
    future_set_exception_unless_cancelled(done_future, ValueError())

    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None



# Generated at 2022-06-12 13:15:06.799319
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.set_result(42)
    assert future.result() == 42
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError)
    assert future.result() == 42
    future = Future()
    future.set_result(42)
    assert future.result() == 42
    future_set_exception_unless_cancelled(future, RuntimeError)
    assert future.result() == 42

# Generated at 2022-06-12 13:15:14.274979
# Unit test for function chain_future
def test_chain_future():
    def f():
        pass
    f.__name__ = "f"
    g = chain_future(f)
    g.__name__ = "g"

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert f.result() == 42
    assert g.result() == 42
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(RuntimeError())
    assert f.exception() is not None
    try:
        g.result()
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-12 13:15:19.190392
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(3)
    assert g.result() == 3

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(ZeroDivisionError())
    with pytest.raises(ZeroDivisionError):
        g.result()
    
    

# Generated at 2022-06-12 13:15:23.296612
# Unit test for function run_on_executor
def test_run_on_executor():
    from unittest import TestCase, mock

    class TestFoo(object):
        def __init__(self):
            self.executor = mock.Mock()

    foo = TestFoo()

    @run_on_executor()
    def bar():
        return

    foo.bar = bar

    foo.bar()

    assert foo.executor.submit.called


# Generated at 2022-06-12 13:15:27.718250
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    def f(result):
        a = yield gen.sleep(0)
        b = yield gen.sleep(0)
        raise gen.Return(result)

    a = Future()
    b = Future()
    chain_future(a, b)

    @gen.coroutine
    def test():
        a.set_result(None)
        res = yield b
        assert res is None

    gen.convert_yielded(test())

# Generated at 2022-06-12 13:15:33.100322
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    etype, evalue, etb = sys.exc_info()
    future_set_exception_unless_cancelled(future, evalue)
    future.cancel()
    # This test will fail with a future.CancelledError if this
    # function does not handle that case properly.
    future_set_exception_unless_cancelled(future, evalue)
    future.set_exception(evalue)
    future.cancel()

# Generated at 2022-06-12 13:15:48.135997
# Unit test for function chain_future
def test_chain_future():
    f1 = futures.Future()
    f2 = futures.Future()

    chain_future(f1, f2)
    f1.set_result("foo")
    assert f2.result() == "foo"


if hasattr(asyncio, "all_tasks"):
    all_tasks = asyncio.all_tasks
else:
    all_tasks = asyncio.Task.all_tasks



# Generated at 2022-06-12 13:15:56.290918
# Unit test for function chain_future
def test_chain_future():
    from tornado import testing
    from tornado.gen import multi

    def f1():
        return 1

    def f2(arg):
        return 2 * arg

    def f3(arg):
        raise Exception()

    def f4(arg):
        raise Exception()

    @multi
    def multi_future():
        x = yield f1()
        y = yield f2(x)
        z = yield f3(x + y)
        w = yield f4(x + y + z)
        return x + y + z + w

    @multi
    def multi_future_error1():
        x = yield f1()
        y = yield f2(x)
        z = yield f3(x + y)
        w = yield f4(x + y + z)
        raise Exception()


# Generated at 2022-06-12 13:16:05.818737
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.log import gen_log

    f1, f2 = Future(), Future()

    chain_future(f1, f2)
    f1.set_result(42)

    assert f2.result() == 42

    def error_callback(f: Future) -> None:
        gen_log.error("f2 raised: %s", f.exception())

    f2.add_done_callback(error_callback)
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())

    # Ensure that f2's errback was run
    assert f2.exception() is not None

# Generated at 2022-06-12 13:16:08.825170
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    assert f.cancelled()
    assert not f.done()
    assert f.result() is None

# Generated at 2022-06-12 13:16:12.599881
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    if sys.version_info >= (3, 5):
        async def async_fn() -> int:
            return 42

        async def test_async_chain_future() -> None:
            f = Future()  # type: Future[int]
            chain_future(async_fn(), f)
            assert await f == 42

        asyncio.run(test_async_chain_future())

# Generated at 2022-06-12 13:16:16.028187
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def dummy_handler(future):
        pass
    asyncio_future = asyncio.Future()
    tornado_future = Future()

    future_set_exception_unless_cancelled(asyncio_future, Exception())
    future_set_exception_unless_cancelled(tornado_future, Exception())

    assert asyncio_future.result() is None
    assert tornado_future.result() is None

# Generated at 2022-06-12 13:16:17.337059
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda : 1+1,1,1) == 2

# Generated at 2022-06-12 13:16:23.634782
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()

    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42


if typing.TYPE_CHECKING:
    def _assert_not_typing(name: str, value: Any):
        if isinstance(value, typing.Type):
            raise AssertionError(
                "%s:%s should not be imported from typing" % (__name__, name)
            )

    _assert_not_typing("Future", Future)
    _assert_not_typing("_T", _T)
    del _assert_not_typing

# Generated at 2022-06-12 13:16:31.157239
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.future = Future()
            self.future2 = Future()

        def test_chain_future(self):
            chain_future(self.future, self.future2)
            self.future.set_result(42)
            self.assertEqual(self.future2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            chain_future(self.future, self.future2)
            self.future.set_exception(ValueError())
            with self.assertRaises(ValueError):
                yield self.future2

       

# Generated at 2022-06-12 13:16:33.470048
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future_set_exception_unless_cancelled(
        asyncio.Future(),
        Exception("exception from future_set_exception_unless_cancelled"),
    )


# Generated at 2022-06-12 13:16:56.529084
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Check that chain_future forwards the result correctly
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    # Check the exception case
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError("foo"))
    assert f2.exception() is not None
    assert f2.exception().args == ("foo",)
    # Check that chain_future does not override an already-set result/exception
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
   

# Generated at 2022-06-12 13:17:05.603552
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    asyncio = py36_mock
    f1 = asyncio.Future()
    f2 = asyncio.Future()
    f2.cancel()
    future_add_done_callback(f1, lambda f: future_set_result_unless_cancelled(f2, 42))
    f1.set_result(None)
    assert f2.cancelled()
    assert not f2.done()
    assert f2.result() is None

    f1 = asyncio.Future()
    f2 = asyncio.Future()
    f2.cancel()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.cancelled()
    assert not f2.done()
    assert f2.result() is None



# Generated at 2022-06-12 13:17:12.235408
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import types
    import typing

    import tornado.testing
    import tornado.ioloop
    from tornado.concurrent import futures

    def func(fn: Callable[..., _T], *args: Any, **kwargs: Any) -> "futures.Future[_T]":
        print('func')
        future = futures.Future()  # type: futures.Future[_T]
        try:
            future_set_result_unless_cancelled(future, fn(*args, **kwargs))
        except Exception:
            future_set_exc_info(future, sys.exc_info())
        return future

    dummy_executor = DummyExecutor()
    dummy_executor.submit(func, lambda x: x, 1)

    print(dummy_executor.submit)

# Generated at 2022-06-12 13:17:16.490375
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # 构造结果函数
    def fn(a: int, b: int) -> int:
        return a + b

    e = dummy_executor
    f = e.submit(fn, 2, 3)
    assert f.result() == 5

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-12 13:17:24.371011
# Unit test for function chain_future
def test_chain_future():
    def future_set_exception(future: asyncio.Future, exception: BaseException) -> None:
        if not future.cancelled():
            future.set_exception(exception)

    def future_set_result(future: asyncio.Future, value: Any) -> None:
        if not future.cancelled():
            future.set_result(value)

    f = asyncio.Future()
    g = asyncio.Future()

    future_set_result(f, 42)
    chain_future(f, g)
    assert g.done() and g.result() == 42

    future_set_exception(f, ZeroDivisionError())
    chain_future(f, g)
    assert g.done() and g.exception() is not None

    f = futures.Future()

# Generated at 2022-06-12 13:17:28.801493
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("Oh Noes"))
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("Oh Noes"))
    assert future.exception() is None

# Generated at 2022-06-12 13:17:37.595556
# Unit test for function chain_future
def test_chain_future():
    def test_future(source_future):
        target_future = Future()
        chain_future(source_future, target_future)
        return target_future

    # Test a source future that isn't done.
    source_future = Future()
    target_future = test_future(source_future)
    source_future.set_result(None)
    assert target_future.done()
    assert not target_future.exception()

    # Test a source future that's done.
    source_future = Future()
    source_future.set_result(None)
    target_future = test_future(source_future)
    assert target_future.done()
    assert not target_future.exception()

    # Test a source future that raised an exception
    source_future = Future()

# Generated at 2022-06-12 13:17:47.136360
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import threading

    def run_in_other_thread(fn):
        def run():
            fn()
            io_loop.stop()

        threading.Thread(target=run).start()
        io_loop.start()

    # Reuse the same loop across multiple tests
    io_loop = tornado.ioloop.IOLoop()
    io_loop.make_current()

    inner = Future()
    outer = Future()

    chain_future(inner, outer)

    # The chain works both ways
    run_in_other_thread(functools.partial(inner.set_result, 42))
    assert outer.result() == 42

    # Exceptions also propagate
    def run():
        inner.set_exception(TypeError("foo"))
        io_loop.stop()

    run_in

# Generated at 2022-06-12 13:17:48.829680
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = future_set_result_unless_cancelled(Future(), "value")
    assert future == "value"

# Generated at 2022-06-12 13:17:56.865349
# Unit test for function chain_future
def test_chain_future():

    class Future2(futures.Future):
        def add_done_callback(self, callback: Callable[..., None]) -> None:
            self._callback = callback

        def set_result(self, result: Any) -> None:
            super(Future2, self).set_result(result)
            self._callback(self)

        def set_exception(self, exception: BaseException) -> None:
            super(Future2, self).set_exception(exception)
            self._callback(self)

    class Future3(Future):
        def add_done_callback(self, callback: Callable[..., None]) -> None:
            self._callback = callback

        def set_result(self, result: Any) -> None:
            super(Future3, self).set_result(result)

# Generated at 2022-06-12 13:18:28.720907
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    assert isinstance(dummy_executor._thread_pool, ThreadPoolExecutor)
    dummy_executor._thread_pool.shutdown()
    dummy_executor._thread_pool = None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("foo"))

# Generated at 2022-06-12 13:18:38.338199
# Unit test for function chain_future
def test_chain_future():
    import threading
    import time

    fut1 = Future()
    fut2 = Future()

    chain_future(fut1, fut2)
    assert fut2.done() is False

    # Test future completion
    fut1.set_result(42)
    assert fut2.result() == 42

    # Test chaining a future to itself
    fut1.set_result(None)
    chain_future(fut1, fut1)
    assert fut1.done() and fut1.result() is None

    # Test chained future failure
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)

    exc = Exception()
    fut1.set_exception(exc)
    assert fut2.exception() == exc
    assert fut2.done()

    # Test with a

# Generated at 2022-06-12 13:18:46.757662
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.testing
    import tornado.web

    class TestFuture(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            try:
                import asyncio
            except ImportError:
                raise unittest.SkipTest("asyncio module not present")
            f = asyncio.Future()
            executor = concurrent.futures.ThreadPoolExecutor(1)

            @run_on_executor(executor='executor')
            def set_result(self):
                # type: () -> None
                asyncio.get_event_loop().call_soon(f.set_result, None)
           

# Generated at 2022-06-12 13:18:52.433704
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.done()
    assert f2.cancelled()



# Generated at 2022-06-12 13:18:58.594634
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert not f1.done()
    assert not f2.done()
    chain_future(f1, f2)
    assert not f1.done()
    assert not f2.done()

    f1.set_result(42)
    assert f1.result() == 42
    assert f2.result() == 42
    assert f1.done()
    assert f2.done()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f1.result() == 42
    assert f1.done()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_

# Generated at 2022-06-12 13:19:07.161908
# Unit test for function chain_future
def test_chain_future():
    async def async_test_chain_future():
        # type: () -> None
        fut = Future()
        fut2 = Future()
        assert fut is not fut2
        chain_future(fut, fut2)
        assert not fut2.done()
        fut.set_result(True)
        assert fut2.done()
        assert fut2.result() is True

        fut = Future()
        fut2 = Future()
        assert fut is not fut2
        chain_future(fut, fut2)
        assert not fut2.done()
        fut.set_exception(ValueError("false"))
        assert fut2.done()
        assert isinstance(fut2.exception(), ValueError)

    #
    # concurrent.futures.Future (futures.Future)
    #
    fut = futures.Future

# Generated at 2022-06-12 13:19:11.111105
# Unit test for function chain_future
def test_chain_future():
    async def main():
        f = Future()
        f2 = Future()
        f.set_result(None)
        chain_future(f, f2)
        return f2

    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(main())

    finally:
        loop.close()



# Generated at 2022-06-12 13:19:19.371008
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result("value")
    assert b.result() == "value"

    a = Future()
    b = asyncio.Future()
    a.set_result("value")
    chain_future(a, b)
    assert b.result() == "value"

    a = Future()
    b = asyncio.Future()
    b.set_result("value")
    chain_future(a, b)
    a.set_result("newvalue")
    assert b.result() == "value"

    a = Future()
    b = asyncio.Future()
    b.set_exception(RuntimeError("error"))
    chain_future(a, b)
    a.set_result("newvalue")


# Generated at 2022-06-12 13:19:27.052126
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.f1_result = None
            self.f2_result = None
            self.f1_exc_info = None
            self.f2_exc_info = None
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            super().tearDown()
            self.executor.shutdown()

        def test_chain(self):
            self.f1 = Future()
            self.f2 = Future()
            self.f1.add_done_callback(self._f1_done_callback)
            self.f2

# Generated at 2022-06-12 13:19:33.857936
# Unit test for function chain_future
def test_chain_future():

    # If a parallel thread sets the result while we are waiting, the
    # WaitFuture should return it immediately.
    def add_done_callback(future):
        future.set_result(5)

    future = Future()
    future.add_done_callback(add_done_callback)

    def callback(future):
        future.set_result(6)

    another = Future()
    chain_future(future, another)
    future_add_done_callback(another, callback)
    assert another.result() == 6

    # If a parallel thread sets the exception while we are waiting, the
    # WaitFuture should raise it immediately.
    future = Future()

    def add_done_callback_error(future):
        future.set_exception(Exception('test_chain_future'))
