

# Generated at 2022-06-12 13:09:55.094639
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    def asyncio_future():
        # type: () -> Future
        return Future()

    def tornado_future():
        # type: () -> futures.Future
        return futures.Future()

    for factory in asyncio_future, tornado_future:
        f = factory()
        future_set_exc_info(f, sys.exc_info())
        assert f.exception() is not None

        f = factory()
        future_set_exception_unless_cancelled(f, Exception())
        assert f.exception() is not None

        f = factory()
        f.cancel()
        future_set_exception_unless_cancelled(f, Exception())
        assert f.exception() is None

# Generated at 2022-06-12 13:10:05.932075
# Unit test for function chain_future
def test_chain_future():
    f = futures.Future()
    g = Future()
    chain_future(f, g)
    f.set_result(3)
    assert g.result() == 3

    # Test that chain_future copes with the chain being cancelled
    # (we don't care about concurrent.futures.Future here, since
    # those arguments are just forwarded to set_exception)
    f = Future()
    g = Future()
    chain_future(f, g)
    g.cancel()
    f.set_exception(RuntimeError())
    assert g.exception() is None

    # Test that chain_future is tolerant of the first future being
    # cancelled as well.
    f = Future()
    g = Future()
    chain_future(f, g)
    f.cancel()
    assert g.exception

# Generated at 2022-06-12 13:10:14.534915
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import pytest
    from concurrent.futures import Future, TimeoutError
    from tornado.concurrent import DummyExecutor

    def a():
        return 3

    def b():
        raise ValueError("error")

    dummy_executor = DummyExecutor()
    future_a = dummy_executor.submit(a)
    future_b = dummy_executor.submit(b)

    assert future_a.cancel() == False
    try:
        future_a.result(timeout=0.01)
    except TimeoutError:
        pass
    else:
        pytest.fail("Dummy Executor didn't raise timeout error")
    assert future_a.result() == 3

    assert future_b.cancel() == False

# Generated at 2022-06-12 13:10:24.371378
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @typing.overload
    def future_set_exception_unless_cancelled(
        future: "futures.Future[_T]", exc: BaseException
    ) -> None:
        pass

    @typing.overload  # noqa: F811
    def future_set_exception_unless_cancelled(
        future: "Future[_T]", exc: BaseException
    ) -> None:
        pass

    def assert_raises(exception_type: type, func: Callable) -> None:
        def assert_raises_decorator(
            future: "Union[futures.Future[_T], Future[_T]]"
        ) -> None:
            with pytest.raises(exception_type):
                func(future)

        return assert_raises_decorator

   

# Generated at 2022-06-12 13:10:30.043998
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    f2 = Future()
    try:
        raise Exception("Exception")
    except:
        # set the exc_info as the future's exception
        future_set_exc_info(f1, sys.exc_info())
        # set the exc_info as the future's exception, and it is canceled.
        future_set_exc_info(f2, sys.exc_info())
    # If the Future f2 is already canceled, it should not raise an exception.

# Generated at 2022-06-12 13:10:34.248541
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError('foo'))
    assert future.exception() is not None
    future = Future()
    assert future.cancel()
    future_set_exception_unless_cancelled(future, ValueError('foo'))

# Generated at 2022-06-12 13:10:36.035117
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("bla"))

# Generated at 2022-06-12 13:10:38.810441
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def f(self, x):
        return x + 1

    class Obj(object):
        executor = dummy_executor

    obj = Obj()

    f(obj, 1).result() == 2


# Generated at 2022-06-12 13:10:41.538136
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None


# Generated at 2022-06-12 13:10:50.242479
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from .locks import Condition

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run(self):
            @run_on_executor
            def f(x):
                return x + 1

            @gen.coroutine
            def g():
                result = yield f(41)
                self.assertEqual(result, 42)

            self.io_loop.run_sync(g)


# Generated at 2022-06-12 13:11:02.860861
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.testing import gen_test
    from tornado.test.util import unittest, ignore_deprecation
    from concurrent.futures import _base, Future as ConcurrentFuture

    class Example(object):
        executor = dummy_executor

        @run_on_executor
        def func(self) -> None:
            """Docstring"""
            return 123

    example = Example()
    future = example.func()
    assert isinstance(future, Future)
    assert future.result() == 123
    assert future.__doc__ == "Docstring"

    # Assert that this method is semantically equivalent to
    # a direct @gen.coroutine-wrapped call to the executor's submit.
    class EquivalentExample(object):
        executor = dummy

# Generated at 2022-06-12 13:11:06.938267
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    future_set_exception_unless_cancelled(f1, Exception("test"))
    assert f1.exception() is not None

    f2 = Future()
    f2.cancel()
    future_set_exception_unless_cancelled(f2, Exception("test"))
    assert f2.exception() is None

# Generated at 2022-06-12 13:11:11.069201
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.done()
    assert isinstance(future.exception(), ValueError)
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.done()
    assert future.exception() is None

# Generated at 2022-06-12 13:11:18.937042
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def run_func(exc_info):
        future = Future()
        future_set_exc_info(future, exc_info)
        return await future

    exc_info = (TypeError, TypeError("foo"), None)
    future = run_func(exc_info)
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()
    try:
        future.result()
    except TypeError as e:
        assert e.__traceback__ is exc_info[2]
        assert type(e) is exc_info[0]
        assert str(e) == "foo"
    else:
        assert False, "future should have been cancelled"

    future = run_func(exc_info)

# Generated at 2022-06-12 13:11:29.131687
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.log import app_log
    from tornado import gen

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.log_records = []  # type: typing.List[logging.LogRecord]

        def _log_handler(self, record):
            self.log_records.append(record)

        def get_logged_exceptions(self) -> typing.List[BaseException]:
            return [r.exc_info[1] for r in self.log_records if r is not None]

        @gen_test
        async def test_cancelled(self):
            future = Future()
            future.cancel()

# Generated at 2022-06-12 13:11:30.751972
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert is_future(dummy_executor.submit(lambda: 1))



# Generated at 2022-06-12 13:11:36.733543
# Unit test for function chain_future
def test_chain_future():
    async def f():
        # type: () -> None
        s = asyncio.Future()
        t = Future()

        chain_future(s, t)
        s.set_result(42)
        assert s.result() == 42
        assert t.result() == 42

    asyncio.get_event_loop().run_until_complete(f())


# Unit tests for function future_add_done_callback



# Generated at 2022-06-12 13:11:42.756692
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    assert not future2.done()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42
    assert future2.done()

    future1 = Future()
    future2 = Future()
    future1.set_result(42)
    chain_future(future1, future2)
    assert future2.result() == 42
    assert future2.done()


# Generated at 2022-06-12 13:11:52.797540
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools
    import concurrent.futures

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = asyncio.get_event_loop()
            self.result = None
            self.done = 0
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

        def callback(self, future):
            self.done += 1
            self.result = future.result()

        def test_chain(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertTrue(a is not b)
            self.assertEqual(self.done, 0)
            a.set_result(42)
            self.io_loop

# Generated at 2022-06-12 13:11:55.946755
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-12 13:12:05.646481
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def f():
        yield
    f2 = Future()  # type: Future[None]
    g = Future()  # type: Future[None]
    chain_future(f(), g)
    chain_future(g, f2)


# Generated at 2022-06-12 13:12:13.347941
# Unit test for function chain_future
def test_chain_future():
    import tornado.ioloop
    import time

    def sleep_and_stop(ioloop, duration):
        time.sleep(duration)
        ioloop.stop()

    def stop_after_future(future):
        if 5 == future.result():
            ioloop.stop()
        else:
            raise Exception("Unexpected result %r" % (future.result(),))

    f = Future()
    f.set_result(5)
    ioloop = tornado.ioloop.IOLoop.current()
    # Run soon makes the stop callback run as soon as the stack frame
    # falls off, so the sleep happens first.  This also exercises
    # the Future.running attribute.
    ioloop.add_callback(sleep_and_stop, ioloop, 0.01)

# Generated at 2022-06-12 13:12:22.363803
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestAsync(AsyncTestCase):
        @gen_test  # type: ignore
        def test_chain_future_asyncio(self) -> None:
            loop = self.io_loop
            executor = futures.ThreadPoolExecutor(2)
            future = loop.run_in_executor(executor, lambda: True)
            future2 = Future()
            chain_future(future, future2)
            result = yield future2
            self.assertTrue(result)

        @gen_test  # type: ignore
        def test_chain_future_concurrent(self) -> None:
            loop = self.io_loop
            executor = futures.ThreadPoolExecutor(2)
            future = executor.submit(lambda: True)

# Generated at 2022-06-12 13:12:30.634159
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future_asyncio(self):
            async_first = Future()
            async_second = Future()
            chain_future(async_first, async_second)
            async_second.add_done_callback(self.stop)
            async_first.set_result(None)
            self.wait()

        def test_chain_future_concurrent(self):
            # concurrent.futures.Future doesn't have __await__; they
            # can't be used ``await``, but they should be compatible
            # with chain_future.
            async_first = Future()
            conc_second = futures.Future()
            chain_future(async_first, conc_second)
            conc

# Generated at 2022-06-12 13:12:36.976394
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future2.cancel()
    chain_future(future1, future2)
    assert not future2.cancelled()
    future1.set_result(42)
    assert future2.result() == 42
    future1 = Future()
    future2 = Future()
    future2.cancel()
    chain_future(future1, future2)
    assert not future2.cancelled()
    future1.set_exception(RuntimeError())
    assert_future_exception(future2, RuntimeError)

# Generated at 2022-06-12 13:12:45.158201
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado import ioloop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = ioloop.IOLoop()
            self.parent = Future()
            self.child = Future()

        def test_chain(self):

            def callback():
                self.parent.set_result(42)

            self.io_loop.add_callback(callback)
            chain_future(self.parent, self.child)

            self.assertFalse(self.child.done())

            self.io_loop.run_sync(self.child)

            self.assertTrue(self.parent.done())
            self.assertTrue(self.child.done())
            self.assertEqual(42, self.child.result())


# Generated at 2022-06-12 13:12:52.303548
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    obj = DummyExecutor()

    # 调用 submit,返回一个 future
    # 返回结果为 2, 异常为未定义
    f = obj.submit(lambda x: x, 2)
    assert f.result() == 2
    assert f.exception() == None

    # 调用 submit,返回一个 future
    # 函数异常
    f = obj.submit(lambda x, y: x / y, 2, 0)
    assert f.exception() == ZeroDivisionError

# Generated at 2022-06-12 13:12:54.201016
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))

# Generated at 2022-06-12 13:13:03.204591
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent.futures import ThreadPoolExecutor

    class TestClass(object):
        executor = ThreadPoolExecutor(4)

    # Test for tornado.concurrent.run_on_executor
    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.test_instance = TestClass()

        def test_synchronous(self):
            @run_on_executor
            def f(self):
                return 42

            result_future = f(self.test_instance)
            self.assertTrue(is_future(result_future))
            result = result_future.result()
            self.assertEqual(42, result)


# Generated at 2022-06-12 13:13:10.948440
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    executor = dummy_executor

    class Foo:
        executor = executor

        @run_on_executor
        def bar(self, a, b=1):
            return a + b

    f = Foo()

    def cb(a):
        assert a == 6
        loop.stop()

    f.bar(4, b=2).add_done_callback(cb)
    loop.start()


if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-12 13:13:42.904396
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    # This test assumes that the futures module is available. It's not
    # available on Windows with Python 2.
    if sys.platform == "win32" and sys.version_info < (3, 0):
        return
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())

    io_loop = IOLoop.current()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    async_future = Future()
    conc_future = futures.Future()

    def set_result():
        loop.call_soon_threadsafe(conc_future.set_result, None)


# Generated at 2022-06-12 13:13:52.121723
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future

    a = Future()
    b = Future()
    c = Future()

    chain_future(b, c)
    assert not b.done()
    assert not c.done()

    b.set_result(42)
    assert b.result() == 42
    assert c.result() == 42

    chain_future(a, b)
    assert not b.done()
    a.set_exception(RuntimeError())
    assert b.done()
    b.result()

    a = Future()
    b = Future()
    c = Future()

    chain_future(b, c)
    assert not b.done()
    assert not c.done()

    a.set_result(42)
    b.set_result(24)
    assert c.result() == 24

    a

# Generated at 2022-06-12 13:13:55.368986
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    future.set_exception(Exception())
    assert future
    future_set_exception_unless_cancelled(future, Exception())
    assert future
    future_set_exception_unless_cancelled(future, Exception())
    assert future



# Generated at 2022-06-12 13:14:04.876048
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    io_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(io_loop)
    result = [None]
    exc_info = [None]

    class A(AsyncTestCase):
        def _callback(self, future):
            result[0] = future.result()
            exc_info[0] = future.exc_info()
            self.stop()

    class B(A):
        def _callback(self, future):
            raise Exception("exception from _callback")

    class C(A):
        def _callback(self, future):
            raise SystemExit("exception from _callback")

    class D(A):
        def _callback(self, future):
            1 // 0


# Generated at 2022-06-12 13:14:10.814770
# Unit test for function chain_future
def test_chain_future():
    def callback1(f: "Future") -> None:
        assert f.result() == "foo"

    def callback2(f: "Future") -> None:
        assert f.result() == "foo"

    f = Future()
    f2 = Future()
    chain_future(f2, f)
    future_add_done_callback(f, callback1)
    future_add_done_callback(f2, callback2)
    f2.set_result("foo")

# Generated at 2022-06-12 13:14:18.953592
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.done()
    assert b.result() == 42

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(b, c)
    a.set_result(42)
    assert b.done()
    assert b.result() == 42
    assert c.done()
    assert c.result() == 42

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, c)
    chain_future(b, c)
    a.set_result(42)
    assert not b.done()
    assert c.done()


# Generated at 2022-06-12 13:14:23.804224
# Unit test for function run_on_executor
def test_run_on_executor():
    # Note that this requires knowing some private details of the
    # implementation (for example, that we always use the current IOLoop).
    from tornado import gen

    @run_on_executor
    def f(x, y):
        return x + y

    @gen.coroutine
    def main():
        result = yield f(1, 2)
        assert result == 3

    main()

# Generated at 2022-06-12 13:14:34.428021
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def f():
        pass
    # All checked in try/finally, since we expect to get an exception.

# Generated at 2022-06-12 13:14:37.026472
# Unit test for function chain_future
def test_chain_future():
    import concurrent.futures

    f = concurrent.futures.Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42

    f = Future()
    f2 = concurrent.futures.Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-12 13:14:39.739535
# Unit test for function chain_future
def test_chain_future():
    def future_set_result_unless_cancelled_mock(future, value):
        future_set_result_unless_cancelled(future, value)

    future = asyncio.Future()
    chain_future(future, future)


# Generated at 2022-06-12 13:15:05.114120
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 3)
    assert future.result() == 3

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    with pytest.raises(FutureCancelledError):
        future.result()


# Generated at 2022-06-12 13:15:09.358158
# Unit test for function chain_future
def test_chain_future():
    err = RuntimeError()

    f1 = Future()
    f1.set_exception(err)

    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f2, f3)
    assert f2.exc_info() is not None
    assert f3.exc_info() is not None
    return f3

# Generated at 2022-06-12 13:15:18.691874
# Unit test for function chain_future
def test_chain_future():
    def callback(f):
        assert f.result() == 123

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert f2.done() is False
    assert f2.cancelled() is False

    f1.set_result(123)
    assert f2.done() is True
    assert f2.result() == 123

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError)
    assert f2.done() is True
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ValueError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f

# Generated at 2022-06-12 13:15:25.552046
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    @run_on_executor
    def slow_set():
        import time
        time.sleep(0.5)
        f1.set_result("abc")

    slow_set()

    chain_future(f1, f2)

    def done(f):
        assert f.result() == "abc"
        loop.stop()

    f2.add_done_callback(done)
    loop.run_forever()

# Generated at 2022-06-12 13:15:29.283377
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    import unittest
    import time

    class MyTestCase(unittest.TestCase):
        executor = dummy_executor

        @run_on_executor()
        def function(self):
            pass

        def test_run_on_executor(self):
            self.function()

    ts = MyTestCase()
    ts.test_run_on_executor()

# Generated at 2022-06-12 13:15:34.020708
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 3)
    assert f.cancelled()
    assert not f.done()

    f = Future()
    future_set_result_unless_cancelled(f, 4)
    assert not f.cancelled()
    assert f.done()
    assert f.result() == 4



# Generated at 2022-06-12 13:15:38.201133
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import time

    @run_on_executor
    def func():
        # type: () -> int
        time.sleep(0.1)
        return 10

    loop = asyncio.get_event_loop()
    future = Future()
    loop.run_until_complete(func())
    chain_future(func(), future)
    loop.run_until_complete(future)
    assert future.result() == 10

# Generated at 2022-06-12 13:15:43.872868
# Unit test for function chain_future
def test_chain_future():
    def check_future_state(future, state):
        if state == "finished":
            if not future.done():
                raise Exception("expected future to be done")
        elif state == "cancelled":
            if not future.cancelled():
                raise Exception("expected future to be cancelled")
        else:
            raise Exception("unknown state: %s" % state)

    async def test_chain_future():
        f = Future()
        f2 = Future()
        chain_future(f, f2)
        f.set_result(None)
        await f2

    asyncio.get_event_loop().run_until_complete(test_chain_future())

    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.cancel()

# Generated at 2022-06-12 13:15:47.093955
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-12 13:15:55.243285
# Unit test for function chain_future
def test_chain_future():
    import time
    import functools
    import concurrent.futures
    import tornado.ioloop
    import tornado.gen
    import tornado.testing
    import tornado.test.util

    @tornado.gen.coroutine
    def test_call(executor):
        # type: (concurrent.futures.Executor) -> None
        # Test a call from an executor to a Future.
        f = Future()
        executor.submit(lambda: f.set_result('foo'))
        result = yield f
        tornado.testing.assert_equal(result, 'foo')

    @tornado.gen.coroutine
    def test_future(executor):
        # type: (concurrent.futures.Executor) -> None
        # Test a call from an executor to a Future.
        f = Future()

# Generated at 2022-06-12 13:16:40.546075
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future1.set_result(42)
    chain_future(future1, future2)
    assert future2.result() == 42



# Generated at 2022-06-12 13:16:47.117628
# Unit test for function run_on_executor
def test_run_on_executor():
    ### test for method decorator
    class Foo(object):
        def __init__(self, ioloop):
            self.executor = futures.ThreadPoolExecutor(1)
            self.ioloop = ioloop

        def execute(self, x):
            return x

        @run_on_executor
        def bar(self, x):
            return self.execute(x)

        @run_on_executor(executor='_thread_pool')
        def baz(self, x):
            return self.execute(x)

    ioloop = IOLoop()
    foo = Foo(ioloop)

    # Test that the decorated method returns a future
    future = foo.bar(42)
    future.add_done_callback(lambda future: ioloop.stop())
    ioloop.start()
   

# Generated at 2022-06-12 13:16:51.243753
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    assert a.cancelled() is False
    future_set_result_unless_cancelled(a, "hello")
    assert a.result() == "hello"
    b = Future()
    b.cancel()
    assert b.cancelled() is True
    future_set_result_unless_cancelled(b, "hello")
    assert b.result() is None

# Generated at 2022-06-12 13:16:56.067598
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    async def f():
        # type: () -> None
        f1 = Future()  # type: Future
        f2 = Future()  # type: Future
        chain_future(f1, f2)
        f1.set_result(42)
        assert (await f2) == 42

    asyncio.get_event_loop().run_until_complete(f())



# Generated at 2022-06-12 13:17:05.281340
# Unit test for function run_on_executor
def test_run_on_executor():
    import types
    import unittest
    from concurrent.futures import ThreadPoolExecutor
    from tornado.ioloop import IOLoop
    from tornado import gen

    class TypeTest(unittest.TestCase):
        def test_basics(self):
            f = run_on_executor(lambda: 1)
            self.assertIsInstance(f, types.FunctionType)

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)
            self.io_loop.run_sync(self.io_loop.add_callback)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()


# Generated at 2022-06-12 13:17:10.249757
# Unit test for function chain_future
def test_chain_future():
    io_loop = None
    loop = None
    try:
        import asyncio
        loop = asyncio.get_event_loop()
    except ImportError:
        io_loop = IOLoop.instance()
    for arg in [loop, io_loop]:
        if arg is None:
            continue
        try:
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            assert b.result() == 42
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(Exception('test'))
            try:
                b.result()
            except:
                pass
            else:
                assert False
        except:
            assert False

# Generated at 2022-06-12 13:17:18.746157
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestException(Exception):
        pass

    class TestCase(AsyncTestCase):
        def test_regular(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_exception(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(TestException())
            self.assertTrue(f2.done())
            self.assertEqual

# Generated at 2022-06-12 13:17:25.922737
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def test():
        future = asyncio.Future()

        @asyncio.coroutine
        def set_exception_unless_cancelled_task():
            exception = Exception('test')
            future_set_exception_unless_cancelled(future, exception)
            if future.exception():
                if not isinstance(future.exception(), Exception):
                    raise Exception('exception is not Exception')
            else:
                raise Exception('exception is not set')

        asyncio.ensure_future(set_exception_unless_cancelled_task())
        future.cancel()
        await asyncio.sleep(0.1)

    asyncio.get_event_loop().run_until_complete(test())


# Generated at 2022-06-12 13:17:33.765249
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, "value")
    assert future.result() == "value"
    assert not future.cancelled()
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, "value")
    assert not future.done()
    assert future.cancelled()
    # Check that we don't get a warning
    future = Future()
    future.set_result("value")
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, "value")

# Generated at 2022-06-12 13:17:42.204436
# Unit test for function chain_future
def test_chain_future():
    _future = Future()
    f = Future()
    chain_future(_future, f)
    _future.set_result(42)
    assert f.result() == 42

    _future = futures.Future()
    f = Future()
    chain_future(_future, f)
    _future.set_result(42)
    assert f.result() == 42

    _future = Future()
    f = futures.Future()
    chain_future(_future, f)
    _future.set_result(42)
    assert f.result() == 42

    _future = futures.Future()
    f = futures.Future()
    chain_future(_future, f)
    _future.set_result(42)
    assert f.result() == 42

# Generated at 2022-06-12 13:19:18.017876
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            @gen.coroutine
            def main_future():
                a = Future()
                b = Future()
                chain_future(a, b)
                yield a
                self.assertTrue(b.done())
            self.io_loop.run_sync(main_future)

        @gen_test
        def test_chain_future_callback(self):
            a = Future()
            b = Future()

            def callback():
                self.stop()
                self.assertTrue(b.done())

            chain_future(a, b)
            future_add_done_callback(b, callback)
            a.set_result(None)
            self.wait

# Generated at 2022-06-12 13:19:25.833907
# Unit test for function run_on_executor
def test_run_on_executor():
    import mock

    # These are necessary so we can call the decorated method and to mock
    # the ThreadPoolExecutor, which has different attributes on py2/py3
    from tornado.concurrent import Future as AsyncFuture
    from concurrent.futures import Future as ConcFuture

    def simple_mock_executor(fn):
        return fn

    class SomeClass(object):
        executor = simple_mock_executor

        @run_on_executor
        def decorated(self):
            pass

    obj = SomeClass()

    obj.decorated()
    assert obj.decorated.__name__ == "decorated"
    assert obj.decorated.__module__ == "__main__"

    obj.decorated.__wrapped__()  # The undecorated version


# Generated at 2022-06-12 13:19:28.763141
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-12 13:19:35.232329
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tempfile
    import unittest
    import threading

    class TestCase(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()

            def run_in_executor(fn, *args, **kwargs):
                fn(*args, **kwargs)
            future.add_done_callback = tornado.ioloop.IOLoop.current().run_in_executor

            exc = Exception("foo")
            future_set_exception_unless_cancelled(future, exc)
            self.assertEqual(future.exception(), exc)

            future = Future()
            future.cancel()

# Generated at 2022-06-12 13:19:36.723873
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ZeroDivisionError)
    assert future.exception()



# Generated at 2022-06-12 13:19:44.909474
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    loop = IOLoop()

    io_loop_initialized = False

    class MainHandler(object):
        def __init__(self, io_loop) -> None:
            # Make sure io_loop is initialized as a global variable.
            # This is to ensure that it can be referenced from inside the
            # test_chain_future function which is defined within a class.
            global io_loop_initialized
            io_loop_initialized = True

            self.io_loop = io_loop
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def slow_function(self) -> int:
            return 1

        @run_on_executor
        def slow_function_with_args(self, arg) -> int:
            return arg

   