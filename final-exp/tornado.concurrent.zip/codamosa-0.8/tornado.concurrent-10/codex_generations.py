

# Generated at 2022-06-12 13:09:52.743532
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        future_set_result_unless_cancelled(future, 4)

    future = Future()
    future.add_done_callback(callback)
    future.set_result(3)
    assert future.result() == 4

# Generated at 2022-06-12 13:09:53.285657
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda: 0)

# Generated at 2022-06-12 13:09:55.521387
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()

    try:
        1/0
    except Exception as e:
        future_set_exception_unless_cancelled(future, e)

# Generated at 2022-06-12 13:10:06.410609
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    from unittest import mock

    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.testing

    try:
        AsyncIOMainLoop().install()
    except AssertionError:
        # can't install twice
        pass

    class Foo(object):
        def __init__(self):
            # type: () -> None
            self.executor = mock.Mock()

        @run_on_executor
        def func(self):
            # type: () -> int
            return 42

    f = Foo()
    f.func()
    assert mock.call(f.func, f) in f.executor.submit.mock_calls
    assert f.func().result() == 42

# Generated at 2022-06-12 13:10:13.310273
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f1 = Future()
    f2 = Future()
    f2.set_result(2)
    f3 = Future()
    f3.set_exception(RuntimeError('hello'))

    future_set_result_unless_cancelled(f1, 1)
    future_set_result_unless_cancelled(f2, 2)
    future_set_result_unless_cancelled(f3, 1)

    assert f1.result() == 1
    assert f2.result() == 2
    assert f3.exception().args[0] == 'hello'



# Generated at 2022-06-12 13:10:24.319090
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()

    # error cases 1: chain from result to exception
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(3)
    f2.set_exception(ZeroDivisionError)

    # test case 2: chain from exception to result
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError)
    f2.set_result(3)

    # test case 3: chain from exception to exception
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError)
    f2.set_

# Generated at 2022-06-12 13:10:33.341393
# Unit test for function chain_future
def test_chain_future():
    async def async_foo(x: int) -> int:
        return x

    @run_on_executor
    def foo(x: int) -> int:
        return x

    io_loop = IOLoop.current()

    f1 = foo(42)
    f2 = async_foo(42)

    f3 = f1.result()  # type: Future[int]
    f4 = f2.result()  # type: Future[int]

    assert f3.result() == 42
    assert f4.result() == 42

    f3 = Future()
    f4 = Future()

    chain_future(f3, f4)
    f3.set_result(42)

    assert f4.result() == 42

# Generated at 2022-06-12 13:10:35.492420
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-12 13:10:44.464975
# Unit test for function chain_future
def test_chain_future():
    def f1(arg, callback):
        callback(arg)

    def f2(callback, arg):
        callback(arg)

    async def f3(arg):
        return arg

    async def f4(arg):
        return await arg

    async def f5(arg):
        raise Exception(arg)

    async def f6(arg):
        return arg

    async def f7(arg):
        return await arg

    def f8(arg):
        raise Exception(arg)

    def f9(arg):
        return arg

    def f10(arg):
        return arg

    def f11(arg):
        raise Exception(arg)

    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

# Generated at 2022-06-12 13:10:52.325460
# Unit test for function chain_future
def test_chain_future():
    # Listen on a port so we have something to wait for without
    # hitting the network.
    import socket

    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    s.listen(1)

    def do_accept(fut: Future[Any]) -> None:
        fut.set_result(s.accept())

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    loop = IOLoop.current()
    loop.add_callback(do_accept, f1)
    loop.add_callback(do_accept, f2)

    try:
        loop.run_sync(lambda: None)
    except RuntimeError:
        import traceback
        traceback.print_exc()

# Generated at 2022-06-12 13:10:57.519412
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError('test'))

# Generated at 2022-06-12 13:11:04.977255
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    exc = DummyExecutor()

    # submit is a bound method to an instance of type DummyExecutor
    # it uses type annotation that are only supported by python 3.5+
    for args, kwargs in [
        (('a_func',), {}),
        ((lambda: None,), {}),
        ((object(),), {}),
        (('a_func', 'a_arg'), {}),
        (('a_func', 'a_arg'), {'a_kwarg': None}),
    ]:
        f = exc.submit(*args, **kwargs)
        assert isinstance(f, futures.Future)
        assert f.done()
        assert not f.cancelled()


# Generated at 2022-06-12 13:11:09.172703
# Unit test for function chain_future
def test_chain_future():
    def get_future() -> "Future[int]":
        return Future()

    f1 = Future()
    f2 = get_future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f2.set_result(24)
    assert f1.result() == 42

# Generated at 2022-06-12 13:11:16.043037
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()

    chain_future(f, f2)
    f.set_result("value")
    assert f2.result() == "value"

    f3 = Future()
    chain_future(f2, f3)
    assert f3.result() == "value"

    f4 = Future()
    f4.set_result("immediate")
    f5 = Future()
    chain_future(f4, f5)

    async def assert_raises_future_already_done():
        f5.result()
        assert False, "this should never happen"

    with pytest.raises(asyncio.InvalidStateError):
        await assert_raises_future_already_done()


# Generated at 2022-06-12 13:11:25.309182
# Unit test for function chain_future
def test_chain_future():
    def callback(future):
        try:
            future.result()
            test.append(True)
        except Exception:
            test.append(False)

    @gen.coroutine
    def work():
        a = gen.moment
        b = gen.engine().add_future(a, callback)
        raise gen.Return(b)

    test = []
    a = gen.Task(work())
    a.add_done_callback(lambda a: test.append(a.result()))
    b = a.result()
    b.set_result(None)
    gen.moment.yield_()

    test_utils.assert_true(all(test))

# Generated at 2022-06-12 13:11:30.256324
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)

    f.set_result(42)
    assert f2.result() == 42

    f3 = Future()
    f4 = Future()
    chain_future(f3, f4)
    f3.set_exception(RuntimeError("asdf"))
    assert f4.exception() is not None
    assert f4.exception().args == ("asdf",)

# Generated at 2022-06-12 13:11:33.824822
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    future_set_exc_info(future, sys.exc_info())
    assert future.cancelled()

# Generated at 2022-06-12 13:11:43.150749
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.platform.asyncio import AsyncIOMainLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):

            @asyncio.coroutine
            def coroutine_future(result, done_callback=None):
                future = Future()
                if done_callback:
                    # wrap the done callback to ensure that the future
                    # is marked as done before the callback is called.
                    future.add_done_callback(done_callback)
                yield from asyncio.sleep(0.01)
                future.set_result(result)
                return future

            @asyncio.coroutine
            def test_coroutine():
                fut = Future()

                def check_result(f):
                    self.assertEqual(f.result(), "foo")


# Generated at 2022-06-12 13:11:48.204404
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise Exception('foo')
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.done()
    assert future.result() is None
    assert future.exception() is not None


# Generated at 2022-06-12 13:11:56.250114
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f2.set_result(84)
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 84

    f1 = Future()
    f2 = Future()
    f2.set_exception(RuntimeError())
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    with pytest.raises(RuntimeError):
        f2.result()

    f1 = Future()
    f2 = Future()
   

# Generated at 2022-06-12 13:12:07.168222
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42
    c = Future()
    chain_future(a, c)
    assert c.result() == 42
    d = Future()
    a.set_result(24)
    chain_future(a, d)
    assert d.result() == 24
    # Chaining d -> b would introduce a cycle, so this is a no-op
    # that shouldn't raise an exception.
    chain_future(d, b)



# Generated at 2022-06-12 13:12:14.492085
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.ioloop

    t = tornado.ioloop.IOLoop.current().time()

    class A(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def foo(self):
            self.result = 42
            self.on_call()

    class B(object):
        def __init__(self, executor):
            self.executor = executor
            self.called = False

        def on_call(self):
            self.called = True

        @run_on_executor(executor='executor')
        def foo(self):
            self.result = 42
            self.on_call()


# Generated at 2022-06-12 13:12:22.924652
# Unit test for function chain_future
def test_chain_future():
    from concurrent.futures import Future  # type: ignore
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result("testing 123")
    assert g.result() == "testing 123"

    # Verify that if f raises an exception, g does too.
    f = Future()
    g = Future()
    chain_future(f, g)
    exc = RuntimeError()
    f.set_exception(exc)
    # test_utils.gen_test checks the exception text to make sure that the
    # stack trace is preserved. However, that mechanism doesn't work if
    # the exception is raised synchronously, so we raise it in a callback.
    def fail():
        raise g.exception()
    g.add_done_callback(fail)



# Generated at 2022-06-12 13:12:31.451331
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import bind_unused_port, AsyncTestCase

    class Test(AsyncTestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(1)
            self.io_loop.run_in_executor(self.executor, lambda: None)
            super(Test, self).setUp()

        def tearDown(self):
            self.executor.shutdown(wait=True)
            super(Test, self).tearDown()

        @run_on_executor
        def blocking_io(self):
            # This may be replaced with IOLoop.add_blocking_callback in
            # future versions of Tornado.
            sock, port = bind_unused_port()
            return port


# Generated at 2022-06-12 13:12:39.608235
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future3)
    chain_future(future2, future3)
    future1.set_result(1)
    future2.set_result(2)
    assert future3.result() == 1
    assert (not future1.cancelled())
    assert (not future2.cancelled())
    assert (not future3.cancelled())

    future4 = Future()
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future3)
    chain_future(future2, future3)
    chain_future(future4, future3)
    future1.set_result(1)
    future2.set_result(2)


# Generated at 2022-06-12 13:12:48.093096
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTests(AsyncTestCase):
        @gen_test
        def test_chain_future(self: Any) -> None:
            # type: () -> None
            result_future = Future()
            callback_future = Future()
            chain_future(result_future, callback_future)

            def callback(future: Future) -> None:
                self.assertEqual(future, result_future)
                callback_future.set_result(42)

            future_add_done_callback(result_future, callback)
            self.assertEqual(result_future.result(), 42)
            self.assertEqual(callback_future.result(), 42)

    # run directly, rather than via AsyncHTTPTestCase
    ChainFutureT

# Generated at 2022-06-12 13:12:52.763797
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42
    c = Future()
    chain_future(a, c)
    assert not c.done()
    a.set_exception(RuntimeError())
    assert c.exception().__class__ == RuntimeError

# Generated at 2022-06-12 13:13:01.781202
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import logging

    # Needs to be an old-style class for Python 2.x
    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

    @run_on_executor
    def some_blocking_calculation(self: Test) -> None:
        pass

    @run_on_executor(executor="other_executor")
    def some_other_blocking_calculation(self: Test) -> None:
        pass

    @run_on_executor
    def callback(self: Test, future: Future) -> None:
        pass

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

       

# Generated at 2022-06-12 13:13:06.635049
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("expected"))
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("expected"))
    # check that the exception actually gets logged
    assert future.exception() is None

# Generated at 2022-06-12 13:13:15.867433
# Unit test for function chain_future
def test_chain_future():
    class AsyncOther(object):
        def __init__(self, other_future):
            self.other_future = other_future

        def get_result(self):
            return self.other_future.result()

    class SyncOther(object):
        def __init__(self, other_future):
            self.other_future = other_future

        def get_result(self):
            return self.other_future.result()

    def task(future, other_future):
        future_set_result_unless_cancelled(future, other_future.get_result())

    def test_futures(async_other, sync_other):
        task_future, callback_future = (
            Future(),
            Future(),
        )
        task_future.result = lambda: None

# Generated at 2022-06-12 13:13:24.758162
# Unit test for function chain_future
def test_chain_future():
    def copy(future):
        assert future is a
        if b.done():
            return
        if a.exc_info():
            future_set_exc_info(b, a.exc_info())
        else:
            b.set_result(a.result())

    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42
    a = Future()
    b = Future()
    a.set_exception(RuntimeError("foo"))
    chain_future(a, b)
    assert b.exception()

# Generated at 2022-06-12 13:13:34.169825
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Test that when a future is cancelled before set_exception_unless_cancelled
    # is called, it does not set the exception.  This test expects the log
    # message to be printed and makes assertions about it
    loop = asyncio.new_event_loop()
    t = DummyException("test")
    f = loop.create_future()
    f.cancel()
    future_set_exc_info(f, (type(t), t, None))
    assert f.cancelled()
    assert f.exception() is None

    log = app_log.make_dict_of_lists_logger()
    future_set_exc_info(f, (type(t), t, None))
    assert len(log["error"]) == 1

# Generated at 2022-06-12 13:13:38.200057
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
   future = Future()
   future_set_result_unless_cancelled(future, 42)
   assert future.result() == 42
   future = Future()
   future.cancel()
   future_set_result_unless_cancelled(future, 42)
   assert future.cancelled()

# Generated at 2022-06-12 13:13:46.601128
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42

    c = Future()
    chain_future(b, c)
    c.set_result(24)
    assert a.result() == 42
    assert b.result() == 42
    assert c.result() == 24

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, c)
    chain_future(b, c)
    a.set_result(42)
    assert c.result() == 42
    b.set_result(24)
    assert c.result() == 24

# Generated at 2022-06-12 13:13:49.227071
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    data = 'Fake data in DummyExecutor'
    future = executor.submit(lambda: data) # type: ignore
    assert future.result() == data

# Generated at 2022-06-12 13:13:57.921065
# Unit test for function chain_future
def test_chain_future():
    def make_future() -> Future:
        future = Future()  # type: Future
        io_loop = IOLoop.current()

        def set_result():
            future.set_result(42)

        io_loop.add_timeout(io_loop.time() + 0.001, set_result)
        return future

    io_loop = IOLoop.current()
    f1 = make_future()
    f2 = make_future()

    f3 = Future()
    chain_future(f1, f3)
    chain_future(f2, f3)

    def f3_callback(f3: Future) -> None:
        # f3's result is the one from f2, not f1
        assert f3.result() == 42
        io_loop.stop()

    f3.add_done_

# Generated at 2022-06-12 13:14:08.311303
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.escape import to_unicode
    from tornado.httputil import HTTPHeaders
    from tornado.platform.asyncio import AsyncIOMainLoop

    def is_ioloop_called(method_name: str) -> bool:
        return method_name in AsyncIOMainLoop.instance()._called

    class Thing(object):
        executor = dummy_executor
        io_loop = None  # type: IOLoop

        def __init__(self, value: int, callback: Callable[[Any], None] = None) -> None:
            self.value = value
            self.callback = callback

        @run_on_executor
        def thing(self, foo: int, bar: int = 0) -> int:
            return self.value + foo + bar


# Generated at 2022-06-12 13:14:13.722758
# Unit test for function chain_future
def test_chain_future():

    f1: Future[str]
    f2: Future[str]

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result('test')
    assert f2.result() == 'test'

    f1 = Future()
    f2 = Future()
    chain_future(f2, f1)
    f1.set_result('test')
    assert f2.result() == 'test'

# Generated at 2022-06-12 13:14:15.831018
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_value = "test"
    fut = dummy_executor.submit(lambda: test_value)
    assert test_value == fut.result()


# Generated at 2022-06-12 13:14:17.879381
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # pragma: no cover
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("exception"))
    assert future.exception() is not None

# Generated at 2022-06-12 13:14:28.218291
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    with f:
        async def f():
            await asyncio.sleep(0.01)
            raise Exception('expected')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(f())



# Generated at 2022-06-12 13:14:37.884472
# Unit test for function chain_future
def test_chain_future():
    async def get_value(future: Future) -> int:
        return await future

    def fail(future: Future) -> None:
        future.set_exception(RuntimeError("error"))

    def make_future():
        future = Future()
        future_add_done_callback(future, fail)
        return future

    f1 = make_future()
    f2 = make_future()
    chain_future(f1, f2)
    assert f2.done()
    assert f2.exception() is not None
    assert isinstance(f2.exception(), RuntimeError)

    f1 = make_future()
    f2 = get_value(f1)
    chain_future(f1, f2)
    assert f2.done()
    assert f2.exception() is not None
    assert isinstance

# Generated at 2022-06-12 13:14:40.997256
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import os
    import time

    from tornado import gen
    from tornado.ioloop import IOLoop

    @gen.coroutine
    def f():
        res = yield dummy_executor.submit(os.getpid)
        assert res == os.getpid()

    IOLoop.current().run_sync(f)

# Generated at 2022-06-12 13:14:50.379871
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.iostream import IOStream
    from tornado.log import gen_log
    from tornado.tcpserver import TCPServer
    from tornado.netutil import bind_sockets

    class Server(TCPServer):

        def __init__(self):
            super().__init__()
            self._waiting = False

        def handle_stream(self, stream: IOStream, address: str) -> None:
            if self._waiting:
                # Two simultaneous connections; drop one.
                self._waiting = False
                stream.close()
                return
            self._waiting = True
            self._stream = stream
            self._stream.set_close_callback(self.on_disconnect)
            self._stream.write(b"HELLO\n")

# Generated at 2022-06-12 13:14:55.754911
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, Exception("foo"))
    tornado_exc = f.exception()
    assert str(tornado_exc) == "foo"
    assert type(tornado_exc) == RuntimeError
    f = asyncio.Future()

    def on_done(f):
        assert f.cancelled()
        assert f.exception() is None

    f.add_done_callback(on_done)
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("bar"))

# Generated at 2022-06-12 13:14:58.565943
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    class A(object):
        def __init__(self):
            self.executor = dummy_executor
            self.a = 1
        @run_on_executor()
        def add(self):
            return self.a+1
    a = A()
    f = a.add()
    f.result()



# Generated at 2022-06-12 13:15:02.465217
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()

    def a_done(_: "Future[_T]"):
        b.set_result(42)

    chain_future(a, b)
    a.add_done_callback(a_done)
    assert b.done()
    assert b.result() == 42

# Generated at 2022-06-12 13:15:11.281859
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.set_result(1)
    f2.result()
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.set_exception(RuntimeError())

    try:
        f2.result()
    except RuntimeError:
        pass
    else:
        raise AssertionError("should have raised RuntimeError")

    f1 = Future()
    f2 = Future()

    f2.set_result(2)

    chain_future(f1, f2)

    f1.set_result(1)

    assert f2.result() == 2

    f1 = Future()
    f2

# Generated at 2022-06-12 13:15:16.512804
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future() # type: Future
    exc = RuntimeError('test')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    exc = RuntimeError('test')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

# Generated at 2022-06-12 13:15:24.434778
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: no cover
    import unittest
    from concurrent.futures import ThreadPoolExecutor

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.thread_pool = ThreadPoolExecutor(1)
            # Note that we can't use the test case's own run_to_completion
            # function, because the decorator doesn't work on staticmethods.
            self.decorated = self.run_on_executor(self.run_to_completion)

        @staticmethod
        def run_to_completion(result: Future) -> None:
            # We're in a different thread, so we can't access self here.
            result.set_result(None)

        def run_decorated(self) -> Future:
            future = Future()
            self.dec

# Generated at 2022-06-12 13:15:44.195406
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

# Generated at 2022-06-12 13:15:50.451353
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future[int]
    future_set_exception_unless_cancelled(future, Exception('test 1'))
    assert future.exception() is not None
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    future_set_exception_unless_cancelled(future, Exception('test 2'))
    assert future.exception() is None
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception('test 3'))

# Generated at 2022-06-12 13:15:59.117824
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from .ioloop import IOLoop


    class A:
        executor = dummy_executor

        def __init__(self, result: int) -> None:
            self.result = result


    class B(A):
        executor = dummy_executor

        @run_on_executor
        def foo(self, arg1: str, arg2: str, **kwargs: str) -> int:
            assert self.result == arg1 + arg2
            assert list(sorted(kwargs.items())) == [("foo", "bar"), ("raz", "zab")]
            return self.result


# Generated at 2022-06-12 13:16:05.400766
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())

    future = Future()
    future_add_done_callback(future, lambda _: future_set_exception_unless_cancelled(future, RuntimeError()))
    future.cancel()

# Generated at 2022-06-12 13:16:10.319915
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    # f.set_result(42)  # Exception, f is cancelled
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


test_future_set_result_unless_cancelled()

# Generated at 2022-06-12 13:16:17.197493
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    loop = asyncio.new_event_loop()

    asyncio.set_event_loop(loop)

    # First test with a Future that has not been cancelled
    future = asyncio.Future()
    exc = OSError(1, 'err')
    future_set_exception_unless_cancelled(future, exc)

    @asyncio.coroutine
    def callback(future):
        assert future.exception() == exc
        loop.stop()

    future.add_done_callback(callback)
    loop.run_forever()

    # Second test with a Future that has been cancelled
    future = asyncio.Future()
    future.cancel()
    exc = OSError(1, 'err')
    future_set_exception_unless_cancelled(future, exc)


# Generated at 2022-06-12 13:16:24.584345
# Unit test for function chain_future
def test_chain_future():
    import time
    import threading
    import unittest

    from tornado.testing import AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test_chaining(self):
            f1 = Future()
            f2 = Future()
            f3 = Future()

            @run_on_executor
            def f1_setter(delta):
                time.sleep(delta)
                f1.set_result(42)

            executor.submit(f1_setter, 0.1)
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
            self.assertFalse(f3.done())
            chain_future(f1, f2)
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
           

# Generated at 2022-06-12 13:16:28.281465
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    async def coro_test():
        f = Future()
        future_set_result_unless_cancelled(f, "test")
        assert f.result() == "test"

        f = Future()
        f.cancel()
        future_set_result_unless_cancelled(f, "test")
        assert f.result() is None

    asyncio.run(coro_test())

# Generated at 2022-06-12 13:16:35.987045
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def get_result(return_value: _T) -> _T:
        return return_value

    def get_result_with_exception() -> _T:
        raise NotImplementedError()

    loop = asyncio.get_event_loop()

    future_1 = get_result(1234)
    future_2 = get_result_with_exception()

    future_3 = Future()
    failure_future_3 = False

    future_4 = Future()
    failure_future_4 = False

    loop.run_until_complete(asyncio.gather(
        future_1, future_2, future_3, future_4
    ))

    if future_1.result() != 1234:
        raise Exception("Wrong result in future_1")


# Generated at 2022-06-12 13:16:41.546197
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Create future.
    future = Future()
    # Create exception.
    exc = ValueError()
    # Set exception.
    future_set_exception_unless_cancelled(future, exc)
    # Get exception.
    assert(future.exception() == exc)
    # Cancel future.
    future.cancel()
    # Set exception again.
    future_set_exception_unless_cancelled(future, exc)
    # Get exception.
    assert(future.exception() is None)
    # Get exception.
    assert(future.exception() == exc)

# Generated at 2022-06-12 13:17:19.435168
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.done()
    assert f.exception() is not None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.exception() is None
    assert f.done()

    f = Future()
    f.set_exception(Exception())
    future_set_exception_unless_cancelled(f, Exception())
    assert f.done()
    assert f.exception() is not None


# Not a unit test, but exercise some code paths

# Generated at 2022-06-12 13:17:23.023535
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    def cb(fut):
        fut.result()
        assert f1.done()

    f2.add_done_callback(cb)

    f1.set_result(42)



# Generated at 2022-06-12 13:17:31.503135
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    async def f():
        pass

    class Test(AsyncTestCase):
        def test_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            # Let's check how f1 and f2 behave together
            f1.set_result(None)
            self.assertTrue(f2.done())
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.done())
            self.assertTrue(f2.exception())
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-12 13:17:40.532450
# Unit test for function chain_future
def test_chain_future():
    import time

    def f(x: int) -> int:
        time.sleep(0.01)
        return x * 3

    def f2(x: int) -> str:
        time.sleep(0.01)
        return "%d * 3" % x

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_result(1)
    f2.result()
    assert f2.result() == 3
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    f1.set_exception(RuntimeError("error"))
    try:
        f2.result()
        raise Exception("should not get here")
    except RuntimeError:
        pass

    f1 = Future()
    f

# Generated at 2022-06-12 13:17:50.041642
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    assert not f2.done()
    assert f2.set_result(None) is None
    assert f2.done()

    # The first future has its result set, the second one is already done.
    chain_future(f, f2)
    assert f2.done()

    f = Future()
    f2 = Future()
    val = object()
    assert f.set_result(val) is None
    assert f.done()
    chain_future(f, f2)
    assert f2.done()
    assert f.result() is val
    assert f2.result() is val

    f = Future()
    f2 = Future()
    val = object()
    assert f.set_exception(val) is None
    assert f.done()
   

# Generated at 2022-06-12 13:17:57.698101
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    from tornado.testing import gen_test, AsyncTestCase

    class MyTestCase(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            super(MyTestCase, self).__init__(*args, **kwargs)
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor()
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            # type: (str, str, Optional[str], Optional[str]) -> str
            return arg1 + arg2 + (kwarg1 or "") + (kwarg2 or "")

        @gen_test
        async def test_run_on_executor(self):
            # type: () -> None
            result

# Generated at 2022-06-12 13:18:05.627145
# Unit test for function chain_future
def test_chain_future():
    @run_on_executor
    def foo():
        return 1

    @run_on_executor
    def bar(arg):
        return arg + 1

    @run_on_executor
    def error():
        raise Exception("testing")

    loop = asyncio.get_event_loop()

    def on_done(future: Future) -> None:
        assert future.result() == 2
        loop.stop()

    future = foo()
    chain_future(future, bar(future))
    future.add_done_callback(on_done)

    with pytest.raises(Exception):
        chain_future(foo(), error())

    loop.run_forever()

# Generated at 2022-06-12 13:18:13.007334
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.util import raise_exc_info
    from concurrent.futures import Future
    from asyncio import Future, Event
    import sys
    import logging

    def test_DummyExecutor_submit():
        future = dummy_executor.submit(lambda: 42)
        assert not future.done()

        def callback(f: Future) -> None:
            assert f.result() == 42
            got_result.set()

        got_result = Event()
        future_add_done_callback(future, callback)
        IOLoop.current().add_future(future, lambda f: f.result())
        if not got_result.is_set():
            got_result.wait()



# Generated at 2022-06-12 13:18:21.082245
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    assert not future1.done()
    assert not future2.done()
    chain_future(future1, future2)
    assert not future1.done()
    assert not future2.done()
    future1.set_result("test")
    assert future1.done()
    assert future2.done()
    assert future2.result() == "test"
    future1 = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    chain_future(future1, future2)
    future1.set_exception(RuntimeError("test error"))
    assert future1.done()
    assert future2.done()
    assert not future2.result()

# Generated at 2022-06-12 13:18:29.686548
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    def func(arg1, arg2='default', *args, **kwargs): # type: ignore
        # type: (Any, Any, *Any, **Any) -> Any
        """docstring for func"""
        return arg1 + arg2
    executor = DummyExecutor()
    future = executor.submit(func, 1, 2)
    assert str(future) == '<Future at 0x7f4eed4c4eb8 state=finished returned int>'
    assert future.result() == 3
    assert future.cancelled() == False
    assert future.running() == False
    assert future.done() == True
    print(future.result())
    print(future.cancelled())
    print(future.running())
    print(future.done())
    assert str(future)

# Generated at 2022-06-12 13:19:29.680433
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class MyException(Exception):
        pass

    future = Future()
    future_set_exception_unless_cancelled(future, MyException('test'))

    def _future_set_exception_unless_cancelled_raise_exc():
        future_set_exception_unless_cancelled(future, MyException('test'))

    e = MyException('test2')
    future_set_exception_unless_cancelled(future, e)
    future.cancel()
    future_set_exception_unless_cancelled(future, MyException('test3'))

# Generated at 2022-06-12 13:19:35.883834
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    def f(x: int, y: int, z: int) -> int:
        return x + y + z

    class MyClass:
        executor = dummy_executor
        @run_on_executor
        def f(self, x: int, y: int, z: int) -> int:
            return f(x, y, z)
        @run_on_executor()
        def g(self, x: int, y: int, z: int) -> int:
            return f(x, y, z)
        @run_on_executor(executor="_executor")
        def h(self, x: int, y: int, z: int) -> int:
            return f(x, y, z)

    # Dummy executor always runs synchronously, so

# Generated at 2022-06-12 13:19:38.607463
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError("foo"))
    assert f.exception() is not None
    assert f.exception().args == ("foo",)



# Generated at 2022-06-12 13:19:41.868448
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    chain_future(g, g)
    f.set_result(42)
    assert f.result() == 42
    assert g.result() == 42
