

# Generated at 2022-06-24 08:17:36.810384
# Unit test for function run_on_executor
def test_run_on_executor():
    # This is a very simple test; it doesn't do anything terribly
    # rigorous, just verifies that the decorator and the callback
    # produce results.
    #
    # A more thorough implementation would need to verify that the
    # function is actually called in a separate thread, but this gets
    # tricky to implement correctly (see #3674).

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self, x: int, y: int) -> int:
            return x + y

        @run_on_executor()
        def bar(self, x: str, y: str) -> str:
            return x + y

    foo = Foo()
    future1 = foo.foo(1, 2)

# Generated at 2022-06-24 08:17:44.268540
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future[int]
    assert not future.done()
    future_set_result_unless_cancelled(future, 3)
    assert future.done()
    assert future.result() == 3
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()

# Generated at 2022-06-24 08:17:48.976497
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future_obj = Future()
    future_obj.cancel()
    future_set_result_unless_cancelled(future_obj, 'result')
    assert future_obj.cancelled()
    assert not future_obj.done()
    assert future_obj.result() is None



# Generated at 2022-06-24 08:17:54.933100
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    future = Future()
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)
        exc2 = future.exception()
        assert exc_info[1] is exc2
    assert future.exception()



# Generated at 2022-06-24 08:18:06.655116
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.testing
    import tornado.test.mock_future
    import unittest

    # test on a regular future
    f = Future()
    f.set_exception(RuntimeError("exception is set"))

    # test exception is set if future is not cancelled
    future_set_exception_unless_cancelled(f, ValueError("exception is set"))
    with tornado.testing.gen_test(timeout=10) as test:
        with unittest.mock.patch("tornado.log.app_log.error") as mock_method:
            yield f
            mock_method.assert_not_called()

    # test future is cancelled before exception is set
    f = Future()
    f.cancel()

# Generated at 2022-06-24 08:18:11.858938
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        @gen_test
        def test_future_set_exc_info(self):
            fut = Future()
            try:
                1 / 0
            except ZeroDivisionError:
                future_set_exc_info(fut, sys.exc_info())
                with self.assertRaises(ZeroDivisionError):
                    yield fut

# Generated at 2022-06-24 08:18:23.548392
# Unit test for function chain_future
def test_chain_future():
    import mock
    import unittest

    def fn(arg, arg2):
        return arg + arg2

    class Test(unittest.TestCase):
        @mock.patch("tornado.concurrent.Future")
        @mock.patch("tornado.concurrent.futures.Future")
        def test(self, MockFuture, MockFuturesFuture):
            a = MockFuturesFuture()
            a.done.return_value = True
            a.result.return_value = 42
            b = MockFuture()
            chain_future(a, b)
            b.set_result.assert_called_with(42)

            a.done.return_value = False
            a.result.return_value = 42
            b = MockFuture()
            chain_future(a, b)
            b.set

# Generated at 2022-06-24 08:18:33.428423
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    def f1(arg, callback):
        # Simulate the asynchronous operation of a thread pool
        # by passing through IOLoop
        tornado.ioloop.IOLoop.instance().add_callback(
            lambda: callback(arg + 1)
        )


    class FutureTest(tornado.testing.AsyncTestCase):
        def async_callback(self, future, callback):
            self.stop()
            callback(future)

        def test_chain_future(self):
            future1 = concurrent.futures.Future()
            future2 = Future()
            chain_future(future1, future2)
            self.assertFalse(future2.done())

            f1(1, functools.partial(self.async_callback, future1))
            self.wait()
           

# Generated at 2022-06-24 08:18:38.274681
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: no cover
    # type: () -> None
    """Test future_add_done_callback"""
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    Loop = []  # type: List[IOLoop]

    def f(loop):
        def callback(future):
            future.result()
            # Schedule a new callback to run after the ioloop
            # iterations are complete.
            IOLoop.current().add_callback(check_loop, loop)

        future = Future()
        Loop.append(loop)
        future_add_done_callback(future, callback)
        future.set_result(None)

    def check_loop(loop):
        assert Loop[0] is loop

    loop = IOLoop()
    loop.add_callback(f, loop)
    loop

# Generated at 2022-06-24 08:18:42.042067
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))
    f = Future()
    future_set_exception_unless_cancelled(f, Exception("test"))



# Generated at 2022-06-24 08:18:44.292627
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    assert d.submit(lambda x: x,10) == 10

# Generated at 2022-06-24 08:18:46.370216
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # noqa: F811
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("cancel"))

# Generated at 2022-06-24 08:18:47.005311
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:18:48.325145
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError('test')
    assert str(e) == 'test', 'str(ReturnValueIgnoredError) is not "test"'

# Generated at 2022-06-24 08:18:49.621899
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass  # Just make sure we can call it

# Generated at 2022-06-24 08:18:53.709171
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    print(__name__)
    def test_fn(x: int, y: int) -> int:
        return x+y
    result = dummy_executor.submit(test_fn, 1, 2)
    print(result.done())
    print(result.result())


# Generated at 2022-06-24 08:18:55.659296
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:19:06.453797
# Unit test for function run_on_executor
def test_run_on_executor():
    import contextlib
    from unittest.mock import patch
    from concurrent.futures import Future, ThreadPoolExecutor

    executor = ThreadPoolExecutor()
    io_loop = patch('tornado.ioloop.IOLoop.current').start()

    @run_on_executor(executor='_executor')
    def slow(self, x: int) -> int:
        return x

    class X:
        _executor = executor

    x = X()
    f = slow(x, 1)
    assert isinstance(f, Future)

    with contextlib.ExitStack() as stack:
        stack.enter_context(patch.object(x, '_executor', None))
        f = slow(x, 1)
        assert isinstance(f, Future)

    f = slow(x, 1)

# Generated at 2022-06-24 08:19:17.170140
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.ioloop

    # Type annotations here are mostly for doctests; mypy's version
    # inference is not good enough to infer the type signature of the
    # decorated method.
    class Foo(object):
        executor = unittest.mock.NonCallableMock()  # type: Executor

        @run_on_executor
        def run(self, arg: int) -> int:
            return arg

    obj = Foo()
    obj.run(42)
    obj.executor.submit.assert_called_once_with(
        obj.run, obj, 42
    )  # type: ignore

    # Test keyword arguments
    obj = Foo()
    obj.executor = unittest.mock.NonCallableMock()
    obj.other = unittest

# Generated at 2022-06-24 08:19:19.483694
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fn = lambda: "hello"
    assert dummy_executor.submit(fn).result() == "hello"

# Generated at 2022-06-24 08:19:26.479220
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is exc
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    assert f.exception() is None
    try:
        raise exc
    except Exception:
        exc_info = sys.exc_info()
    f = Future()
    f.cancel()
    future_set_exc_info(f, exc_info)
    assert f.exception() is None

# Generated at 2022-06-24 08:19:36.211897
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from tornado.log import app_log
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine, sleep, Return
    import unittest

    def foo():
        pass

    # 1st test case
    @coroutine
    def test_1():
        yield sleep(0.1)
        f = run_on_executor(foo)
        a = f(self)
        yield a
        assert a.done() == True
        try:
            assert a.exception() == None
            assert a.result() == None
        except Exception:
            app_log.info(a.exception())
        raise Return(0)

    # 2nd test case

# Generated at 2022-06-24 08:19:42.809708
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado import gen
    from tornado import ioloop
    from tornado import stack_context
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    if not hasattr(asyncio.get_event_loop(), "set_exception"):
        # It's not clear what policy to use with this test on Python 3.7,
        # where asyncio.get_event_loop() simply returns a global default
        # policy instead of raising an error. Skip the test instead.
        return

    ioloop.set_event_loop_policy(AnyThreadEventLoopPolicy())
    executor = futures.ThreadPoolExecutor(1)


# Generated at 2022-06-24 08:19:51.539820
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_result(1)
    assert not f.cancelled()
    f.set_exception(Exception())
    assert f.exception()
    f = Future()
    f.set_result(1)
    assert not f.cancelled()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.exception()
    f = Future()
    f.set_result(1)
    assert not f.cancelled()
    f.cancel()
    assert f.cancelled()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled()

# Generated at 2022-06-24 08:19:54.928692
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    def set_exception_unless_cancelled_test():
        future_set_exception_unless_cancelled(future, Exception("error"))
        assert future.exception() is not None
        assert future.exception().args == ("error",)

    set_exception_unless_cancelled_test()
    future.cancel()
    set_exception_unless_cancelled_test()

# Generated at 2022-06-24 08:19:57.813563
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    dummy_executor.submit(lambda: 1)


# Generated at 2022-06-24 08:19:59.668102
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        return

# Generated at 2022-06-24 08:20:10.467751
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test, AsyncTestCase

    class TestCase(AsyncTestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = asyncio.Future()  # type: Future
            future_set_exception_unless_cancelled(future, ValueError())
            self.assertTrue(future.done())
            self.assertRaises(ValueError, future.result)
            future_set_exception_unless_cancelled(future, ValueError())
            self.assertRaises(ValueError, future.result)

    try:
        asyncio.run(gen_test(TestCase("test_future_set_exception_unless_cancelled")))
    except AttributeError:
        # coroutine function not callable on 3.5
        pass

# Generated at 2022-06-24 08:20:12.112593
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("foo"))

# Generated at 2022-06-24 08:20:17.498399
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.done()



# Generated at 2022-06-24 08:20:27.506198
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import concurrent.futures
    import unittest
    import tornado.platform.asyncio

    async def async_test():
        tornado.platform.asyncio.AsyncIOMainLoop().install()

        @run_on_executor
        def slow_func(a, b, c):
            return a * 10 + b * 20 + c * 30

        futures = [slow_func(1, 2, 3), slow_func(1, 2, 3)]
        await asyncio.gather(*futures)
        assert futures[1].result() == 156

    async def test_return_future():
        # legacy @return_future; use functools.wraps instead
        @return_future
        def func(arg, callback):
            callback(arg)

        result = await func(42)

# Generated at 2022-06-24 08:20:29.684891
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def a(c):
        return 1+c
    asyn = dummy_executor.submit(a,1)
    assert asyn.result() == 2

# Generated at 2022-06-24 08:20:32.158253
# Unit test for function is_future
def test_is_future():
    x = asyncio.Future()  # type: Future
    assert is_future(x)
    assert is_future(Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:20:37.276210
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exc = ValueError()
    future = Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-24 08:20:48.776053
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import unittest.mock

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(unittest.TestCase):
        def test_run_on_executor(self):
            @run_on_executor
            def _blocking_func(x: int, y: int) -> int:
                return x + y

            class Object(object):
                _thread_pool = dummy_executor

                @gen_test
                async def test_add(self):
                    result = await _blocking_func(self, 1, 2)
                    self.assertEqual(result, 3)

            obj = Object()
            IOLoop.current().run_sync(obj.test_add)

    unittest.main()


# Unit

# Generated at 2022-06-24 08:20:55.680197
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.testing import AsyncTestCase
    import functools
    import random

    class DummyExecutorTestCase(AsyncTestCase):
        def test_submit(self):

            def blocking_task():
                return random.random()
            future1 = dummy_executor.submit(blocking_task)

            def callback(future):
                result = future.result()
                self.assertIsInstance(result, float)
                self.stop()
            future1.add_done_callback(callback)
            self.wait()

    DummyExecutorTestCase().test_submit()

# Generated at 2022-06-24 08:20:59.552075
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42



# Generated at 2022-06-24 08:21:00.448316
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:21:04.149840
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import logging
    import sys
    sys.path.append('../')
    logger = logging.getLogger()

    f = dummy_executor.submit(lambda x: x, 'hello')
    logger.info(f.result())

# Generated at 2022-06-24 08:21:05.817256
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(asyncio.Future())  # type: ignore
    assert is_future(concurrent.futures.Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:21:08.701413
# Unit test for function is_future
def test_is_future():
    from tornado.concurrent import Future
    from concurrent.futures import Future as Future2

    future = Future()
    assert is_future(future)  # type: ignore
    assert is_future(Future2())
    assert not is_future(object())



# Generated at 2022-06-24 08:21:20.637359
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_result(42)
    # Make sure there are no exceptions (in callbacks)
    future3.result()
    future3.exception()

    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_exception(ZeroDivisionError())
    # Make sure there are no exceptions (in callbacks)
    future3.result()
    future3.exception()

    # Make sure exceptions in callbacks are reported
    # (add_done

# Generated at 2022-06-24 08:21:22.228696
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:21:25.219429
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, tornado.web.HTTPError(503))

# Generated at 2022-06-24 08:21:37.404207
# Unit test for function chain_future
def test_chain_future():
    from tornado.http1connection import _FakeSocket
    from tornado.ioloop import IOLoop
    from tornado.tcpserver import TCPServer

    io_loop = IOLoop()
    io_loop.make_current()

# Generated at 2022-06-24 08:21:43.669757
# Unit test for function chain_future
def test_chain_future():
    def check_result(fut, result):
        print(result)

    def finish_future(fut):
        print("Finished!")
        fut.set_result(True)

    def error_future(fut):
        raise Exception("Failing")

    fut1 = Future()
    fut2 = Future()
    assert fut1 is not fut2
    chain_future(fut1, fut2)
    fut1.add_done_callback(check_result)
    fut2.add_done_callback(check_result)
    IOLoop.current().add_callback(functools.partial(finish_future, fut1))
    IOLoop.current().add_callback(functools.partial(error_future, fut1))
    return fut2

# Generated at 2022-06-24 08:21:48.903068
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn(*args,**kwargs):
        return args[0] + 1

    class A:
        executor = dummy_executor

    a = A()
    future = a.executor.submit(fn,1)
    assert future.result() == 2

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:21:58.027504
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest
    import asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    AsyncIOMainLoop().install()
    io_loop = asyncio.get_event_loop()

    class MyException(Exception):
        pass


    class TestFuture(AsyncTestCase):
        def test_future_set_exc_info(self):
            future = asyncio.Future()
            try:
                raise MyException()
            except MyException:
                future_set_exc_info(future, sys.exc_info())
            future = io_loop.run_until_complete(future)
            self.assertTrue(future.exception())
            self.assertIsInstance(future.exception(), MyException)

    unittest.main()

# Generated at 2022-06-24 08:21:59.354473
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError('')

# Generated at 2022-06-24 08:22:06.142822
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42
    b.cancel()
    assert b.cancelled()
    a.set_result(43)
    assert b.result() == 42
    b.cancel()
    assert b.cancelled()
    a.set_exception(ValueError("bad"))
    assert b.exception() is not None
    assert b.exception().args == ("bad",)
    b.cancel()
    assert b.cancelled()
    a.set_exception(ValueError("good"))
    assert b.exception().args == ("bad",)
    b.cancel()
    assert b.cancelled()


# Generated at 2022-06-24 08:22:07.954520
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    pass

# Generated at 2022-06-24 08:22:13.119877
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = futures.Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

# Generated at 2022-06-24 08:22:22.388702
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    assert f.done() == False, 'future not done'
    assert f.cancelled() == False, 'future not cancelled'
    future_set_result_unless_cancelled(f, "done")
    assert f.done() == True, 'future done'
    assert f.result() == 'done', 'future result'
    f = Future()
    f.cancel()
    assert f.done() == False, 'future not done'
    assert f.cancelled() == True, 'future cancelled'
    future_set_result_unless_cancelled(f, "done")
    assert f.done() == False, 'future not done'
    assert f.cancelled() == True, 'future cancelled'

# Generated at 2022-06-24 08:22:28.212898
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'foo')
    assert not future.cancelled()
    assert future.exception() == asyncio.CancelledError

    with pytest.raises(asyncio.InvalidStateError):
        future.set_result('foo')

# Generated at 2022-06-24 08:22:30.769722
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        pass

    future_add_done_callback(Future(), callback)
    future_add_done_callback(futures.Future(), callback)



# Generated at 2022-06-24 08:22:32.795607
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError(1, 2, 3)
    assert isinstance(e, Exception)
    assert e.args == (1, 2, 3)

# Generated at 2022-06-24 08:22:35.827114
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    executor = DummyExecutor()
    assert isinstance(executor, futures.Executor)
    assert isinstance(executor, object)


# Generated at 2022-06-24 08:22:43.172742
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    """Simple check that future_add_done_callback works.
    """
    futures = [Future(),
               futures.Future()]
    def callback(future):
        callback.calls += 1
    callback.calls = 0
    for f in futures:
        future_add_done_callback(f, callback)

    for f in futures:
        assert callback.calls == 0
        f.set_result('foo')
        assert callback.calls == 1
    assert callback.calls == 2

# Generated at 2022-06-24 08:22:51.896864
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    async def test_async_future():
        # type: () -> None
        f1 = Future()  # type: Future
        f2 = Future()  # type: Future
        chain_future(f1, f2)
        assert not f2.done()
        f1.set_result("blah")
        await f2
        assert f2.result() == "blah"

    asyncio.get_event_loop().run_until_complete(test_async_future())

    def test_non_async_future():
        # type: () -> None
        f1 = futures.Future()  # type: futures.Future
        f2 = futures.Future()  # type: futures.Future
        chain_future(f1, f2)
        assert not f2.done()


# Generated at 2022-06-24 08:22:53.761310
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    content = 'xxx'
    f = dummy_executor.submit(lambda: content)
    assert f.result() == content


# Generated at 2022-06-24 08:23:01.673361
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    e = DummyExecutor()
    f = e.submit(lambda: 5)
    assert f.result() == 5
    assert e.submit(lambda: 2 + 2).result() == 4
    assert e.submit(lambda x: x + 2, 5).result() == 7
    assert e.submit(lambda x, y: x * y, 2, 5).result() == 10
    f = e.submit(lambda: 1 / 0)
    try:
        f.result()
        assert False
    except Exception as e:
        assert "ZeroDivisionError" in str(e)

    try:
        futures.wait([e.submit(lambda: 1 / 0)])
        assert False
    except Exception as e:
        assert "ZeroDivisionError" in str(e)


# Generated at 2022-06-24 08:23:06.697445
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f = loop.create_future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = loop.create_future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

# Generated at 2022-06-24 08:23:15.283639
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyAbstractClass(object):
        def __init__(self, x):
            self.x = x
            self.executor = dummy_executor

        @run_on_executor
        def func(self, y):
            return self.x * y

    class MyClass(MyAbstractClass):
        pass

    class MyClass2(MyAbstractClass):
        executor = '_thread_pool'

    class MyClass3(MyClass2):
        @run_on_executor(executor='executor')
        def double(self, z):
            return z * 2

    a = MyAbstractClass(10)
    b = MyClass(20)
    c = MyClass2(30)
    d = MyClass3(40)

    # All of these futures should have the same value

# Generated at 2022-06-24 08:23:19.389095
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop.current()
    future1 = Future()
    future2 = Future()

    chain_future(future1, future2)

    io_loop.add_timeout(timedelta(seconds=0), functools.partial(future1.set_result, 42))
    io_loop.add_timeout(timedelta(seconds=1), io_loop.stop)

    yield future1
    self.assertTrue(future1.done())
    self.assertTrue(future2.done())
    self.assertEqual(future2.result(), 42)



# Generated at 2022-06-24 08:23:23.818310
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None

    future1 = DummyExecutor().submit(lambda x: x*2, 5)
    assert future1.result() == 10

    future2 = DummyExecutor().submit(lambda x: x+10, 7)
    assert future2.result() == 17

test_DummyExecutor()

# Generated at 2022-06-24 08:23:33.504792
# Unit test for function run_on_executor
def test_run_on_executor():
    import mock

    thread_pool = mock.Mock()

    class FakeFuture:
        def __init__(self, result):
            self._result = result

        def add_done_callback(self, callback):
            callback(self)

        def result(self):
            return self._result

    class MyClass:
        executor = thread_pool

        @run_on_executor
        def func(self):
            return 5

        def test(self):
            return self.func()

    myobj = MyClass()
    thread_pool.submit.return_value = FakeFuture(5)
    assert myobj.test() == 5

    myobj.func.__self__ = "fake"
    with pytest.raises(AttributeError):
        myobj.test()

# Generated at 2022-06-24 08:23:35.383807
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:23:36.869136
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("testing...")

# Generated at 2022-06-24 08:23:41.574825
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def _cancel_test(future: Future) -> None:
        future_set_exception_unless_cancelled(future, test_exception)

    future = Future()
    test_exception = Exception()
    future_add_done_callback(future, _cancel_test)
    future.cancel()

# Generated at 2022-06-24 08:23:52.020560
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class Test(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def non_coroutine(self):
            return 1

        @run_on_executor
        def future(self):
            future = Future()
            future_set_result_unless_cancelled(future, 2)
            return future

        @run_on_executor
        def exception(self):
            raise Exception("hello")

        @run_on_executor
        def non_future(self):
            return 3

        @run_on_executor(executor="_executor")
        def custom_executor(self):
            return 4


# Generated at 2022-06-24 08:23:54.387344
# Unit test for function is_future
def test_is_future():
    class _TornadoFuture(Future):
        pass

    assert is_future(Future())
    assert is_future(_TornadoFuture())
    assert not is_future(object())
    assert not is_future(None)

# Generated at 2022-06-24 08:24:02.780319
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    f1 = executor.submit(lambda x:x**x, 5)
    f2 = executor.submit(lambda x:x**x, 3)
    f3 = executor.submit(lambda x,y:x**y, 5, 3)
    f4 = executor.submit(lambda x,y:x**y, 3, 5)
    f5 = executor.submit(lambda x,y:x**y, 2, 5)
    print(f1.result(), f2.result(), f3.result(), f4.result(), f5.result())

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:24:03.430866
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    ab = DummyExecutor()
    return ab

# Generated at 2022-06-24 08:24:06.537449
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x * 2, 2)
    assert future.result() == 4



# Generated at 2022-06-24 08:24:12.509395
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        if sys.version_info > (3,):
            raise ReturnValueIgnoredError("foo", "bar")
        raise ReturnValueIgnoredError("foo")
    except ReturnValueIgnoredError as e:
        assert str(e) == "foo"
        if sys.version_info > (3,):
            assert e.args == ("foo", "bar")
        else:
            assert e.args == ("foo",)

# Generated at 2022-06-24 08:24:23.084954
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    result = []

    def callback(f):
        result.append(f.result())
    future.set_result(42)
    future_add_done_callback(future, callback)
    assert result == [42]
    future_add_done_callback(future, callback)
    assert result == [42, 42]
    future.set_result(17)
    assert result == [42, 42]

    future = Future()
    future_add_done_callback(future, callback)
    assert result == [42, 42]
    future.set_result(17)
    assert result == [42, 42, 17]



# Generated at 2022-06-24 08:24:28.415326
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)



# Generated at 2022-06-24 08:24:29.439685
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:24:33.551593
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    input = [1, 2, 3, 4]
    output = [1, 4, 9, 16]
    executor = DummyExecutor()
    future = executor.submit(test_DummyExecutor_submit_callback, input)
    assert future.result() == output


# Generated at 2022-06-24 08:24:34.314117
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:24:38.243452
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    assert not f.cancelled()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42

    g = Future()
    g.cancel()
    assert g.cancelled()
    future_set_result_unless_cancelled(g, 42)
    assert not g.done()

# Generated at 2022-06-24 08:24:40.853117
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    global dummy_executor
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:24:53.906440
# Unit test for function chain_future
def test_chain_future():
    b = Future()
    a = Future()
    chain_future(a, b)

    a.set_result('foo')
    assert b.result() == 'foo'

    a = Future()
    b = Future()
    chain_future(a, b)

    if sys.version_info >= (3, 5):

        # Python 3.5+
        @typing.no_type_check
        def copy(future: Future) -> None:
            assert future is a
            b.set_result(a.exception())

    else:
        # Python 3.4
        def copy(future: Future) -> None:
            future.exception()

    a.set_exception(ValueError())
    assert b.exception() is a.exception()

    a = Future()
    b = Future()
    chain

# Generated at 2022-06-24 08:24:55.257047
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x, 1)
    assert(future.result() == 1)


# Generated at 2022-06-24 08:24:56.355579
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:25:00.891250
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest
    import unittest.mock
    import sys

    class TestException(Exception):
        pass

    class Future(Future):
        def set_exception(self, exc: BaseException) -> None:
            self._exception = exc

    def _call_traceback(
        self: unittest.TestCase, future: Future, exc_info: Tuple[type, BaseException, type]
    ) -> None:
        future_set_exc_info(future, exc_info)
        error_message = "Exception raised outside coroutine"
        unittest.mock.call(
            error_message, exc_info=(TestException, TestException(), mock.ANY,)
        )

    class CallbacksTest(unittest.TestCase):
        def setUp(self) -> None:
            self.future

# Generated at 2022-06-24 08:25:08.943390
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()  # type: Future[None]
    exc = Exception()
    future_set_exc_info(future, sys.exc_info())
    assert future.exc_info()[1] is exc
    future = Future()
    future_set_exc_info(future, (None, None, None))
    assert future.exc_info()[1] is None
    # future_set_exc_info should work even on an already-set future
    future = Future()
    future.set_result(None)
    future_set_exc_info(future, sys.exc_info())
    assert future.exc_info()[1] is exc

# Generated at 2022-06-24 08:25:16.834658
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert isinstance(future, Future)
    assert not future.done()
    future_set_result_unless_cancelled(future, 3)
    assert future.done()
    assert future.result() == 3

    future1 = Future()
    assert isinstance(future1, Future)
    assert not future1.done()
    future1.cancel()
    future_set_result_unless_cancelled(future1, 3)
    assert future1.cancelled() # future1 got cancelled previously.
    assert not future1.done()

# Generated at 2022-06-24 08:25:20.276278
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError()
    ReturnValueIgnoredError("message")
    ReturnValueIgnoredError("message", 1, 2, key="value")


# Generated at 2022-06-24 08:25:24.683690
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    print("Testing constructor of class DummyExecutor")
    try:
        # No assert
        x = DummyExecutor()
        print("Testing succeeded")
        return
    except AssertionError:
        print("AssertionError was raised")
    except Exception:
        print("Exception was raised")
    print("Testing failed")


# Generated at 2022-06-24 08:25:34.586928
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future as ConcFuture
    from tornado.concurrent import Future as AsyncioFuture

    conc_future = ConcFuture()  # type: ConcFuture
    asyncio_future = AsyncioFuture()  # type: AsyncioFuture

    conc_future.set_result('concurrent.futures.Future')
    asyncio_future.set_result('tornado.concurrent.Future')

    # chain_future() variants
    # Future -> Future
    chain_future(asyncio_future, asyncio_future)
    assert asyncio_future.result() == 'tornado.concurrent.Future'
    # Future -> concurrent.futures.Future
    chain_future(asyncio_future, conc_future)

# Generated at 2022-06-24 08:25:38.222998
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def _test():
        return 1
        
    f = DummyExecutor()
    f.submit(_test)



# Generated at 2022-06-24 08:25:42.903741
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.concurrent import Future

    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()

# Generated at 2022-06-24 08:25:43.904210
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("foo")

# Generated at 2022-06-24 08:25:44.876808
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:25:47.544978
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    from tornado.platform.asyncio import to_tornado_future
    import asyncio

    asyncio_future = to_tornado_future(asyncio.Future())
    future_set_result_unless_cancelled(asyncio_future, 1234)
    return asyncio_future


# Generated at 2022-06-24 08:25:50.477646
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())



# Generated at 2022-06-24 08:25:52.910787
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    test_executor = DummyExecutor()
    test_executor.submit(lambda x: x, 5)
    test_executor.shutdown(True)

# Generated at 2022-06-24 08:25:55.813563
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())
    assert is_future(concurrent.futures.Future())
    assert not is_future(object())
    is_future(Future())

# Generated at 2022-06-24 08:26:03.398347
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado
    from tornado.gen import Return
    future = Future()

    try:
        raise Return(42)
    except Return as r:
        assert isinstance(r.value, int)
        exc_info = sys.exc_info()

    future_set_exc_info(future, exc_info)
    assert future.exception() is exc_info[1]

    future = Future()
    try:
        raise Return(42)
    except Return as r:
        assert isinstance(r.value, int)
        exc_info = sys.exc_info()

    future_set_exc_info(future, exc_info)
    assert future.exception() is exc_info[1]

# Generated at 2022-06-24 08:26:11.967216
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    import threading
    import functools
    import concurrent.futures

    class MyTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self._thread_pool_executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=10
            )

        def wrap(self, value):
            # type: (int) -> int
            return value + 1

        @run_on_executor
        def run(self):
            # type: () -> int
            return self.wrap(1)

        @run_on_executor(executor="_thread_pool_executor")
        def run2(self):
            # type: () -> int
            return self.wrap(1)

       

# Generated at 2022-06-24 08:26:16.002379
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    shut = dummy_executor.shutdown(True)
    assert shut is None

# Generated at 2022-06-24 08:26:26.754943
# Unit test for function chain_future
def test_chain_future():
    from .testing import AsyncTestCase, gen_test
    from .gen import coroutine

    class TestCase(AsyncTestCase):
        @gen_test
        def test(self):
            def func(arg):
                self.assertEqual(arg, 42)
                return 24

            future = Future()
            res = yield func(42)
            self.assertEqual(res, 24)

            chain_future(future, func(42))
            self.assertEqual(future.done(), True)
            self.assertEqual(future.result(), 24)

            @coroutine
            def coro():
                self.assertEqual(arg, 42)
                return 24

            @coroutine
            def coro2(arg):
                self.assertEqual(arg, 42)
                return 24

            future = Future()
           

# Generated at 2022-06-24 08:26:30.754913
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop.current()
    executor = futures.ThreadPoolExecutor(2)

    class Foo(object):
        executor = executor

        @run_on_executor
        def f(self, a, b):
            self.io_loop.add_callback(self.stop)
            return a + b

        @staticmethod
        def stop():
            io_loop.stop()

    foo = Foo()
    foo.io_loop = io_loop
    future = foo.f(1, 2)
    assert isinstance(future, Future)
    io_loop.start()
    assert future.result() == 3
    executor.shutdown()



# Generated at 2022-06-24 08:26:38.279637
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.testing import AsyncTestCase
    from tornado.ioloop import IOLoop

    class TestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.loop = IOLoop()
            self.loop.make_current()

        def tearDown(self):
            self.loop.clear_current()
            self.loop.close(all_fds=True)
            super().tearDown()

        def test(self):
            future = Future()
            done = False

            def callback(f):
                nonlocal done
                self.assertTrue(f.done())
                done = True

            future_add_done_callback(future, callback)
            self.assertFalse(done)
            future.set_result(42)


# Generated at 2022-06-24 08:26:47.673764
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import asyncio
    from concurrent import futures

    future = Future()
    future.set_result(None)
    assert future.done()

    def callback(future):
        callback.called = True
        assert future.done()
        assert not future.cancelled()
        assert future.exception() is None
        assert future.result() is None
    callback.called = False

    # Test asyncio Future
    future_add_done_callback(future, callback)
    assert callback.called

    future = asyncio.Future()
    future.set_result(None)
    assert future.done()

    # Test concurrent.futures.Future
    future_add_done_callback(future, callback)
    assert callback.called


# Generated at 2022-06-24 08:26:55.167715
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.testing import gen_test
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    def func(a: int, b: int) -> int:
        return a + b

    @gen_test
    async def run():
        future = dummy_executor.submit(func, 1, 2)
        assert await future == 3
        assert future.done()
        assert future.exc_info() is None

    loop.run_sync(run)

# Generated at 2022-06-24 08:27:04.787910
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    def copy(future):
        assert future is f1
        if f2.done():
            return
        if f1.exception() is not None:
            f2.set_exception(f1.exception())
        else:
            f2.set_result(f1.result())

    future_add_done_callback(f1, copy)
    f1.set_result(42)
    assert [f2.result()] == [42]

    f1 = Future()
    f2 = Future()
    future_add_done_callback(f1, copy)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception().__class__ is ZeroDivisionError



# Generated at 2022-06-24 08:27:06.828724
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:27:10.902060
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    with pytest.raises(Exception):
        future_set_exception_unless_cancelled(future, Exception())

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())



# Generated at 2022-06-24 08:27:14.926202
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, arg):
            return arg + 1

    foo = Foo()
    result_future = foo.bar(41)
    assert is_future(result_future)
    assert result_future.result() == 42



# Generated at 2022-06-24 08:27:19.470116
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def f():
        raise Exception("boo")

    try:
        f()
    except:
        future_set_exc_info(future, sys.exc_info())

    assert future.exception() is not None
    try:
        future.result()
    except Exception as e:
        assert str(e) == "boo"
    else:
        assert False, "should have raised"

# Generated at 2022-06-24 08:27:21.324162
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
  dummy_executor.shutdown()

# Generated at 2022-06-24 08:27:24.108991
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        assert str(e) == "The result of this Future was never retrieved"

# Generated at 2022-06-24 08:27:30.014451
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("Test Exception"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    try:
        future_set_exception_unless_cancelled(future, Exception("Test Exception"))
    except Exception:
        assert False

