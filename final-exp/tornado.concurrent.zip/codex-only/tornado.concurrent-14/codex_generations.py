

# Generated at 2022-06-24 08:17:30.380010
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:17:34.236759
# Unit test for function run_on_executor
def test_run_on_executor():
    switch = [False]

    class Foo(object):
        @run_on_executor
        def foo(self):
            switch[0] = True

    a = Foo()
    a.executor = dummy_executor
    a.foo()

    assert switch[0]

# Generated at 2022-06-24 08:17:35.662647
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    f = DummyExecutor().submit(lambda: 123)
    assert f.result() == 123


# Generated at 2022-06-24 08:17:41.441938
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError(1, 2)


# Decorator to make a function run in the dummy executor.  Used for
# functions that are called from inside a coroutine and are not
# already decorated with @return_future.

# Generated at 2022-06-24 08:17:44.695715
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert isinstance(dummy_executor, DummyExecutor)
    assert dummy_executor.submit == DummyExecutor.submit
    assert dummy_executor.shutdown == DummyExecutor.shutdown


# Generated at 2022-06-24 08:17:49.313235
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            self.executor = DummyExecutor()
            self.result = None

        @run_on_executor
        def f(self):
            self.result = 42

    foo = Foo()
    foo.f()

    assert foo.result == 42

# Generated at 2022-06-24 08:17:50.403017
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


# Generated at 2022-06-24 08:17:58.607099
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    @gen.coroutine
    def wrap():
        x = yield f1
        yield f2

    callback = mock.Mock()
    wrap().add_done_callback(callback)

    # f1 finishes; f2 is still waiting
    assert not f1.done()
    assert not f2.done()
    f1.set_result(42)
    assert f1.result() == 42
    assert not f2.done()
    callback.assert_not_called()

    # f2 finishes
    f2.set_result(47)
    assert f2.result() == 47
    callback.assert_called_once_with(wrap())

# Generated at 2022-06-24 08:18:07.934228
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop

    def test_future_add_done_callback(ioloop):
        # type: (tornado.ioloop.IOLoop) -> None
        @tornado.gen.coroutine
        def make_future():
            # type: () -> Future[int]
            f = Future()
            f.set_result(42)
            raise tornado.gen.Return(f)

        async def async_make_future():
            # type: () -> Future[int]
            f = Future()
            f.set_result(42)
            return f

        @tornado.gen.coroutine
        def run_test():
            # type: () -> None
            f = yield make_future()
            cb_result = []


# Generated at 2022-06-24 08:18:12.600620
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import to_asyncio_future

    class FutureTest(AsyncTestCase):
        def setUp(self):
            super(FutureTest, self).setUp()
            self.future = to_asyncio_future(Future())
            self.future.cancel()

        @gen_test
        async def test_future_set_exception_unless_cancelled(self):
            try:
                raise RuntimeError
            except:
                future_set_exception_unless_cancelled(self.future, sys.exc_info()[1])

# Generated at 2022-06-24 08:18:15.440336
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
	dummy_future = dummy_executor.submit(lambda x: x + 1, 3)
	assert dummy_future.result() == 4


# Generated at 2022-06-24 08:18:17.645160
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())



# Generated at 2022-06-24 08:18:20.518923
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:18:28.864106
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import concurrent.futures

    class MyThreadPoolExecutor(concurrent.futures.ThreadPoolExecutor):
        def __init__(self):
            super(MyThreadPoolExecutor, self).__init__()
            self.io_loop = IOLoop()

    class Test(object):
        executor = MyThreadPoolExecutor()

        @run_on_executor
        def func(self, a, b):
            return a + b

    test = Test()
    assert isinstance(test.executor, MyThreadPoolExecutor)

    def on_done(fut):
        # type: (Future[Any]) -> None
        assert isinstance(fut, Future)
        assert fut.result() == 3
        self.stop()


# Generated at 2022-06-24 08:18:30.106719
# Unit test for function is_future
def test_is_future():
    Future()  # mypy thinks this is a class, not a type.

# Generated at 2022-06-24 08:18:41.418474
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    # Test a concurrent.futures.Future.
    future = futures.Future()
    called = []

    def callback(fut: "concurrent.futures.Future"):
        assert fut is future
        called.append(True)

    future_add_done_callback(future, callback)
    assert called == []
    future.set_result(None)
    assert called == [True]

    # Test an asyncio.Future.
    future = Future()
    called = []

    def callback(fut: Future):
        assert fut is future
        called.append(True)

    future_add_done_callback(future, callback)
    assert called == []
    future.set_result(None)
    assert called == [True]



# Generated at 2022-06-24 08:18:43.745295
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception() is None

# Generated at 2022-06-24 08:18:48.834778
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop
    ioloop = tornado.ioloop.IOLoop.current()

    def my_func(self, x: int, y: int) -> int:
        return x + y

    class MyClass:
        executor = dummy_executor  # type: Any

        @run_on_executor
        def f(self, x: int, y: int) -> Future:
            return x + y

    foo = MyClass()
    result = foo.f(42, 1337)

    assert isinstance(result, Future)
    assert result.done() == False

    ioloop.run_sync(lambda: result)

    assert result.done() == True
    assert result.result() == 42 + 1337

    # As a side effect of the above (and because it's deprecated anyway)
    # check that

# Generated at 2022-06-24 08:18:53.759850
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()

    def call_set_exception_unless_cancelled():
        future_set_exception_unless_cancelled(f, RuntimeError("foo"))

    f.cancel()
    try:
        call_set_exception_unless_cancelled()
    except:
        pass

    assert f.cancelled()

# Generated at 2022-06-24 08:18:58.328661
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    my_future = Future()
    my_other_future = Future()
    future_set_result_unless_cancelled(my_other_future, 1)
    my_future.set_result(5)  # should not raise an exception

# Generated at 2022-06-24 08:19:01.150043
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42

# Generated at 2022-06-24 08:19:02.783350
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    error = ReturnValueIgnoredError("Blah")
    assert error.args == ("Blah",)

# Generated at 2022-06-24 08:19:13.931818
# Unit test for function chain_future
def test_chain_future():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            source = Future()
            dest = Future()
            chain_future(source, dest)
            source.set_result(42)
            self.assertEqual(dest.result(), 42)

            source = Future()
            dest = Future()
            chain_future(source, dest)
            source.set_exception(RuntimeError())
            self.assertEqual(dest.exception().__class__, RuntimeError)

            source = Future()
            dest = Future()
            chain_future(source, dest)
            dest.set_result(1729)
            source.set_result(42)

# Generated at 2022-06-24 08:19:19.703141
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import sys
    import unittest

    from tornado.ioloop import IOLoop

    IOLoop.clear_instance()

    class TestCase(unittest.TestCase):
        def test_future_set_exc_info(self):
            exc_info = (ValueError, ValueError("error"), None)
            f = Future()
            future_set_exc_info(f, exc_info)
            self.assertTrue(f.done())
            self.assertEqual(f.exception(), exc_info[1])

    unittest.main()

# Generated at 2022-06-24 08:19:27.532280
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import gen
    from unittest.mock import MagicMock

    x = DummyExecutor()
    x.submit()

    x.submit(lambda x: None)

    def dummy():
        pass

    x.submit(dummy)

    x.submit(lambda x: None, 10, 20)
    x.submit(dummy, 10, 20)

    x.submit(lambda x: None, 10, 20, a="b")
    x.submit(dummy, 10, 20, a="b")

    @gen.coroutine
    def dummy_coro():
        pass

    x.submit(dummy_coro)
    x.submit(dummy_coro, 10, 20)



# Generated at 2022-06-24 08:19:31.522084
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # type: Future[Any]
    try:
        raise Exception
    except:
        future_set_exception_unless_cancelled(future, sys.exc_info()[1])
    assert future.exception() is not None



# Generated at 2022-06-24 08:19:37.111552
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class Test(object):
        executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            # type: (Test, int, int) -> Future[int]
            return a + b

    t = Test()
    assert isinstance(t.func(1, 1), Future)
    assert t.func(1, 1).result() == 2

# Generated at 2022-06-24 08:19:47.880654
# Unit test for function run_on_executor
def test_run_on_executor():  # noqa
    import tornado.ioloop
    import concurrent.futures

    io_loop = tornado.ioloop.IOLoop.current()

    ex = concurrent.futures.ThreadPoolExecutor(2)

    class A:
        executor = ex

        @run_on_executor
        def f(self, x):
            return x ** 2

    a = A()

    f = a.f(42)
    io_loop.add_future(f, lambda f: io_loop.stop())
    io_loop.start()

    assert f.result() == 1764

    class B:
        @run_on_executor
        def f(self, x):
            return x ** 2

    b = B()

    f = b.f(42)

# Generated at 2022-06-24 08:19:49.512343
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    exception = ReturnValueIgnoredError("Error")
    assert str(exception) == "Error"

# Generated at 2022-06-24 08:19:57.031581
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.concurrent
    import concurrent.futures
    import unittest
    import sys
    import threading

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)
            self.executor = concurrent.futures.ThreadPoolExecutor(
                max_workers=1
            )

        def tearDown(self):
            self.loop.close()
            self.executor.shutdown(wait=True)

        @run_on_executor
        def method(self):
            # type: () -> str
            return "hello, world"


# Generated at 2022-06-24 08:20:03.784874
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    exc_info = (Exception, Exception("test"), None)
    future_set_exception_unless_cancelled(f, exc_info[1])
    assert not f.done()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc_info[1])
    assert f.done()


_STOP_SIGNAL = object()



# Generated at 2022-06-24 08:20:07.866116
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    loop.run_until_complete(f2)
    assert f2.result() == 42



# Generated at 2022-06-24 08:20:10.077834
# Unit test for function chain_future
def test_chain_future():
    ioloop = asyncio.get_event_loop()
    f1 = ioloop.create_future()
    f2 = ioloop.create_future()
    assert id(f1) != id(f2)
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.done()



# Generated at 2022-06-24 08:20:16.254979
# Unit test for function run_on_executor
def test_run_on_executor():
    import datetime
    import tornado
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    class Foo(object):
        def __init__(self):
            # Use an executor with a small thread pool, to simplify the
            # unit test and make it easier to trigger errors.
            self.executor = futures.ThreadPoolExecutor(2)

        @run_on_executor
        def no_result(self):
            pass

        @run_on_executor
        def sleep_and_return(self, i):
            tornado.ioloop.IOLoop.current().add_timeout(
                datetime.timedelta(seconds=0.1), lambda: True
            )
            return i

    foo = Foo()
    foo.no_result()
    foo

# Generated at 2022-06-24 08:20:23.459185
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    def set_result_unless_cancelled(f):
        future_set_result_unless_cancelled(f, 42)


    from concurrent import futures
    from asyncio import get_event_loop


    loop = get_event_loop()
    f = futures.Future()
    loop.call_soon(set_result_unless_cancelled, f)
    with pytest.raises(futures.CancelledError):
        f.cancel()
        loop.run_until_complete(f)



# Generated at 2022-06-24 08:20:27.185980
# Unit test for function is_future
def test_is_future():
    if is_future(Future()):
        throw()
    if not is_future(Future()):
        throw()

# Generated at 2022-06-24 08:20:30.231415
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    """
    >>> test_ReturnValueIgnoredError()
    """
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass



# Generated at 2022-06-24 08:20:35.438843
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    class LocalFuture(asyncio.Future):
        def add_done_callback(self, callback):
            # type: (Callable[["Future[_T]"], Any]) -> None
            self.callback = callback

    f = LocalFuture()

    def callback(future):
        # type: (Future) -> None
        # Some code
        pass

    future_add_done_callback(f, callback)
    assert f.callback is callback

    f.set_result(None)
    assert f.result() is None



# Generated at 2022-06-24 08:20:40.467320
# Unit test for function chain_future
def test_chain_future():
    import tornado.ioloop
    import tornado.testing

    f = Future()  # type: Future[str]
    g = Future()  # type: Future[str]
    chain_future(f, g)
    ioloop = tornado.ioloop.IOLoop.current()

    def complete_future(future, result):
        ioloop.add_callback(future_set_result_unless_cancelled, future, result)

    complete_future(f, "f_result")
    complete_future(g, "g_result")

    # The result of f should be copied to g.
    assert g.result() == "f_result"



# Generated at 2022-06-24 08:20:43.955980
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-24 08:20:49.383082
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future1 = Future()
    future_set_result_unless_cancelled(future1, 'some result1')
    assert future1.result() == 'some result1'
    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, 'some result2')
    assert future2.result() is None


# Generated at 2022-06-24 08:20:53.770106
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def add(a, b):
        return a + b

    print(dummy_executor.submit(add, 2, 3))
    print(dummy_executor.submit(add, 4, 5))
    # print(dummy_executor.submit(add, a=8, b=9))
    print(dummy_executor.submit(add, a=10, b=11))



# Generated at 2022-06-24 08:20:57.873231
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42

    future3 = Future()
    future4 = Future()
    chain_future(future3, future4)
    future3.set_exception(Exception())
    assert future4.exception() is not None

# Generated at 2022-06-24 08:21:05.428446
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()
    future = Future()
    future_set_result_unless_cancelled(future, True)
    loop.run_until_complete(future)
    assert future.result() == True
    # Cancel this future, cannot change its result
    future.cancel()
    future_set_result_unless_cancelled(future, False)
    assert future.result() == None
    future.cancel()
    future_set_result_unless_cancelled(future, True)
    assert future.result() == None

# Generated at 2022-06-24 08:21:11.712123
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.concurrent

    class Foo(object):
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(1)
        @run_on_executor
        def func(self, a, b):
            return a + b
        @run_on_executor(executor='executor')
        def func2(self, a, b):
            return a + b
        @run_on_executor
        def fail(self):
            raise Exception("should never happen")

    foo = Foo()

    f1 = foo.func(1, 2)
    assert isinstance(f1, Future)
    assert f1.result() == 3

    f2 = foo.func2(10, 20)
    assert f2.result() == 30

    f3 = foo.fail()

# Generated at 2022-06-24 08:21:15.188818
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.submit(lambda x: x, 1)
    executor.submit(lambda x: x, 2)
    executor.submit(lambda x: x, 3)
    executor.shutdown()
    assert True


# Generated at 2022-06-24 08:21:16.089351
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda: "hello world")

# Generated at 2022-06-24 08:21:17.517654
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda x: x, "test")


# Generated at 2022-06-24 08:21:21.716836
# Unit test for function future_add_done_callback
def test_future_add_done_callback():

    def callback(f):
        pass

    ff = futures.Future()
    future_add_done_callback(ff, callback)
    ff.set_result(None)

    af = Future()
    future_add_done_callback(af, callback)
    af.set_result(None)

# Generated at 2022-06-24 08:21:26.124229
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, Exception("x"))
    assert future.done()
    assert isinstance(future.exception(), Exception)
    future = Future()
    future.cancel()
    assert future.done()
    future_set_exception_unless_cancelled(future, Exception("x"))
    assert future.done()

# Generated at 2022-06-24 08:21:27.372809
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:21:34.275208
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    from tornado.platform.asyncio import AsyncIOLoop

    loop = AsyncIOLoop()
    loop.make_current()

    def callback(future: Future) -> None:
        pass

    def func(*args: Any) -> None:
        print('args: ', args)

    d = DummyExecutor()
    f = d.submit(func, 1, 3, callback)
    assert f == None

# Generated at 2022-06-24 08:21:41.205836
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()

    future_set_exception_unless_cancelled(future, Exception("test exception"))
    assert future.done()

    future = Future()
    future.cancel()
    assert future.done()

    future_set_exception_unless_cancelled(future, Exception("test exception"))
    assert future.done()

# Generated at 2022-06-24 08:21:51.393921
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.concurrent
    import concurrent.futures

    class A(object):
        executor = concurrent.futures.ThreadPoolExecutor(1)
        _thread_pool = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            return arg

        @run_on_executor(executor="_thread_pool")
        def func2(self, arg):
            return arg

    a = A()

    class TestRun(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop.current()

        def test_run_on_executor(self):
            f = a.func(1)

# Generated at 2022-06-24 08:21:58.416951
# Unit test for function chain_future
def test_chain_future():
    # Test chaining a concurrent.futures.Future to an asyncio.Future,
    # and vice versa.
    import concurrent.futures
    import asyncio

    executor = concurrent.futures.ThreadPoolExecutor(1)

    f1 = Future()
    f2 = concurrent.futures.Future()
    f3 = Future()
    f4 = concurrent.futures.Future()
    chain_future(f1, f2)
    chain_future(f3, f4)
    chain_future(f2, f4)
    chain_future(f1, f3)

    f1.set_result(42)
    loop = asyncio.get_event_loop()

    def finalize():
        assert f3.result() == 42
        assert f4.result() == 42

    loop

# Generated at 2022-06-24 08:22:00.483183
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:22:05.636345
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    done = object()
    e = object()
    r = object()

    def f1():
        fut1.set_result(r)
        return done

    def f2():
        raise Exception("")

    def cb(fut: Future) -> None:
        assert fut is fut2
        assert fut2.result() is done
        return done

    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    assert fut2.result() is None

    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    fut1.set_result(r)
    assert fut2.result() is r

    fut1 = Future()
    fut2 = Future()
    chain_future

# Generated at 2022-06-24 08:22:10.246433
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.cancel()
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

# Generated at 2022-06-24 08:22:13.956782
# Unit test for function chain_future
def test_chain_future():
    future = Future()  # type: Future[int]
    future2 = Future()  # type: Future[int]
    chain_future(future, future2)
    future.set_result(42)
    assert future2.result() == 42



# Generated at 2022-06-24 08:22:17.427309
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.done()
    assert g.result() == 42

# Generated at 2022-06-24 08:22:23.022425
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    cancelled_future = Future()
    cancelled_future.set_result(None)
    future_set_exception_unless_cancelled(future, Exception("example"))
    assert future.exception() is not None
    future_set_exception_unless_cancelled(cancelled_future, Exception("example"))
    assert cancelled_future.exception() is None

# Generated at 2022-06-24 08:22:26.226730
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    results = []
    future = Future()
    future_add_done_callback(future, results.append)

    future.set_result(None)
    assert results == [future]



# Generated at 2022-06-24 08:22:31.208562
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, arg1):
            # type: (Any) -> Any
            return arg1

    foo = Foo()
    future = foo.func(1)
    future.result() == 1

# Generated at 2022-06-24 08:22:34.382116
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test_function(i: int, j: int) -> int:
        return i + j
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(test_function, 1, 9)
    assert future.result() == 10

# Generated at 2022-06-24 08:22:40.884350
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import concurrent.futures

    callback_result = None

    def callback(f):
        nonlocal callback_result
        callback_result = f.result()

    f = concurrent.futures.Future()
    future_add_done_callback(f, callback)
    assert callback_result is None  # not invoked
    f.set_result(42)
    assert callback_result == 42  # invoked immediately



# Generated at 2022-06-24 08:22:46.560776
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # Test the exception 
    executor = DummyExecutor()
    f = executor.submit(f=lambda x: x + 1, args=1)
    print(f.result())
    # Test case without exception
    f = executor.submit(f=lambda x: x - 1, args=1)
    print(f.result())
    return


if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:22:57.503434
# Unit test for function chain_future
def test_chain_future():
    done_future = Future()
    done_future.set_result(None)
    done_future2 = Future()
    done_future2.set_result(None)

    def fn(arg):
        assert isinstance(arg, Future)
        if not arg.done():
            raise ValueError("Future should be done")
        return arg.result()

    # this should run synchronously
    f = done_future.chain(fn)
    assert f.result() is None

    # this should run synchronously
    f = Future().chain(fn, done_future2)
    assert f.result() is None

    # this should run synchronously
    f = Future().chain(fn, done_future)
    assert f.result() is None

    # this should run asynchronously
    f = Future().chain(fn)

# Generated at 2022-06-24 08:23:02.111094
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.result() == 1

# Generated at 2022-06-24 08:23:05.101757
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def foo(a,b):
        return a + b
    res = dummy_executor.submit(foo, 2, 3)
    assert res.result() == foo(2, 3)

# Generated at 2022-06-24 08:23:06.768889
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        ...
    future = Future()
    future_add_done_callback(future, callback)
    future = futures.Future()
    future_add_done_callback(future, callback)



# Generated at 2022-06-24 08:23:11.687120
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    """Test the behavior of method submit of class DummyExecutor.

    """
    def fn(*args: Any, **kwargs: Any) -> int:
        return 1

    futures_list = []
    for i in range(10):
        futures_list.append(dummy_executor.submit(fn, args=[], kwargs={}))
    for future in futures_list:
        assert future.result() == 1

# Generated at 2022-06-24 08:23:13.981913
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(dummy_executor)

# Generated at 2022-06-24 08:23:17.303581
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    assert isinstance(d, futures.Executor)



# Generated at 2022-06-24 08:23:27.043948
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class FakeExecutor(object):
        def submit(
            self, fn: Callable[..., Any], *args: Any, **kwargs: Any
        ) -> "futures.Future":
            return futures.Future()

    class MyClass(object):
        executor = FakeExecutor()
        _thread_pool = FakeExecutor()

        @run_on_executor
        def foo(self):
            pass

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            pass


# Generated at 2022-06-24 08:23:30.437792
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError()
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-24 08:23:39.490448
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc
    future_set_result_unless_cancelled(future, None)
    future_set_exception_unless_cancelled(future, exc)
    assert future.result() is None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.cancelled()
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()

# Generated at 2022-06-24 08:23:48.265230
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado import gen
    from tornado.testing import AsyncTestCase

    class FutureTest(AsyncTestCase):
        @gen.coroutine
        def test_future_add_done_callback(self):
            f1 = asyncio.Future()
            f1.set_result(1)

            f2 = asyncio.Future()
            f2.set_result(2)

            mock_handler = Mock()
            future_add_done_callback(f1, mock_handler)
            future_add_done_callback(f2, mock_handler)
            self.assertEqual(mock_handler.call_count, 2)
            self.assertEqual(mock_handler.call_args_list[0][0][0], f1)

# Generated at 2022-06-24 08:23:52.856859
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.cancelled()
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.cancelled()
    assert future.exception() is None


# Generated at 2022-06-24 08:23:59.628047
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.set_result(2)
    assert future.result() == 2

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()

# Generated at 2022-06-24 08:24:10.886038
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    exc = Exception()
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    try:
        raise f.exception()
    except Exception as e:
        assert e is exc
    f = Future()
    # Tornado-specific, use a non-frame
    f.exc_info = lambda: (None, exc, None)
    future_set_exc_info(f, f.exc_info())
    try:
        raise f.exception()
    except Exception as e:
        assert e is exc
    f = Future()
    f.set_exc_info = lambda *args: None
    future_set_exc_info(f, sys.exc_info())
    f = Future()
    f.set_exc_info = lambda *args: None

# Generated at 2022-06-24 08:24:17.153937
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    exc = Exception("foo")
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is exc



# Generated at 2022-06-24 08:24:18.081013
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True==True

# Generated at 2022-06-24 08:24:27.310914
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    callback_args = None
    from concurrent import futures
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    future = futures.Future()
    callback_args = None

    def callback(f):
        nonlocal callback_args
        callback_args = (f, 1, 2)

    IOLoop.configure("tornado.platform.asyncio.AsyncIOMainLoop")
    IOLoop.current()
    future_add_done_callback(future, callback)
    assert callback_args is None
    future.set_result("result")
    AsyncIOMainLoop().start()
    assert (callback_args[0] is future) and (callback_args[1:] == (1, 2))
    IOLoop.clear_instance()
    AsyncI

# Generated at 2022-06-24 08:24:28.510104
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass


# Generated at 2022-06-24 08:24:33.378023
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    fut = DummyExecutor().submit(lambda x: x + 1, 1)
    assert fut.result() == 2
    try:
        fut = DummyExecutor().submit(lambda x: x / 0, 1)
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError("Must raise ZeroDivisionError")


# Generated at 2022-06-24 08:24:35.972462
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    result = dummy_executor.submit(lambda msg: msg + ' world!', 'Hello')
    assert result.result() == 'Hello world!'
    assert result.done() == True
    assert result.cancelled() == False

# Generated at 2022-06-24 08:24:47.502290
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.ioloop
    import tornado.platform.asyncio
    import concurrent.futures

    executor = concurrent.futures.ThreadPoolExecutor(1)
    io_loop = tornado.ioloop.IOLoop.current()
    asyncio_loop = tornado.platform.asyncio.BaseAsyncIOLoop(io_loop)

    f1 = asyncio_loop.run_in_executor(executor, lambda: 1 / 0)

    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()

    io_loop.run_sync(f2.result)
    assert f2.done()
    assert isinstance(f2.exception(), ZeroDivisionError)

    f3 = Future()

# Generated at 2022-06-24 08:24:53.861607
# Unit test for function chain_future
def test_chain_future():
    from tornado.log import gen_log

    # Test that a chained future doesn't trigger until its parent finishes
    parent = futures.Future()
    f = futures.Future()
    chain_future(parent, f)
    parent.set_result(42)

    def validate_result(future):
        gen_log.debug("future result is %r", future.result())
        assert future.result() == 42

    f.add_done_callback(validate_result)



# Generated at 2022-06-24 08:24:59.719963
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    l = []
    f = Future()
    future_add_done_callback(f, lambda future: l.append(future))
    f.set_result(1)
    assert l == [f]
    f2 = Future()
    future_add_done_callback(f2, lambda future: l.append(future))
    assert l == [f, f2]



# Generated at 2022-06-24 08:25:02.881068
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():

    # create a function that returns 42
    def foo():
        return 42

    # submit to Dummy executor
    fut = dummy_executor.submit(foo)

    # assert that the submit is actually working
    assert fut.result() == 42

# Generated at 2022-06-24 08:25:07.254797
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """Test if future_set_result_unless_cancelled is working as expected.
    """

    # Test if value is set
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10

    # Test if value is not set
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 20)
    assert not future.cancelled()



# Generated at 2022-06-24 08:25:13.122190
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor_1 = DummyExecutor()
    assert not asyncio.isfuture(dummy_executor_1)
    dummy_executor_2 = typing.cast(
        DummyExecutor, dummy_executor_1
    )
    dummy_executor_2.shutdown()
    assert not asyncio.isfuture(dummy_executor_1)

# Generated at 2022-06-24 08:25:14.876727
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert isinstance(future_add_done_callback, Callable)

# Generated at 2022-06-24 08:25:15.592479
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:25:21.716394
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, "test")
    assert f.done()
    assert f.exception() is None
    assert f.result() == "test"

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "test")
    assert f.cancelled()



# Generated at 2022-06-24 08:25:26.114912
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        assert isinstance(future, Future)
        future_set_result_unless_cancelled(future_result, future.result())

    future_result = Future()
    future = Future()
    future_add_done_callback(future, callback)
    assert not future_result.done()
    future.set_result(None)
    future_result.result()



# Generated at 2022-06-24 08:25:27.302806
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    _ = ReturnValueIgnoredError()

# Generated at 2022-06-24 08:25:30.215547
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:25:44.682646
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    io_loop = asyncio.new_event_loop()
    try:
        async def run_test() -> None:
            future = Future()
            called = [False]

            def callback(f):
                called[0] = True
                assert f is future

            future_add_done_callback(future, callback)
            assert not called[0]
            future_add_done_callback(future, callback)
            future.set_result(1)
            assert called[0]

            called[0] = False
            future = Future()
            future.set_result(1)
            future_add_done_callback(future, callback)
            assert called[0]

        io_loop.run_until_complete(run_test())
    finally:
        io_loop.close()



# Generated at 2022-06-24 08:25:49.267169
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    called = []
    f = Future()

    def callback(future):
        # type: (Future) -> None
        called.append(future)

    future_add_done_callback(f, callback)

    f.set_result(None)
    assert called == [f]



# Generated at 2022-06-24 08:25:50.962513
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    assert isinstance(d, DummyExecutor)



# Generated at 2022-06-24 08:26:00.204398
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado import testing

    # We need to call AsyncIOMainLoop.initialize(). Otherwise
    # tornado.platform.asyncio.to_asyncio_future() will fail.
    io_loop = AsyncIOMainLoop()
    io_loop.make_current()

    class FuturesTest(testing.AsyncTestCase):
        def test_future_set_result_unless_cancelled(self):
            future_1 = Future()
            future_2 = Future()

            future_1.cancel()


# Generated at 2022-06-24 08:26:03.134526
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(int(42))  # noqa: F841

# Generated at 2022-06-24 08:26:08.808328
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_future(result=None, exception=None):
        d = DummyExecutor()
        future = d.submit(lambda : 1)
        if exception:
            future.set_exception(exception)
        else:
            future.set_result(result)
        return future


    # A simple test of the future interface, used by test_ft_integration
    test_future().result()
    test_future(1).result()
    with pytest.raises(ZeroDivisionError):
        test_future(exception=ZeroDivisionError()).result()
    with pytest.raises(ZeroDivisionError):
        test_future(exception=ZeroDivisionError()).exception()

# Generated at 2022-06-24 08:26:20.185525
# Unit test for function run_on_executor
def test_run_on_executor():
    class Obj:
        def __init__(self):
            self.executor = dummy_executor
            self.res = None
            self.exc_info = None

        @run_on_executor
        def set(self, arg):
            self.res = arg

        @run_on_executor
        def fail(self, arg):
            1 // 0

        def set_done(self, future):
            try:
                future.result()
            except Exception:
                self.exc_info = sys.exc_info()

    obj = Obj()
    obj.set(42)
    assert obj.res is None
    obj.set.result()
    assert obj.res == 42

    obj.fail(100)
    assert obj.exc_info is None

# Generated at 2022-06-24 08:26:21.789242
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:26:25.405427
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    assert future.result() is None
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()



# Generated at 2022-06-24 08:26:34.200300
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase

    @run_on_executor(executor="_thread_pool")
    def thread_func(arg: Any, **kwargs: Any) -> Any:
        return arg

    @gen.coroutine
    def call_thread_func(arg: Any, **kwargs: Any) -> Any:
        future = thread_func(arg, **kwargs)
        result = yield future
        raise gen.Return(result)

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self._thread_pool = futures.ThreadPoolExecutor(1)

        def test_chain_future(self):
            arg = object()
            future = Future()
            chain_future(call_thread_func(arg), future)
            result = self.wait

# Generated at 2022-06-24 08:26:45.163349
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def async_test():
        future = Future()
        try:
            raise Exception('async exception')
        except:
            future_set_exc_info(future, sys.exc_info())
        future.add_done_callback(lambda fut: fut.result())

    future = Future()
    try:
        raise Exception('sync exception')
    except:
        future_set_exc_info(future, sys.exc_info())
    future.add_done_callback(lambda fut: fut.result())

    futs = [async_test(), future]
    if sys.version_info >= (3, 7):
        asyncio.run(asyncio.wait(futs))
    else:
        loop = asyncio.get_event_loop()

# Generated at 2022-06-24 08:26:47.391507
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.shutdown()

# Generated at 2022-06-24 08:26:53.355661
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError
    except ValueError:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    assert future.exception().__class__ is ValueError

# The rest of the unit tests are in futures_test.py.

# Generated at 2022-06-24 08:27:01.280387
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    #  test a non cancelled future
    my_future_integer = Future()
    future_set_result_unless_cancelled(my_future_integer, 2)  # type: ignore
    assert my_future_integer.result() == 2
    # test a cancelled future
    my_cancelled_future = Future()
    my_cancelled_future.cancel()
    future_set_result_unless_cancelled(my_cancelled_future, 2)  # type: ignore
    assert not my_cancelled_future.cancelled()



# Generated at 2022-06-24 08:27:13.956417
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    x = DummyExecutor()
    # Unit test for method submit
    y = x.submit(lambda x: x, 1)
    # Unit test for method shutdown
    x.shutdown()
    assert not y.done()
    assert y.result() == 1
    # Unit test for class Run_on_executor
    def f(y: DummyExecutor, x: Any) -> Any:
        return y.submit(lambda x: x, x)

    f.executor = x
    g = run_on_executor(f)
    z = g(x, 1)
    assert z.done()
    assert z.result() == 1
    # Unit test for function chain_future
    chain_future(z, y)
    assert y.done()


test_DummyExecutor()
test_DummyExecutor

# Generated at 2022-06-24 08:27:15.213732
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert 1==1


# Generated at 2022-06-24 08:27:26.425167
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading

    # Dummy methods for testing
    def func_dummy(value):
        pass

    def func_empty():
        pass

    def func_args_kwargs(arg1, arg2, kwarg1="", kwarg2=""):
        pass

    def func_summation(arg1, arg2, kwarg1="", kwarg2=""):
        return arg1 + arg2

    def func_exception():
        raise Exception("Exception inside func_exception")

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            # Create an executor that runs functions
            self.executor = futures.ThreadPoolExecutor(1)
            # A dummy class to test run_on_executor

# Generated at 2022-06-24 08:27:34.497589
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    result = []
    # type: List[int]
    @gen.coroutine
    def f():
        result.append(1)
        yield gen.moment
        result.append(2)

    future_add_done_callback(f, lambda f: result.append(3))
    result.append(0)

    IOLoop.current().run_sync(lambda: f())
    assert result == [0, 1, 2, 3]

    result = []
    f = Future()
    future_add_done_callback(f, lambda f: result.append(3))
    result.append(0)
    f.set_result(None)
    assert result == [0, 3]

    result = []
    f = Future()
    f.set_result(None)
    future