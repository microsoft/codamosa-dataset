

# Generated at 2022-06-24 08:17:29.687157
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    print("this is a test for method shutdown of class DummyExecutor")
    dummy_executor.shutdown()
    pass


# Generated at 2022-06-24 08:17:33.722889
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    class TestException(Exception):
        pass

    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, TestException())
    assert future.done()
    assert isinstance(future.exception(), TestException)

    future = Future()
    future.cancel()
    assert not future.done()
    future_set_exception_unless_cancelled(future, TestException())
    assert not future.done()

# Generated at 2022-06-24 08:17:34.818409
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda x: x, 3)


# Generated at 2022-06-24 08:17:38.390742
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: nocover
    future = Future()
    # You can't call set_exception with an empty tuple; you must use None
    # or a valid (type, value, traceback) tuple.
    future_set_exc_info(future, (None, None, None))
    assert future.exception() is None
    future_set_exc_info(future, (ZeroDivisionError, ZeroDivisionError(), None))
    assert isinstance(future.exception(), ZeroDivisionError)



# Generated at 2022-06-24 08:17:38.772233
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:17:41.697720
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert is_future(concurrent.futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:17:49.604099
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest
    # We want to test both tornado.concurrent.Future and asyncio.Future
    # but testing both requires some extra care because their APIs differ
    # slightly.
    #
    # When AsyncIOMainLoop is in use, we want to test asyncio.Future. In the
    # other case we want to test tornado.concurrent.Future.
    #
    # Our strategy is to force AsyncIOMainLoop to be in use by modifying
    # sys.modules, but to make it so that a TypeError is thrown if any
    # irrelevant method or attribute of asyncio.Future is called.
    # The strategy is a little complicated, but I couldn't get it to work
    # in any simpler way.
    old_as

# Generated at 2022-06-24 08:17:58.637495
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.concurrent import Future
    async def async_error():
        raise ValueError
    def sync_error():
        raise ValueError
    for ins in [Future(), Future()]:
        future_set_exc_info(ins, sys.exc_info())
        # from https://docs.python.org/3/library/sys.html#sys.exc_info
        # On entry to an except handler, the exception information is
        # replaced with the new exception information.
        assert sys.exc_info() == (None, None, None)
        assert isinstance(ins.exception(), ValueError)
    for ins in [async_error(), sync_error()]:
        future_set_exc_info(ins, sys.exc_info())
        assert isinstance(ins.exception(), ValueError)

# Generated at 2022-06-24 08:18:08.998317
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    assert not f.done()

    result = {}  # type: typing.Dict[str, typing.Any]

    def cb(future):
        result["callback"] = True
        result["result"] = future.result()

    future_add_done_callback(f, cb)
    f.set_result(True)
    assert result["callback"]
    assert result["result"] is True

    f = Future()
    f.set_result(True)
    result = {}
    future_add_done_callback(f, cb)
    assert result["callback"]
    assert result["result"] is True

# Generated at 2022-06-24 08:18:20.268034
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen
    from tornado.ioloop import IOLoop

    ioloop = IOLoop()
    ioloop.make_current()

    async def f1():
        await gen.moment
        return "f1"

    async def f2():
        await gen.moment
        return "f2"

    async def f3():
        await gen.moment
        return "f3"

    f = Future()
    chain_future(f, f1())
    chain_future(f1(), f2())
    chain_future(f2(), f3())
    f.set_result("f")

    async def f4():
        await gen.moment
        return "f4"

    async def f5():
        await gen.moment
        return "f5"


# Generated at 2022-06-24 08:18:22.594639
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda:1)
    assert future.result() == 1


# Generated at 2022-06-24 08:18:25.266963
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x + 1, 10)
    assert future.result() == 11
    assert future


test_DummyExecutor()

# Generated at 2022-06-24 08:18:30.630493
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    ok = object()
    future_set_result_unless_cancelled(future, ok)
    assert ok == future.result()

    future = Future()
    future.cancel()

    future_set_result_unless_cancelled(future, ok)
    assert future.cancelled()
    with pytest.raises(asyncio.CancelledError):
        future.result()


# Generated at 2022-06-24 08:18:35.899933
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    def test():
        return 'test'
    test_future = DummyExecutor().submit(test)
    assert test_future.result() == 'test'

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:18:38.861549
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        future.set_result("Future is done")

    f = Future()
    future_add_done_callback(f, callback)
    f.set_result("Future is done")



# Generated at 2022-06-24 08:18:48.578005
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import asyncio

    async def coro(result: Any, exception: Exception) -> Future:
        future = Future()  # type: Future
        try:
            future_set_result_unless_cancelled(future, result)
        except Exception as e:
            if exception is None:
                raise
            future_set_exception_unless_cancelled(future, exception)
        return future

    class FutureChainTest(unittest.TestCase):
        def setUp(self) -> None:
            self.io_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)

        def tearDown(self) -> None:
            self.io_loop.close()

        def test_success(self) -> None:
            async_future = Future()  #

# Generated at 2022-06-24 08:18:54.028042
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    result = []

    def raise_error(message, exception=ValueError):
        def raise_func():
            raise exception(message)
        return raise_func

    def set_exc_info(future):
        future_set_exc_info(future, sys.exc_info())

    f = Future()
    f.add_done_callback(set_exc_info)
    IOLoop.current().add_callback(raise_error("foo"))
    f.add_done_callback(lambda f: result.append(f.result()))
    IOLoop.current().add_callback(IOLoop.current().stop)
    IOLoop.current().start()
    assert result[0] is None



# Generated at 2022-06-24 08:19:00.569663
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, RuntimeError("test"))
    assert f.exception()
    assert not f.cancelled()
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError("test2"))
    assert f.exception()
    assert f.cancelled()



# Generated at 2022-06-24 08:19:03.269519
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    args = []
    future_add_done_callback(future, args.append)
    assert not args
    future.set_result(42)
    assert args == [future]

# Generated at 2022-06-24 08:19:05.000890
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass #TODO



# Generated at 2022-06-24 08:19:14.867669
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    f = futures.Future()
    called = []
    future_add_done_callback(f, called.append)
    f.set_result(None)
    assert called[0] is f
    assert len(called) == 1
    called = []
    future_add_done_callback(f, called.append)
    assert called[0] is f
    assert len(called) == 1

# Generated at 2022-06-24 08:19:22.099307
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado import gen

    f1 = Future()  # type: Future[None]
    f2 = Future()  # type: Future[None]
    e1 = Exception()
    e2 = Exception()
    future_set_exception_unless_cancelled(f1, e1)
    f2.cancel()
    future_set_exception_unless_cancelled(f2, e2)
    assert f1.exception() is e1
    assert f1.done()
    with pytest.raises(Exception):
        f2.result()
    assert f2.cancelled()
    assert f2.done()

    # This is different than NoneFuture behavior, but probably harmless
    f3 = Future()  # type: Future[None]
    f3.set_exception(e1)
   

# Generated at 2022-06-24 08:19:24.469656
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("Test exception")
    except:
        future_set_exc_info(future, sys.exc_info())
    return future



# Generated at 2022-06-24 08:19:25.977784
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import concurrent.futures

    loop = asyncio.get_event_loop()
    f = loop.create_future()

    future_add_done_callback(f, lambda x: print(x))

# Generated at 2022-06-24 08:19:35.861841
# Unit test for function run_on_executor
def test_run_on_executor():


    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def bar(self, arg):
            return arg

        @run_on_executor()
        def baz(self, arg):
            return arg

        @run_on_executor(executor="_thread_pool")
        def quux(self, arg):
            return arg

        def quuux(self, arg):
            return arg


    foo = Foo()

    for meth in (foo.bar, foo.baz):
        assert is_future(meth(42))
        assert meth(42).result() == 42

    foo._thread_pool = dummy_executor
    assert is_future(foo.quux(42))
    assert foo.quux(42).result() == 42


# Generated at 2022-06-24 08:19:42.200675
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def inner():
        future = Future()
        future_set_exc_info(future, sys.exc_info())
        # Ensure the exception made it through to the future
        try:
            await future
        except ValueError:
            pass
        else:
            raise AssertionError("future did not contain exception")

    IOLoop.current().run_sync(inner)


# Generated at 2022-06-24 08:19:48.241072
# Unit test for function run_on_executor
def test_run_on_executor():
    class A(object):
        executor = dummy_executor

        @run_on_executor
        def func(self):
            return 1

        @run_on_executor(executor="_other_executor")
        def func2(self):
            return 2

    a = A()
    a._other_executor = dummy_executor
    assert a.func() == a.func2() == 1

# Generated at 2022-06-24 08:19:56.246525
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # noqa: E302,E999
    import tornado.testing
    from tornado.concurrent import Future
    try:
        # asyncio.Future was added in 3.4, but fakes were available
        # in earlier tornado versions.
        from tornado.platform.asyncio import to_asyncio_future
    except ImportError:
        to_asyncio_future = None
        
    class SetExcInfoTest(tornado.testing.AsyncTestCase):
        def test_set_exc(self):
            exc_type = ValueError
            exc_info = (exc_type, exc_type("test"), None)
            future = Future()
            future_set_exc_info(future, exc_info)
            future_add_done_callback(future, self.stop)
            exc = self.wait()[1]
            self

# Generated at 2022-06-24 08:20:07.826203
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from concurrent import futures
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()

    io_loop = asyncio.get_event_loop()

    # Test Future
    future = Future()
    io_loop.run_until_complete(future)
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    io_loop.run_until_complete(future)
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

    # Test futures.Future
    future = futures

# Generated at 2022-06-24 08:20:11.226231
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    import mock # type: ignore
    from tornado.stack_context import StackContext
    future = Future()
    # Use the stack context to get the future set_exception function
    with StackContext(
        lambda: mock.Mock()
    ) as context_manager:
        future_add_done_callback(future, lambda future: context_manager.set_exception(Exception("test_exception")))
        future.set_exception(Exception("test_exception"))
    # Make sure the set_exception function was called
    assert context_manager.set_exception.called is True

# Generated at 2022-06-24 08:20:12.722586
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
  dummy_executor.submit(lambda x: x+1, 1)

# Generated at 2022-06-24 08:20:23.977586
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()

    def f():
        time.sleep(0.01)
        return 5

    def f2():
        time.sleep(0.01)
        raise Exception("exception")

    def f3():
        time.sleep(0.01)

    def check_future(fut):
        if isinstance(fut, Future):
            io_loop.add_future(fut, lambda f: check_future(f))
            return
        # concurrent.futures.Future
        assert isinstance(fut, futures.Future)
        assert fut.result() == 5

    # Test with a concurrent.futures.Future
    c_fut = dummy_executor.submit(f)
    t

# Generated at 2022-06-24 08:20:26.499365
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError('foo'))



# Generated at 2022-06-24 08:20:32.347311
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    callback_args = []

    def callback(f):
        callback_args.append(f)

    f = Future()
    future_add_done_callback(f, callback)
    assert callback_args == []
    assert f.done() == False

    f.set_result(None)
    assert callback_args == [f]
    assert f.done() == True

    f = Future()
    f.set_result(None)
    future_add_done_callback(f, callback)
    assert callback_args == [f, f]
    assert f.done() == True

    f = Future()
    f.set_exception(RuntimeError())
    future_add_done_callback(f, callback)
    assert callback_args == [f, f, f]
    assert f.done() == True


# Generated at 2022-06-24 08:20:33.185686
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:20:43.076334
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    # Test that this does not cause an exception when called from
    # within a `Future` callback. This can happen if `@gen.coroutine`
    # calls code that takes a callback argument (e.g. `IOStream.read_until`);
    # the callback might raise an exception, and the exception would
    # propagate to the future that was yielded by `gen.coroutine`. This
    # is documented behavior, but if the exception isn't caught somewhere
    # else it will trigger the `IOLoop.handle_callback_exception` chain.

    @gen.coroutine
    def read_until(stream, delimiter):
        # type: (IOStream, bytes) -> Future[bytes]
        future = Future()
        stream.read_until(delimiter, future.set_result)

# Generated at 2022-06-24 08:20:53.141467
# Unit test for function chain_future
def test_chain_future():
    import threading
    import time

    def target(a, b, c, d):
        time.sleep(0.5)
        a.set_result(b.result() * d.result())
        c.set_result(10)

    f1 = Future()
    f2 = Future()
    f3 = Future()
    f4 = Future()

    f5 = Future()

    f1.set_result(2)
    f2.set_result(3)
    f4.set_result(5)

    threading.Thread(target=target, args=(f5, f1, f4, f2)).start()
    chain_future(f4, f5)

    ioloop = IOLoop.current()
    ioloop.run_sync(f5.result)

    assert f5.result

# Generated at 2022-06-24 08:20:55.579589
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa: F811
    try:
        raise ReturnValueIgnoredError('err_msg')
    except ReturnValueIgnoredError as e:
        assert e.__str__() == 'err_msg'

# Generated at 2022-06-24 08:20:56.342890
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:20:58.173679
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    @run_on_executor
    def get_result():
        return 42

    async def test_future_add_done_callback():
        assert await get_result() == 42

    from tornado.ioloop import IOLoop

    IOLoop.current().run_sync(test_future_add_done_callback)

# Generated at 2022-06-24 08:20:59.859025
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    future = Future()
    future_set_exc_info(future, sys.exc_info())

# Generated at 2022-06-24 08:21:07.286753
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest

    future = futures.Future()
    exc_info = (BaseException, BaseException("test"), None)
    try:
        raise BaseException("test")
    except BaseException:
        future_set_exc_info(future, sys.exc_info())

    class Foo(unittest.TestCase):
        def test(self):
            self.assertEqual(future.exception(), exc_info[1])

    Foo().test()
    print("done")


if __name__ == "__main__":
    test_future_set_exc_info()

# Generated at 2022-06-24 08:21:17.671461
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from tornado.ioloop import IOLoop
    import unittest

    _executor = dummy_executor

    class A(object):
        executor = _executor


# Generated at 2022-06-24 08:21:19.897250
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "RESULT")
    assert f.cancelled()



# Generated at 2022-06-24 08:21:29.793992
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    def test_func_a(a):
        return a + 5

    def test_func_b(a, b):
        return a + b

    test_a = dummy_executor.submit(test_func_a, 4)
    test_b = dummy_executor.submit(test_func_b, 4, 5)
    assert test_a.result() == 9
    assert test_b.result() == 9

# Generated at 2022-06-24 08:21:33.194522
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    # No-op - previously a unit test, now just a type check.
    # This function must remain because it is import by other unit
    # tests.
    pass

# Generated at 2022-06-24 08:21:41.728564
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    import textwrap
    try:
        raise ReturnValueIgnoredError(
            "Test",
            stack_info=textwrap.dedent(
                """\
                Traceback (most recent call last):
                  File "example.py", line 7, in function
                    function(10)
                  File "example.py", line 4, in function
                    return future_set_result_unless_cancelled(future, x * 2)
                  File "future.py", line 592, in future_set_result_unless_cancelled
                    raise _ReturnValueIgnoredError('Dummy')
                ReturnValueIgnoredError: Dummy
                """
            ),
        )
    except Exception as exc:
        assert exc.stack_info.startswith("Traceback")

# Generated at 2022-06-24 08:21:47.875597
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()

    def set_result(f: Future) -> None:
        f.set_result(42)

    # set_result should not call future_add_done_callback since f
    # is already done. Instead, f will call set_result immediately.
    future_add_done_callback(f, set_result)
    assert f.result() == 42

# Generated at 2022-06-24 08:21:50.676905
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda : 2) == 2


# Generated at 2022-06-24 08:21:56.624642
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())
    assert is_future(asyncio.Future())
    assert is_future(futures.Future())



# Generated at 2022-06-24 08:21:57.410636
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True == True

# Generated at 2022-06-24 08:22:00.523850
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(range, 0)
    assert future.result() == range(0)



# Generated at 2022-06-24 08:22:01.595761
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)

# Generated at 2022-06-24 08:22:08.263709
# Unit test for function chain_future
def test_chain_future():
    import itertools

    for one, two in itertools.product((futures.Future, Future), repeat=2):
        f1 = one()
        f2 = two()
        chain_future(f1, f2)
        f1.set_result("future result")
        assert f2.result() == "future result"
        assert f2.done()

# Generated at 2022-06-24 08:22:09.314277
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x = DummyExecutor()
    x.shutdown()

# Generated at 2022-06-24 08:22:20.980354
# Unit test for function run_on_executor
def test_run_on_executor():
    import os
    import tornado.platform.asyncio
    import tornado.testing
    import unittest

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.io_loop = tornado.platform.asyncio.AsyncIOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(10)

        def test_run_on_executor(self):
            # This is an integration test with the thread pool executor.
            # The two don't fit together as cleanly as we'd like.
            # The test doesn't work on Windows because the thread pool
            # executor uses threads.
            if os.name == 'nt':
                return


# Generated at 2022-06-24 08:22:21.696505
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:22:22.892705
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:26.828307
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn(x: int, y: int) -> int:
        return x + y

    res = dummy_executor.submit(fn, 1, y=2)
    print(res.result())
    print(res.done())


test_DummyExecutor_submit()

# Generated at 2022-06-24 08:22:34.641197
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import to_asyncio_future

    class ChainFutureTest(AsyncTestCase):
        def setUp(self) -> None:
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(2)

        @run_on_executor(executor="executor")
        def finish_immediately(self) -> None:
            pass

        @run_on_executor(executor="executor")
        def finish_later(self) -> None:
            def callback() -> None:
                self.result = "finished"

            io_loop = self.io_loop
            io_loop.add_timeout(io_loop.time() + 0.1, callback)


# Generated at 2022-06-24 08:22:37.622823
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(x: int) -> int:
        return x * x

    future = dummy_executor.submit(func, 2)
    assert future.result() == 4

# Generated at 2022-06-24 08:22:46.689123
# Unit test for function run_on_executor
def test_run_on_executor():
    import types
    import unittest

    class Test(object):
        def __init__(self):
            self._executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def _block(self, x, y):
            return x + y

        def block(self, x, y):
            # type: (Any, Any) -> Future
            future = self._block(x, y)
            assert isinstance(future, Future)
            assert isinstance(future, futures.Future)
            return future

    t = Test()
    f = t.block(1, 2)
    result = f.result()
    assert result == 3



# Generated at 2022-06-24 08:22:49.941725
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:23:01.528839
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()
    fut1 = Future()
    fut2 = Future()
    chain_future(fut1, fut2)
    assert loop.is_running()

    fut1.set_result(42)
    assert fut2.result() == 42
    assert not loop.is_running()

    # Test chaining a concurrent.futures.Future (actually a Future in disguise)
    # to an asyncio.Future
    fut3 = asyncio.get_event_loop().run_in_executor(dummy_executor, lambda: 42)
    fut4 = Future()
    chain_future(fut3, fut4)
    assert fut4.result() == 42

    # Test that cancel propagates from fut2 to fut1
    fut1 = Future()
    fut2 = Future()


# Generated at 2022-06-24 08:23:06.569941
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import sys
    if "tornado.test.util" in sys.modules:
        return

    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 5

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled()

# Generated at 2022-06-24 08:23:10.947005
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception('test')
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    # Check that the future was set with the correct exception.
    assert isinstance(future.exception(), Exception)
    assert future.exception().args[0] == 'test'

# Generated at 2022-06-24 08:23:17.936224
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor
            self.other_executor = dummy_executor

    def sync_func(a, b, c=None):
        return a - b, c

    f = Foo()
    f.executor = unittest.mock.Mock()
    f.other_executor = unittest.mock.Mock()

    @gen_test
    def test_basic():
        AsyncIOMainLoop().install()
        yield f.executor.submit.return_value.result()
        f.executor.submit.assert_called_with

# Generated at 2022-06-24 08:23:23.104486
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.concurrent import Future

    future = Future()
    try:
        raise ValueError("test future_set_exc_info")
    except:
        future_set_exc_info(future, sys.exc_info())
    try:
        future.result()
        raise Exception("should have raised exception")
    except ValueError:
        pass



# Generated at 2022-06-24 08:23:25.324825
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    """Unit test for method shutdown of class DummyExecutor."""
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:23:29.596057
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummyExecutor = DummyExecutor()
    dummyExecutor.submit(str, 'abc')
    dummyExecutor.shutdown()


# Generated at 2022-06-24 08:23:31.385963
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:23:32.271680
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # TODO: implement this!
    pass

# Generated at 2022-06-24 08:23:40.844540
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.util import raise_exc_info

    future = Future()
    try:
        raise ZeroDivisionError
    except ZeroDivisionError:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    future = Future()
    future_set_exc_info(future, (ZeroDivisionError, None, None))
    assert isinstance(future.exception(), ZeroDivisionError)


try:
    import asyncio
except ImportError:
    # Python 3.5, mypy 0.730
    Future.get_loop = None  # type: ignore
else:
    Future.get_loop = lambda _: asyncio.get_event_loop()  # noqa: E731

# Generated at 2022-06-24 08:23:47.952241
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def make_future():
        f = Future()
        # Cancel it immediately to simulate a timing window in which a caller
        # does not see a cancelled Future.
        f.cancel()
        return f

    f1 = make_future()
    f2 = make_future()

    future_set_exception_unless_cancelled(f1, Exception())
    future_set_exception_unless_cancelled(f2, Exception())

# Generated at 2022-06-24 08:23:54.147218
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, True)
    assert f.done()
    assert f.result()

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, True)
    assert f.done()
    assert f.cancelled()

# Generated at 2022-06-24 08:24:00.242357
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)

    assert future.result() == 5

    future = Future()
    future.cancel()

    future_set_result_unless_cancelled(future, 5)

    assert future.result() is None

# Generated at 2022-06-24 08:24:01.262169
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("foo")


# Generated at 2022-06-24 08:24:03.287078
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    future = DummyExecutor().submit(lambda: 'test')
    assert future.result() == 'test'

# Generated at 2022-06-24 08:24:13.924875
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def test_future_set_exception_unless_cancelled(self):
            future = Future()
            future_set_exception_unless_cancelled(future, ValueError('testing'))
            with self.assertRaises(ValueError):
                yield future

    async def async_test_future_set_exception_unless_cancelled():
        future = Future()
        future_set_exception_unless_cancelled(future, ValueError('testing'))
        with pytest.raises(ValueError):
            await future

    MyTestCase().test_future_set_exception_unless_cancelled()

# Generated at 2022-06-24 08:24:17.551488
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def _add_done_callback(future):
        future._done_callback = lambda: True  # type: ignore
    future_add_done_callback = _add_done_callback

    future = Future()  # type: Future
    future_add_done_callback(future, None)
    future_set_exception_unless_cancelled(future, Exception(""))
    assert not future.cancelled()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception(""))

# Generated at 2022-06-24 08:24:23.257244
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    f = Future()  # type: Future[str]
    try:
        raise ValueError
    except ValueError:
        try:
            future_set_exc_info(f, sys.exc_info())
        except asyncio.InvalidStateError:
            pass  # Success!
        else:
            raise Exception("didn't raise")
    else:
        raise Exception("didn't catch")

# Generated at 2022-06-24 08:24:32.256154
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func():
        pass
    
    test = dummy_executor.submit(func, 1, 2)
    assert isinstance(test, futures.Future)
    test = dummy_executor.submit(func)
    assert isinstance(test, futures.Future)
    test = dummy_executor.submit(func, 1, *[2])
    assert isinstance(test, futures.Future)
    test = dummy_executor.submit(func, *[1])
    assert isinstance(test, futures.Future)


# Generated at 2022-06-24 08:24:35.897230
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(arg):
        callback.called = True
    future = Future()
    callback.called = False
    future_add_done_callback(future, callback)
    assert callback.called == False
    future.set_result(1)
    assert callback.called == True



# Generated at 2022-06-24 08:24:37.901494
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()



# Generated at 2022-06-24 08:24:40.980995
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:24:52.350850
# Unit test for function chain_future
def test_chain_future():  # noqa: F811
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result("test")
    loop.run_sync(lambda: f2)
    assert f2.result() == "test"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(Exception("inner"))
    with pytest.raises(Exception, match="inner"):
        loop.run_sync(lambda: f2)

# Generated at 2022-06-24 08:24:55.716924
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(None)

# Generated at 2022-06-24 08:24:59.633671
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "test_future_set_result_unless_cancelled")
    assert f.cancelled()
    assert f.exception() == None

# Generated at 2022-06-24 08:25:06.696311
# Unit test for function chain_future
def test_chain_future():
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    # simplest case
    async def async_foo():
        return 1

    @run_on_executor
    def blocking_foo():
        return 1

    assert chain_future(async_foo(), blocking_foo()) == blocking_foo()

    # IOLoop.add_future
    chain_future(async_foo(), to_tornado_future(async_foo()))

    # Future.add_done_callback
    chain_future(async_foo(), to_asyncio_future(async_foo()))



# Generated at 2022-06-24 08:25:10.290178
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("foo")
    except ReturnValueIgnoredError as e:
        assert str(e) == "foo", str(e)

# Generated at 2022-06-24 08:25:15.870387
# Unit test for function chain_future
def test_chain_future():
    import logging
    import unittest
    import random
    import time

    log = logging.getLogger()
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    log.addHandler(ch)

    def sleep(secs):
        def func():
            t=time.time()
            while time.time() - t < secs:
                pass
            return secs
        return func

    def fail():
        if random.random() > 0.5:
            log.info("fail() exception")
            raise Exception("FAIL")
        else:
            log.info("fail() return str")
            return "FAILED"

    def good():
        log.info("good()")
        return "OK"


# Generated at 2022-06-24 08:25:19.705371
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    future = futures.Future()
    future.cancel()
    # No exception will be raised
    future_set_exception_unless_cancelled(future, RuntimeError())


test_future_set_exception_unless_cancelled()

# Generated at 2022-06-24 08:25:24.208604
# Unit test for function is_future
def test_is_future():
    def is_future(f: Any) -> bool:
        return isinstance(f, futures.Future)

    def is_future2(f: Any) -> bool:
        return isinstance(f, futures.Future)

    assert is_future(Future())
    assert is_future2(Future())
    assert not is_future(Future())

# Generated at 2022-06-24 08:25:34.552913
# Unit test for function chain_future
def test_chain_future():
    def assert_future_state(f, done, result, exception):
        assert f.done() == done
        if f.done():
            if not exception:
                assert f.result() == result
            else:
                assert f.exception() == exception

    f1 = Future()
    f2 = Future()
    f3 = Future()
    f4 = Future()

    # These two were previously used in the real implementation but
    # are no longer.
    assert not f1.add_done_callback(lambda f: None)
    assert not f1.add_done_callback(lambda f: None)

    chain_future(f1, f2)
    assert_future_state(f1, done=False, result=_NO_RESULT, exception=None)

# Generated at 2022-06-24 08:25:45.195422
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def is_done(future: Future) -> bool:
        return future.done()

    future = dummy_executor.submit(lambda: 1)
    assert future.done()
    assert future.result() == 1

    future = dummy_executor.submit(lambda x: x*2, 10)
    assert future.done()
    assert future.result() == 20

    future = dummy_executor.submit(lambda x, y: x + y, 10, 20)
    assert future.done()
    assert future.result() == 30

    future = dummy_executor.submit(lambda: None)
    assert future.done()
    assert future.result() == None

    future = dummy_executor.submit(lambda: 1/0)
    assert future.done()
    assert isinstance(future.exception(), ZeroDivisionError)



# Generated at 2022-06-24 08:25:46.062838
# Unit test for function is_future
def test_is_future():
    Future()


# Generated at 2022-06-24 08:25:52.160300
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: no cover
    # type: () -> None
    f = Future()
    results = []

    def cb(future):
        results.append(future.result())
        future_add_done_callback(f, cb)

    future_add_done_callback(f, cb)

    for i in range(5):
        assert not results
        f.set_result(i)
        assert results == list(range(i + 1))



# Generated at 2022-06-24 08:25:53.499775
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(dummy_executor)


# Generated at 2022-06-24 08:26:01.303346
# Unit test for function chain_future
def test_chain_future():
    def future_set_result(future, value):
        future.set_result(value)

    def future_set_exception(future, e):
        future.set_exception(e)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    future_set_result(f1, 42)
    assert f2.result() == 42
    e = Exception()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    future_set_exception(f1, e)
    assert f2.exception() is e


DEFAULT_TIMEOUT = object()



# Generated at 2022-06-24 08:26:06.766954
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():  # pragma: no cover
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1
    future1 = Future()
    future1.cancel()
    future_set_result_unless_cancelled(future1, 1)
    assert future1.done()
    assert future1.result() is None



# Generated at 2022-06-24 08:26:08.565164
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    if hasattr(DummyExecutor, '__init__'):
        DummyExecutor.__init__
        assert True


# Generated at 2022-06-24 08:26:11.691503
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-24 08:26:19.475918
# Unit test for function run_on_executor
def test_run_on_executor():
    class A:
        def __init__(self) -> None:
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def add(self, a: int, b: int) -> int:
            self.executor.submit(lambda: None)
            return a + b

    @gen.coroutine
    def check():
        a = A()
        assert isinstance((yield a.add(1, 2)), int)

    IOLoop.current().run_sync(check)

# Generated at 2022-06-24 08:26:25.985515
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Test pass 1
    dummy_executor = DummyExecutor()
    fut = dummy_executor.submit(sum, 1, 2)
    assert fut.result() == 3
    # Test pass 2
    fut = dummy_executor.submit(sum, 1, 2, 3)
    assert fut.result() == 6
    # Test pass 3
    async_fut = dummy_executor.submit(asyncio.sleep, 0.1)
    assert async_fut.result() is None



# Generated at 2022-06-24 08:26:29.951708
# Unit test for function run_on_executor
def test_run_on_executor():
    class a:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

    A = a()
    result = A.foo(1, 2)
    assert result.result() == 3

# Generated at 2022-06-24 08:26:37.662768
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    async def test(test_future):
        # type: (Future[Any]) -> None
        set_result = test_future.set_result
        has_callbacks = test_future.add_done_callback

        # Test add_done_callback
        tc1 = futures.Future()
        tc2 = futures.Future()
        t1 = futures.Future()
        t1.set_result(None)
        t2 = futures.Future()
        t2.set_result(None)

        tc1.add_done_callback(lambda x: t1)
        future_add_done_callback(tc2, lambda x: t2)

        # Test concurrent.futures.Future
        f1 = futures.Future()
        f2 = futures.Future()
        f3 = futures.Future()

# Generated at 2022-06-24 08:26:43.775956
# Unit test for function run_on_executor
def test_run_on_executor():
    def test_executor():
        f = Future()
        chain_future(f, Future())
        return f

    class Foo(object):
        executor = test_executor

        @run_on_executor
        def foo(self):
            return 42

    foo = Foo()
    foo.foo().add_done_callback(lambda f: f.result())

# Generated at 2022-06-24 08:26:56.217119
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.ioloop import IOLoop
    from tornado.testing import gen_test, AsyncTestCase

    def set_result_on_next_tick(fut: Future[int]) -> None:
        IOLoop.current().add_callback(future_set_result_unless_cancelled, fut, 42)

    @gen_test
    async def test_futures(self) -> None:
        f = Future()
        future_add_done_callback(f, self.stop)
        set_result_on_next_tick(f)
        self.assertEqual(await f, 42)

        c = Future()
        c.cancel()
        future_add_done_callback(c, self.stop)
        set_result_on_next_tick(c)

# Generated at 2022-06-24 08:26:59.661703
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

# Generated at 2022-06-24 08:27:07.718398
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.testing
    import tornado.gen
    import asyncio

    async def slow_operation(callback: Callable[..., None]) -> None:
        await asyncio.sleep(0.01)
        callback()

    @tornado.testing.gen_test
    async def test_future_add_done_callback_tornado_future():
        future = Future()
        future_add_done_callback(future, callback)
        await slow_operation(future.set_result)
        self.assertTrue(future.done())
        await future

    @tornado.testing.gen_test
    async def test_future_add_done_callback_concurrent_future():
        future = futures.Future()
        future_add_done_callback(future, callback)
        future.set_result(None)

# Generated at 2022-06-24 08:27:09.872830
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future("Not a Future")

# Generated at 2022-06-24 08:27:12.697620
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    """Test of method submit of class DummyExecutor"""
    test_future = DummyExecutor().submit(lambda: 42)
    assert test_future.result() == 42
test_DummyExecutor_submit()


# Generated at 2022-06-24 08:27:13.344079
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:27:15.522958
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    E = DummyExecutor()
    assert hasattr(E, 'shutdown')
    assert hasattr(E.shutdown, '__call__')

# Generated at 2022-06-24 08:27:19.159239
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    sync_future = futures.Future()
    asyncio_future = Future()
    future_set_exc_info(sync_future, sys.exc_info())
    future_set_exc_info(asyncio_future, sys.exc_info())

    # TODO(bquinlan): Add assert statements.
    # Currently, this function cannot be tested because both
    # sync_future and asyncio_future will raise an exception.

# Generated at 2022-06-24 08:27:30.947750
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.testing import AsyncTestCase, gen_test

    class MyFuture(futures.Future):
        def __init__(self, is_done=False):
            super(MyFuture, self).__init__()
            self.callback_result = None
            if is_done:
                self.set_result(None)

        def add_done_callback(self, fn):
            self.callback_result = fn

    class UnitTestFuture(AsyncTestCase):
        @gen_test
        def test_future_add_done_callback(self):
            f = MyFuture()
            future_add_done_callback(f, lambda f: f.set_result("test"))
            self.assertEqual(f.callback_result(f), "test")

    test_future_add_done_callback()

_F