

# Generated at 2022-06-24 08:17:42.024407
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    dummy_executor = DummyExecutor()
    # Define a function
    def test_function(x, y):
        # type: (int, int) -> int
        return x + y

    result_future = dummy_executor.submit(test_function, 1, 1)
    # The result_future should be a future
    assert isinstance(result_future, futures.Future)
    # The result_future should be done
    assert result_future.done()
    # The result of result_future should be 2
    assert result_future.result() == 2
    # The number of threads in the pool should be 0
    assert dummy_executor._max_workers == 0

# Generated at 2022-06-24 08:17:44.225129
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, None)
    assert f.result() is None



# Generated at 2022-06-24 08:17:48.133094
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # Constructor
    de = DummyExecutor()

    # Submit
    assert de.submit(lambda: 1).result() == 1

    assert de.submit(lambda: 1 / 0).exception() is not None

    # Shutdown
    de.shutdown()


# Generated at 2022-06-24 08:17:49.756858
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert DummyExecutor().submit(int, "3")


# Generated at 2022-06-24 08:17:53.040163
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda: 42).result() == 42
    assert dummy_executor.submit(lambda: None).result() is None



# Generated at 2022-06-24 08:18:05.344233
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import time

    future = None

    def cb(f: Union[futures.Future, Future]) -> None:
        assert f is future
        assert f.result() is None

    def set_future(_) -> None:
        nonlocal future
        future = asyncio.Future()
        # make sure the callback isn't run until we return
        time.sleep(0.1)

    def set_future_exception(_) -> None:
        nonlocal future
        future = asyncio.Future()
        future_set_exception_unless_cancelled(future, Exception())

    io_loop = IOLoop.current()
    io_loop.add_callback(set_future)
    io_loop.add_callback(set_future_exception)
    for i in range(2):
        future_add_done_

# Generated at 2022-06-24 08:18:07.585060
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:18:18.214372
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    class MyThread(threading.Thread):
        def run(self):
            self.result = future_result(self.future)
            self.exception = future_exception(self.future)

    class F(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(4)

        def test_example_usage(self):
            @run_on_executor
            def f(x, y):
                time.sleep(100)
                return x + y

            fut = f(1, 2)
            self.assertEqual(future_result(fut), 3)


# Generated at 2022-06-24 08:18:26.346193
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class MyException(Exception):
        def __init__(self, foo):
            Exception.__init__(self, foo)

    f = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        future_set_exc_info(f, sys.exc_info())
    f.add_done_callback(lambda f: f.exception())

    f = Future()
    try:
        raise MyException("foo")
    except MyException:
        future_set_exc_info(f, sys.exc_info())
    f.add_done_callback(lambda f: f.exception())



# Generated at 2022-06-24 08:18:31.690572
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo:
        executor = dummy_executor

        @run_on_executor
        def lol(self, x):
            return x + 42

    foo = Foo()
    assert foo.lol(0).result() == 42
    assert foo.lol(1).result() == 43
    assert foo.lol(2).result() == 44


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 08:18:36.974550
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda x, y: 0, 0, 0)
    assert future.result() == 0
    future = executor.submit(lambda x, y: x / y, 1.0, 0.0)
    assert future.exception().__class__ == ZeroDivisionError


# Generated at 2022-06-24 08:18:44.248405
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, "value")
    assert future.done()
    assert not future.cancelled()
    assert "value" == future.result()

    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, "ignored_value")
    assert future.cancelled()
    assert not future.exception()
    assert not future.done()

# Generated at 2022-06-24 08:18:45.945781
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    ex = ValueError()
    try:
        raise ex
    except:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() == ex



# Generated at 2022-06-24 08:18:47.409692
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    class T:
        def __init__(self):
            self.executor = DummyExecutor()

    t = T()
    t.executor.shutdown()

# Generated at 2022-06-24 08:18:57.951823
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    f = Future()  # type: Future[str]
    f.set_result("a")
    assert f.done()
    assert f.result() == "a"
    f = Future()  # type: Future[str]
    f.set_exception(Exception("b"))
    assert f.done()
    try:
        f.result()
        assert False
    except Exception as e:
        assert e.args[0] == "b"
        
    expected_exception = None  # type: Optional[Exception]
    try:
        dummy_executor.submit(lambda: 0 / 0)
    except Exception as e:
        expected_exception = e

    assert type(expected_exception) == ZeroDivisionError
    assert str(expected_exception) == "division by zero"
    
    f = dummy

# Generated at 2022-06-24 08:19:07.755564
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # type: ignore
    # type: () -> None
    """Tests that future_set_exc_info() behaves properly with
    set_exception() vs. set_exception(None), and can be used to
    unittest the difference between `asyncio.Future` and the extensions
    in older versions of Tornado that make the traceback more useful
    in Python 2.
    """
    e = ValueError("test error")
    f = concurrent.futures.Future()
    future_set_exc_info(f, sys.exc_info())
    assert f.exception() is e
    # This isn't necessarily correct behavior in all cases, but it's
    # what we have for now, so make sure future_set_exc_info doesn't
    # change it.
    f = concurrent.futures.Future()
    f

# Generated at 2022-06-24 08:19:14.043932
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise ValueError
    except:
        exc_info = sys.exc_info()

    class DummyFuture(Future):
        def set_exception(self, exc):
            assert exc is exc_info[1]

    future = DummyFuture()
    future_set_exc_info(future, exc_info)



# Generated at 2022-06-24 08:19:21.461858
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado import gen

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop()
            self.async_future = None

        def tearDown(self):
            self.executor.shutdown()
            self.async_future.cancel()
            self.io_loop.close()
            self.io_loop = None

        def set_async_result(self, result):
            self.async_future.set_result(result)

        def set_async_exception(self, exception):
            self.async_future.set_exception(exception)


# Generated at 2022-06-24 08:19:22.684749
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    """Add test case.
    """
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:19:27.519360
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with DummyExecutor() as e:
        f = e.submit(lambda: True)
        assert f.result()

    t = DummyExecutor()
    f = t.submit(lambda: True)
    assert f.result()
    t.shutdown()

# Generated at 2022-06-24 08:19:33.925743
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # from tornado.concurrent import future_set_result_unless_cancelled
    # x = future_set_result_unless_cancelled(1,1)
    # type(x)
    # print(x)
    # from tornado.concurrent import DummyExecutor
    # test = DummyExecutor()
    # type(test)
    # print(test)
    # test.submit(1,1,1)
    # test.shutdown()
    assert True


# Generated at 2022-06-24 08:19:41.140969
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # We do not use @gen_test because it triggers the very warning we
    # wish to unit test.
    import unittest.mock

    with unittest.mock.patch('tornado.util.log_function_deprecation'):
        event_loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(event_loop)
            future = asyncio.Future()
            callback_arg_future = unittest.mock.Mock()
            future_add_done_callback(future, callback_arg_future)
            future.set_result(42)
            event_loop.run_until_complete(future)
            callback_arg_future.assert_called_with(future)
        finally:
            event_loop.close()



# Generated at 2022-06-24 08:19:51.093364
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def make_future():
        return Future()

    def finish_future(future, exc_info=None):
        # If the Future was already done, don't re-set its exception
        # and check that future_set_exc_info is a no-op.
        if future.done():
            return

        if exc_info is None:
            exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)

    # Test a future that hasn't yet been set
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    future = make_future()
    finish_future(future, exc_info)
    assert future.done()
    assert future.exception() is exc_info[1]

    # Test a future that

# Generated at 2022-06-24 08:19:52.554168
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "OK")
    assert future.cancelled()

# Generated at 2022-06-24 08:19:55.287142
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Test submit of DummyExecutor

    # Test a normal case
    result = None
    def callable(num:int, k:int=10)->int:
        return num * k

    # Call submit of DummyExecutor
    future = dummy_executor.submit(callable, 1, k=2)
    # Call result of Future
    future.result()

# Generated at 2022-06-24 08:19:57.866977
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(True)

# Generated at 2022-06-24 08:20:08.998790
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Test of three scenarios:
    # 1. Successful execution
    # 2. Exception in executing function
    # 3. Future cancellation
    #
    # Under all three scenarios, the DummyExecutor is expected to execute
    # the function immediately, and returns a completed Future object.
    #
    # For scenario 1 and 2, the returned Future is expected to be set to
    # either the result or exception of the execution.
    #
    # For scenario 3, the returned Future is expected to be marked as
    # cancelled.

    # For scenario 1
    def test_func():
        return 1

    future = dummy_executor.submit(test_func)
    assert future.done()
    assert future.result() == 1

    # For scenario 2
    def test_func2():
        raise ValueError("x")

    future = dummy_exec

# Generated at 2022-06-24 08:20:12.304464
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        x = 1 / 0
    except ZeroDivisionError:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None
    assert f.exception() is not True
    assert f.exception() is not False
    assert isinstance(f.exception(), ZeroDivisionError)

# Generated at 2022-06-24 08:20:13.662884
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test = AsyncIOMock()
    executor = DummyExecutor()
    executor.submit(f1, test)
    res = test.test()
    print(res)


# Generated at 2022-06-24 08:20:22.129892
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    io_loop = IOLoop()
    _ = io_loop

    future1 = Future()
    future2 = Future()

    future1.set_result(42)
    chain_future(future1, future2)
    io_loop.run_sync(future2.result)  # this will not raise.

    future1.set_result("foo")
    future2 = Future()
    chain_future(future1, future2)
    io_loop.run_sync(future2.result)

# Generated at 2022-06-24 08:20:32.305645
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest
    from concurrent.futures import Future
    from tornado.ioloop import IOLoop, TimeoutError


    class FutureSetExcInfoTest(unittest.TestCase):
        def test_future_set_exc_info(self):
            future = Future()
            self.assertFalse(future.done())


            def set_future_exc_info():
                try:
                    1 / 0
                except ZeroDivisionError:
                    future_set_exc_info(future, sys.exc_info())


            IOLoop.current().add_callback(set_future_exc_info)
            future.result()
            self.assertTrue(future.done())


        def test_future_set_exc_info_after_cancelled(self):
            future = Future()

# Generated at 2022-06-24 08:20:33.111762
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass


# Generated at 2022-06-24 08:20:38.558948
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = Future()
    dummy_executor.submit(lambda: 1, future)
    assert future.result() == 1

    future = Future()
    dummy_executor.submit(lambda: 1/0, future)
    assert future.exception() != None

    future = Future()
    dummy_executor.submit(lambda: future, future)
    assert future.result() == future

    future = Future()
    dummy_executor.submit(future.set_result, 1, future)
    assert future.result() == 1

    future = Future()
    dummy_executor.submit(future.set_exception, ZeroDivisionError, future)
    assert future.exception() == ZeroDivisionError



# Generated at 2022-06-24 08:20:49.015716
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    future = Future()  # type: Future[int]
    future.set_result(42)
    future_add_done_callback(future, lambda f: f.set_result(3))
    assert future.result() == 3

    future = Future()  # type: Future[int]
    future.set_result(42)
    future_add_done_callback(future, lambda f: f.set_result(3))
    assert future.result() == 3

    future = Future()
    future.set_result(42)
    future_add_done_callback(future, lambda f: f.set_result(3))
    assert future.result() == 3



# Generated at 2022-06-24 08:20:58.246568
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop
    import contextlib
    from logging import getLogger

    with contextlib.ExitStack() as stack:
        loop = stack.enter_context(IOLoop())
        logger = stack.enter_context(
            getLogger().test_logger(app_log.name, level="ERROR")
        )
        future = Future()
        assert not future.cancelled()
        future_set_exception_unless_cancelled(future, ValueError())
        assert logger.handler.records == []

        future = Future()
        future.cancel()
        assert future.cancelled()
        future_set_exception_unless_cancelled(future, ValueError())
        assert len(logger.handler.records) == 1

# Generated at 2022-06-24 08:20:59.308331
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    future = DummyExecutor().submit(lambda x:x, "test")
    print(future.done())

# Generated at 2022-06-24 08:21:04.681160
# Unit test for function chain_future
def test_chain_future():
    class Future(object):
        def __init__(self):
            self._result = None
            self._exc_info = None
            self._callbacks = []
            self._done = False

        def result(self):
            return self._result

        def exception(self):
            return self._exc_info[1] if self._exc_info else None

        def exc_info(self):
            return self._exc_info

        def add_done_callback(self, callback):
            assert not self._done
            self._callbacks.append(callback)

        def set_result(self, result):
            assert not self._done
            self._result = result
            self._done = True
            for callback in self._callbacks:
                callback(self)

        def set_exception(self, exception):
            assert not self._

# Generated at 2022-06-24 08:21:06.842524
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def foo():
        return 1
    dummy_executor.submit(foo)



# Generated at 2022-06-24 08:21:08.275523
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    with ReturnValueIgnoredError() as e:  # type: ignore
        print(e)

# Generated at 2022-06-24 08:21:13.411025
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future("foo")
    assert not is_future(5)
    assert not is_future({})
    assert is_future(Future())
    assert not is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(futures.Future())

# Generated at 2022-06-24 08:21:15.411861
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    with pytest.raises(TypeError):
        ReturnValueIgnoredError()

# Generated at 2022-06-24 08:21:16.288696
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:21:22.641204
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class DummyFuture(object):
        result = None
        exc_info = None

    if tornado.version_info >= (5, 0):
        orig_future = Future()
    else:
        orig_future = DummyFuture()
    future = ReturnValueIgnoredError(orig_future)
    nt.assert_equal(future.args, (orig_future,))
    nt.assert_equal(future.orig_future, orig_future)
    nt.assert_true(str(future))



# Generated at 2022-06-24 08:21:24.877358
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:21:31.950875
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    async def _test_chain_future(future):
        future_result = await future
        return future_result

    def chain_future_helper(input_future):
        output_future = _test_chain_future(input_future)
        chain_future(input_future, output_future)

    future = Future()
    chain_future_helper(future)
    future.set_result(42)
    assert loop.run_until_complete(asyncio.wait_for(future, 1)) == 42

    future = Future()
    chain_future_helper(future)
    future.set_exception(ValueError)

# Generated at 2022-06-24 08:21:40.830850
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def f():
        # type: () -> str
        return "foo"

    def err():
        # type: () -> str
        raise Exception("error")

    for future_class in Future, futures.Future:
        f1 = future_class()
        f2 = future_class()
        chain_future(f1, f2)
        f1.set_result("foo")
        assert f2.result() == "foo"
        f1 = future_class()
        f2 = future_class()
        chain_future(f1, f2)
        f1.set_exception(Exception("error"))
        err = f2.exception()
        assert isinstance(err, Exception)
        assert str(err) == "error"

# Generated at 2022-06-24 08:21:51.209463
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    # 1. Both in the same loop, and a will be finished before b
    a = Future()
    b = Future()
    chain_future(a, b)
    assert not b.done()
    io_loop.call_later(0.1, a.set_result, None)
    io_loop.run_sync(b)

    # 2. Both in the same loop, and b will be finished before a
    a = Future()
    b = Future()
    chain_future(b, a)
    assert not a.done()
    io_loop.call_later(0.1, b.set_result, None)
    io_loop.run_sync(a)

    # 3.

# Generated at 2022-06-24 08:21:58.192848
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def async_func(arg):
        if arg:
            raise ZeroDivisionError
        return arg

    def do_test(future):
        try:
            future.result()
        except ZeroDivisionError:
            # The following line *should* re-raise the error
            # with the same traceback attached
            future_set_exc_info(future, sys.exc_info())
        # The following line *shouldn't* raise anything
        future_set_exc_info(future, sys.exc_info())

    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(async_func(0))
    future.add_done_callback(do_test)
    loop.run_until_complete(future)



# Generated at 2022-06-24 08:22:05.698727
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import threading
    import traceback

    def errorback(f):
        try:
            raise f.exception()
        except Exception as e:
            # Revert to legacy behavior
            if sys.version_info >= (3, 5):
                tb = e.__traceback__
            else:
                tb = traceback.format_tb(e.__traceback__)
                tb = [x.strip() for x in tb]
                tb = "\n".join(tb[2:])
            assert exception_type_name in tb
    future = Future()
    # exception_type_name is the name of the exception type, e.g.
    # "ValueError"
    try:
        raise ValueError()
    except Exception:
        _1, e, tb = sys.exc_info

# Generated at 2022-06-24 08:22:08.350473
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = dummy_executor.submit(lambda :3)
    assert a.result() == 3


# Generated at 2022-06-24 08:22:12.653742
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def f():
        future.set_exc_info((Exception, Exception("foo"), None))

    assert not future.done()
    iol = IOLoop.current()
    iol.add_callback(f)
    iol.add_callback(iol.stop)
    iol.start()
    assert future.exception() is not None


# Aliases for compatibility with older versions of Tornado.
# These will go away in Tornado 6.0.

# Generated at 2022-06-24 08:22:20.981035
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    finished_future = Future()
    unfinished_future = Future()

    unfinished_future.set_result(None)
    finished_future.set_result(None)

    f2 = Future()
    future_add_done_callback(finished_future, f2.set_result)
    future_add_done_callback(unfinished_future, f2.set_result)

    assert f2.done()
    future_add_done_callback(Future(), f2.set_result)
    assert f2.done()



# Generated at 2022-06-24 08:22:22.012408
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()


# Generated at 2022-06-24 08:22:25.675745
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():  # noqa: F811
    result = 0

    def func(a: int, b: int) -> int:
        nonlocal result
        result = a + b

    future = dummy_executor.submit(func, 1, 2)
    assert future.done()
    assert result == 3


# Generated at 2022-06-24 08:22:30.093090
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test
    import tornado.testing

    class CustomException(Exception):
        pass

    @gen_test
    def test_future_set_exception_unless_cancelled():
        loop = tornado.ioloop.IOLoop.current()
        future = Future()
        future_set_exception_unless_cancelled(future, CustomException("unexpected error"))
        future = yield future
        self.assertIsInstance(future, CustomException)

        future = Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, CustomException("canceled error"))
        self.assertRaises(tornado.util.CancelledError, lambda: future)

        future = Future()

# Generated at 2022-06-24 08:22:32.543320
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def my_func():
        return 'run'
    future = dummy_executor.submit(my_func)
    print(future.done())
    print(future.result())


# Generated at 2022-06-24 08:22:38.662941
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-24 08:22:40.836992
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError('testing')

# Generated at 2022-06-24 08:22:43.047877
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fut = dummy_executor.submit(lambda x: x, 1)
    assert fut.result() == 1



# Generated at 2022-06-24 08:22:51.790021
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.platform.asyncio
    import tornado.platform.auto

    # Uncomment this line to see the issue described in
    # https://github.com/tornadoweb/tornado/issues/2393
    # tornado.platform.asyncio.AsyncIOMainLoop().install()
    # tornado.platform.asyncio.to_tornado_future is the implementation
    # of tornado.concurrent.futures.to_tornado_future
    f = tornado.platform.asyncio.to_tornado_future(
        asyncio.Future(), tornado.platform.auto.FuturesPool()
    )
    try:
        raise ValueError()
    except Exception:
        exc_info = sys.exc_info()
    future_set_exc_info(f, exc_info)

# Generated at 2022-06-24 08:23:02.394322
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import asyncio
    from tornado.log import gen_log

    class MyClass(object):
        def __init__(self):
            self._thread_pool = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor()
        def method(self):
            gen_log.warning("running in thread pool")
            return 42

    class Test(unittest.TestCase):
        def test_run_on_executor(self):
            """`run_on_executor` should call the function in a separate thread."""
            # The `futures.Executor.submit()` API returns
            # `concurrent.futures.Future` objects, not `asyncio.Future`
            # objects.  When the `run_on

# Generated at 2022-06-24 08:23:11.896365
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self):
            return 42

    foo = Foo()
    future = foo.bar()
    assert is_future(future)
    assert future.result() == 42

    # test executor keyword argument
    class Foo(object):
        def __init__(self):
            self._thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            return 42

    foo = Foo()
    future = foo.bar()
    assert is_future(future)
    assert future.result() == 42



# Generated at 2022-06-24 08:23:17.153471
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    from tornado.ioloop import IOLoop
    import time

    def f():
        time.sleep(0.01)
        return 42

    io_loop = IOLoop.current()

    a = io_loop.run_in_executor(None, f)
    b = Future()
    chain_future(a, b)
    print(io_loop.run_sync(b.result))

# Generated at 2022-06-24 08:23:18.856639
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:23:20.425042
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError(): # pragma: nocover
    ReturnValueIgnoredError()  # type: ignore

# Generated at 2022-06-24 08:23:29.924880
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    success_future = Future()
    future_set_result_unless_cancelled(success_future, None)
    assert success_future.result() is None

    cancelled_future = Future()
    cancelled_future.cancel()
    future_set_result_unless_cancelled(cancelled_future, None)
    assert cancelled_future.cancelled()

    assert_exc_info = None
    try:
        future_set_result_unless_cancelled(cancelled_future, None)
    except Exception:
        assert_exc_info = sys.exc_info()
    assert assert_exc_info is not None
    assert assert_exc_info[1].args == (
        'Result cannot be set on a cancelled Future.',
    )

# Generated at 2022-06-24 08:23:30.784542
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:23:33.289110
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())  # type: ignore
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:23:40.177524
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f():
        try:
            1 / 0
        except:
            exc_info = sys.exc_info()
            f = Future()
            future_set_exc_info(f, exc_info)
            assert f.exception() is not None
            assert f.exception() is exc_info[1]
            # In py33 and above, the original exception is not cleared, so
            # the exception is still present in sys.exc_info()
            if sys.version_info >= (3, 3):
                assert sys.exc_info() is exc_info

    f()

# Generated at 2022-06-24 08:23:44.134853
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError('error'))
    assert future.done()
    assert isinstance(future.exception(), RuntimeError)

    another_future = Future()
    another_future.cancel()
    # No exception thrown
    future_set_exception_unless_cancelled(another_future, RuntimeError('error'))

# Generated at 2022-06-24 08:23:50.310522
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent.futures import Future
    from concurrent.futures import Executor
    from typing import Any

    def test_callback(future: Future) -> None:
        pass
    x.add_done_callback(test_callback)

    def test_callback(future: Future) -> None:
        for i in range(0, 100):
            if i in x:
                continue
    x.add_done_callback(test_callback)

# Generated at 2022-06-24 08:23:58.394453
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import asyncio
    import concurrent.futures
    import functools
    import pytest
    import tornado.testing
    import tornado.web

    result = {}

    @tornado.gen.coroutine
    def callback(f):
        result["value"] = yield f

    @tornado.gen.coroutine
    def set_result():
        result["value"] = yield asyncio.Future()
        result["value"] = yield concurrent.futures.Future()

    def test(future):
        future_add_done_callback(future, callback)
        future.set_result(42)
        assert result["value"] == 42

        future = asyncio.Future()
        future_add_done_callback(future, callback)
        future.set_result(42)
        tornado.ioloop.IOLoop.current().add

# Generated at 2022-06-24 08:24:00.327136
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit()
    dummy_executor.shutdown()



# Generated at 2022-06-24 08:24:03.531552
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from concurrent.futures import Future

    f = Future()
    assert is_future(f)
    assert not is_future(None)
    assert not is_future(f.result)

# Generated at 2022-06-24 08:24:13.807577
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    ioloop = asyncio.get_event_loop()
    main_future = Future()
    main_future.set_result('hi')
    sub_future = Future()
    sub_future.set_result('bye')
    def callback(future):
        # type: (Future) -> None
        if isinstance(future, Future):
            assert future == sub_future
        else:
            assert future == main_future
    future_add_done_callback(main_future, callback)
    asyncio.run_coroutine_threadsafe(main_future, ioloop).result()
    future_add_done_callback(sub_future, callback)
    asyncio.run_coroutine_threadsafe(sub_future, ioloop).result()


# Generated at 2022-06-24 08:24:19.387537
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    callback_args = None

    def callback(f):
        nonlocal callback_args
        callback_args = (f, )

    future_add_done_callback(future, callback)
    future_set_result(future, "foo")
    assert callback_args == (future, )

    future2 = Future()
    callback_args = None

    def callback(f):
        nonlocal callback_args
        callback_args = (f, )

    future_add_done_callback(future2, callback)
    assert callback_args is None
    future_set_result(future2, "foo")
    assert callback_args == (future2, )


# Generated at 2022-06-24 08:24:27.971709
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    a = asyncio.Future()
    b = asyncio.Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42
    b.cancel()
    assert b.done()
    a.set_exception(ValueError())
    assert not b.done()
    a.cancel()
    assert b.cancelled()

    a = futures.Future()
    b = futures.Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42
    b.cancel()
    assert b.done()
    a.set_exception(ValueError())

# Generated at 2022-06-24 08:24:37.579690
# Unit test for function chain_future
def test_chain_future():
    def f():
        pass

    f.assign_called = False

    def assign_result():
        f.assign_called = True

    a = Future()
    b = Future()

    chain_future(a, b)
    b.add_done_callback(assign_result)
    a.set_result(42)

    assert b.result() == 42
    assert f.assign_called

    c = Future()
    d = Future()
    chain_future(c, d)
    c.set_exception(RuntimeError("exception"))
    with pytest.raises(RuntimeError):
        d.result()

    e = Future()
    f = Future()
    chain_future(e, f)
    e.set_exception(OSError(3, "exception"))

# Generated at 2022-06-24 08:24:39.388431
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda : "lambda")


# Generated at 2022-06-24 08:24:41.362757
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()



# Generated at 2022-06-24 08:24:53.907139
# Unit test for function run_on_executor
def test_run_on_executor():
    from concurrent.futures import ThreadPoolExecutor
    import tornado.testing
    import tornado.web
    import tornado.websocket

    executor = ThreadPoolExecutor(1)

    @run_on_executor
    def future_func(self, x):
        return x + 1

    @run_on_executor(executor="_thread_pool")
    def future_func_alt(self, x):
        return x + 1

    @run_on_executor("_thread_pool")
    def future_func_alt2(self, x):
        return x + 1

    @run_on_executor("_thread_pool", callback="on_callback")
    def future_func_compat(self, x):
        return x + 1


# Generated at 2022-06-24 08:24:56.879247
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:24:59.197094
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    print(type(dummy_executor))
    assert isinstance(dummy_executor, DummyExecutor)


# Generated at 2022-06-24 08:25:03.889149
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def async_test():
        # this function must be a coroutine
        # to be able to use await
        def sync_foo(self):
            pass

        foo_coroutine = dummy_executor.submit(sync_foo, 1)
        result = await foo_coroutine
        assert result is None

    asyncio.get_event_loop().run_until_complete(async_test())

# Generated at 2022-06-24 08:25:15.433283
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    """Test that future_set_exc_info handles all cases.
    """

    class MyException(Exception):
        pass

    def raise_exception(exc_class):
        # type: (type) -> None
        raise exc_class()

    future = Future()  # type: Future[None]
    future_set_exc_info(future, sys.exc_info())
    assert future.exc_info() == sys.exc_info()
    assert future.exception() is not None

    future = Future()  # type: Future[None]
    future_set_exc_info(future, (None, None, None))
    assert future.exc_info() is None
    assert future.exception() is None

    future = Future()  # type: Future[None]

# Generated at 2022-06-24 08:25:22.802900
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def test(self):
            done = False

            @gen_test
            def f():
                self.assertTrue(
                    True
                )  # silence code analyzer warning about unused `gen_test` decorator

            future = Future()
            future_add_done_callback(future, lambda future: setattr(self, "done", True))

            self.assertTrue(done)

    TestCase().test()

# Generated at 2022-06-24 08:25:28.850434
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def raise_error():
        raise RuntimeError("boom")

    # Make sure the error gets raised
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

    # Make sure we can raise another error.
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

    # Make sure errors are properly chained.
    try:
        raise_error()
    except:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), RuntimeError)


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 08:25:31.686151
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    raise ReturnValueIgnoredError  # type: ignore
    # `test_ReturnValueIgnoredError` is called by the test suite and type
    # checked by MyPy.

# Generated at 2022-06-24 08:25:40.958766
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from concurrent.futures import Future as ConcFuture
    import asyncio

    a = ConcFuture()
    b = Future()
    chain_future(a, b)
    assert not a.done()
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42

    a = asyncio.Future()
    b = Future()
    chain_future(a, b)
    assert not a.done()
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42
    a.result()



# Generated at 2022-06-24 08:25:41.496211
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:25:43.200104
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    result = DummyExecutor().submit(lambda: 1)
    assert result.done()


# Generated at 2022-06-24 08:25:52.398020
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future() # type: Future
    try:
        raise ValueError()
    except:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None


# Test compatibility with older versions of Tornado.
# Note that these are no longer used internally, they're just here
# to ensure apps can continue to use them if they were previously
# overriding them.
Future.set_result = future_set_result_unless_cancelled
Future.set_exception = future_set_exception_unless_cancelled
Future.set_exc_info = future_set_exc_info
Future.add_done_callback = future_add_done_callback

# Generated at 2022-06-24 08:25:53.338168
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    raise ReturnValueIgnoredError("example")

# Generated at 2022-06-24 08:25:56.519119
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fun():
        return 123
    future = dummy_executor.submit(fun)
    assert future.done() == True
    assert future.result() == 123

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:26:01.026599
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import ioloop
    from tornado.ioloop import IOLoop
    from concurrent import futures
    from concurrent.futures import Future

    def fun():
        return 123

    executor = DummyExecutor()
    future = executor.submit(fun)
    IOLoop.current().run_sync(lambda: future)
    assert future.result() == 123

# Generated at 2022-06-24 08:26:09.040666
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class MyTestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(MyTestCase, self).__init__(*args, **kwargs)
            self.executor = ThreadPoolExecutor(4)

        @run_on_executor
        def f(self):
            return 42

    case = MyTestCase()
    future1 = case.f()
    future2 = case.f()
    self.assertIsInstance(future1, Future)
    self.assertTrue(future1.done())
    self.assertEqual(future1.result(), 42)
    self.assertEqual(future2.result(), 42)

# Generated at 2022-06-24 08:26:13.942308
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())  # type: ignore
    assert is_future(futures.Future())
    assert is_future(futures.ThreadPoolExecutor().submit(lambda: None))  # type: ignore
    assert not is_future(None)

# Generated at 2022-06-24 08:26:20.109965
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    executor = futures.ThreadPoolExecutor(1)

    class Foo(object):
        executor = executor

        @run_on_executor()
        def method(self):
            # type: () -> int
            return 42

    foo = Foo()
    assert isinstance(foo.method(), futures.Future)
    assert foo.method().result() == 42
    assert foo.method().result() == 42



# Generated at 2022-06-24 08:26:28.938457
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import unittest.mock

    @asyncio.coroutine
    def wrapped_func(arg: str) -> str:
        # type: (str) -> str
        return arg

    class TestCase(unittest.TestCase):
        @unittest.mock.patch(__name__ + ".chain_future")
        def test_chain_future(self, mock_chain_future: unittest.mock.Mock) -> None:
            # type: (unittest.mock.Mock) -> None
            future = Future()
            wrapped = wrapped_func("foo")

            chain_future(future, wrapped)
            self.assertEqual(mock_chain_future.call_count, 1)

    unittest.main()


#

# Generated at 2022-06-24 08:26:30.535812
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
  a = dummy_executor.submit(lambda: 1)
  print(a.result())

# Generated at 2022-06-24 08:26:31.493081
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass



# Generated at 2022-06-24 08:26:38.096986
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def my_func(self, a, b):
            return a + b

        def test_run_on_executor(self):
            f = self.my_func(1, 2)
            self.assertEqual(f, 3)

    unittest.main()


# Generated at 2022-06-24 08:26:48.030657
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    def f(x, y):
        return x + y

    class Foo(object):
        def __init__(self) -> None:
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, x, y):
            return f(x, y)

        @run_on_executor(executor="_thread_pool")
        def baz(self, x, y):
            return f(x, y)

        def qux(self, x, y):
            # tests that positional arguments are preserved
            return f(x, y)

    ioloop = IOLoop()
    foo = Foo()

# Generated at 2022-06-24 08:26:51.842739
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, "test")
    assert future.done()
    assert future.result() == "test"


# Generated at 2022-06-24 08:26:57.390749
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import pytest
    Future = asyncio.Future
    f = Future()
    future_set_exception_unless_cancelled(f, Exception("error"))
    assert f.exception() is not None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("error"))
    assert "error" == f.exception().args[0]

    f = Future()
    f.cancel()
    with pytest.raises(Exception) as exc:
        future_set_exception_unless_cancelled(f, Exception("error"))
    assert "error" == str(exc.value)

    ## test tornado.concurrent.Future
    class Exception2(Exception):
        pass
    f = Future()

# Generated at 2022-06-24 08:27:01.326407
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    try:
        f.result()
    except Exception:
        pass

    # This is the important part of the test:
    sys.exc_clear()

# Generated at 2022-06-24 08:27:11.609826
# Unit test for function run_on_executor
def test_run_on_executor():

    class A(object):
        def __init__(self, io_loop):
            self.io_loop = io_loop
            self.executor = dummy_executor

        @run_on_executor
        def f(self, x, y):
            return x + y

        @run_on_executor(executor="_thread_pool")
        def thread_pool(self, x, y):
            return x * y

    a = A(None)
    f1 = a.f(1, 2)
    f2 = a.thread_pool(10, 20)
    if sys.version_info >= (3, 5):
        assert f1.result() == 3
        assert f2.result() == 200
    assert not f1.done()
    assert not f2.done()



# Generated at 2022-06-24 08:27:12.820859
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    # type: () -> None
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:27:14.999488
# Unit test for function is_future
def test_is_future():
    def check(a) -> None:
        assert is_future(a)
    check(futures.Future())
    check(Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:27:25.931286
# Unit test for function chain_future
def test_chain_future():
    @asyncio.coroutine
    def test_chain_future_async(x, y, z):
        results = yield [chain_future(r, f) for r, f in [(x, y), (x, z)]]
        raise Return((x.result(), y.result(), z.result(), results))

    def check_chain_future(x, y, z):
        f = test_chain_future_async(x, y, z)
        asyncio.get_event_loop().run_until_complete(f)
        return f.result()

    f1 = Future()
    f2 = Future()
    f3 = Future()
    assert check_chain_future(f1, f2, f3) == (None, None, None, [None, None])
    f1.set_result(42)


# Generated at 2022-06-24 08:27:30.460233
# Unit test for function chain_future
def test_chain_future():

    def _make_future(value, exc_info=None, **kwargs):
        future = Future(**kwargs)  # type: Future[_T]
        future_set_result_unless_cancelled(future, value)
        future_set_exc_info(future, exc_info)
        return future

    def _check(a_args, b_args, expect_a_result, expect_b_result, expect_b_exc_info):
        a = _make_future(*a_args)
        b = _make_future(*b_args)
        chain_future(a, b)
        assert a.result() == expect_a_result
        assert b.result() == expect_b_result
        assert b.exc_info() == expect_b_exc_info

    # The following tests are ordered roughly in increasing

# Generated at 2022-06-24 08:27:32.808434
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        print(e)