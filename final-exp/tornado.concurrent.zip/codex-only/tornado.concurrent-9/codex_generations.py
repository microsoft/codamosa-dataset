

# Generated at 2022-06-24 08:17:29.163526
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:17:35.737247
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestModule(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def foo(self, x, y):
            return x + y

    def execute(f):
        return f.result()

    executor = DummyExecutor()
    tm = TestModule(executor)
    f1 = tm.foo(1, 2)
    f2 = tm.foo(3, 4)

    execute(f1)
    assert f1.done()
    assert f1.result() == 3
    assert not f2.done()
    execute(f2)
    assert f2.result() == 7

# Generated at 2022-06-24 08:17:38.158424
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(dummy_executor)


# Generated at 2022-06-24 08:17:44.984669
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    def cb(future):
        # type: (Future[None]) -> None
        assert future.done()

    f1 = Future()
    future_add_done_callback(f1, cb)
    f1.set_result(None)

    f2 = Future()
    f2.set_result(None)
    future_add_done_callback(f2, cb)



# Generated at 2022-06-24 08:17:50.073714
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()

    future_set_exception_unless_cancelled(f, Exception("Test exception"))
    assert f.cancelled()

    f = Future()
    with f._condition:
        future_set_exception_unless_cancelled(f, Exception("Test exception"))
        assert not f.cancelled()

# Generated at 2022-06-24 08:17:50.688443
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())

# Generated at 2022-06-24 08:18:00.669870
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    import inspect
    import threading
    from tornado.ioloop import IOLoop, TimeoutError

    @run_on_executor
    def blocking_func(a: int, b: int) -> int:
        return a * b

    @run_on_executor(executor="_thread_pool")
    def blocking_func_args(self, a: int, b: int) -> int:
        return a * b

    class RunOnExecutor(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.executor = dummy_executor
            self._thread_pool = dummy_executor


# Generated at 2022-06-24 08:18:11.197676
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    from . import ioloop

    future1 = Future()
    future2 = Future()

    chain_future(future1, future2)

    f1_result = object()

    def callback(future):
        # type: (Future) -> None
        self.assertEqual(future, future1)
        self.assertFalse(future2.done())
        self.assertIs(future1.result(), f1_result)

    future_add_done_callback(future1, callback)

    future1.set_result(f1_result)
    future2.set_result(None)

    for future in (future1, future2):
        self.assertTrue(future.done())
        self.assertFalse(future.cancelled())

# Generated at 2022-06-24 08:18:22.831096
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa: F811
    async def async_test():
        fut = Future()
        a = [False]

        def callback(f: "Future[None]"):
            assert f is fut
            a[0] = True

        future_add_done_callback(fut, callback)
        assert not a[0]
        fut.set_result(None)
        await fut
        assert a[0]

        fut = Future()
        a = [False]
        fut.set_result(None)

        def callback(f: "Future[None]"):
            assert f is fut
            a[0] = True

        future_add_done_callback(fut, callback)
        assert a[0]

    import tornado.testing
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncI

# Generated at 2022-06-24 08:18:25.804048
# Unit test for function is_future
def test_is_future():
    @asyncio.coroutine
    def foo():
        pass
    assert is_future(foo())
    assert is_future(dummy_executor.submit(foo))
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:18:26.743340
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # dummy_executor.shutdown()
    pass

# Generated at 2022-06-24 08:18:34.293314
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    """
    # DummyExecutor is a Executor 
    # Submit a task to executor, which unblock IOLoop
    """
    from tornado.gen import sleep
    from tornado.ioloop import IOLoop, TimeoutError

    def foo():
        print("start waiting")
        IOLoop.current().add_callback(sleep, 3)
        print("end waiting")
        return "bar"

    async def main():
        # create a dummy executor
        executor = DummyExecutor()
        # submit a task to executor
        future = executor.submit(foo)
        # wait for the result
        result = await future
        print("get result", result)

    future = main()

# Generated at 2022-06-24 08:18:44.953059
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class TestFuture(unittest.TestCase):
        def setUp(self) -> None:
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self) -> None:
            self.executor.shutdown()

        def test_run_on_executor(self) -> None:
            class Counter:
                @run_on_executor()
                def bump(self) -> int:
                    self.value += 1
                    return self.value

            counter = Counter()
            counter.executor = self.executor
            counter.value = 0
            f = counter.bump()
            result = f.result()
            self.assertEqual(result, 1)


# Generated at 2022-06-24 08:18:46.226755
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummyExecutor = DummyExecutor()
    dummyExecutor.shutdown()

# Generated at 2022-06-24 08:18:49.616304
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-24 08:18:51.683253
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exc = RuntimeError("hi")
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)



# Generated at 2022-06-24 08:18:53.513797
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:18:55.450051
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:19:03.623448
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    import time
    exec_1 = asyncio.get_event_loop()
    request_future = exec_1.create_future()
    def sleep():
        time.sleep(1)
        request_future.set_result(None)
    IOLoop.current().call_later(1,sleep)
    async def async_sleep():
        await request_future
    exec_1.run_until_complete(async_sleep())

    exec_2 = DummyExecutor()
    request_future_1 = exec_2.submit(sleep)
    assert request_future_1.done()


# Generated at 2022-06-24 08:19:06.065523
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.shutdown()
    d.shutdown(wait=False)


# Generated at 2022-06-24 08:19:11.839730
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    future_set_exc_info(f, exc_info)
    f.result()

# Generated at 2022-06-24 08:19:14.096732
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_function():
        return 1

    assert dummy_executor.submit(test_function) == 1

# Generated at 2022-06-24 08:19:16.678086
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # NOQA
    try:
        raise ReturnValueIgnoredError("Ret val ignored")
    except ReturnValueIgnoredError as ex:
        assert ex.args[0] == "Ret val ignored"

# Generated at 2022-06-24 08:19:19.810484
# Unit test for function is_future
def test_is_future():
    async def f():
        return "ok"
    assert is_future(f())
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:19:27.819041
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado
    import sys
    import unittest

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):

        def test_future_set_exception_unless_cancelled(self):
            future = tornado.gen.Future()
            future_set_exception_unless_cancelled(future, ValueError("error"))
            self.assertRaises(ValueError, future.result)

        def test_future_cancelled(self):
            future = tornado.gen.Future()
            future_cancel(future)
            future_set_exception_unless_cancelled(future, ValueError("error"))
            self.assertFalse(future.cancelled())

    unittest.main(module=sys.modules["__main__"])

# Generated at 2022-06-24 08:19:32.489928
# Unit test for function chain_future
def test_chain_future():
    # A Future that already has a result.
    f1 = Future()
    f1.set_result(None)
    # A Future that does not yet have a result.
    f2 = Future()
    chain_future(f1, f2)
    # f2 should now have the same result as f1.
    return f2

# Generated at 2022-06-24 08:19:37.800402
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    future_add_done_callback(f, lambda f: None)
    f.set_result(None)

# Generated at 2022-06-24 08:19:48.328017
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # Check that the future_add_done_callback decorator behaves
    # identically to the add_done_callback method
    from concurrent.futures import Future
    from asyncio import Future as AsyncioFuture

    def done_callback(future):
        done_callback.calls.append(future)

    done_callback.calls = []
    f = Future()
    future_add_done_callback(f, done_callback)
    assert len(done_callback.calls) == 0
    f.set_result(None)
    assert len(done_callback.calls) == 1
    assert done_callback.calls[0] is f

    done_callback.calls = []
    f = AsyncioFuture()
    future_add_done_callback(f, done_callback)

# Generated at 2022-06-24 08:19:49.932693
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) is True
    assert is_future(futures.Future()) is True

# Generated at 2022-06-24 08:19:51.177124
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x = DummyExecutor()
    x.shutdown()
    return x

# Generated at 2022-06-24 08:19:56.702790
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self._executor = dummy_executor
            self._result = None
            self._exception = None
            self._exc_info = None

        def tearDown(self):
            self._executor.shutdown()

        def _run_test(self, *args, **kwargs):
            @run_on_executor(executor="_executor")
            def func(x, y):
                return x + y

            future = func(self, *args, **kwargs)
            future.add_done_callback(self._handle_future)
            IOLoop.current().start()


# Generated at 2022-06-24 08:20:04.813897
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from concurrent.futures import Future

    verdict = object()
    executor = DummyExecutor()
    future = executor.submit(lambda: verdict)
    IOLoop.current().start()
    assert future.result() is verdict
    assert isinstance(future, Future)
    assert to_asyncio_future(future).done()

# Generated at 2022-06-24 08:20:08.356282
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    assert issubclass(ReturnValueIgnoredError, Exception)

# Generated at 2022-06-24 08:20:09.221952
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:20:12.202352
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # Test that `DummyExecutor.shutdown(wait=True)` doesn't block
    # indefinitely.
    from tornado.ioloop import IOLoop

    e = DummyExecutor()
    f = e.submit(lambda: None)
    f.result()
    IOLoop.current().run_sync(e.shutdown)



# Generated at 2022-06-24 08:20:28.303095
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from concurrent import futures

    dummy_executor = DummyExecutor()

    class TestFutureSet(AsyncTestCase):

        @gen_test
        def test_future_set_result_unless_cancelled(self):
            future = dummy_executor.submit(lambda x: x, 'a')
            # Cancel the future
            future.cancel()
            # Set the result unless the future is cancelled
            future_set_result_unless_cancelled(future, 'b')
            # Get the result
            result = yield future
            self.assertEqual(result, 'a')

# Generated at 2022-06-24 08:20:35.981116
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    def callback(_):
        # type: (Future) -> None
        pass

    # Test with concurrent.futures.Future
    f1 = futures.Future()
    f2 = futures.Future()
    f2.add_done_callback(callback)
    f1.add_done_callback(callback)
    chain_future(f1, f2)
    assert not f1.cancelled()
    assert not f2.cancelled()
    f1.set_result(None)
    assert f1.done()
    assert f2.done()
    assert not f2.cancelled()

    # Test with asyncio Future
    f1 = Future()
    f2 = Future()
    future_add_done_callback(f2, callback)
    future_add_done_

# Generated at 2022-06-24 08:20:36.818184
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    exception = ReturnValueIgnoredError()

# Generated at 2022-06-24 08:20:41.567453
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, True)
    assert future.result() is True
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, True)
    assert future.cancelled()

# Generated at 2022-06-24 08:20:52.114227
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    executor = unittest.mock.Mock()
    executor.submit.return_value = Future()

    class AnyCallable:
        def __call__(self, *args, **kwargs):
            pass

    class SomeClass:
        def __init__(self):
            self.executor = executor
            self._thread_pool = executor

        def foo(self):
            pass

        def bar(self, a, b):
            pass

        def baz(self, a, b, c, d=1, e=2):
            pass

        @run_on_executor
        def foo_future(self):
            pass


# Generated at 2022-06-24 08:21:02.227421
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    """future_add_done_callback should behave like Future.add_done_callback."""
    def maybe_add(f):
        def _add_done_callback(callback):
            if f.done():
                callback(f)
            else:
                f.add_done_callback(callback)
        return _add_done_callback

    for done in (True, False):
        # Test compatibility with tornado.concurrent.Futures
        f1 = None
        if done:
            f1 = futures.Future()
            f1.set_result(1)
        else:
            f1 = futures.Future()
        f2 = futures.Future()

        f1.add_done_callback = maybe_add(f1)
        future_add_done_callback(f1, f2.set_result)

        # Test

# Generated at 2022-06-24 08:21:08.752574
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_result(None)
    future_set_exception_unless_cancelled(f, Exception("foo"))
    # The exception should have been ignored.
    assert f.result() is None

    f = Future()
    future_set_exception_unless_cancelled(f, Exception("bar"))
    assert f.exception() is not None
    assert "bar" in str(f.exception())



# Generated at 2022-06-24 08:21:13.544011
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from .stack_context import StackContext
    from .ioloop import IOLoop
    future = dummy_executor.submit(StackContext.current, IOLoop.current)
    assert isinstance(future, Future)
    assert future is not None
    IOLoop.current().run_sync(lambda: None)

# Generated at 2022-06-24 08:21:14.868351
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor != None

# Generated at 2022-06-24 08:21:16.250691
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.submit(lambda : True)
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:21:25.443944
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Obj(object):
        executor = futures.ThreadPoolExecutor(1)

        @gen.coroutine
        def f(self):
            # type: () -> Generator[int, int, None]
            yield gen.moment
            raise Return(42)

        @run_on_executor
        def g(self):
            # type: () -> int
            return 42

        @run_on_executor
        def h(self, x, y):
            # type: (int, int) -> Tuple[int, int]
            return x, y

        @run_on_executor(executor='other_executor')
        def j(self):
            # type: () -> int
            return 42

        other_executor = futures.ThreadPoolExecutor(1)

    obj

# Generated at 2022-06-24 08:21:26.890946
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:21:31.258786
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    with pytest.raises(ReturnValueIgnoredError):
        raise ReturnValueIgnoredError(
            "test_ReturnValueIgnoredError: foo", "bar", None
        )

# Generated at 2022-06-24 08:21:32.704760
# Unit test for function is_future
def test_is_future():
    assert not is_future(object())
    assert is_future(Future())

# Generated at 2022-06-24 08:21:41.487518
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()  # noqa
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.io_loop.add_callback(self.io_loop.stop)
            if kwarg1 is None:
                return arg1 + arg2

# Generated at 2022-06-24 08:21:42.804826
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:21:44.246470
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None


# Generated at 2022-06-24 08:21:46.474059
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    if dummy_executor.shutdown(True):
        print("work")

# Generated at 2022-06-24 08:21:48.499537
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # make sure the method shutdown of class DummyExecutor is working
    # properly
    executor=DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-24 08:21:53.145620
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError('message')
    assert str(e) == 'message'
    assert repr(e) == 'ReturnValueIgnoredError(%r)' % 'message'

# Generated at 2022-06-24 08:22:00.974241
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def test_function():
        1/0
    f = Future()
    try:
        test_function()
    except Exception:
        future_set_exc_info(f, sys.exc_info())
        assert f.exception() is not None
        return
    raise Exception("no exception raised")

# Generated at 2022-06-24 08:22:09.568559
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> Future
    exc = ValueError("test")
    f = Future()
    assert not f.done()
    future_set_exception_unless_cancelled(f, exc)
    assert f.done()
    with pytest.raises(ValueError):
        f.result()

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    assert f.done()
    with pytest.raises(asyncio.CancelledError):
        f.result()

# Generated at 2022-06-24 08:22:14.031108
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, "a")
    assert future.result() == "a"
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "b")
    assert future.cancelled()

# Generated at 2022-06-24 08:22:23.553141
# Unit test for function run_on_executor
def test_run_on_executor():
    import time
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop

    @run_on_executor
    def f():
        time.sleep(0.1)
        return 42

    class TestIOLoop(unittest.TestCase):
        def setUp(self):
            loop = AsyncIOMainLoop()
            loop.make_current()
            self.loop = loop

        def tearDown(self):
            self.loop.close(all_fds=True)

        def test_run_on_executor(self):
            f().add_done_callback(self.stop)
            self.wait()
            self.assertEqual(f.result(), 42)

    unittest.main()

# Generated at 2022-06-24 08:22:32.069363
# Unit test for function run_on_executor
def test_run_on_executor():

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        def good(self, callback=None):
            callback(12)

        def bad(self, callback=None):
            raise Exception("bad")

        @run_on_executor
        def good_cb(self, callback=None):
            callback(12)

        @run_on_executor
        def bad_cb(self, callback=None):
            raise Exception("bad")

    a = Test()
    result = yield a.good()
    assert result == 12

    try:
        yield a.bad()
        raise Exception("should not be here")
    except Exception as e:
        assert str(e) == "bad"

    result = yield a.good_cb()
    assert result == 12


# Generated at 2022-06-24 08:22:34.551039
# Unit test for function is_future
def test_is_future():
    from concurrent.futures import Future
    from asyncio import Future
    assert is_future(Future())
    assert is_future(Future())
    assert not is_future("not a future")

# Generated at 2022-06-24 08:22:45.738576
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    import weakref

    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):

        executor = None
        executors = []

        def setUp(self):
            super(Test, self).setUp()

            def cleanup_executor(executor):
                executor.shutdown()
                self.executors.remove(executor)

            self.executor = executor = concurrent.futures.ThreadPoolExecutor(1)
            self.executors.append(executor)
            self.executor_ref = weakref.ref(executor, cleanup_executor)

        def tearDown(self):
            for executor in self.executors:
                executor.shutdown()

# Generated at 2022-06-24 08:22:47.023031
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    assert ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:57.841562
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import threading
    import time

    from tornado.testing import AsyncTestCase
    from tornado.test.util import unittest

    class FuturesTest(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None

            # This test is a little complicated because it tests multiple
            # implementations of Future and threads as well as IOLoops.

            def get_result(f):
                # type: (Future[int]) -> int
                return f.result()

            def get_result_async(f):
                # type: (Future[int]) -> Future[int]
                af = Future()
                chain_future(f, af)
                return af


# Generated at 2022-06-24 08:23:02.319623
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # Test that calling shutdown() raises NotImplementedError
    try:
        dummy_executor.shutdown()
    except NotImplementedError:
        assert True
    else:
        assert False, "Expected error NotImplementedError not raised"


# Generated at 2022-06-24 08:23:07.070393
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test_set_result(future: Future, value: Any) -> None:
        future_set_result_unless_cancelled(future, value)
        assert future.result() == value

    future = Future()
    test_set_result(future, 42)
    future = Future()
    future.cancel()
    test_set_result(future, 42)



# Generated at 2022-06-24 08:23:12.441828
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()
    assert not future.done()

    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    assert future.done()

# Generated at 2022-06-24 08:23:14.543401
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-24 08:23:20.045761
# Unit test for function chain_future
def test_chain_future():
    def make_future() -> Future:
        # concurrent.futures.Future is not compatible with "await"; replace
        # with a real asyncio.Future when we find one
        return Future()  # type: ignore[return-value]

    a = make_future()
    b = make_future()

    # nothing happens if a does nothing
    a.set_result(None)
    b.result()

    # unless b is canceled, it gets the result of a
    a = make_future()
    b = make_future()
    a.set_result(42)
    assert b.result() == 42

    # if b is canceled before a completes, it doesn't get the result
    a = make_future()
    b = make_future()
    b.cancel()
    a.set_result(42)
   

# Generated at 2022-06-24 08:23:23.618254
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Get the future object
    future = dummy_executor.submit(lambda: 'Future object is ready')
    assert isinstance(future, futures.Future)
    # Get the result or exception
    assert future.result() == 'Future object is ready'

# Generated at 2022-06-24 08:23:24.658300
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    return DummyExecutor()

# Generated at 2022-06-24 08:23:34.465506
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing
    import concurrent.futures

    a_executor = concurrent.futures.ThreadPoolExecutor(1)
    b_executor = concurrent.futures.ThreadPoolExecutor(1)

    @tornado.gen.coroutine
    def f():
        # type: () -> None
        a = a_executor.submit(lambda: 123)  # type: ignore
        b = b_executor.submit(lambda: 456)  # type: ignore
        chain_future(a, b)
        self.assertEqual(a.result(), 123)
        self.assertEqual(b.result(), 123)

    tornado.testing.gen_test(f)()



# Generated at 2022-06-24 08:23:40.285800
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # noqa: F811

    future = Future()  # type: Future[str]
    future.set_result("foo")

    @future_add_done_callback
    def callback(future_arg: Future[str]) -> None:
        assert future_arg is future
        future_arg.result()

    callback(future)



# Generated at 2022-06-24 08:23:47.385989
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 2
    future.cancel()
    future_set_result_unless_cancelled(future, 3)
    assert future.cancelled()



# Generated at 2022-06-24 08:23:55.217176
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    t = asyncio.get_event_loop()
    t.run_until_complete(dummy_executor.submit(print, 'Hello'))
    result = t.run_until_complete(dummy_executor.submit(lambda: 100))
    print(result)
    t.run_until_complete(dummy_executor.submit(sys.exit, 0))
    t.close()
    
if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-24 08:23:57.426239
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:23:58.574363
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass



# Generated at 2022-06-24 08:24:07.189719
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    ex = dummy_executor
    f = ex.submit(lambda x: x+1, 1)
    assert f.result() == 2
    f2 = ex.submit(lambda x:x/0, 1)
    assert ex.submit(lambda:f2.result(), 1).exception()
    assert ex.submit(lambda:f2.result(), 1).exception()
    assert ex.submit(lambda:f2.exception(), 1).result()
    f = ex.submit(lambda x:x, f2)
    assert f.exception()
    ex.shutdown(False)

# Generated at 2022-06-24 08:24:16.262119
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test
    import tornado.ioloop
    import unittest

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()

        def test_chain_asyncio_future(self):
            # Test that when a Future is successfully chained to an
            # asyncio.Future, both will be completed with the same value.
            async def test_chain():
                a = Future()
                b = asyncio.Future()
                chain_future(a, b)
                self.assertFalse(a.done())
                a.set_result(42)
                self.assertTrue(a.done())
                self.assertEqual(await b, 42)


# Generated at 2022-06-24 08:24:18.816354
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:24:20.213653
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x = DummyExecutor()
    x.shutdown()


# Generated at 2022-06-24 08:24:22.472967
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    result = object()
    future = Future()
    future_set_result_unless_cancelled(future, result)
    assert future.result() is result

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, result)
    assert future.cancelled()

# Generated at 2022-06-24 08:24:26.600573
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise Exception()
    except Exception:
        exc_info = sys.exc_info()
    future = Future()
    future_set_exc_info(future, exc_info)
    assert not future.cancelled()
    future.add_done_callback(
        lambda future: assert_true(future.exception() is exc_info[1])
    )

# Generated at 2022-06-24 08:24:30.234105
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(x: int, y: int) -> int:
        return x + y

    executor = DummyExecutor()
    future = executor.submit(f, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-24 08:24:34.321192
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()

# Generated at 2022-06-24 08:24:46.067240
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio
    import concurrent.futures

    class FutureCarryingObject:
        def __init__(self, future: "Future[int]") -> None:
            self.future = future

        @run_on_executor
        def f(self) -> int:
            return 42

        @run_on_executor(executor="_thread_pool")
        def f2(self, x: int, y: int) -> Future:
            return x + y

    class AsyncObject:
        async def f(self) -> int:
            return 42

    class AwaitObject:
        def __init__(self) -> None:
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def f(self) -> int:
            return 42


# Generated at 2022-06-24 08:24:47.372299
# Unit test for function chain_future
def test_chain_future():

    @chain_future
    def f():
        pass

    f()



# Generated at 2022-06-24 08:24:58.756269
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest
    import pickle

    from asyncio import Future, InvalidStateError

    from tornado.testing import AsyncTestCase

    from . import gen_test

    from tornado.stack_context import (
        ExceptionStackContext,
        _handle_exception,
        _stack_context_handle_exception,
    )

    class _TestException(Exception):
        pass

    class TestFutureSetExcInfo(AsyncTestCase):
        @gen_test
        def test_no_exception(self):
            f = Future()
            try:
                future_set_exc_info(f, (None, None, None))
            except Exception as e:
                self.fail("future_set_exc_info raised %r" % e)
            else:
                f.add_done_callback(self.stop)
                yield

# Generated at 2022-06-24 08:24:59.697282
# Unit test for function is_future
def test_is_future():
    Future()  # noqa: F841



# Generated at 2022-06-24 08:25:04.137836
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.ioloop import IOLoop

    def expect_exception(future: Future) -> None:
        assert future.exception() is not None
        IOLoop.current().stop()

    future = Future()
    future_set_exc_info(future, sys.exc_info())
    future.add_done_callback(expect_exception)
    IOLoop.current().start()

# Generated at 2022-06-24 08:25:05.732054
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    excutor = dummy_executor
    print(excutor.submit(lambda x: x + 1, 3))

# test_DummyExecutor()

# Generated at 2022-06-24 08:25:12.299170
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class TestException(Exception):
        pass
    f = Future()
    f.set_result(None)

    future_set_exception_unless_cancelled(f, TestException())
    assert f.exception() is None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, TestException())
    assert f.exception() is None

# Generated at 2022-06-24 08:25:23.156584
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import unittest
    import unittest.mock as mock

    class TestFuture(unittest.TestCase):
        def test_future_add_done_callback(self):
            # Define a callback and a future that is set to complete multiple times
            def callback(future):
                pass

            future = Future()
            future.set_result(None)
            future.set_exception(Exception())

            # Ensure that for both cases the callback is called exactly once
            for _ in range(2):
                with mock.patch('tornado.gen._callback'):
                    future_add_done_callback(future, callback)
                    self.assertEqual(len(callback.mock_calls), 1)


# Generated at 2022-06-24 08:25:26.749417
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert executor is not None

# Generated at 2022-06-24 08:25:29.644990
# Unit test for function is_future
def test_is_future():
    def f(): pass
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(f)

# Generated at 2022-06-24 08:25:38.483934
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)
    assert not f2.done()

    f1.set_result(42)
    assert f2.done()

    f3 = Future()
    chain_future(f2, f3)
    assert f3.done()
    assert f3.result() == 42

    f1 = Future()
    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f2, f3)
    f1.set_exception(ValueError())
    assert isinstance(f3.exception(), ValueError)


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 08:25:42.474551
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def x(a,b):
        return a+b
    future = dummy_executor.submit(x,1,2)
    assert future.result() == 3

if __name__ == '__main__':
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:25:50.695022
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("Test Exception"))
    assert future.result() is None
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, Exception("Another Exception"))
    assert future.result() is None
    assert future.exception() is not None
    assert len(future.exception().args) == 2
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("Test Exception"))
    assert future.cancelled() == True



# Generated at 2022-06-24 08:26:00.162607
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    class TestFuture(Future):
        def __init__(self):
            self._result = _NO_RESULT
            self._exc_info = None
            self._done = False
            self._callbacks = []

        def result(self):
            if self._exc_info is not None:
                raise self._exc_info[1].with_traceback(self._exc_info[2])
            assert self._result is not _NO_RESULT
            return self._result

        def set_result(self, result):
            self._result = result
            self._wake_callbacks()

        def done(self):
            return self._done

        def add_done_callback(self, callback):
            self._callbacks.append(callback)

        def _wake_callbacks(self):
            self._done = True

# Generated at 2022-06-24 08:26:03.096312
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future("foo")

# Generated at 2022-06-24 08:26:09.348253
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Start both asyncio.Future and concurrent.futures.Future
    # in the same way:
    a = Future()
    a.set_result(42)
    assert not a.cancelled()
    assert a.done()
    assert a.result() == 42
    b = Future()
    c = futures.Future()
    d = futures.Future()
    for f in [b, c, d]:
        assert not f.cancelled()
        assert not f.done()
        assert f.result() is _NO_RESULT
    chain_future(a, b)
    chain_future(a, c)
    chain_future(a, d)
    assert b.result() == 42
    assert c.result() == 42
    assert d.result() == 42

    #

# Generated at 2022-06-24 08:26:20.432477
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import datetime
    from tornado.httpclient import HTTPRequest, AsyncHTTPClient
    from tornado.options import define, parse_command_line, options
    from tornado.escape import url_escape
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.web import Application, RequestHandler, authenticated
    from tornado.websocket import WebSocketHandler
    import tornado.gen
    import tornado.escape
    import logging
    import os.path
    import tornado.httpserver
    import tornado.ioloop
    import tornado.options
    import tornado.web
    def test_DummyExecutor_submit_callback(result: int) -> None:
        print(result)
    dummy_executor.submit(test_DummyExecutor_submit_callback, 2)


# Generated at 2022-06-24 08:26:29.117974
# Unit test for function chain_future
def test_chain_future():
    import unittest

    def fail(future: Future, exc: BaseException):
        future_set_exc_info(future, exc_info())

    class TestChainFuture(unittest.TestCase):
        def test_chain(self):
            futures = []  # type: List[Future]
            for i in range(10):
                f = Future()
                chain_future(f, futures[-1])
                futures.append(f)
            futures[0].set_result(None)
            for f in futures:
                self.assertTrue(f.done())

        def test_chain_exception(self):
            futures = []  # type: List[Future]
            for i in range(10):
                f = Future()
                chain_future(f, futures[-1])
                futures.append(f)


# Generated at 2022-06-24 08:26:30.575024
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:26:35.633452
# Unit test for function chain_future
def test_chain_future():
    futures = []  # type: typing.List[asyncio.Future[int]]
    for i in range(5):
        futures.append(asyncio.Future())

    for a, b in zip(futures, futures[1:]):
        chain_future(a, b)

    futures[0].set_result(42)

    assert futures[-1].result() == 42

    # If a Future is cancelled before the next Future is complete,
    # the second one should not get an exception
    futures[0].cancel()
    futures[1].set_exception(Exception())
    assert not futures[2].done()

# Generated at 2022-06-24 08:26:38.482217
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 100)
    assert future.cancelled()



# Generated at 2022-06-24 08:26:40.096867
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda: 3)



# Generated at 2022-06-24 08:26:47.842219
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    future = Future() # type: Future
    future_set_result_unless_cancelled(future, 42)
    future_add_done_callback(future, lambda f: f.set_result(f.result() * 2))
    assert future.result() == 84



# Generated at 2022-06-24 08:26:59.820841
# Unit test for function chain_future
def test_chain_future():
    import time
    import functools
    import concurrent.futures

    # Python 2.6 create_task is used for testing.
    def create_task(target, *args, **kwargs) -> futures.Future:
        future = futures.Future()
        def run():
            try:
                result = target(*args, **kwargs)
            except Exception:
                future_set_exc_info(future, sys.exc_info())
            else:
                future_set_result_unless_cancelled(future, result)
        tornado.ioloop.IOLoop.current().add_callback(run)
        return future

    # Python 3.5+ create_task is used with asyncio.

# Generated at 2022-06-24 08:27:00.880879
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda: 1)

# Generated at 2022-06-24 08:27:03.195943
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    """Unit test for method shutdown of class DummyExecutor
    """
    executor = DummyExecutor()
    executor.submit(lambda: None)
    executor.shutdown()

# Generated at 2022-06-24 08:27:11.147290
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def main():
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, True)
        assert not future.cancelled()
        assert future.done()
        assert future.result() == True

    # run in new event loop
    event_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(event_loop)
    event_loop.run_until_complete(main())
    event_loop.close()



# Generated at 2022-06-24 08:27:18.587707
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: nocover
    import time
    import tornado.ioloop
    f = Future()
    state = []

    @tornado.gen.coroutine
    def coro(future):
        state.append("callback")
        x = yield future
        state.append(x)

    future_add_done_callback(f, coro)
    assert state == []
    f.set_result(123)
    tornado.ioloop.IOLoop.current().run_sync(lambda: None)
    assert state == ["callback", 123]

    del state[:]
    f = Future()
    future_add_done_callback(f, coro)
    time.sleep(0.1)
    assert state == []
    f.set_result(456)
    tornado.ioloop.IOLoop.current().run_

# Generated at 2022-06-24 08:27:19.470503
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:27:31.207034
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import concurrent.futures
    import tornado
    import tornado.ioloop

    def on_done_futures(futures: "typing.List[Future[str]]") -> None:
        finished_futures = []
        for future in futures:
            if future.done():
                finished_futures.append(future)
        else:
            return

        # finished_futures is not empty

        # If a finished future has an exception raise it
        for f in finished_futures:
            if f.exception() is not None:
                raise f.exception()

        # If a finished future has no result, just consume the result
        for f in finished_futures:
            if f.result() is None:
                f.result()

        # The finished futures have results