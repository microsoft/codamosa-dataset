

# Generated at 2022-06-24 08:17:30.316411
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    DummyExecutor()

# Generated at 2022-06-24 08:17:33.895166
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    f = executor.submit(lambda x: x + 1, 10)
    assert f.result() == 11
    assert f.done()
    assert f.running() == False


# Generated at 2022-06-24 08:17:45.262763
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest
    import sys
    import traceback

    class TestException(Exception):
        pass

    class FutureTest(unittest.TestCase):
        def test_future_set_exc_info(self):

            class OldFuture(object):
                def __init__(self):
                    self.done_callbacks = []
                    self.exc_info = None

                def set_exception(self, exc):
                    self.exception = exc

                def done(self):
                    return False

                def result(self):
                    raise self.exception

                def add_done_callback(self, fn):
                    self.done_callbacks.append(fn)

            def get_stack():
                return self.assertRaises(TestException, self.test_future.result)

            # Test the old future implementation

# Generated at 2022-06-24 08:17:55.700599
# Unit test for function run_on_executor
def test_run_on_executor():
    import threading

    class TestClass(object):
        def initialize(self, lock, queue):
            """
            Initialization method to set the instance variables.
            """
            self.lock = lock
            self.queue = queue

            # Create an executor that uses threads
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def thread_method(self):
            """
            Method that runs in a thread using the executor
            """
            # This test method can be called multiple times from different
            # threads so we need to use locks.
            self.lock.acquire()
            self.queue.append(threading.currentThread())
            self.lock.release()

    # Create a lock and a list that will be used to ensure that the
    # thread_method runs in different threads.

# Generated at 2022-06-24 08:18:00.454796
# Unit test for function is_future
def test_is_future():
    assert not is_future(1)
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(Exception)
    assert is_future(Future())

# Generated at 2022-06-24 08:18:01.789847
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    e = DummyExecutor()


# Generated at 2022-06-24 08:18:05.604720
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    exe = DummyExecutor()
    fn = lambda : print("abc")
    future = exe.submit(fn)
    future.result()

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:18:08.116347
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = dummy_executor
    future = executor.submit(lambda x:x, "hello")
    assert future.done()
    assert future.result() == "hello"


# Generated at 2022-06-24 08:18:13.618627
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest.mock
    from concurrent import futures
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.testing import AsyncTestCase

    class F(AsyncTestCase):
        def test_set_exception_unless_cancelled(self):
            m = unittest.mock.Mock()
            future = futures.Future()
            exception = TimeoutError()

            future_set_exception_unless_cancelled(future, exception)
            self.assertFalse(m.exception.called)
            future_add_done_callback(future, lambda _: IOLoop.current().stop())
            IOLoop.current().start()
            m.error.assert_called_with(
                "Exception after Future was cancelled",
                exc_info=exception,
            )

    test

# Generated at 2022-06-24 08:18:20.568237
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(42)
    assert b.result() == 42
    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(RuntimeError())
    try:
        b.result()
    except RuntimeError:
        pass
    else:
        assert False, "did not propagate exception"



# Generated at 2022-06-24 08:18:28.431381
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            @run_on_executor
            def func(a: int, b: int) -> int:
                return a + b

            self.func = func

        def test_run_on_executor(self) -> None:
            from tornado import gen

            @gen.coroutine
            def test_coroutine() -> None:
                future = self.func(1, 2)
                result = yield future
                self.assertEqual(result, 3)

            test_coroutine()

    unittest.main()


if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-24 08:18:32.949220
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.log
    import unittest

    class SomeException(Exception):
        pass

    future = Future()
    future_set_exc_info(future, (None, None, None))
    with unittest.mock.patch("tornado.log.app_log") as mocked:
        future_set_exc_info(future, (SomeException, SomeException(), None))
        assert mocked.error.called



# Generated at 2022-06-24 08:18:37.346542
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    a = Future()

    def f():
        try:
            raise Exception()
        except Exception:
            future_set_exc_info(a, sys.exc_info())

    asyncio.get_event_loop().run_sync(f)
    assert a.exception() is not None

# Generated at 2022-06-24 08:18:47.378825
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest.mock

    numbers = [0]

    def increment(_: Any) -> None:
        numbers[0] += 1

    async def test_chain(_: Any) -> None:
        a = Future()
        b = Future()
        chain_future(a, b)
        increment(None)

        # b is not immediately ready
        assert not b.done()
        a.set_result(3)
        increment(None)
        # b is ready now
        assert b.result() == 3
        increment(None)

    with unittest.mock.patch("tornado.concurrent.futures.Future") as future_mock:
        test_chain(None)


# Generated at 2022-06-24 08:18:49.587984
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = Future()
    chain_future(future, future)



# Generated at 2022-06-24 08:18:51.244444
# Unit test for function is_future
def test_is_future():
    future = Future()
    assert is_future(future)
    assert not is_future(object)
    assert not is_future(executor)

# Generated at 2022-06-24 08:19:02.906931
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    # type: ignore

    def f():
        pass

    def cb():
        pass

    executor = unittest.mock.Mock()
    executor.return_value = unittest.mock.Mock()
    executor.return_value.submit.return_value = futures.Future()
    executor.return_value.submit.return_value.done.return_value = False
    s = unittest.mock.Mock()
    s.executor = executor
    s.f = run_on_executor()(f)
    s.f()
    executor.assert_called_with()
    executor.return_value.submit.assert_called_with(s.f, s)

    executor.return_value.submit.return_value

# Generated at 2022-06-24 08:19:13.718342
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Check if it can call set_exception if the future is not cancelled.
    future_not_cancelled = Future()
    future_set_exception_unless_cancelled(future_not_cancelled, ValueError())
    assert future_not_cancelled.result() is None

    # Check if it can log exception if the future is cancelled.
    future_cancelled = Future()
    future_cancelled.cancel()
    try:
        future_set_exception_unless_cancelled(future_cancelled, ValueError())
    except:
        assert False


if typing.TYPE_CHECKING:
    DelayedCall = asyncio.TimerHandle
else:
    DelayedCall = asyncio.TimerHandle  # type: ignore

# Generated at 2022-06-24 08:19:20.974688
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():  # noqa: F811
    from tornado.testing import gen_test

    @gen.coroutine
    def f():
        return "hello"

    @gen_test
    def test():
        expect = "hello"
        future = dummy_executor.submit(f)
        result = yield future
        assert result == expect

    test()

# Generated at 2022-06-24 08:19:24.780744
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, True)
    assert future.done()
    assert future.result()

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, True)
    assert future.done()
    assert (not future.result())

# Generated at 2022-06-24 08:19:35.640799
# Unit test for function chain_future
def test_chain_future():
    ioloop = IOLoop.current()
    # Test combining Future and concurrent.futures.Future objects

    def make_dummy_future(value: Any, delay: float) -> "Future[Any]":
        future = Future()
        ioloop.call_later(delay, lambda: future_set_result_unless_cancelled(future, value))
        return future

    f1 = make_dummy_future(1, 0.1)
    f2 = futures.Future()
    chain_future(f1, f2)
    result = ioloop.run_sync(lambda: f2)
    assert result == 1, result

    f1 = make_dummy_future(1, 0)
    f2 = make_dummy_future(2, 0)
    f1.set_result(42)


# Generated at 2022-06-24 08:19:43.190818
# Unit test for function chain_future
def test_chain_future():
    e = Future()
    f = Future()

    def fail(future):
        future.set_exception(RuntimeError())

    def succeed(future):
        future.set_result(None)

    chain_future(e, f)
    chain_future(f, e)
    e.add_done_callback(succeed)
    f.add_done_callback(fail)
    assert e.exception() is not None
    assert f.exception() is not None



# Generated at 2022-06-24 08:19:48.459358
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    print("test_DummyExecutor start")
    # simple test:
    query = "a"
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(test_DummyExecutor_func, query)
    print("test_DummyExecutor_func output:", future.result())
    print("test_DummyExecutor finish")



# Generated at 2022-06-24 08:19:51.091924
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), ZeroDivisionError)

# Generated at 2022-06-24 08:19:56.304805
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import asyncio
    class Test(object):
        def __init__(self):
            self.executor = dummy_executor
        @run_on_executor
        def foo(self, a, b = 10):
            return a + b
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.ensure_future(Test().foo(3)))
    loop.close()

# Generated at 2022-06-24 08:20:02.896740
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, 42)
    except:
        assert False, "future_set_result_unless_cancelled raised an unexpected exception"

# Generated at 2022-06-24 08:20:09.819368
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with pytest.raises(Exception) as e_info:
        dummy_executor = DummyExecutor()


# Generated at 2022-06-24 08:20:22.354788
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado.testing
    import traceback
    import contextlib
    import logging

    @contextlib.contextmanager
    def nullcontext():
        yield

    future = Future()
    exc = Exception()

    future.set_exception(exc)
    with tornado.testing.expect_deprecated_failure(
        r"coroutine raised exception"
    ):
        with tornado.testing.gen_test(future):
            pass

    log_queue = tornado.queues.Queue()
    handler = logging.Handler()

    def handle(record):
        log_queue.put(record)

    handler.emit = handle
    logger = logging.getLogger("tornado.general")
    old_level = logger.level
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    future = Future

# Generated at 2022-06-24 08:20:32.341081
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Test the  different classes
    mode = ["Concurrent", "Asyncio", None]
    for mode_type in mode:
        myFuture = DummyExecutor()
        if mode_type == "Concurrent":
            # Call with concurrent.futures.Future for final result
            myFuture = myFuture.submit(lambda x: x * x, 5)
            assert myFuture.result() == 25
        elif mode_type == "Asyncio":
            # Call with asyncio.Future for final result
            myFuture = myFuture.submit(lambda x: x * x, 5)
            assert asyncio.run(myFuture) == 25
        elif mode_type == None:
            # Call with Future for final result
            myFuture = myFuture.submit(lambda x: x * x, 5)
            assert myFuture.result() == 25

# Generated at 2022-06-24 08:20:35.238218
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Unit test for function future_set_exception_unless_cancelled
    future = Future()
    future.cancel()
    exception = ValueError()
    future_set_exception_unless_cancelled(future, exception)

# Generated at 2022-06-24 08:20:37.332494
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(Future()) is True
    assert not is_future(None)
    assert is_future(None) is False



# Generated at 2022-06-24 08:20:48.826347
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def __init__(self, *a, **kw):
            super(MyTestCase, self).__init__(*a, **kw)
            self.executor = dummy_executor
            self.result = None
            self.future = None

        @run_on_executor
        def get_42(self):
            self.result = 42
            return 42

        @run_on_executor
        def get_exc(self):
            raise Exception('exception')

        @run_on_executor(executor='executor')
        def get_42_alt(self):
            self.result = 42
            return 42


# Generated at 2022-06-24 08:20:50.144539
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:20:54.402096
# Unit test for function run_on_executor
def test_run_on_executor():

    def executor(method):
        # Executor snippet
        fn = functools.partial(method, self)
        return self._thread_pool.submit(fn)

    class Test():
        pass

    Test.executor = executor

    @run_on_executor
    def foo(self):
        return "lol"

    test = Test()
    test.foo()

# Generated at 2022-06-24 08:20:56.670510
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ex = ReturnValueIgnoredError("My message")
    assert str(ex) == "My message"

# Generated at 2022-06-24 08:20:58.246265
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    _ = DummyExecutor()

# Generated at 2022-06-24 08:21:02.181945
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise RuntimeError
    except Exception:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    assert future.exception() is exc_info[1]



# Generated at 2022-06-24 08:21:05.697688
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> DummyExecutor
    """Test for the DummyExecutor's constructor, which creates the object."""
    dummyExecutor = DummyExecutor()
    assert dummyExecutor
    return dummyExecutor



# Generated at 2022-06-24 08:21:10.940031
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # Note that this function can be called with and without
    # arguments.
    try:
        assert False, "this should be an exception"
    except Exception:
        exc_info = sys.exc_info()
    try:
        assert False, "this should be an exception"
    except Exception:
        exc_info_with_tb = sys.exc_info()

    f = Future()
    f.set_exception(exc_info[1])

    f2 = Future()
    f2.set_exception(exc_info_with_tb[1])
    assert f2.exc_info() == exc_info_with_tb, f2.exc_info()

    f3 = Future()
    future_set_exc_info(f3, exc_info)

# Generated at 2022-06-24 08:21:15.840457
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()  # type: Future[str]
    # Make sure the Future is not done yet
    assert not future.done()
    # Set the exception
    future_set_exc_info(future, sys.exc_info())
    # Make sure the Future is done
    assert future.done()
    # Make sure the exception is the expected one
    assert future.exception() == AssertionError()

# Generated at 2022-06-24 08:21:19.057830
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # See https://github.com/tornadoweb/tornado/issues/1373
    def done_callback(future):
        raise Exception("should not be called")

    future = Future()
    future_add_done_callback(future, done_callback)
    future.set_exception(Exception('error message'))

# Deprecated aliases.
FutureFailedError = futures.TimeoutError
FutureCancelledError = futures.CancelledError  # type: ignore

# Generated at 2022-06-24 08:21:27.580876
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa: F811
    future = Future()
    callback_called = False

    def callback(f):
        nonlocal callback_called
        callback_called = True
        assert future is f

    # Test already-done future
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    future_add_done_callback(future, callback)
    assert callback_called

    # Test callback called after done
    callback_called = False
    future = Future()
    future_add_done_callback(future, callback)
    assert not future.done()
    assert not callback_called
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    assert callback_called



# Generated at 2022-06-24 08:21:38.426139
# Unit test for function future_set_exc_info
def test_future_set_exc_info():

    f = Future()

    # The following two loops are to test the case when
    # Future._tb_logger is True and False, respectively.
    for i in range(2):
        # The following three try...except...else clauses are
        # to test the case when Future._exc_info is None and
        # not None, and when Future._exception and
        # Future._exc_info[1] are None and not None.
        for j in range(2):
            if j == 0:
                exc_info = None
                exception = None
                try:
                    raise ValueError
                except ValueError:
                    exc_info = sys.exc_info()
            else:
                exc_info = sys.exc_info()
                exception = exc_info[1]
            if i == 0:
                f._tb_log

# Generated at 2022-06-24 08:21:40.218589
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda: 42)


# Generated at 2022-06-24 08:21:46.822482
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import asyncio
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-24 08:21:57.044116
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    import logging
    import unittest

    class FutureTest(unittest.TestCase):
        def test_future_set_exc_info(self):
            # type: () -> None
            f = Future()
            future_set_exception_unless_cancelled(f, ValueError())
            self.assertTrue(f.done())
            self.assertIsInstance(f.exception(), ValueError)

            f = Future()
            f.cancel()

            # Check that exceptions are logged
            with self.assertLogs(level=logging.ERROR) as cm:
                future_set_exception_unless_cancelled(f, ValueError())
                self.assertTrue(f.cancelled())

# Generated at 2022-06-24 08:22:05.370738
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import pytest

    _ = future_set_exc_info  # __init__.py uses this as a back-compat alias, so we do too.
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    # Logging is set up in test_main().

    class FutureSetExceptionUnlessCancelledTest(AsyncTestCase):
        def setUp(self):
            super().setUp()
            # Monkey-patch the Future class to log all callbacks and
            # closures, so we can verify that the error is not raised.
            self._orig_callback_cls = Future._Callback  # type: ignore

            class ErrorLoggingCallback(Future._Callback):  # type: ignore
                def __init__(self, type_, fn, context):
                    super().__

# Generated at 2022-06-24 08:22:11.466971
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        future_set_exc_info(f, sys.exc_info())
    ioloop = IOLoop.current()
    ioloop.add_future(f, lambda f: ioloop.stop())
    ioloop.start()
    f.result()



# Generated at 2022-06-24 08:22:22.473210
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    import logging
    import io

    f = Future()
    future_set_exception_unless_cancelled(f, Exception("test"))
    # The future should not have been cancelled and should now be done with an exception
    self.assertFalse(f.cancelled())
    self.assertTrue(f.done())
    self.assertIsInstance(f.exception(), Exception)

    f = Future()
    f.cancel()
    # Capture app_log output
    original_logging_level = app_log.level
    # The future should have been cancelled, but the set_exception call should not raise
    future_set_exception_unless_cancelled(f, Exception("test"))
    self.assertTrue(f.cancelled())
    self.assertTrue(f.done())
   

# Generated at 2022-06-24 08:22:24.326957
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.submit(lambda: 1)
    assert executor.shutdown() is None

# Generated at 2022-06-24 08:22:25.675496
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError("Test error")

# Generated at 2022-06-24 08:22:33.344621
# Unit test for function chain_future
def test_chain_future():
    import tornado.test.util

    futures = []  # type: List[Future]

    def add_future() -> Future:
        f = Future()
        futures.append(f)
        return f

    def add_futures() -> Tuple[Future, Future]:
        return add_future(), add_future()

    def callback(future: Future) -> None:
        future.set_result(None)

    def test_chain(source: Future, dest: Future) -> None:
        chain_future(source, dest)
        callback(source)
        tornado.test.util.wait_for_io_loop(
            self.io_loop, lambda: dest.done()
        )
        self.assertEqual(dest.result(), None)


# Generated at 2022-06-24 08:22:38.616591
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = asyncio.Future()
    def callback(f: asyncio.Future) -> None:
        assert f is future
    future_add_done_callback(future, callback)
    loop.run_until_complete(future)
    loop.close()



# Generated at 2022-06-24 08:22:45.087788
# Unit test for function run_on_executor
def test_run_on_executor():
    class Obj(object):
        def __init__(self) -> None:
            self.executor = dummy_executor

        @run_on_executor
        def foo(self):
            pass

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            pass

    o = Obj()
    assert o.foo() is not None
    assert o.bar() is not None



# Generated at 2022-06-24 08:22:46.520527
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    _ = ReturnValueIgnoredError('test')  # noqa: F841

# Generated at 2022-06-24 08:22:57.502940
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # noqa: F811
    from concurrent import futures
    from tornado import gen
    from tornado.ioloop import IOLoop

    # test for concurrent.futures.Future
    future = futures.Future()  # type: futures.Future[int]
    results = []  # type: typing.List[str]

    def callback(fut: futures.Future[int]) -> None:
        results.append("callback")
        results.append(fut.result())

    future_add_done_callback(future, callback)
    results.append("launch")

    IOLoop.current().add_callback(lambda: future.set_result(42))
    assert results == ["launch", "callback", 42]

    future = gen.convert_yielded(future)  # type: Future[int]
    results = []
   

# Generated at 2022-06-24 08:22:59.978548
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy = DummyExecutor()
    future = dummy.submit(lambda: 1)
    assert(future.result() == 1)

# Generated at 2022-06-24 08:23:02.169687
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import doctest
    success, num_failures = doctest.testmod()
    assert success == True


# Generated at 2022-06-24 08:23:12.301508
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is not None
    f = Future()
    f.set_result(42)
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.cancelled()
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception() is not None
    # To prevent a lingering reference to the old-style code path,
    # call this again to make sure the code path is hit.
    f = Future()
   

# Generated at 2022-06-24 08:23:15.018477
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None



# Generated at 2022-06-24 08:23:19.634163
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from concurrent.futures import ThreadPoolExecutor

    executor = ThreadPoolExecutor(4)

    @run_on_executor(executor=executor)
    def fn():
        return 1

    ioloop = IOLoop.current()

    class Foo:
        @run_on_executor(executor=executor)
        def method(self):
            return 2

    @run_on_executor(executor)
    def fn2():
        return 3

    @run_on_executor(executor=executor)
    def fn3():
        raise Exception("error")

    @run_on_executor(executor=executor)
    def fn4():
        raise KeyboardInterrupt()


# Generated at 2022-06-24 08:23:29.768133
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    io_loop = IOLoop()
    io_loop.make_current()
    future = Future()
    try:
        raise Exception("Test exception")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), Exception)
    assert future.exception().args == ("Test exception",)


_NONE_FUTURE: asyncio.Future[None] = Future()
_NONE_FUTURE.set_result(None)

if typing.TYPE_CHECKING:
    from .locks import BaseLock  # noqa: F401
    from . import locks

    _P = typing.TypeVar("_P")


# Generated at 2022-06-24 08:23:35.244531
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def test():
        f = Future()
        f.cancel() 
        future_set_result_unless_cancelled(f, "value")
        # This would raise an exception if the future was not cancelled:
        assert f.cancelled()

    asyncio.get_event_loop().run_until_complete(test())

# Generated at 2022-06-24 08:23:36.503937
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    x = ReturnValueIgnoredError()
    str(x)
    repr(x)

# Generated at 2022-06-24 08:23:41.878353
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future,  10)
    assert future.result() == 10
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()

# Generated at 2022-06-24 08:23:52.177403
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import mock
    import sys

    class fake_future:
        exception_raised = False

        def __init__(self, state=None):
            self.state = state
            self.log = mock.Mock()

        def set_exception(self, exception):
            self.log.exception.assert_not_called()
            self.exception_raised = True

        def cancelled(self):
            return self.state == "cancelled"

    # Future is cancelled, no exception is raised
    future = fake_future(state="cancelled")
    future_set_exception_unless_cancelled(future, Exception())
    future.log.exception.assert_called_once_with(
        "Exception after Future was cancelled", exc_info=sys.exc_info()
    )
    assert not future.exception

# Generated at 2022-06-24 08:24:00.951796
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = futures.Future()
    f_add_done_callback = future_add_done_callback  # helper for mypy function overloads

    seen = []
    f_add_done_callback(f, lambda f: seen.append(f.result()))
    assert seen == []
    f.set_result(42)
    assert seen == [42]

    seen = []
    f = Future()
    f_add_done_callback(f, lambda f: seen.append(f.result()))
    assert seen == []
    f.set_result(42)
    assert seen == [42]

# Generated at 2022-06-24 08:24:11.729195
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            initial = Future()
            intermediate = Future()
            final = Future()
            chain_future(initial, intermediate)
            chain_future(intermediate, final)
            self.io_loop.add_callback(initial.set_result, "result")
            self.assertEqual(self.io_loop.run_sync(final.result), "result")

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()
    test.tearDown()



# Generated at 2022-06-24 08:24:24.691575
# Unit test for function chain_future
def test_chain_future():

    def test_chain_future_thread(future):
        future.set_result(5)

    def test_chain_future_thread_error(future):
        future.set_exception(RuntimeError())

    def test_chain_future_done_callback(future):
        assert future.result() == 5

    def test_chain_future_done_callback_error(future):
        assert isinstance(future.exception(), RuntimeError)

    def test_chain_future_done_callback_error_2(future):
        assert isinstance(future.exception(), RuntimeError)

    future2 = concurrent.futures.Future()
    future = Future()
    chain_future(future2, future)
    future2.add_done_callback(test_chain_future_done_callback_error)

    future2.result()

   

# Generated at 2022-06-24 08:24:37.470820
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """
    Test function future_set_result_unless_cancelled()
    """
    # Test Future
    def test_future_set_result_unless_cancelled_sub_1():
        """
        Test Future
        """
        future = Future()
        assert not future.cancelled()

        # Set the result
        future_set_result_unless_cancelled(future, 1)
        assert future.cancelled() == False
        assert future.result() == 1

        # Cancel the future
        future.cancel()

        # Set the result
        future_set_result_unless_cancelled(future, 2)
        assert future.cancelled() == True
        assert future.result() == 1

    # Test concurrent.futures.Future

# Generated at 2022-06-24 08:24:41.364287
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(a, b):
        return a + b
    df = dummy_executor.submit(f, 1, 2)
    assert df.result() == 3

# Generated at 2022-06-24 08:24:53.907068
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    # A dummy class with a dummy method to test run_on_executor
    class DummyClass:
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def dummy_method(self, arg):
            return "dummy_method: " + str(arg)

        def dummy_method_with_kwargs(self, arg):  # type: ignore
            return "dummy_method_with_kwargs: " + str(arg)

        @run_on_executor(executor="_thread_pool")
        def dummy_method_with_alternate_executor_attr(self, arg):
            return "dummy_method_with_alternate_executor_attr: " + str(arg)


# Generated at 2022-06-24 08:24:57.292465
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    fut = dummy_executor.submit(lambda x: x + 2, 1)
    assert fut.result() == 3

# Generated at 2022-06-24 08:25:04.963687
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    assert not b.done()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.done()
    assert b.result() == 42
    assert a.result() == 42
    c = Future()
    chain_future(b, c)
    assert c.done()
    assert c.result() == 42
    a = Future()
    b = Future()
    a.set_exception(ZeroDivisionError())
    chain_future(a, b)
    assert b.exception() is not None
    assert isinstance(b.exception(), ZeroDivisionError)



# Generated at 2022-06-24 08:25:07.568501
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-24 08:25:14.031950
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()

    f = asyncio.Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "foo")
    assert f.result() is None

    f = asyncio.Future()
    future_set_result_unless_cancelled(f, "foo")
    assert f.result() == "foo"

# Generated at 2022-06-24 08:25:24.606928
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.escape
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class EchoHandler(tornado.websocket.WebSocketHandler):
        executor = dummy_executor

        @tornado.gen.coroutine
        def open(self):
            return "hello"

        @tornado.gen.coroutine
        def on_message(self, message):
            if message == "error":
                raise Exception("error message")
            elif message == "close":
                self.close()
            elif message == "tornado.escape.xhtml_escape":
                self.write_message(tornado.escape.xhtml_escape("<>"))

# Generated at 2022-06-24 08:25:29.191378
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda x : x, 1)
    assert dummy_executor.submit(lambda x : x, 1).result() == 1
    assert dummy_executor.submit(lambda x: x + 1, 1)
    assert dummy_executor.submit(lambda x : x + 1, 1).result() == 2


# Generated at 2022-06-24 08:25:31.500124
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    result = dummy_executor.submit(lambda: 2 * 3)
    assert result.result() == 6
    assert result.done()

# Generated at 2022-06-24 08:25:40.051883
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("x"))
    assert future.done()
    assert future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("x"))
    assert future.done()
    assert not future.exception()

# Generated at 2022-06-24 08:25:43.732460
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def fn(a):
        return a + 1
    future = dummy_executor.submit(fn, 1)
    IOLoop.current().add_future(future,lambda: None)
    print(future.result())


if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-24 08:25:48.646111
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    assert isinstance(dummy_executor, object), "DummyExecutor is not an object"
    assert isinstance(dummy_executor, futures.Executor), "DummyExecutor is not an futures.Executor"


if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:25:59.252877
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    from tornado import gen
    import time
    from concurrent import futures

    def func(): # type: ignore
        return "return"

    def coro_func():
        # type: () -> str
        return "return"

    executor = DummyExecutor()

    # test @run_on_executor
    @gen.coroutine
    def test_executor():
        # type: () -> None
        result = yield executor.submit(func) # type: ignore
        assert result == "return"

        future = executor.submit(coro_func)
        result = yield future
        assert result == "return"

        # test @run_on_executor with callback
        @gen.coroutine
        def callback(future): # type: ignore
            result = yield future

# Generated at 2022-06-24 08:26:01.557449
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert isinstance(dummy_executor, DummyExecutor)
    assert dummy_executor.submit(lambda: 42) == 42



# Generated at 2022-06-24 08:26:10.237878
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        # This should get the __module__ path, not '__main__' (see #5706).
        exec("raise ValueError")
    except Exception:
        exc_info = sys.exc_info()
        f = Future()
        future_set_exc_info(f, exc_info)
        assert f.exc_info() is not None
        assert isinstance(f.exc_info()[1], ValueError)
        assert f.exc_info()[2] is exc_info[2]
        assert f.exc_info()[2].tb_frame.f_locals["__name__"] == __name__
        assert f.exc_info()[2].tb_frame.f_locals["exc_info"] is exc_info



# Generated at 2022-06-24 08:26:21.040801
# Unit test for function chain_future
def test_chain_future():
    global counter, result
    counter = 0
    result = None

    def callback():
        global counter, result
        counter += 1
        result = f.result()

    f1 = Future()

    f = Future()
    f1.set_result(123)
    chain_future(f1, f)
    f.add_done_callback(callback)

    assert counter == 1
    assert result == 123

    def callback():
        global counter, result
        counter += 1
        result = f.exception()

    f1 = Future()
    f = Future()
    f1.set_exception(ZeroDivisionError())
    chain_future(f1, f)
    f.add_done_callback(callback)

    assert counter == 2
    assert isinstance(result, ZeroDivisionError)



# Generated at 2022-06-24 08:26:22.123469
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda x:x + "bar", "foo") == "foobar"

# Generated at 2022-06-24 08:26:24.893682
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None
    assert isinstance(f.exception(), Exception)
    assert f.exception().args == ("foo",)

# Generated at 2022-06-24 08:26:26.113076
# Unit test for function is_future
def test_is_future():
    asyncio.Future() # type: Future

# Generated at 2022-06-24 08:26:30.052173
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    future = Future()  # type: Future[Any]
    assert is_future(future)
    assert not is_future(object())
    assert is_future(concurrent.futures.Future())
    assert not is_future(concurrent.futures.Executor())

# Generated at 2022-06-24 08:26:32.201446
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda x: x, 3)
    assert future.result() == 3


# Generated at 2022-06-24 08:26:33.250458
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert is_future(futures.Future())
    a = Future()
    assert is_future(a)

# Generated at 2022-06-24 08:26:34.085356
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:26:37.514505
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f():
        raise RuntimeError("foo")

    future = Future()
    try:
        f()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    future.add_done_callback(lambda f: f.result())

# Generated at 2022-06-24 08:26:47.735066
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import logging
    import time
    import unittest
    from tornado.ioloop import IOLoop

    class FutureTestCase(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            # Use a ThreadPoolExecutor so that we can run tasks on the
            # default IOLoop even in the presence of the blocking task
            # below.
            self.executor = futures.ThreadPoolExecutor(1)

        def test_global_future(self):
            # type: () -> None
            def task():
                # type: () -> None
                # A blocking task to make sure we use the thread pool
                time.sleep(0.01)


# Generated at 2022-06-24 08:26:50.235608
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = dummy_executor
    future = executor.submit(lambda: 1 + 1)
    assert future.result() == 2



# Generated at 2022-06-24 08:26:53.773581
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "done")
    assert future.cancelled()



# Generated at 2022-06-24 08:26:59.558562
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b
    ret = dummy_executor.submit(func, 1, 2)
    assert ret.result() == 3
    assert ret.done() == True

    try:
        dummy_executor.submit(func, 1, 'a')
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-24 08:27:04.168606
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    fut = Future()
    fut.cancel()
    future_set_result_unless_cancelled(fut, "result")
    fut.cancel()
    future_set_result_unless_cancelled(fut, "result2")

    assert not fut.cancelled()
    assert fut.result() is None
    assert fut.done()

# Generated at 2022-06-24 08:27:06.506245
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    assert str(ReturnValueIgnoredError("foo")).startswith("foo")

# Generated at 2022-06-24 08:27:16.117901
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado import gen, testing
    from tornado.platform.asyncio import AsyncIOMainLoop

    class RunOnExecutorTest(testing.AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self):
            return 42

        def test_run_on_executor(self):
            coro = self.func()
            self.assertIs(self.executor, self.func.__self__)
            self.assertIsInstance(coro, Future)
            self.assertEqual(self.get_result(coro), 42)

    AsyncIOMainLoop().install()


# Generated at 2022-06-24 08:27:21.114615
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.testing

    class TestFutureAddDoneCallback(tornado.testing.AsyncTestCase):
        def test_future_add_done_callback_futures(self):
            # This test is only meaningful when Tornado's Future is used.
            from tornado import gen
            import tornado.concurrent

            @gen.coroutine
            def test_futures():
                f = tornado.concurrent.Future()
                future_add_done_callback(f, self.stop)
                yield f
                self.fail("yield shouldn't return")

            f = test_futures()
            self.wait()
            f.set_result(None)

        def test_future_add_done_callback_asyncio(self):
            import asyncio


# Generated at 2022-06-24 08:27:25.681683
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        future.done.append(True)

    future = Future()
    future_add_done_callback(future, callback)
    assert future.done == []
    future.set_result(None)
    assert future.done == [True]



# Generated at 2022-06-24 08:27:31.096691
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

