

# Generated at 2022-06-24 08:17:38.237137
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import concurrent.futures
    import unittest

    class MyFuture(concurrent.futures.Future):
        def __init__(self, result):
            # type: (Any) -> None
            super(MyFuture, self).__init__()
            self.result = result

    class MyFuture2(Future):
        def __init__(self, result):
            # type: (Any) -> None
            super(MyFuture2, self).__init__()
            self.result = result


# Generated at 2022-06-24 08:17:40.126397
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from tornado import ioloop
    import time
    executor = DummyExecutor()
    def test_fn():
        time.sleep(1)
    executor.submit(test_fn)
    executor.shutdown()
    ioloop.IOLoop.current().start()

# Generated at 2022-06-24 08:17:45.029374
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import tornado

    class MyTestException(Exception):
        pass

    future = tornado.concurrent.Future()

    future_set_exception_unless_cancelled(future, MyTestException("My Test"))

    assert future.exception() is not None
    assert isinstance(future.exception(), MyTestException)
    assert "My Test" in str(future.exception())



# Generated at 2022-06-24 08:17:53.135837
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f1 = Future()
    f2 = Future()
    future_set_result_unless_cancelled(f1, 1)
    future_set_result_unless_cancelled(f2, 2)
    assert f1.done() and f1.result() == 1
    assert f2.done() and f2.result() == 2

    f3 = Future()
    f3.cancel()
    future_set_result_unless_cancelled(f3, 3)
    assert not f3.done()
    assert f3.cancelled()



# Generated at 2022-06-24 08:17:54.403254
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:18:06.400945
# Unit test for function chain_future
def test_chain_future():
    d = dict(result=None, exception=None, error_type=None)

    def f1():
        return 1

    def f2():
        return 2

    def f3():
        raise Exception("test")

    def f4():
        raise Exception("test")

    def f5():
        raise Exception("test")

    # Test future
    a = futures.Future()  # type: futures.Future[int]
    b = Future()  # type: Future[int]

    # Chain and set a result
    chain_future(a, b)
    a.set_result(f1())
    assert b.result() == f1()
    b.add_done_callback(lambda future: d.__setitem__("result", future.result()))
    assert d["result"] == f1()
    d.__set

# Generated at 2022-06-24 08:18:08.516714
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:18:13.788971
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.done()
    assert isinstance(future.exception(), Exception)
    assert future.exception().args == ("foo",)


_TResult = typing.TypeVar("_TResult")



# Generated at 2022-06-24 08:18:22.785944
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    class TestFutureSetExceptionUnlessCancelled(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            f1 = Future()
            f1.cancel()
            exception = Exception("Custom exception")
            future_set_exception_unless_cancelled(f1, exception)
            self.assertEqual(f1.exception(), None)

            f2 = Future()
            future_set_exception_unless_cancelled(f2, exception)
            self.assertEqual(f2.exception(), exception)

    unittest.main()

# Generated at 2022-06-24 08:18:29.988630
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async_future = Future()
    # By default, the future is not cancelled
    future_set_result_unless_cancelled(async_future, 'x')
    assert async_future.result() == 'x'
    assert not async_future.cancelled()
    assert not async_future.done()
    async_future.cancel()
    assert async_future.cancelled()

    # Ensure exception is not thrown
    future_set_result_unless_cancelled(async_future, 'y')
    assert async_future.cancelled()

    conc_future = futures.Future()
    # By default, the future is not cancelled
    future_set_result_unless_cancelled(conc_future, 'x')
    assert conc_future.result() == 'x'
    assert not conc_future

# Generated at 2022-06-24 08:18:38.045616
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    a = Future()
    b = futures.Future()
    c = []
    d = []

    future_add_done_callback(a, lambda future: c.append(future.result()))
    future_add_done_callback(b, lambda future: d.append(future.result()))
    a.set_result(1)
    b.set_result(2)
    assert c == [1]
    assert d == [2]



# Generated at 2022-06-24 08:18:42.907161
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class MyException(Exception):
        pass
    future = Future()
    future_set_exception_unless_cancelled(future, MyException())
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, MyException())
    assert future.exception() is None



# Generated at 2022-06-24 08:18:46.227256
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future([])
    assert not is_future(object())

# Generated at 2022-06-24 08:18:48.414327
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()

    future_set_exception_unless_cancelled(f, Exception())
    f = Future()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.result() == None

# Generated at 2022-06-24 08:18:53.951935
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    future = Future()
    try:
        1 / 0
    except Exception:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    try:
        future.result()
        raise Exception("didn't get an exception")
    except ZeroDivisionError:
        pass



# Generated at 2022-06-24 08:19:01.346841
# Unit test for function run_on_executor
def test_run_on_executor():
    loop = IOLoop()

    class Target(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

    t = Target()

    @gen.coroutine
    def f():
        result = yield t.foo(1, 2)
        self.assertEqual(result, 3)
        loop.stop()

    loop.add_callback(f)
    loop.start()

# Generated at 2022-06-24 08:19:02.289056
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:19:08.319322
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        raise ValueError('error')
    except ValueError as e:
        exc_info = sys.exc_info()
    f = Future()
    future_set_exc_info(f, exc_info)
    assert isinstance(f.exception(), ValueError)
    f = Future()
    f.cancel()
    future_set_exc_info(f, exc_info)
    assert f.exception() == None


# Generated at 2022-06-24 08:19:15.112829
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def test():
        foo = 1
        conc_future = dummy_executor.submit(lambda x: x, foo)
        async_future = Future()
        chain_future(conc_future, async_future)
        res = await async_future
        print(res)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())

# Generated at 2022-06-24 08:19:20.592046
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import functools
    import concurrent.futures
    global callback
    callback = False
    def _callback(future):
        global callback
        callback = True
        assert future.done()
        assert future.result() == 42
    f = concurrent.futures.Future()
    future_add_done_callback(f, _callback)
    f.set_result(42)
    assert callback
    callback = False
    f = concurrent.futures.Future()
    f.set_result(42)
    future_add_done_callback(f, _callback)
    assert callback

# Generated at 2022-06-24 08:19:25.857094
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class DumbException(Exception):
        pass

    try:
        raise DumbException()
    except DumbException:
        exc_info: Tuple[
            Optional[type], Optional[BaseException], Optional[types.TracebackType]
        ] = sys.exc_info()
        f = Future()
        future_set_exc_info(f, exc_info)
        assert f.exception() is not None
        assert f.exception().__class__ is DumbException

# Generated at 2022-06-24 08:19:28.193004
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func():
        return 1
    f = DummyExecutor().submit(func)
    assert f.result() == 1


# Generated at 2022-06-24 08:19:35.935104
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.web
    import tornado.ioloop
    import tornado.httpserver

    class MainHandler(tornado.web.RequestHandler):
        _thread_pool = dummy_executor

        @tornado.web.asynchronous
        @run_on_executor
        def get(self):
            self.finish({'name': 'Hello, world'})

    application = tornado.web.Application([
        (r"/", MainHandler),
    ])

    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(8080)
    tornado.ioloop.IOLoop.current().start()

# Generated at 2022-06-24 08:19:45.506380
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import asyncio

    executor = dummy_executor

    async def test_submit():
        f = executor.submit(lambda x, y: x+y, 3, 4)
        await asyncio.sleep(0.1)
        assert f.done() == True
        assert f.result() == 7

        f = executor.submit(lambda x: 1 / x, 0)
        await asyncio.sleep(0.1)
        assert f.done() == True
        assert f.exception() is not None
        assert f.result() == None

        for i in range(10):
            f = executor.submit(lambda x: x, i)
            assert f.done() == False



# Generated at 2022-06-24 08:19:48.684167
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-24 08:19:51.010619
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
  executor = DummyExecutor()
  future = executor.submit(lambda a, b: a+b, 1, 2)
  assert future.result() == 3

# Generated at 2022-06-24 08:19:52.500102
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 08:19:55.114904
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    results = []

    def cb(future):
        results.append(future)

    future_add_done_callback(f, cb)
    f.set_result(None)
    f = Future()
    future_add_done_callback(f, cb)
    assert f in results


# Generated at 2022-06-24 08:19:58.496901
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    try:
        dummy_executor.shutdown(wait=True)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 08:20:02.944062
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # noqa: F811
    try:
        1 / 0
    except Exception as e:
        exc = e
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)

# Generated at 2022-06-24 08:20:10.358072
# Unit test for function chain_future
def test_chain_future():
    import tornado.gen

    f = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    f.set_result(42)

    chain_future(f, f2)
    assert f2.result() == 42

    # Verify that a weak ref to f2 doesn't prevent it from being freed
    f2_ref = weakref.ref(f2)
    f2 = None
    for _ in range(20):
        if f2_ref() is None:
            break
        time.sleep(0.01)
    assert f2_ref() is None



# Generated at 2022-06-24 08:20:13.923273
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    async def async_fn():
        await asyncio.sleep(0.01)
        return 1

    @run_on_executor
    def fn():
        return 2

    def callback(future: Future):
        assert future.result() in (1, 2), "future.result() is not 1 or 2"

    future = async_fn()
    future_add_done_callback(future, callback)
    future = fn()
    future_add_done_callback(future, callback)
    asyncio.get_event_loop().run_until_complete(asyncio.gather(future))

test_future_add_done_callback()

# Generated at 2022-06-24 08:20:16.247827
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    asyncio.Future()
    futures.Future()

# Generated at 2022-06-24 08:20:18.887041
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    import tornado.gen as gen

    @gen.coroutine
    def f():
        # type: () -> Future
        return dummy_executor.submit(lambda : 'abc')

    future = f()  # type: Future
    IOLoop.current().run_sync(future)
    assert future.result() == 'abc'

# Generated at 2022-06-24 08:20:28.146964
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    class MainTest(AsyncTestCase):
        def setUp(self):
            super(MainTest, self).setUp()
            self.wait_called = 0
            self.thread_pool = ThreadPoolExecutor(3)
            self.loop = AsyncIOMainLoop()
            self.loop.make_current()

            self.result = None
            self.exception = None

        def tearDown(self):
            self.thread_pool.shutdown()
            self.loop.close(all_fds=True)
            super(MainTest, self).tearDown()


# Generated at 2022-06-24 08:20:31.609976
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("123")
    except:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None


if __name__ == "__main__":
    test_future_set_exc_info()  # type: ignore

# Generated at 2022-06-24 08:20:33.614158
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future(object())
    assert not is_future(lambda: None)
    assert Future()
    assert not futures.Future()

# Generated at 2022-06-24 08:20:34.156249
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:20:36.548343
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    f2 = Future()

    f2.cancel()

    future_set_exception_unless_cancelled(f1, Exception("This should be set"))

    assert(f1.done() == True)
    assert(f2.done() == True)

# Generated at 2022-06-24 08:20:38.106139
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    f = Future()
    is_future(f)  # type: ignore



# Generated at 2022-06-24 08:20:42.277813
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn(self):
        return "test_DummyExecutor_submit"
    future = dummy_executor.submit(fn)
    result = future.result()
    assert result == "test_DummyExecutor_submit"


# Generated at 2022-06-24 08:20:45.071106
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_function():
        pass

    result = dummy_executor.submit(test_function)
    assert isinstance(result, futures.Future)


# Generated at 2022-06-24 08:20:54.729772
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import AsyncTestCase, bind_unused_port

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor(executor="executor")
        def thread_func(self, x, y=0):
            return x + y

        def test_run_on_executor(self):
            f = self.thread_func(41, y=1)
            self.assertFalse(f.done())
            # Bind the socket to make sure we will get the same port next
            # time.
            self.io_loop.run_sync(lambda: bind_unused_port())

# Generated at 2022-06-24 08:21:05.783305
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.testing import AsyncTestCase
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestFutureSetExcInfo(AsyncTestCase):
        def setUp(self) -> None:
            super(TestFutureSetExcInfo, self).setUp()
            self.io_loop = self.new_ioloop(make_current=False)
            AsyncIOMainLoop().install()

        def tearDown(self) -> None:
            super(TestFutureSetExcInfo, self).tearDown()
            self.io_loop.close(all_fds=True)
            AsyncIOMainLoop().clear_instance()

        async def test_future_set_exc_info(self) -> None:
            future = Future()
            try:
                raise ValueError()
            except ValueError:
                exc

# Generated at 2022-06-24 08:21:11.013539
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from types import MethodType

    def foo():
        return 1

    # test the class Type
    assert(DummyExecutor.__class__.__name__ == "type")

    # test the class name
    assert(DummyExecutor.__name__ == "DummyExecutor")

    # test the class super-class
    assert(DummyExecutor.__bases__.__class__.__name__ == "tuple")
    assert(len(DummyExecutor.__bases__) == 1)
    assert(DummyExecutor.__bases__[0].__name__ == "Executor")
    assert(DummyExecutor.__bases__[0].__module__ == "concurrent.futures")

    # test the class has no __dict__

# Generated at 2022-06-24 08:21:22.169594
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.gen import coroutine, Return, Future

    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def f(self, arg):
            return arg * 10

        @run_on_executor(executor='_executor')
        def f2(self, arg):
            return arg * 20

        @coroutine
        def call_f(self, arg):
            result = yield self.f(arg)
            raise Return(result)

        @coroutine
        def call_f2(self, arg):
            result = yield self.f2(arg)
            raise Return(result)

    t = Test()
    assert t.f(10) == 100
    assert t.f2(10) == 200
    assert t.call_f(10).result() == 100

# Generated at 2022-06-24 08:21:23.931950
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    ReturnValueIgnoredError("Test")

# Generated at 2022-06-24 08:21:30.579791
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.test.util import unittest, skipIfNoPY34

    @skipIfNoPY34
    class FutureAddDoneCallbackTest(unittest.TestCase):
        def future_done(self, future):
            future.result()
            self.assertTrue(True)

        def test_future_add_done_callback(self):
            # In python 3.4 and above, asyncio.Future and concurrent.futures.Future
            # are different classes.
            if sys.version_info >= (3, 4):
                future = Future()
                future_add_done_callback(future, self.future_done)
                future.set_result(None)

    test_future_add_done_callback()

# Generated at 2022-06-24 08:21:35.334787
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    callback_list = []
    done = False
    future = Future()

    def set_done():
        nonlocal done
        done = True

    def callback1(arg):
        callback_list.append(1)

    def callback2(arg):
        callback_list.append(2)

    def callback3(arg):
        callback_list.append(3)

    future_add_done_callback(future, callback1)
    assert not callback_list
    future_add_done_callback(future, callback2)
    assert not callback_list
    future_add_done_callback(future, callback3)
    assert not callback_list

    future.set_result(None)
    set_done()

    assert done
    assert callback_list == [1, 2, 3]

# Generated at 2022-06-24 08:21:43.709714
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    try:
        import asyncio
    except ImportError:
        return
    f1 = asyncio.Future()
    f2 = futures.Future()
    value = object()

    def callback(f):
        # type: (Future) -> None
        assert f.result() is value

    future_add_done_callback(f1, callback)
    future_add_done_callback(f2, callback)
    f1.set_result(value)
    f2.set_result(value)

# Generated at 2022-06-24 08:21:50.670517
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    try:
        raise Exception()
    except Exception as exc:
        future_set_exception_unless_cancelled(future, exc)
    future.result()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.cancelled()
    future = Future()
    future.set_exception(Exception())
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

# Generated at 2022-06-24 08:21:59.033546
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, Exception('foo'))
    assert future.done()
    assert isinstance(future.exception(), Exception)
    assert str(future.exception()) == 'foo'
    future_set_exception_unless_cancelled(future, Exception('bar'))
    assert future.done()
    assert str(future.exception()) == 'foo'

# Generated at 2022-06-24 08:22:00.161679
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    _ = ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:07.006037
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import pytest
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    import asyncio

    future_result = True
    async_future_result = True
    global_result = True

    def callback(_future):
        global future_result
        future_result = False

    def async_callback(_future):
        global async_future_result
        async_future_result = False

    def global_callback(_future):
        global global_result
        global_result = False

    future = futures.Future()
    future_add_done_callback(future, callback)
    future.set_result(0)

    async_future = asyncio.Future()
    future_add_done_callback(async_future, async_callback)
    async_future.set_result

# Generated at 2022-06-24 08:22:14.707755
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError('test'))
    assert future.exception() is not None

    future.cancel()
    try:
        # Make sure future_set_exception_unless_cancelled doesn't raise
        # an exception
        future_set_exception_unless_cancelled(future, RuntimeError('test'))
    except asyncio.InvalidStateError:
        # An exception is raised if this is an asyncio.Future
        pass
    except TypeError:
        # An exception is raised if this is a concurrent.futures.Future
        pass

# Generated at 2022-06-24 08:22:24.245478
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop

    class A:
        def __init__(self, x):
            self.x = x
            self.io_loop = IOLoop.current()
            self.executor = dummy_executor

        @run_on_executor
        def f(self):
            return self.x

        @run_on_executor(executor="_executor")
        def g(self):
            return self.x

    a = A(42)
    f = a.f()
    g = a.g()
    IOLoop.current().run_sync(f)
    assert f.result() == 42
    IOLoop.current().run_sync(g)
    assert g.result() == 42

# Generated at 2022-06-24 08:22:32.534149
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import contextlib
    from io import StringIO
    from tornado.log import gen_log
    from tornado.testing import AsyncTestCase, ExpectLog, gen_test

    try:
        from unittest import mock
    except ImportError:
        import mock

    class MyFuture(Future):
        pass

    @contextlib.contextmanager
    def capture_log():
        with mock.patch("logging.StreamHandler.emit") as mock_emit:
            sio = StringIO()
            with ExpectLog("", "tornado.general", sio):
                yield sio, mock_emit

    class TestException(Exception):
        pass

    class LoggingTest(AsyncTestCase):
        @gen_test
        def test_future_set_exception_unless_cancelled(self):
            future = MyFuture()


# Generated at 2022-06-24 08:22:41.306837
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_impl():
        f_outer = Future()
        f_inner = Future()
        chain_future(f_inner, f_outer)
        f_inner.set_result("foo")
        assert (yield f_outer) == "foo"
        f_outer2 = Future()
        chain_future(f_inner, f_outer2)
        f_inner.set_result("bar")
        assert (yield f_outer2) == "foo"

    return test_chain_future_impl()

# Generated at 2022-06-24 08:22:43.868487
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None



# Generated at 2022-06-24 08:22:47.802733
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda x: x + 1, 1)
    assert future.result() == 2
    future = dummy_executor.submit(lambda x, y: x + y, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-24 08:22:55.145769
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest

    IOLoop = asyncio.get_event_loop()

    def future_exception_callback(future: Future) -> None:
        IOLoop.stop()

    exception = Exception("Test Exception")

    done_future = Future()
    done_future.set_result(None)

    cancelled_future = Future()
    cancelled_future.cancel()

    async_future = Future()

    future_set_exc_info(done_future, (type(exception), exception, None))
    future_set_exc_info(cancelled_future, (type(exception), exception, None))
    future_set_exception_unless_cancelled(async_future, exception)
    future_add_done_callback(async_future, future_exception_callback)


# Generated at 2022-06-24 08:23:05.067540
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # Type ignored because the type checker doesn't understand the mock library
    future = Future()  # type: ignore

    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.done()
    assert future.exception() is None

    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.done()
    assert future.exception() is None

    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.done()
    assert future.exception() is None

# Generated at 2022-06-24 08:23:08.045219
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(x:int) -> int:
        return x*x
    future = dummy_executor.submit(foo, 2)
    result = future.result()
    assert foo(2) == result

# Generated at 2022-06-24 08:23:11.548361
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert is_future(Future())
    assert is_future(futures.Future())
    assert is_future(asyncio.ensure_future(Future()))
    assert not is_future(types.coroutine)



# Generated at 2022-06-24 08:23:19.199778
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.done()
    try:
        f2.result()
    except Exception:
        pass
    else:
        raise Exception("did not propagate exception")

# Generated at 2022-06-24 08:23:23.668931
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    fs_list = []
    for i in range(5):
        fs_list.append(executor.submit(lambda x: x, i))
    for i in range(5):
        assert fs_list[i].result() == i
    executor.shutdown()

# Generated at 2022-06-24 08:23:28.912524
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.result() == 10

    future_set_result_unless_cancelled(future, 20)
    assert future.result() == 10

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()



# Generated at 2022-06-24 08:23:32.917029
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    assert f.cancelled()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled()

# Generated at 2022-06-24 08:23:40.660783
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # type: ignore
    import sys
    import unittest

    if hasattr(sys, "pypy_version_info"):
        # AIOFuture.cancel() doesn't reliably raise an exception, at least
        # on PyPy 5.10.
        raise unittest.SkipTest("uncertain cancel() behavior")

    from concurrent import futures

    class DummyException(Exception):
        pass

    future = futures.Future()
    future.set_exception(DummyException())

    exception = None  # type: Optional[BaseException]
    try:
        future.result()
    except BaseException as e:
        exception = e
    assert isinstance(exception, DummyException)

# Generated at 2022-06-24 08:23:44.968984
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(1)
    assert not is_future("foo")

# Generated at 2022-06-24 08:23:52.183608
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    def make():
        # type: () -> Future[int]
        f = Future()
        future_add_done_callback(f, lambda f: f.result())
        return f

    f = make()
    f.set_result(42)
    assert f.done()
    assert f.result() == 42

    f = make()
    f.set_exception(ZeroDivisionError())
    assert f.done()
    assert f.exception()

    try:
        make().result()
        assert False
    except ZeroDivisionError:
        pass


# These classes are mutually recursive and therefore cannot be in the same
# class scope as each other.

# Generated at 2022-06-24 08:23:58.264236
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def f(x: int) -> int:
        return x + 1

    x: DummyExecutor = DummyExecutor()
    y: "Future[int]" = x.submit(f, 10)

    if y.done():
        assert y.result() == 11
    else:
        assert False



# Generated at 2022-06-24 08:24:09.618302
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent.futures import ThreadPoolExecutor
    import threading
    import queue
    from typing import Any
    from tornado.ioloop import IOLoop

    def get_thread_id() -> int:
        return threading.get_ident()
    def get_thread_id_executor() -> int:
        return get_thread_id()
    def get_thread_id_io_loop(io_loop: IOLoop) -> int:
        return get_thread_id()
    def raise_exc() -> Any:
        raise Exception()

    executor = ThreadPoolExecutor(1)
    q = queue.Queue()
    def callback(future: Future) -> None:
        try:
            result = future.result()
        except Exception as e:
            result = e
        q.put(result)

    I

# Generated at 2022-06-24 08:24:16.998805
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    executor = concurrent.futures.ThreadPoolExecutor(1)
    async def async_func():
        await asyncio.sleep(0)
        return 1

    cb = mock.Mock()
    future = executor.submit(async_func)
    future_add_done_callback(future, cb)

    assert cb.call_count == 0
    assert future.done() == False

    # Running loop until future is done
    asyncio.get_event_loop().run_until_complete(future)
    assert cb.call_count == 1
    assert future.done()
    assert future.result() == 1
    assert cb.call_args[0] == (future,)

# Generated at 2022-06-24 08:24:19.625136
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    @run_on_executor
    def my_func(a, b):
        return a + b

    # No setup code needed if no dependencies

    # Execute code under test
    t = my_func(1, 2)
    assert t.result() == 3

    # Verify results
    assert True

# Generated at 2022-06-24 08:24:20.267408
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass



# Generated at 2022-06-24 08:24:25.195531
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.concurrent import Future

    # Test that the exception is logged
    f = Future()
    f.set_exception(Exception())
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())
    # Check that it doesn't raise
    future_set_exception_unless_cancelled(f, None)

# Generated at 2022-06-24 08:24:29.140551
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:24:37.997945
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.log
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.log import app_log
    from tornado.gen import convert_yielded
    from concurrent.futures import ThreadPoolExecutor
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    import asyncio
    import time
    import os
    import sys

    def blocking_f() -> None:
        time.sleep(1)


# Generated at 2022-06-24 08:24:43.844871
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_result("result")
    assert future1.result() == "result"
    assert future2.result() == "result"



# Generated at 2022-06-24 08:24:46.123389
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda: 1)
    assert future.result() == 1



# Generated at 2022-06-24 08:24:47.068629
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError(0, 1, 2)

# Generated at 2022-06-24 08:24:51.511374
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "hello")
    assert f.result() is None
    f = Future()
    future_set_result_unless_cancelled(f, "hello")
    assert f.result() == "hello"

# Generated at 2022-06-24 08:24:56.457557
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    result = object()
    future = Future()
    future_set_result_unless_cancelled(future, result)
    assert future.result() is result
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, result)
    assert future.cancelled()

# Generated at 2022-06-24 08:25:01.658448
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from concurrent import futures
    import time

    thd_pool = futures.ThreadPoolExecutor(max_workers=1)
    loop = asyncio.get_event_loop()
    now = time.time()
    while True:
        if time.time() - now > 5:
            return
        future = loop.run_in_executor(thd_pool, time.sleep, 0.1)
        future.done()

# Generated at 2022-06-24 08:25:08.281854
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    import time
    import tornado.ioloop
    from tornado.platform.asyncio import to_asyncio_future, to_tornado_future

    def f():
        time.sleep(0.01)
        return 42

    ioloop = tornado.ioloop.IOLoop.current()

    futures = []
    for i in range(4):
        async_future = Future()
        future = to_tornado_future(async_future)
        chain_future(future, async_future)
        futures.append(future)
    futures[0].set_result(42)
    futures[1].set_exception(ValueError("foo"))
    futures[2].set_exception(ValueError("foo"))
    futures[2].cancel()
    futures[3].set_exception

# Generated at 2022-06-24 08:25:19.551273
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    import unittest
    import asyncio
    from concurrent import futures
    from tornado.httpclient import AsyncHTTPClient

    http_client = AsyncHTTPClient()

    class DummyExecutorTest(unittest.TestCase):
        @gen_test
        def test_dummy_executor_future(self):
            # The @run_on_executor decorator must be applied to instance methods.
            class Foo(object):
                executor = futures.ThreadPoolExecutor(2)

            @run_on_executor
            def async_method(self, url):
                return http_client.fetch(url).body

            @run_on_executor(executor="executor")
            def async_method_with_executor_arg(self, url):
                return http_client.fetch(url).body

           

# Generated at 2022-06-24 08:25:20.694083
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:25:23.665091
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        assert future.done()
        future.result()

    f = Future()
    future_add_done_callback(f, callback)
    f.set_result(None)



# Generated at 2022-06-24 08:25:30.316550
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self) -> None:
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, x: str, y: int) -> str:
            return x * y

    f = Foo()
    assert f.bar("a", 5) == "aaaaa"

# Generated at 2022-06-24 08:25:39.324248
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    def do_something(a: Any, b: Any, c: Any) -> Any:
        return a + b + c

    future = dummy_executor.submit(do_something, 1, 2, 3)
    assert future.done() == True
    assert future.result() == 6



# Generated at 2022-06-24 08:25:40.958571
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    try:
        d = DummyExecutor()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 08:25:51.006486
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import pytest
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    def make_test_coro():
        async def test_coro():
            fut = asyncio.Future()
            res = []

            def callback(f):
                res.append("callback called")

            tornado_fut = to_tornado_future(fut)
            asyncio_fut = to_asyncio_future(tornado_fut)

            tornado_fut.add_done_callback(callback)
            future_add_done_callback(asyncio_fut, callback)

            await asyncio.wait([tornado_fut, asyncio_fut], timeout=0.1)

            return res

        res

# Generated at 2022-06-24 08:25:57.674775
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 5

    # Ensure that a cancelled Future is not changed
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled()

    # Ensure that a finished Future is not changed.
    f = Future()
    f.set_result(10)
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 10


# Generated at 2022-06-24 08:25:58.370953
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass

# Generated at 2022-06-24 08:26:05.255529
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    chain_future(f, f2)
    f.set_result(42)
    assert f2.result() == 42
    f3 = Future()
    f4 = Future()
    chain_future(f3, f4)
    f3.set_exception(ZeroDivisionError())
    try:
        f4.result()
    except ZeroDivisionError:
        pass
    else:
        raise Exception("should have raised ZeroDivisionError")

# Generated at 2022-06-24 08:26:08.187637
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        # Verify that the exception constructor sets the message field
        assert isinstance(e.args, tuple)
        assert e.args == ("ReturnValueIgnoredError",)

# Generated at 2022-06-24 08:26:16.311615
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # pragma: no cover
    def test_callback(future):
        future.called = True
    
    f = Future()
    future_add_done_callback(f, test_callback)
    assert not future_done(f)
    assert not future_cancelled(f)
    assert not hasattr(f, "called")
    f.set_result("done")
    assert future_done(f)
    assert not future_cancelled(f)
    assert f.called



# Generated at 2022-06-24 08:26:17.868549
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    return ReturnValueIgnoredError("Error returned because value is ignored in call")

# Generated at 2022-06-24 08:26:22.196745
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    exc = ReturnValueIgnoredError("foo")
    assert str(exc) == "foo"
    assert repr(exc) == "<ReturnValueIgnoredError: foo>"
    assert "foo" in repr(exc)



# Generated at 2022-06-24 08:26:25.450792
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception
    except:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None
    assert future.result() is None

# Generated at 2022-06-24 08:26:34.235265
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    from tornado.testing import AsyncTestCase, bind_unused_port

    class FakeExecutor:
        def __init__(self):
            self.threadpool = concurrent.futures.ThreadPoolExecutor(1)

        def submit(self, fn, *args, **kwargs):
            return self.threadpool.submit(fn, *args, **kwargs)

        def shutdown(self):
            self.threadpool.shutdown()

    class ReturnFutureTestCase(AsyncTestCase):
        def setUp(self):
            super(ReturnFutureTestCase, self).setUp()
            self.executor = FakeExecutor()

        def tearDown(self):
            self.executor.shutdown()


# Generated at 2022-06-24 08:26:35.072894
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass



# Generated at 2022-06-24 08:26:38.506153
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future_cancelled = Future()
    future_cancelled.cancel()
    future_set_result_unless_cancelled(future_cancelled, 42)
    assert future_cancelled.cancelled()

# Generated at 2022-06-24 08:26:41.253781
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda x: x + 10, 1)
    assert future.result() == 11


# Generated at 2022-06-24 08:26:46.686044
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    done_future = dummy_executor.submit(lambda : None)
    assert done_future.done()
    assert None == done_future.result()
    assert not done_future.cancelled()


# Generated at 2022-06-24 08:26:48.996321
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    msg = "this is a test"
    err = ReturnValueIgnoredError(msg)
    assert err.args == (msg,)

# Generated at 2022-06-24 08:26:51.547618
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:26:52.891970
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:27:02.389948
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    loop = IOLoop.current()

    @gen_test
    def test():
        fut = Future()

        @gen.coroutine
        def test_callback(future):
            self.assertEqual(future, fut)
            self.stop()

        future_add_done_callback(fut, loop.add_callback)
        fut.set_result('result')
        future_add_done_callback(fut, test_callback)
        future_add_done_callback(loop.run_sync(fut), test_callback)

    test()
    loop.start()
    loop.close()



# Generated at 2022-06-24 08:27:09.802654
# Unit test for function is_future
def test_is_future():
    def func(*args, **kwargs):
        return args, kwargs

    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(func)
    assert not is_future(func())
    assert not is_future(gen_test())
    assert not is_future(gen_test())



# Generated at 2022-06-24 08:27:15.103481
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from . import gen

    def isinstance_test(a, expected):
        # type: (Any, bool) -> None
        assert is_future(a) == expected

    yield gen.coroutine(isinstance_test)(Future(), True)
    yield gen.coroutine(isinstance_test)(futures.Future(), True)
    yield gen.coroutine(isinstance_test)(object(), False)
    yield gen.coroutine(isinstance_test)(is_future, False)

# Generated at 2022-06-24 08:27:26.037118
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import sys
    from tornado.testing import AsyncTestCase
    from tornado.log import app_log

    class MyException(Exception):
        pass

    class FutureTest(AsyncTestCase):
        def test_future_set_exc_info(self):
            f = Future()
            future_set_exc_info(f, sys.exc_info())
            future_add_done_callback(f, self.stop)
            self.wait()
            self.assertIsInstance(f.exception(), NameError)

        def test_future_set_exc_info_with_cls(self):
            f = Future()
            future_set_exc_info(f, (MyException, MyException(), None))
            future_add_done_callback(f, self.stop)
            self.wait()

# Generated at 2022-06-24 08:27:28.445433
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError
    except Exception:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    future.add_done_callback(
        lambda f: f.exception() is exc_info[1]
    )  # type: ignore



# Generated at 2022-06-24 08:27:29.841707
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    exe = DummyExecutor()
    exe.shutdown(wait=True)

# Generated at 2022-06-24 08:27:31.879843
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    assert executor.shutdown() == None