

# Generated at 2022-06-24 08:17:44.363486
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    from unittest import mock
    class MockSuccess:
        def __init__(self):
            pass
        def __call__(self):
            return True

    class MockError:
        def __init__(self):
            pass
        def __call__(self):
            raise KeyError("key error")

    @mock.patch("functools.wraps")
    def test_with_success(mock_wraps):
        @run_on_executor(executor='_thread_pool')
        def foo(self):
            pass

        mock_self = mock.Mock()
        mock_self.executor = dummy_executor
        foo(mock_self)
        mock_wraps.assert_called_once_with(foo)


# Generated at 2022-06-24 08:17:46.434659
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = dummy_executor
    dummy_executor.submit(lambda i: i*i, 2)


# Generated at 2022-06-24 08:17:56.755780
# Unit test for function run_on_executor
def test_run_on_executor():
    import functools
    import unittest.mock
    import unittest

    @unittest.mock.patch("concurrent.futures.ThreadPoolExecutor")
    def test(executor_mock):
        # type: (unittest.mock.Mock) -> None
        executor_mock.return_value = unittest.mock.Mock()
        executor = executor_mock.return_value

        class Foo(object):
            executor = "executor"

            def method(self, x, y):
                return x + y

            method_future = run_on_executor()(method)

        foo = Foo()
        x = object()
        y = object()
        future = foo.method_future(x, y)
        executor.submit.assert_

# Generated at 2022-06-24 08:18:07.550760
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    # Success test: with a result
    base_future = Future()
    result_future = Future()
    chain_future(base_future, result_future)
    io_loop.run_sync(base_future.set_result, "result")
    assert io_loop.run_sync(result_future.result) == "result"
    assert result_future.exception() is None, "result future should not have an exception"
    assert result_future.cancelled() is False, "result future should not be cancelled"

    # Exception test: with an exception
    base_future = Future()
    result_future = Future()
    chain_future(base_future, result_future)
    exception = ValueError("exception message")
    io_loop

# Generated at 2022-06-24 08:18:09.580811
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(3)
    assert not is_future(object())



# Generated at 2022-06-24 08:18:21.036298
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    errors = []
    results = []

    def cb(fut):
        if fut.exception():
            errors.append(fut.exception())
        else:
            results.append(fut.result())

    chain_future(f1, f2)
    f1.set_result(1)
    f2.add_done_callback(cb)

    assert errors == []
    assert results == [1]
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    f2.add_done_callback(cb)
    assert len(errors) == 1
    assert isinstance(errors[0], ValueError)
    assert results == [1]

# Generated at 2022-06-24 08:18:28.863724
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import unittest

    from tornado.testing import AsyncTestCase

    class FutureAddDoneCallbackTest(AsyncTestCase):
        def test_add_done_callback(self):
            future = Future()
            callback_result = []

            def first_callback(f: Future) -> None:
                self.assertTrue(f.done())
                self.assertTrue(future.done())
                callback_result.append("Called1")

            future_add_done_callback(future, first_callback)
            callback_result.append("first_callback")
            future.set_result(42)
            self.assertEqual(callback_result, ["first_callback", "Called1"])

    unittest.main()


_NO_RESULT = object()



# Generated at 2022-06-24 08:18:41.917288
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.ioloop
    from multiprocessing import Process
    from tornado.ioloop import IOLoop
    import time
    import logging
    import os
    import sys
    import json
    import random
    import argparse

    #logging.basicConfig(level=logging.INFO)
    # now = datetime.datetime.now()
    # logging.info("Start %s." % now)

    parser = argparse.ArgumentParser()
    parser.add_argument("--http_port", type=int, default=8888)
    #parser.add_argument("--nb_to_test", type=int, default=100)
    args = parser.parse_args()
    #print(args)

    #INSTANCE_COUNTER = 0


# Generated at 2022-06-24 08:18:44.864752
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()

    def foo(_):
        return _

    assert executor.submit(foo, 1).result() == 1



# Generated at 2022-06-24 08:18:52.447750
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()

    f = Future()  # type: Future[Any]
    future_set_exc_info(f, exc_info)
    assert f.exception() is exc_info[1]

    f = Future()  # type: Future[Any]
    f.set_exc_info(exc_info)
    assert f.exception() is exc_info[1]

    f = futures.Future()  # type: futures.Future[Any]
    future_set_exc_info(f, exc_info)
    assert f.exception() is exc_info[1]

    f = futures.Future()  # type: futures.Future[Any]
    f.set_exc_info

# Generated at 2022-06-24 08:19:03.701990
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.ioloop
    import inspect
    import functools
    import concurrent.futures

    _TEST_EXECUTOR = concurrent.futures.ThreadPoolExecutor(1)

    class DummyExecutorClass(object):
        def __init__(self):
            self._executor = None

        def method(self, arg, kwarg=None):
            assert arg == 1
            assert kwarg == 2
            return arg + 1

        method_with_self = run_on_executor()(method)
        method_with_temp_executor = run_on_executor(executor="_executor")(method)


# Generated at 2022-06-24 08:19:07.959029
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future.set_result(None)
    assert future.done()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    assert future.cancelled()


# Generated at 2022-06-24 08:19:10.820935
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())  # type: ignore
    assert is_future(Future())

# Generated at 2022-06-24 08:19:15.382342
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_result(None)
    future_set_exception_unless_cancelled(f, Exception("test exception"))
    assert f.exception() is not None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test exception"))
    assert f.exception() is None

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, None)
    assert f.exception() is None

# Generated at 2022-06-24 08:19:17.964456
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():

    def print_hello():
        print("Hello!")

    future = dummy_executor.submit(print_hello)
    future.result()

    dummy_executor.shutdown()


# Generated at 2022-06-24 08:19:22.604394
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert not f2.done()
    chain_future(f1, f2)

    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42



# Generated at 2022-06-24 08:19:32.311777
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def f(future: Future) -> bool:
        future_set_result_unless_cancelled(future, True)
        return True

    future = Future()
    assert future.cancel()
    cflist = []
    future.add_done_callback(cflist.append)
    assert not future.done()
    assert future.cancelled()
    assert not cflist
    dummy_executor.submit(f, future)
    assert cflist
    assert len(cflist) == 1
    assert cflist[0].done()
    assert not cflist[0].cancelled()
    assert cflist[0].result()


# Generated at 2022-06-24 08:19:36.163690
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() is None




# Generated at 2022-06-24 08:19:39.211180
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    f = dummy_executor.submit(lambda x: x * x, 10)
    assert f.result() == 100


# Generated at 2022-06-24 08:19:41.900362
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    future2 = Future()
    chain_future(future, future2)
    future.set_result(3)
    assert future2.result() == 3



# Generated at 2022-06-24 08:19:49.384559
# Unit test for function chain_future
def test_chain_future():
    future = Future()
    chained = Future()
    chain_future(chained, future)
    assert not (future.done() and future.cancelled())
    chained.set_result(42)
    assert not (future.done() or future.cancelled())
    assert future.result() == 42
    chained.cancel()
    assert not future.done()
    assert not future.cancelled()
    future.cancel()
    assert future.done()
    assert future.cancelled()


# Backwards compatibility aliases.
WaitFuture = Future
TracebackFuture = Future

# Generated at 2022-06-24 08:19:54.553039
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.done()
    assert not future.cancelled()
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.done()
    assert future.cancelled()

    # Note: concurrent.futures.Future does not support "cancel".
    future = futures.Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.done()
    assert not future.cancelled()
    assert future.result() == 42



# Generated at 2022-06-24 08:20:00.979243
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, object())
    assert future.done()
    assert future.result() is not None

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, object())
    assert future.cancelled()

# Generated at 2022-06-24 08:20:10.681146
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class MyError(Exception):
        pass

    for FutureType in (futures.Future, Future):
        async def test_future():
            future = FutureType()
            try:
                1 / 0
            except ZeroDivisionError:
                future_set_exc_info(future, sys.exc_info())
            assert future.exception() is not None
            try:
                future.result()
            except ZeroDivisionError:
                pass
            else:
                raise AssertionError("ZeroDivisionError should have been raised")

        import tornado
        import tornado.testing
        import tornado.platform.asyncio

        tornado.testing.run_sync(test_future, io_loop=tornado.platform.asyncio.AsyncIOLoop())



# Generated at 2022-06-24 08:20:16.156170
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class CustomExc(Exception):
        pass
    future = Future()
    future_set_exc_info(future, (CustomExc, CustomExc("foo"), None))
    assert future.exception() is not None
    with pytest.raises(CustomExc, match="foo"):
        future.result()

# Generated at 2022-06-24 08:20:24.025429
# Unit test for function future_add_done_callback
def test_future_add_done_callback():   # pragma: nocover
    import unittest
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.testing import AsyncTestCase

    class TestFutureAddDoneCallback(AsyncTestCase):
        def test_done_callback(self):
            future = Future()
            f2 = Future()
            future_add_done_callback(future, f2.set_result)
            future.set_result(1)
            self.assertTrue(f2.done())

        @gen.coroutine
        def test_done_callback_coroutine(self):
            future = Future()
            f2 = Future()
            future_add_done_callback(future, f2.set_result)
            yield gen.moment
            future.set_result(1)

# Generated at 2022-06-24 08:20:32.647683
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_add_done_callback(f, lambda f: f.set_result(1))
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()
    f = Future()
    future_add_done_callback(f, lambda f: f.set_exception(ValueError('error')))
    try:
        f.result()
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"
    f = Future()
    f.cancel()

# Generated at 2022-06-24 08:20:36.487056
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.done()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.done()
    assert f2.exception() is not None



# Generated at 2022-06-24 08:20:40.049286
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import functools

    global callback_args

    def callback(future):
        global callback_args
        callback_args = (future,)

    # Test both types of Future.
    for future_type in (Future, futures.Future):
        future = future_type()
        future_add_done_callback(future, functools.partial(callback, future_type))
        assert callback_args == ()
        future.set_result(future_type)
        assert callback_args == (future,)
        del callback_args



# Generated at 2022-06-24 08:20:51.515249
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f():
        raise ValueError()

    f1 = Future()
    f2 = Future()

    # test_future_set_exc_info1
    f1.set_exception(ValueError())
    future_set_exc_info(f2, sys.exc_info())

    # test_future_set_exc_info2
    f1.set_exception(ValueError())
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(f2, sys.exc_info())

    # test_future_set_exc_info3
    try:
        raise ValueError()
    except ValueError:
        f1.set_exception(sys.exc_info())
        future_set_exc_info(f2, sys.exc_info())

    # test_

# Generated at 2022-06-24 08:20:52.076821
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:20:54.376188
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    global dummy_executor
    print(dummy_executor.submit(lambda x: x, 10))
    # will print: <Future at 0x7fa3c8e39bd0 state=finished returned int>

# Generated at 2022-06-24 08:21:01.132672
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    exc = Exception('error message')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    exc = Exception('error message')
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    # Cancelled future does not have exception
    assert future.exception() is None

# Generated at 2022-06-24 08:21:09.540309
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen, testing
    from . import testing as test

    @gen.coroutine
    def f():
        raise gen.Return((yield g()))

    @gen.coroutine
    def g():
        raise gen.Return(1)

    @gen.coroutine
    def f2():
        raise gen.Return((yield g2()))

    @gen.coroutine
    def g2():
        raise gen.Return(2)

    @testing.gen_test
    def test_chain_future():
        f1 = f()
        f2 = f2()
        f3 = Future()

        chain_future(f1, f3)
        chain_future(f2, f3)

        res = yield f3
        test.assertEqual(res, 2)

# Generated at 2022-06-24 08:21:10.998458
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:21:17.049106
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f1 = Future()  # type: Future
    try:
        raise ValueError("foo")
    except:
        future_set_exc_info(f1, sys.exc_info())

    assert f1.exception() is not None

    f2 = Future()  # type: Future
    try:
        raise ValueError("foo")
    except:
        future_set_exc_info(f2, sys.exc_info())

    assert f2.exception() is not None

# Generated at 2022-06-24 08:21:26.126390
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import io
    import unittest.mock
    import sys

    # Capture stderr to check Log
    stderr = io.StringIO()
    _, sys.stderr = sys.stderr, stderr

    # Create future.
    future = Future()

    # Logging happens when future has been cancelled
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("Error1"))
    assert "Error1" in stderr.getvalue()

    # Test normal operation
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("Error2"))
    assert not future.done()
    assert "Error2" not in stderr.getvalue()

    # No logging if we do not cancel first

# Generated at 2022-06-24 08:21:33.331595
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    f = Future()
    future_set_exception_unless_cancelled(f, ERROR)
    assert f.exception() == ERROR

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ERROR)
    assert f.cancelled()


# The following functions are copied from the concurrent.futures package,
# which explains most of their implementation and style.



# Generated at 2022-06-24 08:21:41.795851
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def foo():
        return 1
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    DummyExecutor().submit(foo)
    Dummy

# Generated at 2022-06-24 08:21:45.081627
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception('a'))
    assert f.exception() is None

# Generated at 2022-06-24 08:21:48.221901
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.cancelled()

# Generated at 2022-06-24 08:21:53.989383
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    io_loop = asyncio.get_event_loop()

    def target(a, b):
        return (a, b)

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            executor = futures.ThreadPoolExecutor(1)
            self.executor = executor
            self.addCleanup(executor.shutdown)

        @run_on_executor(executor='executor')
        def synch_func(self, a, b):
            return target(a, b)

    test_case = MyTestCase()
    io_loop.run_until_complete(test_case.synch_func(1, 2))

# Generated at 2022-06-24 08:22:00.316978
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise RuntimeError
    except RuntimeError:
        exc_info = sys.exc_info()
        future = Future()
        future_set_exc_info(future, exc_info)
        future.result()
    assert False

# Generated at 2022-06-24 08:22:05.924189
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    x = asyncio.Future()
    y = dummy_executor.submit(lambda: None)
    assert y.done()
    assert y.result() is None
    y = dummy_executor.submit(lambda: sum([1,2,3]))
    assert y.done()
    assert y.result() == 6
    def boom():
        raise Exception("boom")

    y = dummy_executor.submit(boom)
    assert not y.done()
    dummy_executor.shutdown()
    # we can only test that this doesn't raise an exception.
    # result doesn't work because boom raised an exception.
    assert y.done()

# Generated at 2022-06-24 08:22:13.515553
# Unit test for function is_future
def test_is_future():
    import unittest
    from types import GeneratorType
    from tornado.gen import coroutine
    from asyncio import Future

    class Test(unittest.TestCase):
        def test_is_future(self):
            self.assertTrue(is_future(Future()))  # type: ignore
            self.assertFalse(is_future(object()))
            self.assertFalse(is_future(None))
            self.assertFalse(is_future(GeneratorType))
            self.assertFalse(is_future(coroutine(lambda: 1)))

# Generated at 2022-06-24 08:22:16.775066
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def test():
        try:
            raise Exception("hello")
        except Exception:
            future_set_exc_info(future, sys.exc_info())

    test()
    future.result()

# Generated at 2022-06-24 08:22:26.223882
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # OK
    import traceback
    import time

    # OK
    def bad_func(val: int) -> int:
        return val/0

    # OK
    def ok_func(val: int) -> int:
        return val*2

    # OK
    async def async_ok_func(val: int) -> Future:
        r = await asyncio.sleep(1)
        return val * 2

    # OK
    def log_exception(type: type, value: Exception, tb: types.TracebackType):
        print("@log_exception", type, value, tb)
        asyncio.get_event_loop().stop()

    # OK
    def log_result(val: int):
        print("@log_result", val)
        asyncio.get_event_loop().stop()



# Generated at 2022-06-24 08:22:27.223012
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("Test")


# Generated at 2022-06-24 08:22:30.814517
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError()
    assert repr(e) == 'ReturnValueIgnoredError()'
    e = ReturnValueIgnoredError('foo')
    assert repr(e) == "ReturnValueIgnoredError('foo',)"

# Generated at 2022-06-24 08:22:31.737803
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()



# Generated at 2022-06-24 08:22:33.115712
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-24 08:22:35.289610
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    future = dummy_executor.submit(lambda: "result")
    assert future.result() == "result"



# Generated at 2022-06-24 08:22:41.068336
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from tornado import gen
    from concurrent.futures import Future
    from asyncio import Future as AsyncioFuture

    class _A(object):
        pass

    assert is_future(Future())
    assert is_future(gen.Future())
    assert is_future(AsyncioFuture())
    assert not is_future(_A())

# Generated at 2022-06-24 08:22:50.250183
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.ioloop import IOLoop
    from tornado.test.util import unittest

    class TestException(Exception):
        pass

    class ErrorTestCase(unittest.TestCase):
        def test_future_set_exc_info(self):
            # type: () -> None
            exc_info = None  # type: Optional[Tuple[Optional[type], BaseException, Optional[types.TracebackType]]]
            try:
                raise TestException("Error message")
            except TestException:
                exc_info = sys.exc_info()
            future = Future()
            future_set_exc_info(future, exc_info)
            self.assertEqual(future.exception().args, ("Error message",))
            future = Future()
            future_set_exc_info(future, exc_info)


# Generated at 2022-06-24 08:23:01.710012
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def assert_future_set_exception_unless_cancelled(future):
        assert future.cancelled()
        future_set_exception_unless_cancelled(future, RuntimeError)
        assert future.cancelled()

    future = Future()
    future.set_result(None)
    future_set_exception_unless_cancelled(future, RuntimeError)
    assert future.exception() == RuntimeError
    assert not future.cancelled()

    future = Future()
    future.set_exception(RuntimeError)
    future_set_exception_unless_cancelled(future, FutureCancelledError)
    assert future.exception() == RuntimeError
    assert not future.cancelled()

    future = Future()
    assert not future.cancelled()
    future.cancel()

# Generated at 2022-06-24 08:23:11.971689
# Unit test for function chain_future
def test_chain_future():
    # Tests that the given chain of futures completes successfully and
    # with the correct result (or raises the correct exception on
    # failure).  The contracts of these aren't perfectly respected yet
    # (e.g. the callback for c gets called after the next iteration of
    # the event loop instead of synchronously), but it's close enough
    # for now.

    def check_chain(a: "Future[int]", b: "Future[int]", c: "Future[int]") -> None:
        """Wait for all three futures to complete and check the result."""
        def validate(fut: "Future[int]") -> None:
            if fut.result() == 5:
                IOLoop.current().stop()
            else:
                raise Exception("invalid result: %r" % (fut.result(),))

        future_add_

# Generated at 2022-06-24 08:23:16.914780
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import tornado.testing
    future = Future()
    future_set_result_unless_cancelled(future, 0x123)
    tornado.testing.assert_future_result(future, 0x123)
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 0x123)
    tornado.testing.assert_future_cancelled(future)



# Generated at 2022-06-24 08:23:26.719476
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import types
    import unittest

    from tornado.platform.asyncio import AsyncIOMainLoop

    # asyncio.Future.set_exc_info requires the additional 'tb'
    # argument which must be a traceback
    async def tasks(self):
        self.future.set_exc_info(self.exc_info)

    class FutureTest(unittest.TestCase):
        def test_future_set_exc_info(self):
            if not AsyncIOMainLoop().asyncio_event_loop_policy._loop_factory:
                self.skipTest("asyncio event loop policy is not initialized")

            # set up exc_info triple
            try:
                raise Exception("exception")
            except Exception:
                exc_info = sys.exc_info()
            future = Future()
           

# Generated at 2022-06-24 08:23:32.941120
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    from unittest.mock import MagicMock

    from tornado.log import LogFormatter
    import io
    import sys

    class LogFormatterTestCase(unittest.TestCase):
        def setUp(self):
            formatter = LogFormatter()

            strbuf = io.StringIO()
            handler = logging.StreamHandler(stream=strbuf)
            handler.setFormatter(formatter)

            self.old_stderr, sys.stderr = sys.stderr, strbuf

            self.mock_future = MagicMock()

        def tearDown(self):
            sys.stderr = self.old_stderr

        def test_future_set_exception_unless_cancelled(self):
            self.mock_future.cancelled.return_

# Generated at 2022-06-24 08:23:38.194124
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():

    def foo() -> Future:
        future = Future()
        future_set_result_unless_cancelled(future, 1)
        return future

    def bar() -> Future:
        future = Future()
        future_set_result_unless_cancelled(future, 2)
        future.cancel()
        return future

    assert foo().result() == 1
    assert bar().cancelled()

# Generated at 2022-06-24 08:23:46.462146
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    f = Future()  # type: Future[None]
    # result is not set if the future is cancelled
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    assert f.cancelled()
    assert not f.done()

    # result is set if the future is not cancelled
    future_set_result_unless_cancelled(f, None)
    assert not f.cancelled()
    assert f.done()

    # result is not set if the future is already done
    f = Future()
    f.set_result(0)
    future_set_result_unless_cancelled(f, 1)
    assert f.done()
    assert f.result() == 0

# Generated at 2022-06-24 08:23:52.858582
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    def foo(x, y):
        return x + y
    result = executor.submit(foo, 1, 2)
    assert result.result() == 3

# Generated at 2022-06-24 08:23:57.904145
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    def foo(a):
        return 1 + a

    future = dummy_executor.submit(foo, 1)
    assert future.result() == 2

# Generated at 2022-06-24 08:24:01.013278
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test():
        res = 2 + 5
        return res

    dummy_executor.submit(test)
    # The result is 7
    assert dummy_executor.submit(test).result() == 7


# Generated at 2022-06-24 08:24:12.142663
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()
    assert not future.done()
    assert not future.result()

    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.exception
    assert future.done()
    assert future.result() == 10

    future = futures.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 10)
    assert future.cancelled()
    assert not future.done()
    assert not future.result()

    future = futures.Future()
    future_set_result_unless_cancelled(future, 10)
    assert future.exception

# Generated at 2022-06-24 08:24:17.616609
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with dummy_executor as executor:
        future = executor.submit(lambda: "test")
        result = future.result()
    # result = "test"
    assert result == "test"



# Generated at 2022-06-24 08:24:18.620406
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:24:25.444547
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import threading
    from concurrent import futures

    def callback(future):
        events.append(future)

    executor = futures.ThreadPoolExecutor(1)
    events = []
    f1 = executor.submit(lambda: True)
    f2 = executor.submit(lambda: True)
    future_add_done_callback(f1, callback)
    future_add_done_callback(f2, callback)
    assert len(events) == 2
    assert events[0] is f1
    assert events[1] is f2



# Generated at 2022-06-24 08:24:26.143471
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    DummyExecutor()

# Generated at 2022-06-24 08:24:35.777354
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    a = Future()
    a.cancel()
    future_set_result_unless_cancelled(a, 1)
    if a.exception() != asyncio.CancelledError:
        raise Exception("Expected a canceled future")
    b = Future()
    future_set_result_unless_cancelled(b, 1)
    assert b.result() == 1
    c = futures.Future()
    c.cancel()
    future_set_result_unless_cancelled(c, 1)
    if c.exception() != futures.CancelledError:
        raise Exception("Expected a canceled future")
    d = futures.Future()
    future_set_result_unless_cancelled(d, 1)
    assert d.result() == 1

# Generated at 2022-06-24 08:24:42.088545
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    import time

    class MyTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.some_attribute = 1
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor(executor="executor")
        def func_for_test(self, a, b, c=3):
            # type: (int, int, int) -> int
            assert self.some_attribute == 1
            time.sleep(0.1)  # to make sure the executor is actually used
            return a + b + c

        def test_run_on_executor(self):
            # type: () -> None
            self.some_attribute = 2
            future = self.func_for

# Generated at 2022-06-24 08:24:45.519348
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    """Test idle DummyExecutor can be shutdown"""
    dummy_executor.shutdown()



# Generated at 2022-06-24 08:24:48.629271
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception("foo")
    except:
        future_set_exc_info(f, sys.exc_info())
    assert "foo" in f.exception().args

# Generated at 2022-06-24 08:24:51.790754
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    future_add_done_callback(f, lambda f: f.set_result(42))
    assert f.result() == 42



# Generated at 2022-06-24 08:24:54.596797
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f():
        raise RuntimeError('test')
    future = Future()
    try:
        f()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), RuntimeError)
    assert future.exception().args == ('test',)



# Generated at 2022-06-24 08:25:00.327433
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = futures.Future()
    called = []

    def callback(future):
        called.append(future)

    future_add_done_callback(future, callback)
    future.set_result(None)
    assert called[0] is future

    future = Future()
    future_add_done_callback(future, callback)
    future.set_result(None)
    assert called[1] is future

# Generated at 2022-06-24 08:25:04.100567
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # DummyExecutor is a subclass of Executor
    assert issubclass(DummyExecutor, futures.Executor)

    def _f(x: int) -> int:
        return x

    x = DummyExecutor()
    f = x.submit(_f, 1)
    assert f.result() == 1


# Generated at 2022-06-24 08:25:08.033516
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError()
    except ValueError as e:
        future_set_exc_info(future, sys.exc_info())
        assert future.result() is e

# Generated at 2022-06-24 08:25:11.182545
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()  # type: ignore
    except ReturnValueIgnoredError:
        pass
    else:
        raise Exception("test failed")

# Generated at 2022-06-24 08:25:13.417770
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.submit(lambda x: x, 3)
    executor.shutdown()

# Generated at 2022-06-24 08:25:24.128056
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    testfuture = Future()
    testfuture.set_result('test result')

    try:
        future_set_exception_unless_cancelled(testfuture, asyncio.CancelledError())
        # Asyncio.InvalidStateError should *not* be raised
    except asyncio.InvalidStateError:
        raise AssertionError("future_set_exception_unless_cancelled raised an exception when it should not have.")

    # The Future should remain unchanged
    assert (testfuture.result() == 'test result')

    # Now try with a cancelled future
    testfuture = Future()
    testfuture.cancel()


# Generated at 2022-06-24 08:25:26.718654
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def fn(a, b):
        return a + b
    future = DummyExecutor().submit(fn, 1, 2)
    assert 3 == future.result()

# Generated at 2022-06-24 08:25:35.267064
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import sys
    import traceback
    import unittest
    import warnings

    from tornado.log import gen_log

    if hasattr(asyncio, "current_task"):
        # Python 3.8 or newer.
        from asyncio import current_task

        def get_task() -> asyncio.Task:
            task = current_task()
            if task is None:
                raise RuntimeError("current_task() returned None")
            return task

    # for Python 3.4/3.5 compatibility
    elif hasattr(asyncio, "Task") and hasattr(asyncio.Task, "_current_tasks"):
        # Python 3.6 or 3.7
        def get_task() -> asyncio.Task:
            tasks = getattr(asyncio.Task, "_current_tasks")

# Generated at 2022-06-24 08:25:39.839187
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled() == True, "Future is not cancelled"

# Generated at 2022-06-24 08:25:43.861829
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    # type: ignore
    future_obj = futures.Future()
    assert is_future(future_obj)
    assert not is_future("")
    assert not is_future(1)
    assert not is_future(())
    assert not is_future({})
    assert not is_future(None)

# Generated at 2022-06-24 08:25:49.921640
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    future = Future()
    # print(dummy_executor)
    dummy_executor.submit(fn=lambda: future, args=[], kwargs={})
    IOLoop.current().add_future(future, lambda f: None)
    # print(future)


if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-24 08:25:56.194512
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import time
    import random
    import concurrent.futures
    import multiprocessing
    max_workers=multiprocessing.cpu_count()
    try:
        executor=concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
        with executor:
            def say(what):
                time.sleep(random.randint(1,3))
                print(what)
                return "done"
            results=executor.map(say,range(10))
            for result in results:
                print(result)
    except Exception as e:
        raise e


# Generated at 2022-06-24 08:25:57.498104
# Unit test for function is_future
def test_is_future():
    Future()  # type: ignore
    Future()  # type: ignore

# Generated at 2022-06-24 08:26:05.221307
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    exception = RuntimeError()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_exception(exception)
    assert future2.done()
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    assert not future2.done()
    future1.set_result(42)
    assert future2.done()



# Generated at 2022-06-24 08:26:05.760721
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:26:16.002395
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None

    def make_future(*args: Any, **kwargs: Any) -> "Future[_T]":
        # type: ignore
        return Future(*args, **kwargs)

    cb_args = []  # type: List[Tuple[str, Future]]

    def cb(source: Future, key: str) -> None:
        cb_args.append((key, source))

    f1 = make_future()
    f2 = make_future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    assert not f2.cancelled()

    f1 = make_future()
    f2 = make_future()
    f1.set_result(42)

# Generated at 2022-06-24 08:26:26.754860
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.platform.asyncio import to_asyncio_future
    from concurrent.futures import ThreadPoolExecutor

    from concurrent.futures import Future
    # Compute a result so we can make sure that both the
    # ThreadPoolExecutor and DummyExecutor compute the same answer
    def wait_random_seconds():
        import random
        import time
        t = random.uniform(0, 1)
        time.sleep(t)
        return t

    tornado_future = Future()
    tornado_future = to_asyncio_future(tornado_future)

    async def task():
        tornado_future.set_result(wait_random_seconds())

    t = ThreadPoolExecutor(1)
    d = DummyExecutor()
    t_future = t.submit(wait_random_seconds)


# Generated at 2022-06-24 08:26:31.244170
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def async_test_future_set_exc_info():
        future = asyncio.Future()
        try:
            raise ValueError()
        except:
            future_set_exc_info(future, sys.exc_info())
        assert not future.done()
        res = future.result()
        assert False, 'Future does not raise exception: %r' % res
    asyncio.run(async_test_future_set_exc_info())

# Generated at 2022-06-24 08:26:33.000523
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future("foo")

# Generated at 2022-06-24 08:26:38.772071
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.ioloop import IOLoop

    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done() and not future.cancelled()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done() and future.cancelled()

    loop = IOLoop()
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done() and not future.cancelled()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done() and future.cancelled()

# Generated at 2022-06-24 08:26:46.986207
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    msg: str = "ReturnValueIgnoredError message"
    e: ReturnValueIgnoredError = ReturnValueIgnoredError(msg)
    assert msg in str(e), "ReturnValueIgnoredError missing message in str(ReturnValueIgnoredError)"

# Generated at 2022-06-24 08:26:50.597419
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(1, 'foo', bar='baz')
    assert future.result() == 'foo'
    

# Generated at 2022-06-24 08:26:52.464664
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()
    return



# Generated at 2022-06-24 08:26:56.919338
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'
    future.cancel()
    future_set_result_unless_cancelled(future, 'bar')
    assert future.result() == 'foo'



# Generated at 2022-06-24 08:27:03.648287
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    callback_args: List[Any] = []
    def callback(arg):
        callback_args.append(arg)
    future_add_done_callback(future, callback)
    assert callback_args == []
    future.set_result(None)
    assert callback_args == [future]
    callback_args = []
    future = Future()
    future.set_result(None)
    future_add_done_callback(future, callback)
    assert callback_args == [future]

# Generated at 2022-06-24 08:27:04.599607
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError('msg')
    assert str(e) == 'msg'

# Generated at 2022-06-24 08:27:12.015804
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from concurrent.futures._base import RUNNING, FINISHED, CANCELLED
    import threading
    executor = DummyExecutor()
    assert executor._state == RUNNING
    executor.submit(threading.Thread)
    executor.shutdown(wait=True)
    assert executor._threads == set()
    assert executor._state == FINISHED
    executor.submit(threading.Thread)
    assert executor._state == CANCELLED


if __name__ == "__main__":
    test_DummyExecutor_shutdown()

# Generated at 2022-06-24 08:27:13.538489
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())  # type: ignore
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:27:15.394231
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: nocover
    e = ReturnValueIgnoredError("test")
    assert e.args == ("test",)

# Generated at 2022-06-24 08:27:22.033775
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    f.add_done_callback(lambda future: future.exception())

    f = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    f.add_done_callback(lambda future: future.exception())



# Generated at 2022-06-24 08:27:25.828997
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception()



# Generated at 2022-06-24 08:27:30.907821
# Unit test for function future_add_done_callback
def test_future_add_done_callback():

    import pytest

    f1 = Future()

    def callback(future):
        assert future.done()
        assert future == f1

    future_add_done_callback(f1, callback)

    # cannot test `f1.set_result` in this test because it is not a coroutine
    # f1.set_result(None)

    futures.Future()



# Generated at 2022-06-24 08:27:40.801149
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures

    class MyFuture(Future):
        def __init__(self):
            self._result = None
            self._exception = None
            self._traceback = None
            self._callbacks = []

        def set_result(self, result):
            self._result = result
            self._run_callbacks()

        def set_exception(self, exception):
            self._exception = exception
            self._run_callbacks()

        def result(self):
            return self._result

        def exception(self):
            return self._exception

        def add_done_callback(self, fn):
            self._callbacks.append(fn)
            self._run_callbacks()
