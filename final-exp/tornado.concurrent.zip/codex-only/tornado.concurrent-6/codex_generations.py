

# Generated at 2022-06-24 08:17:35.662986
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class TestException(Exception):
        pass
    e = ReturnValueIgnoredError("foo")
    assert e.args == ("foo",)
    e = ReturnValueIgnoredError("foo", TestException())
    assert isinstance(e.__context__, TestException)

# Generated at 2022-06-24 08:17:39.748135
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()  # type: ignore
    except ReturnValueIgnoredError:  # type: ignore
        pass


# Generated at 2022-06-24 08:17:41.771520
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:17:47.016663
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = asyncio.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert not future.done()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert not future.done()
    future = asyncio.Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()



# Generated at 2022-06-24 08:17:55.695526
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future_a = Future()  # type: Future[int]
    future_b = Future()  # type: Future[int]
    chain_future(future_a, future_b)
    future_a.set_result(42)
    assert future_b.result() == 42
    future_a = Future()  # type: Future[int]
    future_b = Future()  # type: Future[int]
    future_b.set_result(100)
    chain_future(future_a, future_b)
    future_a.set_result(42)
    assert future_b.result() == 100

# Generated at 2022-06-24 08:17:59.849389
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future("future")

# Generated at 2022-06-24 08:18:05.963809
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(*args,**kwargs):
        print(args[0])
        print(args[1])
        return args[0] + args[1]
    DummyExecutor().submit(func,1,2)
    DummyExecutor().submit(func,1,2,name="zhuo")


# Generated at 2022-06-24 08:18:06.909666
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:18:09.716415
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception()
    except:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None

# Generated at 2022-06-24 08:18:13.408112
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # Ensure that our Future.set_exc_info works.
    future = Future()
    try:
        raise Exception()
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    future.result()

# Generated at 2022-06-24 08:18:18.431106
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():  # pragma: no cover
    import unittest

    class TestFuture(Future):
        def __init__(self, exc_info: Tuple[Any, Any, Any]) -> None:
            super().__init__()
            self.exc_info = exc_info
            self.set_exception(exc_info[1])

        def cancel(self) -> bool:
            return super().cancel()

        def exc_info(self) -> Tuple[Any, Any, Any]:
            return self.exc_info

    class TestException(Exception):
        pass

    class TestCase(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self) -> None:
            future = TestFuture((None, TestException, None))


# Generated at 2022-06-24 08:18:20.062672
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        ...

    def test(future):
        future_add_done_callback(future, callback)

    test([futures.Future])
    test([Future])
    test([asyncio.Future])

# Generated at 2022-06-24 08:18:28.625954
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    a = Future()
    b = Future()
    chain_future(a, b)

    a.set_result(42)
    assert b.result() == 42

    c = Future()
    d = Future()
    chain_future(c, d)
    e = Future()
    chain_future(d, e)

    c.set_exception(ZeroDivisionError())
    try:
        with pytest.raises(ZeroDivisionError):
            e.result()
    except AttributeError:
        # python 2: tornado.concurrent.Future does not have result()
        assert e.exception() is not None

    f = Future()
    g = Future()
    h = Future()
    chain_future(f, g)
    chain_future(g, h)
   

# Generated at 2022-06-24 08:18:33.108184
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def callback_func():
        pass

    def func(*args, **kwargs):
        pass

    exe = DummyExecutor()

    f = exe.submit(func)

    f.add_done_callback(callback_func)

    f.cancel()
    f.result()
    f.exception()
    f.set_running_or_notify_cancel()

test_DummyExecutor_submit()

# Generated at 2022-06-24 08:18:44.202874
# Unit test for function chain_future
def test_chain_future():
    a, b = Future(), Future()
    chain_future(a, b)
    assert not b.done()
    a.set_result(42)
    assert b.result() == 42

    a, b = Future(), Future()
    a.set_exception(RuntimeError())
    chain_future(a, b)
    assert b.exception().__class__ == RuntimeError


if sys.platform == "win32":
    import ctypes
    import errno

    _GetLastError = ctypes.windll.kernel32.GetLastError
    _GetLastError.argtypes = []
    _GetLastError.restype = ctypes.c_uint

    _WSAGetLastError = ctypes.windll.ws2_32.WSAGetLastError
    _WSAGetLastError.argtypes = []
   

# Generated at 2022-06-24 08:18:45.371068
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.submit(lambda : 1)
    executor.shutdown(wait=False)

# Generated at 2022-06-24 08:18:50.379869
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(f):
        assert f.result() == 1
        _tests_ran.add("add_done_callback")

    # test add_done_callback on a done future
    f = Future()
    f.set_result(1)
    future_add_done_callback(f, callback)
    f = Future()
    f.set_exception(Exception())
    future_add_done_callback(f, callback)
    f = Future()
    f.set_result(1)
    future_add_done_callback(f, callback)

    f = Future()

    def finish_future(f):
        f.set_result(1)

    # test add_done_callback on a pending future
    # (this also tests add_done_callback on a future that's pending but
    # has had callbacks added

# Generated at 2022-06-24 08:19:01.954377
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    # Future changed between py34 and py35, so there are two tests
    exc_info = (None, None, None)
    try:
        raise Exception()
    except:
        exc_info = sys.exc_info()
        # Note that sys.exc_info can return None in some cases
        if exc_info == (None, None, None):
            raise Exception("sys.exc_info returned (None, None, None)")
    for FutureClass in (asyncio.Future, futures.Future):
        f = FutureClass()
        f2 = FutureClass()
        future_set_exc_info(f2, exc_info)
        assert f2.exception() is not None
        assert f2.exception() == exc_info[1]
        chain_future(f, f2)


# Generated at 2022-06-24 08:19:12.679732
# Unit test for function future_set_exc_info
def test_future_set_exc_info():

    def function_raising_exception() -> None:
        raise Exception("An exception from a function")

    f = Future()
    future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None

    g = Future()
    future_set_exc_info(g, sys.exc_info())
    assert g.exception() is not None

    h = Future()
    try:
        function_raising_exception()
    except Exception:
        future_set_exc_info(h, sys.exc_info())
    assert h.exception() is not None

    i = Future()
    try:
        function_raising_exception()
    except Exception:
        future_set_exc_info(i, sys.exc_info())
    assert i.exception() is not None

# Generated at 2022-06-24 08:19:17.802531
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    exec = DummyExecutor()
    future = exec.submit(lambda a: a, 2)
    assert future.result() == 2



# Generated at 2022-06-24 08:19:24.946690
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def test_callback(future):
        future._result = 99

    # Test a tornado future
    f = Future()
    future_add_done_callback(f, test_callback)
    assert not hasattr(f, '_result')
    f.set_result(1)
    assert f._result == 99

    # Test a concurrent future
    f2 = futures.Future()
    future_add_done_callback(f2, test_callback)
    assert not hasattr(f2, '_result')
    f2.set_result(2)
    assert f2._result == 99

# Generated at 2022-06-24 08:19:29.945059
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from tornado.concurrent import Future
    from concurrent.futures import Future as FutureF
    from asyncio import Future as FutureA

    assert is_future(Future())
    assert is_future(FutureF())
    assert is_future(FutureA())
    assert not is_future(object())

# Generated at 2022-06-24 08:19:38.625656
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import to_tornado_future_cycle
    from tornado.testing import AsyncTestCase, bind_unused_port, gen_test

    class MyException(Exception):
        pass

    class TestFutureSetExcInfo(AsyncTestCase):
        def test_future_set_exc_info_asyncio(self):
            asyncio_future = asyncio.Future()

            with self.assertRaisesRegex(
                MyException, "should be turned into an exception"
            ):
                future_set_exc_info(asyncio_future, (MyException, MyException(""), None))
            self.assertTrue(asyncio_future.done())



# Generated at 2022-06-24 08:19:43.982176
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    try:
        future_set_exception_unless_cancelled(future, IOError())
    except Exception:
        raise AssertionError("future_set_exception_unless_cancelled failed")
    future_set_result_unless_cancelled(future, None)
    future_set_exc_info(future, sys.exc_info())

# Generated at 2022-06-24 08:19:45.930037
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test_func(a):
        return a+10
    dummy_executor.submit(test_func, 10)


# Generated at 2022-06-24 08:19:48.412930
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError(): # type: () -> None
    ReturnValueIgnoredError("testing")
    ReturnValueIgnoredError("testing", "foo")

# Generated at 2022-06-24 08:19:56.364317
# Unit test for function run_on_executor
def test_run_on_executor():
    from unittest.mock import patch

    def check_thread_pool_executor(method):
        with patch("tornado.concurrent.futures.ThreadPoolExecutor") as patch_executor:
            executor = patch_executor.return_value
            executor.submit.return_value = Future()
            method()
            assert executor.submit.call_count == 1

    @run_on_executor  # type: ignore
    def method_no_args():
        pass

    @run_on_executor(executor="_thread_pool")  # type: ignore
    def method_with_executor(self):
        pass

    class TestCase:
        executor = dummy_executor
        _thread_pool = dummy_executor

    test_case = TestCase()
    check_thread_pool

# Generated at 2022-06-24 08:19:59.465033
# Unit test for function is_future
def test_is_future():
    if hasattr(asyncio, "Future"):
        assert is_future(Future())
    assert is_future(futures.Future())



# Generated at 2022-06-24 08:20:10.279466
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado import gen, testing
    from tornado.platform.asyncio import AsyncIOMainLoop

    @gen.coroutine
    def test_future_set_result_unless_cancelled_helper():
        future = Future()
        future_set_result_unless_cancelled(future, None)
        self.assertTrue(future.done())
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, None)
        self.assertTrue(future.done())

    AsyncIOMainLoop().install()
    try:
        ioloop = asyncio.get_event_loop()
        ioloop.run_sync(test_future_set_result_unless_cancelled_helper)
    finally:
        AsyncIOMainLoop().close

# Generated at 2022-06-24 08:20:22.397735
# Unit test for function run_on_executor
def test_run_on_executor():
    # Python 3.7+ has a robust mock library, but before that we need to
    # use our own mock implementation.

    class MockExecutor:
        def __init__(self):
            self.submit_args = None  # type: Any

        def shutdown(self, wait: bool = True) -> None:
            pass

        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            self.submit_args = (fn, args, kwargs)
            return futures.Future()  # type: ignore

    class Foo:
        executor = MockExecutor()

        @run_on_executor
        def bar(self):
            return 1


# Generated at 2022-06-24 08:20:26.499192
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import gen_test

    future = Future()
    future.cancel()
    future_set_exc_info(future, sys.exc_info())



# Generated at 2022-06-24 08:20:32.543965
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(object):
        def __init__(self, result: Any) -> None:
            self.result = result
            self.executor = dummy_executor

        @run_on_executor
        def bar(self, arg: Any) -> Any:
            return arg

    @gen_test
    def f() -> None:
        foo = Foo(42)
        result = yield foo.bar(123)
        assert result == 123
        assert foo.result == 42

    AsyncTestCase().run_sync(f)



# Generated at 2022-06-24 08:20:34.519748
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future = Future()  # type: Future[None]
    chain_future(future, Future())
    future.set_result(None)



# Generated at 2022-06-24 08:20:40.088582
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    with pytest.raises(asyncio.InvalidStateError):
        future.set_result(1)

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled() == True


# Generated at 2022-06-24 08:20:51.515639
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest

    class Foo(object):
        executor = dummy_executor

        def __init__(self):
            self.x = 0

        @run_on_executor
        def setx(self, x):
            self.x = x

        @run_on_executor(executor="executor2")
        def setx2(self, x):
            self.x = x

    class Bar(object):
        _thread_pool = dummy_executor

        def __init__(self):
            self.x = 0

        @run_on_executor(executor="_thread_pool")
        def setx(self, x):
            self.x = x

    class Bar2(object):
        def __init__(self):
            self.x = 0

# Generated at 2022-06-24 08:20:54.747534
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # type: ignore
    future = Future()
    result = []

    def cb(f):
        result.append(f.result())

    future_add_done_callback(future, cb)
    assert not result

    future.set_result(42)
    assert result == [42]



# Generated at 2022-06-24 08:21:03.824800
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    exception_handler_called = False

    future = futures.Future()
    try:
        raise AssertionError("test")
    except AssertionError as e:
        future_set_exception_unless_cancelled(future, e)
        future.cancel()
        future_set_exception_unless_cancelled(future, e)

    def exception_handler(f: futures.Future) -> None:
        nonlocal exception_handler_called
        assert f.exception() is e
        exception_handler_called = True

    future.add_done_callback(exception_handler)

    assert exception_handler_called

# Generated at 2022-06-24 08:21:07.503025
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import time
    future = dummy_executor.submit(lambda: time.sleep(1))
    assert future.done() is True
    assert future.result() is None

# Generated at 2022-06-24 08:21:17.790926
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    io_loop = IOLoop.current()

    # Test a single done Future
    f = Future()
    f.set_result(None)
    g = Future()
    chain_future(f, g)
    assert g.done()

    # Test that chain_future can be called before the first Future is done
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(None)
    assert g.done()

    # Test that chain_future can be called at any time
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(None)
    h = Future()
    chain_future

# Generated at 2022-06-24 08:21:21.033416
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    ReturnValueIgnoredError('test')

# Generated at 2022-06-24 08:21:29.436990
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    @gen.coroutine
    def test(executor=None):
        future = Future()
        results = []
        future_add_done_callback(future, lambda future: results.append(future))
        assert results == []
        future.set_result(None)
        yield gen.moment
        assert results == [future]
    IOLoop.current().run_sync(lambda: test())



# Generated at 2022-06-24 08:21:32.519061
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    f1 = dummy_executor.submit(lambda x:x, "hello")
    print(f1.result())


# Generated at 2022-06-24 08:21:41.384689
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    calls = []

    def callback(f):
        calls.append(f)
        assert f is future

    future_add_done_callback(future, callback)
    assert calls == [future]
    assert not future.cancelled()

    calls = []
    future_add_done_callback(future, callback)
    assert calls == [future]
    assert not future.cancelled()

    future.set_result(None)
    assert calls == [future, future]
    assert not future.cancelled()

    future = Future()
    future.cancel()
    future_add_done_callback(future, callback)
    assert calls == [future, future]
    assert future.cancelled()

    calls = []
    future = Future()
    future.cancel()
    future.set

# Generated at 2022-06-24 08:21:51.241841
# Unit test for function run_on_executor
def test_run_on_executor():
    import threading
    import time

    class TestRunOnExecutor(object):
        def __init__(self):
            self.executor = ThreadPoolExecutor(1)

        @run_on_executor(executor='executor')
        def sleep(self, t):
            time.sleep(t)

    t = TestRunOnExecutor()
    a = t.sleep(5)
    b = t.sleep(5)
    assert not a.done()
    assert not b.done()
    time.sleep(1)
    assert not a.done()
    assert not b.done()
    a.result()
    assert a.done()
    assert not b.done()
    b.result()
    assert b.done()



# Generated at 2022-06-24 08:21:53.461786
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()
    print("Test DummyExecutor.shutdown finished")

# Generated at 2022-06-24 08:21:59.966045
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test_executor_task():
        loop=asyncio.get_event_loop()
        future=dummy_executor.submit(add_on_executor, 4, 5)
        print("Future:{}".format(future))
        result_future=loop.run_until_complete(future)
        print("Result of future:{}".format(result_future))

    def add_on_executor(first:int, second:int)->int:
        return first+second

    test_executor_task()


# Generated at 2022-06-24 08:22:03.751719
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.testing
    
    def return_a_future():
        future = Future()
        future_set_result_unless_cancelled(future, 5)
        return future

    @gen_test
    def test_dummy_executor():
        res = yield return_a_future()
        self.assertEqual(res, 5)



# Generated at 2022-06-24 08:22:10.049117
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class CalledError(Exception):
        pass

    class A(object):
        executor = dummy_executor

        @run_on_executor
        def method(self):
            # type: () -> int
            raise CalledError()

    a = A()
    f = a.method()
    with pytest.raises(CalledError):
        f.result()


# Generated at 2022-06-24 08:22:20.129465
# Unit test for function chain_future
def test_chain_future():
    class FakeFuture(object):
        def __init__(self, result):
            self.result = result

        def done(self):
            return True

        def result(self):
            return self.result

        def exception(self):
            return None

    test_result = 42
    future = FakeFuture(test_result)
    chained_future = Future()
    chain_future(future, chained_future)
    assert chained_future.result() == test_result
    future = FakeFuture(ReturnValueIgnoredError())
    chained_future = Future()
    chain_future(future, chained_future)
    assert chained_future.exception() == ReturnValueIgnoredError

# Generated at 2022-06-24 08:22:21.832650
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    dummy_executor.submit(lambda x : x+1, 1)

# Generated at 2022-06-24 08:22:30.463378
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    """Test function chain_future."""
    io_loop = IOLoop()

    def callback1(f: Future) -> None:
        pass

    def callback2(f: Future) -> None:
        pass

    f = Future()
    f2 = Future()
    chain_future(f, f2)

    if not f2.done():
        raise ValueError("chain_future failed 1")

    f = Future()
    f2 = Future()
    f.set_result(None)
    chain_future(f, f2)
    if not f2.done():
        raise ValueError("chain_future failed 2")

    f = Future()
    f2 = Future()
    f.add_done_callback(callback1)
    f.add_done_callback(callback2)


# Generated at 2022-06-24 08:22:33.289531
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(1)
    assert not is_future("foo")
    assert not is_future({"a": 1})
    assert not is_future(object())



# Generated at 2022-06-24 08:22:34.550649
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert isinstance(dummy_executor, DummyExecutor)


# Generated at 2022-06-24 08:22:38.754714
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    result = []
    executor = DummyExecutor()
    executor.submit(lambda: result.append(1), ())
    executor.submit(lambda: result.append(2), ())
    assert result == [1, 2]


# Generated at 2022-06-24 08:22:42.043437
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class TestClass:
        def __init__(self):
            pass

    test = TestClass()
    f = futures.Future()
    chain_future(f, test)



# Generated at 2022-06-24 08:22:45.289285
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test")

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 08:22:48.266918
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    f2 = Future()
    f.cancel()
    chain_future(f, f2)
    assert f2.cancelled()

    f3 = Future()
    chain_future(f, f3)



# Generated at 2022-06-24 08:22:58.533633
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest  # type: ignore
    from tornado.ioloop import IOLoop

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def thread_func(self, arg, kwarg=123):
            return arg * kwarg

        def test_run_on_executor(self):
            async def f():
                self.assertEqual(123, await self.thread_func(1))
                self.assertEqual(456, await self.thread_func(2, kwarg=228))

# Generated at 2022-06-24 08:23:04.907892
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f1 = asyncio.Future()
    future_set_result_unless_cancelled(f1, None)
    assert f1.done()
    f2 = asyncio.Future()
    f2.cancel()
    future_set_result_unless_cancelled(f2, None)
    assert f2.done()
    with pytest.raises(asyncio.InvalidStateError):
        future_set_result_unless_cancelled(f2, None)

# Generated at 2022-06-24 08:23:06.235725
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    f = dummy_executor.submit(lambda: 1 + 1)
    assert f.result() == 2

# Generated at 2022-06-24 08:23:08.642303
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass

# Generated at 2022-06-24 08:23:10.446091
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dE = DummyExecutor()
    dE.shutdown(True)

# Generated at 2022-06-24 08:23:12.279073
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert is_future(Future())
    assert not is_future(futures.Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:23:18.554471
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    result = []
    e = DummyExecutor()

    def c():
        result.append(1)

    f = e.submit(c)
    assert not f.done()
    assert not result
    f.result()
    assert result == [1]

    def a():
        raise Exception("hello world")

    f = e.submit(a)
    try:
        f.result()
    except Exception as e:
        assert str(e) == "hello world"
    else:
        assert False



# Generated at 2022-06-24 08:23:19.726481
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:23:24.016769
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)  # type: ignore
    assert not is_future(1)
    assert not is_future("")
    assert not is_future(object())
    assert not is_future([])
    assert is_future(futures.Future())
    assert is_future(Future())

# Generated at 2022-06-24 08:23:25.412197
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy = DummyExecutor()
    dummy.submit(my_func)



# Generated at 2022-06-24 08:23:30.595599
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        # type: ignore
        raise ReturnValueIgnoredError('ignored')
    except ReturnValueIgnoredError as e:
        assert e.args == ('ignored',)
        assert str(e) == 'ignored'

# Generated at 2022-06-24 08:23:40.180530
# Unit test for function chain_future
def test_chain_future():
    from tornado.platform.asyncio import to_tornado_future
    from tornado.testing import ExpectedException

    future = asyncio.Future()
    future2 = Future()
    chain_future(future, future2)

    future.set_result(1)
    assert future2.result() == 1

    future = asyncio.Future()
    future2 = Future()
    chain_future(future2, future)

    future2.set_result(2)
    assert future.result() == 2

    future = asyncio.Future()
    future2 = Future()
    future3 = Future()
    future3.cancel()
    chain_future(future, future2)
    chain_future(future, future3)

    future.set_result(3)
    assert future2.result() == 3

# Generated at 2022-06-24 08:23:48.603427
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    future3 = Future()  # type: Future[str]

    # future1 finishes
    chain_future(future1, future2)
    chain_future(future1, future3)
    future1.set_result('foo')
    assert future2.result() == 'foo'
    assert future3.result() == 'foo'

    # future2 finishes
    future1 = Future()  # type: Future[str]
    future2 = Future()  # type: Future[str]
    future3 = Future()  # type: Future[str]
    chain_future(future2, future3)
    chain_future(future1, future2)
    future2.set_result('foo')
    assert future

# Generated at 2022-06-24 08:23:53.896264
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()  # type: Future[str]
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), ValueError)


# Unit tests for function future_add_done_callback

# Generated at 2022-06-24 08:23:58.706257
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 4)
    assert future.done()
    assert 4 == future.result()



# Generated at 2022-06-24 08:24:03.238587
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "success")
    assert future.result() == "success"
    assert not future.cancel()
    future_set_result_unless_cancelled(future, "cancel")
    assert not future.done()



# Generated at 2022-06-24 08:24:13.887283
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    if sys.version_info < (3, 5):
        # No testing of asyncio futures until we support Python 3.5.
        # (The asyncio module was introduced in 3.4, but it was not
        # stable until 3.5. We could go back to 3.4 if we packaged
        # a private copy of asyncio, but that seems like more work
        # than this feature is worth.)
        return

    # Wrapper for concurrent.futures.Future that also has an
    # "add_done_callback" method.  This lets the tests check that
    # the Future API is used correctly.

# Generated at 2022-06-24 08:24:16.532176
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future() # type: Future
    f.set_exception(ValueError())
    def test_func():
        try:
            raise ValueError()
        except ValueError:
            future_set_exc_info(f, sys.exc_info())
    test_func()

# Generated at 2022-06-24 08:24:18.671963
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(object())
    assert not is_future(None)



# Generated at 2022-06-24 08:24:21.036140
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda x:x, "test")


if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-24 08:24:30.406547
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from concurrent.futures import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    executor = dummy_executor
    loop = IOLoop.current()
    future = executor.submit(lambda x: x * x, 2)
    if isinstance(future, Future):
        future_set_result_unless_cancelled(future, 2)

    assert(future.done())
    IOLoop.current().stop()

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:24:38.996549
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures
    import functools
    import os
    import threading
    import time

    executor = concurrent.futures.ThreadPoolExecutor(16)
    io_loop = IOLoop()

    class Foo(object):
        executor = executor

        def compute(self, a, b):
            io_loop.add_callback(io_loop.stop)
            return a + b

        def compute_with_callback(self, a, b):
            io_loop.add_callback(io_loop.stop)
            return (a, b)

    foo = Foo()
    f = foo.compute(1, 2)
    assert isinstance(f, concurrent.futures.Future)
    io_loop.start()
    assert f.result() == 3


# Generated at 2022-06-24 08:24:49.637444
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest

    class TestException(Exception):
        pass

    class FutureSetExcInfoTest(unittest.TestCase):
        @staticmethod
        def f1():
            raise TestException

        @staticmethod
        def f2():
            1 / 0

        def test_function_with_error(self):
            try:
                self.f1()
            except Exception:
                f = Future()
                future_set_exc_info(f, sys.exc_info())
                exc_info = f.exception()
                self.assertIsInstance(exc_info, TestException)

        def test_function_without_error(self):
            try:
                self.f2()
            except Exception:
                f = Future()
                future_set_exc_info(f, sys.exc_info())

# Generated at 2022-06-24 08:24:51.369875
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = DummyExecutor().submit(lambda: 1)
    assert future.result() == 1

# Generated at 2022-06-24 08:24:58.889120
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.testing

    class _TestHandler(tornado.testing.AsyncTestCase):
        @tornado.testing.gen_test
        def test_future_add_done_callback(self):
            from tornado.concurrent import Future

            future = Future()

            def callback(future):
                future.set_result(True)

            future_add_done_callback(future, callback)

            self.assertTrue(future.result())

    # Run tests.
    _TestHandler().test_future_add_done_callback()

# Generated at 2022-06-24 08:25:00.924543
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert isinstance(dummy_executor, futures.Executor)


# Generated at 2022-06-24 08:25:04.252044
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import unittest.mock
    fut = Future()
    callback = unittest.mock.Mock()
    future_add_done_callback(fut, callback)
    assert not callback.called
    fut.set_result(42)
    assert callback.called
    assert callback.call_args[0] == (fut,)



# Generated at 2022-06-24 08:25:09.199362
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(asyncio.Future())
    assert is_future(concurrent.futures.Future())
    assert not is_future(0)
    assert not is_future(True)
    assert not is_future(None)

# Generated at 2022-06-24 08:25:12.587862
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    invoked = []
    future_add_done_callback(future, lambda future: invoked.append(future))
    assert not invoked
    future.set_result(None)
    assert invoked == [future]

# Generated at 2022-06-24 08:25:17.847070
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def raise_exception():
        raise Exception("testing")

    future = Future()
    assert not future.done()
    try:
        # Trigger an exception
        raise_exception()
    except:
        # Capture and set the exception info
        future_set_exc_info(future, sys.exc_info())
    assert future.done()
    assert future.exception() is not None

# Generated at 2022-06-24 08:25:23.916270
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert exc == future.exception()
    future_set_exception_unless_cancelled(future, exc)
    assert exc == future.exception()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert exc == future.exception()

# Generated at 2022-06-24 08:25:29.901971
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    result = dummy_executor.submit(lambda x, y: x + y, 5, 10)
    assert result == 15
    assert result.done() == True
    assert result.result() == 15
    assert result.executor == dummy_executor


# Generated at 2022-06-24 08:25:36.068356
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    try:
        future_set_result_unless_cancelled(future, 1)
        assert False, 'should raise exception'
    except asyncio.InvalidStateError:
        pass
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, 1)
        assert False, 'should raise exception'
    except asyncio.InvalidStateError:
        pass
    assert future.result() is None
    future_set_result_unless_cancelled(future, 1)
    assert future.result() is None

# Generated at 2022-06-24 08:25:39.339040
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a = dummy_executor.submit(lambda: 1+1)
    assert a.result() == 2


# Generated at 2022-06-24 08:25:41.258727
# Unit test for function is_future
def test_is_future():
    f = Future()
    assert is_future(f)
    cf = futures.Future()  # type: futures.Future
    assert is_future(cf)

# Generated at 2022-06-24 08:25:41.768095
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    DummyExecutor()

# Generated at 2022-06-24 08:25:43.198870
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:25:44.874964
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:25:46.098080
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()


# Generated at 2022-06-24 08:25:47.387179
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert not is_future("not a future")

# Generated at 2022-06-24 08:25:52.876348
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

    future = Future()
    future_set_result_unless_cancelled(future, 2)
    assert not future.cancelled()
    assert future.result() == 2



# Generated at 2022-06-24 08:26:02.021954
# Unit test for function chain_future
def test_chain_future():
    from tornado.concurrent import Future
    from tornado.concurrent import TracebackFuture
    from tornado.concurrent import futures

    f1 = futures.Future()
    f1_result = object()
    f2 = TracebackFuture()
    f2_result = object()
    f3 = Future()
    f3_result = object()

    # f1 -> f2 -> f3

    chain_future(f1, f2)
    f2.add_done_callback(lambda f2: f2.result().append(f2_result))
    chain_future(f2, f3)
    f3.add_done_callback(lambda f3: f3.result().append(f3_result))

    # f1 completes successfully
    f1.set_result([])
    assert f1.result() == []

# Generated at 2022-06-24 08:26:03.398834
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    assert executor.shutdown() == None


# Generated at 2022-06-24 08:26:11.967779
# Unit test for function chain_future
def test_chain_future():
    # Use an Executor to ensure the results are ready
    executor = futures.ThreadPoolExecutor(2)
    io_loop = IOLoop.current()

    @run_on_executor
    def f(x):
        return x

    def target(fut, arg):
        # type: (Future[int], int) -> None
        io_loop.add_future(f(arg), lambda f: fut.set_result(f.result()))

    fut1 = Future()  # type: Future[int]
    future_add_done_callback(fut1, lambda f: f.result() + 1)
    fut2 = Future()  # type: Future[int]
    future_add_done_callback(fut2, lambda f: f.result() * 2)

# Generated at 2022-06-24 08:26:16.558194
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:26:24.857660
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock
    from tornado.ioloop import IOLoop

    f = Future()
    f.cancel()

    with mock.patch("tornado.gen.app_log.error") as log_mock:
        future_set_exception_unless_cancelled(f, RuntimeError("error"))
        log_mock.assert_called_once()

    f = Future()
    IOLoop.current().run_sync(lambda: future_set_exception_unless_cancelled(f, RuntimeError("error")))
    assert f.exception() is not None

# Generated at 2022-06-24 08:26:37.370597
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit == DummyExecutor().submit
    assert dummy_executor == DummyExecutor()


if __name__ == "__main__":
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class FutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

            f3 = Future()
            chain_future(f3, f2)

# Generated at 2022-06-24 08:26:41.411505
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    test_future = Future()

    def raise_exc():
        raise Exception("test exception")

    raise_exc()

    future_set_exc_info(test_future, sys.exc_info())
    assert test_future.exception() is not None

# Generated at 2022-06-24 08:26:46.239139
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():

    class FakeFuture(Future):
        def __init__(self, loop: Any) -> None:
            super().__init__(loop=loop)
            self._cancelled = False

        def cancel(self) -> bool:
            self._cancelled = True
            return True

        def cancelled(self) -> bool:
            return self._cancelled

    class FakeIOLoop(object):
        def add_future(self, future: Future, callback: Callable) -> None:
            self.expected_future = future
            self.expected_callback = callback

    loop = FakeIOLoop()
    future = FakeFuture(loop)
    exc = Exception("oops")

    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    assert loop.expected_future is None

# Generated at 2022-06-24 08:26:48.946863
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    obj = DummyExecutor()
    print(obj.submit(lambda x: x, [1,2]))
    print(obj.shutdown())


# Generated at 2022-06-24 08:26:54.839232
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()

    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future.cancel()
    future_set_result_unless_cancelled(future, "bar")
    assert future.cancelled()

# Generated at 2022-06-24 08:26:56.718776
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    excutor = DummyExecutor()
    assert excutor.shutdown(wait=True) == None

# Generated at 2022-06-24 08:26:59.770457
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    dummy_executor.submit(lambda x: x + 1, 3)
    assert dummy_executor is not None


# Generated at 2022-06-24 08:27:07.747955
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(RuntimeError())
    g.add_done_callback(lambda f: f.exception())
    assert_raises(RuntimeError, g.result)
    f = Future()
    g = Future()
    f.set_result(42)
    chain_future(f, g)
    assert g.result() == 42
    f = Future()
    g = Future()
    f.set_exception(RuntimeError())
    chain_future(f, g)

# Generated at 2022-06-24 08:27:11.195584
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 123)
    assert future.result() == 123
    future_set_result_unless_cancelled(future, 456)
    assert future.result() == 123


# Generated at 2022-06-24 08:27:12.994783
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert not future.done()
    future.exception()



# Generated at 2022-06-24 08:27:17.651794
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent.futures import Future

    future = Future()
    called = []
    future_add_done_callback(future, lambda f: called.append(1))
    future_add_done_callback(future, lambda f: called.append(f.result()))

    assert not called
    future.set_result(None)

# For backwards compatibility with Tornado < 4.2.

# Generated at 2022-06-24 08:27:29.398509
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent.futures import Executor

    def test_function(*args: Any, **kwargs: Any) -> int:
        return 5

    class TestClass:
        _dummyExecutor = DummyExecutor()

        @run_on_executor(executor="_dummyExecutor")
        def test_function(*args: Any, **kwargs: Any) -> int:
            return 5

        def test_function_with_run_on_executor(*args: Any, **kwargs: Any) -> int:
            return self.test_function(*args, **kwargs)

    test_instance = TestClass()
    assert isinstance(test_instance._dummyExecutor, Executor)

    f1: Future[int] = dummy_executor.submit(test_function)

# Generated at 2022-06-24 08:27:31.932055
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    assert dummy_executor is not None
    assert dummy_executor.submit is not None


# Generated at 2022-06-24 08:27:41.275784
# Unit test for function future_set_exc_info
def test_future_set_exc_info():

    if sys.version_info < (3, 5, 2):
        # A bug in Python 3.5.1 (fixed in 3.5.2) causes this test to fail.
        raise unittest.SkipTest('Known bug in Python 3.5.1.')

    from unittest.case import TestCase
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.log import gen_log

    class FutureSetExcInfoTest(TestCase):

        @gen.coroutine
        def _test_future_set_exc_info(self):
            try:
                yield 1 / 0
            except ZeroDivisionError:
                exc_info = sys.exc_info()

            # This is the public API, which will use the new conversion
            # code on Python 3.5+
            f1 = gen.Future