

# Generated at 2022-06-24 08:17:36.505623
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    str1 = "Hello"
    str2 = "world"
    dummy_executor.shutdown()
    if dummy_executor.submit(lambda x, y : x + y, str1, str2).result() == str1 + str2:
        print("Test Successful")
    else:
        print("Test Failed")

# Generated at 2022-06-24 08:17:41.981101
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def test():
        future = Future()
        future_set_result_unless_cancelled(future, None)
        future_set_result_unless_cancelled(future, None)
        value = await future



# Generated at 2022-06-24 08:17:43.000199
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-24 08:17:48.452113
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    import time

    # Blocking function
    def sleep(num):
        time.sleep(num)
        return True

    result = dummy_executor.submit(sleep, 2)
    assert result.done()
    assert isinstance(result, futures.Future)
    assert result.result() == True


if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:17:53.437536
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        test_future_add_done_callback.callback_result = future.result()

    f = Future()
    future_add_done_callback(f, callback)
    f.set_result(42)
    assert test_future_add_done_callback.callback_result == 42



# Generated at 2022-06-24 08:17:55.478323
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class Test(object):
        @return_future
        def fetch(self, callback=None):
            raise ReturnValueIgnoredError()

# Generated at 2022-06-24 08:18:06.109426
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    future = loop.create_task(asyncio.sleep(0))
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.done()

    future = Future()
    future.set_result(None)
    future_set_result_unless_cancelled(future, "result")
    assert future.done()

    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.done()



# Generated at 2022-06-24 08:18:09.268676
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-24 08:18:11.610120
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()



# Generated at 2022-06-24 08:18:16.677613
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    # Since the Future is not done, these should not throw:
    future_set_exc_info(f, sys.exc_info())
    f.set_exception(Exception())
    future_set_exc_info(f, sys.exc_info())


# Generated at 2022-06-24 08:18:23.503316
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado import testing
    from tornado.ioloop import IOLoop

    class ChainFutureTest(testing.AsyncTestCase):
        def test_chain(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 08:18:25.434152
# Unit test for function is_future
def test_is_future():
    f1 = Future()
    f2 = futures.Future()
    assert is_future(f1)
    assert is_future(f2)

# Generated at 2022-06-24 08:18:33.706539
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

# Generated at 2022-06-24 08:18:40.479619
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future_1, future_2 = Future(), Future()  # type: Future, Future
    future_1.cancel()

    future_set_result_unless_cancelled(future_1, 0)
    assert future_1.done()
    assert future_1.cancelled()

    future_set_result_unless_cancelled(future_2, 0)
    assert future_2.done()
    assert not future_2.cancelled()
    assert future_2.result() == 0



# Generated at 2022-06-24 08:18:49.908291
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    def callback1(future):  # type: ignore
        """Tests that adding a callback to a completed Future stores the value"""
        assert future.result() == 1
        assert not future.cancelled()
        assert not future.done()

    def callback2(future):  # type: ignore
        """Tests that adding a callback to an uncompleted future waits for it"""
        assert future.result() == 2
        assert not future.cancelled()
        assert not future.done()

    value1 = 1
    value2 = 2
    future1 = asyncio.Future()  # type: Future
    future2 = asyncio.Future()  # type: Future
    future1.set_result(value1)
    future_add_done_callback(future1, callback1)
    future_add_done

# Generated at 2022-06-24 08:18:50.736376
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()


# Generated at 2022-06-24 08:18:51.562016
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError(b"test")

# Generated at 2022-06-24 08:18:53.809612
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:19:01.736308
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.set_result(True)
    assert f.done()
    assert f.result()
    # The future was done, so this should not raise an exception.
    assert future_set_result_unless_cancelled(f, True) is None
    # Cancel the future.
    f.cancel()
    assert f.cancelled()
    # The future was cancelled, so this should not raise an exception.
    assert future_set_result_unless_cancelled(f, True) is None

# Generated at 2022-06-24 08:19:08.516559
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    f2 = Future()
    f2.set_result(None)
    cond = asyncio.Condition()
    with cond:
        future_set_exception_unless_cancelled(f1, RuntimeError())
        future_set_exception_unless_cancelled(f2, RuntimeError())
        cond.wait_for(lambda: f1.exception() is not None and f2.done())
    assert isinstance(f1.exception(), RuntimeError)
    assert f2.done()


# Generated at 2022-06-24 08:19:12.313764
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def add(a,b):
        return a+b
    a = dummy_executor.submit(add,1,2)
    assert a.result() == 3

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:19:19.579928
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    future.cancel()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None
    assert future.cancelled()

# Generated at 2022-06-24 08:19:28.383667
# Unit test for function is_future
def test_is_future():
    class FutureSubclass(Future):
        pass

    class FutureSubclassWrapper(object):
        def __init__(self):
            self.wrapped_future = FutureSubclass()

        def __getattr__(self, attr):
            if attr == 'wrapped_future':
                return self.wrapped_future
            else:
                return getattr(self.wrapped_future, attr)

    assert is_future(Future())
    assert is_future(Future())
    assert is_future(FutureSubclass())
    assert is_future(FutureSubclassWrapper())
    assert not is_future(None)
    assert not is_future(FutureSubclass()
                         .then(lambda *args: None))
    assert not is_future({'wrap': FutureSubclass()})



# Generated at 2022-06-24 08:19:37.529997
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import unittest.mock as mock
    from tornado.ioloop import IOLoop
    import tornado.testing

    class FakeExecutor(object):
        def __init__(self):
            assert self.executor is FakeExecutor

        def submit(self, fn, *args, **kwargs):
            f = concurrent.futures.Future()
            try:
                f.set_result(fn(*args, **kwargs))
            except Exception:
                f.set_exc_info(sys.exc_info())
            return f

    class Test(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = FakeExecutor()
            self.counter = 0
            future_on_queue = None 

# Generated at 2022-06-24 08:19:48.113242
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import functools
    import time

    from tornado.escape import native_str
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def __init__(self, *args, **kwargs):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

            super(TestCase, self).__init__(*args, **kwargs)

        def get_new_ioloop(self):
            return self.io_loop

    class TestClass:
        @run_on_executor(executor='_thread_pool')
        def run_on_thread(self, a: int, b: int) -> int:
            return a + b


# Generated at 2022-06-24 08:19:56.158095
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import functools

    # The Executor class below is a bit more forgiving than
    # concurrent.futures.Executor in that its submit function can be
    # called with non-callable arguments, and in that case it just
    # returns a Future with the same type as the argument.
    class Executor(futures.Executor):
        def submit(
            self, fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            future = futures.Future()  # type: futures.Future[_T]
            if not callable(fn):
                future.set_result(fn)

# Generated at 2022-06-24 08:20:06.351079
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.done()
    assert future.exception()

    future = Future()
    future.set_result(1)
    assert future.done()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.result()
    assert not future.exception()

    future = Future()
    future.cancel()
    assert future.done()
    future_set_exception_unless_cancelled(future, Exception())
    assert not future.exception()
    assert not future.result()

# Generated at 2022-06-24 08:20:07.315715
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:20:11.036881
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    @gen.coroutine
    def f():
        # type: () -> None
        future = Future() # type: Future
        assert not future.done()
        future_set_result_unless_cancelled(future, 1)
        assert future.done()

    IOLoop.current().run_sync(f)

# Generated at 2022-06-24 08:20:13.392038
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

# Generated at 2022-06-24 08:20:14.757836
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    return DummyExecutor()


# Generated at 2022-06-24 08:20:16.521463
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:20:24.708946
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """Unit test for function future_set_result_unless_cancelled"""
    f1 = Future()
    future_set_result_unless_cancelled(f1, 42)
    assert f1.result() == 42

    f2 = Future()
    f2_cancelled = f2.cancel()
    assert f2_cancelled == True
    f2_cancelled = f2.cancel()
    assert f2_cancelled == False
    with pytest.raises(asyncio.InvalidStateError):
        future_set_result_unless_cancelled(f2, 42)



# Generated at 2022-06-24 08:20:26.474797
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()  # ensures exception is logged
    future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-24 08:20:35.249326
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import io
    import sys

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.future1 = Future()
            self.future2 = Future()
            chain_future(self.future1, self.future2)

        def test_exception(self):
            e = Exception()
            self.future1.set_exception(e)
            self.assertEqual(self.future2.exception(), e)

        def test_result(self):
            r = object()
            self.future1.set_result(r)
            self.assertEqual(self.future2.result(), r)

        def test_fail_after_complete(self):
            self.future1.set_result(object())

# Generated at 2022-06-24 08:20:38.335039
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()  # type: Future
    result = []

    future_add_done_callback(f, lambda fut: result.append(fut))
    assert not result
    f.set_result(None)
    assert result == [f]

    future_add_done_callback(f, lambda fut: result.append(fut))
    assert result == [f, f]



# Generated at 2022-06-24 08:20:39.596330
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x = DummyExecutor()
    x.shutdown()

# Generated at 2022-06-24 08:20:50.794604
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class FakeFuture:

        def __init__(self):
            self.result_set = False
            self.exception_set = False

        def set_result(self, result):
            self.result_set = True

        def set_exception(self, exception):
            self.exception_set = True

        def cancelled(self):
            return True

        def result(self):
            pass

        def exception(self):
            pass

    future = FakeFuture()
    future_set_result_unless_cancelled(future, None)
    assert not future.result_set
    assert not future.exception_set
    future_set_exception_unless_cancelled(future, Exception())
    assert not future.result_set
    assert not future.exception_set

# Generated at 2022-06-24 08:20:52.643107
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    print(type(dummy_executor))

# test for function run_on_executor

# Generated at 2022-06-24 08:20:58.473412
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        raise Exception("test 123")
    except Exception:
        exc_info = sys.exc_info()

    # test set_exception without cancel
    future = Future()
    future_set_exception_unless_cancelled(future, exc_info[1])
    assert future.exception() is not None
    assert future.exception() == exc_info[1]

    # test set_exception with cancel
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc_info[1])
    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-24 08:21:04.104475
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(future, exc)
    assert exc == future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert exc != future.exception()



# Generated at 2022-06-24 08:21:08.451748
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            super(TestChainFuture, self).tearDown()
            self.executor.shutdown()

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(None)
            yield f2

    test_chain_future()

# Generated at 2022-06-24 08:21:10.781681
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass


# Generated at 2022-06-24 08:21:12.664074
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class TornadoReturnValueIgnoredError(ReturnValueIgnoredError):
        pass

test_ReturnValueIgnoredError()

# Generated at 2022-06-24 08:21:22.831187
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest

    class FutureTests(unittest.TestCase):
        def setUp(self):
            self.future = Future()
            self.cancelled_future = Future()
            self.cancelled_future.cancel()

        def test_future_set_result_unless_cancelled(self):
            # Ensure that future.set_result() on a cancelled future
            # does not raise an exception.
            future_set_result_unless_cancelled(self.future, 123)
            self.assertEqual(self.future.result(), 123)

            future_set_result_unless_cancelled(self.cancelled_future, 123)
            self.assertTrue(self.cancelled_future.cancelled())


# Generated at 2022-06-24 08:21:26.686915
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda a: a + 1, 1)
    future.result()
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:21:29.629200
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()

# Generated at 2022-06-24 08:21:31.778888
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        future.set_result(1)

    future = Future()
    future_add_done_callback(future, callback)
    future.cancel()

    assert future.cancelled()



# Generated at 2022-06-24 08:21:37.214751
# Unit test for function chain_future
def test_chain_future():
    async def async_future_test():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        assert not future2.done()
        future1.set_result(42)
        assert future2.done()
        assert future2.result() == 42

    async def concurrent_future_test():
        future1 = futures.Future()
        future2 = Future()
        chain_future(future1, future2)
        assert not future2.done()
        future1.set_result(42)
        assert future2.done()
        assert future2.result() == 42

    async def raise_in_chain():
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)

# Generated at 2022-06-24 08:21:42.037198
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None

    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc

    future = Future()
    future.cancel()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None
    # TODO: Check app_log output

# Generated at 2022-06-24 08:21:43.171384
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("a")
    except ReturnValueIgnoredError as e:
        e.message

# Generated at 2022-06-24 08:21:52.238811
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.concurrent import Future, chain_future
    from tornado.platform.asyncio import AsyncIOMainLoop

    if type(Future()) is not Future:
        # We're running the tests on the asyncio event loop.
        raise unittest.SkipTest('test only applies to Tornado Future')

    result = []
    # This function is difficult to test with standard mocks because
    # mocks do a poor job of inspecting the call stack. So use a real
    # Future and AsyncIOMainLoop to test it.
    future = Future()
    future_add_done_callback(future, result.append)
    chain_future(Future(), future)
    assert not result
    io_loop = AsyncIOMainLoop()
    io_loop.make_current()
    io_loop.run_sync(lambda: None)

# Generated at 2022-06-24 08:22:03.045453
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async def test_future_set_result_unless_cancelled():
        try:
            future = Future()
            future_set_result_unless_cancelled(future, 10)
            assert 10 == await future
            future = Future()
            future.cancel()
            future_set_result_unless_cancelled(future, 10)
        except Exception as e:
            assert False
    import tornado.testing
    tornado.testing.run_sync(test_future_set_result_unless_cancelled)


# Generated at 2022-06-24 08:22:05.532497
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    e = DummyExecutor()
    assert e.submit(lambda s: s, 'result') == 'result'



# Generated at 2022-06-24 08:22:10.541008
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_exception(Exception("Exception raised"))
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("Exception raised"))
    assert isinstance(f.exception(), Exception) # check if future is cancelled


# Generated at 2022-06-24 08:22:22.035881
# Unit test for function chain_future
def test_chain_future():  # pragma: no cover
    import unittest
    import tornado
    import tornado.testing
    import concurrent.futures

    class ChainFutureTest(unittest.TestCase):
        def test_chain(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(123)
            self.assertEqual(f1.result(), 123)
            self.assertEqual(f2.result(), 123)

        def test_chain_exc(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

            class MyExc(Exception):
                pass

            f1.set_exception(MyExc())
            self.assertRaises(MyExc, f2.result)

       

# Generated at 2022-06-24 08:22:26.674505
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None

    def callback(future):
        # type: (Future[int]) -> None
        assert future.result() == 1

    future = Future()
    # cancel the future and then set result, this should not raise an exception
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    future.add_done_callback(callback)

# Generated at 2022-06-24 08:22:31.515059
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) is True
    assert is_future(futures.Future()) is True
    assert is_future(Future(lambda: None)) is True
    assert is_future(futures.Future(lambda: None)) is True
    assert is_future(None) is False
    assert is_future(1) is False

# Generated at 2022-06-24 08:22:32.228623
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:22:38.051909
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    future = Future()
    future_set_result_unless_cancelled(future, 2)
    assert future.done()
    assert future.result() == 2



# Generated at 2022-06-24 08:22:40.714375
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future_result(future), ValueError)



# Generated at 2022-06-24 08:22:42.090982
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    de = DummyExecutor()
    de.shutdown()



# Generated at 2022-06-24 08:22:45.591000
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(None)



# Generated at 2022-06-24 08:22:51.059857
# Unit test for function chain_future
def test_chain_future():   # pragma: no cover
    import time

    @gen.coroutine
    def f1():
        time.sleep(1)
        raise gen.Return(42)

    @gen.coroutine
    def f2():
        time.sleep(1)
        raise gen.Return(100)

    loop = ioloop.IOLoop.current()

    a = f1()
    b = f2()

    chain_future(a, b)

    assert loop.run_sync(b) == 42

# Generated at 2022-06-24 08:22:53.574654
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy = DummyExecutor()
    assert callable(dummy) == False, "dummy is not callable"
    print("Everything passed!")


# Generated at 2022-06-24 08:22:55.339373
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    f = DummyExecutor()
    str(f)
    f.shutdown(wait=True)



# Generated at 2022-06-24 08:23:07.994124
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    future = Future()

    # Future instance
    future_add_done_callback(future, lambda fut: fut.set_result("callback"))
    assert future.result() == "callback"

    # type: futures.Future
    future = concurrent.futures.Future()

    # future is already set
    future.set_result("yes")
    future_add_done_callback(future, lambda fut: fut.set_result("NO"))
    assert future.result() == "yes"

    # future is not set
    future_add_done_callback(future, lambda fut: fut.set_result("ok"))
    assert future.result() == "ok"

    # Make sure this works with completely non-futures

# Generated at 2022-06-24 08:23:09.871357
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    return ReturnValueIgnoredError("test")

# Generated at 2022-06-24 08:23:12.264361
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))
    assert f.exception() is None



# Generated at 2022-06-24 08:23:15.551084
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-24 08:23:17.143110
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def add(a, b):
        return a + b
    future = dummy_executor.submit(add, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-24 08:23:17.708106
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:23:20.637107
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.submit(lambda: 1)
    d.shutdown()
    d.submit(lambda: 2)

# Generated at 2022-06-24 08:23:28.046728
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    from tornado import gen

    @gen.coroutine
    def coroutine_func(a, b):
        # type: (int, int) -> int
        raise gen.Return(a + b)

    def callback_func(f):
        # type: (futures.Future) -> None
        assert f.result() == 6, f.result()

    coroutine_func(1, 2).add_done_callback(callback_func)


if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:23:29.509307
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except Exception:
        pass

# Generated at 2022-06-24 08:23:33.325654
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test
    
    class DummyExecutorTest(AsyncTestCase):
        @gen_test
        async def test_submit(self):
            def func():
                return True

            future = dummy_executor.submit(func)
            assert future.done()
            assert await future
    
    
    unittest.main()


# Generated at 2022-06-24 08:23:40.247686
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest.mock
    import tornado.platform.asyncio

    f = Future()
    assert not f.done()
    exc_info = (None, OSError(), None)
    with unittest.mock.patch("tornado.ioloop.IOLoop.current") as current:
        current.return_value = tornado.platform.asyncio.AsyncIOMainLoop()
        future_set_exc_info(f, exc_info)
    assert f.done()
    assert f.exception() is exc_info[1]

# Generated at 2022-06-24 08:23:51.547425
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    import logging
    from tornado.log import gen_log

    class DummyExecutorSubmitTest(unittest.TestCase):
        def test_submit(self):

            # test for cancelled Future
            future = DummyExecutor().submit(gen_log.info, 'info')
            future.cancel()
            future.set_result(1)  # should not raise an exception

            # test for done Future
            future.cancel()
            future.set_result(1)

            # test for exception
            future = DummyExecutor().submit(gen_log.info, 'future')
            # if future.done():
            #     raise Exception("done")
            future.set_result(1)

            # test for _NO_RESULT

# Generated at 2022-06-24 08:23:55.428446
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def print_result(future):
        print("result: {}".format(future.result()))

    def add(a, b):
        return a + b

    future = dummy_executor.submit(add, 2, 3)
    future.add_done_callback(print_result)

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:23:58.282040
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(asyncio.Future())
    assert is_future(concurrent.futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:24:01.353735
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class CustomException(Exception):
        pass

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(
        future, CustomException("Custom message")
    )

# Generated at 2022-06-24 08:24:02.984581
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    pass


# Generated at 2022-06-24 08:24:05.423418
# Unit test for function is_future
def test_is_future():
    from tornado.concurrent import Future  # noqa: F811
    assert is_future(Future())
    assert not is_future(1)



# Generated at 2022-06-24 08:24:09.969564
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def function(self):
            raise Exception()

    foo = Foo()
    foo_function_future = foo.function()
    foo_function_future.result()

# Generated at 2022-06-24 08:24:17.460529
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def bar(self, arg):
            return arg + 1

        @run_on_executor(executor='_thread_pool')
        def baz(self, arg):
            return arg - 1

        def __init__(self):
            self._thread_pool = dummy_executor

    foo = Foo()
    assert not foo.bar.running()
    f = foo.bar(42)
    assert f is not None
    assert foo.bar.running()
    assert foo.bar(42) is not f
    f.add_done_callback(lambda f: f.result())
    f.result()
    f = foo.baz(42)
    f.result()

# Generated at 2022-06-24 08:24:23.172726
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    results = []

    def done(future):
        results.append(future)

    future_add_done_callback(f, done)
    f.set_result(3)
    assert results
    f = Future()
    future_add_done_callback(f, done)
    f.set_result(4)
    assert len(results) == 2



# Generated at 2022-06-24 08:24:34.997145
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    @gen.coroutine
    def f():
        future = concurrent.futures.Future()
        future_set_result_unless_cancelled(future, 1)
        assert future.result() == 1

    @gen.coroutine
    def g():
        future = Future()
        future_set_result_unless_cancelled(future, 1)
        assert (yield future) == 1

    @gen.coroutine
    def h():
        future = concurrent.futures.Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 1)
        yield future

    @gen.coroutine
    def i():
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, 1)
        yield future
    I

# Generated at 2022-06-24 08:24:45.981181
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import io
    import logging
    import sys

    class StringIOHandler(logging.StreamHandler, io.StringIO):
        """Handler which writes to a StringIO"""
        def __init__(self) -> None:
            io.StringIO.__init__(self)
            logging.StreamHandler.__init__(self, self)

        def flush(self) -> None:
            pass

    handler = StringIOHandler()

    future = Future()
    try:
        raise Exception()
    except Exception:
        ex_info = sys.exc_info()
    future_set_exc_info(future, ex_info)
    if not future.exception():
        raise Exception("future_set_exc_info failed to set an exception")

# Generated at 2022-06-24 08:24:55.318981
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.testing

    class foo(object):
        executor = 'mock'

        @run_on_executor
        def bar(self):
            return "baz"

    with unittest.mock.patch('tornado.concurrent.run_on_executor') as m_run_on_executor:
        f = foo()
        f.bar()
    m_run_on_executor.assert_called_once_with(executor='mock')(foo.bar)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_run_on_executor()

# Generated at 2022-06-24 08:24:56.164672
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    tmp = DummyExecutor()
    tmp.shutdown()


# Generated at 2022-06-24 08:24:58.233859
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor1 = DummyExecutor()
    executor1.shutdown(wait = True)

# Generated at 2022-06-24 08:24:59.196837
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())

# Generated at 2022-06-24 08:25:01.427458
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    e = DummyExecutor()
    future = e.submit(lambda: 1)
    assert future.result() == 1

# Generated at 2022-06-24 08:25:05.390646
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = RuntimeError('some error')
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-24 08:25:10.666328
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future_cancel(future)
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-24 08:25:14.081003
# Unit test for function is_future
def test_is_future():
    assert is_future(None) == False
    assert is_future("") == False
    assert is_future(1) == False
    assert is_future(Future()) == True
    assert is_future(futures.Future()) == True

# Generated at 2022-06-24 08:25:15.010215
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test")

# Generated at 2022-06-24 08:25:25.351617
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    l = []
    f = d.submit(lambda: l.append(1))
    assert l == [1]
    assert f.done()
    assert f.result() is None
    assert f.exception() is not None
    assert isinstance(f.exception(), RuntimeError)
    assert "Exception was never retrieved" in str(f.exception())

    # test that Future is compatible with asyncio.as_completed
    assert not f.cancelled()
    assert not f.running()
    f = d.submit(lambda: l.append(1))
    assert f.done()
    assert not f.cancelled()
    assert not f.running()

    # test that Future is compatible with asyncio.gather

# Generated at 2022-06-24 08:25:34.407741
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.ioloop import IOLoop
    from concurrent import futures

    to_cancel = None

    try:
        f1 = asyncio.Future()  # type: Future
        f2 = futures.Future()  # type: futures.Future
        to_cancel = f1
        future_set_exc_info(f1, sys.exc_info())
        future_set_exc_info(f2, sys.exc_info())
        assert f1.exception() is not None
        assert f2.exception() is not None
    finally:
        if to_cancel is not None:
            to_cancel.cancel()
        IOLoop.current().stop()
        IOLoop.current().start()



# Generated at 2022-06-24 08:25:43.791253
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    import time
    import threading
    def foo(a,b):
        return a+b
    class TestDummyExecutor(unittest.TestCase):
        def test_submit(self):
            future = dummy_executor.submit(foo,1,2)
            self.assertEqual(future.result(),3)
        def test_submit_with_exception(self):
            with self.assertRaises(ZeroDivisionError):
                future = dummy_executor.submit(lambda:1/0)
                time.sleep(0.2)
                future.result()
    unittest.main()


# Generated at 2022-06-24 08:25:47.513284
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def f():
        raise Exception("test")

    f()
    exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    future.result()

# Generated at 2022-06-24 08:25:51.826460
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async_future = Future()
    future_set_result_unless_cancelled(async_future, 1)
    assert async_future.result() == 1

    async_future = Future()
    future_set_result_unless_cancelled(async_future, Exception())
    assert async_future.exception() is not None


# Generated at 2022-06-24 08:26:01.111993
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import time

    f1 = Future()
    f2 = Future()

    f1.set_result(0)
    f2.set_exception(Exception())

    def set_result0(future):
        future.set_result(0)

    def set_result1(future):
        future.set_result(1)

    def set_exception(future):
        future.set_exception(Exception())

    def raise_exception(future):
        raise Exception()

    def sleep(future):
        time.sleep(0.01)

    def test_method(callback1=None, callback2=None, callback3=None, callback4=None):
        f3 = Future()
        if callback1:
            future_add_done_callback(f3, callback1)
        if callback2:
            future_

# Generated at 2022-06-24 08:26:01.980376
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    assert ReturnValueIgnoredError()


# Generated at 2022-06-24 08:26:07.240046
# Unit test for function run_on_executor
def test_run_on_executor():
    from unittest.mock import Mock
    import os

    executor = Mock()
    future = Mock()
    executor.submit = Mock(return_value=future)

    class TestHandler(object):
        executor = executor
        io_loop = os.urandom

        @run_on_executor
        def foo(self):
            future.set_result(b"foo")

    handler = TestHandler()
    handler.foo()
    executor.submit.assert_called_once_with(handler.foo, handler)
    future.set_result.assert_called_once_with(b"foo")

# Generated at 2022-06-24 08:26:18.766140
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def raise_exc():
        raise Exception("see?")

    class TornadoFuture(Future):
        def exc_info(self):
            # Dummy implementation for a Tornado Future.
            return sys.exc_info()

    for cls in Future, TornadoFuture:
        fut = cls()
        fut.set_result(1)
        future_set_exc_info(fut, sys.exc_info())
        assert fut.exception() is not None
        try:
            fut.result()
        except Exception:
            pass
        else:
            raise ValueError("This future should have an exception")

        fut2 = cls()
        fut2.cancel()
        fut2.set_result(None)
        future_set_exc_info(fut2, sys.exc_info())
        assert fut2.exception

# Generated at 2022-06-24 08:26:28.285029
# Unit test for function chain_future
def test_chain_future():
    @typing.no_type_check
    def maybe_async(value: bool) -> Future:
        f = Future()
        if value:
            f.set_result(42)
        else:
            f.set_result(84)
        return f

    result = []

    def cb(a: Future) -> None:
        result.append(a.result())

    def cb_exc(a: Future) -> None:
        result.append(a.exception())

    maybe_async(True).add_done_callback(cb)
    assert result == [42]

    result = []
    maybe_async(True).add_done_callback(cb_exc)
    assert result == [None]

    maybe_async(False).add_done_callback(cb)

# Generated at 2022-06-24 08:26:31.200187
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    try:
        dummy_executor = DummyExecutor()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-24 08:26:38.588411
# Unit test for function chain_future
def test_chain_future():
    # Test passing result
    first = Future()
    second = Future()
    chain_future(first, second)
    first.set_result(42)
    assert second.result() == 42

    # Test passing error
    first = Future()
    second = Future()
    chain_future(first, second)
    first.set_exception(RuntimeError("oops"))
    try:
        second.result()
        assert False, "should have thrown an exception"
    except RuntimeError as e:
        assert "oops" in str(e)

    # Test catching cancel
    first = Future()
    second = Future()
    first.cancel()
    chain_future(first, second)
    assert second.cancelled()
    assert not first.cancelled()

    # Test chaining onto a completed future
    first = Future()

# Generated at 2022-06-24 08:26:45.323675
# Unit test for function future_add_done_callback
def test_future_add_done_callback():

    def callback(future):
        future._result += 1

    future = Future()
    future_set_result(future, 1)
    future_add_done_callback(future, callback)
    assert future.result() == 2

    future = Future()
    future_add_done_callback(future, callback)
    future_set_result(future, 1)
    assert future.result() == 2

# Backwards-compatible wrapper for ConcurrentFuture

# Generated at 2022-06-24 08:26:48.686150
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.set_exception(ZeroDivisionError())
    f.cancel()
    future_set_exception_unless_cancelled(f, TypeError())

# Generated at 2022-06-24 08:26:56.166326
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures

    def f(x, y):
        assert x == 1
        assert y == 2
        return x + y

    class Foo(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor()
        def gunk(self, arg):
            return arg + 1

    foo = Foo()
    assert foo.gunk(42) == 43



# Generated at 2022-06-24 08:27:01.636197
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.testing import AsyncTestCase, gen_test

    result = []

    class Test(AsyncTestCase):
        @gen_test
        def test(self):
            def sync_call():
                result.append(1)

            future = dummy_executor.submit(sync_call)
            yield future
            self.assertEqual(result, [1])

    Test().test()

# Generated at 2022-06-24 08:27:06.160198
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    fut = asyncio.Future()
    called = []

    def callback(f: Future) -> None:
        assert f is fut
        called.append(True)

    future_add_done_callback(fut, callback)
    assert called == []
    fut.set_result(None)
    assert called == [True]
    called.pop()
    future_add_done_callback(fut, callback)
    assert called == [True]



# Generated at 2022-06-24 08:27:07.334299
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError("my message")

# Generated at 2022-06-24 08:27:13.715494
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Complete successfully
    future = dummy_executor.submit(lambda: 1)
    assert future.result() == 1

    # Complete with an exception
    future = dummy_executor.submit(lambda: 1 / 0)
    try:
        future.result()
    except ZeroDivisionError:
        pass
    else:
        assert False

    # Complete before waiting for the result
    future = dummy_executor.submit(lambda: 1)
    assert future.done()
    assert future.result() == 1

    # Callback is called immediately
    f = future_add_done_callback(future, lambda f: f)
    assert f is future



# Generated at 2022-06-24 08:27:18.797786
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    callback_args = None
    def callback(arg):
        nonlocal callback_args
        callback_args = arg

    f = Future()
    future_add_done_callback(f, callback)
    assert callback_args is None
    f.set_result(5)
    assert callback_args is f
    callback_args = None
    f = Future()
    f.set_result(6)
    future_add_done_callback(f, callback)
    assert callback_args is f



# Generated at 2022-06-24 08:27:29.619431
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class Test(object):
        def __init__(self) -> None:
            self.executor = futures.ThreadPoolExecutor(max_workers=5)

        @run_on_executor()
        def async_call(self, arg: int, kwarg: int = 1) -> int:
            return arg + kwarg

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.test = Test()

        def test_run_on_executor(self) -> None:
            fut = self.test.async_call(10)
            self.assertEqual(fut.result(), 11)

    unittest.main()

# Generated at 2022-06-24 08:27:33.552163
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.cancel()
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

# Generated at 2022-06-24 08:27:42.587712
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import gen

    class MyTestCase(unittest.TestCase):
        @gen.coroutine
        def test_run_on_executor(self):

            class MyClass(object):
                executor = dummy_executor

                @run_on_executor
                def foo(self, a, b):
                    return a + b

            obj = MyClass()
            result = yield obj.foo(1, 2)
            self.assertEqual(result, 3)

    AsyncIOMainLoop().install()
    try:
        unittest.main()
    finally:
        AsyncIOMainLoop().close(all_fds=True)


if __name__ == "__main__":
    test_