

# Generated at 2022-06-24 08:17:36.674867
# Unit test for function chain_future
def test_chain_future():
    def check_future(test_future, expected_exception, expected_result):
        if (expected_exception is not None and
                not test_future.exception()):
            raise Exception('Exception expected')
        if test_future.exception():
            if test_future.exception().args[0] != expected_exception:
                raise Exception('Unexpected exception %s' %
                                test_future.exception())
        if (expected_result is not None and
                test_future.result() != expected_result):
            raise Exception('Result mismatch')

    def make_future(value):
        result = Future()
        result.set_result(value)
        return result

    def make_exception(exception):
        result = Future()
        result.set_exception(exception)
        return result

    check

# Generated at 2022-06-24 08:17:39.095121
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:17:45.029730
# Unit test for function is_future
def test_is_future():
    class MyFuture(object):
        ...

    async def mycoro() -> None:
        ...

    @gen.coroutine
    def mygen() -> None:
        ...

    assert is_future(Future())
    assert is_future(concurrent.futures.Future())
    assert is_future(mycoro())
    assert is_future(mygen())
    assert not is_future(MyFuture())

# Generated at 2022-06-24 08:17:51.434093
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock
    from tornado import gen

    class FakeFuture(gen.Future):
        # The tornado.gen.Future constructor doesn't accept a result.
        def __init__(self, exc_info: Optional[Tuple[type, BaseException, types.TracebackType]]) -> None:
            # asyncio.Future is an old-style class, so super() does not work.
            gen.Future.__init__(self)
            if exc_info is not None:
                self.set_exc_info(exc_info)


# Generated at 2022-06-24 08:18:02.332924
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import logging
    import time

    class RunOnExecutorTest(unittest.TestCase):
        @gen_test
        def test_0(self):
            class Foo(object):
                def __init__(self, executor):
                    self.executor = executor

                @run_on_executor
                def func(self, a, b, callback=None):
                    time.sleep(0.01)
                    self.callback_called = True
                    self.failUnlessEqual(a, 1)
                    self.failUnlessEqual(b, 2)
                    if callback is not None:
                        callback()

            loop = IOLoop.current()
            executor = Executor(2)
            foo = Foo(executor)
            future = foo.func(1, 2)
            yield future



# Generated at 2022-06-24 08:18:11.277993
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(None)
    assert f2.done()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.done()
    assert isinstance(f2.exception(), RuntimeError)
    f1 = Future()
    f2 = Future()
    f2.set_result(None)
    chain_future(f1, f2)
    assert not f1.done()
    f1.set_result(None)
    assert f1.done()

# Generated at 2022-06-24 08:18:22.925482
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    from tornado.log import access_log, app_log, gen_log
    from tornado.testing import AsyncTestCase, LogTrapTestCase

    # This test mocks the logging functions so we don't get spurious
    # log messages in other tests. The mock functions check the
    # arguments to ensure the right things are being logged.
    logging.root.manager.emittedNoHandlerWarning = True
    sentinel = object()
    exc = ValueError()

    calls = []  # type: List[Tuple[str, Any, Any]]

    def mock_log(name: str, level: int, msg: str, *args: Any, **kwargs: Any) -> None:
        calls.append((name, args, kwargs))


# Generated at 2022-06-24 08:18:25.558197
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.cancelled()

# Generated at 2022-06-24 08:18:28.901128
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    current_future = dummy_executor.submit(lambda: 'test_input')
    assert current_future.done() == True
    assert current_future.result() == 'test_input'

# Generated at 2022-06-24 08:18:31.301058
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:18:39.104509
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    a = ReturnValueIgnoredError()
    b = ReturnValueIgnoredError(a)
    c = ReturnValueIgnoredError(a, b)
    d = ReturnValueIgnoredError(a, b, c)
    e = ReturnValueIgnoredError(a, b, c, d)
    ReturnValueIgnoredError(a, b, c, d, e)
    ReturnValueIgnoredError(a, b, c, d, e, 'foo')
    ReturnValueIgnoredError(a, b, c, d, e, 'foo', bar=123)

# Generated at 2022-06-24 08:18:42.346381
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    import asyncio
    import concurrent
    assert is_future(Future())
    assert is_future(concurrent.futures.Future())
    assert not is_future(asyncio.Future())

# Generated at 2022-06-24 08:18:46.698667
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    with pytest.raises(TypeError):
        ReturnValueIgnoredError()

    with pytest.raises(TypeError):
        ReturnValueIgnoredError("test")

    with pytest.raises(TypeError):
        ReturnValueIgnoredError("test", exc_info=(None, None, None))



# Generated at 2022-06-24 08:18:55.396714
# Unit test for function chain_future
def test_chain_future():

    @gen.coroutine
    def f():
        yield gen.sleep(0)
        raise Exception("foo")

    f1 = f()
    f2 = Future()
    chain_future(f1, f2)
    f1.add_done_callback(lambda future: sys.stdout.flush())
    f2.add_done_callback(lambda future: sys.stdout.flush())
    try:
        ioloop.IOLoop.current().run_sync(f2.result)
        assert False
    except Exception:
        pass
    assert f1.exception() is not None
    assert f2.exception() is not None
    assert f1.exception() == f2.exception()

# Generated at 2022-06-24 08:18:57.230347
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exc_info(f, sys.exc_info())

# Generated at 2022-06-24 08:18:58.600728
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    exc = Exception("foo")
    traceback = None
    future = Future()
    try:
        raise exc
    except:
        future_set_exc_info(future, sys.exc_info())
        assert future.exception() == exc



# Generated at 2022-06-24 08:19:06.998241
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa: F811
    def callback(future):
        assert future.result() == 1

    future = Future()
    future_add_done_callback(future, callback)
    future.set_result(1)

    future = Future()
    future.set_result(1)
    future_add_done_callback(future, callback)


if hasattr(asyncio, "isfuture"):
    is_future_type = asyncio.isfuture
else:
    def is_future_type(x: Any) -> bool:
        return isinstance(x, types.GeneratorType) or inspect.isawaitable(x)



# Generated at 2022-06-24 08:19:09.440406
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f,5)
    assert f.result() == 5
    # assert future_set_result_unless_cancelled(f,5) == None

# Generated at 2022-06-24 08:19:12.491748
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    old_future = futures.Future()
    old_future.set_exception(ValueError())
    new_future = Future()

    future_set_exc_info(new_future, old_future.exc_info())
    return new_future

# Generated at 2022-06-24 08:19:20.704720
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class x(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)

        @run_on_executor
        def f(self, x, y):
            time.sleep(0.1)
            return x + y

    class RunOnExecutorTest(unittest.TestCase):
        def test_run_on_executor(self):
            obj = x()
            f = obj.f(1, 2)
            result = yield f
            self.assertEqual(3, result)


# Generated at 2022-06-24 08:19:23.675867
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # type: ignore
    ReturnValueIgnoredError()
    ReturnValueIgnoredError("foo")


# These aliases exist for backwards compatibility.
ReturnValueIgnoredError = ReturnValueIgnoredError
RunResult = Future
native_coroutine = Future

# Generated at 2022-06-24 08:19:31.075959
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = asyncio.Future()
    exc = RuntimeError()
    future_set_exception(fut, exc)
    assert fut.exception() is exc
    assert not fut.cancelled()

    fut = asyncio.Future()
    fut.cancel()
    exc = RuntimeError()
    future_set_exception_unless_cancelled(fut, exc)
    assert fut.exception() is None
    assert fut.cancelled()

# Generated at 2022-06-24 08:19:33.293314
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    e = DummyExecutor()
    d = e.submit(lambda: 42)
    assert (d.result() == 42)

# Generated at 2022-06-24 08:19:41.479637
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            class MyExecutor:
                def submit(self, fn, *args, **kwargs):
                    self.future = Future()
                    self.future.set_result(fn(*args, **kwargs))
                    return self.future

            class MyClass:
                executor = MyExecutor()

            @run_on_executor
            def fn(self, a, b):
                self.assertEqual(self.total, 3)
                return a + b

            @run_on_executor
            def error(self):
                raise Exception("error")

            self.cls = MyClass()
            self.sync_fn = fn
            self.error_fn = error

# Generated at 2022-06-24 08:19:50.718072
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # This test runs in this module because tornado.test.gen_test is a
    # decorator that requires that the function it wraps be defined at
    # module level.
    from tornado.testing import AsyncTestCase

    class FutureTest(AsyncTestCase):
        def test_future_add_done_callback(self):
            future = Future()
            result = []

            def callback(f):
                result.append(1)

            future_add_done_callback(future, callback)
            self.assertEqual(result, [])
            future_add_done_callback(future, callback)
            future.set_result(None)
            self.assertEqual(result, [1, 1])

    FutureTest().test_future_add_done_callback()

# Generated at 2022-06-24 08:19:53.128896
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
    future.cancel()
    future_set_result_unless_cancelled(future, 6)
    assert future.result() == 5


# Generated at 2022-06-24 08:19:58.271616
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    class Foo:
        executor = dummy_executor

        @run_on_executor
        def dosomething(self):
            return "foo"

        @run_on_executor(executor="_thread_pool")
        def dosomething_future(self):
            return self.executor.submit(lambda: 42)

    f = Foo()
    assert not isinstance(f.dosomething(), Future)
    IOLoop.current().run_sync(f.dosomething)
    assert isinstance(f.dosomething_future(), Future)
    assert IOLoop.current().run_sync(f.dosomething_future) == 42
    assert IOLoop.current().run_sync(f.dosomething) == "foo"


# Unit test

# Generated at 2022-06-24 08:20:09.346987
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    from tornado.ioloop import IOLoop

    io_loop = IOLoop()

    class Example(object):
        executor = dummy_executor

        def __init__(self):
            self.io_loop = io_loop

        @run_on_executor
        def func(self, a, b):
            self.value = a + b
            if hasattr(self, "callback"):
                # Should have been cleared by the test.
                raise Exception("test failed: callback was not cleared")
            self.event.set()

    # Prevent the dummy_executor from losing track of Example.func by
    # keeping a reference to it here.  We don't need this in real
    # code because bound methods are always referenced by their objects.

# Generated at 2022-06-24 08:20:12.835804
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado import gen
    from tornado.ioloop import IOLoop

    @gen.coroutine
    def test():
        executor = DummyExecutor()

        def run_in_executor(arg: Any) -> Any:
            return arg

        result = yield executor.submit(run_in_executor, 1)
        assert result == 1

    IOLoop.current().run_sync(test)


# Generated at 2022-06-24 08:20:23.418612
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import pytest
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        @gen_test
        def test_future_add_done_callback(self):
            result = []

            def callback(future):
                result.append(future.result())

            future = Future()
            future_add_done_callback(future, callback)
            future.set_result("foo")
            IOLoop.current().call_later(0.01, IOLoop.current().stop)
            yield
            assert result == ["foo"]

    pytest.main("-q %s" % __file__)



# Generated at 2022-06-24 08:20:26.738008
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    IgnoreResult()
    IgnoreAllResult()

# Generated at 2022-06-24 08:20:31.183416
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from unittest import mock
    future = Future()
    callback = mock.Mock()
    future_add_done_callback(future, callback)
    callback.assert_not_called()
    future_set_result_unless_cancelled(future, mock.sentinel.result)
    callback.assert_called_once_with(future)



# Generated at 2022-06-24 08:20:32.411208
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.submit(lambda x: x + 1, 1) == 2

# Generated at 2022-06-24 08:20:33.507216
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()  # Should not throw exception


# Generated at 2022-06-24 08:20:38.223524
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    tmp1 = Future()  # type: Future[_T]
    tmp2 = Future()  # type: Future[_T]
    tmp1.result()
    tmp2.result()
    #tmp3.result()
    #tmp4.result()
    #tmp5.result()
    #tmp6.result()
    #tmp7.result()
    #tmp8.result()
    #tmp9.result()


# Generated at 2022-06-24 08:20:49.383145
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.queues import Queue

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.q = Queue()

        def tearDown(self):
            if not self.q.empty():
                self.q.get_nowait()

        def test_chain(self):
            future1 = Future()
            future2 = Future()
            chain_future(future1, future2)
            future2.add_done_callback(lambda future: self.q.put(future.result()))
            self.assertTrue(self.q.empty())
            future1.set_result(42)
            self.assertEqual(self.q.get_nowait(), 42)

    unittest.main()

# Generated at 2022-06-24 08:20:51.628289
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(1)

# Generated at 2022-06-24 08:20:53.955958
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = dummy_executor
    f = d.submit(lambda x: x, 10)
    print(f.result())


if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-24 08:21:00.475835
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        def __init__(self):
            # type: () -> None
            self.executor = futures.ThreadPoolExecutor(1)
            self.result = None  # type: Optional[Future]

        @run_on_executor
        def fetch(self, arg):
            # type: (int) -> int
            return arg * 10

        def fetch_result(self, arg):
            # type: (int) -> Future
            return self.fetch(arg)

        @run_on_executor(executor="executor")
        def fetch2(self, arg):
            # type: (int) -> int
            return arg * 20

        def fetch_result2(self, arg):
            # type: (int) -> Future
            return self.fetch2(arg)


# Generated at 2022-06-24 08:21:04.516145
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    loop.run_until_complete(future)
    assert future.result() is None

# Generated at 2022-06-24 08:21:08.268088
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    test_DummyExecutor_submit.t = False
    def foo(x):
        test_DummyExecutor_submit.t = True
    f = dummy_executor.submit(foo, 3)
    f.result()
    assert test_DummyExecutor_submit.t


# Generated at 2022-06-24 08:21:10.998957
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    # print(dummy_executor.submit())
    pass


# Generated at 2022-06-24 08:21:21.126698
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    
    dummy_executor.submit(add_num, 2, 3)
    assert add_num(2, 3) == dummy_executor.submit(add_num, 2, 3).result()
    def bar(*a):
        return a
    dummy_executor.submit(bar,1, 2, 3)
    assert bar(1,2, 3) == dummy_executor.submit(bar, 1, 2, 3).result()
    baz = lambda *a: a
    dummy_executor.submit(baz,1, 2, 3)
    assert baz(1,2, 3) == dummy_executor.submit(baz, 1, 2, 3).result()
    

# Generated at 2022-06-24 08:21:34.862976
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
	pool = futures.ThreadPoolExecutor(10)
	dummy_executor = DummyExecutor()
	assert isinstance(dummy_executor, DummyExecutor)
	assert isinstance(dummy_executor, futures.Executor)
	assert not isinstance(dummy_executor, futures.ThreadPoolExecutor)

	# test: DummyExecutor.shutdown
	dummy_executor.shutdown()
	assert isinstance(dummy_executor, DummyExecutor)
	assert isinstance(dummy_executor, futures.Executor)
	assert not isinstance(dummy_executor, futures.ThreadPoolExecutor)

	# test: DummyExecutor.submit
	future = dummy_executor.submit(func=add, x=1, y=2)

# Generated at 2022-06-24 08:21:38.178234
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    f = d.submit(lambda x: x, 1)
    assert f.done()
    assert f.result() == 1



# Generated at 2022-06-24 08:21:41.654421
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    future.add_done_callback(
        lambda f: f.exception().with_traceback(None)
    )  # suppress stack trace from within this function
    assert future.exception() is not None

# Generated at 2022-06-24 08:21:51.594830
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import mock

    from tornado.platform.asyncio import (
        to_asyncio_future,
        AsyncIOMainLoop,
        to_tornado_future,
    )

    @asyncio.coroutine
    def init():
        yield from AsyncIOMainLoop().install()

    class MyExecutor(futures.Executor):
        def __init__(self):
            self.shutdown_called = False

        def submit(self, fn, *args, **kwargs):
            return to_tornado_future(fn(*args, **kwargs))

        def shutdown(self, wait=True):
            self.shutdown_called = True


# Generated at 2022-06-24 08:21:53.383998
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:22:01.289212
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.cancelled()


# Generated at 2022-06-24 08:22:02.092713
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("err")

# Generated at 2022-06-24 08:22:05.492457
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future(object())
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:22:09.706731
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(asyncio.Task(Future()))
    assert not is_future(object())
    assert not is_future(None)

# Generated at 2022-06-24 08:22:21.328105
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock
    from concurrent.futures import Future
    from tornado.log import app_log

    fut = Future()
    fut.set_result(1)

    exc = ValueError("foo")

    future_set_exception_unless_cancelled(fut, exc)
    assert fut.exception() == exc

    fut = Future()
    fut.cancel()

    with mock.patch("tornado.util.app_log.error") as mocked:
        future_set_exception_unless_cancelled(fut, exc)
        mocked.assert_called()  # it should have logged
        assert fut.exception() is None
        assert list(fut.exception().args) == ["foo"]

    # Set argument to None to suppress logging.

# Generated at 2022-06-24 08:22:29.081782
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from concurrent.futures import Future
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = dummy_executor

        @gen_test
        def test_function(self):
            future = self.executor.submit(self.add, 2, 3)
            result = yield future
            self.assertEqual(result, 5)

        def add(self, a: int, b: int) -> int:
            return a + b

    # test the results of submitting a function to the dummy executor
    test = Test()
    test.setUp()
    test.test_function()



# Generated at 2022-06-24 08:22:36.619036
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.result() == f2.result()



# Generated at 2022-06-24 08:22:39.885420
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    '''
    Unit Test for the shutdown method of dummy_executor class
    '''
    dummy_executor.shutdown()
    assert True


# Generated at 2022-06-24 08:22:43.402972
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    # No error if f has not been cancelled
    assert f.cancel() is False
    future_set_result_unless_cancelled(f, None)
    assert f.done()


# Generated at 2022-06-24 08:22:44.012515
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
  pass

# Generated at 2022-06-24 08:22:47.524411
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    e = RuntimeError("test")
    future_set_exception_unless_cancelled(future, e)
    future.cancel()
    future_set_exception_unless_cancelled(future, e)
    assert True


# Generated at 2022-06-24 08:22:58.147523
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import asyncio
    import concurrent.futures

    class MyCoro:
        def __init__(self, result):
            self._result = result

        def __await__(self):
            yield

            return self._result

    @asyncio.coroutine
    def func():
        return "foo"

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    @run_on_executor(executor="_thread_pool")
    def inner_coro(self):
        # type: (MyType) -> MyCoro
        return MyCoro("bar")

    @run_on_executor
    def inner_func(self):
        # type: (MyType) -> str
        return "foo"


# Generated at 2022-06-24 08:23:02.864979
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    # Future was cancelled, no exception should be raised
    assert f.cancelled()
    assert not f.done()  # type: ignore

# Generated at 2022-06-24 08:23:12.811984
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    # This is not a proper unit test; this function is not intended
    # for public use and the API may change in any release.

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def sync_func(self, a, b):
            return a + b

        @run_on_executor(executor="executor2")
        def sync_func2(self, a, b):
            return a + b

        def __init__(self):
            self.executor2 = dummy_executor

    ioloop = asyncio.get_event_loop()
    f = Foo()
    f2 = Foo()
    f2.executor2 = None
    f3 = Foo()
    f3.executor = None
    assert ioloop.run

# Generated at 2022-06-24 08:23:16.197014
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(arg1: str, arg2: int) -> str:
        return arg1 * arg2

    d = dummy_executor.submit(f, 'hello', 3)
    assert d.result() == 'hellohellohello'


# Generated at 2022-06-24 08:23:20.043788
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()

    def callback(future):
        assert future is f
        callback.called = True

    callback.called = False
    future_add_done_callback(f, callback)
    # Even though f is not done, callback should be called synchronously.
    assert callback.called

    f.set_result(None)
    future_add_done_callback(f, callback)
    # And the second time it should be called asynchronously.
    assert not callback.called
    f.result()  # wait for callbacks to run
    assert callback.called



# Generated at 2022-06-24 08:23:20.694930
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    pass



# Generated at 2022-06-24 08:23:24.258051
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = Exception("fake exception")
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() == exception

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exception)
    assert future.exception() is None


# Generated at 2022-06-24 08:23:30.901632
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def test():
        f1 = Future()
        f1.cancel()

        f2 = Future()

        future_set_exception_unless_cancelled(f1, ZeroDivisionError())
        future_set_exception_unless_cancelled(f2, ZeroDivisionError())

        try:
            await f2
        except ZeroDivisionError:
            pass
        else:
            assert False

    asyncio.get_event_loop().run_until_complete(test())

# Generated at 2022-06-24 08:23:32.476149
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())



# Generated at 2022-06-24 08:23:38.852965
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def sync_fn(n):
        return 2*n

    f = dummy_executor.submit(sync_fn, 123456)
    assert f.result() == sync_fn(123456)

    def sync_fn_with_param(n, param):
        return 2*n+param

    f = dummy_executor.submit(sync_fn_with_param, 123456, param=100)
    assert f.result() == sync_fn_with_param(123456, 100)


# Generated at 2022-06-24 08:23:42.534931
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def f():
        raise Exception("hello")
    fut = f()
    fut.add_done_callback(future_set_exc_info)
    assert fut.exception() is not None
    assert fut.exception().args == ("hello",)

# Generated at 2022-06-24 08:23:46.571430
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.submit(foo)
    executor.submit(foo, 2, 3)
    executor.submit(foo, 2, y=9)

    executor.shutdown()

# Generated at 2022-06-24 08:23:50.454617
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert True

# Generated at 2022-06-24 08:23:56.569434
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        callback.called = True
        assert future.result() == 'Done!'
    callback.called = False
    fut = Future()
    future_add_done_callback(fut, callback)
    assert not callback.called
    fut.set_result('Done!')
    assert callback.called
    future_add_done_callback(fut, callback)  # should work twice
    assert callback.called
    callback.called = False
    fut = Future()
    fut.set_result('Done!')
    future_add_done_callback(fut, callback)
    assert callback.called

# Generated at 2022-06-24 08:24:02.976775
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    loop = asyncio.get_event_loop()

    async def test(expected_result: Any) -> None:
        future = loop.create_future()
        future_set_result_unless_cancelled(future, expected_result)
        actual_result = await future
        assert actual_result == expected_result

    loop.run_until_complete(test(42))
    loop.run_until_complete(test(None))
    loop.run_until_complete(test(Exception))

    future = loop.create_future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-24 08:24:03.585062
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()

# Generated at 2022-06-24 08:24:07.440114
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 5)
    assert f.result() == 5
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 5)
    assert f.cancelled()
    f = Future()
    f.set_exception(ValueError)
    future_set_result_unless_cancelled(f, 5)
    assert f.exception() is not None

# Generated at 2022-06-24 08:24:10.835921
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    dummy_future = asyncio.Future()
    assert is_future(dummy_future)
    dummy_future = futures.Future()
    assert is_future(dummy_future)

# Generated at 2022-06-24 08:24:24.617071
# Unit test for function chain_future
def test_chain_future():

    import tornado.ioloop

    io_loop = tornado.ioloop.IOLoop()

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    def set_f1(c):
        if not f1.cancelled():
            f1.set_result(None)

    def f():
        io_loop.add_callback(set_f1, 0)
        return f1

    result = io_loop.run_sync(f)
    assert result is f1
    assert f2.done()

    # if f2 is already cancelled, it should be skipped
    f1 = Future()
    f2 = Future()
    f2.cancel()
    chain_future(f1, f2)
    result = io_loop.run_sync(f)
   

# Generated at 2022-06-24 08:24:37.133918
# Unit test for function is_future
def test_is_future():
    async def async_main():
        return 42

    async def async_throw():
        raise Exception()

    @run_on_executor
    def sync_main():
        return 42

    @run_on_executor
    def sync_throw():
        raise Exception()

    # Sync
    assert not is_future(sync_main())
    assert not is_future(sync_throw())
    assert is_future(sync_main().result())
    assert is_future(sync_throw().result())

    # Async
    assert not is_future(async_main())
    assert not is_future(async_throw())
    assert is_future(async_main().result())
    assert is_future(async_throw().result())

# Generated at 2022-06-24 08:24:44.129307
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert future.cancel() == True
    future_set_result_unless_cancelled(future, 'foo')
    assert future.cancelled() == True
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.cancelled() == False
    assert future.result() == 'foo'



# Generated at 2022-06-24 08:24:51.798428
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result("abc")
    assert f2.result() == "abc"

    f1 = Future()
    f2 = Future()
    chain_future(f2, f1)
    f2.set_exception(RuntimeError)
    try:
        f1.result()
    except RuntimeError:
        pass
    else:
        raise AssertionError("should have raised exception")

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_exception(RuntimeError)
    try:
        f1.result()
    except RuntimeError:
        pass

# Generated at 2022-06-24 08:24:53.632748
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    assert isinstance(d, futures.Executor) == True
    d.shutdown()

# Generated at 2022-06-24 08:25:01.948316
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print("\n=== Test DummyExecutor.submit()")
    future = dummy_executor.submit(lambda x: x+1, 2)

    def callback(f: Future):
        print("DummyExecutor.submit callback: f =", f)
        assert f.result() == 3
        print("DummyExcecutor.submit callback: result =", f.result())

    future_add_done_callback(future, callback)
    print("== Test DummyExecutor.submit() ===")

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:25:06.657666
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures
    import functools
    import unittest

    from tornado.ioloop import IOLoop
    import tornado.gen
    import tornado.testing
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_tornado_future

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    ioloop = IOLoop.current()

    executor = concurrent.futures.ThreadPoolExecutor(2)

    class TestFuture(tornado.concurrent.Future):
        def set_result(self, value):
            super(TestFuture, self).set_result(value)
            assert ioloop.asyncio_loop.is_running()

    class TestHandler:
        executor = executor
        _thread_pool = concurrent.futures

# Generated at 2022-06-24 08:25:18.305963
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.escape import native_str
    from tornado.httputil import _BadRequestException
    from tornado.ioloop import IOLoop

    ioloop = IOLoop.current()

    async def f():
        # Create an exception whose stack trace is something other than the
        # current stack.
        await ioloop.sleep(0.01)
        raise _BadRequestException()

    @gen.coroutine
    def test_async_future():
        try:
            yield f()
            raise Exception("Did not get expected exception")
        except _BadRequestException:
            string_io = io.StringIO()
            sys.print_exception(string_io)
            # The message changes in Python 3, so just check that it has
            # the expected substring.

# Generated at 2022-06-24 08:25:27.204227
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.concurrent import Future, run_on_executor

    executor = DummyExecutor()

    class Foo(object):
        executor = executor

        @run_on_executor
        def callback(self, arg):
            return arg + 1

    foo = Foo()
    f = foo.callback(41)
    # The dummy executor runs synchronously, so the Future should already be
    # finished.
    assert f.done()
    assert f.result() == 42

    # Check that args are passed through correctly.
    arguments = {"arg": 1, "arg2": 2, "arg3": 3}

    class Foo2(object):
        def __init__(self, executor):
            self.executor = executor


# Generated at 2022-06-24 08:25:35.516734
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    AsyncIOMainLoop().install()

    @run_on_executor
    def f(x: int) -> int:
        return x + 1

    @gen.coroutine
    def g():
        for i in range(5):
            try:
                assert (yield f(i)) == i + 1
            finally:
                if i >= 4:
                    raise gen.Return()

    @gen.coroutine
    def h():
        try:
            yield f(Future())
        except TypeError:
            pass
        else:
            raise Exception("did not get expected TypeError")

    class Foo(object):
        executor = dummy_executor


# Generated at 2022-06-24 08:25:42.942585
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    class MyException(Exception):
        pass

    f = Future()
    future_set_exception_unless_cancelled(f, MyException())
    assert f.exception() is not None
    assert isinstance(f.exception(), MyException)

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, MyException())
    assert f.exception() is None

# Generated at 2022-06-24 08:25:46.995744
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """Tests whether future_set_result_unless_cancelled raises InvalidStateError
     exception when Future has been cancelled.
    """
    future = Future()
    future.cancel()

    future_set_result_unless_cancelled(future, 1)


# Generated at 2022-06-24 08:25:49.607739
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    async def test_func(x: int) -> int:
        return x+1

    f = dummy_executor.submit(test_fun, 1)
    assert f.result() == 2

# Generated at 2022-06-24 08:25:54.382620
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestCase(AsyncTestCase):
        @gen_test
        async def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(None)
            self.assertEqual(f.result(), g.result())

    test = TestCase()
    test.test_chain_future()

# Generated at 2022-06-24 08:26:03.145452
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import logging
    import unittest

    from tornado.log import access_log, app_log, gen_log

    from tornado.testing import AsyncTestCase, LogTrapTestCase, gen_test
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())

    class FutureSetExceptionUnlessCancelledTest(AsyncTestCase, LogTrapTestCase):
        def _callback(self, future):
            future.cancel()

        @gen_test
        async def test_future_set_exception_unless_cancelled(self):
            # Test log messages are printed
            future = Future()
            future_add_done_callback(future, self._callback)

# Generated at 2022-06-24 08:26:10.238546
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import unittest
    import unittest.mock

    class FooTest(unittest.TestCase):
        def test_future_set_exception_unless_cancelled(self):
            f = Future()
            f.cancel()
            with unittest.mock.patch("tornado.gen.log.error") as error_mock:
                future_set_exception_unless_cancelled(f, ValueError("error"))
            error_mock.assert_called_once()
            (exc_info,), kwargs = error_mock.call_args
            self.assertIsInstance(exc_info[1], ValueError)
    unittest.main()

# Generated at 2022-06-24 08:26:15.232372
# Unit test for function chain_future
def test_chain_future():
    import futuretest
    import tornado.testing

    io_loop = futuretest.make_test_future()

    def make_future():
        return Future()  # type: ignore

    futuretest.test_chain_future(io_loop, make_future, chain_future)



# Generated at 2022-06-24 08:26:26.248513
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    if sys.version_info < (3, 5, 2):
        # asyncio.Future did not exist before 3.5.2.
        return

    loop = asyncio.get_event_loop()
    f = Future()  # type: Future[str]
    g = Future()

    def set_g(f):
        g.set_result(f.result())

    chain_future(f, g)

    class Accumulator(Future):
        def __init__(self):
            super().__init__()
            self.results = []

        def accumulate(self, f):
            self.results.append(f.result())
            if len(self.results) == 2:
                self.set_result("".join(self.results))

    h = Accumulator()
    chain

# Generated at 2022-06-24 08:26:32.709619
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestCase(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            a = Future()
            b = Future()
            c = Future()
            chain_future(a, b)
            chain_future(b, c)
            a.set_result(1)
            # This set_result should have no effect because b has been marked as
            # done by the callback on a.
            b.set_result(2)

# Generated at 2022-06-24 08:26:33.463910
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:26:34.571394
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    _ = dummy_executor.shutdown()

# Generated at 2022-06-24 08:26:35.415668
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("msg")

# Generated at 2022-06-24 08:26:37.323863
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError("some message")
    assert str(e) == "some message"



# Generated at 2022-06-24 08:26:38.860602
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError('foo')

# Generated at 2022-06-24 08:26:44.821293
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test_func(a,b):
        return a, b
    
    def test_func2():
        return 0
    executor = dummy_executor
    fut = executor.submit(test_func, 1, 5)
    print(fut.result())
    fut = executor.submit(test_func2)
    print(fut.result())

# Generated at 2022-06-24 08:26:47.742699
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    assert isinstance(dummy_executor, DummyExecutor)



# Generated at 2022-06-24 08:26:48.762553
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda: 2 + 2) == dummy_executor.submit(lambda: 2 + 2)

# Generated at 2022-06-24 08:26:52.411564
# Unit test for function is_future
def test_is_future():
    class MyFuture:
        pass

    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(MyFuture())



# Generated at 2022-06-24 08:26:56.870378
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    test_future = Future()
    test_exc = Exception('this exception should never propagate')
    future_set_exception_unless_cancelled(test_future, test_exc)

    test_future.cancel()
    future_set_exception_unless_cancelled(test_future, test_exc)

# Generated at 2022-06-24 08:27:06.194593
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class ReturnValueIgnoredError(Exception):
        pass

    class ExampleClass:
        executor = dummy_executor

        @run_on_executor
        def blocking_call(self) -> int:  # type: ignore
            return 42

        @run_on_executor
        def blocking_call_with_callback(
            self, callback: Callable[[int], None]
        ) -> None:  # type: ignore
            callback(42)

        @run_on_executor(executor="_other_executor")
        def blocking_call_explicit_attr(self) -> int:  # type: ignore
            return 42


# Generated at 2022-06-24 08:27:08.146853
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    test_executor = DummyExecutor()
    test_executor.submit(lambda arg: arg, 1)
    test_executor.submit(lambda arg: arg, 2)
    test_executor.shutdown()

# Generated at 2022-06-24 08:27:14.146733
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def assert_exc_info(expected, exc_info):
        future = Future()
        future_set_exc_info(future, exc_info)
        assert future.exception() == expected

    try:
        1 / 0
    except ZeroDivisionError:
        orig_exc_info = sys.exc_info()

    if sys.version_info < (3,):
        assert_exc_info(orig_exc_info[0], orig_exc_info)
    else:
        assert_exc_info(orig_exc_info[1], orig_exc_info)

# Generated at 2022-06-24 08:27:16.113940
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(me.dummy_func_, 5)


# Generated at 2022-06-24 08:27:17.359471
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:27:29.076444
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.web import RequestHandler, Application
    from tornado.concurrent import run_on_executor


    class Handler(RequestHandler):
        @run_on_executor  # run add_one in threadpool
        def add_one(self, x):
            return x + 1

        @run_on_executor
        def add_two(self, x):
            return x + 2

        @run_on_executor
        def get_five(self):
            return 5

        @run_on_executor
        def raise_error(self):
            raise Exception('error')

        def get(self):
            futures = [self.add_one(1)]

# Generated at 2022-06-24 08:27:38.194632
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    assert not future.done()
    callback_done = False
    def callback(f):
        assert future == f
        nonlocal callback_done
        callback_done = True
    assert not callback_done
    future_add_done_callback(future, callback)
    assert not callback_done
    future.set_result(42)
    assert callback_done
    callback_done = False
    assert future.done()
    future_add_done_callback(future, callback)
    assert callback_done
    try:
        future.set_result(43)
    except Exception:
        pass
    else:
        raise AssertionError("calling set_result on a done future should fail")