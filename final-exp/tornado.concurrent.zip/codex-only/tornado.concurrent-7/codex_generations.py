

# Generated at 2022-06-24 08:17:35.437434
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado import testing

    class CustomException(Exception):
        pass

    @testing.gen_test
    async def test_normal_future():
        future = asyncio.Future()
        future_set_exception_unless_cancelled(future, CustomException())
        with testing.assertRaises(CustomException):
            await future

    @testing.gen_test
    async def test_cancelled_future():
        future = asyncio.Future()
        future.cancel()
        future_set_exception_unless_cancelled(future, CustomException())
        with testing.assertRaises(asyncio.CancelledError):
            await future

# Generated at 2022-06-24 08:17:46.745867
# Unit test for function run_on_executor
def test_run_on_executor():
    def f(self, x, y):
        return x + y

    @run_on_executor
    def g(self, x, y):
        return x + y

    class MyClass:
        executor = dummy_executor

    obj = MyClass()
    # Make sure it's defined as a function (not a method), which matters
    # if we're going to use this signature in other contexts.
    assert g.__name__ == "g"
    assert isinstance(g.__closure__, tuple)
    assert isinstance(g.__closure__[0].cell_contents, types.FunctionType)
    assert g(obj, 1, 2) == 3

    # Make sure the @run_on_executor version does the same thing.
    future = g(obj, 1, 2)

# Generated at 2022-06-24 08:17:53.304534
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def callback():
        raise TypeError()

    future = asyncio.Future()  # type: Future
    future_add_done_callback(future, callback)

    future_set_exc_info(future, sys.exc_info())

    # now try it for a future that's already cancelled
    future = asyncio.Future()  # type: Future
    future.cancel()
    future_set_exc_info(future, sys.exc_info())

# Generated at 2022-06-24 08:18:00.558548
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, (Exception, Exception("test"), None))
    assert "test" in future.exception().args
    future_set_exc_info(future, (None, None, None))
    assert future.exception().args == ()
    future_set_exc_info(future, (BaseException, BaseException(), None))
    assert "BaseException" in future.exception().args

# Generated at 2022-06-24 08:18:03.340848
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError as e:
        assert str(e) == repr(e)

# Generated at 2022-06-24 08:18:10.991620
# Unit test for function run_on_executor
def test_run_on_executor():
    """deprecated decorator *synchronously* runs a method in an executor.

    It is a mistake to use the decorator form of `run_on_executor` when
    calling a method that was decorated with it (when the method will
    run on an executor and return a `Future`). This test checks that
    the decorator raises an exception in this case, otherwise
    applications will hang silently.
    """
    class Test(object):
        @run_on_executor()
        def fn(self, x):
            return x

    t = Test()
    t.fn(1)



# Generated at 2022-06-24 08:18:13.300753
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa: F811
    try:
        raise ReturnValueIgnoredError("foo")
    except ReturnValueIgnoredError as e:
        assert str(e) == "foo"
        assert repr(e) == "ReturnValueIgnoredError('foo',)"

# Generated at 2022-06-24 08:18:20.417180
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, 42)
    assert future.done()
    assert future.result() == 42

    future2 = Future()
    future2.cancel()
    assert future2.done()
    future_set_result_unless_cancelled(future2, 42)
    assert future2.done()
    assert future2.cancelled()

# Generated at 2022-06-24 08:18:25.845190
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    class TestException(Exception):
        pass

    def do_raise():
        raise TestException("error message")

    future = Future()
    try:
        do_raise()
    except Exception:
        future_set_exc_info(future, sys.exc_info())

    try:
        future.result()
    except TestException:
        pass
    else:
        assert False, "future_set_exc_info uses sys.exc_info()"

# Generated at 2022-06-24 08:18:28.318633
# Unit test for function is_future
def test_is_future():
    assert not is_future(futures.Future())
    assert not is_future(concurrent.futures.Future())
    assert is_future(Future())

# Generated at 2022-06-24 08:18:33.371268
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    async def asynctest():
        future_ok = dummy_executor.submit(lambda:1)
        future_er = dummy_executor.submit(lambda:1/0)
        future_er.set_exception(BaseException())
        assert future_ok.result() == 1
        assert future_er.result() == 1/0

    loop = asyncio.get_event_loop()
    loop.run_until_complete(asynctest())
    loop.close()



# Generated at 2022-06-24 08:18:40.734775
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import asyncio
    import tornado.ioloop

    @asyncio.coroutine
    def f():
        raise ValueError()

    try:
        future = tornado.ioloop.IOLoop.current().run_sync(f)
    except ValueError:
        future_set_exc_info(future, sys.exc_info())
    else:
        assert False

    assert (
        "ValueError" in future.exception().__str__()
    ), "future_set_exc_info does not set exception correctly"



# Generated at 2022-06-24 08:18:45.992533
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1
    future = Future()
    future.cancel()
    assert future.done()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-24 08:18:46.611684
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:18:53.447669
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.simple_httpclient

    future1 = Future()
    try:
        1 / 0
    except:
        future_set_exc_info(future1, sys.exc_info())
    assert future1.exc_info()[1].__class__ is ZeroDivisionError

    future2 = Future()
    try:
        1 / 0
    except:
        future_set_exc_info(future2, sys.exc_info())
    assert future2.exception().__class__ is ZeroDivisionError

    future3 = Future()

    class CustomException(Exception):
        pass

    try:
        raise CustomException
    except:
        future_set_exc_info(future3, sys.exc_info())

    assert future3.exception().__class__ is CustomException

    future4 = Future()
    req

# Generated at 2022-06-24 08:19:00.956086
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(a, b):
        return a + b
    future = dummy_executor.submit(foo, 1, 2)
    assert future.done()
    assert future.result() == 3
    try:
        future = dummy_executor.submit(foo, 1, '2')
        future.result()
    except TypeError:
        pass
    else:
        assert False


if __name__ == '__main__':
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:19:07.538566
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent.futures import Future as CFuture
    from asyncio import Future as AFuture

    def callback(future):
        callback.called = True

    future = AFuture()
    callback.called = False
    future_add_done_callback(future, callback)
    future.set_result(None)
    assert callback.called

    future = CFuture()
    callback.called = False
    future_add_done_callback(future, callback)
    future.set_result(None)
    assert callback.called


# Generated at 2022-06-24 08:19:17.855033
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.ioloop import IOLoop, TimeoutError
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy

    with AnyThreadEventLoopPolicy():
        class FutureTests(AsyncTestCase):
            @gen_test
            async def test_set_result_unless_cancelled(self):
                future = Future()
                IOLoop.current().add_callback(future_set_result_unless_cancelled, future, 5)
                await future
                self.assertEqual(future.result(), 5)

            @gen_test
            async def test_set_result_if_cancelled(self):
                future = Future()
                future.cancel()

# Generated at 2022-06-24 08:19:24.708827
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = Future()

    @chain_future(future, Future())
    def done_callback(fut: Future[Any]) -> None:
        fut.set_result(None)

    @chain_future(future, Future())
    def done_errback(fut: Future[Any]) -> None:
        fut.set_exception(Exception())

    future.set_result(None)
    loop.run_until_complete(future)

# Generated at 2022-06-24 08:19:29.474708
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado_py3.concurrent import futures
    import traceback
    import unittest

    class DummyExecutorTest(unittest.TestCase):
        def test_run_on_executor(self):
            # The basic case.
            self.executor = dummy_executor
            self.io_loop.run_sync(self._run_on_executor_test)

            # The decorated method must be a normally-callable object, not a
            # class method or staticmethod.
            @run_on_executor
            def static_method():
                return 123

            self.assertRaises(TypeError, static_method)

            # The decorated method must be unbound if it is a member of a
            # class, to allow it to be rebound to the instance when invoked
            # from run_on_executor.


# Generated at 2022-06-24 08:19:38.087805
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    @typing.overload
    def test(f: Future) -> None:
        pass

    @typing.overload
    def test(f: futures.Future) -> None:
        pass

    def test(f: "Union[futures.Future, Future]"):
        assert f.done()
        assert f.exception() is not None
        assert f.exception().args == ("foobar",)

    f1 = Future()
    f2 = Future()

    future_set_exception_unless_cancelled(f1, RuntimeError("foobar"))
    test(f1)

    f2.cancel()
    future_set_exception_unless_cancelled(f2, RuntimeError("foobar"))
    test(f2)

# Generated at 2022-06-24 08:19:40.338581
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    assert isinstance(d, concurrent.futures.Executor)
    return True


# Generated at 2022-06-24 08:19:45.466351
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda: True)
    assert future.result() == True

    future = dummy_executor.submit(lambda: False)
    assert future.result() == False

    future = dummy_executor.submit(lambda: 1)
    assert future.result() == 1

    future = dummy_executor.submit(lambda: 0)
    assert future.result() == 0


# Generated at 2022-06-24 08:19:53.582965
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # with this future, we can check both asyncio.Future path and old
    # tornado path.
    class MyFuture(Future):
        # this attribute is only present in old tornado futures
        exc_info = None

    f = MyFuture()
    future_set_exc_info(f, sys.exc_info())
    assert isinstance(f.exception(), Exception)

    f = MyFuture()
    future_set_exc_info(f, None)
    assert f.exception() is None, f.exception()

    future_set_exc_info(f, (None, None, None))
    assert f.exception() is None, f.exception()



# Generated at 2022-06-24 08:20:05.314081
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOLoop().install()

    future = Future()
    try:
        1 / 0
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    for i in range(3):
        future.add_done_callback(lambda f: f.exception())

    loop = tornado.ioloop.IOLoop.current()
    loop.call_later(0, lambda: future_set_exc_info(future, sys.exc_info()))
    loop.call_later(0, future.cancel)
    loop.call_later(0.1, loop.stop)
    loop.start()


# Backwards compatibility names
_chain_future = chain_future
_is_future = is_future
_

# Generated at 2022-06-24 08:20:13.626518
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest
    import unittest.mock
    import threading
    import tornado.testing

    class RunOnExecutorTest(unittest.TestCase):
        def __init__(self, executor=None):
            # type: (Optional[futures.Executor]) -> None
            super(RunOnExecutorTest, self).__init__()
            self.executor = executor or futures.ThreadPoolExecutor(2)


# Generated at 2022-06-24 08:20:24.430564
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    assert not g.done()
    f.set_result(42)
    assert g.done()
    assert g.result() == 42

    f = Future()
    g = Future()
    f.set_exception(ValueError())
    chain_future(f, g)
    assert g.done()
    assert g.exception() is not None
    assert isinstance(g.exception(), ValueError)

    f = Future()
    g = Future()
    f.cancel()
    chain_future(f, g)
    assert g.done()
    assert g.exception() is not None
    assert isinstance(g.exception(), futures.CancelledError)

# Generated at 2022-06-24 08:20:28.617186
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()

    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError)


# Generated at 2022-06-24 08:20:31.114421
# Unit test for function is_future
def test_is_future():
    class Foo:
        pass

    assert is_future(Future())
    assert is_future(Foo()) is False
    assert is_future(Foo) is False
    assert is_future(None) is False

# Generated at 2022-06-24 08:20:35.376637
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = Future()
    exc = Exception("foobar")
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() == exc
    future = Future()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() == exc



# Generated at 2022-06-24 08:20:37.443259
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exception = ValueError()
    future.cancel()

    future_set_exception_unless_cancelled(future, exception)

    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-24 08:20:46.819943
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = Future()
    f1.cancel()
    future_set_exception_unless_cancelled(f1, Exception())
    assert f1.cancelled()
    f2 = Future()
    future_set_exception_unless_cancelled(f2, Exception())
    assert not f2.cancelled()
    assert len(f2.exception().args) == 0
    future_set_exception_unless_cancelled(f2, ValueError(1, 2, 3))
    assert not f2.cancelled()
    assert len(f2.exception().args) == 3



# Generated at 2022-06-24 08:20:51.736621
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()
    fut.cancel()
    future_set_result_unless_cancelled(fut, "hello")
    assert fut.cancelled()
    assert fut.result() is None
    fut = Future()
    future_set_result_unless_cancelled(fut, "hello")
    assert fut.result() == "hello"

# Generated at 2022-06-24 08:20:52.601151
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:20:59.531927
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    #  创建一个异步的Future对象
    future = Future()
    #  Future对象的状态为done
    future.set_result('hello')

    # 创建一个同步的Future对象
    f = DummyExecutor().submit(lambda: 'hello')
    # Future对象的状态为done
    #  在DummyExecutor的submit方法中
    #  创建了一个同步的Future对象
    #  立即对对象进行

# Generated at 2022-06-24 08:21:08.906552
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor()
        def bar(self):
            return 1

        @run_on_executor
        def baz(self):
            return 1

    foo = Foo()

    class TestCase(AsyncTestCase):
        def test(self):
            f = foo.bar()
            self.assertIsInstance(f, Future)
            self.assertEqual(1, self.io_loop.run_sync(f.result))

    test = TestCase().test

    # Test the __wrapped__ attribute
    wrapped = foo.bar
    self_ = foo

# Generated at 2022-06-24 08:21:13.720660
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def test_spawn_callback(x):
        pass

    test_executor = DummyExecutor()

    test_executor.submit(test_spawn_callback, 1)
    test_executor.submit(test_spawn_callback, 2)

    test_executor.shutdown()


# Generated at 2022-06-24 08:21:16.005372
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:21:17.072672
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test exception message")

# Generated at 2022-06-24 08:21:20.497236
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    """Test that `ReturnValueIgnoredError` has a working constructor.

    This is here for backwards compatibility. The actual implementation
    is in `.gen`, and this function exists only to make sure that
    `ReturnValueIgnoredError` is not optimized away.
    """
    Exc = ReturnValueIgnoredError
    try:
        raise Exc()
    except Exc as e:
        assert str(e) == ""
    try:
        raise Exc("foo")
    except Exc as e:
        assert str(e) == "foo"

# Generated at 2022-06-24 08:21:29.083390
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado import testing, gen
    from concurrent.futures import Future
    from concurrent.futures import ThreadPoolExecutor
    from concurrent.futures import ProcessPoolExecutor
    from multiprocessing import Process

    class DummyExecutorTest(testing.AsyncTestCase):
        @gen.coroutine
        def _test_dummy_executor_multiple(self, repeat_number: int, executor: 'futures.Executor'):
            dummy_executor = DummyExecutor()
            futures = []
            for i in range(repeat_number):
                f1 = Future()
                f2 = Future()

                @gen.coroutine
                def compute():
                    self.assertTrue(f1.set_result(1))
                    f3 = Future()

# Generated at 2022-06-24 08:21:39.355260
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado.ioloop import IOLoop

    class TestClass(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=1, kwarg2=2):
            return arg1, arg2, kwarg1, kwarg2
    class TestClassWithAlternativeAttribute(object):
        def __init__(self):
            self.task_runner = dummy_executor

        @run_on_executor(executor='task_runner')
        def func(self, arg1, arg2, kwarg1=1, kwarg2=2):
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-24 08:21:41.384775
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class Error(Exception):
        pass

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Error())

# Generated at 2022-06-24 08:21:49.283929
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    # Under Python 3.7, asyncio.Future is a subclass of concurrent.futures.Future
    # and thus this test explicitly calls future_set_exc_info
    # with a concurrent.futures.Future object.

    future = futures.Future()
    future_set_exc_info(future, exc_info)  # type: ignore
    assert future.exception() is exc_info[1]

# Generated at 2022-06-24 08:22:01.933210
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    class SomeFuture(Future):
        def __init__(self, expected_result):
            super().__init__()
            self._result = expected_result

        def result(self):
            return self._result

    future = SomeFuture(expected_result=1)
    future2 = SomeFuture(expected_result=2)

    assert future.done() is True
    assert future2.done() is True

    assert future.result() == 1
    assert future2.result() == 2

    class SomeFutureProxy(futures.Future):
        def __init__(self, future):
            super().__init__()
            self._future = future

    def callback(future):
        assert future.result() == 1
        assert future2.result() == 2

    future_add_done_callback(future, callback)
    future_add

# Generated at 2022-06-24 08:22:04.180268
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    try:
        dummy_executor.shutdown()
    except Exception:
        assert False

# Generated at 2022-06-24 08:22:05.575155
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda : 1 + 1)


# Generated at 2022-06-24 08:22:12.393698
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop.current()

    f1 = Future()
    f2 = Future()

    def cb(future):
        assert future is f1

    future_add_done_callback(f1, cb)
    f1.set_result(None)
    io_loop.add_future(f2, cb)
    f2.set_result(None)



# Generated at 2022-06-24 08:22:20.289273
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from pympler import tracker
    import gc
    tr = tracker.SummaryTracker()
    gc.collect()
    tr.print_diff()
    print("Test for method shutdown of class DummyExecutor:")
    print("Before DummyExecutor.shutdown()")
    tr.print_diff()
    dummy_executor.shutdown()
    gc.collect()
    print("After DummyExecutor.shutdown()")
    tr.print_diff()
    tr.print_diff()

# Generated at 2022-06-24 08:22:21.955250
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    e = DummyExecutor()
    f = e.submit(lambda:2)
    assert f.result() == 2

# Generated at 2022-06-24 08:22:23.837750
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    test_future = DummyExecutor().submit(lambda x: x * 2, 10)
    assert test_future.result() == 20

# Generated at 2022-06-24 08:22:32.246680
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(
        future, Exception("Exception message")
    )
    future_set_result_unless_cancelled(future, None)
    future_set_exception_unless_cancelled(
        future, Exception("Exception message")
    )
    assert future.exception() is None
    assert future.done() is True
    # This assertion is not guaranteed to be True.
    assert future.cancelled() is False
    future_set_result_unless_cancelled(future, None)
    future_set_result_unless_cancelled(future, None)
    future_set_exception_unless_cancelled(
        future, Exception("Exception message")
    )

# Generated at 2022-06-24 08:22:33.628034
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:36.469943
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(1)
    assert not is_future(object())



# Generated at 2022-06-24 08:22:47.190252
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.future = Future()
            self.callback_result = None

        def callback(self, future):
            self.callback_result = future.result()

    t = Test()

    def set_result():
        IOLoop.current().remove_timeout(timeout)
        t.future.set_result(1)

    future_add_done_callback(t.future, t.callback)
    assert t.callback_result is None
    timeout = IOLoop.current().add_timeout(IOLoop.current().time() + 0.01, set_result)
    IOLoop.current().start()
    assert t.callback_result == 1

    t2 = Test()
    t2.future.set_result

# Generated at 2022-06-24 08:22:57.992528
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import concurrent.futures
    from tornado.concurrent import Future
    from tornado.concurrent import Future
    from concurrent.futures import Future
    from tornado.concurrent import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future
    from concurrent.futures import Future

    future = Future()
    assert isinstance(future, Future)

    future = Future()
    assert isinstance(future, Future)

    future = Future()
    assert isinstance(future, Future)

    executor = DummyExecutor()

# Generated at 2022-06-24 08:23:02.111678
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert not future.done()
    future = Future()
    future.set_result(2)
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 2

# Generated at 2022-06-24 08:23:06.480970
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f1 = futures.Future()
    f1.cancel()
    future_set_exception_unless_cancelled(f1, RuntimeError("test"))

    f2 = futures.Future()
    future_set_exception_unless_cancelled(f2, RuntimeError("test"))
    assert f2.exception() is not None

# Generated at 2022-06-24 08:23:07.826127
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    assert d.shutdown(1) is None

# Generated at 2022-06-24 08:23:14.223628
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(f):
        assert f.done()

    # concurrent.futures.Future
    future = futures.Future()
    future_add_done_callback(future, callback)
    future.set_result(None)

    # asyncio.Future
    future = Future()
    future_add_done_callback(future, callback)
    future.set_result(None)


# Generated at 2022-06-24 08:23:25.660831
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f3 = Future()
            chain_future(f3, f2)
            self.assertFalse(f2.done())
            f3.set_exception(ValueError)
            self.assertRaises(ValueError, f2.result)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)


# Generated at 2022-06-24 08:23:30.316633
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("Test exception")
    except:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), Exception)

# Generated at 2022-06-24 08:23:33.289747
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_exception_unless_cancelled(future, ZeroDivisionError())
    assert future.exception() == ZeroDivisionError



# Generated at 2022-06-24 08:23:38.196271
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from unittest.mock import Mock
    fn = Mock(return_value=42)
    f = dummy_executor.submit(fn, 1, 2, a=3, b=4)
    assert f.done()
    assert fn.call_args == ((1, 2), dict(a=3, b=4))
    assert f.result() == 42

# Generated at 2022-06-24 08:23:46.228630
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    global task_done
    task_done = False

    f = asyncio.Future()
    f.add_done_callback(lambda future: setattr(future, 'done_by_set_result', True))

    assert not f.done()
    future_set_result_unless_cancelled(f, None)
    assert f.done()

    # Ensure that set_result is propagating to added callback.
    assert f.done_by_set_result

    # Cancel the Future.
    f.cancel()

    # Ensure cancellation is propagating to the callback.
    assert f.done_by_set_result

    # Ensure that the Future is not being marked as done.
    assert f.done()
    assert not f.cancelled()

# Generated at 2022-06-24 08:23:49.440519
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    assert dummy_executor.submit(lambda x: x+3, 7).result() == 10
    assert dummy_executor.submit(lambda x: x/0, 1).exception().__class__.__name__ == 'ZeroDivisionError'

# Generated at 2022-06-24 08:23:54.217750
# Unit test for function chain_future
def test_chain_future():
    a = Future()
    b = Future()
    c = Future()

    chain_future(a, b)
    chain_future(b, c)

    a.set_result(1)
    assert c.result() == 1

    d = Future()
    chain_future(a, d)
    assert d.result() == 1

# Generated at 2022-06-24 08:24:02.975239
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.testing
    import tornado.ioloop
    import tornado.concurrent
    import time

    @tornado.concurrent.run_on_executor(executor='_executor')
    def f():
        return 42

    class T(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(T, self).setUp()
            self._executor = dummy_executor

        def tearDown(self):
            super(T, self).tearDown()
            self._executor.shutdown()

        @tornado.testing.gen_test
        async def test_main(self):
            self.assertEqual((await f()), 42)

    tornado.testing.main()

# Generated at 2022-06-24 08:24:13.680060
# Unit test for function chain_future
def test_chain_future():
    error = IOError()
    # test general failure case
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_exception(error)
    assert future2.exception() is error
    # test cancellation
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.cancel()
    assert future1.cancelled()
    assert future2.cancelled()
    # test multiple chaining
    future1 = Future()
    future2 = Future()
    future3 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    future1.set_exception(error)
    assert future3.exception() is error

#

# Generated at 2022-06-24 08:24:16.535136
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    de = DummyExecutor()
    de.submit(lambda x: x, 1)
    de.shutdown()

# Generated at 2022-06-24 08:24:19.829176
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise TypeError()
    except:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception().__class__ is TypeError
    assert future.exception() is not None

# Generated at 2022-06-24 08:24:21.036113
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


# Generated at 2022-06-24 08:24:22.082351
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert dummy_executor.shutdown() == None

# Generated at 2022-06-24 08:24:29.023118
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import logging
    import time
    import concurrent.futures
    import functools
    import inspect
    import threading
    from tornado.httputil import url_concat
    from tornado.log import access_log, app_log, gen_log
    from tornado.netutil import Resolver
    from tornado.platform.asyncio import AsyncIOLoop
    from tornado.platform.auto import set_close_exec
    from tornado.platform.posix import setsid
    from tornado.platform.select import Waker
    from tornado.platform.twisted import TornadoReactor
    from tornado.platform.windows import _supports_sendfile
    from tornado.process import cpu_count
    from tornado.tcpclient import TCPClient
    from tornado.test.util import unittest
    from tornado import gen
   

# Generated at 2022-06-24 08:24:35.539255
# Unit test for function run_on_executor
def test_run_on_executor():
    _future = True


__all__ = [
    "is_future",
    "DummyExecutor",
    "dummy_executor",
    "Future",
    "ReturnValueIgnoredError",
    "chain_future",
    "future_set_result_unless_cancelled",
    "future_set_exception_unless_cancelled",
    "future_set_exc_info",
    "future_add_done_callback",
]

# Generated at 2022-06-24 08:24:46.989710
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    class Dummy(object):
        def __init__(self) -> None:
            self.executor = dummy_executor
            self._sync_result = None
            self._sync_exception = None
            self._sync_event = Event()

        @run_on_executor
        def sync_call(self, arg: int) -> int:
            return arg

        @run_on_executor
        def sync_exception(self, arg: int) -> None:
            raise ValueError(arg)

        @run_on_executor
        def sync_wait(self, arg: int) -> None:
            self._sync_event.wait()


# Generated at 2022-06-24 08:24:50.665792
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def test(future):
        future.set_result(True)

    f = Future()
    future_add_done_callback(f, test)
    # test should have been called by now.
    f.result()



# Generated at 2022-06-24 08:24:53.186968
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future("")



# Generated at 2022-06-24 08:24:54.369180
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("msg")



# Generated at 2022-06-24 08:24:56.350981
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("a", "b")



# Generated at 2022-06-24 08:25:05.208675
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    from tornado.platform.asyncio import AsyncIOMainLoop

    from tornado.testing import AsyncTestCase
    from tornado.test.util import unittest_run_loop

    class ChainFutureTest(AsyncTestCase):
        def setUp(self) -> None:
            super().setUp()
            # Both tests use the same IOLoop.
            if not AsyncIOMainLoop().asyncio_loop.is_running():
                AsyncIOMainLoop().install()
            self.loop = IOLoop.current()


# Generated at 2022-06-24 08:25:10.198985
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    # Test with an exception type, value and traceback
    future_set_exc_info(future, (ValueError, ValueError(1), None))
    if isinstance(future, Future):
        # Test with an exception instance
        future_set_exc_info(future, (ValueError(2), None, None))
    # Test with a tuple with mismatching exc_info
    try:
        raise ValueError()
    except ValueError:
        exc = sys.exc_info()
    future_set_exc_info(future, (exc[0], exc[2], exc[1]))


if __name__ == "__main__":
    test_future_set_exc_info()

# Generated at 2022-06-24 08:25:21.254927
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import unittest

    class TestException(Exception):
        pass

    class TestFutureSetExcInfo(unittest.TestCase):
        def test_set_exc_info(self):
            future = Future()
            future_set_exc_info(future, sys.exc_info())
            self.assertTrue(future.exception())
            self.assertIsInstance(future.exception(), Exception)

        def test_set_exc_info_from_exception(self):
            future = Future()
            future_set_exc_info(future, (None, TestException(), None))
            self.assertTrue(future.exception())
            self.assertIsInstance(future.exception(), TestException)

        def test_set_exc_info_on_exception(self):
            future = Future()
            future_set_ex

# Generated at 2022-06-24 08:25:32.962671
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.testing.gen_test
    def test():
        # Test chain_future when future is done
        future1 = Future()
        future1.set_result(3)
        future2 = Future()
        chain_future(future1, future2)
        self.assertEqual(future2.result(), 3)

        # Test chain_future when first future is not done
        future1 = Future()
        future2 = Future()
        chain_future(future1, future2)
        future1.set_result(4)
        self.assertEqual(future2.result(), 4)

    test()

# Generated at 2022-06-24 08:25:42.753151
# Unit test for function run_on_executor
def test_run_on_executor():
    class TestClass(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, a, b, callback=None):
            # type: (Any, Any, Optional[Callable]) -> None
            callback([a, b])

    inst = TestClass()
    result = []  # type: List[Any]

    def cb(value):
        # type: (Any) -> None
        result.extend(value)

    inst.func(1, 2, callback=cb)

    assert result == [1, 2]



# Generated at 2022-06-24 08:25:52.675956
# Unit test for function run_on_executor
def test_run_on_executor():
    IOLoop = None
    try:
        from tornado.ioloop import IOLoop
    except ImportError:
        pass
    executor = DummyExecutor()

    class Obj(object):
        executor = executor
        _thread_pool = executor

        @run_on_executor
        def foo(self, a, b):
            IOLoop.current().add_callback_from_signal(lambda: None)
            self.result = a + b
            return self.result

        @run_on_executor(executor='_thread_pool')
        def bar(self, a, b):
            return a * b

        @run_on_executor(executor=executor)
        def baz(self, a, b):
            pass

    o = Obj()

# Generated at 2022-06-24 08:25:56.297930
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except:
        exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)
    assert future.exception().args == (ZeroDivisionError,)



# Generated at 2022-06-24 08:26:01.148480
# Unit test for function chain_future
def test_chain_future():
    lst = [None]
    fut1 = Future()
    fut2 = Future()

    def callback(future):
        assert future is fut1
        lst[0] = fut1.result()

    chain_future(fut1, fut2)
    future_add_done_callback(fut2, callback)
    fut1.set_result(42)
    assert lst == [42]

# Generated at 2022-06-24 08:26:09.949737
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa
    import tornado.gen
    import tornado.testing
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    @tornado.gen.coroutine
    def test():
        def cb(future):
            if not future.cancelled():
                future.set_result(True)

        f = tornado.concurrent.Future()
        future_add_done_callback(f, cb)
        f.set_result(False)
        result = yield f
        tornado.testing.assert_true(result)

        f = tornado.concurrent.Future()
        future_add_done_callback(f, cb)
        result = yield f
        tornado.testing.assert_true(result)

        f = tornado.concurrent.Future()

# Generated at 2022-06-24 08:26:20.840227
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    from tornado.ioloop import IOLoop
    import functools
    import time

    @unittest.skipIf(sys.version_info >= (3, 8), 'skip python 3.8 since the CancelledError is gone')
    class TestFutureSetResultUnlessCancelled(unittest.TestCase):
        def test_future_set_result_unless_cancelled(self):

            def callback(f):
                self.assertEqual(f.result(), "I succeed")

            def cancel_callback(f):
                self.assertTrue(f.cancelled())

            def cancel_callback2(f):
                self.assertTrue(f.cancelled())

            f = Future()
            f.add_done_callback(callback)

            g = Future()
            g.add_done_

# Generated at 2022-06-24 08:26:29.345843
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # pragma: no cover
    import asyncio
    import tornado.log

    # Don't log to stderr
    test_log = tornado.log.gen_log.name("tornado.test.future")

    async def do_test():
        future = asyncio.Future()
        try:
            1 / 0
        except ZeroDivisionError:
            future_set_exc_info(future, sys.exc_info())
        assert future.exception() is not None
        # Future.exception is documented to return the exception instance
        # itself, not the exc_info tuple.
        assert isinstance(future.exception(), ZeroDivisionError)

        future = asyncio.Future()
        try:
            1 / 0
        except ZeroDivisionError:
            exc_info = sys.exc_info()
            future_set_

# Generated at 2022-06-24 08:26:38.914270
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # This test demonstrates that future_add_done_callback is called
    # immediately when future is already done.
    import time
    import tornado.ioloop
    import tornado.testing
    import tornado.concurrent

    def wait_until_done(future):
        time.sleep(0.01)
        if future.done():
            return
        tornado.ioloop.IOLoop.current().add_callback(functools.partial(wait_until_done, future))

    @tornado.testing.gen_test
    def test_future_add_done_callback(self):
        # Create a Future which is already done.
        future = tornado.concurrent.Future()
        future.set_result(10)
        # We wait until the Future is done.
        wait_until_done(future)
        # Then we register a callback.

# Generated at 2022-06-24 08:26:44.488895
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    done = False
    def mark_done(fut):
        assert isinstance(fut, Future)
        nonlocal done
        done = True
    f = Future()
    future_add_done_callback(f, mark_done)
    f.set_result(None)
    assert done



# Generated at 2022-06-24 08:26:56.771122
# Unit test for function chain_future
def test_chain_future():
    # Test that chain_future works with both types of futures
    def cc():
        future_a = Future()  # type: Future[_T]
        future_b = future_a
        future_c = concurrent.futures.Future()  # type: futures.Future[_T]
        future_d = future_c
        future_a.set_result(None)
        assert future_c.done()
        assert future_d.done()
    cc()

    def dd():
        future_a = Future()  # type: Future[_T]
        future_b = future_a
        future_c = concurrent.futures.Future()  # type: futures.Future[_T]
        future_d = future_c
        future_a.set_exception(Exception)
        assert future_c.done()
        assert future

# Generated at 2022-06-24 08:27:05.854163
# Unit test for function run_on_executor
def test_run_on_executor():
    class MyClass(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def my_method(self):
            return 42

    inst = MyClass()
    f = inst.my_method()
    assert f.result() == 42

    class OtherExecutorClass(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_executor")
        def my_method(self):
            return 42

    inst = OtherExecutorClass()
    f = inst.my_method()
    assert f.result() == 42


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 08:27:14.485792
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = futures.Future()
    exc = Exception()

    future_set_exception_unless_cancelled(future, exc)
    assert exc is future.exception()

    future = futures.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

    future = asyncio.Future()
    future_set_exception_unless_cancelled(future, exc)
    assert exc is future.exception()

    future = asyncio.Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is None

# Generated at 2022-06-24 08:27:17.569662
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def f():
        pass
    obj = DummyExecutor()
    obj.submit(f)
    obj.shutdown(False)
    obj.shutdown()
    assert obj.submit(f) is not None


# Generated at 2022-06-24 08:27:22.997769
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def test(cancel):
        future = Future()
        if cancel:
            future.cancel()
        future_set_result_unless_cancelled(future, 42)
        if cancel:
            assert future.cancelled()
        else:
            assert future.result() == 42

    test(True)
    test(False)



# Generated at 2022-06-24 08:27:26.035854
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = dummy_executor
    future = executor.submit(lambda : 1+1)
    assert future.result() == 2


# Generated at 2022-06-24 08:27:27.165512
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())


# Generated at 2022-06-24 08:27:34.928461
# Unit test for function chain_future
def test_chain_future():
    io_loop = asyncio.get_event_loop()

    @gen.coroutine
    def async_test(x, y, z=None):
        yield gen.sleep(0.01)
        raise gen.Return(x + y + z)

    def sync_test(x, y, z=None):
        return x + y + z

    @gen.coroutine
    def runner(func, *args, **kwargs):
        raise gen.Return((yield func(*args, **kwargs)))

    async_result = async_test(1, 2, z=3)
    sync_result = sync_test(1, 2, z=3)
    f = Future()
    chain_future(async_result, f)
    io_loop.run_sync(runner, f.result)
    # make sure our result