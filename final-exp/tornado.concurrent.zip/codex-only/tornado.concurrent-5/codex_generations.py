

# Generated at 2022-06-24 08:17:32.267849
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()

    def test_method(a, b):
        return a + b

    test_executor_future = executor.submit(test_method, 1, 2)
    assert test_executor_future.result() == 3

# Generated at 2022-06-24 08:17:34.171143
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())
    assert not is_future(None)

# Generated at 2022-06-24 08:17:36.998119
# Unit test for function chain_future
def test_chain_future():
    done_future = Future()
    done_future.set_result(42)
    result_future = Future()
    chain_future(done_future, result_future)
    assert result_future.result() == 42



# Generated at 2022-06-24 08:17:41.979666
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    "Test the method shutdown of class DummyExecutor"
    # declaration
    dummy_executor = DummyExecutor()

    # call the method
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:17:47.430680
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    def check(future, exc):
        future_set_exception_unless_cancelled(future, exc)
        assert future.exception() is exc

    future = Future()
    exc = Exception()
    check(future, exc)

    future = Future()
    future.cancel()
    check(future, exc)

    future = Future()
    exc = asyncio.CancelledError()
    check(future, exc)

    future = Future()
    future.cancel()
    check(future, exc)

# Generated at 2022-06-24 08:17:52.849886
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1/0 # type: ignore
    except ZeroDivisionError:
        future_set_exc_info(future, sys.exc_info())
    assert isinstance(future.exception(), ZeroDivisionError)


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 08:17:54.403254
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future()) == True
    assert is_future(Future()) == True

# Generated at 2022-06-24 08:18:00.071139
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
        future_set_exc_info(future, exc_info)
    assert isinstance(future.exception(), ZeroDivisionError)



# Generated at 2022-06-24 08:18:05.455073
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled() is False
    assert f.exception()

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled() is True

# Generated at 2022-06-24 08:18:14.264326
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.testing import gen_test, bind_unused_port, AsyncTestCase

    def test_func():
        pass

    f = Future()

    @gen_test
    def test_future_add_done_callback_asyncio_future(self):
        future_add_done_callback(f, test_func)
        f.set_result(None)

    _, port = bind_unused_port()
    AsyncTestCase.configure("tornado.simple_httpclient.AsyncHTTPClient")
    AsyncTestCase.get_ioloop().run_sync(test_future_add_done_callback_asyncio_future)



# Generated at 2022-06-24 08:18:15.725917
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    assert ReturnValueIgnoredError('foo').args == ('foo',)

# Generated at 2022-06-24 08:18:26.082930
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()


# Generated at 2022-06-24 08:18:27.939327
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    assert f.done()



# Generated at 2022-06-24 08:18:34.766502
# Unit test for function run_on_executor
def test_run_on_executor():
    import mock
    import unittest

    class Example(object):
        def __init__(self):
            self.executor = dummy_executor

        def start(self):
            self.future = self.executor.submit(self.run)

        @run_on_executor
        def run(self):
            return 42

    result = []

    def callback(future):
        result.append(future.result())
    example = Example()
    example.future.add_done_callback(callback)
    with mock.patch.object(example.executor, "submit", wraps=example.executor.submit):
        example.start()
    assert result == [42]


if __name__ == "__main__":
    import unittest


# Generated at 2022-06-24 08:18:38.866634
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

# Generated at 2022-06-24 08:18:42.280295
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def test_future_set_exc_info(self):
            future = Future()

            @gen_test
            async def test():
                try:
                    raise ValueError("test")
                except:
                    future_set_exc_info(future, sys.exc_info())
                with self.assertRaises(ValueError):
                    await future

    test_future_set_exc_info_case = MyTestCase("test_future_set_exc_info")
    test_future_set_exc_info_case.test_future_set_exc_info()



# Generated at 2022-06-24 08:18:51.200146
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from concurrent.futures import Future
    from tornado import gen
    from tornado.platform.asyncio import to_asyncio_future

    @gen.coroutine
    def f():
        pass

    future = gen.convert_yielded(f())
    f2 = Future()
    future_add_done_callback(future, lambda f: f2.set_result(None))
    assert len(future._callbacks) == 1
    aio_future = to_asyncio_future(future)
    future_add_done_callback(aio_future, lambda f: f2.set_result(None))
    assert len(aio_future._callbacks) == 1
    assert future._callbacks == aio_future._callbacks

# Generated at 2022-06-24 08:18:54.963852
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future(object())
    assert is_future(Future())
    assert is_future(futures.Future())



# Generated at 2022-06-24 08:18:57.231269
# Unit test for function is_future
def test_is_future():
    import asyncio
    assert is_future(Future())
    assert is_future(asyncio.Future())


# Generated at 2022-06-24 08:19:07.463382
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import pytest
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    from tornado import gen
    import asyncio
    from collections import deque
    import sys

    class FutureTestCase(AsyncTestCase):
        @gen_test(timeout=40)
        async def test_future_set_result_called_on_cancelled_future(self):
            # Create a future with a cancelled state
            loop = asyncio.get_event_loop()
            future1 = Future()
            future1.set_result(10)
            future2 = Future()
            future2.cancel()
            future_set_result_unless_cancelled(future2, 10)
            assert future2.cancelled()


# Generated at 2022-06-24 08:19:10.610564
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # Just call it, to make sure it doesn't throw an exception
    dummy_executor.shutdown()
    return True

# Generated at 2022-06-24 08:19:14.055274
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    assert isinstance(dummy_executor, DummyExecutor)


# Generated at 2022-06-24 08:19:15.908414
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(x):
        return x + 1

    future = dummy_executor.submit(func, 2)
    assert future.result() == 3



# Generated at 2022-06-24 08:19:17.729214
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception)
    f = Future()
    future_set_exception_unless_cancelled(f, Exception)

# Generated at 2022-06-24 08:19:26.956905
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest
    from tornado.test.util import stop_loop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.loop = AsyncIOMainLoop()
            self.loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            stop_loop(self.loop)
            self.loop.close()

        @run_on_executor
        def func_to_be_run_in_executor(self):
            return 42

    t = MyTestCase()
    t.setUp()
    result = t.func_to_be_run_in_executor()

# Generated at 2022-06-24 08:19:32.134590
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 10)
    future_set_result_unless_cancelled(future, 20)
    assert future.result() == 10
    future2 = Future()
    future2.cancel()
    future_set_result_unless_cancelled(future2, 10)
    assert future2.cancelled()

# Generated at 2022-06-24 08:19:40.938732
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()

    try:
        raise Exception("hello")
    except Exception:
        exc_info = sys.exc_info()  # type: ignore

    future_set_exc_info(future, exc_info)
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exc_info(future, exc_info)

# Generated at 2022-06-24 08:19:47.787224
# Unit test for function chain_future
def test_chain_future():
    def f():
        # type: () -> Future[int]
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        return f2

    assert isinstance(f(), Future)

    f2 = f()
    # Return type is really Future[int], but mypy doesn't figure that out.
    assert isinstance(f2, Future)  # type: ignore
    assert f2.result() == 42

# Generated at 2022-06-24 08:19:51.134023
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    def f(a):
        return a

    exe = DummyExecutor()
    exe.submit(f, 1)
    print(exe.submit(f, 2))

if __name__ == "__main__":
    test_DummyExecutor_shutdown()

# Generated at 2022-06-24 08:19:52.882866
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future("foo")
    assert not is_future(object())



# Generated at 2022-06-24 08:19:54.421511
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-24 08:19:57.921153
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert isinstance(executor, DummyExecutor)
    assert isinstance(executor, futures.Executor)


# Generated at 2022-06-24 08:19:58.958641
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:20:04.673761
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    assert not f1.done()
    assert not f2.done()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f1.done()
    assert f2.done()
    assert f2.result() == 42



# Generated at 2022-06-24 08:20:11.549836
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.exception()
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())
    assert f.cancelled()



# Generated at 2022-06-24 08:20:23.044998
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    @gen.coroutine
    def f():
        raise gen.Return(42)

    @gen.coroutine
    def f2():
        raise gen.Return(2)

    @gen.coroutine
    def f3():
        raise gen.Return(3)

    @gen.coroutine
    def check_chaining():
        future1 = f()
        future2 = f2()
        f3()
        future1.set_result(42)
        future2.set_result(2)
        assert not future1.done()
        assert not future2.done()

    # Make sure that the coroutine continues executing even with
    # no IOLoop running
    check_chaining()

    # Make sure that the coroutine does not continue when run until
    # it's finished

# Generated at 2022-06-24 08:20:32.376369
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    from tornado import gen
    from tornado.ioloop import IOLoop

    loop = IOLoop()

    class MyClass:
        def __init__(self):
            self.executor = futures.ThreadPoolExecutor(2)

        @run_on_executor
        def func(self, a, b):
            return a + b

    class TestRunOnExecutor(unittest.TestCase):
        def test_run_on_executor(self):
            obj = MyClass()

            @gen.coroutine
            def f():
                result = yield obj.func(5, 6)
                self.assertEqual(result, 11)
                result = yield gen.maybe_future(obj.func(6, 7))
                self.assertEqual(result, 13)
                # Exercise the deprecated arguments

# Generated at 2022-06-24 08:20:33.693650
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    assert isinstance(dummy_executor, DummyExecutor)

# Generated at 2022-06-24 08:20:35.014494
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())  # type: ignore
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:20:35.565524
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    DummyExecutor()

# Generated at 2022-06-24 08:20:37.161387
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown(False)
    executor.shutdown(True)
    executor.shutdown()


# Generated at 2022-06-24 08:20:45.020793
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    msg1 = "foo"
    msg2 = "bar"
    try:
        raise ReturnValueIgnoredError(msg1)
    except ReturnValueIgnoredError:
        exc = sys.exc_info()[1]
        assert msg1 in exc.args
        assert not msg2 in exc.args
    try:
        raise ReturnValueIgnoredError(msg1, msg2)
    except ReturnValueIgnoredError:
        exc = sys.exc_info()[1]
        assert msg1 in exc.args
        assert msg2 in exc.args



# Generated at 2022-06-24 08:20:46.699831
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:20:52.896630
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def f():
        1 / 0

    try:
        f().send(None)
    except Exception:
        exc_info = sys.exc_info()
    exc = Exception()

    future = Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() == exc_info[1]

    future = futures.Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() == exc_info[1]

# Generated at 2022-06-24 08:20:56.179454
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    @run_on_executor
    def foo(*args: Any, **kwargs: Any):
        return args, kwargs
    f = foo(1,2,3, test=1)
    print(f.result())

if __name__ == '__main__':
    test_DummyExecutor()

# Generated at 2022-06-24 08:21:04.878784
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future: Future) -> None:
        assert future.result() == 1
        complete.append(1)

    future = Future()
    complete = []
    future_add_done_callback(future, callback)
    future_add_done_callback(future, lambda future: complete.append(2))
    assert not complete
    future.set_result(1)
    assert complete == [1, 2]

    future = Future()
    future.set_result(1)
    future_add_done_callback(future, callback)
    assert complete == [1, 2, 1]



# Generated at 2022-06-24 08:21:07.590641
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()
    try:
        executor.submit(print, "hello")
        assert False
    except RuntimeError:
        pass


# Generated at 2022-06-24 08:21:17.790953
# Unit test for function run_on_executor
def test_run_on_executor():
    try:
        # Try to import this to ensure it's not already installed.
        # It's important that we don't install it globally because
        # we want to test exactly the unpatched version.
        import trollius

        trollius.is_installed = True
    except ImportError:
        trollius = None

    if trollius is None:
        # The trollius module is not installed or is not up-to-date,
        # so we can't test this method.
        return

    import tornado.concurrent

    # trollius has both a ThreadPoolExecutor and a ProcessPoolExecutor;
    # we want to use the latter.
    with trollius.ProcessPoolExecutor() as executor:
        class A(object):
            executor = executor


# Generated at 2022-06-24 08:21:22.377795
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None


try:
    from asyncio import Task
except ImportError:
    Task = None

if Task is not None:

    @typing.overload
    def ensure_future(future: "Future[_T]", loop: Optional[asyncio.BaseEventLoop] = ...) -> "Future[_T]":
        pass

    @typing.overload
    def ensure_future(future: "_T", loop: Optional[asyncio.BaseEventLoop] = ...) -> "Future[_T]":
        pass


# Generated at 2022-06-24 08:21:29.793214
# Unit test for function run_on_executor
def test_run_on_executor():
    import tornado.ioloop

    class A:
        def __init__(self):
            self._executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

        @run_on_executor(executor="_executor")
        def bar(self, a, b):
            return a + b

    a = A()
    f = a.foo(1, 2)
    f2 = a.bar(10, 20)

    tornado.ioloop.IOLoop.current().run_sync(lambda: f)
    tornado.ioloop.IOLoop.current().run_sync(lambda: f2)
    assert f.result() == 3
    assert f2.result() == 30

# Generated at 2022-06-24 08:21:34.609256
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future([])
    assert not is_future(object())
    assert not is_future(test_is_future)
    assert not is_future(1)

# Generated at 2022-06-24 08:21:41.837928
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    fut = Future()
    fut.cancel()
    try:
        future_set_exception_unless_cancelled(fut, ValueError())
    except ValueError:
        assert False, "ValueError raised"
    # No exception should be raised by this function
    fut = Future()
    try:
        future_set_exception_unless_cancelled(fut, ValueError())
    except ValueError:
        assert False, "ValueError raised"

# Generated at 2022-06-24 08:21:44.026618
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.set_result(None)
    assert future.result() is None

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() is None



# Generated at 2022-06-24 08:21:48.541397
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    test_future = Future()
    test_future.cancel()
    future_set_result_unless_cancelled(test_future, 1)
    assert not test_future.cancelled()
    assert test_future.result() == 1



# Generated at 2022-06-24 08:21:52.437456
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    x: DummyExecutor = DummyExecutor()
    x.submit(lambda y: y, None)
    del x


# Generated at 2022-06-24 08:21:56.346562
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa: F811
    executor = futures.ThreadPoolExecutor(1)
    future = executor.submit(lambda: None)

    finished = False

    def callback(f: "Future[None]"):
        assert f is future
        nonlocal finished
        finished = True

    future_add_done_callback(future, callback)
    assert finished
    future.result()



# Generated at 2022-06-24 08:22:05.359735
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from concurrent.futures import Future
    from tornado.testing import AsyncTestCase, gen_test

    class _TestFutureSetResultUnlessCancelled(AsyncTestCase):
        @gen_test
        def test_future_set_result_unless_cancelled(self):
            def await_future(future):
                return future_set_result_unless_cancelled(future, "value")

            future = Future()  # type: Future
            future.cancel()
            future_set_result_unless_cancelled(future, "value")
            self.assertTrue(future.cancelled())

            future = Future()  # type: Future
            await_future(future)
            self.assertEqual(future.result(), "value")

    _TestFutureSetResultUnlessCancelled().test_future_set_result_

# Generated at 2022-06-24 08:22:11.467071
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    a = Future()
    exc = ValueError()
    a.cancel()
    future_set_exception_unless_cancelled(a, exc)
    assert a.cancelled() and not a.exception()
    b = Future()
    future_set_exception_unless_cancelled(b, exc)
    assert b.exception() is exc



# Generated at 2022-06-24 08:22:22.473045
# Unit test for function chain_future
def test_chain_future():
    # pytype: disable=unsupported-operands
    d = Future()  # type: Future[int]
    e = Future()  # type: Future[int]
    chain_future(d, e)
    d.set_result(42)
    assert d.result() == 42
    assert e.result() == 42

    d2 = Future()
    e2 = Future()
    chain_future(d2, e2)
    d2.set_exception(ValueError())
    assert e2.exception() is not None
    assert isinstance(e2.exception(), ValueError)

    d3 = Future()
    e3 = Future()
    chain_future(d3, e3)
    e3.cancel()
    d3.set_result(42)
    assert d3.result() == 42

# Generated at 2022-06-24 08:22:31.219618
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from unittest import mock

    class A(object):
        a = 1
        b = 2
        _executor = mock.Mock()  # type: ignore

        @run_on_executor
        def foo(self, x):
            # type: (int) -> int
            return self.a + self.b + x

        @run_on_executor(executor="_executor")
        def bar(self, x):
            # type: (int) -> int
            return self.a + self.b + x

    a = A()
    a._executor.submit.return_value = mock.Mock()  # type: ignore
    a._executor.submit.return_value.result.return_value = 10  # type: ignore

# Generated at 2022-06-24 08:22:34.038676
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    only_exc = ReturnValueIgnoredError("message")
    assert only_exc.args == ("message",)
    both_exc = ReturnValueIgnoredError("message", "buffer")
    assert both_exc.args == ("message", "buffer")

# Generated at 2022-06-24 08:22:41.259924
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    if sys.version_info[:2] < (3, 6):
        # Before Python 3.6, it is not possible to create a class with an empty
        # __init__, so we need to specify the entire constructor.
        class ReturnValueIgnoredError(Exception):
            pass
    else:
        class ReturnValueIgnoredError(Exception):
            def __init__(self):
                pass  # type: ignore
    r = ReturnValueIgnoredError()
    assert r is not None

# Generated at 2022-06-24 08:22:43.455040
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    msg = "foo"
    e = ReturnValueIgnoredError(msg)
    assert str(e) == msg



# Generated at 2022-06-24 08:22:52.082569
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(24)
    assert f2.result() == 42
    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())

# Generated at 2022-06-24 08:22:54.797551
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def foo(*args, **kwargs) -> int:
        return 123

    ex = DummyExecutor()
    f = ex.submit(foo)
    assert f.result() == 123

# Generated at 2022-06-24 08:22:55.900330
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with DummyExecutor() as ex:
        assert isinstance(ex, DummyExecutor)


# Generated at 2022-06-24 08:23:02.915085
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = asyncio.Future()
    assert f.cancelled() is False
    f.cancel()
    assert f.cancelled()
    future_set_result_unless_cancelled(f, 'foo')
    assert f.cancelled()
    assert f.done()
    assert f.result() == 'foo'



# Generated at 2022-06-24 08:23:08.660226
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class ValueError(Exception):
        pass
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.cancelled()
    assert future.exception() is ValueError
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-24 08:23:10.079933
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:23:12.949737
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-24 08:23:16.485986
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    try:
        future_set_exception_unless_cancelled(f, ValueError("test"))
    except ValueError:
        raise AssertionError("future_set_exception_unless_cancelled failed")

# Generated at 2022-06-24 08:23:22.655357
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    called = [0]
    def callback(future):
        assert not future.cancelled()
        assert future.done()
        assert future.result() == 42
        called[0] += 1
    future_add_done_callback(future, callback)
    assert called == [1]
    future.set_result(42)
    assert called == [1]
    future.set_result(43)
    assert called == [1]


# Generated at 2022-06-24 08:23:24.508662
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    fut = dummy_executor.submit(lambda x: x, 5)
    assert(fut.result() == 5)

# Generated at 2022-06-24 08:23:29.467244
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class Foo:
        pass

    foo = Foo()

    try:
        raise ReturnValueIgnoredError("Class: %s" % repr(foo))
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:23:33.550245
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    done = []

    def callback(f):
        done.append(f)

    future_add_done_callback(f, callback)
    f.set_result(1)
    assert done[0] is f

# Generated at 2022-06-24 08:23:37.460958
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    def test_exc(exc):
        f.set_exception(exc)
        future_set_exception_unless_cancelled(f, exc)
    test_exc(RuntimeError())
    f.cancel()
    test_exc(RuntimeError())

# Generated at 2022-06-24 08:23:43.412388
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from tornado.concurrent import DummyExecutor
    from concurrent.futures import Future
    import threading
    import time
    def f(i):
        time.sleep(0.1)
        return threading.current_thread()
    dummy_executor = DummyExecutor()
    d = dummy_executor.submit(f,5)
    d.add_done_callback(lambda f: f.result())

    dummy_executor.shutdown()

# Generated at 2022-06-24 08:23:52.962412
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import io
    import sys
    import unittest
    import textwrap

    io_loop = IOLoop()
    # Set this up to capture stderr
    stderr = io.StringIO() if sys.version_info >= (3,) else io.BytesIO()
    save_stderr = sys.stderr
    sys.stderr = stderr

# Generated at 2022-06-24 08:24:01.539929
# Unit test for function run_on_executor
def test_run_on_executor():
    @run_on_executor
    def my_function(self):
        return "hello"

    class MyClass(object):
        executor = dummy_executor

        def __init__(self):
            self.callback_result = None

        def my_method(self, callback):
            future = my_function(self)
            future.add_done_callback(
                lambda f: self.io_loop.add_future(f, callback))
            return future

    c = MyClass()
    c.my_method(c.callback)
    assert c.callback_result == "hello"

# Generated at 2022-06-24 08:24:04.851672
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(1)
    assert not is_future("")
    assert not is_future(object())

# Generated at 2022-06-24 08:24:06.592761
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:24:08.786242
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    de = DummyExecutor()
    assert de.submit(lambda x: x, 8)  == 8

# Generated at 2022-06-24 08:24:10.276554
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())

# Generated at 2022-06-24 08:24:11.641227
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:24:24.342007
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    @run_on_executor
    def fail():
        1 / 0
        return True

    @gen.coroutine
    def test():
        f = fail()
        try:
            yield f
        except ZeroDivisionError:
            # this would pass with the original Tornado version of the
            # function, but it wouldn't give us a traceback
            pass
        raise gen.Return(False)

    class FakeFuture(object):
        def __init__(self):
            self.exc_info = None

        def done(self):
            return True

        def result(self):
            return True

    future = FakeFuture()
    f = fail()
    future_set_exc_info(future, f.exc_info())
    assert future.exc_info



# Generated at 2022-06-24 08:24:37.471194
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import functools

    class FuturesTest(unittest.TestCase):
        def setUp(self):
            self.futures = []  # type: typing.List[typing.Any]

        def tearDown(self):
            for f in self.futures:
                f.cancel()

        def new_future(self) -> Future:
            f = Future()
            self.futures.append(f)
            return f

        @run_on_executor
        def f(self, value: int) -> int:
            return value

        @run_on_executor(executor="_thread_pool")
        def g(self, value: int) -> int:
            return value

        def setUp(self):
            # type: () -> None
            self.exec

# Generated at 2022-06-24 08:24:48.542006
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # todo: test arguments
    dummy_executor = DummyExecutor()

    # todo: test return value of method submit
    # todo: test default behavior of method submit
    # todo: test behavior of method submit when arguments are invalid
    dummy_executor.submit(lambda : None)

    # todo: test behavior of method submit when return values are invalid
    dummy_executor.submit(lambda : None, None)

    # todo: test return value of method shutdown
    # todo: test default behavior of method shutdown
    # todo: test behavior of method shutdown when arguments are invalid
    dummy_executor.shutdown()

    # todo: test behavior of method shutdown when return values are invalid
    dummy_executor.shutdown("")


# Generated at 2022-06-24 08:24:52.070547
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    fut = Future()  # type: Future[int]
    try:
        raise ValueError
    except:
        future_set_exc_info(fut, sys.exc_info())
    assert fut.exception() is not None



# Generated at 2022-06-24 08:24:57.709033
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, 2)
    except asyncio.InvalidStateError:
        pass
    assert future.cancelled() is True

# Generated at 2022-06-24 08:25:01.823371
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    ioloop = tornado.ioloop.IOLoop.current()
    ioloop.run_sync(lambda: dummy_executor.submit(lambda: None))


# Unit tests for function chain_future

# Generated at 2022-06-24 08:25:03.005752
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError('testError')


# Generated at 2022-06-24 08:25:14.353013
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    f = Future()
    callback_called = [False]

    def callback(future):
        # type: (Future) -> None
        callback_called[0] = True
        assert future is f

    future_add_done_callback(f, callback)
    assert callback_called[0]
    f.cancel()

    f = Future()
    callback_called[0] = False
    future_add_done_callback(f, callback)
    assert not callback_called[0]
    f.set_result(None)
    assert callback_called[0]

    f = futures.Future()
    callback_called[0] = False
    future_add_done_callback(f, callback)
    assert not callback_called[0]
    f.set_result(None)

# Generated at 2022-06-24 08:25:22.406697
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    exec = DummyExecutor()
    import tornado.platform.asyncio
    future = exec.submit(lambda x: x * 10, 2)
    def future_callback(f: any) -> None:
        print("future_callback: %s" % f.result())
    tornado.platform.asyncio.AsyncIOMainLoop().call_soon(future_callback, future)
    tornado.platform.asyncio.AsyncIOMainLoop().run_forever()

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:25:27.745246
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    # The result is set.
    assert future.result() == "result"
    # Future does not raise a tornado.util.CancelledError exception.
    assert not future.cancelled()

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    # Future raises a tornado.util.CancelledError exception.
    assert future.cancelled()
    assert future.exception()



# Generated at 2022-06-24 08:25:29.578773
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 5)
    assert future.cancelled()

# Generated at 2022-06-24 08:25:30.661248
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()

# Generated at 2022-06-24 08:25:36.832768
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Type: (...) -> Future
    # Type: (Executor, Callable, *Any, **Any) -> Future
    pass



# Generated at 2022-06-24 08:25:47.209664
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    from unittest import mock
    from tornado.testing import AsyncTestCase, gen_test

    class ExampleClass(AsyncTestCase):
        executor = "executor"

        def __init__(self):
            super(ExampleClass, self).__init__()

            self.executor = "executor"
            setattr(self, "executor", mock.MagicMock())
            self._thread_pool = "executor"
            setattr(self, "_thread_pool", mock.MagicMock())

        @run_on_executor
        def foo(self, a, b):
            # type: (str, str) -> str
            return a + b


# Generated at 2022-06-24 08:25:55.423172
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class TestCase(unittest.TestCase):
        def tearDown(self):
            # Always stop the loop in case a test fails before it calls stop
            IOLoop.current().stop()

        def test_function(self):
            @run_on_executor
            def f(x, y):
                return x + y

            f(1, 2)

        def test_method(self):
            class Test(object):
                @run_on_executor
                def f(self, x, y):
                    return x + y

            Test().f(1, 2)

    unittest.main()


if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-24 08:26:08.150284
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.get_event_loop()

    # Chain a concurrent.futures.Future to an asyncio.Future
    cf = futures.Future()
    af = Future()
    chain_future(af, cf)
    assert not cf.done()
    af.set_result(42)
    assert cf.done()
    assert cf.result() == 42

    # Chain an asyncio.Future to a concurrent.futures.Future
    cf = futures.Future()
    af = Future()
    chain_future(cf, af)
    assert not af.done()
    cf.set_result(42)
    loop.run_until_complete(af)
    assert af.result() == 42

    # An exception is copied from a Future to its chained pair
    cf = futures.Future()
    af = Future()
   

# Generated at 2022-06-24 08:26:11.403027
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # equal(1,1)
    assert 1==1
    a = dummy_executor
    a.shutdown()
    dummy_executor.shutdown()



# Generated at 2022-06-24 08:26:21.560425
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from concurrent import futures
    from tornado.concurrent import Future

    def fn(x: Any, y: Any) -> Any:
        return x + y

    dummy_executor = DummyExecutor()
    future1 = Future()
    future2 = Future()
    dummy_executor.submit(fn, 1, 2)
    assert not future1.done()
    assert not future2.done()
    assert future1.result() == None
    assert future2.result() == None
    assert future1.exception() == None
    assert future2.exception() == None
    dummy_executor.submit(fn, 1, 2)
    assert future1.result() == None
    assert future2.result() == None
    assert future1.exception() == None
    assert future2.exception() == None

# Unit test

# Generated at 2022-06-24 08:26:22.203603
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    print(ReturnValueIgnoredError())

# Generated at 2022-06-24 08:26:25.121019
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    x = Future()
    x.set_result(42)
    result = []
    future_add_done_callback(x, lambda x: result.append(x.result()))
    assert result == [42]
    y = Future()
    y.set_result(42)
    future_add_done_callback(y, lambda x: result.append(x.result()))



# Generated at 2022-06-24 08:26:29.783332
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    from tornado.concurrent import Future

    from concurrent import futures
    conc_future = futures.Future() # type: futures.Future
    async_future = Future() # type: Future
    assert is_future(conc_future)
    assert is_future(async_future)


# Generated at 2022-06-24 08:26:37.506891
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.platform.asyncio import AsyncIOMainLoop
    from concurrent.futures import ThreadPoolExecutor

    class Test(object):
        executor = ThreadPoolExecutor(1)

        @run_on_executor
        def f(self):
            return 42

    AsyncIOMainLoop().install()
    t = Test()
    # Test with concurrent.futures.Future
    f = t.f()
    assert isinstance(f, futures.Future)
    with unittest.mock.patch(
        "tornado.concurrent._chain_future", wraps=chain_future
    ) as chain_future:
        f.result()
        chain_future.assert_called_with(f, f)
    # Test with asyncio.Future
    AsyncIOMain

# Generated at 2022-06-24 08:26:39.076714
# Unit test for function is_future
def test_is_future():
    is_future(futures.Future())
    is_future(Future())

# Generated at 2022-06-24 08:26:41.735054
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda: 2)
    assert future.result() == 2

# Generated at 2022-06-24 08:26:49.194032
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Test for issue 9861
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()
    assert f.done()
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert not f.cancelled()
    assert f.done()
    assert f.result() == 42
    # Test for issue 12493
    f = Future()
    f.set_result(None)
    future_set_result_unless_cancelled(f, 42)
    assert not f.cancelled()
    assert f.done()
    assert f.result() == 42



# Generated at 2022-06-24 08:26:51.711086
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(object())



# Generated at 2022-06-24 08:26:58.091314
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()  # type: Future
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.result() == 1
    # Cancel the future
    future.cancel()
    # Try to set the future's result
    future_set_result_unless_cancelled(future, 1)
    assert future.done()
    assert future.cancelled()
    assert future.result() == 1

# Generated at 2022-06-24 08:27:00.777863
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda : print("Hello, World"))
    print("waiting ...")
    print(future.result())

# Generated at 2022-06-24 08:27:04.129330
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future("abc")
    assert is_future(Future())
    assert is_future(futures.Future())
    assert is_future(Future().add_done_callback(lambda f: None))

# Generated at 2022-06-24 08:27:10.080577
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    async def async_test():
        future = Future()
        future_add_done_callback(future, lambda future: None)
        future.set_result(None)
    asyncio.get_event_loop().run_until_complete(async_test())
    future = futures.Future()
    future_add_done_callback(future, lambda future: None)
    future.set_result(None)



# Generated at 2022-06-24 08:27:14.789764
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        callback.called = True
    callback.called = False
    future = Future()
    future_add_done_callback(future, callback)
    assert not callback.called
    future.set_result(None)
    assert callback.called
    callback.called = False
    future = Future()
    future.set_result(None)
    future_add_done_callback(future, callback)
    assert callback.called

# We define a few helpers that are part of the public API for Futures
# but are not yet available in concurrent.futures.  Once they are
# defined there, they should be removed from this file.



# Generated at 2022-06-24 08:27:17.696729
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def dummy_function(x):
        return(x)
    dummy_executor=DummyExecutor()
    dummy_future=dummy_executor.submit(dummy_function,1)
    assert dummy_future.result()==1

# Generated at 2022-06-24 08:27:29.442276
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # noqa: F811
    from tornado.testing import AsyncTestCase, gen_test

    class TestFuture(Future):
        def __init__(self):
            super().__init__()
            self.add_done_callback_call_count = 0

        def add_done_callback(self, callback: Callable[..., None]) -> None:
            self.add_done_callback_call_count += 1
            super().add_done_callback(callback)

    class DummyException(Exception):
        pass

    class TestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.future = TestFuture()

        @gen_test
        async def test_future_add_done_callback_done(self):
            self.future.set_result("done")
            future_add

# Generated at 2022-06-24 08:27:31.566762
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor.submit(lambda a: 1, 1)
    dummy_executor.shutdown()