

# Generated at 2022-06-24 08:17:44.011403
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: no cover
    import time

    # In Python3, we need to be explicit about the return type of
    # add_done_callback (otherwise mypy will complain).
    from concurrent.futures import Future

    class FakeFuture(Future):
        def add_done_callback(
            self, callback: Callable[[Future], None]
        ) -> None:  # type: ignore
            super(FakeFuture, self).add_done_callback(callback)

    class FakePool(object):
        def submit(
            self, func: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "Future[_T]":
            future = FakeFuture()
            future.set_result(func(*args, **kwargs))
            return future


# Generated at 2022-06-24 08:17:48.685287
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    loop = asyncio.get_event_loop()
    executor = DummyExecutor()

    def add(x: int, y: int) -> int:
        return x + y

    future = executor.submit(add, 1, 2)  # type: Future
    res = loop.run_until_complete(future)
    assert res == 3

# Generated at 2022-06-24 08:17:49.897618
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    pass


# Generated at 2022-06-24 08:17:55.653670
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    exc_info = None
    try:
        raise Exception("Error")
    except Exception:
        exc_info = sys.exc_info()
    future = Future()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None
    future = Future()
    future_set_exc_info(future, None)
    assert future.exception() is None

# Generated at 2022-06-24 08:17:56.923279
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor is not None

# Generated at 2022-06-24 08:18:04.738259
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert not is_future(Future())
    assert is_future(dummy_executor.submit(lambda: None))
    f = Future()
    f.set_result(None)
    assert is_future(f)

    future_add_done_callback(f, lambda f: None)
    assert future_set_exc_info(f, (None, None, None)) is None

# Generated at 2022-06-24 08:18:09.531892
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError(TypeError("test_message"))
    except ReturnValueIgnoredError as e:
        assert e.__class__ is ReturnValueIgnoredError
        assert isinstance(e, Exception)
        assert e.args == (TypeError("test_message"),)
        assert repr(e) == "<ReturnValueIgnoredError: test_message>"

# Generated at 2022-06-24 08:18:10.825013
# Unit test for function is_future
def test_is_future():
    assert is_future(object()) == False
    assert is_future(Future()) == True

# Generated at 2022-06-24 08:18:14.014408
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    e = RuntimeError("test_error")
    future_set_exception_unless_cancelled(future, e)
    assert future.exception()
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, e)
    assert future.cancelled()

# Generated at 2022-06-24 08:18:21.085226
# Unit test for function chain_future
def test_chain_future():
    c = Future()
    d = Future()

    def callback(future):
        future_set_result_unless_cancelled(d, "done")

    chain_future(c, d)
    assert not d.done()
    future_add_done_callback(c, callback)
    assert not d.done()
    future_set_result_unless_cancelled(c, 'test test')
    assert d.result() == 'done'



# Generated at 2022-06-24 08:18:23.238090
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with dummy_executor.submit(
        lambda: 1 + 1
    ) as (f):
        f.result()

# Generated at 2022-06-24 08:18:27.031211
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    future_set_exception_unless_cancelled(f, Exception("test"))
    assert f.exception() is not None
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))
    assert f.exception() is None

# Generated at 2022-06-24 08:18:34.414883
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.testing.mock.Mock()
            self.executor = DummyExecutor()
            self.future = Future()

        @run_on_executor
        def background_task(self, a, b, callback=None):
            # type: (int, int, Optional[Callable]) -> int
            """Typing annotations are not propagated to docstrings"""
            self.io_loop.add_future.assert_called_with(
                self.background_task.future, self.callback
            )
            return a + b

        def callback(self, future):
            self.callback_called = True

# Generated at 2022-06-24 08:18:39.064738
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-24 08:18:45.037996
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test

    class TestClass:
        @run_on_executor
        def do_work(self, a: int, b: int) -> int:
            return a + b

    @gen_test
    async def test_chain_future():
        test_class = TestClass()
        future = test_class.do_work(1, 2)
        result = await future
        assert result == 3

# Generated at 2022-06-24 08:18:47.340631
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    """
    >>> # test for DummyExecutor's constructor
    >>> DummyExecutor
    <class 'tornado.concurrent.DummyExecutor'>
"""


# Generated at 2022-06-24 08:18:48.235338
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()
    assert True

# Generated at 2022-06-24 08:18:49.070581
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:19:00.673504
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def return_future(self, arg):
            # type: (Any) -> Future
            return Future()

        @run_on_executor
        def raise_exc(self):
            raise Exception("foo")

        @run_on_executor
        def return_arg(self, arg):
            return arg

        @run_on_executor
        def return_kwarg(self, **kwargs):
            return kwargs

        @run_on_executor
        def return_args_kwargs(self, *args, **kwargs):
            return args, kwargs

    f = Foo()
    future = f.return_future("arg")
    assert is_future(future)
    future = f.return_

# Generated at 2022-06-24 08:19:05.613262
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.done()
    assert f.result() == 42

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()



# Generated at 2022-06-24 08:19:17.170170
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    async_future = Future()
    conc_future = futures.Future()
    future_set_result_unless_cancelled(async_future, "foo")
    future_set_result_unless_cancelled(conc_future, "foo")
    assert async_future.result() == "foo"
    assert conc_future.result() == "foo"

    async_future = Future()
    async_future.cancel()
    conc_future = futures.Future()
    conc_future.cancel()
    future_set_result_unless_cancelled(async_future, "foo")
    future_set_result_unless_cancelled(conc_future, "foo")
    assert async_future.cancelled() == True and async_future.result() == None
    assert conc_future.cancelled

# Generated at 2022-06-24 08:19:23.510008
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError("error message"))


if hasattr(asyncio, "wrap_future"):
    def wrap_future(future: "Union[futures.Future[_T], Future[_T]]", *args: Any) -> "Future[_T]":  # noqa: B950
        return asyncio.wrap_future(future, *args)
else:
    # asyncio compatibility as of 3.6 (python 3.7 has wrap_future)
    def wrap_future(future: "Union[futures.Future[_T], Future[_T]]", loop: asyncio.AbstractEventLoop = None) -> "Future[_T]":  # noqa: B950
        if loop is None:
            loop = asyncio.get

# Generated at 2022-06-24 08:19:24.253089
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    DummyExecutor()

# Generated at 2022-06-24 08:19:32.311784
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    result = {}

    def callback(f):
        result["called"] = True
        assert f is future

    future_add_done_callback(future, callback)
    assert result == {}
    future.set_result(None)
    assert result["called"]

    # repeat the test with a future that is already done
    future = Future()
    future.set_result(None)
    result = {}
    future_add_done_callback(future, callback)
    assert result["called"]



# Generated at 2022-06-24 08:19:39.814747
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-24 08:19:44.551084
# Unit test for function chain_future
def test_chain_future():
    def f():
        return 3
    io_loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_result, f())
    assert f2.result() == 3
    f3 = Future()
    io_loop.add_callback(f3.set_result, f())
    chain_future(f3, f1)
    assert f1.result() == 3

# Generated at 2022-06-24 08:19:49.632434
# Unit test for function chain_future
def test_chain_future():
    # Casting these to Any because pylint does not like type Any
    loop = asyncio.new_event_loop()  # type: Any
    io_loop = IOLoop.current()  # type: Any

# Generated at 2022-06-24 08:19:51.387314
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def submit_func(x: int) -> int:
        return x + 1

    x = dummy_executor.submit(submit_func, 1)
    assert isinstance(x, futures.Future)
    assert x.done()
    assert x.result() == 2



# Generated at 2022-06-24 08:19:51.953245
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass



# Generated at 2022-06-24 08:19:53.870798
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a,b):
        return a*b
    obj = DummyExecutor()
    future = obj.submit(func, 2, 7)
    print(future.result())

# Generated at 2022-06-24 08:19:55.147902
# Unit test for function is_future
def test_is_future():  # type: ignore
    f = Future()
    assert is_future(f)
    assert not is_future(object())

# Generated at 2022-06-24 08:19:59.363596
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise Exception()
    except Exception:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception()


# Generated at 2022-06-24 08:20:09.216103
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # Create an executor
    executor = DummyExecutor()
    # Function to be executed
    def add(a, b):
        return a + b
    # Submit the above function to the executor with arguments 1, 2
    # and return the future
    future = executor.submit(add, 1, 2)
    assert future.result() == 3
    def mul(a, b):
        return a * b
    # Submit the above function to the executor with arguments 4, 5
    # and return the future
    future1 = executor.submit(mul, 4, 5)
    assert future1.result() == 20

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:20:12.591493
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, "foo")
    assert f.cancelled()
    assert not f.done()
    f = Future()
    future_set_result_unless_cancelled(f, "foo")
    assert not f.cancelled()
    assert f.done()



# Generated at 2022-06-24 08:20:16.905702
# Unit test for function is_future
def test_is_future():
    def _is_future(x: Any) -> bool:
        return isinstance(x, FUTURES)
    assert _is_future(Future())
    assert _is_future(futures.Future())
    assert not _is_future("abc")

# Generated at 2022-06-24 08:20:19.498666
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)



# Generated at 2022-06-24 08:20:28.432988
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.concurrent import Future

    # By including a reference to this function in an exception we
    # can tell whether the exception was raised or is being re-used.
    def raiser(exc):
        raise exc

    def inner():
        f = Future()
        try:
            raiser(ValueError())
        except ValueError as e:
            # Verify that the exception has the expected local state.
            expected_tb = sys.exc_info()[2]
            assert raiser in e.__traceback__.tb_frame.f_code.co_names
            # Verify that the exception has the expected re-use state.
            # (This is just a sanity check, since the real issue
            # is that the exception has the wrong traceback.)
            assert raiser not in e.__traceback__.tb_next.t

# Generated at 2022-06-24 08:20:36.059183
# Unit test for function chain_future
def test_chain_future():
    first_result = None
    second_result = None
    exception = None

    def handle_first(future):
        nonlocal first_result
        nonlocal exception
        if future.exception() is not None:
            exception = future.exception()
            return
        first_result = future.result()

    def handle_second(future):
        nonlocal second_result
        nonlocal exception
        if future.exception() is not None:
            exception = future.exception()
            return
        second_result = future.result()

    first = Future()
    second = Future()
    chain_future(first, second)
    first.add_done_callback(handle_first)
    second.add_done_callback(handle_second)
    first.set_result(42)
    assert first_result == 42

# Generated at 2022-06-24 08:20:39.738662
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    assert future.done()
    future = Future()
    future.cancel()
    assert not future.done()
    future_set_result_unless_cancelled(future, 1)
    assert not future.done()


# Generated at 2022-06-24 08:20:47.871524
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import functools

    def raise_exception(exc):  # type: ignore
        raise exc

    future = Future()
    error = ValueError("error message")
    future_set_exc_info(future, (type(error), error, None))
    assert future.exception() == error
    future = Future()
    future_set_exc_info(future, (type(error), error, None))
    future_add_done_callback(future, functools.partial(raise_exception, error))

# Generated at 2022-06-24 08:20:57.603637
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado import gen
    from tornado.ioloop import IOLoop

    @gen.coroutine
    def test_chain_two_futures():
        source = Future()
        dest = Future()
        chain_future(source, dest)
        source.set_result(42)
        self.assertEqual(42, (yield dest))

    @gen.coroutine
    def test_chain_future_and_concurrent_future():
        source = Future()
        dest = concurrent.futures.Future()
        chain_future(source, dest)
        source.set_result(42)
        self.assertEqual(42, (yield dest))

    @gen.coroutine
    def test_chain_concurrent_future_and_future():
        source = concurrent.futures.Future

# Generated at 2022-06-24 08:21:07.553488
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock

    f = Future()
    exc = Exception("foo")

    future_set_exc_info(f, (None, exc, None))
    f.exception()  # check that set_exc_info worked

    with mock.patch.object(app_log, "error") as mock_error:
        future_set_exception_unless_cancelled(f, Exception("bar"))
        assert not mock_error.called, "future_set_exception_unless_cancelled shouldn't raise"

    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, exc)
    with mock.patch.object(app_log, "error") as mock_error:
        f.exception()

# Generated at 2022-06-24 08:21:17.791100
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    # Future.result() raises if called on incomplete Future, so
    # we need to rescue that exception.
    def result(f):
        # type: (Future) -> Any
        try:
            return f.result()
        except Exception as e:
            return e

    f1 = Future()    # type: Future[int]
    f2 = Future()    # type: Future[int]
    res = []         # type: List[Any]

    def callback(f):
        # type: (Future[int]) -> None
        res.append(result(f))
    future_add_done_callback(f1, callback)
    future_add_done_callback(f2, callback)
    f1.set_result(2)
    f2.set_result(3)

    assert res

# Generated at 2022-06-24 08:21:22.862645
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

    try:
        future_set_exception_unless_cancelled(f, ValueError())
    except ValueError:
        pass

# Generated at 2022-06-24 08:21:30.430469
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.testing
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado import gen


    class TestFutureAddDoneCallback(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestFutureAddDoneCallback, self).setUp()
            AsyncIOMainLoop().install()

        def test_future_add_done_callback_asyncio_future(self):
            @gen.coroutine
            def test():
                f = Future()
                f.set_result(None)
                cb_done = False

                def cb(future):
                    self.assertTrue(future.done())
                    nonlocal cb_done
                    cb_done = True

                future_add_done_callback(f, cb)
                self.assertTrue(cb_done)

# Generated at 2022-06-24 08:21:32.189649
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    assert executor is not None



# Generated at 2022-06-24 08:21:33.926517
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: no cover
    try:
        raise ReturnValueIgnoredError
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-24 08:21:38.136621
# Unit test for function is_future
def test_is_future():
    assert not is_future(1)
    assert is_future(Future())
    assert is_future(futures.Future())

test_is_future()

# Generated at 2022-06-24 08:21:40.556350
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda : 1 + 2)
    assert future.result() == 3

# Generated at 2022-06-24 08:21:51.210256
# Unit test for function chain_future
def test_chain_future():
    import unittest

    def f1(future, arg):
        future.set_result(arg)

    def f2(future, arg):
        future.set_exception(Exception(arg))

    def f3(future, arg):
        future_set_exc_info(future, arg)

    def f4(future, arg):
        future.set_result(arg)
        future.set_result(arg)

    def f5(future, arg):
        future.set_exception(Exception(arg))
        future.set_exception(Exception(arg))

    def f6(future, arg):
        future_set_exc_info(future, arg)
        future_set_exc_info(future, arg)


# Generated at 2022-06-24 08:22:02.059398
# Unit test for function chain_future
def test_chain_future():
    def mock_futures() -> Tuple[Future, Future]:
        mock_a = Future()  # type: Future
        mock_b = Future()  # type: Future
        return mock_a, mock_b

    def test_exception() -> None:
        mock_a, mock_b = mock_futures()
        chain_future(mock_a, mock_b)
        mock_a.set_exception(RuntimeError("Test"))
        assert not mock_b.cancelled()
        assert mock_b.exception() is not None
        # The exception passed to set_exception is not the same instance
        # as the one returned by exception() or the one raised if we call
        # result()

# Generated at 2022-06-24 08:22:04.333197
# Unit test for function is_future
def test_is_future():
    assert is_future(asyncio.Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:22:10.841575
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "value")
    assert future.done()
    assert future.result() == "value"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "value")
    assert future.done()
    with pytest.raises(asyncio.CancelledError):
        future.result()


# Generated at 2022-06-24 08:22:13.474693
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("foo")
    except ReturnValueIgnoredError as e:
        assert str(e) == "foo"



# Generated at 2022-06-24 08:22:14.222100
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("foo")  # no exception

# Generated at 2022-06-24 08:22:16.954030
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = futures.Future()
    future_add_done_callback(f, lambda _: None)
    f.set_result(42)

# Generated at 2022-06-24 08:22:28.045690
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from unittest import mock
    future = Future()

    e = Exception()
    future_set_exception_unless_cancelled(future, e)
    assert future.exception() == e

    future_set_exception_unless_cancelled(future, e)
    assert future.exception() == e

    future.cancel()
    with mock.patch("tornado.concurrent._log.error") as mock_error:
        future_set_exception_unless_cancelled(future, e)
        mock_error.assert_called_once_with("Exception after Future was cancelled", exc_info=e)
    assert future.exception() == e
    assert future._log_traceback
    assert future._log_exception == e

# Generated at 2022-06-24 08:22:31.949665
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class ClassThatCausesReturnValueIgnoredError(object):
        @return_future  # type: ignore
        def method_that_causes_ReturnValueIgnoredError(self):
            return None

    with ClassThatCausesReturnValueIgnoredError() as x:
        x.method_that_causes_ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:36.327042
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

    future = Future()
    future_set_result_unless_cancelled(future, "result")
    future.cancel()
    assert not future.done()

# Generated at 2022-06-24 08:22:46.382720
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    result = []

    def cb(f):
        result.append(f.result())

    future_add_done_callback(f, cb)
    f.set_result(3)
    assert result == [3]
    f = Future()
    future_add_done_callback(f, cb)
    assert result == [3]
    f.set_result(4)
    assert result == [3, 4]
    try:
        1 / 0
    except Exception:
        f = Future()
        future_add_done_callback(f, cb)
        f.set_exception(sys.exc_info())
        raise AssertionError("should have raised an exception") from None



# Generated at 2022-06-24 08:22:53.345064
# Unit test for function future_add_done_callback
def test_future_add_done_callback():  # type: ignore
    def mk_done_future():  # type: ignore
        future = Future()
        future.set_result(None)
        return future

    def f():  # type: ignore
        raise Exception("function f should not be called")

    future = mk_done_future()
    future_add_done_callback(future, f)  # should not raise an exception

    future = Future()
    future_add_done_callback(future, f)  # should not raise an exception



# Generated at 2022-06-24 08:22:55.636689
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:23:07.994259
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.executor = DummyExecutor()

        def test_returns_future(self):
            @run_on_executor(executor="executor")
            def fn(self):
                return 42

            result = fn(self)
            self.assertIsInstance(result, Future)
            self.assertEqual(result.result(), 42)

        def test_exception_propagates(self):
            @run_on_executor(executor="executor")
            def fn(self):
                raise Exception("foo")

            result = fn(self)
            self.assertRaises(Exception, result.result)


# Generated at 2022-06-24 08:23:11.080436
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    assert dummy_executor.submit(functools.wraps(1))
    assert dummy_executor.submit(functools.wraps(1))



# Generated at 2022-06-24 08:23:21.570308
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    f = Future()
    result = []

    def cb1(f):
        # type: (Future) -> None
        result.append(f.result())

    def cb2(f):
        # type: (Future) -> None
        result.append(f.result())

    future_add_done_callback(f, cb1)
    f.set_result(42)
    future_add_done_callback(f, cb2)
    assert result == [42, 42]

    del result[:]
    f = Future()
    future_add_done_callback(f, cb2)
    future_add_done_callback(f, cb1)
    f.set_result(42)
    assert result == [42, 42]



# Generated at 2022-06-24 08:23:29.819373
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    
    def add(a: int, b: int) -> int:
        return a + b

    executor = DummyExecutor()
    future = executor.submit(add, 2, 3)
    assert future.result() == 5
    future = executor.submit(add, 2, 4)
    assert future.result() == 6
    future = executor.submit(add, 2, 5)
    assert future.result() == 7

    # Test exception
    def exception(a: int, b: int) -> int:
        raise ValueError

    future = executor.submit(exception, 2, 5)
    assert future.exception() != None

    

# Generated at 2022-06-24 08:23:35.023019
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    assert(dummy_executor.submit(lambda: 3) == 3)
    assert(dummy_executor.submit(lambda: 'a') == 'a')
    assert(dummy_executor.submit(lambda: {}) == {})
    assert(dummy_executor.submit(lambda: []) == [])
    assert(dummy_executor.submit(lambda: False) == False)
    assert(dummy_executor.submit(lambda: ()) == ())
    assert(dummy_executor.submit(lambda: None) is None)

# Generated at 2022-06-24 08:23:37.340121
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())
    assert not is_future(object())



# Generated at 2022-06-24 08:23:41.011186
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception()



# Generated at 2022-06-24 08:23:47.995941
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 'value')
    assert future.result() == 'value'

    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 'value')
    with pytest.raises(asyncio.CancelledError):
        future.result()

# Generated at 2022-06-24 08:23:52.611036
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(5)
    assert not is_future({})
    assert not is_future([])

# Generated at 2022-06-24 08:24:00.546365
# Unit test for function chain_future
def test_chain_future():
    f2 = Future()

    def assert_done_callback(future: Future[int]) -> None:
        assert future.result() == 1

    @run_on_executor(executor='_thread_pool')
    def update_future(future: Future[int]) -> None:
        future_set_result_unless_cancelled(future, 1)
    chain_future(update_future(Future()), f2)
    f2.add_done_callback(assert_done_callback)


# Generated at 2022-06-24 08:24:08.091159
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import tornado.testing
    import contextlib
    from tornado.log import gen_log

    io_loop = tornado.testing.AsyncTestCase.get_new_ioloop()
    future = future_class(io_loop=io_loop)
    future_set_exc_info(future, sys.exc_info())
    with contextlib.closing(io_loop):
        io_loop.run_sync(lambda: future)
    assert "Exception ignored in Future" in gen_log.text()



# Generated at 2022-06-24 08:24:09.667350
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    err = ReturnValueIgnoredError("test")
    assert str(err) == "test"

# Generated at 2022-06-24 08:24:12.721277
# Unit test for function is_future
def test_is_future(): assert is_future(Future()) == True



# Generated at 2022-06-24 08:24:13.960414
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())

# Generated at 2022-06-24 08:24:18.256712
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    # fut = futures.Future()

    def callback(fut):
        assert isinstance(fut, Future)

    future_add_done_callback(f, callback)

    # callback should not have been called yet
    def _test_exception():
        raise ValueError('---')

    _test_exception()

    # mark f as done, causing callback to be run.
    # if our callback wasn't called (if f wasn't done),
    # then our exception would be raised again.
    f.set_result(None)

    # this should not raise an exception
    f.result()



# Generated at 2022-06-24 08:24:20.016399
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    obj = ReturnValueIgnoredError('test')
    assert str(obj) == "test"

# Generated at 2022-06-24 08:24:23.041578
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-24 08:24:26.834912
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    e = DummyExecutor()
    f = e.submit(lambda x: x, 1)
    assert f.result() == 1

# Generated at 2022-06-24 08:24:29.350481
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    return_value = ReturnValueIgnoredError('message')
    assert return_value.args == ('message',)

# Generated at 2022-06-24 08:24:36.438248
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future

    future = dummy_executor.submit(lambda: "hello")
    assert future.exception() == None
    assert future.result() == "hello"
    # Unit test for method submit of class DummyExecutor
    future = dummy_executor.submit(lambda: 1 / 0)
    assert not future.exception() == None
    assert not future.result() == None
    # Unit test for method submit of class DummyExecutor
    future = dummy_executor.submit(Future)
    assert not future.exception() == None
    assert not future.result() == None


# Generated at 2022-06-24 08:24:38.865935
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def callback(future):
        pass

    future_add_done_callback(Future(), callback)
    future_add_done_callback(futures.Future(), callback)

# Generated at 2022-06-24 08:24:49.637190
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado.platform.asyncio import AsyncIOMainLoop

    # The error should be set
    future = Future()
    try:
        raise ZeroDivisionError()
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    test_future = future
    future = None
    AsyncIOMainLoop().install()
    try:
        with test_future:  # type: ignore
            pass
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    assert exc_info[1] == test_future.exception()

    # The exception should always be set
    future = Future()
    future_set_exc_info(future, None)
    test_future = future
    future = None


# Generated at 2022-06-24 08:24:54.801218
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    import logging
    if hasattr(logging, "NullHandler"):
        logging.getLogger("test_future_set_result_unless_cancelled").addHandler(logging.NullHandler())
    else:
        logging.getLogger("test_future_set_result_unless_cancelled").addHandler(logging.StreamHandler())

    class TestFutureSetResultUnlessCancelled(unittest.TestCase):
        def test_set_result_unless_cancelled(self):
            from concurrent import futures
            from tornado.concurrent import Future
            from tornado.platform.asyncio import AnyThreadEventLoopPolicy

            executed_by_native_python_future = False
            executed_by_asyncio_future = False


# Generated at 2022-06-24 08:24:57.858640
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    a = executor.submit(lambda x:x, "test_DummyExecutor")
    print(a.result())



# Generated at 2022-06-24 08:25:06.038075
# Unit test for function chain_future
def test_chain_future():
    from concurrent.futures import Future
    from tornado import gen
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(AsyncTestCase):
        def setUp(self):
            super(Foo, self).setUp()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            super(Foo, self).tearDown()

        @gen_test
        def test_chain(self):
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            f1.set_result(42)
            chain_future(f1, f2)

# Generated at 2022-06-24 08:25:17.741071
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future
    from concurrent.futures import CancelledError

    f = dummy_executor.submit(lambda: 123)
    assert isinstance(f, Future)
    assert f.result() == 123
    assert f.cancelled() == False

    g = dummy_executor.submit(lambda: 123/0)
    assert isinstance(g, Future)
    try:
        g.result()
        assert False
    except ZeroDivisionError:
        pass

    h = dummy_executor.submit(lambda: 123)
    h.cancel()
    assert h.cancelled() == True
    assert h.done() == True
    try:
        h.result()
        assert False
    except CancelledError:
        pass


if __name__ == "__main__":
    import doct

# Generated at 2022-06-24 08:25:20.276435
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func():
        pass
    future = dummy_executor.submit(func)
    assert future.done()


# Generated at 2022-06-24 08:25:25.924592
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None


# Generated at 2022-06-24 08:25:31.097617
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError("\xcf\x84\xcf\x81\xce\xbf\xcf\x82")
    except ReturnValueIgnoredError as e:
        assert str(e) == "\xcf\x84\xcf\x81\xce\xbf\xcf\x82"



# Generated at 2022-06-24 08:25:34.722935
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:25:38.725811
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:25:48.566576
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    IOLoop.configure("tornado.platform.asyncio.AsyncIOMainLoop")
    loop = IOLoop.current()

    executor = unittest.mock.NonCallableMock()

    class Foo:
        def __init__(self):
            self.executor = executor

        @run_on_executor()
        def foo(self):
            return 123

    @run_on_executor()
    def bar(x):
        return 456 * x

    @run_on_executor(executor="foo")
    def baz(x):
        return 789 * x

    async def test_await(fn, x):
        result = await fn(x)

# Generated at 2022-06-24 08:25:56.868041
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    import tornado.ioloop
    from tornado.testing import AsyncTestCase

    class MyTest(AsyncTestCase):
        def test_run_on_executor(self):
            @run_on_executor
            def fn(arg):
                return arg + 1

            def check_result(future):
                self.assertEqual(future.result(), 6)
                self.stop()

            future = fn(5)
            future.add_done_callback(check_result)
            self.wait()

    unittest.main()
test_DummyExecutor_submit()

# Generated at 2022-06-24 08:26:04.305461
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_function(*args, **kwargs):
        return [args, kwargs]
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(test_function, 1, 2, 3, kw1="hello", kw2="world")
    assert future.result() == [[1, 2, 3], {"kw1": "hello", "kw2": "world"}]

# Generated at 2022-06-24 08:26:10.084217
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    a = dummy_executor.submit(lambda x: x + 1, 1)
    assert a.result() == 2
    b = dummy_executor.submit(lambda x, y: x + y, 1, 1)
    assert b.result() == 2
    c = dummy_executor.submit(lambda x, y, z: x + y + z, 1, 1, 1)
    assert c.result() == 3
    d = dummy_executor.submit(lambda x, y, z=3: x + y + z, 1, 1)
    assert d.result() == 5


# Generated at 2022-06-24 08:26:13.804100
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    try:
        DummyExecutor().submit(lambda: None)
    except Exception as e:
        raise AssertionError("Exception thrown: %s", str(e))

# Generated at 2022-06-24 08:26:15.343839
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    t = DummyExecutor()
    t.submit(lambda : 2 * 2)

# Generated at 2022-06-24 08:26:22.344488
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor_ = DummyExecutor()
    assert dummy_executor_.submit(lambda x: x, 1) is not None
    assert dummy_executor_.submit(lambda x: x) is not None
    assert dummy_executor_.submit(lambda x: x, 1, 2) is not None
    assert dummy_executor_.submit(lambda x: x, 1, *[1,2,3,4]) is not None


# Generated at 2022-06-24 08:26:24.813101
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(i:int) -> int:
        return i

    testFuture = DummyExecutor().submit(foo, 1)
    assert(testFuture.result() == 1)

# Generated at 2022-06-24 08:26:31.927580
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = asyncio.Future()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is RuntimeError()
    f = asyncio.Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError())
    assert f.exception() is None

# Generated at 2022-06-24 08:26:36.403934
# Unit test for function run_on_executor
def test_run_on_executor():
    import asyncio

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def doubles(self, x):
            return x * 2

    @run_on_executor(executor="_thread_pool")
    def _double(x):
        return x * 2

    foo = Foo()
    io_loop = asyncio.get_event_loop()
    async def run_double():
        assert io_loop.is_running()
        result = await foo.doubles(21)
        assert result == 42

    io_loop.run_until_complete(run_double())
    # Python 3.5 and older do not support run_coroutine_threadsafe
    if hasattr(asyncio, "run_coroutine_threadsafe"):
        result = asyncio.run_

# Generated at 2022-06-24 08:26:37.184287
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass

# Generated at 2022-06-24 08:26:38.285005
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()  # type: ignore

# Generated at 2022-06-24 08:26:48.115934
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.platform.asyncio

    old_fork = tornado.platform.asyncio.AsyncIOMainLoop.configure


# Generated at 2022-06-24 08:26:50.236073
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert not is_future(None)



# Generated at 2022-06-24 08:26:54.328699
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        @gen_test
        def test_future_add_done_callback(self):
            f = Future()
            IOLoop.current().add_future(f, lambda x: self.stop())
            f.set_result(None)
            self.wait()

    MyTestCase().test_future_add_done_callback()



# Generated at 2022-06-24 08:27:04.430174
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    L = []
    future_add_done_callback(future, lambda f: L.append('done'))

    assert L == []
    future.set_result(42)
    assert L == ['done']

    # Now check that it doesn't run if the future is already done.
    L = []
    future = Future()
    future.set_result(42)
    future_add_done_callback(future, lambda f: L.append('done'))
    assert L == ['done']

    # And again with a concurrent.futures.Future.
    L = []
    future = futures.Future()  # type: ignore
    future.set_result(42)
    future_add_done_callback(future, lambda f: L.append('done'))
    assert L == ['done']

# Generated at 2022-06-24 08:27:08.288939
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummyExecutor = DummyExecutor()
    future = dummyExecutor.submit(pow, 2, 3)
    assert future.result() == 8
    dummyExecutor.shutdown()


# Generated at 2022-06-24 08:27:12.456253
# Unit test for function is_future
def test_is_future():
    import tornado.ioloop

    def func():
        pass

    with tornado.ioloop.IOLoop.current() as loop:
        f1 = loop.run_in_executor(None, func)
        assert is_future(f1)
        assert not is_future(func)

        @run_on_executor()
        def f2(self):
            pass

        assert is_future(f2(None))

# Generated at 2022-06-24 08:27:14.477169
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # pragma: nocover
    try:
        raise ReturnValueIgnoredError("some message")
    except ReturnValueIgnoredError as e:
        assert str(e) == "some message"  # type: ignore
    else:
        raise AssertionError("didn't see the expected exception")

# Generated at 2022-06-24 08:27:23.374506
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    class Foo(object):
        def __init__(self):
            # type: () -> None
            self.executor = dummy_executor
            self._thread_pool = dummy_executor

        @run_on_executor
        def foo(self):
            # type: () -> int
            return 42

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            # type: () -> int
            return 24

    f = Foo()
    foo_future = f.foo()
    bar_future = f.bar()
    assert foo_future.result() == 42
    assert bar_future.result() == 24

# Generated at 2022-06-24 08:27:33.305525
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import concurrent.futures
    import functools
    import time

    def run(executor, future):
        """Run a future and return its result, waiting at most 1 second."""
        with concurrent.futures.ThreadPoolExecutor() as e:
            done = e.submit(functools.partial(future.result, 1))
            return done.result(1)

    def test(future):
        """Perform a simple test of a Future."""
        # Done future with result
        future.set_result('foo')
        assert future.result() == 'foo'
        assert run(dummy_executor, future) == 'foo'

        # Done future with exception
        exec('raise Exception("bar")')
        future.set_exc_info(sys.exc_info())