

# Generated at 2022-06-24 08:17:32.813071
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 0)
    assert f.done()
    assert f.cancelled()
    f = Future()
    f.set_result(1)
    assert f.result() == 1

# Generated at 2022-06-24 08:17:34.521245
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    future = dummy_executor.submit(lambda: True)
    assert future.result()
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:17:39.848959
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = futures.Future()
    cb_args = []
    cb_kwargs = []

    def cb(*args, **kwargs):
        cb_args.extend(args)
        cb_kwargs.update(kwargs)

    future_add_done_callback(future, cb)
    assert not cb_args
    assert not cb_kwargs
    future_add_done_callback(future, cb)
    assert not cb_args
    assert not cb_kwargs

    future.set_result(1)
    assert cb_args == [future]
    assert not cb_kwargs
    future_add_done_callback(future, cb)
    assert cb_args == [future, future]
    assert not cb_kwargs

    # Verify that it works

# Generated at 2022-06-24 08:17:43.463302
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """
    test_future_set_exception_unless_cancelled
    """
    import unittest

    class TestFuture(unittest.TestCase):
        def test_future_set_exception_unless_cancelled_is_noop_when_cancelled(self):
            future = Future()
            future.cancel()
            future_set_exception_unless_cancelled(future, Exception())
            self.assertFalse(future.done())

    unittest.main()

# Generated at 2022-06-24 08:17:50.507181
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest.mock

    executor = futures.ThreadPoolExecutor(1)
    test = unittest.mock.Mock()

    class Test(object):
        def __init__(self):
            # type: () -> None
            self.executor = executor

        @run_on_executor
        def f(self, a, b, c=5, d=6, *args, **kwargs):
            # type: (str, int, str, int, object, object) -> str
            test(self, a, b, c, d, args, kwargs)
            return "retval"

        # uses different executor and argument names

# Generated at 2022-06-24 08:17:51.510529
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:17:53.032913
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)

# Generated at 2022-06-24 08:17:57.281218
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    future_set_result_unless_cancelled(future, 42)
    assert not future.done()
    assert future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.cancelled()
    assert not future.done()

# Generated at 2022-06-24 08:18:10.699202
# Unit test for function run_on_executor
def test_run_on_executor():
    import concurrent.futures
    import functools
    import tornado
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.testing
    import asyncio

    class SomeClass(object):
        def __init__(self) -> None:
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @tornado.concurrent.run_on_executor
        def sleep(self, t: float) -> float:
            time.sleep(t)
            return t

    class TestAsyncIO(tornado.testing.AsyncTestCase):
        def test_run_on_executor(self) -> None:
            asyncio.set_event_loop(None)
            tornado.platform.asyncio.AsyncIOMainLoop().install()

            obj = SomeClass()


# Generated at 2022-06-24 08:18:14.363996
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from typing import Any, Callable, TypeVar

    _T = TypeVar("_T")

    def test_fn(x: int) -> int:
        return x + 1

    a = DummyExecutor()
    b = a.submit(test_fn, 1)
    if type(b) == futures.Future:
        assert b.done()
        assert b.result() == 2
    else:
        assert False



# Generated at 2022-06-24 08:18:25.014234
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def test_chaining(self):
            @gen_test
            async def test_chain_future():
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(42, await f2)

                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_exception(ZeroDivisionError())
                with self.assertRaises(ZeroDivisionError):
                    await f2

    test_case = TestCase()
    test_case.run_until_complete(test_case.test_chaining())



# Generated at 2022-06-24 08:18:33.558370
# Unit test for function chain_future
def test_chain_future():
    import time

    # The test is rather racy, but it does a reasonable job of testing the
    # basic functionality.
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.done()
    assert f1.done()
    assert f2.result() == 42
    assert f1.result() == 42

    f1 = Future()
    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f2, f3)
    f1.set_result(42)
    time.sleep(0.1)
    assert f1.done()
    assert f2.done()
    assert f3.done()
    assert f3.result()

# Generated at 2022-06-24 08:18:35.080625
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'test')
    future.cancel()
    future_set_result_unless_cancelled(future, 'test')

# Generated at 2022-06-24 08:18:39.579137
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(1)
    dummy_executor.submit(1,2)
    dummy_executor.submit(1,2,3)
    dummy_executor.submit(1,2,3,4)
    dummy_executor.submit(1,2,3,4,5)


# Generated at 2022-06-24 08:18:41.518623
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("foo"))

# Generated at 2022-06-24 08:18:42.120276
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:18:51.067788
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future_set_result_unless_cancelled(future, 24)
    assert future.result() == 42
    future_set_result_unless_cancelled(future, None)
    assert future.result() == 42

    future = Future()
    future_set_result_unless_cancelled(future, future)
    assert future.result() == future

    # Cancel the future and set its result. This should raise an exception
    future = Future()
    future.cancel()
    try:
        future_set_result_unless_cancelled(future, 42)
    except asyncio.InvalidStateError:
        pass

# Generated at 2022-06-24 08:18:53.612698
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    ex = DummyExecutor()
    future = ex.submit(sum, range(1,10))
    print(future)


# Generated at 2022-06-24 08:18:56.373168
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    d = dummy_executor.submit(func)
    assert d.result() == 10


# Generated at 2022-06-24 08:19:07.004482
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from concurrent import futures
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    AsyncIOMainLoop().install()

    class TestClass(AsyncTestCase):
        def test_future_set_result_unless_cancelled(self):
            # create a dummy executor and a future
            executor = futures.ThreadPoolExecutor(max_workers=2)
            future = Future()

            # execute a task in the executor and set the future
            def set_future(future, executor):
                # set the future
                future_set_result_unless_cancelled(future, "test")

                # shutdown the executor
                executor.shutdown()

            executor.submit(set_future, future, executor)
            self

# Generated at 2022-06-24 08:19:08.793409
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:19:11.976290
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except Exception as e:
        a = ReturnValueIgnoredError(e)
        print(a)

# Generated at 2022-06-24 08:19:20.437681
# Unit test for function run_on_executor
def test_run_on_executor():
    class A(object):
        def __init__(self, executor):
            self.executor = executor
            self.subtask_ran = False
            self.subtask_value = False

        @run_on_executor
        def task(self):
            self.subtask()
            return True

        @run_on_executor
        def task_with_timeout(self):
            self.subtask()
            return True

        def subtask(self):
            self.subtask_ran = True
            return self.subtask_value

    e = futures.ThreadPoolExecutor(2)
    a = A(executor=e)

    def run(future):
        assert future.result()
        assert a.subtask_ran
        assert a.subtask_value

    a.subtask_value = True


# Generated at 2022-06-24 08:19:27.192597
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    result = []
    completed = False

    def callback(future):
        result.append(future.result())

    future = Future()
    future_add_done_callback(future, callback)
    try:
        raise TypeError(u"foo")
    except TypeError:
        future_set_exc_info(future, sys.exc_info())
    assert result[0].args == (u"foo",)
    assert result[0].__class__ == TypeError

    result = []
    future = Future()
    future_add_done_callback(future, callback)
    future.set_result(42)
    assert result[0] == 42

# Generated at 2022-06-24 08:19:33.655398
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    future_set_exc_info(future, sys.exc_info())
    assert not future.done()
    assert not future.cancelled()
    future_set_exc_info(future, None)
    assert future.done()
    assert not future.cancelled()
    assert future.exception() is None
    future_set_exc_info(future, sys.exc_info())
    exc = future.exception()
    assert exc is not None and issubclass(exc, RuntimeError)

# Generated at 2022-06-24 08:19:45.547813
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.web
    import tornado.websocket
    import concurrent.futures

    class MainHandler(tornado.web.RequestHandler):
        def initialize(self, executor: concurrent.futures.Executor) -> None:
            self.executor = executor

        async def get(self) -> None:
            a = Future()  # type: Future[int]
            b = Future()  # type: Future[int]
            chain_future(a, b)
            self.executor.submit(a.set_result, 42)
            res = await b
            print(res)

        def test_callback(self) -> None:
            a = Future()  # type: Future[int]
            future_add_done_callback(a, lambda x: print(x.result()))


# Generated at 2022-06-24 08:19:53.966316
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import time
    import tornado.ioloop
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()
    io_loop = tornado.ioloop.IOLoop.current()

    done = False

    def set_done():
        nonlocal done
        done = True

    def set_value():
        future = Future()
        future_set_result_unless_cancelled(future, "result")
        future.add_done_callback(lambda f: io_loop.add_callback(set_done))

    io_loop.add_callback(set_value)
    io_loop.run_sync(lambda: time.sleep(1))
    assert done

# Generated at 2022-06-24 08:19:57.904652
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    x = Future()
    x.set_result(None)
    future_set_exception_unless_cancelled(x, RuntimeError())

    x = Future()
    x.set_exception(RuntimeError())
    future_set_exception_unless_cancelled(x, RuntimeError())

    x = Future()
    x.cancel()
    future_set_exception_unless_cancelled(x, RuntimeError())

    x = Future()
    x.cancel()
    future_set_exception_unless_cancelled(x, RuntimeError())


# Generated at 2022-06-24 08:20:00.239455
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(object())

# Generated at 2022-06-24 08:20:05.717197
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    def finished_callback(future):
        # type: (Future[_T]) -> None
        assert future._state == "FINISHED"
    f = Future()
    future_add_done_callback(f, finished_callback)
    assert f._state == "PENDING"
    f.set_result(None)

# Generated at 2022-06-24 08:20:07.819637
# Unit test for function is_future
def test_is_future():
    assert not is_future(3)
    assert is_future(Future())
    assert is_future(futures.Future())


# Generated at 2022-06-24 08:20:15.103868
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import time
    import concurrent.futures
    import functools
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    executor = concurrent.futures.ThreadPoolExecutor(1)

    class ExampleHandler(tornado.websocket.WebSocketHandler):
        executor = executor

        @run_on_executor
        def get(self: Any, a: int, b: int) -> int:
            return a + b

        def open(self: Any) -> None:
            self.result = None

            def callback(future: "Future[int]") -> None:
                self.result = future.result()
                self.io_loop.stop()

            future = self.get(1, 2)
            future

# Generated at 2022-06-24 08:20:24.467401
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    f = Future()
    f.set_result(None)
    result = []

    def callback(future):
        # type: (Future) -> None
        result.append(future)

    future_add_done_callback(f, callback)
    future_add_done_callback(f, lambda future: result.append(future))
    assert result == [f, f]

    f = Future()
    result = []
    future_add_done_callback(f, callback)
    future_add_done_callback(f, lambda future: result.append(future))
    f.set_result(None)
    assert result == [f, f]



# Generated at 2022-06-24 08:20:33.082160
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    """Test future_set_result_unless_cancelled"""
    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, "result")

    future = Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, "result")

    future = Future()
    future.cancel()
    assert future.cancelled()

    # set_result raises an exception
    future = Future()
    future.set_result(1)
    assert future.done()
    assert future.result() == 1



# Generated at 2022-06-24 08:20:35.439636
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1

# Generated at 2022-06-24 08:20:38.001369
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # type: () -> None
    f = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None

# Generated at 2022-06-24 08:20:38.628661
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    pass

# Generated at 2022-06-24 08:20:45.121585
# Unit test for function is_future
def test_is_future():
    def function():
        pass
    assert not is_future(function)
    assert not is_future(Future())
    assert is_future(futures.Future())
    # concurrent.future.Future does not have a __future_class__
    # attribute, so the best we can do is check the module name.
    assert futures.Future.__module__.startswith("concurrent.futures")

# Generated at 2022-06-24 08:20:48.579284
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    result = executor.submit(lambda a, b: a + b, 1, 2)
    print(result.result())
    assert result.result() == 3


# Generated at 2022-06-24 08:20:49.787563
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())

# Generated at 2022-06-24 08:20:56.730604
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42
    assert not future2.cancelled()
    future1 = Future()
    future2 = Future()
    future1.set_exception(ZeroDivisionError())
    chain_future(future1, future2)
    assert future2.exception() is not None
    assert not future2.cancelled()
    future1 = Future()
    future2 = Future()
    future1.cancel()
    chain_future(future1, future2)
    assert future2.cancelled()

# Generated at 2022-06-24 08:21:07.326360
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    executor = futures.ThreadPoolExecutor(1)

    class MyFuture(Future):
        pass

    class MyObj:
        executor = executor

        def __init__(self):
            # type: () -> None
            self.foo_result = None  # type: int
            self.bar_result = None  # type: int
            self.check_result = None  # type: int
            self.baz_result = None  # type: int

        @run_on_executor
        def foo(self, arg):
            # type: (int) -> int
            # tests that instance methods can be run on the executor
            return arg + 1

        @run_on_executor
        def bar(self, arg):
            # type: (int) -> int
            raise Exception

# Generated at 2022-06-24 08:21:08.441087
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()


# Generated at 2022-06-24 08:21:20.336760
# Unit test for function run_on_executor
def test_run_on_executor():
    import inspect
    import unittest

    import concurrent.futures
    import asyncio
    import functools

    class TestException(Exception):
        pass

    class Example(object):
        def __init__(self):
            self.io_loop = IOLoop.current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking(self):
            raise TestException("it worked")

        @run_on_executor
        def blocking_with_arguments(self, a, b, c=None):
            if a != 1 or b != 2 or c != 3:
                raise Exception("unexpected arguments")
            return a, b, c

    example = Example()


# Generated at 2022-06-24 08:21:23.343407
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:21:35.323794
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def noargs(self):
            return 42

        @run_on_executor
        def args(self, a, b):
            return a + b

        @run_on_executor
        def kwargs(self, a, b=10):
            return a + b

        @run_on_executor(executor="_executor")
        def custom_attr(self):
            return 42

        # Because we don't use @gen.coroutine,
        # this method can't be called by AsyncTestCase.
        # but we can call it directly and test its future.


# Generated at 2022-06-24 08:21:36.732245
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass


# Generated at 2022-06-24 08:21:42.625251
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    class MyError(Exception):
        pass
    future_set_exception_unless_cancelled(future, MyError)
    assert future.exception() is not None
    assert isinstance(future.exception(), MyError)

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, MyError)

# Generated at 2022-06-24 08:21:46.372253
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    e = futures.Executor()
    f1 = e.submit(lambda: True)
    f2 = e.submit(lambda: False)
    f1_result = [False]
    f2_result = [False]
    future_add_done_callback(f1, lambda future: f1_result.__setitem__(0, future.result()))
    future_add_done_callback(f2, lambda future: f2_result.__setitem__(0, future.result()))
    assert f1_result[0]
    assert not f2_result[0]



# Generated at 2022-06-24 08:21:49.059904
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from concurrent.futures import Executor
    assert isinstance(dummy_executor,Executor)
    assert isinstance(dummy_executor,DummyExecutor)


# Generated at 2022-06-24 08:21:54.508052
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:22:04.326986
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    def f1_callback(f):
        assert not f2.done()
        f1.set_exception(Exception("test"))

    def f2_callback(f):
        assert f1.done()
        assert f1.exception()
        assert f2.exception()
        io_loop.stop()

    f1.add_done_callback(f1_callback)
    f2.add_done_callback(f2_callback)
    io_loop.start()



# Generated at 2022-06-24 08:22:14.828585
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import sys
    import types
    import functools
    from concurrent import futures
    from tornado.ioloop import IOLoop
    from tornado import gen
    from concurrent.futures import Future


    def get_result(future: Future) -> str:
        if future.done():
            return future.result()
        else:
            raise Exception("No result")

    class MyExecutor(futures.Executor):
        @staticmethod
        def submit(
            fn: Callable[..., _T], *args: Any, **kwargs: Any
        ) -> "futures.Future[_T]":
            future = futures.Future()  # type: futures.Future[_T]

# Generated at 2022-06-24 08:22:20.385318
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = futures.Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    future = futures.Future()
    future_set_result_unless_cancelled(future, 1)
    assert not future.cancelled()
    assert future.done()
    assert future.result() == 1


# Generated at 2022-06-24 08:22:22.575725
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())



# Generated at 2022-06-24 08:22:24.530983
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert 'ValueError' in future.exception().args[0]

# Generated at 2022-06-24 08:22:28.767064
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(
        future, Exception("test_future_set_exception_unless_cancelled"))
    assert future.exception() is None

# Generated at 2022-06-24 08:22:33.344514
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import unittest
    exec = DummyExecutor()
    class TestChain_on_executor(unittest.TestCase):
        def test_execute(self):
            def  echo(a):
                return a
            future = exec.submit(echo, "Hello world!")
            assert future.result() == "Hello world!"
    unittest.main()

if __name__ == "__main__":
    test_DummyExecutor_submit()

# Generated at 2022-06-24 08:22:37.084499
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def test_func(a, b):
        return a + b
    de = DummyExecutor()
    f = de.submit(test_func, 1, 2)
    assert f.done()
    assert f.result() == 3

# Generated at 2022-06-24 08:22:38.848431
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    my_executor=DummyExecutor()
    assert isinstance(my_executor,DummyExecutor)

# Generated at 2022-06-24 08:22:41.835421
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass
    except Exception:
        assert False


# For use in Type Hints
_F = typing.TypeVar("_F", bound="Future")
_FT = typing.TypeVar("_FT")



# Generated at 2022-06-24 08:22:47.797963
# Unit test for function chain_future
def test_chain_future():
    f = Future()

    def setter(inner_f):
        inner_f.set_result(42)

    chain_future(f, f)
    assert f.done()
    assert f.result() == 42

    f = Future()
    chain_future(f, f)
    assert not f.done()
    f.set_result(42)
    assert f.result() == 42



# Generated at 2022-06-24 08:22:52.740106
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    io_loop = IOLoop.current()

    def f():
        pass

    def finish():
        io_loop.stop()

    start = gen.convert_yielded(f())
    assert start.done()

    future_add_done_callback(start, finish)
    io_loop.start()



# Generated at 2022-06-24 08:22:57.344603
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    executor = dummy_executor
    f = executor.submit(lambda: 1 + 2)
    loop.run_until_complete(f)
    assert f.result() == 3


# Generated at 2022-06-24 08:22:58.392885
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass

# Generated at 2022-06-24 08:23:01.480465
# Unit test for function is_future
def test_is_future():
    assert is_future(futures.Future())
    assert is_future(Future())
    assert not is_future(None)
    assert not is_future(True)

# Generated at 2022-06-24 08:23:02.126407
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    pass

# Generated at 2022-06-24 08:23:05.600181
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    exc = RuntimeError("test error")
    future_set_exc_info(future, sys.exc_info())
    assert future.exception() is exc


if __name__ == "__main__":
    test_future_set_exc_info()

# Generated at 2022-06-24 08:23:14.629062
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    results = []

    def handle_future(f):
        results.append(f)

    future_add_done_callback(future, handle_future)
    assert handle_future in future._callbacks

    future_add_done_callback(future, handle_future)
    assert handle_future in future._callbacks

    assert len(results) == 0

    future.set_result(42)
    assert len(results) == 2
    assert results[0] is future
    assert results[1] is future

    future = Future()
    future_add_done_callback(future, handle_future)
    assert handle_future in future._callbacks

    assert len(results) == 2

    future.set_result(42)
    assert len(results) == 3
    assert results[2] is future




# Generated at 2022-06-24 08:23:16.137646
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    x = DummyExecutor()
    assert isinstance(x, DummyExecutor)


# Generated at 2022-06-24 08:23:18.560570
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(object())

# Generated at 2022-06-24 08:23:27.954798
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    # #17926: Verify that future_set_exc_info works for both Tornado and asyncio Futures
    for future_class in (Future, futures.Future):  # type: ignore
        # Verify that future_set_exc_info raises the same exception that Future.set_exception would
        future = future_class()
        if future_class is Future:
            future.add_done_callback(lambda fut: fut)
        future_set_exc_info(future, (ZeroDivisionError, ZeroDivisionError(), None))
        with future_class() as exc_future:
            future_set_exc_info(exc_future, (ZeroDivisionError, ZeroDivisionError(), None))

# Generated at 2022-06-24 08:23:35.244062
# Unit test for function chain_future
def test_chain_future():
    loop = asyncio.new_event_loop()

    def make_future(*args: Any, **kwargs: Any) -> Future:
        return loop.run_in_executor(None, futures.Future, *args, **kwargs)

    async def chain(a_future: Future, b_future: Future) -> None:
        chain_future(a_future, b_future)
        await b_future
        return "callback"

    async def chain2(a_future: Future, b_future: Future) -> None:
        chain_future(a_future, b_future)
        await b_future
        return "callback"

    f1 = make_future()
    f2 = make_future()
    f3 = make_future()
    f4 = make_future()


# Generated at 2022-06-24 08:23:44.817005
# Unit test for function chain_future
def test_chain_future():
    try:
        # Try to import ``concurrent.futures``
        __import__("concurrent.futures")
    except ImportError:
        return

    import concurrent.futures
    import time

    import tornado.ioloop
    import tornado.testing
    from tornado import gen

    from tornado.util import gen_test

    class FutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            @gen.coroutine
            def f():
                self.called = True
                raise gen.Return(42)

            # This test is complicated by the fact that concurrent.futures
            # futures are not compatible with the version of Future used by
            # gen.Return.  chain_future fakes the compatibility.
            executor = concurrent.futures.ThreadPoolExecutor(1)


# Generated at 2022-06-24 08:23:53.362214
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    def f(a, b, c=1, d=2, *args, **kwargs):
        # type: (int, int, Any, Any, Any, Any) -> Any
        return a, b, c, d, args, kwargs

    f_submitted = dummy_executor.submit(f, 1, 2, 3, d=4, e=5, f=6)
    assert f_submitted.result() == (1, 2, 3, 4, (), {"e": 5, "f": 6})
    assert f_submitted.done()
    assert not f_submitted.cancelled()
    assert not f_submitted.running()

    # Test exceptions

# Generated at 2022-06-24 08:24:03.064613
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import random

    class TestCase(unittest.TestCase):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super(TestCase, self).__init__(*args, **kwargs)
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self) -> None:
            self.executor.shutdown(wait=True)

        def test_basic(self) -> None:
            @run_on_executor
            def f() -> int:
                return 5

            result_future = f()
            self.assertIsInstance(result_future, Future)
            self.assertEqual(result_future.result(), 5)


# Generated at 2022-06-24 08:24:09.767218
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    assert not f.done()
    future_set_result_unless_cancelled(f, None)
    assert f.done()

    f = Future()
    assert not f.done()
    f.cancel()
    assert f.done()
    assert f.cancelled()
    future_set_result_unless_cancelled(f, None)
    assert f.done()
    assert f.cancelled()

# Generated at 2022-06-24 08:24:13.594790
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise ValueError("foo")
    except ValueError:
        exc_info = sys.exc_info()

    async_future = asyncio.Future()
    future_set_exc_info(async_future, exc_info)
    assert async_future.exception() is not None

# Generated at 2022-06-24 08:24:18.814519
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 5)
    assert future.result() == 5
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 6)
    assert future.cancelled()

# Generated at 2022-06-24 08:24:21.238869
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    result = executor.shutdown()
    assert(result==None)


# Generated at 2022-06-24 08:24:26.504345
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert is_future(futures.Future())
    assert is_future(Future())

    with pytest.raises(TypeError):
        is_future(Future()).cancel()


import pytest

from tornado.util import raise_exc_info



# Generated at 2022-06-24 08:24:32.041633
# Unit test for function run_on_executor
def test_run_on_executor():
    async def func1():
        pass

    class Test:
        executor = dummy_executor

    t = Test()
    r = run_on_executor(func1)
    assert r(t) is not None

# Generated at 2022-06-24 08:24:33.021085
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:24:36.552784
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    class Task:
        def __init__(self):
            pass

        def __call__(self):
            return "hello"

    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(Task())
    assert future.result() == "hello"


# Generated at 2022-06-24 08:24:41.087456
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    excinfo = None
    try:
        raise TypeError
    except TypeError:
        excinfo = sys.exc_info()

    a = Future()
    future_set_exc_info(a, excinfo)
    a.result()

# Generated at 2022-06-24 08:24:46.297767
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 'my result')
    assert f.cancelled()

# Generated at 2022-06-24 08:24:52.669417
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def inner():
        raise Exception('foo')
    try:
        inner()
    except Exception:
        exc_info = sys.exc_info()

    f = Future()
    future_set_exc_info(f, exc_info)
    assert isinstance(f.exception(), Exception)
    assert f.exception() and f.exception().args == ('foo',)


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 08:24:54.177453
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-24 08:25:00.628529
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future() # type: Future
    try:
        future_set_result_unless_cancelled(future, 4)
        assert False, 'set_result should raise exception'
    except:
        future.cancel()
        try:
            future_set_result_unless_cancelled(future, 3)
        except Exception as e:
            assert False, "set_result should not raise exception: %r" % e

# Generated at 2022-06-24 08:25:01.532430
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError(_T())

# Generated at 2022-06-24 08:25:12.058233
# Unit test for function run_on_executor
def test_run_on_executor():
    class Example(object):
        def __init__(self, io_loop: "IOLoop") -> None:
            self.io_loop = io_loop
            self.executor = ThreadPoolExecutor(1)
            self._success_future = Future()

        @run_on_executor
        def test(self, arg, kwarg=None) -> str:
            assert self.io_loop is self.io_loop.current()
            return arg + kwarg

        def test_done(self, future: "Future[str]") -> None:
            self.assertEqual(future.result(), "test")
            self._success_future.set_result(True)

        def test_2(self) -> None:
            future = self.test("test", kwarg="")
            future.add_done_callback

# Generated at 2022-06-24 08:25:14.266428
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    dummyExecutor = DummyExecutor()
    dummyExecutor.shutdown(wait=True)

# Generated at 2022-06-24 08:25:19.863024
# Unit test for function run_on_executor
def test_run_on_executor():
    from unittest.mock import Mock

    class A:
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            pass

    a = A()
    a.foo()
    assert a.executor.submit.called
    a.executor.submit.assert_called_with(a.foo, a)

# Generated at 2022-06-24 08:25:27.870487
# Unit test for function run_on_executor
def test_run_on_executor():
    try:
        # Python 3.7+
        from unittest import mock
    except ImportError:
        import mock

    class A(object):
        executor = dummy_executor

        @run_on_executor
        def f(self):
            return 1

    class B(object):
        _thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def g(self):
            return 2

    a = A()
    b = B()
    with mock.patch("tornado.concurrent.futures.Future") as mock_future:
        future = a.f()
        future2 = b.g()
    assert len(mock_future.mock_calls) == 2
    assert future == mock_future.return_value
    assert future

# Generated at 2022-06-24 08:25:32.698382
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    def fn(*args, **kwargs):
        return 'result'

    # without @return_future
    future = Future()
    if not future.cancelled():
        future.set_result('result')
    assert future.done()

    # with @return_future
    future = Future()
    return_future(fn)(None, future)
    assert future.done()

# Generated at 2022-06-24 08:25:41.061357
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    # future has not been canceled
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    # future has been canceled
    assert future.cancelled()

# Generated at 2022-06-24 08:25:48.135668
# Unit test for function future_set_exc_info
def test_future_set_exc_info():

    def future_set_exc_info_helper(future):
        pass

    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
    future = Future()
    future_set_exc_info_helper(future)
    assert future.exception() == None
    future_set_exc_info(future, exc_info)
    assert future.exception() == exc_info[1]


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 08:25:55.751265
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    async def test_future_set_result_unless_cancelled():
        future = Future()
        future.cancel()
        future_set_result_unless_cancelled(future, "result")
        assert not future.done()
        assert future.cancelled()
        future = Future()
        future_set_result_unless_cancelled(future, "result")
        assert future.done()
        assert future.result() == "result"

    AsyncIOMainLoop().install()
    AsyncTestCase().run_sync(test_future_set_result_unless_cancelled)



# Generated at 2022-06-24 08:26:01.601859
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    e = futures.Executor()
    d = Future()
    c = Future()
    b = Future()
    a = e.submit(lambda x: x, 1)

    chain_future(a, b)
    chain_future(b, c)
    chain_future(c, d)

    @d.add_done_callback
    def f(_):
        assert d.result() == 1

    e.shutdown(wait=True)


# Generated at 2022-06-24 08:26:06.690976
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    """Unit test for function future_set_result_unless_cancelled"""
    exception = 'This is an exception'
    f = Future()  # type: Future
    f.cancel()
    assert f.cancelled() is True
    future_set_result_unless_cancelled(f, exception)
    assert f.cancelled() is True
    f = Future()  # type: Future
    future_set_result_unless_cancelled(f, exception)
    assert f.exception() == exception



# Generated at 2022-06-24 08:26:07.906437
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # type: () -> None
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:26:19.628506
# Unit test for function chain_future

# Generated at 2022-06-24 08:26:22.527429
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    assert future.cancelled() == False
    future_set_exc_info(future, (None, None, None))
    assert future.result() == None

# Generated at 2022-06-24 08:26:24.292975
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    ex = DummyExecutor()
    f = ex.submit(lambda: 123)
    assert f.result() == 123

# Generated at 2022-06-24 08:26:37.325372
# Unit test for function chain_future
def test_chain_future():
    @gen.coroutine
    def f1(x, y):
        yield gen.moment
        raise gen.Return(x + y)

    @gen.coroutine
    def f2(x, y):
        z = yield f1(x, y)
        raise gen.Return(z * 2)

    @gen.coroutine
    def f3(x, y):
        z = yield f2(x, y)
        raise gen.Return(z * 3)

    @gen.coroutine
    def f4(x, y):
        z = yield f3(x, y)
        raise gen.Return(z * 4)

    f = Future()
    f4(1, 2, callback=(f.set_result, f))
    result = yield f
    eq(result, 24)

# Generated at 2022-06-24 08:26:45.016978
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.testing

    @tornado.testing.gen_test
    async def test_add_done_callback():
        future = Future()
        async def callback(future):
            assert future.done()
            future.set_result(None)
        tornado.ioloop.IOLoop.current().call_soon(future.set_result, None)
        future_add_done_callback(future, callback)
        await future

    test_add_done_callback()



# Generated at 2022-06-24 08:26:54.082930
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()

    def f():
        raise Exception("nope")

    def g():
        return f()

    future_set_exc_info(future, sys.exc_info())
    if future.exception() is None:
        raise Exception("didn't set exception")
    future = Future()
    try:
        g()
    except:  # noqa: F841
        future_set_exc_info(future, sys.exc_info())
    if future.exception() is None:
        raise Exception("didn't set exception")

# Generated at 2022-06-24 08:27:04.246925
# Unit test for function run_on_executor
def test_run_on_executor():  # noqa: C901
    import unittest
    import concurrent.futures
    import functools
    import sys
    import threading

    import tornado
    import tornado.gen
    import tornado.testing
    import tornado.ioloop
    from tornado.platform.asyncio import AsyncIOLoop

    class TestMixin(object):
        def mock_thread_pool(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(
                1, thread_name_prefix="TestMixin"
            )

        def setUp(self):
            super(TestMixin, self).setUp()
            if self.executor:
                self.executor.shutdown()
                self.io_loop.add_future(self.executor.submit(lambda: None),
                                        lambda future: None)

# Generated at 2022-06-24 08:27:09.913340
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    executor = DummyExecutor()
    future = executor.submit(lambda: 1)
    assert future.result() == 1
    exception = ZeroDivisionError
    future = executor.submit(lambda: 1 / 0)
    assert isinstance(future.exception(), exception)
    future = executor.submit(lambda: 1)
    assert future.done()



# Generated at 2022-06-24 08:27:11.103866
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    dummy_executor.submit(print, "test")

# Generated at 2022-06-24 08:27:18.504820
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None

    class Greeter(object):
        executor = dummy_executor

        @run_on_executor
        def greet(self, greeting: str) -> str:
            return greeting + " world"

    greeter = Greeter()
    f = greeter.greet("hello")
    assert isinstance(f, Future)
    assert f.result() == "hello world"


if __name__ == "__main__":
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    _T = typing.TypeVar("_T")

    class FutureTest(AsyncTestCase):
        def test_future(self):
            # type: () -> None
            f = Future()
            f.set_result(42)

# Generated at 2022-06-24 08:27:19.383082
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    DummyExecutor().shutdown()


# Generated at 2022-06-24 08:27:25.570685
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    async def f():
        await Future()

    future = f()
    if not future.done():
        future_set_exc_info(future, sys.exc_info())


# This namespace is used by both tornado.concurrent and
# tornado.gen.convert_yielded. See docstring for the latter for
# details.

