

# Generated at 2022-06-24 08:17:34.102597
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError(
        "test %s %s", tuple(["1", "2"]), dict(a=3, b=4, c=5)
    )


# Generated at 2022-06-24 08:17:35.606492
# Unit test for function is_future
def test_is_future():
    assert not is_future("foo")
    assert is_future(Future())
    assert is_future(futures.Future())


# Generated at 2022-06-24 08:17:46.885350
# Unit test for function chain_future
def test_chain_future():
    # Test that chain_future copies the result of the first Future to the
    # second, unless the second is already done.

    async def async_fn() -> int:
        return 42

    def sync_fn() -> int:
        return 1337

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f1.done() and not f2.done()

    f1.set_result(None)
    assert f1.done() and f2.done() and f2.result() is None

    f1 = Future()
    f2 = Future()
    f2.set_result(None)
    chain_future(f1, f2)
    assert not f1.done() and f2.done()

    # Regression test for an obscure bug:
    #

# Generated at 2022-06-24 08:17:48.684558
# Unit test for function is_future
def test_is_future():
    def f(x):
        return x
    f(Future())
    f(futures.Future())

# Generated at 2022-06-24 08:17:53.303583
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    e = dummy_executor
    # Arrange
    assert e.__class__.__name__ == "DummyExecutor"
    # Act/Assert
    e.shutdown(False)
    assert e.__class__.__name__ == "DummyExecutor"

# Generated at 2022-06-24 08:17:58.353129
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError(): # pragma: nocover
    class Foo(object):
        @return_future
        def bar(self, callback):
            pass

        @return_future(None)
        def baz(self, callback):
            pass

    try:
        Foo().bar()
    except ReturnValueIgnoredError:
        pass
    else:
        assert False

    try:
        Foo().baz()
    except ReturnValueIgnoredError:
        pass
    else:
        assert False



# Generated at 2022-06-24 08:18:07.839578
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import tornado.ioloop

    class TestCase(unittest.TestCase):
        def setUp(self) -> None:
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()

        def tearDown(self) -> None:
            self.executor.shutdown(wait=True)
            self.io_loop.close()

        def test_run_on_executor_default(self) -> None:
            self.io_loop.make_current()

            @run_on_executor
            def func(self, x):
                self.assertIs(self.io_loop, tornado.ioloop.IOLoop.current())

# Generated at 2022-06-24 08:18:08.849254
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    with DummyExecutor() as executor:
        pass
    pass

# Generated at 2022-06-24 08:18:12.675538
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    try:
        async_future = loop.create_future()
        conc_future = futures.Future()
        chain_future(async_future, conc_future)
        chain_future(conc_future, async_future)
        loop.run_until_complete(async_future)
        assert conc_future.done()

        conc_future.set_result(42)
        assert async_future.result() == 42
    finally:
        loop.close()

# Generated at 2022-06-24 08:18:16.418080
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # expected is 8
    dummy_future = dummy_executor.submit(lambda x: x * 2, 5)
    assert dummy_future.result() == 10

# test for run_on_executor

# Generated at 2022-06-24 08:18:17.787077
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    e = ReturnValueIgnoredError('test')
    assert str(e) == 'test'

# Generated at 2022-06-24 08:18:27.554119
# Unit test for function future_add_done_callback
def test_future_add_done_callback():

    class DummyFuture(Future):

        def __init__(self, expect_object=None):
            self._expect_object = expect_object
            super().__init__()

        def _set_state(self, state, value=_NO_RESULT):
            if (value is not _NO_RESULT) and (value != self._expect_object):
                raise ValueError("future's object is %r, should be %r" % (value, self._expect_object))
            super()._set_state(state, value)

    now = object()

    def on_done(future):
        if future.done() and future.result() is not now:
            raise ValueError("future's object is %r, should be %r" % (future.result(), now))


# Generated at 2022-06-24 08:18:31.763866
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    fut = Future()
    future_set_result_unless_cancelled(fut, "result")
    assert fut.result() == "result"

    fut = Future()
    fut.cancel()
    future_set_result_unless_cancelled(fut, "ignored")
    with pytest.raises(futures.CancelledError):
        fut.result()

# Generated at 2022-06-24 08:18:34.377035
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("This is an error"))

# Generated at 2022-06-24 08:18:39.295280
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    assert future.cancelled()
    future_set_exception_unless_cancelled(future, Exception())


# Generated at 2022-06-24 08:18:48.921751
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1

    f1 = Future()
    f2 = Future()
    f2.cancel()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(1)
    assert f1.result() == 1

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError("foo"))
   

# Generated at 2022-06-24 08:18:50.165825
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:18:51.316513
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    assert dummy_executor is DummyExecutor()

# Generated at 2022-06-24 08:18:55.181272
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)
    assert not is_future(1)

# Generated at 2022-06-24 08:19:06.057666
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    class TestCase(AsyncTestCase):
        def test_run_on_executor(self):
            @run_on_executor
            def f(x):
                return x + 1

            future = f(41)
            self.assertEqual(42, self.io_loop.run_sync(future))

        def test_run_on_executor_self(self):
            @run_on_executor
            def f(self, x):
                return self.y + x

            future = f(self, 41)
            self.y = 1
            self.assertEqual(42, self.io_loop.run_sync(future))

    AsyncIOMainLoop().install()

# Generated at 2022-06-24 08:19:07.356323
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    # test_shutdown method of DummyExecutor must not throw any exception
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:19:08.851141
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:19:12.360163
# Unit test for function is_future
def test_is_future():
    try:
        # type: () -> None
        assert is_future(Future())
    except NameError:
        # Future is not defined.
        pass

# Generated at 2022-06-24 08:19:20.621326
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    @gen_test
    def test():
        class A(object):
            def __init__(self, loop: asyncio.AbstractEventLoop):
                self.executor = dummy_executor
                self.io_loop = loop

            @run_on_executor
            def foo(self, a: int, b: str, c: float) -> str:
                return b * int(c + a)

        a = A(AsyncIOMainLoop().asyncio_loop)
        result = yield a.foo(1, 'x', 2.0)
        self.assertEqual(result, 'xx')

    AsyncTestCase().run_sync(test)

# Generated at 2022-06-24 08:19:22.540695
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    def func(a: int, b: int) -> int:
        return a + b

    res = dummy_executor.submit(func, 1, 2)
    assert res.result() == 3


# Generated at 2022-06-24 08:19:30.037132
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()

    def cb():
        f2.set_result(True)

    chain_future(f1, f2)
    f1.set_result(True)
    assert f2.done()
    assert f2.result()

    f1 = Future()
    f2 = Future()
    f1.set_result(True)
    chain_future(f1, f2)
    assert f2.done()
    assert f2.result()



# Generated at 2022-06-24 08:19:38.679355
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    try:
        raise Exception("foo")
    except Exception:
        exc_info = sys.exc_info()

    # No exception before set
    future = Future()
    if future.exception() is not None:
        raise Exception("Exception was already set: %r" % future.exception())
    future_set_exc_info(future, exc_info)
    if future.exception() is None:
        raise Exception("Exception was not set")
    else:
        app_log.info("Exception: %r", future.exception())

    # No exception before set (futures.Future version)
    future = futures.Future()
    if future.exception() is not None:
        raise Exception("Exception was already set: %r" % future.exception())

# Generated at 2022-06-24 08:19:43.326949
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    # Once cancelled, a future cannot be reset to be done with a result.
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert not future.cancelled()
    assert future.done()
    assert future.result() == "foo"


# Generated at 2022-06-24 08:19:52.936668
# Unit test for function run_on_executor
def test_run_on_executor():
    import os
    import socket

    import unittest
    import tornado.httputil
    import tornado.iostream

    from tornado.ioloop import IOLoop

    @tornado.gen.coroutine
    def get_google():
        # In a thread in the executor
        stream = yield tornado.iostream.IOStream.connect(
            tornado.httputil.HTTPSConnection("www.google.com", 443)
        )
        stream.write(
            b"GET / HTTP/1.0\r\nHost: www.google.com\r\nUser-Agent: tornado-test\r\n\r\n"
        )
        response = yield stream.read_until(b"\r\n\r\n")
        stream.close()
        raise tornado.gen.Return(response)


# Generated at 2022-06-24 08:19:54.098128
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    with DummyExecutor() as ex:
        future = ex.submit(lambda: "done")
        assert future.result() == "done"

# Generated at 2022-06-24 08:20:05.672590
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.iostream import IOStream
    from tornado import gen
    import socket
    import functools

    @gen.coroutine
    def main():
        HOST, PORT = "localhost", 8888
        stream = IOStream(socket.socket())
        stream.connect((HOST, PORT))
        # test write callback
        future = dummy_executor.submit(stream.write, b"some data")
        yield future
        print("write callback done")
        # test read_until_close
        future = dummy_executor.submit(stream.read_until_close)
        data = yield future
        print("got data:", repr(data))

    IOLoop.current().run_sync(main)

# Generated at 2022-06-24 08:20:13.852838
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import pytest
    from tornado.ioloop import IOLoop

    class SimpleFuture(Future):
        def __init__(self) -> None:
            self._result = None  # type: Union[None, Exception]
            self._callbacks = []  # type: List[Callable[[], None]]

        def set_result(self, value: Any) -> None:
            raise NotImplementedError("set_result")

        def set_exception(self, exception: Exception) -> None:
            raise NotImplementedError("set_exception")

        def add_done_callback(self, callback: Callable[[], None]) -> None:
            self._callbacks.append(callback)

        def done(self) -> bool:
            return self._result is not None


# Generated at 2022-06-24 08:20:20.904478
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f() -> None:
        1 / 0

    future = Future()
    future_set_exc_info(
        future, (None, ZeroDivisionError(), None)  # type: ignore
    )
    assert future.exception() is not None

    future = Future()
    future_set_exc_info(future, (None, None, None))
    assert future.exception() is None
    assert future.done()

# Generated at 2022-06-24 08:20:24.943029
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    """
    >>> ReturnValueIgnoredError("message", "argument")
    Traceback (most recent call last):
        ...
    ReturnValueIgnoredError: The 'message' argument to Future.set_result() was ignored: 'argument'
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 08:20:34.965065
# Unit test for function chain_future

# Generated at 2022-06-24 08:20:45.405025
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(max_workers=2)
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close(all_fds=True)

        def test_run_on_executor(self):
            @run_on_executor(executor='executor')
            def f(self):
                return 42

            @run_on_executor()
            def g(x):
                return x * 10

            class Foo(object):
                executor = self.executor


# Generated at 2022-06-24 08:20:47.017018
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()
    ReturnValueIgnoredError("explicit message")

# Generated at 2022-06-24 08:20:55.971363
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import unittest
    from asyncio import Future

    @unittest.mock.patch.object(Future, "cancelled", return_value=True)
    @unittest.mock.patch.object(Future, "set_result")
    def test_set_result_cancelled(mock_cancelled, mock_set_result):
        future = Future()
        future_set_result_unless_cancelled(future, "result")
        mock_set_result.assert_not_called()
    
    test_set_result_cancelled()


# Generated at 2022-06-24 08:21:02.978473
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    d = DummyExecutor()
    d.submit(my_sum, 2, 3)

    # Also test the decorator
    class A:
        def __init__(self):
            self.executor = d

        @run_on_executor
        def foo(self, x):
            return x+2

    a = A()
    f = a.foo(3)
    assert not f.done()
    assert f.result() == 5


# Generated at 2022-06-24 08:21:06.759951
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    executor = DummyExecutor()
    executor.shutdown()

# Generated at 2022-06-24 08:21:15.841090
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import tornado.web
    import tornado.ioloop

    class MainHandler(tornado.web.RequestHandler):
        executor = dummy_executor

        @tornado.web.asynchronous
        @run_on_executor
        def get(self):
            import time
            time.sleep(3)  # simulate long running task
            self.write("hello, world")
            self.finish()

    app = tornado.web.Application([(r"/", MainHandler)])
    app.listen(8880)
    tornado.ioloop.IOLoop.current().start()

    # $ curl http://localhost:8880 -w '\n'
    # hello, world


# Generated at 2022-06-24 08:21:25.042659
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    class FutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def _make_future(self):
            return concurrent.futures.Future()

        def _make_async_future(self):
            return Future()

        def test_run_on_executor(self):
            if sys.version_info < (3, 5, 2):
                # This is a pretty error-prone test. Don't trust it with our
                # old crufty asyncio implementation.
                self.skipTest("tests internals of asyncio")

# Generated at 2022-06-24 08:21:28.960301
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo():
        return 1
    d = DummyExecutor()
    f = d.submit(foo)
    f.add_done_callback(lambda future: print(future.result()))



# Generated at 2022-06-24 08:21:32.569290
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    executor = DummyExecutor()
    future = executor.submit(lambda: 42)
    assert future.result() == 42

test_DummyExecutor()

# Generated at 2022-06-24 08:21:38.612725
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    async def test():
        IOLoop.current().add_callback(dummy_executor.shutdown)
        await IOLoop.current().add_future(to_asyncio_future(asyncio.sleep(1)), lambda f: f)
        print('test_DummyExecutor_shutdown: pass')

    asyncio.ensure_future(test())


# Generated at 2022-06-24 08:21:39.982287
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    dummy = ReturnValueIgnoredError
    dummy = dummy

# Generated at 2022-06-24 08:21:51.068732
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def ret(x=None):
        return x

    new_future = dummy_executor.submit(ret, 1)
    assert type(new_future) == Future
    assert new_future.result() == 1

    new_future = dummy_executor.submit(ret)
    assert type(new_future) == Future
    assert new_future.result() == None

    new_future = dummy_executor.submit(lambda x: x + 1)
    assert type(new_future) == Future
    assert new_future.result() == None

    new_future = dummy_executor.submit(lambda: 1/0)
    assert type(new_future) == Future
    try:
        new_future.result()
        assert False
    except ZeroDivisionError:
        assert True


# Generated at 2022-06-24 08:21:53.103038
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    e = DummyExecutor()
    e.submit(str, 'abc')
    e.shutdown()

# Generated at 2022-06-24 08:21:58.832126
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    fut = Future()  # type: Future[str]
    assert not fut.done()
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(fut, sys.exc_info())
    assert fut.done()
    assert isinstance(fut.exception(), ValueError)
    assert sys.exc_info() == (None, None, None)

# Generated at 2022-06-24 08:22:01.094006
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda: 1)
    assert future.result() == 1

# Generated at 2022-06-24 08:22:06.145671
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def raise_fail():
        raise RuntimeError("failure")

    def raise_logic():
        raise LogicError("logic error")

    # Keep reference to avoid GC of frame
    future = Future()

    try:
        raise_logic()
    except:
        future_set_exc_info(future, sys.exc_info())

    future1 = Future()
    future_add_done_callback(future1, lambda f: future_set_exc_info(future, sys.exc_info()))
    future_set_result_unless_cancelled(future1, None)

    for i in range(5):
        future = Future()
        future_add_done_callback(future, lambda f: f.result())
        future_set_result_unless_cancelled(future, i)

    future = Future()

# Generated at 2022-06-24 08:22:15.969311
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(1)
    assert f2.result() == 1
    assert not f2.cancelled()
    assert not f2.exception()
    # Test exceptions
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError("foo"))
    assert f2.exception() is not None
    try:
        f2.result()
    except ValueError as e:
        assert str(e) == "foo"

# Generated at 2022-06-24 08:22:24.390545
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    io_loop = IOLoop()
    io_loop.make_current()
    future = Future()

    @run_on_executor(executor='_thread_pool')
    def sleep_and_set_result(seconds):
        sleep(seconds)
        return seconds

    def callback(future):
        io_loop.stop()
        io_loop.close()
        assert future.result() == 5

    future_add_done_callback(future, callback)
    sleep_and_set_result(5)



# Generated at 2022-06-24 08:22:32.639785
# Unit test for function chain_future
def test_chain_future():
    """
    Unit tests that chain_future method works appropriately.
    """
    import unittest
    import threading
    import time

    class TestChainFuture(unittest.TestCase):
        """
        This class tests the functionality of the future object passed as
        the first parameter to the chain_future function.
        """
        def test_future_successful(self):
            """
            Tests a successful future object.
            """
            future = Future()
            chained_future = Future()

            def set_result(future):
                future.set_result(42)

            threading.Timer(0.01, set_result, args=[future]).start()

            chain_future(future, chained_future)
            time.sleep(0.1)
            self.assertEqual(chained_future.result(), 42)


# Generated at 2022-06-24 08:22:41.754619
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # Create a Future
    future = Future()
    # Create a dummy result
    dummy_result = 0
    # Set dummy result
    future_set_result_unless_cancelled(future, dummy_result)
    # Check result is set and is the right value
    assert future.result() == dummy_result
    # Cancel Future
    future.cancel()
    # Once Future is cancelled, trying to set result should not raise error
    future_set_result_unless_cancelled(future, dummy_result)
    # Check that Future is cancelled and no result was set
    assert future.cancelled() and future.result() is None

# Generated at 2022-06-24 08:22:45.831398
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    future_set_exc_info(future, exc_info)
    assert future.exception() is not None

# Generated at 2022-06-24 08:22:51.824825
# Unit test for function future_set_exc_info
def test_future_set_exc_info():  # type: ignore
    class FakeFuture:
        def set_exception(self, exc):
            self.exc = exc

        def cancel(self):
            pass

    future = FakeFuture()
    error = RuntimeError("test error")

    def _raise():
        raise error

    future_set_exc_info(future, sys.exc_info())
    assert future.exc is error
    future_set_exc_info(future, sys.exc_info())
    assert future.exc is error
    future_set_exc_info(future, None)
    assert future.exc is None

# Generated at 2022-06-24 08:22:52.795486
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:22:58.805906
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado import gen

    @gen.coroutine
    def f():
        raise ValueError

    fut = f()
    try:
        fut.result()
    except ValueError:
        exc_info = sys.exc_info()
        assert isinstance(exc_info[1], ValueError)
    else:
        raise Exception("Did not raise")

    future = Future()
    future_set_exc_info(future, exc_info)
    try:
        future.result()
    except ValueError:
        assert isinstance(future.exception(), ValueError)
    else:
        raise Exception("Did not raise")

    future = Future()
    future.cancel()
    future_set_exc_info(future, exc_info)
    assert future.cancelled()
    assert future.exception() is None

# Generated at 2022-06-24 08:23:07.270087
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.set_result(123)
    # Normally, setting an exception after the future is complete will
    # fail.  But if the future is cancelled, we'd rather log the error.
    future.cancel()
    # Assert no exception is raised.
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    # Check that the exception is logged.
    future = Future()
    future.cancel()
    with app_log.catch_log():
        future_set_exception_unless_cancelled(future, RuntimeError("test"))
        assert app_log.exception_was_logged()

# Generated at 2022-06-24 08:23:10.125331
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    a = DummyExecutor()
    a.submit(print, "hello")
    a.submit(sorted, [1, 4, 2, 5])
    a.shutdown()

# Generated at 2022-06-24 08:23:16.674980
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = asyncio.Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42

    f = asyncio.Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() is None



# Generated at 2022-06-24 08:23:24.457071
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    future = Future()
    future.set_result(None)
    called = []
    future_add_done_callback(future, lambda f: called.append(f))
    assert called == [future]

    future = Future()
    called = []
    future_add_done_callback(future, lambda f: called.append(f))
    future.set_result(None)
    assert called == [future]

    future = Future()
    future.set_result(None)
    called = []
    future_add_done_callback(future, lambda f: called.append(f))
    assert called == [future]

# Generated at 2022-06-24 08:23:34.421001
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.ioloop
    from tornado.testing import AsyncTestCase, ExpectLog

    class Test(AsyncTestCase):
        def test_normal_result(self):
            self.flag = None

            class Obj:
                executor = dummy_executor

                @run_on_executor
                def method(self):
                    return 123

                def callback(self, future):
                    self.flag = future.result()
                    self.stop()

            obj = Obj()
            obj.method().add_done_callback(obj.callback)
            self.wait()
            self.assertEqual(self.flag, 123)

        def test_exception_result(self):
            self.flag = self.failureException = None

            class Obj:
                executor = dummy_executor


# Generated at 2022-06-24 08:23:42.338885
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    """Ensure that run_on_executor returns the right thing."""
    import concurrent.futures
    import functools
    import itertools

    import tornado

    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web

    class Handler(tornado.web.RequestHandler):
        executor = concurrent.futures.ThreadPoolExecutor(5)

        @tornado.gen.coroutine
        def get(self):
            self.finish((yield self.slow()))

        @run_on_executor
        def slow(self):
            # type: () -> float
            import time
            time.sleep(0.1)
            return 42.0

   

# Generated at 2022-06-24 08:23:46.389793
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()  # type: Future[Any]
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())

# Generated at 2022-06-24 08:23:49.942248
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    f.cancel()
    future_set_result_unless_cancelled(f, 2)
    assert f.cancelled()
    assert f.result() == 1

# Generated at 2022-06-24 08:23:55.578065
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future

    class TestClass:

        def __init__(self, executor):
            self.test_executor = executor

        @run_on_executor
        def test_submit(self, k, v):
            return k + v

    test_obj = TestClass(dummy_executor)
    future = test_obj.test_submit(1, 1)
    assert isinstance(future, Future)
    assert future.result() == 2


# Generated at 2022-06-24 08:24:05.366335
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import asyncio
    from concurrent import futures

    class Runner:
        def __init__(self, executor: Optional[futures.Executor]) -> None:
            self.executor = executor

        @run_on_executor
        def run(self: "Runner") -> None:
            raise Exception("error")

        @run_on_executor(executor="_executor")
        def run_with_kwargs(self: "Runner") -> None:
            raise Exception("error")

        def run_with_result(self: "Runner") -> "Future[int]":
            return Future()


# Generated at 2022-06-24 08:24:10.683484
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    result = []
    def fn(a, b):
        result.append((a, b))
        return a + b
    test_future = dummy_executor.submit(fn, 1, 2)
    assert isinstance(test_future, futures.Future)
    assert test_future.result() == 3
    assert result == [(1, 2)]

# Generated at 2022-06-24 08:24:16.442984
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    async def async_test_DummyExecutor_submit() -> Any:
        test_DummyExecutor_submit_future = dummy_executor.submit(
            lambda: print('test_DummyExecutor_submit')
        )  # type: futures.Future[Any]
        test_DummyExecutor_submit_result = await test_DummyExecutor_submit_future
        assert test_DummyExecutor_submit_result is None
    asyncio.get_event_loop().run_until_complete(async_test_DummyExecutor_submit())

# Generated at 2022-06-24 08:24:26.175747
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    def fn(self):
        yield gen.sleep(0)
        return 5

    class Self:
        executor = dummy_executor

    @run_on_executor
    def fn2(self, a, b):
        return a + b + (yield gen.sleep(0))

    @run_on_executor
    def fn3(self, a, b):
        return a + b

    with unittest.mock.patch("tornado.concurrent.futures.TracebackFuture"):
        self = Self()
        future = fn3(self, 1, 2)
        self.assertEqual(future.result(), 3)

        fn3(self, 1, 2, callback=self.stop)

# Generated at 2022-06-24 08:24:32.709814
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    import functools
    import asyncio

    async def f():
        raise ValueError

    @functools.wraps(f)
    def wrapper():
        return asyncio.ensure_future(f())

    future = wrapper()
    assert not future.done()
    future_set_exc_info(future, sys.exc_info())
    assert future.done()
    with pytest.raises(ValueError):
        future.result()



# Generated at 2022-06-24 08:24:35.504403
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    #print("\ntest_DummyExecutor")
    dummy_executor = DummyExecutor()
    future = dummy_executor.submit(lambda b: b * 10, 3)
    print(future.result())


# Generated at 2022-06-24 08:24:46.952187
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest

    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    @gen.coroutine
    def f():
        yield gen.sleep(0.01)
        raise Exception("foo")

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

    loop.run_sync(lambda: chain_future(f1, f2))
    loop.run_sync(lambda: f1.set_exception(Exception("bar")))
    self.assertEqual("bar", f2.exception().args[0])
    loop.close()

    # Ensure the exception is logged.
    log_lines = self.io_loop.handler.stream.getvalue().strip().split("\n")
    self

# Generated at 2022-06-24 08:24:58.335222
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    global g_called, g_future
    g_called = False
    g_future = None


# Generated at 2022-06-24 08:24:59.101230
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    dummy_executor = DummyExecutor()
    dummy_executor.shutdown()

# Generated at 2022-06-24 08:25:09.561703
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import time
    import unittest
    from tornado.ioloop import IOLoop

    class FADCTestCase(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor()
            self.io_loop = IOLoop()

        def _wait(self, seconds):
            return self.io_loop.run_in_executor(
                self.executor, lambda: time.sleep(seconds)
            )

        def test_future_add_done_callback(self):
            callback_args = []

            def callback(f):
                self.assertTrue(f.done())
                callback_args.append(f.result())

            f = self._wait(0.1)
            self.assertFalse(f.done())

# Generated at 2022-06-24 08:25:20.797344
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        raise ValueError()
    except ValueError:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None
    f = Future()
    f.set_exception(ValueError())
    future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None


# This is copied from python3.5's stdlib and backported to older
# versions of python. It should be removed once we only support
# python 3.5+.

# Generated at 2022-06-24 08:25:21.865766
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError()

# Generated at 2022-06-24 08:25:34.190386
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    def dummy_callback_fail(unused_future):
        raise Exception('This should not get called')

    # Test encoding/decoding of exceptions.
    # This is important on Python 2, where the exception state is reset
    # after 'yield'.
    f1 = Future()
    f1.set_exception(ZeroDivisionError())
    # No callback, the exception should get logged.
    yield f1
    f2 = Future()
    f2.set_exception(ZeroDivisionError())
    future_add_done_callback(f2, dummy_callback_fail)
    yield f2
    f3 = Future()
    f3.set_exception(ZeroDivisionError())
    future_add_done_callback(f3, lambda f: f.result())

# Generated at 2022-06-24 08:25:42.479595
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    print(dummy_executor)
    print(dummy_executor.submit)
    print(dummy_executor.submit(lambda: 1))
    print(dummy_executor.submit(lambda: 1).result())
    # The blocking wait will trigger the submit callback, which will run on the current thread.
    print(dummy_executor.submit(lambda: 1).result())
    print(dummy_executor.submit(lambda: 1).result())
test_DummyExecutor_submit()

# Generated at 2022-06-24 08:25:49.267038
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    f = Future()
    done = []

    def callback(future):
        # type: (Future) -> None
        assert future is f
        done.append(True)

    future_add_done_callback(f, callback)
    assert done
    f.set_result(None)
    assert done

    f = Future()
    done = []
    future_add_done_callback(f, callback)
    assert not done
    f.set_result(None)
    assert done

# Generated at 2022-06-24 08:25:55.900674
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    # type: () -> None
    future = asyncio.Future()
    assert not future.cancelled()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'

    future = asyncio.Future()
    future.cancel()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 'foo')
    assert not future.done()



# Generated at 2022-06-24 08:26:08.153006
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def func(self):
            return 42

        @run_on_executor(executor="_other_attr")
        def func2(self):
            return 42

    foo = Foo()
    foo._other_attr = dummy_executor
    assert foo.func().result() == 42
    assert foo.func2().result() == 42

    # Corner cases around the callback argument
    @run_on_executor(callback=lambda _: None)
    def func3(self):
        return 1

    assert func3(Foo(), callback=lambda _: 2).result() == 2


# Generated at 2022-06-24 08:26:10.746100
# Unit test for function is_future
def test_is_future():
    assert is_future(Future()) is True
    assert is_future(futures.Future()) is True
    assert is_future(object()) is False

# Generated at 2022-06-24 08:26:16.162078
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    f = Future()
    try:
        # noqa: E711
        1 / 0
        assert False, "this line should not be reached"
    except ZeroDivisionError:
        future_set_exc_info(f, sys.exc_info())
    assert f.exception() is not None

# Generated at 2022-06-24 08:26:26.788037
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from concurrent.futures import ThreadPoolExecutor
    from tornado.ioloop import IOLoop

    class Foo(object):
        def __init__(self):
            self.executor = ThreadPoolExecutor(1)

        @run_on_executor
        def bar(self):
            return 42

        @run_on_executor(executor="executor")
        def bar2(self):
            return 42

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.loop = IOLoop()
            self.foo = Foo()
            self.future = self.foo.bar()
            self.loop.make_current()
            self.loop.add_future(self.future, self.stop)
            self.loop.start()

       

# Generated at 2022-06-24 08:26:29.747229
# Unit test for function chain_future
def test_chain_future():
    test_future = Future()
    test_future.set_result(123)

    def callback(future: Future[int]) -> None:
        future.result()

    chain_future(test_future, Future())

# Generated at 2022-06-24 08:26:37.474338
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class MainLoop(AsyncIOMainLoop):
        def initialize(self, **kwargs):
            super(MainLoop, self).initialize(**kwargs)
            self.wrap = kwargs.get('wrap', False)
            self.done = False
            self.future = None

        def stop(self):
            super(MainLoop, self).stop()

        async def wait(self):
            while not self.done:
                await asyncio.sleep(0)

        def callback(self, future):
            self.done = True
            assert self.future is future


# Generated at 2022-06-24 08:26:47.704895
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    from .testing import AsyncTestCase
    from concurrent.futures import Future as CFuture

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = dummy_executor  # type: Any
            self.f1 = Future()  # type: Future
            self.f2 = CFuture()  # type: CFuture
            self.f3 = Future()  # type: Future
            self.f4 = CFuture()  # type: CFuture

        def test_future_to_future(self):
            chain_future(self.f1, self.f3)
            self.f1.set_result(42)

# Generated at 2022-06-24 08:26:56.875423
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.testing import gen_test
    from tornado.ioloop import IOLoop

    @gen_test
    def test():
        dummy_executor_result = yield dummy_executor.submit(lambda: "done")
        assert dummy_executor_result == "done"

    IOLoop.current().run_sync(test)

if __name__ == "__main__":
    import unittest

    class DummyExecutorTest(unittest.TestCase):
        def test_DummyExecutor(self):
            test_DummyExecutor()

    unittest.main()

# Generated at 2022-06-24 08:27:01.548380
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError())
    assert future.exception()

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError())



# Generated at 2022-06-24 08:27:08.786681
# Unit test for function chain_future
def test_chain_future():
    future1 = Future()
    future2 = Future()
    future3 = Future()
    future4 = Future()
    chain_future(future1, future2)
    chain_future(future2, future3)
    chain_future(future3, future4)

    future1.set_result(0)
    assert not future2.done()
    assert not future3.done()
    assert not future4.done()

    future2.set_result(0)
    assert future3.done()
    assert future4.done()

    def _set_result():
        future3.set_result(0)

    IOLoop.current().add_callback(_set_result)
    assert not future4.done()
    future4.cancel()
    assert not future4.done()

    future1.cancel()
   

# Generated at 2022-06-24 08:27:14.146648
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    from tornado.testing import AsyncTestCase

    class MyAsyncTestCase(AsyncTestCase):

        def setUp(self):
            super(MyAsyncTestCase, self).setUp()

        def test_function(self):
            test_future = asyncio.Future()
            future_set_result_unless_cancelled(test_future, True)
            self.assertTrue(test_future.done())
            self.assertTrue(test_future.result())
            self.stop()

    MyAsyncTestCase().run()

# Generated at 2022-06-24 08:27:24.712771
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import mock

    result = "result"
    exception = RuntimeError()
    future = Future()

    # set the result
    chain_future(Future(), future)
    future.set_result(result)
    assert future.result() == result

    # set the exception
    future = Future()
    chain_future(Future(), future)
    future.set_exception(exception)
    assert isinstance(future.exception(), RuntimeError)

    # return a Future from a Future
    future = Future()
    chain_future(Future(), future)
    chained_future = Future()
    future.set_result(chained_future)
    chained_future.set_exception(exception)
    assert isinstance(future.exception(), RuntimeError)

    # return a Future from a Future from a Future


# Generated at 2022-06-24 08:27:26.516944
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    ReturnValueIgnoredError("test")

# Generated at 2022-06-24 08:27:34.329498
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    future_concurrent = futures.Future()
    result = []
    future_add_done_callback(future_concurrent, lambda fut: result.append(1))
    future_concurrent.set_result(1)
    assert result == [1]

    future_tornado = Future()
    future_add_done_callback(future_tornado, lambda fut: result.append(2))
    future_tornado.set_result(2)
    assert result == [1, 2]

    future_tornado = Future()
    future_add_done_callback(future_tornado, lambda fut: result.append(2))
    future_tornado.set_result(2)
    assert result == [1, 2, 2]

