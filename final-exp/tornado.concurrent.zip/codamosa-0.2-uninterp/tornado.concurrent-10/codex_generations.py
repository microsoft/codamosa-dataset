

# Generated at 2022-06-18 09:49:19.042443
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:49:27.849037
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_

# Generated at 2022-06-18 09:49:32.161845
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:39.674869
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

        def test_chain_future_exception(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(RuntimeError("foo"))
            self.assertRaises(RuntimeError, g.result)

        def test_chain_future_cancel(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.cancel()
            self.assertTrue

# Generated at 2022-06-18 09:49:45.168829
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:49:50.841311
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.run()

# Generated at 2022-06-18 09:50:00.400035
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class Test(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor")
        def func_with_explicit_executor(self, a, b):
            return a + b


# Generated at 2022-06-18 09:50:03.353225
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:12.385063
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:50:17.522192
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()

# Generated at 2022-06-18 09:50:25.447554
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:28.262097
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-18 09:50:40.668862
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())

# Generated at 2022-06-18 09:50:51.249054
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain(self):
            # type: () -> None
                a = Future()
                b = Future()
                chain_future(a, b)
                a.set_result(42)
                self.assertEqual(b.result(), 42)

                a = Future()
                b = Future()
                chain_future(a, b)
                a.set_exception(RuntimeError())
                self.assertTrue(b.exception())

                a = Future()
                b = Future()
                chain_future(a, b)
                b.set_exception(RuntimeError())
                a.set_exception(RuntimeError())
                self.assertTrue(b.exception())

                a = Future

# Generated at 2022-06-18 09:50:56.333345
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:04.313636
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:51:17.083524
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ValueError())
    assert f2.done()
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

# Generated at 2022-06-18 09:51:22.848849
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()
    assert f.result() is None

# Generated at 2022-06-18 09:51:28.987986
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test_chain_future()

# Generated at 2022-06-18 09:51:32.923572
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:44.376460
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()

# Generated at 2022-06-18 09:51:47.694356
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # type: () -> None
    def fn(a, b, c):
        # type: (int, int, int) -> int
        return a + b + c

    future = dummy_executor.submit(fn, 1, 2, 3)
    assert future.result() == 6

# Generated at 2022-06-18 09:51:50.368073
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:55.200332
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:06.867181
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
                f1 = Future()  # type: Future[int]
                f2 = Future()  # type: Future[int]
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(f2.result(), 42)

                f1 = Future()  # type: Future[int]
                f2 = Future()  # type: Future[int]
                chain_future(f1, f2)
                f1.set_exception(ZeroDivisionError())
                self.assertRaises(ZeroDivisionError, f2.result)


# Generated at 2022-06-18 09:52:09.825427
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:52:14.209251
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()

# Generated at 2022-06-18 09:52:16.781895
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:52:26.837026
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking_func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            time.sleep(0.01)
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:52:33.553434
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    assert future.result() is None

# Generated at 2022-06-18 09:52:53.582767
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:01.085907
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            @gen_test
            def test_chain_future():
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(42, (yield f2))

    test_chain_future()

# Generated at 2022-06-18 09:53:11.461765
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()

        @run_on_executor
        def blocking_func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:53:18.857482
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:53:24.435934
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:53:27.623715
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-18 09:53:37.084367
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        def test_run_on_executor(self):
            future = self.func(1, 2)
            self.assertEqual(self.io_loop.run_sync(future), 3)

    unittest.main()

# Generated at 2022-06-18 09:53:44.485620
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f1.done())
            self.assertFalse(f2.done())
            f1.set_result(42)
            yield f2
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:53:48.859992
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:53:57.415534
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:54:39.949596
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:54:42.490006
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:54:47.539169
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    unittest.main()

# Generated at 2022-06-18 09:54:51.494077
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    unittest.main()

# Generated at 2022-06-18 09:54:54.569022
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()


# Generated at 2022-06-18 09:55:03.896718
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ZeroDivisionError())
    assert f2.done()
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f

# Generated at 2022-06-18 09:55:14.683931
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class RunOnExecutorTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop.run_sync(functools.partial(tornado.platform.asyncio.AsyncIOMainLoop().install, self.io_loop))


# Generated at 2022-06-18 09:55:22.837561
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future

# Generated at 2022-06-18 09:55:25.444614
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))

# Generated at 2022-06-18 09:55:33.852051
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:57:03.121407
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:57:12.421971
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_with_executor(self):
            f1 = self.executor.submit(lambda: 42)
            f2 = Future()
            chain_future(f1, f2)
            self.io_loop.add_

# Generated at 2022-06-18 09:57:15.154462
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_fn(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_fn, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:57:26.092463
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    def f():
        # type: () -> int
        return 42

    @tornado.testing.gen_test
    def test_chain_future():
        # type: () -> None
        f1 = Future()  # type: Future[int]
        f2 = Future()  # type: Future[int]
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

        f1 = Future()  # type: Future[int]
        f2 = Future()  # type: Future[int]
        chain_future(f1, f2)
        f1.set_exception(ValueError())

# Generated at 2022-06-18 09:57:32.939023
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = concurrent.futures.Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:57:38.616451
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:57:45.551751
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()
    assert not f.done()
    assert f.result() is None
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert not f.cancelled()
    assert f.done()
    assert f.result() == 1

# Generated at 2022-06-18 09:57:56.667599
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.c

# Generated at 2022-06-18 09:58:06.306118
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools

    def callback(future):
        future.set_result(future.result() + 1)

    def errorback(future):
        future.set_exception(Exception("error"))

    def callback2(future):
        future.set_result(future.result() + 1)

    def errorback2(future):
        future.set_exception(Exception("error"))

    def callback3(future):
        future.set_result(future.result() + 1)

    def errorback3(future):
        future.set_exception(Exception("error"))

    def callback4(future):
        future.set_result(future.result() + 1)

    def errorback4(future):
        future.set_exception(Exception("error"))


# Generated at 2022-06-18 09:58:15.190276
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f = Future()
        f2 = Future()
        chain_future(f, f2)
        f.set_result(42)
        self.assertEqual(f2.result(), 42)

        f = Future()
        f2 = Future()
        chain_future(f, f2)
        f.set_exception(ValueError())
        with self.assertRaises(ValueError):
            f2.result()

        f = Future()
        f2 = Future()
        f.set_result(42)
        chain_future(f, f2)
        self.assertEqual(f2.result(), 42)

        f = Future()
        f2 = Future()
        f.set_exception