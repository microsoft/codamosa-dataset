

# Generated at 2022-06-18 09:49:15.553634
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    TestChainFuture().test_chain_future()
    TestChainFuture().test_chain_future_exc_info()

# Generated at 2022-06-18 09:49:21.289623
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def f(a, b):
        return a + b
    future = dummy_executor.submit(f, 1, 2)
    loop.run_until_complete(future)
    assert future.result() == 3
    loop.close()


# Generated at 2022-06-18 09:49:26.235877
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:49:30.588746
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:38.708772
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_exception(ValueError())
        with self.assertRaises(ValueError):
            f2.result()


# Generated at 2022-06-18 09:49:49.251938
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with tornado.testing.assert_raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result

# Generated at 2022-06-18 09:49:52.909186
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:03.239456
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking(self):
            time.sleep(0.1)
            return 42

        @run_on_executor
        def blocking_with_arg(self, arg):
            time.sleep(0.1)
            return arg


# Generated at 2022-06-18 09:50:16.256532
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools

    def f(x):
        time.sleep(0.01)
        return x

    def g(x):
        time.sleep(0.01)
        raise Exception(x)

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)

# Generated at 2022-06-18 09:50:28.358578
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, f2.result)

        def test_chain_future_cancel(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
           

# Generated at 2022-06-18 09:50:42.100493
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools
    from tornado.ioloop import IOLoop

    def f(x):
        return x + 1

    def g(x):
        return x * 2

    def h(x):
        return x - 3

    def callback(future):
        IOLoop.current().stop()

    def test_chain(f1, f2, f3, x):
        f1 = f1(x)
        f2 = f2(x)
        f3 = f3(x)
        chain_future(f1, f2)
        chain_future(f2, f3)
        future_add_done_callback(f3, callback)
        IOLoop.current().start()
        return f3.result()


# Generated at 2022-06-18 09:50:49.474663
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:50:54.088997
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:00.996672
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain(self):
            @gen_test
            def test_chain_future():
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(42, (yield f2))

    test_chain_future()

# Generated at 2022-06-18 09:51:07.521701
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:20.081238
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest_run_loop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        @run_on_executor(executor="executor")
        def func2(self, arg):
            return arg + 1

        @run_on_executor(executor="_executor")
        def func3(self, arg):
            return arg + 1


# Generated at 2022-06-18 09:51:28.657795
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        yield tornado.gen.moment

    @tornado.gen.coroutine
    def g():
        yield tornado.gen.moment

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = f()
        f2 = Future()
        chain_future(f1, f2)
        yield f2
        g1 = g()
        g2 = Future()
        chain_future(g1, g2)
        yield g2

    test_chain_future()

# Generated at 2022-06-18 09:51:32.302757
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:37.863820
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:50.146673
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor")
        def func2(self, a, b):
            return a + b

        @run_on_executor(executor="_executor")
        def func3(self, a, b):
            return a + b

        def test_run_on_executor(self):
            future = self.func(1, 2)
            self.assertIsInstance(future, Future)

# Generated at 2022-06-18 09:52:07.956037
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        # type: () -> None
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future_asyncio()
    test_chain_future_concurrent()

# Generated at 2022-06-18 09:52:12.701281
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:52:15.126952
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:52:25.266162
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)


# Generated at 2022-06-18 09:52:31.797004
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:40.604954
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:52:53.205416
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    def f():
        # type: () -> str
        return "foo"

    def errback(future):
        # type: (Future) -> None
        future.set_exception(Exception("error"))

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result("foo")
    assert b.result() == "foo"

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(Exception("foo"))
    try:
        b.result()
        assert False
    except Exception as e:
        assert str(e) == "foo"

    a = Future

# Generated at 2022-06-18 09:53:05.069905
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_with_executor(self):
            f1 = self.executor.submit(lambda: 42)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:53:09.675400
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:10.670587
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    dummy_executor.submit(lambda: 1)

# Generated at 2022-06-18 09:53:26.716310
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:37.893357
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        def test_run_on_executor(self):
            f = self.func(41)
            self.assertEqual(f.result(), 42)


# Generated at 2022-06-18 09:53:47.619425
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.platform.asyncio

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOMainLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            @run_on_executor
            def f():
                return 42

           

# Generated at 2022-06-18 09:53:52.999607
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:56.717873
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b
    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:54:00.625549
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:54:10.844454
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    a = Future()
    b = Future()
    chain_future(a, b)
    io_loop.add_future(a, lambda a: None)
    io_loop.add_future(b, lambda b: None)
    io_loop.add_callback(a.set_result, 42)
    io_loop.add_callback(b.set_result, 24)
    io_loop.add_callback(io_loop.stop)
    io_loop.start()
    assert a.result() == 42
    assert b.result() == 42

    a = Future()
    b = Future()
    chain_future(a, b)
    io_loop

# Generated at 2022-06-18 09:54:17.370157
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    import asyncio
    import time
    from tornado.log import app_log
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    async def test():
        def func(a, b):
            return a + b
        future = dummy_executor.submit(func, 1, 2)
        result = await future
        app_log.info(result)
        loop.stop()
    loop.add_callback(test)
    loop.start()


# Generated at 2022-06-18 09:54:19.753934
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42



# Generated at 2022-06-18 09:54:29.839936
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, arg):
            time.sleep(0.1)
            return arg

        def test_run_on_executor(self):
            f = self.func(42)
            self

# Generated at 2022-06-18 09:55:04.444194
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

        @gen_test
        def test_chain_future_exception_concurrent(self):
            f1 = futures.Future

# Generated at 2022-06-18 09:55:12.009176
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run()

# Generated at 2022-06-18 09:55:16.908291
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:20.635268
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:29.691623
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run_on_executor(self):
            @run_on_executor
            def f(x, y):
                return x + y


# Generated at 2022-06-18 09:55:31.548365
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-18 09:55:39.006048
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        raise tornado.gen.Return(42)

    @tornado.gen.coroutine
    def g():
        result = yield f()
        raise tornado.gen.Return(result)

    @tornado.gen.coroutine
    def h():
        result = yield g()
        raise tornado.gen.Return(result)

    @tornado.testing.gen_test
    def test():
        result = yield h()
        assert result == 42

    test()

# Generated at 2022-06-18 09:55:41.324867
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:55:44.485889
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:55:51.106482
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()


if __name__ == "__main__":
    test_chain

# Generated at 2022-06-18 09:57:40.923604
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

    @tornado.testing.gen_test
    def test_chain_future_concurrent(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)

# Generated at 2022-06-18 09:57:45.761880
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:50.206158
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    assert future.result() is None

# Generated at 2022-06-18 09:57:57.625911
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    loop.make_current()
    def test_func(a, b):
        return a + b
    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3
    loop.close()


# Generated at 2022-06-18 09:58:06.934921
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    loop.run_sync(lambda: f2)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ZeroDivisionError())
    loop.run_sync(lambda: f2)
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)



# Generated at 2022-06-18 09:58:12.351307
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:58:21.970063
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:58:28.615945
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        @run_on_executor(executor="executor")
        def func_with_executor(self, arg):
            return arg + 1


# Generated at 2022-06-18 09:58:31.696033
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-18 09:58:35.893972
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None