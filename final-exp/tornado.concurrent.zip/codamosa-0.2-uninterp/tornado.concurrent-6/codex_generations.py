

# Generated at 2022-06-18 09:49:21.254140
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            return a + b

    class Test2(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor(executor="executor")
        def func(self, a, b):
            return a + b

    class Test3(object):
        def __init__(self):
            self._thread_pool = concurrent.futures.ThreadPoolExecutor(1)


# Generated at 2022-06-18 09:49:30.669675
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)

# Generated at 2022-06-18 09:49:34.711594
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:49:46.306405
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f = Future()
            f2 = Future()
            chain_future(f, f2)
            f.set_result(42)
            self.assertEqual(f2.result(), 42)
            f3 = Future()
            chain_future(f, f3)
            self.assertEqual(f3.result(), 42)
            f4 = Future()
            chain_future(f2, f4)
            self.assertEqual(f4.result(), 42)
            f5 = Future()

# Generated at 2022-06-18 09:49:55.136277
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing
    import tornado.concurrent
    import concurrent.futures

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = tornado.concurrent.Future()
            f2 = tornado.concurrent.Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = tornado.concurrent.Future()
            f2 = tornado.concurrent.Future()
            chain_future(f1, f2)
            f1.set_exception(ValueError())
            self.assertTrue(f2.exception())

            f1 = tornado

# Generated at 2022-06-18 09:49:59.677380
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:50:01.238635
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-18 09:50:04.024393
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:50:10.013059
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:50:14.897608
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()

# Generated at 2022-06-18 09:50:27.974454
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.done()
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ZeroDivisionError())
    assert f2.done()
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

# Generated at 2022-06-18 09:50:33.918710
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:50:43.248465
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture

# Generated at 2022-06-18 09:50:52.651809
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_exception(RuntimeError())
        with self.assertRaises(RuntimeError):
            f2.result()

        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.cancel()
        self.assertTrue(f2.cancelled())

        f1 = Future()
        f2 = Future()
       

# Generated at 2022-06-18 09:51:06.535663
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            # type: () -> None
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)

# Generated at 2022-06-18 09:51:13.218905
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:51:25.203517
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
           

# Generated at 2022-06-18 09:51:30.866111
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()
    assert not f.done()
    assert f.result() is None

    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert not f.cancelled()
    assert f.done()
    assert f.result() == 42

# Generated at 2022-06-18 09:51:34.700187
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:39.723696
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:51.577164
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-18 09:51:55.116360
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled()

# Generated at 2022-06-18 09:51:59.849342
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:52:06.655338
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:12.187910
# Unit test for function chain_future
def test_chain_future():
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:17.262106
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f = Future()
        g = Future()
        chain_future(f, g)
        f.set_result(42)
        assert g.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:52:20.866466
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:29.255032
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Test that chain_future works with both types of Future
    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = futures.Future()
    chain_future(f2, f1)
    assert not f1.done()
    f2.set_result(42)
    assert f1.result() == 42
    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ValueError())
    assert f2.exception() is not None

# Generated at 2022-06-18 09:52:34.269033
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:52:37.094262
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_fn(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_fn, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:52:54.351232
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b
    dummy_executor.submit(func, 1, 2)

# Generated at 2022-06-18 09:53:00.540677
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def test_func():
        return 1
    future = dummy_executor.submit(test_func)
    assert future.result() == 1
    loop.close()


# Generated at 2022-06-18 09:53:07.278953
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:53:13.452523
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    io_loop = IOLoop()
    io_loop.run_sync(lambda: ChainFutureTest().test_chain_future())

# Generated at 2022-06-18 09:53:26.531461
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:53:32.777676
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:53:37.841439
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:53:47.583636
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, f2.result)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            f2.cancel()

# Generated at 2022-06-18 09:53:52.570421
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:54:02.776744
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

        @gen_test
        def test_chain_future_cancel(self):
            f1 = Future()
            f2

# Generated at 2022-06-18 09:54:45.311074
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg + 1

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self, arg):
            return arg + 1

    class Test3(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self, arg):
            return arg + 1


# Generated at 2022-06-18 09:54:46.672664
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception("test"))

# Generated at 2022-06-18 09:54:49.677606
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:54:54.687338
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:54:58.897123
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:55:02.801564
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:13.601940
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2, kwarg1=3, kwarg2=4)
            self.assertEqual

# Generated at 2022-06-18 09:55:21.924998
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()

# Generated at 2022-06-18 09:55:26.240433
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:34.421514
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, f2.result)

        def test_chain_future_cancel(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
           

# Generated at 2022-06-18 09:56:46.235727
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:56:53.163423
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing
    import tornado.gen

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception())

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.cancel()
            self.assertTrue(f2.cancelled())

            f

# Generated at 2022-06-18 09:57:03.156048
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Test that chain_future works with both types of Future
    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = futures.Future()
    chain_future(f2, f1)
    f2.set_result(42)
    assert f1.result() == 42

    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = futures.Future()

# Generated at 2022-06-18 09:57:08.322456
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:57:13.970022
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.run()

# Generated at 2022-06-18 09:57:18.529795
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:57:29.312714
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:57:41.688441
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)

# Generated at 2022-06-18 09:57:52.167310
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    try:
        f2.result()
    except ValueError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    assert f1.done()

# Generated at 2022-06-18 09:57:57.728888
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None