

# Generated at 2022-06-18 09:49:28.073742
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:49:37.185212
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_result, 42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_exception, ValueError())
    try:
        f2.result()
        assert False
    except ValueError:
        pass

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback

# Generated at 2022-06-18 09:49:48.187309
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRa

# Generated at 2022-06-18 09:49:50.463104
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())
    assert f.cancelled()

# Generated at 2022-06-18 09:49:53.781105
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    assert future.done()
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()

# Generated at 2022-06-18 09:50:04.141049
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("foo"))

# Generated at 2022-06-18 09:50:07.707402
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b
    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3


# Generated at 2022-06-18 09:50:16.692451
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:50:28.849965
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception())

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.cancel()
            self.assertTrue(f2.cancelled())

           

# Generated at 2022-06-18 09:50:35.260720
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:50:46.249827
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:48.647904
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-18 09:50:59.465231
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop

    class Test(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            return arg + 1

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.test = Test()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:51:12.360594
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    def f(x):
        time.sleep(0.01)
        return x

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

        def test_chain_future_exception(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, b.result)

        def test_chain_future_cancel(self):
            a = Future()
            b = Future()

# Generated at 2022-06-18 09:51:24.826262
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future

# Generated at 2022-06-18 09:51:34.175083
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:51:41.064837
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class Test(unittest.TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            super(Test, self).tearDown()


# Generated at 2022-06-18 09:51:47.612940
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:51:52.050474
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()



# Generated at 2022-06-18 09:52:03.915954
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class Test(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            time.sleep(0.01)
            return a + b

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)

# Generated at 2022-06-18 09:52:17.122817
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:21.739397
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:24.641852
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func():
        return "test_func"
    future = dummy_executor.submit(test_func)
    assert future.result() == "test_func"


# Generated at 2022-06-18 09:52:29.254869
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:39.448511
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f2

# Generated at 2022-06-18 09:52:52.032630
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = Test()
   

# Generated at 2022-06-18 09:52:57.385435
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:53:08.306583
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking_func(self, arg1, arg2):
            time.sleep(0.1)
            return arg1 + arg2

        @run_on_executor
        def blocking_func_with_callback(self, arg1, arg2, callback):
            time.sleep(0.1)
            callback(arg1 + arg2)


# Generated at 2022-06-18 09:53:19.420137
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking(self):
            # type: () -> int
            return 42

        @run_on_executor(executor="executor")
        def blocking_with_executor(self):
            # type: () -> int
            return 42


# Generated at 2022-06-18 09:53:26.760257
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    unittest.main()

# Generated at 2022-06-18 09:54:01.812519
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        def test_run_on_executor(self):
            f = self.func(1, 2)
            self.assertEqual(f.result(), 3)

        @run_on_executor
        def func_exc(self):
            raise Exception("foo")


# Generated at 2022-06-18 09:54:05.788937
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:54:16.553452
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_with_executor(self):
            f1 = self.executor.submit(lambda: 42)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:54:26.808242
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42


# Generated at 2022-06-18 09:54:28.912992
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:54:35.840963
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()

# Generated at 2022-06-18 09:54:42.446039
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:54:50.412897
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.set_result(42)
            f1.set_result(24)

# Generated at 2022-06-18 09:54:55.677551
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            io_loop.run_sync(lambda: f2)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_exception(RuntimeError("test"))
           

# Generated at 2022-06-18 09:55:04.657052
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:55:57.287612
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:56:01.734385
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:56:05.533914
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-18 09:56:15.599748
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_

# Generated at 2022-06-18 09:56:20.985317
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:56:30.696230
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_

# Generated at 2022-06-18 09:56:35.324516
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:56:41.830364
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            future1 = Future()
            future2 = Future()
            chain_future(future1, future2)
            future1.set_result(42)
            self.assertEqual(future2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:56:48.448503
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class TestDummyExecutor(AsyncTestCase):
        def test_submit(self):
            @gen_test
            async def test():
                async def async_fn():
                    return 42

                future = dummy_executor.submit(async_fn)
                self.assertEqual(await future, 42)

            IOLoop.current().run_sync(test)

    test_DummyExecutor_submit()

# Generated at 2022-06-18 09:56:54.374204
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:58:48.898881
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:58:58.649204
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

    test = Test()
    future = test.foo(1, 2)
    assert isinstance(future, Future)
    assert future.result() == 3

    # Test that the executor is used even if the method is called
    # synchronously.
    with unittest.mock.patch.object(test.executor, "submit") as submit:
        test.foo(1, 2)
        submit.assert_called_with(test.foo, 1, 2)

    # Test that the executor is used even if the method is called
    # asynchronously.

# Generated at 2022-06-18 09:59:03.289936
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import threading

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor
        def func_exc(self):
            raise Exception("foo")


# Generated at 2022-06-18 09:59:11.510175
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    loop.run_sync(lambda: f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ZeroDivisionError())
    try:
        loop.run_sync(lambda: f2)
        assert False
    except ZeroDivisionError:
        pass

    f1 = Future()
    f2 = Future()