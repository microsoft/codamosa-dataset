

# Generated at 2022-06-18 09:49:15.668946
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_asyncio(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual((yield f2), 42)


# Generated at 2022-06-18 09:49:19.931787
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:25.157402
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:49:28.108734
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    assert str(future.exception()) == "foo"

# Generated at 2022-06-18 09:49:31.384493
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("test")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None

# Generated at 2022-06-18 09:49:39.120581
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, a, b):
            return a + b

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_executor")
        def func(self, a, b):
            return a + b

    class Test3(object):
        def __init__(self):
            self._executor = dummy_executor

        @run_on_executor(executor="_executor")
        def func(self, a, b):
            return a + b


# Generated at 2022-06-18 09:49:44.260658
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    assert future.exception().args == ("foo",)



# Generated at 2022-06-18 09:49:47.515173
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    future = Future()
    try:
        raise Exception("foo")
    except Exception:
        future_set_exc_info(future, sys.exc_info())
    assert future.exception() is not None
    assert future.exception().args == ("foo",)



# Generated at 2022-06-18 09:49:56.834482
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class Test(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor")
        def func_with_kwargs(self, a, b):
            return a + b


# Generated at 2022-06-18 09:49:59.879630
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-18 09:50:17.018804
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        def test_run_on_executor(self):
            f = self.func(41)
            self.assertEqual(f.result(), 42)

    AsyncIOMainLoop().install()


# Generated at 2022-06-18 09:50:22.451287
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:50:35.476275
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking_func(self):
            time.sleep(0.1)
            return 42

        @gen_test
        def test_run_on_executor(self):
            result = yield self.blocking_func()
            self.assertEqual(result, 42)

    unittest.main()

# Generated at 2022-06-18 09:50:47.335012
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:50:51.513743
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:59.353270
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    ChainFutureTest().run()

# Generated at 2022-06-18 09:51:12.262603
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super(TestRunOnExecutor, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop.current()
            self.io_loop.make_current()
            self.addCleanup(self.executor.shutdown)

        def test_run_on_executor(self):
            @run_on_executor
            def f():
                return 42

            @run_on_executor(executor="executor")
            def g():
                return 42

# Generated at 2022-06-18 09:51:19.652351
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:51:30.455988
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
        assert False
    except ZeroDivisionError:
        pass

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(24)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:51:33.976911
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:51:46.586963
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:57.331464
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_concurrent(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual((yield f2), 42)


# Generated at 2022-06-18 09:52:09.197923
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:52:14.253474
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()



# Generated at 2022-06-18 09:52:20.433070
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:28.977467
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future

# Generated at 2022-06-18 09:52:38.007944
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:50.188674
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import tornado.ioloop
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class TestHandler(tornado.web.RequestHandler):
        executor = concurrent.futures.ThreadPoolExecutor(1)

        @tornado.web.asynchronous
        @tornado.gen.coroutine
        def get(self):
            yield self.sleep()
            self.write("hello")
            self.finish()

        @run_on_executor
        def sleep(self):
            time.sleep(0.1)

    class TestWebSocketHandler(tornado.websocket.WebSocketHandler):
        executor = concurrent.futures.ThreadPoolExecutor(1)


# Generated at 2022-06-18 09:52:56.849045
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:07.820507
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.ioloop import IOLoop

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.done())

# Generated at 2022-06-18 09:53:30.649279
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    with tornado.testing.assert_raises(RuntimeError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()

# Generated at 2022-06-18 09:53:35.859543
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:46.302362
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.platform.asyncio

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = concurrent.futures.Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = concurrent.futures.Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2

# Generated at 2022-06-18 09:53:58.141153
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.executor = dummy_executor

        @run_on_executor
        def func(self, a, b):
            return a + b

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)

        @gen_test
        def test_run_on_executor_with_keyword(self):
            self.executor = "executor"


# Generated at 2022-06-18 09:54:00.119503
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))

# Generated at 2022-06-18 09:54:08.288993
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown(wait=True)
            self.io_loop.close()

        @run_on_executor
        def blocking_func(self, x, y):
            time.sleep(0.01)
            return x + y

        def test_run_on_executor(self):
            f = self.blocking_func(1, 2)
            result = self.io_loop.run_sync(lambda: f)

# Generated at 2022-06-18 09:54:14.396338
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:54:18.888780
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:54:24.326818
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()
    assert future.result() is None

# Generated at 2022-06-18 09:54:30.434987
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:54:59.167142
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())

# Generated at 2022-06-18 09:55:09.161637
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            with self.assertRaises(RuntimeError):
                yield f2

        @gen_test
        def test_chain_future_cancel(self):
            f

# Generated at 2022-06-18 09:55:19.124618
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestCase(AsyncTestCase):
        def setUp(self):
            super(TestCase, self).setUp()
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(42)
            self.assertEqual(result, 42)


# Generated at 2022-06-18 09:55:25.602105
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:55:31.848192
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        raise tornado.gen.Return(42)

    @tornado.gen.coroutine
    def g():
        result = yield f()
        raise tornado.gen.Return(result)

    @tornado.gen.coroutine
    def h():
        result = yield g()
        raise tornado.gen.Return(result)

    @tornado.testing.gen_test
    def test():
        result = yield h()
        assert result == 42

    test()

# Generated at 2022-06-18 09:55:36.063091
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:40.418866
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:55:47.748092
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:55:57.663671
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future

# Generated at 2022-06-18 09:56:06.908164
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:57:14.784256
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_with_executor(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:57:25.669581
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.set_result(42)
            f1.set_result(24)

# Generated at 2022-06-18 09:57:32.949816
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test_chain_future()

# Generated at 2022-06-18 09:57:45.763091
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.obj = Test()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:57:50.207219
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    test_chain_future()

# Generated at 2022-06-18 09:58:01.710123
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.platform.asyncio

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("foo"))

# Generated at 2022-06-18 09:58:09.424389
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f

# Generated at 2022-06-18 09:58:13.260488
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:58:16.718532
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3


# Generated at 2022-06-18 09:58:18.654470
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, RuntimeError("test"))