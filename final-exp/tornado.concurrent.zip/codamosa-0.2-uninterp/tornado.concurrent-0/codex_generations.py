

# Generated at 2022-06-18 09:49:17.515096
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:49:22.467423
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:49:27.158187
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import unittest.mock

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg

    test = Test()
    future = test.func(42)
    assert future.result() == 42



# Generated at 2022-06-18 09:49:36.375081
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:49:41.708882
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:49:51.708461
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg):
            return arg

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(42)
            self.assertEqual(result, 42)

    unittest.main()

# Generated at 2022-06-18 09:49:59.889868
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_result(42)
    chain_future(f1, f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    f1.set_exception(RuntimeError())
    chain_future(f1, f2)
    assert f2.exception() is not None



# Generated at 2022-06-18 09:50:03.869725
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:50:17.018938
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertEqual(f2.exception().args, ("test",))

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            f2.cancel()

# Generated at 2022-06-18 09:50:22.390366
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:50:33.052304
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-18 09:50:42.447785
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test_chain_future()

# Generated at 2022-06-18 09:50:52.201346
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.testing.AsyncTestCase.get_new_ioloop()

        def tearDown(self):
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))

# Generated at 2022-06-18 09:51:05.218347
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with tornado.testing.assert_raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:51:18.395810
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(f2.result(), 42)

                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f1.set_exception(ZeroDivisionError())
                self.assertRaises(ZeroDivisionError, f2.result)

                f1 = Future()
                f2 = Future()
                chain_future(f1, f2)
                f2.cancel()
                f

# Generated at 2022-06-18 09:51:29.600488
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:51:34.816662
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:51:41.371111
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
   

# Generated at 2022-06-18 09:51:46.541186
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:54.042789
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = Test()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:52:15.243427
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-18 09:52:22.476703
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:26.625202
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:32.378218
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    try:
        f2.result()
        assert False, "did not get expected exception"
    except ValueError:
        pass

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(1729)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()


# Generated at 2022-06-18 09:52:39.871633
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

        @gen_test
        def test_chain_future_2(self):
            f1 = self.executor.submit(lambda: 1 / 1)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:52:52.415583
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:52:58.180177
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:09.014133
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_exception(RuntimeError())

# Generated at 2022-06-18 09:53:13.272634
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:26.346737
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = dummy_executor
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.addCleanup(self.io_loop.close)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)



# Generated at 2022-06-18 09:54:05.479258
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

    @tornado.testing.gen_test
    def test_chain_future_concurrent(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)

# Generated at 2022-06-18 09:54:16.259261
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, x, y):
            return x + y

        def test_run_on_executor(self):
            f = self.func(1, 2)
            self.assertEqual(f.result(), 3)

        @run_on_executor
        def func_exc(self):
            raise Exception("foo")


# Generated at 2022-06-18 09:54:18.773639
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(x: int) -> int:
        return x + 1

    future = dummy_executor.submit(foo, 1)
    assert future.result() == 2



# Generated at 2022-06-18 09:54:27.988783
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    def f(x):
        # type: (int) -> int
        return x + 1

    def g(x):
        # type: (int) -> int
        return x * 2

    ioloop = IOLoop.current()
    f1 = ioloop.run_sync(lambda: f(1))
    f2 = ioloop.run_sync(lambda: g(2))
    f3 = Future()  # type: Future[int]
    chain_future(f1, f3)
    chain_future(f2, f3)
    assert ioloop.run_sync(lambda: f3) == 4



# Generated at 2022-06-18 09:54:33.041320
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:54:39.756549
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import tornado.ioloop
    import concurrent.futures

    class Test(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:54:46.643137
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
   

# Generated at 2022-06-18 09:54:49.462630
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-18 09:54:54.909385
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        # type: () -> None
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    test_chain_future_asyncio()
    test_chain_future_concurrent()

# Generated at 2022-06-18 09:55:00.183192
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def f():
        return 1
    future = dummy_executor.submit(f)
    loop.run_until_complete(future)
    assert future.result() == 1
    loop.close()


# Generated at 2022-06-18 09:55:41.493064
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            # type: () -> None
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
           

# Generated at 2022-06-18 09:55:48.883095
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import tornado.testing
    import tornado.gen
    import tornado.platform.asyncio
    import tornado.platform.asyncio

    class RunOnExecutorTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop.set_default_executor(self.executor)

        def tearDown(self):
            self.executor.shutdown()
            super(RunOnExecutorTest, self).tearDown()


# Generated at 2022-06-18 09:55:53.366556
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:56:00.888213
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import time
    import unittest

    from tornado.ioloop import IOLoop

    io_loop = IOLoop()

    def f():
        # type: () -> str
        time.sleep(0.01)
        return "hello"

    def g():
        # type: () -> str
        time.sleep(0.02)
        return "world"

    def h():
        # type: () -> str
        time.sleep(0.03)
        return "!"

    def f_error():
        # type: () -> None
        time.sleep(0.01)
        raise Exception("hello")

    def g_error():
        # type: () -> None
        time.sleep(0.02)
        raise Exception("world")


# Generated at 2022-06-18 09:56:04.753939
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:56:09.203639
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:56:13.620452
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:56:22.115478
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop.current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_future(f2, lambda f: io_loop.stop())
    io_loop.call_later(0.1, f1.set_result, None)
    io_loop.start()
    assert f2.done()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_future(f2, lambda f: io_loop.stop())
    io_loop.call_later(0.1, f1.set_exception, ValueError())
    io_loop.start()


# Generated at 2022-06-18 09:56:26.856917
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()



# Generated at 2022-06-18 09:56:32.099328
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_until_complete(test.test_chain_future())

# Generated at 2022-06-18 09:57:12.259341
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:57:14.357103
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:57:18.965679
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:57:29.843507
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()

# Generated at 2022-06-18 09:57:34.971474
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import gen_test

    @gen_test
    def test_chain_future():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:57:41.994973
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:52.435260
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_failure(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:57:57.626875
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:59.987367
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:08.448202
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRa