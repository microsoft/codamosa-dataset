

# Generated at 2022-06-18 09:49:28.970526
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock
    import tornado.testing

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def foo(self):
            return 42

        @run_on_executor(executor="_thread_pool")
        def bar(self):
            return 42

    foo = Foo()
    foo._thread_pool = dummy_executor

    with unittest.mock.patch.object(dummy_executor, "submit") as submit:
        f = foo.foo()
        assert isinstance(f, Future)
        assert submit.called
        assert submit.call_args[0][0] is foo.foo
        assert submit.call_args[0][1] is foo


# Generated at 2022-06-18 09:49:37.956074
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))

# Generated at 2022-06-18 09:49:45.727953
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:49:54.477860
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import threading

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            self.executor.shutdown(wait=True)

        def test_run_on_executor(self):
            @run_on_executor
            def f(self):
                self.thread_id = threading.current_thread().ident
                return 42

           

# Generated at 2022-06-18 09:50:04.909479
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertFalse(b.done())
            a.set_result(42)
            self.assertEqual(b.result(), 42)

        def test_chain_future_exception(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            self.assertFalse(b.done())

# Generated at 2022-06-18 09:50:17.243755
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            with self.assertRaises(RuntimeError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:50:29.333890
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest_run_loop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor")
        def func2(self, a, b):
            return a + b


# Generated at 2022-06-18 09:50:41.259087
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.a = Future()
            self.b = Future()

        def test_chain_future(self):
            chain_future(self.a, self.b)
            self.a.set_result(42)
            self.assertEqual(self.b.result(), 42)

        def test_chain_future_exception(self):
            chain_future(self.a, self.b)
            self.a.set_exception(RuntimeError("foo"))
            self.assertRaises(RuntimeError, self.b.result)

        def test_chain_future_cancel(self):
            chain_future(self.a, self.b)
            self.a.cancel()


# Generated at 2022-06-18 09:50:51.449831
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)


# Generated at 2022-06-18 09:50:56.608732
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:09.832048
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    f2.cancel()
    assert f2.cancelled()



# Generated at 2022-06-18 09:51:15.504741
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:51:22.904664
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:51:30.112922
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test_chain_future()

# Generated at 2022-06-18 09:51:33.935321
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1, f2 = Future(), Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    test_chain_future()

# Generated at 2022-06-18 09:51:40.955323
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.platform.asyncio
    import tornado.testing
    import tornado.web
    import tornado.websocket

    class TestHandler(tornado.web.RequestHandler):
        executor = dummy_executor

        @run_on_executor
        def get(self):
            return 42

        @run_on_executor
        def post(self):
            raise Exception("error")

    class TestWebSocketHandler(tornado.websocket.WebSocketHandler):
        executor = dummy_executor

        @run_on_executor
        def open(self):
            self.write_message("hello")

    class TestApplication(tornado.web.Application):
        def __init__(self):
            super(TestApplication, self).__init__([(r"/", TestHandler)])

# Generated at 2022-06-18 09:51:45.846764
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-18 09:51:51.696791
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:02.529463
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:52:10.899874
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:52:58.025138
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def f():
        return 1
    future = dummy_executor.submit(f)
    assert isinstance(future, Future)
    assert future.result() == 1
    future = dummy_executor.submit(f, 1, 2, 3)
    assert isinstance(future, Future)
    assert future.result() == 1
    future = dummy_executor.submit(f, a=1, b=2, c=3)
    assert isinstance(future, Future)
    assert future.result() == 1
    def f():
        raise Exception('test')
    future = dummy_exec

# Generated at 2022-06-18 09:53:03.027156
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:09.062140
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing
    import tornado.gen

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:53:20.185778
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ValueError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(24)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f

# Generated at 2022-06-18 09:53:27.127001
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import gen_test

    @gen_test
    def test_chain_future():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:53:31.626785
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:42.992546
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_with_executor(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)

# Generated at 2022-06-18 09:53:47.138295
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:53:51.615300
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado.testing import AsyncTestCase, gen_test

    class FutureSetExceptionUnlessCancelledTest(AsyncTestCase):
        @gen_test
        def test_future_set_exception_unless_cancelled(self):
            future = Future()
            future_set_exception_unless_cancelled(future, Exception())
            with self.assertRaises(Exception):
                yield future

    test = FutureSetExceptionUnlessCancelledTest()
    test.test_future_set_exception_unless_cancelled()

# Generated at 2022-06-18 09:53:54.070783
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:54:40.490547
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    loop.run_sync(lambda: f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(RuntimeError())
    with pytest.raises(RuntimeError):
        loop.run_sync(lambda: f2)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

# Generated at 2022-06-18 09:54:50.380557
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:54:54.173255
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:55:03.448273
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super(TestRunOnExecutor, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(TestRunOnExecutor, self).tearDown()

        @run_on_executor
        def blocking_func(self, x, y):
            time.sleep(0.01)
            return x + y


# Generated at 2022-06-18 09:55:06.295024
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3


# Generated at 2022-06-18 09:55:17.286615
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    if sys.version_info >= (3, 5):
        # asyncio.Future is not available on Python 2.
        class AsyncChainFutureTest(AsyncTestCase):
            @gen_test
            def test_chain(self):
                f1 = asyncio.Future()
                f2 = asyncio.Future()
                chain_future(f1, f2)
                f1.set_result(42)

# Generated at 2022-06-18 09:55:25.797560
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:55:34.077114
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f

# Generated at 2022-06-18 09:55:35.836247
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func():
        return 1
    dummy_executor.submit(test_func)


# Generated at 2022-06-18 09:55:40.553481
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:56:40.753881
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:56:44.696349
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:56:46.991066
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()

# Generated at 2022-06-18 09:56:51.116941
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future.cancel()
    future_set_result_unless_cancelled(future, 2)
    assert future.cancelled()
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 2)
    assert future.cancelled()

# Generated at 2022-06-18 09:57:00.317386
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            # type: () -> None
            f1

# Generated at 2022-06-18 09:57:06.505980
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def test_func(a, b):
        return a + b
    future = dummy_executor.submit(test_func, 1, 2)
    loop.run_until_complete(future)
    assert future.result() == 3
    loop.close()


# Generated at 2022-06-18 09:57:10.900617
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:14.784997
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:21.352321
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:57:31.805932
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)
