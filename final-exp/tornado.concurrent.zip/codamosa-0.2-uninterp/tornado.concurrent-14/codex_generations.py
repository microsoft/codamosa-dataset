

# Generated at 2022-06-18 09:49:13.303420
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:17.707438
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()

# Generated at 2022-06-18 09:49:21.982509
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:27.924155
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    IOLoop.current().run_sync(lambda: unittest.main())

# Generated at 2022-06-18 09:49:32.241473
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:49:36.054943
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:40.443956
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)



# Generated at 2022-06-18 09:49:45.887420
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()

# Generated at 2022-06-18 09:49:53.256739
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, x, y):
            time.sleep(0.01)
            return x + y

        def test_run_on_executor(self):
            f = self.func(1, 2)
            self.assertEqual(f.result(), 3)

    unittest.main()

# Generated at 2022-06-18 09:50:03.598594
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())

# Generated at 2022-06-18 09:50:21.120637
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set

# Generated at 2022-06-18 09:50:22.200500
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(x):
        return x + 1
    future = dummy_executor.submit(f, 1)
    assert future.result() == 2

# Generated at 2022-06-18 09:50:36.142590
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()

# Generated at 2022-06-18 09:50:42.384123
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

    test_chain_future()

# Generated at 2022-06-18 09:50:52.140608
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import tornado.testing
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.platform.asyncio
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)


# Generated at 2022-06-18 09:51:05.167913
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import threading

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:51:18.395886
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time
    import concurrent.futures

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            self.executor.shutdown()

        @run_on_executor
        def blocking_func(self):
            time.sleep(0.01)
            return 42

        def test_run_on_executor(self):
            result = self.blocking

# Generated at 2022-06-18 09:51:29.186843
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_exception(RuntimeError())
            with self.assertRaises(RuntimeError):
                f2.result()

    unittest.main()

# Generated at 2022-06-18 09:51:37.513841
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    def f1():
        # type: () -> int
        return 42

    def f2(x):
        # type: (int) -> str
        return str(x)

    def f3(x):
        # type: (str) -> None
        assert x == "42"

    f1_done = Future()
    f2_done = Future()
    f3_done = Future()

    chain_future(f1_done, f2_done)
    chain_future(f2_done, f3_done)

    loop.add_future(f1_done, lambda f: f1_done.set_result(f1()))

# Generated at 2022-06-18 09:51:47.409970
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    def thread_func(future):
        time.sleep(0.1)
        future.set_result(42)

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            future1 = Future()
            future2 = Future()
            chain_future(future1, future2)
            thread = threading.Thread(target=thread_func, args=(future1,))
            thread.start()
            future2.result()
            self.assertEqual(future2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:04.756588
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def f(self):
            return 42

        @run_on_executor(executor='_thread_pool')
        def g(self):
            return 42

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.t = Test()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:52:08.709743
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:52:17.703094
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ValueError())
            self.assertRaises(ValueError, f2.result)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)


# Generated at 2022-06-18 09:52:24.458581
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    TestChainFuture().test_chain_future()

# Generated at 2022-06-18 09:52:27.845711
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))

# Generated at 2022-06-18 09:52:33.501375
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def f(self):
            return 42

        @run_on_executor(executor="_executor")
        def g(self):
            return 42

    class TestFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.t = Test()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:52:40.925591
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test_chain_future()

# Generated at 2022-06-18 09:52:49.160231
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:53:01.798955
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(TestChainFuture, self).tearDown()

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1

# Generated at 2022-06-18 09:53:08.359081
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:53:26.666686
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42

    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()



# Generated at 2022-06-18 09:53:33.819707
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_until_complete(test.test_chain_future())

# Generated at 2022-06-18 09:53:44.843735
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()



# Generated at 2022-06-18 09:53:49.643977
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:54:00.961923
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = dummy_executor
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            super(Test, self).tearDown()

        @run_on_executor
        def func(self, a, b):
            return a + b


# Generated at 2022-06-18 09:54:10.983850
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking_func(self):
            # type: () -> int
            return 42

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = self.blocking_func()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:54:14.728857
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()

# Generated at 2022-06-18 09:54:26.006554
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_callback(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            result = [None]


# Generated at 2022-06-18 09:54:32.047610
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:54:35.572585
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:13.781289
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

    unittest.main()

# Generated at 2022-06-18 09:55:17.533561
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:55:26.016167
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    try:
        f2.result()
    except RuntimeError:
        pass
    else:
        assert False, "did not propagate exception"
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()

# Generated at 2022-06-18 09:55:29.604816
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:33.346537
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:55:36.033095
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:43.307982
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    future_set_result_unless_cancelled(future, 2)
    assert future.result() == 1


# Generated at 2022-06-18 09:55:48.384118
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:55:57.716544
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:56:04.085128
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:57:22.329982
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f

# Generated at 2022-06-18 09:57:32.978510
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(24)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:57:45.126182
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        def test_run_on_executor(self):
            future = self.func(1, 2)
            self.assertEqual(self.io_loop.run_sync(future), 3)

    unittest.main()

# Generated at 2022-06-18 09:57:56.140600
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self, executor):
            self.executor = executor

        @run_on_executor
        def f(self):
            return 42

        @run_on_executor(executor="_executor")
        def g(self):
            return 42

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)
            self.test = Test(self.executor)
            self.test._executor = self.executor

        def tearDown(self):
            self

# Generated at 2022-06-18 09:58:03.483449
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:58:10.598774
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:58:17.093787
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking_func(self):
            time.sleep(0.01)
            return 42

        @run_on_executor
        def blocking_func_exc(self):
            time.sleep(0.01)
            raise Exception("foo")

        @run_on_executor
        def blocking_func_exc_with_result(self):
            time

# Generated at 2022-06-18 09:58:25.745523
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:58:27.102153
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(x):
        return x + 1
    future = dummy_executor.submit(foo, 1)
    assert future.result() == 2

# Generated at 2022-06-18 09:58:36.773953
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    @tornado.testing.gen_test
    def test_chain_future_asyncio_to_concurrent():
        f1 = Future()
        f2 = futures.Future()
        chain_