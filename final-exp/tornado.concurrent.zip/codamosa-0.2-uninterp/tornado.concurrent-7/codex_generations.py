

# Generated at 2022-06-18 09:49:14.770919
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:49:24.047382
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:49:30.506983
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:49:36.486491
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    loop.make_current()
    future = dummy_executor.submit(lambda: 1)
    assert future.result() == 1
    future = dummy_executor.submit(lambda: 1 / 0)
    try:
        future.result()
    except ZeroDivisionError:
        pass
    else:
        assert False
    loop.close()

# Generated at 2022-06-18 09:49:48.052952
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception())

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_

# Generated at 2022-06-18 09:49:57.549182
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f2

# Generated at 2022-06-18 09:50:00.447574
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:13.198416
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest_run_loop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        @run_on_executor(executor="_executor")
        def func2(self, arg):
            return arg + 1



# Generated at 2022-06-18 09:50:25.453409
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(MyTestCase, self).tearDown()

        @run_on_executor
        def blocking_func(self):
            time.sleep(0.1)
            return 42

        @gen_test
        def test_run_on_executor(self):
            result = yield self.blocking_func()
            self

# Generated at 2022-06-18 09:50:34.341172
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = Test()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:50:46.453415
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:50:54.117480
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super(TestRunOnExecutor, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(41)
            self.assertEqual(result, 42)

        @gen_test
        def test_run_on_executor_with_callback(self):
            self.func(41, callback=(yield gen.Callback("callback")))
            result = yield gen

# Generated at 2022-06-18 09:51:02.813364
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        yield tornado.gen.moment

    @tornado.gen.coroutine
    def g():
        yield tornado.gen.moment

    @tornado.testing.gen_test
    def test():
        f1 = f()
        f2 = Future()
        chain_future(f1, f2)
        g1 = g()
        g2 = Future()
        chain_future(g1, g2)
        yield [f2, g2]

    test()

# Generated at 2022-06-18 09:51:16.280022
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)

# Generated at 2022-06-18 09:51:21.303603
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:31.798290
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest_run_loop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = dummy_executor

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="executor")
        def func_with_executor_arg(self, a, b):
            return a + b

        @run_on_executor
        def func_with_callback(self, a, b, callback):
            callback(a + b)


# Generated at 2022-06-18 09:51:39.501712
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run_on_executor(self):
            @run_on_executor
            def f(self):
                return 42

            @run_on_executor(executor="executor")
            def g(self):
                return 42

            @run_on_executor(executor="_executor")
            def h(self):
                return 42


# Generated at 2022-06-18 09:51:45.270693
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:51:50.546296
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class FutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:52:01.220527
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import tornado.testing

    class RunOnExecutorTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(RunOnExecutorTest, self).tearDown()

        @run_on_executor
        def func(self, arg):
            return arg

        @run_on_executor(executor="executor")
        def func2(self, arg):
            return arg


# Generated at 2022-06-18 09:52:10.314775
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()


# Generated at 2022-06-18 09:52:14.600823
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:52:19.378803
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:24.508745
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is not None
    assert future.exception().args == ("test",)
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:52:30.986495
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    loop = IOLoop()
    loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cance

# Generated at 2022-06-18 09:52:39.343206
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    io_loop = IOLoop()
    io_loop.make_current()
    try:
        unittest.main()
    finally:
        io_loop.clear_current()
        io_loop.close(all_fds=True)
        time.sleep(0.1)

# Generated at 2022-06-18 09:52:51.973175
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def f(self, x, y):
            return x + y

        @run_on_executor(executor="executor")
        def g(self, x, y):
            return x + y

        @run_on_executor(executor="_thread_pool")
        def h(self, x, y):
            return x + y

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

# Generated at 2022-06-18 09:53:03.841369
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import gen_test, AsyncTestCase

    class TestCase(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                f2.result()

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()

# Generated at 2022-06-18 09:53:09.393596
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:53:15.698866
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()


if __name__ == "__main__":
    test_chain_future()

# Generated at 2022-06-18 09:53:25.360805
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def f(x):
        return x + 1

    future = dummy_executor.submit(f, 1)
    assert future.result() == 2

# Generated at 2022-06-18 09:53:36.122547
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:53:46.567522
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:53:58.409314
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg + 1

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self, arg):
            return arg + 1

    class Test3(object):
        def __init__(self):
            self._thread_pool = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def func(self, arg):
            return arg + 1


# Generated at 2022-06-18 09:54:01.953025
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()

# Generated at 2022-06-18 09:54:07.637725
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:54:14.438298
# Unit test for function chain_future
def test_chain_future():
    import time

    @gen.coroutine
    def f():
        yield gen.moment

    @gen.coroutine
    def f2():
        yield gen.moment

    f1 = f()
    f2 = f2()
    chain_future(f1, f2)
    f1.set_result(42)
    time.sleep(0.1)
    assert f2.result() == 42



# Generated at 2022-06-18 09:54:19.146139
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()

    def f():
        # type: () -> int
        return 42

    def g(future):
        # type: (Future[int]) -> None
        assert future.result() == 42
        loop.stop()

    future = Future()
    chain_future(loop.run_in_executor(None, f), future)
    future.add_done_callback(g)
    loop.start()

# Generated at 2022-06-18 09:54:24.372353
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:54:28.027399
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:54:37.191819
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:54:38.301399
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def foo(a, b):
        return a + b

    future = dummy_executor.submit(foo, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:54:42.949227
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:54:46.761297
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_until_complete(test.test_chain_future())

# Generated at 2022-06-18 09:54:51.142097
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:54:56.100425
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:01.349759
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:06.008314
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:55:14.142045
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:55:16.865121
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, None)
    future.cancel()
    future_set_result_unless_cancelled(future, None)

# Generated at 2022-06-18 09:55:31.813929
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:42.030411
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg):
            return arg + 1

        @run_on_executor(executor="_executor")
        def func_with_executor(self, arg):
            return arg + 1


# Generated at 2022-06-18 09:55:47.091989
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:57.197047
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Test(unittest.TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            super(Test, self).tearDown()

        @run_on_executor
        def func(self, a, b):
            return a + b


# Generated at 2022-06-18 09:56:05.661904
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(RuntimeError("foo"))
            with self.assertRaises(RuntimeError):
                yield g

    unittest.main()

# Generated at 2022-06-18 09:56:10.806821
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:56:19.962744
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class Test(unittest.TestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)
            super(Test, self).tearDown()


# Generated at 2022-06-18 09:56:23.810011
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()
    assert f.result() is None

# Generated at 2022-06-18 09:56:30.658227
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:56:35.324580
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:57:14.706014
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            time.sleep(0.01)
            return arg

        @gen_test
        def test_chain_future(self):
            f1 = self.func(1)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:57:19.872399
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:57:30.236917
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio_future():
        # type: () -> None
        future1 = Future()  # type: Future[int]
        future2 = Future()  # type: Future[int]
        chain_future(future1, future2)
        future1.set_result(42)
        self.assertEqual(42, (yield future2))

    @tornado.testing.gen_test
    def test_chain_future_concurrent_future():
        # type: () -> None
        future1 = futures.Future()  # type: futures.Future[int]
        future2 = Future()  # type: Future[int]
        chain_future(future1, future2)
        future1

# Generated at 2022-06-18 09:57:42.563691
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            with self.assertRaises(RuntimeError):
                f2.result()

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:57:53.686609
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(ChainFutureTest, self).tearDown()

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:57:56.552587
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:58:06.197914
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()

# Generated at 2022-06-18 09:58:10.770205
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:15.732141
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test_chain_future()

# Generated at 2022-06-18 09:58:22.214819
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test_chain_future()