

# Generated at 2022-06-18 09:49:14.975883
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:49:18.998678
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:24.750896
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:49:33.801911
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # Test that chain_future works with both Tornado and asyncio Futures
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = futures.Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = futures.Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = futures.Future()
    f2 = futures.Future()
    chain_future(f1, f2)

# Generated at 2022-06-18 09:49:37.187540
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-18 09:49:48.186929
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exc(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)


# Generated at 2022-06-18 09:49:57.679580
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:50:04.171509
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    try:
        f2.result()
    except ValueError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
   

# Generated at 2022-06-18 09:50:17.470156
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("exception"))
            self.assertEqual(str(f2.exception()), "exception")
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:50:30.095738
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()

        @run_on_executor
        def func(self, arg):
            return arg

    test = Test()
    f = test.func(1)
    assert isinstance(f, Future)
    assert f.result() == 1

    @run_on_executor
    def func2(arg):
        return arg

    f = func2(2)
    assert isinstance(f, Future)
    assert f.result() == 2


# Generated at 2022-06-18 09:50:40.132465
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:51.213902
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(None)
            self.assertTrue(f2.done())

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.done())
            self.assertTrue(f2.exception())

        def test_chain_future_cancel(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:51:04.108625
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:51:10.171573
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:51:15.394799
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:24.140699
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:51:31.352351
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.run()

# Generated at 2022-06-18 09:51:34.175162
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42



# Generated at 2022-06-18 09:51:43.375807
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.test.util import unittest

    class RunOnExecutorTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)


# Generated at 2022-06-18 09:51:52.004958
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield g

    unittest.main()

# Generated at 2022-06-18 09:52:07.955933
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import concurrent.futures

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)

# Generated at 2022-06-18 09:52:11.758974
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.gen

    class TestChainFuture(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            executor = concurrent.futures.ThreadPoolExecutor(1)
            f1 = executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            self.assertRaises(ZeroDivisionError, f2.result)

    tornado.testing.main()

# Generated at 2022-06-18 09:52:17.183329
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:21.787502
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:29.809883
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def blocking_func(self):
            time.sleep(0.1)
            return 42

        @run_on_executor(executor='executor')
        def blocking_func_with_executor(self):
            time.sleep(0.1)
            return 42


# Generated at 2022-06-18 09:52:39.864971
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.set_exception(RuntimeError("test"))
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()

    chain_future(f1, f2)

    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

    chain

# Generated at 2022-06-18 09:52:52.409328
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def fn(x: int, y: int) -> int:
        return x + y

    future = dummy_executor.submit(fn, 1, 2)
    assert future.result() == 3

    future = dummy_executor.submit(fn, 1, y=2)
    assert future.result() == 3

    future = dummy_executor.submit(fn, x=1, y=2)
    assert future.result() == 3

    future = dummy_executor.submit(fn, x=1, y=2)
    assert future.result() == 3

    future = dummy_executor.submit(fn, 1, y=2)
    assert future.result() == 3

    future = dummy_executor.submit(fn, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:53:04.299236
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Foo(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def bar(self):
            return 42

        @run_on_executor(executor="_thread_pool")
        def baz(self):
            return 42

    foo = Foo()
    foo._thread_pool = dummy_executor
    IOLoop.configure(AsyncIOMainLoop)
    loop = IOLoop.current()
    f = foo.bar()
    loop.add_future(f, lambda f: loop.stop())
    loop.start()
    assert f.result() == 42
    f = foo.baz()
    loop

# Generated at 2022-06-18 09:53:08.641494
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:12.494154
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:53:20.743572
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-18 09:53:32.590175
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            # type: () -> None
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())

# Generated at 2022-06-18 09:53:43.799315
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def blocking_func(self, arg1, arg2):
            time.sleep(0.1)
            return arg1 + arg2


# Generated at 2022-06-18 09:53:53.752314
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def test_chain(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

        def test_chain_cancel(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            b.cancel()
            self.assertTrue(b.cancelled())
            self.assertFalse(b.done())

        def test_chain_cancel_before(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            b

# Generated at 2022-06-18 09:53:59.026939
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:54:05.872625
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            # type: () -> None
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            # type: () -> None
            self.executor.shutdown()

        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:54:16.625829
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:54:26.809084
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.assertIs(self.io_loop, IOLoop.current())
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:54:33.277147
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(RuntimeError("test"))
            self.assertEqual(b.exception().args, ("test",))

            a = Future()
            b = Future()
            chain_future(a, b)
            b.set_result(42)
            a.set

# Generated at 2022-06-18 09:54:43.973901
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    f2.cancel()
    assert f2.cancelled()
    assert f2.exception() is None


# Generated at 2022-06-18 09:55:06.454763
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:55:12.467692
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:55:21.102944
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.ioloop.IOLoop()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)

    tornado.testing.main()

# Generated at 2022-06-18 09:55:26.639522
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:55:29.909847
# Unit test for function run_on_executor
def test_run_on_executor():
    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def bar(self):
            return 42

    foo = Foo()
    future = foo.bar()
    assert future.result() == 42



# Generated at 2022-06-18 09:55:36.685729
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import tornado.gen

    class Test(unittest.TestCase):
        def setUp(self):
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @tornado.gen.coroutine
        def test_run_on_executor(self):
            future = self.func(1, 2)
            self.assertIsInstance(future, tornado.concurrent.Future)
            result = yield future
            self.assertEqual(result, 3)

    tornado.testing.main()

# Generated at 2022-06-18 09:55:46.585252
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:55:56.980820
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception())

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result

# Generated at 2022-06-18 09:56:03.137959
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:56:13.320303
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:56:34.362023
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:56:41.099443
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:56:49.395752
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super(TestRunOnExecutor, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(TestRunOnExecutor, self).tearDown()

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:56:51.458444
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:56:57.136888
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

        @gen_test
        def test_chain_future_2(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:57:01.608088
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:05.145725
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:57:14.552941
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg):
            return arg

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func("test")
            self.assertEqual(result, "test")


# Generated at 2022-06-18 09:57:19.170614
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:57:23.257263
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

# Generated at 2022-06-18 09:57:59.881473
# Unit test for function chain_future
def test_chain_future():
    def f(x):
        return x + 1

    def g(x):
        return x * 2

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(ZeroDivisionError())
    try:
        b.result()
        assert False
    except ZeroDivisionError:
        pass

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(b, c)
    a.set_result(1)
    assert b.result() == 1
    assert c.result() == 1

    a = Future()

# Generated at 2022-06-18 09:58:04.460999
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:10.972148
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking(self):
            return 42

        @gen_test
        def test_blocking(self):
            result = yield self.blocking()
            self.assertEqual(result, 42)

    unittest.main()

# Generated at 2022-06-18 09:58:14.243301
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:58:24.306516
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
           

# Generated at 2022-06-18 09:58:25.801817
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-18 09:58:31.626773
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future_set_result_unless_cancelled(future, "bar")
    assert future.result() == "foo"
    future.cancel()
    future_set_result_unless_cancelled(future, "bar")
    assert future.cancelled()

# Generated at 2022-06-18 09:58:35.510579
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:45.108593
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    f2.cancel()
    assert f2.exception() is None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set

# Generated at 2022-06-18 09:58:49.058417
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()