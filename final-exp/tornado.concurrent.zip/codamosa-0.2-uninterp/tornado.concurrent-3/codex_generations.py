

# Generated at 2022-06-18 09:49:21.538516
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    def f():
        time.sleep(0.1)
        return 42

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            executor = futures.ThreadPoolExecutor(1)
            a = executor.submit(f)
            b = Future()
            chain_future(a, b)
            self.assertEqual(b.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:49:31.185821
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:49:36.329927
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:49:47.849347
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_

# Generated at 2022-06-18 09:49:51.536814
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:55.572232
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:50:02.899499
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_with_executor(self):
            f1 = self.executor.submit(lambda: 42)
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:50:11.849553
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:50:20.633109
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class MyTestCase(AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)

    unittest.main()

# Generated at 2022-06-18 09:50:24.989083
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3


# Generated at 2022-06-18 09:50:38.819392
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:50:45.443322
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:50:53.305166
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, a, b):
            return a + b

        def test_run_on_executor(self):
            future = self.func(1, 2)
            self.assertEqual(self.io_loop.run_sync(future), 3)

    unittest.main()

# Generated at 2022-06-18 09:51:00.897669
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import gen_test, AsyncTestCase

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:51:07.354069
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()


# Generated at 2022-06-18 09:51:19.871527
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def f(self):
            return 42

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor='_executor')
        def f(self):
            return 42

    class Test3(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor='_executor')
        def f(self):
            return 42

        def g(self):
            return self.f()



# Generated at 2022-06-18 09:51:30.620065
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def test_func(a, b):
        return a + b
    def test_func_exception(a, b):
        raise Exception("test_func_exception")
    def test_func_exception_with_traceback(a, b):
        try:
            raise Exception("test_func_exception")
        except Exception as e:
            raise e

# Generated at 2022-06-18 09:51:34.095894
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:51:39.747192
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            io_loop.add_future(f2, lambda f: self.stop(f.result()))
            self.assertEqual(42, self.wait())

    unittest.main()

# Generated at 2022-06-18 09:51:46.792024
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:52:07.803249
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))

# Generated at 2022-06-18 09:52:10.367236
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-18 09:52:18.380714
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(42, f2.result())

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:52:26.414207
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            loop.add_future(f2, lambda f: self.stop(f.result()))
            self.assertEqual(42, self.wait())

    test_chain_future.__test__ = False  # type: ignore
    unittest.main()

# Generated at 2022-06-18 09:52:38.335984
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    loop = IOLoop()
    loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cance

# Generated at 2022-06-18 09:52:43.418417
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:48.723197
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:52:57.013201
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.platform.asyncio import AsyncIOMainLoop

    AsyncIOMainLoop().install()

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:53:02.017483
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:10.435306
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import concurrent.futures

    class Test(object):
        def __init__(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            time.sleep(0.01)
            return a + b

    class TestCase(unittest.TestCase):
        def test_run_on_executor(self):
            test = Test()
            future = test.func(1, 2)
            self.assertEqual(future.result(), 3)

    unittest.main()

# Generated at 2022-06-18 09:53:29.437316
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    future1 = Future()
    future2 = Future()
    chain_future(future1, future2)
    future1.set_result(42)
    assert future2.result() == 42

    future3 = Future()
    future4 = Future()
    chain_future(future3, future4)
    future3.set_exception(RuntimeError())
    try:
        future4.result()
    except RuntimeError:
        pass
    else:
        assert False, "did not propagate exception"



# Generated at 2022-06-18 09:53:32.162799
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:53:37.695158
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:47.463100
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:53:52.800619
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:54:02.940198
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.set_result(42)
            f1.set_result(24)

# Generated at 2022-06-18 09:54:08.286579
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:54:18.248629
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.testing import AsyncTestCase, gen_test

    class Foo(object):
        def __init__(self, io_loop):
            self.executor = dummy_executor
            self.io_loop = io_loop

        @run_on_executor
        def bar(self):
            return 42

        @run_on_executor(executor="executor")
        def baz(self):
            return 42

    @run_on_executor
    def function(x, y):
        return x + y

    @gen_test
    def test_foo():
        foo = Foo(IOLoop.current())

# Generated at 2022-06-18 09:54:25.054270
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:54:33.119709
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:55:14.719507
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = Test()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:55:22.981783
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools

    from tornado.ioloop import IOLoop

    def f(x):
        return x * 10

    def g(x):
        return x + "foo"

    def h(x):
        raise Exception("foo")

    def i(x):
        return x

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)

# Generated at 2022-06-18 09:55:32.277053
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f1

# Generated at 2022-06-18 09:55:38.537797
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:48.997841
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest.mock

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg + 1

    foo = Foo()
    future = foo.func(1)
    assert future.result() == 2

    # Test that the executor is configurable
    foo.executor = unittest.mock.Mock()
    foo.func(1)
    foo.executor.submit.assert_called_with(foo.func, foo, 1)

    # Test that the executor attribute is configurable
    foo.executor = unittest.mock.Mock()
    foo.func = run_on_executor(executor="_thread_pool")(foo.func)

# Generated at 2022-06-18 09:55:57.521372
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:56:01.397192
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:56:11.544738
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, f2.result)


# Generated at 2022-06-18 09:56:14.683659
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:56:18.649609
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-18 09:57:48.796816
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self

# Generated at 2022-06-18 09:57:59.926398
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, a, b):
            return a + b

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_executor")
        def func(self, a, b):
            return a + b

    class Test3(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_executor")
        def func(self, a, b):
            raise Exception("foo")


# Generated at 2022-06-18 09:58:07.933387
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()

# Generated at 2022-06-18 09:58:15.759146
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def foo(self, a, b):
            return a + b

    class Test2(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def foo(self, a, b):
            return a + b

    class Test3(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor(executor="_thread_pool")
        def foo(self, a, b):
            return a + b


# Generated at 2022-06-18 09:58:23.676754
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()

# Generated at 2022-06-18 09:58:29.543045
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    import tornado.testing
    import tornado.platform.asyncio
    import tornado.platform.asyncio

    class MyTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(MyTestCase, self).tearDown()

        @run_on_executor
        def blocking_func(self, arg):
            time.sleep(0.1)
            return arg


# Generated at 2022-06-18 09:58:39.393776
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    import asyncio

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
                f1 = concurrent.futures.Future()
                f2 = asyncio.Future()
                chain_future(f1, f2)
                f1.set_result(42)
                self.assertEqual(f2.result(), 42)

                f1 = concurrent.futures.Future()
                f2 = asyncio.Future()
                chain_future(f1, f2)
                f1.set_exception(ValueError())
                self.assertRaises(ValueError, f2.result)

                f1 = concurrent.futures.Future()
               

# Generated at 2022-06-18 09:58:42.956763
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:58:46.602556
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:58:49.552103
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None