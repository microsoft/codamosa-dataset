

# Generated at 2022-06-18 09:49:20.903439
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            io_loop = IOLoop()
            io_loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertEqual(f2.exception().args, ("test",))

            f1 = Future()
            f2 = Future()
            f3 = Future()

# Generated at 2022-06-18 09:49:25.234826
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:49:31.388190
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        yield tornado.gen.moment

    @tornado.gen.coroutine
    def g():
        yield tornado.gen.moment

    @tornado.testing.gen_test
    def test_chain_future():
        f_future = f()
        g_future = g()
        chain_future(f_future, g_future)
        yield g_future

    test_chain_future()

# Generated at 2022-06-18 09:49:39.148739
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()

# Generated at 2022-06-18 09:49:49.724382
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg):
            return arg


# Generated at 2022-06-18 09:49:53.736784
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:50:04.097219
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import functools

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:50:17.362551
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run_on_executor(self):
            @run_on_executor
            def f(self):
                return 42

            @run_on_executor(executor="executor")
            def g(self):
                return 42

            @run_on_executor(executor="_executor")
            def h(self):
                return 42


# Generated at 2022-06-18 09:50:29.932219
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()

            def callback(f):
                self.assertEqual(f, f1)
                self.assertFalse(f2.done())
                f2.set_result(None)


# Generated at 2022-06-18 09:50:41.121339
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, x):
            # type: (int) -> int
            return x + 1

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f = self.func(1)
            g = Future()
            chain_future(f, g)

# Generated at 2022-06-18 09:50:50.594041
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    loop = IOLoop.current()
    def test_func(a, b):
        return a + b
    future = dummy_executor.submit(test_func, 1, 2)
    loop.run_until_complete(future)
    assert future.result() == 3
    loop.close()


# Generated at 2022-06-18 09:50:56.826807
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        yield tornado.gen.moment

    @tornado.gen.coroutine
    def g():
        yield tornado.gen.moment

    f1 = f()
    f2 = g()
    chain_future(f1, f2)
    tornado.testing.gen_test(f2)

# Generated at 2022-06-18 09:51:01.933040
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 42)
    assert f.result() == 42
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 42)
    assert f.cancelled()



# Generated at 2022-06-18 09:51:10.431718
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:51:13.814548
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:51:18.875319
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:29.900539
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.platform.asyncio import AsyncIOMainLoop

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.io_loop = AsyncIOMainLoop()
            self.io_loop.make_current()

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.setUp()


# Generated at 2022-06-18 09:51:38.090674
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class MyTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(MyTestCase, self).tearDown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)

    unittest.main()

# Generated at 2022-06-18 09:51:41.962050
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b

    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:51:52.249335
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class RunOnExecutorTest(AsyncTestCase):
        def setUp(self):
            super(RunOnExecutorTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(RunOnExecutorTest, self).tearDown()

        @run_on_executor
        def func(self, arg):
            return arg

        @gen_test
        def test_run_on_executor(self):
            result = yield self.func(42)
            self.assertEqual

# Generated at 2022-06-18 09:52:07.588741
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:52:16.119119
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:26.226482
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            loop = IOLoop()
            loop.make_current()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertTrue(f2.exception())

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.c

# Generated at 2022-06-18 09:52:38.007479
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ZeroDivisionError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    f1.set_result(24)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:52:50.188778
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:52:57.704462
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:53:08.597523
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.assertEqual(arg1, 1)
            self.assertEqual(arg2, 2)

# Generated at 2022-06-18 09:53:19.704202
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertRaises(RuntimeError, f2.result)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)

# Generated at 2022-06-18 09:53:31.290239
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import concurrent.futures
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(ChainFutureTest, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            # type: () -> None
            self.executor.shutdown()
            super(ChainFutureTest, self).tearDown()

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)


# Generated at 2022-06-18 09:53:37.033151
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception('test'))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception('test'))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:51.307164
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop

    class Test(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = dummy_executor

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        @run_on_executor
        def func(self, a, b):
            return a + b

        @run_on_executor(executor="_executor")
        def func2(self, a, b):
            return a + b


# Generated at 2022-06-18 09:53:56.671074
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:54:04.612185
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor
            self.io_loop = IOLoop()

        @run_on_executor
        def func(self, a, b):
            return a + b

    test = Test()
    future = test.func(1, 2)
    assert isinstance(future, Future)
    assert future.result() == 3

    # Test that the executor is actually used.
    future = test.func(1, 2)
    assert isinstance(future, Future)
    assert not future.done()
    threading.Thread(target=future.set_result, args=(3,)).start()
    assert future.result() == 3

    #

# Generated at 2022-06-18 09:54:15.552631
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing
    import tornado.gen

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop = tornado.ioloop.IOLoop()

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @tornado.gen.coroutine
        def test_run_on_executor(self):
            @run_on_executor
            def f(self):
                return 42

            result = yield f(self)
            self.assertEqual(result, 42)


# Generated at 2022-06-18 09:54:17.986488
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, Exception())

# Generated at 2022-06-18 09:54:23.025063
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:54:32.175208
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing
    import tornado.platform.asyncio

    tornado.platform.asyncio.AsyncIOMainLoop().install()

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        self.assertEqual(f2.result(), 42)

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        # type: () -> None
        f1 = futures.Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)

# Generated at 2022-06-18 09:54:39.159791
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)


# Generated at 2022-06-18 09:54:46.273564
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.set_result(42)
            f1.set_result(24)
            self.assertEqual

# Generated at 2022-06-18 09:54:52.456638
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def setUp(self):
            super(ChainFutureTest, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())

# Generated at 2022-06-18 09:55:15.156799
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        raise tornado.gen.Return(42)

    @tornado.gen.coroutine
    def g():
        result = yield f()
        raise tornado.gen.Return(result)

    @tornado.gen.coroutine
    def h():
        result = yield g()
        raise tornado.gen.Return(result)

    @tornado.testing.gen_test
    def test():
        result = yield h()
        assert result == 42

    test()

# Generated at 2022-06-18 09:55:20.376347
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        yield tornado.gen.moment

    @tornado.gen.coroutine
    def g():
        yield tornado.gen.moment

    @tornado.testing.gen_test
    def test_chain():
        f1 = f()
        f2 = g()
        chain_future(f1, f2)
        yield f2

    test_chain()

# Generated at 2022-06-18 09:55:24.528976
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:33.493865
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing
    import tornado.concurrent
    import concurrent.futures

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()  # type: Future[int]
            f2 = Future()  # type: Future[int]
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)


# Generated at 2022-06-18 09:55:43.793570
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    assert f2.exception() is not None
    assert isinstance(f2.exception(), ValueError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:55:50.631214
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class MyTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            super(MyTestCase, self).tearDown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)

    unittest.main()

# Generated at 2022-06-18 09:55:56.944026
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()
    future = Future()
    future.set_result("result")
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

# Generated at 2022-06-18 09:56:01.282960
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()

# Generated at 2022-06-18 09:56:11.460368
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, f2.result)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.cancel()
            f1.set_result(42)
            self.assertTrue

# Generated at 2022-06-18 09:56:20.473602
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_

# Generated at 2022-06-18 09:56:59.036357
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:08.394407
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import concurrent.futures

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()

        @run_on_executor
        def func(self, a, b):
            return a + b

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            result = yield self.func(1, 2)
            self.assertEqual(result, 3)


# Generated at 2022-06-18 09:57:13.099146
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:17.307397
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:57:28.034467
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            # type: () -> None
            self.executor.shutdown()
            super(TestChainFuture, self).tearDown()

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual

# Generated at 2022-06-18 09:57:39.722690
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close()

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError("test"))

# Generated at 2022-06-18 09:57:47.844443
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing
    import tornado.gen

    @tornado.gen.coroutine
    def f():
        raise tornado.gen.Return(42)

    @tornado.gen.coroutine
    def g():
        result = yield f()
        raise tornado.gen.Return(result)

    @tornado.gen.coroutine
    def h():
        result = yield g()
        raise tornado.gen.Return(result)

    @tornado.testing.gen_test
    def test():
        result = yield h()
        assert result == 42

    test()

# Generated at 2022-06-18 09:57:55.146156
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:58:05.205812
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test_chain_

# Generated at 2022-06-18 09:58:13.730526
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    unittest.main()