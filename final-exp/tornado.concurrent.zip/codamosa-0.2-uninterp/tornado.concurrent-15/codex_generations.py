

# Generated at 2022-06-18 09:49:20.772281
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor(executor="executor")
        def blocking(self):
            return 42

        @gen_test
        def test_chain_future(self):
            f = self.blocking()
            g = Future()
            chain_future(f, g)

# Generated at 2022-06-18 09:49:23.542090
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b):
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3


# Generated at 2022-06-18 09:49:27.425400
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:49:36.638406
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    with pytest.raises(ValueError):
        f2.result()

    f1 = Future()  # type: Future[int]
    f2 = Future()  # type: Future[int]
    chain_future(f1, f2)
    f2.cancel()

# Generated at 2022-06-18 09:49:48.097101
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    f2.cancel()
    assert f2.cancelled()

    f

# Generated at 2022-06-18 09:49:57.593191
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:50:04.125031
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

        @gen_test
        def test_chain_future_cancel(self):
            f1 = Future()
            f2

# Generated at 2022-06-18 09:50:17.412471
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future

    class MyTestCase(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.io_loop.set_default_executor(self.executor)

        def tearDown(self):
            super(MyTestCase, self).tearDown()
            self.executor.shutdown()

        @run_on_executor
        def blocking_func(self):
            return 42


# Generated at 2022-06-18 09:50:29.990354
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    try:
        f2.result()
    except ValueError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    f2.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:50:41.450187
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f

# Generated at 2022-06-18 09:50:56.826080
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:51:10.224634
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    def f():
        time.sleep(0.01)
        return 42

    class Test(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception())

        def test_chain_future_already_completed(self):
            f1 = Future()
            f2 = Future

# Generated at 2022-06-18 09:51:13.055329
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:51:20.403182
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:51:25.248732
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()


# Generated at 2022-06-18 09:51:29.907310
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.result() == 'foo'
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 'foo')
    assert future.cancelled()



# Generated at 2022-06-18 09:51:32.730569
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()


# Generated at 2022-06-18 09:51:40.174451
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:51:46.371782
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:51:50.586032
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:52:15.244041
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import functools
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestRunOnExecutor(AsyncTestCase):
        def setUp(self):
            super(TestRunOnExecutor, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, arg1, arg2, kwarg1=None, kwarg2=None):
            self.assertIs(self.io_loop, IOLoop.current())
            return arg1, arg2, kwarg1, kwarg2


# Generated at 2022-06-18 09:52:25.440414
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_result, 42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_exception, ValueError())
    try:
        f2.result()
        assert False
    except ValueError:
        pass

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback

# Generated at 2022-06-18 09:52:29.986855
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:39.895875
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(RuntimeError())
            self.assertTrue(f2.exception() is not None)

            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f2.set_result(42)
            f1.set_result(24)

# Generated at 2022-06-18 09:52:45.454717
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("foo"))
    assert future.exception() is None

# Generated at 2022-06-18 09:52:58.237288
# Unit test for function run_on_executor
def test_run_on_executor():
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        def setUp(self):
            super(Test, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @run_on_executor
        def blocking(self):
            return 42

        @gen_test
        def test_blocking(self):
            result = yield self.blocking()
            self.assertEqual(result, 42)

        @run_on_executor(executor="executor")
        def blocking_with_arg(self, arg):
            return arg

        @gen_test
        def test_blocking_with_arg(self):
            result = yield self.blocking_with_arg(42)
            self.assertEqual

# Generated at 2022-06-18 09:53:03.226445
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:53:09.297395
# Unit test for function chain_future
def test_chain_future():
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:53:15.594911
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

    IOLoop.current().run_sync(ChainFutureTest("test_chain_future").test_chain_future)

# Generated at 2022-06-18 09:53:21.068190
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42

    test_chain_future()

# Generated at 2022-06-18 09:53:58.051788
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:54:05.328525
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_exception(RuntimeError())

# Generated at 2022-06-18 09:54:16.107603
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:54:26.769136
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.cancel()
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2

# Generated at 2022-06-18 09:54:30.495124
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:54:33.988980
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:54:37.255574
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "result")
    assert future.result() == "result"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "result")
    assert future.cancelled()



# Generated at 2022-06-18 09:54:40.032653
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future():
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert (yield f2) == 42

    test_chain_future()

# Generated at 2022-06-18 09:54:47.475612
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test_chain_future()

# Generated at 2022-06-18 09:54:53.222912
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        # type: () -> None
        f = Future()
        g = Future()
        chain_future(f, g)
        f.set_result(42)
        assert (yield g) == 42

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        # type: () -> None
        f = futures.Future()
        g = Future()
        chain_future(f, g)
        f.set_result(42)
        assert (yield g) == 42

    test_chain_future_asyncio()
    test_chain_future_concurrent()



# Generated at 2022-06-18 09:55:49.397421
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_result(42)
            self.assertEqual(g.result(), 42)

            f = Future()
            g = Future()
            chain_future(f, g)
            f.set_exception(RuntimeError("foo"))
            self.assertEqual(g.exception().args, ("foo",))

            f = Future()
            g = Future()
            chain_future(f, g)
            g.set_result(42)
            f.set_result(24)
            self.assertEqual(g.result(), 42)

            f = Future()

# Generated at 2022-06-18 09:55:53.895075
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:55:56.507893
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:56:06.134446
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import time
    import threading

    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        def test_run_on_executor(self):
            @run_on_executor
            def f(x):
                time.sleep(0.01)
                return x + 1

            @run_on_executor(executor="executor")
            def g(x):
                time.sleep(0.01)
                return x + 1


# Generated at 2022-06-18 09:56:16.136529
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import tornado.testing
    import tornado.concurrent
    import tornado.platform.asyncio

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.platform.asyncio.AsyncIOMainLoop()
            self.io_loop.make_current()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_run_on_executor(self):
            @run_on_executor
            def f(x, y):
                return x + y


# Generated at 2022-06-18 09:56:25.158107
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.platform.asyncio import to_asyncio_future

    class Test(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg

    class TestAsync(object):
        executor = dummy_executor

        @run_on_executor
        async def func(self, arg):
            return arg

    class TestWithCallback(object):
        executor = dummy_executor

        @run_on_executor
        def func(self, arg, callback):
            callback(arg)

    class TestAsyncWithCallback(object):
        executor = dummy_executor


# Generated at 2022-06-18 09:56:29.595989
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()

# Generated at 2022-06-18 09:56:33.461257
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "test")
    assert future.cancelled()



# Generated at 2022-06-18 09:56:43.531333
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()
            self.thread_id = None

        @run_on_executor
        def func(self):
            self.thread_id = threading.current_thread().ident
            time.sleep(0.01)
            return 42

    class TestFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.test = Test()


# Generated at 2022-06-18 09:56:51.095949
# Unit test for function chain_future
def test_chain_future():
    import time
    import unittest
    from tornado.ioloop import IOLoop

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertTrue(f2.done())
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()