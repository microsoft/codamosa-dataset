

# Generated at 2022-06-18 09:49:15.902517
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(None)
            yield f2
            self.assertTrue(f2.done())


# Generated at 2022-06-18 09:49:25.429995
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ValueError())
    try:
        f2.result()
    except ValueError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()
   

# Generated at 2022-06-18 09:49:34.524587
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    loop = IOLoop.current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_result(42)
    loop.run_sync(lambda: f2)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    assert not f2.done()
    f1.set_exception(ValueError())
    loop.run_sync(lambda: f2)
    assert isinstance(f2.exception(), ValueError)

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

# Generated at 2022-06-18 09:49:41.054416
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import concurrent.futures
    import tornado.testing
    import tornado.platform.asyncio
    import asyncio

    class TestRunOnExecutor(unittest.TestCase):
        def setUp(self):
            self.io_loop = tornado.testing.AsyncTestCase.get_new_ioloop()
            self.executor = concurrent.futures.ThreadPoolExecutor(1)
            self.executor2 = concurrent.futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.executor2.shutdown()

        @tornado.testing.gen_test
        def test_run_on_executor(self):
            @run_on_executor
            def f(x):
                return x + 1



# Generated at 2022-06-18 09:49:50.156707
# Unit test for function chain_future
def test_chain_future():
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()
    try:
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_result(42)
        assert f2.result() == 42
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        f1.set_exception(ZeroDivisionError())
        try:
            f2.result()
        except ZeroDivisionError:
            pass
        else:
            assert False
    finally:
        io_loop.clear_current()

# Generated at 2022-06-18 09:49:58.327188
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test = TestChainFuture()
    test.setUp()
    test.test_chain_future()

# Generated at 2022-06-18 09:50:04.589776
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_result(42)
            self.assertEqual(b.result(), 42)

        def test_chain_future_exception(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            a.set_exception(RuntimeError("test"))
            self.assertRaises(RuntimeError, b.result)

        def test_chain_future_cancel(self):
            a = Future()
            b = Future()
            chain_future(a, b)
            b.cancel()
            a.set_result(42)


# Generated at 2022-06-18 09:50:13.974698
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future(self):
        # type: (tornado.testing.AsyncTestCase) -> None
        f1 = Future()
        f2 = Future()
        chain_future(f1, f2)
        self.assertFalse(f2.done())
        f1.set_result(42)
        result = yield f2
        self.assertEqual(result, 42)

    unittest.main()

# Generated at 2022-06-18 09:50:26.297913
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    import asyncio
    import concurrent.futures
    import functools

    def f(x: int) -> int:
        return x + 1

    def g(x: int) -> int:
        return x + 2

    def h(x: int) -> int:
        return x + 3

    def test(f: Callable[[int], int], x: int, expected: int) -> None:
        loop = asyncio.get_event_loop()
        future = to_asyncio_future(dummy_executor.submit(f, x))
        loop.run_until_complete(future)
        assert future.result() == expected

    test(f, 1, 2)

# Generated at 2022-06-18 09:50:28.395102
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:50:43.518955
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    # This test is not run by the normal test suite because it uses
    # private APIs.
    from tornado.ioloop import IOLoop

    loop = IOLoop()
    loop.make_current()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    assert f2.exception() is not None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
   

# Generated at 2022-06-18 09:50:51.097738
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:03.246354
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import threading

    class ChainFutureTest(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()
            self.executor = ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.clear_current()

        def test_chain_future(self):
            @run_on_executor
            def wait_for_result(future, timeout):
                time.sleep(timeout)
                future.set_result(42)

            f = Future()
            wait_for_result(f, 0.1)
            f2 = Future()
            chain_future(f, f2)
            self.assertE

# Generated at 2022-06-18 09:51:09.862165
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:17.854895
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.run()

# Generated at 2022-06-18 09:51:25.973463
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(42, (yield f2))

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:51:30.454315
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:51:36.147756
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def f(self):
            return 42

    t = Test()
    f = t.f()
    assert isinstance(f, Future)
    assert not f.done()
    IOLoop.current().run_sync(f)
    assert f.result() == 42

    # Test that the executor is taken from the instance, not the class
    t2 = Test()
    t2.executor = None
    with unittest.mock.patch.object(t, "executor") as mock_executor:
        t2.f()
    mock_executor.submit.assert_called_once_

# Generated at 2022-06-18 09:51:42.061060
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    # type: () -> None
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:51:49.704976
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.test_chain_future()

# Generated at 2022-06-18 09:52:11.915338
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:52:23.531124
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.io_loop.make_current()

        def tearDown(self):
            self.io_loop.clear_current()
            self.io_loop.close(all_fds=True)

        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1

# Generated at 2022-06-18 09:52:28.757793
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:39.087599
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    import threading
    import time

    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor
            self.io_loop = IOLoop.current()
            self.thread_id = None
            self.result = None

        @run_on_executor
        def f(self):
            self.thread_id = threading.current_thread().ident
            time.sleep(0.01)
            return 42

        @run_on_executor
        def g(self, a, b):
            return a + b

        @run_on_executor(executor='_thread_pool')
        def h(self):
            pass


# Generated at 2022-06-18 09:52:48.285010
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class Test(object):
        def __init__(self):
            self.executor = dummy_executor

        @run_on_executor
        def func(self, arg):
            return arg

    class TestCase(unittest.TestCase):
        def test_run_on_executor(self):
            test = Test()
            future = test.func(42)
            IOLoop.current().run_sync(future.result)
            self.assertEqual(future.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:52:54.075075
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, "foo")
    assert future.result() == "foo"

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, "foo")
    assert future.cancelled()



# Generated at 2022-06-18 09:53:00.705514
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:53:05.726787
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.exception() is None

# Generated at 2022-06-18 09:53:15.956619
# Unit test for function chain_future
def test_chain_future():
    def f(x):
        return x + 1

    def g(x):
        return x * 2

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_result(1)
    assert b.result() == 1

    a = Future()
    b = Future()
    chain_future(a, b)
    a.set_exception(ZeroDivisionError())
    try:
        b.result()
        assert False
    except ZeroDivisionError:
        pass

    a = Future()
    b = Future()
    c = Future()
    chain_future(a, b)
    chain_future(b, c)
    a.set_result(1)
    assert b.result() == 1
    assert c.result() == 1

    a = Future()

# Generated at 2022-06-18 09:53:28.588808
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def setUp(self):
            # type: () -> None
            super(TestChainFuture, self).setUp()
            self.executor = futures.ThreadPoolExecutor(1)

        @gen_test
        def test_chain_future(self):
            # type: () -> None
            f1 = self.executor.submit(lambda: 1 / 0)
            f2 = Future()
            chain_future(f1, f2)
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:53:48.365406
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a, b, c):
        return a + b + c

    future = dummy_executor.submit(test_func, 1, 2, 3)
    assert future.result() == 6

# Generated at 2022-06-18 09:53:53.482076
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    future_set_result_unless_cancelled(f, 1)
    assert f.result() == 1
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 1)
    assert f.cancelled()


# Generated at 2022-06-18 09:53:59.860483
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:54:05.752786
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import tornado.testing

    @tornado.testing.gen_test
    def test_chain_future_asyncio():
        # type: () -> None
        f = Future()
        f2 = Future()
        chain_future(f, f2)
        f.set_result(42)
        assert (yield f2) == 42

    @tornado.testing.gen_test
    def test_chain_future_concurrent():
        # type: () -> None
        f = futures.Future()
        f2 = Future()
        chain_future(f, f2)
        f.set_result(42)
        assert (yield f2) == 42

    test_chain_future_asyncio()
    test_chain_future_concurrent()

# Generated at 2022-06-18 09:54:11.441663
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:54:19.256694
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError())
    try:
        f2.result()
    except RuntimeError:
        pass
    else:
        assert False, "should have raised"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:54:23.153034
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def test_func(a: int, b: int) -> int:
        return a + b

    future = dummy_executor.submit(test_func, 1, 2)
    assert future.result() == 3



# Generated at 2022-06-18 09:54:27.127695
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result() == 1
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 1)
    assert future.cancelled()



# Generated at 2022-06-18 09:54:32.463258
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    import unittest
    import tornado.testing

    class ChainFutureTest(tornado.testing.AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    tornado.testing.main()

# Generated at 2022-06-18 09:54:43.234262
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.ioloop import IOLoop

    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_result, 42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    io_loop.add_callback(f1.set_exception, ValueError("foo"))
    try:
        f2.result()
        assert False, "expected exception"
    except ValueError as e:
        assert str(e) == "foo"

    f1 = Future()
    f2 = Future()
    chain_

# Generated at 2022-06-18 09:55:21.957529
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2


# Generated at 2022-06-18 09:55:29.983599
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado.ioloop import IOLoop

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.io_loop = IOLoop()
            self.executor = futures.ThreadPoolExecutor(1)

        def tearDown(self):
            self.executor.shutdown()
            self.io_loop.close()

        @run_on_executor
        def func(self, arg):
            return arg + 1

        def test_run_on_executor(self):
            f = self.func(41)
            self.assertEqual(f.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:35.524664
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.testing import AsyncTestCase, gen_test

    class ChainFutureTest(AsyncTestCase):
        @gen_test
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            self.assertFalse(f2.done())
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:55:45.536252
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
        assert False
    except ZeroDivisionError:
        pass
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)

# Generated at 2022-06-18 09:55:47.909556
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(a, b):
        return a + b
    future = dummy_executor.submit(func, 1, 2)
    assert future.result() == 3

# Generated at 2022-06-18 09:55:52.545918
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:55:58.189498
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    test = TestChainFuture()
    test.run_sync(test.test_chain_future)

# Generated at 2022-06-18 09:56:02.011877
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42
    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()


# Generated at 2022-06-18 09:56:07.938152
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time

    class TestChainFuture(unittest.TestCase):
        def test_chain_future(self):
            loop = asyncio.get_event_loop()
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            loop.run_until_complete(f2)
            self.assertEqual(f2.result(), 42)

    unittest.main()

# Generated at 2022-06-18 09:56:14.880780
# Unit test for function chain_future
def test_chain_future():
    import unittest

    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

    io_loop = IOLoop()
    io_loop.run_sync(ChainFutureTest().test_chain_future)

# Generated at 2022-06-18 09:58:03.130699
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(ZeroDivisionError())
    try:
        f2.result()
    except ZeroDivisionError:
        pass
    else:
        assert False, "did not propagate exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.set_result(42)
    assert f1.done()
    assert f2.result() == 42

    f1 = Future()

# Generated at 2022-06-18 09:58:06.038229
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, RuntimeError("test"))
    assert future.exception() is None

# Generated at 2022-06-18 09:58:14.681622
# Unit test for function chain_future
def test_chain_future():
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exception(self):
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test_chain_future()

# Generated at 2022-06-18 09:58:24.378582
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_result(42)
    assert f2.result() == 42

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f1.set_exception(RuntimeError("foo"))
    try:
        f2.result()
    except RuntimeError as e:
        assert str(e) == "foo"
    else:
        assert False, "expected exception"

    f1 = Future()
    f2 = Future()
    chain_future(f1, f2)
    f2.cancel()
    f1.set_result(42)
    assert f2.cancelled()

    f1 = Future()
    f2 = Future()

# Generated at 2022-06-18 09:58:27.044110
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:36.775752
# Unit test for function chain_future
def test_chain_future():
    import unittest
    import time
    import concurrent.futures
    from tornado.ioloop import IOLoop

    class ChainFutureTest(unittest.TestCase):
        def test_chain_future(self):
            # type: () -> None
            executor = concurrent.futures.ThreadPoolExecutor(1)

# Generated at 2022-06-18 09:58:46.473000
# Unit test for function chain_future
def test_chain_future():
    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_result(42)
    assert g.result() == 42

    f = Future()
    g = Future()
    chain_future(f, g)
    f.set_exception(RuntimeError())
    assert g.exception() is not None
    assert isinstance(g.exception(), RuntimeError)

    f = Future()
    g = Future()
    chain_future(f, g)
    g.set_result(42)
    f.set_result(24)
    assert g.result() == 42

    f = Future()
    g = Future()
    chain_future(f, g)
    g.set_exception(RuntimeError())
    f.set_result(24)

# Generated at 2022-06-18 09:58:49.365900
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-18 09:58:51.755979
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future = Future()
    future.cancel()
    future_set_result_unless_cancelled(future, 42)
    assert future.cancelled()



# Generated at 2022-06-18 09:58:56.781421
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import AsyncTestCase, gen_test

    class TestChainFuture(AsyncTestCase):
        def test_chain_future(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_result(42)
            self.assertEqual(f2.result(), 42)

        @gen_test
        def test_chain_future_exc_info(self):
            # type: () -> None
            f1 = Future()
            f2 = Future()
            chain_future(f1, f2)
            f1.set_exception(ZeroDivisionError())
            with self.assertRaises(ZeroDivisionError):
                yield f2

    test_chain_