

# Generated at 2022-06-22 03:28:13.821951
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    """Unit test for constructor of class ReturnValueIgnoredError."""
    e = ReturnValueIgnoredError('message', None)
    assert e.__str__() == 'message'

# Generated at 2022-06-22 03:28:17.199386
# Unit test for function is_future
def test_is_future():
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future("s")


# Generated at 2022-06-22 03:28:18.380118
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    pass


# Generated at 2022-06-22 03:28:26.611581
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    import unittest.mock

    @run_on_executor
    def fn():
        return 5

    fn.executor = unittest.mock.Mock()
    fn()
    fn.executor.submit.assert_called_with(fn)

    # test that run_on_executor is usable as a class method
    @run_on_executor(executor="thread_pool")
    def fn2(self):
        assert self is x

    class Magic(object):
        executor = "thread_pool"
        fn2 = staticmethod(fn2)

    x = Magic()
    x.fn2()
    # magic attribute not present

# Generated at 2022-06-22 03:28:30.089157
# Unit test for function is_future
def test_is_future():
    assert(is_future(Future()))
    assert(not is_future(futures.Future()))
    assert(not is_future(3))
    assert(not is_future(Future.__init__))

# Generated at 2022-06-22 03:28:38.676724
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado.ioloop import IOLoop

    e = DummyExecutor()
    f = e.submit(lambda : 10)
    assert f.result() == 10

    def g() -> int:
        return f.result()

    f2 = e.submit(g)
    assert f2.result() == 10

    def h() -> int:
        raise Exception()

    f3 = e.submit(h)
    assert f3.result() is None
    assert f3.exception() is not None

# Generated at 2022-06-22 03:28:47.804576
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest
    from tornado import gen
    from tornado.platform.asyncio import AsyncIOMainLoop
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class AsyncioTestMixin:
        def get_new_ioloop(self):
            loop = AsyncIOMainLoop()
            loop.make_current()
            return loop

        def tearDown(self):
            loop = asyncio.get_event_loop()
            loop.close()

    class MyTestCase(AsyncioTestMixin, AsyncHTTPTestCase):
        def setUp(self):
            super(MyTestCase, self).setUp()
            self.executor = concurrent.futures.ThreadPoolExecutor(2)


# Generated at 2022-06-22 03:28:52.929110
# Unit test for function chain_future
def test_chain_future():
    from tornado import gen

    future1_result = object()
    future2_result = object()

    @gen.coroutine
    def f():
        return future1_result

    @gen.coroutine
    def g():
        return future2_result

    f1 = f()
    f2 = f1.clone()
    chain_future(f1, f2)
    assert f1 is not f2
    assert f1._state is f2._state
    assert f1.done() is f2.done()
    assert not f1.done()
    f2.add_done_callback(lambda f: f.result())
    r = gen.convert_yielded(f2)
    assert r is future1_result

    # Test with futures.Future
    f1 = futures.Future()
    chain_future

# Generated at 2022-06-22 03:28:54.919503
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    from tornado.concurrent import Future
    def fn():
        pass
    e = dummy_executor
    f = e.submit(fn)
    assert isinstance(f, Future)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 03:28:57.381634
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is not None

    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception())
    assert future.exception() is None

# Generated at 2022-06-22 03:32:24.777926
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    # type: () -> None
    my_future = Future()  # type: Future[int]
    future_add_done_callback(my_future, lambda my_future: None)
    my_future.set_result(42)



# Generated at 2022-06-22 03:32:29.541709
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    import tornado
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    future = future_set_result_unless_cancelled(future, "test")
    assert future.result() == "test"
    import tornado.ioloop
    tornado.ioloop.IOLoop.instance().start()


# Generated at 2022-06-22 03:32:37.993523
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class TestException(Exception):
        pass
    class TestFuture(Future):
        def __init__(self, cancelled: bool) -> None:
            super().__init__()
            self._cancelled = cancelled
            self._exc = None

        def cancelled(self) -> bool:
            return self._cancelled

        def exception(self) -> Optional[BaseException]:
            return self._exc

        def set_exception(self, exception: BaseException) -> None:
            self._exc = exception

    future_set_exception_unless_cancelled(TestFuture(False), TestException())
    exc = TestFuture(True).exception()
    assert exc is not None
    assert isinstance(exc, TestException)

# Generated at 2022-06-22 03:32:40.144304
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    # type: () -> None
    with ReturnValueIgnoredError("test") as e:
        raise ReturnValueIgnoredError("test")

# Generated at 2022-06-22 03:32:42.353025
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown(): pass

# Generated at 2022-06-22 03:32:46.691205
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    # type: () -> None
    data = []
    def f():
        data.append(1)
        return 2
    future = dummy_executor.submit(f)
    assert data == [1]
    assert future.result() == 2

# Generated at 2022-06-22 03:32:55.808411
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    result = Future()
    exc = ValueError('test')
    future_set_exception_unless_cancelled(result, exc)
    assert result.exception() == exc
    # call twice to make sure second time is no-op and does not raise an error
    future_set_exception_unless_cancelled(result, exc)
    assert result.exception() == exc
    # Cancel the future and make sure that an exception is not raised.
    result.cancel()
    future_set_exception_unless_cancelled(result, exc)
    assert result.exception() is None

# Generated at 2022-06-22 03:32:59.436548
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, 4)
    assert f.cancelled()

# Generated at 2022-06-22 03:33:06.921122
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    async def test(future):
        future_set_exception_unless_cancelled(future, Exception())
        assert future.done()
        assert future.exception() is None
        future.cancel()
        future_set_exception_unless_cancelled(future, Exception())
        future.cancel()
    ioloop = IOLoop()
    future = Future()
    ioloop.add_future(test(future), lambda future: ioloop.stop())
    ioloop.start()

# Generated at 2022-06-22 03:33:11.126598
# Unit test for function is_future
def test_is_future():
    assert not is_future(None)
    assert not is_future(True)
    assert not is_future(object())
    assert not is_future(Future())
    assert not is_future(asyncio.Future())
    assert is_future(futures.Future())
    assert is_future(asyncio.ensure_future(Future()))



# Generated at 2022-06-22 03:36:01.275008
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    assert not future.done()
    future_set_result_unless_cancelled(future, 123)
    assert future.done()
    assert future.result() == 123

    future = Future()
    future.cancel()
    assert future.done()
    assert future.cancelled()
    future_set_result_unless_cancelled(future, 123)
    assert future.done()
    assert future.cancelled()
    assert future.result() is None

# Generated at 2022-06-22 03:36:11.946274
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    from tornado import gen
    from tornado.testing import AsyncTestCase

    io_loop = asyncio.new_event_loop()
    asyncio.set_event_loop(io_loop)

    executor = DummyExecutor()
    @gen.coroutine
    def coroutine():
        pass

    @run_on_executor(executor=executor)
    def blocking_func():
        raise ValueError('passed')

    blocking_func()

    @gen.coroutine
    async def async_func():
        pass

    with AsyncTestCase().assertRaises(TypeError):
        executor.submit(coroutine)

    with AsyncTestCase().assertRaises(TypeError):
        executor.submit(async_func)

# Generated at 2022-06-22 03:36:19.135817
# Unit test for function run_on_executor
def test_run_on_executor():
    # type: () -> None
    # Use no blocking-call preempted by other process
    import time

    executor = futures.ThreadPoolExecutor(1)

    class Test(object):
        executor = executor

        @run_on_executor
        def f(self):
            # type: () -> Future[Any]
            time.sleep(0.1)
            return 42

    test = Test()
    future = test.f()

    assert future.result() == 42



# Generated at 2022-06-22 03:36:21.338396
# Unit test for method shutdown of class DummyExecutor
def test_DummyExecutor_shutdown():
    d = DummyExecutor()
    d.shutdown()
    # print(d.submit(lambda: print("Unit test for DummyExecutor")))

# Generated at 2022-06-22 03:36:25.570741
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    assert is_future(Future())
    assert is_future(futures.Future())
    assert not is_future(None)

# Generated at 2022-06-22 03:36:36.416368
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    def f():
        future_set_exc_info(fut, sys.exc_info())
        raise Exception('should not reach here')

    fut = Future()
    try:
        f()
    except:
        pass
    assert not fut.done()
    future_set_exc_info(fut, sys.exc_info())
    assert fut.done()
    assert isinstance(fut.exception(), Exception)



# Generated at 2022-06-22 03:36:39.279810
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_exception_unless_cancelled(f, ValueError())

# Generated at 2022-06-22 03:36:40.713264
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():  # noqa: F811
    try:
        raise ReturnValueIgnoredError()
    except ReturnValueIgnoredError:
        pass

# Generated at 2022-06-22 03:36:50.048508
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()

    future_set_result_unless_cancelled(future, 42)
    assert future.result() == 42

    future_set_result_unless_cancelled(future, 43)
    assert future.result() == 42

    future = Future()
    future_set_result_unless_cancelled(future, 42)

    future_set_result_unless_cancelled(future, 43)
    assert future.result() == 42

    future = Future()
    future_set_result_unless_cancelled(future, 42)
    future.cancel()

    future_set_result_unless_cancelled(future, 43)



# Generated at 2022-06-22 03:36:57.361255
# Unit test for function run_on_executor
def test_run_on_executor():  # pragma: no cover

    from tornado.ioloop import IOLoop

    class MyClass:
        def __init__(
            self,
            executor: "Optional[futures.ThreadPoolExecutor] = None"
        ) -> None:
            self.executor = executor or dummy_executor
            self.result = None  # type: Any

        @run_on_executor()
        def foo(self, x: int) -> int:
            self.result = x
            return x ** 2

    ioloop = IOLoop.current()

    obj = MyClass()
    obj.foo(10)
    ioloop.add_future(
        obj.foo, lambda future: ioloop.stop()
    )  # type: ignore  # https://github.com/python/mypy/issues/5