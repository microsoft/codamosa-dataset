

# Generated at 2022-06-22 03:28:06.639498
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    f = Future()
    f.cancel()

    try:
        1 / 0
    except Exception as e:
        exc = e

    future_set_exception_unless_cancelled(f, exc)

    # future_set_exception_unless_cancelled does not raise exception, but logs it
    # instead (see the method's docstring)

    if not f.done():
        raise Exception("future_set_exception_unless_cancelled does not set result/exception")

# Generated at 2022-06-22 03:28:15.511231
# Unit test for function chain_future
def test_chain_future():
    # type: () -> None
    from tornado.testing import gen_test
    from tornado.concurrent import Future

    @gen_test
    def test():
        # type: () -> None
        f1 = Future()
        f2 = Future()
        f3 = Future()
        chain_future(f1, f2)
        chain_future(f2, f3)
        f1.set_result(42)
        assert 42 == (yield f1)
        assert 42 == (yield f2)
        assert 42 == (yield f3)

    test()



# Generated at 2022-06-22 03:28:19.363110
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():

    def test():
        return 1

    test_result = dummy_executor.submit(test)
    assert test_result.result() == 1

test_DummyExecutor_submit()

# Generated at 2022-06-22 03:28:24.703436
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    f = Future()
    f.cancel()
    future_set_result_unless_cancelled(f, None)
    try:
        f.result()
    except Exception as e:
        assert type(e) is asyncio.CancelledError
    try:
        f.exception()
    except Exception as e:
        assert type(e) is asyncio.CancelledError
    future_set_result_unless_cancelled(f, None)



# Generated at 2022-06-22 03:28:33.735905
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    class Future(asyncio.Future):
        def __init__(self, *args, **kwargs):
            super(Future, self).__init__(*args, **kwargs)
            self._exception = None

        def exception(self):
            return self._exception

        def set_exception(self, exception):
            self._exception = exception

    # Test that exception can be set
    future = Future()
    future_set_exception_unless_cancelled(future, Exception('msg'))
    assert future.exception() is not None

    # Test that exception is not set
    future = Future()
    future.cancel()
    future_set_exception_unless_cancelled(future, Exception('msg'))
    assert future.exception() is None

# Generated at 2022-06-22 03:28:42.632397
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    class Future:
        def __init__(self):
            self.result: Any = None
            self.cancelled = False
        def set_result(self, result):
            assert self.cancelled == False
            self.result = result
        def cancelled(self):
            return self.cancelled

    future = Future()
    future_set_result_unless_cancelled(future, 1)
    assert future.result == 1
    future.cancelled = True
    future_set_result_unless_cancelled(future, 2)
    assert future.result == 1

# Generated at 2022-06-22 03:28:44.827851
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    a=DummyExecutor()
    z=asyncio.Future()
    assert isinstance(z, asyncio.Future)

# Generated at 2022-06-22 03:28:49.186552
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    d = DummyExecutor()
    assert d.submit(lambda x: x, 42).result() == 42
    assert d.submit(lambda x: 1 / x, 0).exception().__class__ == ZeroDivisionError

# Generated at 2022-06-22 03:28:52.676392
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    future = Future()
    exc = Exception()
    future_set_exception_unless_cancelled(future, exc)
    assert future.exception() is exc
    future.cancel()
    assert future.exception() is exc

# Generated at 2022-06-22 03:28:58.654638
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    from tornado import gen
    from tornado.ioloop import IOLoop

    class MyException(Exception):
        pass

    @gen.coroutine
    def f():
        raise MyException()
        
    future = f()
    future.cancel()
    future_set_exception_unless_cancelled(future, MyException())

    with pytest.raises(MyException):
        IOLoop.current().run_sync(f)



# Generated at 2022-06-22 03:29:12.343843
# Unit test for function chain_future
def test_chain_future():
    f1 = Future()
    f2 = Future()
    f3 = Future()
    chain_future(f1, f2)
    chain_future(f1, f3)
    f1.set_result(3)
    assert f2.result() == 3
    assert f3.result() == 3
    try:
        f2.set_result(5)
    except Exception:
        pass
    else:
        assert False, "second set_result should fail"
    assert f3.result() == 3

# Generated at 2022-06-22 03:29:14.337212
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    assert dummy_executor.submit(lambda x : x, 42)

# Generated at 2022-06-22 03:29:26.622494
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    import tornado.ioloop
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    async_future = Future()
    sync_future = futures.Future()

    # Ensure that callback is invoked immediately if Future is already done
    result = []
    future_add_done_callback(async_future, result.append)
    future_add_done_callback(sync_future, result.append)
    async_future.set_result(None)
    sync_future.set_result(None)
    assert result == [async_future, sync_future]

    # Ensure that callback is invoked when Future completes
    result = []
    f = Future()
    future_add_done_callback(f, result.append)

# Generated at 2022-06-22 03:29:38.330939
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # DummyExecutor can be used for non-threaded or single-threaded unittests.
    from tornado.ioloop import IOLoop

    @run_on_executor
    def function(arg, kwarg=None):
        return arg, kwarg

    v1 = 1
    v2 = 2
    v3 = 3
    io_loop = IOLoop.current()
    future1 = function(v1, kwarg=v2)
    future2 = function(v2, kwarg=v3)
    future3 = function(v3, kwarg=v1)
    future1.add_done_callback(
        lambda f: io_loop.add_callback(functools.partial(f.result, v1, v2))
    )

# Generated at 2022-06-22 03:29:44.372424
# Unit test for function is_future
def test_is_future():
    print('TEST: future_test.test_is_future')
    print('EXPECT: True')
    print(is_future(future_add_done_callback))
    print('EXPECT: True')
    print(is_future(Future()))

# Run the unit tests if this file is executed directly
if __name__ == '__main__':
    test_is_future()

# Generated at 2022-06-22 03:29:50.551429
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    print("测试开始：")
    a = DummyExecutor()
    b = a.submit(lambda x: x*x, 2)
    print("submit:")
    print(b)

    print("shutdown:")
    a.shutdown()

    print("测试结束")


# Generated at 2022-06-22 03:29:52.835961
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def func(x):
        return 10*x
    dummy_executor.submit(func,5)


# Generated at 2022-06-22 03:29:54.013410
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    asyncio.Future()

# Generated at 2022-06-22 03:30:04.983276
# Unit test for function run_on_executor
def test_run_on_executor():
    import unittest

    import concurrent.futures
    import functools

    from tornado.platform.asyncio import AsyncIOMainLoop
    import tornado.testing
    import tornado.test.util

    def dummy_executor():
        return concurrent.futures.ThreadPoolExecutor(0)

    class AsyncClass(object):
        def __init__(self):
            self.executor = dummy_executor()

        def foo(self, callback):
            def run():
                return callback(42)

            return self.executor.submit(run)

        @run_on_executor
        def bar(self, x, callback):
            future = self.foo(callback)
            return future.result() * x


# Generated at 2022-06-22 03:30:08.615761
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    _future = futures.Future()
    _future_list = []
    future_add_done_callback(_future, _future_list.append)
    assert not _future_list
    _future.set_result(None)
    assert _future is _future_list[0]



# Generated at 2022-06-22 03:30:23.727585
# Unit test for function run_on_executor
def test_run_on_executor():
    import time
    import unittest
    from unittest import mock
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    class Foo(object):
        executor = dummy_executor

        @run_on_executor
        def bar(self):
            time.sleep(0.01)
            return "done"

        def bar2(self):
            time.sleep(0.01)
            return "done"

        @run_on_executor(executor="_executor")
        def bar3(self):
            time.sleep(0.01)
            return "done"

        @run_on_executor
        def baz(self):
            raise Exception("error")

        _executor = mock.MagicMock()

    f = Foo()

# Generated at 2022-06-22 03:30:32.861930
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    testFuture = Future()
    future_set_result_unless_cancelled(testFuture, "Bingo!")
    assert testFuture.result() == "Bingo!"
    testFuture = Future()
    future_set_result_unless_cancelled(testFuture, "Test")
    testFuture.cancel()
    with pytest.raises(asyncio.InvalidStateError):
        assert testFuture.result()
    testFuture = Future()
    future_set_result_unless_cancelled(testFuture, None)
    assert testFuture.result() == None

# Generated at 2022-06-22 03:30:37.177681
# Unit test for constructor of class ReturnValueIgnoredError
def test_ReturnValueIgnoredError():
    try:
        raise ReturnValueIgnoredError()
    except Exception as e:
        assert isinstance(e, ReturnValueIgnoredError)
        assert type(e) is ReturnValueIgnoredError
        assert isinstance(e, Exception)
        assert type(e) is not Exception

# Generated at 2022-06-22 03:30:48.683670
# Unit test for function chain_future
def test_chain_future():
    io_loop = IOLoop()
    io_loop.make_current()

    f1 = Future()

    from tornado.concurrent import Future as cf
    f2 = cf()

    chain_future(f1, f2)

    # Check that chained future starts in same state.
    assert not f2.done()
    assert not f2.cancelled()
    assert f2.exception() is None
    assert f2.result() is None

    # Create a new future to test that f2's result is ignored
    f3 = Future()
    chain_future(f1, f3)

    # Complete f1 with a result
    f1.set_result("foo")

    # Because f2 was chained to f1, it is now completed as well.
    # Give it a little bit of time.
    io_loop

# Generated at 2022-06-22 03:30:51.870225
# Unit test for constructor of class DummyExecutor
def test_DummyExecutor():
    exe = dummy_executor
    print(exe)

if __name__ == "__main__":
    test_DummyExecutor()

# Generated at 2022-06-22 03:31:00.367902
# Unit test for function chain_future
def test_chain_future():
    import tornado.testing

    io_loop = tornado.testing.AsyncTestCase.io_loop()

    def f1(result, error):
        io_loop.stop()
        if error:
            raise error
        return result

    def f2(result, error):
        io_loop.stop()
        if error:
            raise error
        return result

    def f3(result, error):
        io_loop.stop()
        if error:
            raise error
        return result

    def f4(result, error):
        io_loop.stop()
        if error:
            raise error
        return result

    def f5(result, error):
        io_loop.stop()
        if error:
            raise error
        return result


# Generated at 2022-06-22 03:31:07.268521
# Unit test for function run_on_executor
def test_run_on_executor():
    class A(object):
        executor = dummy_executor

        @run_on_executor
        def f(self):
            return 42

    a = A()
    fut = a.f()
    assert isinstance(fut, Future)
    assert fut.result() == 42
    assert not dummy_executor._shutdown


if __name__ == "__main__":
    test_run_on_executor()

# Generated at 2022-06-22 03:31:09.033144
# Unit test for function is_future
def test_is_future():
    f = Future()
    assert is_future(f)
    assert not is_future(object())

# Generated at 2022-06-22 03:31:15.199256
# Unit test for function future_set_exc_info
def test_future_set_exc_info():
    from tornado import gen, ioloop

    @gen.coroutine
    def test_coroutine():
        future = Future()
        future_set_exc_info(future, sys.exc_info())
        with pytest.raises(Exception):
            yield future

    ioloop.IOLoop.current().run_sync(test_coroutine)



# Generated at 2022-06-22 03:31:20.317014
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    """Tests function future_set_exception_unless_cancelled"""
    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert future.done()
    assert isinstance(future.exception(), ValueError)
    assert not future.cancelled()

# Generated at 2022-06-22 03:31:38.605382
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    import threading
    from concurrent.futures import Future
    from tornado.log import app_log

    future = Future()
    future_set_exception_unless_cancelled(future, ValueError())
    assert not future.done()

    future = Future()
    future.cancel()
    app_log.error = log_error = threading.Event()

    def callback():
        log_error.set()
    future_add_done_callback(future, callback)
    future_set_exception_unless_cancelled(future, ValueError())
    assert log_error.wait(timeout=0.1)


__all__ = [
    "DummyExecutor",
    "Future",
    "ReturnValueIgnoredError",
    "is_future",
    "run_on_executor",
]

# Generated at 2022-06-22 03:31:41.345159
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    def add(a, b):
        return a + b
    a = DummyExecutor()
    fut = a.submit(add, 1, 2)
    print(f"result of fut is {fut.result()}")


# Generated at 2022-06-22 03:31:44.506203
# Unit test for function future_set_result_unless_cancelled
def test_future_set_result_unless_cancelled():
    future = Future()
    future.set_result(None)
    future.cancel()
    future_set_result_unless_cancelled(future, None)
    assert future.cancelled()

# Generated at 2022-06-22 03:31:56.540482
# Unit test for function future_add_done_callback
def test_future_add_done_callback():
    f = Future()
    result = [False]
    future_add_done_callback(f, lambda f : result.__setitem__(0, True))
    f.set_result(None)
    assert result[0] is True

    f = Future()
    result = [False]
    future_add_done_callback(f, lambda f : result.__setitem__(0, True))
    assert result[0] is False
    f.set_result(None)
    assert result[0] is True

    f = Future()
    result = [False]
    future_add_done_callback(f, lambda f : result.__setitem__(0, True))
    assert result[0] is False
    f.set_exception(Exception())
    assert result[0] is True

    f = Future()


# Generated at 2022-06-22 03:32:01.814891
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    # create the future object
    future = dummy_executor.submit(pow, 2, 2) # should return 4
    print('future.done():', future.done())
    print('future.result():', future.result())
    print('future.cancelled():', future.cancelled())
    print('future.running():', future.running())
    print('future.set_running_or_notify_cancel():', future.set_running_or_notify_cancel())
    # future.result() should return 4
    assert(future.result() == 4)

# Generated at 2022-06-22 03:32:13.932084
# Unit test for function run_on_executor
def test_run_on_executor():
    import time
    import unittest
    import concurrent.futures
    import tornado.ioloop
    import tornado.testing

    class Foo(object):
        executor = concurrent.futures.ThreadPoolExecutor(1)

        @run_on_executor
        def func(self, a, b):
            return a + b

        def callback(self, f):
            self.stop()
            self.assertEqual(f.result(), 3)

    def test_run_on_executor_decorator():
        io_loop = tornado.ioloop.IOLoop()
        io_loop.make_current()
        f = Foo()
        f.func(1, 2).add_done_callback(f.callback)
        f.start()
        f.join()

# Generated at 2022-06-22 03:32:15.955619
# Unit test for method submit of class DummyExecutor
def test_DummyExecutor_submit():
    d = DummyExecutor()
    f = d.submit(lambda: "test")
    assert(f.done())
    assert(f.result() == "test")



# Generated at 2022-06-22 03:32:22.533431
# Unit test for function is_future
def test_is_future():
    # type: () -> None
    import asyncio
    from typing import cast

    # New style Future
    assert is_future(Future())
    assert is_future(cast(Future, asyncio.Future()))
    # Old style Future
    assert is_future(futures.Future())
    # Other
    assert not is_future(None)

# Generated at 2022-06-22 03:32:32.420770
# Unit test for function run_on_executor
def test_run_on_executor():
    class IntFuture(Future):
        pass

    class Foo:
        executor = dummy_executor

        @run_on_executor()
        def sync_func(self):
            return 1

        @run_on_executor
        def sync_func2(self):
            return 2

        @run_on_executor(executor='_thread_pool')
        def sync_func3(self):
            return 3

        @run_on_executor(executor=IntFuture)
        def sync_func4(self):
            return 4

    foo = Foo()
    foo._thread_pool = dummy_executor

    assert foo.sync_func() == foo.executor.submit(foo.sync_func)
    assert foo.sync_func2() == foo.executor.submit(foo.sync_func2)


# Generated at 2022-06-22 03:32:38.453124
# Unit test for function future_set_exception_unless_cancelled
def test_future_set_exception_unless_cancelled():
    try:
        raise ValueError("foobar")
    except ValueError as exc:
        ex = exc
        future = Future()
        future_set_exception_unless_cancelled(future, exc)
        assert future.exception() is ex

if __name__ == "__main__":
    import unittest

    test_future_set_exception_unless_cancelled()